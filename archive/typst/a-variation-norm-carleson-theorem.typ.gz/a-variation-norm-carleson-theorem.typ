// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/10/10/a-variation-norm-carleson-theorem/
// Converted to Typst by tao2typ: "2026-10-14T15:17:28.406491+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A variation norm Carleson theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A variation norm Carleson theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 October 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/10/10/a-variation-norm-carleson-theorem/")[#text("https://terrytao.wordpress.com/2009/10/10/a-variation-norm-carleson-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.ucla.edu/people/pages/oberlin.shtml")[#text("Richard Oberlin")]#text(",")#link("http://www.math.wisc.edu/%7Eseeger/")[#text(" Andreas Seeger")]#text(",")#link("http://www.math.ucla.edu/%7Ethiele/")[#text(" Christoph Thiele")]#text(",")#link("http://www.maths.ed.ac.uk/people/show/person/11")[#text(" Jim Wright")]#text(", and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/0910.1555")[#text("A variation norm Carleson theorem")]#text("“, submitted to ")#link("http://www.ems-ph.org/journals/journal.php?jrn=jems")[#text("J. Europ. Math. Soc.")]#text(".")

#text("The celebrated Carleson-Hunt theorem asserts that if ")#mi("f: {\\Bbb R}/{\\Bbb Z} \\to {\\Bbb C}")#text(" is an ")#mi("L^p")#text(" function for some ")#mi("1 < p \\leq \\infty")#text(", then the partial Fourier series")

#align(center)[#tao-fit-display[#mitex("S_n f(x) := \\sum_{k=-n}^n \\hat f(k) e^{2\\pi ikx}")]]

#text("of ")#mi("f")#text(" converge to ")#mi("f")#text(" almost everywhere. (The claim fails for ")#mi("p=1")#text(", as shown by a famous counterexample of Kolmogorov.) The theorem follows easily from the inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| \\sup_n \\left|S_n f(x)\\right| \\right\\|_{L^p({\\Bbb R}/{\\Bbb Z})} \\leq C_p \\left\\| f \\right\\|_{L^p({\\Bbb R}/{\\Bbb Z})},", block: true)]]

#text("where ")#mi("1 < p < \\infty")#text(", and ")#mi("C_p")#text(" depends only on ")#mi("p")#text(". Indeed, one first verifies Carleson’s theorem for a dense subclass of ")#mi("L^p")#text(" (e.g. the space of test functions) and then uses a standard limiting argument involving (1) (this is an example of the trick “")#link("http://www.tricki.org/article/Create_an_epsilon_of_room")[#text("give yourself an epsilon of room")]#text("“).")

#text("The Carleson-Hunt theorem shows that ")#mi("S_n f(x)")#text(" converges as ")#mi("n \\to \\infty")#text(" for almost every ")#mi("x")#text(", but does not say much more about the nature of that convergence. One way to measure the strength of the convergence is to introduce the variational norms")

#align(center)[#tao-fit-display[#tao-math("{\\mathcal V}^r (S_n f(x))_{n = 0}^\\infty := \\sup_{n_1 \\leq \\ldots \\leq n_k} (\\sum_{j=1}^{k-1} \\left|S_{n_{j+1}} f(x) - S_{n_j} f(x)\\right|^r)^{1/r}", block: true)]]

#text("for various ")#mi("1 \\leq r \\leq \\infty")#text(". For ")#mi("r = \\infty")#text(" this is the Carleson maximal function ")#tao-math("\\sup_n \\left|S_n f(x)\\right|", block: false)#text("; for ")#mi("r=1")#text(" this is the total variation of the sequence ")#mi("S_n f(x)")#text(", which one can verify to be the ")#mi("\\ell^1")#text(" norm of ")#mi("\\hat f")#text(".")

#text("Our main result is to obtain the following variational strengthening of (1)")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| {\\mathcal V}^r S_n f(x) \\right\\|_{L^p({\\Bbb R}/{\\Bbb Z})} \\leq C_{p,r} \\left\\| f \\right\\|_{L^p({\\Bbb R}/{\\Bbb Z})}", block: true)]]

#text("whenever ")#mi("r > 2")#text(" and ")#mi("r/(r-1) < p < \\infty")#text("; these conditions on ")#mi("p,r")#text(" are optimal. (For those readers familiar with martingales, the relationship of (2) to (1) is analogous to the relationship between Lepingle’s inequality (a variant of the more well known ")#link("http://en.wikipedia.org/wiki/Doob%27s_martingale_inequality")[#text("Doob’s inequality")]#text(") and the Hardy-Littlewood maximal inequality.)")

#text("Because a sequence with finite ")#mi("r")#text("-variation for some finite ")#mi("r")#text(" is necessarily convergent, this leads to a new proof of the Carleson-Hunt theorem without the need for a dense subclass. In particular, we obtain ergodic theory analogues of this result, in the case where no obvious dense subclass is available; more precisely, we obtain a new (and more “quantitative”) proof of a Wiener-Wintner-type theorem (first obtained by Lacey and Terwilleger), namely that given any measure-preserving group ")#mi("(T_t)_{t \\in {\\Bbb R}}")#text(" on a measure space ")#mi("X")#text(", and a function ")#mi("f \\in L^p(X)")#text(" for some ")#mi("p>1")#text(", one has for almost every ")#mi("x \\in X")#text(" that for every real number ")#mi("\\theta")#text(", the integrals ")#tao-math("\\int_{\\varepsilon \\leq \\left|t\\right| \\leq N} T^t f(x) e^{i\\theta t}/t\\ dt", block: false)#text(" converge as ")#mi("\\varepsilon \\to 0, N \\to \\infty")#text(" for ")#emph[#text("every")]#text(" ")#mi("\\theta")#text(" (not merely almost every ")#mi("\\theta")#text(").")

#text("The estimate (2) also provides a new proof of a result of Christ and Kiselev on the almost everywhere boundedness of eigenfunctions of Schrodinger operators with ")#mi("L^p")#text(" potentials with ")#mi("p<2")#text(". Unfortunately, due to various endpoint issues, this barely fails to settle the endpoint case ")#mi("p=2")#text(", a conjecture known as the nonlinear Carleson conjecture (discussed in ")#link("https://terrytao.wordpress.com/2007/12/17/multi-linear-multipliers-associated-to-simplexes-of-arbitrary-length/")[#text("this previous post")]#text(").")

#text("The approach here follows the Lacey-Thiele approach to Carleson’s theorem (which is in turn based on an earlier approach of Fefferman), based on linearising the Carleson maximal function by picking the integer ")#mi("n = n(x)")#text(" which attains the supremum ")#tao-math("\\sup_n \\left|S_n f(x)\\right|", block: false)#text(", dividing phase space into “tiles”, and organising these tiles into “trees” and then into “forests” based on the distribution of the phase space “energy” of ")#mi("f")#text(", together with the “mass” distribution of the graph of the function ")#mi("x \\mapsto n(x)")#text(". One then needs to combine various “Bessel” type bounds on the energy, “Vitali-type” bounds on the mass, and “Calderon-Zygmund” type estimates on the trees together to obtain the result.")

#text("In our setting, the main new difficulty is that there are multiple integers ")#mi("n_1(x),\\ldots,n_{k(x)}(x)")#text(" associated to each point rather than one, which requires a more detailed analysis of the “multiplicity” of forests that was not present in earlier work. (Also, the Calderon-Zygmund estimates need to be replaced with Lepingle type estimates, though this is a relatively standard change, being first introduced in a paper of Bourgain.)")

#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23bf00d119f264c8fb45fb8a053ba42daa31d05a719782cf4eeded1822fff845-72691823a0ab8166006fe0300e84b1b7b9e361146651d68c93ee4f2cf8398220.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Bailey")]], [#link("https://terrytao.wordpress.com/2009/10/10/a-variation-norm-carleson-theorem/#comment-41801")[#strong[#text("Andrew Bailey")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2009")])]

#text("Small typo in your definition of the variational norm: | -> (.")

#text("Nice paper. Could you shed a little more light on your comment about the analysis of the “multiplicity” of forests?")

#text("By the way, should you feel inclined to write anything more on this topic, I for one would be interested in reading it. :-)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/10/a-variation-norm-carleson-theorem/#comment-41806")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2009")])]

#text("Thanks for the correction!")

#text("A forest is a collection of trees T which are basically disjoint in phase space, but possibly overlapping in physical space; in particular, the physical support ")#mi("I_T")#text(" of the trees ")#mi("T")#text(" in a forest may overlap, so the multiplicity function ")#mi("N := \\sum_T 1_{I_T}")#text(" may be larger than 1 on occasion. Previous work in this area measured the size of a forest by the ")#mi("L^1")#text(" norm of its multiplicity function (i.e. the sum of the widths ")#tao-math("\\left|I_T\\right|", block: false)#text(" of its constituent trees); for our work we also need to consider other ")#mi("L^p")#text(" norms (actually we rely mostly on the ")#mi("L^1")#text(" norm and the BMO norm, and then interpolate to get everything else.) The basic point is that if one needs to sample the Fourier series at k points to get the maximum variation, then one expects the most important forests to have multiplicity between 1 and k (higher multiplicity forests are also present, but have a diminished contribution to the final estimate compared to the lower-multiplicity forests).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23bf00d119f264c8fb45fb8a053ba42daa31d05a719782cf4eeded1822fff845-72691823a0ab8166006fe0300e84b1b7b9e361146651d68c93ee4f2cf8398220.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Bailey")]], [#link("https://terrytao.wordpress.com/2009/10/10/a-variation-norm-carleson-theorem/#comment-41815")[#strong[#text("Andrew Bailey")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2009")])]

#text("Interesting. I hadn’t thought of ")#tao-math("\\sum_T \\left|I_T\\right|", block: false)#text(" in this way before. Thanks.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0407444868fc42987e0e767c3fa8c7571cd73af435533bcece7a36bd594b0514-2ae27efe97fcf1ece7ea67e36afa94eee62825664716dc4ee7cf030a881d77c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shannon7774")]], [#link("https://terrytao.wordpress.com/2009/10/10/a-variation-norm-carleson-theorem/#comment-41814")[#strong[#text("shannon7774")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2009")])]

#text("Is there a relationship between Carleson’s theorem and almost-sure convergence of an L^p martingale? You alluded to martingales, but I wasn’t sure if this is the connection point?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/10/a-variation-norm-carleson-theorem/#comment-41818")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2009")])]

#text("Yes, the latter is roughly speaking the lacunary special case of the former. The lacunary partial Fourier series ")#tao-math("\\sum_{\\left|k\\right| \\leq 2^n} \\hat f(k) e^{2\\pi ikx}", block: false)#text(", where ")#mi("2^n")#text(" is a power of two, is roughly analogous to the projection of f to the ")#mi("\\sigma")#text("-algebra of functions on the unit circle which are constant on dyadic intervals of length ")#mi("2^{-n}")#text(". (To make this analogy more accurate, one would have to smooth the Fourier series, leading to a Littlewood-Paley projection.) Pointwise convergence of the (smoothed out) lacunary partial Fourier series can be established by basically the same methods used to establish almost everywhere convergence for martingale projections. Whilst the entire Carleson maximal function is modeled by using all the tiles in phase space, smoothed out lacunary partial Fourier series are basically modeled by a single tree of tiles, with base frequency zero. (A tree with non-zero base frequency corresponds to a modulated lacunary partial Fourier series, such as ")#tao-math("\\sum_{\\left|k-k_0\\right| \\leq 2^n} \\hat f(k) e^{2\\pi i kx}", block: false)#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/10/10/a-variation-norm-carleson-theorem/#comment-41819")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2009")])]

#text("Is there a reason you choose to work on the circle in this situation? Typically the Lacey-Thiele methods (including an earlier paper of yours) are carried out on the line.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/10/a-variation-norm-carleson-theorem/#comment-41821")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2009")])]

#text("Well, there is a correspondence between the two: a suitably “scale-invariant” estimate on the circle can be rescaled to produce as a limiting case the corresponding estimate on the line, and in the converse direction there is a somewhat trickier transference argument (using things like Poisson summation) that recovers the circle case from the line case. Because the latter implication is a bit harder than the other, the circle result is slightly “deeper” and so we decided to make it our headline result, but the way we prove it is by first recalling the transference argument to reduce things to the line case, and then establish the estimate on the line by the usual time-frequency methods.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23bf00d119f264c8fb45fb8a053ba42daa31d05a719782cf4eeded1822fff845-72691823a0ab8166006fe0300e84b1b7b9e361146651d68c93ee4f2cf8398220.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Bailey")]], [#link("https://terrytao.wordpress.com/2009/10/10/a-variation-norm-carleson-theorem/#comment-41825")[#strong[#text("Andrew Bailey")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2009")])]

#text("Working directly on the circle in the Lacey/Thiele paper does throw up a few interesting features. One that particularly intrigues me is that if you re-cast certain quantities viewed in the paper on the “time” side as being on the frequency side, you get oscillatory integrals which look like reasonably natural candidates for the the kinds of estimates that were obtained on the time side. However, try to do the same thing on the circle and you get oscillatory sums and suddenly things are less clear.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vorlesung Funktionalanalysis: Erste Etappe « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2009/10/10/a-variation-norm-carleson-theorem/#comment-42134")[#strong[#text("Vorlesung Funktionalanalysis: Erste Etappe « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2009")])]

#text("[…] einer Menge vom Lebesgueschen Maß konvergiert. Mehr zum Theorem von Carleson findet sich auf dem Blog von T. Tao. Im Gegensatz hierzu gibt es Funktionen, deren Forurierreihe nicht punktweise konvergiert. Dieses […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2009/10/10/a-variation-norm-carleson-theorem/#comment-42404")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2009")])]

#text("Can you say anything about the (double) endpoint case when r=p=2? I understand that the inequality as stated in (2) fails, but is it possible that the failure is, say, only logarithmic? That is, could there be an inequality of the form || ||s[f](n,x)||_{v^2}||_{2} << ln(N)^{b} ||f||_{2} for f(x) = \\sum_{n=-N}^{N} \\hat{f}(n) e(nx)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/10/a-variation-norm-carleson-theorem/#comment-42405")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2009")])]

#text("Yes, this should be the case for some b (perhaps even b=1). Generally, the only sources of divergence in these sorts of estimates come from a pileup of scales; if one only considers frequency scales from 1 to N then there are only a logarithmic number of scales in play, and each scale should only contribute a bounded amount. (Note for instance that Carleson’s theorem with a logarithmic loss is quite easy to show, basically because the Dirichlet kernel has an L^1 norm which is logarithmic in nature (which is closely related to the fact that the L^1 norm at each dyadic scale is bounded).)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of small business insurance cost")]], [#link("https://terrytao.wordpress.com/2009/10/10/a-variation-norm-carleson-theorem/#comment-246828")[#strong[#text("small business insurance cost")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2013")])]

#text("Heck yeah bay-bee keep them coming!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FUA Kap05-AB03 „Hilbertraumbasis“ | UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2009/10/10/a-variation-norm-carleson-theorem/#comment-511811")[#strong[#text("FUA Kap05-AB03 „Hilbertraumbasis“ | UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2019")])]

#text("[…] einer Menge vom Lebesgueschen Maß $ 0 $ konvergiert. Mehr zum Theorem von Carleson findet sich auf dem Blog von T. Tao. Die historische Entwicklung hierzu findet man in [Bressoud]; siehe auch l.c. Ex. 8.1.10 — […]")
]
