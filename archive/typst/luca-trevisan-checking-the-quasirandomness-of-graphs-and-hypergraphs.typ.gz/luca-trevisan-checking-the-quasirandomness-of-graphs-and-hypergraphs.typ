// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/
// Converted to Typst by tao2typ: "2026-10-14T16:35:13.040812+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "(Luca Trevisan) Checking the Quasirandomness of Graphs and Hypergraphs", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("(Luca Trevisan) Checking the Quasirandomness of Graphs and Hypergraphs")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 February 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/")[#text("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("[")#emph[#text("This post is authored by ")#link("http://www.cs.berkeley.edu/~luca/")[#text("Luca Trevisan")]#text(". – T.")]#text("]")

#text("Notions of “quasirandomness” for graphs and hypergraphs have many applications in combinatorics and computer science. Several ")#link("https://terrytao.wordpress.com/tag/randomness/")[#text("past posts by Terry")]#text(" have addressed the role of quasirandom structures in additive combinatorics. A recurring theme is that if an object (a graph, a hypergraph, a subset of integers, …) is quasirandom, then several useful properties can be immediately deduced, but, also, if an object is not quasirandom then it possesses some “structure” than can be usefully exploited in an inductive argument. The contrapositive statements of such randomness-structure dichotomies are that certain simple properties imply quasirandomness. One can view such results as algorithms that can be used to “certify” quasirandomness, and the existence (or, in some cases, conjectural non-existence) of such algorithms has implications in computer science, as I shall discuss in this post.")#linebreak()#text(" ")#metadata(none) <tao-d6e78fc2edf55ba53aed>

#text("Informally, an undirected graph ")#mi("G=(V,E)")#text(" is ")#emph[#text("quasirandom")]#text(" if, for every two large sets of vertices ")#mi("S")#text(" and ")#mi("T")#text(", the number of edges between ")#mi("S")#text(" and ")#mi("T")#text(" is approximately what it would be, on average, if we had generated ")#mi("G")#text(" by picking ")#tao-math("\\left|E\\right|", block: false)#text(" edges uniformly at random. Quantitatively, we’ll say that a graph ")#mi("G=(V,E)")#text(" is ")#emph[#mi("\\epsilon")#text("-quasirandom")]#text(" if for every two disjoint sets of vertices ")#mi("S")#text(" and ")#mi("T")#text(" the number of edges between ")#mi("S")#text(" and ")#mi("T")#text(" differs from ")#tao-math("\\left|E\\right| \\cdot \\left|S\\right| \\cdot \\left|T\\right| / \\binom{\\left|V\\right|}{2}", block: false)#text(" by at most an ")#tao-math("\\epsilon \\left|E\\right|", block: false)#text(" additive error term. This property is true with ")#mi("\\epsilon=0")#text(" for the ")#link("http://en.wikipedia.org/wiki/Complete_graph")[#text("complete graph")]#text(", and it is quite remarkable that there exist very sparse graphs that are quasi-random. Indeed it is possible to show that a random graph with ")#tao-math("O(\\left|V\\right|/\\epsilon^2)", block: false)#text(" edges (that is, a graph where the average degree of a vertex is a constant depending only on ")#mi("\\epsilon")#text(") is ")#mi("\\epsilon")#text("-quasirandom with high probability. While this is remarkable enough, it is also true that there are efficient algorithms that, given a random graph with ")#tao-math("c\\left|V\\right|", block: false)#text(" edges, are able with high probability to verify that the graph is ")#mi("O(1/\\sqrt{c})")#text("-quasirandom. (This is true with some caveats, as explained below.)")

#text("Here are some implications of such algorithms. Consider the problem of finding a largest ")#link("http://en.wikipedia.org/wiki/Independent_set")[#text("independent set")]#text(" in a given graph. (If vertices represent tasks to be performed, and an edge represents a conflict that makes it impossible to perform two tasks at the same time, a largest independent set is a largest choice of simultaneously doable tasks.) This problem is ")#link("http://en.wikipedia.org/wiki/NP-hard")[#text("NP-hard")]#text(", meaning that if there were an efficient optimization algorithm for it, there would be an algorithm that given a provable mathematical statement would find a shortest proof for it in time polynomial in the length of the shortest proof; a number of other highly unlikely algorithmic consequences, including polynomial time algorithms to break any possible cryptographic protocol, would also follow. (See e.g. ")#link("http://www.claymath.org/millennium/P_vs_NP/")[#text("this description of the P versus NP problem")]#text(".) In addition, we know that, in an ")#mi("n")#text("-vertex graph, even achieving an ")#mi("n^{.99}")#text(" approximation in polynomial time would imply that ")#mi("P=NP")#text(" (as ")#link("http://www.nada.kth.se/%7Ejohanh/cliqueinap.ps")[#text("proved by Hastad")]#text(") and that, in particular, exact optimization would also be possible in polynomial time. When we look at graphs of maximum degree ")#mi("d")#text(", a ")#mi("d+1")#text(" approximation is trivial, but it is NP-hard to approximate the problem better than ")#mi("d/2^{\\sqrt{\\log d}}")#text(" (see ")#link("http://www.cs.berkeley.edu/%7Eluca/pubs/stoc01.ps")[#text("this paper")]#text(").")

#text("Now consider a random ")#mi("d")#text("-regular graph; it is easy to find an independent set of size ")#tao-math("\\left|V\\right|/(d+1)", block: false)#text(", and, with high probability, we can prove that the graph is ")#mi("O(1/\\sqrt {d})")#text("-quasirandom, and hence the largest independent set has size ")#tao-math("O(\\left|V\\right|/\\sqrt {d})", block: false)#text(". This means that we")#linebreak()#text(" achieve with high probability an approximation of ")#mi("\\sqrt {d}")#text(", and so that")#linebreak()#text(" random graphs are not the hardest instances of the problem. Typically, in combinatorics, when random graphs are not extremal for a given problem, then finding extremal constructions is very hard; indeed, one has to work quite hard to come up with examples showing that certain approximate algorithms for the independent set problem (such as the ")#link("http://arxiv.org/abs/math/9312214")[#text("Lovasz theta function")]#text(") do achieve approximation as bad as ")#mi("d^{1-o(1)}")#text(" (see ")#link("http://www.wisdom.weizmann.ac.il/%7Efeige/Approx/theta.ps")[#text("this paper by Feige")]#text(").")

#text("The same phenomenon occurs for a number of other graph optimization problems. For example the ")#link("http://en.wikipedia.org/wiki/Cut_(graph_theory)")[#text("Max Cut problem")]#text(" is the problem of finding a partition of the vertices of a given graph into two sets, so that a largest number of edges are “cut,” that is, have endpoints on different sides of the partition. There is a polynomial-time algorithm that achieves an ")#mi("\\approx .878")#text(" approximation factor, it is NP-hard to approximate the problem better than ")#mi("16/17")#text(", and there is some evidence that no approximation better than ")#mi("\\approx .878")#text(" is achievable (see Section 5.1 of ")#link("http://www.cs.berkeley.edu/%7Eluca/pubs/inapprox.pdf")[#text("this paper")]#text(" for references). On the other hand, in every graph it is easy to find a partition that cuts half of the edges (use a random partition), and in an ")#mi("\\epsilon")#text("-quasirandom graph no partition can cut more than a ")#mi("1/2 + O(\\epsilon)")#text(" fraction of edges; this means that, here, too, when looking at worst-case instances for certain algorithms one must resort to non-random constructions.")

#text("Having motivated the problem, let me briefly describe the algorithms.")

#text("First I’d like to discuss an algorithm that gives slightly worse bounds and works only on dense graphs, but is surprisingly simple: count the number of 4-cycles in the graph. This amazing result is due to ")#link("http://www.ams.org/mathscinet-getitem?mr=1054011")[#text("Chung, Graham, Wilson")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=930498")[#text("Thomason")]#text(" (see the introductory sections of ")#link("http://www.dpmms.cam.ac.uk/%7Ewtg10/belapaper.pdf")[#text("this paper of Gowers")]#text(" for further references). Suppose we have a graph with ")#mi("n")#text(" vertices and ")#mi("p \\binom{n}{2}")#text(" edges; then a first observation is that the number of 4-")#link("http://en.wikipedia.org/wiki/Cycle_%28mathematics%29")[#text("cycles")]#text(" (that is, the number of 4-tuples of vertices ")#mi("(x_1,y_1,x_2,y_2)")#text(" such that the four edges ")#mi("(x_i,y_j)")#text(" exist for ")#mi("i,j \\in \\{1,2\\}")#text(") is at least ")#mi("p^4n^4")#text(", which follows from two applications of ")#link("http://en.wikipedia.org/wiki/Cauchy%E2%80%93Schwarz_inequality")[#text("Cauchy-Schwarz")]#text(":")

#align(center)[#mi("n^8 p^4 = ( \\sum_{x,y} A(x,y) )^4")#linebreak()#text(" ")#mi("\\leq (n \\sum_{x,y_1,y_2} A(x,y_1)A(x,y_2))^2")#linebreak()#text(" ")#mi("\\leq n^4   \\sum_{x_1,x_2,y_1,y_2}A(x_1,y_1)A(x_1,y_2)A(x_2,y_1)A(x_2,y_2)")]

#text("where we define ")#mi("A(x,y):=1")#text(" if ")#mi("(x,y)")#text(" is an edge, and ")#mi("A(x,y):= 0")#text(" otherwise.")

#text("Note that ")#mi("p^4 n^4")#text(" is the average number of 4-cycles in a random graph with ")#mi("n")#text(" vertices in which each edge is included with probability ")#mi("p")#text(". The surprising thing is that if, in a given graph, the number of 4-cycles is close to ")#mi("p^4 n^4")#text(", then the graph is quasirandom. This follows from applying Cauchy-Schwarz twice, in a similar way, starting from the expression")

#align(center)[#tao-fit-display[#mitex("\\frac {1}{n^4} (\\sum_{x\\in S,y\\in T} (A(x,y) - p) )^4")]]

#text("which we want to prove to be at most ")#mi("\\epsilon^4 p^4 n^4")#text(" for every set ")#mi("S")#text(" and ")#mi("T")#text(", in order to establish that the graph is ")#mi("\\epsilon")#text("-pseudorandom. It turns out that the above expression is upper bounded by the difference between the number of 4-cycles in the graph and ")#mi("p^4 n^4")#text(".")

#text("When we deal with sparse graphs, unfortunately, this approach breaks down. In fact, any approach that looks at small patterns is bound to fail: a random graph with ")#tao-math("c\\left|V\\right|", block: false)#text(" edges and a random bipartite graph with ")#tao-math("c\\left|V\\right|", block: false)#text(" edges look “locally the same” even though the former is very likely to be ")#mi("O(1/\\sqrt{c})")#text("-quasirandom, while the latter is not quasirandom at all.")

#text("For sparse ")#link("http://en.wikipedia.org/wiki/Regular_graph")[#emph[#text("regular")]]#text(" graphs (for which all vertices have the same degree), “spectral” techniques give extremely good certificates of quasirandomness. Let ")#mi("G=(V,E)")#text(" be a regular graph where all vertices have degree ")#mi("d")#text(", and ")#mi("A")#text(" be the ")#link("http://en.wikipedia.org/wiki/Adjacency_matrix")[#text("adjacency matrix")]#text(" of ")#mi("G")#text(", hence ")#mi("A(u,v)=1")#text(" if ")#mi("(u,v)")#text(" is an edge and ")#mi("A(u,v)=0")#text(" otherwise. One can see that:")

#enum(start: 1, 
[#mi("A")#text(" is symmetric, hence all ")#link("http://en.wikipedia.org/wiki/Eigenvalue")[#text("eigenvalues")]#text(" are real;")],
[#text("the vector ")#mi("(1,\\ldots,1)")#text(" is an eigenvector with eigenvalue ")#mi("d")#text(";")],
[#text("all eigenvalues are between -d and d. Let now ")#mi("\\lambda_1 \\geq \\lambda_2 \\geq \\ldots \\geq \\lambda_n")#text(" be the eigenvalues of ")#mi("A")#text(", with multiplicities; as we said, ")#mi("\\lambda_1=d")#text(".")]
)

#text("It turns out that if all the other eigenvalues are at most ")#mi("\\epsilon d")#text(" in absolute value, then ")#mi("G")#text(" is ")#mi("\\epsilon")#text("-quasirandom. More precisely, if ")#mi("S")#text(" and ")#mi("T")#text(" are disjoint sets, then")

#align(center)[#tao-fit-display[#tao-math("\\left| e(S,T) - \\frac{d\\cdot \\left|S\\right|\\cdot \\left|T\\right|}{\\left|V\\right|} \\right| \\leq \\max \\{ \\left|\\lambda_2\\right|,\\left|\\lambda_n\\right| \\} \\cdot \\sqrt{\\left|T\\right|\\cdot \\left|V\\right| }", block: true)]]

#text("This result is known as the ")#link("http://en.wikipedia.org/wiki/Expander_mixing_lemma")[#emph[#text("expander mixing lemma")]]#text(", and the intuition of the proof is quite simple. Let ")#mi("{\\bf v}_1, \\ldots, {\\bf v}_n")#text(" be a system of orthonormal eigenvector for the eigenvalues ")#mi("\\lambda_1,\\ldots,\\lambda_n")#text(". The number of edges between the sets ")#mi("S")#text(" and ")#mi("T")#text(" is")

#align(center)[#tao-fit-display[#mitex("1_S A 1_T^t")]]

#text("where, for a set ")#mi("S")#text(", we define ")#mi("1_S")#text(" as the vector such that ")#mi("1_S(u)=1")#text(" if ")#mi("u \\in S")#text(" and ")#mi("1_S(u)=0")#text(" otherwise. This can be rewritten as")

#align(center)[#tao-fit-display[#mitex("d\\cdot 1_S \\cdot {\\mathbf v}_1^t \\cdot 1_T \\cdot {\\mathbf v}_1^t + \\sum_{i=2}^n \\lambda_i 1_S {\\mathbf v}_i^t \\cdot 1_T \\cdot {\\mathbf v}_i^t")]]

#text("and the first term is ")#tao-math("d \\left|S\\right| \\left|T\\right| /n", block: false)#text(", while the other terms can be upper")#linebreak()#text(" bounded by ")#tao-math("\\max_{i=2,\\ldots,n} \\left|\\lambda_i\\right| \\sqrt{\\left|S\\right| \\left|T\\right|}", block: false)#text(" in absolute value.Furthermore, if one picks a ")#mi("d")#text("-regular graph at random, then all eigenvalues except ")#mi("\\lambda_1")#text(" are at most ")#mi("O(\\sqrt {d-1})")#text(" with high probability. One can in fact prove that the upper bound is close to ")#mi("2\\sqrt{d-1}")#text(", which is the best possible, but ")#link("http://www.math.ubc.ca/%7Ejf/pubs/web_stuff/alon.html")[#text("such arguments are very difficult")]#text(". (A nitpick here is that said results apply to the probabilistic model where we take the union of ")#mi("d")#text(" random ")#link("http://en.wikipedia.org/wiki/Matching")[#text("matchings")]#text(" rather than a random ")#mi("d")#text("-regular graph.)")

#text("To sum up, if a random graph is generated by taking the union of ")#mi("d")#text(" random matchings, we can certify that is is ")#mi("O(1/\\sqrt {d})")#text("-quasirandom. In the ")#mi("G_{n,p}")#text(" model where each edge is selected with probability ")#mi("p")#text(", similar arguments apply (and can certify ")#mi("1/O(\\sqrt {d})")#text("-quasirandomness, where ")#mi("d = pn")#text(" is the average degree), provided that the average degree ")#mi("pn")#text(" is at least ")#mi("(\\log n)^{O(1)}")#text(". The case of average constant degree is trickier, but it can probably be handled by standard techniques (removing high-degree and isolated vertices before computing the spectrum) that have succeeded in related problems.")

#text("Given how satisfactory are the combinatorial and algorithmic theories of quasirandomness for graphs, we may hope for similar results for hypergraphs.")

#text("In the dense case, an approach based on counting local patterns indeed works in a completely analogous way. In a 3-uniform hypergraph (an hypergraph where each hyperedge contains three vertices) with ")#mi("n")#text(" vertices and ")#mi("p \\binom{n}{3}")#text(" hyperedges we shall count the number of 6-tuples ")#mi("(x_1,x_2,y_1,y_2,z_1,z_2)")#text(" of vertices such that all the 8 hyperedges of the form ")#mi("(x_i,y_j,z_k)")#text(" exist for ")#mi("i,j,k\\in \\{1,2\\}")#text(". Three applications of Cauchy-Schwarz show that this number is at least ")#mi("p^8 n^6")#text(", and that if this number is at most ")#mi("(1+\\epsilon^{O(1)} )p^8 n^6")#text(" then the hypergraph is ")#mi("\\epsilon")#text("-quasirandom.")

#text("Again, however, local approaches fail for sparse hypergraphs.")

#text("An algorithm for the sparse case would have remarkable applications for the ")#link("http://en.wikipedia.org/wiki/Boolean_satisfiability_problem")[#text("kSAT problem")]#text(". In the kSAT problem we are given a boolean AND-of-ORs expression where each OR term is over ")#mi("k")#text(" variables, for example this is an instance of 3SAT:")

#align(center)[#tao-fit-display[#mitex("(x_1 \\vee x_3 \\vee \\neg x_4) \\wedge (\\neg x_1 \\vee x_2 \\vee \\neg x_3) \\wedge (x_1 \\vee x_2 \\vee \\neg x_4)")]]

#text("and we want to know if there is a setting to the variables that satisfies the formula. In the above example, setting all variables to ")#mi("\\text{True}")#text(" works. This problem is a canonical ")#link("http://en.wikipedia.org/wiki/NP-complete")[#text("NP-complete ")]#text("problem for all ")#mi("k\\geq 3")#text(": if a polynomial time algorithm existed, then there would be polynomial time algorithms for all problems in NP. (There is a linear time algorithm to solve 2SAT.)")

#text("Recently, there has been considerable interest in the question of the average-case complexity of kSAT, in the model where we pick at random a formula with ")#mi("n")#text(" variables and ")#mi("m(n)")#text(" ")#link("http://en.wikipedia.org/wiki/Clause_%28logic%29")[#text("clauses")]#text(". (A “clause” is an OR term in the formula.)")

#text("In the hard graph problems we discussed above, uniformly chosen random instances were “easier” than worst-case instances, assuming ")#mi("P\\neq NP")#text(". In the kSAT case, the situation seems more complex. It is conjectured that, for every ")#mi("k")#text(", there is a constant ")#mi("c_k")#text(" such that when we generate a random formula with ")#mi("m(n) \\leq (c_k - \\epsilon) n")#text(" clauses then the formula is satisfiable with high probability, and when we generate a random formula with ")#mi("m(n) \\geq (c_k + \\epsilon) n")#text(" then the formula is unsatisfiable with high probability. Furthermore, there are algorithms that are conjectured to find satisfying assignments with high probability in the ")#mi("m(n) \\leq (c_k -\\epsilon)")#text(" regime. (See my posts ")#link("http://in-theory.blogspot.com/2007/05/random-ksat.html")[#text("here")]#text(", ")#link("http://in-theory.blogspot.com/2007/05/proving-unsatisfiability-of-random-ksat.html")[#text("here")]#text(" and ")#link("http://in-theory.blogspot.com/2007/08/more-ways-to-prove-unsatisfiability-of.html")[#text("here")]#text(" for references).")

#text("An open question is whether there is an efficient way to certify the unsatisfiability of random formulas in the ")#mi("m(n) \\geq (c_k + \\epsilon) n")#text(" regime.")

#text("One approach in this direction is to reduce to an hypergraph problem. Given a kSAT formula with ")#mi("n")#text(" variables and ")#mi("m")#text(" edges, construct a ")#mi("k")#text("-uniform hypergraph with 2n vertices (one for each variable x and bit b, which we think of as being the assignment ")#mi("x=b")#text(") and ")#mi("m")#text(" hyperdges, one for each clause, connecting the unique values of the variables that contradict the clause. Suppose the formula has a satisfying assignment, then there is a set of half the vertices such that no hyperedge is completely contained in the set; this is called an ")#link("http://en.wikipedia.org/wiki/Independent_set")[#text("independent set")]#text(". Now, if one generates the formula randomly, then the associated hypergraph is a random hypergraph. The question then becomes: given a random hypergraph, can we certify that there is no large independent set? If we could certify that a random hypergraph of sufficiently large average degree is, say, ")#mi("1/100")#text("-quasirandom, then the non-existence of large independent sets would follow, and we would be able to certify the unsatisfiability of comparably dense random kSAT instances.")

#text("A natural approach to certify the quasirandomness of a given sparse hypergraph is to look for generalizations of spectral methods. While there is no clear definition of what the “eigenvalues” of an 3-hypergraph (or, more generally, of a symmetric trilinear form) should be, ")#link("http://www.math.ubc.ca/%7Ejf/pubs/web_stuff/hyp.html")[#text("Friedman and Wigderson")]#text(" consider the characterization of the second eigenvalue of a graph as the problem of optimizing a certain quadratic form. The problem has a natural generalization to trilinear forms, and yields a definition of “second eigenvalue” of a 3-hypergraph. They are able to prove that this parameter is bounded for random hypergraphs and that when it is bounded the hypergraph is quasirandom. Unfortunately, no algorithm is known to efficiently compute this parameter.")

#text("It is becoming a standard conjecture that, indeed, the unsatisfiability of random ")#mi("kSAT")#text(" instances is hard to verify when ")#mi("m(n) = cn")#text(" and ")#mi("c")#text(" is an arbitrarily large constant. (Note that the problem becomes easier, or no harder, when ")#mi("c")#text(" is larger.) On the other hand, simple refutation algorithms exist for kSAT in the setting of very high density, and the")#link("http://www.ams.org/mathscinet-getitem?mr=1054011")[#text(" Chung-Graham-Wilson")]#text(" approach can certify quasirandomness of dense hypergraphs.")

#text("We can then ask what is the minimal density for which such problems admit efficient algorithmic solutions.")

#text("For kSAT, so far, the best refutation algorithms work when the density is about ")#mi("n^{k/2}")#text(", and, for even ")#mi("k")#text(", the idea of such algorithms also leads to an algorithm to verify the quasirandomness of random ")#mi("k")#text("-hypergraphs.")

#text("Translated to the hypergraph setting, the algorithm is as follows. Given a ")#mi("k")#text("-hypergraph (even ")#mi("k")#text(") with ")#mi("n")#text(" vertices and about ")#mi("n^{k/2}")#text(" hyperdges, we create a graph with ")#mi("n^{k/2}")#text(" vertices, one per ")#mi("k/2")#text("-tuple. Each ")#mi("k")#text("-hyperedge is associated to an edge in the graph (by splitting, say, randomly, the ")#mi("k")#text("-tuple into two ")#mi("k/2")#text("-tuples). One can see that if the graph is ")#mi("\\epsilon")#text("-quasirandom, then the hypergraph is ")#mi("O(\\epsilon)")#text("-quasirandom. (The contrapositive is easier to prove, suppose the hypergraph is not quasirandom, let ")#mi("S_1,\\ldots,S_k")#text(" be the sets that witness that the quasirandomness property is contradicted; then the sets ")#mi("(S_1 \\times \\cdots \\times S_{k/2})")#text(" and ")#mi("(S_{k/2+1} \\times \\cdots \\times S_k)")#text(" contradict the quasirandomness of the graph.) If the hypergraph is randomly generated, then the graph is randomly generated, and we can use spectral techniques to verify its quasirandomness.")

#text("For odd ")#mi("k")#text(", there are algorithms that certify the unsatisfiability of random kSAT formulas with about ")#mi("n^{k/2}")#text(" clauses; as far as I know, the analogous result is open for hypergraphs. (The kSAT algorithms use properties of kSAT that have no analog in the general hypergraph setting, such as the fact that an assignment that satisfies both ")#mi("(x\\vee y\\vee q)")#text(" and ")#mi("(\\neg q \\vee w\\vee z)")#text(" must also satisfy ")#mi("(x \\vee y \\vee w \\vee z)")#text(".")

#text("Substantial work has gone into proving limitations of spectral methods for the problem of certifying the unsatisfiability of random instances of ")#mi("k")#text("SAT. Bounds at least as good as those obtained by spectral methods can always be obtained by formulating a ")#link("http://en.wikipedia.org/wiki/Semidefinite_programming")[#text("semidefinite programming ")]#text("(SDP) relaxation of the given problem, and there are several results showing that even very powerful SDP relaxations of kSAT cannot certify unsatisfiability even for fairly large densities (see e.g. ")#link("http://portal.acm.org/citation.cfm?doid=1060590.1060634")[#text("this paper")]#text("), and the hypergraph quasirandomness problem is only harder. Still, it is plausible that one can verify the quasirandomness of a random hypergraph with at least ")#mi("n^{1+\\epsilon}")#text(" hyperedges, for all ")#mi("\\epsilon>0")#text(". At least, the problem should be solvable in 3-hypergraphs with ")#mi("n^{1.5}")#text(" hyperedges.")

#heading(level: 1)[#text("Comments (20)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/#comment-26233")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("I have a problem that I can’t solve relating to the certifiability of hypergraph quasirandomness which is related to Luca’s post, and which potentially has various applications to breaking the parity problem in number theory.")

#text("It goes as follows. Let ")#mi("{}[n] := \\{1,\\ldots,n\\}")#text(" for some large integer n. We consider two functions ")#mi("f, g: [n]^2 \\to [n]^2")#text(" from the square to the square (which can be identified with two 4-uniform 4-partite hypergraphs on 4 groups of n vertices). The first function f is a random permutation from ")#mi("{}[n]^2")#text(" to ")#mi("{}[n]^2")#text(". The second function g is slightly harder to describe. One first needs a random colouring ")#mi("c: [n] \\to {\\Bbb Z}/2{\\Bbb Z}")#text(", and then g is a random permutation subject to the additional property that ")#mi("c(x)+c(y)=c(z)+c(w) \\text{ mod } 2")#text(" whenever ")#mi("g(x,y)=(z,w)")#text(". To put it another way, the colouring c divides ")#mi("{}[n]^2")#text(" in a “checkerboard fashion” into “white squares” ")#mi("\\{ (x,y) \\in [n]^2: c(x)+c(y)=0\\}")#text(" and two “black squares” ")#mi("\\{ (x,y) \\in [n]^2: c(x)+c(y)=1\\}")#text(", and g is a random permutation from white squares to white squares and from black squares to black squares.")

#text("My problem is as follows: suppose one is given the two functions f and g (but not c) as above, but is not told which is which. Can one build an efficient distinguisher that can determine which function is f and which is g with high probability?")

#text("I know that any purely “local” statistic (e.g. number of “octahedra”) cannot distinguish f from g; some sort of “eigenvalue” computation seems to be needed instead. Unfortunately, f and g seem to be too sparse (only ")#mi("n^2")#text(" hyperedges among ")#mi("n^4")#text(" possible hyperedges) to get anywhere. Note that the hypergraph associated to f is quasirandom, whilst the hypergraph associated to g is not, so this problem can be viewed as a special case of Luca’s general question.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas M.")]], [#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/#comment-26265")[#strong[#text("Klas M.")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2008")])]

#text("Dear Terry,")#linebreak()#text(" Would not the number of cycles distinguish ")#mi("g")#text(" from ")#mi("f")#text(" with high probability?")#linebreak()#text(" A random permutation of an ")#mi("n")#text("-set has an expectation of ")#mi("\\log n")#text(" cycles, and small variance. The permutation ")#mi("g")#text(" is built from independent permutations of two sets, both of size around ")#mi("n^2/2")#text(", and ")#mi("f")#text(" is a random permutation of a set of size ")#mi("n^2")#text(", so ")#mi("g")#text(" is expected to have about twice as many cycles as ")#mi("f")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/#comment-26267")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2008")])]

#text("Hmm, fair enough, that solves my problem as stated :-) . I’ll have to think about whether that solution extends to the more complicated situations for which this problem was a toy model.")

#text("Suppose though that we change things a little bit. Instead of one colouring map ")#mi("c: [n] \\to {\\Bbb Z}/2{\\Bbb Z}")#text(", we have four maps ")#mi("c_1, c_2, c_3, c_4: [n] \\to {\\Bbb Z}/2{\\Bbb Z}")#text(", chosen independently at random (and all unknown to the distinguisher). Let’s say now that g is random subject to the constraint that ")#mi("c_1(x)+c_2(y) = c_3(z)+c_4(w)")#text(" whenever ")#mi("g(x,y)=(z,w)")#text(". It seems now that f and g have the same number and distribution of cycles, so the distinguisher problem needs a different attack in this case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f88eee0d6973c436c210c2afbc7cf8779b1f62207dfb647d23f7807b07bbff1b-83b98080115309744e39776bb5b82db01900232417c778e33455efe062cacbe8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris")]], [#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/#comment-26301")[#strong[#text("Chris")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2008")])]

#text("Dear Prof. Tao, I’m not sure if I understand your problem")#linebreak()#text(" correctly, but consider the following.")

#text("I assume the distribution of random colourings ")#mi("c_1, c_2, c_3, c_4")#text(" is uniform on the set ")#mi("C_{1234} = \\{c_1, c_2, c_3, c_4: \\{ \\# \\{(x,y): c_1(x) + c_2(y) = i\\} = \\# \\{(z,w): c_3(z) + c_4(w) = i\\}; i=0,1\\}\\}.")

#text("I need some notation for partitionings of ")#mi("{}[n]^2,")#text(" namely let ")#mi("P_i^{k,m}= \\{(x,y): c_k(x) + c_m(y) = i\\}.")#text(" Consider the following (very similar) procedures of sampling such colourings.")

#text("1. Choose uniformly at random ")#mi("c_1")#text(" and independent of ")#mi("c_1")#text(" choose uniformly at random ")#mi("c_2.")#text(" Now, independent of ")#mi("c_1")#text(" and ")#mi("c_2")#text(" choose a random permutation, say ")#mi("h,")#text(" from ")#mi("{}[n]^2")#text(" to ")#mi("{}[n]^2")#text(" and let ")#mi("C_i^{3,4} = h(P_i^{1,2}),")#text(" for ")#mi("i=0,1.")#text(" Now, if ")#mi("(z,w) \\in C_1^{3,4}")#text(" toss a coin to decide between ")#mi("c_3(z)=1; \\; c_4(w)=0")#text(" and ")#mi("c_3(z)=0; \\; c_4(w)=1.")#text(" If ")#mi("(z,w) \\in C_0^{3,4}")#text(" toss a coin to decide between ")#mi("c_3(z)=c_4(w)=1")#text(" and ")#mi("c_3(z)=c_4(w)=0.")#text(" Clearly after we defined ")#mi("c_3")#text(" and ")#mi("c_4")#text(" also ")#mi("P_i^{3,4} = C_i^{3,4}.")

#text("2. Choose uniformly at random ")#mi("c_1")#text(" and independent of ")#mi("c_1")#text(" choose uniformly at random ")#mi("c_2.")#text(" Let ")#mi("K_0 =\\# P_0^{1,2}")#text(" Now, independent of ")#mi("c_1")#text(" and ")#mi("c_2")#text(" choose a random partitioning of ")#mi("{}[n]^2,")#text(" into ")#mi("C_0^{3,4}")#text(" and ")#mi("C_1^{3,4}")#text(" such that ")#mi("K_0 =\\# C_0^{1,2},")#text(" the partitioning depends on ")#mi("K_0,")#text(" but not on other features of ")#mi("c_1, c_2.")#text(" Now, if ")#mi("(z,w) \\in C_1^{3,4}")#text(" toss a coin to decide between ")#mi("c_3(z)=1 \\; c_4(w)=0")#text(" and ")#mi("c_3(z)=0 \\; c_4(w)=1.")#text(" If ")#mi("(z,w) \\in C_0^{3,4}")#text(" toss a coin to decide between ")#mi("c_3(z)=c_4(w)=1")#text(" and ")#mi("c_3(z)=c_4(w)=0.")#text(" Clearly after we defined ")#mi("c_3")#text(" and ")#mi("c_4")#text(" also ")#mi("P_i^{3,4} = C_i^{3,4}.")#text(" The last step is to choose uniformly at random mappings, say ")#mi("h_0,")#text(" from ")#mi("P_0^{1,2}")#text(" to ")#mi("P_0^{3,4}")#text(" and ")#mi("h_1,")#text(" from ")#mi("P_1^{1,2}")#text(" to ")#mi("P_1^{3,4}")#text(" and glue them to obtain ")#mi("h.")

#text("The observation is that in both sampling schemes ")#mi("h")#text(" follows the same distribution (and in fact ")#mi("\\{c_1,c_2, c_3, c_4, h\\}")#text(" follow the same distribution) whereas the ")#mi("h")#text(" defined in (1) is ")#mi("f")#text(" and")#linebreak()#text(" the ")#mi("h")#text(" defined in (2) is ")#mi("g.")

#text("Thus, if the sampling schemes are correct, ")#mi("f")#text(" and ")#mi("g")#text(" are statistically indistinguishable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/#comment-26303")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2008")])]

#text("Dear Chris,")

#text("The problem is that ")#mi("c_3(z)")#text(" and ")#mi("c_4(w)")#text(" are functions of only one of the two variables (z,w), and so one cannot always consistently specify these functions as ")#mi("(z,w)")#text(" ranges across, say, ")#mi("C^{3,4}_1")#text(". For instance suppose ")#mi("(z,w)")#text(" and ")#mi("(z,w^{\\prime})")#text(" both lie in ")#mi("C^{3,4}_1")#text("; the coin tosses for each pair may lead to inconsistent prescriptions of what ")#mi("c_3(z)")#text(" should be.")

#text("The easiest way to show that f and g are distinguishable is to see that the graph of f (as viewed as a sparse 4-uniform 4-partite hypergraph on 4n vertices) is quasirandom in the sense of the main post (in particular, for any sets A, B, C, D of size n/2 in [n], the number of quadruples (x,y,z,w) in A x B x C x D such that f(x,y)=(z,w) is always close to the expected number, which is n^2/16), the graph of g is not (just take A,B,C,D to be the sets where c_1=0, c_2=0, c_3=0, c_4=0 respectively).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f88eee0d6973c436c210c2afbc7cf8779b1f62207dfb647d23f7807b07bbff1b-83b98080115309744e39776bb5b82db01900232417c778e33455efe062cacbe8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris")]], [#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/#comment-26306")[#strong[#text("Chris")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2008")])]

#text("I see, my bad! :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jun Tarui")]], [#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/#comment-26310")[#strong[#text("Jun Tarui")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2008")])]

#text("Hi.")#linebreak()#text(" For both the original and revised problems, can’t we distiguish f and g with high probability in the following way?")

#text("Fix an arbitray O(log n) by O(log n) square. Focusing on this square, check if there are balanced colorings with respect to which a function in question preserves the parity, where coloring is balanced if the number of each color doesn’t exceed, say, 2/3 fraction. Do naive, exhaustive checking; the number of all colorings (balanced or not) is poly(n).")

#text("Random coloring is balanced with probability at least 1-1/poly(n). The probability that a random permutation has any parity-preserving colorings is at most n^-Omega(log n) by a union bound over all balanced colorings.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/#comment-26312")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2008")])]

#text("Dear Jun Tarui,")

#text("I initially thought this worked (and it would be a great solution!) but unfortunately the problem is that f and g don’t map small squares to small squares; a O(log n) x O(log n) square gets mapped all over the place inside ")#mi("{}[n]^2")#text(", and in fact generically one doesn’t even expect the image to ever repeat any coordinates (one is far below the threshold for the birthday paradox to come into play). So one can’t detect parity preservation inside such a square.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/525f8cf91ba78b1369037f164732b2b4dadbeb32a154e253453a000fb82cf44c-193104b5886f56df9434e27a51f2df7a74833f59287221db09a17906fa95ed40.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hikolapola")]], [#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/#comment-26345")[#strong[#text("hikolapola")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("thanks for such a usefull post!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jun Tarui")]], [#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/#comment-26347")[#strong[#text("Jun Tarui")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("Dear Terry,")

#text("Thank you for explaining my misunderstanding in my previous post above. Let me try again. For simplicity, I’ll consider random balanced colorings, i.e. ones that give each color to n/2 points, and general vs parity-preserving random *functions* from [n]^2 to [n]^2 as opposed to permutations on [n]^2.")

#text("Check if there are four points that form a grid-parallel rectangle and get mapped to a (possibly degenerate) rectangle with diagonal pairs going to diagonal pairs. If such four points exist, declare that a function is parity-preserving g, and f otherwise. I think this distinguishes random f vs parity-preserving random g with constant probability. (You say above ")#emph[#text("I know that any purely “local” statistic (e.g. number of “octahedra”) cannot distinguish f from g")]#text(", so maybe I’m again missing something; sorry if this is the case…)")

#text("Consider an arbitrary rectangle R. Prob[f(R) is a rectangle] is about 2/n^4. For g, R is either (1) monochromatic or (2) bichromatic with vertical/horizontal/diagonal pairs having the same color; in all cases, Prob[g(R) is a rectangle] is about 4/n^4, i.e., twice as large. The number of rectangles is (n choose 2)^2, i.e., about n^4/4. So the expected number of rectangles mapping to a rectangle is about 1/2 for f and about 1 for g.")

#text("We want to apply a Poisson approximation argument (Alon-Spencer: The probabilistic method, Chapter 8). So consider the probability of two rectangles R1 and R2 both getting mapped to rectangles. Consider the size of their intersection, i.e. how many points belong to both R1 and R2; it is either 0 or 1 or 2. If it is 0 or 1, we can consider the events of R1/R2 getting mapped to a rectangle as independent for both cases of f and g. If it is 2, the intersection forms a vertical or horizontal pair, and the probabilities for f and g respectively are about 2/n^7 and 8/n^7; so they are O(1/n^7). But the number of such pairs (R1, R2) is O(n^5), and thus their contribution for the sake of Poisson approximation (“Delta” in Alon-Spencer) is only O(1/n^2).")

#text("So for any balanced coloring, under a parity-preserving random permutation g, the probability that at least one rectangle gets mapped to a rectangle is 1 – e^(-1+O(1/n^2)), i.e., about 1-1/e, whereas for a random permutation f, the probability is at most about 1/2 since the expectation is about 1/2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/#comment-26362")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("Dear Jun Tarui,")

#text("Your analysis looks correct, and does provide a probabilistic distinguisher between f and g that has a greater than 50% chance of being accurate, though it does not seem obvious how to iterate it and create a distinguisher which is accurate with arbitrarily high probability for any fixed f and g. (At the risk of seeming to constantly move the goal posts, I actually want a little bit more than this: I want a rigorous certificate of quasirandomness which cannot be satisfied by any g, but is satisfied by most f. But a 99% accurate distinguisher would already be progress, and more than I am currently able to do.)")

#text("I guess I should have qualified my previous assertion on equivalence of local statistics; my analysis was only for those patterns which occurred quite frequently (at least n^c of them for some c > 0). In such cases, the number of independent variables exceeds twice the number of equations and so the parity constraints have only a negligible effect. But as you point out, the statistics do shift a little bit for those patterns which only occur O(1) times.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f88eee0d6973c436c210c2afbc7cf8779b1f62207dfb647d23f7807b07bbff1b-83b98080115309744e39776bb5b82db01900232417c778e33455efe062cacbe8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris")]], [#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/#comment-26380")[#strong[#text("Chris")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("Dear Prof. Tao,")

#text("is it OK to assume I can compute ")#mi("g^{-1}(z,w)")#text(" and ")#mi("f^{-1}(z,w)")#text(" in constant time?")

#text("Also, what do you mean by efficient distinguisher in your initial post? Since $n$ is large, do you expect it to take poly(log(n)) to compute it? or linear of n or maybe poly(n) is OK?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/#comment-26408")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2008")])]

#text("Dear Chris,")

#text("The best distinguisher I know that accepts all g and rejects most f has exponential cost in n, so anything polynomial in n or even subexponential would be an improvement. (In particular this means that lookup tables for ")#mi("f^{-1}")#text(" and ")#mi("g^{-1}")#text(" are essentially free.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jun Tarui")]], [#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/#comment-26420")[#strong[#text("Jun Tarui")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2008")])]

#text("Dear Terry,")

#text("Just one note to your remark (in your comment 1) “Unfortunately, f and g seem to be too sparse (only n^2 hyperedges among n^4 possible hyperedges) to get anywhere. ”")

#text("If there are cn^2 hyperdedges for sufficiently large constant c, I think it suffices to certify non-quasirandomness of g by the procedure explained in the last part of the main post. In particular, for your revised problem, given 16 independent copies of f and g (independent random g that are parity-preserving with respect to fixed colorings), I think we can distinguish them with high probability.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jun Tarui")]], [#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/#comment-26431")[#strong[#text("Jun Tarui")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2008")])]

#text("Dear Terry,")

#text("I think that the following solves your revised problem as stated (without certifying non-quasirandomness).")

#text("Let h be a permutation in question. For x, y, z, w in [n], if h(x, y) = (z, w), write the equation c1(x) + c2(y) = c3(z) + c4(w); thus obtain n^2 mod-2 linear equations in 4n unknowns. Solve the linear system to see if it has a solution such that at least one of c1, c2, c3, c4 is not constant, i.e., not all-0 nor all-1. (This is equivalent to the kernel having dimension at least 4; it can be easily checked.)")

#text("With high probability, a random permutation f does not have such a solution: There are 2^(4n) possible colorings(=solutions); for each coloring, the probability that a random permutation respects the coloring is smaller than n^(-Omega(n)).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/#comment-26440")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2008")])]

#text("Dear Jun Tarui,")

#text("That is a nice solution to the problem! The one drawback (for the applications I have in mind) is that it is not too robust with respect to noise; if for instance the parity condition is violated by g for o(n^2) of the pairs x,y then it is not clear how to do “robust linear algebra over F_2” and make the distinguisher work in this case. (In other words, as you say, it is not a quasirandomness certificate.) Though if the noise was much smaller, say only O(log n) errors, then presumably your earlier random sampling trick would work to eradicate it.")

#text("(I’m also interested in the case when the functions f, g are only partially defined, say on 1% of the pairs x,y, and possibly multi-valued and non-injective (e.g. each (z,w) could be hit by as many as 100 (x,y)). But any reasonably robust distinguisher for the permutation case should extend to this more general case – for instance, your linear algebra distinguisher seems to work in this case as long as there is only a negligible amount of noise.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/#comment-26502")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2008")])]

#text("A minor correction: the number of copies of the 4-cycle in a graph with density ")#mi("p")#text(" it at least ")#mi("p^4n^4")#text(" and not at most ")#mi("p^4n^4")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/#comment-26505")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2008")])]

#text("Thanks for the correction!")

#text("Best,")

#text("Terry")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/#comment-30042")[#strong[#text("Local Events, Turan’s Problem and Limits of Graphs and Hypergraphs « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2008")]

#text("[…] Related posts: “Extremal Combinatorics I,” and over Terry Tao’s blog: (Luca Trevisan) Checking the Quasirandomness of Graphs and Hypergraphs […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/15/luca-trevisan-checking-the-quasirandomness-of-graphs-and-hypergraphs/#comment-43829")[#strong[#text("The extremal utility belt: Cauchy-Schwarz « Portrait of the Mathematician")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2010")]

#text("[…] extremal utility belt: Cauchy-Schwarz By Harrison I found this little gem in an old post on Terry Tao’s blog. There’s not really enough content in it to merit an entire […]")
]
