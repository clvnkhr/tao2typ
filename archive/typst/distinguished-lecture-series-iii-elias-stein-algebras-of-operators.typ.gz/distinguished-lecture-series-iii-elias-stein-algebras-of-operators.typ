// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/10/24/distinguished-lecture-series-iii-elias-stein-algebras-of-operators/
// Converted to Typst by tao2typ: "2026-10-14T15:16:54.070876+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Distinguished Lecture Series III: Elias Stein, “Algebras of operators”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Distinguished Lecture Series III: Elias Stein, “Algebras of operators”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 October 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/10/24/distinguished-lecture-series-iii-elias-stein-algebras-of-operators/")[#text("https://terrytao.wordpress.com/2008/10/24/distinguished-lecture-series-iii-elias-stein-algebras-of-operators/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the third of the ")#link("http://www.math.ucla.edu/dls/2009/stein.shtml")[#text("Distinguished Lecture Series")]#text(" given by ")#link("http://en.wikipedia.org/wiki/Elias_Stein")[#text("Eli Stein")]#text(" here at UCLA, Eli presented a slightly different topic, which is work in preparation with ")#link("http://www.math.wisc.edu/~nagel/")[#text("Alex Nagel")]#text(", ")#link("http://homepage.sns.it/fricci/")[#text("Fulvio Ricci")]#text(", and Steve Wainger, on algebras of singular integral operators which are sensitive to multiple different geometries in a nilpotent Lie group.")

#metadata(none) <tao-b85d0a69c1d611c1e074>

#text("For sake of discussion, let us begin by working on the Heisenberg group ")#mi("{\\Bbb H}^n = \\{ (z,t) \\in {\\Bbb C}^n \\times {\\Bbb R} \\}")#text(" with group law ")#mi("(z,t) (z^{\\prime},t^{\\prime}) = (z+z^{\\prime},t+t^{\\prime}+2\\text{Im}(z\\overline{z^{\\prime}}))")#text(" (this notation differs slightly from that in the previous lectures, as we have decremented n by 1). We have two classical algebras of singular integral operators on this space. On the one hand, one can view ")#mi("{\\Bbb H}^n")#text(" as a 2n+1-dimensional Euclidean space ")#mi("{\\Bbb R}^{2n+1}")#text(" and consider the algebra of ")#link("http://en.wikipedia.org/wiki/Pseudo-differential_operator")[#text("pseudodifferential operators")]#text(" on this space. On the other hand, one can look at convolution operators ")#mi("T: f \\mapsto f*K")#text(" using the group multiplication (thus ")#mi("Tf(x) = \\int_{{\\Bbb H}^n} K(y) f(xy^{-1})\\ dy")#text("), where K is a Calderòn-Zygmund kernel adapted to the scaling structure of the Heisenberg group. Both algebras of operators are indeed algebras, and are bounded on every ")#mi("L^p")#text(" space for ")#mi("1 < p < \\infty")#text(". It is then a natural question to ask whether there is some larger algebra that contains both types of operators. This will naturally create operators with “hybrid kernels” that detect both the Euclidean geometric structure and the Heisenberg geometric structure. A model example of this is the convolution operator ")#mi("Tf := f * K")#text(" where K is the distribution given by a suitable principal value interpretation of the function")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("K( z, t ) := \\frac{z_j z_k}{(\\left|z\\right|^2+\\left|t\\right|^2)^{n+1}} \\frac{1}{\\left|z\\right|^2+it}", block: true)]]

#text("where ")#mi("1 \\leq j,k \\leq n")#text(" are fixed indices. More generally, one could consider convolution kernels ")#mi("f\\mapsto f*K")#text(" where K is smooth for non-zero (z,t) and obeys the derivative estimates")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|\\partial_t^\\beta \\partial_{z,\\overline{z}}^\\alpha K(x)\\right| \\leq C_{\\alpha,\\beta} \\left|x\\right|_E^{-2n-\\left|\\alpha\\right|} \\left|x\\right|_H^{-2-2\\beta}", block: true)]]

#text("where ")#mi("x = (z,t)")#text(", ")#tao-math("\\left|x\\right|_E := (\\left|z\\right|^2+\\left|t\\right|^2)^{1/2}", block: false)#text(", and ")#tao-math("\\left|x\\right|_H := \\left|z\\right|+\\left|t\\right|^{1/2}", block: false)#text(", and also obeys the cancellation condition ")#mi("\\langle K, \\phi_{r,R} \\rangle| \\leq C")#text(" for all ")#mi("0 < R^2 \\leq r^2 \\leq R")#text(", where ")#mi("\\phi")#text(" is a non-trivial bump function and ")#mi("\\phi_{r,R}(z,t) = \\phi(z/r,t/R)")#text(". [Note that (2) just barely prevents K from being absolutely integrable, in analogy with other singular integral operator kernels.] There is also a new condition that appears in this hybrid setting that does not occur in the previous settings: one needs the “marginal distributions” ")#mi("\\int_{\\Bbb R} K(z,t) \\phi(t/R)\\ dt")#text(" and ")#mi("\\int_{{\\Bbb C}^n} K(z,t) \\phi(z/R)\\ dz")#text(" to themselves be Calderòn-Zygmund kernels on ")#mi("{\\Bbb C}^n")#text(" and ")#mi("{\\Bbb R}")#text(" respectively, uniformly in ")#mi("R > 0")#text(".")

#text("The first main result of Nagel et al. is that the class of such operators is an algebra, and is bounded on ")#mi("L^p({\\Bbb H}^n)")#text(" for all ")#mi("1 < p < \\infty")#text(". Furthermore, this algebra of convolution operators can be extended to a larger algebra of “hybrid pseudodifferential operators”")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("Tf(x) := \\int_{{\\Bbb H}^n} K(x,y) f(xy^{-1})\\ dy")]]

#text("where for each fixed x, ")#mi("K(x,y)")#text(" (and more generally ")#mi("\\partial_x^\\alpha K(x,y)")#text(") is a kernel of the above form, uniformly in x. This algebra contains both standard pseudodifferential operators and Calderòn-Zygmund operators on the Heisenberg group. The former turn out to be “almost central” in the sense that the commutator between a pseudodifferential operator and any other operator in this algebra is a smoothing operator (more precisely, it gains 1/2 of a Euclidean derivative in ")#mi("L^2")#text(", and a proportionally lesser amount of regularity in other ")#mi("L^p")#text(" spaces). Similar results exist for other nilpotent groups than the Heisenberg group, as discussed a little later.")

#text("One major difficulty here is that these kernels have a more complicated singularity than just being singular along the diagonal ")#mi("x=y")#text(", in that the region where the kernel is large also concentrates along various higher-dimensional spaces, such as the space ")#mi("\\{ ((z,t), (z^{\\prime},t^{\\prime})): x=x^{\\prime} \\}")#text(". Because of this, the second part of the Calderòn-Zygmund paradigm – i.e. leveraging ")#mi("L^2")#text(" boundedness to obtain ")#mi("L^p")#text(" bounds – does not work well any more. Instead, what Eli and his coauthors did was to go back to an older paradigm, the ")#emph[#text("product paradigm")]#text(", in which results in multidimensional (or multiparameter) harmonic analysis were obtained by iterating results in one-dimensional (or one-parameter) harmonic analysis.")

#text("To explain this paradigm, Eli went back to one of the very first applications of this paradigm, namely the ")#link("http://en.wikipedia.org/wiki/Multiplier_(Fourier_analysis)")[#emph[#text("Marcinkiewicz multiplier theorem")]]#text(", proven in 1933, and used among other things to show that the Riesz-like transforms ")#mi("\\partial_{x_i} \\partial_{x_j} \\Delta^{-1}")#text(" were bounded on ")#mi("L^p({\\Bbb R}^n)")#text(" for ")#mi("1 < p < \\infty")#text(". The precise statement of the theorem is slightly technical and was not given here, but the main ingredient of this theorem was the multidimensional Littlewood-Paley inequality, which in turn followed from iterations of the one-dimensional Littlewood-Paley inequality. To describe this in more detail, Eli then discussed an improvement of the Marcinkiewicz multiplier theorem due to ")#link("http://www.ams.org/mathscinet-getitem?mr=664621")[#text("R. Fefferman and Stein")]#text(", concerning product singular integral operators, which serves as a partial model for the more recent results of Nagel et al.. For simplicity, let us consider convolution operators ")#mi("T: f \\mapsto f * K")#text(" on the plane ")#mi("{\\Bbb R}^2 \\equiv {\\Bbb R} \\times {\\Bbb R}")#text(", although the theory extends to arbitrary products of finitely many Euclidean spaces. We define a product kernel to be a distribution K, smooth away from the coordinate axes ")#mi("\\{ (x_1,x_2): x_1=0 \\text{ or } x_2 = 0 \\}")#text(", that obeys the kernel bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|\\partial_{x_1}^{\\alpha_1} \\partial_{x_2}^{\\alpha_2} K(x_1,x_2)\\right| \\leq C_{\\alpha_1, \\alpha_2} \\left|x_1\\right|^{-1-\\left|\\alpha_1\\right|} \\left|x_2\\right|^{-1-\\left|\\alpha_2\\right|}", block: true)]]

#text("for all ")#mi("\\alpha_1, \\alpha_2 \\geq 0")#text(" and all non-zero ")#mi("x_1, x_2")#text(". We also require two cancellation conditions: firstly, that ")#tao-math("\\left|\\langle K, \\phi_{R_1,R_2} \\rangle\\right| \\leq C", block: false)#text(" for all ")#mi("R_1,R_2 > 0")#text(", where ")#mi("\\phi_{R_1,R_2}(x_1,x_2) := \\phi(x_1/R_1,x_2/R_2)")#text(" and ")#mi("\\phi")#text(" is a non-trivial bump function, and secondly that the marginal kernels ")#mi("\\int_{{\\Bbb R}} K(x_1,x_2) \\phi(x_1/R_1)\\ dx_1")#text(" and ")#mi("\\int_{{\\Bbb R}} K(x_1,x_2) \\phi(x_2/R_2)\\ dx_2")#text(" are one-dimensional Calderòn-Zygmund operators. [Examples of such kernels include the classical two-dimensional Calderòn-Zygmund kernels on ")#mi("{\\Bbb R}^2")#text(", as well as tensor products ")#mi("K_1(x_1) K_2(x_2)")#text(" of one-dimensional Calderòn-Zygmund kernels.]")

#text("The main result of R. Fefferman and Stein was that such convolution operators are bounded on ")#mi("L^p({\\Bbb R}^2)")#text(" for all ")#mi("1 < p < \\infty")#text(" and form a (commutative) algebra. The proof proceeds by the product paradigm. Firstly, one observes that kernels in the above class can be characterised in two different manners, much as in the classical case. On the Fourier-analytic side, the Fourier transform ")#mi("m = \\hat K")#text(" of a product kernel obeys the product symbol estimates ")#tao-math("\\left|\\partial_{\\xi_1}^{\\alpha_1} \\partial_{\\xi_2}^{\\alpha_2} m(\\xi_1,\\xi_2)\\right| \\leq C_{\\alpha_1,\\alpha_2} \\left|\\xi_1\\right|^{-\\left|\\alpha_1\\right|} \\left|\\xi_2\\right|^{-\\left|\\alpha_2\\right|}", block: false)#text(" for all non-zero ")#mi("\\alpha_1,\\alpha_2")#text(". This is enough to establish ")#mi("L^p")#text(" boundedness, but the non-local nature of the singularity means that the usual Calderòn-Zygmund argument to boost the ")#mi("L^2")#text(" bound to ")#mi("L^p")#text(" bounds no longer works well. Instead, one uses the third type of characterisation of these kernels, namely that they can be decomposed as ")#mi("K = \\sum_I \\phi_I")#text(", where ")#mi("I = (i_1,i_2) \\in {\\Bbb Z}^2")#text(", ")#mi("\\phi_{i_1,i_2}(x_1,x_2) = 2^{i_1+i_2} \\phi^{(i_1,i_2)}( 2^{i_1} x_1, 2^{i_2} x_2)")#text(", and the ")#mi("\\phi^{(i_1,i_2)}")#text(" are bump functions uniformly in ")#mi("i_1,i_2")#text(" that satisfy the marginal cancellation conditions ")#mi("\\int_{\\Bbb R} \\phi^{(i_1,i_2)}(x_1,x_2)\\ dx_2 = 0")#text(" and ")#mi("\\int_{\\Bbb R} \\phi^{(i_1,i_2)}(x_1,x_2)\\ dx_1 = 0")#text(".")

#text("This characterisation can be combined with the Littlewood-Paley square function inequality to establish the theorem of R. Fefferman and Stein. To explain this, Eli returned to the one-dimensional (or one-parameter) theory. If ")#mi("T: f \\mapsto f*K")#text(" is a classical Calderòn-Zygmund convolution operator, then by decomposing K into dyadic pieces it is not difficult to show a pointwise estimate of the form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|P_j ( Tf )\\right| \\leq C M \\left|\\tilde P_j f\\right|", block: true)]]

#text("for all j, where ")#mi("P_j: f \\mapsto f * \\phi_j")#text(" is a Littlewood-Paley type projection (thus ")#mi("\\phi_j(x) = 2^j \\phi(2^j x)")#text(" and ")#mi("\\phi")#text(" has mean zero), M is the ")#link("http://en.wikipedia.org/wiki/Hardy-Littlewood_maximal_function")[#text("Hardy-Littlewood maximal function")]#text(", and ")#mi("\\tilde P_j")#text(" is a slightly larger variant of ")#mi("P_j")#text(" (chosen so that ")#mi("P_j = P_j \\tilde P_j")#text(", and hence ")#mi("P_j(Tf) = P_j(T \\tilde P_j f)")#text(" by commutativity). The ")#mi("L^p")#text(" boundedness of T can then be deduced from the Littlewood-Paley square function inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| (\\sum_j \\left|P_j(f)\\right|^2)^{1/2} \\right\\|_{L^p} \\sim \\left\\|f\\right\\|_{L^p}", block: true)]]

#text("and the variant")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left\\| (\\sum_j \\left|M \\tilde P_j(f)\\right|^2)^{1/2} \\right\\|_{L^p} \\sim \\left\\|f\\right\\|_{L^p}", block: true)]]

#text("(which follows by combining the square function inequality with the vector-valued maximal inequality of C. Fefferman and Stein).")

#text("The same method can be applied in the product setting, using the product version of the Littlewood-Paley inequality. On ")#mi("{\\Bbb R}^2")#text(", for instance, one can introduce the Littlewood-Paley projections ")#mi("P_{j_1,j_2} := P^1_{j_1} P^2_{j_2}")#text(" for ")#mi("(j_1,j_2) \\in {\\Bbb Z}^2")#text(", defined by first applying a one-dimensional Littlewood-Paley projection ")#mi("P^1_{j_1}")#text(" in the ")#mi("x_1")#text(" variable (keeping ")#mi("x_2")#text(" frozen), and then applying a one-dimensional Littlewood-Paley projection ")#mi("P^2_{j_2}")#text(" in the ")#mi("x_2")#text(" variable (keeping ")#mi("x_1")#text(" frozen). For the product operators T considered by R. Fefferman and Stein, there is a product analogue of (4), namely")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left|P_J ( Tf )\\right| \\leq C {\\mathcal M} \\left|\\tilde P_J f\\right|", block: true)]]

#text("for all ")#mi("J = (j_1,j_2) \\in {\\Bbb Z}^2")#text(", where ")#mi("\\tilde P_J")#text(" is again a variant of ")#mi("P_J")#text(", and ")#mi("{\\mathcal M} =M_1 M_2")#text(" is the ")#emph[#text("strong maximal function")]#text(", defined by composing the two one-dimensional Hardy-Littlewood maximal functions. There are analogues of the Littlewood-Paley inequalities (5), (6), which can be proven by concatenating various one-dimensional inequalities (basically, one needs certain “vector-valued” extensions of (5), (6)). From these facts, the proof of the theorem of R. Fefferman and Stein is relatively straightforward.")

#text("The moral of the above story is this: the product operator T was not itself a tensor product of lower-dimensional operators, but it was nevertheless ")#emph[#text("controlled")]#text(" by objects (such as the Littlewood-Paley square function and the strong maximal function) which were products of lower-dimensional objects, thus allowing this operator to be controlled by the lower-dimensional theory.")

#text("Eli now returned to the Heisenberg group ")#mi("{\\Bbb H}^n")#text(" to apply the product paradigm to convolution operators ")#mi("f \\mapsto f*K")#text(" such as convolution with the kernel (1). Note that kernels like (1) are already almost of product form; morally we have")

#align(center)[#tao-fit-display[#tao-math("K(z,t) = \\frac{z_j z_k}{(\\left|z\\right|^2+\\left|t\\right|^2)^{n+1}} \\frac{1}{\\left|z\\right|^2+it} ``\\leq`` \\frac{z_j z_k}{\\left|z\\right|^{2n+2}} \\frac{1}{it}", block: true)]]

#text("which suggests that K is “dominated” by the tensor product of two classical kernels. If we were dealing with a Euclidean convolution rather than a Heisenberg convolution, the product theory of R. Fefferman and Stein would then presumably allow us to conclude the bounds one wants for this operator. So the main new difficulty is how to deal with the “twisted” nature of Heisenberg convolution.")

#text("It turns out that the correct way to deal with this is to extend this class of hybrid kernels to a larger class of kernels, which were singular on a ")#link("http://en.wikipedia.org/wiki/Flag_(linear_algebra)")[#text("flag")]#text(" of subspaces rather than at a point. In the Heisenberg case, the relevant flag is ")#mi("\\{0\\} \\subset \\{ (0,t): t \\in {\\Bbb R} \\} \\subset {\\Bbb H}^n")#text(". The corresponding kernels are those that are smooth on ")#mi("\\{ (x,t): x \\neq 0 \\}")#text(" and obey the estimates")

#align(center)[#tao-fit-display[#tao-math("\\left|\\partial_t^\\alpha \\partial_{z,\\overline{z}}^\\beta K(z,t)\\right| \\leq C_{\\alpha,\\beta} \\left|z\\right|^{-2n-\\left|\\alpha\\right|} \\left|(z,t)\\right|_H^{-2-2\\left|\\beta\\right|}", block: true)]]

#text("for all multi-indices ")#mi("\\alpha,\\beta")#text(", where ")#tao-math("\\left|(z,t)\\right|_H := \\left|z\\right|+\\left|t\\right|^{1/2}", block: false)#text(". We also need some cancellation conditions; firstly, that ")#tao-math("\\left|\\langle K, \\phi_{r,R} \\rangle\\right| \\leq C", block: false)#text(" whenever $0 < R^2 \\leq r^2 \\leq R$, where ")#mi("\\phi_{r,R}(z,t) := \\phi(z/r,t/R)")#text(", and secondly that the marginal distributions of K are themselves Calderòn-Zygmund kernels.")

#text("Examples of such operators includes multipliers of the form ")#mi("m( {\\mathcal L}, iT)")#text(", where ")#mi("{\\mathcal L} :=- \\sum_{i=1}^n X_i^2+Y_i^2")#text(" is the sub-Laplacian (which commutes with T), and m is a product symbol of order 0. (In fact, every convolution operator whose kernel obeys the properties of the previous paragraph and is invariant under rotations of the z variable, is of this form.)")

#text("The work of Nagel et al. shows that these flag kernel convolution operators are bounded on ")#mi("L^p")#text(" and form an algebra; furthermore, there is a “variable-coefficient” extension of this algebra involving operators such as (3). To establish this claim, it is in fact convenient to work in a more general setting than a Heisenberg group, namely that of a ")#link("http://en.wikipedia.org/wiki/Graded_algebra")[#text("graded")]#text(" ")#link("http://en.wikipedia.org/wiki/Simply_connected")[#text("simply connected")]#text(" ")#link("http://en.wikipedia.org/wiki/Nilpotent_group")[#text("nilpotent")]#text(" ")#link("http://en.wikipedia.org/wiki/Lie_group")[#text("Lie group")]#text(" G. This group can be described as the exponential ")#mi("G = \\exp{\\mathfrak g}")#text(" of its ")#link("http://en.wikipedia.org/wiki/Lie_algebra")[#text("Lie algebra")]#text(" ")#mi("{\\mathfrak g}")#text(", which in turn can be split as a direct sum ")#mi("{\\mathfrak g} = \\bigoplus_{j=1}^k {\\mathfrak h}_j")#text(", where the ")#mi("{\\mathfrak h}_j")#text(" are subspaces obeying the commutation relations ")#mi("{}[{\\mathfrak h}_j, {\\mathfrak h}_l] \\subset {\\mathfrak h}_{j+l}")#text(" (with the convention that ")#mi("{\\mathfrak h}_j")#text(" is trivial for ")#mi("j > k")#text("). This grading leads to a ")#link("http://en.wikipedia.org/wiki/Filtration_(mathematics)")[#text("filtration")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Flag_(linear_algebra)")[#text("flag")]#text(")")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak g} = {\\mathfrak g}_1 \\supset \\ldots \\supset {\\mathfrak g}_k \\supset \\{0\\}")]]

#text("defined by ")#mi("{\\mathfrak g}_j := {\\mathfrak h}_j \\oplus \\ldots \\oplus {\\mathfrak h}_k")#text(". Exponentiating this leads to a corresponding filtration of Lie groups")

#align(center)[#tao-fit-display[#mitex("G = G_1 \\geq G_2 \\geq \\ldots \\geq G_k \\geq \\{\\text{id}\\}.")]]

#text("We parameterise elements of ")#mi("{\\mathfrak g} \\equiv G")#text(" by ")#mi("(x_1,\\ldots,x_k)")#text(", where ")#mi("x_j \\in {\\mathfrak g}_j")#text(". We then have a natural scaling")

#align(center)[#tao-fit-display[#mitex("(x_1,\\ldots,x_k) \\mapsto (\\delta x_1, \\ldots, \\delta^k x_k)")]]

#text("that respects all the previous structures, and gives the Lie algebra a homogeneous dimension of ")#mi("Q := \\sum_{j=1}^k j \\text{dim}({\\mathfrak g}_j)")#text(". We also have some “semi-norms”")

#align(center)[#tao-fit-display[#tao-math("N_j(x_1,\\ldots,x_k) := \\left|x_1\\right|^j + \\left|x_2\\right|^{j/2} + \\ldots + \\left|x_j\\right|", block: true)]]

#text("which can be viewed as a variant of ")#tao-math("\\left|x_j\\right|", block: false)#text(" (for instance, they behave the same way with respect to scaling). We then define a flag kernel to be a function K on ")#mi("{\\mathfrak g} \\equiv G")#text(" that is smooth on the set ")#mi("x_1 \\neq 0")#text(", obeys the derivative bounds")

#align(center)[#tao-math("\\left|\\partial_{x_1}^{\\alpha_1} \\ldots \\partial_{x_k}^{\\alpha_k} K(x_1,\\ldots,x_k)\\right| \\leq C_{\\alpha_1,\\ldots,\\alpha_k} \\prod_{j=1}^k N_j(x_j)^{-\\text{dim}({\\mathfrak g}_j)-\\left|\\alpha_j\\right|}", block: false)#text(",")]

#text("is such that ")#tao-math("\\left|\\langle K, \\phi_R \\rangle\\right| \\leq C", block: false)#text(" for all “acceptable” radii ")#mi("R = (r_1,\\ldots,r_k)")#text(", where ")#mi("\\phi_R(x_1,\\ldots,x_k) = \\phi(x_1/r_1,\\ldots,x_k/r_k)")#text(" and “acceptable” means that ")#mi("r_1^k \\leq r_2^{k/2} \\leq \\ldots \\leq r_k")#text(", and such that every marginal integral of K is itself a flag kernel of lower dimension (so this is a recursive definition). The main theorem here is, once again, that convolution operators with flag kernels are bounded on ")#mi("L^p(G)")#text(" for every ")#mi("1 < p < \\infty")#text(" and form a (non-commutative) algebra. Once one has this result (as well as a variable coefficient generalisation of this result), all the other results claimed earlier follow fairly easily.")

#text("[The main reason we restrict attention to “acceptable” radii scales is that the corresponding bump functions ")#mi("\\phi_R")#text(" are stable under twisted convolution: the convolution of two such ")#mi("\\phi_R")#text(" is essentially a multiple of another ")#mi("\\phi_R")#text(".]")

#text("Eli then briefly sketched the main ingredients of the proof of the above theorem. The first step is to introduce Littlewood-Paley operators ")#mi("P^{(m)}_j")#text(" for each subgroup ")#mi("G_m")#text(", which one can then lift to act also on the whole group G (by foliating G into cosets of the normal subgroup ")#mi("G_m")#text("). One can then create multiparameter Littlewood-Paley operators ")#mi("P_J = P_{j_k}^{(k)} \\ldots P_{j_1}^{(1)}")#text(" for ")#mi("J = (j_1,\\ldots,j_k) \\in {\\Bbb Z}^k")#text(". (One has to be a little careful here because these operators don’t commute with each other, but as long as one orders things consistently, things turn out to be OK.) One also has a strong maximal function ")#mi("{\\mathcal M}")#text(" associated to acceptable boxes. The main proposition is then a variant of (7), namely that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left|P_J T P_I^* f\\right| \\leq C 2^{-c\\left|I-J\\right|} {\\mathcal M} f", block: true)]]

#text("for all ")#mi("I, J \\in {\\Bbb Z}^k")#text(", where ")#mi("c > 0")#text(" is an absolute constant. One can use this inequality to deduce everything one needs using appropriate variants of the Littlewood-Paley square function inequality as before.")

#text("The proof of (8) is somewhat complicated by the twisted nature of convolution on nilpotent Lie groups. A key technical step in the proof of (8) (and one which, apparently, held up the project for quite some time) was to show that the class of flag kernels was stable under various “acceptable” changes of variables, such as the change from canonical coordinates ")#mi("\\exp(\\sum_i a_i X_i ) \\to (a_1,\\ldots,a_n)")#text(" of the first kind for the Lie group G, to canonical coordinates ")#mi("\\prod_i \\exp(a_i X_i) \\to (a_1,\\ldots,a_n)")#text(" of the second kind.")
