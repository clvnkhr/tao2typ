// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/09/16/inverting-the-schur-complement-and-large-dimensional-gelfand-tsetlin-patterns/
// Converted to Typst by tao2typ: "2026-10-14T16:38:11.784047+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Inverting the Schur complement, and large-dimensional Gelfand-Tsetlin patterns", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Inverting the Schur complement, and large-dimensional Gelfand-Tsetlin patterns")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 September 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/09/16/inverting-the-schur-complement-and-large-dimensional-gelfand-tsetlin-patterns/")[#text("https://terrytao.wordpress.com/2017/09/16/inverting-the-schur-complement-and-large-dimensional-gelfand-tsetlin-patterns/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Suppose we have an ")#mi("{n \\times n}")#text(" matrix ")#mi("{M}")#text(" that is expressed in block-matrix form as")

#align(center)[#tao-fit-display[#mitex("M = \\begin{pmatrix} A & B \\\\ C & D \\end{pmatrix}")]]

#text("where ")#mi("{A}")#text(" is an ")#mi("{(n-k) \\times (n-k)}")#text(" matrix, ")#mi("{B}")#text(" is an ")#mi("{(n-k) \\times k}")#text(" matrix, ")#mi("{C}")#text(" is an ")#mi("{k \\times (n-k)}")#text(" matrix, and ")#mi("{D}")#text(" is a ")#mi("{k \\times k}")#text(" matrix for some ")#mi("{1 < k < n}")#text(". If ")#mi("{A}")#text(" is invertible, we can use the technique of ")#link("https://en.wikipedia.org/wiki/Schur_complement")[#text("Schur complementation")]#text(" to express the inverse of ")#mi("{M}")#text(" (if it exists) in terms of the inverse of ")#mi("{A}")#text(", and the other components ")#mi("{B,C,D}")#text(" of course. Indeed, to solve the equation")

#align(center)[#tao-fit-display[#mitex("M \\begin{pmatrix} x & y \\end{pmatrix} = \\begin{pmatrix} a & b \\end{pmatrix},")]]

#text("where ")#mi("{x, a}")#text(" are ")#mi("{(n-k) \\times 1}")#text(" column vectors and ")#mi("{y,b}")#text(" are ")#mi("{k \\times 1}")#text(" column vectors, we can expand this out as a system")

#tao-aligned(keep: true)[


#tao-math("Ax + By  & = a", block: true)



#tao-math("Cx + Dy  & = b.", block: true)
]

#text("Using the invertibility of ")#mi("{A}")#text(", we can write the first equation as ")#metadata(none) <tao-8f26d6fe2a3dafd82808>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("x = A^{-1} a - A^{-1} B y")]]

#text("and substituting this into the second equation yields")

#align(center)[#tao-fit-display[#mitex("(D - C A^{-1} B) y = b - C A^{-1} a")]]

#text("and thus (assuming that ")#mi("{D - CA^{-1} B}")#text(" is invertible)")

#align(center)[#tao-fit-display[#mitex("y = - (D - CA^{-1} B)^{-1} CA^{-1} a + (D - CA^{-1} B)^{-1} b")]]

#text("and then inserting this back into ")#link(<tao-8f26d6fe2a3dafd82808>)[#text("(1)")]#text(" gives")

#align(center)[#tao-fit-display[#mitex("x = (A^{-1} + A^{-1} B (D - CA^{-1} B)^{-1} C A^{-1}) a - A^{-1} B (D - CA^{-1} B)^{-1} b.")]]

#text("Comparing this with")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} x & y \\end{pmatrix} = M^{-1} \\begin{pmatrix} a & b \\end{pmatrix},")]]

#text("we have managed to express the inverse of ")#mi("{M}")#text(" as")

#align(center)[#tao-fit-display[#mitex("M^{-1} =")]]

#metadata(none) <tao-5e85370e555e95d27df6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\begin{pmatrix} A^{-1} + A^{-1} B (D - CA^{-1} B)^{-1} C A^{-1} & - A^{-1} B (D - CA^{-1} B)^{-1} \\\\ - (D - CA^{-1} B)^{-1} CA^{-1} & (D - CA^{-1} B)^{-1} \\end{pmatrix}.")]]

#text("One can consider the inverse problem: given the inverse ")#mi("{M^{-1}}")#text(" of ")#mi("{M}")#text(", does one have a nice formula for the inverse ")#mi("{A^{-1}}")#text(" of the minor ")#mi("{A}")#text("? Trying to recover this directly from ")#link(<tao-5e85370e555e95d27df6>)[#text("(2)")]#text(" looks somewhat messy. However, one can proceed as follows. Let ")#mi("{U}")#text(" denote the ")#mi("{n \\times k}")#text(" matrix")

#align(center)[#tao-fit-display[#mitex("U := \\begin{pmatrix} 0 \\\\ I_k \\end{pmatrix}")]]

#text("(with ")#mi("{I_k}")#text(" the ")#mi("{k \\times k}")#text(" identity matrix), and let ")#mi("{V}")#text(" be its transpose:")

#align(center)[#tao-fit-display[#mitex("V := \\begin{pmatrix} 0 & I_k \\end{pmatrix}.")]]

#text("Then for any scalar ")#mi("{t}")#text(" (which we identify with ")#mi("{t}")#text(" times the identity matrix), one has")

#align(center)[#tao-fit-display[#mitex("M + UtV = \\begin{pmatrix} A & B \\\\ C & D+t \\end{pmatrix},")]]

#text("and hence by ")#link(<tao-5e85370e555e95d27df6>)[#text("(2)")]

#align(center)[#tao-fit-display[#mitex("(M+UtV)^{-1} =")]]

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} A^{-1} + A^{-1} B (D + t - CA^{-1} B)^{-1} C A^{-1} & - A^{-1} B (D + t- CA^{-1} B)^{-1} \\\\ - (D + t - CA^{-1} B)^{-1} CA^{-1} & (D + t - CA^{-1} B)^{-1} \\end{pmatrix}.")]]

#text("noting that the inverses here will exist for ")#mi("{t}")#text(" large enough. Taking limits as ")#mi("{t \\rightarrow \\infty}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\lim_{t \\rightarrow \\infty} (M+UtV)^{-1} = \\begin{pmatrix} A^{-1} & 0 \\\\ 0 & 0 \\end{pmatrix}.")]]

#text("On the other hand, by the ")#link("https://en.wikipedia.org/wiki/Woodbury_matrix_identity")[#text("Woodbury matrix identity")]#text(" (discussed in ")#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/")[#text("this previous blog post")]#text("), we have")

#align(center)[#tao-fit-display[#mitex("(M+UtV)^{-1} = M^{-1} - M^{-1} U (t^{-1} + V M^{-1} U)^{-1} V M^{-1}")]]

#text("and hence on taking limits and comparing with the preceding identity, one has")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} A^{-1} & 0 \\\\ 0 & 0 \\end{pmatrix} = M^{-1} - M^{-1} U (V M^{-1} U)^{-1} V M^{-1}.")]]

#text("This achieves the aim of expressing the inverse ")#mi("{A^{-1}}")#text(" of the minor in terms of the inverse of the full matrix. Taking traces and rearranging, we conclude in particular that ")#metadata(none) <tao-c9768948bba65e0f90d9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\mathrm{tr} A^{-1} = \\mathrm{tr} M^{-1} - \\mathrm{tr} (V M^{-2} U) (V M^{-1} U)^{-1}.")]]

#text("In the ")#mi("{k=1}")#text(" case, this can be simplified to ")#metadata(none) <tao-59af442de9ad6a95613b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\mathrm{tr} A^{-1} = \\mathrm{tr} M^{-1} - \\frac{e_n^T M^{-2} e_n}{e_n^T M^{-1} e_n}")]]

#text("where ")#mi("{e_n}")#text(" is the ")#mi("{n^{th}}")#text(" basis column vector.")

#text("We can apply this identity to understand how the spectrum of an ")#mi("{n \\times n}")#text(" random matrix ")#mi("{M}")#text(" relates to that of its top left ")#mi("{n-1 \\times n-1}")#text(" minor ")#mi("{A}")#text(". Subtracting any complex multiple ")#mi("{z}")#text(" of the identity from ")#mi("{M}")#text(" (and hence from ")#mi("{A}")#text("), we can relate the ")#link("https://en.wikipedia.org/wiki/Stieltjes_transformation")[#text("Stieltjes transform")]#text(" ")#mi("{s_M(z) := \\frac{1}{n} \\mathrm{tr}(M-z)^{-1}}")#text(" of ")#mi("{M}")#text(" with the Stieltjes transform ")#mi("{s_A(z) := \\frac{1}{n-1} \\mathrm{tr}(A-z)^{-1}}")#text(" of ")#mi("{A}")#text(": ")#metadata(none) <tao-523c3c6f72c9ee90eedc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("s_A(z) = \\frac{n}{n-1} s_M(z) - \\frac{1}{n-1} \\frac{e_n^T (M-z)^{-2} e_n}{e_n^T (M-z)^{-1} e_n}")]]

#text("At this point we begin to proceed informally. Assume for sake of argument that the random matrix ")#mi("{M}")#text(" is Hermitian, with distribution that is invariant under conjugation by the unitary group ")#mi("{U(n)}")#text("; for instance, ")#mi("{M}")#text(" could be drawn from the ")#link("https://en.wikipedia.org/wiki/Random_matrix#Gaussian_ensembles")[#text("Gaussian Unitary Ensemble")]#text(" (GUE), or alternatively ")#mi("{M}")#text(" could be of the form ")#mi("{M = U D U^*}")#text(" for some real diagonal matrix ")#mi("{D}")#text(" and ")#mi("{U}")#text(" a unitary matrix drawn randomly from ")#mi("{U(n)}")#text(" using Haar measure. To fix normalisations we will assume that the eigenvalues of ")#mi("{M}")#text(" are typically of size ")#mi("{O(1)}")#text(". Then ")#mi("{A}")#text(" is also Hermitian and ")#mi("{U(n)}")#text("-invariant. Furthermore, the law of ")#mi("{e_n^T (M-z)^{-1} e_n}")#text(" will be the same as the law of ")#mi("{u^* (M-z)^{-1} u}")#text(", where ")#mi("{u}")#text(" is now drawn uniformly from the unit sphere (independently of ")#mi("{M}")#text("). Diagonalising ")#mi("{M}")#text(" into eigenvalues ")#mi("{\\lambda_j}")#text(" and eigenvectors ")#mi("{v_j}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("u^* (M-z)^{-1} u = \\sum_{j=1}^n \\frac{\\left|u^* v_j\\right|^2}{\\lambda_j - z}.", block: true)]]

#text("One can think of ")#mi("{u}")#text(" as a random (complex) Gaussian vector, divided by the magnitude of that vector (which, by the Chernoff inequality, will concentrate to ")#mi("{\\sqrt{n}}")#text("). Thus the coefficients ")#mi("{u^* v_j}")#text(" with respect to the orthonormal basis ")#mi("{v_1,\\dots,v_j}")#text(" can be thought of as independent (complex) Gaussian vectors, divided by that magnitude. Using this and the Chernoff inequality again, we see (for ")#mi("{z}")#text(" distance ")#mi("{\\sim 1}")#text(" away from the real axis at least) that one has the concentration of measure")

#align(center)[#tao-fit-display[#mitex("u^* (M-z)^{-1} u \\approx \\frac{1}{n} \\sum_{j=1}^n \\frac{1}{\\lambda_j - z}")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("e_n^T (M-z)^{-1} e_n \\approx \\frac{1}{n} \\mathrm{tr} (M-z)^{-1} = s_M(z)")]]

#text("(that is to say, the diagonal entries of ")#mi("{(M-z)^{-1}}")#text(" are roughly constant). Similarly we have")

#align(center)[#tao-fit-display[#mitex("e_n^T (M-z)^{-2} e_n \\approx \\frac{1}{n} \\mathrm{tr} (M-z)^{-2} = \\frac{d}{dz} s_M(z).")]]

#text("Inserting this into ")#link(<tao-523c3c6f72c9ee90eedc>)[#text("(5)")]#text(" and discarding terms of size ")#mi("{O(1/n^2)}")#text(", we thus conclude the approximate relationship")

#align(center)[#tao-fit-display[#mitex("s_A(z) \\approx s_M(z) + \\frac{1}{n} ( s_M(z) - s_M(z)^{-1} \\frac{d}{dz} s_M(z) ).")]]

#text("This can be viewed as a difference equation for the Stieltjes transform of top left minors of ")#mi("{M}")#text(". Iterating this equation, and formally replacing the difference equation by a differential equation in the large ")#mi("{n}")#text(" limit, we see that when ")#mi("{n}")#text(" is large and ")#mi("{k \\approx e^{-t} n}")#text(" for some ")#mi("{t \\geq 0}")#text(", one expects the top left ")#mi("{k \\times k}")#text(" minor ")#mi("{A_k}")#text(" of ")#mi("{M}")#text(" to have Stieltjes transform ")#metadata(none) <tao-84e536696b764ca9d458>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("s_{A_k}(z) \\approx s( t, z )")]]

#text("where ")#mi("{s(t,z)}")#text(" solves the Burgers-type equation ")#metadata(none) <tao-066cae0fda0b5685c46b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\partial_t s(t,z) = s(t,z) - s(t,z)^{-1} \\frac{d}{dz} s(t,z)")]]

#text("with initial data ")#mi("{s(0,z) = s_M(z)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" ")#metadata(none) <tao-1eeffe64ffed560e873c>#text(" If ")#mi("{M}")#text(" is a constant multiple ")#mi("{M = cI_n}")#text(" of the identity, then ")#mi("{s_M(z) = \\frac{1}{c-z}}")#text(". One checks that ")#mi("{s(t,z) = \\frac{1}{c-z}}")#text(" is a steady state solution to ")#link(<tao-066cae0fda0b5685c46b>)[#text("(7)")]#text(", which is unsurprising given that all minors of ")#mi("{M}")#text(" are also ")#mi("{c}")#text(" times the identity.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" ")#metadata(none) <tao-eef70f4158cde69e1d7f>#text(" If ")#mi("{M}")#text(" is GUE normalised so that each entry has variance ")#mi("{\\sigma^2/n}")#text(", then by the semi-circular law (see ")#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/")[#text("previous notes")]#text(") one has ")#mi("{s_M(z) \\approx \\frac{-z + \\sqrt{z^2-4\\sigma^2}}{2\\sigma^2} = -\\frac{2}{z + \\sqrt{z^2-4\\sigma^2}}}")#text(" (using an appropriate branch of the square root). One can then verify the self-similar solution")

#align(center)[#tao-fit-display[#mitex("s(t,z) = \\frac{-z + \\sqrt{z^2 - 4\\sigma^2 e^{-t}}}{2\\sigma^2 e^{-t}} = -\\frac{2}{z + \\sqrt{z^2 - 4\\sigma^2 e^{-t}}}")]]

#text("to ")#link(<tao-066cae0fda0b5685c46b>)[#text("(7)")]#text(", which is consistent with the fact that a top ")#mi("{k \\times k}")#text(" minor of ")#mi("{M}")#text(" also has the law of GUE, with each entry having variance ")#mi("{\\sigma^2 / n \\approx \\sigma^2 e^{-t} / k}")#text(" when ")#mi("{k \\approx e^{-t} n}")#text(".")
]

#text("One can justify the approximation ")#link(<tao-84e536696b764ca9d458>)[#text("(6)")]#text(" given a sufficiently good well-posedness theory for the equation ")#link(<tao-066cae0fda0b5685c46b>)[#text("(7)")]#text(". We will not do so here, but will note that (as with the classical ")#link("https://en.wikipedia.org/wiki/Burgers%27_equation")[#text("inviscid Burgers equation")]#text(") the equation can be solved exactly (formally, at least) by the ")#link("https://en.wikipedia.org/wiki/Method_of_characteristics")[#text("method of characteristics")]#text(". For any initial position ")#mi("{z_0}")#text(", we consider the characteristic flow ")#mi("{t \\mapsto z(t)}")#text(" formed by solving the ODE ")#metadata(none) <tao-7e15c7c1a6037e9efd88>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\frac{d}{dt} z(t) = s(t,z(t))^{-1}")]]

#text("with initial data ")#mi("{z(0) = z_0}")#text(", ignoring for this discussion the problems of existence and uniqueness. Then from the chain rule, the equation ")#link(<tao-066cae0fda0b5685c46b>)[#text("(7)")]#text(" implies that")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} s( t, z(t) ) = s(t,z(t))")]]

#text("and thus ")#mi("{s(t,z(t)) = e^t s(0,z_0)}")#text(". Inserting this back into ")#link(<tao-7e15c7c1a6037e9efd88>)[#text("(8)")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("z(t) = z_0 + s(0,z_0)^{-1} (1-e^{-t})")]]

#text("and thus ")#link(<tao-066cae0fda0b5685c46b>)[#text("(7)")]#text(" may be solved implicitly via the equation ")#metadata(none) <tao-bb1046b429a7f917a06d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("s(t, z_0 + s(0,z_0)^{-1} (1-e^{-t}) ) = e^t s(0, z_0)")]]

#text("for all ")#mi("{t}")#text(" and ")#mi("{z_0}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" In practice, the equation ")#link(<tao-bb1046b429a7f917a06d>)[#text("(9)")]#text(" may stop working when ")#mi("{z_0 + s(0,z_0)^{-1} (1-e^{-t})}")#text(" crosses the real axis, as ")#link(<tao-066cae0fda0b5685c46b>)[#text("(7)")]#text(" does not necessarily hold in this region. It is a cute exercise (ultimately coming from the Cauchy-Schwarz inequality) to show that this crossing always happens, for instance if ")#mi("{z_0}")#text(" has positive imaginary part then ")#mi("{z_0 + s(0,z_0)^{-1}}")#text(" necessarily has negative or zero imaginary part.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4")]#text(" Suppose we have ")#mi("{s(0,z) = \\frac{1}{c-z}}")#text(" as in Example ")#link(<tao-1eeffe64ffed560e873c>)[#text("1")]#text(". Then ")#link(<tao-bb1046b429a7f917a06d>)[#text("(9)")]#text(" becomes")

#align(center)[#tao-fit-display[#mitex("s( t, z_0 + (c-z_0) (1-e^{-t}) ) = \\frac{e^t}{c-z_0}")]]

#text("for any ")#mi("{t,z_0}")#text(", which after making the change of variables ")#mi("{z = z_0 + (c-z_0) (1-e^{-t}) = c - e^{-t} (c - z_0)}")#text(" becomes")

#align(center)[#tao-fit-display[#mitex("s(t, z ) = \\frac{1}{c-z}")]]

#text("as in Example ")#link(<tao-1eeffe64ffed560e873c>)[#text("1")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 5")]#text(" Suppose we have")

#align(center)[#tao-fit-display[#mitex("s(0,z) = \\frac{-z + \\sqrt{z^2-4\\sigma^2}}{2\\sigma^2} = -\\frac{2}{z + \\sqrt{z^2-4\\sigma^2}}.")]]

#text("as in Example ")#link(<tao-eef70f4158cde69e1d7f>)[#text("2")]#text(". Then ")#link(<tao-bb1046b429a7f917a06d>)[#text("(9)")]#text(" becomes")

#align(center)[#tao-fit-display[#mitex("s(t, z_0 - \\frac{z_0 + \\sqrt{z_0^2-4\\sigma^2}}{2} (1-e^{-t}) ) = e^t \\frac{-z_0 + \\sqrt{z_0^2-4\\sigma^2}}{2\\sigma^2}.")]]

#text("If we write")

#tao-aligned(keep: true)[


#tao-math("z  & := z_0 - \\frac{z_0 + \\sqrt{z_0^2-4\\sigma^2}}{2} (1-e^{-t})", block: true)



#tao-math(" & = \\frac{(1+e^{-t}) z_0 - (1-e^{-t}) \\sqrt{z_0^2-4\\sigma^2}}{2}", block: true)
]

#text("one can calculate that")

#align(center)[#tao-fit-display[#mitex("z^2 - 4 \\sigma^2 e^{-t} = (\\frac{(1-e^{-t}) z_0 - (1+e^{-t}) \\sqrt{z_0^2-4\\sigma^2}}{2})^2")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\frac{-z + \\sqrt{z^2 - 4\\sigma^2 e^{-t}}}{2\\sigma^2 e^{-t}} = e^t \\frac{-z_0 + \\sqrt{z_0^2-4\\sigma^2}}{2\\sigma^2}")]]

#text("which gives ")#metadata(none) <tao-6983682fa44129f21f37>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("s(t,z) = \\frac{-z + \\sqrt{z^2 - 4\\sigma^2 e^{-t}}}{2\\sigma^2 e^{-t}}.")]]
]

#text("One can recover the spectral measure ")#mi("{\\mu}")#text(" from the Stieltjes transform ")#mi("{s(z)}")#text(" as the weak limit of ")#mi("{x \\mapsto \\frac{1}{\\pi} \\mathrm{Im} s(x+i\\varepsilon)}")#text(" as ")#mi("{\\varepsilon \\rightarrow 0}")#text("; we write this informally as")

#align(center)[#tao-fit-display[#mitex("d\\mu(x) = \\frac{1}{\\pi} \\mathrm{Im} s(x+i0^+)\\ dx.")]]

#text("In this informal notation, we have for instance that")

#align(center)[#tao-fit-display[#mitex("\\delta_c(x) = \\frac{1}{\\pi} \\mathrm{Im} \\frac{1}{c-x-i0^+}\\ dx")]]

#text("which can be interpreted as the fact that the Cauchy distributions ")#mi("{\\frac{1}{\\pi} \\frac{\\varepsilon}{(c-x)^2+\\varepsilon^2}}")#text(" converge weakly to the Dirac mass at ")#mi("{c}")#text(" as ")#mi("{\\varepsilon \\rightarrow 0}")#text(". Similarly, the spectral measure associated to ")#link(<tao-6983682fa44129f21f37>)[#text("(10)")]#text(" is the semicircular measure ")#mi("{\\frac{1}{2\\pi \\sigma^2 e^{-t}} (4 \\sigma^2 e^{-t}-x^2)_+^{1/2}}")#text(".")

#text("If we let ")#mi("{\\mu_t}")#text(" be the spectral measure associated to ")#mi("{s(t,\\cdot)}")#text(", then the curve ")#mi("{e^{-t} \\mapsto \\mu_t}")#text(" from ")#mi("{(0,1]}")#text(" to the space of measures is the high-dimensional limit ")#mi("{n \\rightarrow \\infty}")#text(" of a Gelfand-Tsetlin pattern (discussed in ")#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/")[#text("this previous post")]#text("), if the pattern is randomly generated amongst all matrices ")#mi("{M}")#text(" with spectrum asymptotic to ")#mi("{\\mu_0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". For instance, if ")#mi("{\\mu_0 = \\delta_c}")#text(", then the curve is ")#mi("{\\alpha \\mapsto \\delta_c}")#text(", corresponding to a pattern that is entirely filled with ")#mi("{c}")#text("‘s. If instead ")#mi("{\\mu_0 = \\frac{1}{2\\pi \\sigma^2} (4\\sigma^2-x^2)_+^{1/2}}")#text(" is a semicircular distribution, then the pattern is")

#align(center)[#tao-fit-display[#mitex("\\alpha \\mapsto \\frac{1}{2\\pi \\sigma^2 \\alpha} (4\\sigma^2 \\alpha -x^2)_+^{1/2},")]]

#text("thus at height ")#mi("{\\alpha}")#text(" from the top, the pattern is semicircular on the interval ")#mi("{[-2\\sigma \\sqrt{\\alpha}, 2\\sigma \\sqrt{\\alpha}]}")#text(". The interlacing property of Gelfand-Tsetlin patterns translates to the claim that ")#mi("{\\alpha \\mu_\\alpha(-\\infty,\\lambda)}")#text(" (resp. ")#mi("{\\alpha \\mu_\\alpha(\\lambda,\\infty)}")#text(") is non-decreasing (resp. non-increasing) in ")#mi("{\\alpha}")#text(" for any fixed ")#mi("{\\lambda}")#text(". In principle one should be able to establish these monotonicity claims directly from the PDE ")#link(<tao-066cae0fda0b5685c46b>)[#text("(7)")]#text(" or from the implicit solution ")#link(<tao-bb1046b429a7f917a06d>)[#text("(9)")]#text(", but it was not clear to me how to do so.")

#text("An interesting example of such a limiting Gelfand-Tsetlin pattern occurs when ")#mi("{\\mu_0 = \\frac{1}{2} \\delta_{-1} + \\frac{1}{2} \\delta_1}")#text(", which corresponds to ")#mi("{M}")#text(" being ")#mi("{2P-I}")#text(", where ")#mi("{P}")#text(" is an orthogonal projection to a random ")#mi("{n/2}")#text("-dimensional subspace of ")#mi("{{\\bf C}^n}")#text(". Here we have")

#align(center)[#tao-fit-display[#mitex("s(0,z) = \\frac{1}{2} \\frac{1}{-1-z} + \\frac{1}{2} \\frac{1}{1-z} = \\frac{z}{1-z^2}")]]

#text("and so ")#link(<tao-bb1046b429a7f917a06d>)[#text("(9)")]#text(" in this case becomes")

#align(center)[#tao-fit-display[#mitex("s(t, z_0 + \\frac{1-z_0^2}{z_0} (1-e^{-t}) ) = \\frac{e^t z_0}{1-z_0^2}")]]

#text("A tedious calculation then gives the solution ")#metadata(none) <tao-7d9b73003b497e43b0fc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("s(t,z) = \\frac{(2e^{-t}-1)z + \\sqrt{z^2 - 4e^{-t}(1-e^{-t})}}{2e^{-t}(1-z^2)}.")]]

#text("For ")#mi("{\\alpha = e^{-t} > 1/2}")#text(", there are simple poles at ")#mi("{z=-1,+1}")#text(", and the associated measure is")

#align(center)[#tao-fit-display[#mitex("\\mu_\\alpha = \\frac{2\\alpha-1}{2\\alpha} \\delta_{-1} + \\frac{2\\alpha-1}{2\\alpha} \\delta_1 + \\frac{1}{2\\pi \\alpha(1-x^2)} (4\\alpha(1-\\alpha)-x^2)_+^{1/2}\\ dx.")]]

#text("This reflects the interlacing property, which forces ")#mi("{\\frac{2\\alpha-1}{2\\alpha} \\alpha n}")#text(" of the ")#mi("{\\alpha n}")#text(" eigenvalues of the ")#mi("{\\alpha n \\times \\alpha n}")#text(" minor to be equal to ")#mi("{-1}")#text(" (resp. ")#mi("{+1}")#text("). For ")#mi("{\\alpha = e^{-t} \\leq 1/2}")#text(", the poles disappear and one just has")

#align(center)[#tao-fit-display[#mitex("\\mu_\\alpha = \\frac{1}{2\\pi \\alpha(1-x^2)} (4\\alpha(1-\\alpha)-x^2)_+^{1/2}\\ dx.")]]

#text("For ")#mi("{\\alpha=1/2}")#text(", one has an inverse semicircle distribution")

#align(center)[#tao-fit-display[#mitex("\\mu_{1/2} = \\frac{1}{\\pi} (1-x^2)_+^{-1/2}.")]]

#text("There is presumably a direct geometric explanation of this fact (basically describing the singular values of the product of two random orthogonal projections to half-dimensional subspaces of ")#mi("{{\\bf C}^n}")#text("), but I do not know of one off-hand.")

#text("The evolution of ")#mi("{s(t,z)}")#text(" can also be understood using the ")#emph[#mi("{R}")#text("-transform")]#text(" and ")#emph[#mi("{S}")#text("-transform")]#text(" from free probability. Formally, letlet ")#mi("{z(t,s)}")#text(" be the inverse of ")#mi("{s(t,z)}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("s(t,z(t,s)) = s")]]

#text("for all ")#mi("{t,s}")#text(", and then define the ")#mi("{R}")#text("-transform")

#align(center)[#tao-fit-display[#mitex("R(t,s) := z(t,-s) - \\frac{1}{s}.")]]

#text("The equation ")#link(<tao-bb1046b429a7f917a06d>)[#text("(9)")]#text(" may be rewritten as")

#align(center)[#tao-fit-display[#mitex("z( t, e^t s ) = z(0,s) + s^{-1} (1-e^{-t})")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("R(t, -e^t s) = R(0, -s)")]]

#text("or equivalently ")#metadata(none) <tao-be1db3249c28eae3c154>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("R(t,s) = R(0, e^{-t} s).")]]

#text("See ")#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/")[#text("these previous notes")]#text(" for a discussion of free probability topics such as the ")#mi("{R}")#text("-transform.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 6")]#text(" If ")#mi("{s(t,z) = \\frac{1}{c-z}}")#text(" then the ")#mi("{R}")#text(" transform is ")#mi("{R(t,s) = c}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 7")]#text(" If ")#mi("{s(t,z)}")#text(" is given by ")#link(<tao-6983682fa44129f21f37>)[#text("(10)")]#text(", then the ")#mi("{R}")#text(" transform is")

#align(center)[#tao-fit-display[#mitex("R(t,s) = \\sigma^2 e^{-t} s.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 8")]#text(" If ")#mi("{s(t,z)}")#text(" is given by ")#link(<tao-7d9b73003b497e43b0fc>)[#text("(11)")]#text(", then the ")#mi("{R}")#text(" transform is")

#align(center)[#tao-fit-display[#mitex("R(t,s) = \\frac{-1 + \\sqrt{1 + 4 s^2 e^{-2t}}}{2 s e^{-t}}.")]]
]

#text("This simple relationship ")#link(<tao-be1db3249c28eae3c154>)[#text("(12)")]#text(" is essentially ")#link("https://arxiv.org/abs/funct-an/9604011")[#text("due to Nica and Speicher")]#text(" (thanks to Dima Shylakhtenko for this reference). It has the remarkable consequence that when ")#mi("{\\alpha = 1/m}")#text(" is the reciprocal of a natural number ")#mi("{m}")#text(", then ")#mi("{\\mu_{1/m}}")#text(" is the free arithmetic mean of ")#mi("{m}")#text(" copies of ")#mi("{\\mu}")#text(", that is to say ")#mi("{\\mu_{1/m}}")#text(" is the free convolution ")#mi("{\\mu \\boxplus \\dots \\boxplus \\mu}")#text(" of ")#mi("{m}")#text(" copies of ")#mi("{\\mu}")#text(", pushed forward by the map ")#mi("{\\lambda \\rightarrow \\lambda/m}")#text(". In terms of random matrices, this is asserting that the top ")#mi("{n/m \\times n/m}")#text(" minor of a random matrix ")#mi("{M}")#text(" has spectral measure approximately equal to that of an arithmetic mean ")#mi("{\\frac{1}{m} (M_1 + \\dots + M_m)}")#text(" of ")#mi("{m}")#text(" independent copies of ")#mi("{M}")#text(", so that the process of taking top left minors is in some sense a continuous analogue of the process of taking freely independent arithmetic means. There ought to be a geometric proof of this assertion, but I do not know of one. In the limit ")#mi("{m \\rightarrow \\infty}")#text(" (or ")#mi("{\\alpha \\rightarrow 0}")#text("), the ")#mi("{R}")#text("-transform becomes linear and the spectral measure becomes semicircular, which is of course consistent with the free central limit theorem.")

#text("In a similar vein, if one defines the function")

#align(center)[#tao-fit-display[#mitex("\\omega(t,z) := \\alpha \\int_{\\bf R} \\frac{zx}{1-zx}\\ d\\mu_\\alpha(x) = e^{-t} (- 1 - z^{-1} s(t, z^{-1}))")]]

#text("and inverts it to obtain a function ")#mi("{z(t,\\omega)}")#text(" with")

#align(center)[#tao-fit-display[#mitex("\\omega(t, z(t,\\omega)) = \\omega")]]

#text("for all ")#mi("{t, \\omega}")#text(", then the ")#emph[#mi("{S}")#text("-transform")]#text(" ")#mi("{S(t,\\omega)}")#text(" is defined by")

#align(center)[#tao-fit-display[#mitex("S(t,\\omega) := \\frac{1+\\omega}{\\omega} z(t,\\omega).")]]

#text("Writing")

#align(center)[#tao-fit-display[#mitex("s(t,z) = - z^{-1} ( 1 + e^t \\omega(t, z^{-1}) )")]]

#text("for any ")#mi("{t}")#text(", ")#mi("{z}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("z_0 + s(0,z_0)^{-1} (1-e^{-t}) = z_0 \\frac{\\omega(0,z_0^{-1})+e^{-t}}{\\omega(0,z_0^{-1})+1}")]]

#text("and so ")#link(<tao-bb1046b429a7f917a06d>)[#text("(9)")]#text(" becomes")

#align(center)[#tao-fit-display[#mitex("- z_0^{-1} \\frac{\\omega(0,z_0^{-1})+1}{\\omega(0,z_0^{-1})+e^{-t}} (1 + e^{t} \\omega(t, z_0^{-1} \\frac{\\omega(0,z_0^{-1})+1}{\\omega(0,z_0^{-1})+e^{-t}}))")]]

#align(center)[#tao-fit-display[#mitex("= - e^t z_0^{-1} (1 + \\omega(0, z_0^{-1}))")]]

#text("which simplifies to")

#align(center)[#tao-fit-display[#mitex("\\omega(t, z_0^{-1} \\frac{\\omega(0,z_0^{-1})+1}{\\omega(0,z_0^{-1})+e^{-t}})) = \\omega(0, z_0^{-1});")]]

#text("replacing ")#mi("{z_0}")#text(" by ")#mi("{z(0,\\omega)^{-1}}")#text(" we obtain")

#align(center)[#tao-fit-display[#mitex("\\omega(t, z(0,\\omega) \\frac{\\omega+1}{\\omega+e^{-t}}) = \\omega")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("z(0,\\omega)\\frac{\\omega+1}{\\omega+e^{-t}} = z(t, \\omega)")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("S(0, \\omega) = \\frac{\\omega+e^{-t}}{\\omega+1} S(t, \\omega).")]]

#text("One can compute ")#mi("{\\frac{\\omega+e^{-t}}{\\omega+1}}")#text(" to be the ")#mi("{S}")#text("-transform of the measure ")#mi("{(1-\\alpha) \\delta_0 + \\alpha \\delta_1}")#text("; from the link between ")#mi("{S}")#text("-transforms and free products (see e.g. ")#link("http://jointmathematicsmeetings.org/meetings/national/jmm2013/amssc-Guionnet.pdf")[#text("these notes of Guionnet")]#text("), we conclude that ")#mi("{(1-\\alpha)\\delta_0 + \\alpha \\mu_\\alpha}")#text(" is the free product of ")#mi("{\\mu_1}")#text(" and ")#mi("{(1-\\alpha) \\delta_0 + \\alpha \\delta_1}")#text(". This is consistent with the random matrix theory interpretation, since ")#mi("{(1-\\alpha)\\delta_0 + \\alpha \\mu_\\alpha}")#text(" is also the spectral measure of ")#mi("{PMP}")#text(", where ")#mi("{P}")#text(" is the orthogonal projection to the span of the first ")#mi("{\\alpha n}")#text(" basis elements, so in particular ")#mi("{P}")#text(" has spectral measure ")#mi("{(1-\\alpha) \\delta_0 + \\alpha \\delta_1}")#text(". If ")#mi("{M}")#text(" is unitarily invariant then (by a ")#link("http://www.ams.org/mathscinet-getitem?mr=1094052")[#text("fundamental result of Voiculescu")]#text(") it is asymptotically freely independent of ")#mi("{P}")#text(", so the spectral measure of ")#mi("{PMP = P^{1/2} M P^{1/2}}")#text(" is asymptotically the free product of that of ")#mi("{M}")#text(" and of ")#mi("{P}")#text(".")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2017/09/16/inverting-the-schur-complement-and-large-dimensional-gelfand-tsetlin-patterns/#comment-486320")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2017")])]

#text("There’s a typo after “and then inserting this back into (1) gives”, a there should be a parenthesis around the expression multiplied by a. Also, the equation (2) is too wide and the “(2)” is not visible (for me).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad4c3e019150b140bc6294f3e40473e219b48a2efe695fd61fffd95ce371b23c-1911117f007cf12d1cf989d9df9995a20201c986ba4c70c42d080735f7970b92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergei Ofitserov")]], [#link("https://terrytao.wordpress.com/2017/09/16/inverting-the-schur-complement-and-large-dimensional-gelfand-tsetlin-patterns/#comment-486434")[#strong[#text("Sergei Ofitserov")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2017")])]

#text("Dear Terence Tao! I again participate in discussion by theme Szemeredi’s theorem(previous post). P(1),P(2),P(3)-that directions of unfolding arithmetic progressions. More exactly,P(1) and P(2)-that unfolding of arithmetic progressions by columns up and down. Upper bound-9999, lower bound-1000(that bounds of Fourier analysis). And here P(3)-that already direction of unfolding arithmetic progressions by stitchs, wear out in infinity. P(3) for theorem1.6-that line of locking in infinity(fully possibly-closed elliptical curve). 1-1/10L-that no finished first page of my book. Thanks! Sergei.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23261e56304fab72986f482f6af3f367c6c7b41f78dc27469ebe2a581262c28b-af8c3d185c4c01b8a973194133f8b4352b0300a0a4c92dddc7b8c61c2bde1ab5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JDM")]], [#link("https://terrytao.wordpress.com/2017/09/16/inverting-the-schur-complement-and-large-dimensional-gelfand-tsetlin-patterns/#comment-486662")[#strong[#text("JDM")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2017")])]

#text("Your inversion formulas also appear in Wikipedia. While everything is a “matrix”, my Representation Theory textbooks hardly write out the operators in this way. By drawing a column for each group element, as Cayley or Schur might have done. And lo and behold they were block diagonal !!")

#link("https://en.m.wikipedia.org/wiki/Invertible_matrix#Blockwise_inversion")[#text("https://en.m.wikipedia.org/wiki/Invertible_matrix#Blockwise_inversion")]

#link("https://en.m.wikipedia.org/wiki/Block_matrix")[#text("https://en.m.wikipedia.org/wiki/Block_matrix")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/09/16/inverting-the-schur-complement-and-large-dimensional-gelfand-tsetlin-patterns/#comment-486745")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2017")])]

#text("A closing bracket is missing in the equation number “(2)”.")

#emph[#text("[It’s there, but cut off by the blog. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08d760d7d31285c7d925d34ea210680fd3049bc3ff0a6fd1243e2c9d5005aeb8-253f48a58ee9b3c67cecf14847b615b257ee5ddd3de765622f1696cf1c488010.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of burakcakmakblog")]], [#link("https://terrytao.wordpress.com/2017/09/16/inverting-the-schur-complement-and-large-dimensional-gelfand-tsetlin-patterns/#comment-486842")[#strong[#text("burakcakmakblog")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2017")])]

#text("Professor, as regards the discussion below Example (8), the formula by Nica and Speicher, i.e. ")#mi("R_A(s)=R_M(\\beta s)")#text(" for ")#mi("\\beta=(n-k)/n")#text(" can be easily shown as follows: From the multiplicative free convolution we have ")#mi("S_A(z)=S_M(\\beta z)")#text(". Then, by invoking the general relationship between the R- and S- transforms which is ")#mi("R(s)S(sR(s))=1=S(z)R(zS(z))")#text(" (see [Haagerup, Larsen, 99]) we get ")#mi("R_A(s)=R_M(\\beta s)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Free fractional convolution powers | What's new")]], [#link("https://terrytao.wordpress.com/2017/09/16/inverting-the-schur-complement-and-large-dimensional-gelfand-tsetlin-patterns/#comment-587475")[#strong[#text("Free fractional convolution powers | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2020")])]

#text("[…] initial condition (see for a derivation). This equation can be solved explicitly using the emph as free probability analogues of the classical probability concepts of differential entropy and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/09/16/inverting-the-schur-complement-and-large-dimensional-gelfand-tsetlin-patterns/#comment-692623")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2026")])]

#text("I remember the techniques I learned in my linear algebra course for finding the inverse of a block matrix: such as elementary row operations, Cramer’s rule, and so forth. I find the Schur complement a bit hard to memorize — is it a more practical or useful technique in practice?")
]
