// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/
// Converted to Typst by tao2typ: "2026-10-14T11:23:05.767961+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Simons Lecture II: Structure and randomness in ergodic theory and graph theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Simons Lecture II: Structure and randomness in ergodic theory and graph theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 April 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/")[#text("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In this second lecture, I wish to talk about the dichotomy between structure and randomness as it manifests itself in four closely related areas of mathematics:")

#list(
[#emph[#text("Combinatorial number theory")]#text(", which seeks to find patterns in unstructured dense sets (or colourings) of integers;")],
[#emph[#text("Ergodic theory")]#text(" (or more specifically, multiple recurrence theory), which seeks to find patterns in positive-measure sets under the action of a discrete dynamical system on probability spaces (or more specifically, measure-preserving actions of the integers ")#mi("{\\Bbb Z}")#text(");")],
[#emph[#text("Graph theory")]#text(", or more specifically the portion of this theory concerned with finding patterns in large unstructured dense graphs; and")],
[#emph[#text("Ergodic graph theory")]#text(", which is a very new and undeveloped subject, which roughly speaking seems to be concerned with the patterns within a measure-preserving action of the infinite permutation group ")#mi("S_\\infty")#text(", which is one of several models we have available to study infinite “limits” of graphs.")]
)

#text("The two “discrete” (or “finitary”, or “quantitative”) fields of combinatorial number theory and graph theory happen to be related to each other, basically by using the Cayley graph construction; I will give an example of this shortly. The two “continuous” (or “infinitary”, or “qualitative”) fields of ergodic theory and ergodic graph theory are at present only related on the level of analogy and informal intuition, but hopefully some more systematic connections between them will appear soon.")

#text("On the other hand, we have some very rigorous connections between combinatorial number theory and ergodic theory, and also (more recently) between graph theory and ergodic graph theory, basically by the procedure of viewing the infinitary continuous setting as a limit of the finitary discrete setting. These two connections go by the names of the ")#emph[#text("Furstenberg correspondence principle")]#text(" and the ")#emph[#text("graph correspondence principle")]#text(" respectively. These principles allow one to tap the power of the infinitary world (for instance, the ability to take limits and perform completions or closures of objects) in order to establish results in the finitary world, or at least to take the ")#emph[#text("intuition")]#text(" gained in the infinitary world and transfer it to a finitary setting. Conversely, the finitary world provides an excellent model setting to refine one’s understanding of infinitary objects, for instance by establishing quantitative analogues of “soft” results obtained in an infinitary manner. I will remark here that this best-of-both-worlds approach, borrowing from both the finitary and infinitary traditions of mathematics, was absolutely necessary for Ben Green and I in order to establish our result on long arithmetic progressions in the primes. In particular, the infinitary setting is excellent for being able to rigorously define and study concepts (such as structure or randomness) which are much “fuzzier” and harder to pin down exactly in the finitary world.")

#metadata(none) <tao-15bab1986ff36a1041e4>#text("Let me first discuss the connection between combinatorial number theory and graph theory. We can illustrate this connection with two classical results from the former and latter field respectively:")

#list(
[#link("http://en.wikipedia.org/wiki/Schur's_theorem")[#text("Schur’s theorem")]#text(": If the positive integers are coloured using finitely many colours, then one can find positive integers x, y such that x, y, x+y all have the same colour.")],
[#link("http://en.wikipedia.org/wiki/Ramsey%27s_theorem")[#text("Ramsey’s theorem")]#text(": If an infinite complete graph is edge-coloured using finitely many colours, then one can find a triangle all of whose edges have the same colour.")]
)

#text("(In fact, both of these theorems can be generalised to say much stronger statements, but we will content ourselves with just these special cases). It is in fact easy to see that Schur’s theorem is deducible from Ramsey’s theorem. Indeed, given a colouring of the positive integers, one can create an infinite coloured complete graph (the ")#emph[#text("Cayley graph ")]#text("associated to that colouring) whose vertex set is the integers ")#mi("{\\Bbb Z}")#text(", and such that an edge {a,b} with a < b is coloured using the colour assigned to b-a. Applying Ramsey’s theorem, together with the elementary identity (c-a) = (b-a) + (c-b), we then quickly deduce Schur’s theorem.")

#text("Let us now turn to ergodic theory. The basic object of study here is a ")#emph[#text("measure-preserving system")]#text(" (or ")#emph[#text("probability-preserving system")]#text("), which is a probability space ")#mi("(X, {\\mathcal B}, \\mu)")#text(" (i.e. a set X equipped with a ")#link("http://en.wikipedia.org/wiki/Sigma-algebra")[#text("sigma-algebra")]#text(" ")#mi("\\mathcal B")#text(" of measurable sets and a probability measure ")#mi("\\mu")#text(" on that sigma-algebra), together with a shift map ")#mi("T: X \\to X")#text(", which for simplicity we shall take to be invertible and bi-measurable (so its inverse is also measurable); in particular we have iterated shift maps ")#mi("T^n: X \\to X")#text(" for any integer n, giving rise to an action of the integers ")#mi("{\\Bbb Z}")#text(". The important property we need is that the shift map is measure-preserving, thus ")#mi("\\mu(T(E)) = \\mu(E)")#text(" for all measurable sets E.")

#text("In the ")#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/")[#text("last lecture")]#text(" we saw that sets of integers could be divided (rather informally) into structured sets, pseudorandom sets, and hybrids between the two. The same is true in ergodic theory – and this time, one can in fact make these notions extremely precise. Let us first start with some examples:")

#list(
[#text("The ")#emph[#text("circle shift,")]#text(" in which ")#mi("X := {\\Bbb R}/{\\Bbb Z}")#text(" is the standard unit circle with normalised ")#link("http://en.wikipedia.org/wiki/Haar_measure")[#text("Haar measure")]#text(", and ")#mi("T(x) := x + \\alpha")#text(" for some fixed real number ")#mi("\\alpha")#text(". If we identify X with the unit circle in the complex plane via the standard identification ")#mi("x \\mapsto e^{2\\pi i x}")#text(", then the shift corresponds to an anti-clockwise rotation by ")#mi("\\alpha")#text(". This is a very structured system, and corresponds in combinatorial number theory to ")#emph[#text("Bohr sets")]#text(" such as ")#mi("\\{ n \\in {\\Bbb Z}: 0 < \\{ n \\alpha \\} < 0.01 \\}")#text(", which implicitly made an appearance in the previous lecture.")],
[#text("The ")#emph[#text("two-point shift")]#text(", in which X := {0,1} with uniform probability measure, and T simply interchanges 0 and 1. This very structured system corresponds to the set A of odd numbers (or of even numbers) mentioned in the previous lecture. More generally, any permutation on a finite set gives rise to a simple measure-preserving system.")],
[#text("The ")#emph[#text("skew shift")]#text(", in which ")#mi("X := ({\\Bbb R}/{\\Bbb Z})^2")#text(" is the 2-torus with normalised Haar measure, and ")#mi("T(x,y) := (x+\\alpha,y+x)")#text(" for some fixed real number ")#mi("\\alpha")#text(". If we just look at the behaviour of the x-component of this torus we see that the skew shift contains the circle shift as a ")#emph[#text("factor")]#text(", or equivalently that the skew shift is an ")#emph[#text("extension")]#text(" of the circle shift (in this particular case, since the fibres are circles and the action on the fibres is rotation, we call this a ")#emph[#text("circle extension")]#text(" of the circle shift). This system is also structured (but in a more complicated way than the previous two shifts), and corresponds to quadratically structured sets such as the ")#emph[#text("quadratic Bohr set")]#text(" ")#mi("\\{ n \\in {\\Bbb Z}: 0 < \\{ \\sqrt{2} n^2 \\} < 0.01 \\}")#text(", which made an appearance in the previous lecture.")],
[#text("The ")#emph[#text("Bernoulli shift")]#text(", in which ")#mi("X := \\{0,1\\}^{\\Bbb Z} \\equiv 2^{\\Bbb Z}")#text(" is the space of infinite 0-1 sequences (or equivalently, the space of all sets of integers), equipped with uniform product probability measure, and T is the left shift ")#mi("T (x_n)_{n \\in \\Bbb Z} := (x_{n+1})_{n \\in \\Bbb Z}")#text(". This is a very random system, corresponding to the random sets B discussed in the previous lecture.")],
[#text("Hybrid systems, e.g. products of a circle shift and a Bernoulli shift, or extensions of a circle shift by a Bernoulli system, a doubly skew shift (a circle extension of a circle extension of a circle shift), etc.")]
)

#text("One can classify these systems in precise terms according to how the shift action ")#mi("T^n")#text(" moves sets E around. On the one hand, we have some well-defined notions which represent structure:")

#list(
[#emph[#text("Trivial")]#text(" systems are such that ")#mi("T^n E = E")#text(" for all E and all n.")],
[#emph[#text("Periodic")]#text(" systems are such that for every E, there exists a positive n such that ")#mi("T^n E = E")#text(". The two-point shift is an example, as is the circle shift when ")#mi("\\alpha")#text(" is rational.")],
[#emph[#text("Almost periodic")]#text(" or ")#emph[#text("compact")]#text(" systems are such that for every E and every ")#mi("\\epsilon > 0")#text(", there exists a positive n such that ")#mi("T^n E")#text(" and ")#mi("E")#text(" differ by a set of measure at most ")#mi("\\epsilon")#text(". The circle shift is a good example of this (thanks to the ")#link("http://en.wikipedia.org/wiki/Equidistribution_theorem")[#text("equidistribution theorem")]#text("). The term “compact” is used because there is an equivalent characterisation of compact systems, namely that the orbits of the shift in ")#mi("L^2(X)")#text(" are always precompact in the strong topology.")]
)

#text("On the other hand, we have some well-defined terms which represent pseudorandomness:")

#list(
[#emph[#text("Strongly mixing")]#text(" systems are such that for every E, F, we have ")#mi("\\mu(T^n E \\cap F) \\to \\mu(E) \\mu(F)")#text(" as n tends to infinity; the Bernoulli shift is a good example. Informally, this is saying that shifted sets become asymptotically independent of unshifted sets.")],
[#emph[#text("Weakly mixing")]#text(" systems are such that for every E, F, we have ")#mi("\\mu(T^n E \\cap F) \\to \\mu(E) \\mu(F)")#text(" as n tends to infinity after excluding a set of exceptional values of n of asymptotic density zero. For technical reasons, weak mixing is a better notion to use in the structure-randomness dichotomy than strong mixing (for much the same reason that one always wants to allow negligible sets of measure zero in measure theory).")]
)

#text("There are also more complicated (but well-defined) hybrid notions of structure and randomness which we will not give here. We will however briefly discuss the situation for the skew shift. This shift is not almost periodic: most sets A will become increasingly “skewed” as it gets shifted, and will never return to resemble itself again. However, if one restricts attention to the underlying circle shift factor (i.e. restricting attention only to those sets which are unions of vertical fibres), then one recovers almost periodicity. Furthermore, the skew shift is almost periodic ")#emph[#text("relative")]#text(" to the underlying circle shift, in the sense that while the shifts ")#mi("T^n A")#text(" of a given set A do not return to resemble A globally, they do return to resemble A when restricted to any fixed vertical fibre (this can be shown using the method of ")#link("http://en.wikipedia.org/wiki/Weyl_sum")[#text("Weyl sums")]#text(" from Fourier analysis). Because of this, we say that the skew shift is a ")#emph[#text("compact extension")]#text(" of a compact system.")

#text("As discussed in the above examples, every dynamical system is capable of generating some interesting sets of integers, specifically ")#emph[#text("recurrence sets")]#text(" ")#mi("\\{ n \\in {\\Bbb Z}: T^n x_0 \\in E \\}")#text(" where E is a set in X and ")#mi("x_0")#text(" is a point in X. This set actally captures much of the dynamics of E in the system (especially if X is ")#link("http://en.wikipedia.org/wiki/Ergodic_%28adjective%29")[#text("ergodic")]#text(" and ")#mi("x_0")#text(" is “generic”). The ")#emph[#text("Furstenberg correspondence principle")]#text(" reverses this procedure, starting with a set of integers A and using that to generate a dynamical system which “models” that set in a certain way. Modulo some minor technicalities, it works as follows.")

#enum(start: 1, 
[#text("As with the Bernoulli shift, we work in the space ")#mi("X := \\{0,1\\}^{\\Bbb Z} \\equiv 2^{\\Bbb Z}")#text(", with the product sigma-algebra and the left shift; but we leave the probability measure ")#mi("\\mu")#text(" (which can be interpreted as the distribution of a certain random subset of the integers) undefined for now. The original set A can now be interpreted as a single point inside X.")],
[#text("Now pick a large number N, and shift A backwards and forwards up to N times, giving rise to 2N+1 sets ")#mi("T^{-N} A, \\ldots, T^N A")#text(", which can be thought of as 2N+1 points inside X. We consider the uniform distribution on these points, i.e. we shift A by a random amount between -N and N. This gives rise to a discrete probability measure ")#mi("\\mu_N")#text(" on X (which is only supported on 2N+1 points inside X). Each of these measures is approximately invariant under the shift T.")],
[#text("We now let N go to infinity. We apply the (sequential form of the) ")#link("http://en.wikipedia.org/wiki/Banach-Alaoglu_theorem")[#text("Banach-Alaoglu theorem")]#text(", which among other things shows that the space of Borel probability measures on a compact Hausdorff space (which X is) is sequentially compact in the weak-* topology. (This particular version of Banach-Alaoglu can in fact be established by a diagonalisation argument which completely avoids the axiom of choice.) Thus we can find a subsequence of the measures ")#mi("\\mu_N")#text(" which converge in the weak-* topology to a limit ")#mi("\\mu")#text(" (this subsequence and limit may not be unique, but this will not concern us). Since the ")#mi("\\mu_N")#text(" are approximately invariant under T, with the degree of approximation improving with N, one can easily show that the limit measure ")#mi("\\mu")#text(" is shift-invariant.")]
)

#text("By using this recipe to construct a measure-preserving system from a set of integers, it is possible to deduce theorems in combinatorial number theory from those in ergodic theory (similarly to how the Cayley graph construction allowed one to deduce theorems in combinatorial number theory from those in graph theory). The most famous example of this concerns the following two deep theorems:")

#list(
[#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("Szemerédi’s theorem")]#text(": If A is a set of integers of positive ")#link("http://en.wikipedia.org/wiki/Upper_asymptotic_density")[#text("upper density")]#text(", and k is a positive integer, then A contains infinitely many arithmetic progressions ")#mi("x, x+n, \\ldots, x+(k-1)n")#text(" of length k. (Note that the case k=2 is trivial.)")],
[#link("http://www.ams.org/mathscinet-getitem?mr=498471")[#text("Furstenberg’s recurrence theorem")]#text(": If E is a set of positive measure in a measure-preserving system, and k is a positive integer, then there are infinitely many integers n for which ")#mi("\\mu( A \\cap T^n A \\cap \\ldots \\cap T^{(k-1)n} A) > 0")#text(". (Note that the case k=2 is the more classical ")#link("http://en.wikipedia.org/wiki/Poincar%C3%A9_recurrence_theorem")[#text("Poincaré recurrence theorem")]#text(").")]
)

#text("Using the above correspondence principle (or a slight variation thereof), it is not difficult to show that the two theorems are in fact equivalent; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=603625")[#text("Furstenberg’s book on the subject")]#text(". The power of these two theorems derives from the fact that the former works for ")#emph[#text("arbitrary")]#text(" sets of positive density, and the latter works for ")#emph[#text("arbitrary")]#text(" measure-preserving systems – there are essentially no structural assumptions on the basic object of study in either, and it is therefore quite remarkable that one can still conclude such a non-trivial result.")

#text("The story of Szemerédi’s theorem is quite a long one, which I have discussed ")#link("http://www.cambridge.org/uk/catalogue/catalogue.asp?isbn=0521853869")[#text("in")]#text(" ")#link("http://front.math.ucdavis.edu/math.NT/0411246")[#text("many")]#text(" ")#link("http://front.math.ucdavis.edu/math.CO/0604456")[#text("previous")]#text(" ")#link("http://arxiv.org/abs/math.HO/0702396")[#text("places")]#text(", and will not do so again here, though I will note here that all the proofs of this theorem exploit the dichotomy between structure and randomness (and there are some good reasons for this – the underlying cause of arithmetic progressions is totally different in the structured and pseudorandom cases). I will however briefly describe how Furstenberg’s recurrence theorem is proven (following the approach of")#link("http://www.ams.org/mathscinet-getitem?mr=670131")[#text(" Furstenberg, Katznelson, and Ornstein")]#text("; there are a couple other ergodic theoretic proofs, including of course Furstenberg’s original proof). The first major step is to establish the ")#emph[#text("Furstenberg structure theorem")]#text(", which takes an arbitrary measure-preserving system and describes it as a suitable hybrid of a compact system and a weakly mixing system (or more precisely, a weakly mixing extension of a transfinite tower of compact extensions). This theorem relies on ")#link("http://en.wikipedia.org/wiki/Zorn%27s_lemma")[#text("Zorn’s lemma")]#text(", although it is possible to give a proof of the recurrence theorem without recourse to the axiom of choice. The proof requires various tools from infinitary analysis (e.g. the compactness of integral operators) but is relatively straightforward. Next, one makes the rather simple observation that the Furstenberg recurrence theorem is easy to show both for compact systems and for weakly mixing systems. In the former case, the almost periodicity shows that there are lots of integers n for which ")#mi("T^n A")#text(" is almost identical with A (in the sense that they differ by a set of small measure) – which, after shifting by n again, implies that ")#mi("T^{2n} A")#text(" is almost identical with ")#mi("T^n A")#text(", and so forth – which soon makes it easy to arrange matters so that ")#mi("A \\cap T^n A \\cap \\ldots \\cap T^{(k-1)n} A")#text(" is non-empty. In the latter case, the weak mixing shows that for most n, the sets (or “events”) ")#mi("A")#text(" and ")#mi("T^n A")#text(" are almost uncorrelated (or “independent”); similarly, for any fixed m, we have ")#mi("A \\cap T^m A")#text(" and ")#mi("T^n(A \\cap T^m A) = T^n A \\cap T^{n+m} A")#text(" almost uncorrelated for n large enough. By using the Cauchy-Schwarz inequality (in the form of a useful lemma of van der Corput) repeatedly, we can eventually show that ")#mi("A, T^n A, \\ldots, T^{(k-1)n} A")#text(" are almost ")#emph[#text("jointly")]#text(" independent (as opposed to being merely almost pairwise independent) for many n, at which point the recurrence theorem is easy to show. It is somewhat more tricky to show that one can also combine these arguments with each other to show that the recurrence property also holds for the transfinite combinations of compact and weakly mixing systems that come out of the Furstenberg structure theorem, but it can be done with a certain amount of effort, and this concludes the proof of the recurrence theorem. This same method of proof turns out, with several additional technical twists, to establish many further varieties of recurrence theorems, which in turn (via the correspondence principle) gives several powerful results in combinatorial number theory, several of which continue to have no non-ergodic proof even today.")

#text("(There has also been a significant amount of progress more recently ")#link("http://www.ams.org/mathscinet-getitem?mr=939438")[#text("by")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=1412607")[#text("several")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("ergodic")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2257397")[#text("theorists")]#text(" in understanding the “structured” side of the Furstenberg structure theorem, in which dynamical notions of structure, such as compactness, have been converted into algebraic and topological notions of structure, in particular into the actions of nilpotent Lie groups on their homogeneous spaces. This is an important development, and is closely related to the polynomial and generalised polynomial sequences appearing in the previous talk, but it would be beyond the scope of this talk to discuss it here.)")

#text("Let us now leave ergodic theory and return to graph theory. Given the power of the Furstenberg correspondence principle, it is natural to look for something similar in graph theory, which would connect up results in finitary graph theory with some infinitary variant. A typical candidate for a finitary graph theory result that one would hope to do this for is the triangle removal lemma, which was discussed in a ")#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/")[#text("recent blog post here")]#text(". That lemma is in fact closely connected with Szemerédi’s theorem, indeed it implies the k=3 case of that theorem (i.e. ")#link("http://en.wikipedia.org/wiki/Roth%27s_theorem")[#text("Roth’s theorem")]#text(") in much the same way that Ramsey’s theorem implies Schur’s theorem. It does turn out that this is possible, although the infinitary analogues of things like the triangle removal lemma are a little strange-looking (one such analogue can be found in ")#link("http://www.arxiv.org/abs/math.CO/0602037")[#text("this paper")]#text("; another can be found in ")#link("http://research.microsoft.com/users/lovasz/heredit-test.pdf")[#text("this one")]#text("). But it is easier to describe the concept of a graph limit. There are several equivalent formulations of this limit, including the notion of a “graphon” introduced ")#link("http://research.microsoft.com/users/lovasz/limits.pdf")[#text("by Lovász and Szegedy")]#text(", the flag algebra construction introduced ")#link("http://www.mi.ras.ru/~razborov/flag.pdf")[#text("by Razborov")]#text(", and the notion of a permutation-invariant measure space ")#link("http://www.arxiv.org/abs/math.CO/0602037")[#text("introduced by myself")]#text(". I will discuss my own construction here, which is closely modelled on the Furstenberg correspondence principle. What it does is starts with a sequence ")#mi("G_n")#text(" of graphs (which one should think of as getting increasingly large, while remaining dense) and extracts a limit object, which is a probability space ")#mi("(X, {\\mathcal B}, \\mu)")#text(" together with an action of the permutation group ")#mi("S_\\infty")#text(" on the integers, as follows.")

#enum(start: 1, 
[#text("We let ")#mi("X = 2^{\\binom{\\Bbb Z}{2}}")#text(" be the space of all graphs on the integers, with the standard product (i.e. weak) topology, and hence product sigma-algebra. This space has an obvious action of the permutation group ")#mi("S_\\infty")#text(", formed by permuting the vertices.")],
[#text("Each graph ")#mi("G_n")#text(" generates a random graph on the integers – or equivalently, a probability measure ")#mi("\\mu_n")#text(" in X – as follows. We randomly and independently sample the vertices of the graph ")#mi("G_n")#text(" infinitely often, creating a sequence ")#mi("(v_{n,i})_{i \\in {\\Bbb Z}}")#text(" of vertices in the graph ")#mi("G_n")#text(". (Of course, many of these vertices will collide, but this will be not be important for us.) This then creates a random graph on the integers, with any two integers i and j connected by an edge if their associated vertices ")#mi("v_{n,i}, v_{n,j}")#text(" are distinct and are connected by an edge in ")#mi("G_n")#text(". By construction, the probability measure ")#mi("\\mu_n")#text(" associated to this graph is already ")#mi("S_\\infty")#text("-invariant.")],
[#text("We then let n go to infinity, and extract a weak limit ")#mi("\\mu")#text(" just as with the Furstenberg correspondence principle.")]
)

#text("It is then possible to prove results somewhat analogous to the Furstenberg structure theorem and Furstenberg recurrence theorem in this setting, and use this to prove several results in graph theory (as well as its more complicated generalisation, ")#link("http://en.wikipedia.org/wiki/Hypergraph")[#text("hypergraph")]#text(" theory). I myself am optimistic that by transferring more ideas from traditional ergodic theory into this new setting of “ergodic graph theory”, that one could obtain a new tool for systematically establishing a number of other qualitative results in graph theory, particularly those which are traditionally reliant on the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(" (which is almost a qualitative result itself, given how poor the bounds are). This is however still a work in progress.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32d20b607dd4a46a31b50b296721fa38971f66b82bd92d1f5d175ddc5ec77357-f8e58c684383cc0d9d017fe9cb7460cd650cf256c49ebdc234eea265f863d13a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rcourant")]], [#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/#comment-328")[#strong[#text("rcourant")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2007")])]

#text("Dr. Tao, what do you think about Richard Courant as a mathematician?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32d20b607dd4a46a31b50b296721fa38971f66b82bd92d1f5d175ddc5ec77357-f8e58c684383cc0d9d017fe9cb7460cd650cf256c49ebdc234eea265f863d13a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rcourant")]], [#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/#comment-329")[#strong[#text("rcourant")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2007")])]

#text("Terry,")

#text("Do you believe that financial markets are predictable in the long run? Black and Scholes came up with the following:")

#mi("\\frac{\\partial V}{\\partial t} + \\frac{1}{2}\\omega^{2}S^{2}\\frac{\\partial^{2} V}{\\partial S^{2}} + rS\\frac{\\partial V}{\\partial S} - rV = 0")

#text("which gives the price of a derivative ")#mi("V_{t}")#text(" at a time ")#mi("t")#text(".")

#text("Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Simons Lecture III: Structure and randomness in PDE « What’s new")]], [#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/#comment-338")[#strong[#text("Simons Lecture III: Structure and randomness in PDE « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2007")])]

#text("[…] Hamiltonian PDE, such as the Schrödinger equation , which are heuristically related (via Liouville’s theorem) to measure-preserving actions of the real line (or time axis) , somewhat in analogy to how combinatorial number theory and graph theory were related to measure-preserving actions of and respectively, as discussed in the previous lecture. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/#comment-377")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2007")])]

#text("“This theorem relies on Zorn’s lemma, although it is possible to give a proof of the recurrence theorem without recourse to the axiom of choice. The proof requires various tools from infinitary analysis (e.g. the compactness of integral operators) but is relatively straightforward.”")

#text("Can you give us a link or reference?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/#comment-380")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2007")])]

#text("Dear Anonymous,")

#text("Furstenberg’s ")#link("http://www.ams.org/mathscinet-getitem?mr=498471")[#text("original 1977 paper")]#text(" proved the recurrence theorem without Zorn’s lemma, and with some effort can be made fully choice-free. The later ")#link("http://www.ams.org/mathscinet-getitem?mr=670131")[#text("proof of Furstenberg-Katznelson-Ornstein in 1982")]#text(" is perhaps more elegant, proceeding via the Furstenberg structure theorem, but that theorem of course requires transfinite induction (Zorn’s lemma) to prove.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/#comment-383")[#strong[#text("Not Even Wrong » Blog Archive » Math and Physics Roundup")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2007")]

#text("[…] the highest possible quality, see Terry Tao’s postings on his Simons lectures at MIT, here, here and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hoang")]], [#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/#comment-441")[#strong[#text("Hoang")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2007")])]

#text("Dear Professor,")

#text("“but that theorem of course requires transfinite induction (Zorn’s lemma) to prove.”")

#text("I guess transfinite induction is quite different from Zorn’s lemma. Transfinite induction works with every well-ordered set regardless of Choice (of course this is the case of every set if we assume Choice). As far as I know, the Furstenberg structure theorem makes use of transfinite induction on the ordinal numbers, which are already well-ordered regardless of Choice.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/#comment-469")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2007")])]

#text("Dear Hoang,")

#text("That’s a good point, though I do view Zorn’s lemma as a generalisation of transfinite induction, which takes place on a poset rather than a well-ordered set. Indeed, one often uses Zorn’s lemma in the following formulation: Assume that a property P holds for at least one element in a poset (base case), that the limit of every chain of elements obeying P, also obeys P (limit ordinal case), and that every non-maximal element of the poset obeying P has a larger element also obeying P (successor ordinal case). Then at least one maximal element of the poset obeys P. In this formulation the similarity to transfinite induction is quite clear.")

#text("One can prove Furstenberg’s recurrence theorem using Zorn’s lemma in the above formulation, where the poset is the poset of factors of the original system, and P is the property that Furstenberg’s recurrence theorem holds for that factor. The Furstenberg structure theorem is also proven by Zorn’s lemma, though in this case it is easier to use that lemma in its more usual formuation (to construct a maximal distal factor of a system) than to try to prove this structure theorem in an “inductive” manner.")

#text("It turns out that the tower of compact factors that shows up in the Furstenberg structure theorem has an ordinal which is at most countable (and that any such ordinal can arise in this way – a result of Foreman and Beleznay), which probably means that the structure theorem can be proven just using the axiom of countable choice, though I haven’t checked this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Simons Lecture I: Structure and randomness in Fourier analysis and number theory « What’s new")]], [#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/#comment-479")[#strong[#text("Simons Lecture I: Structure and randomness in Fourier analysis and number theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2007")])]

#text("[…] first lecture, I describe the dichotomy as it appears in Fourier analysis and in number theory. (In the second, I discuss the dichotomy in ergodic theory and graph theory, while in the third, I discuss […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Soft analysis, hard analysis, and the finite convergence principle « What’s new")]], [#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/#comment-1141")[#strong[#text("Soft analysis, hard analysis, and the finite convergence principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2007")])]

#text("[…] theorem on one hand and the Furstenberg recurrence theorem on the other, as briefly discussed in my Simons lecture on these topics. (In these contexts, the correspondence between the finitary and infinitary statements is known as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Structure and randomness in combinatorics « What’s new")]], [#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/#comment-5319")[#strong[#text("Structure and randomness in combinatorics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2007")])]

#text("[…] in October. This tutorial covers similar ground as my ICM paper (or slides), or my first two Simons lectures, but focuses more on the “nuts-and-bolts” of how structure theorems actually work to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 1: Overview « What’s new")]], [#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/#comment-23597")[#strong[#text("254A, Lecture 1: Overview « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2008")])]

#text("[…] satisfactorily. (In particular, ergodic theory is a framework in which our understanding of the dichotomy between structure and randomness is at is most […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The correspondence principle and finitary ergodic theory « What’s new")]], [#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/#comment-32333")[#strong[#text("The correspondence principle and finitary ergodic theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2008")])]

#text("[…] that it actually implies the k=3 case of Szemerédi’s theorem. (See also my previous blog posts on related topics.) It turns out that this result can be deduced from some infinitary […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A massively collaborative mathematical project « What’s new")]], [#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/#comment-35389")[#strong[#text("A massively collaborative mathematical project « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2009")])]

#text("[…] and Roth’s theorem has a combinatorial proof based on the triangle removal lemma (see e.g. my Simons lecture on the subject, or Tim Gowers’ background article for the project), it is thus natural to ask whether the […]")
]
