// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/
// Converted to Typst by tao2typ: "2026-10-14T16:39:21.058487+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The maximal length of the Erdős–Herzog–Piranian lemniscate in high degree", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The maximal length of the Erdős–Herzog–Piranian lemniscate in high degree")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 December 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/")[#text("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my preprint ")#link("https://arxiv.org/abs/2512.12455")[#text("The maximal length of the Erdős–Herzog–Piranian lemniscate in high degree")]#text(". This paper resolves (in the asymptotic regime of sufficiently high degree) an old question about the ")#link("https://en.wikipedia.org/wiki/Polynomial_lemniscate")[#text("polynomial lemniscates")]

#align(center)[#tao-fit-display[#tao-math("\\partial E_1(p) := \\{ z: \\left|p(z)\\right| = 1\\}", block: true)]]

#text("attached to monic polynomials ")#mi("{p}")#text(" of a given degree ")#mi("{n}")#text(", and specifically the question of bounding the arclength ")#mi("{\\ell(\\partial E_1(p))}")#text(" of such lemniscates. For instance, when ")#mi("{p(z)=z^n}")#text(", the lemniscate is the unit circle and the arclength is ")#mi("{2\\pi}")#text("; this in fact turns out to be the minimum possible length amongst all (connected) lemniscates, a ")#link("https://zbmath.org/0090.01601")[#text("result of Pommerenke")]#text(". However, the question of the ")#emph[#text("largest")]#text(" lemniscate length is open. The leading candidate for the extremizer is the polynomial")

#align(center)[#tao-fit-display[#mitex("p_0(z)= z^n-1")]]

#text("whose lemniscate is quite convoluted, with an arclength that can be computed asymptotically as")

#align(center)[#tao-fit-display[#mitex("\\ell(\\partial E_1(p_0)) = B(1/2,n/2) = 2n + 4 \\log 2 + O(1/n)")]]

#text("where ")#mi("{B}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Beta_function")[#text("beta function")]#text(".")

#image("../assets/9ebadea4e123bca75de5b69e9e842c3f4408f0f59d9a323b632d7f7a78b2e867-fa682428c914eae7b1912fd6375b5529cc24c6808a62aaa499fccbabfb054587.png", width: 90%)

#text("(The images here were generated using AlphaEvolve and Gemini.) A reasonably ")#link("https://zbmath.org/0088.25302")[#text("well-known conjecture of Erdős, Herzog, and Piranian")]#text(" (")#link("https://www.erdosproblems.com/114")[#text("Erdős problem 114")]#text(") asserts that this is indeed the maximizer, thus ")#mi("{\\ell(\\partial E_1(p)) \\leq \\ell(\\partial E_1(p_0))}")#text(" for all monic polynomials of degree ")#mi("{n}")#text(".")

#text("There have been several partial results towards this conjecture. For instance, Eremenko and Hayman verified the conjecture when ")#mi("{n=2}")#text(". Asympotically, bounds of the form ")#mi("{\\ell(\\partial E_1(p)) \\leq (C+o(1)) n}")#text(" had been known for various ")#mi("{C}")#text(" such as ")#mi("{\\pi}")#text(", ")#mi("{2\\pi}")#text(", or ")#mi("{4\\pi}")#text("; a significant advance was made ")#link("https://zbmath.org/1181.30002")[#text("by Fryntov and Nazarov")]#text(", who obtained the asymptotically sharp upper bound")

#align(center)[#tao-fit-display[#mitex("\\ell(\\partial E_1(p)) \\leq 2n + O(n^{7/8})")]]

#text("and also obtained the sharp conjecture ")#mi("{\\ell(\\partial E_1(p)) \\leq \\ell(\\partial E_1(p_0))}")#text(" for ")#mi("{p}")#text(" sufficiently close to ")#mi("{p_0}")#text(". In that paper, the authors comment that the ")#mi("{O(n^{7/8})}")#text(" error could be improved, but that ")#mi("{O(n^{1/2})}")#text(" seemed to be the limit of their method.")

#text("I recently explored this problem with the optimization tool ")#emph[#text("AlphaEvolve")]#text(", where I found that when I assigned this tool the task of optimizing ")#mi("{\\ell(\\partial E_1(p))}")#text(" for a given degree ")#mi("{n}")#text(", that the tool rapidly converged to choosing ")#mi("{p}")#text(" to be equal to ")#mi("{p_0}")#text(" (up to the rotation and translation symmetries of the problem). This suggested to me that the conjecture was true for all ")#mi("{n}")#text(", though of course this was far from a rigorous proof. AlphaEvolve also provided some useful visualization code for these lemniscates which I have incorporated into the paper (and this blog post), and which helped build my intuition for this problem; I view this sort of “vibe-coded visualization” as another practical use-case of present-day AI tools.")

#text("In this paper, we iteratively improve upon the Fryntov-Nazarov method to obtain the following bounds, in increasing order of strength:")

#list(
[#text("(i) ")#mi("{\\ell(\\partial E_1(p)) \\leq 2n + O(n^{1/2})}")#text(".")],
[#text("(ii) ")#mi("{\\ell(\\partial E_1(p)) \\leq 2n + O(1)}")#text(".")],
[#text("(iii) ")#mi("{\\ell(\\partial E_1(p)) \\leq 2n + 4 \\log 2 + o(1)}")#text(".")],
[#text("(iv) ")#mi("{\\ell(\\partial E_1(p)) \\leq \\ell(\\partial E_1(p_0))}")#text(" for sufficiently large ")#mi("{n}")#text(".")]
)

#text("In particular, the Erdős–Herzog–Piranian conjecture is now verified for sufficiently large ")#mi("{n}")#text(".")

#text("The proof of these bounds is somewhat circuitious and technical, with the analysis from each part of this result used as a starting point for the next one. For this blog post, I would like to focus on the main ideas of the arguments.")

#text("A key difficulty is that there are relatively few tools for ")#emph[#text("upper bounding")]#text(" the arclength of a curve; indeed, the ")#link("https://en.wikipedia.org/wiki/Coastline_paradox")[#text("coastline paradox")]#text(" already shows that curves can have infinite length even when bounded. Thus, one needs to utilize some smooth or algebraic structure on the curve to hope for good upper bounds. One possible approach is via the ")#link("https://en.wikipedia.org/wiki/Crofton_formula")[#text("Crofton formula")]#text(", using Bezout’s theorem to control the intersection of the curve with various lines. This is already good enough to get bounds of the form ")#mi("{\\ell(\\partial E_1(p)) \\leq O(n)}")#text(" (for instance by combining it with other known tools to control the diameter of the lemniscate), but it seems challenging to use this approach to get bounds close to the optimal ")#mi("{\\sim 2n}")#text(".")

#text("Instead, we follow Fryntov–Nazarov and utilize Stokes’ theorem to convert the arclength into an area integral. A typical identity used in that paper is")

#align(center)[#tao-fit-display[#tao-math("\\ell(\\partial E_1(p)) = 2 \\int_{E_1(p)} |p^{\\prime}|\\ dA - \\int_{E_1(p)} \\frac{\\left|p\\varphi\\right|}{\\varphi} \\psi\\ dA", block: true)]]

#text("where ")#mi("{dA}")#text(" is area measure, ")#mi("{\\varphi = p^{\\prime}/p}")#text(" is the log-derivative of ")#mi("{p}")#text(", ")#mi("{\\psi = p^{\\prime\\prime}/p^{\\prime}}")#text(" is the log-derivative of ")#mi("{p^{\\prime}}")#text(", and ")#mi("{E_1(p)}")#text(" is the region ")#tao-math("{\\{ \\left|p\\right| \\leq 1 \\}}", block: false)#text(". This and the triangle inequality already lets one prove bounds of the form ")#mi("{\\ell(\\partial E_1(p)) \\leq 2\\pi n + O(n^{1/2})}")#text(" by controlling ")#mi("{\\int_{E_1(p)} |\\psi|\\ dA}")#text(" using the triangle inequality, the ")#link("https://en.wikipedia.org/wiki/Hardy%E2%80%93Littlewood_inequality")[#text("Hardy-Littlewood rearrangement inequality")]#text(", and the Polya capacity inequality.")

#text("But this argument does not fully capture the oscillating nature of the phase ")#tao-math("{\\frac{\\left|\\varphi\\right|}{\\varphi}}", block: false)#text(" on one hand, and the oscillating nature of ")#mi("{E_1(p)}")#text(" on the other. Fryntov–Nazarov exploited these oscillations with some additional decompositions and integration by parts arguments. By optimizing these arguments, I was able to establish an inequality of the form ")#metadata(none) <tao-2b50aa6ff81012c3421a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\ell(\\partial E_1(p)) \\leq \\frac{1}{\\pi} \\int_{E_2(p)} |\\psi|\\ dA + O(X_1+X_2+X_3+X_4+X_5)")]]

#text(" ")#text(" where ")#tao-math("{E_2(p) = \\{ \\left|p\\right| \\leq 2\\}}", block: false)#text(" is an enlargement of ")#mi("{E_1(p)}")#text(" (that is significantly less oscillatory, as displayed in the figure below), and ")#mi("{X_1,\\dots,X_5}")#text(" are certain error terms that can be controlled by a number of standard tools (e.g., the ")#link("https://en.wikipedia.org/wiki/Area_theorem_(conformal_mapping)")[#text("Grönwall area theorem")]#text(").")

#text("One can heuristically justify ")#link(<tao-2b50aa6ff81012c3421a>)[#text("(1)")]#text(" as follows. Suppose we work in a region where the functions ")#mi("{\\psi}")#text(", ")#mi("{p}")#text(" are roughly constant: ")#mi("{\\psi(z) \\approx \\psi_0}")#text(", ")#mi("{p(z) \\approx c_0}")#text(". For simplicity let us normalize ")#mi("{\\psi_0}")#text(" to be real, and ")#mi("{c_0}")#text(" to be negative real. In order to have a non-trivial lemniscate in this region, ")#mi("{c_0}")#text(" should be close to ")#mi("{-1}")#text(". Because the unit circle ")#mi("{\\partial D(0,1)}")#text(" is tangent to the line ")#mi("{\\{ w: \\Re w = -1\\}}")#text(" at ")#mi("{-1}")#text(", the lemniscate condition ")#tao-math("{\\left|p(z)\\right|=1}", block: false)#text(" is then heuristically approximated by the condition that ")#mi("{\\Re (p(z) + 1) = 0}")#text(". On the other hand, the hypothesis ")#mi("{\\psi(z) \\approx \\psi_0}")#text(" suggests that ")#mi("{p^{\\prime}(z) \\approx A e^{\\psi_0 z}}")#text(" for some amplitude ")#mi("{z}")#text(", which heuristically integrates to ")#mi("{p(z) \\approx c_0 + \\frac{A}{\\psi_0} e^{\\psi_0 z}}")#text(". Writing ")#mi("{\\frac{A}{\\psi_0}}")#text(" in polar coordinates as ")#mi("{Re^{i\\theta}}")#text(" and ")#mi("{z}")#text(" in Cartesian coordinates as ")#mi("{x+iy}")#text(", the condition ")#mi("{\\Re(p(z)+1)=0}")#text(" can then be rearranged after some algebra as")

#align(center)[#tao-fit-display[#mitex("\\cos (\\psi_0 y + \\theta) \\approx -\\frac{1+c_0}{Re^{\\psi_0 x}}.")]]

#text("If the right-hand side is much larger than ")#mi("{1}")#text(" in magnitude, we thus expect the lemniscate to be empty in this region; but if instead the right-hand side is much less than ")#mi("{1}")#text(" in magnitude, we expect the lemniscate to behave like a periodic sequence of horizontal lines of spacing ")#mi("{\\frac{\\pi}{\\psi_0}}")#text(". This makes the main terms on both sides of ")#link(<tao-2b50aa6ff81012c3421a>)[#text("(1)")]#text(" approximately agree (per unit area).")

#text("A graphic illustration of ")#link(<tao-2b50aa6ff81012c3421a>)[#text("(1)")]#text(" (provided by Gemini) is shown below, where the dark spots correspond to small values of ")#mi("{\\psi}")#text(" that act to “repel” (and shorten) the lemniscate. (The bright spots correspond to the critical points of ")#mi("{p}")#text(", which in this case consist of six critical points at the origin and one at both of ")#mi("{+1/2}")#text(" and ")#mi("{-1/2}")#text(".)")

#image("../assets/fe3ac626a925fdb7abf64df36f4972b85c346e582e407c6b75d64fb466f7615c-f466c60e15167b0717b72d017218b1de6955d3f07bb119e3ead87b8003f53a40.png", width: 90%)

#text("By choosing parameters appropriately, one can show that ")#mi("{X_1,\\dots,X_5 = O(\\sqrt{n})}")#text(" and ")#mi("{\\frac{1}{\\pi} \\int_{E_2(p)} |\\psi|\\ dA \\leq 2n + O(1)}")#text(", yielding the first bound ")#mi("{\\ell(\\partial E_1(p)) \\leq 2n + O(n^{1/2})}")#text(". However, by a more careful inspection of the arguments, and in particular measuring the defect in the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\psi(z)\\right| = \\left|\\sum_\\zeta \\frac{1}{z-\\zeta}\\right| \\leq \\sum_\\zeta \\frac{1}{\\left|z-\\zeta\\right|},", block: true)]]

#text("where ")#mi("{\\zeta}")#text(" ranges over critical points. From some elementary geometry, one can show that the more the critical points ")#mi("{\\zeta}")#text(" are dispersed away from each other (in an ")#mi("{\\ell^1}")#text(" sense), the more one can gain over the triangle inequality here; conversely, the ")#mi("{L^1}")#text(" dispersion ")#tao-math("{\\sum_\\zeta \\left|\\zeta\\right|}", block: false)#text(" of the critical points (after normalizing so that these critical points have mean zero) can be used to improve the control on the error terms ")#mi("{X_1,\\dots,X_5}")#text(". Optimizing this strategy leads to the second bound")

#align(center)[#tao-fit-display[#mitex("\\ell(\\partial E_1(p)) \\leq 2n + O(1).")]]

#text("At this point, the only remaining cases that need to be handled are the ones with bounded dispersion: ")#tao-math("{\\sum_\\zeta \\left|\\zeta\\right| \\leq 1}", block: false)#text(". In this case, one can do some elementary manipulations of the factorization")

#align(center)[#tao-fit-display[#mitex("p^{\\prime}(z) = n \\prod_\\zeta (z-\\zeta)")]]

#text("to obtain some quite precise control on the asymptotics of ")#mi("{p(z)}")#text(" and ")#mi("{p^{\\prime}(z)}")#text("; for instance, we will be able to obtain an approximation of the form")

#align(center)[#tao-fit-display[#mitex("p(z) \\approx -1 + \\frac{z p^{\\prime}(z)}{n}")]]

#text("with high accuracy, as long as ")#mi("{z}")#text(" is not too close to the origin or to critical points. This, combined with direct arclength computations, can eventually lead to the third estimate")

#align(center)[#tao-fit-display[#mitex("\\ell(\\partial E_1(p)) \\leq 2n + 4 \\log 2 + o(1).")]]

#text("The last remaining cases to handle are those of small dispersion, ")#tao-math("{\\sum_\\zeta \\left|\\zeta\\right| = o(1)}", block: false)#text(". An extremely careful version of the previous analysis can now give an estimate of the shape")

#align(center)[#tao-fit-display[#tao-math("\\ell(\\partial E_1(p)) \\leq \\ell(\\partial E_1(p_0)) - c \\left\\|p\\right\\| + o(\\left\\|p\\right\\|)", block: true)]]

#text("for an absolute constant ")#mi("{c>0}")#text(", where ")#tao-math("{\\left\\|p\\right\\|}", block: false)#text(" is a measure of how close ")#mi("{p}")#text(" is to ")#mi("{p_0}")#text(" (it is equal to the dispersion ")#tao-math("{\\sum_\\zeta \\left|\\zeta\\right|}", block: false)#text(" plus an additional term ")#tao-math("{n \\left|1 + p(0)\\right|^{1/n}}", block: false)#text(" to deal with the constant term ")#mi("{p(0)}")#text("). This establishes the final bound (for ")#mi("{n}")#text(" large enough), and even shows that the only extremizer is ")#mi("{p_0}")#text(" (up to translation and rotation symmetry).")

#heading(level: 1)[#text("Comments (20)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/#comment-689412")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2025")])]

#text("Is there any known value for a “sufficiently large n” threshold for the conjecture⁶?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/#comment-689415")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2025")])]

#text("It is in principle explicit, but likely to be enormous with the current argument due to its complexity (there are a ton of O() type error terms, and the implied constant in each one is likely to double or worse at each step, leading to an exponentially large lower bound on n). So unfortunately I do not see this argument as directly leading to a full proof of the conjecture, but it may help inspire a more efficient approach.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/#comment-689413")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2025")])]

#text("Hi Terry,")

#text("Thanks for sharing this very interesting result! I am wondering how were the individual claims verified (cf. the Acknowledgements section of the paper)? For example, were they formally verified in some way?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/#comment-689416")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2025")])]

#text("I did not use formal verification for this paper, though I imagine many of the components of the proof could be formally verified. Though I did rely on an earlier paper of Eremenko and Hayman which utilized, among other things, the theory of quasiconformal mappings and the Riemann-Hurwitz formula, and either of these could take some significant effort to formalize (the former in particular uses a little bit of PDE). Also, to justify Stokes theorem one may need a little bit of the theory of semialgebraic sets.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/094d3a4afafc4b15d41318284c2793f669c652fa25de78d54e81ec79d56b06d1-7bd83a067de926febbd326d5fbb07a8c24c7f8180773830f5b707328a9a6bdd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boris Alexeev")]], [#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/#comment-689414")[#strong[#text("Boris Alexeev")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2025")])]

#text("Is it easy to use AlphaEvolve to optimize the quantities in Erdős Problems 509, 1038, 1039, and 1041?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/#comment-689421")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2025")])]

#text("Good questions! 509 is a “For all, there exists” problem which is currently very difficult to either prove or disprove by AlphaEvolve. We actually took a look at 1038 and 1041 already. 1038 is really a problem about probability measures rather than polynomials (one can reformulate it in terms of the empirical distribution of the zeroes); [EHP58] already observed that the infimum is less than 2, and we got AlphaEvolve to reach 1.84 using the following empirical zero distribution [(-0.8399999999999999, 0.01607282659569635), (-0.8699999999999999, 0.018668276991332278), (-0.96, 0.015722736638053406), (-1.0, 0.02786639212010361), (-0.94, 0.016135713032333365), (-0.9099999999999999, 0.018142805612153572), (1.0, 0.8305116235730803), (-0.7999999999999998, 0.026585242076298716), (-0.99, 0.013889666827470722), (-0.98, 0.016404716533477668)] (i.e., 0.016 of the zeroes lie at -0.83999, etc.), though we used a coarse discretization for this and the results are not numerically rigorous. For the supremum we rapidly reach the known example of 2 sqrt(2) which appears to be a local extremum at least; but I’ll try this again and see if we can somehow break out of this extremum.")

#text("1039 asks about an inf of a sup which again is a bit tricky to work with, though the sup (computing the inradius) is reasonably computationally tractable. It might be explorable with some effort.")

#text("For 1041 we had some fun figuring out how to provide dual certificates ruling out “paths of length less than 2”, but the AE run we eventually made here did not find any counterexamples.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/#comment-689418")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2025")])]

#text("For this paper (and Sendov), saying you ‘asymptotically resolve’ is too weak! You fully solve it for all large values. (The former would lead one to believe you got e.g. Fryntov and Nazarov’s kind of result.)")

#emph[#text("[Wording adjusted, thanks -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/#comment-689429")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2025")])]

#text("Still ambiguous for the same reason…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/#comment-689439")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2025")])]

#text("Why not just say “for sufficiently high degree”? Why say “asymptotic”?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/#comment-689419")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2025")])]

#text("“vew” should be “view”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1ced1bf58675142f83a17d6a3f85fa0ff2e0fa98c7047b7cf3bac528b407f17-c56f4399a41dca409d2aa0ecdfc63cf7c3b8ee66208f48f1d52f576a19830524.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of clevera7b173df70")]], [#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/#comment-689423")[#strong[#text("clevera7b173df70")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2025")])]

#text("Can your software be used to prove rigorously the case d=3?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/#comment-689428")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2025")])]

#text("We were looking into this! Because of the known reduction to lemniscates containing their critical points, there is only a one-parameter family of potential counterexamples up to symmetries (see Figure 3 of the paper for an example in this family). Numerically it definitely looks like ")#mi("z^3-1")#text(" is the maximum, but to prove this rigorously with numerics would require some bounds on the derivative of the lemniscate length with respect to the parameter ")#mi("a")#text(" (or at least some Holder continuity bounds), and this looked somewhat tedious (but in principle doable).")

#mi("d=4")#text(" would be significantly more challenging though, as there are now two degrees of freedom (and the topology of the potential extremizers looks a little complicated).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/#comment-689430")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2025")])]

#text("Tao…I would like your opinion on something.")

#text("As someone who wants to ideally do something great in math for its own sake, but does not possess the money/connections to get into virtually any college or specialized institution…what would you suggest I do?")

#text("I’ve already accepted that I’m going to have to start from the very bottom and go from there, beginning with pre-calculus and algebra; i.e. ~10th grade level. I’m not wishing to achieve something in this field (whether that be establishing a new field of math, solving a famous/notable unsolved problem, both, etc) for any reason, other than the common good of humanity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/#comment-689438")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2025")])]

#text("One possibility is to participate in a crowdsourced math project, a list of which can be found at ")#link("https://mathoverflow.net/questions/500720/list-of-crowdsourced-math-projects-actively-seeking-participants")[#text("https://mathoverflow.net/questions/500720/list-of-crowdsourced-math-projects-actively-seeking-participants")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/#comment-689443")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2025")])]

#text("I feel honored to be addressed by someone such as yourself, despite being one of countless individuals that could have asked you this question.")

#text("The MathOverflow thread you gave me is ")#emph[#text("exactly")]#text(" the kind of suggestion list I was looking for. I am also aware of Harmonic’s Aristotle Lean API, and your commentary regarding some of its achievements. All of this is…incredibly encouraging to me.")

#text("Genuinely, thank you.")#linebreak()#text("More people like you should exist in our world. :)")

#text("– Serrara")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/#comment-689459")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2025")])]

#text("Professor Tao,")

#text("Following the theme of computational tools aiding discovery:")

#text("I recently developed a finite-sample diagnostic called ")#strong[#text("Iterated Segment Embeddings (ISE)")]#text(". It uses diffusion maps to recover constructive “witness charts” for structures detected by inverse theorems (e.g., recovering the nilmanifold geometry from Rudin-Shapiro or irrational rotations).")

#text("Unlike Gowers norms which flag ")#emph[#text("that")]#text(" structure exists, this pipeline outputs explicit coordinate charts that allow one to visualize the underlying manifold from the raw integer sequence.")

#text("I thought this might be a useful heuristic instrument for the experimental phase of problems like the one discussed here or the Erdos/discrepancy projects.")

#strong[#text("Code/Demos:")]#text(" ")#link("https://github.com/Bayachay/ISE")[#text("https://github.com/Bayachay/ISE")]#linebreak()#strong[#text("Write-up:")]#text(" ")#link("https://zenodo.org/records/17997461")[#text("https://zenodo.org/records/17997461")]

#text("William")

#text("(No reply needed, just sharing the tool).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/#comment-689488")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2025")])]

#text("In Lemma 3.2 you write")#linebreak()#tao-math("\\ell(\\partial E_1(p_0))=\\int_{-\\pi}^{\\pi} \\left|1+e^{i\\alpha}\\right|^{-\\frac{n-1}{n}},d\\alpha = B\\!\\left(\\tfrac12,\\tfrac{1}{2n}\\right).", block: false)

#text("Using ")#tao-math("\\left|1+e^{i\\alpha}\\right| = 2\\cos(\\alpha/2)", block: false)#text(" on ")#mi("[-\\pi,\\pi]")#text(" and the standard Beta integral")#linebreak()#mi("B(p,q)=2\\int_{0}^{\\pi/2} (\\sin t)^{2p-1}(\\cos t)^{2q-1},dt,")#linebreak()#text("I instead get")#linebreak()#text(" ")#tao-math("\\int_{-\\pi}^{\\pi} \\left|1+e^{i\\alpha}\\right|^{-\\frac{n-1}{n}},d\\alpha=2^{1/n},B\\!\\left(\\tfrac12,\\tfrac{1}{2n}\\right).", block: false)

#text("Am I missing a normalization, or should there be a factor ")#mi("2^{1/n}")#text(" in (3.5)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/#comment-689506")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2025")])]

#text("That is a typo (and the formula in (1.1) is the correct one, as you observe).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/#comment-689512")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2025")])]

#text("I think you mean to add that every extremal polynomial has a connected 1-lemniscate in proposition 1.2. Because the remark 3 at the bottom of page 7 states that the polynomial (1.13) does not contradict proposition 1.2 even though its 1- lemniscate is disconnected, because it is not extremal. However proposition 1.2 as it currently is written does not exclude the possibility of extremal polynomials with disconnected lemniscates, it only states that there exists an extremal polynomial with a connected 1-lemniscate which also contains all of its critical points.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/15/the-maximal-length-of-the-erdos-herzog-piranian-lemniscate-in-high-degree/#comment-689549")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2026")])]

#text("Professor Tao, with the rapid acceleration of formalization (Lean) and AI in mathematics, do you foresee a shift where the ‘value’ of a mathematician changes? specifically, will the skill of ")#strong[#text("generating conjectures")]#text(" become significantly more valuable than the skill of ")#strong[#text("constructing proofs")]#text(", given that AI might eventually handle the tactical steps of proving?")
]
