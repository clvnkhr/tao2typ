// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/08/01/analytic-number-theory-program-at-msri-jan-may-2017/
// Converted to Typst by tao2typ: "2026-10-14T15:19:31.351106+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Analytic Number Theory program at MSRI: Jan-May 2017", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Analytic Number Theory program at MSRI: Jan-May 2017")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 August 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/08/01/analytic-number-theory-program-at-msri-jan-may-2017/")[#text("https://terrytao.wordpress.com/2015/08/01/analytic-number-theory-program-at-msri-jan-may-2017/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("http://www.mathstat.concordia.ca/faculty/cdavid/")[#text("Chantal David")]#text(",")#link("http://www.dms.umontreal.ca/~andrew/")[#text(" Andrew Granville")]#text(", ")#link("https://people.math.ethz.ch/~kowalski/")[#text("Emmanuel Kowalski")]#text(", ")#link("http://tan.epfl.ch/philippe.michel")[#text("Phillipe Michel")]#text(", ")#link("http://math.stanford.edu/~ksound/")[#text("Kannan Soundararajan")]#text(", and I are ")#link("http://www.msri.org/programs/297")[#text("running a program at MSRI in the Spring of 2017 (more precisely, from Jan 17, 2017 to May 26, 2017) in the area of analytic number theory")]#text(", with the intention to bringing together many of the leading experts in all aspects of the subject and to present recent work on the many active areas of the subject (the discussion on previous blog posts here have mostly focused on advances in the study of the distribution of the prime numbers, but there have been many other notable recent developments too, such as refinements of the circle method, a deeper understanding of the asymptotics of bounded multiplicative functions and of the “pretentious” approach to analytic number theory, more “analysis-friendly” formulations of the theorems of Deligne and others involving trace functions over fields, and new subconvexity theorems for automorphic forms, to name a few). Like any other semester MSRI program, there will be a number of workshops, seminars, and similar activities taking place while the members are in residence. I’m personally looking forward to the program, which should be occurring in the midst of a particularly productive time for the subject. Needless to say, I (and the rest of the organising committee) plan to be present for most of the program.")

#text("Applications for Postdoctoral Fellowships, Research Memberships, and Research Professorships for this program (and for other MSRI programs in this time period, namely the ")#link("http://www.msri.org/programs/300")[#text("companion program in Harmonic Analysis")]#text(" and the ")#link("http://www.msri.org/programs/278")[#text("Fall program in Geometric Group Theory")]#text(", as well as the complementary program in all other areas of mathematics) have ")#link("http://www.msri.org/web/msri/scientific/member-application")[#text("just opened up today")]#text(". Applications are open to everyone (until they close on Dec 1), but require supporting documentation, such as a CV, statement of purpose, and letters of recommendation from other mathematicians; see ")#link("http://www.msri.org/web/msri/scientific/member-application")[#text("the application page for more details")]#text(".")
