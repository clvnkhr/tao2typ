// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/09/05/a-trivial-remark-about-schemes/
// Converted to Typst by tao2typ: "2026-10-14T16:36:53.081127+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A trivial remark about schemes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A trivial remark about schemes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 September 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/09/05/a-trivial-remark-about-schemes/")[#text("https://terrytao.wordpress.com/2012/09/05/a-trivial-remark-about-schemes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("[")#emph[#text("Note: the idea for this post originated before the ")#link("http://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf")[#text("recent preprint of Mochizuki on the abc conjecture")]#text(" was released, and is not intended as a commentary on that work, which offers a much more non-trivial perspective on scheme theory. -T.")]#text("]")

#text("In classical algebraic geometry, the central object of study is an ")#link("http://en.wikipedia.org/wiki/Algebraic_variety")[#text("algebraic variety")]#text(" ")#mi("{V}")#text(" over a field ")#mi("{k}")#text(" (and the theory works best when this field ")#mi("{k}")#text(" is algebraically closed). One can talk about either affine or projective varieties; for sake of discussion, let us restrict attention to affine varieties. Such varieties can be viewed in at least four different ways:")

#list(
[#text("(Algebraic geometry) One can view a variety through the set ")#mi("{V(k)}")#text(" of points (over ")#mi("{k}")#text(") in that variety.")],
[#text("(Commutative algebra) One can view a variety through the field of rational functions ")#mi("{k(V)}")#text(" on that variety, or the subring ")#mi("{k[V]}")#text(" of polynomial functions in that field.")],
[#text("(Dual algebraic geometry) One can view a variety through a collection of polynomials ")#mi("{P_1,\\ldots,P_m}")#text(" that cut out that variety.")],
[#text("(Dual commutative algebra) One can view a variety through the ideal ")#mi("{I(V)}")#text(" of polynomials that vanish on that variety.")]
)

#text("For instance, the unit circle over the reals can be thought of in each of these four different ways:")

#list(
[#text("(Algebraic geometry) The set of points ")#mi("{\\{ (x,y) \\in {\\bf R}^2: x^2+y^2 = 1 \\}}")#text(".")],
[#text("(Commutative algebra) The quotient ")#mi("{{\\bf R}[x,y] / (x^2+y^2-1)}")#text(" of the polynomial ring ")#mi("{{\\bf R}[x,y]}")#text(" by the ideal generated by ")#mi("{x^2+y^2-1}")#text(" (or equivalently, the algebra generated by ")#mi("{x,y}")#text(" subject to the constraint ")#mi("{x^2+y^2=1}")#text("), or the fraction field of that quotient.")],
[#text("(Dual algebraic geometry) The polynomial ")#mi("{x^2+y^2-1}")#text(".")],
[#text("(Dual commutative algebra) The ideal ")#mi("{(x^2+y^2-1)}")#text(" generated by ")#mi("{x^2+y^2-1}")#text(".")]
)

#text("The four viewpoints are ")#emph[#text("almost")]#text(" equivalent to each other (particularly if the underlying field ")#mi("{k}")#text(" is algebraically closed), as there are obvious ways to pass from one viewpoint to another. For instance, starting with the set of points on a variety, one can form the space of rational functions on that variety, or the ideal of polynomials that vanish on that variety. Given a set of polynomials, one can cut out their zero locus, or form the ideal that they generate. Given an ideal in a polynomial ring, one can quotient out the ring by the ideal and then form the fraction field. Finally, given the ring of polynomials on a variety, one can form its ")#link("http://en.wikipedia.org/wiki/Spectrum_of_a_ring")[#text("spectrum")]#text(" (the space of prime ideals in the ring) to recover the set of points on that variety (together with the ")#link("http://en.wikipedia.org/wiki/Zariski_topology")[#text("Zariski topology")]#text(" on that variety).")

#text("Because of the connections between these viewpoints, there are extensive “dictionaries” (most notably the ")#emph[#text("ideal-variety dictionary")]#text(") that convert basic concepts in one of these four perspectives into any of the other three. For instance, passing from a variety to a subvariety shrinks the set of points and the function field, but enlarges the set of polynomials needed to cut out the variety, as well as the associated ideal. Taking the intersection or union of two varieties corresponds to adding or multiplying together the two ideals respectively. The ")#link("http://en.wikipedia.org/wiki/Dimension_of_an_algebraic_variety")[#text("dimension of an (irreducible) algebraic variety")]#text(" can be defined as the ")#link("http://en.wikipedia.org/wiki/Transcendence_degree")[#text("transcendence degree")]#text(" of the function field, the maximal length of chains of subvarieties, or the ")#link("http://en.wikipedia.org/wiki/Krull_dimension")[#text("Krull dimension")]#text(" of the ring of polynomials. And so on and so forth. Thanks to these dictionaries, it is now commonplace to think of commutative algebras geometrically, or conversely to approach algebraic geometry from the perspective of abstract algebra. There are however some very well known defects to these dictionaries, at least when viewed in the classical setting of algebraic varieties. The main one is that two different ideals (or two inequivalent sets of polynomials) can cut out the same set of points, particularly if the underlying field ")#mi("{k}")#text(" is not algebraically closed. For instance, if the underlying field is the real line ")#mi("{{\\bf R}}")#text(", then the polynomial equations ")#mi("{x^2+1=0}")#text(" and ")#mi("{1=0}")#text(" cut out the same set of points, namely the empty set, but the ideal generated by ")#mi("{x^2+1}")#text(" in ")#mi("{{\\bf R}[x]}")#text(" is certainly different from the ideal generated by ")#mi("{1}")#text(". This particular example does not work in an algebraically closed field such as ")#mi("{{\\bf C}}")#text(", but in that case the polynomial equations ")#mi("{x^2=0}")#text(" and ")#mi("{x=0}")#text(" also cut out the same set of points (namely the origin), but again ")#mi("{x^2}")#text(" and ")#mi("{x}")#text(" generate different ideals in ")#mi("{{\\bf C}[x]}")#text(". Thanks to ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_Nullstellensatz")[#text("Hilbert’s nullstellensatz")]#text(", we can get around this problem (in the case when ")#mi("{k}")#text(" is algebraically closed) by always passing from an ideal to its ")#link("http://en.wikipedia.org/wiki/Radical_of_an_ideal")[#text("radical")]#text(", but this causes many aspects of the theory of algebraic varieties to become more complicated when the varieties involved develop singularities or multiplicities, as can already be seen with the simple example of ")#link("http://en.wikipedia.org/wiki/B%C3%A9zout%27s_theorem")[#text("Bezout’s theorem")]#text(".")

#text("Nowadays, the standard way to deal with these issues is to replace the notion of an algebraic variety with the more general notion of a ")#link("http://en.wikipedia.org/wiki/Scheme_(mathematics)")[#text("scheme")]#text(". Roughly speaking, the way schemes are defined is to focus on the commutative algebra perspective as the primary one, and to allow the base field ")#mi("{k}")#text(" to be not algebraically closed, or even to just be a commutative ring instead of a field. (One could even consider non-commutative rings, leading to ")#link("http://en.wikipedia.org/wiki/Non-commutative_geometry")[#text("non-commutative geometry")]#text(", but we will not discuss this extension of scheme theory further here.) Once one generalises to these more abstract rings, the notion of a rational function becomes more complicated (one has to work locally instead of globally, cutting out the points where the function becomes singular), but as a first approximation one can think of a scheme as basically being the same concept as a commutative ring. (In actuality, due to the need to localise, a scheme is defined as a ")#link("http://en.wikipedia.org/wiki/Sheaf_(mathematics)")[#text("sheaf")]#text(" of rings rather than a single ring, but these technicalities will not be important for the purposes of this discussion.) All the other concepts from algebraic geometry that might previously have been defined using one of the other three perspectives, are then redefined in terms of this ring (or sheaf of rings) in order to generalise them to schemes.")

#text("Thus, for instance, in scheme theory the rings ")#mi("{{\\bf R}[x]/(x^2)}")#text(" and ")#mi("{{\\bf R}[x]/(x)}")#text(" describe different schemes; from the classical perspective, they cut out the same locus, namely the point ")#mi("{\\{0\\}}")#text(", but the former scheme makes this point “fatter” than the latter scheme, giving it a degree (or multiplicity) of ")#mi("{2}")#text(" rather than ")#mi("{1}")#text(".")

#text("Because of this, it seems that the link between the commutative algebra perspective and the algebraic geometry perspective is still not quite perfect in scheme theory, unless one is willing to start “fattening” various varieties to correctly model multiplicity or singularity. But – and this is the trivial remark I wanted to make in this blog post – one can recover a tight connection between the two perspectives as long as one allows the freedom to arbitrarily extend the underlying base ring.")

#text("Here’s what I mean by this. Consider classical algebraic geometry over some commutative ring ")#mi("{R}")#text(" (not necessarily a field). Any set of polynomials ")#mi("{P_1,\\ldots,P_m \\in R[x_1,\\ldots,x_d]}")#text(" in ")#mi("{d}")#text(" indeterminate variables ")#mi("{x_1,\\ldots,x_d}")#text(" with coefficients in ")#mi("{R}")#text(" determines, on the one hand, an ideal")

#tao-aligned(keep: true)[


#tao-math("I  & := (P_1,\\ldots,P_m)", block: true)



#tao-math(" & = \\{P_1Q_1+\\ldots+P_mQ_m: Q_1,\\ldots,Q_m \\in R[x_1,\\ldots,x_d]\\}", block: true)
]

#text("in ")#mi("{R[x_1,\\ldots,x_d]}")#text(", and also cuts out a zero locus")

#align(center)[#tao-fit-display[#mitex("V[R] := \\{ (y_1,\\ldots,y_d) \\in R^d: P_1(y_1,\\ldots,y_d) = \\ldots = P_m(y_1,\\ldots,y_d) = 0 \\},")]]

#text("since each of the polynomials ")#mi("{P_1,\\ldots,P_m}")#text(" clearly make sense as maps from ")#mi("{R^d}")#text(" to ")#mi("{R}")#text(". Of course, one can also write ")#mi("{V[R]}")#text(" in terms of ")#mi("{I}")#text(":")

#align(center)[#tao-fit-display[#mitex("V[R] := \\{ (y_1,\\ldots,y_d) \\in R^d: P(y_1,\\ldots,y_d) = 0 \\text{ for all } P \\in I \\}.")]]

#text("Thus the ideal ")#mi("{I}")#text(" uniquely determines the zero locus ")#mi("{V[R]}")#text(", and we will emphasise this by writing ")#mi("{V[R]}")#text(" as ")#mi("{V_I[R]}")#text(". As the previous counterexamples illustrate, the converse is not true. However, whenever we have any extension ")#mi("{R^{\\prime}}")#text(" of the ring ")#mi("{R}")#text(" (i.e. a commutative ring ")#mi("{R^{\\prime}}")#text(" that contains ")#mi("{R}")#text(" as a subring), then we can also view the polynomials ")#mi("{P_1,\\ldots,P_m}")#text(" as maps from ")#mi("{(R^{\\prime})^d}")#text(" to ")#mi("{R^{\\prime}}")#text(", and so one can also define the zero locus for all the extensions:")

#tao-aligned(keep: true)[


#tao-math("V[R^{\\prime}]  & := \\{ (y_1,\\ldots,y_d) \\in (R^{\\prime})^d:", block: true)



#tao-math("P_1(y_1,\\ldots,y_d)  & = \\ldots = P_m(y_1,\\ldots,y_d) = 0 \\}.", block: true)
]

#text("As before, ")#mi("{V[R^{\\prime}]}")#text(" is determined by the ideal ")#mi("{I}")#text(":")

#tao-aligned(keep: true)[


#tao-math("V[R^{\\prime}]  & = V_I[R^{\\prime}] := \\{ (y_1,\\ldots,y_d) \\in (R^{\\prime})^d:", block: true)



#tao-math("P(y_1,\\ldots,y_d)  & = 0 \\text{ for all } P \\in I \\}.", block: true)
]

#text("The trivial remark is then that while a single zero locus ")#mi("{V_I[R]}")#text(" is insufficient to recover ")#mi("{I}")#text(", the collection of zero loci ")#mi("{V_I[R^{\\prime}]}")#text(" for ")#emph[#text("all")]#text(" extensions ")#mi("{R^{\\prime}}")#text(" of ")#mi("{R}")#text(" (or more precisely, the assignment map ")#mi("{R^{\\prime} \\mapsto V_I[R^{\\prime}]}")#text(", known as the ")#emph[#text("functor of points")]#text(" of ")#mi("{V_I}")#text(") is sufficient to recover ")#mi("{I}")#text(", as long as at least one zero locus, say ")#mi("{V_I[R_0]}")#text(", is non-empty. Indeed, suppose we have two ideals ")#mi("{I, I^{\\prime}}")#text(" of ")#mi("{R[x_1,\\ldots,x_d]}")#text(" that cut out the same non-empty zero locus for all extensions ")#mi("{R^{\\prime}}")#text(" of ")#mi("{R}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("V_I[R^{\\prime}] = V_{I^{\\prime}}[R^{\\prime}] \\neq \\emptyset")]]

#text("for all extensions ")#mi("{R^{\\prime}}")#text(" of ")#mi("{R}")#text(". We apply this with the extension ")#mi("{R^{\\prime}}")#text(" of ")#mi("{R}")#text(" given by ")#mi("{R^{\\prime} := R_0[x_1,\\ldots,x_d]/I}")#text(". Note that the embedding of ")#mi("{R}")#text(" in ")#mi("{R_0[x_1,\\ldots,x_d]/I}")#text(" is injective, since otherwise ")#mi("{I}")#text(" would cut out the empty set as the zero locus over ")#mi("{R_0}")#text(", and so ")#mi("{R^{\\prime}}")#text(" is indeed an extension of ")#mi("{R}")#text(". Tautologically, the point ")#mi("{(x_1 \\text{ mod } I, \\ldots, x_d \\text{ mod } I)}")#text(" lies in ")#mi("{V_I[R^{\\prime}]}")#text(", and thus necessarily lies in ")#mi("{V_{I^{\\prime}}[R^{\\prime}]}")#text(" as well. Unpacking what this means, we conclude that ")#mi("{P \\in I}")#text(" whenever ")#mi("{P \\in I^{\\prime}}")#text(", that is to say that ")#mi("{I^{\\prime} \\subset I}")#text(". By a symmetric argument, we also have ")#mi("{I \\subset I^{\\prime}}")#text(", and thus ")#mi("{I=I^{\\prime}}")#text(" as claimed. (As pointed out in comments, this fact (and its proof) is essentially a special case of the ")#link("http://en.wikipedia.org/wiki/Yoneda_lemma")[#text("Yoneda lemma")]#text(". The connection is tighter if one allows ")#mi("{R^{\\prime}}")#text(" to be any ring with a (not necessarily injective) map from ")#mi("{R}")#text(" into it, rather than an extension of ")#mi("{R}")#text(", in which case one can also drop the hypothesis that ")#mi("{V_I[R_0]}")#text(" is non-empty for at least one ")#mi("{R_0}")#text(". For instance, ")#mi("{V_{(2)}[R^{\\prime}] = V_{(3)}[R^{\\prime}] = \\emptyset}")#text(" for every extension ")#mi("{R^{\\prime}}")#text(" of the integers, but if one also allows quotients such as ")#mi("{{\\bf Z}/(2)}")#text(" or ")#mi("{{\\bf Z}/(3)}")#text(" instead, then ")#mi("{V_{(2)}[R^{\\prime}]}")#text(" and ")#mi("{V_{(3)}[R^{\\prime}]}")#text(" are no longer necessarily equal.)")

#text("Thus, as long as one thinks of a variety or scheme as cutting out points not just in the original base ring or field, but in all extensions of that base ring or field, one recovers an exact correspondence between the algebraic geometry perspective and the commutative algebra perspective. This is similar to the classical algebraic geometry position of viewing an algebraic variety as being defined simultaneously over all fields that contain the coefficients of the defining polynomials, but the crucial difference between scheme theory and classical algebraic geometry is that one also allows definition over commutative rings, and not just fields. In particular, one needs to allow extensions to rings that may contain nilpotent elements, otherwise one cannot distinguish an ideal from its radical.")

#text("There are of course many ways to extend a field into a ring, but as an analyst, one way to do so that appeals particularly to me is to introduce an epsilon parameter and work modulo errors of ")#mi("{O(\\varepsilon)}")#text(". To formalise this algebraically, let’s say for sake of concreteness that the base field is the real line ")#mi("{{\\bf R}}")#text(". Consider the ring ")#mi("{\\tilde R}")#text(" of real-valued quantities ")#mi("{x = x_\\varepsilon}")#text(" that depend on a parameter ")#mi("{\\varepsilon \\geq 0}")#text(" (i.e. functions from ")#mi("{{\\bf R}^+}")#text(" to ")#mi("{{\\bf R}}")#text("), which are ")#emph[#text("locally bounded")]#text(" in the sense that ")#mi("{x}")#text(" is bounded whenever ")#mi("{\\varepsilon}")#text(" is bounded. (One can, if one wishes, impose some further continuity or smoothness hypotheses on how ")#mi("{x}")#text(" depends on ")#mi("{\\varepsilon}")#text(", but this turns out not to be relevant for the following discussion. Algebraists often prefer to use the ring of ")#link("http://en.wikipedia.org/wiki/Puiseux_series")[#text("Puiseux series")]#text(" here in place of ")#mi("{\\tilde R}")#text(", and a nonstandard analyst might instead use the ")#link("http://en.wikipedia.org/wiki/Hyperreal_number")[#text("hyperreals")]#text(", but again this will not make too much difference for our purposes.) Inside this commutative ring, we can form the ideal ")#mi("{I}")#text(" of quantities ")#mi("{x = x_\\varepsilon}")#text(" that are of size ")#mi("{O(\\varepsilon)}")#text(" as ")#mi("{\\varepsilon \\rightarrow 0}")#text(", i.e. there exists a quantity ")#mi("{C>0}")#text(" independent of ")#mi("{\\varepsilon}")#text(" such that ")#tao-math("{\\left|x\\right| \\leq C\\varepsilon}", block: false)#text(" for all sufficiently small ")#mi("{\\varepsilon}")#text(". This can easily be seen to indeed be an ideal in ")#mi("{\\tilde R}")#text(". We then form the quotient ring ")#mi("{R^{\\prime} := \\tilde R/I := \\{ x \\text{ mod } I: x \\in \\tilde R \\}}")#text(". Note that ")#mi("{x = y \\text{ mod } I}")#text(" is equivalent to the assertion that ")#mi("{x = y + O(\\varepsilon)}")#text(", so we are encoding the analyst’s notion of “equal up to errors of ")#mi("{O(\\varepsilon)}")#text("” into algebraic terms.")

#text("Clearly, ")#mi("{R^{\\prime}}")#text(" is a commutative ring extending ")#mi("{{\\bf R}}")#text(". Hence, any algebraic variety")

#align(center)[#tao-fit-display[#mitex("V[{\\bf R}] = \\{ (y_1,\\ldots,y_d) \\in {\\bf R}^d: P_1(y_1,\\ldots,y_d) = \\ldots = P_m(y_1,\\ldots,y_d) = 0 \\}")]]

#text("defined over the reals ")#mi("{{\\bf R}}")#text(" (so the polynomials ")#mi("{P_1,\\ldots,P_m}")#text(" have coefficients in ")#mi("{{\\bf R}}")#text("), also is defined over ")#mi("{R^{\\prime}}")#text(":")

#tao-aligned(keep: true)[


#tao-math("V[R^{\\prime}]  & = \\{ (y_1,\\ldots,y_d) \\in (R^{\\prime})^d:", block: true)



#tao-math("P_1(y_1,\\ldots,y_d)  & = \\ldots = P_m(y_1,\\ldots,y_d) = 0 \\}.", block: true)
]

#text("In language that more closely resembles analysis, we have")

#align(center)[#tao-fit-display[#mitex("V[R^{\\prime}] = \\{ (y_1,\\ldots,y_d) \\in \\tilde R^d: P_1(y_1,\\ldots,y_d), \\ldots, P_m(y_1,\\ldots,y_d) = O(\\varepsilon) \\}")]]

#align(center)[#tao-fit-display[#mitex("\\text{ mod } I^d.")]]

#text("Thus we see that ")#mi("{V[R^{\\prime}]}")#text(" is in some sense an “")#mi("{\\varepsilon}")#text("-thickening” of ")#mi("{V[{\\bf R}]}")#text(", and is thus one way to give rigorous meaning to the intuition that schemes can “thicken” varieties. For instance, the scheme associated to the ideal ")#mi("{(x)}")#text(", when interpreted over ")#mi("{R^{\\prime}}")#text(", becomes an ")#mi("{O(\\varepsilon)}")#text(" neighbourhood of the origin")

#align(center)[#tao-fit-display[#mitex("V_{(x)}[R^{\\prime}] = \\{ y \\in \\tilde R: y = O(\\varepsilon) \\} \\text{ mod } I,")]]

#text("but the scheme associated to the smaller ideal ")#mi("{(x^2)}")#text(", when interpreted over ")#mi("{R^{\\prime}}")#text(", becomes an ")#mi("{O(\\varepsilon^{1/2})}")#text("-neighbourhood of the origin, thus being a much “fatter” point:")

#tao-aligned(keep: true)[


#tao-math("V_{(x^2)}[R^{\\prime}]  & = \\{ y \\in \\tilde R: y^2 = O(\\varepsilon) \\} \\text{ mod } I", block: true)



#tao-math(" & = \\{ y \\in \\tilde R: y = O(\\varepsilon^{1/2} ) \\} \\text{ mod } I.", block: true)
]

#text("Once one introduces the analyst’s epsilon, one can see quite clearly that ")#mi("{V_{(x^2)}[R^{\\prime}]}")#text(" is coming from a larger scheme than ")#mi("{V_{(x)}[R^{\\prime}]}")#text(", with fewer polynomials vanishing on it; in particular, the polynomial ")#mi("{x}")#text(" vanishes to order ")#mi("{O(\\varepsilon)}")#text(" on ")#mi("{V_{(x)}[R^{\\prime}]}")#text(" but does not vanish to order ")#mi("{O(\\varepsilon)}")#text(" on ")#mi("{V_{(x^2)}[R^{\\prime}]}")#text(".")

#text("By working with this analyst’s extension of ")#mi("{{\\bf R}}")#text(", one can already get a reasonably good first approximation of what schemes over ")#mi("{{\\bf R}}")#text(" look like, which I found particularly helpful for getting some intuition on these objects. However, since this is only one extension of ")#mi("{{\\bf R}}")#text(", and not a “universal” such extension, it cannot quite distinguish any two schemes from each other, although it does a better job of this than classical algebraic geometry. For instance, consider the scheme cut out by the polynomials ")#mi("{x^2, y^2}")#text(" in two dimensions. Over ")#mi("{R^{\\prime}}")#text(", this becomes")

#tao-aligned(keep: true)[


#tao-math("V_{(x^2,y^2)}[R^{\\prime}]  & = \\{ (x,y) \\in \\tilde R^2: x^2, y^2 = O(\\varepsilon) \\} \\text{ mod } I^2", block: true)



#tao-math(" & = \\{ (x,y) \\in \\tilde R^2: x, y = O(\\varepsilon^{1/2}) \\} \\text{ mod } I^2.", block: true)
]

#text("Note that the polynomial ")#mi("{xy}")#text(" vanishes to order ")#mi("{O(\\varepsilon)}")#text(" on this locus, but ")#mi("{xy}")#text(" fails to lie in the ideal ")#mi("{(x^2,y^2)}")#text(". Equivalently, we have ")#mi("{V_{(x^2,y^2)}[R^{\\prime}] = V_{(x^2,y^2,xy)}[R^{\\prime}]}")#text(", despite ")#mi("{(x^2,y^2)}")#text(" and ")#mi("{(x^2,y^2,xy)}")#text(" being distinct ideals. Basically, the analogue of the nullstellensatz for ")#mi("{R^{\\prime}}")#text(" does not completely remove the need for performing a closure operation on the ideal ")#mi("{I}")#text("; it is less severe than taking the radical, but is instead more like taking a “convex hull” in that one needs to be able to “interpolate” between two polynomials in the ideal (such as ")#mi("{x^2}")#text(" and ")#mi("{y^2}")#text(" to arrive at intermediate polynomials (such as ")#mi("{xy}")#text(") that one then places in the ideal.")

#text("One can also view ideals (and hence, schemes), from a model-theoretic perspective. Let ")#mi("{I}")#text(" be an ideal of a polynomial ring ")#mi("{R[x_1,\\ldots,x_d]}")#text(" generated by some polynomials ")#mi("{P_1,\\ldots,P_m \\in R[x_1,\\ldots,x_d]}")#text(". Then, clearly, if ")#mi("{Q}")#text(" is another polynomial in the ideal ")#mi("{I}")#text(", then we can use the axioms of commutative algebra (which are basically the axioms of high school algebra) to obtain the syntactic deduction")

#align(center)[#tao-fit-display[#mitex("P_1(x_1,\\ldots,x_d) = \\ldots = P_m(x_1,\\ldots,x_d) = 0 \\vdash Q(x_1,\\ldots,x_d) = 0")]]

#text("(since ")#mi("{Q}")#text(" is just a sum of multiples of ")#mi("{P_1,\\ldots,P_m}")#text("). In particular, we have the semantic deduction ")#metadata(none) <tao-320107cae2265c2d5ee8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("P_1(y_1,\\ldots,y_d) = \\ldots = P_m(y_1,\\ldots,y_d) = 0 \\implies Q(y_1,\\ldots,y_d) = 0")]]

#text("for any assignment of indeterminates ")#mi("{y_1,\\ldots,y_d}")#text(" in ")#mi("{R}")#text(" (or in any extension ")#mi("{R^{\\prime}}")#text(" of ")#mi("{R}")#text("). If we restrict ")#mi("{y_1,\\ldots,y_d}")#text(" to lie in ")#mi("{R}")#text(" only, then (even if ")#mi("{R}")#text(" is an algebraically closed field), the converse of the above statement is false; there can exist polynomials ")#mi("{Q}")#text(" outside of ")#mi("{I}")#text(" for which ")#link(<tao-320107cae2265c2d5ee8>)[#text("(1)")]#text(" holds for all assignments ")#mi("{y_1,\\ldots,y_d}")#text(" in ")#mi("{R}")#text(". For instance, we have")

#align(center)[#tao-fit-display[#mitex("y^2 = 0 \\implies y = 0")]]

#text("for all ")#mi("{y}")#text(" in an algebraically closed field, despite ")#mi("{x}")#text(" not lying in the ideal ")#mi("{(x^2)}")#text(". Of course, the nullstellensatz again explains what is going on here; ")#link(<tao-320107cae2265c2d5ee8>)[#text("(1)")]#text(" holds whenever ")#mi("{Q}")#text(" lies in the radical of ")#mi("{I}")#text(", which can be larger than ")#mi("{I}")#text(" itself. But if one allows the indeterminates ")#mi("{y_1,\\ldots,y_d}")#text(" to take values in arbitrary extensions ")#mi("{R^{\\prime}}")#text(" of ")#mi("{R}")#text(", then the truth of the converse is restored, thus giving a “completeness theorem” relating the syntactic deductions of commutative algebra to the semantic interpretations of such algebras over the extensions ")#mi("{R^{\\prime}}")#text(". For instance, since")

#align(center)[#tao-fit-display[#mitex("y^2 = O(\\varepsilon) \\not \\implies y = O(\\varepsilon)")]]

#text("we no longer have a counterexample to the converse coming from ")#mi("{x}")#text(" and ")#mi("{(x^2)}")#text(" once we work in ")#mi("{R^{\\prime}}")#text(" instead of ")#mi("{{\\bf R}}")#text(". On the other hand, we still have")

#align(center)[#tao-fit-display[#mitex("x^2, y^2 = O(\\varepsilon) \\implies xy = O(\\varepsilon)")]]

#text("so the extension ")#mi("{R^{\\prime}}")#text(" is not powerful enough to detect that ")#mi("{xy}")#text(" does not actually lie in ")#mi("{(x^2,y^2)}")#text("; a larger ring (which is less easy to assign an analytic interpretation to) is needed to achieve this.")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2012/09/05/a-trivial-remark-about-schemes/#comment-167369")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2012")])]

#text("Yes, this is essentially Grothendieck’s functor of points perspective on algebraic geometry (where one thinks of a commutative ring ")#mi("S")#text(" in terms of the functor ")#mi("\\text{Hom}(S, -)")#text(" it represents on the category of commutative rings). In general this is an application of the Yoneda lemma, but in the particular case of schemes it really does tie in quite closely to the most naive perspective on algebraic geometry as being about zero sets of polynomials, and arguably does this better than the standard description of schemes as locally ringed spaces.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/09/05/a-trivial-remark-about-schemes/#comment-167443")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2012")])]

#text("Thanks for pointing this out! I’ve made some adjustments to the post accordingly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7fd533e2278b2b7b9769ea87b02d1f14d33d1b29b97fe9963de06369ed4671c0-81f09d61f384d3bdb882b54647f5864be3b5321022c0805cbd51f74984821a68.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ot")]], [#link("https://terrytao.wordpress.com/2012/09/05/a-trivial-remark-about-schemes/#comment-167496")[#strong[#text("Ot")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2012")])]

#text("This post is absolutely awesome! It clarified in 20 minutes one graduate course of algebraic geometry. Thank you very much! Can I translate into Spanish?")

#emph[#text("[Sure – see the last section of ")#link("https://terrytao.wordpress.com/about/")[#text("https://terrytao.wordpress.com/about/")]#text(" – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ede325661861aae8415c318da25ecca4e4a9d880ac46c7a202d0ef0dbd5d30f5-4386b210f6455153aed2810900c960a4e787656cdd09582d7f8b29880ccb1554.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 動中の静 / dō chū no sei")]], [#link("https://terrytao.wordpress.com/2012/09/05/a-trivial-remark-about-schemes/#comment-167507")[#strong[#text("動中の静 / dō chū no sei")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2012")])]

#text("[…] a quick post to heartily recommend Terence Tao’s latest blog post, “A trivial remark about schemes”. My mathematical intuition has always been strongest in analysis; algebra and geometry have always […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a34de3cadf72ccac6610285e12c3bcebfccb65bbfbc1dbf4a0a4e1418f0dfae9-ff08d1e6595501802fa250f8098ab7d7e733ad521cc83d71559bc3462cc6ab4f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vít Tuček")]], [#link("https://terrytao.wordpress.com/2012/09/05/a-trivial-remark-about-schemes/#comment-167542")[#strong[#text("Vít Tuček")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2012")])]

#text("Thank you for a very nice explanation! It is so refreshing to read about the actual underlying ideas of some widely used notion, instead of a mere definition and examples that explains nothing.")

#text("What I think this wonderful post is missing though is a small remark, that one can indeed prove Hilbert’s Nullstellensatz using model theory (if my memory serves me well).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ac0f91483a48a9d93b1977df48bcd89d159e740253d523c87dcbd59fa832ee4-980fe49509e6b765c38f74227c18b5d6baa480d0f2c06444f6d190a0f7bdefc3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A trivial remark about schemes « Guzman's Mathematics Weblog")]], [#link("https://terrytao.wordpress.com/2012/09/05/a-trivial-remark-about-schemes/#comment-167613")[#strong[#text("A trivial remark about schemes « Guzman's Mathematics Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2012")])]

#text("[…] A trivial remark about schemes. Share this:FacebookTwitterRedditStumbleUponTumblrDiggLinkedInPinterestEmailPrintLike this:LikeBe the first to like this. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trying to understand the Galois correspondence | What's new")]], [#link("https://terrytao.wordpress.com/2012/09/05/a-trivial-remark-about-schemes/#comment-504381")[#strong[#text("Trying to understand the Galois correspondence | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2018")])]

#text("[…] consists of all the “models” or “representations” of (in the spirit of this previous blog post). (There is a technical set-theoretic issue here because the class of integral domains is a proper […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yoneda’s lemma as an identification of form and function: the case study of polynomials | What's new")]], [#link("https://terrytao.wordpress.com/2012/09/05/a-trivial-remark-about-schemes/#comment-681179")[#strong[#text("Yoneda’s lemma as an identification of form and function: the case study of polynomials | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2023")])]

#text("[…] Grothendieck’s “functor of points” interpretation of a scheme, discussed in this previous blog post, is one typical example of […]")
]
