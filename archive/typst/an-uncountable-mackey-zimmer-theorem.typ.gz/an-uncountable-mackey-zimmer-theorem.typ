// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/10/01/an-uncountable-mackey-zimmer-theorem/
// Converted to Typst by tao2typ: "2026-10-14T11:00:40.376865+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An uncountable Mackey-Zimmer theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An uncountable Mackey-Zimmer theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 October 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/10/01/an-uncountable-mackey-zimmer-theorem/")[#text("https://terrytao.wordpress.com/2020/10/01/an-uncountable-mackey-zimmer-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Asgar Jamneshan and I have just uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/2010.00574")[#text("An uncountable Mackey-Zimmer theorem")]#text("“. This paper is part of our longer term project to develop “uncountable” versions of various theorems in ergodic theory; see ")#link("https://terrytao.wordpress.com/2019/11/28/an-uncountable-moore-schmidt-theorem/")[#text("this previous paper")]#text(" of Asgar and myself for the first paper in this series (and another paper will appear shortly).")

#text("In this case the theorem in question is the Mackey-Zimmer theorem, previously discussed in ")#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/")[#text("this blog post")]#text(". This theorem gives an important classification of group and homogeneous extensions of measure-preserving systems. Let us first work in the (classical) setting of concrete measure-preserving systems. Let ")#mi("{Y = (Y, \\mu_Y, T_Y)}")#text(" be a measure-preserving system for some group ")#mi("{\\Gamma}")#text(", thus ")#mi("{(Y,\\mu_Y)}")#text(" is a (concrete) probability space and ")#mi("{T_Y : \\gamma \\rightarrow T_Y^\\gamma}")#text(" is a group homomorphism from ")#mi("{\\Gamma}")#text(" to the automorphism group ")#mi("{\\mathrm{Aut}(Y,\\mu_Y)}")#text(" of the probability space. (Here we are abusing notation by using ")#mi("{Y}")#text(" to refer both to the measure-preserving system and to the underlying set. In the notation of the paper we would instead distinguish these two objects as ")#mi("{Y_{\\mathbf{ConcPrb}_\\Gamma}}")#text(" and ")#mi("{Y_{\\mathbf{Set}}}")#text(" respectively, reflecting two of the (many) categories one might wish to view ")#mi("{Y}")#text(" as a member of, but for sake of this informal overview we will not maintain such precise distinctions.) If ")#mi("{K}")#text(" is a compact group, we define a ")#emph[#text("(concrete) cocycle")]#text(" to be a collection of measurable functions ")#mi("{\\rho_\\gamma : Y \\rightarrow K}")#text(" for ")#mi("{\\gamma \\in \\Gamma}")#text(" that obey the ")#emph[#text("cocycle equation")]#text(" ")#metadata(none) <tao-ddd02a0345ad6d42b737>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\rho_{\\gamma \\gamma^{\\prime}}(y) = \\rho_\\gamma(T_Y^{\\gamma^{\\prime}} y) \\rho_{\\gamma^{\\prime}}(y)")]]

#text(" ")#text(" for each ")#mi("{\\gamma,\\gamma^{\\prime} \\in \\Gamma}")#text(" and all ")#mi("{y \\in Y}")#text(". (One could weaken this requirement by only demanding the cocycle equation to hold for almost all ")#mi("{y}")#text(", rather than all ")#mi("{y}")#text("; we will effectively do so later in the post, when we move to opposite probability algebra systems.) Any such cocycle generates a ")#emph[#text("group skew-product")]#text(" ")#mi("{X = Y \\rtimes_\\rho K}")#text(" of ")#mi("{Y}")#text(", which is another measure-preserving system ")#mi("{(X, \\mu_X, T_X)}")#text(" where")

#list(
[#mi("{X = Y \\times K}")#text(" is the Cartesian product of ")#mi("{Y}")#text(" and ")#mi("{K}")#text(";")],
[#mi("{\\mu_X = \\mu_Y \\times \\mathrm{Haar}_K}")#text(" is the product measure of ")#mi("{\\mu_Y}")#text(" and Haar probability measure on ")#mi("{K}")#text("; and")],
[#text("The action ")#mi("{T_X: \\gamma \\rightarrow }")#text(" is given by the formula")

#metadata(none) <tao-1b5b9ccb3e8d006a5230>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("T_X^\\gamma(y,k) := (T_Y^\\gamma y, \\rho_\\gamma(y) k).")]]]
)

#text("The cocycle equation ")#link(<tao-ddd02a0345ad6d42b737>)[#text("(1)")]#text(" guarantees that ")#mi("{T_X}")#text(" is a homomorphism, and the (left) invariance of Haar measure and Fubini’s theorem guarantees that the ")#mi("{T_X^\\gamma}")#text(" remain measure preserving. There is also the more general notion of a ")#emph[#text("homogeneous skew-product")]#text(" ")#mi("{X \\times Y \\times_\\rho K/L}")#text(" in which the group ")#mi("{K}")#text(" is replaced by the homogeneous space ")#mi("{K/L}")#text(" for some closed subgroup of ")#mi("{L}")#text(", noting that ")#mi("{K/L}")#text(" still comes with a left-action of ")#mi("{K}")#text(" and a Haar measure. Group skew-products are very “explicit” ways to extend a system ")#mi("{Y}")#text(", as everything is described by the cocycle ")#mi("{\\rho}")#text(" which is a relatively tractable object to manipulate. (This is not to say that the cohomology of measure-preserving systems is trivial, but at least there are many tools one can use to study them, such as the ")#link("https://terrytao.wordpress.com/2019/11/28/an-uncountable-moore-schmidt-theorem/")[#text("Moore-Schmidt theorem")]#text(" discussed in this previous post.)")

#text("This group skew-product ")#mi("{X}")#text(" comes with a factor map ")#mi("{\\pi: X \\rightarrow Y}")#text(" and a coordinate map ")#mi("{\\theta: X \\rightarrow K}")#text(", which by ")#link(<tao-1b5b9ccb3e8d006a5230>)[#text("(2)")]#text(" are related to the action via the identities ")#metadata(none) <tao-045ef594d81d2f2134d6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\pi \\circ T_X^\\gamma = T_Y^\\gamma \\circ \\pi")]]

#text(" ")#text(" and")

#metadata(none) <tao-0ab25f3049004ce59691>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\theta \\circ T_X^\\gamma = (\\rho_\\gamma \\circ \\pi) \\theta")]]

#text("where in ")#link(<tao-0ab25f3049004ce59691>)[#text("(4)")]#text(" we are implicitly working in the group of (concretely) measurable functions from ")#mi("{Y}")#text(" to ")#mi("{K}")#text(". Furthermore, the combined map ")#mi("{(\\pi,\\theta): X \\rightarrow Y \\times K}")#text(" is measure-preserving (using the product measure on ")#mi("{Y \\times K}")#text("), indeed the way we have constructed things this map is just the identity map.")

#text("We can now generalize the notion of group skew-product by just working with the maps ")#mi("{\\pi, \\theta}")#text(", and weakening the requirement that ")#mi("{(\\pi,\\theta)}")#text(" be measure-preserving. Namely, define a ")#emph[#text("group extension")]#text(" of ")#mi("{Y}")#text(" by ")#mi("{K}")#text(" to be a measure-preserving system ")#mi("{(X,\\mu_X, T_X)}")#text(" equipped with a measure-preserving map ")#mi("{\\pi: X \\rightarrow Y}")#text(" obeying ")#link(<tao-045ef594d81d2f2134d6>)[#text("(3)")]#text(" and a measurable map ")#mi("{\\theta: X \\rightarrow K}")#text(" obeying ")#link(<tao-0ab25f3049004ce59691>)[#text("(4)")]#text(" for some cocycle ")#mi("{\\rho}")#text(", such that the ")#mi("{\\sigma}")#text("-algebra of ")#mi("{X}")#text(" is generated by ")#mi("{\\pi,\\theta}")#text(". There is also a more general notion of a ")#emph[#text("homogeneous extension")]#text(" in which ")#mi("{\\theta}")#text(" takes values in ")#mi("{K/L}")#text(" rather than ")#mi("{K}")#text(". Then every group skew-product ")#mi("{Y \\rtimes_\\rho K}")#text(" is a group extension of ")#mi("{Y}")#text(" by ")#mi("{K}")#text(", but not conversely. Here are some key counterexamples:")

#list(
[#text("(i) If ")#mi("{H}")#text(" is a closed subgroup of ")#mi("{K}")#text(", and ")#mi("{\\rho}")#text(" is a cocycle taking values in ")#mi("{H}")#text(", then ")#mi("{Y \\rtimes_\\rho H}")#text(" can be viewed as a group extension of ")#mi("{Y}")#text(" by ")#mi("{K}")#text(", taking ")#mi("{\\theta: Y \\rtimes_\\rho H \\rightarrow K}")#text(" to be the vertical coordinate ")#mi("{\\theta(y,h) = h}")#text(" (viewing ")#mi("{h}")#text(" now as an element of ")#mi("{K}")#text("). This will not be a skew-product by ")#mi("{K}")#text(" because ")#mi("{(\\theta,\\pi)}")#text(" pushes forward to the wrong measure on ")#mi("{Y \\times K}")#text(": it pushes forward to ")#mi("{\\mu_Y \\times \\mathrm{Haar}_H}")#text(" rather than ")#mi("{\\mu_Y \\times \\mathrm{Haar}_K}")#text(".")],
[#text("(ii) If one takes the same example as (i), but twists the vertical coordinate ")#mi("{\\theta}")#text(" to another vertical coordinate ")#mi("{\\tilde \\theta(y,h) := \\Phi(y) \\theta(y,h)}")#text(" for some measurable “gauge function” ")#mi("{\\Phi: Y \\rightarrow K}")#text(", then ")#mi("{Y \\rtimes_\\rho H}")#text(" is still a group extension by ")#mi("{K}")#text(", but now with the cocycle ")#mi("{\\rho}")#text(" replaced by the cohomologous cocycle")

#align(center)[#tao-fit-display[#mitex("\\tilde \\rho_\\gamma(y) := \\Phi(T_Y^\\gamma y) \\rho_\\gamma \\Phi(y)^{-1}.")]]

#text("Again, this will not be a skew product by ")#mi("{K}")#text(", because ")#mi("{(\\theta,\\pi)}")#text(" pushes forward to a twisted version of ")#mi("{\\mu_Y \\times \\mathrm{Haar}_H}")#text(" that is supported (at least in the case where ")#mi("{Y}")#text(" is compact and the cocycle ")#mi("{\\rho}")#text(" is continuous) on the ")#mi("{H}")#text("-bundle ")#mi("{\\bigcup_{y \\in Y} \\{y\\} \\times \\Phi(y) H}")#text(".")],
[#text("(iii) With the situation as in (i), take ")#mi("{X}")#text(" to be the union ")#mi("{X = Y \\rtimes_\\rho H \\uplus Y \\rtimes_\\rho Hk \\subset Y \\times K}")#text(" for some ")#mi("{k \\in K}")#text(" outside of ")#mi("{H}")#text(", where we continue to use the action ")#link(<tao-1b5b9ccb3e8d006a5230>)[#text("(2)")]#text(" and the standard vertical coordinate ")#mi("{\\theta: (y,k) \\mapsto k}")#text(" but now use the measure ")#mi("{\\mu_Y \\times (\\frac{1}{2} \\mathrm{Haar}_H + \\frac{1}{2} \\mathrm{Haar}_{Hk})}")#text(".")]
)

#text("As it turns out, group extensions and homogeneous extensions arise naturally in the Furstenberg-Zimmer structural theory of measure-preserving systems; roughly speaking, every compact extension of ")#mi("{Y}")#text(" is an inverse limit of group extensions. It is then of interest to classify such extensions.")

#text("Examples such as (iii) are annoying, but they can be excluded by imposing the additional condition that the system ")#mi("{(X,\\mu_X,T_X)}")#text(" is ")#link("https://en.wikipedia.org/wiki/Ergodicity")[#text("ergodic")]#text(" – all invariant (or essentially invariant) sets are of measure zero or measure one. (An essentially invariant set is a measurable subset ")#mi("{E}")#text(" of ")#mi("{X}")#text(" such that ")#mi("{T^\\gamma E}")#text(" is equal modulo null sets to ")#mi("{E}")#text(" for all ")#mi("{\\gamma \\in \\Gamma}")#text(".) For instance, the system in (iii) is non-ergodic because the set ")#mi("{Y \\times H}")#text(" (or ")#mi("{Y \\times Hk}")#text(") is invariant but has measure ")#mi("{1/2}")#text(". We then have the following fundamental result of Mackey and Zimmer:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Countable Mackey Zimmer theorem)")]#text(" ")#metadata(none) <tao-6c35493a2b937829c981>#text(" Let ")#mi("{\\Gamma}")#text(" be a group, ")#mi("{Y}")#text(" be a concrete measure-preserving system, and ")#mi("{K}")#text(" be a compact Hausdorff group. Assume that ")#mi("{\\Gamma}")#text(" is at most countable, ")#mi("{Y}")#text(" is a standard Borel space, and ")#mi("{K}")#text(" is metrizable. Then every (concrete) ergodic group extension of ")#mi("{Y}")#text(" is abstractly isomorphic to a group skew-product (by some closed subgroup ")#mi("{H}")#text(" of ")#mi("{K}")#text("), and every (concrete) ergodic homogeneous extension of ")#mi("{Y}")#text(" is similarly abstractly isomorphic to a homogeneous skew-product.")
]

#text("We will not define precisely what “abstractly isomorphic” means here, but it roughly speaking means “isomorphic after quotienting out the null sets”. A proof of this theorem can be found for instance in ")#link("https://terrytao.wordpress.com/2020/10/01/an-uncountable-mackey-zimmer-theorem/\\href")[#text("\\href")]#text(".")

#text("The main result of this paper is to remove the “countability” hypotheses from the above theorem, at the cost of working with opposite probability algebra systems rather than concrete systems. (We will discuss opposite probability algebras in a subsequent blog post relating to another paper in this series.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Uncountable Mackey Zimmer theorem)")]#text(" ")#metadata(none) <tao-e4225382969de14bd8f9>#text(" Let ")#mi("{\\Gamma}")#text(" be a group, ")#mi("{Y}")#text(" be an opposite probability algebra measure-preserving system, and ")#mi("{K}")#text(" be a compact Hausdorff group. Then every (abstract) ergodic group extension of ")#mi("{Y}")#text(" is abstractly isomorphic to a group skew-product (by some closed subgroup ")#mi("{H}")#text(" of ")#mi("{K}")#text("), and every (abstract) ergodic homogeneous extension of ")#mi("{Y}")#text(" is similarly abstractly isomorphic to a homogeneous skew-product.")
]

#text("We plan to use this result in future work to obtain uncountable versions of the Furstenberg-Zimmer and Host-Kra structure theorems.")

#text("As one might expect, one locates a proof of Theorem ")#link(<tao-e4225382969de14bd8f9>)[#text("2")]#text(" by finding a proof of Theorem ")#link(<tao-6c35493a2b937829c981>)[#text("1")]#text(" that does not rely too strongly on “countable” tools, such as disintegration or measurable selection, so that all of those tools can be replaced by “uncountable” counterparts. The proof we use is based on the one given in ")#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/")[#text("this previous post")]#text(", and begins by comparing the system ")#mi("{X}")#text(" with the group extension ")#mi("{Y \\rtimes_\\rho K}")#text(". As the examples (i), (ii) show, these two systems need not be isomorphic even in the ergodic case, due to the different probability measures employed. However one can relate the two after performing an additional averaging in ")#mi("{K}")#text(". More precisely, there is a canonical factor map ")#mi("{\\Pi: X \\rtimes_1 K \\rightarrow Y \\times_\\rho K}")#text(" given by the formula")

#align(center)[#tao-fit-display[#mitex("\\Pi(x, k) := (\\pi(x), \\theta(x) k).")]]

#text("This is a factor map not only of ")#mi("{\\Gamma}")#text("-systems, but actually of ")#mi("{\\Gamma \\times K^{op}}")#text("-systems, where the ")#link("https://en.wikipedia.org/wiki/Opposite_group")[#text("opposite group")]#text(" ")#mi("{K^{op}}")#text(" to ")#mi("{K}")#text(" acts (on the left) by right-multiplication of the second coordinate (this reversal of order is why we need to use the opposite group here). The key point is that the ergodicity properties of the system ")#mi("{Y \\times_\\rho K}")#text(" are closely tied the group ")#mi("{H}")#text(" that is “secretly” controlling the group extension. Indeed, in example (i), the invariant functions on ")#mi("{Y \\times_\\rho K}")#text(" take the form ")#mi("{(y,k) \\mapsto f(Hk)}")#text(" for some measurable ")#mi("{f: H \\backslash K \\rightarrow {\\bf C}}")#text(", while in example (ii), the invariant functions on ")#mi("{Y \\times_{\\tilde \\rho} K}")#text(" take the form ")#mi("{(y,k) \\mapsto f(H \\Phi(y)^{-1} k)}")#text(". In either case, the invariant factor is isomorphic to ")#mi("{H \\backslash K}")#text(", and can be viewed as a factor of the invariant factor of ")#mi("{X \\rtimes_1 K}")#text(", which is isomorphic to ")#mi("{K}")#text(". Pursuing this reasoning (using an abstract ergodic theorem of Alaoglu and Birkhoff, as discussed in ")#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/")[#text("the previous post")]#text(") one obtains the ")#emph[#text("Mackey range")]#text(" ")#mi("{H}")#text(", and also obtains the quotient ")#mi("{\\tilde \\Phi: Y \\rightarrow K/H}")#text(" of ")#mi("{\\Phi: Y \\rightarrow K}")#text(" to ")#mi("{K/H}")#text(" in this process. The main remaining task is to lift the quotient ")#mi("{\\tilde \\Phi}")#text(" back up to a map ")#mi("{\\Phi: Y \\rightarrow K}")#text(" that stays measurable, in order to “untwist” a system that looks like (ii) to make it into one that looks like (i). In countable settings this is where a “")#link("https://en.wikipedia.org/wiki/Selection_theorem")[#text("measurable selection theorem")]#text("” would ordinarily be invoked, but in the uncountable setting such theorems are not available for concrete maps. However it turns out that they still remain available for abstract maps: any abstractly measurable map ")#mi("{\\tilde \\Phi}")#text(" from ")#mi("{Y}")#text(" to ")#mi("{K/H}")#text(" has an abstractly measurable lift from ")#mi("{Y}")#text(" to ")#mi("{K}")#text(". To prove this we first use a canonical model for opposite probability algebras (which we will discuss in a companion post to this one, to appear shortly) to work with continuous maps (on a Stone space) rather than abstractly measurable maps. The measurable map ")#mi("{\\tilde \\Phi}")#text(" then induces a probability measure on ")#mi("{Y \\times K/H}")#text(", formed by pushing forward ")#mi("{\\mu_Y}")#text(" by the graphing map ")#mi("{y \\mapsto (y,\\tilde \\Phi(y))}")#text(". This measure in turn has several lifts up to a probability measure on ")#mi("{Y \\times K}")#text("; for instance, one can construct such a measure ")#mi("{\\overline{\\mu}}")#text(" via the Riesz representation theorem by demanding")

#align(center)[#tao-fit-display[#mitex("\\int_{Y \\times K} f(y,k) \\overline{\\mu}(y,k) := \\int_Y (\\int_{\\tilde \\Phi(y) H} f(y,k)\\ d\\mathrm{Haar}_{\\tilde \\Phi(y) H})\\ d\\mu_Y(y)")]]

#text("for all continuous functions ")#mi("{f}")#text(". This measure does not come from a graph of any single lift ")#mi("{\\Phi: Y \\rightarrow K}")#text(", but is in some sense an “average” of the entire ensemble of these lifts. But it turns out one can invoke the ")#link("https://en.wikipedia.org/wiki/Krein%E2%80%93Milman_theorem")[#text("Krein-Milman theorem")]#text(" to pass to an extremal lifting measure which ")#emph[#text("does")]#text(" come from an (abstract) lift ")#mi("{\\Phi}")#text(", and this can be used as a substitute for a measurable selection theorem. A variant of this Krein-Milman argument can also be used to express any homogeneous extension as a quotient of a group extension, giving the second part of the Mackey-Zimmer theorem.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/01/an-uncountable-mackey-zimmer-theorem/#comment-592722")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2020")])]

#text("After theorem 1 says “A proof of this theorem can be found for instance in .” I think a citation is supposed to go there.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/01/an-uncountable-mackey-zimmer-theorem/#comment-592989")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2020")])]

#text("Hmm, it still looks the same from here, through 2 different browsers. Maybe a caching issue? I’ll try again tomorrow.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/01/an-uncountable-mackey-zimmer-theorem/#comment-592799")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2020")])]

#text("I’m getting a lot of “Formula does not parse” for this article :/")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81c1cf6702093972106d4355d3436ba378ee870e2e6a64ed64addae622cf1efe-722da0096ba8d8c90108df270f0c422e927b95c2aa613a1f88962ed4968409f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/01/an-uncountable-mackey-zimmer-theorem/#comment-592840")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2020")])]

#mi("X\\times Y \\times_\\rho K/L")#text(" should be ")#mi("X=Y\\rtimes_\\rho K/L")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/01/an-uncountable-mackey-zimmer-theorem/#comment-592866")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2020")])]

#text("Maybe a linebreak just before Defintion 1.1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/01/an-uncountable-mackey-zimmer-theorem/#comment-592988")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2020")])]

#text("The very last words of the blog “, and” should be cut off.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Foundational aspects of uncountable measure theory: Gelfand duality, Riesz representation, canonical models, and canonical disintegration | What's new")]], [#link("https://terrytao.wordpress.com/2020/10/01/an-uncountable-mackey-zimmer-theorem/#comment-593494")[#strong[#text("Foundational aspects of uncountable measure theory: Gelfand duality, Riesz representation, canonical models, and canonical disintegration | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2020")])]

#text("[…] Asgar Jamneshan and I have just uploaded to the arXiv our paper “Foundational aspects of uncountable measure theory: Gelfand duality, Riesz representation, canonical models, and canonical disintegration“. This paper arose from our longer-term project to systematically develop “uncountable” ergodic theory – ergodic theory in which the groups acting are not required to be countable, the probability spaces one acts on are not required to be standard Borel, or Polish, and the compact groups that arise in the structural theory (e.g., the theory of group extensions) are not required to be separable. One of the motivations of doing this is to allow ergodic theory results to be applied to ultraproducts of finite dynamical systems, which can then hopefully be transferred to establish combinatorial results with good uniformity properties. An instance of this is the uncountable Mackey-Zimmer theorem, discussed in this companion blog post. […]")
]
