// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T15:19:12.694647+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Elliott-Halberstam conjecture implies the Vinogradov least quadratic nonresidue conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Elliott-Halberstam conjecture implies the Vinogradov least quadratic nonresidue conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 October 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/")[#text("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper “")#link("http://arxiv.org/abs/1410.7073")[#text("The Elliott-Halberstam conjecture implies the Vinogradov least quadratic nonresidue conjecture")]#text("“. As the title suggests, this paper links together the ")#link("http://en.wikipedia.org/wiki/Elliott%E2%80%93Halberstam_conjecture")[#text("Elliott-Halberstam conjecture")]#text(" from sieve theory with the conjecture of Vinogradov concerning the least quadratic nonresidue ")#mi("{n(p)}")#text(" of a prime ")#mi("{p}")#text(". Vinogradov established the bound ")#metadata(none) <tao-eb56c72061b9df5bf9c2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("n(p) \\ll p^{\\frac{1}{2\\sqrt{e}}} \\log^2 p")]]

#text("and conjectured that ")#metadata(none) <tao-b58e6ac010f2b26b5c79>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("n(p) \\ll p^\\varepsilon")]]

#text("for any fixed ")#mi("{\\varepsilon>0}")#text(". Unconditionally, the best result so far (up to logarithmic factors) that holds for all primes ")#mi("{p}")#text(" is by Burgess, who showed that ")#metadata(none) <tao-a5d95459b53438cac196>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("n(p) \\ll p^{\\frac{1}{4\\sqrt{e}}+\\varepsilon}")]]

#text("for any fixed ")#mi("{\\varepsilon>0}")#text(". See ")#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/")[#text("this previous post")]#text(" for a proof of these bounds.")

#text("In this paper, we show that the Vinogradov conjecture is a consequence of the Elliott-Halberstam conjecture. Using a variant of the argument, we also show that the “Type II” estimates ")#link("http://annals.math.princeton.edu/2014/179-3/p07")[#text("established by Zhang")]#text(" and numerically improved by ")#link("http://arxiv.org/abs/1402.0811")[#text("the Polymath8a project")]#text(" can be used to improve a little on the Vinogradov bound ")#link(<tao-eb56c72061b9df5bf9c2>)[#text("(1)")]#text(", to")

#align(center)[#tao-fit-display[#mitex("n(p) \\ll p^{(\\frac{1}{2}-\\frac{1}{34})\\frac{1}{\\sqrt{e}} + \\varepsilon},")]]

#text("although this falls well short of the Burgess bound. However, the method is somewhat different (although in both cases it is the Weil exponential sum bounds that are the source of the gain over ")#link(<tao-eb56c72061b9df5bf9c2>)[#text("(1)")]#text(") and it is conceivable that a numerically stronger version of the Type II estimates could obtain results that are more competitive with the Burgess bound. At any rate, this demonstrates that the equidistribution estimates introduced by Zhang may have further applications beyond the family of results related to bounded gaps between primes.")

#text("The connection between the least quadratic nonresidue problem and Elliott-Halberstam is follows. Suppose for contradiction we can find a prime ")#mi("{q}")#text(" with ")#mi("{n(q)}")#text(" unusually large. Letting ")#mi("{\\chi}")#text(" be the quadratic character modulo ")#mi("{q}")#text(", this implies that the sums ")#mi("{\\sum_{n \\leq x} \\chi(n)}")#text(" are also unusually large for a significant range of ")#mi("{x}")#text(" (e.g. ")#mi("{x < n(q)}")#text("), although the sum is also quite small for large ")#mi("{x}")#text(" (e.g. ")#mi("{x > q}")#text("), due to the cancellation present in ")#mi("{\\chi}")#text(". It turns out (by a sort of “uncertainty principle” for multiplicative functions, as per ")#link("http://www.ams.org/mathscinet-getitem?mr=2299742")[#text("this paper of Granville and Soundararajan")]#text(") that these facts force ")#mi("{\\sum_{n\\leq x} \\chi(n) \\Lambda(n)}")#text(" to be unusually large in magnitude for some large ")#mi("{x}")#text(" (with ")#mi("{q^C \\leq x \\leq q^{C^{\\prime}}}")#text(" for two large absolute constants ")#mi("{C,C^{\\prime}}")#text("). By the periodicity of ")#mi("{\\chi}")#text(", this means that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n\\leq x} \\chi(n) \\Lambda(n+q)")]]

#text("must be unusually large also. However, because ")#mi("{n(q)}")#text(" is large, one can factorise ")#mi("{\\chi}")#text(" as ")#mi("{f * 1}")#text(" for a fairly sparsely supported function ")#mi("{f = \\chi * \\mu}")#text(". The Elliott-Halberstam conjecture, which controls the distribution of ")#mi("{\\Lambda}")#text(" in arithmetic progressions on the average can then be used to show that ")#mi("{\\sum_{n \\leq x} (f*1)(n) \\Lambda(n+q)}")#text(" is small, giving the required contradiction.")

#text("The implication involving Type II estimates is proven by a variant of the argument. If ")#mi("{n(q)}")#text(" is large, then a character sum ")#mi("{\\sum_{N\\leq n \\leq 2N} \\chi(n)}")#text(" is unusually large for a certain ")#mi("{N}")#text(". By multiplicativity of ")#mi("{\\chi}")#text(", this shows that ")#mi("{\\chi}")#text(" correlates with ")#mi("{\\chi * 1_{[N,2N]}}")#text(", and then by periodicity of ")#mi("{\\chi}")#text(", this shows that ")#mi("{\\chi(n)}")#text(" correlates with ")#mi("{\\chi * 1_{[N,2N]}(n+jq)}")#text(" for various small ")#mi("{q}")#text(". By the Cauchy-Schwarz inequality (cf. ")#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/")[#text("this previous blog post")]#text("), this implies that ")#mi("{\\chi * 1_{[N,2N]}(n+jq)}")#text(" correlates with ")#mi("{\\chi * 1_{[N,2N]}(n+j^{\\prime}q)}")#text(" for some distinct ")#mi("{j,j^{\\prime}}")#text(". But this can be ruled out by using Type II estimates.")

#text("I’ll record here a well-known observation concerning potential counterexamples to any improvement to the Burgess bound, that is to say an infinite sequence of primes ")#mi("{p}")#text(" with ")#mi("{n(p) = p^{\\frac{1}{4\\sqrt{e}} + o(1)}}")#text(". Suppose we let ")#mi("{a(t)}")#text(" be the asymptotic mean value of the quadratic character ")#mi("{\\chi}")#text(" at ")#mi("{p^t}")#text(" and ")#mi("{b(t)}")#text(" the mean value of ")#mi("{\\chi \\Lambda}")#text("; these quantities are defined precisely in my paper, but roughly speaking one can think of")

#align(center)[#tao-fit-display[#mitex("a(t) = \\lim_{p \\rightarrow \\infty} \\frac{1}{p^t} \\sum_{n \\leq p^t} \\chi(n)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("b(t) = \\lim_{p \\rightarrow \\infty} \\frac{1}{p^t} \\sum_{n \\leq p^t} \\chi(n) \\Lambda(n).")]]

#text("Thanks to the basic Dirichlet convolution identity ")#mi("{\\chi(n) \\log(n) = \\chi * \\chi\\Lambda(n)}")#text(", one can establish the ")#emph[#text("Wirsing integral equation")]

#align(center)[#tao-fit-display[#mitex("t a(t) = \\int_0^t a(u) b(t-u)\\ du")]]

#text("for all ")#mi("{t \\geq 0}")#text("; see my paper for details (actually far sharper claims than this appear in previous work of Wirsing and Granville-Soundararajan). If we have an infinite sequence of counterexamples to any improvement to the Burgess bound, then we have")

#align(center)[#tao-fit-display[#mitex("a(t)=b(t) = 1 \\text{ for } t < \\frac{1}{4\\sqrt{e}}")]]

#text("while from the Burgess exponential sum estimates we have")

#align(center)[#tao-fit-display[#mitex("a(t) = 0 \\text{ for } t > \\frac{1}{4}.")]]

#text("These two constraints, together with the Wirsing integral equation, end up determining ")#mi("{a}")#text(" and ")#mi("{b}")#text(" completely. It turns out that we must have")

#align(center)[#tao-fit-display[#mitex("b(t) = -1 \\text{ for } \\frac{1}{4\\sqrt{e}} \\leq t \\leq \\frac{1}{4}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("a(t) = 1 - 2 \\log(4 \\sqrt{e} t) \\text{ for } \\frac{1}{4\\sqrt{e}} \\leq t \\leq \\frac{1}{4}")]]

#text("and then for ")#mi("{t > \\frac{1}{4}}")#text(", ")#mi("{b}")#text(" evolves by the integral equation")

#align(center)[#tao-fit-display[#mitex("b(t) = \\int_{1/4\\sqrt{e}}^{1/4} b(t-u) \\frac{2du}{u}.")]]

#text("For instance")

#align(center)[#tao-fit-display[#mitex("b(t) = 1 \\text{ for } \\frac{1}{4} < t \\leq \\frac{1}{2\\sqrt{e}}")]]

#text("and then ")#mi("{b}")#text(" oscillates in a somewhat strange fashion towards zero as ")#mi("{t \\rightarrow \\infty}")#text(". This very odd behaviour of ")#mi("{\\sum_n \\chi(n) \\Lambda(n)}")#text(" is surely impossible, but it seems remarkably hard to exclude it without invoking a strong hypothesis, such as GRH or the Elliott-Halberstam conjecture (or weaker versions thereof).")

#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-433789")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2014")])]

#text("Great!Terry,I’m seriously eager to wait Twin prime conjecture solved completely every seconds like in the fire.Once,twin prime conejecuture fell down,next Riemann hypothesis,next strong Goldbach conjecture.Good luck!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed7fe480a3961266e21303169a56485024d3761fdd7df6313fdb8a9c1d61f7a0-75a66dce3db0742badf7bb3b53131cb1c0febb8c669081d6c1961ecdd8c48a16.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of voloch")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-433792")[#strong[#text("voloch")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2014")])]

#text("I assume the argument only works for real characters, otherwise you’d have stated something more general. Is this correct and do you expect to be able to overcome whatever difficulty there is to extend to arbitrary characters?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-433812")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2014")])]

#text("Both results work for arbitrary characters; the Elliott-Halberstam conjecture would imply that the least n for which chi(n) is not equal to 1 is ")#mi("O(q^{o(1)})")#text(" for any character ")#mi("\\chi")#text(" of prime conductor ")#mi("q")#text(" (and composite conductor would probably be doable too if one is more careful). I guess I should add a remark to that effect in the paper. The second result is already stated in the paper for arbitrary characters: a Type II estimate implies nontrivial character sum bounds beyond Polya-Vinogradov for arbitrary characters.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed7fe480a3961266e21303169a56485024d3761fdd7df6313fdb8a9c1d61f7a0-75a66dce3db0742badf7bb3b53131cb1c0febb8c669081d6c1961ecdd8c48a16.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of voloch")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-433837")[#strong[#text("voloch")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2014")])]

#text("So EH implies existence of small primitive roots. That’s worth mentioning.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-433855")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2014")])]

#text("Hmm, I hadn’t thought about that angle… my second argument (starting from a Type II hypothesis, which is a special case of a generalised Elliott-Halberstam conjecture) should give a bound on small primitive roots (because it bounds character sums ")#mi("\\sum_{n \\leq N} \\chi(n)")#text(" with an arbitrary power of ")#mi("\\log x")#text(" saved), but the first argument (starting from just EH) may be more difficult to adapt, because it only controls characters ")#mi("\\chi")#text(" which are equal to 1 for all small numbers (so that ")#mi("\\chi")#text(" factorises usefully as ")#mi("\\chi = 1 * f")#text(", allowing one to exploit the EH hypothesis to estimate sums such as ")#mi("\\sum_{n \\leq N} \\chi(n) \\Lambda(n+q)")#text("). If ")#mi("q-1")#text(" has only O(1) prime factors there may be a chance to do something there though; I’ll have to think about it.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-433877")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2014")])]

#text("I think I can use EH to bound the least primitive root by ")#mi("p^{o(1)}")#text(" assuming that ")#mi("p-1")#text(" has a bounded number of factors. What the argument gives directly is that for each non-principal character ")#mi("\\chi")#text(", that there is an ")#mi("n = n_\\chi")#text(" of size ")#mi("n_\\chi \\ll p^{o(1)}")#text(" such that ")#mi("\\chi(n_\\chi) \\neq 1")#text(". Unfortunately ")#mi("n_\\chi")#text(" depends on ")#mi("\\chi")#text(" and so one does not immediately get a primitive root this way. But with a bit of combinatorics exploiting the multiplicativity of characters and the bounded number of prime factors of p-1, one can show that if there are no small primitive roots, then there is at least one non-principal character ")#mi("\\chi")#text(" for which ")#mi("\\chi(n)=1")#text(" for all small n, which on taking contrapositives gives the claim. For instance, in the simplest case when ")#mi("p-1")#text(" has just two prime factors ")#mi("p-1=2q")#text(", there are two generating characters ")#mi("\\chi_1, \\chi_2")#text(". If one has an ")#mi("n_1")#text(" such that ")#mi("\\chi_1(n_1)=1 \\neq \\chi_2(n_1)")#text(" and an ")#mi("n_2")#text(" such that ")#mi("\\chi_2(n_2) = 1\\neq \\chi_1(n_2)")#text(", then by multiplicativity ")#mi("\\chi_1(n_1n_2), \\chi_2(n_1n_2) \\neq 1")#text(" and so ")#mi("n_1 n_2")#text(" is a generator. So the only way one doesn’t get a small generator is if ")#mi("\\chi_1=1")#text(" for all small numbers or ")#mi("\\chi_2=1")#text(" for all small numbers (or both). Things get combinatorially more complicated when the group of characters has higher rank, but the same basic argument turns out to work. I’ll put it in the next revision of the ms.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-433822")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2014")])]

#text("“means that … to be unusually large” -> “means that … must be unusually large” ?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-433856")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2014")])]

#text("Notes for the first 8 pages of your paper:")

#text("– P. 1, l. 7: “follows the” –> “follows from the”")#linebreak()#text(" – P. 3, Conj. 1.4, l. 5: Use `\\colon’ instead of `:’ for maps")#linebreak()#text(" – P. 4, proof of Coro. 1.6, l 3: Use `\\coloneqq’ from the mathtools package instead of `:=’")#linebreak()#text(" – P. 5, Remark 1.7, l. 9: Use `\\coloneqq’ instead of `:=’")#linebreak()#text(" – P. 6, l. 9: Use `\\colon’ instead of `:’ for maps")#linebreak()#text(" – P. 6, Sec. 2, l. 5: “small, e.g. ")#mi("\\kappa")#text(" “small, e.g., ")#mi("\\kappa")#text(" “")#mi("t\\,a(t)")#text("”")

#text("The typographical comments also apply to the rest of the paper. :-)")

#emph[#text("[Thanks, these will be corrected in the next revision of the ms. – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ff1e219a5930ed589f26296204018f76066f1df344fa98c1dd586c06cd8e7df-5c1f7b828608f40dee04ef2a00038c915be6e7e0fd745863b5c41f5525dabf16.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 2802562155qqcom")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-433947")[#strong[#text("2802562155qqcom")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2014")])]

#text("ok great！")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-434184")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2014")])]

#text("– Lemma 2.2: “")#mi("t\\ a(t)")#text("” –> “")#mi("t\\,a(t)")#text("” [a smaller space]")#linebreak()#text(" – At the end of the proof of Lemma 2.2: “")#mi("ta(t)")#text("” –> “")#mi("t\\,a(t)")#text("” [insert a small space]")

#emph[#text("[This will be addressed in the next revision of the ms. – T.]")]#text("?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8db27f7df730347cb223d2c7c97a0915dc46d079ba17577d892ff6eef30757e1-ab05506c3ed44c79ba51fb6a7d9c6d7d021628a88072a5cfcf68c866665c6e43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nikhil Bera")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-434007")[#strong[#text("Nikhil Bera")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2014")])]

#text("Dear Prof. Terri Tao,")#linebreak()#text(" I’m a post graduate student from India. I have been suffering from a problem from my 1st year graduate courses. I want to do mathematics. But there is some other problem. I sub-consciously turn to find a meaning for life. What does it mean to live a life? We live we die and everything apparently gets finished. Then what does it mean to live a life?Sometimes I tried to find a answer, a logical answer, which will be the most believable to me, but never got a permanent satisfactory answer. Now a days I’m trying ran away from this problem so that I can concentrate in mathematics properly.Please reply to me. Give me a answer please or a motivation to forget this question.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2aa71e10246691cdbb83520a07203ed4267501dc488885de75f3f61c539984ee-6bef50ad075e9079c98691b3d3935e5070b0b05b47ab3ab5424092980f5b556f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ashwin1729")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-434103")[#strong[#text("ashwin1729")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2014")])]

#text("I believe anyone who does science comes across this when young.The best thing you can do is to convince yourselves that you don’t have enough tools to attack the problem and leave it for the future.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-434368")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2014")])]

#text("what ashwin basically means is that if you’ve descended from pure mathematics to finding the mere meaning of life (lol) you are probably stuck.")#linebreak()#text(" Anyway the answer’s quite simple really……………………………………………..42")#linebreak()#text(" I highly recommend you read “The Hitchhiker’s Guide to The Galaxy”- Douglas Adams, and go back to things that first got you interested in maths, read proofs that simply blew your mind again, and read a little biography of the greats – Euler, Gauss etc.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-434083")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2014")])]

#text("You should turn to a psychologist rather than a mathematician.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/739a741e6a46e2725b353c3d6582f2a23e9e44d25cca93e40b8332ba2a10d26a-955fb350db122312e7bf69ca0b8366be260a10e16486ed7cdba3f811ddf542b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tienhsiang")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-435172")[#strong[#text("tienhsiang")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2014")])]

#text("May I ask a limit question？ How to find out the limit of (1-1/4)(1-1/4^2)……(1-1/4^n) when n goes to infinity？Hope you are not offended.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2aa71e10246691cdbb83520a07203ed4267501dc488885de75f3f61c539984ee-6bef50ad075e9079c98691b3d3935e5070b0b05b47ab3ab5424092980f5b556f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ashwin1729")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-435220")[#strong[#text("ashwin1729")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2014")])]

#text("Dear tienhsiang,you can ask all your math related querries and get valid answers at:")

#link("http://math.stackexchange.com/")[#text("http://math.stackexchange.com/")]

#text("Good Luck!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/739a741e6a46e2725b353c3d6582f2a23e9e44d25cca93e40b8332ba2a10d26a-955fb350db122312e7bf69ca0b8366be260a10e16486ed7cdba3f811ddf542b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tienhsiang")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-435271")[#strong[#text("tienhsiang")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2014")])]

#text("Thanks a lot！")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-441255")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2014")])]

#text("Dear Terry,")#linebreak()#text(" On page 8 of your paper, you wrote “Since $\\chi$ has mean zero on intervals of length $q$, it is easy to see that $A_q=o(1)$”. I don’t quite see this, wouldn’t this imply a better bound for $L(1,\\chi)$, namely $o(\\log q)$ instead of $O(\\log q)$?")#linebreak()#text(" Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-441377")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2014")])]

#text("Ah, that is a typo: the claim should be that ")#mi("A_q(t) = A_q(t^{\\prime}) + o(1)")#text(" for ")#mi("t,t^{\\prime} > 1")#text("; it should only be ")#mi("a")#text(" that vanishes in this region, not ")#mi("A")#text(". I’ll update the paper in the next revision to reflect this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-449842")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2015")])]

#text("I’ve managed to improve the exponent of ")#mi("\\frac{1}{2}-\\frac{1}{34}")#text(" in the above bounds to ")#mi("\\frac{1}{2} - \\frac{1}{14}")#text(", although this is still well short of the Burgess exponents of ")#mi("\\frac{1}{2} - \\frac{1}{4}")#text(" (in the cube-free case) and ")#mi("\\frac{1}{2} - \\frac{1}{6}")#text(" (in the non-cube-free case). There are two arguments, one using the classical level of distribution of the divisor function ")#mi("\\tau=\\tau_2")#text(" at exponent 2/3, and the second using the ")#link("http://blogs.ethz.ch/kowalski/2013/06/25/a-ternary-divisor-variation/")[#text("more recent result of Fouvry, Kowalski, and Iwaniec")]#text(" that the third divisor function ")#mi("\\tau_3")#text(" has level of distribution 4/7 on smooth moduli.")

#text("Roughly speaking, the argument is as follows. Suppose that ")#mi("\\sum_{n \\leq N} \\chi(n)")#text(" is large for some ")#mi("N \\approx q^{3/7}")#text(". Then ")#mi("1_{[1,N]} * 1_{[1,N]} * \\chi 1_{[1,M]}")#text(" has large correlation with ")#mi("\\chi")#text(" on an interval of length a little bit larger than ")#mi("q")#text(" for some ")#mi("M \\approx q^{1/7}")#text(". As ")#mi("\\chi")#text(" is periodic with period q, the Cauchy-Schwarz argument in my paper then shows that ")#mi("1_{[1,N]} * 1_{[1,N]} * \\chi 1_{[1,M]}(n+jq)")#text(" has unusually high correlation with ")#mi("1_{[1,N]} * 1_{[1,N]} * \\chi 1_{[1,M]}(n)")#text(" for some non-zero j. This implies that ")#mi("1_{[1,N]} * 1_{[1,N]} * \\chi 1_{[1,M]}")#text(", and hence ")#mi("1_{[1,N]} * 1_{[1,N]}")#text(", has irregular distribution at moduli ")#mi("\\approx q / N \\approx (N^2)^{2/3}")#text(". But this contradicts (the proof of) the fact that ")#mi("\\tau_2")#text(" has level of distribution ")#mi("2/3")#text(".")

#text("A similar argument using ")#mi("1_{[1,N]} * 1_{[1,N^{\\prime}]} * 1_{[1,N^{\\prime}]}")#text(" with ")#mi("N \\approx q^{3/7}")#text(" and ")#mi("N^{\\prime} \\approx q^{2/7}")#text(" and the Fouvry-Kowalski-Iwaniec argument giving the 4/7 level of distribution for ")#mi("\\tau_3")#text(" predicts that at least one of the sums ")#mi("\\sum_{n \\leq N} \\chi(n)")#text(" or ")#mi("\\sum_{n \\leq N^{\\prime}} \\chi(n)")#text(" exhibits cancellation. (This is enough to bound the least quadratic nonresidue by ")#mi("q^{\\frac{3}{7\\sqrt{e}}+o(1)}")#text(".)")

#text("To improve on the non-cube-free Burgess result by these methods, one would need a level of distribution of ")#mi("\\tau_3")#text(" above 2/3; to improve upon the cube-free Burgess result, one would need a level of distribution of ")#mi("\\tau_4")#text(" above 3/4. Unfortunately this is a fair bit beyond current technology. (There is some “well-factorable” structure in the weights, but it is not clear how to use that to go beyond the existing results.)")

#text("On the other hand, one can at least now improve upon the Vinogradov exponent of ")#mi("1/2")#text(" without using any of the Weil conjectures: using the elementary Kloosterman bound on Kloosterman sums (saving a ")#mi("q^{1/4}")#text(" gain instead of the full ")#mi("q^{1/2}")#text(" gain), one can get an exponent of ")#mi("\\frac{1}{2} - \\frac{1}{30}")#text(" (I think).")

#text("ADDED LATER: More generally, getting beyond an exponent of ")#mi("\\frac{1}{k}")#text(" by these methods looks to be roughly equivalent to that of getting the predicted asymptotic for ")#mi("\\sum_{n \\leq x} \\tau_k(n) \\tau_k(n+q)")#text(" for ")#mi("q = o(x)")#text(". Kloosterman sums do the job for ")#mi("k=2")#text(" (cf. the Titchmarsh divisor problem; also automorphic forms methods are available too, at least in the regime ")#mi("q=O(1)")#text("), but ")#mi("k=3")#text(" (which would beat the non-cube-free Burgess) is already a little bit beyond current technology, and ")#mi("k=4")#text(" (which would beat Burgess in general) looks hopeless at present. (The limiting case ")#mi("k \\to \\infty")#text(" is a slightly simpler cousin of the twin prime and even Goldbach conjectures, but still considered extremely difficult.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/10/27/the-elliott-halberstam-conjecture-implies-the-vinogradov-least-quadratic-nonresidue-conjecture/#comment-449919")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2015")])]

#text("Nice improvements!")

#text("Notes to your arXiv paper:")#linebreak()#text(" – In (1.9): ")#mi("1/2")#text(" –> ")#mi("\\frac{1}{2}")#text(" (in the exponent)")#linebreak()#text(" – References [25] and [26] should be updated.")
]
]
