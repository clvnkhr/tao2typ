// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/
// Converted to Typst by tao2typ: "2026-10-14T16:37:01.306334+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Notes on the classification of complex Lie algebras", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Notes on the classification of complex Lie algebras")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 April 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/")[#text("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("An ")#link("http://en.wikipedia.org/wiki/Lie_algebra")[#text("abstract finite-dimensional complex Lie algebra")]#text(", or ")#emph[#text("Lie algebra")]#text(" for short, is a finite-dimensional complex vector space ")#mi("{{\\mathfrak g}}")#text(" together with an anti-symmetric bilinear form ")#mi("{[,] = [,]_{\\mathfrak g}: {\\mathfrak g} \\times {\\mathfrak g} \\rightarrow {\\mathfrak g}}")#text(" that obeys the ")#link("http://en.wikipedia.org/wiki/Jacobi_identity")[#text("Jacobi identity")]#text(" ")#metadata(none) <tao-9dcc6fbbb4f3d0969043>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("[[x,y],z] + [[y,z],x] + [[z,x],y] = 0")]]

#text(" for all ")#mi("{x,y,z \\in {\\mathfrak g}}")#text("; by anti-symmetry one can also rewrite the Jacobi identity as ")#metadata(none) <tao-d75a0f5a7461846c8840>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("[x,[y,z]] = [[x,y],z] + [y,[x,z]].")]]

#text(" We will usually omit the subscript from the Lie bracket ")#mi("{[,]_{\\mathfrak g}}")#text(" when this will not cause ambiguity. A ")#emph[#text("homomorphism")]#text(" ")#mi("{\\phi: {\\mathfrak g} \\rightarrow {\\mathfrak h}}")#text(" between two Lie algebras ")#mi("{{\\mathfrak g},{\\mathfrak h}}")#text(" is a linear map that respects the Lie bracket, thus ")#mi("{\\phi([x,y]_{\\mathfrak g}) =[\\phi(x),\\phi(y)]_{\\mathfrak h}}")#text(" for all ")#mi("{x,y \\in {\\mathfrak g}}")#text(". As with many other classes of mathematical objects, the class of Lie algebras together with their homomorphisms then form a ")#link("http://en.wikipedia.org/wiki/Category_(mathematics)")[#text("category")]#text(". One can of course also consider Lie algebras in infinite dimension or over other fields, but we will restrict attention throughout these notes to the finite-dimensional complex case. The trivial, zero-dimensional Lie algebra is denoted ")#mi("{0}")#text("; Lie algebras of positive dimension will be called ")#emph[#text("non-trivial")]#text(".")

#text("Lie algebras come up in many contexts in mathematics, in particular arising as the tangent space of complex ")#link("http://en.wikipedia.org/wiki/Lie_group")[#text("Lie groups")]#text(". It is thus very profitable to think of Lie algebras as being the infinitesimal component of a Lie group, and in particular almost all of the notation and concepts that are applicable to Lie groups (e.g. nilpotence, solvability, extensions, etc.) have infinitesimal counterparts in the category of Lie algebras (often with exactly the same terminology). See ")#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("this previous blog post")]#text(" for more discussion about the connection between Lie algebras and Lie groups (that post was focused over the reals instead of the complexes, but much of the discussion carries over to the complex case).")

#text("A particular example of a Lie algebra is the general linear Lie algebra ")#mi("{{\\mathfrak{gl}}(V)}")#text(" of linear transformations ")#mi("{x: V \\rightarrow V}")#text(" on a finite-dimensional complex vector space (or ")#emph[#text("vector space")]#text(" for short) ")#mi("{V}")#text(", with the commutator Lie bracket ")#mi("{[x,y] := xy-yx}")#text("; one easily verifies that this is indeed an abstract Lie algebra. We will define a ")#emph[#text("concrete")]#text(" Lie algebra to be a Lie algebra that is a subalgebra of ")#mi("{{\\mathfrak{gl}}(V)}")#text(" for some vector space ")#mi("{V}")#text(", and similarly define a ")#emph[#text("representation")]#text(" of a Lie algebra ")#mi("{{\\mathfrak g}}")#text(" to be a homomorphism ")#mi("{\\rho: {\\mathfrak g} \\rightarrow {\\mathfrak h}}")#text(" into a concrete Lie algebra ")#mi("{{\\mathfrak h}}")#text(". It is a deep ")#link("http://en.wikipedia.org/wiki/Ado%27s_theorem")[#text("theorem of Ado")]#text(" (discussed in ")#link("https://terrytao.wordpress.com/2011/05/10/ados-theorem/")[#text("this previous post")]#text(") that every abstract Lie algebra is in fact isomorphic to a concrete one (or equivalently, that every abstract Lie algebra has a faithful representation), but we will not need or prove this fact here.")

#text("Even without Ado’s theorem, though, the structure of abstract Lie algebras is very well understood. As with objects in many other algebraic categories, a basic way to understand a Lie algebra ")#mi("{{\\mathfrak g}}")#text(" is to factor it into two simpler algebras ")#mi("{{\\mathfrak h}, {\\mathfrak k}}")#text(" via a ")#link("http://en.wikipedia.org/wiki/Short_exact_sequence#Short_exact_sequence")[#text("short exact sequence")]#text(" ")#metadata(none) <tao-fa79d4746c21cd960a17>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("0 \\rightarrow {\\mathfrak h} \\rightarrow {\\mathfrak g} \\rightarrow {\\mathfrak k} \\rightarrow 0,")]]

#text(" thus one has an injective homomorphism from ")#mi("{{\\mathfrak h}}")#text(" to ")#mi("{{\\mathfrak g}}")#text(" and a surjective homomorphism from ")#mi("{{\\mathfrak g}}")#text(" to ")#mi("{{\\mathfrak k}}")#text(" such that the image of the former homomorphism is the kernel of the latter. (To be pedantic, a short exact sequence in a general category requires these homomorphisms to be ")#link("http://en.wikipedia.org/wiki/Monomorphism")[#text("monomorphisms")]#text(" and ")#link("http://en.wikipedia.org/wiki/Epimorphism")[#text("epimorphisms")]#text(" respectively, but in the category of Lie algebras these turn out to reduce to the more familiar concepts of injectivity and surjectivity respectively.) Given such a sequence, one can (non-uniquely) identify ")#mi("{{\\mathfrak g}}")#text(" with the vector space ")#mi("{{\\mathfrak h} \\times {\\mathfrak k}}")#text(" equipped with a Lie bracket of the form ")#metadata(none) <tao-accac4c40fc8a864f771>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("[(t,x), (s,y)]_{\\mathfrak g} = ([t,s]_{\\mathfrak h} + A(t,y) - A(s,x) + B(x,y), [x,y]_{\\mathfrak k})")]]

#text(" for some bilinear maps ")#mi("{A: {\\mathfrak h} \\times {\\mathfrak k} \\rightarrow {\\mathfrak h}}")#text(" and ")#mi("{B: {\\mathfrak k} \\times {\\mathfrak k} \\rightarrow {\\mathfrak h}}")#text(" that obey some Jacobi-type identities which we will not record here. Understanding exactly what maps ")#mi("{A,B}")#text(" are possible here (up to coordinate change) can be a difficult task (and is one of the key objectives of ")#link("http://en.wikipedia.org/wiki/Lie_algebra_cohomology")[#text("Lie algebra cohomology")]#text("), but in principle at least, the problem of understanding ")#mi("{{\\mathfrak g}}")#text(" can be reduced to that of understanding that of its factors ")#mi("{{\\mathfrak k}, {\\mathfrak h}}")#text(". To emphasise this, I will (perhaps idiosyncratically) express the existence of a short exact sequence ")#link(<tao-fa79d4746c21cd960a17>)[#text("(3)")]#text(" by the ")#link("http://en.wikipedia.org/wiki/ATLAS_of_Finite_Groups")[#text("ATLAS")]#text("-type notation ")#metadata(none) <tao-7046d42eb9dfd6e60a5c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("{\\mathfrak g} = {\\mathfrak h} . {\\mathfrak k}")]]

#text(" although one should caution that for given ")#mi("{{\\mathfrak h}}")#text(" and ")#mi("{{\\mathfrak k}}")#text(", there can be multiple non-isomorphic ")#mi("{{\\mathfrak g}}")#text(" that can form a short exact sequence with ")#mi("{{\\mathfrak h},{\\mathfrak k}}")#text(", so that ")#mi("{{\\mathfrak h} . {\\mathfrak k}}")#text(" is not a uniquely defined combination of ")#mi("{{\\mathfrak h}}")#text(" and ")#mi("{{\\mathfrak k}}")#text("; one could emphasise this by writing ")#mi("{{\\mathfrak h} ._{A,B} {\\mathfrak k}}")#text(" instead of ")#mi("{{\\mathfrak h} . {\\mathfrak k}}")#text(", though we will not do so here. We will refer to ")#mi("{{\\mathfrak g}}")#text(" as an ")#emph[#text("extension")]#text(" of ")#mi("{{\\mathfrak k}}")#text(" by ")#mi("{{\\mathfrak h}}")#text(", and read the notation ")#link(<tao-7046d42eb9dfd6e60a5c>)[#text("(5)")]#text(" as “ ")#mi("{{\\mathfrak g}}")#text(" is ")#mi("{{\\mathfrak h}}")#text("-by-")#mi("{{\\mathfrak k}}")#text("“; confusingly, these two notations reverse the subject and object of “by”, but unfortunately both notations are well entrenched in the literature. We caution that the operation ")#mi("{.}")#text(" is not commutative, and it is only partly associative: every Lie algebra of the form ")#mi("{{\\mathfrak k} . ({\\mathfrak h} . {\\mathfrak l})}")#text(" is also of the form ")#mi("{({\\mathfrak k} . {\\mathfrak h}) . {\\mathfrak l}}")#text(", but the converse is not true (see ")#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/")[#text("this previous blog post")]#text(" for some related discussion). As we are working in the infinitesimal world of Lie algebras (which have an additive group operation) rather than Lie groups (in which the group operation is usually written multiplicatively), it may help to think of ")#mi("{{\\mathfrak h} . {\\mathfrak k}}")#text(" as a (twisted) “sum” of ")#mi("{{\\mathfrak h}}")#text(" and ")#mi("{{\\mathfrak k}}")#text(" rather than a “product”; for instance, we have ")#mi("{{\\mathfrak g} = 0 . {\\mathfrak g}}")#text(" and ")#mi("{{\\mathfrak g} = {\\mathfrak g} . 0}")#text(", and also ")#mi("{\\dim {\\mathfrak h} . {\\mathfrak k} = \\dim {\\mathfrak h} + \\dim {\\mathfrak k}}")#text(".")

#text("Special examples of extensions ")#mi("{{\\mathfrak h} .{\\mathfrak k}}")#text(" of ")#mi("{{\\mathfrak k}}")#text(" by ")#mi("{{\\mathfrak h}}")#text(" include the ")#link("http://en.wikipedia.org/wiki/Direct_product")[#text("direct sum")]#text(" (or ")#emph[#text("direct product")]#text(") ")#mi("{{\\mathfrak h} \\oplus {\\mathfrak k}}")#text(" (also denoted ")#mi("{{\\mathfrak h} \\times {\\mathfrak k}}")#text("), which is given by the construction ")#link(<tao-accac4c40fc8a864f771>)[#text("(4)")]#text(" with ")#mi("{A}")#text(" and ")#mi("{B}")#text(" both vanishing, and the ")#link("http://en.wikipedia.org/wiki/Splitting_lemma")[#text("split extension")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Semidirect_product")[#text("semidirect product")]#text(") ")#mi("{{\\mathfrak h} : {\\mathfrak k} = {\\mathfrak h} :_\\rho {\\mathfrak k}}")#text(" (also denoted ")#mi("{{\\mathfrak h} \\ltimes {\\mathfrak k} = {\\mathfrak h} \\ltimes_\\rho {\\mathfrak k}}")#text("), which is given by the construction ")#link(<tao-accac4c40fc8a864f771>)[#text("(4)")]#text(" with ")#mi("{B}")#text(" vanishing and the bilinear map ")#mi("{A: {\\mathfrak h} \\times {\\mathfrak k} \\rightarrow {\\mathfrak h}}")#text(" taking the form")

#align(center)[#tao-fit-display[#mitex("A( t, x ) = \\rho(x)(t)")]]

#text("for some representation ")#mi("{\\rho: {\\mathfrak k} \\rightarrow \\text{Der} {\\mathfrak h}}")#text(" of ")#mi("{{\\mathfrak k}}")#text(" in the concrete Lie algebra of ")#link("http://en.wikipedia.org/wiki/Derivation_(abstract_algebra)")[#text("derivations")]#text(" ")#mi("{\\text{Der} {\\mathfrak h} \\subset {\\mathfrak{gl}}({\\mathfrak h})}")#text(" of ")#mi("{{\\mathfrak h}}")#text(", that is to say the algebra of linear maps ")#mi("{D: {\\mathfrak h} \\rightarrow {\\mathfrak h}}")#text(" that obey the Leibniz rule")

#align(center)[#tao-fit-display[#mitex("D[s,t]_{\\mathfrak h} = [Ds,t]_{\\mathfrak h} + [s,Dt]_{\\mathfrak h}")]]

#text("for all ")#mi("{s,t \\in {\\mathfrak h}}")#text(". (The derivation algebra ")#mi("{\\text{Der} {\\mathfrak g}}")#text(" of a Lie algebra ")#mi("{{\\mathfrak g}}")#text(" is analogous to the ")#link("http://en.wikipedia.org/wiki/Automorphism_group")[#text("automorphism group")]#text(" ")#mi("{\\text{Aut}(G)}")#text(" of a Lie group ")#mi("{G}")#text(", with the two concepts being intertwined by the tangent space functor ")#mi("{G \\mapsto {\\mathfrak g}}")#text(" from Lie groups to Lie algebras (i.e. the derivation algebra is the infinitesimal version of the automorphism group). Of course, this functor also intertwines the Lie algebra and Lie group versions of most of the other concepts discussed here, such as extensions, semidirect products, etc.)")

#text("There are two general ways to factor a Lie algebra ")#mi("{{\\mathfrak g}}")#text(" as an extension ")#mi("{{\\mathfrak h} . {\\mathfrak k}}")#text(" of a smaller Lie algebra ")#mi("{{\\mathfrak k}}")#text(" by another smaller Lie algebra ")#mi("{{\\mathfrak h}}")#text(". One is to locate a ")#link("http://en.wikipedia.org/wiki/Lie_algebra#Homomorphisms.2C_subalgebras.2C_and_ideals")[#text("Lie algebra ideal")]#text(" (or ")#emph[#text("ideal")]#text(" for short) ")#mi("{{\\mathfrak h}}")#text(" in ")#mi("{{\\mathfrak g}}")#text(", thus ")#mi("{[{\\mathfrak h},{\\mathfrak g}] \\subset {\\mathfrak h}}")#text(", where ")#mi("{[{\\mathfrak h},{\\mathfrak g}]}")#text(" denotes the Lie algebra generated by ")#mi("{\\{ [x,y]: x \\in {\\mathfrak h}, y \\in {\\mathfrak g} \\}}")#text(", and then take ")#mi("{{\\mathfrak k}}")#text(" to be the quotient space ")#mi("{{\\mathfrak g}/{\\mathfrak h}}")#text(" in the usual manner; one can check that ")#mi("{{\\mathfrak h}}")#text(", ")#mi("{{\\mathfrak k}}")#text(" are also Lie algebras and that we do indeed have a short exact sequence")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak g} = {\\mathfrak h} . ({\\mathfrak g}/{\\mathfrak h}).")]]

#text("Conversely, whenever one has a factorisation ")#mi("{{\\mathfrak g} = {\\mathfrak h} . {\\mathfrak k}}")#text(", one can identify ")#mi("{{\\mathfrak h}}")#text(" with an ideal in ")#mi("{{\\mathfrak g}}")#text(", and ")#mi("{{\\mathfrak k}}")#text(" with the quotient of ")#mi("{{\\mathfrak g}}")#text(" by ")#mi("{{\\mathfrak h}}")#text(".")

#text("The other general way to obtain such a factorisation is is to start with a homomorphism ")#mi("{\\rho: {\\mathfrak g} \\rightarrow {\\mathfrak m}}")#text(" of ")#mi("{{\\mathfrak g}}")#text(" into another Lie algebra ")#mi("{{\\mathfrak m}}")#text(", take ")#mi("{{\\mathfrak k}}")#text(" to be the image ")#mi("{\\rho({\\mathfrak g})}")#text(" of ")#mi("{{\\mathfrak g}}")#text(", and ")#mi("{{\\mathfrak h}}")#text(" to be the kernel ")#mi("{\\text{ker} \\rho := \\{ x \\in {\\mathfrak g}: \\rho(x) = 0 \\}}")#text(". Again, it is easy to see that this does indeed create a short exact sequence:")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak g} = \\text{ker} \\rho . \\rho({\\mathfrak g}).")]]

#text("Conversely, whenever one has a factorisation ")#mi("{{\\mathfrak g} = {\\mathfrak h} . {\\mathfrak k}}")#text(", one can identify ")#mi("{{\\mathfrak k}}")#text(" with the image of ")#mi("{{\\mathfrak g}}")#text(" under some homomorphism, and ")#mi("{{\\mathfrak h}}")#text(" with the kernel of that homomorphism. Note that if a representation ")#mi("{\\rho: {\\mathfrak g} \\rightarrow {\\mathfrak m}}")#text(" is ")#link("http://en.wikipedia.org/wiki/Faithful_representation")[#text("faithful")]#text(" (i.e. injective), then the kernel is trivial and ")#mi("{{\\mathfrak g}}")#text(" is isomorphic to ")#mi("{\\rho({\\mathfrak g})}")#text(".")

#text("Now we consider some examples of factoring some class of Lie algebras into simpler Lie algebras. The easiest examples of Lie algebras to understand are the ")#emph[#text("abelian")]#text(" Lie algebras ")#mi("{{\\mathfrak g}}")#text(", in which the Lie bracket identically vanishes. Every one-dimensional Lie algebra is automatically abelian, and thus isomorphic to the scalar algebra ")#mi("{{\\bf C}}")#text(". Conversely, by using an arbitrary linear basis of ")#mi("{{\\mathfrak g}}")#text(", we see that an abelian Lie algebra is isomorphic to the direct sum of one-dimensional algebras. Thus, a Lie algebra is abelian if and only if it is isomorphic to the direct sum of finitely many copies of ")#mi("{{\\bf C}}")#text(".")

#text("Now consider a Lie algebra ")#mi("{{\\mathfrak g}}")#text(" that is not necessarily abelian. We then form the ")#link("http://en.wikipedia.org/wiki/Derived_subgroup")[#text("derived algebra")]#text(" ")#mi("{[{\\mathfrak g},{\\mathfrak g}]}")#text("; this algebra is trivial if and only if ")#mi("{{\\mathfrak g}}")#text(" is abelian. It is easy to see that ")#mi("{[{\\mathfrak h},{\\mathfrak k}]}")#text(" is an ideal whenever ")#mi("{{\\mathfrak h},{\\mathfrak k}}")#text(" are ideals, so in particular the derived algebra ")#mi("{[{\\mathfrak g},{\\mathfrak g}]}")#text(" is an ideal and we thus have the short exact sequence")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak g} = [{\\mathfrak g},{\\mathfrak g}] . ({\\mathfrak g}/[{\\mathfrak g},{\\mathfrak g}]).")]]

#text("The algebra ")#mi("{{\\mathfrak g}/[{\\mathfrak g},{\\mathfrak g}]}")#text(" is the maximal abelian quotient of ")#mi("{{\\mathfrak g}}")#text(", and is known as the ")#link("http://en.wikipedia.org/wiki/Derived_subgroup#Abelianization")[#text("abelianisation")]#text(" of ")#mi("{{\\mathfrak g}}")#text(". If it is trivial, we call the Lie algebra ")#link("http://en.wikipedia.org/wiki/Perfect_group")[#text("perfect")]#text(". If instead it is non-trivial, then the derived algebra has strictly smaller dimension than ")#mi("{{\\mathfrak g}}")#text(". From this, it is natural to associate two series to any Lie algebra ")#mi("{{\\mathfrak g}}")#text(", the ")#emph[#text("lower central series")]

#align(center)[#tao-fit-display[#mitex("{\\mathfrak g}_1 = {\\mathfrak g}; {\\mathfrak g}_2 := [{\\mathfrak g}, {\\mathfrak g}_1]; {\\mathfrak g}_3 := [{\\mathfrak g}, {\\mathfrak g}_2]; \\ldots")]]

#text("and the ")#emph[#text("derived series")]

#align(center)[#tao-fit-display[#mitex("{\\mathfrak g}^{(1)} := {\\mathfrak g}; {\\mathfrak g}^{(2)} := [{\\mathfrak g}^{(1)}, {\\mathfrak g}^{(1)}]; {\\mathfrak g}^{(3)} := [{\\mathfrak g}^{(2)}, {\\mathfrak g}^{(2)}]; \\ldots.")]]

#text("By induction we see that these are both decreasing series of ideals of ")#mi("{{\\mathfrak g}}")#text(", with the derived series being slightly smaller (")#mi("{{\\mathfrak g}^{(k)} \\subseteq {\\mathfrak g}_k}")#text(" for all ")#mi("{k}")#text("). We say that a Lie algebra is ")#link("http://en.wikipedia.org/wiki/Nilpotent_Lie_algebra")[#text("nilpotent")]#text(" if its lower central series is eventually trivial, and ")#link("http://en.wikipedia.org/wiki/Solvable_Lie_algebra")[#text("solvable")]#text(" if its derived series eventually becomes trivial. Thus, abelian Lie algebras are nilpotent, and nilpotent Lie algebras are solvable, but the converses are not necessarily true. For instance, in the general linear group ")#mi("{{\\mathfrak{gl}}_n = {\\mathfrak{gl}}({\\bf C}^n)}")#text(", which can be identified with the Lie algebra of ")#mi("{n \\times n}")#text(" complex matrices, the subalgebra ")#mi("{{\\mathfrak n}}")#text(" of strictly upper triangular matrices is nilpotent (but not abelian for ")#mi("{n \\geq 3}")#text("), while the subalgebra ")#mi("{{\\mathfrak n}}")#text(" of upper triangular matrices is solvable (but not nilpotent for ")#mi("{n \\geq 2}")#text("). It is also clear that any subalgebra of a nilpotent algebra is nilpotent, and similarly for solvable or abelian algebras.")

#text("From the above discussion we see that a Lie algebra is solvable if and only if it can be represented by a tower of abelian extensions, thus")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak g} = ( \\dots ({\\mathfrak a}_k . {\\mathfrak a}_{k-1}) \\dots . {\\mathfrak a}_2 ) . {\\mathfrak a}_1")]]

#text("for some abelian ")#mi("{{\\mathfrak a}_1,\\ldots,{\\mathfrak a}_k}")#text(". Similarly, a Lie algebra ")#mi("{{\\mathfrak g}}")#text(" is nilpotent if it is expressible as a tower of ")#emph[#text("central")]#text(" extensions (so that in all the extensions ")#mi("{{\\mathfrak h} . {\\mathfrak k}}")#text(" in the above factorisation, ")#mi("{{\\mathfrak h}}")#text(" is central in ")#mi("{{\\mathfrak h} . {\\mathfrak k}}")#text(", where we say that ")#mi("{{\\mathfrak h}}")#text(" is central in ")#mi("{{\\mathfrak g}}")#text(" if ")#mi("{[{\\mathfrak h},{\\mathfrak g}]=0}")#text("). We also see that an extension ")#mi("{{\\mathfrak h} . {\\mathfrak k}}")#text(" is solvable if and only of both factors ")#mi("{{\\mathfrak h}, {\\mathfrak k}}")#text(" are solvable. Splitting abelian algebras into cyclic (i.e. one-dimensional) ones, we thus see that a finite-dimensional Lie algebra is solvable if and only if it is ")#link("http://en.wikipedia.org/wiki/Polycyclic_group")[#text("polycylic")]#text(", i.e. it can be represented by a tower of cyclic extensions.")

#text("For our next fundamental example of using short exact sequences to split a general Lie algebra into simpler objects, we observe that every abstract Lie algebra ")#mi("{{\\mathfrak g}}")#text(" has an ")#link("http://en.wikipedia.org/wiki/Adjoint_representation")[#text("adjoint representation")]#text(" ")#mi("{\\text{ad}: {\\mathfrak g} \\rightarrow \\text{ad} {\\mathfrak g} \\subset {\\mathfrak{gl}}({\\mathfrak g})}")#text(", where for each ")#mi("{x \\in {\\mathfrak g}}")#text(", ")#mi("{\\text{ad} x \\in {\\mathfrak{gl}}({\\mathfrak g})}")#text(" is the linear map ")#mi("{(\\text{ad} x)(y) := [x,y]}")#text("; one easily verifies that this is indeed a representation (indeed, ")#link(<tao-d75a0f5a7461846c8840>)[#text("(2)")]#text(" is equivalent to the assertion that ")#mi("{\\text{ad} [x,y] = [\\text{ad} x, \\text{ad} y]}")#text(" for all ")#mi("{x,y \\in {\\mathfrak g}}")#text("). The kernel of this representation is the ")#link("http://en.wikipedia.org/wiki/Center_(group_theory)")[#text("center")]#text(" ")#mi("{Z({\\mathfrak g}) := \\{ x \\in {\\mathfrak g}: [x,{\\mathfrak g}] = 0\\}}")#text(", which the maximal central subalgebra of ")#mi("{{\\mathfrak g}}")#text(". We thus have the short exact sequence ")#metadata(none) <tao-8cb6279a8e1b12a96774>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("{\\mathfrak g} = Z({\\mathfrak g}) . \\text{ad} g")]]

#text(" which, among other things, shows that every abstract Lie algebra is a central extension of a concrete Lie algebra (which can serve as a cheap substitute for Ado’s theorem mentioned earlier).")

#text("For our next fundamental decomposition of Lie algebras, we need some more definitions. A Lie algebra ")#mi("{{\\mathfrak g}}")#text(" is ")#link("http://en.wikipedia.org/wiki/Simple_Lie_algebra")[#text("simple")]#text(" if it is non-abelian and has no ideals other than ")#mi("{0}")#text(" and ")#mi("{{\\mathfrak g}}")#text("; thus simple Lie algebras cannot be factored ")#mi("{{\\mathfrak g} = {\\mathfrak h} . {\\mathfrak k}}")#text(" into strictly smaller algebras ")#mi("{{\\mathfrak h},{\\mathfrak k}}")#text(". In particular, simple Lie algebras are automatically perfect and centerless. We have the following fundamental theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Equivalent definitions of semisimplicity)")]#text(" ")#metadata(none) <tao-7c21b8ee84cee675a9cc>#text(" Let ")#mi("{{\\mathfrak g}}")#text(" be a Lie algebra. Then the following are equivalent:")

#list(
[#text("(i) ")#mi("{{\\mathfrak g}}")#text(" does not contain any non-trivial solvable ideal.")],
[#text("(ii) ")#mi("{{\\mathfrak g}}")#text(" does not contain any non-trivial abelian ideal.")],
[#text("(iii) The ")#link("http://en.wikipedia.org/wiki/Killing_form")[#text("Killing form")]#text(" ")#mi("{K: {\\mathfrak g} \\times {\\mathfrak g} \\rightarrow {\\bf C}}")#text(", defined as the bilinear form ")#mi("{K(x,y) := \\text{tr}_{\\mathfrak g}( (\\text{ad} x) (\\text{ad} y) )}")#text(", is non-degenerate on ")#mi("{{\\mathfrak g}}")#text(".")],
[#text("(iv) ")#mi("{{\\mathfrak g}}")#text(" is isomorphic to the direct sum of finitely many non-abelian simple Lie algebras.")]
)
]

#text("We review the proof of this theorem later in these notes. A Lie algebra obeying any (and hence all) of the properties (i)-(iv) is known as a ")#link("http://en.wikipedia.org/wiki/Semisimple_Lie_algebra")[#text("semisimple")]#text(" Lie algebra. The statement (iv) is usually taken as the ")#emph[#text("definition")]#text(" of semisimplicity; the equivalence of (iv) and (i) is a special case of ")#emph[#text("Weyl’s complete reducibility theorem")]#text(" (see Theorem ")#link(<tao-ac9027d6fceb8e369ce6>)[#text("44")]#text("), and the equivalence of (iv) and (iii) is known as the ")#emph[#text("Cartan semisimplicity criterion")]#text(". (The equivalence of (i) and (ii) is easy.)")

#text("If ")#mi("{{\\mathfrak h}}")#text(" and ")#mi("{{\\mathfrak k}}")#text(" are solvable ideals of a Lie algebra ")#mi("{{\\mathfrak g}}")#text(", then it is not difficult to see that the vector sum ")#mi("{{\\mathfrak h}+{\\mathfrak k}}")#text(" is also a solvable ideal (because on quotienting by ")#mi("{{\\mathfrak h}}")#text(" we see that the derived series of ")#mi("{{\\mathfrak h}+{\\mathfrak k}}")#text(" must eventually fall inside ")#mi("{{\\mathfrak h}}")#text(", and thence must eventually become trivial by the solvability of ")#mi("{{\\mathfrak h}}")#text("). As our Lie algebras are finite dimensional, we conclude that ")#mi("{{\\mathfrak g}}")#text(" has a unique maximal solvable ideal, known as the ")#link("http://en.wikipedia.org/wiki/Radical_of_a_Lie_algebra")[#text("radical")]#text(" ")#mi("{\\text{rad} {\\mathfrak g}}")#text(" of ")#mi("{{\\mathfrak g}}")#text(". The quotient ")#mi("{{\\mathfrak g}/\\text{rad} {\\mathfrak g}}")#text(" is then a Lie algebra with trivial radical, and is thus semisimple by the above theorem, giving the ")#link("http://en.wikipedia.org/wiki/Levi_decomposition")[#text("Levi decomposition")]

#align(center)[#tao-fit-display[#mitex("{\\mathfrak g} = \\text{rad} {\\mathfrak g} . ({\\mathfrak g} / \\text{rad} {\\mathfrak g})")]]

#text("expressing an arbitrary Lie algebra as an extension of a semisimple Lie algebra ")#mi("{{\\mathfrak g}/\\text{rad}{\\mathfrak g}}")#text(" by a solvable algebra ")#mi("{\\text{rad} {\\mathfrak g}}")#text(" (and it is not hard to see that this is the only possible such extension up to isomorphism). Indeed, a deep theorem of Levi allows one to upgrade this decomposition to a split extension")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak g} = \\text{rad} {\\mathfrak g} : ({\\mathfrak g} / \\text{rad} {\\mathfrak g})")]]

#text("although we will not need or prove this result here.")

#text("In view of the above decompositions, we see that we can factor any Lie algebra (using a suitable combination of direct sums and extensions) into a finite number of simple Lie algebras and the scalar algebra ")#mi("{{\\bf C}}")#text(". In principle, this means that one can understand an arbitrary Lie algebra once one understands all the simple Lie algebras (which, being defined over ")#mi("{{\\bf C}}")#text(", are somewhat confusingly referred to as ")#emph[#text("simple complex Lie algebras")]#text(" in the literature). Amazingly, this latter class of algebras are completely classified:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Classification of simple Lie algebras)")]#text(" ")#metadata(none) <tao-0889113e04d3203f0c40>#text(" Up to isomorphism, every simple Lie algebra is of one of the following forms:")

#list(
[#mi("{A_n = \\mathfrak{sl}_{n+1}}")#text(" for some ")#mi("{n \\geq 1}")#text(".")],
[#mi("{B_n = \\mathfrak{so}_{2n+1}}")#text(" for some ")#mi("{n \\geq 2}")#text(".")],
[#mi("{C_n = \\mathfrak{sp}_{2n}}")#text(" for some ")#mi("{n \\geq 3}")#text(".")],
[#mi("{D_n = \\mathfrak{so}_{2n}}")#text(" for some ")#mi("{n \\geq 4}")#text(".")],
[#mi("{E_6, E_7}")#text(", or ")#mi("{E_8}")#text(".")],
[#mi("{F_4}")#text(".")],
[#mi("{G_2}")#text(".")]
)

#text("(The precise definition of the ")#link("http://en.wikipedia.org/wiki/Classical_group")[#text("classical Lie algebras")]#text(" ")#mi("{A_n,B_n,C_n,D_n}")#text(" and the exceptional Lie algebras ")#mi("{E_6,E_7,E_8,F_4,G_2}")#text(" will be recalled later.)")
]

#text("(One can extend the families ")#mi("{A_n,B_n,C_n,D_n}")#text(" of classical Lie algebras a little bit to smaller values of ")#mi("{n}")#text(", but the resulting algebras are either isomorphic to other algebras on this list, or cease to be simple; see ")#link("https://terrytao.wordpress.com/2011/03/11/exceptional-isogenies-between-the-classical-lie-groups/")[#text("this previous post")]#text(" for further discussion.)")

#text("This classification is a basic starting point for the classification of many other related objects, including Lie algebras and Lie groups over more general fields (e.g. the reals ")#mi("{{\\bf R}}")#text("), as well as finite simple groups. Being so fundamental to the subject, this classification is covered in almost every basic textbook in Lie algebras, and I myself learned it many years ago in an honours undergraduate course back in Australia. The proof is rather lengthy, though, and I have always had difficulty keeping it straight in my head. So I have decided to write some notes on the classification in this blog post, aiming to be self-contained (though moving rapidly). There is no new material in this post, though; it is all drawn from standard reference texts (I relied particularly on ")#link("http://www.ams.org/mathscinet-getitem?mr=1153249")[#text("Fulton and Harris’s text")]#text(", which I highly recommend). In fact it seems remarkably hard to deviate from the standard routes given in the literature to the classification; I would be interested in knowing about other ways to reach the classification (or substeps in that classification) that are genuinely different from the orthodox route.")

#metadata(none) <tao-8f5ef0d2b3aa8f8fc323>

#heading(level: 1)[#strong[#text(" — 1. Abelian representations — ")]]

#text("One of the key strategies in the classification of a Lie algebra ")#mi("{{\\mathfrak g}}")#text(" is to work with representations of ")#mi("{{\\mathfrak g}}")#text(", particularly the adjoint representation ")#mi("{\\text{ad}: {\\mathfrak g} \\rightarrow \\text{ad} g}")#text(", and then restrict such representations to various simpler subalgebras ")#mi("{{\\mathfrak h}}")#text(" of ")#mi("{{\\mathfrak g}}")#text(", for which the representation theory is well understood. In particular, one aims to exploit the representation theory of ")#emph[#text("abelian")]#text(" algebras (and to a lesser extent, nilpotent and solvable algebras), as well as the fundamental example of the two-dimensional ")#link("http://en.wikipedia.org/wiki/Special_linear_Lie_algebra")[#text("special linear Lie algebra")]#text(" ")#mi("{\\mathfrak{sl}_2}")#text(", which is the smallest and easiest to understand of the simple Lie algebras, and plays an absolutely crucial role in exploring and then classifying all the other simple Lie algebras.")

#text("We begin this program by recording the representation theory of abelian Lie algebras. We begin with representations ")#mi("{\\rho: {\\bf C} \\rightarrow {\\mathfrak{gl}}(V)}")#text(" of the one-dimensional algebra ")#mi("{{\\bf C}}")#text(". Setting ")#mi("{x := \\rho(1)}")#text(", this is essentially the representation theory of a single linear transformation ")#mi("{x: V \\rightarrow V}")#text(". Here, the theory is given by the ")#link("http://en.wikipedia.org/wiki/Jordan%E2%80%93Chevalley_decomposition")[#text("Jordan decomposition")]#text(". Firstly, for each complex number ")#mi("{\\lambda\\in {\\bf C}}")#text(", we can define the ")#link("http://en.wikipedia.org/wiki/Generalized_eigenspace")[#text("generalised eigenspace")]

#align(center)[#tao-fit-display[#mitex("V_\\lambda^x := \\{ v \\in V: (x-\\lambda)^n v = 0 \\text{ for some } n \\}.")]]

#text("One easily verifies that the ")#mi("{V_\\lambda^x}")#text(" are all linearly independent ")#mi("{x}")#text("-invariant subspaces of ")#mi("{V}")#text(", and in particular that there are only finitely many ")#mi("{\\lambda}")#text(" (the ")#emph[#text("spectrum")]#text(" ")#mi("{\\sigma(x)}")#text(" of ")#mi("{x}")#text(") for which ")#mi("{V_\\lambda^x}")#text(" is non-trivial. If one quotients out all the generalised eigenspaces, one can check that the quotiented transformation ")#mi("{x}")#text(" no longer has any spectrum, which contradicts the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_algebra")[#text("fundamental theorem of algebra")]#text(" applied to the ")#link("http://en.wikipedia.org/wiki/Characteristic_polynomial")[#text("characteristic polynomial")]#text(" of this quotiented transformation (or, if is more analytically inclined, one could apply ")#link("http://en.wikipedia.org/wiki/Liouville%27s_theorem_(complex_analysis)")[#text("Liouville’s theorem")]#text(" to the ")#link("http://en.wikipedia.org/wiki/Resolvent_formalism")[#text("resolvent operators")]#text(" to obtain the required contradiction). Thus the generalised eigenspaces span ")#mi("{V}")#text(":")

#align(center)[#tao-fit-display[#mitex("V = \\bigoplus_{\\lambda \\in \\sigma(x)} V_\\lambda^x.")]]

#text("On each space ")#mi("{V_\\lambda^x}")#text(", the operator ")#mi("{x-\\lambda}")#text(" only has spectrum at zero, and thus (again from the fundamental theorem of algebra) has non-trivial kernel; similarly for any ")#mi("{x}")#text("-invariant subspace of ")#mi("{V_\\lambda^x}")#text(", such as the range ")#mi("{(x-\\lambda) V_\\lambda^x}")#text(" of ")#mi("{x-\\lambda}")#text(". Iterating this observation we conclude that ")#mi("{x-\\lambda}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Nilpotent_operator")[#text("nilpotent operator")]#text(" on ")#mi("{V_\\lambda^x}")#text(", thus ")#mi("{(x-\\lambda)^n=0}")#text(" for some ")#mi("{n}")#text(". If we then write ")#mi("{x_{ss}}")#text(" to be the direct sum of the scalar multiplication operators ")#mi("{\\lambda}")#text(" on each generalised eigenspace ")#mi("{V_\\lambda^x}")#text(", and ")#mi("{x_n}")#text(" to be the direct sum of the operators ")#mi("{x-\\lambda}")#text(" on these spaces, we have obtained the ")#link("http://en.wikipedia.org/wiki/Jordan%E2%80%93Chevalley_decomposition")[#text("Jordan decomposition")]#text(" (or ")#emph[#text("Jordan-Chevalley decomposition")]#text(")")

#align(center)[#tao-fit-display[#mitex("x = x_{ss} + x_n")]]

#text("where the operator ")#mi("{x_{ss}: V \\rightarrow V}")#text(" is ")#link("http://en.wikipedia.org/wiki/Semi-simple_operator")[#text("semisimple")]#text(" in the sense that it is a diagonalisable linear transformation on ")#mi("{V}")#text(" (or equivalently, all generalised eigenspaces are actually eigenspaces), and ")#mi("{x_n}")#text(" is nilpotent. Furthermore, as we may use polynomial interpolation to find a polynomial ")#mi("{P: {\\bf C} \\rightarrow {\\bf C}}")#text(" such that ")#mi("{P(z)-\\lambda}")#text(" vanishes to arbitrarily high order at ")#mi("{z=\\lambda}")#text(" for each ")#mi("{\\lambda \\in \\sigma(V)}")#text(" (and also ")#mi("{P(0)=0}")#text("), we see that ")#mi("{x_{ss}}")#text(" (and hence ")#mi("{x_n}")#text(") can be expressed as polynomials in ")#mi("{x}")#text(" with zero constant coefficient; this fact will be important later. In particular, ")#mi("{x_{ss}}")#text(" and ")#mi("{x_n}")#text(" commute.")

#text("Conversely, given an arbitrary linear transformation ")#mi("{x: V \\rightarrow V}")#text(", the Jordan-Chevalley decomposition is the unique decomposition into commuting semisimple and nilpotent elements. Indeed, if we have an alternate decomposition ")#mi("{x = x^{\\prime}_{ss} + x^{\\prime}_n}")#text(" into a semisimple element ")#mi("{x^{\\prime}_{ss}}")#text(" commuting with a nilpotent element ")#mi("{x^{\\prime}_n}")#text(", then the generalised eigenspaces of ")#mi("{x}")#text(" must be preserved by both ")#mi("{x^{\\prime}_{ss}}")#text(" and ")#mi("{x^{\\prime}_n}")#text(", and so without loss of generality we may assume that there is just a single generalised eigenspace ")#mi("{V = V_\\lambda^x}")#text("; subtracting ")#mi("{\\lambda}")#text(" we may then assume that ")#mi("{\\lambda=0}")#text(", but then ")#mi("{x}")#text(" is nilpotent, and so ")#mi("{x^{\\prime}_{ss} = x - x^{\\prime}_n}")#text(" is also nilpotent; but the only transformation which is both semisimple and nilpotent is the zero transformation, and the claim follows.")

#text("From the Jordan-Chevalley decomposition it is not difficult to then place ")#mi("{x}")#text(" in ")#link("http://en.wikipedia.org/wiki/Jordan_normal_form")[#text("Jordan normal form")]#text(" by selecting a suitable basis for ")#mi("{V}")#text("; see e.g. ")#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/")[#text("this previous blog post")]#text(". But in contrast to the Jordan-Chevalley decomposition, the basis is not unique in general, and we will not explicitly use the Jordan normal form in the rest of this post.")

#text("Given an abstract complex vector space ")#mi("{V}")#text(", there is in general no canonical notion of complex conjugation on ")#mi("{V}")#text(", or of linear transformations ")#mi("{x: V \\rightarrow V}")#text(". However, we can define the conjugate ")#mi("{\\overline{x}}")#text(" of any ")#emph[#text("semisimple")]#text(" transformation ")#mi("{x: V \\rightarrow V}")#text(", defined as the direct sum of ")#mi("{\\overline{\\lambda}}")#text(" on each eigenspace ")#mi("{V_\\lambda^x}")#text(" of ")#mi("{x}")#text(". In particular, we can define the conjugate ")#mi("{\\overline{x_{ss}}: V \\rightarrow V}")#text(" of the semisimple component ")#mi("{x_{ss}}")#text(" of an arbitrary linear transformation ")#mi("{x_{ss}}")#text(", which will be the direct sum of ")#mi("{\\overline{\\lambda}}")#text(" on each ")#emph[#text("generalised")]#text(" eigenspace ")#mi("{V_\\lambda^x}")#text(" of ")#mi("{x}")#text(". The significance of this transformation lies in the observation that the product ")#mi("{\\overline{x_{ss}} x}")#text(" has trace ")#tao-math("{\\left|\\lambda\\right|^2 \\text{dim} V_\\lambda^x}", block: false)#text(" on each generalised eigenspace (since nilpotent operators have zero trace), and in particular we see that ")#metadata(none) <tao-9f86d081884c7d659a2f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\text{tr}(\\overline{x_{ss}} x) = 0")]]

#text(" if and only if the spectrum consists only of zero, or equivalently that ")#mi("{x}")#text(" is nilpotent. Thus ")#link(<tao-9f86d081884c7d659a2f>)[#text("(7)")]#text(" provides a test for nilpotency, which will be turn out to be quite useful later in this post. (Note that this trick relies very much on the special structure of ")#mi("{{\\bf C}}")#text(", in particular the fact that it has characteristic zero.)")

#text("In the above arguments we have used the basic fact that if two operators ")#mi("{x: V \\rightarrow V}")#text(" and ")#mi("{y: V \\rightarrow V}")#text(" commute, then the generalised eigenspaces of one operator are preserved by the other. Iterating this fact, we can now start understanding the representations ")#mi("{\\rho: {\\mathfrak h} \\rightarrow {\\mathfrak{gl}}(V)}")#text(" of an abelian Lie algebra. Namely, there is a finite set ")#mi("{\\sigma(\\rho) \\subset {\\mathfrak h}^*}")#text(" of linear functionals (or homomorphisms) ")#mi("{\\lambda: {\\mathfrak h} \\rightarrow {\\bf C}}")#text(" on ")#mi("{{\\mathfrak h}}")#text(" (i.e. elements of the dual space ")#mi("{{\\mathfrak h}^*}")#text(") for which the generalised eigenspaces")

#align(center)[#tao-fit-display[#mitex("V_\\lambda^{\\mathfrak h} := \\{ v \\in V: (\\rho({\\mathfrak h}) - \\lambda)^n v = 0 \\text{ for some } n \\}")]]

#text("are non-trivial and ")#mi("{{\\mathfrak h}}")#text("-invariant, and we have the decomposition")

#align(center)[#tao-fit-display[#mitex("V = \\bigoplus_{\\lambda \\in \\sigma(x)} V_\\lambda^{\\mathfrak h}.")]]

#text("Here we use ")#mi("{(\\rho({\\mathfrak h})-\\lambda)^n v=0}")#text(" as short-hand for writing ")#mi("{(x_1-\\lambda(x_1)) \\ldots (\\rho(x_n)-\\lambda(x_n)) v = 0}")#text(" for all ")#mi("{x_1,\\ldots,x_n \\in {\\mathfrak h}}")#text(". An important special case arises when the action of ")#mi("{{\\mathfrak h}}")#text(" is semisimple in the sense that ")#mi("{\\rho(x)}")#text(" is semisimple for all ")#mi("{x \\in {\\mathfrak h}}")#text(". Then all the generalised eigenspaces are just eigenspaces (or ")#link("http://en.wikipedia.org/wiki/Weight_space#Weight_space_of_a_representation")[#text("weight spaces")]#text(") , thus")

#align(center)[#tao-fit-display[#mitex("\\rho(x) v = \\lambda(x) v")]]

#text("for all ")#mi("{v \\in V_\\lambda^{\\mathfrak h}}")#text(" and ")#mi("{x \\in{\\mathfrak h}}")#text(". When this occurs we call ")#mi("{v}")#text(" a ")#emph[#text("weight vector")]#text(" with weight ")#mi("{\\lambda}")#text(".")

#heading(level: 1)[#strong[#text(" — 2. Engel’s theorem and Lie’s theorem — ")]]

#text("In the introduction we gave the two basic examples of nilpotent and solvable Lie algebras, namely the strictly upper triangular and upper triangular matrices. The theorems ")#link("http://en.wikipedia.org/wiki/Engel%27s_theorem")[#text("of Engel")]#text(" and ")#link("http://en.wikipedia.org/wiki/Lie%27s_theorem#Lie.27s_theorem")[#text("of Lie")]#text(" assert, roughly speaking, that these examples (and subalgebras thereof) are essentially the only type of solvable and nilpotent Lie algebras that can exist, at least in the concrete setting of subalgebras of ")#mi("{{\\mathfrak{gl}}(V)}")#text(". Among other things, these theorems greatly clarify the representation theory of nilpotent and solvable Lie algebras.")

#text("We begin with Engel’s theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Engel’s theorem)")]#text(" Let ")#mi("{{\\mathfrak g} \\subset {\\mathfrak{gl}}(V)}")#text(" be a concrete Lie algebra such that every element ")#mi("{x}")#text(" of ")#mi("{{\\mathfrak g}}")#text(" is nilpotent as a linear transformation on ")#mi("{V}")#text(".")

#list(
[#text("(i) If ")#mi("{V}")#text(" is non-trivial, then there is a non-zero element ")#mi("{v}")#text(" of ")#mi("{V}")#text(" which is annihilated by every element of ")#mi("{{\\mathfrak g}}")#text(".")],
[#text("(ii) There is a basis of ")#mi("{V}")#text(" for which all elements of ")#mi("{{\\mathfrak g}}")#text(" are strictly upper triangular. In particular, ")#mi("{{\\mathfrak g}}")#text(" is nilpotent.")]
)
]

#emph[#text("Proof:")]#text(" We begin with (i). We induct on the dimension of ")#mi("{{\\mathfrak g}}")#text(". The claim is trivial for dimensions ")#mi("{0}")#text(" and ")#mi("{1}")#text(", so suppose that ")#mi("{{\\mathfrak g}}")#text(" has dimension greater than ")#mi("{1}")#text(", and that the claim is already proven for smaller dimensions.")

#text("Let ")#mi("{{\\mathfrak h}}")#text(" be a maximal proper subalgebra of ")#mi("{{\\mathfrak g}}")#text(", then ")#mi("{{\\mathfrak h}}")#text(" has dimension strictly between zero and ")#mi("{\\text{dim} \\mathfrak{g}}")#text(" (since all one-dimensional subspaces are proper subalgebras). Observe that for every ")#mi("{x \\in {\\mathfrak h}}")#text(", ")#mi("{\\text{ad} x}")#text(" acts on both the vector spaces ")#mi("{{\\mathfrak g}}")#text(" and ")#mi("{{\\mathfrak h}}")#text(" and thus also on the quotient space ")#mi("{{\\mathfrak g}/{\\mathfrak h}}")#text(". As ")#mi("{x}")#text(" is nilpotent, all of these actions are nilpotent also. In particular, by induction hypothesis, there is ")#mi("{v \\in {\\mathfrak g}/{\\mathfrak h}}")#text(" which is annihilated by ")#mi("{\\text{ad} x}")#text(" for all ")#mi("{x \\in {\\mathfrak h}}")#text(". Let ")#mi("{w}")#text(" be a representative of ")#mi("{v}")#text(" in ")#mi("{{\\mathfrak g}}")#text(", then ")#mi("{[w, {\\mathfrak h}] \\subset {\\mathfrak h}}")#text(", and so ")#mi("{\\text{span}(w, {\\mathfrak h})}")#text(" is a subalgebra and is thus all of ")#mi("{{\\mathfrak g}}")#text(".")

#text("By induction hypothesis again, the space ")#mi("{W}")#text(" of vectors in ")#mi("{V}")#text(" annihilated by ")#mi("{{\\mathfrak h}}")#text(" is non-trivial; as ")#mi("{[w, {\\mathfrak h}] \\subset {\\mathfrak h}}")#text(", it is preserved by ")#mi("{w}")#text(". As ")#mi("{w}")#text(" is nilpotent, there is a non-trivial element of ")#mi("{W}")#text(" annihilated by ")#mi("{w}")#text(" and hence by ")#mi("{{\\mathfrak g}}")#text(", as required.")

#text("Now we prove (ii). We induct on the dimension of ")#mi("{V}")#text(". The case of dimension zero is trivial, so suppose ")#mi("{V}")#text(" has dimension at least one, and the claim has already been proven for dimension ")#mi("{\\text{dim}(V)-1}")#text(". By (i), we may find a non-trivial vector ")#mi("{v}")#text(" annihilated by ")#mi("{{\\mathfrak g}}")#text(", and so we may project ")#mi("{{\\mathfrak g}}")#text(" down to ")#mi("{{\\mathfrak{gl}}(V / \\text{span}(v))}")#text(". By the induction hypothesis, there is a basis for ")#mi("{V/\\text{span}(v)}")#text(" on which the projection of any element of ")#mi("{{\\mathfrak g}}")#text(" is strictly upper-triangular; pulling this basis back to ")#mi("{V}")#text(" and adjoining ")#mi("{v}")#text(", we obtain the claim. ")#mi("\\Box")

#text("As a corollary of this theorem and the short exact sequence ")#link(<tao-8cb6279a8e1b12a96774>)[#text("(6)")]#text(" we see that an abstract Lie algebra ")#mi("{{\\mathfrak g}}")#text(" is nilpotent iff ")#mi("{\\text{ad} {\\mathfrak g}}")#text(" is nilpotent iff ")#mi("{\\text{ad} x}")#text(" is nilpotent in ")#mi("{{\\mathfrak g}}")#text(" for every ")#mi("{x \\in {\\mathfrak g}}")#text(" (i.e. every element of ")#mi("{{\\mathfrak g}}")#text(" is ")#emph[#text("ad-nilpotent")]#text(").")

#text("Engel’s theorem is in fact valid over every field. The analogous theorem of Lie for solvable algebras, however, relies much more strongly on the specific properties of the complex field ")#mi("{{\\bf C}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Lie’s theorem)")]#text(" Let ")#mi("{{\\mathfrak g} \\subset {\\mathfrak{gl}}(V)}")#text(" be a solvable concrete Lie algebra.")

#list(
[#text("(i) If ")#mi("{V}")#text(" is non-trivial, there exists a non-zero element ")#mi("{v}")#text(" of ")#mi("{V}")#text(" which is an eigenvector for every element of ")#mi("{{\\mathfrak g}}")#text(".")],
[#text("(ii) There is a basis for ")#mi("{V}")#text(" such that every element of ")#mi("{{\\mathfrak g}}")#text(" is upper triangular.")]
)
]

#text("Note that if one specialises Lie’s theorem to abelian ")#mi("{{\\mathfrak g}}")#text(" then one essentially recovers the abelian theory of the previous section.")

#emph[#text("Proof:")]#text(" We prove (i). As before we induct on the dimension of ")#mi("{{\\mathfrak g}}")#text(". The dimension zero case is trivial, so suppose that ")#mi("{{\\mathfrak g}}")#text(" has dimension at least one and that the claim has been proven for smaller dimensions.")

#text("Let ")#mi("{{\\mathfrak h}}")#text(" be a codimension one subalgebra of ")#mi("{{\\mathfrak g}}")#text("; such an algebra can be formed by taking a codimension one subspace of the abelianisation ")#mi("{{\\mathfrak g}/[{\\mathfrak g}, {\\mathfrak g}]}")#text(" (which has dimension at least one, else ")#mi("{{\\mathfrak g}}")#text(" will not be solvable) and then pulling back to ")#mi("{{\\mathfrak g}}")#text(". Note that ")#mi("{{\\mathfrak h}}")#text(" is automatically an ideal.")

#text("By induction, there is a non-zero element ")#mi("{v}")#text(" of ")#mi("{V}")#text(" such that every element of ")#mi("{{\\mathfrak h}}")#text(" has ")#mi("{v}")#text(" as an eigenvector, thus we have")

#align(center)[#tao-fit-display[#mitex("xv = \\lambda(x) v")]]

#text("for all ")#mi("{x \\in {\\mathfrak h}}")#text(" and some linear functional ")#mi("{\\lambda: {\\mathfrak h} \\rightarrow {\\bf C}}")#text(". If we then set ")#mi("{W = V_\\lambda^{\\mathfrak h}}")#text(" to be the simultaneous eigenspace")

#align(center)[#tao-fit-display[#mitex("W := \\{ w \\in V: xv = \\lambda(x) v \\text{ for all } x \\in {\\mathfrak h} \\}")]]

#text("then ")#mi("{W}")#text(" is a non-trivial subspace of ")#mi("{V}")#text(".")

#text("Let ")#mi("{y}")#text(" be an element of ")#mi("{{\\mathfrak g}}")#text(" that is not in ")#mi("{{\\mathfrak h}}")#text(", and let ")#mi("{w \\in W}")#text(". Consider the space spanned by the orbit ")#mi("{w, yw, y^2 w, \\ldots}")#text(". By finite dimensionality, this space has a basis ")#mi("{w, yw, y^2 w, \\ldots, y^{n-1} w}")#text(" for some ")#mi("{n}")#text(". By induction and definition of ")#mi("{W}")#text(", we see that every ")#mi("{x \\in {\\mathfrak h}}")#text(" acts on this space by an upper-triangular matrix with diagonal entries ")#mi("{\\lambda(x)}")#text(" in this basis. Of course, ")#mi("{y}")#text(" acts on this space as well, and so ")#mi("{[x,y]}")#text(" has trace zero on this space, thus ")#mi("{n \\lambda([x,y]) = 0}")#text(" and so ")#mi("{\\lambda([x,y])=0}")#text(" (here we use the characteristic zero nature of ")#mi("{{\\bf C}}")#text("). From this we see that ")#mi("{y}")#text(" fixes ")#mi("{W}")#text(". If we let ")#mi("{v^{\\prime}}")#text(" be an eigenvector of ")#mi("{y}")#text(" on ")#mi("{W}")#text(" (which exists from the Jordan decomposition of ")#mi("{y}")#text("), we conclude that ")#mi("{v^{\\prime}}")#text(" is a simultaneous eigenvector of ")#mi("{{\\mathfrak g}}")#text(" as required.")

#text("The claim (ii) follows from (i) much as in Engel’s theorem. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 3. Characterising semisimplicity — ")]]

#text("The objective of this section will be to prove Theorem ")#link(<tao-7c21b8ee84cee675a9cc>)[#text("1")]#text(".")

#text("Let ")#mi("{{\\mathfrak g} \\subset {\\mathfrak{gl}}(V)}")#text(" be an concrete Lie algebra, and ")#mi("{x}")#text(" be an element of ")#mi("{{\\mathfrak g}}")#text(". Then the components ")#mi("{x_{ss}, x_n: V \\rightarrow V}")#text(" of ")#mi("{x}")#text(" need not lie in ")#mi("{{\\mathfrak g}}")#text(". However they behave “as if” they lie in ")#mi("{{\\mathfrak g}}")#text(" for the purposes of taking Lie brackets, in the following sense:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5")]#text(" ")#metadata(none) <tao-a1d9890884c1b4b960c2>#text(" Let ")#mi("{{\\mathfrak g} \\subset {\\mathfrak{gl}}(V)}")#text(" and let ")#mi("{x \\in {\\mathfrak g}}")#text(" have Jordan decomposition ")#mi("{x = x_{ss} + x_n}")#text(". Then ")#mi("{[x_{ss},{\\mathfrak g}] \\subset [{\\mathfrak g},{\\mathfrak g}]}")#text(", ")#mi("{[\\overline{x_{ss}},{\\mathfrak g}] \\subset [{\\mathfrak g},{\\mathfrak g}]}")#text(" and ")#mi("{[x_n,{\\mathfrak g}] \\subset [{\\mathfrak g},{\\mathfrak g}]}")#text(".")
]

#emph[#text("Proof:")]#text(" As ")#mi("{x_{ss}}")#text(" and ")#mi("{x_n}")#text(" are semisimple and nilpotent on ")#mi("{V}")#text(" and commute with each other, ")#mi("{\\text{ad} x_{ss}}")#text(" and ")#mi("{\\text{ad} x_n}")#text(" are semisimple and nilpotent on ")#mi("{{\\mathfrak{gl}}(V)}")#text(" and also commute with each other (this can for instance by using Lie’s theorem (or the Jordan normal form) to place ")#mi("{x}")#text(" in upper triangular form and computing everything explicitly). Thus ")#mi("{\\text{ad} x = \\text{ad} x_{ss} + \\text{ad} x_n}")#text(" is the Jordan-Chevalley decomposition of ")#mi("{\\text{ad} x}")#text(", and in particular ")#mi("{\\text{ad} x_{ss} = Q(\\text{ad} x)}")#text(" for some polynomial ")#mi("{Q}")#text(" with zero constant coefficient. Since ")#mi("{\\text{ad} x}")#text(" maps ")#mi("{{\\mathfrak g}}")#text(" to the subalgebra ")#mi("{[{\\mathfrak g},{\\mathfrak g}]}")#text(", we conclude that ")#mi("{\\text{ad} x_{ss} = Q(\\text{ad} x)}")#text(" does also, thus ")#mi("{[x_{ss}, {\\mathfrak g}] \\subset [{\\mathfrak g},{\\mathfrak g}]}")#text(" as required. Similarly for ")#mi("{\\overline{x_{ss}}}")#text(" and ")#mi("{x_n}")#text(" (note that ")#mi("{\\text{ad} \\overline{x_{ss}} = \\overline{ \\text{ad} x_{ss} }}")#text("). ")#mi("\\Box")

#text("We can now use this (together with Engel’s theorem and the test ")#link(<tao-9f86d081884c7d659a2f>)[#text("(7)")]#text(" for nilpotency) to obtain a part of Theorem ")#link(<tao-7c21b8ee84cee675a9cc>)[#text("1")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6")]#text(" ")#metadata(none) <tao-0510eddd781102030eb8>#text(" Let ")#mi("{{\\mathfrak g}}")#text(" be a simple Lie algebra. Then the Killing form ")#mi("{K}")#text(" is non-degenerate.")
]

#emph[#text("Proof:")]#text(" As ")#mi("{{\\mathfrak g}}")#text(" is simple, its center ")#mi("{Z({\\mathfrak g})}")#text(" is trivial, so by ")#link(<tao-8cb6279a8e1b12a96774>)[#text("(6)")]#text(" ")#mi("{{\\mathfrak g}}")#text(" is isomorphic to ")#mi("{\\text{ad} {\\mathfrak g}}")#text(". In particular we may assume that ")#mi("{{\\mathfrak g}}")#text(" is a concrete Lie algebra, thus ")#mi("{{\\mathfrak g} \\subset {\\mathfrak{gl}}(V)}")#text(" for some vector space ")#mi("{V}")#text(".")

#text("Suppose for contradiction that ")#mi("{K}")#text(" is degenerate. Using the skew-adjointness identity")

#align(center)[#tao-fit-display[#mitex("K( [z,x], y ) = - K( x, [z,y] )")]]

#text("for all ")#mi("{x,y,z \\in {\\mathfrak g}}")#text(" (which comes from the cyclic properties of trace), we see that the kernel ")#mi("{\\{ x \\in {\\mathfrak g}: K(x,y)=0 \\text{ for all } y \\in {\\mathfrak g} \\}}")#text(" is a non-trivial ideal of ")#mi("{{\\mathfrak g}}")#text(", and is thus all of ")#mi("{{\\mathfrak g}}")#text(" as ")#mi("{{\\mathfrak g}}")#text(" is simple. Thus ")#mi("{K(x,y)=0}")#text(" for all ")#mi("{x, y \\in {\\mathfrak g}}")#text(".")

#text("Now let ")#mi("{x,y,z \\in {\\mathfrak g}}")#text(". By Lemma ")#link(<tao-a1d9890884c1b4b960c2>)[#text("5")]#text(", ")#mi("{\\overline{x_{ss}}}")#text(" acts by Lie bracket on ")#mi("{{\\mathfrak g}}")#text(" and so one can define ")#mi("{\\text{ad} \\overline{x_{ss}} \\in {\\mathfrak{gl}}({\\mathfrak g})}")#text(". We now consider the quantity")

#align(center)[#tao-fit-display[#mitex("\\text{tr}_{\\mathfrak g} (\\text{ad} \\overline{x_{ss}}) (\\text{ad} [y,z]).")]]

#text("We can rearrange this as")

#align(center)[#tao-fit-display[#mitex("\\text{tr}_{\\mathfrak g} (\\text{ad} [y,\\overline{x_{ss}}]) (\\text{ad} z).")]]

#text("By Lemma ")#link(<tao-a1d9890884c1b4b960c2>)[#text("5")]#text(", ")#mi("{[y,\\overline{x_{ss}}] \\in {\\mathfrak g}}")#text(", so this is equal to")

#align(center)[#tao-fit-display[#mitex("K( [y,\\overline{x_{ss}}], z ) = 0,")]]

#text("and so")

#align(center)[#tao-fit-display[#mitex("\\text{tr}_{\\mathfrak g} (\\text{ad} \\overline{x_{ss}}) (\\text{ad} w) = 0")]]

#text("for all ")#mi("{w \\in [{\\mathfrak g},{\\mathfrak g}]}")#text(". On the other hand, ")#mi("{[{\\mathfrak g},{\\mathfrak g}]}")#text(" is an ideal of ")#mi("{{\\mathfrak g}}")#text("; as ")#mi("{{\\mathfrak g}}")#text(" is simple, we must thus have ")#mi("{{\\mathfrak g} = [{\\mathfrak g},{\\mathfrak g}]}")#text(" (i.e. ")#mi("{{\\mathfrak g}}")#text(" is perfect). As ")#mi("{x \\in {\\mathfrak g}}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\text{tr}_{\\mathfrak g} (\\text{ad} \\overline{x_{ss}}) (\\text{ad} x) = 0.")]]

#text("From ")#link(<tao-9f86d081884c7d659a2f>)[#text("(7)")]#text(" we conclude that ")#mi("{\\text{ad} x}")#text(" is nilpotent for every ")#mi("{x}")#text(". By Engel’s theorem, this implies that ")#mi("{\\text{ad} {\\mathfrak g}}")#text(", and hence ")#mi("{{\\mathfrak g}}")#text(", is nilpotent; but ")#mi("{{\\mathfrak g}}")#text(" is simple, giving the desired contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 7")]#text(" ")#metadata(none) <tao-9294ab38039f60d2ec53>#text(" Let ")#mi("{{\\mathfrak h}}")#text(" be a simple ideal of a Lie algebra ")#mi("{{\\mathfrak g}}")#text(". Then ")#mi("{{\\mathfrak h}}")#text(" is complemented by another ideal ")#mi("{{\\mathfrak k}}")#text(" of ")#mi("{{\\mathfrak g}}")#text(" (thus ")#mi("{{\\mathfrak h} \\cap {\\mathfrak k} = \\{0\\}}")#text(" and ")#mi("{{\\mathfrak h} + {\\mathfrak k} = {\\mathfrak g}}")#text("), with ")#mi("{{\\mathfrak g}}")#text(" isomorphic to the direct sum ")#mi("{{\\mathfrak h} \\oplus {\\mathfrak k}}")#text(".")
]

#emph[#text("Proof:")]#text(" The adjoint action of ")#mi("{{\\mathfrak g}}")#text(" restricts to the ideal ")#mi("{{\\mathfrak h}}")#text(" and gives a restricted Killing form")

#align(center)[#tao-fit-display[#mitex("K_\\mathfrak{h}(x,y) := \\text{tr}_\\mathfrak{h}( (\\text{ad} x) (\\text{ad} y) ).")]]

#text("By Proposition ")#link(<tao-0510eddd781102030eb8>)[#text("6")]#text(", this bilinear form is non-degenerate on ")#mi("{{\\mathfrak h}}")#text(", so the orthogonal complement")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak k} := {\\mathfrak h}^\\perp = \\{ x \\in {\\mathfrak g}: K_\\mathfrak{h}(x,y) = 0\\text{ for all } y \\in {\\mathfrak h} \\}")]]

#text("is a complementary subspace to ")#mi("{{\\mathfrak h}}")#text(". It can be verified to also be an ideal. Since ")#mi("{[{\\mathfrak h},{\\mathfrak k}]}")#text(" lies in both ")#mi("{{\\mathfrak h}}")#text(" and ")#mi("{{\\mathfrak k}}")#text(", we see that ")#mi("{[{\\mathfrak h},{\\mathfrak k}]=0}")#text(", and so ")#mi("{{\\mathfrak g}}")#text(" is isomorphic to ")#mi("{{\\mathfrak h} \\oplus {\\mathfrak k}}")#text(" as claimed. ")#mi("\\Box")

#text("Now we can prove Theorem ")#link(<tao-7c21b8ee84cee675a9cc>)[#text("1")]#text(". We first observe that (i) trivially implies (ii); conversely, if ")#mi("{{\\mathfrak g}}")#text(" has a non-trivial solvable ideal ")#mi("{{\\mathfrak h}}")#text(", then every element of the derived series of ")#mi("{{\\mathfrak h}}")#text(" is also an ideal of ")#mi("{{\\mathfrak g}}")#text(", and in particular ")#mi("{{\\mathfrak g}}")#text(" will have a non-trivial abelian ideal. Thus (i) and (ii) are equivalent.")

#text("Now we show that (i) implies (iv), which we do by induction on the dimension of ")#mi("{{\\mathfrak g}}")#text(". Of course we may assume ")#mi("{{\\mathfrak g}}")#text(" is non-trivial. Let ")#mi("{{\\mathfrak h}}")#text(" be a non-trivial ideal of ")#mi("{{\\mathfrak g}}")#text(" of minimal dimension. If ")#mi("{{\\mathfrak h} = {\\mathfrak g}}")#text(" then ")#mi("{{\\mathfrak g}}")#text(" is simple (note that it cannot be abelian as ")#mi("{{\\mathfrak g}}")#text(" is non-trivial and semisimple) and we are done. If ")#mi("{{\\mathfrak h}}")#text(" is strictly smaller than ")#mi("{{\\mathfrak g}}")#text(", then it also has no non-trivial solvable ideals (because the radical of ")#mi("{{\\mathfrak h}}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Characteristic_subgroup")[#text("characteristic")]#text(" subalgebra of ")#mi("{{\\mathfrak h}}")#text(" and is thus an ideal in ")#mi("{{\\mathfrak g}}")#text(") and so by induction is isomorphic to the direct sum of simple Lie algebras; as ")#mi("{{\\mathfrak h}}")#text(" was minimal, we conclude that ")#mi("{{\\mathfrak h}}")#text(" is itself simple. By Corollary ")#link(<tao-9294ab38039f60d2ec53>)[#text("7")]#text(", ")#mi("{{\\mathfrak g}}")#text(" then splits as the direct sum of ")#mi("{{\\mathfrak h}}")#text(" and a semisimple Lie algebra of strictly smaller dimension, and the claim follows from the induction hypothesis.")

#text("From Proposition ")#link(<tao-0510eddd781102030eb8>)[#text("6")]#text(" we see that (iv) implies (iii), so to finish the proof of Theorem ")#link(<tao-7c21b8ee84cee675a9cc>)[#text("1")]#text(" it suffices to show that (iii) implies (ii). Indeed, if ")#mi("{{\\mathfrak g}}")#text(" has a non-trivial abelian ideal ")#mi("{{\\mathfrak h}}")#text(", then for any ")#mi("{x \\in {\\mathfrak g}}")#text(" and ")#mi("{y \\in {\\mathfrak h}}")#text(", ")#mi("{\\text{ad} x \\text{ad} y}")#text(" annihilates ")#mi("{{\\mathfrak h}}")#text(" and also has range in ")#mi("{{\\mathfrak h}}")#text(", hence has trace zero, so ")#mi("{{\\mathfrak h}}")#text(" is ")#mi("{K}")#text("-orthogonal to ")#mi("{{\\mathfrak g}}")#text(", giving the degeneracy of the Killing form.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" Similar methods also give the ")#emph[#text("Cartan solvability criterion")]#text(": a Lie algebra ")#mi("{{\\mathfrak g}}")#text(" is solvable if and only if ")#mi("{{\\mathfrak g}}")#text(" is orthogonal to ")#mi("{[{\\mathfrak g},{\\mathfrak g}]}")#text(" with respect to the Killing form. Indeed, the “only if” part follows easily from Lie’s theorem, while for the “if” part one can adapt the proof of Proposition ")#link(<tao-0510eddd781102030eb8>)[#text("6")]#text(" to show that if ")#mi("{{\\mathfrak g}}")#text(" is orthogonal to ")#mi("{[{\\mathfrak g},{\\mathfrak g}]}")#text(", then every element of ")#mi("{\\text{ad} [{\\mathfrak g},{\\mathfrak g}]}")#text(" is nilpotent, hence by Engel’s theorem ")#mi("{\\text{ad} [{\\mathfrak g},{\\mathfrak g}]}")#text(" is nilpotent, and so from the short exact sequence ")#link(<tao-8cb6279a8e1b12a96774>)[#text("(6)")]#text(" we see that ")#mi("{[{\\mathfrak g},{\\mathfrak g}]}")#text(" is nilpotent, and hence ")#mi("{{\\mathfrak g}}")#text(" is solvable.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" The decomposition of a semisimple Lie algebra as the direct sum of simple Lie algebras is unique up to isomorphism and permutation. Indeed, suppose that ")#mi("{\\bigoplus_{i=1}^n {\\mathfrak g}_i}")#text(" is isomorphic to ")#mi("{\\bigoplus_{j=1}^{n^{\\prime}} {\\mathfrak g}^{\\prime}_j}")#text(" for some simple ")#mi("{{\\mathfrak g}_i, {\\mathfrak g}^{\\prime}_j}")#text(". We project each ")#mi("{{\\mathfrak g}^{\\prime}_j}")#text(" to ")#mi("{{\\mathfrak g}_i}")#text(" and observe from simplicity that these projections must either be zero or isomorphisms (cf. ")#link("http://en.wikipedia.org/wiki/Schur%27s_lemma")[#text("Schur’s lemma")]#text("). For fixed ")#mi("{i}")#text(", there must be at least one ")#mi("{j}")#text(" for which the projection is an isomorphism (otherwise ")#mi("{\\bigoplus_{j=1}^{n^{\\prime}} {\\mathfrak g}^{\\prime}_j}")#text(" could not generate all of ")#mi("{\\bigoplus_{i=1}^n {\\mathfrak g}_i}")#text("); on the other hand, as any two ")#mi("{{\\mathfrak g}^{\\prime}_j}")#text(" commute with each other in the direct sum, and ")#mi("{{\\mathfrak g}_i}")#text(" is nonabelian, there is at most one ")#mi("{j}")#text(" for which the projection is an isomorphism. This gives the required identification of the ")#mi("{{\\mathfrak g}_i}")#text(" and ")#mi("{{\\mathfrak g}^{\\prime}_j}")#text(" up to isomorphism and permutation.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" One can also establish complete reducibility by using the ")#link("http://en.wikipedia.org/wiki/Unitarian_trick")[#text("Weyl unitary trick")]#text(", in which one first creates a real compact Lie group whose Lie algebra is a real form of the complex Lie algebra being studied, and then uses the complete reducibility of actions of compact groups. This also gives an alternate way to establish Theorem ")#link(<tao-ac9027d6fceb8e369ce6>)[#text("44")]#text(" in the appendix.")
]

#text("Semisimple Lie algebras have a number of important non-degeneracy properties. For instance, they have no non-trivial outer automorphisms (at the infinitesimal level, at least):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11")]#text(" ")#metadata(none) <tao-9dfbc63747c6ec4e8d43>#text(" Let ")#mi("{{\\mathfrak g}}")#text(" be a semisimple Lie algebra. Then every derivation ")#mi("{D \\in \\text{Der} {\\mathfrak g}}")#text(" on ")#mi("{{\\mathfrak g}}")#text(" is inner, thus ")#mi("{D = \\text{ad} x}")#text(" for some ")#mi("{x \\in {\\mathfrak g}}")#text(".")
]

#emph[#text("Proof:")]#text(" From the identity ")#mi("{[D, \\text{ad} x] = \\text{ad} Dx}")#text(" we see that ")#mi("{\\text{ad} g}")#text(" is an ideal in ")#mi("{\\text{Der} {\\mathfrak g}}")#text(". The trace form ")#mi("{(D_1,D_2) \\mapsto \\text{tr}(D_1 D_2)}")#text(" on ")#mi("{\\text{Der} {\\mathfrak g}}")#text(" restricts to the Killing form on ")#mi("{\\text{ad}({\\mathfrak g})}")#text(", which is non-degenerate.")

#text("Suppose for contradiction that ")#mi("{\\text{ad}({\\mathfrak g})}")#text(" is not all of ")#mi("{\\text{Der}({\\mathfrak g})}")#text(", then there is a non-trivial derivation ")#mi("{D}")#text(" which is trace-form orthogonal to ")#mi("{\\text{ad}({\\mathfrak g})}")#text(", thus ")#mi("{D}")#text(" is trace-orthogonal to ")#mi("{[\\text{ad} x, \\text{ad} y]}")#text(" for all ")#mi("{x,y \\in {\\mathfrak g}}")#text(", so that ")#mi("{[D, \\text{ad} x] = \\text{ad} {Dx}}")#text(" is trace-orthogonal to ")#mi("{\\text{ad} y}")#text(" for all ")#mi("{x,y \\in {\\mathfrak g}}")#text(". As ")#mi("{K}")#text(" is non-degenerate, we conclude that ")#mi("{Dx=0}")#text(" for all ")#mi("{x}")#text(", and so ")#mi("{D}")#text(" is trivial, a contradiction. ")#mi("\\Box")

#text("This fact, combined with the complete reducibility of ")#mi("{{\\mathfrak g}}")#text("-modules (a fact which we will prove in an appendix) implies that the Jordan decomposition preserves concrete semisimple Lie algebras:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 12")]#text(" ")#metadata(none) <tao-77cf6a9be9777b7893fe>#text(" Let ")#mi("{{\\mathfrak g} \\subset {\\mathfrak{gl}}(V)}")#text(" be a concrete semisimple Lie algebra, and let ")#mi("{x \\in {\\mathfrak g}}")#text(". Then ")#mi("{x_{ss}, x_n, \\overline{x}_{ss}}")#text(" also lie in ")#mi("{{\\mathfrak g}}")#text(".")
]

#emph[#text("Proof:")]#text(" By Theorem ")#link(<tao-7c21b8ee84cee675a9cc>)[#text("1")]#text(", ")#mi("{{\\mathfrak g}}")#text(" is the direct sum of commuting simple algebras. It is easy to see that if ")#mi("{x,y}")#text(" commute then the Jordan decomposition of ")#mi("{x+y}")#text(" arises from the sum of the Jordan decompositions of ")#mi("{x}")#text(" and ")#mi("{y}")#text(" separately, so we may assume without loss of generality that ")#mi("{{\\mathfrak g}}")#text(" is simple.")

#text("Observe that if ")#mi("{V}")#text(" splits as the direct sum ")#mi("{V = V_1 \\oplus V_2}")#text(" of two ")#mi("{{\\mathfrak g}}")#text("-invariant subspaces (so that ")#mi("{{\\mathfrak g}}")#text(" can be viewed as a subalgebra of ")#mi("{{\\mathfrak{gl}}(V_1) \\oplus {\\mathfrak{gl}}(V_2)}")#text(", and the elements of ")#mi("{x}")#text(" can be viewed as being block-diagonal in a suitable basis of ")#mi("{V_1,V_2}")#text("), then the claim for ")#mi("{V}")#text(" follows from that of ")#mi("{V_1}")#text(" and ")#mi("{V_2}")#text(". So by an induction on dimension, it suffices to establish the claim under the hypothesis that ")#mi("{V}")#text(" is ")#link("http://en.wikipedia.org/wiki/Indecomposable_module")[#text("indecomposable")]#text(", in that it cannot be expressed as the direct sum of two non-trivial invariant subspaces.")

#text("In the appendix we will show that every invariant subspace ")#mi("{W}")#text(" of ")#mi("{V}")#text(" is ")#emph[#text("complemented")]#text(" in that one can write ")#mi("{V = W \\oplus W^{\\prime}}")#text(" for some invariant subspace ")#mi("{W^{\\prime}}")#text(". Assuming this fact, it suffices to establish the claim in the case that ")#mi("{V}")#text(" is ")#emph[#text("irreducible")]#text(", in the sense that it contains no proper invariant subspaces.")

#text("By Lemma ")#link(<tao-9294ab38039f60d2ec53>)[#text("7")]#text(", the operation ")#mi("{y \\mapsto [x_{ss}, y]}")#text(" is a derivation on ")#mi("{{\\mathfrak g}}")#text(", thus there exists ")#mi("{a \\in {\\mathfrak g}}")#text(" such that ")#mi("{[x_{ss},y] = (\\text{ad} a) y}")#text(" for all ")#mi("{y \\in {\\mathfrak g}}")#text(", thus ")#mi("{x_{ss}-a \\in {\\mathfrak{gl}}(V)}")#text(" centralises ")#mi("{{\\mathfrak g}}")#text(". By ")#link("http://en.wikipedia.org/wiki/Schur%27s_lemma")[#text("Schur’s lemma")]#text(" and the hypothesis of irreducibility, we conclude that ")#mi("{x_{ss}-a}")#text(" is a multiple of a constant ")#mi("{\\lambda}")#text(". Onthe other hand, every element of ")#mi("{{\\mathfrak g}}")#text(" has trace zero since ")#mi("{{\\mathfrak g} = [{\\mathfrak g},{\\mathfrak g}]}")#text("; in particular, ")#mi("{a}")#text(" and ")#mi("{x}")#text(" have trace zero, and so ")#mi("{x_{ss}-a}")#text(" has trace zero. But this trace is just ")#mi("{\\lambda\\text{dim} W}")#text(", so we conclude that ")#mi("{x_{ss}-a = \\lambda = 0}")#text(" and the claim follows for ")#mi("{x_{ss}}")#text(". Similarly for ")#mi("{x_n}")#text(" and ")#mi("{\\overline{x}_{ss}}")#text(". ")#mi("\\Box")

#text("This allows us to make the Jordan decomposition universal for semisimple algebras:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 13 (Semisimple Jordan decomposition)")]#text(" ")#metadata(none) <tao-120a7973926846f70822>#text(" Let ")#mi("{{\\mathfrak g}}")#text(" be a semisimple Lie algebra, and let ")#mi("{x \\in {\\mathfrak g}}")#text(". Then we have a unique decomposition ")#mi("{x = x_{ss} + x_n}")#text(" in ")#mi("{{\\mathfrak g}}")#text(" such that ")#mi("{\\rho(x_{ss}) = (\\rho(x))_{ss}}")#text(" and ")#mi("{\\rho(x_n) = (\\rho(x))_n}")#text(" for every representation ")#mi("{\\rho}")#text(" of ")#mi("{{\\mathfrak g}}")#text(".")
]

#emph[#text("Proof:")]#text(" As the adjoint representation is faithful we may assume without loss of generality that ")#mi("{{\\mathfrak g}}")#text(" is a concrete algebra, thus ")#mi("{{\\mathfrak g} \\subset {\\mathfrak{gl}}(V)}")#text(". The uniqueness is then clear by taking ")#mi("{\\rho}")#text(" to be the identity. To obtain existence, we take ")#mi("{x_{ss}, x_n}")#text(" to be the concrete Jordan decomposition. We need to verify ")#mi("{\\rho(x_{ss}) = (\\rho(x))_{ss}}")#text(" and ")#mi("{\\rho(x_n) = (\\rho(x))_n}")#text(" for any representation ")#mi("{\\rho: {\\mathfrak g} \\rightarrow {\\mathfrak m}}")#text(". The adjoint actions of ")#mi("{\\rho(x_{ss})}")#text(" and ")#mi("{\\rho(x_n)}")#text(" on ")#mi("{\\rho({\\mathfrak g})}")#text(" commute and are semisimple and nilpotent respectively and so")

#align(center)[#tao-fit-display[#mitex("\\text{ad} \\rho(x_{ss}) = (\\text{ad} \\rho(x))_{ss}; \\quad \\text{ad} \\rho(x_{n}) = (\\text{ad} \\rho(x))_{n}")]]

#text("in ")#mi("{\\text{ad} \\rho(g)}")#text(" (cf. the proof of Lemma ")#link(<tao-a1d9890884c1b4b960c2>)[#text("5")]#text("). A similar argument (applying Corollary ")#link(<tao-77cf6a9be9777b7893fe>)[#text("12")]#text(" to ")#mi("{\\rho(g)}")#text(", which is isomorphic to a quotient of ")#mi("{{\\mathfrak g}}")#text(" and is thus semisimple, to keep ")#mi("{\\rho(x)_{ss}, \\rho(x)_n}")#text(" in ")#mi("{\\rho({\\mathfrak g})}")#text(") gives")

#align(center)[#tao-fit-display[#mitex("\\text{ad} (\\rho(x)_{ss}) = (\\text{ad} \\rho(x))_{ss}; \\quad \\text{ad}(\\rho(x)_{n}) = (\\text{ad} \\rho(x))_{n}.")]]

#text("Since the adjoint representation of the semisimple algebra ")#mi("{\\rho({\\mathfrak g})}")#text(" is faithful, the claim follows. ")#mi("\\Box")

#text("One can also show that ")#mi("{x_{ss}}")#text(", ")#mi("{x_n}")#text(" commute with each other and with the centraliser ")#mi("{C(x) := \\{ y \\in {\\mathfrak g}: [x,y] = 0 \\}}")#text(" of ")#mi("{x}")#text(" by using the faithful nature of the adjoint representation for semisimple algebras, though we will not need these facts here. Using this lemma we have a well-defined notion of an element ")#mi("{x}")#text(" of a semisimple algebra ")#mi("{{\\mathfrak g}}")#text(" being semisimple (resp. nilpotent), namely that ")#mi("{x=x_{ss}}")#text(" or ")#mi("{x=x_n}")#text(". Lemma ")#link(<tao-120a7973926846f70822>)[#text("13")]#text(" then implies that any representation of a semisimple element of ")#mi("{{\\mathfrak g}}")#text(" is again semisimple, and any representation of a nilpotent element of ")#mi("{{\\mathfrak g}}")#text(" is again nilpotent. This apparently innocuous statement relies heavily on the semisimple nature of ")#mi("{{\\mathfrak g}}")#text("; note for instance that the representation")

#align(center)[#tao-fit-display[#mitex("t \\mapsto \\begin{pmatrix} 0 & t \\\\ 0 & 0 \\end{pmatrix}")]]

#text("of the non-semisimple algebra ")#mi("{{\\bf C} \\equiv {\\mathfrak{gl}}_1}")#text(" into ")#mi("{{\\mathfrak{gl}}_2}")#text(" takes semisimple elements to nilpotent ones.")

#heading(level: 1)[#strong[#text(" — 4. Cartan subalgebras — ")]]

#text("While simple Lie algebras do not have any non-trivial ideals, they do have some very useful subalgebras known as ")#link("http://en.wikipedia.org/wiki/Cartan_subalgebra")[#text("Cartan subalgebras")]#text(" which will eventually turn out to be abelian and which can be used to dramatically clarify the structure of the rest of the algebra.")

#text("We need some definitions. An element ")#mi("{x}")#text(" of ")#mi("{{\\mathfrak g}}")#text(" is said to be ")#link("http://en.wikipedia.org/wiki/Regular_element_of_a_Lie_algebra")[#text("regular")]#text(" if its generalised null space")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak g}^x_0 := \\{ y \\in {\\mathfrak g}: (\\text{ad} x)^n y = 0 \\text{ for some } n \\}")]]

#text("has minimal dimension. A ")#emph[#text("Cartan subalgebra")]#text(" of ")#mi("{{\\mathfrak g}}")#text(" is a nilpotent subalgebra ")#mi("{{\\mathfrak h}}")#text(" of ")#mi("{{\\mathfrak g}}")#text(" which is its own ")#link("http://en.wikipedia.org/wiki/Centralizer_and_normalizer")[#text("normaliser")]#text(", thus ")#mi("{N({\\mathfrak h}) := \\{ x \\in {\\mathfrak g}: [x,{\\mathfrak h}] \\subset {\\mathfrak h} \\}}")#text(" is equal to ")#mi("{{\\mathfrak h}}")#text(". From the polynomial nature of the Lie algebra operations (and the ")#link("http://en.wikipedia.org/wiki/Noetherian_topological_space")[#text("Noetherian nature of algebraic geometry")]#text(") we see that the regular elements of ")#mi("{{\\mathcal g}}")#text(" are generic (i.e. they form a non-empty ")#link("http://en.wikipedia.org/wiki/Zariski_topology")[#text("Zariski-open")]#text(" subset of ")#mi("{{\\mathfrak g}}")#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 14")]#text(" In ")#mi("{{\\mathfrak{gl}}(V)}")#text(", the regular elements consist of the semisimple elements with distinct eigenvalues. Fixing a basis for ")#mi("{V}")#text(", the space of elements of ")#mi("{{\\mathfrak{gl}}(V)}")#text(" that are diagonalised by that basis form a Cartan subalgebra of ")#mi("{{\\mathfrak{gl}}(V)}")#text(".")
]

#text("Cartan algebras always exist, and can be constructed as generalised null spaces of regular elements:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 15 (Existence of Cartan subalgebras)")]#text(" Let ")#mi("{{\\mathfrak g}}")#text(" be an abstract Lie algebra. If ")#mi("{x \\in {\\mathfrak g}}")#text(" is regular, then the generalised null space ")#mi("{{\\mathfrak h} := {\\mathfrak g}^x_0}")#text(" of ")#mi("{x}")#text(" is a Cartan subalgebra.")
]

#emph[#text("Proof:")]#text(" Suppose that ")#mi("{{\\mathfrak h}}")#text(" is not nilpotent, then by Engel’s theorem the adjoint action of at least one element of ")#mi("{{\\mathfrak h}}")#text(" on ")#mi("{{\\mathfrak h}}")#text(" is not nilpotent. By the polynomial nature of the Lie algebra operations, we conclude that the adjoint action of a generic element of ")#mi("{{\\mathfrak h}}")#text(" on ")#mi("{{\\mathfrak h}}")#text(" is not nilpotent.")

#text("The action of ")#mi("{x}")#text(" on ")#mi("{{\\mathfrak g}/{\\mathfrak h}}")#text(" is non-singular, so the action of generic elements of ")#mi("{{\\mathfrak h}}")#text(" on ")#mi("{{\\mathfrak g}/{\\mathfrak h}}")#text(" is also non-singular. Thus we can find ")#mi("{y \\in {\\mathfrak h}}")#text(" such that ")#mi("{\\text{ad} y}")#text(" is not nilpotent on ")#mi("{{\\mathfrak h}}")#text(" and not singular on ")#mi("{{\\mathfrak g}/{\\mathfrak h}}")#text(". From this we see that ")#mi("{{\\mathfrak g}^y_0}")#text(" is a proper subspace of ")#mi("{{\\mathfrak g}^x_0}")#text(", contradicting the regularity of ")#mi("{x}")#text(". Thus ")#mi("{{\\mathfrak h}}")#text(" is nilpotent.")

#text("Finally, we show that ")#mi("{{\\mathfrak h}}")#text(" is its own normaliser. Suppose that ")#mi("{y \\in {\\mathfrak g}}")#text(" normalises ")#mi("{{\\mathfrak h}}")#text(", then ")#mi("{(\\text{ad} x) y \\in {\\mathfrak h}}")#text(". But ")#mi("{{\\mathfrak h}}")#text(" is the generalised null space of ")#mi("{\\text{ad} x}")#text(", and so ")#mi("{y \\in {\\mathfrak h}}")#text(" as required.")

#text("Furthermore, all Cartan algebras arise as generalised null spaces:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 16 (Cartans are null spaces)")]#text(" ")#metadata(none) <tao-93969d193161ae6fbd17>#text(" Let ")#mi("{{\\mathfrak g}}")#text(" be an abstract Lie algebra, and let ")#mi("{{\\mathfrak h}}")#text(" be a Cartan subalgebra. Let")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak g}_0^{\\mathfrak h} = \\{ x \\in {\\mathfrak g}: (\\text{ad} {\\mathfrak h})^n x = 0 \\text{ for some } n \\}")]]

#text("be the generalised null space of ")#mi("{{\\mathfrak h}}")#text(". Then ")#mi("{{\\mathfrak g}_0^{\\mathfrak h} = {\\mathfrak h}}")#text(". Furthermore, for generic ")#mi("{x \\in {\\mathfrak h}}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak h} = {\\mathfrak g}_0^x.")]]
]

#emph[#text("Proof:")]#text(" As ")#mi("{{\\mathfrak h}}")#text(" is nilpotent, we certainly have ")#mi("{{\\mathfrak h} \\subset {\\mathfrak g}_0^{\\mathfrak h}}")#text(". Now, for any ")#mi("{x \\in {\\mathfrak h}}")#text(", ")#mi("{\\text{ad} x}")#text(" acts nilpotently on both ")#mi("{{\\mathfrak g}_0^{\\mathfrak h}}")#text(" and ")#mi("{{\\mathfrak h}}")#text(" and hence on ")#mi("{{\\mathfrak g}_0^{\\mathfrak h}/{\\mathfrak h}}")#text(". By Engel’s theorem, we can thus find ")#mi("{y \\in {\\mathfrak g}_0^{\\mathfrak h}/{\\mathfrak h}}")#text(" that is annihilated by the adjoint action of ")#mi("{{\\mathfrak h}}")#text("; pulling back to ")#mi("{{\\mathfrak g}_0^{\\mathfrak h}}")#text(", we conclude that the normaliser of ")#mi("{{\\mathfrak h}}")#text(" is strictly larger than ")#mi("{{\\mathfrak h}}")#text(", contradicting the hypothesis that ")#mi("{{\\mathfrak h}}")#text(" is a Cartan subalgebra. This shows that ")#mi("{{\\mathfrak g}_0^{\\mathfrak h} = {\\mathfrak h}}")#text(".")

#text("Now let ")#mi("{x \\in {\\mathfrak h}}")#text(" be generic, then ")#mi("{{\\mathfrak g}_0^x}")#text(" has minimal dimension amongst ")#mi("{x \\in {\\mathfrak h}}")#text(". Let ")#mi("{y \\in {\\mathfrak h}}")#text(" be arbitrary. Then for any scalar ")#mi("{t}")#text(", ")#mi("{\\text{ad} (x+ty)}")#text(" acts on ")#mi("{{\\mathfrak g}}")#text(" and on ")#mi("{{\\mathfrak h}}")#text(" and hence on ")#mi("{{\\mathfrak g}/{\\mathfrak h}}")#text(". This action is invertible when ")#mi("{t=0}")#text(", and hence is also invertible for generic ")#mi("{t}")#text("; thus for generic ")#mi("{t}")#text(", ")#mi("{{\\mathfrak g}^{x+ty}_0 \\subset {\\mathfrak g}^x_0}")#text(". By minimality we conclude that ")#mi("{{\\mathfrak g}^{x+ty}_0 = {\\mathfrak g}^x_0}")#text(", so ")#mi("{\\text{ad} (x+ty)}")#text(" is nilpotent on ")#mi("{{\\mathfrak g}^x_0}")#text(" for generic ")#mi("{t}")#text(", and thus for all ")#mi("{t}")#text(". In particular ")#mi("{\\text{ad} (x+y)}")#text(" is nilpotent on ")#mi("{{\\mathfrak g}^x_0}")#text(" for any ")#mi("{y \\in {\\mathfrak h}}")#text(", thus ")#mi("{{\\mathfrak g}^x_0 \\subset {\\mathfrak g}^{\\mathfrak h}_0 = {\\mathfrak h}}")#text(". Since ")#mi("{{\\mathfrak h} \\subset {\\mathfrak g}^x_0}")#text(", we obtain ")#mi("{{\\mathfrak h} = {\\mathfrak g}_0^x}")#text(" as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 17 (Cartans are conjugate)")]#text(" Let ")#mi("{{\\mathfrak g}}")#text(" be a Lie algebra, and let ")#mi("{{\\mathfrak h}}")#text(" be a Cartan algebra. Then for generic ")#mi("{x \\in {\\mathfrak g}}")#text(", ")#mi("{{\\mathfrak h}}")#text(" is conjugate to ")#mi("{{\\mathfrak g}_0^x}")#text(" by an inner automorphism of ")#mi("{{\\mathfrak g}}")#text(" (i.e. an element of the algebraic group generated by ")#mi("{\\exp(\\text{ad} y)}")#text(" for ")#mi("{y \\in {\\mathfrak g}}")#text("). In particular, any two Cartan subalgebras are conjugate to each other by an inner automorphism.")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{S}")#text(" be the set of ")#mi("{x^{\\prime} \\in {\\mathfrak h}}")#text(" with ")#mi("{{\\mathfrak h} = {\\mathfrak g}_0^{x^{\\prime}}}")#text(", then ")#mi("{x^{\\prime}}")#text(" is a Zariski open dense subset of ")#mi("{{\\mathfrak h}}")#text(" by Proposition ")#link(<tao-93969d193161ae6fbd17>)[#text("16")]#text(". Then let ")#mi("{T}")#text(" be the collection of ")#mi("{x \\in {\\mathfrak g}}")#text(" that are conjugate to an ")#mi("{x^{\\prime} \\in S}")#text(", then ")#mi("{T}")#text(" is a algebraically constructible subset of ")#mi("{{\\mathfrak g}}")#text(". For ")#mi("{x^{\\prime} \\in S}")#text(", observe that ")#mi("{(\\text{ad} {x^{\\prime}})({\\mathfrak g})}")#text(" and ")#mi("{{\\mathfrak h}}")#text(" span ")#mi("{{\\mathfrak g}}")#text(", since ")#mi("{{\\mathfrak h} = {\\mathfrak g}_0^{x^{\\prime}}}")#text(", and so by the ")#link("http://en.wikipedia.org/wiki/Inverse_function_theorem")[#text("inverse function theorem")]#text(", a (topological) neighbourhood of ")#mi("{x^{\\prime}}")#text(" is contained in ")#mi("{T}")#text(". This implies that ")#mi("{T}")#text(" is Zariski dense, and the claim follows. ")#mi("\\Box")

#text("In the case of semisimple algebras, the Cartan structure is particularly clean:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 18")]#text(" ")#metadata(none) <tao-0c030586945fe504b604>#text(" Let ")#mi("{{\\mathfrak g}}")#text(" be a semisimple Lie algebra. Then every Cartan subalgebra ")#mi("{{\\mathfrak h}}")#text(" is abelian, and ")#mi("{K}")#text(" is non-degenerate on ")#mi("{{\\mathfrak h}}")#text(".")
]

#text("The dimension of the Cartan algebra of a semisimple Lie algebra is known as the ")#emph[#text("rank")]#text(" of the algebra.")

#emph[#text("Proof:")]#text(" The nilpotent algebra ")#mi("{{\\mathfrak h}}")#text(" acts via the adjoint action on ")#mi("{{\\mathfrak g}}")#text(", and by Lie’s theorem this action can be made upper triangular. From this it is not difficult to obtain a decomposition")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak g} = \\bigoplus_{\\lambda \\in \\sigma({\\mathfrak h})} {\\mathfrak g}^{\\mathfrak h}_\\lambda")]]

#text("for some finite set ")#mi("{\\sigma({\\mathfrak h}) \\subset {\\mathfrak h}^*}")#text(", where ")#mi("{{\\mathfrak g}^{\\mathfrak h}_\\lambda}")#text(" are the generalised eigenspaces")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak g}^{\\mathfrak h}_\\lambda = \\{ x \\in {\\mathfrak g}: (\\text{ad} {\\mathfrak h}-\\lambda)^k x = 0 \\text{ for some } k \\}.")]]

#text("From the Jacobi identity ")#link(<tao-d75a0f5a7461846c8840>)[#text("(2)")]#text(" we see that ")#mi("{[{\\mathfrak g}^{\\mathfrak h}_{\\lambda}, {\\mathfrak g}^{\\mathfrak h}_{\\mu}] \\subset {\\mathfrak g}^{\\mathfrak h}_{\\lambda+\\mu}}")#text(". Among other things, this shows that ")#mi("{{\\mathfrak g}^{\\mathfrak h}_{\\lambda}}")#text(" has ad-trace zero for any non-zero ")#mi("{\\lambda}")#text(", and hence ")#mi("{{\\mathfrak g}^{\\mathfrak h}_{\\lambda}, {\\mathfrak g}^{\\mathfrak h}_{\\mu}}")#text(" are ")#mi("{K}")#text("-orthogonal if ")#mi("{\\lambda+\\mu \\neq 0}")#text(". In particular, ")#mi("{{\\mathfrak g}^{\\mathfrak h}_{0}}")#text(" is ")#mi("{K}")#text("-orthogonal to ")#mi("{\\bigoplus_{\\lambda \\neq 0} {\\mathfrak g}^{\\mathfrak h}_\\lambda}")#text(". By Theorem ")#link(<tao-7c21b8ee84cee675a9cc>)[#text("1")]#text(", ")#mi("{K}")#text(" is non-degenerate on ")#mi("{{\\mathfrak g}}")#text(", and thus also non-degenerate on ")#mi("{{\\mathfrak g}^{\\mathfrak h}_0}")#text("; by Proposition ")#link(<tao-93969d193161ae6fbd17>)[#text("16")]#text(", ")#mi("{K}")#text(" is thus non-degenerate on ")#mi("{{\\mathfrak h}}")#text(". But by Lie’s theorem, we can find a basis for which ")#mi("{{\\mathfrak h}}")#text(" consists of upper-triangular matrices in the adjoint representation of ")#mi("{{\\mathfrak g}}")#text(", so that ")#mi("{[{\\mathfrak h},{\\mathfrak h}]}")#text(" is strictly upper-triangular and thus ")#mi("{K}")#text("-orthogonal to ")#mi("{{\\mathfrak h}}")#text(". As ")#mi("{K}")#text(" is non-degenerate on ")#mi("{{\\mathfrak h}}")#text(", this forces ")#mi("{[{\\mathfrak h},{\\mathfrak h}]}")#text(" to be trivial, as required. ")#mi("\\Box")

#text("We now use the semisimple Jordan decomposition (Lemma ")#link(<tao-120a7973926846f70822>)[#text("13")]#text(") to obtain a further non-degeneracy property of the Cartan subalgebras of semisimple algebras:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 19")]#text(" ")#metadata(none) <tao-70963e33ab0c3fcd4d19>#text(" Let ")#mi("{{\\mathfrak g}}")#text(" be a semisimple Lie algebra. Then every Cartan subalgebra ")#mi("{{\\mathfrak h}}")#text(" consists entirely of semisimple elements.")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{x \\in {\\mathfrak h}}")#text(", then (by the abelian nature of ")#mi("{{\\mathfrak h}}")#text(") ")#mi("{\\text{ad} x}")#text(" annihilates ")#mi("{{\\mathfrak h}}")#text("; as ")#mi("{\\text{ad} {x_{n}}}")#text(" is a polynomial in ")#mi("{\\text{ad} x}")#text(" with zero constant coefficient, ")#mi("{\\text{ad} {x_n}}")#text(" annihilates ")#mi("{{\\mathfrak h}}")#text(" as well; thus ")#mi("{x_n}")#text(" normalises ")#mi("{{\\mathfrak h}}")#text(" and thus also lies in ")#mi("{{\\mathfrak h}}")#text(" as ")#mi("{{\\mathfrak h}}")#text(" is Cartan. If ")#mi("{y \\in {\\mathfrak h}}")#text(", then ")#mi("{y}")#text(" commutes with ")#mi("{x_n}")#text(" and so ")#mi("{\\text{ad} y}")#text(" commutes with ")#mi("{\\text{ad} {x_n}}")#text(". As the latter is nilpotent, we conclude that ")#mi("{\\text{ad} {x_n} \\text{ad} y}")#text(" is nilpotent and thus has trace zero. Thus ")#mi("{x_n}")#text(" is ")#mi("{K}")#text("-orthogonal to ")#mi("{{\\mathfrak h}}")#text(" and thus vanishes since the Killing form is non-degenerate on ")#mi("{{\\mathfrak h}}")#text(". Thus every element of ")#mi("{{\\mathfrak h}}")#text(" is semisimple as required. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 5. ")#mi("{{\\mathfrak{sl}}_2}")#text(" representations — ")]]

#text("To proceed further, we now need to perform some computations on a very specific Lie algebra, the special linear algebra ")#mi("{\\mathfrak{sl}_2}")#text(" of ")#mi("{2 \\times 2}")#text(" complex matrices with zero trace. This is a three-dimensional concrete Lie algebra, spanned by the three generators")

#align(center)[#tao-fit-display[#mitex("H := \\begin{pmatrix} 1 & 0 \\\\ 0 & -1 \\end{pmatrix}; X := \\begin{pmatrix} 0 & 1 \\\\ 0 & 0 \\end{pmatrix}; Y := \\begin{pmatrix} 0 & 0 \\\\ 1 & 0 \\end{pmatrix}")]]

#text("which obey the commutation relations ")#metadata(none) <tao-ff298e4c4f975caa2511>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("[H,X] = 2X; [H,Y] = -2Y; [X,Y] = H.")]]

#text(" Conversely, any abstract three-dimensional Lie algebra generated by ")#mi("{H,X,Y}")#text(" with relations ")#link(<tao-ff298e4c4f975caa2511>)[#text("(8)")]#text(" is clearly isomorphic to ")#mi("{\\mathfrak{sl}_2}")#text(". One can check that this is a simple Lie algebra, with the one-dimensional space generated by ")#mi("{H}")#text(" being a Cartan subalgebra.")

#text("Now we classify by hand the representations ")#mi("{\\rho: \\mathfrak{sl}_2 \\rightarrow {\\mathfrak{gl}}(V)}")#text(" of ")#mi("{\\mathfrak{sl}_2}")#text(". Observe that ")#mi("{\\mathfrak{sl}_2}")#text(" acts infinitesimally on ")#mi("{{\\bf R}^2}")#text(" by the differential operators (or vector fields)")

#align(center)[#tao-fit-display[#mitex("H \\rightarrow x \\partial_x - y \\partial_y; \\quad X \\rightarrow x \\partial_y; \\quad Y \\rightarrow y \\partial_x.")]]

#text("In particular, we see that for each natural number ")#mi("{n}")#text(", the space ")#mi("{P_n}")#text(" of homogeneous polynomials in two variables ")#mi("{x,y}")#text(" of degree ")#mi("{n}")#text(" has a representation ")#mi("{\\sigma_n: \\mathfrak{sl}_2 \\rightarrow {\\mathfrak{gl}}(P_n)}")#text("; if we give this space the basis ")#mi("{e_{2i-n} := x^i y^{n-i}}")#text(" for ")#mi("{i=0,\\ldots,n}")#text(", the action is then described by the formulae ")#metadata(none) <tao-7a7b9f165c6525f14114>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\sigma_n(H) e_j = j e_j; \\quad \\sigma_n(X) e_j = \\frac{n-j}{2} e_{j+2}; \\quad \\sigma_n(Y) e_j = \\frac{n+j}{2} e_{j-2}")]]

#text(" for ")#mi("{j = n, n-2, \\ldots, -n+2, n}")#text(". From these formulae it is also easy to see that these representations are irreducible in the sense that the ")#mi("{P_n}")#text(" have no non-trivial ")#mi("{\\mathfrak{sl}_2}")#text("-invariant subspaces.")

#text("Conversely, these representations (and their direct sums) describe (up to isomorphism) all of the representations of ")#mi("{\\mathfrak{sl}_2}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 20 (Representations of ")#mi("{\\mathfrak{sl}_2}")#text(")")]#text(" ")#metadata(none) <tao-7a9767fb84376073d114>#text(" Any representation ")#mi("{\\rho: \\mathfrak{sl}_2 \\rightarrow {\\mathfrak{gl}}(V)}")#text(" is isomorphic to the direct sum of finitely many of the representations ")#mi("{\\sigma_n: \\mathfrak{sl}_2 \\rightarrow {\\mathfrak{gl}}(P_n)}")#text(".")
]

#text("Here of course the direct sum ")#mi("{\\rho_1 \\oplus \\rho_2: {\\mathfrak g} \\rightarrow {\\mathfrak{gl}}(V_1 \\oplus V_2)}")#text(" of two representations ")#mi("{\\rho_1: {\\mathfrak g} \\rightarrow {\\mathfrak{gl}}(V_1)}")#text(", ")#mi("{\\rho_2: {\\mathfrak g} \\rightarrow {\\mathfrak{gl}}(V_2)}")#text(" is defined as ")#mi("{\\rho_1 \\oplus \\rho_2(x) := (\\rho_1(x), \\rho_2(x))}")#text(", and two representations ")#mi("{\\rho_1: {\\mathfrak g} \\rightarrow {\\mathfrak{gl}}(V_1)}")#text(", ")#mi("{\\rho_2: {\\mathfrak g} \\rightarrow {\\mathfrak{gl}}(V_2)}")#text(" are isomorphic if there is an invertible linear map ")#mi("{\\phi: V_1 \\rightarrow V_2}")#text(" such that ")#mi("{\\phi \\circ \\rho_1(x) = \\rho_2(x) \\circ \\phi}")#text(" for all ")#mi("{x \\in {\\mathfrak g}}")#text(".")

#emph[#text("Proof:")]#text(" By induction we may assume that ")#mi("{V}")#text(" is non-trivial, the claim has already been proven for any smaller dimensional spaces than ")#mi("{V}")#text(".")

#text("As ")#mi("{H}")#text(" is semisimple, ")#mi("{\\rho(H)}")#text(" is semisimple by Lemma ")#link(<tao-120a7973926846f70822>)[#text("13")]#text(", and so we can split ")#mi("{V}")#text(" into the direct sum")

#align(center)[#tao-fit-display[#mitex("V = \\oplus_{\\lambda \\in \\sigma(H)} V^H_\\lambda")]]

#text("of eigenspaces of ")#mi("{H}")#text(" for some finite ")#mi("{\\sigma(H) \\subset {\\bf C}}")#text(".")

#text("From ")#link(<tao-ff298e4c4f975caa2511>)[#text("(8)")]#text(" we have the raising law")

#align(center)[#tao-fit-display[#mitex("\\rho(X) V^H_\\lambda \\subset V^H_{\\lambda+2}")]]

#text("and the lowering law")

#align(center)[#tao-fit-display[#mitex("\\rho(Y) V^H_\\lambda \\subset V^H_{\\lambda-2}")]]

#text("As ")#mi("{\\sigma(H)}")#text(" is finite, we may find a “highest weight” ")#mi("{\\lambda \\in \\sigma(H)}")#text(" with the property that ")#mi("{\\lambda+2 \\not \\in \\sigma(H)}")#text(", thus ")#mi("{\\rho(X)}")#text(" annihilates ")#mi("{V^H_\\lambda}")#text(" by the raising law. We will use the basic strategy of starting from the highest weight space and applying lowering operators to discover one of the irreducible components of the representation.")

#text("From ")#link(<tao-ff298e4c4f975caa2511>)[#text("(8)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\rho(X) \\rho(Y) = \\rho(Y) \\rho(X) + \\rho(H)")]]

#text("and so from induction and the lowering law we see that ")#metadata(none) <tao-07397d633f25a7101990>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\rho(X) \\rho(Y)^{k+1} v = (\\lambda + (\\lambda-2) + \\ldots + (\\lambda-2k)) \\rho(Y)^k v")]]

#text(" for all natural numbers ")#mi("{k}")#text(" and all ")#mi("{v \\in V^H_\\lambda}")#text(". If ")#mi("{\\lambda + (\\lambda-2) + \\ldots + (\\lambda-2k)}")#text(" is never zero, this creates an infinite sequence ")#mi("{V^H_\\lambda, V^H_{\\lambda-2}, V^H_{\\lambda-4}, \\ldots}")#text(" of non-trivial eigenspaces, which is absurd, so we have ")#mi("{\\lambda + (\\lambda-2) + \\ldots + (\\lambda-2n) = 0}")#text(" for some natural number ")#mi("{n}")#text(", thus ")#mi("{\\lambda = n}")#text(". If we then let")

#align(center)[#tao-fit-display[#mitex("W := \\bigoplus_{k=0}^n \\rho(Y)^k V^H_n")]]

#text("then we see that ")#mi("{W}")#text(" is invariant under ")#mi("{H}")#text(", ")#mi("{X}")#text(", and ")#mi("{Y}")#text(", and thus ")#mi("{{\\mathfrak g}}")#text("-invariant; also if for each ")#mi("{\\lambda \\in \\sigma(H)}")#text(" we let ")#mi("{\\tilde V^H_\\lambda}")#text(" be the set of all ")#mi("{v \\in V^H_\\lambda}")#text(" such that ")#mi("{\\rho(X)^k v}")#text(" is never a non-zero element of ")#mi("{V^H_n}")#text(" then we see that")

#align(center)[#tao-fit-display[#mitex("\\tilde W := \\bigoplus_{\\lambda \\in \\sigma(H)} \\tilde V^H_\\lambda")]]

#text("is also ")#mi("{{\\mathfrak g}}")#text("-invariant, and furthermore that ")#mi("{W}")#text(" and ")#mi("{\\tilde W}")#text(" are complementary subspaces in ")#mi("{V}")#text(". Applying the induction hypothesis, we are done unless ")#mi("{W=V}")#text(", but then by splitting ")#mi("{V^H_n}")#text(" into one-dimensional spaces and applying the lowering operators, we see that we reduce to the case that ")#mi("{V^H_n}")#text(" is one-dimensional. But if one then lets ")#mi("{e_n}")#text(" be a generator of ")#mi("{V^H_n}")#text(" and recursively defines ")#mi("{e_{n-2}, e_{n-4},\\ldots,e_{-n}}")#text(" by")

#align(center)[#tao-fit-display[#mitex("\\rho(Y) e_j = \\frac{n+j}{2} e_{j-2}")]]

#text("one then checks using ")#link(<tao-07397d633f25a7101990>)[#text("(10)")]#text(" that ")#mi("{\\rho}")#text(" is isomorphic to ")#mi("{\\sigma_n}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 21")]#text(" Theorem ")#link(<tao-7a9767fb84376073d114>)[#text("20")]#text(" shows that all representations of ")#mi("{\\mathfrak{sl}_2}")#text(" are ")#emph[#text("completely reducible")]#text(" in that they can be decomposed as the direct sum of irreducible representations. In fact, all representations of semisimple Lie algebras are completely reducible; this can be proven by a variant of the above arguments (in combination with the analysis of weights given below), and can also be proven by the unitary trick, or by analysing the action of ")#link("http://en.wikipedia.org/wiki/Casimir_invariant")[#text("Casimir elements")]#text(" of the universal enveloping algebra of ")#mi("{{\\mathfrak g}}")#text(", as done in the Appendix.")
]

#heading(level: 1)[#strong[#text(" — 6. Root spaces — ")]]

#metadata(none) <tao-02892b235fa087c7e3e7>

#text("Now we use the ")#mi("{\\mathfrak{sl}_2}")#text(" theory to analyse more general semisimple algebras.")

#text("Let ")#mi("{{\\mathfrak g}}")#text(" be a semisimple Lie algebra, and let ")#mi("{{\\mathfrak h}}")#text(" be a Cartan algebra, then by Proposition ")#link(<tao-0c030586945fe504b604>)[#text("18")]#text(" ")#mi("{{\\mathfrak h}}")#text(" is abelian and acts in a semisimple fashion on ")#mi("{{\\mathfrak g}}")#text(", and by Proposition ")#link(<tao-93969d193161ae6fbd17>)[#text("16")]#text(" ")#mi("{{\\mathfrak h}}")#text(" is its own null space ")#mi("{{\\mathfrak g}^{\\mathfrak h}_0}")#text(" in the weight decomposition of ")#mi("{{\\mathfrak g}}")#text(", thus we have the ")#link("http://en.wikipedia.org/wiki/Cartan_decomposition")[#text("Cartan decomposition")]

#align(center)[#tao-fit-display[#mitex("{\\mathfrak g} = {\\mathfrak h} \\oplus \\bigoplus_{\\alpha \\in \\Phi} {\\mathfrak g}^{\\mathfrak h}_\\alpha")]]

#text("as vector spaces (not as Lie algebras) where ")#mi("{\\Phi}")#text(" is a finite subset of ")#mi("{{\\mathfrak h}^* \\backslash \\{0\\}}")#text(" (known as the set of ")#emph[#text("roots")]#text(") and ")#mi("{{\\mathfrak g}^{\\mathfrak h}_\\alpha}")#text(" is the non-trivial eigenspace ")#metadata(none) <tao-fb0b23773a1f394e1a57>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("{\\mathfrak g}^{\\mathfrak h}_\\alpha = \\{ x \\in {\\mathfrak g}: [y,x] = \\alpha(y) x \\text{ for all } y \\in {\\mathfrak h} \\}.")]]



#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 22")]#text(" A key example to keep in mind is when ")#mi("{{\\mathfrak g} = \\mathfrak{sl}_n}")#text(" is the Lie algebra of ")#mi("{n \\times n}")#text(" matrices of trace zero. An explicit computation using the Killing form and Theorem ")#link(<tao-7c21b8ee84cee675a9cc>)[#text("1")]#text(" shows that this algebra is semisimple; in fact it is simple, but we will not show this yet. The space ")#mi("{{\\mathfrak h}}")#text(" of diagonal matrices of trace zero can then be verified to be a Cartan algebra; it can be identified with the space ")#mi("{{\\bf C}^n_0}")#text(" of complex ")#mi("{n}")#text("-tuples summing to zero, and using the usual Hermitian inner product on ")#mi("{{\\bf C}^n}")#text(" we can also identify ")#mi("{{\\mathfrak h}^*}")#text(" with ")#mi("{{\\bf C}^n_0}")#text(". The roots are then of the form ")#mi("{e_i - e_j}")#text(" for distinct ")#mi("{1 \\leq i,j \\leq n}")#text(", where ")#mi("{e_1,\\ldots,e_n}")#text(" is the standard basis for ")#mi("{{\\bf C}^n}")#text(", with ")#mi("{{\\mathfrak g}^{\\mathfrak h}_{e_i-e_j}}")#text(" being the one-dimensional space of matrices that are vanishing except possibly at the ")#mi("{(i,j)}")#text(" coefficient.")
]

#text("From the Jacobi identity ")#link(<tao-d75a0f5a7461846c8840>)[#text("(2)")]#text(" we see that the Lie bracket acts additively on the weights, thus ")#metadata(none) <tao-7e9e5ac30f2216fd0fd6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("[{\\mathfrak g}^{\\mathfrak h}_\\alpha, {\\mathfrak g}^{\\mathfrak h}_\\beta] \\subset {\\mathfrak g}^{\\mathfrak h}_{\\alpha+\\beta}")]]

#text(" for all ")#mi("{\\alpha,\\beta \\in {\\mathfrak h}^*}")#text(". Taking traces, we conclude that")

#align(center)[#tao-fit-display[#mitex("K( {\\mathfrak g}^{\\mathfrak h}_\\alpha, {\\mathfrak g}^{\\mathfrak h}_\\beta ) = 0")]]

#text("whenever ")#mi("{\\alpha+\\beta \\neq 0}")#text(". As ")#mi("{K}")#text(" is non-degenerate, we conclude that if ")#mi("{{\\mathfrak g}^{\\mathfrak h}_\\alpha}")#text(" is non-trivial, then ")#mi("{{\\mathfrak g}^{\\mathfrak h}_{-\\alpha}}")#text(" must also be non-trivial, thus ")#mi("{\\Phi}")#text(" is symmetric around the origin.")

#text("We also claim that ")#mi("{\\Phi}")#text(" spans ")#mi("{{\\mathfrak h}^*}")#text(" as a vector space. For if this were not the case, then there would be a non-trivial ")#mi("{x \\in {\\mathfrak h}}")#text(" that is annihilated by ")#mi("{\\Phi}")#text(", which by ")#link(<tao-fb0b23773a1f394e1a57>)[#text("(11)")]#text(" implies that ")#mi("{\\text{ad} x}")#text(" annihilates all of the ")#mi("{{\\mathfrak g}^{\\mathfrak h}_\\alpha}")#text(" and is thus central, contradicting the semisimplicity of ")#mi("{{\\mathfrak g}}")#text(".")

#text("From Proposition ")#link(<tao-0c030586945fe504b604>)[#text("18")]#text(", ")#mi("{K}")#text(" is non-degenerate on ")#mi("{{\\mathfrak h}}")#text(". Thus, for each root ")#mi("{\\alpha \\in \\Phi}")#text(", there is a corresponding non-zero element ")#mi("{t_\\alpha}")#text(" of ")#mi("{{\\mathfrak h}}")#text(" such that ")#mi("{K( t_\\alpha, x ) = \\alpha(x)}")#text(" for all ")#mi("{x \\in {\\mathfrak h}}")#text(". If we let ")#mi("{x \\in {\\mathfrak g}^{\\mathfrak h}_\\alpha, y \\in {\\mathfrak g}^{\\mathfrak h}_{-\\alpha}}")#text(", and ")#mi("{z \\in {\\mathfrak g}^{\\mathfrak h}_0= {\\mathfrak h}}")#text(", we have")

#tao-aligned(keep: true)[


#tao-math("K( [x,y], z )  & = K( y, [z,x] )", block: true)



#tao-math(" & = K( y, \\alpha(z) x )", block: true)



#tao-math(" & = \\alpha( K(x,y) z )", block: true)



#tao-math(" & = K( K(x,y) t_\\alpha, z )", block: true)
]

#text("and thus by the non-degeneracy of ")#mi("{K}")#text(" on ")#mi("{{\\mathfrak h}}")#text(" we obtain the useful formula ")#metadata(none) <tao-4a8da30a4036bd2fc0ea>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("[x,y] = K(x,y) t_\\alpha")]]

#text(" for ")#mi("{x \\in {\\mathfrak g}^{\\mathfrak h}_\\alpha}")#text(" and ")#mi("{y \\in {\\mathfrak g}^{\\mathfrak h}_{-\\alpha}}")#text(".")

#text("As ")#mi("{K}")#text(" is non-degenerate, we can find ")#mi("{X = X_\\alpha \\in {\\mathfrak g}^{\\mathfrak h}_\\alpha}")#text(" and ")#mi("{Y = Y_\\alpha \\in {\\mathfrak g}^{\\mathfrak h}_{-\\alpha}}")#text(" with ")#mi("{K(X,Y) \\neq 0}")#text(" (which can be found as ")#mi("{K}")#text(" is non-degenerate). We divide into two cases depending on whether ")#mi("{\\alpha(t_\\alpha)}")#text(" vanishes or not. If ")#mi("{\\alpha(t_\\alpha)}")#text(" vanishes, then ")#mi("{[X,Y]}")#text(" is non-trivial but commutes with ")#mi("{X}")#text(" and ")#mi("{Y}")#text(", and so ")#mi("{\\text{ad} X,\\text{ad} Y}")#text(" generate a solvable algebra. By Lie’s theorem, this algebra is upper-triangular in some basis, and so ")#mi("{\\text{ad} [X,Y]}")#text(" is nilpotent, hence ")#mi("{\\text{ad} t_\\alpha}")#text(" is nilpotent; but by Proposition ")#link(<tao-70963e33ab0c3fcd4d19>)[#text("19")]#text(" ")#mi("{\\text{ad} t_\\alpha}")#text(" is also semisimple, contradicting the non-zero nature of ")#mi("{t_\\alpha}")#text(" (and the semisimple nature of ")#mi("{{\\mathfrak g}}")#text("). Thus ")#mi("{\\alpha(t_\\alpha)}")#text(" is non-vanishing. If we then scale ")#mi("{X,Y}")#text(" so that ")#mi("{[X,Y] = H}")#text(", where ")#mi("{H = H_\\alpha}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Co-root#Dual_root_system_and_coroots")[#text("co-root")]#text(" of ")#mi("{\\alpha}")#text(", defined as the element of ")#mi("{{\\mathfrak h}}")#text(" given by the formula")

#align(center)[#tao-fit-display[#mitex("H := \\frac{2}{\\alpha(t_\\alpha)} t_\\alpha")]]

#text("so that ")#metadata(none) <tao-95d7113969d32d19ba90>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\alpha(H) = 2,")]]

#text(" then ")#mi("{X,Y,H}")#text(" obey the relations ")#link(<tao-ff298e4c4f975caa2511>)[#text("(8)")]#text(" and thus generate a copy of ")#mi("{\\mathfrak{sl}_2}")#text(", rather than a solvable algebra. The representation theory of ")#mi("{\\mathfrak{sl}_2}")#text(" can then be applied to the space ")#metadata(none) <tao-a31fe9656fc8d3a459e6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\bigcup_{n \\in S_\\alpha} {\\mathfrak g}^{\\mathfrak h}_{n\\alpha/2},")]]

#text(" where ")#mi("{S_\\alpha := \\{ n \\in {\\bf R}: n \\alpha/2 \\in \\Phi \\cup \\{0\\}\\}}")#text(". By ")#link(<tao-7e9e5ac30f2216fd0fd6>)[#text("(19)")]#text(", this space is invariant with respect to ")#mi("{x}")#text(" and ")#mi("{y}")#text(" and hence to the copy of ")#mi("{\\mathfrak{sl}_2}")#text(", and by ")#link(<tao-fb0b23773a1f394e1a57>)[#text("(11)")]#text(", ")#link(<tao-95d7113969d32d19ba90>)[#text("(14)")]#text(" each ")#mi("{{\\mathfrak g}^{\\mathfrak h}_{n\\alpha/2}}")#text(" is the weight space of ")#mi("{H}")#text(" of weight ")#mi("{n}")#text(" for each ")#mi("{n \\in S}")#text(". By Theorem ")#link(<tao-7a9767fb84376073d114>)[#text("20")]#text(", we conclude that the set ")#mi("{S}")#text(" consists of integers. On the other hand, from ")#link(<tao-4a8da30a4036bd2fc0ea>)[#text("(13)")]#text(" we see that any copy of the representation ")#mi("{\\sigma_n}")#text(" with ")#mi("{n}")#text(" a positive even integer must have its ")#mi("{0}")#text(" weight space contained in the span of ")#mi("{t_\\alpha}")#text(", and so there is only one such representation in ")#link(<tao-a31fe9656fc8d3a459e6>)[#text("(15)")]#text(". As ")#mi("{X, Y, H}")#text(" already give a copy of ")#mi("{\\sigma_2}")#text(" in ")#link(<tao-a31fe9656fc8d3a459e6>)[#text("(15)")]#text(", there are no other copies of ")#mi("{\\sigma_n}")#text(" with ")#mi("{n}")#text(" positive even, thus we have that ")#mi("{{\\mathfrak g}^{\\mathfrak h}_\\alpha}")#text(" is one-dimensional and that the only even multiples of ")#mi("{\\alpha/2}")#text(" in ")#mi("{\\Phi}")#text(" are ")#mi("{\\pm \\alpha}")#text(". In particular, ")#mi("{2\\alpha \\not \\in \\Phi}")#text(" whenever ")#mi("{\\alpha \\in \\Phi}")#text(", which also implies that ")#mi("{\\alpha/2 \\not \\in \\Phi}")#text(" whenever ")#mi("{\\alpha \\in \\Phi}")#text(". Returning to Theorem ")#link(<tao-7a9767fb84376073d114>)[#text("20")]#text(", we conclude that the set ")#mi("{S_\\alpha}")#text(" contains no odd integers, and so ")#mi("{\\alpha}")#text(" and ")#mi("{-\\alpha}")#text(" are the only multiples of ")#mi("{\\alpha}")#text(" in ")#mi("{\\Phi}")#text(".")

#text("Next, let ")#mi("{\\beta}")#text(" be any non-zero element of ")#mi("{{\\mathfrak h}^*}")#text(" orthogonal to ")#mi("{\\alpha}")#text(" with respect to the inner product ")#mi("{\\langle,\\rangle}")#text(" of ")#mi("{{\\mathfrak h}^*}")#text(" that is dual to the restriction of the Killing form to ")#mi("{{\\mathfrak h}}")#text(", and consider the space ")#metadata(none) <tao-b34138a022fc6ca55ae8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\bigcup_{n \\in S_{\\alpha,\\beta}} {\\mathfrak g}^{\\mathfrak h}_{\\beta+n\\alpha/2}")]]

#text(" where")

#align(center)[#tao-fit-display[#mitex("S_{\\alpha,\\beta} := \\{ n \\in {\\bf R}: \\beta + n \\alpha/2 \\in \\Phi \\}.")]]

#text("By ")#link(<tao-7e9e5ac30f2216fd0fd6>)[#text("(19)")]#text(", this is again an ")#mi("{\\mathfrak{sl}_2}")#text("-invariant space, and by ")#link(<tao-fb0b23773a1f394e1a57>)[#text("(11)")]#text(", ")#link(<tao-95d7113969d32d19ba90>)[#text("(14)")]#text(" each ")#mi("{{\\mathfrak g}^{\\mathfrak h}_{\\beta+n\\alpha/2}}")#text(" is the weight space of ")#mi("{H}")#text(" of weight ")#mi("{n}")#text(". From Theorem ")#link(<tao-7a9767fb84376073d114>)[#text("20")]#text(" we see that ")#mi("{S_{\\alpha,\\beta}}")#text(" is an arithmetic progression ")#mi("{\\{-m,-m+2,\\ldots,m-2,m\\}}")#text(" of spacing ")#mi("{2}")#text("; in particular, ")#mi("{S_{\\alpha,\\beta}}")#text(" is symmetric around the origin and consists only of integers. This implies that the set ")#mi("{\\Phi}")#text(" is symmetric with respect to reflection across the hyperplane that is orthogonal to ")#mi("{\\alpha}")#text(", and also implies that")

#align(center)[#tao-fit-display[#mitex("2 \\frac{\\langle \\alpha,\\beta\\rangle}{\\langle \\alpha,\\alpha \\rangle} \\in {\\bf Z}")]]

#text("for all roots ")#mi("{\\alpha,\\beta \\in \\Phi}")#text(".")

#text("We summarise the various geometric properties of ")#mi("{\\Phi}")#text(" as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 23 (Root systems)")]#text(" Let ")#mi("{{\\mathfrak g}}")#text(" be a semisimple Lie algebra, let ")#mi("{{\\mathfrak h}}")#text(" be a Cartan subalgebra, and let ")#mi("{\\langle,\\rangle}")#text(" be the inner product on ")#mi("{{\\mathfrak h}^*}")#text(" that is dual to the Killing form restricted to ")#mi("{{\\mathfrak h}}")#text(". Let ")#mi("{\\Phi \\subset {\\mathfrak h}^*}")#text(" be the set of roots. Then:")

#list(
[#text("(i) ")#mi("{\\Phi}")#text(" does not contain zero.")],
[#text("(ii) If ")#mi("{\\alpha}")#text(" is a root, then ")#mi("{\\Phi}")#text(" is symmetric with respect to the reflection operation ")#mi("{s_\\alpha: {\\mathfrak h}^* \\rightarrow {\\mathfrak h}^*}")#text(" across the hyperplane orthogonal to ")#mi("{\\alpha}")#text("; in particular, ")#mi("{-\\alpha}")#text(" is also a root.")],
[#text("(iii) If ")#mi("{\\alpha}")#text(" is a root, then no multiple of ")#mi("{\\alpha}")#text(" other than ")#mi("{\\pm \\alpha}")#text(" are roots.")],
[#text("(iv) If ")#mi("{\\alpha,\\beta}")#text(" are roots, then ")#mi("{\\frac{\\langle \\alpha,\\beta \\rangle}{\\langle \\alpha,\\alpha \\rangle}}")#text(" is an integer or half-integer. Equivalently, ")#mi("{s_\\alpha(\\beta) = \\beta + m \\alpha}")#text(" for some integer ")#mi("{m}")#text(".")],
[#text("(v) ")#mi("{\\Phi}")#text(" spans ")#mi("{{\\mathfrak h}^*}")#text(".")]
)
]

#text("A set of vectors ")#mi("{\\Phi}")#text(" obeying the above axioms (i)-(v) is known as a ")#link("http://en.wikipedia.org/wiki/Root_system")[#text("root system")]#text(" on ")#mi("{{\\mathfrak h}^*}")#text(" (viewed as a finite dimensional complex Hilbert space with the inner product ")#mi("{\\langle,\\rangle}")#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 24")]#text(" A short calculation reveals the remarkable fact that if ")#mi("{\\Phi}")#text(" is a root system, then the associated system of co-roots ")#mi("{\\{H_\\alpha: \\alpha \\in \\Phi\\}}")#text(" is also a root system. This is one of the starting points for the deep phenomenon of ")#link("http://en.wikipedia.org/wiki/Langlands_dual")[#text("Langlands duality")]#text(", which we will not discuss here.")
]

#text("When ")#mi("{{\\mathfrak g}}")#text(" is simple, one can impose a useful additional axiom on ")#mi("{\\Phi}")#text(". Say that a root system ")#mi("{\\Phi}")#text(" is ")#emph[#text("irreducible")]#text(" if ")#mi("{\\Phi}")#text(" cannot be covered by the union ")#mi("{V \\cup W}")#text(" of two orthogonal proper subspaces of ")#mi("{{\\mathfrak h}^*}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 25")]#text(" ")#metadata(none) <tao-affb5e7b23650fa41232>#text(" If ")#mi("{{\\mathfrak g}}")#text(" is a simple Lie algebra, then the root system of ")#mi("{\\Phi}")#text(" is irreducible.")
]

#emph[#text("Proof:")]#text(" If ")#mi("{\\Phi}")#text(" can be covered by two orthogonal subspaces ")#mi("{V \\cup W}")#text(", then if we consider the subspace of ")#mi("{{\\mathfrak g}}")

#align(center)[#tao-fit-display[#mitex("V \\oplus \\bigoplus_{\\alpha \\in \\Phi \\cap V} {\\mathfrak g}^{\\mathfrak h}_\\alpha")]]

#text("where we use the inner product ")#mi("{\\langle,\\rangle}")#text(" to identify ")#mi("{{\\mathfrak h}^*}")#text(" with ")#mi("{{\\mathfrak h}}")#text(" and thus ")#mi("{V}")#text(" with a subspace of ")#mi("{{\\mathfrak h}}")#text(" (thus for instance this identifies ")#mi("{\\alpha}")#text(" with ")#mi("{t_\\alpha}")#text("), then one can check using ")#link(<tao-7e9e5ac30f2216fd0fd6>)[#text("(19)")]#text(" and ")#link(<tao-4a8da30a4036bd2fc0ea>)[#text("(13)")]#text(" that this is a proper ideal of ")#mi("{{\\mathfrak g}}")#text(", contradicting simplicity. ")#mi("\\Box")

#text("It is easy to see that every root system is expressible as the union of irreducible root systems (on orthogonal subspaces of ")#mi("{{\\mathfrak h}^*}")#text("). As it turns out, the irreducible root systems are completely classified, with the complete list of root systems (up to isomorphism) being described in terms of the ")#link("http://en.wikipedia.org/wiki/Dynkin_diagram")[#text("Dynkin diagrams")]#text(" ")#mi("{A_n, B_n, C_n, D_n, E_6, E_7, E_8, F_4, G_2}")#text(" briefly mentioned in Theorem ")#link(<tao-0889113e04d3203f0c40>)[#text("2")]#text(". We will now turn to this classification in the next section, and then use root systems to recover the Lie algebra.")

#heading(level: 1)[#strong[#text(" — 7. Classification of root systems — ")]]

#text("In this section we classify all the irreducible root systems ")#mi("{\\Phi}")#text(" on a finite dimensional complex Hilbert space ")#mi("{{\\mathfrak h}^*}")#text(", up to Hilbert space isometry. Of course, we may take ")#mi("{{\\mathfrak h}^*}")#text(" to be a standard complex Hilbert space ")#mi("{{\\bf C}^n}")#text(" without loss of generality. The arguments here are purely elementary, proceeding purely from the root system axioms rather than from any Lie algebra theory.")

#text("Actually, we can quickly pass from the complex setting to the real setting. By axiom (v), ")#mi("{\\Phi}")#text(" contains a basis ")#mi("{\\alpha_1,\\ldots,\\alpha_n}")#text(" of ")#mi("{{\\bf C}^n}")#text("; by axiom (iv), the inner products between these basis vectors are real, as are the inner products between any other root and a basis root. From this we see that ")#mi("{\\Phi}")#text(" lies in the ")#emph[#text("real")]#text(" vector space spanned by the basis roots, so by a change of basis we may assume without loss of generality that ")#mi("{\\Phi \\subset {\\bf R}^n}")#text(".")

#text("Henceforth ")#mi("{\\Phi}")#text(" is assumed to lie in ")#mi("{{\\bf R}^n}")#text(". From two applications of (iv) we see that for any two roots ")#mi("{\\alpha,\\beta}")#text(", the expression")

#align(center)[#tao-fit-display[#mitex("\\frac{\\langle \\alpha,\\beta \\rangle}{\\langle \\alpha,\\alpha \\rangle} \\frac{\\langle \\alpha,\\beta \\rangle}{\\langle \\beta,\\beta \\rangle}")]]

#text("lies in ")#mi("{\\frac{1}{4} {\\bf Z}}")#text("; but it is also equal to ")#mi("{\\cos^2 \\angle(\\alpha,\\beta)}")#text(", and hence")

#align(center)[#tao-fit-display[#mitex("\\cos^2 \\angle(\\alpha,\\beta) \\in \\{ 0, \\frac{1}{4}, \\frac{1}{2}, \\frac{3}{4}, 1 \\}")]]

#text("for all roots ")#mi("{\\alpha,\\beta}")#text(". Analysing these cases further using (iv) again, we conclude that there are only a restricted range of options for a pair of roots ")#mi("{\\alpha,\\beta}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 26")]#text(" ")#metadata(none) <tao-ba0850ca04c64d0c9e1c>#text(" Let ")#mi("{\\alpha,\\beta}")#text(" be roots. Then one of the following occurs:")

#list(
[#text("(0) ")#mi("{\\beta}")#text(" and ")#mi("{\\alpha}")#text(" are orthogonal.")],
[#text("(1/4) ")#mi("{\\alpha,\\beta}")#text(" have the same length and subtend an angle of ")#mi("{\\pi/3}")#text(" or ")#mi("{2\\pi/3}")#text(".")],
[#text("(1/2) ")#mi("{\\alpha}")#text(" has ")#mi("{\\sqrt{2}}")#text(" times the length of ")#mi("{\\beta}")#text(" or vice versa, and ")#mi("{\\alpha,\\beta}")#text(" subtend an angle of ")#mi("{\\pi/4}")#text(" or ")#mi("{3\\pi/4}")#text(".")],
[#text("(3/4) ")#mi("{\\alpha}")#text(" has ")#mi("{\\sqrt{3}}")#text(" times the length of ")#mi("{\\beta}")#text(" or vice versa, and ")#mi("{\\alpha,\\beta}")#text(" subtend an angle of ")#mi("{\\pi/6}")#text(" or ")#mi("{5\\pi/6}")#text(".")],
[#text("(1) ")#mi("{\\beta = \\pm \\alpha}")#text(".")]
)
]

#text("We next record a useful corollary of Lemma ")#link(<tao-ba0850ca04c64d0c9e1c>)[#text("26")]#text(" (and axiom (ii)):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 27")]#text(" ")#metadata(none) <tao-b690463f073de69a7d81>#text(" Let ")#mi("{\\alpha,\\beta}")#text(" be roots. If ")#mi("{\\alpha,\\beta}")#text(" subtend an acute angle, then ")#mi("{\\alpha-\\beta}")#text(" and ")#mi("{\\beta-\\alpha}")#text(" are also roots. Equivalently, if ")#mi("{\\alpha,\\beta}")#text(" subtend an obtuse angle, then ")#mi("{\\alpha-\\beta}")#text(" and ")#mi("{\\beta-\\alpha}")#text(" are not roots.")
]

#text("This follows from a routine case analysis and is omitted.")

#text("We can leverage Corollary ")#link(<tao-b690463f073de69a7d81>)[#text("27")]#text(" as follows. Call an element ")#mi("{h}")#text(" of ")#mi("{{\\bf R}^n}")#text(" ")#emph[#text("regular")]#text(" if it is not orthogonal to any root, thus generic elements of ")#mi("{{\\bf R}^n}")#text(" are regular. Given a regular element ")#mi("{h}")#text(", let ")#mi("{\\Phi_h^+ := \\{ \\alpha \\in \\Phi: \\langle \\alpha,h\\rangle > 0 \\}}")#text(" denote the roots ")#mi("{\\alpha}")#text(" which are ")#emph[#mi("{h}")#text("-positive")]#text(" in the sense that their inner product with ")#mi("{h}")#text(" is positive; thus ")#mi("{\\Phi}")#text(" is partitioned into ")#mi("{\\Phi_h^+}")#text(" and ")#mi("{-\\Phi_h^+}")#text(". We will abbreviate ")#mi("{h}")#text("-positive as ")#emph[#text("positive")]#text(" if ")#mi("{h}")#text(" is understood from context. Call a positive root ")#mi("{\\alpha \\in \\Phi_h^+}")#text(" a ")#emph[#mi("{h}")#text("-simple root")]#text(" (or ")#emph[#text("simple root")]#text(" for short) if it cannot be written as the sum of two positive roots. Clearly every positive root is then a linear combination of simple roots with natural number coefficients. By Corollary ")#link(<tao-b690463f073de69a7d81>)[#text("27")]#text(", two simple roots cannot subtend an acute angle, and so any two distinct simple roots subtend a right or obtuse angle.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 28")]#text(" Using the root system ")#mi("{\\{ e_i -e_j: 1 \\leq i,j \\leq n; i \\neq j \\}}")#text(" of ")#mi("{\\mathfrak{sl}_n}")#text(" discussed previously, if one takes ")#mi("{h}")#text(" to be any vector in ")#mi("{{\\bf C}^n_0}")#text(" with decreasing coefficients, then the positive roots are those roots ")#mi("{e_i - e_j}")#text(" with ")#mi("{i<j}")#text(", and the simple roots are the roots ")#mi("{e_i - e_{i+1}}")#text(" for ")#mi("{1 \\leq i < n}")#text(".")
]

#text("Define an ")#emph[#text("admissible configuration")]#text(" to be a collection of unit vectors in ")#mi("{{\\bf R}^n}")#text(" in a open half-space ")#mi("{\\{ v: \\langle v,h \\rangle>0\\}}")#text(" with the property that any two vectors in this collection form an angle of ")#mi("{\\pi/2}")#text(", ")#mi("{2\\pi/3}")#text(", ")#mi("{3\\pi/4}")#text(", or ")#mi("{5\\pi/6}")#text(", and call the configuration ")#emph[#text("irreducible")]#text(" if it cannot be decomposed into two non-empty orthogonal subsets. From Lemma ")#link(<tao-ba0850ca04c64d0c9e1c>)[#text("26")]#text(" and the above discussion we see that the unit vectors ")#tao-math("{\\alpha/\\left\\|\\alpha\\right\\|}", block: false)#text(" associated to the simple roots are an admissible configuration. They are also irreducible, for if the simple roots partition into two orthogonal sets then it is not hard to show (using Corollary ")#link(<tao-b690463f073de69a7d81>)[#text("27")]#text(") that all positive roots lie in the span of one of these two sets, contradicting irreducibility of the root system.")

#text("We can say quite a bit about admissible configurations; the fact that the vectors in the system always subtend right or obtuse angles, combined with the half-space restriction, is quite limiting (basically because this information can be in violation of inequalities such as the ")#link("http://en.wikipedia.org/wiki/Bessel_inequality")[#text("Bessel inequality")]#text(", or the positive (semi-)definiteness ")#tao-math("{\\left\\| \\sum_i c_i v_i \\right\\|^2 \\geq 0}", block: false)#text(" of the ")#link("http://en.wikipedia.org/wiki/Gram_matrix")[#text("Gram matrix")]#text("). We begin with an assertion of linear independence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 29")]#text(" If ")#mi("{v_1,\\ldots,v_n}")#text(" is an admissible configuration, then it is linearly independent.")
]

#text("Among other things, this shows that the number of simple roots of a semisimple Lie algebra is equal to the rank of that algebra.")

#emph[#text("Proof:")]#text(" Suppose this is not the case, then one has a non-trivial linear constraint")

#align(center)[#tao-fit-display[#mitex("\\sum_{i \\in A} c_i v_i = \\sum_{j \\in B} c_j v_j")]]

#text("for some positive ")#mi("{c_i,c_j}")#text(" and disjoint ")#mi("{A,B \\subset \\{1,\\ldots,n\\}}")#text(". But as any two vectors in an admissible configuration subtend a right or obtuse angle, ")#mi("{\\langle \\sum_{i \\in A} c_i v_i, \\sum_{j \\in B} c_j v_j\\rangle \\leq 0}")#text(", and thus ")#mi("{\\sum_{i \\in A} c_i v_i = \\sum_{j \\in B} c_j v_j=0}")#text(". But this is not possible as all the ")#mi("{v_i}")#text(" lie in an open half-space. ")#mi("\\Box")

#text("Define the ")#link("http://en.wikipedia.org/wiki/Coxeter_diagram")[#text("Coxeter diagram")]#text(" of an admissible configuration ")#mi("{v_1,\\ldots,v_n}")#text(" to be the graph with vertices ")#mi("{v_1,\\ldots,v_n}")#text(", and with any two vertices ")#mi("{v_i,v_j}")#text(" connected by an edge of multiplicity ")#mi("{4 \\cos^2 \\angle v_i,v_j}")#text(", thus two vertices are unconnected if they are orthogonal, connected with a single edge if they subtend an angle of ")#mi("{2\\pi/3}")#text(", a double edge if they subtend an angle of ")#mi("{3\\pi/4}")#text(", and a triple edge if they subtend an angle of ")#mi("{5\\pi/6}")#text(". The irreducibility of a configuration is equivalent to the connectedness of a Coxeter diagram. Note that the Coxeter diagram describes all the inner products between the ")#mi("{v_i}")#text(" and thus describes the ")#mi("{v_i}")#text(" up to an orthogonal transformation (as can be seen for instance by applying the Gram-Schmidt process).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 30")]#text(" The Coxeter diagram of an admissible configuration is ")#link("http://en.wikipedia.org/wiki/Cycle_(graph_theory)")[#text("acyclic")]#text(" (ignoring multiplicity of edges). In particular, the Coxeter diagram of an irreducible admissible configuration is a ")#link("http://en.wikipedia.org/wiki/Tree_(graph_theory)")[#text("tree")]#text(".")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that the Coxeter diagram contains a cycle ")#mi("{v_1,\\ldots,v_n}")#text(", we see that ")#mi("{\\langle v_i,v_{i+1}\\rangle \\leq - \\frac{1}{2}}")#text(" for ")#mi("{i=1,\\ldots,n}")#text(" (with the convention ")#mi("{v_{n+1}=v_1}")#text(") and ")#mi("{\\langle v_i,v_j \\rangle \\leq 0}")#text(" for all other ")#mi("{i}")#text(". This implies that ")#tao-math("{\\left\\|\\sum_{i=1}^n v_i\\right\\|^2 \\leq 0}", block: false)#text(", which contradicts the linear independence of the ")#mi("{v_i}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 31")]#text(" ")#metadata(none) <tao-15f3b852d2465ae56ff5>#text(" Any vertex in the Coxeter diagram has degree at most three (counting multiplicity).")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{v_0}")#text(" be a vertex which is adjacent to some other vertices ")#mi("{v_1,\\ldots,v_d}")#text(", which are then an orthonormal system. By Bessel’s inequality (and linear independence) one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^d \\langle v_0,v_i\\rangle^2 < 1.")]]

#text("But from construction of the Coxeter diagram we have ")#mi("{\\langle v_0,v_i\\rangle^2 = \\frac{m_i}{4}}")#text(" for each ")#mi("{i}")#text(", where ")#mi("{m_i \\in \\{1,2,3\\}}")#text(" is the multiplicity of the edge connecting ")#mi("{v_0}")#text(" and ")#mi("{v_i}")#text(". The claim follows. ")#mi("\\Box")

#text("We can also contract simple edges:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 32")]#text(" ")#metadata(none) <tao-1143da2bc54c495c4be3>#text(" If ")#mi("{v_1,\\ldots,v_n}")#text(" is an admissible configuration with ")#mi("{v_i,v_j}")#text(" joined by a single edge, then the configuration formed from ")#mi("{v_1,\\ldots,v_n}")#text(" by replacing ")#mi("{v_i,v_j}")#text(" with the single vertex ")#mi("{v_i+v_j}")#text(" is again an admissible configuration, with the resulting Coxeter diagram formed from the original Coxeter diagram by deleting the edge between ")#mi("{v_i}")#text(" and ")#mi("{v_j}")#text(" and then identifying ")#mi("{v_i,v_j}")#text(" together.")
]

#text("This follows easily from acyclicity and direct computation.")

#text("By Lemma ")#link(<tao-15f3b852d2465ae56ff5>)[#text("31")]#text(" and Lemma ")#link(<tao-1143da2bc54c495c4be3>)[#text("32")]#text(", the Coxeter diagram can never form a vertex of degree three no matter how many simple edges are contracted. From this we can easily show that connected Coxeter diagrams must have one of the following shapes:")

#list(
[#mi("{A_n}")#text(": ")#mi("{n}")#text(" vertices joined in a chain of simple edges;")],
[#mi("{BCF_n}")#text(": ")#mi("{n}")#text(" vertices joined in a chain of edges, one of which is a double edge and all others are simple edges;")],
[#mi("{DE_n}")#text(": three chains of simple edges emenating from a common vertex (forming a “Y” shape), connecting ")#mi("{n}")#text(" vertices in all;")],
[#mi("{G_2}")#text(": Two vertices joined by a triple edge.")]
)

#text("We can cut down the ")#mi("{BCF_n}")#text(" and ")#mi("{DE_n}")#text(" cases further:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 33")]#text(" The Coxeter diagram of an admissible configuration cannot contain as a subgraph")

#list(
[#text("(a) A chain of four edges, with one of the interior edges a double edge;")],
[#text("(b) Three chains of two simple edges each, emenating from a common vertex;")],
[#text("(c) Three chains of simple edges of length ")#mi("{1, 2, 5}")#text(" respectively, emenating from a common vertex.")],
[#text("(d) Three chains of simple edges of length ")#mi("{1, 3, 3}")#text(" respectively, emenating from a common vertex.")]
)
]

#emph[#text("Proof:")]#text(" To exclude (a), suppose for contradiction that we have two chains ")#mi("{(u_1,u_2)}")#text(" and ")#mi("{(v_1,v_2,v_3)}")#text(" of simple edges, with ")#mi("{u_2,v_3}")#text(" joined by a double edge. Writing ")#mi("{U := \\frac{1}{\\sqrt{3}} (u_1+2u_2)}")#text(" and ")#mi("{V := \\frac{1}{\\sqrt{6}}(v_1+2v_2+3v_3)}")#text(", one computes that ")#mi("{U,V}")#text(" are unit vectors with inner product ")#mi("{\\langle U,V \\rangle = -1}")#text(", implying that ")#mi("{U,V}")#text(" are parallel, contradicting linear independence.")

#text("To exclude (b), suppose that we have three chains ")#mi("{(u_1,u_2,x)}")#text(", ")#mi("{(v_1,v_2,x)}")#text(", ")#mi("{(w_1,w_2,x)}")#text(" of simple edges joined at ")#mi("{x}")#text(". Then the vectors ")#mi("{U := \\frac{1}{\\sqrt{3}}(u_1+2u_2), V := \\frac{1}{\\sqrt{3}}(v_1+2v_2), W := \\frac{1}{\\sqrt{3}}(w_1+2w_2)}")#text(" are an orthonormal system that each have an inner product of ")#mi("{-1/\\sqrt{3}}")#text(" each with ")#mi("{x}")#text(". Comparing this with Bessel’s inequality we conclude that ")#mi("{x}")#text(" lies in the span of ")#mi("{U,V,W}")#text(", contradicting linear independence.")

#text("To exclude (c), suppose we have three chains ")#mi("{(u_1,x)}")#text(", ")#mi("{(v_1,v_2,x)}")#text(", ")#mi("{(w_1,w_2,w_3,w_4,w_5,x)}")#text(" of simple edges joined at ")#mi("{x}")#text(". Writing ")#mi("{U := u_1}")#text(", ")#mi("{V := \\frac{1}{\\sqrt{3}}(v_1+2v_2)}")#text(", ")#mi("{W := \\frac{1}{\\sqrt{15}}(w_1+2w_2+3w_3+4w_4+5w_5)}")#text(", we compute that ")#mi("{U,V,W}")#text(" are an orthonormal system that have inner products of ")#mi("{-1/2, -1/\\sqrt{3}, -\\frac{5}{\\sqrt{60}}}")#text(" respectively with ")#mi("{x}")#text(". As ")#mi("{\\frac{1}{4}+\\frac{1}{3}+\\frac{25}{60} = 1}")#text(", this forces ")#mi("{x}")#text(" to lie in the span of ")#mi("{U,V,W}")#text(", again contradicting linear independence.")

#text("The same argument works to exclude (d): from three chains ")#mi("{(u_1,x)}")#text(", ")#mi("{(v_1,v_2,v_3,x)}")#text(", ")#mi("{(w_1,w_2,w_3,x)}")#text(", repeat the previous argument with ")#mi("{U := u_1}")#text(", ")#mi("{V := \\frac{1}{\\sqrt{6}}(v_1+2v_2+3v_3)}")#text(", ")#mi("{W := \\frac{1}{\\sqrt{6}}(w_1+2w_2+3w_3)}")#text("; ")#mi("{U,V,W}")#text(" are now an orthonormal system with inner products of ")#mi("{-\\frac{1}{2}, -\\frac{3}{2\\sqrt{6}}, -\\frac{3}{2\\sqrt{6}}}")#text(", and as ")#mi("{\\frac{1}{4} + \\frac{3}{8} + \\frac{3}{8} = 1}")#text(" one can contradict linear independence as before. ")#mi("\\Box")

#text("We remark that one could also obtain the required contradictions in the above proof by verifying in all four cases that the ")#link("http://en.wikipedia.org/wiki/Gramian_matrix")[#text("Gram matrix")]#text(" of the subconfiguration has determinant zero.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 34")]#text(" The Coxeter diagram of an irreducible admissible configuration must take one of the following forms:")

#list(
[#mi("{A_n}")#text(": ")#mi("{n}")#text(" vertices joined in a chain of simple edges for some ")#mi("{n \\geq 1}")#text(";")],
[#mi("{BC_n}")#text(": ")#mi("{n}")#text(" vertices joined in a chain of edges for some ")#mi("{n \\geq 2}")#text(", with one boundary edge being a double edge and all other edges simple;")],
[#mi("{D_n}")#text(": Three chains of simple edges of length ")#mi("{1,1,n-3}")#text(" respectively for some ")#mi("{n \\geq 4}")#text(", emenating from a single vertex;")],
[#mi("{E_n}")#text(": Three chains of simple edges of length ")#mi("{1,2,n-4}")#text(" respectively for some ")#mi("{n=6,7,8}")#text(", emenating from a single vertex;")],
[#mi("{F_4}")#text(": Four vertices joined in a chain of edges, with the middle edge being a double edge and the other two edges simple;")],
[#mi("{G_2}")#text(": Two vertices joined by a triple edge.")]
)
]

#text("Now we return to root systems. Fixing a regular ")#mi("{h}")#text(", we define the ")#link("http://en.wikipedia.org/wiki/Dynkin_diagram")[#text("Dynkin diagram")]#text(" to be the Coxeter diagram associated to the (unit vectors of the) simple roots, except that we orient the double or triple edges to point from the longer root to the shorter root. (Note from Lemma ")#link(<tao-ba0850ca04c64d0c9e1c>)[#text("26")]#text(" that we know exactly what the ratio between lengths is in these cases; in particular, the Dynkin diagram describes the root system up to a unitary transformation and dilation.) We conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 35")]#text(" The Dynkin diagram of an irreducible root system must take one of the following forms:")

#list(
[#mi("{A_n}")#text(": ")#mi("{n}")#text(" vertices joined in a chain of simple edges for some ")#mi("{n \\geq 1}")#text(";")],
[#mi("{B_n}")#text(": ")#mi("{n}")#text(" vertices joined in a chain of edges for some ")#mi("{n \\geq 2}")#text(", with one boundary edge being a double edge (pointing outward) and all other edges simple;")],
[#mi("{C_n}")#text(": ")#mi("{n}")#text(" vertices joined in a chain of edges for some ")#mi("{n \\geq 3}")#text(", with one boundary edge being a double edge (pointing inward) and all other edges simple;")],
[#mi("{D_n}")#text(": Three chains of simple edges of length ")#mi("{1,1,n-3}")#text(" respectively for some ")#mi("{n \\geq 4}")#text(", emenating from a single vertex;")],
[#mi("{E_n}")#text(": Three chains of simple edges of length ")#mi("{1,2,n-4}")#text(" respectively for some ")#mi("{n=6,7,8}")#text(", emenating from a single vertex;")],
[#mi("{F_4}")#text(": Four vertices joined in a chain of edges, with the middle edge being a double (oriented) edge and the other two edges simple;")],
[#mi("{G_2}")#text(": Two vertices joined by a triple (oriented) edge.")]
)
]

#text("??? This describes (up to isomorphism and dilation) the simple roots:")

#list(
[#mi("{A_n}")#text(": The simple roots take the form ")#mi("{e_i - e_{i+1}}")#text(" for ")#mi("{1 \\leq i \\leq n+1}")#text(" in the space ")#mi("{{\\bf C}^{n+1}_0}")#text(" of vectors whose coefficients sum to zero;")],
[#mi("{B_n}")#text(": The simple roots take the form ")#mi("{e_i-e_{i+1}}")#text(" for ")#mi("{1 \\leq i \\leq n-1}")#text(" and also ")#mi("{e_n}")#text(" in ")#mi("{{\\bf C}^n}")#text(".")],
[#mi("{C_n}")#text(": The simple roots take the form ")#mi("{e_i-e_{i+1}}")#text(" for ")#mi("{1 \\leq i \\leq n-1}")#text(" and also ")#mi("{2e_n}")#text(" in ")#mi("{{\\bf C}^n}")#text(".")],
[#mi("{D_n}")#text(": The simple roots take the form ")#mi("{e_i-e_{i+1}}")#text(" for ")#mi("{1 \\leq i \\leq n-1}")#text(" and also ")#mi("{e_{n-1}+e_n}")#text(" in ")#mi("{{\\bf C}^n}")#text(".")],
[#mi("{E_8}")#text(": The simple roots take the form ")#mi("{e_i-e_{i+1}}")#text(" for ")#mi("{1 \\leq i \\leq 6}")#text(" and also ")#mi("{e_6+e_7}")#text(" and ")#mi("{-\\frac{1}{2}\\sum_{i=1}^8 e_i}")#text(" in ")#mi("{{\\bf C}^8}")#text(".")],
[#mi("{E_6,E_7}")#text(": This system is obtained from ")#mi("{E_8}")#text(" by deleting the first one or two simple roots (and cutting down ")#mi("{{\\bf C}^8}")#text(" appropriately)")],
[#mi("{F_4}")#text(": The simple roots take the form ")#mi("{e_i-e_{i+1}}")#text(" for ")#mi("{1 \\leq i \\leq 2}")#text(" and also ")#mi("{e_3}")#text(" and ")#mi("{-\\frac{1}{2} \\sum_{i=1}^4 e_i}")#text(" in ")#mi("{{\\bf C}^4}")#text(".")],
[#mi("{G_2}")#text(": The simple roots take the form ")#mi("{e_1-e_2}")#text(", ")#mi("{e_3-2e_2+e_1}")#text(" in ")#mi("{{\\bf C}^3_0}")#text(".")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 36")]#text(" A slightly different way to reach the classification is to replace the Dynkin diagram by the ")#emph[#text("extended Dynkin diagram")]#text(" in which one also adds the maximal negative root in addition to the simple roots; this breaks the linear independence, but one can then label each vertex by the coefficient in the linear combination needed to make the roots sum to zero, and one can then analyse these multiplicities to classify the possible diagrams and thence the root systems.")
]

#text("Now we show how the simple roots can be used to recover the entire root system. Define the ")#link("http://en.wikipedia.org/wiki/Weyl_group")[#text("Weyl group")]#text(" ")#mi("{W}")#text(" to be the group generated by all the reflections ")#mi("{s_\\alpha}")#text(" coming from all the roots ")#mi("{\\alpha}")#text("; as the roots span ")#mi("{{\\bf R}^n}")#text(" and obey axiom (ii), the Weyl group acts faithfully on the finite set ")#mi("{\\Phi}")#text(" and is thus itself finite.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 37")]#text(" Let ")#mi("{h}")#text(" be regular, and let ")#mi("{h^{\\prime}}")#text(" be any element of ")#mi("{{\\bf R}^n}")#text(". Then there exists ")#mi("{w \\in W}")#text(" such that ")#mi("{\\langle w(h^{\\prime}), \\alpha \\rangle \\geq 0}")#text(" for all ")#mi("{h}")#text("-simple roots ")#mi("{\\alpha}")#text(" (or equivalently, for all ")#mi("{h}")#text("-positive roots ")#mi("{\\alpha}")#text("). In particular, if ")#mi("{h^{\\prime}}")#text(" is regular, then ")#mi("{\\Phi_{w(h^{\\prime})}^+ = \\Phi_h^+}")#text(", so that all ")#mi("{h}")#text("-simple roots are ")#mi("{w(h^{\\prime})}")#text("-simple and vice versa.")

#text("Furthermore, every root can be mapped by an element of ")#mi("{W}")#text(" to an ")#mi("{h}")#text("-simple root.")

#text("Finally, ")#mi("{W}")#text(" is generated by the reflections ")#mi("{s_\\alpha}")#text(" coming from the ")#mi("{h}")#text("-simple roots ")#mi("{\\alpha}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{\\alpha}")#text(" be a simple root. The action of the reflection ")#mi("{s_\\alpha}")#text(" maps ")#mi("{\\alpha}")#text(" to ")#mi("{-\\alpha}")#text(", and maps all other simple roots ")#mi("{\\beta}")#text(" to ")#mi("{\\beta+m\\alpha}")#text(" for some non-negative ")#mi("{m}")#text(" (since ")#mi("{\\alpha,\\beta}")#text(" subtend a right or obtuse angle). In particular, we see that ")#mi("{s_\\alpha}")#text(" maps all positive roots other than ")#mi("{\\alpha}")#text(" to positive roots, and hence (as ")#mi("{s_\\alpha}")#text(" is an involution)")

#align(center)[#tao-fit-display[#mitex("s_\\alpha(\\Phi_h^+) = \\Phi_h^+ \\cup \\{-\\alpha\\} \\backslash \\{\\alpha\\}.")]]

#text("In particular, if we define ")#mi("{\\rho := \\frac{1}{2} \\sum_{\\beta \\in \\Phi_h^+} \\beta}")#text(", then ")#metadata(none) <tao-bdb8ec313eb09be46a25>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("s_\\alpha(\\rho) = \\rho-\\alpha")]]

#text(" for all simple roots ")#mi("{\\alpha}")#text(".")

#text("Let ")#mi("{W_h}")#text(" be the subgroup of ")#mi("{W}")#text(" generated by the ")#mi("{s_\\alpha}")#text(" for the simple roots ")#mi("{\\alpha}")#text(", and choose ")#mi("{w \\in W_h}")#text(" to maximise ")#mi("{\\langle w(h^{\\prime}), \\rho \\rangle}")#text(". Then from ")#link(<tao-bdb8ec313eb09be46a25>)[#text("(17)")]#text(" we have ")#mi("{\\langle w(h^{\\prime}),\\alpha \\rangle \\geq 0}")#text(", giving the first claim. Since every root ")#mi("{\\alpha}")#text(" is ")#mi("{h^{\\prime}}")#text("-simple for some regular ")#mi("{h^{\\prime}}")#text(" (by selecting ")#mi("{h^{\\prime}}")#text(" to very nearly be orthogonal to ")#mi("{\\alpha}")#text("), we conclude that every root can be mapped by an element of ")#mi("{W_h}")#text(" to a ")#mi("{h}")#text("-simple root in ")#mi("{h}")#text(", giving the second claim. Thus for any root ")#mi("{\\beta}")#text(", ")#mi("{s_\\beta}")#text(" is conjugate in ")#mi("{W_h}")#text(" to a reflection ")#mi("{s_\\alpha}")#text(" for a ")#mi("{h}")#text("-simple root ")#mi("{\\alpha}")#text(", so ")#mi("{s_\\beta}")#text(" lies in ")#mi("{W_h}")#text(" and so ")#mi("{W=W_h}")#text(", giving the final claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 38")]#text(" The set of all ")#mi("{h^{\\prime}}")#text(" for which ")#mi("{\\Phi_{h^{\\prime}}^+ = \\Phi_h^+}")#text(" is known as the ")#link("http://en.wikipedia.org/wiki/Weyl_group")[#text("Weyl chamber")]#text(" associated to ")#mi("{h}")#text("; this is an open polyhedral cone in ")#mi("{{\\bf R}^n}")#text(", and the above lemma shows that it is the interior of a fundamental domain of the action of the Weyl group. In the case of the special linear group, the standard Weyl chamber (in ")#mi("{{\\bf R}^n_0}")#text(" now instead of ")#mi("{{\\bf R}^n}")#text(") would be the set of vectors ")#mi("{h^{\\prime} \\in {\\bf R}^n_0}")#text(" with decreasing coefficients.")
]

#text("From the above lemma we can reconstruct the root system from the simple roots by using the reflections ")#mi("{s_\\alpha}")#text(" associated to the simple roots to generate the Weyl group ")#mi("{W}")#text(", and then applying the Weyl group to the simple roots to recover all the roots. Note that the lemma also shows that the set of ")#mi("{h}")#text("-simple roots and ")#mi("{h^{\\prime}}")#text("-simple roots are isomorphic for any regular ")#mi("{h,h^{\\prime}}")#text(", so that the Dynkin diagram is indeed independent (up to isomorphism) of the choice of regular element ")#mi("{h}")#text(" as claimed earlier. We have thus in principle described the irreducible root systems (up to isomorphism) as coming from the Dynkin diagrams ")#mi("{A_n,B_n,C_n,D_n,E_6,E_7,E_8,F_4,G_2}")#text("; see for instance the ")#link("http://en.wikipedia.org/wiki/Root_system")[#text("Wikipedia page on root systems")]#text(" for explicit descriptions of all of these. With these explicit descriptions one can verify that all of these systems are indeed irreducible root systems.")

#heading(level: 1)[#strong[#text(" — 8. Chevalley bases — ")]]

#text("Now that we have described root systems, we use them to reconstruct Lie algebras. We first begin with an abstract uniqueness result that shows that a simple Lie algebra is determined up to isomorphism by its root system.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 39 (Root system uniquely determines a simple Lie algebra)")]#text(" ")#metadata(none) <tao-e067a42ccd18bb72c51c>#text(" Let ")#mi("{{\\mathfrak g}, \\tilde {\\mathfrak g}}")#text(" be simple Lie algebras with Cartan subalgebras ")#mi("{{\\mathfrak h}}")#text(", ")#mi("{\\tilde {\\mathfrak h}}")#text(" and root systems ")#mi("{\\Phi \\subset {\\mathfrak h}^*}")#text(", ")#mi("{\\tilde \\Phi \\subset \\tilde {\\mathfrak h}^*}")#text(". Suppose that one can identify ")#mi("{{\\mathfrak h}}")#text(" with ")#mi("{\\tilde {\\mathfrak h}}")#text(" as vector spaces in such a way that the root systems agree: ")#mi("{\\Phi = \\tilde \\Phi}")#text(". Then the identification between ")#mi("{{\\mathfrak h}}")#text(" and ")#mi("{\\tilde {\\mathfrak h}}")#text(" can be extended to an identification of ")#mi("{{\\mathfrak g}}")#text(" and ")#mi("{\\tilde {\\mathfrak g}}")#text(" as Lie algebras.")
]

#emph[#text("Proof:")]#text(" First we note from ")#link(<tao-fb0b23773a1f394e1a57>)[#text("(11)")]#text(" and the identification ")#mi("{\\Phi=\\tilde \\Phi}")#text(" that the Killing forms on ")#mi("{{\\mathfrak h}}")#text(" and ")#mi("{\\tilde {\\mathfrak h}}")#text(" agree, so we will identify ")#mi("{{\\mathfrak h}, \\tilde {\\mathfrak h}}")#text(" as Hilbert spaces, not just as vector spaces.")

#text("The strategy will be exploit a Lie algebra version of the ")#link("http://en.wikipedia.org/wiki/Goursat_lemma")[#text("Goursat lemma")]#text(" (or the ")#link("http://en.wikipedia.org/wiki/Schur_lemma")[#text("Schur lemma")]#text("), finding a sufficiently “non-degenerate” subalgebra ")#mi("{{\\mathfrak k}}")#text(" of ")#mi("{{\\mathfrak g} \\oplus \\tilde {\\mathfrak g}}")#text(" and using the simple nature of ")#mi("{{\\mathfrak g}}")#text(" and ")#mi("{\\tilde {\\mathfrak g}}")#text(" to show that this subalgebra is the graph of an isomorphism from ")#mi("{{\\mathfrak g}}")#text(" to ")#mi("{\\tilde {\\mathfrak g}}")#text(". This strategy will follow the same general strategy used in Theorem ")#link(<tao-7a9767fb84376073d114>)[#text("20")]#text(", namely to start with a “highest weight” space and apply lowering operators to discover the required graph.")

#text("We turn to the details. Pick a regular element ")#mi("{h}")#text(" of ")#mi("{{\\mathfrak h} =\\tilde {\\mathfrak h}}")#text(", so that one has a notion of a positive root. For every simple root ")#mi("{\\alpha}")#text(", we select non-zero elements ")#mi("{X_\\alpha, Y_\\alpha}")#text(", of ")#mi("{{\\mathfrak g}^{\\mathfrak h}_\\alpha, {\\mathfrak g}^{\\mathfrak h}_{-\\alpha}}")#text(" respectively such that ")#metadata(none) <tao-c8aada734719b55cacc9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("[X_\\alpha,Y_\\alpha] = H_\\alpha")]]

#text(" where ")#mi("{H_\\alpha}")#text(" is the co-root of ")#mi("{\\alpha}")#text("; similarly select ")#mi("{\\tilde X_\\alpha, \\tilde Y_\\alpha}")#text(" in ")#mi("{\\tilde {\\mathfrak g}^{\\mathfrak h}_\\alpha, \\tilde {\\mathfrak g}^{\\mathfrak h}_{-\\alpha}}")#text(", and set ")#mi("{X^{\\prime}_\\alpha := X_\\alpha \\oplus \\tilde X_\\alpha}")#text(" and ")#mi("{Y^{\\prime}_\\alpha := Y_\\alpha \\oplus \\tilde Y_\\alpha}")#text(". Let ")#mi("{{\\mathfrak k}}")#text(" be the subalgebra of ")#mi("{{\\mathfrak g} \\oplus {\\mathfrak g}^{\\prime} }")#text(" generated by the ")#mi("{X^{\\prime}_\\alpha}")#text(" and ")#mi("{Y^{\\prime}_\\alpha}")#text(". It is not hard to see that the ")#mi("{X_\\alpha, Y_\\alpha}")#text(" generate ")#mi("{{\\mathfrak g}}")#text(" as a Lie algebra, so ")#mi("{{\\mathfrak k}}")#text(" surjects onto ")#mi("{{\\mathfrak g}}")#text("; similarly ")#mi("{{\\mathfrak k}}")#text(" surjects onto ")#mi("{{\\mathfrak g}^{\\prime} }")#text(".")

#text("Let ")#mi("{\\beta}")#text(" be a maximal root, that is to say a root such that ")#mi("{\\beta+\\alpha}")#text(" is not a root for any positive ")#mi("{\\alpha}")#text("; such a root always exists. (It is in fact unique, though we will not need this fact here.) Then we have one-dimensional spaces ")#mi("{{\\mathfrak g}^{\\mathfrak h}_\\beta}")#text(" and ")#mi("{\\tilde {\\mathfrak g}^{\\mathfrak h}_\\beta}")#text(", and thus a two-dimensional subspace ")#mi("{{\\mathfrak g}^{\\mathfrak h}_\\beta \\oplus \\tilde {\\mathfrak g}^{\\mathfrak h}_\\beta}")#text(" in ")#mi("{{\\mathfrak g} \\oplus \\tilde {\\mathfrak g}}")#text(". Inside this subspace, we select a one-dimensional subspace ")#mi("{L}")#text(" which is not equal to ")#mi("{{\\mathfrak g}^{\\mathfrak h}_\\beta \\oplus 0}")#text(" or ")#mi("{0 \\times \\tilde {\\mathfrak g}^{\\mathfrak h}_\\beta}")#text("; in particular, ")#mi("{L}")#text(" is not contained in ")#mi("{{\\mathfrak g} \\oplus 0}")#text(" or ")#mi("{0 \\oplus \\tilde {\\mathfrak g}}")#text(".")

#text("Let ")#mi("{{\\mathfrak l}}")#text(" be the subspace of ")#mi("{{\\mathfrak g} \\oplus {\\mathfrak g}^{\\prime} }")#text(" generated by ")#mi("{L}")#text(" and the adjoint action of the lowering operators ")#mi("{Y^{\\prime}_\\alpha}")#text(", thus it is spanned by elements of the form ")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\text{ad} Y^{\\prime}_{\\alpha_1} \\ldots \\text{ad} Y^{\\prime}_{\\alpha_k} x")]]

#text(" for simple roots ")#mi("{\\alpha_1,\\ldots,\\alpha_k}")#text(" and ")#mi("{x \\in L}")#text(". Then ")#mi("{{\\mathfrak l}}")#text(" contains ")#mi("{L}")#text(" and is thus not contained in ")#mi("{{\\mathfrak g} \\oplus 0, 0 \\oplus \\tilde {\\mathfrak g}}")#text("; because ")#link(<tao-7e9e5ac30f2216fd0fd6>)[#text("(19)")]#text(" only involves lowering operators, we also see that ")#mi("{L}")#text(" does not contain any other element of ")#mi("{{\\mathfrak g}^{\\mathfrak h}_\\beta \\oplus \\tilde {\\mathfrak g}^{\\mathfrak h}_\\beta}")#text(" other than ")#mi("{{\\mathfrak l}}")#text(". In particular, ")#mi("{L}")#text(" is not all of ")#mi("{{\\mathfrak g} \\oplus \\tilde {\\mathfrak g}}")#text(".")

#text("Clearly ")#mi("{{\\mathfrak l}}")#text(" is closed under the adjoint action of the lowering operators ")#mi("{Y^{\\prime}_\\alpha}")#text(". We claim that it is also closed under the adjoint action of the raising operators ")#mi("{X^{\\prime}_\\alpha}")#text(". To see this, first observe that ")#mi("{X^{\\prime}_\\alpha, Y^{\\prime}_\\gamma}")#text(" commute when ")#mi("{\\alpha,\\gamma}")#text(" are distinct simple roots, because ")#mi("{\\alpha-\\beta}")#text(" cannot be a root (since this would make one of ")#mi("{\\alpha,\\gamma}")#text(" non-simple). Next, from ")#link(<tao-c8aada734719b55cacc9>)[#text("(18)")]#text(" we see that ")#mi("{\\text{ad} X^{\\prime}_\\alpha \\text{ad} Y^{\\prime}_\\alpha}")#text(" acts as a scalar on any element of the form ")#link(<tao-7e9e5ac30f2216fd0fd6>)[#text("(19)")]#text(", while from the maximality of ")#mi("{\\beta}")#text(" we see that ")#mi("{\\text{ad} X^{\\prime}_\\alpha}")#text(" annihilates ")#mi("{x}")#text(". From this the claim easily follows.")

#text("As ")#mi("{{\\mathfrak l}}")#text(" is closed under the adjoint action of both the ")#mi("{X^{\\prime}_\\alpha}")#text(" and the ")#mi("{Y^{\\prime}_\\alpha}")#text(", we have ")#mi("{[{\\mathfrak k},{\\mathfrak l}] \\subset {\\mathfrak l}}")#text(". Projecting onto ")#mi("{{\\mathfrak g}}")#text(", we see that the projection of ")#mi("{{\\mathfrak l}}")#text(" is an ideal of ")#mi("{{\\mathfrak g}}")#text(", and is hence ")#mi("{0}")#text(" or ")#mi("{{\\mathfrak g}}")#text(" as ")#mi("{{\\mathfrak g}}")#text(" is simple. As ")#mi("{{\\mathfrak l}}")#text(" is not contained in ")#mi("{0 \\oplus \\tilde {\\mathfrak g}}")#text(", we see that ")#mi("{{\\mathfrak l}}")#text(" surjects onto ")#mi("{{\\mathfrak g}}")#text("; similarly it surjects onto ")#mi("{\\tilde {\\mathfrak g}}")#text(". An analogous argument shows that the intersection of ")#mi("{{\\mathfrak l}}")#text(" with ")#mi("{{\\mathfrak g} \\oplus 0}")#text(" is either ")#mi("{0}")#text(" or ")#mi("{{\\mathfrak g} \\oplus 0}")#text("; the latter would force ")#mi("{{\\mathfrak l} = {\\mathfrak g} \\oplus \\tilde {\\mathfrak g}}")#text(" by the surjective projection onto ")#mi("{\\tilde {\\mathfrak g}}")#text(", which was already ruled out. Thus ")#mi("{{\\mathfrak l}}")#text(" has trivial intersection with ")#mi("{{\\mathfrak g} \\oplus 0}")#text(", and similarly with ")#mi("{0 \\oplus \\tilde {\\mathfrak g}}")#text(", and is thus a graph. Such a graph cannot be an ideal of ")#mi("{{\\mathfrak g} \\oplus \\tilde {\\mathfrak g}}")#text(", so that ")#mi("{{\\mathfrak k} \\neq {\\mathfrak g} \\oplus \\tilde {\\mathfrak g}}")#text(". As ")#mi("{{\\mathfrak k}}")#text(" was a subalgebra that surjected onto both ")#mi("{{\\mathfrak g}}")#text(" and ")#mi("{\\tilde {\\mathfrak g}}")#text(", we conclude by arguing as before that ")#mi("{{\\mathfrak k}}")#text(" is also a graph; as ")#mi("{{\\mathfrak k}}")#text(" is a Lie algebra, the graph is that of a Lie algebra isomorphism by the Lie algebra closed graph theorem (see ")#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/")[#text("this previous blog post")]#text("). Since ")#mi("{[X^{\\prime}_\\alpha,Y^{\\prime}_\\alpha] = H_\\alpha \\oplus H_\\alpha}")#text(", we see that ")#mi("{{\\mathfrak k}}")#text(" restricts to the graph of the identity on ")#mi("{{\\mathfrak h}}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 40")]#text(" The above arguments show that every root can be obtained from the maximal root by iteratively subtracting off simple roots (while staying in ")#mi("{\\Phi \\cup \\{0\\}}")#text("), which among other things implies that the maximal root is unique. These facts can also be established directly from the axioms of a root system (or from the classification of root systems), but we will not do so here. By using Theorem ")#link(<tao-e067a42ccd18bb72c51c>)[#text("39")]#text(", one can convert graph automorphisms of the Dynkin diagram (e.g. the automorphism sending the ")#mi("{A_n}")#text(" Dynkin diagram to its inverse, or the ")#link("http://en.wikipedia.org/wiki/Triality")[#text("triality")]#text(" automorphism that rotates the ")#mi("{D_4}")#text(" diagram) to automorphisms of the Lie algebra; these are important in the theory of twisted ")#link("http://en.wikipedia.org/wiki/Groups_of_lie_type")[#text("groups of Lie type")]#text(", and more specifically the ")#link("http://en.wikipedia.org/wiki/Groups_of_lie_type#Steinberg_groups")[#text("Steinberg groups")]#text(" and ")#link("http://en.wikipedia.org/wiki/Groups_of_lie_type#Suzuki.E2.80.93Ree_groups")[#text("Suzuki-Ree groups")]#text(", but will not be discussed further here.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 41")]#text(" In a converse direction, once one establishes that in an irreducible root system ")#mi("{\\Phi}")#text(" that every root can be obtained from the maximal root by subtracting off simple roots (while staying in ")#mi("{\\Phi \\cup \\{0\\}}")#text("), this shows that any Lie algebra ")#mi("{{\\mathfrak g}}")#text(" associated to this system is necessarily simple. Indeed, given any non-trivial ideal ")#mi("{{\\mathfrak h}}")#text(" in ")#mi("{{\\mathfrak g}}")#text(" and a non-trivial element ")#mi("{x}")#text(" of ")#mi("{{\\mathfrak h}}")#text(", one locates a minimal element of ")#mi("{\\Phi \\cup \\{0\\}}")#text(" in which ")#mi("{x}")#text(" has a non-trivial component, then iteratively applies raising operators to then locate a non-trivial element of the root space of the maximal root in ")#mi("{{\\mathfrak h}}")#text("; if one then applies lowering operators one recovers all the other root spaces, so that ")#mi("{{\\mathfrak h}={\\mathfrak g}}")#text(".")
]

#text("Theorem ")#link(<tao-e067a42ccd18bb72c51c>)[#text("39")]#text(", when combined with the results from previous sections, already gives Theorem ")#link(<tao-0889113e04d3203f0c40>)[#text("2")]#text(", but without a fully explicit way to determine the Lie algebras ")#mi("{A_n,B_n,C_n,D_n,E_6,E_7,E_8,F_4,G_2}")#text(" listed in that theorem (or even to establish whether these systems exist at all). In the case of the ")#link("http://en.wikipedia.org/wiki/Classical_Lie_algebra")[#text("classical Lie algebras")]#text(" ")#mi("{A_n,B_n,C_n,D_n}")#text(", one can explicitly describe these algebras in terms of the ")#link("http://en.wikipedia.org/wiki/Special_linear_algebra")[#text("special linear algebras")]#text(" ")#mi("{\\mathfrak{sl}_n}")#text(", ")#link("http://en.wikipedia.org/wiki/Special_orthogonal_group")[#text("special orthogonal algebras")]#text(" ")#mi("{\\mathfrak{so}_n}")#text(", and ")#link("http://en.wikipedia.org/wiki/Symplectic_group")[#text("symplectic algebras")]#text(" ")#mi("{\\mathfrak{sp}_n}")#text(", but this does not give too much guidance as to how to explicitly describe the ")#emph[#text("exceptional Lie algebras")]#text(" ")#mi("{E_6,E_7,E_8,F_4,G_2}")#text(". We now turn to the question of how to explicitly describe all the simple Lie algebras in a unified fashion.")

#text("Let ")#mi("{{\\mathfrak g}}")#text(" be a simple Lie algebra, with Cartan algebra ")#mi("{{\\mathfrak h}}")#text(". We view ")#mi("{{\\mathfrak h}}")#text(" as a Hilbert space with the Killing form, and then identify this space with its dual ")#mi("{{\\mathfrak h}^*}")#text(". Thus for instance the coroot ")#mi("{H_\\alpha}")#text(" of a root ")#mi("{\\alpha \\in {\\mathfrak h}^* \\equiv {\\mathfrak h}}")#text(" is now given by the simpler formula ")#metadata(none) <tao-a11ae06469c63740d7b0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("H_\\alpha = \\frac{2}{\\langle\\alpha,\\alpha\\rangle} \\alpha.")]]



#text("Let ")#mi("{\\Phi \\subset {\\mathfrak h}^* \\equiv {\\mathfrak h}}")#text(" be the root system, which is irreducible. As described in Section ")#link(<tao-02892b235fa087c7e3e7>)[#text("6")]#text(", we have the vector space decomposition")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak g} \\equiv {\\mathfrak h} \\oplus \\bigoplus_{\\alpha \\in \\Phi} {\\mathfrak g}^{\\mathfrak h}_\\alpha")]]

#text("where the spaces ")#mi("{{\\mathfrak g}^{\\mathfrak h}_\\alpha}")#text(" are one-dimensional, thus we can choose a generator ")#mi("{E_\\alpha}")#text(" for each ")#mi("{{\\mathfrak g}^{\\mathfrak h}_\\alpha}")#text(", though we have the freedom to multiply each ")#mi("{E_\\alpha}")#text(" by a complex constant, which we will take advantage of to perform various normalisations. A basis for algebra ")#mi("{{\\mathfrak h}}")#text(" together with the ")#mi("{E_\\alpha}")#text(" then form a basis for ")#mi("{{\\mathfrak g}}")#text(", known as a ")#emph[#text("Cartan-Weyl basis")]#text(" for this Lie algebra. From ")#link(<tao-fb0b23773a1f394e1a57>)[#text("(11)")]#text(", ")#link(<tao-a11ae06469c63740d7b0>)[#text("(20)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("[H_\\alpha, E_\\beta] = A_{\\alpha,\\beta} E_\\beta")]]

#text("where ")#mi("{A_{\\alpha,\\beta}}")#text(" is the quantity")

#align(center)[#tao-fit-display[#mitex("A_{\\alpha,\\beta} := \\frac{2\\langle \\alpha,\\beta\\rangle}{\\langle \\alpha,\\alpha\\rangle}")]]

#text("which is always an integer because ")#mi("{\\Phi}")#text(" is a root system (indeed ")#mi("{A_{\\alpha,\\beta}}")#text(" takes values in ")#mi("{\\{ 0, \\pm 1, \\pm 2, \\pm 3 \\}}")#text(", and form an interesting matrix known as the ")#link("http://en.wikipedia.org/wiki/Cartan_matrix")[#text("Cartan matrix")]#text(").")

#text("As discussed in Section ")#link(<tao-02892b235fa087c7e3e7>)[#text("6")]#text(", ")#mi("{[E_\\alpha, E_{-\\alpha}]}")#text(" is a multiple of the coroot ")#mi("{H_\\alpha}")#text("; by adjusting ")#mi("{E_\\alpha,E_{-\\alpha}}")#text(" for each pair ")#mi("{\\{\\alpha,-\\alpha\\}}")#text(" we may normalise things so that ")#metadata(none) <tao-10d8884e2c31326a325c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("[E_\\alpha, E_{-\\alpha}] = H_\\alpha")]]

#text(" for all ")#mi("{\\alpha}")#text(" (here we use the fact that ")#mi("{H_{-\\alpha} = -H_\\alpha}")#text(" to avoid inconsistency). Next, we see from ")#link(<tao-7e9e5ac30f2216fd0fd6>)[#text("(19)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("[E_\\alpha, E_\\beta] = 0")]]

#text("if ")#mi("{\\alpha+\\beta \\not \\in \\Phi \\cup \\{0\\}}")#text(", and ")#metadata(none) <tao-00bd77de181369e887fe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("[E_\\alpha, E_\\beta] = N_{\\alpha,\\beta} E_{\\alpha+\\beta}")]]

#text(" for some complex number ")#mi("{N_{\\alpha,\\beta}}")#text(" if ")#mi("{\\alpha+\\beta \\in \\Phi}")#text(". By considering the action of ")#mi("{E_\\alpha}")#text(" on ")#link(<tao-b34138a022fc6ca55ae8>)[#text("(16)")]#text(" using Theorem ")#link(<tao-7a9767fb84376073d114>)[#text("20")]#text(" one can verify that ")#mi("{N_{\\alpha,\\beta}}")#text(" is non-zero; however, its value is not yet fully determined because there is still residual freedom to normalise the ")#mi("{E_\\alpha}")#text(". Indeed, one has the freedom to multiply ")#mi("{E_\\alpha}")#text(" by any non-zero complex scalar ")#mi("{c_\\alpha}")#text(" as long as ")#mi("{c_{-\\alpha} = c_\\alpha^{-1}}")#text(" (to preserve the normalisation ")#link(<tao-10d8884e2c31326a325c>)[#text("(21)")]#text("), in which case the structure constant ")#mi("{N_{\\alpha,\\beta}}")#text(" gets transformed according to the law ")#metadata(none) <tao-8f1f74adf65864c86d3d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("N_{\\alpha,\\beta} \\mapsto \\frac{c_\\alpha c_\\beta}{c_{\\alpha+\\beta}} N_{\\alpha,\\beta}.")]]

#text(" However, observe that the combined structure constant ")#mi("{N_{\\alpha,\\beta} N_{-\\alpha,-\\beta}}")#text(" is unchanged by this rescaling. And indeed there is an explicit formula for this quantity:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 42")]#text(" For any roots ")#mi("{\\alpha,\\beta}")#text(" with ")#mi("{\\alpha+\\beta \\in \\Phi}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("N_{\\alpha,\\beta} N_{-\\alpha,-\\beta} = (r+1)^2")]]

#text("where ")#mi("{\\beta-r\\alpha,\\ldots,\\beta,\\ldots,\\beta+q\\alpha}")#text(" are the string of roots of the form ")#mi("{\\beta + m\\alpha}")#text(" for integer ")#mi("{m}")#text(".")
]

#text("This formula can be confirmed by an explicit computation using Theorem ")#link(<tao-7a9767fb84376073d114>)[#text("20")]#text(" (using, say, the standard basis for ")#mi("{P_n}")#text(" to select ")#mi("{E_{\\beta+m\\alpha}}")#text(", which then fixes ")#mi("{E_{-\\beta-m\\alpha}}")#text(" by ")#link(<tao-10d8884e2c31326a325c>)[#text("(21)")]#text("); we omit the details.")

#text("On the other hand, we have the following clever renormalisation trick of Chevalley, exploiting the abstract isomorphism from Theorem ")#link(<tao-e067a42ccd18bb72c51c>)[#text("39")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 43 (Chevalley normalisation)")]#text(" There exist choices of ")#mi("{E_\\alpha}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("N_{\\alpha,\\beta} = N_{-\\alpha,-\\beta}")]]

#text("for all roots ")#mi("{\\alpha,\\beta}")#text(" with ")#mi("{\\alpha+\\beta \\in \\Phi}")#text(".")
]

#emph[#text("Proof:")]#text(" We first select ")#mi("{E_\\alpha}")#text(" arbitrarily, then we will have")

#align(center)[#tao-fit-display[#mitex("N_{\\alpha,\\beta} = a_{\\alpha,\\beta} N_{-\\alpha,-\\beta}")]]

#text("for some non-zero ")#mi("{a_{\\alpha,\\beta}}")#text(" for all roots ")#mi("{\\alpha,\\beta}")#text(". The plan is then to locate coefficients ")#mi("{c_\\alpha}")#text(" so that the transformation ")#link(<tao-8f1f74adf65864c86d3d>)[#text("(23)")]#text(" eliminates all of the ")#mi("{a_{\\alpha,\\beta}}")#text(" factors.")

#text("To do this, observe that we may identify ")#mi("{{\\mathfrak h}}")#text(" with itself and ")#mi("{\\Phi}")#text(" with itself via the negation map ")#mi("{x \\mapsto -x}")#text(" for ")#mi("{x \\in {\\mathfrak h}}")#text(" and ")#mi("{\\alpha \\mapsto -\\alpha}")#text(" for ")#mi("{\\alpha \\in \\Phi}")#text(". From this and Theorem ")#link(<tao-e067a42ccd18bb72c51c>)[#text("39")]#text(", we may find a Lie algebra isomorphism ")#mi("{\\phi: {\\mathfrak g} \\rightarrow {\\mathfrak g}}")#text(" that maps ")#mi("{x}")#text(" to ")#mi("{-x}")#text(" on ")#mi("{{\\mathfrak h}}")#text(", and thus maps ")#mi("{{\\mathfrak g}^{\\mathfrak h}_\\alpha}")#text(" to ")#mi("{{\\mathfrak g}^{\\mathfrak h}_{-\\alpha}}")#text(" for any root ")#mi("{\\alpha}")#text(". In particular, we have")

#align(center)[#tao-fit-display[#mitex("\\phi( E_\\alpha ) = b_\\alpha E_{-\\alpha}")]]

#text("for some non-zero coefficients ")#mi("{b_\\alpha}")#text("; from ")#link(<tao-10d8884e2c31326a325c>)[#text("(21)")]#text(" we see in particular that ")#metadata(none) <tao-1759f7a2eb8085ca9435>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("b_\\alpha b_{-\\alpha} = 1.")]]

#text(" If we then apply ")#mi("{\\phi}")#text(" to ")#link(<tao-00bd77de181369e887fe>)[#text("(22)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("b_\\alpha b_\\beta N_{-\\alpha,-\\beta} = b_{\\alpha+\\beta} N_{\\alpha,\\beta}")]]

#text("when ")#mi("{\\alpha+\\beta}")#text(" is a root, so that ")#mi("{a_{\\alpha,\\beta}}")#text(" takes the special form")

#align(center)[#tao-fit-display[#mitex("a_{\\alpha,\\beta} = \\frac{b_\\alpha b_\\beta}{b_{\\alpha+\\beta}}.")]]

#text("If we then select ")#mi("{c_\\alpha}")#text(" so that")

#align(center)[#tao-fit-display[#mitex("c_\\alpha = b_\\alpha c_{-\\alpha}")]]

#text("for all roots ")#mi("{\\alpha}")#text(" (this is possible thanks to ")#link(<tao-1759f7a2eb8085ca9435>)[#text("(24)")]#text("), then the transformation ")#link(<tao-8f1f74adf65864c86d3d>)[#text("(23)")]#text(" eliminates ")#mi("{a_{\\alpha,\\beta}}")#text(" as desired. ")#mi("\\Box")

#text("From the above two lemmas, we see that we can select a special Cartan-Weyl basis, known as a ")#link("http://en.wikipedia.org/wiki/Chevalley_basis")[#text("Chevalley basis")]#text(", such that ")#metadata(none) <tao-0cf67fc72b3c86c7a454>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("[E_\\alpha, E_\\beta] = \\pm (r+1) E_{\\alpha+\\beta}")]]

#text(" whenever ")#mi("{\\alpha+\\beta}")#text(" is a root; in particular, the structure constants ")#mi("{N_{\\alpha,\\beta}}")#text(" are all integers, which is a crucial fact when one wishes to construct Lie algebras and ")#link("http://en.wikipedia.org/wiki/Chevalley_group#Chevalley_groups")[#text("Chevalley groups")]#text(" over fields of arbitrary characteristic. This comes very close to fully describing the Lie algebra structure associated to a given Dynkin diagram, except that one still has to select the signs ")#mi("{\\pm}")#text(" in ")#link(<tao-0cf67fc72b3c86c7a454>)[#text("(25)")]#text(" so that one actually gets a Lie algebra (i.e. that the Jacobi identity ")#link(<tao-9dcc6fbbb4f3d0969043>)[#text("(1)")]#text(" is obeyed). This turns out to be non-trivial; see ")#link("http://www.ams.org/mathscinet-getitem?mr=214638")[#text("this paper of Tits")]#text(" for details. (There are other approaches to demonstrate existence of a Lie algebra associated to a given root system; one popular one proceeds using the Chevalley-Serre relations, see e.g. this ")#link("http://www.ams.org/mathscinet-getitem?mr=215886")[#text("text of Serre")]#text(". There is still a certain amount of freedom to select the signs, but this ambiguity can be described precisely; see ")#link("http://www.ams.org/mathscinet-getitem?mr=1266626")[#text("the book of Carter")]#text(" for details.) Among other things, this construction shows that every root system actually creates a Lie algebra (thus far we have only established uniqueness, not existence), though once one has the classification one could also build a Lie algebra explicitly for each Dynkin diagram by hand (in particular, one can build the simply laced classical Lie algebras ")#mi("{A_n, D_n}")#text(" and the maximal simply laced exceptional algebra ")#mi("{E_8}")#text(", and construct the remaining Lie algebras by taking fixed points of suitable involutions; see e.g. ")#link("http://math.berkeley.edu/~theojf/LieQuantumGroups.pdf")[#text("these notes of Borcherds")]#text(" et al. for this approach).")

#heading(level: 1)[#strong[#text(" — 9. Appendix: Casimirs and complete reducibility — ")]]

#text("In this appendix we supply a proof of the following fact, used in the proof of Corollary ")#link(<tao-77cf6a9be9777b7893fe>)[#text("12")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 44 (Weyl’s complete reducibility theorem)")]#text(" ")#metadata(none) <tao-ac9027d6fceb8e369ce6>#text(" Let ")#mi("{{\\mathfrak g} \\subset {\\mathfrak{gl}}(V)}")#text(" be a simple Lie algebra, and let ")#mi("{W}")#text(" be a ")#mi("{{\\mathfrak g}}")#text("-invariant subspace of ")#mi("{V}")#text(". Then there exists a complementary ")#mi("{{\\mathfrak g}}")#text("-invariant subspace ")#mi("{W^{\\prime}}")#text(" such that ")#mi("{V = W \\oplus W^{\\prime}}")#text(".")
]

#text("Among other things, ")#link("http://en.wikipedia.org/wiki/Weyl's_theorem_on_complete_reducibility")[#text("Weyl’s complete reducibility theorem")]#text(" shows that every finite-dimensional linear representation of ")#mi("{{\\mathfrak g}}")#text(" splits into the direct sum of irreducible representations, which explains the terminology. The claim is also true for semisimple Lie algebras ")#mi("{{\\mathfrak g}}")#text(", but we will only need the simple case here, which allows for some minor simplifications to the argument.")

#text("The proof of this theorem requires a variant ")#mi("{B: {\\mathfrak g} \\times {\\mathfrak g} \\rightarrow {\\bf C}}")#text(" of the Killing form associated to ")#mi("{V}")#text(", defined by the formula ")#metadata(none) <tao-789f20284da6c6aed969>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("B(x,y) := \\text{tr}( xy ),")]]

#text(" and a certain element of ")#mi("{{\\mathfrak{gl}}(V)}")#text(" associated to this form known as the ")#link("http://en.wikipedia.org/wiki/Casimir_element")[#text("Casimir operator")]#text(". We first need to establish a variant of Theorem ")#link(<tao-7c21b8ee84cee675a9cc>)[#text("1")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 45")]#text(" With the hypotheses of Theorem ")#link(<tao-ac9027d6fceb8e369ce6>)[#text("44")]#text(", ")#mi("{B}")#text(" is non-degenerate.")
]

#emph[#text("Proof:")]#text(" This is a routine modification of Proposition ")#link(<tao-0510eddd781102030eb8>)[#text("6")]#text(" (one simply omits the use of the adjoint representation). ")#mi("\\Box")

#text("Once one establishes non-degeneracy, one can then define the ")#emph[#text("Casimir operator")]#text(" ")#mi("{C \\in {\\mathfrak{gl}}(V)}")#text(" by setting")

#align(center)[#tao-fit-display[#mitex("C:= \\sum_{i=1}^n e_i f_i")]]

#text("whenever ")#mi("{e_1,\\ldots,e_n}")#text(" is a basis of ")#mi("{{\\mathfrak g}}")#text(" and ")#mi("{f_1,\\ldots,f_n}")#text(" is its ")#link("http://en.wikipedia.org/wiki/Dual_basis")[#text("dual basis")]#text(", thus ")#mi("{B(e_i,f_j) = \\delta_{ij}}")#text(". It is easy to see that this definition does not depend on the choice of basis, which in turn (by infinitesimally conjugating both bases by an element ")#mi("{x}")#text(" of the algebra ")#mi("{{\\mathfrak g}}")#text(") implies that ")#mi("{C}")#text(" commutes with every element ")#mi("{x}")#text(" of ")#mi("{{\\mathfrak g}}")#text(".")

#text("On the other hand, ")#mi("{C}")#text(" does not vanish entirely. Indeed, taking traces and using ")#link(<tao-789f20284da6c6aed969>)[#text("(26)")]#text(" we see that ")#metadata(none) <tao-a8f91262ec932c68f35a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\text{tr}(C) = \\text{dim}({\\mathfrak g}).")]]



#text("This already gives an important special case of Theorem ")#link(<tao-ac9027d6fceb8e369ce6>)[#text("44")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 46")]#text(" Theorem ")#link(<tao-ac9027d6fceb8e369ce6>)[#text("44")]#text(" is true when ")#mi("{W}")#text(" has codimension one and is irreducible.")
]

#emph[#text("Proof:")]#text(" The Lie algebra ")#mi("{{\\mathfrak g}}")#text(" acts on the one-dimensional space ")#mi("{V/W}")#text("; since ")#mi("{{\\mathfrak g} = [{\\mathfrak g},{\\mathfrak g}]}")#text(" (from the simplicity hypothesis), we conclude that this action is trivial. In other words, each element of ")#mi("{{\\mathfrak g}}")#text(" maps ")#mi("{V}")#text(" to ")#mi("{W}")#text(", so the Casimir operator ")#mi("{C}")#text(" does as well. In particular, the trace of ")#mi("{C}")#text(" on ")#mi("{V}")#text(" is the same as the trace of ")#mi("{C}")#text(" on ")#mi("{W}")#text(". On the other hand, by Schur’s lemma, ")#mi("{C}")#text(" is a constant on ")#mi("{W}")#text("; applying ")#link(<tao-a8f91262ec932c68f35a>)[#text("(27)")]#text(", we conclude that this constant is non-zero. Thus ")#mi("{C}")#text(" is non-degenerate on ")#mi("{W}")#text(", but is not full rank on ")#mi("{V}")#text(" as it maps ")#mi("{V}")#text(" to ")#mi("{W}")#text(". Thus it must have a one-dimensional null-space ")#mi("{W^{\\prime}}")#text(" which is complementary to ")#mi("{W}")#text(". As ")#mi("{C}")#text(" commutes with ")#mi("{{\\mathfrak g}}")#text(", ")#mi("{W^{\\prime}}")#text(" is ")#mi("{{\\mathfrak g}}")#text("-invariant, and the claim follows. ")#mi("\\Box")

#text("We can then remove the irreducibility hypothesis:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 47")]#text(" ")#metadata(none) <tao-4ed60a56b931d74d389b>#text(" Theorem ")#link(<tao-ac9027d6fceb8e369ce6>)[#text("44")]#text(" is true when ")#mi("{W}")#text(" has codimension one.")
]

#text("We remark that this statement is essentially a reformulation of ")#link("http://en.wikipedia.org/wiki/Whitehead%27s_lemma_(Lie_algebras)")[#text("Whitehead’s lemma")]#text(".")

#emph[#text("Proof:")]#text(" We induct on the dimension of ")#mi("{W}")#text(" (or ")#mi("{V}")#text("). If ")#mi("{W}")#text(" is irreducible then we are already done, so suppose that ")#mi("{W}")#text(" has a proper invariant subspace ")#mi("{U}")#text(". Then ")#mi("{W/U}")#text(" has codimension one in ")#mi("{V/U}")#text(", so by the induction hypothesis ")#mi("{W/U}")#text(" is complemented by a one-dimensional invariant subspace ")#mi("{Y}")#text(" of ")#mi("{V/U}")#text(", which lifts to an invariant subspace ")#mi("{Z}")#text(" of ")#mi("{V}")#text(" in which ")#mi("{U}")#text(" has codimension one. By the induction hypothesis again, ")#mi("{U}")#text(" is complemented by a one-dimensional invariant subspace ")#mi("{W^{\\prime}}")#text(" in ")#mi("{Z}")#text(", and it is then easy to see that ")#mi("{W^{\\prime}}")#text(" also complements ")#mi("{W}")#text(" in ")#mi("{V}")#text(", and the claim follows. ")#mi("\\Box")

#text("Next, we remove the codimension one hypothesis instead:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 48")]#text(" Theorem ")#link(<tao-ac9027d6fceb8e369ce6>)[#text("44")]#text(" is true when ")#mi("{W}")#text(" is irreducible.")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{A}")#text(" be the space of linear maps ")#mi("{T: V \\rightarrow W}")#text(" whose restriction to ")#mi("{W}")#text(" is a constant multiple of the identity, and let ")#mi("{B}")#text(" be the subalgebra of ")#mi("{A}")#text(" whose restriction to ")#mi("{W}")#text(" vanishes. Then ")#mi("{A, B}")#text(" are ")#mi("{{\\mathfrak g}}")#text("-invariant (using the Lie bracket action), and ")#mi("{B}")#text(" has codimension one in ")#mi("{A}")#text(". Applying Proposition ")#link(<tao-4ed60a56b931d74d389b>)[#text("47")]#text(" (pushing ")#mi("{{\\mathfrak g}}")#text(" forward to ")#mi("{\\mathfrak{gl}(A)}")#text(", and treating the degenerate case when ")#mi("{\\mathfrak{gl}(A)}")#text(" vanishes separately) we see that ")#mi("{B}")#text(" is complemented by a one-dimensional invariant subspace ")#mi("{B^{\\prime}}")#text(" of ")#mi("{A}")#text(". Thus there exist ")#mi("{T \\in A}")#text(" that does not lie in ")#mi("{B}")#text(", and which commutes with every element of ")#mi("{{\\mathfrak g}}")#text(". The kernel ")#mi("{W^{\\prime}}")#text(" of ")#mi("{T}")#text(" is then an invariant complement of ")#mi("{W}")#text(" in ")#mi("{V}")#text(", and the claim follows. ")#mi("\\Box")

#text("Applying the induction argument used to prove Proposition ")#link(<tao-4ed60a56b931d74d389b>)[#text("47")]#text(", we now obtain Theorem ")#link(<tao-ac9027d6fceb8e369ce6>)[#text("44")]#text(" in full generality.")

#heading(level: 1)[#text("Comments (35)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-226595")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2013")])]

#text("“The significance of this transformation lies in the observation that the product ")#mi("{\\overline{x_{ss}} x}")#text(" has trace ")#tao-math("{\\left|\\lambda\\right|^2 \\text{dim} V_\\lambda^x}", block: false)#text(" on each generalised eigenspace (since nilpotent operators have zero trace), and in particular we see that")

#mi("\\displaystyle \\text{tr}(\\overline{x_{ss}} x) = 0 \\ \\ \\ \\ \\ (7)")

#text("if and only if the spectrum consists only of zero, or equivalently that ")#mi("x")#text(" is nilpotent.”")

#text("This is a really nice idea. Thanks for sharing.")

#text("Does this trick of defining a semisimple conjugate and using it to count the magnitude of the eigenvalues come from any particular source or subject? I don’t seem to remember it being mentioned in any of the standard texts on Lie algebras (although I think they all use some form of (less elegant) nilpotency criteria when establishing Cartan’s criterion)")

#text("Also, it seems that if we move from the complex numbers to a different field of characteristic zero, then we need to rely on the presence of some kind of positivity in order to ensure that ")#tao-math("{\\left|\\lambda\\right|^2 \\text{dim} V_\\lambda^x} \\neq 0", block: false)#text(" when the ")#mi("\\lambda")#text(" are nonzero. What precisely is the additional structure that we are using (if any) to ensure that this nilpotency criteria works?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-226698")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2013")])]

#text("I think this is more or less the standard trick to get nondegeneracy of the Killing form in semisimple Lie algebras of characteristic zero; I don’t know who first used it, though. Sometimes one works in arbitrary characteristic zero fields instead of the complex numbers, in which case the conjugation map ")#mi("z \\mapsto \\overline{z}")#text(" has to be replaced with an element of a suitable Galois group (or else one plays with various homomorphisms to the rationals) before one can use the above argument (alternatlvely, one can try to use some version of the Lefschetz principle to transfer the complex results to other fields of characteristic zero (or sufficiently large characteristic)). My personal preference leans towards complex methods rather than general algebraic methods, but this choice ls largely a matter of personal taste.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-226635")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2013")])]

#text("Prof. Tao – I believe you mean the image of H is the kernel of L in your definition if short exact sequence. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/135675b97fe69927e91cb748f831870f446e71fa8a739aaa849d5b42124f522b-faba070bded647fdb7b69b0b854f013008755e8866cfcdf59dd568d10fcd5222.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian Agol")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-226682")[#strong[#text("Ian Agol")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2013")])]

#text("The signs you discuss for the Chevalley basis are a bit tricky, since there’s no Weyl group invariant way of assigning them. Borcherds has an elegant method to do the construction for E8 given in Chapters 26-27 of these notes: ")#link("http://math.berkeley.edu/~anton/written/LieGroups/LieGroups.pdf")[#text("http://math.berkeley.edu/~anton/written/LieGroups/LieGroups.pdf")]#linebreak()#text(" or section 7.5 of these notes: ")#link("http://math.berkeley.edu/~theojf/LieQuantumGroups.pdf")[#text("http://math.berkeley.edu/~theojf/LieQuantumGroups.pdf")]

#text("Once you have the E8 Lie algebra, the other exceptional algebras may be shown to exist as subalgebras.")

#emph[#text("[Reference added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-226715")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2013")])]

#text(">One is to locate a Lie algebra ideal (or ideal for short)…")

#text("shouldn’t the ideal condition be [g,h] \\subset h?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-226717")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2013")])]

#text("Also,")

#text(">then the derived **group** has strictly smaller dimension")

#text("should be “algebra”.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6795de0f1bb61e22f59883f5257e16351b2500fac9769c4181fc7f2c14239eea-750b01c12157b7bd1a0511c1c7748fbc3f0be1776e5d2f1d8f7fab973891f090.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dick Gross")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-227177")[#strong[#text("Dick Gross")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2013")])]

#text("My favorite treatment of the “choice of signs” is in Jacob Lurie’s senior thesis:")

#link("http://www.math.harvard.edu/~lurie/papers/thesis.pdf")[#text("Click to access thesis.pdf")]

#text("By passing to a double cover of the root lattice, Lurie essentially removes all of the choices. Not only does this give an elegant construction of the adjoint representation, but the method can be extended to construct all the minuscule representations over the integers, and to determine their")#linebreak()#text(" tensor invariants.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6294c896e943bfb2c7201b24288124f68ad8f75ef29fe5b64a1165255135b2c5-d93b247a2dc99e501556f105c024a332ab8eb133fa48ae4fc636d6b8d504035b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-230872")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2013")])]

#text("Maybe it’s a stupid question: is the ")#mi("\\sigma(x)")#text(" in last but one equation in section 1 (")#mi("V = \\bigoplus_{\\lambda \\in \\sigma(x)} V_\\lambda^{\\mathfrak h}")#text(") suppose to be ")#mi("\\sigma(\\rho)")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-233692")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Regarding the Levi decomposition: I don’t think you chose your terminology well. Call ")#mi("\\mathfrak{g} / \\mathrm{rad}")#text(" the ")#emph[#text("Levi quotient")]#text(". As you say, it is a Theorem of Levi that this has a section, so the extension splits. Because of that, the notation ")#mi("\\mathfrak{g} = \\mathrm{rad}\\mathfrak{g}.(\\mathfrak{g} / \\mathrm{rad}\\mathfrak{g})")#text(" without Levi’s Theorem doesn’t make sense to me. What kind of product are you using?")

#text("Regarding the Jordan Decomposition: the uniqueness statement is very powerful. Here one example: the properties of an element being semisimple or nilpotent and two elements commuting are invariant under the automorphism group of ")#mi("\\mathbb{C}")#text(". It follows that if the entries of a matrix ")#mi("x")#text(" lie in some subfield of ")#mi("\\mathbb{C}")#text(", then ")#mi("x_\\textrm{ss}, x_\\textrm{n}")#text(" have their entries in that same subfield (for example, the semisimple and nilpotent parts of a real matrix are real, even if the eigenvalues are complex).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-233704")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("I’m using an ATLAS type notation in which ")#mi("{\\mathfrak g} . {\\mathfrak h}")#text(" denotes a (possibly non-split) extension of ")#mi("{\\mathfrak h}")#text(" by ")#mi("{\\mathfrak g}")#text("; it’s a product twisted by a cocycle rather than by an action.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-233780")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("Thanks — I haven’t seen this notation before.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on simple groups of Lie type | What's new")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-243956")[#strong[#text("Notes on simple groups of Lie type | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("[…] this previous post I recorded some (very standard) material on the structural theory of finite-dimensional complex Lie […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4db7f931b7831845d5ad9a27b1a6319cf65192de9454a28bb64b50d9e9f9875b-09b27acb458a076240e9968737c42ca77e5653b215ae746d53770326465c5608.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-245153")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2013")])]

#text("In the proof of Corollary 9, haven’t we just proved that $\\latex x_{ss} – a$ is nilpotent? Am I overlooking something?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-245184")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2013")])]

#text("Gah, you’re right. The argument does show that ")#mi("x_{ss}-a")#text(" vanishes when restricted to each irreducible module of ")#mi("V")#text(", which if combined with the fact that modules of semisimple Lie algebras are completely reducible, gives the claim… but I really wanted to avoid invoking complete reducibility of modules in my exposition (it’s not so hard to prove if one uses Casimir elements, but this clutters things up pedagogically). I have to think a bit to see how to get around this issue. (I can reduce to the case when ")#mi("{\\mathfrak g}")#text(" is simple without too much difficulty, but this doesn’t seem to be enough.)")

#emph[#text("[UPDATE: It doesn’t look like there is an easy fix here, so I have now added the standard Casimir-based proof of complete reducibility to the notes. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-245376")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2013")])]

#text("Sorry to have been such a bother! Thanks for clearing this up.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90aa6386641bc9897c01d26e95c2d39f4b5fc3c4aefdf913beb0adc36ae6c66b-57f60c4d70ae636346f3500edb78c8f57812b386a0cab14c0ceb24809d82333c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-272430")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("Dear Professor Tao,")

#text("This might be a stupid question, but what does characteristic subalgebra mean in the proof of (i) imply (iv) in Theorem 1?")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-272431")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("“Characteristic” means “invariant with respect to all automorphisms of the ambient space”. (This terminology is most commonly used in the ")#link("http://en.wikipedia.org/wiki/Characteristic_subgroup")[#text("context of groups")]#text(", but can also be defined for algebras, and in particular for Lie algebras, without difficulty.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90aa6386641bc9897c01d26e95c2d39f4b5fc3c4aefdf913beb0adc36ae6c66b-57f60c4d70ae636346f3500edb78c8f57812b386a0cab14c0ceb24809d82333c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-272446")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("Is it possible to just argue that by Prop 7 ")#mi("g = h\\oplus t")#text(", so that any ideal of ")#mi("h")#text(" is also an ideal of ")#mi("g")#text("? Where is characteristic property of solvable ideal being used? Am I overlooking something?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-272449")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("Corollary 7 is only available when ")#mi("{\\frak h}")#text(" is simple. The characteristic property of the radical is used by observing that the adjoint operation of any element of ")#mi("{\\frak g}")#text(" is an automorphism of ")#mi("{\\frak h}")#text(", and thus preserves the radical of ")#mi("{\\frak h}")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90aa6386641bc9897c01d26e95c2d39f4b5fc3c4aefdf913beb0adc36ae6c66b-57f60c4d70ae636346f3500edb78c8f57812b386a0cab14c0ceb24809d82333c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-272452")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("I am still not able to figure out why ")#mi("\\text{ad}(x): \\mathfrak{h} \\rightarrow \\mathfrak{h}")#text(" is an automorphism of ")#mi("\\mathfrak{h}")#text(" for any ")#mi("x \\in \\mathfrak{g}")#text(". It seems it is obviously false when ")#mi("x = 0")#text(", and is not clear why it should be true for ")#mi("x \\neq 0")#text(". Am I overlooking something?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-272492")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Sorry, I meant to say “derivation” rather than “automorphism” in my previous comments. (A derivation of Lie algebras is an infinitesimal version of an automorphism on Lie groups, in exactly the same way that a Lie bracket is an infinitesimal version of conjugation on a Lie group.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90aa6386641bc9897c01d26e95c2d39f4b5fc3c4aefdf913beb0adc36ae6c66b-57f60c4d70ae636346f3500edb78c8f57812b386a0cab14c0ceb24809d82333c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-272517")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Thanks for clearing this up! That is really helpful and have a nice weekend :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cd16bde09d8834ec27d528d9d74c8c1789c69786cfe28a19c37ae77d7399c2a-3f03289850e5fe86fbc86e24ed6820f8d46ae898c2af8c39165567af2ab49ab4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of E8: An Exceptionally Beautiful Piece of Mathematics | Tamás F. Görbe")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-455970")[#strong[#text("E8: An Exceptionally Beautiful Piece of Mathematics | Tamás F. Görbe")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2015")])]

#text("[…] T. Tao, Notes on the classification of complex Lie algebras, blogpost, April 27, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/584cd02f839ef6f42551e80d351f9a4a15cb388eea2c96194a9925dcd6248b8b-d4a31d6f5ab8c8b59637f67c32594b522a6199cfd232e67ffe727dace4462076.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-459661")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2015")])]

#text("The end of the proof of Corollary 9 is confusing (or it can be simplified): as ")#mi("\\lambda=0")#text(", we have that ")#mi("x_{ss}=a")#text(" lies in ")#mi("\\mathfrak{g}")#text(", hence also ")#mi("x_n=x-x_{ss}")#text(" and ")#mi("\\overline{x}_{ss}")#text(" lie in ")#mi("\\mathfrak{g}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/584cd02f839ef6f42551e80d351f9a4a15cb388eea2c96194a9925dcd6248b8b-d4a31d6f5ab8c8b59637f67c32594b522a6199cfd232e67ffe727dace4462076.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-459770")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2015")])]

#text("At the end of the proof of Proposition 14, “")#mi("[\\mathfrak{h},\\mathfrak{h}]")#text(" to be abelian” should be")#linebreak()#text(" “")#mi("[\\mathfrak{h},\\mathfrak{h}]")#text(" to be trivial” or “")#mi("\\mathfrak{h}")#text(" to be abelian”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/584cd02f839ef6f42551e80d351f9a4a15cb388eea2c96194a9925dcd6248b8b-d4a31d6f5ab8c8b59637f67c32594b522a6199cfd232e67ffe727dace4462076.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-459777")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2015")])]

#text("Another typo: At the end of the proof of Lemma 23, ")#mi("-\\frac{m_i}{4}")#text(" should be ")#mi("\\frac{m_i}{4}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-473716")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2016")])]

#text("Regarding corollary 20, aren’t there root systems (such as G2) with roots that subtend an acute angle whose sum is in the root lattice?")

#emph[#text("[Oops, you’re right, this conclusion of the corollary should be deleted (fortunately it isn’t the part of the corollary that is used elsewhere). -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc98d6e7463cd9b0c34d6f41e9b38d2bf428020e2da9025b7273024d5adfa88a-1bdca7fcc9780d99a50558b912efd49fc69893b670f2edbe0efd8141d7c788b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Meinolf Geck")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-478949")[#strong[#text("Meinolf Geck")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2017")])]

#text("Dear Prof. Tao,")#linebreak()#text(" as for the signs in a Chevalley basis, I would like to mention that one can make a definite choice based on an idea of Lusztig, see my paper")

#link("http://www.ams.org/journals/proc/0000-000-00/S0002-9939-2017-13600-4/S0002-9939-2017-13600-4.pdf")[#text("Click to access S0002-9939-2017-13600-4.pdf")]

#text("Sincerely, Meinolf Geck")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b3a15036f737b41dda57fdef964a646b829e7c0e93b16439c306072800c155d-83ef5729526ba29527d0e44725f75f73f839f4978aaac3a11e90ac9f88073bae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jean-Philippe Burelle")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-517308")[#strong[#text("Jean-Philippe Burelle")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2019")])]

#text("Dear Professor Tao,")#linebreak()#text(" In Lemma 25, it seems that you are missing one forbidden subdiagram in order to be able to deduce Corollary 26 :")#linebreak()#text(" Three chains of simple edges of length {1, 3, 3} respectively, emenating from a common vertex.")#linebreak()#text(" It can also be checked by computing the determinant of the Gram matrix.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-635595")[#strong[#text("Algebre Lie | Noncommutative Algebra")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2021")]

#text("[…] Tao: ")#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras")[#text("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/562f778a672442c36297f0c0c5e35b7944dd7437388dfb60710ae12dee5e6add-263540662e9778abf68885a1f03e6dfebbe13cf20c048d7e863f8113eb90a95f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammed Mannan")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-675622")[#strong[#text("Mohammed Mannan")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2023")])]

#text("After “From the above discussion we see that a Lie algebra is solvable if and only if it can be represented by a tower of abelian extensions, thus” should it not be")

#text("g = (… (a_k . a_k-1) … a_2) . a_1")

#text("rather than")

#text("g = a_1 . ( a_2 … (a_k-1 . a_k) …)")

#text("since we start with g = [g,g] . g/[g,g] and expand [g,g] (and in each following step the left term is expanded and the right term is abelian)?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-675903")[#strong[#text("Complexification – eryanghsu")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2023")]

#text("[…] ")#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-Lie-algebras")[#text("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-Lie-algebras")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-693963")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2026")])]

#text("I have a question that might be rather basic, but it has puzzled me for a long time: in the definition of abstract Lie algebra, why do we need to specifically require [, ] to satisfy the Jacobi identity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-693967")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2026")])]

#text("Why is the Jacobi identity so important that it has to be part of the definition of abstract Lie algebra?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/#comment-693970")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2026")])]

#text("I am ")#link("https://claude.ai/share/93c7d6ce-b071-4fc5-8191-6a8d714800e7")[#text("outsourcing this question to an AI")]#text(", which interprets the Jacobi identity as a “fossil” of the associative law for algebras (or for groups).")

#text("Another analogy is with closed or exact 2-forms. Much as a Lie bracket ")#mi("[X,Y]")#text(" is supposed to be abstraction of the notion of a commutator ")#mi("\\nabla_X Y - \\nabla_Y X")#text(" of vector fields, the notion of a closed 2-form ")#mi("\\omega")#text(" can be thought of as the abstraction of the notion of an exact 2-form, i.e., a differential ")#mi("\\omega = d\\theta")#text(" of a ")#mi("1")#text("-form. Compare for instance the Jacobi identity ")#mi("[X,[Y,Z]] + [Y,[Z,X]] + [Z,[X,Y]] = 0")#text(" with the closure property ")#mi("d\\omega=0")#text(" (or in coordinates, ")#mi("\\nabla_\\alpha \\omega_{\\beta \\gamma} + \\nabla_\\beta \\omega_{\\gamma \\alpha} + \\nabla_\\gamma \\omega_{\\alpha \\beta} = 0")#text("), and the commutator property ")#mi("[X,Y] = \\nabla_X Y - \\nabla_Y X")#text(" (or in coordinates, ")#mi("[X,Y]^\\beta = X^\\alpha \\nabla_\\alpha Y^\\beta - Y^\\alpha \\nabla_\\alpha X^\\beta")#text(") with the exact propety ")#mi("\\omega = d\\theta")#text(" (or in coordinates, ")#mi("\\omega_{\\alpha \\beta} = \\partial_\\alpha \\theta_\\beta - \\partial_\\beta \\theta_\\alpha")#text(").")

#text("For what it is worth, ")#link("https://claude.ai/share/93c7d6ce-b071-4fc5-8191-6a8d714800e7")[#text("here is an AI comment")]#text(" on the above relation.")
]
]
