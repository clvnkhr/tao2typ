// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/02/247a-notes-2-the-hardy-littlewood-maximal-function-and-applications/
// Converted to Typst by tao2typ: "2026-10-25T11:51:29.915984+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "247A, Notes 2: The Hardy–Littlewood maximal function and applications", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("247A, Notes 2: The Hardy–Littlewood maximal function and applications")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/02/247a-notes-2-the-hardy-littlewood-maximal-function-and-applications/")[#text("https://terrytao.wordpress.com/2026/10/02/247a-notes-2-the-hardy-littlewood-maximal-function-and-applications/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-25 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#heading(level: 1)[#strong[#text(" — 1. The Hardy-Littlewood maximal inequality — ")]]

#text("We work in Euclidean space ")#mi("{{\\bf R}^d}")#text(" with Lebesgue measure; we write ")#tao-math("{\\left|E\\right|}", block: false)#text(" instead of ")#mi("{\\mu(E)}")#text(" for the Lebesgue measure of a set ")#mi("{E}")#text(". For any ")#mi("{x \\in {\\bf R}^d}")#text(" and ")#mi("{r > 0}")#text(" let ")#tao-math("{B(x,r) := \\{ y \\in {\\bf R}^d: \\left|x-y\\right| < r \\}}", block: false)#text(" denote the open ball of radius ")#mi("{r}")#text(" centred at ")#mi("{x}")#text(". Thus for instance ")#tao-math("{\\left|B(x,r)\\right| \\sim_d r^d}", block: false)#text(". For any ")#mi("{c > 0}")#text(", we use ")#mi("{cB(x,r) = B(x,cr)}")#text(" to denote the dilate of ")#mi("{B(x,r)}")#text(" around its centre by ")#mi("{c}")#text(".")

#text("For any ")#mi("{r > 0}")#text(", we define the averaging operators ")#mi("{A_r}")#text(" on ")#mi("{{\\bf R}^d}")#text(" for any locally integrable ")#mi("{f}")#text(" by")

#align(center)[#tao-fit-display[#tao-math("A_r f(x) := \\frac{1}{\\left|B(x,r)\\right|} \\int_{B(x,r)} f(y)\\ dy.", block: true)]]

#text("It is not hard to see that these averages ")#mi("{A_r}")#text(" are well-defined, and are even continuous functions, for locally integrable ")#mi("{f}")#text(".")

#text("One can view ")#mi("{A_r}")#text(" as an averaging operator")

#align(center)[#tao-fit-display[#tao-math("A_r f = f * \\frac{1}{\\left|B(0,r)\\right|} 1_{B(0,r)}.", block: true)]]

#text("From ")#link("https://en.wikipedia.org/wiki/Schur_test")[#text("Schur’s test")]#text(" or ")#link("https://en.wikipedia.org/wiki/Young%27s_convolution_inequality")[#text("Young’s inequality")]#text(" (or ")#link("https://en.wikipedia.org/wiki/Minkowski_inequality")[#text("Minkowski’s inequality")]#text(") we know that these ")#mi("{A_r}")#text(" are contractions on every ")#mi("{L^p({\\bf R}^d)}")#text(", ")#mi("{1 \\leq p \\leq \\infty}")#text(":")

#align(center)[#tao-fit-display[#tao-math("\\left\\| A_r f \\right\\|_{L^p({\\bf R}^d)} \\leq \\left\\|f\\right\\|_{L^p({\\bf R}^d)}.", block: true)]]

#text("Thus the averages ")#mi("{A_r f}")#text(" are uniformly bounded in ")#emph[#text("size")]#text(" as ")#mi("{r}")#text(" varies. The fundamental ")#link("https://en.wikipedia.org/wiki/Hardy%E2%80%93Littlewood_inequality")[#text("Hardy-Littlewood maximal inequality")]#text(" asserts, roughly speaking, that they are also uniformly bounded in ")#emph[#text("shape")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Hardy-Littlewood maximal inequality)")]#text(" We have the strong-type ")#mi("{(p,p)}")#text(" inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{r > 0} A_r \\left|f\\right| \\right\\|_{L^p({\\bf R}^d)} \\lesssim_{p,d} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("for all ")#mi("{1 < p \\leq \\infty}")#text(" and any ")#mi("{f \\in L^p({\\bf R}^d)}")#text(", and also the weak-type ")#mi("{(1,1)}")#text(" inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{r > 0} A_r \\left|f\\right| \\right\\|_{L^{1,\\infty}({\\bf R}^d)} \\lesssim_{d} \\left\\|f\\right\\|_{L^1({\\bf R}^d)}", block: true)]]

#text("for any ")#mi("{f \\in L^1({\\bf R}^d)}")#text(".")
]

#text("The sublinear operator")

#align(center)[#tao-fit-display[#tao-math("Mf := \\sup_{r > 0} A_r \\left|f\\right|", block: true)]]

#text("is known as the ")#emph[#text("Hardy-Littlewood maximal operator")]#text(". It is easy to see that the above proposition is equivalent to the assertion that the Hardy-Littlewood maximal operator is weak-type ")#mi("{(1,1)}")#text(" and strong-type ")#mi("{(p,p)}")#text(" for all ")#mi("{1 < p \\leq \\infty}")#text(". Note that it is not strong-type ")#mi("{(1,1)}")#text("; indeed, if ")#mi("{f}")#text(" is any non-trivial function, then we easily verify the pointwise bound ")#mi("{Mf(x) \\gtrsim_f \\langle x \\rangle^{-d}}")#text(", which ensures that ")#mi("{Mf}")#text(" is not in ")#mi("{L^1_x({\\bf R}^d)}")#text(". (Here we use the “Japanese bracket” notation ")#tao-math("{\\langle x \\rangle := (1 + \\left|x\\right|^2)^{1/2}}", block: false)#text(", as a smoothed out version of the absolute value function ")#tao-math("{\\left|x\\right|}", block: false)#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Explain why ")#mi("{M}")#text(" is not of strong or weak type ")#mi("{(p,q)}")#text(" for any ")#mi("{p \\neq q}")#text(".")
]

#text("As this proposition is so fundamental we shall give several proofs of it.")

#heading(level: 1)[#strong[#text(" — 2. First proof — ")]]

#text("We begin with the classical proof, starting with some standard qualitative reductions. Firstly we may easily reduce to ")#mi("{f}")#text(" being non-negative. A monotone convergence argument also lets us restrict to functions ")#mi("{f}")#text(" which are bounded and have compact support. (At this point one may object that ")#mi("{Mf}")#text(" might not be measurable, but one can use dominated convergence to restrict ")#mi("{r}")#text(" to be (say) rational, at which point measurability is clear.) Also, ")#mi("{A_r f}")#text(" is continuous in ")#mi("{r}")#text(", so we may restrict ")#mi("{r}")#text(" to a countable dense set (such as the positive rationals); another monotone convergence argument then lets us restrict ")#mi("{r}")#text(" to a finite set. Of course, our bounds need to be uniform in this set, as well as being uniform in the boundedness and support of ")#mi("{f}")#text(".")

#text("It is obvious that ")#mi("{M}")#text(" is bounded on ")#mi("{L^\\infty({\\bf R}^d)}")#text(" (indeed, it is a contraction on this space). So it suffices by Marcinkiewicz interpolation to prove the weak-type ")#mi("{(1,1)}")#text(" inequality; by homogeneity (and the preceding reductions) it thus suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ \\sup_{r > 0} A_r f \\geq 1 \\}\\right| \\lesssim_d \\left\\| f \\right\\|_{L^1({\\bf R}^d)}", block: true)]]

#text("for any non-negative bounded compactly supported ")#mi("{f}")#text(", where we are implicitly restricting ")#mi("{r}")#text(" to a finite set.")

#text("Let us denote the set on the left-hand side by ")#mi("{E}")#text("; our hypotheses on ")#mi("{f}")#text(" and ")#mi("{r}")#text(" easily ensure that ")#mi("{E}")#text(" is a compact set (alternatively, one can work with the uncountable sup ")#mi("{\\sup_{r>0}}")#text(", but instead replace ")#mi("{E}")#text(" by an arbitrary compact subset ")#mi("{K}")#text(" of itself, and then take suprema in ")#mi("{K}")#text(" at the end, noting that Lebesgue measure is a ")#mi("{\\sigma}")#text("-finite Radon measure). By construction, we thus see that for any ")#mi("{x \\in E}")#text(" there exists a radius ")#mi("{r(x) > 0}")#text(" such that ")#mi("{f}")#text(" is locally large compared to the ball ")#mi("{B(x,r(x))}")#text(": ")#metadata(none) <tao-b7d00c87307b04ab71c4>#tao-math("\\displaystyle  \\left|B(x,r(x))\\right| < \\int_{B(x,r(x))} f(y)\\ dy. \\ \\ \\ \\ \\ (1)", block: false)#text(" ")#text(" On the other hand, what we want to show is that ")#mi("{f}")#text(" is globally large compared to ")#mi("{E}")#text(": ")#metadata(none) <tao-88246f42e618bc950f5a>#tao-math("\\displaystyle  \\left|E\\right| \\lesssim_d \\int_{{\\bf R}^d} f(y)\\ dy. \\ \\ \\ \\ \\ (2)", block: false)#text(" ")#text(" Since the compact set ")#mi("{E}")#text(" is covered by the balls ")#mi("{B(x,r(x))}")#text(", and hence by finitely many of these balls, things look quite promising. However, there is one remaining issue, which is that these balls could overlap quite heavily, preventing us from summing ")#link(<tao-b7d00c87307b04ab71c4>)[#text("(1)")]#text(" to get ")#link(<tao-88246f42e618bc950f5a>)[#text("(2)")]#text(". Fortunately there is a very simple algorithm which extracts out from any collection of overlapping balls, a collection of non-overlapping balls which manages to capture a significant fraction of the original collection in measure:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Wiener’s Vitali-type covering lemma)")]#text(" Let ")#mi("{B_1,\\ldots,B_N}")#text(" be a finite collection of balls. Then there is a subcollection ")#mi("{B_{n_1},\\ldots,B_{n_k}}")#text(" of ")#emph[#text("disjoint")]#text(" balls such that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i=1}^k \\left|B_{n_i}\\right| = \\left|B_{n_1} \\cup \\ldots \\cup B_{n_k}\\right| \\geq 3^{-d} |B_1 \\cup \\ldots \\cup B_N|.", block: true)]]
]

#emph[#text("Proof:")]#text(" We can order ")#mi("{B_1,\\ldots,B_N}")#text(" in decreasing order of size. Now we select the disjoint balls ")#mi("{B^{\\prime}_1,\\ldots,B^{\\prime}_N}")#text(" by the greedy algorithm, picking the largest balls we can at each stage. Namely, for ")#mi("{i=1,2,\\ldots}")#text(" we choose ")#mi("{B_{n_i}}")#text(" to be the first ball which is disjoint from all previously selected balls ")#mi("{B_{n_1},\\ldots,B_{n_{i-1}}}")#text(" (thus for instance ")#mi("{n_1}")#text(" must equal ")#mi("{1}")#text("), until we run out of balls. Clearly this gives us a family of disjoint balls. Now observe from construction that each ball ")#mi("{B_m}")#text(" in the original collection is either a ball ")#mi("{B_{n_i}}")#text(" in the subcollection, or else intersects a ball ")#mi("{B_{n_i}}")#text(" in the subcollection of equal or larger radius. In either case we see from the triangle inequality that ")#mi("{B_m}")#text(" is contained in ")#mi("{3B_{n_i}}")#text(". In other words,")

#align(center)[#tao-fit-display[#mitex("B_1 \\cup \\ldots \\cup B_N \\subseteq 3B_{n_1} \\cup \\ldots \\cup 3 B_{n_k}")]]

#text("and so")

#align(center)[#tao-fit-display[#tao-math("\\left|B_1 \\cup \\ldots \\cup B_N\\right| \\leq 3^d \\sum_{i=1}^k \\left|B_{n_i}\\right| = 3^d \\left|B_{n_1} \\cup \\ldots \\cup B_{n_k}\\right|", block: true)]]

#text("and the claim follows. ")#mi("\\Box")

#text("From the covering lemma it is easy to conclude ")#link(<tao-88246f42e618bc950f5a>)[#text("(2)")]#text(". Indeed, since ")#mi("{E}")#text(" is covered by finitely many of the balls ")#mi("{B(x,r(x))}")#text(", the covering lemma gives us finitely many ")#emph[#text("disjoint")]#text(" balls ")#mi("{B(x_i,r(x_i))}")#text(", ")#mi("{i=1,\\ldots,k}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{i=1}^k B(x_i,r(x_i))\\right| \\geq 3^{-d} \\left|E\\right|", block: true)]]

#text("and then on summing ")#link(<tao-b7d00c87307b04ab71c4>)[#text("(1)")]#text(" we get ")#link(<tao-88246f42e618bc950f5a>)[#text("(2)")]#text(" (with an explicit constant of ")#mi("{3^d}")#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" Under mild assumptions one can generalise the covering lemma to infinite families of balls without difficulty. One can also replace balls by similar objects, such as cubes; the main property that one needs is that if two such objects overlap, then the smaller one is contained in some dilate of the larger. This is a fairly general property, and for instance holds for metric balls on a measure space with some doubling property ")#mi("{\\mu( B(x,2r) ) = O( \\mu( B(x,r) ) )}")#text(", but it fails for very thin or eccentric sets such as long tubes, rectangles, annuli, etc. Indeed, understanding the maximal operator for these more geometrically complicated objects is still a major challenge in harmonic analysis, leading to important conjectures such as the Kakeya conjecture, which remains open in higher dimensions despite recent progress.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5 (Baby Besicovitch covering lemma)")]#text(" Let ")#mi("{I_1,\\ldots,I_N}")#text(" be a collection of intervals on the real line. Show that there exist a subcollection ")#mi("{I_{n_1}, \\ldots, I_{n_k}}")#text(" such that ")#mi("{I_{n_1} \\cup \\ldots \\cup I_{n_k} = I_1 \\cup \\ldots \\cup I_N}")#text(", and such that every point ")#mi("{x \\in {\\bf R}}")#text(" belongs to at most ")#mi("{O(1)}")#text(" of the intervals ")#mi("{I_{n_1},\\ldots,I_{n_k}}")#text(". What is the best explicit bound for ")#mi("{O(1)}")#text(" you can get?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Show that if ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" is supported on ")#mi("{[0,1]}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Mf \\right\\|_{L^1([0,1])} \\lesssim \\left\\|f\\right\\|_{L \\log L([0,1])}.", block: true)]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" For any locally integrable ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(", let ")#mi("{M_\\Box f}")#text(" denote the rectangular maximal function")

#align(center)[#tao-fit-display[#tao-math("M_\\Box f(x) := \\sup_{R\\ni x} \\frac{1}{\\left|R\\right|} \\int_R |f(y)|\\ dy", block: true)]]

#text("where ")#mi("{R}")#text(" ranges over all rectangles with sides parallel to the coordinate axes which contain ")#mi("{x}")#text(". Show that ")#mi("{M_\\Box}")#text(" is bounded on ")#mi("{L^p}")#text(" for all ")#mi("{1 < p \\leq \\infty}")#text(". (Hint: prove by induction, controlling the ")#mi("{d}")#text("-dimensional rectangular maximal function by the ")#mi("{d-1}")#text("-dimensional “horizontal” rectangular maximal function, applied to a one-dimensional “vertical” maximal function. A certain amount of application of the Fubini-Tonelli theorem may be needed.) Show by example that ")#mi("{M_\\Box}")#text(" is ")#emph[#text("not")]#text(" of weak-type ")#mi("{(1,1)}")#text(" in dimensions ")#mi("{d \\geq 2}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Let ")#mi("{1 \\leq p < \\infty}")#text(", ")#mi("{0 < \\alpha < d/p}")#text(", and let ")#mi("{f}")#text(" be locally integrable on ")#mi("{{\\bf R}^d}")#text(".")

#list(
[#text("(i) Establish ")#emph[#text("Hedberg’s inequality")]

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^d} \\frac{\\left|f(y)\\right|}{\\left|x-y\\right|^{d-\\alpha}}\\ dy \\lesssim_{d,\\alpha,p} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}^{\\frac{\\alpha p}{d}} (Mf(x))^{1-\\frac{\\alpha p}{d}}", block: true)]]

#text("for all ")#mi("{y \\in {\\bf R}^d}")#text(". (Hint: use symmetries to normalise as many quantities as you can, and then divide the integral either dyadically, or into a region near ")#mi("{x}")#text(" and a region away from ")#mi("{x}")#text(", estimating the two regions differently.)")],
[#text("(ii) Use Hedberg’s inequality to establish the ")#link("https://en.wikipedia.org/wiki/Sobolev_inequality")[#text("Hardy-Littlewood-Sobolev inequality")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| I_\\alpha f\\right\\|_{L^q({\\bf R}^d)} \\lesssim_{d,\\alpha,p} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("where the ")#emph[#text("fractional integral operator")]#text(" ")#mi("{I_\\alpha}")#text(" is defined by")

#align(center)[#tao-fit-display[#tao-math("I_\\alpha f(x) := \\int_{{\\bf R}^d} \\frac{\\left|f(y)\\right|}{\\left|x-y\\right|^{d-\\alpha}}\\ dy", block: true)]]

#text("and ")#mi("{q}")#text(" is the exponent for which ")#mi("{\\alpha = d/p - d/q}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Let ")#mi("{f \\in L^1({\\bf R}^d)}")#text(", and let ")#mi("{B}")#text(" be a ball such that ")#mi("{M f \\geq \\lambda}")#text(" at every point of ")#mi("{B}")#text(". Show that ")#mi("{Mf \\gtrsim_d \\lambda}")#text(" at every point of ")#mi("{2B}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 3. Second proof — ")]]

#text("Let us now give a slightly different proof of the above inequality, replacing balls by the slightly simpler structure of ")#link("https://en.wikipedia.org/wiki/Dyadic_cubes")[#text("dyadic cubes")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 10 (Dyadic cube)")]#text(" A ")#emph[#text("dyadic cube")]#text(" in ")#mi("{{\\bf R}^d}")#text(" of ")#emph[#text("generation")]#text(" ")#mi("{n}")#text(" is a set of the form")

#align(center)[#tao-fit-display[#mitex("Q = Q_{n,k} = 2^n (k + [0,1)^d) = \\{ 2^n (k+x): x \\in [0,1)^d \\}")]]

#text("where ")#mi("{n}")#text(" is an integer and ")#mi("{k \\in {\\bf Z}^d}")#text(".")
]

#text("The crucial property of dyadic cubes is the ")#emph[#text("nesting property")]#text(": if two dyadic cubes overlap, then one must contain the other. This leads to")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11 (Dyadic Vitali-type covering lemma)")]#text(" Let ")#mi("{Q_1,\\ldots,Q_N}")#text(" be a finite collection of dyadic cubes. Then there is a subcollection ")#mi("{Q_{n_1},\\ldots,Q_{n_k}}")#text(" of ")#emph[#text("disjoint")]#text(" cubes such that")

#align(center)[#tao-fit-display[#mitex("Q_{n_1} \\cup \\ldots \\cup Q_{n_k} = Q_1 \\cup \\ldots \\cup Q_N.")]]
]

#emph[#text("Proof:")]#text(" Take the ")#mi("{Q_{n_i}}")#text(" to be the maximal dyadic cubes in ")#mi("{Q_1,\\ldots,Q_N}")#text(" — the cubes which are not contained in any other cubes in this collection. The nesting property then ensures that they are disjoint and cover all of ")#mi("{Q_1,\\ldots,Q_N}")#text(" between them. ")#mi("\\Box")

#text("If we then define the ")#emph[#text("dyadic maximal function")]

#align(center)[#tao-fit-display[#tao-math("M_\\Delta f(x) := \\sup_{Q \\ni x} \\frac{1}{\\left|Q\\right|} \\int_Q \\left|f\\right| = \\sup_{Q \\ni x} \\frac{1}{\\left|Q\\right|} \\int_Q |f(y)|\\ dy", block: true)]]

#text("where ")#mi("{Q}")#text(" ranges over the dyadic cubes which contain ")#mi("{x}")#text(", then the same argument as before then gives the ")#emph[#text("dyadic Hardy-Littlewood maximal inequality")]

#metadata(none) <tao-079cdc52e64462dfac51>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\| M_\\Delta f \\right\\|_{L^{1,\\infty}({\\bf R}^d)} \\leq \\left\\|f\\right\\|_{L^1({\\bf R}^d)}", block: true)]]

#text("(with no constant loss whatsoever!) which then leads via Marcinkiewicz interpolation to")

#align(center)[#tao-fit-display[#tao-math("\\left\\| M_\\Delta f \\right\\|_{L^p({\\bf R}^d)} \\lesssim_p \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("for ")#mi("{1 < p \\leq \\infty}")#text(".")

#text("We can rewrite the dyadic maximal inequality in another way. Let ")#mi("{{\\mathcal B}_n}")#text(" be the ")#mi("{\\sigma}")#text("-algebra generated by the dyadic cubes of generation ")#mi("{n}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}(f|{\\mathcal B}_n)(x) = \\frac{1}{\\left|Q\\right|} \\int_Q f(y)\\ dy", block: true)]]

#text("where ")#mi("{Q}")#text(" is the unique dyadic cube of generation ")#mi("{n}")#text(" which contains ")#mi("{x}")#text(". The dyadic Hardy-Littlewood maximal inequality is then equivalent to the assertion that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_n \\left|\\mathop{\\bf E}( f|{\\mathcal B}_n )\\right| \\right\\|_{L^{1,\\infty}({\\bf R}^d)} \\leq \\left\\|f\\right\\|_{L^1({\\bf R}^d)}", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_n \\left|\\mathop{\\bf E}( f|{\\mathcal B}_n )\\right| \\right\\|_{L^p({\\bf R}^d)} \\lesssim_p \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("for ")#mi("{1 < p \\leq \\infty}")#text(".")

#text("Observe that if ")#mi("{x \\in Q}")#text(", then there is a ball ")#mi("{B(x,r)}")#text(" centred at ")#mi("{x}")#text(" which contains ")#mi("{Q}")#text(" of comparable volume: ")#tao-math("{\\left|B(x,r)\\right| \\sim_d \\left|Q\\right|}", block: false)#text(". Because of this, one easily obtains the pointwise inequality")

#align(center)[#tao-fit-display[#mitex("M_\\Delta f(x) \\lesssim_d M f(x)")]]

#text("and so the dyadic inequality follows (up to constants) from the non-dyadic one. The converse pointwise inequality is not true (test it with ")#mi("{d=1}")#text(" and ")#mi("{f = 1_{[0,1]}}")#text(", for instance). However, a slightly modification of this inequality is true, thanks to the ")#emph[#mi("{1/3}")#text("-translation trick")]#text(" that dates back to de la Vallée Poussin, though later rediscovered by harmonic analysts such as Okikiolu. We first explain this trick in the context of the unit interval ")#mi("{[0,1]}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 12")]#text(" Let ")#mi("{I \\subset [0,1]}")#text(" be a (non-dyadic) interval. Then there exists an interval ")#mi("{J}")#text(" which is either a dyadic interval, or a dyadic interval translated by ")#mi("{1/3}")#text(", such that ")#mi("{I \\subset J}")#text(" and ")#tao-math("{\\left|J\\right| \\lesssim \\left|I\\right|}", block: false)#text(".")
]

#text("The only significance of ")#mi("{1/3}")#text(" is that its binary digit expansion oscillates between ")#mi("{0}")#text(" and ")#mi("{1}")#text(". Note that the claim is false without the ")#mi("{1/3}")#text(" shifts; consider for instance the interval ")#mi("{[0.5-\\varepsilon,0.5+\\varepsilon]}")#text(" for some very small ")#mi("{\\varepsilon}")#text(", which straddles a certain “discontinuity” in the standard dyadic mesh. The point is that the dyadic mesh and the ")#mi("{1/3}")#text("-translate of the dyadic mesh do not share any discontinuities.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Prove the above lemma.")
]

#text("For intervals larger than ")#mi("{[0,1]}")#text(", a shift by ")#mi("{1/3}")#text(" is not enough; consider for instance what happens to the interval ")#mi("{(-1,1)}")#text(". Instead, we have to shift by ")#mi("{4^\\infty/3}")#text(", which of course does not make sense as a real number. However, it does make sense in some formal ")#mi("{2}")#text("-adic sense (as the doubly infinite binary string ")#mi("{\\ldots10101.010101\\ldots}")#text(") which is good enough to define shifted dyadic meshes.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 14 (Dyadic meshes)")]#text(" We define ")#mi("{{\\mathcal D}^1_0}")#text(" to be the collection of all dyadic intervals in ")#mi("{{\\bf R}}")#text(". We define ")#mi("{{\\mathcal D}^1_{4^\\infty/3}}")#text(" to be the collection of all intervals of the form ")#mi("{I + 4^N/3}")#text(", where ")#mi("{I}")#text(" is a dyadic interval at some generation ")#mi("{n}")#text(" and ")#mi("{N}")#text(" is any integer greater than or equal to ")#mi("{n}")#text(" (note that the exact choice of ")#mi("{N}")#text(" is irrelevant). If ")#mi("{\\alpha = (\\alpha_1,\\ldots,\\alpha_d) \\in \\{0, 4^\\infty/3\\}^d}")#text(", we let ")#mi("{{\\mathcal D}^d_\\alpha = {\\mathcal D}^1_{\\alpha_1} \\times \\ldots \\times {\\mathcal D}^1_{\\alpha_d} }")#text(" be the collection of cubes formed by the Cartesian product of intervals from ")#mi("{{\\mathcal D}^1_{\\alpha_1}, \\ldots, {\\mathcal D}^1_{\\alpha_d}}")#text(".")
]

#text("By modifying the above lemma one then quickly deduces")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 15")]#text(" Let ")#mi("{B \\subset {\\bf R}^d}")#text(" be a ball. Then there exists ")#mi("{\\alpha \\in \\{0, 4^\\infty/3\\}^d}")#text(" and a shifted dyadic cube ")#mi("{Q \\in {\\mathcal D}^d_\\alpha}")#text(" such that ")#mi("{B \\subset Q}")#text(" and ")#tao-math("{\\left|Q\\right| \\lesssim_d \\left|B\\right|}", block: false)#text(".")
]

#text("This in turn leads to the pointwise inequality bounding the dyadic maximal function by the ordinary one:")

#align(center)[#tao-fit-display[#mitex("Mf(x) \\lesssim_d \\sup_{\\alpha \\in \\{0,4^\\infty/3\\}^d} M_{\\Delta,\\alpha} f(x)")]]

#text("where ")#mi("{M_{\\Delta,\\alpha}}")#text(" is the shifted dyadic maximal function")

#align(center)[#tao-fit-display[#tao-math("M_{\\Delta,\\alpha} f(x) := \\sup_{Q \\in {\\mathcal D}^d_\\alpha: Q \\ni x} \\frac{1}{\\left|Q\\right|} \\int_Q |f|.", block: true)]]

#text("A routine modification of the proof of the dyadic maximal inequality (or translating this inequality by ")#mi("{4^N/3}")#text(" and taking limits as ")#mi("{N \\rightarrow \\infty}")#text(") shows that each of the ")#mi("{M_{\\Delta,\\alpha}}")#text(" are individually of weak-type ")#mi("{(1,1)}")#text(", and bounded on ")#mi("{L^p}")#text(" for ")#mi("{1 < p \\leq \\infty}")#text(". Since there are only ")#mi("{O_d(1)}")#text(" many choices of ")#mi("{\\alpha}")#text(", we can then deduce the usual Hardy-Littlewood maximal inequality from the dyadic one.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 16")]#text(" What is going on here is that there are two ways to view the real line ")#mi("{{\\bf R}}")#text(". One is the “Euclidean” way, with the usual group structure and metric. The other is the “Walsh” or “dyadic” way, in which we identify ")#mi("{{\\bf R}}")#text(" with the ")#link("https://en.wikipedia.org/wiki/Cantor_cube")[#text("Cantor group")]

#align(center)[#tao-fit-display[#mitex("{\\bf R}_\\Delta := \\{ (a_n)_{n \\in {\\bf Z}} \\in ({\\bf Z}/2{\\bf Z})^{\\bf Z}: a_n = 0 \\text{ for sufficiently large } n \\}")]]

#text("via the binary representation, ")#mi("{\\sum_n a_n 2^{-n} \\equiv (a_n)_{n \\in {\\bf Z}}}")#text(" (identifying ")#mi("{{\\bf Z}/2{\\bf Z}}")#text(" with ")#mi("{(0,1)}")#text(", and ignoring the measure zero sets of terminating decimals where the binary representation is not unique). The group structure is now the one inherited from the Cantor group; in the binary representation, the Cantor-Walsh addition law ")#mi("{x +_\\Delta y}")#text(" is the same as ordinary addition ")#mi("{x+y}")#text(" but where we neglect to carry bits. The usual archimedean metric ")#tao-math("{d(x,y) = \\left|x-y\\right|}", block: false)#text(" is replaced by the non-archimedean metric ")#mi("{d_\\Delta(x,y)}")#text(", defined by")

#align(center)[#tao-fit-display[#mitex("d_\\Delta((a_n)_{n \\in {\\bf Z}}, (b_n)_{n \\in {\\bf Z}}) := \\sup \\{ 2^n: a_n \\neq b_n \\}.")]]

#text("With this metric, the dyadic intervals become the metric balls.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Hardy-Littlewood maximal inequality for filtrations)")]#text(" Let ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" be a measure space, and let ")#mi("{{\\mathcal B}_n}")#text(" be an increasing sequence of ")#mi("{\\sigma}")#text("-finite ")#mi("{\\sigma}")#text("-algebras in ")#mi("{{\\mathcal B}}")#text(" (thus ")#mi("{{\\mathcal B}_n \\subset {\\mathcal B}_{n+1}}")#text(" for all ")#mi("{n \\in {\\bf Z}}")#text("). Show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_n \\left|\\mathop{\\bf E}(f|{\\mathcal B}_n)\\right| \\right\\|_{L^{1,\\infty}(X,{\\mathcal B},\\mu)} \\leq \\left\\|f\\right\\|_{L^1(X,{\\mathcal B},\\mu)}", block: true)]]

#text("and hence")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_n \\left|\\mathop{\\bf E}(f|{\\mathcal B}_n)\\right| \\right\\|_{L^p(X,{\\mathcal B},\\mu)} \\lesssim_p \\left\\|f\\right\\|_{L^p(X,{\\mathcal B},\\mu)}", block: true)]]

#text("for all ")#mi("{1 < p \\leq \\infty}")#text(" and all ")#mi("{{\\mathcal B}}")#text("-measurable ")#mi("{f}")#text(" for which the right-hand side is finite. (Hint: use monotone convergence to reduce to finitely many ")#mi("{{\\mathcal B}_n}")#text(". Reduce further to the case when the ")#mi("{{\\mathcal B}_n}")#text(" are countably generated (by using the level sets of the ")#mi("{\\mathop{\\bf E}(f|{\\mathcal B}_m)}")#text(" for rational intervals). Reduce further still to the case where the ")#mi("{{\\mathcal B}_n}")#text(" are finitely generated, i.e. finite. Now adapt the dyadic argument. There are also simpler arguments which do not require all of these reductions.) This inequality is also known as ")#link("https://en.wikipedia.org/wiki/Doob%27s_martingale_inequality")[#text("Doob’s inequality")]#text(", and implies in particular that ")#mi("{\\mathop{\\bf E}(f|{\\mathcal B}_n)}")#text(" converges pointwise a.e. to ")#mi("{\\mathop{\\bf E}(f|\\bigvee_n {\\mathcal B}_n)}")#text(" whenever ")#mi("{f \\in L^1(X,{\\mathcal B},\\mu)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18 (Relationship between dyadic and non-dyadic Hardy-Littlewood maximal inequalities)")]#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be locally integrable. Establish the pointwise bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ M_\\Delta f \\geq C_d \\lambda\\}\\right| \\leq \\left|\\{ Mf \\geq \\lambda \\}\\right| \\lesssim_d \\left|\\{ M_\\Delta f \\geq c_d \\lambda \\}\\right|", block: true)]]

#text("for some ")#mi("{c_d > 0}")#text(" depending only on ")#mi("{d}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 4. Third proof — ")]]

#text("In the above arguments we obtained ")#mi("{L^p}")#text(" bounds by first proving weak ")#mi("{(1,1)}")#text(" bounds and then interpolating. It is natural to ask whether such bounds can be obtained directly. The answer is yes, but it is surprisingly more difficult to do so. Let us give two such approaches, a ")#link("https://en.wikipedia.org/wiki/Bellman_equation")[#text("Bellman function")]#text(" approach and a ")#emph[#mi("{TT^*}")#text(" method approach")]#text(", which are themselves powerful methods which apply to many other problems as well.")

#text("We begin with the Bellman function approach. This method works primarily for dyadic model operators, such as ")#mi("{M_\\Delta}")#text(", though it can also work for very geometric operators as well (using geometric averaging operators such as heat kernels in place of the dyadic averaging operators). For simplicity let us just work in one dimension (though it is possible to use rearrangement and space-filling curves to deduce the higher-dimensional case from the one-dimensional case), and consider the task of establishing")

#align(center)[#tao-fit-display[#tao-math("\\left\\| M_\\Delta f \\right\\|_{L^p({\\bf R})} \\lesssim_p \\left\\|f\\right\\|_{L^p({\\bf R})}", block: true)]]

#text("for some fixed ")#mi("{1 < p \\leq \\infty}")#text(" (such as ")#mi("{p=2}")#text(").")

#text("The idea is to work by ")#emph[#text("induction on scales")]#text(" – in other words, to induct on the number of generations. To do this we need a “base case”, so we perform some qualitative reductions. Fix ")#mi("{1 < p < \\infty}")#text(" (the case ")#mi("{p=\\infty}")#text(" being trivial). By a monotone convergence argument we may restrict attention only to those intervals ")#mi("{I}")#text(" of length larger than ")#mi("{2^{-N}}")#text(", so long as our estimates are uniform in ")#mi("{N}")#text(". By rescaling (replacing ")#mi("{f(x)}")#text(" by ")#mi("{f(2^N x)}")#text(") we can reduce to the case ")#mi("{N=0}")#text(". Let us write ")#mi("{M_{\\geq 1}}")#text(" for the dyadic maximal function restricted to intervals of length at least ")#mi("{1}")#text(". By a monotone convergence argument (there is a slight problem because we cannot represent ")#mi("{{\\bf R}}")#text(" as the monotone limit of dyadic intervals; however we can do this for ")#mi("{{\\bf R}^+}")#text(" and ")#mi("{{\\bf R}^-}")#text(" separately, and then add up, noting that the dyadic maximal function is localised to each of these half-lines, e.g. if ")#mi("{f}")#text(" is supported on ")#mi("{{\\bf R}^+}")#text(" then so is ")#mi("{M_{\\geq 1} f}")#text(") we can also assume that ")#mi("{f}")#text(" is supported on a dyadic interval ")#mi("{I}")#text(" of some length ")#mi("{2^n \\geq 1}")#text(", and also we may restrict ")#mi("{M_{\\geq 1} f}")#text(" to that interval. We can also take ")#mi("{f}")#text(" to be non-negative. Our task is now to show that there exists a constant ")#mi("{C_p}")#text(" such that ")#metadata(none) <tao-c2c2df2657974c48f0eb>#tao-math("\\displaystyle  \\frac{1}{\\left|I\\right|} \\int_I (M_{\\geq 1} f(x))^p\\ dx \\leq C_p \\frac{1}{\\left|I\\right|} \\int_I f(x)^p\\ dx \\ \\ \\ \\ \\ (4)", block: false)#text(" ")#text(" whenever ")#mi("{f: I \\rightarrow {\\bf R}^+}")#text(". (We make the constant ")#mi("{C_p}")#text(" explicit here because of the induction that we shall shortly use.) Of course the point is that ")#mi("{C_p}")#text(" is independent of ")#mi("{n}")#text(", ")#mi("{I}")#text(", and ")#mi("{f}")#text(".")

#text("We make a small but useful remark: once ")#mi("{f}")#text(" and ")#mi("{M_{\\geq 1} f}")#text(" are both restricted to ")#mi("{I}")#text(", the only dyadic intervals ")#mi("{J}")#text(" which are relevant in the definition of ")#mi("{M_{\\geq 1} f}")#text(" are those which are contained in ")#mi("{I}")#text(" (including ")#mi("{I}")#text(" itself). Intervals which are disjoint from ")#mi("{I}")#text(" play no role, and intervals which contain ")#mi("{I}")#text(" give a worse average than that arising from ")#mi("{I}")#text(" itself.")

#text("The idea is to prove this by induction on the generation ")#mi("{n}")#text(" of ")#mi("{I}")#text(". Our first approach will not quite work, but a subtle modification of it will.")

#text("When ")#mi("{n=0}")#text(" the claim is trivial (as long as ")#mi("{C_p \\geq 1}")#text("), because for ")#mi("{I}")#text(" a dyadic interval of generation ")#mi("{0}")#text(" and ")#mi("{x \\in I}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("M_{\\geq 1} f(x) = \\frac{1}{\\left|I\\right|} \\int_I f(y)\\ dy \\leq (\\frac{1}{\\left|I\\right|} \\int_I f(x)^p)^{1/p}.", block: true)]]

#text("Now let ")#mi("{n \\geq 1}")#text(", and let us see whether we can deduce the ")#mi("{n}")#text(" case from the ")#mi("{n-1}")#text(" case ")#emph[#text("without causing any deterioration in the constant ")#mi("{C_p}")]#text(". (Using various applications of the triangle inequality it is not hard to get from ")#mi("{n-1}")#text(" to ")#mi("{n}")#text(", replacing ")#mi("{C_p}")#text(" with something worse like ")#mi("{2C_p + 1}")#text(", but this is not going to iterate into something independent of ")#mi("{n}")#text(".)")

#text("Let us split the dyadic interval ")#mi("{I}")#text(" of generation ")#mi("{n}")#text(" into two “children” ")#mi("{I = I_l \\cup I_r}")#text(" of generation ")#mi("{n-1}")#text(" (")#mi("{l}")#text(" and ")#mi("{r}")#text(" stand for left and right). This also causes a split ")#mi("{f = f_l + f_r}")#text(". By induction hypothesis we have")

#align(center)[#tao-fit-display[#tao-math("\\begin{array}{rl}  \\frac{1}{\\left|I_l\\right|} \\int_{I_l} (M_{\\geq 1} f_l(x))^p\\ dx &\\leq C_p \\frac{1}{\\left|I_l\\right|} \\int_{I_l} f_l(x)^p\\ dx \\\\ \\frac{1}{\\left|I_r\\right|} \\int_{I_r} (M_{\\geq 1} f_r(x))^p\\ dx &\\leq C_p \\frac{1}{\\left|I_r\\right|} \\int_{I_r} f_r(x)^p\\ dx. \\end{array}", block: true)]]

#text("and we also trivially have")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|I\\right|} \\int_I f(x)^p\\ dx = \\frac{1}{2} (\\frac{1}{\\left|I_l\\right|} \\int_{I_l} f_l(x)^p\\ dx + \\frac{1}{\\left|I_r\\right|} \\int_{I_r} f_r(x)^p)\\ dx.", block: true)]]

#text("Now if we were lucky enough to have the pointwise estimates")

#align(center)[#tao-fit-display[#mitex("M_{\\geq 1} f(x) \\leq M_{\\geq 1} f_l(x) \\text{ when } x \\in I_l")]]

#text("and similarly for ")#mi("{I_r}")#text(", then we could simply average the two induction hypotheses and be done. However, this is not quite the case: the correct relationship between the maximal function of ")#mi("{f}")#text(" and of ")#mi("{f_l, f_r}")#text(" is that")

#align(center)[#tao-fit-display[#tao-math("M_{\\geq 1} f(x) = \\max( M_{\\geq 1} f_l(x), \\frac{1}{\\left|I\\right|} \\int_I f ) \\text{ when } x \\in I_l", block: true)]]

#text("and similarly when ")#mi("{x \\in I_r}")#text(". This causes a problem. If we estimate the max by a sum and use triangle type inequalities, we will eventually get a bound such as ")#link(<tao-c2c2df2657974c48f0eb>)[#text("(4)")]#text(" but with ")#mi("{C_p}")#text(" replaced by ")#mi("{O_p(C_p+1)}")#text(", which is not acceptable for iteration purposes. So we have to somehow keep the max with the constant ")#tao-math("{\\frac{1}{\\left|I\\right|} \\int_I f}", block: false)#text(" with us in the induction argument. This eventually forces us to change the induction hypothesis ")#link(<tao-c2c2df2657974c48f0eb>)[#text("(4)")]#text(", replacing the left-hand side ")#tao-math("{\\frac{1}{\\left|I\\right|} \\int_I M_{\\geq 1} f(x)^p\\ dx}", block: false)#text(" by the more general ")#tao-math("{\\frac{1}{\\left|I\\right|} \\int_I \\max(M_{\\geq 1} f(x), A)^p\\ dx}", block: false)#text(" for some arbitrary ")#mi("{A > 0}")#text(". Given our knowledge that max and addition are comparable up to constants, we know that ")#link(<tao-c2c2df2657974c48f0eb>)[#text("(4)")]#text(" is equivalent to the estimate")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|I\\right|} \\int_I \\max(M_{\\geq 1} f(x),A)^p\\ dx \\leq C^{\\prime}_p (\\frac{1}{\\left|I\\right|} \\int_I f(x)^p\\ dx + A^p )", block: true)]]

#text("up to changes in the constant ")#mi("{C_p}")#text(". But perhaps this estimate has a better chance of being proven by induction. The key recursive inequality is now that")

#align(center)[#tao-fit-display[#tao-math("\\max(M_{\\geq 1} f(x),A) = \\max( M_{\\geq 1} f_l(x), \\max(A,\\frac{1}{\\left|I\\right|} \\int_I f) ) \\text{ when } x \\in I_l", block: true)]]

#text("and similarly for ")#mi("{I_l}")#text(". One can try the induction strategy again, but one sees that the inability to efficiently control ")#tao-math("{\\frac{1}{\\left|I\\right|} \\int_I f}", block: false)#text(" in terms of ")#mi("{\\int_I f(x)^p\\ dx}")#text(" and ")#mi("{A}")#text(" is a serious problem. (Hölder’s inequality of course gives ")#tao-math("{\\frac{1}{\\left|I\\right|} \\int_I f}", block: false)#text(" bounded by ")#tao-math("{(\\frac{1}{\\left|I\\right|} \\int_I f^p)^{1/p}}", block: false)#text(", but this turns out to be insufficient.) Because of this, we have no choice but to also throw in the average ")#tao-math("{B = \\frac{1}{\\left|I\\right|} \\int_I f}", block: false)#text(" into the induction hypothesis somehow.")

#text("Let us formalise this as follows. Given any parameters ")#mi("{D, B, A > 0}")#text(", let ")#mi("{V_n(A,B,D)}")#text(" denote the ")#emph[#text("cost function")]

#align(center)[#tao-fit-display[#tao-math("\\begin{array}{c} V_n(A,B,D) := \\sup \\{ \\frac{1}{\\left|I\\right|} \\int_I \\max(M_{\\geq 1} f(x), A)^p\\ dx: \\\\ \\frac{1}{\\left|I\\right|} \\int_I f^p = D; \\frac{1}{\\left|I\\right|} \\int_I f = B; \\left|I\\right|=2^n \\}\\end{array}", block: true)]]

#text("where ")#mi("{f}")#text(" is understood to be nonnegative and supported on a dyadic interval ")#mi("{I}")#text(" of generation ")#mi("{n}")#text(". Note that Hölder’s inequality shows that ")#mi("{V_n(A,B,D) = -\\infty}")#text(" when ")#mi("{B^p > D}")#text(", since in this case the supremum is over an empty set. Our task is thus to show that")

#metadata(none) <tao-bb08e9bed6c8ad48b062>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("V_n(A,B,D) \\lesssim_p D + A^p")]]

#text("uniformly in ")#mi("{n}")#text(" and in ")#mi("{A,B,D}")#text(". As we said earlier, the ")#mi("{B}")#text(" parameter is not obviously necessary yet, but will become so when we try to perform the induction, as it tracks a certain finer property of the function ")#mi("{f}")#text(" which needs to be managed in order to prevent the constants from blowing up. The base case when ")#tao-math("{\\left|I\\right|=1}", block: false)#text(" is again trivial; the issue is to pass from fine scales to coarse scales without destroying the boundedness of implicit constant.")

#text("Now the recursive inequality can be turned into an inequality for ")#mi("{V_n}")#text(". Suppose that ")#mi("{f}")#text(" attains the supremum (or comes within an epsilon of it). We have")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|I_l\\right|} \\int_{I_l} f_l^p = D - \\delta; \\quad \\frac{1}{\\left|I_r\\right|} \\int_{I_r} f_r^p = D + \\delta", block: true)]]

#text("for some ")#tao-math("{\\left|\\delta\\right| \\leq D}", block: false)#text(". Similarly")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|I_l\\right|} \\int_{I_l} f_l = B - \\beta; \\quad \\frac{1}{\\left|I_r\\right|} \\int_{I_r} f_r = B + \\beta", block: true)]]

#text("for some ")#tao-math("{\\left|\\beta\\right| \\leq B}", block: false)#text(". Then we have")

#align(center)[#tao-fit-display[#mitex("\\max( M_{\\geq 1} f(x), A ) = \\max( M_{\\geq 1} f_l(x), \\max(A, B) )")]]

#text("for ")#mi("{x \\in I_l}")#text(", and similarly for ")#mi("{x \\in I_r}")#text("; by construction we thus have")

#align(center)[#tao-fit-display[#tao-math("\\begin{array}{c} \\frac{1}{\\left|I\\right|} \\int_I \\max( M_{\\geq 1} f(x), A )^p \\\\ \\leq \\frac{1}{2}( V_{n-1}( \\max(A,B), B-\\beta, D-\\delta ) \\\\ + V_{n-1}( \\max(A,B), B+\\beta, D+\\delta ) ).\\end{array}", block: true)]]

#text("Taking suprema, we obtain the recursive inequality")

#align(center)[#tao-fit-display[#tao-math("\\begin{array}{c} V_n(A,B,D) \\leq \\sup_{\\left|\\beta\\right| \\leq B, \\left|\\delta\\right| \\leq D} \\\\ \\frac{1}{2}( V_{n-1}( \\max(A,B), B-\\beta, D-\\delta ) + V_{n-1}( \\max(A,B), B+\\beta, D+\\delta ) ).\\end{array}", block: true)]]

#text("(In fact, this is an equality — why?) On the other hand, ")#mi("{V_0}")#text(" can be computed directly as")

#align(center)[#tao-fit-display[#mitex("V_0(A,B,D) = \\max(A,B)^p")]]

#text("when ")#mi("{B^p \\leq D}")#text(", and ")#mi("{V_0(A,B,D)=-\\infty}")#text(" otherwise. In principle, this gives us a complete description of ")#mi("{V_n(A,B,D)}")#text(", which should allow one to determine the truth or falsity of ")#link(<tao-bb08e9bed6c8ad48b062>)[#text("(5)")]#text(". Note that we have reduced the problem from one involving an unknown function ")#mi("{f}")#text(" (which has infinitely many degrees of freedom) to one involving just three scalar parameters ")#mi("{A,B,D}")#text(", except that we have a different cost function at every scale. However, suppose that we can devise a ")#emph[#text("Bellman function")]#text(" ")#mi("{\\Phi(A,B,D)}")#text(" with the property that")

#metadata(none) <tao-094aeaa555a83c8a8ef2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("V_0(A,B,D) \\lesssim \\Phi(A,B,D) \\lesssim_p D+A^p")]]

#text("for all ")#mi("{A,B,D}")#text(", and such that ")#mi("{\\Phi}")#text(" obeys the inequality")

#metadata(none) <tao-3bdea8d9f6b92bce4d7f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\begin{array}{c} \\Phi(A,B,D) \\geq \\frac{1}{2}( \\Phi( \\max(A,B), B-\\beta, D-\\delta ) \\\\ + \\Phi( \\max(A,B), B+\\beta, D+\\delta ) ) \\end{array}")]]

#text("whenever ")#tao-math("{\\left|\\beta\\right| \\leq B}", block: false)#text(" and ")#tao-math("{\\left|\\delta\\right| \\leq D}", block: false)#text(". Then an induction will show that")

#align(center)[#tao-fit-display[#mitex("V_n(A,B,D) \\lesssim \\Phi(A,B,D) \\lesssim_p D+A^p")]]

#text("for all ")#mi("{n}")#text(" (and note that the implied constants here are ")#emph[#text("uniform")]#text(" in ")#mi("{n}")#text("), thus proving ")#link(<tao-bb08e9bed6c8ad48b062>)[#text("(5)")]#text(".")

#text("Thus the whole task is reduced to a freshman calculus problem, namely to find a function of three variables obeying the bounds ")#link(<tao-094aeaa555a83c8a8ef2>)[#text("(6)")]#text(" and ")#link(<tao-3bdea8d9f6b92bce4d7f>)[#text("(7)")]#text(". The difficulty of course, is to find the function; verifying the properties is then routine. This “hunt for a Bellman function” is surprisingly subtle, and requires one to choose a surprisingly non-trivial choice of ")#mi("{\\Phi}")#text(".")

#text("By considering the scale invariance when we multiply ")#mi("{f}")#text(" by a scalar ")#mi("{\\lambda}")#text(", and multiply ")#mi("{A,B,D}")#text(" by ")#mi("{\\lambda,\\lambda,\\lambda^p}")#text(" respectively, we obtain the scaling law")

#align(center)[#tao-fit-display[#mitex("V_n(\\lambda A, \\lambda B, \\lambda^p D) = \\lambda^p V_n(A,B,D)")]]

#text("and so the Bellman function should also obey the same scaling law. In particular, the ratio ")#mi("{B/A}")#text(" is a dimensionless quantity.")

#text("The condition ")#link(<tao-3bdea8d9f6b92bce4d7f>)[#text("(7)")]#text(" resembles a concavity condition, and so it is natural to try to find choices which are concave in some of the variables. An initial candidate is the function ")#mi("{\\Phi(A,B,D) = D}")#text(", which certainly obeys ")#link(<tao-3bdea8d9f6b92bce4d7f>)[#text("(7)")]#text(" and the upper bound of ")#link(<tao-094aeaa555a83c8a8ef2>)[#text("(6)")]#text(" (and which, in fact, ultimately corresponds to the original estimate ")#link(<tao-c2c2df2657974c48f0eb>)[#text("(4)")]#text(" before we threw in the other parameters ")#mi("{B,A}")#text("); unfortunately it does not obey the lower bound in ")#link(<tao-094aeaa555a83c8a8ef2>)[#text("(6)")]#text(", in the case where ")#mi("{A}")#text(" is large compared with ")#mi("{B}")#text(" and ")#mi("{D^{1/p}}")#text(". So we need to tweak this function somewhat. The first step is to improve the concavity by exploiting the fact that the function only needs to be non-trivial on the region ")#mi("{B^p \\leq D}")#text(". One can exploit this by using the candidate function ")#mi("{\\Phi(A,B,C) = D - \\frac{1}{2} B^p}")#text(" (say). This still obeys ")#link(<tao-3bdea8d9f6b92bce4d7f>)[#text("(7)")]#text(", but now with a bit of a gain when ")#mi("{\\beta}")#text(" is large due to the ")#emph[#text("strict")]#text(" concavity of ")#mi("{-B^p}")#text(". (One cannot play similar games with the ")#mi("{D}")#text(" parameter as the upper and lower bounds in ")#link(<tao-094aeaa555a83c8a8ef2>)[#text("(6)")]#text(" force linear-type behaviour in ")#mi("{D}")#text(".) But we still have not fixed the problem that ")#mi("{\\Phi}")#text(" is not as large as ")#mi("{V_0(A,B,D)}")#text(" when ")#mi("{A}")#text(" is large. After some trial and error, one eventually lands on the ansatz")

#align(center)[#tao-fit-display[#mitex("\\Phi(A,B,C) = D + A^p f( B/A )")]]

#text("for some function ")#mi("{f: {\\bf R}^+ \\rightarrow {\\bf R}}")#text(" depending on ")#mi("{p}")#text(" which we will choose presently. The function ")#mi("{f(x) = -\\frac{1}{2} x^p}")#text(" gives us back our previous attempt ")#mi("{D - \\frac{1}{2} B^p}")#text(".")

#text("The upper bound in ")#link(<tao-094aeaa555a83c8a8ef2>)[#text("(6)")]#text(" is now clear if we have an upper bound of the form ")#metadata(none) <tao-3f524cdc07a11d7c6220>#mi("\\displaystyle  f(x) \\leq O_p(1) \\ \\ \\ \\ \\ (8)")#text(" ")#text(" for all ")#mi("{x \\geq 0}")#text(". Now we consider the lower bound. If we have the lower bound ")#metadata(none) <tao-e4ab4e3b1493d5a997b4>#mi("\\displaystyle  f(x) \\geq -\\frac{1}{2} x^p \\ \\ \\ \\ \\ (9)")#text(" ")#text(" for all ")#mi("{x \\geq 0}")#text(", then from the constraint ")#mi("{B^p \\leq D}")#text(" we have the lower bound ")#mi("{f(x) \\geq \\frac{1}{2} D \\geq \\frac{1}{2} B^p}")#text(". This already gives ")#link(<tao-094aeaa555a83c8a8ef2>)[#text("(6)")]#text(" unless the ratio ")#mi("{B/A}")#text(" is very close to zero. But ")#mi("{f}")#text(" is continuous with ")#metadata(none) <tao-625e0f649de27800fc3b>#mi("\\displaystyle  f(0) > 0 \\ \\ \\ \\ \\ (10)")#text(" ")#text(" then for ")#mi("{B/A}")#text(" small enough, ")#mi("{f}")#text(" is bounded away from zero, and we also get a lower bound ")#mi("{\\Phi(A,B,D) \\gg A^p}")#text(". Thus we will recover both sides of ")#link(<tao-094aeaa555a83c8a8ef2>)[#text("(6)")]#text(".")

#text("It remains to establish ")#link(<tao-3bdea8d9f6b92bce4d7f>)[#text("(7)")]#text(". By homogeneity we may normalize ")#mi("{A=1}")#text(", and the inequality simplifies to an inequality for ")#mi("{f}")#text(":")

#align(center)[#tao-fit-display[#mitex("f(B) \\leq \\frac{1}{2}( \\max(1,B)^p f(\\frac{B-\\beta}{\\max(1,B)}) + \\max(1,B)^p f(\\frac{B+\\beta}{\\max(1,B)}) ).")]]

#text("If ")#mi("{B \\leq 1}")#text(", then this simplifies to")

#align(center)[#tao-fit-display[#mitex("f(B) \\leq \\frac{1}{2}( f(B-\\beta) + f(B+\\beta))")]]

#text("and so if we require ")#mi("{f}")#text(" to be concave then we will be done in this case. Now suppose ")#mi("{B > 1}")#text(", so we now seek to show that")

#align(center)[#tao-fit-display[#mitex("f(B) \\leq \\frac{1}{2}( B^p f(\\frac{B-\\beta}{B}) + f(\\frac{B+\\beta}{B})).")]]

#text("Let ")#mi("{0 < \\varepsilon < 1}")#text(" be a small quantity to be chosen later, and suppose that")

#metadata(none) <tao-608cdb524384f5ee06ed>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("f(x) = -\\frac{1}{2} x^p \\text{ for } x \\geq \\varepsilon.")]]

#text("Then from the concavity of ")#mi("{-\\frac{1}{2}x^p}")#text(" we see that we are done as long as ")#mi("{\\frac{B-\\beta}{B}}")#text(", ")#mi("{\\frac{B+\\beta}{B}}")#text(" are larger than ")#mi("{\\varepsilon}")#text(". The only case remaining is if ")#mi("{\\frac{B-\\beta}{B} \\leq \\varepsilon}")#text(", which forces ")#mi("{\\frac{B+\\beta}{B} = (2-O(\\varepsilon)) B}")#text(". If we also require")

#metadata(none) <tao-b6e1288527a6032c0f29>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("f(x) \\geq - O_p(\\varepsilon^p) \\text{ for } 0 \\leq x \\leq \\varepsilon")]]

#text("then the inequality take the form")

#align(center)[#tao-fit-display[#mitex("-\\frac{1}{2} B^p \\leq \\frac{1}{2}( - O_p(\\varepsilon^p) + (2-O(\\varepsilon))^p B^p ),")]]

#text("which is valid for ")#mi("{B \\geq 1}")#text(" if ")#mi("{\\varepsilon}")#text(" is small enough.")

#text("Finally, we note that we can construct a concave (hence continuous) function ")#mi("{f}")#text(" obeying all the required properties ")#link(<tao-3f524cdc07a11d7c6220>)[#text("(8)")]#text("–")#link(<tao-b6e1288527a6032c0f29>)[#text("(12)")]#text(", by using ")#link(<tao-608cdb524384f5ee06ed>)[#text("(11)")]#text(" for ")#mi("{x \\geq \\varepsilon}")#text(" and extending linearly by the tangent line to ")#link(<tao-608cdb524384f5ee06ed>)[#text("(11)")]#text(" at ")#mi("{x=\\varepsilon}")#text(" to cover the ")#mi("{x < \\varepsilon}")#text(" range.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 19")]#text(" Bellman function methods are in principle the sharpest and most powerful technique to prove estimates. However they are restricted to dyadic settings (or very geometric continuous settings), and are very delicate due to the need to establish very subtle concavity properties. In the recent OpenAI release, the Bellman function method ")#link("https://github.com/openai/math/blob/main/preprints/An-L3-bound-for-the-dyadic-triangular-Hilbert-form-October-5-2026/dyadic-triangular-hilbert.pdf")[#text("was used")]#text(" to bound a dyadic version of the triangular Hilbert transform; the ")#link("https://github.com/openai/math/blob/main/preprints/The-maximal-triangular-Hilbert-transform-at-the-symmetric-point-September-24-2026/paper.pdf")[#text("same method can be extended to the continuous counterpart")]#text(", but with a significantly more complicated proof.")
]

#heading(level: 1)[#strong[#text(" — 5. Fourth proof — ")]]

#text("Finally, we present the “")#mi("{TT^*}")#text(" approach” to the Hardy-Littlewood maximal inequality. This approach works for both the dyadic and non-dyadic maximal functions, but is restricted to establishing ")#mi("{L^2}")#text(" boundedness (this is a fundamental limitation of the ")#mi("{TT^*}")#text(" method, that at least one of the spaces involved has to be a Hilbert space). The basic idea is rather than prove a boundedness result directly on the maximal operator ")#mi("{M}")#text(" (i.e. an estimate of the form ")#mi("{M = O(1)}")#text("), we prove an estimate on the square of this operator (roughly speaking, we prove an estimate of the form ")#mi("{M^2 = O(M)}")#text("). This is an example of a powerful strategy to understand an operator by raising it to a higher power, and hoping to exploit some self-cancellation. Note that we do not have to cancel the entire power (which would roughly speaking correspond to proving a bound of the form ")#mi("{M^2 = O(1)}")#text("); any nontrivial cancellation at all is exploitable.")

#text("Let us work with the non-dyadic maximal function, thus we wish to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{r > 0} A_r f \\right\\|_{L^2({\\bf R}^d)} \\lesssim_d \\left\\|f\\right\\|_{L^2({\\bf R}^d)}", block: true)]]

#text("for all non-negative ")#mi("{f}")#text(". As before we may restrict ")#mi("{r}")#text(" to range in a finite set ")#mi("{{\\mathcal R}}")#text(", provided our bounds are independent of the choice of ")#mi("{{\\mathcal R}}")#text(". Note that because each ")#mi("{A_r}")#text(" is already bounded on ")#mi("{L^2}")#text(", the maximal operator is now already bounded with ")#emph[#text("some")]#text(" finite operator norm. Let ")#mi("{D}")#text(" denote the optimal such norm, thus ")#mi("{D}")#text(" is the best constant for which")

#metadata(none) <tao-ef809616390533e15df6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left\\| \\sup_{r \\in {\\mathcal R}} A_r f \\right\\|_{L^2({\\bf R}^d)} \\leq D \\left\\|f\\right\\|_{L^2({\\bf R}^d)}.", block: true)]]

#text("We know ")#mi("{D}")#text(" is finite; our objective is to obtain the bound ")#mi("{D = O_d(1)}")#text(". We will do this by controlling ")#mi("{D}")#text(" in a nontrivial way in terms of itself, and in particular by controlling the “square” of the maximal operator by the maximal operator.")

#text("Observe that ")#link(<tao-ef809616390533e15df6>)[#text("(13)")]#text(" is equivalent to the uniform linearised estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| A_{r(x)} f(x) \\right\\|_{L^2_x({\\bf R}^d)} \\leq D \\left\\|f\\right\\|_{L^2({\\bf R}^d)}", block: true)]]

#text("for all measurable functions ")#mi("{r: {\\bf R}^d \\rightarrow {\\mathcal R}}")#text(".")

#text("Let us fix the function ")#mi("{r}")#text(". Then we can define the linear operator ")#mi("{T_r}")#text(" by")

#align(center)[#tao-fit-display[#tao-math("T_r f(x) := A_{r(x)} f(x) = \\frac{1}{\\left|B(x,r(x))\\right|} \\int_{{\\bf R}^d} 1_{\\left|x-y\\right| \\leq r(x)} f(y)\\ dy.", block: true)]]

#text("We can thus interpret ")#mi("{D}")#text(" as the largest ")#mi("{L^2}")#text(" operator norm of the ")#mi("{T_r}")#text(":")

#align(center)[#tao-fit-display[#tao-math("D = \\sup_r \\left\\| T_r \\right\\|_{L^2({\\bf R}^d) \\rightarrow L^2({\\bf R}^d)}.", block: true)]]

#text("To compute this operator norm we make the following observation.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 20 (")#mi("{TT^*}")#text(" identity)")]#text(" Let ")#mi("{T: H \\rightarrow X}")#text(" be a continuous map from a Hilbert space to a normed vector space, and let ")#mi("{T^*: X^* \\rightarrow H}")#text(" be its adjoint. Then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T \\right\\|_{H \\rightarrow X} = \\left\\|T^* \\right\\|_{X^* \\rightarrow H} = \\left\\| TT^* \\right\\|_{X^* \\rightarrow X}^{1/2}.", block: true)]]
]

#emph[#text("Proof:")]#text(" The first identity is just duality. Then we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|TT^* \\right\\|_{X^* \\rightarrow X} \\leq \\left\\| T \\right\\|_{H \\rightarrow X} \\left\\|T^* \\right\\|_{X^* \\rightarrow H} = \\left\\|T^* \\right\\|_{X^* \\rightarrow H}^2", block: true)]]

#text("which gives the lower bound in the second identity. For the upper bound, observe that for any ")#mi("{f \\in X^*}")#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T^* f \\right\\|_H^2 = \\langle f, TT^* f \\rangle \\leq \\left\\|f\\right\\|_{X^*} \\left\\| TT^* f \\right\\|_X \\leq \\left\\|f\\right\\|_{X^*}^2 \\left\\| TT^* \\right\\|_{X^* \\rightarrow X};", block: true)]]

#text("taking square roots gives the upper bound as desired. ")#mi("\\Box")

#text("In light of this identity we know that")

#align(center)[#tao-fit-display[#tao-math("D^2 = \\sup_r \\left\\| T_r T_r^* \\right\\|_{L^2({\\bf R}^d) \\rightarrow L^2({\\bf R}^d)}.", block: true)]]

#text("Now let us take a look at what ")#mi("{T_r T_r^*}")#text(" is. Observe that ")#mi("{T_r}")#text(" is an integral operator with kernel")

#align(center)[#tao-fit-display[#tao-math("K(x,y) := \\frac{1}{\\left|B(x,r(x))\\right|} 1_{\\left|x-y\\right| \\leq r(x)}.", block: true)]]

#text("Thus the adjoint is given by")

#align(center)[#tao-fit-display[#tao-math("T_r^* g(y) = \\int_{{\\bf R}^d} \\frac{1}{\\left|B(x,r(x))\\right|} 1_{\\left|x-y\\right| \\leq r(x)} g(x)\\ dx", block: true)]]

#text("and then ")#mi("{TT^*}")#text(" is given by")

#align(center)[#tao-fit-display[#tao-math("\\begin{array}{c} T_r T_r^* g(x^{\\prime}) = \\\\ \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} \\frac{1}{\\left|B(x,r(x))\\right| \\left|B(x^{\\prime},r(x^{\\prime}))\\right|} 1_{\\left|x-y\\right| \\leq r(x)} 1_{\\left|x^{\\prime}-y\\right| \\leq r(x^{\\prime})} g(x)\\ dy dx.\\end{array}", block: true)]]

#text("Note that the ")#mi("{y}")#text(" integral can be computed fairly easily. First we observe that the ")#mi("{y}")#text(" integral vanishes unless ")#tao-math("{\\left|x-x^{\\prime}\\right| \\leq r(x)+r(x^{\\prime})}", block: false)#text(", and in the latter case it enjoys a bound of ")#mi("{O_d(\\min(r(x),r(x^{\\prime}))^d)}")#text(". Also, ")#tao-math("{\\left|B(x,r(x))\\right| \\sim_d r(x)^d}", block: false)#text(" and ")#tao-math("{\\left|B(x^{\\prime},r(x^{\\prime}))\\right| \\sim_d r(x^{\\prime})^d}", block: false)#text(". Putting this together we see that")

#align(center)[#tao-fit-display[#tao-math("\\left| T_r T_r^* g(x^{\\prime}) \\right| \\lesssim_d \\int_{{\\bf R}^d} 1_{\\left|x-x^{\\prime}\\right| \\leq r(x)+r(x^{\\prime})} \\frac{1}{\\max(r(x),r(x^{\\prime}))^d} |g(x)|\\ dx.", block: true)]]

#text("It is natural to split this integral into the regions ")#mi("{r(x) \\leq r(x^{\\prime})}")#text(" and ")#mi("{r(x) \\geq r(x^{\\prime})}")#text(", leading to the bound")

#align(center)[#tao-fit-display[#tao-math("\\begin{array}{c} \\left| T_r T_r^* g(x^{\\prime}) \\right| \\lesssim_d \\int_{{\\bf R}^d} 1_{\\left|x-x^{\\prime}\\right| \\leq 2r(x)} \\frac{1}{r(x)^d} |g(x)|\\ dx \\\\ + \\int_{{\\bf R}^d} 1_{\\left|x-x^{\\prime}\\right| \\leq 2r(x^{\\prime})} \\frac{1}{r(x^{\\prime})^d} |g(x)|\\ dx.\\end{array}", block: true)]]

#text("Comparing this with the formulae for ")#mi("{T_r}")#text(" and ")#mi("{T_{r^{\\prime}}}")#text(", we obtain the interesting pointwise inequality")

#align(center)[#tao-fit-display[#tao-math("\\left| T_r T_r^* g(x^{\\prime}) \\right| \\lesssim_d T_{2r} |g|(x^{\\prime}) + T^*_{2r} |g|(x^{\\prime})", block: true)]]

#text("where ")#mi("{2r}")#text(" is the function ")#mi("{x \\mapsto 2r(x)}")#text(", of course. On the other hand, a scaling argument gives")

#align(center)[#tao-fit-display[#tao-math("\\left\\|T_{2r}\\right\\|_{L^2({\\bf R}^d) \\rightarrow L^2({\\bf R}^d)} \\leq D", block: true)]]

#text("and hence we conclude from the triangle inequality that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T_r T_r^* \\right\\|_{L^2({\\bf R}^d) \\rightarrow L^2({\\bf R}^d)} \\lesssim_d D;", block: true)]]

#text("taking suprema in ")#mi("{r}")#text(" we conclude that ")#mi("{D^2 \\lesssim_d D}")#text(", and hence (since ")#mi("{D}")#text(" is known to be finite) ")#mi("{D \\lesssim_d 1}")#text(", and the claim follows.")

#text("The Hardy-Littlewood maximal function directly bounds averages on balls and cubes, but it also controls several other types of averages as well. For instance, we have the pointwise inequality ")#metadata(none) <tao-251fecd592e56e6c4a95>#mi("\\displaystyle  \\frac{1}{r^d} \\int_{{\\bf R}^d} \\frac{1}{\\langle (x-y)/r \\rangle^{d+\\varepsilon}} |f(y)|\\ dy \\lesssim_{d,\\varepsilon} Mf(x) \\ \\ \\ \\ \\ (14)")#text(" ")#text(" for any locally integrable ")#mi("{f}")#text(", any ")#mi("{x \\in {\\bf R}^d}")#text(", and any ")#mi("{\\varepsilon > 0}")#text("; this can be achieved by dividing the ")#mi("{y}")#text(" integral into dyadic shells ")#tao-math("{2^n r \\leq \\left|x-y\\right| < 2^{n+1} r}", block: false)#text(" for ")#mi("{n \\geq 0}")#text(", as well as the ball ")#tao-math("{\\left|x-y\\right| < r}", block: false)#text(", and we leave the computation to the reader.")

#text("The proof of the Hardy-Littlewood maximal inequality extends to the more general setting of ")#emph[#text("spaces of homogeneous type")]#text(" (which is similar, but different from, the notion of a ")#link("https://en.wikipedia.org/wiki/Homogeneous_space")[#text("homogeneous space")]#text("). These are measure spaces ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" with a metric ")#mi("{d}")#text(", such that the open balls are measurable with positive finite measure, and that one has the doubling property")

#align(center)[#tao-fit-display[#mitex("\\mu(B(x,2r)) \\lesssim \\mu(B(x,r))")]]

#text("for any ")#mi("{x,r}")#text(". Then the Vitali-type covering lemma extends without difficulty to this setting and yields the maximal inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{r > 0} \\frac{1}{\\left|B(x,r)\\right|} \\int_{B(x,r)} |f(y)|\\ d\\mu(y) \\right\\|_{L^{1,\\infty}(X)} \\lesssim \\left\\|f\\right\\|_{L^1(X)}", block: true)]]

#text("and hence")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{r > 0} \\frac{1}{\\left|B(x,r)\\right|} \\int_{B(x,r)} |f(y)|\\ d\\mu(y) \\right\\|_{L^p(X)} \\lesssim_p \\left\\|f\\right\\|_{L^p(X)}", block: true)]]

#text("for any ")#mi("{1 < p \\leq \\infty}")#text(".")

#text("In particular we obtain the discrete inequality ")#metadata(none) <tao-3ffed84716fe61a1bf42>#tao-math("\\displaystyle  \\left\\| \\sup_{N > 0} \\frac{1}{N} \\sum_{n=1}^N f(m+n) \\right\\|_{l^{1,\\infty}_m({\\bf Z})} \\leq \\left\\| f\\right\\|_{l^1({\\bf Z})}; \\ \\ \\ \\ \\ (15)", block: false)#text(" ")#text(" (which we need in our applications to ergodic theory below), while on the torus ")#mi("{{\\bf R}/{\\bf Z}}")#text(" with the usual Lebesgue measure we have ")#metadata(none) <tao-93969d193161ae6fbd17>#tao-math("\\displaystyle  \\left\\| \\sup_{r > 0} \\frac{1}{2r} \\int_{\\left|x-y\\right| \\leq r} |f(y)|\\ dy \\right\\|_{L^p({\\bf R}/{\\bf Z})} \\lesssim_p \\left\\|f\\right\\|_{L^p({\\bf R}/{\\bf Z})} \\ \\ \\ \\ \\ (16)", block: false)#text(" ")#text(" for ")#mi("{1 < p \\leq \\infty}")#text(" (which we will need for our applications to complex analysis).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 21")]#text(" One could try playing with ")#mi("{T^*T}")#text(" instead of ")#mi("{TT^*}")#text(" here, but that turns out to not work very well. The problem is that the linearised maximal operator is only well-behaved in one variable, and the ")#mi("{TT^*}")#text(" method manages to play the two well-behaved variables against each other; going the other way one achieves no obvious cancellation.")
]

#heading(level: 1)[#strong[#text(" — 6. Some consequences of the maximal inequality — ")]]

#text("The Hardy-Littlewood maximal inequality is the underlying quantitative estimate which powers many qualitative pointwise convergence results. A basic example is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 22 (Lebesgue differentiation theorem)")]#text(" Let ")#mi("{f}")#text(" be locally integrable. Then we have the pointwise convergence ")#mi("{\\lim_{r \\rightarrow 0} A_r f(x) = f(x)}")#text(" for almost every ")#mi("{x}")#text(". In fact we have the stronger estimate")

#metadata(none) <tao-618c059cbed8ed18910d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\lim_{r \\rightarrow 0} \\frac{1}{\\left|B(x,r)\\right|} \\int_{B(x,r)} |f(y)-f(x)|\\ dy = 0", block: true)]]

#text("for almost every ")#mi("{x}")#text(".")
]

#text("Before we prove the theorem, let us make some remarks. Firstly, from the identity")

#align(center)[#tao-fit-display[#tao-math("A_r f(x) - f(x) = \\frac{1}{\\left|B(x,r)\\right|} \\int_{B(x,r)} (f(y)-f(x))\\ dy", block: true)]]

#text("and the triangle inequality it is clear that the second estimate implies the first. Secondly, observe that ")#mi("{f}")#text(" is continuous at ")#mi("{x}")#text(" if and only if the worst-case local fluctuation goes to zero")

#align(center)[#tao-fit-display[#tao-math("\\lim_{r \\rightarrow 0} \\sup_{y \\in B(x,r)} \\left|f(y)-f(x)\\right| = 0.", block: true)]]

#text("Thus the differentiation theorem is asserting that locally integrable functions are ")#emph[#text("almost everywhere continuous on the average")]#text(", in that the average-case local fluctuation goes to zero. This is a manifestation of one of Littlewood’s three principles, namely that ")#emph[#text("measurable functions are almost continuous")]#text(". If ")#mi("{x}")#text(" is such that ")#link(<tao-618c059cbed8ed18910d>)[#text("(17)")]#text(" holds, we say that ")#mi("{x}")#text(" is a ")#emph[#text("Lebesgue point")]#text(" of ")#mi("{f}")#text(", thus for locally integrable ")#mi("{f}")#text(", almost every point ")#mi("{x}")#text(" is a Lebesgue point.")

#emph[#text("Proof:")]#text(" It suffices to establish the result for ")#mi("{x}")#text(" constrained to a large ball ")#mi("{B(0,R)}")#text(", where ")#mi("{R > 0}")#text(" is arbitrary. The claim is obvious if ")#mi("{f}")#text(" vanishes on ")#mi("{B(0,2R)}")#text(", so by linearity we may assume that ")#mi("{f}")#text(" is supported on ")#mi("{B(0,2R)}")#text("; in particular ")#mi("{f}")#text(" now lies in ")#mi("{L^1({\\bf R}^d)}")#text(". Thus it suffices to establish the claim when ")#mi("{f \\in L^1({\\bf R}^d)}")#text(".")

#text("By the preceding discussion we already know that the claim is true for the continuous compactly supported functions ")#mi("{C_c({\\bf R}^d)}")#text(", which is a dense subclass of ")#mi("{L^1({\\bf R}^d)}")#text(". To pass from the dense subclass to the full class we use the Hardy-Littlewood maximal inequality now lets us reduce matters to verifying the claim on a dense subset of ")#mi("{L^1({\\bf R}^d)}")#text(". To see this, suppose that we already have proven the claim on a dense class. Then, given any ")#mi("{f \\in L^1({\\bf R}^d)}")#text(" we can write ")#mi("{f}")#text(" as the limit in ")#mi("{L^1}")#text(" of a sequence ")#mi("{f_n}")#text(" in this dense class; by refining these sequence to make the ")#mi("{L^1}")#text(" convergence sufficiently fast (e.g. ")#tao-math("{\\left\\|f_n - f\\right\\|_{L^1({\\bf R}^d)} \\leq 2^{-n}}", block: false)#text(") and using Markov’s inequality and the Borel–Cantelli lemma, we can also ensure that ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" pointwise almost everywhere. Now from the Hardy-Littlewood maximal inequality, we know that ")#tao-math("{\\left\\| \\sup_{r > 0} A_r \\left|f_n - f\\right| \\right\\|_{L^{1,\\infty}({\\bf R}^d)}}", block: false)#text(" converges to zero, thus ")#tao-math("{\\sup_{r > 0} A_r\\left|f_n - f\\right|}", block: false)#text(" converges to zero in measure. By the triangle inequality this implies that ")#tao-math("{\\sup_{r > 0} \\left|A_r f_n - A_r f\\right|}", block: false)#text(" converges in measure also. Thus (again passing to a rapidly converging subsequence as necessary) we see that ")#tao-math("{\\sup_{r > 0} \\left|A_r f_n(x) - A_r f(x)\\right|}", block: false)#text(" converges to zero for almost every ")#mi("{x}")#text(". This uniform-in-")#mi("{r}")#text(" convergence lets one deduce the convergence of ")#mi("{A_r f}")#text(" from the convergence of ")#mi("{A_r f_n}")#text(".")

#text("Finally, by taking a dense class such as the Schwartz class (or even the continuous functions in ")#mi("{L^1({\\bf R}^d)}")#text(") we easily verify the convergence. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 23")]#text(" Because the proof used a density argument, it offers no quantitative rate for the speed of convergence. Indeed the convergence can be arbitrarily slow; this is ultimately due to the implicit hypothesis that ")#mi("{f}")#text(" is measurable, which is itself a qualitative assumption that offers no explicit bounds. More quantitative versions of measurability, e.g. quantifying the extent to which a measurable set can be approximated by elementary sets, can lead to more explicit bounds.")

#text("Consider for instance the function ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" defined by ")#mi("{f(x) = 1}")#text(" when ")#mi("{0 < x < 1}")#text(" and the integer part of ")#mi("{Nx}")#text(" is even, and ")#mi("{f(x) = 0}")#text(" otherwise, where ")#mi("{N}")#text(" is a large integer. Then we see that for ")#mi("{0 < x < 1}")#text(", ")#mi("{A_r(x)}")#text(" will stay close to ")#mi("{1/2}")#text(" for quite a while (basically for all ")#mi("{r \\gg 1/N}")#text("), and only at scales ")#mi("{1/N}")#text(" or less will it begin to “decide” to converge to either ")#mi("{0}")#text(" or ")#mi("{1}")#text(". Modifying this type of example (e.g. by a “Weierstrass example” formed by summing together a geometrically decaying series of such oscillating functions, with ")#mi("{N}")#text(" going to infinity), one can concoct functions whose convergence of ")#mi("{A_r f}")#text(" to ")#mi("{f}")#text(" is arbitrarily slow. (One can obtain quantitative rates by enforcing regularity conditions on the function, which essentially compactifies the space of functions that one is working with; we will see some examples of this later.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Let ")#mi("{f}")#text(" be a locally integrable function on ")#mi("{{\\bf R}^d}")#text(". Call a point ")#mi("{x \\in {\\bf R}^d}")#text(" a ")#emph[#text("Lebesgue point")]#text(" if there exists a number ")#mi("{c}")#text(" such that ")#tao-math("{\\lim_{r \\rightarrow 0} \\frac{1}{\\left|B(x,r)\\right|} \\int_{B(x,r)} |f(y) - c|\\ dy = 0}", block: false)#text(". Show that almost every point is a Lebesgue point, and that ")#mi("{c}")#text(" is equal to ")#mi("{f(x)}")#text(" almost everywhere.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25 (Heat kernels)")]#text(" For any ")#mi("{t > 0}")#text(" and any ")#mi("{f \\in L^p({\\bf R}^d)}")#text(" for some ")#mi("{1 \\leq p \\leq \\infty}")#text(", define the ")#emph[#text("heat kernel")]#text(" ")#mi("{e^{t\\Delta} f}")#text(" by")

#align(center)[#tao-fit-display[#tao-math("e^{t\\Delta} f(x) := \\frac{1}{(4\\pi t)^{d/2}} \\int_{{\\bf R}^d} e^{-\\left|x-y\\right|^2/4t} f(y)\\ dy.", block: true)]]

#text("Show that if ")#mi("{1 \\leq p < \\infty}")#text(" and ")#mi("{f \\in L^p({\\bf R}^d)}")#text(", then ")#mi("{e^{t\\Delta} f}")#text(" converges both pointwise and in norm to ")#mi("{f}")#text(" as ")#mi("{t \\rightarrow 0}")#text(".")
]

#text("Now let us explore applications to ergodic theory. In particular we wish to investigate limits of the form")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N T^n f")]]

#text("for various functions ")#mi("{f}")#text(" and various “shift operators” ")#mi("{T}")#text(".")

#text("Let us first look at an abstract setting, in which ")#mi("{T}")#text(" is a unitary operator on a Hilbert space.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 26 (Von Neumann ergodic theorem)")]#text(" Let ")#mi("{T: H \\rightarrow H}")#text(" be a unitary operator on a Hilbert space. Then for any ")#mi("{f \\in H}")#text(", the limit ")#mi("{\\lim_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N T^n f}")#text(" exists in the strong ")#mi("{H}")#text(" topology.")
]

#emph[#text("Proof:")]#text(" Let us first argue formally. We have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_{n=1}^N T^n f = \\frac{T + \\ldots + T^N}{N} f.")]]

#text("Formally, we have the geometric series formula")

#align(center)[#tao-fit-display[#mitex("\\frac{T + \\ldots + T^N}{N} f = \\frac{T^{N+1}-T}{N(T-1)} f")]]

#text("which looks like it converges to zero, unless ")#mi("{T-1}")#text(" fails to be invertible; but on the other hand when ")#mi("{T=1}")#text(" ")#mi("{\\frac{T + \\ldots + T^N}{N}}")#text(" is just ")#mi("{1}")#text(", which of course converges to the identity. So we seem to have covered two extreme cases.")

#text("Now let us make the above argument rigorous. If ")#mi("{f}")#text(" is ")#mi("{T}")#text("-invariant, thus ")#mi("{Tf = f}")#text(", then ")#mi("{T^n f = f}")#text(" and it is clear that ")#mi("{\\lim_{n \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N T^n f}")#text(" converges to ")#mi("{f}")#text(". If on the other hand ")#mi("{f}")#text(" is a ")#mi("{T}")#text("-difference, ")#mi("{f = Tg - g}")#text(" for some ")#mi("{g \\in H}")#text(", then we verify the telescoping identity ")#mi("{\\sum_{n=1}^N T^n f = T^{N+1} g - T g}")#text(". Since unitary operators preserve the norm, we thus see from the triangle inequality that ")#mi("{\\lim_{n \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N T^n f}")#text(" converges to zero. Also, since the averaging operators ")#mi("{\\frac{1}{N} \\sum_{n=1}^N T^n}")#text(" are uniformly bounded in ")#mi("{H}")#text(" (by the triangle inequality), we see that any strong limit of ")#mi("{T}")#text("-differences also has the property that ")#mi("{\\lim_{n \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N T^n f}")#text(" exists and equals zero.")

#text("To summarise so far, we have two closed subspaces of ")#mi("{H}")#text(" for which we know convergence. The first is ")#mi("{H^T := \\{ f \\in H: Tf = f\\}}")#text(", the invariant space of ")#mi("{T}")#text("; here the limit converges to the identity. The other is ")#mi("{\\overline{\\{ Tg-g: g \\in H \\}}}")#text(", the closure of the ")#mi("{T}")#text("-differences; here the limit conveges to zero. These two spaces turn out to be orthogonal complements. To see this, first observe that they are orthogonal: if ")#mi("{Tf = f}")#text(", then ")#mi("{\\langle f, Tg \\rangle = \\langle Tf, Tg \\rangle = \\langle f, g \\rangle}")#text(" by unitarity, and hence ")#mi("{f}")#text(" is orthogonal to every ")#mi("{T}")#text("-difference ")#mi("{Tg-g}")#text(" and hence by continuity of inner product is orthogonal to ")#mi("{\\overline{\\{ Tg-g: g \\in H \\}}}")#text(". To show orthogonal complement, it then suffices to show that any vector ")#mi("{f}")#text(" orthogonal to ")#mi("{\\overline{\\{ Tg-g: g \\in H \\}}}")#text(" is invariant. But then ")#mi("{f}")#text(" is orthogonal to ")#mi("{Tf-f}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\langle f, Tf - f \\rangle = 0.")]]

#text("We rewrite the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\langle f, Tf \\rangle - \\langle f, f \\rangle = \\langle f, Tf \\rangle - \\langle Tf, Tf \\rangle = - \\langle Tf - f, Tf \\rangle")]]

#text("and on conjugating and subtracting we conclude that")

#align(center)[#tao-fit-display[#mitex("\\langle Tf - f, Tf - f \\rangle = 0")]]

#text("and thus ")#mi("{Tf=f}")#text(" as claimed. ")#mi("\\Box")

#text("Note that the above argument in fact shows the stronger claim that ")#mi("{\\lim_{n \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N T^n f}")#text(" converges to the orthogonal projection of ")#mi("{f}")#text(" to ")#mi("{H^T}")#text(".")

#text("Now we move to a more specialised setting, that of a measure-preserving system.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 27 (Measure-preserving system)")]#text(" A ")#emph[#text("measure-preserving system")]#text(" ")#mi("{(X,{\\mathcal B}, \\mu, T)}")#text(" is a probability space ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" (thus ")#mi("{\\mu(X)=1}")#text(") together with a bi-measurable bijection ")#mi("{T: X \\rightarrow X}")#text(" (thus ")#mi("{T}")#text(" and ")#mi("{T^{-1}}")#text(" are both measurable) such that ")#mi("{T}")#text(" is measure-preserving, thus ")#mi("{\\mu(T(E)) = \\mu(E)}")#text(" for all ")#mi("{E \\in {\\mathcal B}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 28 (Circle shift)")]#text(" Let ")#mi("{X = {\\bf R}/{\\bf Z}}")#text(" be the standard circle with the usual Borel ")#mi("{\\sigma}")#text("-algebra and Lebesgue measure, and let ")#mi("{Tx := x + \\alpha}")#text(" for some ")#mi("{\\alpha \\in {\\bf R}}")#text(", which may be either rational or irrational.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 29")]#text(" Many of the results here hold under more relaxed assumptions on ")#mi("{T}")#text(", but we will not attempt to optimise the hypotheses here.")
]

#text("The shift ")#mi("{T}")#text(" on the base space ")#mi("{X}")#text(", ")#mi("{x \\mapsto T(x)}")#text(", induces a shift on sets ")#mi("{E \\in {\\mathcal B}}")#text(", ")#mi("{E \\mapsto T(E)}")#text(", and then also induces a map on measurable functions ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" by ")#mi("{Tf := f \\circ T^{-1}}")#text(". The use of ")#mi("{T^{-1}}")#text(" is natural since it ensures that ")#mi("{T 1_E = 1_{TE}}")#text(" and ")#mi("{Tf(Tx) = f(x)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 30 (Mean ergodic theorem)")]#text(" Let ")#mi("{(X,{\\mathcal B},\\mu,T)}")#text(" be a measure-preserving system, and let ")#mi("{f \\in L^p(X)}")#text(" for some ")#mi("{1 \\leq p < \\infty}")#text(". Then the sequence ")#mi("{\\frac{1}{N} \\sum_{n=1}^N T^n f}")#text(" converges strongly in ")#mi("{L^p(X)}")#text(".")
]

#emph[#text("Proof:")]#text(" The operator ")#mi("{T}")#text(" is an isometry on ")#mi("{L^p}")#text(", and so by the triangle inequality the averaging operators ")#mi("{\\frac{1}{N} \\sum_{n=1}^N T^n}")#text(" are uniformly bounded in ")#mi("{L^p}")#text(". Thus it suffices to prove the claim for a dense subclass of ")#mi("{L^p}")#text("; we shall pick ")#mi("{L^\\infty(X)}")#text(". In this class, which is embedded into the Hilbert space ")#mi("{L^2(X)}")#text(", we already know from the von Neumann ergodic theorem (and the fact that ")#mi("{T}")#text(" is a unitary operator on ")#mi("{L^2(X)}")#text(") that the averages are convergent in ")#mi("{L^2(X)}")#text(" norm. But they are also uniformly bounded in ")#mi("{L^\\infty(X)}")#text(". So the claim follows from the log-convexity of ")#mi("{L^p}")#text(" norms (for ")#mi("{p \\geq 2}")#text(") or by Hölder’s inequality and the finite measure of ")#mi("{X}")#text(" (for ")#mi("{p < 2}")#text("). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" Show by example that the mean ergodic theorem fails for ")#mi("{p < 1}")#text(" and for ")#mi("{p=\\infty}")#text(".")
]

#text("Now we study the pointwise convergence problem. The key quantitative estimate needed is the following analogue of the Hardy-Littlewood maximal inequality.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 32 (Hardy-Littlewood maximal inequality for measure-preserving systems)")]#text(" Let ")#mi("{(X,{\\mathcal B},\\mu,T)}")#text(" be a measure-preserving system. Then we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{N > 0} \\frac{1}{N} \\sum_{n=1}^N T^n f \\right\\|_{L^{1,\\infty}(X)} \\lesssim \\left\\|f\\right\\|_{L^1(X)}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{N > 0} \\frac{1}{N} \\sum_{n=1}^N T^n f \\right\\|_{L^p(X)} \\lesssim_p \\left\\|f\\right\\|_{L^p(X)}", block: true)]]

#text("for all ")#mi("{1 < p \\leq \\infty}")#text(".")
]

#emph[#text("Proof:")]#text(" The claim is trivial when ")#mi("{p=\\infty}")#text(", so once again the task is to prove the pointwise estimate. By monotone convergence it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{1 \\leq N < N_0} \\frac{1}{N} \\sum_{n=1}^N T^n f \\right\\|_{L^{1,\\infty}(X)} \\lesssim \\left\\|f\\right\\|_{L^1(X)}", block: true)]]

#text("uniformly in ")#mi("{N_0 > 1}")#text(".")

#text("The idea is to lift up to a space where ")#mi("{T}")#text(" can be modeled by the integer shift ")#mi("{n \\mapsto n+1}")#text(", at which point we can apply ")#link(<tao-3ffed84716fe61a1bf42>)[#text("(15)")]#text(". Fix ")#mi("{N_0}")#text(", and let ")#mi("{[2N_0]}")#text(" be the finite set ")#mi("{[2N_0] := \\{0,\\ldots,2N_0-1\\}}")#text(", endowed with the discrete ")#mi("{\\sigma}")#text("-algebra and uniform measure, so that ")#mi("{X \\times [2N_0]}")#text(" is a probability space. Inside this space we have ")#mi("{X \\times [N_0]}")#text(", where ")#mi("{[N_0] := \\{0,\\ldots,N_0-1\\}}")#text(". We define the function ")#mi("{F: X \\times [2N_0] \\rightarrow {\\bf C}}")#text(" by")

#align(center)[#tao-fit-display[#mitex("F(x,n) := T^n f(x).")]]

#text("From ")#link(<tao-3ffed84716fe61a1bf42>)[#text("(15)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{1 \\leq N < N_0} \\frac{1}{N} \\sum_{n=1}^N F(x,n+m) \\right\\|_{l^{1,\\infty}_m([N_0])} \\lesssim \\left\\| F(x,m) \\right\\|_{l^1_m([2N_0])}", block: true)]]

#text("for all ")#mi("{x \\in X}")#text("; writing out what the ")#mi("{l^{1,\\infty}}")#text(" norm means, and integrating in ")#mi("{X}")#text(" using Fubini’s theorem, we conclude")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{1 \\leq N < N_0} \\frac{1}{N} \\sum_{n=1}^N F(x,n+m) \\right\\|_{L^{1,\\infty}_{x,m}(X \\times [N_0])} \\lesssim \\left\\| F \\right\\|_{L^1(X \\times [2N_0])}.", block: true)]]

#text("The right-hand side is just ")#tao-math("{\\left\\|f\\right\\|_{L^1(X)}}", block: false)#text(". As for the left-hand side, observe that")

#align(center)[#tao-fit-display[#mitex("\\sup_{1 \\leq N < N_0} \\frac{1}{N} \\sum_{n=1}^N F(x,n+m) = \\sup_{1 \\leq N < N_0} \\frac{1}{N} \\sum_{n=1}^N T^n f( T^{-m} x )")]]

#text("and so on writing out the ")#mi("{L^{1,\\infty}}")#text(" norm we see that the left-hand side is comparable to")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{1 \\leq N < N_0} \\frac{1}{N} \\sum_{n=1}^N T^n f(x) \\right\\|_{L^{1,\\infty}(X)}", block: true)]]

#text("and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 33")]#text(" Note how a maximal inequality for the integers was “transferred” to a maximal inequality on arbitrary measure preserving systems. There are several abstract ")#emph[#text("transference principles")]#text(" which generalise this type of phenomenon. In particular, the above argument is in fact a special case of the ")#emph[#text("Calderón transference principle")]#text(".")
]

#text("Now we can present the analogue of the Lebesgue differentiation theorem for measure-preserving systems.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 34 (Pointwise ergodic theorem)")]#text(" Let ")#mi("{(X,{\\mathcal B},\\mu,T)}")#text(" be a measure-preserving system, and let ")#mi("{f \\in L^1(X)}")#text(". Then the sequence ")#mi("{\\frac{1}{N} \\sum_{n=1}^N T^n f}")#text(" converges pointwise almost everywhere.")
]

#emph[#text("Proof:")]#text(" By repeating the argument in the Lebesgue differentiation theorem more or less verbatim (using the above maximal inequality in place of the Hardy-Littlewood inequality) it suffices to verify the claim for a dense subclass of ")#mi("{L^1(X)}")#text(", such as ")#mi("{L^2(X)}")#text(". Since the ")#mi("{L^2(X)}")#text(" norm controls the ")#mi("{L^1}")#text(" norm, it suffices to do so for a dense subclass of ")#mi("{L^2(X)}")#text(".")

#text("Now we repeat the proof of the von Neumann ergodic theorem. For the invariant part ")#mi("{L^2(X)^T}")#text(" of ")#mi("{L^2(X)}")#text(", the pointwise convergence is obvious. Also, for functions of the form ")#mi("{Tg-g}")#text(" with ")#mi("{g \\in L^\\infty(X)}")#text(", the convergence is also obvious. But these functions are clearly dense in ")#mi("{\\{ Tg-g: g \\in L^2(X) \\}}")#text(" and hence in ")#mi("{\\overline{\\{ Tg-g: g \\in L^2(X) \\}}}")#text(". Since this space and ")#mi("{L^2(X)^T}")#text(" are orthogonal complements of ")#mi("{L^2(X)}")#text(", we thus have demonstrated convergence of a dense subclass of ")#mi("{L^2(X)}")#text(" and thus of ")#mi("{L^1(X)}")#text(", as desired. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 35")]#text(" Notice how the strategy of establishing convergence splits into two independent parts — obtaining convergence on a dense subclass, and then establishing some harmonic analysis estimate to pass to the general case. This is not the only way to achieve convergence results. Later on we shall see a variation-norm approach which relies purely on harmonic analysis estimates to obtain convergence (foregoing the dense subclass). In the opposite direction, there are more dynamical approaches (which we do not cover here) which forego the harmonic analysis component of the argument, relying instead on analysing the dynamics of the measure-preserving system by other means (such as measure-theoretic or topological means). It is not fully understood to what extent these different techniques complement each other.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36")]#text(" Let ")#mi("{(X,{\\mathcal B},\\mu,T)}")#text(" be a measure-preserving system. Let ")#mi("{{\\mathcal B}^T = \\{ E \\in {\\mathcal B}: T(E) = E \\}}")#text(" be the elements of ")#mi("{{\\mathcal B}}")#text(" which are ")#mi("{T}")#text("-invariant (up to sets of measure zero, of course). Show that for any ")#mi("{f \\in L^p({\\mathcal B})}")#text(" and ")#mi("{1 \\leq p < \\infty}")#text(", the averages ")#mi("{\\frac{1}{N} \\sum_{n=1}^N T^n f}")#text(" converge in ")#mi("{L^p}")#text(" norm and pointwise almost everywhere to ")#mi("{\\mathop{\\bf E}(f|{\\mathcal B}^T)}")#text(". In particular, when ")#mi("{X}")#text(" is ")#emph[#text("ergodic")]#text(" (thus the only invariant sets have zero measure or full measure), conclude that ")#mi("{\\frac{1}{N} \\sum_{n=1}^N T^n f}")#text(" converges pointwise and in ")#mi("{L^p}")#text(" norm to ")#mi("{\\int_X f\\ d\\mu}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37 (Poincare recurrence theorem)")]#text(" Let ")#mi("{(X,{\\mathcal B},\\mu,T)}")#text(" be a measure-preserving system, and let ")#mi("{f \\geq 0}")#text(" be non-negative with ")#mi("{\\int_X f\\ d\\mu > 0}")#text(". Show that ")#mi("{\\int_X f T^n f\\ d\\mu > 0}")#text(" for infinitely many ")#mi("{n \\geq 1}")#text(".")
]

#text("By combining the Lebesgue differentiation theorem with the Radon-Nikodym theorem, one easily obtains")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 38 (One-dimensional Radamacher differentiation theorem)")]#text(" ")#metadata(none) <tao-3c3101c3d5d9d674cbcb>#text(" If ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" is Lipschitz, then it is differentiable almost everywhere, its derivative lies in ")#mi("{L^\\infty({\\bf R})}")#text(", and we have the fundamental theorem of calculus ")#mi("{f(y) - f(x) = \\int_x^y f^{\\prime}(z)\\ dz}")#text(" for all ")#mi("{x, y \\in {\\bf R}}")#text(".")
]

#emph[#text("Proof:")]#text(" We may reduce to the case when ")#mi("{f}")#text(" is real. The Riemann-Stieltjes measure ")#mi("{df}")#text(" is easily seen to be absolutely continuous with respect to Lebesgue measure, and is thus of the form ")#mi("{df = g dx}")#text(" for some locally integrable ")#mi("{g}")#text(", thus ")#mi("{f(y) -f(x) = \\int_x^y g(z)\\ dz}")#text(" by the Radon-Nikodym theorem. The Lebesgue differentiation theorem then shows that ")#mi("{f^{\\prime}}")#text(" exists and is equal to ")#mi("{g}")#text(" at every Lebesgue point of ")#mi("{g}")#text(" (see Q7), and the claim follows. (The boundedness of ")#mi("{g = f^{\\prime}}")#text(" is clear from the Lipschitz nature of ")#mi("{f}")#text(".) ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 39")]#text(" There are other ways to prove this theorem that do not require Radon-Nikodym differentiation, which we shall encounter later.")
]

#text("This one-dimensional theorem implies a multi-dimensional analogue:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 40 (Radamacher differentiation theorem)")]#text(" If ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is Lipschitz, then ")#mi("{f}")#text(" is differentiable almost everywhere, thus for almost every ")#mi("{x}")#text(" there exists a vector ")#mi("{\\nabla f(x)}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\lim_{h \\rightarrow 0} \\frac{ \\left|f(x+h) - f(x) - \\nabla f(x) \\cdot h\\right|}{\\left|h\\right|} = 0.", block: true)]]
]

#emph[#text("Proof:")]#text(" For simplicity of notation we take ")#mi("{d=2}")#text(", although the general case is similar. Theorem ")#link(<tao-3c3101c3d5d9d674cbcb>)[#text("38")]#text(" (and Fubini’s theorem) shows that the partial derivatives ")#mi("{\\frac{\\partial f}{\\partial x_1}}")#text(", ")#mi("{\\frac{\\partial f}{\\partial x_2}}")#text(" exist almost everywhere and are bounded. This gives us a candidate gradient ")#mi("{\\nabla f}")#text(" defined almost everywhere. The remaining challenge is to show total differentiability. In other words, for any ")#mi("{\\varepsilon > 0}")#text(", we need to show that for almost every ")#mi("{x}")#text(", we have ")#metadata(none) <tao-25a42bd20e49a4172cd2>#tao-math("\\displaystyle  f(x+h) - f(x) = \\nabla f(x) \\cdot h + O( \\varepsilon \\left|h\\right| ) \\ \\ \\ \\ \\ (18)", block: false)#text(" ")#text(" whenever ")#tao-math("{\\left|h\\right|}", block: false)#text(" is sufficiently small depending on ")#mi("{x}")#text(". Note that the control of the partial derivatives only achieve this when ")#mi("{h}")#text(" is a multiple of ")#mi("{e_1}")#text(" or ")#mi("{e_2}")#text(".")

#text("Fix ")#mi("{\\varepsilon > 0}")#text(". We will need to make things slightly more quantitative. For any ")#mi("{n \\geq 1}")#text(" and ")#mi("{i=1,2}")#text(", let ")#mi("{X_{i,n}}")#text(" denote the set")

#tao-aligned(keep: true)[


#tao-math("X_{i,n}  & := \\{ x \\in {\\bf R}^2: \\left|f(x + h_i e_i) - f(x) - \\frac{\\partial f}{\\partial x_i}(x) h_i\\right| \\leq \\varepsilon \\left|h_i\\right|", block: true)



#tao-math("\\text{ whenever } \\left|h_i\\right|  & \\leq \\frac{1}{n} \\}.", block: true)
]

#text("Then the almost everywhere existence of ")#mi("{\\frac{\\partial f}{\\partial x_i}}")#text(" implies that the ")#mi("{X_{i,n}}")#text(" are measurable and increase to ")#mi("{{\\bf R}^2}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(" (neglecting sets of measure zero). In particular, almost every point lies in infinitely many of the ")#mi("{X_{i,n}}")#text(". Because of this, we know that almost every point is a horizontal and vertical Lebesgue point of ")#mi("{\\frac{\\partial f}{\\partial x_i}}")#text(" and of ")#mi("{1_{X_{i,n}}}")#text(" for infinitely many ")#mi("{n}")#text(". (We say that ")#mi("{(x,y)}")#text(" is a horizontal Lebesgue point of ")#mi("{F}")#text(" if ")#mi("{\\frac{1}{2r} \\int_{-r}^r |F(x+t,y) - F(x,y)|\\ dt \\rightarrow 0}")#text(" as ")#mi("{r \\rightarrow 0}")#text(", and similarly define a vertical Lebesgue point of ")#mi("{F}")#text(".) In particular, for almost every point there is an ")#mi("{n}")#text(" such that one lies in ")#mi("{X_{i,n}}")#text(", and is a horizontal and vertical Lebesgue point of ")#mi("{\\frac{\\partial f}{\\partial x_i}}")#text(" and of ")#mi("{1_{X_{i,n}}}")#text(" for ")#mi("{i=1,2}")#text(". From this it is not hard to show ")#link(<tao-25a42bd20e49a4172cd2>)[#text("(18)")]#text(" for a large density set of ")#mi("{h}")#text(" near ")#mi("{x}")#text(" (say of density ")#mi("{1 - \\varepsilon^2}")#text("), basically by decomposing")

#align(center)[#tao-fit-display[#mitex("f(x+h_1e_1+h_2e_2) - f(x) = [f(x+h_1e_1) - f(x)] + [f(x+h_1e_1+h_2e_2) - f(x+h_1 e_1)]")]]

#text("and using the Lebesgue point properties to ensure that ")#mi("{\\frac{\\partial f}{\\partial x_2}(x+h_1e_1)}")#text(" is usually close to ")#mi("{\\frac{\\partial f}{\\partial x_2}(x)}")#text("; we omit the details. The remaining exceptional values of ")#mi("{h}")#text(" can then be dealt with by locating a nearby non-exceptional value of ")#mi("{h}")#text(" and using the Lipschitz property. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 41 (Fundamental theorem of calculus)")]#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" be locally integrable, and let ")#mi("{F(x) := \\int_0^x f(y)\\ dy}")#text(" (with the usual convention that ")#mi("{\\int_0^{-x} = -\\int_{-x}^0}")#text("). Show that ")#mi("{F}")#text(" is differentiable at every Lebesgue point of ")#mi("{f}")#text(", and that ")#mi("{F^{\\prime} = f}")#text(" almost everywhere.")
]

#heading(level: 1)[#strong[#text(" — 7. ")#mi("{H^p}")#text(" functions — ")]]

#text("Another classical application of the Hardy-Littlewood maximal function lies in obtaining a satisfactory theory of (complex) ")#mi("{H^p}")#text(" functions on the complex disk ")#tao-math("{{\\mathbb D} := \\{ z: \\left|z\\right| < 1 \\}}", block: false)#text(" for ")#mi("{1 < p \\leq \\infty}")#text(". (The theory for ")#mi("{p \\leq 1}")#text(" is more subtle and will not be dealt with here.)")

#text("Let ")#mi("{f: {\\mathbb D} \\rightarrow {\\bf C}}")#text(" be a holomorphic function. From residue calculus we have")

#align(center)[#tao-fit-display[#tao-math("2f(z)-f(0) = \\frac{1}{2\\pi i} \\int_{\\left|\\zeta\\right|=r} \\frac{f(\\zeta)(\\zeta+z)}{\\zeta(\\zeta - z)} d\\zeta", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("f(0) = \\frac{1}{2\\pi i} \\int_{\\left|\\zeta\\right|=r} \\frac{f(\\zeta)(r^2/\\zeta+\\bar{z})}{\\zeta(r^2/\\zeta - \\bar{z})} d\\zeta", block: true)]]

#text("when ")#tao-math("{\\left|z\\right| < r}", block: false)#text(", and so on averaging, and noting that ")#mi("{\\frac{r^2/\\zeta+\\bar{z}}{r^2/\\zeta - \\bar{z}}}")#text(" is the complex conjugate of ")#mi("{\\frac{\\zeta+z}{\\zeta-z}}")#text(" when ")#tao-math("{\\left|\\zeta\\right|=r}", block: false)#text(", we obtain")

#align(center)[#tao-fit-display[#tao-math("f(z) = \\int_{\\left|\\zeta\\right|=r} f(\\zeta) \\mathrm{Re}( \\frac{\\zeta+z}{\\zeta-z} ) \\frac{d\\zeta}{2\\pi i \\zeta}", block: true)]]

#text("or in other words, if we set ")#mi("{f_r: {\\bf R}/{\\bf Z} \\rightarrow {\\bf C}}")#text(" to be the function ")#mi("{f_r(\\theta) := f(re^{2\\pi i \\theta})}")#text(", we have the ")#emph[#text("reproducing formula")]

#align(center)[#tao-fit-display[#mitex("f_s = f_r * K_{s/r}")]]

#text("whenever ")#mi("{0 \\leq s < r < 1}")#text(" and ")#mi("{K_{t}}")#text(" is the ")#emph[#text("Poisson kernel")]

#align(center)[#tao-fit-display[#mitex("K_t(\\beta) = \\mathrm{Re}( \\frac{e^{2\\pi i \\beta} + t}{e^{2\\pi i \\beta} - t} ) = \\frac{1-t^2}{1+t^2 - 2t \\cos 2\\pi \\beta}.")]]

#text("The kernel ")#mi("{K_t}")#text(" is clearly non-negative; applying the above identity to ")#mi("{f \\equiv 1}")#text(" (or computing directly) we see also that ")#mi("{K_t}")#text(" has mass ")#mi("{1}")#text(":")

#align(center)[#tao-fit-display[#tao-math("\\left\\|K_t\\right\\|_{L^1({\\bf R}/{\\bf Z})} = \\int_{{\\bf R}/{\\bf Z}} K_t\\ d\\theta = 1.", block: true)]]

#text("From Young’s inequality we thus obtain that for ")#mi("{1 \\leq p \\leq \\infty}")#text(", the ")#mi("{L^p}")#text(" norm of ")#mi("{f}")#text(" is increasing on circles:")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f_s\\right\\|_{L^p({\\bf R}/{\\bf Z})} \\leq \\left\\| f_t\\right\\|_{L^p({\\bf R}/{\\bf Z})}.", block: true)]]

#text("(Note that the ")#mi("{p=\\infty}")#text(" case is just the maximum principle.) In particular, the quantity")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{H^p({\\mathbb D})} := \\lim_{t \\rightarrow 1^-} \\left\\| f_t\\right\\|_{L^p_\\theta({\\bf R}/{\\bf Z})}", block: true)]]

#text("always exists. We say that ")#mi("{f}")#text(" is an ")#emph[#mi("{H^p}")#text(" function")]#text(" if ")#mi("{f}")#text(" is analytic on ")#mi("{{\\mathbb D}}")#text(" and the norm ")#tao-math("{\\left\\|f\\right\\|_{H^p({\\mathbb D})}}", block: false)#text(" is finite. It is not hard to see that ")#mi("{H^p({\\mathbb D})}")#text(" becomes a normed vector space (and that ")#mi("{H^p({\\mathbb D}) \\supset H^q({\\mathbb D})}")#text(" whenever ")#mi("{p < q}")#text("); a little more work shows that it is in fact complete.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42")]#text(" For any ")#mi("{n \\in {\\bf Z}}")#text(" and ")#mi("{g \\in L^1({\\bf R}/{\\bf Z})}")#text(", define the ")#emph[#text("Fourier coefficient")]#text(" ")#mi("{\\hat g(n)}")#text(" of ")#mi("{g}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\hat g(n) := \\int_{{\\bf R}/{\\bf Z}} g(\\theta) e^{-2\\pi i n \\theta}\\ d\\theta.")]]

#text("Show that")

#align(center)[#tao-fit-display[#tao-math("\\hat K_t(n) = t^{\\left|n\\right|}", block: true)]]

#text("for every ")#mi("{0 \\leq t < 1}")#text(" and ")#mi("{n \\in {\\bf Z}}")#text(", and that")

#align(center)[#tao-fit-display[#tao-math("\\hat f_s(n) = (s/r)^{\\left|n\\right|} \\hat f_r(n)", block: true)]]

#text("for every ")#mi("{f}")#text(" holomorphic on ")#mi("{{\\mathbb D}}")#text(", ")#mi("{0 \\leq s < r < 1}")#text(" and ")#mi("{n \\in {\\bf Z}}")#text(". Also show that ")#mi("{\\hat f_r(n) = 0}")#text(" for all ")#mi("{n < 0}")#text(", and that")

#align(center)[#tao-fit-display[#mitex("K_t * K_{t^{\\prime}} = K_{tt^{\\prime}}")]]

#text("for all ")#mi("{0 \\leq t,t^{\\prime} \\leq 1}")#text(". (Note that these identities can be proven either by complex analysis methods or by Fourier analysis methods; it is instructive to prove them both ways and compare results.)")
]

#text("The kernel ")#mi("{K_t}")#text(" can be easily verified to obey the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|K_t(\\theta)\\right| \\lesssim \\frac{1/(1-t)}{\\langle \\mathrm{dist}(0,\\theta)/(1-t) \\rangle^2}.", block: true)]]

#text("This is enough to obtain the pointwise estimate")

#align(center)[#tao-fit-display[#tao-math("\\left|f * K_t\\right| \\lesssim Mf", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("Mf(\\theta) := \\sup_{r > 0} \\frac{1}{2r} \\int_{\\mathrm{dist}(\\alpha,\\theta) < r} |f(\\alpha)|\\ d\\alpha")]]

#text("is the Hardy-Littlewood maximal function of ")#mi("{f}")#text(". From last week’s notes we conclude that for any ")#mi("{1 \\leq p \\leq \\infty}")#text(" and ")#mi("{f \\in L^p({\\bf R}/{\\bf Z})}")#text(", that ")#mi("{f*K_t}")#text(" converges to ")#mi("{f}")#text(" in ")#mi("{L^p({\\bf R}/{\\bf Z})}")#text(" norm, and by modifying the proof of the Lebesgue differentiation theorem we also see that it converges pointwise almost everywhere.")

#text("The definition of ")#mi("{H^p}")#text(" strongly suggests (but does not immediately prove) that if ")#mi("{f}")#text(" lies in ")#mi("{H^p}")#text(", then ")#mi("{f_t}")#text(" should converge to some sort of limit ")#mi("{f_1}")#text(" as ")#mi("{t \\rightarrow 1^-}")#text(". This is indeed the case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 43")]#text(" ")#metadata(none) <tao-1caf527f6d2a83b0fa25>#text(" Let ")#mi("{f \\in H^p({\\mathbb D})}")#text(" for ")#mi("{1 < p < \\infty}")#text(". Then ")#mi("{f_t}")#text(" converges both in ")#mi("{L^p({\\bf R}/{\\bf Z})}")#text(" norm and pointwise almost everywhere to a limit ")#mi("{f_1 \\in L^p({\\bf R}/{\\bf Z})}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 44")]#text(" The theorem fails for ")#mi("{p\\leq 1}")#text(", as can be seen by explicitly computing using the function ")#mi("{f(z) := \\frac{1+z}{1-z}}")#text(". When ")#mi("{p=\\infty}")#text(", the pointwise almost everywhere claim is still true, but the convergence is not.")
]

#emph[#text("Proof:")]#text(" Let us first demonstrate weak convergence. For any ")#mi("{g \\in L^{p^{\\prime}}({\\bf R}/{\\bf Z})}")#text(" and ")#mi("{0 < t < 1}")#text(", we observe that ")#metadata(none) <tao-7653097b0a56851e687b>#mi("\\displaystyle  \\langle f_r, g * K_t \\rangle = \\langle f_r * K_t, g \\rangle = \\langle f_{rt}, g \\rangle = \\langle f_t * K_r, g \\rangle \\ \\ \\ \\ \\ (19)")#text(" ")#text(" where ")#mi("{\\langle f, g\\rangle := \\int_{{\\bf R}/{\\bf Z}} f(\\theta) \\overline{g(\\theta)}\\ d\\theta}")#text(" is the inner product on ")#mi("{{\\bf R}/{\\bf Z}}")#text(" (here we use the fact that ")#mi("{K_t}")#text(" is real and even). Since ")#mi("{f_t * K_r}")#text(" converges in ")#mi("{L^p}")#text(" norm to ")#mi("{f_t}")#text(" as ")#mi("{r \\rightarrow 1}")#text(", we thus see that ")#mi("{\\langle f_r, g * K_t \\rangle}")#text(" converges to a limit as ")#mi("{r \\rightarrow 1}")#text(". Since ")#mi("{g * K_t}")#text(" converges in ")#mi("{L^{p^{\\prime}}}")#text(" norm to ")#mi("{g}")#text(" as ")#mi("{t \\rightarrow 1}")#text(", we conclude (from Hölder’s inequality and the uniform ")#mi("{L^p}")#text(" bound on ")#mi("{f_r}")#text(") that ")#mi("{\\langle f_r, g \\rangle}")#text(" also converges to a limit as ")#mi("{r \\rightarrow 1}")#text(", thus ")#mi("{f_r}")#text(" converges weakly. But as ")#mi("{L^p}")#text(" is reflexive, the closed unit ball is also weakly closed, and we conclude that ")#mi("{f_r}")#text(" converges weakly to ")#mi("{f_1}")#text(" for some ")#mi("{f_1 \\in L^p({\\bf R}/{\\bf Z})}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\lim_{r \\rightarrow 1} \\langle f_r, g \\rangle = \\langle f_1, g \\rangle")]]

#text("for all ")#mi("{g \\in L^{p^{\\prime}}}")#text(". Replacing ")#mi("{g}")#text(" by ")#mi("{g*K_t}")#text(" and using ")#link(<tao-7653097b0a56851e687b>)[#text("(19)")]#text(" we conclude")

#align(center)[#tao-fit-display[#mitex("\\lim_{r \\rightarrow 1} \\langle f_t * K_r, g \\rangle = \\langle f_1, g * K_t \\rangle,")]]

#text("and hence (since ")#mi("{f_t * K_r}")#text(" converges to ")#mi("{f_t}")#text(" in ")#mi("{L^p}")#text(" norm)")

#align(center)[#tao-fit-display[#mitex("\\langle f_t, g \\rangle = \\langle f_1, g * K_t \\rangle = \\langle f_1 * K_t, g \\rangle.")]]

#text("This is for all ")#mi("{g \\in L^{p^{\\prime}}}")#text(", thus we have")

#align(center)[#tao-fit-display[#mitex("f_t = f_1 * K_t.")]]

#text("Thus ")#mi("{f_t}")#text(" converges pointwise almost everywhere and in ")#mi("{L^p}")#text(" norm to ")#mi("{f_1}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 45 (Fatou’s theorem)")]#text(" Let ")#mi("{f \\in H^p({\\mathbb D})}")#text(" for some ")#mi("{1 < p \\leq \\infty}")#text(", and let ")#mi("{f_1}")#text(" be as in Theorem ")#link(<tao-1caf527f6d2a83b0fa25>)[#text("43")]#text(". Show that for almost every ")#mi("{\\theta \\in {\\bf R}/{\\bf Z}}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} f(z_n) = f_1(\\theta)")]]

#text("whenever ")#mi("{z_n \\in {\\mathbb D}}")#text(" is a sequence of points converging to ")#mi("{e^{2\\pi i \\theta}}")#text(" ")#emph[#text("non-tangentially")]#text(" in the sense that ")#mi("{\\angle (e^{2\\pi i \\theta} - z_n), e^{2\\pi i \\theta}}")#text(" is uniformly bounded away from ")#mi("{\\pi/2}")#text(". (Hint: first reduce to a fixed angle of non-tangentiality (e.g. all angles less than pi/2 – 1/n), and then build an appropriate “non-tangential maximal function”, formed by taking suprema over all points in a sector with apex ")#mi("{e^{2\\pi i \\theta}}")#text(" and this fixed angle of non-tangentiality. Use the kernel bounds to bound this maximal function by the Hardy-Littlewood maximal operator.)")
]

#heading(level: 1)[#strong[#text(" — 8. The Calderón-Zygmund decomposition — ")]]

#text("For a function ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" on an abstract measure space, and any threshold ")#mi("{\\lambda > 0}")#text(" one has the basic decomposition")

#align(center)[#tao-fit-display[#tao-math("f = f 1_{\\left|f\\right| \\leq \\lambda} + f 1_{\\left|f\\right| > \\lambda}", block: true)]]

#text("into a “good” ")#tao-math("{g := f 1_{\\left|f\\right| \\leq\\lambda}}", block: false)#text(" piece (bounded by ")#mi("{\\lambda}")#text("), and a “bad” piece ")#tao-math("{b := f 1_{\\left|f\\right| > \\lambda}}", block: false)#text(" (larger than ")#mi("{\\lambda}")#text(", but at least of small support). If for instance ")#mi("{f \\in L^1(X)}")#text(", then we have the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g\\right\\|_{L^1(X)} \\leq \\left\\|f\\right\\|_{L^1(X)}; \\quad \\left\\|g\\right\\|_{L^\\infty(X)} \\leq \\lambda", block: true)]]

#text("for the good piece and")

#align(center)[#tao-fit-display[#tao-math("\\left\\|b\\right\\|_{L^1(X)} \\leq \\left\\|f\\right\\|_{L^1(X)}; \\quad \\mu( \\mathrm{supp}(b) ) \\leq \\frac{\\left\\|f\\right\\|_{L^1(X)}}{\\lambda}", block: true)]]

#text("for the bad piece (the last inequality being Markov’s inequality). Thus both pieces inherit the ")#mi("{L^1}")#text(" bound of the whole, but enjoy an additional useful property. This type of decomposition underlies tools such as the layer cake decompositions and the real interpolation method.")

#text("For arbitrary measure spaces ")#mi("{X}")#text(" with no additional structure, this type of decomposition is about the best one can do to split ")#mi("{f}")#text(" into “good” and “bad” parts. But if ")#mi("{f}")#text(" has more structure — in particular some sort of metric or dyadic structure compatible with the measure — then one can do better, in particular one can select the bad piece ")#mi("{b}")#text(" to be “locally oscillating” in a certain sense. This principle, which uses the same ideas that underlie the Hardy-Littlewood maximal inequality, is formalised in the ")#emph[#text("Calderón-Zygmund decomposition")]#text(", a fundamental tool in the Calderón-Zygmund theory of singular integrals.")

#text("To motivate the lemma let us first give a simple one-dimensional version.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 46 (Rising sun lemma)")]#text(" Let ")#mi("{I \\subset {\\bf R}}")#text(" be a bounded interval, and let ")#mi("{f: I \\rightarrow {\\bf R}}")#text(" be integrable, and let ")#mi("{\\lambda \\in {\\bf R}}")#text(" be such that ")#tao-math("{\\frac{1}{\\left|I\\right|} \\int_I f \\leq \\lambda}", block: false)#text(". Then there exist an at most countable family ")#mi("{(I_\\alpha)_{\\alpha \\in A}}")#text(" of disjoint open intervals in ")#mi("{I}")#text(" such that")

#list(
[#mi("{f(x) \\leq \\lambda}")#text(" for almost every ")#mi("{x \\in I \\backslash \\bigcup_{\\alpha \\in A} I_\\alpha}")#text(";")],
[#tao-math("{\\frac{1}{\\left|I_\\alpha\\right|} \\int_{I_\\alpha} f = \\lambda}", block: false)#text(" for every ")#mi("{\\alpha \\in A}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" By subtracting ")#mi("{\\lambda}")#text(" from ")#mi("{f}")#text(" we may normalise ")#mi("{\\lambda = 0}")#text(". We may take ")#mi("{I}")#text(" to be half-open ")#mi("{I = [x_-,x_+)}")#text(". Define ")#mi("{F: I \\rightarrow {\\bf R}}")#text(" by ")#mi("{F(x) := -\\int_{x_-}^x f(y)\\ dy}")#text(". Then ")#mi("{F}")#text(" is a continuous function which starts at zero and ends up positive. Define a “maximal” version ")#mi("{F^*: I \\rightarrow {\\bf R}}")#text(" of ")#mi("{F}")#text(" by ")#mi("{F^*(x) := \\sup_{x_- \\leq y \\leq x} F(y)}")#text(", then ")#mi("{F^*}")#text(" is continuous non-decreasing which starts at zero and ends up positive. Let ")#mi("{\\Omega := \\{ x \\in I: F^*(x) > F(x) \\}}")#text(", then ")#mi("{\\Omega}")#text(" is an open subset of ")#mi("{I}")#text(", thus ")#mi("{\\Omega = \\bigcup_{\\alpha \\in A} I_\\alpha}")#text(" for some at most countable set of intervals ")#mi("{I_\\alpha}")#text(". At the endpoints of each interval we have ")#mi("{F^*(x) = F(x)}")#text(", while on the interior of these intervals ")#mi("{F^*}")#text(" is necessarily constant (why?). This gives the second desired property. For the first, one observes from Q7 that at almost every point where ")#mi("{f(x) < 0}")#text(", we have ")#mi("{F}")#text(" differentiable with ")#mi("{F^{\\prime} < 0}")#text(", which implies that ")#mi("{x \\in \\Omega}")#text(", and the claim follows. ")#mi("\\Box")

#text("As a corollary we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 47 (One-dimensional rising sun lemma)")]#text(" Let the hypotheses be as in the above lemma. Then we have a decomposition ")#mi("{f = g + \\sum_{\\alpha \\in A} b_\\alpha}")#text(", where ")#mi("{g: I \\rightarrow {\\bf R}}")#text(" is bounded above by ")#mi("{\\lambda}")#text(" with ")#mi("{\\int_I g = \\int_I f}")#text(", and for each ")#mi("{\\alpha \\in A}")#text(", ")#mi("{b_\\alpha}")#text(" is supported in ")#mi("{I_\\alpha}")#text(" and has mean zero. Furthermore, if ")#mi("{\\lambda > 0}")#text(" and ")#mi("{f}")#text(" is non-negative, then ")#tao-math("{\\sum_\\alpha \\left|I_\\alpha\\right| \\leq \\frac{\\left\\|f\\right\\|_{L^1(I)}}{\\lambda}}", block: false)#text(" and ")#tao-math("{\\left\\| b_\\alpha \\right\\|_{L^1} \\leq 2 \\lambda \\left|I_\\alpha\\right|}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" We set ")#mi("{b_\\alpha := (f-\\lambda) 1_{I_\\alpha}}")#text(", and set ")#mi("{g}")#text(" equal to ")#mi("{f}")#text(" outside of ")#mi("{\\bigcup_\\alpha I_\\alpha}")#text(" and equal to ")#mi("{\\lambda}")#text(" inside ")#mi("{\\bigcup_{\\alpha} I_\\alpha}")#text(". To prove the last two claims, we have")

#align(center)[#tao-fit-display[#tao-math("\\int_{I_\\alpha} f = \\lambda \\left|I_\\alpha\\right|", block: true)]]

#text("so on summing and using the non-negativity of ")#mi("{f}")

#align(center)[#tao-fit-display[#tao-math("\\int_{I} f \\geq \\lambda \\sum_\\alpha \\left|I_\\alpha\\right|", block: true)]]

#text("from which the former claim follows. Finally, from the definition of ")#mi("{b_\\alpha}")#text(" and the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|b_\\alpha \\right\\|_{L^1} \\leq \\int_{I_\\alpha} f + \\int_{I_\\alpha} \\lambda = 2 \\lambda \\left|I_\\alpha\\right|", block: true)]]

#text("which is the latter claim. ")#mi("\\Box")

#text("The proof of the rising sun lemma relies crucially on the ordered nature of the real line. For more general spaces, such as Euclidean spaces, it is preferable to use arguments that rely instead on metric or dyadic structure. We begin with a dyadic version.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 48 (Dyadic Calderón-Zygmund decomposition)")]#text(" Let ")#mi("{f \\in L^1({\\bf R}^d)}")#text(" and ")#mi("{\\lambda > 0}")#text(". Then there exists a decomposition ")#mi("{f = g + \\sum_{Q \\in {\\mathcal Q}} b_Q}")#text(", where the “good” function ")#mi("{g}")#text(" obeys the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g\\right\\|_{L^1({\\bf R}^d)} \\leq \\left\\|f\\right\\|_{L^1({\\bf R}^d)}; \\quad \\left\\|g\\right\\|_{L^\\infty({\\bf R}^d)} \\leq 2^d \\lambda,", block: true)]]

#mi("{Q}")#text(" ranges over a disjoint family ")#mi("{{\\mathcal Q}}")#text(" of dyadic cubes, and each ")#mi("{b_Q}")#text(" is supported on ")#mi("{Q}")#text(", has mean zero, and has the ")#mi("{L^1}")#text(" bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\|b_Q \\right\\|_{L^1({\\bf R}^d)} \\leq 2^{d+1} \\lambda |Q|.", block: true)]]

#text("Furthermore, we have the inclusions")

#align(center)[#tao-fit-display[#mitex("\\bigcup_{Q \\in {\\mathcal Q}} Q = \\{ M_\\Delta f > \\lambda \\} \\subset \\{ Mf \\gtrsim \\lambda \\}.")]]

#text("In particular from ")#link(<tao-079cdc52e64462dfac51>)[#text("(3)")]#text(" we have ")#tao-math("{\\sum_{Q \\in {\\mathcal Q}} \\left|Q\\right| \\leq \\frac{\\left\\|f\\right\\|_{L^1({\\bf R}^d)}}{\\lambda}}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" The arguments here will closely resemble that used to prove ")#link(<tao-079cdc52e64462dfac51>)[#text("(3)")]#text(". Let us say that a cube ")#mi("{Q}")#text(" is ")#emph[#text("bad")]#text(" if ")#tao-math("{\\frac{1}{\\left|Q\\right|} \\int_Q \\left|f\\right| > \\lambda}", block: false)#text(", and ")#emph[#text("good")]#text(" otherwise. Call a bad cube ")#mi("{Q}")#text(" ")#emph[#text("maximal")]#text(" if ")#mi("{Q}")#text(" is bad, but no cube strictly containing ")#mi("{Q}")#text(" is bad, and let ")#mi("{{\\mathcal Q}}")#text(" be the collection of all maximal bad cubes, thus ")#mi("{{\\mathcal Q}}")#text(" is a collection of disjoint dyadic cubes, and we also clearly have ")#mi("{M_\\Delta f \\geq \\lambda}")#text(" on each bad cube. From the hypothesis ")#mi("{f \\in L^1({\\bf R}^d)}")#text(" and monotone convergence we see that all cubes with sufficiently large side-length are automatically good. Thus every bad cube is contained in a maximal bad cube.")

#text("Now let ")#mi("{Q}")#text(" be a maximal bad cube. The parent ")#mi("{Q^{\\prime}}")#text(" of ")#mi("{Q}")#text(" (i.e. the unique dyadic cube of twice the side-length containing ")#mi("{Q}")#text(") is good, hence ")#tao-math("{\\frac{1}{Q^{\\prime}} \\int_{Q^{\\prime}} \\left|f\\right| \\leq \\lambda}", block: false)#text(". Since ")#tao-math("{\\left|Q^{\\prime}\\right| = 2^d \\left|Q\\right|}", block: false)#text(", we conclude that ")#tao-math("{\\frac{1}{\\left|Q\\right|} \\int_Q \\left|f\\right| \\leq 2^d \\lambda}", block: false)#text(". Now set")

#align(center)[#tao-fit-display[#tao-math("b_Q := (f - \\frac{1}{\\left|Q\\right|} \\int_Q f) 1_Q", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("g = f (1 - 1_{\\bigcup_{Q \\in {\\mathcal Q}} Q}) + \\sum_Q (\\frac{1}{\\left|Q\\right|} \\int_Q f) 1_Q.", block: true)]]

#text("All the desired properties are then easily verified, except perhaps for the claim ")#tao-math("{\\left\\|g\\right\\|_{L^\\infty({\\bf R}^d)} \\leq 2^d \\lambda}", block: false)#text(". This claim is clear on each separate cube ")#mi("{Q}")#text("; the only difficulty is to show that ")#mi("{g}")#text(" is bounded by ")#mi("{2^d \\lambda}")#text(" outside of ")#mi("{\\bigcup_{Q \\in {\\mathcal Q}} Q}")#text(". But by construction we see that if ")#mi("{x \\not \\in \\bigcup_{Q \\in {\\mathcal Q}} Q}")#text(" and ")#mi("{Q \\ni x}")#text(", then ")#mi("{Q}")#text(" is good, and ")#tao-math("{\\left|\\frac{1}{\\left|Q\\right|} \\int_Q g\\right| = \\left|\\frac{1}{\\left|Q\\right|} \\int_Q f\\right| \\leq \\lambda}", block: false)#text(". On the other hand, the (dyadic version of the) Lebesgue differentiation theorem shows that ")#tao-math("{\\frac{1}{\\left|Q\\right|} \\int_Q f}", block: false)#text(" converges to ")#mi("{f(x)}")#text(" for almost every ")#mi("{x}")#text(" as ")#tao-math("{\\left|Q\\right| \\rightarrow 0}", block: false)#text(". Thus ")#tao-math("{\\left|g(x)\\right| \\leq \\lambda}", block: false)#text(" for almost every such ")#mi("{x}")#text(", and we are done. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 49")]#text(" Let ")#mi("{{\\mathcal B}}")#text(" be the ")#mi("{\\sigma}")#text("-algebra generated by the cubes in ")#mi("{{\\mathcal Q}}")#text(", and the Borel subsets of ")#mi("{{\\bf R}^d \\backslash \\bigcup_{Q \\in {\\mathcal Q}} Q}")#text(". Show that ")#mi("{g = \\mathop{\\bf E}(f|{\\mathcal B})}")#text(".")
]

#text("Note that the total bad set ")#mi("{\\bigcup_{Q \\in {\\mathcal Q}} Q}")#text(" is given by the level set ")#mi("{\\{ M_\\Delta f > \\lambda\\}}")#text(" of the dyadic maximal function. This suggests an alternate approach to the Calderón-Zygmund decomposition, in which one starts by identifying the total bad set (in this case, ")#mi("{\\{ M_\\Delta f > \\lambda\\}}")#text("), and then decomposes it into cubes or balls. A prototype decomposition of this type is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 50 (Dyadic Whitney decomposition)")]#text(" Let ")#mi("{\\Omega \\subsetneq {\\bf R}_+^d}")#text(" be an open set. Then there exists a decomposition ")#mi("{\\Omega = \\bigcup_{Q\\in {\\mathcal Q}} Q}")#text(", where ")#mi("{Q}")#text(" ranges over a family ")#mi("{{\\mathcal Q}}")#text(" of disjoint dyadic cubes, and for each ")#mi("{Q}")#text(" in this family ")#mi("{{\\mathcal Q}}")#text(", the parent ")#mi("{Q^{\\prime}}")#text(" of ")#mi("{Q}")#text(" is not contained in ")#mi("{\\Omega}")#text(".")
]

#emph[#text("Proof:")]#text(" Define ")#mi("{{\\mathcal Q}}")#text(" to be the set of all dyadic cubes ")#mi("{Q}")#text(" in ")#mi("{\\Omega}")#text(" which are maximal with respect to set inclusion; the claim follows from the nesting property. (The condition ")#mi("{\\Omega \\subsetneq {\\bf R}_+^d}")#text(" is needed to ensure that every cube is contained in a maximal cube; the open-ness is to get every point of ")#mi("{\\Omega}")#text(" contained in at least one cube.) ")#mi("\\Box")

#text("The property that ")#mi("{Q^{\\prime}}")#text(" is not contained in ")#mi("{\\Omega}")#text(" implies the bounds")

#align(center)[#tao-fit-display[#mitex("0 \\leq \\mathrm{dist}(Q, {\\bf R}^d_+ \\backslash \\Omega) \\leq \\mathrm{diam}(Q).")]]

#text("In many applications we need to complement the upper bound with a non-trivial lower bound. This can be done with a little more effort:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 51 (Whitney decomposition)")]#text(" Let ")#mi("{\\Omega \\subsetneq {\\bf R}^d}")#text(" be an open set and let ")#mi("{K \\geq 1}")#text(". Then there exists a decomposition ")#mi("{\\Omega = \\bigcup_{Q\\in {\\mathcal Q}} Q}")#text(", where ")#mi("{Q}")#text(" ranges over a family ")#mi("{{\\mathcal Q}}")#text(" of disjoint dyadic cubes, and for each ")#mi("{Q}")#text(" in this family ")#mi("{{\\mathcal Q}}")#text(", we have ")#mi("{\\mathrm{dist}(Q, {\\bf R}^d \\backslash \\Omega) \\sim K \\mathrm{diam}(Q)}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{{\\mathcal Q}^{\\prime}}")#text(" denote those dyadic cubes ")#mi("{Q}")#text(" in ")#mi("{\\Omega}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("K \\mathrm{diam}(Q) \\leq \\mathrm{dist}(Q, {\\bf R}^d \\backslash \\Omega) \\leq 5 K \\mathrm{diam}(Q).")]]

#text("It is not hard to show that these cubes cover ")#mi("{\\Omega}")#text("; indeed, given any ")#mi("{x}")#text(" in ")#mi("{\\Omega}")#text(", all one needs to do is to locate a cube ")#mi("{Q}")#text(" containing ")#mi("{x}")#text(" with diameter between ")#mi("{\\mathrm{dist}(x, {\\bf R}^d \\backslash \\Omega)/4K}")#text(" and ")#mi("{\\mathrm{dist}(x, {\\bf R}^d \\backslash \\Omega)/2K}")#text(". The cubes are not disjoint; however if one lets ")#mi("{{\\mathcal Q} \\subset {\\mathcal Q}^{\\prime}}")#text(" be those cubes in ")#mi("{{\\mathcal Q}^{\\prime}}")#text(" which are maximal with respect to set inclusion, then the claim follows from the nesting property. ")#mi("\\Box")

#text("Note that if ")#mi("{K}")#text(" is large, the cubes in this above decomposition have the property that nearby cubes ")#mi("{Q, Q^{\\prime}}")#text(" (in the sense that ")#mi("{\\mathrm{dist}(Q,Q^{\\prime}) \\lesssim \\mathrm{diam}(Q) + \\mathrm{diam}(Q^{\\prime})}")#text(") have comparable diameter, thanks to the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathrm{dist}(Q,{\\bf R}^d \\backslash \\Omega) - \\mathrm{dist}(Q^{\\prime},{\\bf R}^d \\backslash \\Omega)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\leq \\mathrm{dist}(Q,Q^{\\prime}) + \\mathrm{diam}(Q) + \\mathrm{diam}(Q^{\\prime}).")]]

#text("Since every cube is contained in a ball of comparable radius (with constants depending on ")#mi("{d}")#text("), we then conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 52 (Whitney decomposition for balls)")]#text(" Let ")#mi("{\\Omega \\subsetneq {\\bf R}^d}")#text(" be an open set and let ")#mi("{K \\geq 1}")#text(". Then one can cover ")#mi("{\\Omega}")#text(" by balls ")#mi("{B}")#text(" such that ")#mi("{\\mathrm{dist}(B, {\\bf R}^d \\backslash \\Omega) \\sim_d K \\mathrm{diam}(B)}")#text(", and such that each point in ")#mi("{\\Omega}")#text(" is contained in at most ")#mi("{O_d(1)}")#text(" balls.")
]

#text("These decompositions can be used to prove some minor variants of the Calderón-Zygmund decomposition, which we will not describe in detail here.")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/713bba3917c66a0ca054f58fad79f94515e22034e956dee52fa738eaffe72b49-bf88a5aaed0d40eba6a8653b394fa1e2efcbdc95f1bc82de8856579095b90e07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cosmo Chou")]], [#link("https://terrytao.wordpress.com/2026/10/02/247a-notes-2-the-hardy-littlewood-maximal-function-and-applications/comment-page-1/#comment-696691")[#strong[#text("Cosmo Chou")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("Dear Professor Tao,")

#text("Thank you for this exceptionally lucid exposition of the Hardy–Littlewood maximal inequality, particularly the comparative perspective across the four distinct proof paradigms.")

#text("In Section 3, the clean nesting geometry of dyadic cubes ")#mi("Q = 2^n(k + [0,1)^d)")#text(" and the non-overlapping Vitali covering are especially enlightening. In three dimensions (")#mi("d = 3")#text("), the natural volume expansion factor ")#mi("2^d = 8")#text(" yields a striking scale-contraction factor of ")#mi("\\kappa = 2^{-3} = 1/8")#text(" per generation. In multiscale discrete dynamics, this geometric contraction property provides an extraordinarily rigorous measure-theoretic foundation for tracking scale-by-scale energy localization.")

#text("Furthermore, your pedagogical framing of the Calderón–Zygmund decomposition in Section 8 (")#mi("f = g + b")#text(") provides immediate physical clarity for multiscale hydrodynamic PDEs: the mean-zero cancellation property of the singular parts (")#mi("\\int_Q b_Q = 0")#text(") elegantly guarantees that localized vortex/soliton singularities do not induce unphysical far-field drifts in the smooth background field ")#mi("g")#text(".")

#text("Notes like this are invaluable not only for graduate students, but also for researchers exploring constructive geometric frameworks and multi-scale continuous-discrete couplings. Much appreciated!")

#text("Warm regards,")

#text("Cosmo Chou")

#text("H3QM Lab / Independent Researcher")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/02/247a-notes-2-the-hardy-littlewood-maximal-function-and-applications/comment-page-1/#comment-696694")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("This is not the first time I see that the so-called 1/3 trick is attributed to M. Christ, but in 1916, in his book Intégrale de Lebesgue, fonctions d’ensemble, classes de Baire (Gauthier- Villars, Paris) C. De La Vallée Poussin had already used this technique.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/10/02/247a-notes-2-the-hardy-littlewood-maximal-function-and-applications/comment-page-1/#comment-696701")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("Nice find! I did some more digging and found (in footnote 2 of ")#link("https://arxiv.org/abs/1412.4157")[#text("this paper of Cruz-Uribe")]#text(") some more history on the introduction of this trick to harmonic analysis, where the author ultimately attributes the modern instantiation of this trick to Okikiolu.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/02/247a-notes-2-the-hardy-littlewood-maximal-function-and-applications/comment-page-1/#comment-696704")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("Thanks! In the paper you mentioned, David Cruz-Uribe writes that «dyadic grids and dyadic operators» «date back to the 1950’s and the seminal work of Calderón and Zygmund», but, with some effort, one can reconstruct a bit of the history that, from the 1916 work of C. De La Vallée Poussin, that I mentioned before, has led to their Acta paper, and realise that, after C. De La Vallée Poussin made use of dyadic grids using the “1/3 trick”, his ideas were picked up by a number of other mathematicians and finally led E. Sparre-Andersen and B. Jessen to write three papers, published from 1946 to 1948 in a Danish journal (Det Kgl. Danske Vidensabernes Selskab Mat. Fys. Medd.), which have a bearing on these topics. As it often happens in mathematics, the history of these ideas has been forgotten. A bit of this history has been reconstructed in a joint paper I wrote with Steven G. Krantz, titled «")#link("https://link.springer.com/article/10.1007/s12220-021-00618-z")[#text("Foundations of Fatou Theory and a Tribute to the Work of E.M. Stein on Boundary Behavior of Holomorphic Functions")]#text("».")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/713bba3917c66a0ca054f58fad79f94515e22034e956dee52fa738eaffe72b49-bf88a5aaed0d40eba6a8653b394fa1e2efcbdc95f1bc82de8856579095b90e07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cosmof5d7acd87d")]], [#link("https://terrytao.wordpress.com/2026/10/02/247a-notes-2-the-hardy-littlewood-maximal-function-and-applications/comment-page-1/#comment-696730")[#strong[#text("cosmof5d7acd87d")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2026")])]

#text("Dear Professor Tao,")

#text("Following this wonderful exchange on the provenance from De La Vallée Poussin (1916) to Okikiolu and Cruz-Uribe, Lemma 12 highlights something truly profound about the geometric nature of the $1/3$ shift.")

#text("The observation that $1/3 = 0.010101\\dots_2$ oscillates between $0$ and $1$ in binary—thereby ensuring that the shifted mesh $\\mathcal{D}_{4^\\infty/3}^d$ never shares a boundary singularity with the standard dyadic grid—is a remarkable bridge between real analysis and binary representations. In multiscale discrete computation and floating-point arithmetic, the boundary-straddling interval $[0.5-\\varepsilon, 0.5+\\varepsilon]$ is precisely where discrete grid truncations and machine-epsilon roundoff issues tend to concentrate.")

#text("Furthermore, this raises a fascinating perspective from interactive theorem proving (e.g., Lean 4 / Mathlib): while classical pen-and-paper analysis often treats the $1/3$ shift as a brief, intuitive “trick,” formalizing it requires non-trivial combinatorial infrastructure to prove that the shifted intervals cover arbitrary balls without boundary degeneration. In formal environments (such as the recent milestones in the Carleson formalization project), what human mathematicians casually pass over as an “elementary shift” demands substantial formal machinery to establish rigorous decidability and covering bounds.")

#text("Thank you and the commenters for turning what began as lecture notes into such a rich discussion on history, geometry, and formal rigor!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/02/247a-notes-2-the-hardy-littlewood-maximal-function-and-applications/comment-page-1/#comment-696770")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("Small typo in exercise 8(i). The text after the displayed equation should say x in R^d rather than y in R^d.")

#text("Thanks for the wonderful notes!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/713bba3917c66a0ca054f58fad79f94515e22034e956dee52fa738eaffe72b49-bf88a5aaed0d40eba6a8653b394fa1e2efcbdc95f1bc82de8856579095b90e07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cosmochou")]], [#link("https://terrytao.wordpress.com/2026/10/02/247a-notes-2-the-hardy-littlewood-maximal-function-and-applications/comment-page-1/#comment-696795")[#strong[#text("cosmochou")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2026")])]

#text("Thanks for the wonderful notes! Just two minor typos that might confuse students working through the exercises and theorems:")

#text("1. In Exercise 42: the text says “")#mi("\\hat f_r(n) = 0")#text(" for all ")#mi("n \\neq 0")#text("“, which should presumably be for all “")#mi("n < 0")#text("” (and “")#mi("f \\in \\mathbf{D}")#text("” as holomorphic on ")#mi("\\mathbf{D}")#text(").")

#text("2. In Theorem 26 (and its proof): the limit is written as “")#mi("\\lim_{n \\to \\infty} \\frac{1}{N} \\sum_{n=1}^N T^n f")#text("“, which should be “")#mi("\\lim_{N \\to \\infty}")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]
