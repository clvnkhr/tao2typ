// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/04/14/newton-iteration-and-the-siegel-linearisation-theorem/
// Converted to Typst by tao2typ: "2026-10-14T15:19:28.112548+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Newton iteration and the Siegel linearisation theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Newton iteration and the Siegel linearisation theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 April 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/04/14/newton-iteration-and-the-siegel-linearisation-theorem/")[#text("https://terrytao.wordpress.com/2015/04/14/newton-iteration-and-the-siegel-linearisation-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("An extremely large portion of mathematics is concerned with locating solutions to equations such as")

#align(center)[#tao-fit-display[#mitex("f(x) = 0")]]

#text("or ")#metadata(none) <tao-abb3e2bec70b2bcc0ac4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\Phi(x) = x")]]

#text("for ")#mi("{x}")#text(" in some suitable domain space (either finite-dimensional or infinite-dimensional), and various maps ")#mi("{f}")#text(" or ")#mi("{\\Phi}")#text(". To solve the fixed point iteration equation ")#link(<tao-abb3e2bec70b2bcc0ac4>)[#text("(1)")]#text(", the simplest general method available is the ")#link("http://en.wikipedia.org/wiki/Fixed-point_iteration")[#text("fixed point iteration")]#text(" method: one starts with an initial ")#emph[#text("approximate solution")]#text(" ")#mi("{x_0}")#text(" to ")#link(<tao-abb3e2bec70b2bcc0ac4>)[#text("(1)")]#text(", so that ")#mi("{\\Phi(x_0) \\approx x_0}")#text(", and then recursively constructs the sequence ")#mi("{x_1, x_2, x_3, \\dots}")#text(" by ")#mi("{x_n := \\Phi(x_{n-1})}")#text(". If ")#mi("{\\Phi}")#text(" behaves enough like a “contraction”, and the domain is complete, then one can expect the ")#mi("{x_n}")#text(" to converge to a limit ")#mi("{x}")#text(", which should then be a solution to ")#link(<tao-abb3e2bec70b2bcc0ac4>)[#text("(1)")]#text(". For instance, if ")#mi("{\\Phi: X \\rightarrow X}")#text(" is a map from a metric space ")#mi("{X = (X,d)}")#text(" to itself, which is a contraction in the sense that")

#align(center)[#tao-fit-display[#mitex("d( \\Phi(x), \\Phi(y) ) \\leq (1-\\eta) d(x,y)")]]

#text("for all ")#mi("{x,y \\in X}")#text(" and some ")#mi("{\\eta>0}")#text(", then with ")#mi("{x_n}")#text(" as above we have")

#align(center)[#tao-fit-display[#mitex("d( x_{n+1}, x_n ) \\leq (1-\\eta) d(x_n, x_{n-1} )")]]

#text("for any ")#mi("{n}")#text(", and so the distances ")#mi("{d(x_n, x_{n-1} )}")#text(" between successive elements of the sequence decay at at least a geometric rate. This leads to the ")#link("http://en.wikipedia.org/wiki/Banach_fixed-point_theorem")[#text("contraction mapping theorem")]#text(", which has many important consequences, such as the ")#link("http://en.wikipedia.org/wiki/Inverse_function_theorem")[#text("inverse function theorem")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Picard%E2%80%93Lindel%C3%B6f_theorem")[#text("Picard existence theorem")]#text(".")

#text("A slightly more complicated instance of this strategy arises when trying to ")#emph[#text("linearise")]#text(" a complex map ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" defined in a neighbourhood ")#mi("{U}")#text(" of a fixed point. For simplicity we normalise the fixed point to be the origin, thus ")#mi("{0 \\in U}")#text(" and ")#mi("{f(0)=0}")#text(". When studying the ")#link("http://en.wikipedia.org/wiki/Complex_dynamics")[#text("complex dynamics")]#text(" ")#mi("{f^2 = f \\circ f}")#text(", ")#mi("{f^3 = f \\circ f \\circ f}")#text(", ")#mi("{\\dots}")#text(" of such a map, it can be useful to try to conjugate ")#mi("{f}")#text(" to another function ")#mi("{g = \\psi^{-1} \\circ f \\circ \\psi}")#text(", where ")#mi("{\\psi}")#text(" is a holomorphic function defined and invertible near ")#mi("{0}")#text(" with ")#mi("{\\psi(0)=0}")#text(", since the dynamics of ")#mi("{g}")#text(" will be conjguate to that of ")#mi("{f}")#text(". Note that if ")#mi("{f(0)=0}")#text(" and ")#mi("{f^{\\prime}(0)=\\lambda}")#text(", then from the chain rule any conjugate ")#mi("{g}")#text(" of ")#mi("{f}")#text(" will also have ")#mi("{g(0)=0}")#text(" and ")#mi("{g^{\\prime}(0)=\\lambda}")#text(". Thus, the “simplest” function one can hope to conjugate ")#mi("{f}")#text(" to is the linear function ")#mi("{z \\mapsto \\lambda z}")#text(". Let us say that ")#mi("{f}")#text(" is ")#emph[#text("linearisable")]#text(" (around ")#mi("{0}")#text(") if it is conjugate to ")#mi("{z \\mapsto \\lambda z}")#text(" in some neighbourhood of ")#mi("{0}")#text(". Equivalently, ")#mi("{f}")#text(" is linearisable if there is a solution to the ")#link("http://en.wikipedia.org/wiki/Schr%C3%B6der%27s_equation")[#text("Schröder equation")]#text(" ")#metadata(none) <tao-3be6e8333ca086807288>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("f( \\psi(z) ) = \\psi(\\lambda z)")]]

#text("for some ")#mi("{\\psi: U^{\\prime} \\rightarrow {\\bf C}}")#text(" defined and invertible in a neighbourhood ")#mi("{U^{\\prime}}")#text(" of ")#mi("{0}")#text(" with ")#mi("{\\psi(0)=0}")#text(", and all ")#mi("{z}")#text(" sufficiently close to ")#mi("{0}")#text(". (The Schröder equation is normalised somewhat differently in the literature, but this form is equivalent to the usual form, at least when ")#mi("{\\lambda}")#text(" is non-zero.) Note that if ")#mi("{\\psi}")#text(" solves the above equation, then so does ")#mi("{z \\mapsto \\psi(cz)}")#text(" for any non-zero ")#mi("{c}")#text(", so we may normalise ")#mi("{\\psi^{\\prime}(0)=1}")#text(" in addition to ")#mi("{\\psi(0)=0}")#text(", which also ensures local invertibility from the inverse function theorem. (Note from winding number considerations that ")#mi("{\\psi}")#text(" cannot be invertible near zero if ")#mi("{\\psi^{\\prime}(0)}")#text(" vanishes.)")

#text("We have the following basic result of Koenigs:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Koenig’s linearisation theorem)")]#text(" Let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a holomorphic function defined near ")#mi("{0}")#text(" with ")#mi("{f(0)=0}")#text(" and ")#mi("{f^{\\prime}(0)=\\lambda}")#text(". If ")#tao-math("{0 < \\left|\\lambda\\right| < 1}", block: false)#text(" (attracting case) or ")#tao-math("{1 < \\left|\\lambda\\right| < \\infty}", block: false)#text(" (repelling case), then ")#mi("{f}")#text(" is linearisable near zero.")
]

#emph[#text("Proof:")]#text(" Observe that if ")#mi("{f, \\psi, \\lambda}")#text(" solve ")#link(<tao-3be6e8333ca086807288>)[#text("(2)")]#text(", then ")#mi("{f^{-1}, \\psi^{-1}, \\lambda^{-1}}")#text(" solve ")#link(<tao-3be6e8333ca086807288>)[#text("(2)")]#text(" also (in a sufficiently small neighbourhood of zero). Thus we may reduce to the attractive case ")#tao-math("{0 < \\left|\\lambda\\right| < 1}", block: false)#text(".")

#text("Let ")#mi("{r>0}")#text(" be a sufficiently small radius, and let ")#mi("{X}")#text(" denote the space of holomorphic functions ")#mi("{\\psi: B(0,r) \\rightarrow {\\bf C}}")#text(" on the complex disk ")#tao-math("{B(0,r) := \\{z \\in {\\bf C}: \\left|z\\right| < r \\}}", block: false)#text(" with ")#mi("{\\psi(0)=0}")#text(" and ")#mi("{\\psi^{\\prime}(0)=1}")#text(". We can view the Schröder equation ")#link(<tao-3be6e8333ca086807288>)[#text("(2)")]#text(" as a fixed point equation")

#align(center)[#tao-fit-display[#mitex("\\psi = \\Phi(\\psi)")]]

#text("where ")#mi("{\\Phi: X^{\\prime} \\rightarrow X}")#text(" is the partially defined function on ")#mi("{X}")#text(" that maps a function ")#mi("{\\psi: B(0,r) \\rightarrow {\\bf C}}")#text(" to the function ")#mi("{\\Phi(\\psi): B(0,r) \\rightarrow {\\bf C}}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("\\Phi(\\psi)(z) := f^{-1}( \\psi( \\lambda z ) ),")]]

#text("assuming that ")#mi("{f^{-1}}")#text(" is well-defined on the range of ")#mi("{\\psi(B(0,\\lambda r))}")#text(" (this is why ")#mi("{\\Phi}")#text(" is only partially defined).")

#text("We can solve this equation by the fixed point iteration method, if ")#mi("{r}")#text(" is small enough. Namely, we start with ")#mi("{\\psi_0: B(0,r) \\rightarrow {\\bf C}}")#text(" being the identity map, and set ")#mi("{\\psi_1 := \\Phi(\\psi_0), \\psi_2 := \\Phi(\\psi_1)}")#text(", etc. We equip ")#mi("{X}")#text(" with the uniform metric ")#tao-math("{d( \\psi, \\tilde \\psi ) := \\sup_{z \\in B(0,r)} \\left|\\psi(z) - \\tilde \\psi(z)\\right|}", block: false)#text(". Observe that if ")#mi("{d( \\psi, \\psi_0 ), d(\\tilde \\psi, \\psi_0) \\leq r}")#text(", and ")#mi("{r}")#text(" is small enough, then ")#mi("{\\psi, \\tilde \\psi}")#text(" takes values in ")#mi("{B(0,2r)}")#text(", and ")#mi("{\\Phi(\\psi), \\Phi(\\tilde \\psi)}")#text(" are well-defined and lie in ")#mi("{X}")#text(". Also, since ")#mi("{f^{-1}}")#text(" is smooth and has derivative ")#mi("{\\lambda^{-1}}")#text(" at ")#mi("{0}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|f^{-1}(z) - f^{-1}(w)\\right| \\leq (1+\\varepsilon) \\left|\\lambda\\right|^{-1} \\left|z-w\\right|", block: true)]]

#text("if ")#mi("{z, w \\in B(0,r)}")#text(", ")#mi("{\\varepsilon>0}")#text(" and ")#mi("{r}")#text(" is sufficiently small depending on ")#mi("{\\varepsilon}")#text(". This is not yet enough to establish the required contraction (thanks to Mario Bonk for pointing this out); but observe that the function ")#mi("{\\frac{\\psi(z)-\\tilde \\psi(z)}{z^2}}")#text(" is holomorphic on ")#mi("{B(0,r)}")#text(" and bounded by ")#mi("{d(\\psi,\\tilde \\psi)/r^2}")#text(" on the boundary of this ball (or slightly within this boundary), so by the maximum principle we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{\\psi(z)-\\tilde \\psi(z)}{z^2}\\right| \\leq \\frac{1}{r^2} d(\\psi,\\tilde \\psi)", block: true)]]

#text("on all of ")#mi("{B(0,r)}")#text(", and in particular")

#align(center)[#tao-fit-display[#tao-math("\\left|\\psi(z)-\\tilde \\psi(z)\\right| \\leq \\left|\\lambda\\right|^2 d(\\psi,\\tilde \\psi)", block: true)]]

#text("on ")#mi("{B(0,\\lambda r)}")#text(". Putting all this together, we see that")

#align(center)[#tao-fit-display[#mitex("d( \\Phi(\\psi), \\Phi(\\tilde \\psi)) \\leq (1+\\varepsilon) |\\lambda| d(\\psi, \\tilde \\psi);")]]

#text("since ")#tao-math("{\\left|\\lambda\\right|<1}", block: false)#text(", we thus obtain a contraction on the ball ")#mi("{\\{ \\psi \\in X: d(\\psi,\\psi_0) \\leq r \\}}")#text(" if ")#mi("{\\varepsilon}")#text(" is small enough (and ")#mi("{r}")#text(" sufficiently small depending on ")#mi("{\\varepsilon}")#text("). From this (and the completeness of ")#mi("{X}")#text(", which follows from ")#link("http://en.wikipedia.org/wiki/Morera%27s_theorem")[#text("Morera’s theorem")]#text(") we see that the iteration ")#mi("{\\psi_n}")#text(" converges (exponentially fast) to a limit ")#mi("{\\psi \\in X}")#text(" which is a fixed point of ")#mi("{\\Phi}")#text(", and thus solves Schröder’s equation, as required. ")#mi("\\Box")

#text("Koenig’s linearisation theorem leaves open the ")#emph[#text("indifferent case")]#text(" when ")#tao-math("{\\left|\\lambda\\right|=1}", block: false)#text(". In the ")#emph[#text("rationally indifferent")]#text(" case when ")#mi("{\\lambda^n=1}")#text(" for some natural number ")#mi("{n}")#text(", there is an obvious obstruction to linearisability, namely that ")#mi("{f^n = 1}")#text(" (in particular, linearisation is not possible in this case when ")#mi("{f}")#text(" is a non-trivial rational function). An obstruction is also present in some ")#emph[#text("irrationally indifferent")]#text(" cases (where ")#tao-math("{\\left|\\lambda\\right|=1}", block: false)#text(" but ")#mi("{\\lambda^n \\neq 1}")#text(" for any natural number ")#mi("{n}")#text("), if ")#mi("{\\lambda}")#text(" is sufficiently close to various roots of unity; the first result of this form is due to Cremer, and the optimal result of this type for quadratic maps was ")#link("http://www.ams.org/mathscinet-getitem?mr=929279")[#text("established by Yoccoz")]#text(". In the other direction, we have the following result of Siegel:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Siegel’s linearisation theorem)")]#text(" Let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a holomorphic function defined near ")#mi("{0}")#text(" with ")#mi("{f(0)=0}")#text(" and ")#mi("{f^{\\prime}(0)=\\lambda}")#text(". If ")#tao-math("{\\left|\\lambda\\right|=1}", block: false)#text(" and one has the ")#link("http://en.wikipedia.org/wiki/Diophantine_approximation")[#text("Diophantine condition")]#text(" ")#tao-math("{\\frac{1}{\\left|\\lambda^n-1\\right|} \\leq C n^C}", block: false)#text(" for all natural numbers ")#mi("{n}")#text(" and some constant ")#mi("{C>0}")#text(", then ")#mi("{f}")#text(" is linearisable at ")#mi("{0}")#text(".")
]

#text("The Diophantine condition can be relaxed to a more general condition involving the rational exponents of the phase ")#mi("{\\theta}")#text(" of ")#mi("{\\lambda = e^{2\\pi i \\theta}}")#text("; this was worked out by Brjuno, with the condition matching the one later obtained by Yoccoz. Amusingly, while the set of Diophantine numbers (and hence the set of linearisable ")#mi("{\\lambda}")#text(") has full measure on the unit circle, the set of non-linearisable ")#mi("{\\lambda}")#text(" is generic (the complement of countably many nowhere dense sets) due to the above-mentioned work of Cremer, leading to a striking disparity between the measure-theoretic and category notions of “largeness”.")

#text("Siegel’s theorem does not seem to be provable using a fixed point iteration method. However, it can be established by modifying another basic method to solve equations, namely ")#link("http://en.wikipedia.org/wiki/Newton%27s_method")[#text("Newton’s method")]#text(". Let us first review how this method works to solve the equation ")#mi("{f(x)=0}")#text(" for some smooth function ")#mi("{f: I \\rightarrow {\\bf R}}")#text(" defined on an interval ")#mi("{I}")#text(". We suppose we have some initial approximant ")#mi("{x_0 \\in I}")#text(" to this equation, with ")#mi("{f(x_0)}")#text(" small but not necessarily zero. To make the analysis more quantitative, let us suppose that the interval ")#mi("{[x_0-r_0,x_0+r_0]}")#text(" lies in ")#mi("{I}")#text(" for some ")#mi("{r_0>0}")#text(", and we have the estimates")

#tao-aligned(keep: true)[


#tao-math("\\left|f(x_0)\\right|  & \\leq \\delta_0 r_0", block: true)



#tao-math("\\left|f^{\\prime}(x)\\right|  & \\geq \\eta_0", block: true)



#tao-math("\\left|f^{\\prime\\prime}(x)\\right|  & \\leq \\frac{1}{\\eta_0 r_0}", block: true)
]

#text("for some ")#mi("{\\delta_0 > 0}")#text(" and ")#mi("{0 < \\eta_0 < 1/2}")#text(" and all ")#mi("{x \\in [x_0-r_0,x_0+r_0]}")#text(" (the factors of ")#mi("{r_0}")#text(" are present to make ")#mi("{\\delta_0,\\eta_0}")#text(" “dimensionless”).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" ")#metadata(none) <tao-0af0314a0d41115a67cf>#text(" Under the above hypotheses, we can find ")#mi("{x_1}")#text(" with ")#tao-math("{\\left|x_1 - x_0\\right| \\leq \\eta_0 r_0}", block: false)#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x_1)\\right| \\ll \\delta_0^2 \\eta_0^{-O(1)} r_0.", block: true)]]

#text("In particular, setting ")#mi("{r_1 := (1-\\eta_0) r_0}")#text(", ")#mi("{\\eta_1 := \\eta_0/2}")#text(", and ")#mi("{\\delta_1 = O(\\delta_0^2 \\eta_0^{-O(1)})}")#text(", we have ")#mi("{[x_1-r_1,x_1+r_1] \\subset [x_0-r_0,x_0+r_0] \\subset I}")#text(", and")

#tao-aligned(keep: true)[


#tao-math("\\left|f(x_1)\\right|  & \\leq \\delta_1 r_1", block: true)



#tao-math("\\left|f^{\\prime}(x)\\right|  & \\geq \\eta_1", block: true)



#tao-math("\\left|f^{\\prime\\prime}(x)\\right|  & \\leq \\frac{1}{\\eta_1 r_1}", block: true)
]

#text("for all ")#mi("{x \\in [x_1-r_1,x_1+r_1]}")#text(".")
]

#text("The crucial point here is that the new error ")#mi("{\\delta_1}")#text(" is roughly the square of the previous error ")#mi("{\\delta_0}")#text(". This leads to extremely fast (double-exponential) improvement in the error upon iteration, which is more than enough to absorb the exponential losses coming from the ")#mi("{\\eta_0^{-O(1)}}")#text(" factor.")

#emph[#text("Proof:")]#text(" If ")#mi("{\\delta_0 > c \\eta_0^{C}}")#text(" for some absolute constants ")#mi("{C,c>0}")#text(" then we may simply take ")#mi("{x_0=x_1}")#text(", so we may assume that ")#mi("{\\delta_0 \\leq c \\eta_0^{C}}")#text(" for some small ")#mi("{c>0}")#text(" and large ")#mi("{C>0}")#text(". Using the Newton approximation ")#mi("{f(x_0+h) \\approx f(x_0) + h f^{\\prime}(x_0)}")#text(" we are led to the choice")

#align(center)[#tao-fit-display[#mitex("x_1 := x_0 - \\frac{f(x_0)}{f^{\\prime}(x_0)}")]]

#text("for ")#mi("{x_1}")#text(". From the hypotheses on ")#mi("{f}")#text(" and the smallness hypothesis on ")#mi("{\\delta}")#text(" we certainly have ")#tao-math("{\\left|x_1-x_0\\right| \\leq \\eta_0 r_0}", block: false)#text(". From Taylor’s theorem with remainder we have")

#tao-aligned(keep: true)[


#tao-math("f(x_1)  & = f(x_0) - \\frac{f(x_0)}{f^{\\prime}(x_0)} f^{\\prime}(x_0) + O( \\frac{1}{\\eta_0 r_0} \\left|\\frac{f(x_0)}{f^{\\prime}(x_0)}\\right|^2 )", block: true)



#tao-math(" & = O( \\frac{1}{\\eta_0 r_0} (\\frac{\\delta_0 r_0}{\\eta_0})^2 )", block: true)
]

#text("and the claim follows. ")#mi("\\Box")

#text("We can iterate this procedure; starting with ")#mi("{x_0,\\eta_0,r_0,\\delta_0}")#text(" as above, we obtain a sequence of nested intervals ")#mi("{[x_n-r_n,x_n+r_n]}")#text(" with ")#mi("{f(x_n)| \\leq \\delta_n}")#text(", and with ")#mi("{\\eta_n,r_n,\\delta_n,x_n}")#text(" evolving by the recursive equations and estimates")

#tao-aligned(keep: true)[


#tao-math("\\eta_n  & = \\eta_{n-1} / 2", block: true)



#tao-math("r_n  & = (1 - \\eta_{n-1}) r_{n-1}", block: true)



#tao-math("\\delta_n  & = O( \\delta_{n-1}^2 \\eta_{n-1}^{-O(1)} )", block: true)



#tao-math("\\left|x_n - x_{n-1}\\right|  & \\leq \\eta_{n-1} r_{n-1}.", block: true)
]

#text("If ")#mi("{\\delta_0}")#text(" is sufficiently small depending on ")#mi("{\\eta_0}")#text(", we see that ")#mi("{\\delta_n}")#text(" converges rapidly to zero (indeed, we can inductively obtain a bound of the form ")#mi("{\\delta_n \\leq \\eta_0^{C (2^n + n)}}")#text(" for some large absolute constant ")#mi("{C}")#text(" if ")#mi("{\\delta_0}")#text(" is small enough), and ")#mi("{x_n}")#text(" converges to a limit ")#mi("{x \\in I}")#text(" which then solves the equation ")#mi("{f(x)=0}")#text(" by the continuity of ")#mi("{f}")#text(".")

#text("As I recently learned from ")#link("http://www.math.ucla.edu/~lizq/")[#text("Zhiqiang Li")]#text(", a similar scheme works to prove Siegel’s theorem, as can be found for instance in ")#link("http://www.ams.org/mathscinet-getitem?mr=1230383")[#text("this text of Carleson and Gamelin")]#text(". The key is the following analogue of Lemma ")#link(<tao-0af0314a0d41115a67cf>)[#text("3")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4")]#text(" Let ")#mi("{\\lambda}")#text(" be a complex number with ")#tao-math("{\\left|\\lambda\\right|=1}", block: false)#text(" and ")#tao-math("{\\frac{1}{\\left|\\lambda^n-1\\right|} \\ll n^{O(1)}}", block: false)#text(" for all natural numbers ")#mi("{n}")#text(". Let ")#mi("{r_0>0}")#text(", and let ")#mi("{f_0: B(0,r_0) \\rightarrow {\\bf C}}")#text(" be a holomorphic function with ")#mi("{f_0(0)=0}")#text(", ")#mi("{f^{\\prime}_0(0)=\\lambda}")#text(", and ")#metadata(none) <tao-2336f379fff1a2ad59fe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|f_0(z) - \\lambda z\\right| \\leq \\delta_0 r_0", block: true)]]

#text("for all ")#mi("{z \\in B(0,r_0)}")#text(" and some ")#mi("{\\delta_0>0}")#text(". Let ")#mi("{0 < \\eta_0 \\leq 1/2}")#text(", and set ")#mi("{r_1 := (1-\\eta_0) r_0}")#text(". Then there exists an injective holomorphic function ")#mi("{\\psi_0: B(0, r_1) \\rightarrow B(0, r_0)}")#text(" and a holomorphic function ")#mi("{f_1: B(0,r_1) \\rightarrow {\\bf C}}")#text(" such that ")#metadata(none) <tao-8252aa52eaa25942e776>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("f_0( \\psi_1(z) ) = \\psi_1(f_1(z))")]]

#text("for all ")#mi("{z \\in B(0,r_1)}")#text(", and such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\psi_1(z) - z\\right| \\ll \\delta_0 \\eta_0^{-O(1)} r_1", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|f_1(z) - \\lambda z\\right| \\leq \\delta_1 r_1", block: true)]]

#text("for all ")#mi("{z \\in B(0,r_1)}")#text(" and some ")#mi("{\\delta_1 = O(\\delta_0^2 \\eta_0^{-O(1)})}")#text(".")
]

#emph[#text("Proof:")]#text(" By scaling we may normalise ")#mi("{r_0=1}")#text(". If ")#mi("{\\delta_0 > c \\eta_0^C}")#text(" for some constants ")#mi("{c,C>0}")#text(", then we can simply take ")#mi("{\\psi_1}")#text(" to be the identity and ")#mi("{f_1=f_0}")#text(", so we may assume that ")#mi("{\\delta_0 \\leq c \\eta_0^C}")#text(" for some small ")#mi("{c>0}")#text(" and large ")#mi("{C>0}")#text(".")

#text("To motivate the choice of ")#mi("{\\psi_1}")#text(", we write ")#mi("{f_0(z) = \\lambda z + \\hat f_0(z)}")#text(" and ")#mi("{\\psi_1(z) = z + \\hat \\psi(z)}")#text(", with ")#mi("{\\hat f_0}")#text(" and ")#mi("{\\hat \\psi_1}")#text(" viewed as small. We would like to have ")#mi("{f_0(\\psi_1(z)) \\approx \\psi_1(\\lambda z)}")#text(", which expands as")

#align(center)[#tao-fit-display[#mitex("\\lambda z + \\lambda \\hat \\psi_1(z) + \\hat f_0( z + \\hat \\psi_1(z) ) \\approx \\lambda z + \\hat \\psi_1(\\lambda z).")]]

#text("As ")#mi("{\\hat f_0}")#text(" and ")#mi("{\\hat \\psi}")#text(" are both small, we can heuristically approximate ")#mi("{\\hat f_0(z + \\hat \\psi_1(z) ) \\approx \\hat f_0(z)}")#text(" up to quadratic errors (compare with the Newton approximation ")#mi("{f(x_0+h) \\approx f(x_0) + h f^{\\prime}(x_0)}")#text("), and arrive at the equation ")#metadata(none) <tao-f90e22675ced9c138e19>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\hat \\psi_1(\\lambda z) - \\lambda \\hat \\psi_1(z) = \\hat f_0(z).")]]

#text("This equation can be solved by Taylor series; the function ")#mi("{\\hat f_0}")#text(" vanishes to second order at the origin and thus has a Taylor expansion")

#align(center)[#tao-fit-display[#mitex("\\hat f_0(z) = \\sum_{n=2}^\\infty a_n z^n")]]

#text("and then ")#mi("{\\hat \\psi_1}")#text(" has a Taylor expansion")

#align(center)[#tao-fit-display[#mitex("\\hat \\psi_1(z) = \\sum_{n=2}^\\infty \\frac{a_n}{\\lambda^n - \\lambda} z^n.")]]

#text("We take this as our definition of ")#mi("{\\hat \\psi_1}")#text(", define ")#mi("{\\psi_1(z) := z + \\hat \\psi_1(z)}")#text(", and then define ")#mi("{f_1}")#text(" implicitly via ")#link(<tao-8252aa52eaa25942e776>)[#text("(4)")]#text(".")

#text("Let us now justify that this choice works. By ")#link(<tao-2336f379fff1a2ad59fe>)[#text("(3)")]#text(" and the generalised Cauchy integral formula, we have ")#tao-math("{\\left|a_n\\right| \\leq \\delta_0}", block: false)#text(" for all ")#mi("{n}")#text("; by the Diophantine assumption on ")#mi("{\\lambda}")#text(", we thus have ")#tao-math("{\\left|\\frac{a_n}{\\lambda^n - \\lambda}\\right| \\ll \\delta_0 n^{O(1)}}", block: false)#text(". In particular, ")#mi("{\\hat \\psi_1}")#text(" converges on ")#mi("{B(0,1)}")#text(", and on the disk ")#mi("{B(0, (1-\\eta_0/4))}")#text(" (say) we have the bounds ")#metadata(none) <tao-9b47e1d1d4eeae0d6760>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|\\hat \\psi_1(z)\\right|, \\left|\\hat \\psi^{\\prime}_1(z)\\right| \\ll \\delta_0 \\sum_{n=2}^\\infty n^{O(1)} (1-\\eta_0/4)^n \\ll \\eta_0^{-O(1)} \\delta_0.", block: true)]]

#text("In particular, as ")#mi("{\\delta_0}")#text(" is so small, we see that ")#mi("{\\psi_1}")#text(" maps ")#mi("{B(0, (1-\\eta_0/4))}")#text(" injectively to ")#mi("{B(0,1)}")#text(" and ")#mi("{B(0,1-\\eta_0)}")#text(" to ")#mi("{B(0,1-3\\eta_0/4)}")#text(", and the inverse ")#mi("{\\psi_1^{-1}}")#text(" maps ")#mi("{B(0, (1-\\eta_0/2))}")#text(" to ")#mi("{B(0, (1-\\eta_0/4))}")#text(". From ")#link(<tao-2336f379fff1a2ad59fe>)[#text("(3)")]#text(" we see that ")#mi("{f_0}")#text(" maps ")#mi("{B(0,1-3\\eta_0/4)}")#text(" to ")#mi("{B(0,1-\\eta_0/2)}")#text(", and so if we set ")#mi("{f_1: B(0,1-\\eta_0) \\rightarrow B(0,1-\\eta_0/4)}")#text(" to be the function ")#mi("{f_1 := \\psi_1^{-1} \\circ f_0 \\circ \\psi_1}")#text(", then ")#mi("{f_1}")#text(" is a holomorphic function obeying ")#link(<tao-8252aa52eaa25942e776>)[#text("(4)")]#text(". Expanding ")#link(<tao-8252aa52eaa25942e776>)[#text("(4)")]#text(" in terms of ")#mi("{\\hat f_0}")#text(" and ")#mi("{\\hat \\psi_1}")#text(" as before, and also writing ")#mi("{f_1(z) = \\lambda z + \\hat f_1(z)}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\lambda z + \\lambda \\hat \\psi_1(z) + \\hat f_0( z + \\hat \\psi_1(z) ) = \\lambda z + \\hat f_1(z) + \\hat \\psi_1(\\lambda z + \\hat f_1(z))")]]

#text("for ")#mi("{z \\in B(0, 1-\\eta_0)}")#text(", which by ")#link(<tao-f90e22675ced9c138e19>)[#text("(5)")]#text(" simplifies to")

#align(center)[#tao-fit-display[#mitex("\\hat f_1(z) = \\hat f_0( z + \\hat \\psi_1(z) ) - \\hat f_0(z) + \\hat \\psi_1(\\lambda z) - \\hat \\psi_1(\\lambda z + \\hat f_1(z)).")]]

#text("From ")#link(<tao-9b47e1d1d4eeae0d6760>)[#text("(6)")]#text(", the fundamental theorem of calculus, and the smallness of ")#mi("{\\delta_0}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\hat \\psi_1(\\lambda z) - \\hat \\psi_1(\\lambda z + \\hat f_1(z))\\right| \\leq \\frac{1}{2} \\left|\\hat f_1(z)\\right|", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\left|\\hat f_1(z)\\right| \\leq 2 |\\hat f_0( z + \\hat \\psi_1(z) ) - \\hat f_0(z)|.", block: true)]]

#text("From ")#link(<tao-2336f379fff1a2ad59fe>)[#text("(3)")]#text(" and the Cauchy integral formula we have ")#mi("{\\hat f^{\\prime}_0(z) = O( \\delta_0 \\eta_0^{-O(1)})}")#text(" on (say) ")#mi("{B(0,1-\\eta_0/4)}")#text(", and so from ")#link(<tao-9b47e1d1d4eeae0d6760>)[#text("(6)")]#text(" and the fundamental theorem of calculus we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\hat f_1(z)\\right| \\ll \\delta_0^2 \\eta_0^{-O(1)}", block: true)]]

#text("on ")#mi("{B(0,1-\\eta_0)}")#text(", and the claim follows. ")#mi("\\Box")

#text("If we set ")#mi("{\\eta_0 := 1/2}")#text(", ")#mi("{f_0 := f}")#text(", and ")#mi("{\\delta_0>0}")#text(" to be sufficiently small, then (since ")#mi("{f(z)-\\lambda z}")#text(" vanishes to second order at the origin), the hypotheses of this lemma will be obeyed for some sufficiently small ")#mi("{r_0}")#text(". Iterating the lemma (and halving ")#mi("{\\eta_0}")#text(" repeatedly), we can then find sequences ")#mi("{\\eta_n, \\delta_n, r_n > 0}")#text(", injective holomorphic functions ")#mi("{\\psi_n: B(0,r_n) \\rightarrow B(0,r_{n-1})}")#text(" and holomorphic functions ")#mi("{f_n: B(0,r_n) \\rightarrow {\\bf C}}")#text(" such that one has the recursive identities and estimates")

#tao-aligned(keep: true)[


#tao-math("\\eta_n  & = \\eta_{n-1} / 2", block: true)



#tao-math("r_n  & = (1 - \\eta_{n-1}) r_{n-1}", block: true)



#tao-math("\\delta_n  & = O( \\delta_{n-1}^2 \\eta_{n-1}^{-O(1)} )", block: true)



#tao-math("\\left|\\psi_n(z) - z\\right|  & \\ll \\delta_{n-1} \\eta_{n-1}^{-O(1)} r_n", block: true)



#tao-math("\\left|f_n(z) - \\lambda z\\right|  & \\leq \\delta_n r_n", block: true)



#tao-math("f_{n-1}( \\psi_n(z) )  & = \\psi_n(f_n(z))", block: true)
]

#text("for all ")#mi("{n \\geq 1}")#text(" and ")#mi("{z \\in B(0,r_n)}")#text(". By construction, ")#mi("{r_n}")#text(" decreases to a positive radius ")#mi("{r_\\infty}")#text(" that is a constant multiple of ")#mi("{r_0}")#text(", while (for ")#mi("{\\delta_0}")#text(" small enough) ")#mi("{\\delta_n}")#text(" converges double-exponentially to zero, so in particular ")#mi("{f_n(z)}")#text(" converges uniformly to ")#mi("{\\lambda z}")#text(" on ")#mi("{B(0,r_\\infty)}")#text(". Also, ")#mi("{\\psi_n}")#text(" is close enough to the identity, the compositions ")#mi("{\\Psi_n := \\psi_1 \\circ \\dots \\circ \\psi_n}")#text(" are uniformly convergent on ")#mi("{B(0,r_\\infty/2)}")#text(" with ")#mi("{\\Psi_n(0)=0}")#text(" and ")#mi("{\\Psi^{\\prime}_n(0)=1}")#text(". From this we have")

#align(center)[#tao-fit-display[#mitex("f( \\Psi_n(z) ) = \\Psi_n(f_n(z))")]]

#text("on ")#mi("{B(0,r_\\infty/4)}")#text(", and on taking limits using Morera’s theorem we obtain a holomorphic function ")#mi("{\\Psi}")#text(" defined near ")#mi("{0}")#text(" with ")#mi("{\\Psi(0)=0}")#text(", ")#mi("{\\Psi^{\\prime}(0)=1}")#text(", and")

#align(center)[#tao-fit-display[#mitex("f( \\Psi(z) ) = \\Psi(\\lambda z),")]]

#text("obtaining the required linearisation.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" The idea of using a Newton-type method to obtain error terms that decay double-exponentially, and can therefore absorb exponential losses in the iteration, also occurs in ")#link("http://en.wikipedia.org/wiki/Kolmogorov%E2%80%93Arnold%E2%80%93Moser_theorem")[#text("KAM theory")]#text(" and in ")#link("http://en.wikipedia.org/wiki/Nash%E2%80%93Moser_theorem")[#text("Nash-Moser iteration")]#text(", presumably due to Siegel’s influence on Moser. (I discuss Nash-Moser iteration in ")#link("http://www.math.ucla.edu/~tao/preprints/Expository/nashmoser.dvi")[#text("this note")]#text(" that I wrote back in 2006.)")
]

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/04/14/newton-iteration-and-the-siegel-linearisation-theorem/#comment-454110")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2015")])]

#text("i like that concept sir….i have new operators and spaces and any new conecpt i need this month…i doing project")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/04/14/newton-iteration-and-the-siegel-linearisation-theorem/#comment-454111")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2015")])]

#text("Is it possible to extend the (local) linearization theory to some class of ")#mi("\\mathbb R^n")#text(" – valued smooth functions ")#mi("f")#text(" over some region in ")#mi("\\mathbb R^n")#text(" ? (perhaps under some condition on ")#mi("f")#text(", like the Cauchy-Riemann equations for the case of holomorphic ")#mi("f")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/04/14/newton-iteration-and-the-siegel-linearisation-theorem/#comment-454147")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2015")])]

#text("I don’t know of any work in this direction, but there is some literature on p-adic versions of Siegel’s linearisation theorem, in which the complex plane is replaced by the p-adic completion ")#mi("{\\bf C}_p")#text(" of ")#mi("{\\bf Q}_p")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/04/14/newton-iteration-and-the-siegel-linearisation-theorem/#comment-454459")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2015")])]

#text("Some related results are given by Rodrigues and Sola-Morales in “Known results and open problems on ")#mi("C^1")#text(" linearization in Banach Spaces”, Sao Paulo J. Math. Sci. 6, 2(2012), 375-384.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/04/14/newton-iteration-and-the-siegel-linearisation-theorem/#comment-454113")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2015")])]

#text("Is the sufficient (Diophantine) condition in theorem 2 also a necessary one?")

#emph[#text("[No; see the comments following that theorem. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c7ead00368c278f1bae3f783dff5d147095be9bdcfa0e629252dbeab0c95dbd7-05eb8a376e8e92d4b5efd1667932ac91eb81c3840ff70dc2d99be642b960bb5b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JJG")]], [#link("https://terrytao.wordpress.com/2015/04/14/newton-iteration-and-the-siegel-linearisation-theorem/#comment-454116")[#strong[#text("JJG")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2015")])]

#text("Could one use the super-quadratic modified Newton methods (e.g., Weerakoon & Fernando, ‘A variant of Newton’s method with accelerated third-order convergence’, Appl. Math. Let. 13, 87–93, 2000) to similar (or improved!) affect?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/04/14/newton-iteration-and-the-siegel-linearisation-theorem/#comment-454139")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2015")])]

#text("In the proof of lemma 3, “large ")#mi("C>0")#text("” (third line) may be replaced by “")#mi("C \\geq 2")#text("” (which is needed for the estimate ")#tao-math("\\left|x_1 - x_0\\right| \\leq \\eta_0 r_0", block: false)#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/04/14/newton-iteration-and-the-siegel-linearisation-theorem/#comment-454148")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2015")])]

#text("This is true; however, in my post I wish to emphasise that the precise value of C is not terribly important for this type of argument, and can change in different instances of that argument (e.g. in Lemma 4, the requirement on C will be a little different).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/04/14/newton-iteration-and-the-siegel-linearisation-theorem/#comment-454176")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2015")])]

#text("Theorem 2: As a beginner I am trying to see how ")#mi("\\lambda")#text(" with phase ")#mi("\\theta")#text(" could violate the Diophantine condition in the irrationally indifferent case. Is it true that this requires the nonzero sequence ")#mi("n\\theta")#text(" ")#mi("(2\\pi)")#text(" to have a nonuniformly-spaced subsequence which converges to zero?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/04/14/newton-iteration-and-the-siegel-linearisation-theorem/#comment-454245")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2015")])]

#text("In theorem 1, ")#mi("f")#text(" is linearized only locally over a sufficiently small neighborhood of ")#mi("0")#text(".")#linebreak()#text(" Consider the possibility of linearizing ")#mi("f")#text(" globally over its whole domain ")#mi("U")#text(" in the attractive case where ")#mi("U")#text(" is simply connected:")#linebreak()#text(" A necessary condition seems to be that ")#mi("0")#text(" is the only(!) fixed point for ")#mi("f")#text(" in U. Is this the only obstruction for the global linearization of ")#mi("f")#text(" over ")#mi("U")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/04/14/newton-iteration-and-the-siegel-linearisation-theorem/#comment-454270")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2015")])]

#text("Well, another obvious obstruction would be that ")#mi("f")#text(" would have to be injective.")

#text("If one requires all maps to be holomorphic, then any global linearising map ")#mi("\\psi")#text(" must be an analytic continuation of a local linearising map ")#mi("\\psi")#text(", which one can show to be unique once one normalises ")#mi("\\psi^{\\prime}(0)=1")#text(". So it’s basically a question of how far one can analytically continue ")#mi("\\psi")#text(" and keep it invertible.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8445e7901e0a01d2eb017cd01c6f0497e4e5f9d379cdf0cb56c0619c133a5da7-d1a983a123f3db47bea3e7a5ce508970cb7b4e2e8b11f12c5a08f4cdf8c6774b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ricardo Pérez-Marco")]], [#link("https://terrytao.wordpress.com/2015/04/14/newton-iteration-and-the-siegel-linearisation-theorem/#comment-454727")[#strong[#text("Ricardo Pérez-Marco")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2015")])]

#text("Hi Terry, Nice entry. About your comment that “Siegel’s theorem does not seem to be provable using a fixed point iteration method” There is a paper of Michael Herman proving Siegel’s linearization using an elementary fixed point argument (not iterative, and only for certain rotation numbers). Can’t check the reference right now, but may be this one: “M.R. Herman – Simple proofs of local conjugacy theorems for diffeomorphisms of the circle with almost every rotation number, Bol. Soc. Bras. Mat.16 (1985), 45-83. ” (the same type of arguments work for linearization of circle maps, and you can indeed prove a rigorous dictionary between both problems through a construction using Hedgehogs, see “Fixed points and circle maps,” Acta Mathematica, vol. 179, no. 2, pp. 243–294, 1997). You may also like in the spirit of elementary proofs Yoccoz’s proof for almost all rotation numbers for quadratic maps only needing Fatou’s radial limit theorem. Cheers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2c4699af39d6e67f42f26e4f37f3764ee24c183deb651e3957ec0129bfcb3ca-7a803e7c9ef94a2af874c1479a84d6eda02163a89803ab17c35b84ba75194a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of E.L. Wisty")]], [#link("https://terrytao.wordpress.com/2015/04/14/newton-iteration-and-the-siegel-linearisation-theorem/#comment-456223")[#strong[#text("E.L. Wisty")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2015")])]

#text("Reblogged this on ")#link("https://pinkiguana2.wordpress.com/2015/05/31/newton-iteration-and-the-siegel-linearisation-theorem/")[#text("Pink Iguana")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on the Nash embedding theorem | What's new")]], [#link("https://terrytao.wordpress.com/2015/04/14/newton-iteration-and-the-siegel-linearisation-theorem/#comment-468514")[#strong[#text("Notes on the Nash embedding theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2016")])]

#text("[…] theorem with a much more rapidly convergent scheme that generalises Newton’s method; see this previous blog post for a similar idea. The other way out, due to Gunther, is to observe that can be factored […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3170687540c66dc22acac3ff153a5f7b25b10303e42e1144b148a6cfe32bff3d-0c12835ec5ba8882b4301c470ff7175f999ad4539c3167aabdb48ab191ff6473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eulogio Garcia")]], [#link("https://terrytao.wordpress.com/2015/04/14/newton-iteration-and-the-siegel-linearisation-theorem/#comment-476364")[#strong[#text("Eulogio Garcia")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2017")])]

#text("Professor Tao, you may be interested to know the following.")

#text("Theorem: every curve interval bounded by a secant line has its midpoint in the projection of ")#mi("(x_{i})")#text(" where.")

#mi("(x_{i}) = x_{n} - \\left[\\frac{2(f(x_{n}) - f(x))}{\\sqrt {2}}\\right]")

#text("With this theorem the is verified among other things the Taylor’s theorem.")
]
