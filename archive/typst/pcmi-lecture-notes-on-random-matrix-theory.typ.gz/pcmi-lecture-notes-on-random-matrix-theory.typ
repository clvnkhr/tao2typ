// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/06/07/pcmi-lecture-notes-on-random-matrix-theory/
// Converted to Typst by tao2typ: "2026-10-14T16:38:08.650690+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "PCMI lecture notes on random matrix theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("PCMI lecture notes on random matrix theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 June 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/06/07/pcmi-lecture-notes-on-random-matrix-theory/")[#text("https://terrytao.wordpress.com/2017/06/07/pcmi-lecture-notes-on-random-matrix-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In July I will be spending a week at Park City, being one of the mini-course lecturers in the ")#link("https://pcmi.ias.edu/program-gss/2017")[#text("Graduate Summer School component")]#text(" of the ")#link("https://pcmi.ias.edu/program-index/2017")[#text("Park City Summer Session on random matrices")]#text(". I have chosen to give some lectures on least singular values of random matrices, the circular law, and the Lindeberg exchange method in random matrix theory; this is a slightly different set of topics than I had initially advertised (which was instead about the Lindeberg exchange method and the local relaxation flow method), but after consulting with the other mini-course lecturers I felt that this would be a more complementary set of topics. I have uploaded an ")#link("https://terrytao.wordpress.com/wp-content/uploads/2018/03/terencetao20180306.pdf")[#text("draft of my lecture notes")]#text(" (some portion of which is derived from ")#link("https://terrytao.wordpress.com/books/topics-in-random-matrix-theory/")[#text("my monograph on the subject")]#text("); as always, comments and corrections are welcome.")

#emph[#text("[Update, June 23: notes revised and reformatted to PCMI format. -T.]")]

#emph[#text("[Update, Mar 19 2018: further revision. -T.]")]

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/06/07/pcmi-lecture-notes-on-random-matrix-theory/#comment-482235")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2017")])]

#text("Will there be any videos posted online of the lectures?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2017/06/07/pcmi-lecture-notes-on-random-matrix-theory/#comment-482350")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2017")])]

#text("No connections to free probability theory?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9d6c587f0179a9e9cd79521e2b6e113d0cb1f812e0a24e3149da324234575b5-b393abd8e95f8ff6c0382edd82d629c7d085349005e0c6c3c8751e025646bf26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2017/06/07/pcmi-lecture-notes-on-random-matrix-theory/#comment-482544")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2017")])]

#text("Connections to free probability will be the focus of the lectures by Shlyakhtenko.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e61d020eb5d4a79a2ddd4647f419a85128931336990d2b437925383058847a8-c52c25f4123c65058f107cdd6c8c1e1b55b76ad68cb644bd35a8f25afbfa0c9f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terry Cheng")]], [#link("https://terrytao.wordpress.com/2017/06/07/pcmi-lecture-notes-on-random-matrix-theory/#comment-482689")[#strong[#text("Terry Cheng")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2017")])]

#text("Will there be any reports online?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a8b401a164ffa2eef727d150ec77375393d084ff9d96b1b2e3f33c8a769b8c6c-ac0d65b7d393a6dbf8fa670bea5cf46a240f84b9b35c9b43ef48905fff84f4ff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Danilo")]], [#link("https://terrytao.wordpress.com/2017/06/07/pcmi-lecture-notes-on-random-matrix-theory/#comment-483000")[#strong[#text("Danilo")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2017")])]

#text("Even though I do not understand anything, I want to watch the lecture online")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/41c3947534e3fe2afe5b2e7c80f60664181e3aab4f31c4dd5c50f3a34924ccd5-c5fc0ef9bcad7fc8031a2e045a2d8349dcccc3055f184504dc2121b81ea5a0d4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Julian")]], [#link("https://terrytao.wordpress.com/2017/06/07/pcmi-lecture-notes-on-random-matrix-theory/#comment-483229")[#strong[#text("Julian")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2017")])]

#text("This is probably a rather weird question, but what is the bibliography style and/or package used in the lecture notes? I find it visually pleasing and very useful with the MR-links and the page back-references")

#emph[#text("[pcmi.cls, see ")#link("https://pcmi.ias.edu/author-info")[#text("https://pcmi.ias.edu/author-info")]#text(" -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9aeeac82e12aa6c9091628cfd1a147a9e78166ac7bf9d93c9d2c456aaaaab26f-05305d4969d6bad1b63ad391a6f10c8ed97be94051a2db954bd96daa7e19b479.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Keiji")]], [#link("https://terrytao.wordpress.com/2017/06/07/pcmi-lecture-notes-on-random-matrix-theory/#comment-483591")[#strong[#text("Keiji")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2017")])]

#text("[correction]")#linebreak()#text(" 1.1 The epsilon-net argument")#linebreak()#text(" – the proof of theorem 1.1.1(Upper bound for operator norm)")

#text("P(||Mx|| <= Cn^{1/2} / 2) < P(||Mx|| >= C n^{1/2} / 2) <= exp( -c C^{2} n / 4 + O(n) )")

#text("Thank you for uploading the lecture note.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T.]")]
]
