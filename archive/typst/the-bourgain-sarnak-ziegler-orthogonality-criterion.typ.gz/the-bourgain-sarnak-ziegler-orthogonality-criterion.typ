// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/
// Converted to Typst by tao2typ: "2026-10-14T16:36:42.807087+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Katai-Bourgain-Sarnak-Ziegler orthogonality criterion", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Katai-Bourgain-Sarnak-Ziegler orthogonality criterion")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 November 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/")[#text("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the basic problems in analytic number theory is to estimate sums of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{p<x} f(p)")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(", where ")#mi("{p}")#text(" ranges over primes and ")#mi("{f}")#text(" is some explicit function of interest (e.g. a linear phase function ")#mi("{f(p) = e^{2\\pi i \\alpha p}}")#text(" for some real number ")#mi("{\\alpha}")#text("). This is essentially the same task as obtaining estimates on the sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{n<x} \\Lambda(n) f(n)")]]

#text("where ")#mi("{\\Lambda}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(". If ")#mi("{f}")#text(" is bounded, ")#mi("{f(n)=O(1)}")#text(", then from the prime number theorem one has the trivial bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n<x} \\Lambda(n) f(n) = O(x)")]]

#text("but often (when ")#mi("{f}")#text(" is somehow “oscillatory” in nature) one is seeking the refinement ")#metadata(none) <tao-ad4cfcc2c02b00d292cd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{n<x} \\Lambda(n) f(n) = o(x)")]]

#text("or equivalently ")#metadata(none) <tao-974148695e6d3f098aa8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{p<x} f(p) = o(\\frac{x}{\\log x}).")]]

#text("Thanks to identities such as ")#metadata(none) <tao-80bd06825af571a6e019>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\Lambda(n) = \\sum_{d|n} \\mu(d) \\log(\\frac{n}{d}),")]]

#text("where ")#mi("{\\mu}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Mobius_function")[#text("Möbius function")]#text(", refinements such as ")#link(<tao-ad4cfcc2c02b00d292cd>)[#text("(1)")]#text(" are similar in spirit to estimates of the form ")#metadata(none) <tao-7941e7dba30bbf3b3fc6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{n<x} \\mu(n) f(n) = o(x).")]]

#text("Unfortunately, the connection between ")#link(<tao-ad4cfcc2c02b00d292cd>)[#text("(1)")]#text(" and ")#link(<tao-7941e7dba30bbf3b3fc6>)[#text("(4)")]#text(" is not particularly tight; roughly speaking, one needs to improve the bounds in ")#link(<tao-7941e7dba30bbf3b3fc6>)[#text("(4)")]#text(" (and variants thereof) by about two factors of ")#mi("{\\log x}")#text(" before one can use identities such as ")#link(<tao-80bd06825af571a6e019>)[#text("(3)")]#text(" to recover ")#link(<tao-ad4cfcc2c02b00d292cd>)[#text("(1)")]#text(". Still, one generally thinks of ")#link(<tao-ad4cfcc2c02b00d292cd>)[#text("(1)")]#text(" and ")#link(<tao-7941e7dba30bbf3b3fc6>)[#text("(4)")]#text(" as being “morally” equivalent, even if they are not formally equivalent.")

#text("When ")#mi("{f}")#text(" is oscillating in a sufficiently “irrational” way, then one standard way to proceed is the method of Type I and Type II sums, which uses truncated versions of divisor identities such as ")#link(<tao-80bd06825af571a6e019>)[#text("(3)")]#text(" to expand out either ")#link(<tao-ad4cfcc2c02b00d292cd>)[#text("(1)")]#text(" or ")#link(<tao-7941e7dba30bbf3b3fc6>)[#text("(4)")]#text(" into linear (Type I) or bilinear sums (Type II) with which one can exploit the oscillation of ")#mi("{f}")#text(". For instance, Vaughan’s identity lets one rewrite the sum in ")#link(<tao-ad4cfcc2c02b00d292cd>)[#text("(1)")]#text(" as the sum of the Type I sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq U} \\mu(d) (\\sum_{V/d \\leq r \\leq x/d} (\\log r) f(rd)),")]]

#text("the Type I sum")

#align(center)[#tao-fit-display[#mitex("-\\sum_{d \\leq UV} a(d) \\sum_{V/d \\leq r \\leq x/d} f(rd),")]]

#text("the Type II sum")

#align(center)[#tao-fit-display[#mitex("-\\sum_{V \\leq d \\leq x/U} \\sum_{U < m \\leq x/V} \\Lambda(d) b(m) f(dm),")]]

#text("and the error term ")#mi("{\\sum_{d \\leq V} \\Lambda(n) f(n)}")#text(", whenever ")#mi("{1 \\leq U, V \\leq x}")#text(" are parameters, and ")#mi("{a, b}")#text(" are the sequences")

#align(center)[#tao-fit-display[#mitex("a(d) := \\sum_{e \\leq U, f \\leq V: ef = d} \\Lambda(d) \\mu(e)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("b(m) := \\sum_{d|m: d \\leq U} \\mu(d).")]]

#text("Similarly one can express ")#link(<tao-7941e7dba30bbf3b3fc6>)[#text("(4)")]#text(" as the Type I sum")

#align(center)[#tao-fit-display[#mitex("-\\sum_{d \\leq UV} c(d) \\sum_{UV/d \\leq r \\leq x/d} f(rd),")]]

#text("the Type II sum")

#align(center)[#tao-fit-display[#mitex("- \\sum_{V < d \\leq x/U} \\sum_{U < m \\leq x/d} \\mu(m) b(d) f(dm)")]]

#text("and the error term ")#mi("{\\sum_{d \\leq UV} \\mu(n) f(N)}")#text(", whenever ")#mi("{1 \\leq U,V \\leq x}")#text(" with ")#mi("{UV \\leq x}")#text(", and ")#mi("{c}")#text(" is the sequence")

#align(center)[#tao-fit-display[#mitex("c(d) := \\sum_{e \\leq U, f \\leq V: ef = d} \\mu(d) \\mu(e).")]]

#text("After eliminating troublesome sequences such as ")#mi("{a(), b(), c()}")#text(" via Cauchy-Schwarz or the triangle inequality, one is then faced with the task of estimating Type I sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{r \\leq y} f(rd)")]]

#text("or Type II sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{r \\leq y} f(rd) \\overline{f(rd^{\\prime})}")]]

#text("for various ")#mi("{y, d, d^{\\prime} \\geq 1}")#text(". Here, the trivial bound is ")#mi("{O(y)}")#text(", but due to a number of logarithmic inefficiencies in the above method, one has to obtain bounds that are more like ")#mi("{O( \\frac{y}{\\log^C y})}")#text(" for some constant ")#mi("{C}")#text(" (e.g. ")#mi("{C=5}")#text(") in order to end up with an asymptotic such as ")#link(<tao-ad4cfcc2c02b00d292cd>)[#text("(1)")]#text(" or ")#link(<tao-7941e7dba30bbf3b3fc6>)[#text("(4)")]#text(".")

#text("However, in a ")#link("http://arxiv.org/abs/1110.0992")[#text("recent paper of Bourgain, Sarnak, and Ziegler")]#text(", it was observed that as long as one is only seeking the Mobius orthogonality ")#link(<tao-7941e7dba30bbf3b3fc6>)[#text("(4)")]#text(" rather than the von Mangoldt orthogonality ")#link(<tao-ad4cfcc2c02b00d292cd>)[#text("(1)")]#text(", one can avoid losing any logarithmic factors, and rely purely on qualitative equidistribution properties of ")#mi("{f}")#text(". A special case of their orthogonality criterion (which actually dates back to an earlier ")#link("http://www.ams.org/mathscinet-getitem?mr=836415")[#text("paper of Katai")]#text(", as was pointed out to me by Nikos Frantzikinakis) is as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Orthogonality criterion)")]#text(" ")#metadata(none) <tao-294dfae5089bcf19d0cf>#text(" Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be a bounded function such that ")#metadata(none) <tao-baff4fb62c8b1c5a7934>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{n \\leq x} f(pn) \\overline{f(qn)} = o(x)")]]

#text("for any distinct primes ")#mi("{p, q}")#text(" (where the decay rate of the error term ")#mi("{o(x)}")#text(" may depend on ")#mi("{p}")#text(" and ")#mi("{q}")#text("). Then ")#metadata(none) <tao-3218c9b4903695b6ac0b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{n \\leq x} \\mu(n) f(n) =o(x).")]]
]

#text("Actually, the Bourgain-Sarnak-Ziegler paper establishes a more quantitative version of this proposition, in which ")#mi("{\\mu}")#text(" can be replaced by an arbitrary bounded multiplicative function, but we will content ourselves with the above weaker special case. (See also ")#link("https://www.dpmms.cam.ac.uk/~ajh228/FiniteBilinearNotes.pdf")[#text("these notes of Harper")]#text(", which uses the Katai argument to give a slightly weaker quantitative bound in the same spirit.) This criterion can be viewed as a multiplicative variant of the classical van der Corput lemma, which in our notation asserts that ")#mi("{\\sum_{n \\leq x} f(n) = o(x)}")#text(" if one has ")#mi("{\\sum_{n \\leq x} f(n+h) \\overline{f(n)} = o(x)}")#text(" for each fixed non-zero ")#mi("{h}")#text(".")

#text("As a sample application, Proposition ")#link(<tao-294dfae5089bcf19d0cf>)[#text("1")]#text(" easily gives a proof of the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) e^{2\\pi i \\alpha n} = o(x)")]]

#text("for any irrational ")#mi("{\\alpha}")#text(". (For rational ")#mi("{\\alpha}")#text(", this is a little trickier, as it is basically equivalent to the prime number theorem in arithmetic progressions.) The paper of Bourgain, Sarnak, and Ziegler also apply this criterion to nilsequences (obtaining a quick proof of a qualitative version of a ")#link("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/")[#text("result of Ben Green and myself")]#text(", see ")#link("http://www.technion.ac.il/~tamarzr/soft-green-tao.pdf")[#text("these notes of Ziegler")]#text(" for details) and to horocycle flows (for which no Möbius orthogonality result was previously known).")

#text("Informally, the connection between ")#link(<tao-baff4fb62c8b1c5a7934>)[#text("(5)")]#text(" and ")#link(<tao-3218c9b4903695b6ac0b>)[#text("(6)")]#text(" comes from the multiplicative nature of the Möbius function. If ")#link(<tao-3218c9b4903695b6ac0b>)[#text("(6)")]#text(" failed, then ")#mi("{\\mu(n)}")#text(" exhibits strong correlation with ")#mi("{f(n)}")#text("; by change of variables, we then expect ")#mi("{\\mu(pn)}")#text(" to correlate with ")#mi("{f(pn)}")#text(" and ")#mi("{\\mu(pm)}")#text(" to correlate with ")#mi("{f(qn)}")#text(", for “typical” ")#mi("{p,q}")#text(" at least. On the other hand, since ")#mi("{\\mu}")#text(" is multiplicative, ")#mi("{\\mu(pn)}")#text(" exhibits strong correlation with ")#mi("{\\mu(qn)}")#text(". Putting all this together (and pretending correlation is transitive), this would give the claim (in the contrapositive). Of course, correlation is not quite transitive, but it turns out that one can use the Cauchy-Schwarz inequality as a substitute for transitivity of correlation in this case.")

#text("I will give a proof of Proposition ")#link(<tao-294dfae5089bcf19d0cf>)[#text("1")]#text(" below the fold (which is not quite based on the argument in the above mentioned paper, but on a variant of that argument communicated to me by Tamar Ziegler, and also independently discovered by Adam Harper). The main idea is to exploit the following observation: if ")#mi("{P}")#text(" is a “large” but finite set of primes (in the sense that the sum ")#mi("{A := \\sum_{p \\in P} \\frac{1}{p}}")#text(" is large), then for a typical large number ")#mi("{n}")#text(" (much larger than the elements of ")#mi("{P}")#text("), the number of primes in ")#mi("{P}")#text(" that divide ")#mi("{n}")#text(" is pretty close to ")#mi("{A = \\sum_{p \\in P} \\frac{1}{p}}")#text(": ")#metadata(none) <tao-f4435ec544de04f88d5a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\sum_{p \\in P: p|n} 1 \\approx A.")]]

#text("A more precise formalisation of this heuristic is provided by the ")#link("http://en.wikipedia.org/wiki/Tur%C3%A1n%E2%80%93Kubilius_inequality")[#text("Turan-Kubilius inequality")]#text(", which is proven by a simple application of the ")#link("http://en.wikipedia.org/wiki/Second_moment_method")[#text("second moment method")]#text(".")

#text("In particular, one can sum ")#link(<tao-f4435ec544de04f88d5a>)[#text("(7)")]#text(" against ")#mi("{\\mu(n) f(n)}")#text(" and obtain an approximation")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) f(n) \\approx \\frac{1}{A} \\sum_{p \\in P} \\sum_{n \\leq x: p|n} \\mu(n) f(n)")]]

#text("that approximates a sum of ")#mi("{\\mu(n) f(n)}")#text(" by a bunch of sparser sums of ")#mi("{\\mu(n) f(n)}")#text(". Since")

#align(center)[#tao-fit-display[#mitex("x = \\frac{1}{A} \\sum_{p \\in P} \\frac{x}{p},")]]

#text("we see (heuristically, at least) that in order to establish ")#link(<tao-7941e7dba30bbf3b3fc6>)[#text("(4)")]#text(", it would suffice to establish the sparser estimates")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x: p|n} \\mu(n) f(n) = o(\\frac{x}{p})")]]

#text("for all ")#mi("{p \\in P}")#text(" (or at least for “most” ")#mi("{p \\in P}")#text(").")

#text("Now we make the change of variables ")#mi("{n = pm}")#text(". As the Möbius function is multiplicative, we usually have ")#mi("{\\mu(n) = \\mu(p) \\mu(m) = - \\mu(m)}")#text(". (There is an exception when ")#mi("{n}")#text(" is divisible by ")#mi("{p^2}")#text(", but this will be a rare event and we will be able to ignore it.) So it should suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\leq x/p} \\mu(m) f(pm) = o( x/p )")]]

#text("for most ")#mi("{p \\in P}")#text(". However, by the hypothesis ")#link(<tao-baff4fb62c8b1c5a7934>)[#text("(5)")]#text(", the sequences ")#mi("{m \\mapsto f(pm)}")#text(" are asymptotically orthogonal as ")#mi("{p}")#text(" varies, and this claim will then follow from a Cauchy-Schwarz argument.")

#metadata(none) <tao-ddef93f4d4bccc45fb92>

#heading(level: 1)[#strong[#text(" — 1. Rigorous proof — ")]]

#text("We will need a slowly growing function ")#mi("{H = H(x)}")#text(" of ")#mi("{x}")#text(", with ")#mi("{H(x) \\rightarrow \\infty}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(", to be chosen later. As the sum of reciprocals of primes diverges, we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p < H} \\frac{1}{p} \\rightarrow \\infty")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(". It will also be convenient to eliminate small primes. Note that we may find an even slower growing function ")#mi("{W = W(x)}")#text(" of ")#mi("{x}")#text(", with ")#mi("{W(x) \\rightarrow \\infty}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(", such that")

#align(center)[#tao-fit-display[#mitex("\\sum_{W \\leq p < H} \\frac{1}{p} \\rightarrow \\infty.")]]

#text("Although it is not terribly important, we will take ")#mi("{W}")#text(" and ")#mi("{H}")#text(" to be powers of two. Thus, if we set ")#mi("{P}")#text(" to be all the primes between ")#mi("{W}")#text(" and ")#mi("{H}")#text(", the quantity")

#align(center)[#tao-fit-display[#mitex("A := \\sum_{p \\in P} \\frac{1}{p}")]]

#text("goes to infinity as ")#mi("{x \\rightarrow \\infty}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Turan-Kubilius inequality)")]#text(" One has ")#metadata(none) <tao-1ec22d56dbbc91e849b0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\sum_{n \\leq x} \\left|\\sum_{p \\in P: p|n} 1 - A\\right|^2 \\ll A x.", block: true)]]
]

#emph[#text("Proof:")]#text(" We have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\sum_{p \\in P: p|n} 1 = \\sum_{p \\in P} \\sum_{n \\leq x: p|n} 1.")]]

#text("On the other hand, we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x: p|n} 1 = \\frac{x}{p} + O(1)")]]

#text("and thus (if ")#mi("{H}")#text(" is sufficiently slowly growing)")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\sum_{p \\in P: p|n} 1 = x A + O(x).")]]

#text("Similarly, we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} (\\sum_{p \\in P: p|n} 1)^2 = \\sum_{p,q \\in P} \\sum_{n \\leq x: p|n, q|n} 1.")]]

#text("The expression ")#mi("{\\sum_{n \\leq x: p|n, q|n} 1}")#text(" is equal to ")#mi("{\\frac{x}{p}+O(1)}")#text(" when ")#mi("{q=p}")#text(", and ")#mi("{\\frac{x}{pq}}")#text(" when ")#mi("{p \\neq q}")#text(". A brief calculation then shows that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} (\\sum_{p \\in P: p|n} 1)^2 = x A^2 + O(A x)")]]

#text("if ")#mi("{H}")#text(" is sufficiently slowly growing. Inserting these bounds into ")#link(<tao-1ec22d56dbbc91e849b0>)[#text("(8)")]#text(", the claim follows. ")#mi("\\Box")

#text("From ")#link(<tao-1ec22d56dbbc91e849b0>)[#text("(8)")]#text(" and the Cauchy-Schwarz inequality, one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} (\\sum_{p \\in P: p|n} 1 - A) \\mu(n) f(n) = O( A^{1/2} x )")]]

#text("which we rearrange as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) f(n) = \\frac{1}{A} \\sum_{p \\in P} \\sum_{n \\leq x: p|n} \\mu(n) f(n) + O( A^{-1/2} x ).")]]

#text("Since ")#mi("{A}")#text(" goes to infinity, the ")#mi("{O(A^{-1/2} x)}")#text(" term is ")#mi("{o(x)}")#text(", so it now suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\in P} \\sum_{n \\leq x: p|n} \\mu(n) f(n) = o( A x ).")]]

#text("Write ")#mi("{n=pm}")#text(". Then we have ")#mi("{\\mu(n) f(n) = - \\mu(m) f(pm)}")#text(" for all but ")#mi("{O(x/p^2)}")#text(" values of ")#mi("{n}")#text(" (if ")#mi("{H}")#text(" is sufficiently slowly growing). The exceptional values contribute at most")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\in P} \\frac{x}{p^2} = \\sum_{p \\in P} \\frac{x}{Wp} = O(Ax/W) = o(Ax)")]]

#text("which is acceptable. Thus it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\in P} \\sum_{m \\leq x/p} \\mu(m) f(pm) = o(Ax).")]]

#text("Partitioning into dyadic blocks, it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{p \\in P_k} \\sum_{m \\leq x/p} \\mu(m) f(pm) = o( \\left|P_k\\right| x / 2^k )", block: true)]]

#text("uniformly for ")#mi("{W \\leq 2^k < H}")#text(", where ")#mi("{P_k}")#text(" are the primes between ")#mi("{2^k}")#text(" and ")#mi("{2^{k+1}}")#text(".")

#text("Fix ")#mi("{k}")#text(". The left-hand side can be rewritten as")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\leq x/2^k} \\mu(m) \\sum_{p \\in P_k} f(pm) 1_{m \\leq x/p}")]]

#text("so by the Cauchy-Schwarz inequality it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{m \\leq x/2^k} \\left|\\sum_{p \\in P_k} f(pm) 1_{m \\leq x/p}\\right|^2 = o( \\left|P_k\\right|^2 x / 2^k ).", block: true)]]

#text("We can rearrange the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\sum_{p,q \\in P_k} \\sum_{m \\leq \\min(x/p,x/q)} f(pm) \\overline{f(qm)}.")]]

#text("Now if ")#mi("{H}")#text(" is sufficiently slowly growing as a function of ")#mi("{x}")#text(", we see from ")#link(<tao-baff4fb62c8b1c5a7934>)[#text("(5)")]#text(" that for all distinct ")#mi("{p,q \\leq H}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\leq \\min(x/p,x/q)} f(pm) \\overline{f(qm)} = o( x / 2^k )")]]

#text("uniformly in ")#mi("{p,q}")#text("; meanwhile, for ")#mi("{p=q}")#text(", we have the crude bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\leq \\min(x/p,x/q)} f(pm) \\overline{f(qm)} = O( x / 2^k ).")]]

#text("The claim follows (noting from the prime number theorem that ")#tao-math("{\\left|P_k\\right| = o(\\left|P_k\\right|^2)}", block: false)#text(").")

#heading(level: 1)[#strong[#text(" — 2. From Möbius to von Mangoldt? — ")]]

#text("It would be great if one could pass from the Möbius asymptotic orthogonality ")#link(<tao-7941e7dba30bbf3b3fc6>)[#text("(4)")]#text(" to the von Mangoldt asymptotic orthgonality ")#link(<tao-ad4cfcc2c02b00d292cd>)[#text("(1)")]#text(" (or equivalently, to ")#link(<tao-974148695e6d3f098aa8>)[#text("(2)")]#text("), as this would give some new information about the distribution of primes. Unfortunately, it seems that some additional input is needed to do so. Here is a simple example of a conditional implication that requires an additional input, namely some quantitative control on “Type I” sums:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3")]#text(" Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be a bounded function such that ")#metadata(none) <tao-b076d0643d8294e911d8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\sum_{n \\leq x} \\mu(n) f(dn) = o(x)")]]

#text("for each fixed ")#mi("{d \\geq 1}")#text(" (with the decay rate allowed to depend on ")#mi("{d}")#text("). Suppose also that one has the Type I bound ")#metadata(none) <tao-b5e509d769c77bd1fecf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\sum_{1 \\leq m \\leq M} \\sup_{y \\leq x} \\left|\\sum_{n \\leq y} f(mn)\\right| \\ll \\frac{M x}{\\log^{2+\\epsilon} x}", block: true)]]

#text("for all ")#mi("{M, x \\geq 2}")#text(" and some absolute constant ")#mi("{\\epsilon>0}")#text(", where the implied constant is independent of both ")#mi("{M}")#text(" and ")#mi("{x}")#text(". Then one has ")#metadata(none) <tao-5400d6b19f4371145577>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\sum_{n \\leq x} \\Lambda(n) f(n) = o(x)")]]

#text("and thus (by discarding the prime powers and summing by parts)")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\in x} f(p) = o(\\frac{x}{\\log x}).")]]
]

#emph[#text("Proof:")]#text(" We use the Dirichlet hyperbola method. Using ")#link(<tao-80bd06825af571a6e019>)[#text("(3)")]#text(", one can write the left-hand side of ")#link(<tao-5400d6b19f4371145577>)[#text("(11)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{dm \\leq x} \\mu(m) (\\log d) f(dm).")]]

#text("We let ")#mi("{D = D(x)}")#text(" be a slowly growing function of ")#mi("{x}")#text(" to be chosen later, and split this sum as ")#metadata(none) <tao-799ef92a11af918e3fb7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\sum_{d \\leq D} \\log d \\sum_{m \\leq x/d} \\mu(m) f(dm) + \\sum_{m < x/D} \\mu(m) \\sum_{D < d \\leq x/m} (\\log d) f(dm).")]]

#text("If ")#mi("{D}")#text(" is sufficiently slowly growing, then by ")#link(<tao-b076d0643d8294e911d8>)[#text("(9)")]#text(" one has ")#mi("{ \\sum_{m \\leq x/d} \\mu(m) f(dm) = o(x)}")#text(" uniformly for all ")#mi("{d \\leq D}")#text(". If ")#mi("{D}")#text(" is sufficiently slowly growing, this implies that the first term in ")#link(<tao-799ef92a11af918e3fb7>)[#text("(12)")]#text(" is also ")#mi("{o(x)}")#text(". As for the second term, we dyadically decompose it and bound it in absolute value by ")#metadata(none) <tao-0d2397f8a178391e379d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\sum_{2^k < x/D} \\sum_{2^k \\leq m < 2^{k+1}} |\\sum_{D < d \\leq x/m} (\\log d) f(dm)|.")]]

#text("By summation by parts, we can bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{D < d \\leq x/m} (\\log d) f(dm)\\right| \\ll \\log(x/2^k) \\sup_{y \\leq x/2^k} \\left|\\sum_{n \\leq y} f(mn)\\right|", block: true)]]

#text("and so by ")#link(<tao-b5e509d769c77bd1fecf>)[#text("(10)")]#text(", we can bound ")#link(<tao-0d2397f8a178391e379d>)[#text("(13)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\ll \\sum_{2^k < x/D} \\frac{x}{\\log^{1+\\epsilon}(x/2^k)}.")]]

#text("This sum evaluates to ")#mi("{O( x / D^\\epsilon )}")#text(", and the claim follows since ")#mi("{D}")#text(" goes to infinity. ")#mi("\\Box")

#text("Note that the trivial bound on ")#link(<tao-b5e509d769c77bd1fecf>)[#text("(10)")]#text(" is ")#mi("{Mx}")#text(", so one needs to gain about two logarithmic factors over the trivial bound in order to use the above proposition. The presence of the supremum is annoying, but it can be removed by a modification of the argument if one improves the bound by an additional logarithm by a variety of methods (e.g. completion of sums), or by smoothing out the constraint ")#mi("{n \\leq x}")#text(". However, I do not know of a way to remove the need to improve the trivial bound by two logarithmic factors.")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/#comment-108803")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2011")])]

#text("Terry,")

#text("Interesting post. Proposition 3 interests me, in particular. There would seem to be some hope of using it to understand horocycle flows along the primes, because (9) can probably be obtained from Ratner’s theorem as B-S-Z do, whilst the stronger quantitative estimate (10) requires only an understanding of flows on ")#mi("G/\\Gamma = SL_2(R)/SL_2(Z)")#text(", and not on the product ")#mi("(G \\times G)/(\\Gamma \\times \\Gamma)")#text(". As I understand it, quite a lot is known in that setting.")

#text("Ben")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/#comment-108893")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2011")])]

#text("Yes, this does seem hopeful. Tammy just pointed me towards Theorem ")#strike[#text("4.5")]#text(" 4.11 of ")#link("http://arxiv.org/abs/1110.0777")[#text("this paper of Sarnak and Ubis")]#text(", in particular, which is analogous to our own polynomially quantitative Ratner-type theorem on nilmanifolds, which in principle (when combined with the Vinogradov lemma and Siegel-Walfisz) should indeed give something very close to (10). We’ll ask Peter whether he thinks this might work, as this is probably the quickest way to settle the question. :-)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/#comment-108904")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2011")])]

#text("Terry,")

#text("Yes indeed. My feeling is that one is in the game so long as it is not necessary to understand quantitative distribution results on $G/\\Gamma \\times G/\\Gamma$, which is beyond current techniques.")

#text("Ben")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/085ba48ce77dd6add57a2d13e0da619b6a00906753322fad675cd15808f5d80c-fab198fe9f9f2db850d5e24ac322a71b2cfb737f8683d107ee457b07f0ecece3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adrián Ubis")]], [#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/#comment-108909")[#strong[#text("Adrián Ubis")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2011")])]

#text("Dear Ben and Terence,")

#text("it is indeed possible to get (10) from my paper with Peter Sarnak,")#linebreak()#text(" but just for ")#mi("M<x^{1/4}")#text("! I think we could improve it a little, but the problem is that you need (10), as far as I can see, for any ")#mi("M,x")#text("; in particular, for ")#mi("M")#text(" larger than ")#mi("x")#text(" this seems to me out of reach of any method using just harmonic analysis on the modular surface.")

#text("In other words, you need essentially any level for type I sums, which is typically quite hard to get.")

#text("Best,")#linebreak()#text(" Adrian.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/#comment-108924")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2011")])]

#text("Ah, I see the difficulty now: to get effective equidistribution on the discrete horocycle orbits ")#mi("n \\mapsto \\xi h(s)^n")#text(" via the methods in your paper one needs a polynomial bound on s, which blocks one from getting the full range of (10). In contrast, when the equidistribution results of Ben and myself for nilflow orbits ")#mi("n \\mapsto g^n x")#text(", there is no bound required on g (and indeed there is a lifting trick of Furstenberg that lifts a nilflow with unbounded g to a higher-dimensional nilflow with bounded g), which is what allows one to get (10) with no bound on M. (And if one only has qualitative equidistribution on the Mobius side, there is no effective bound for M in terms of x.)")

#text("Still, the problem is at least reduced to a statement purely about quantitative equidistribution of horocycle flow, which, while still difficult, at least doesn’t have any primes in it…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/085ba48ce77dd6add57a2d13e0da619b6a00906753322fad675cd15808f5d80c-fab198fe9f9f2db850d5e24ac322a71b2cfb737f8683d107ee457b07f0ecece3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adrián Ubis")]], [#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/#comment-108930")[#strong[#text("Adrián Ubis")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2011")])]

#text("Exactly, that is the trouble. Anyway, as you both point, it is really nice that now one “only” needs to control the horocycle flow in the modular surface, instead of having to know either about products of the modular surface or about the primes themselves.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86146225fcfad58054440d08e37d519da83c448c9052553e429231be7dee3e96-d7ac745a462ea0935cfd4d1b7c24bf8a03fb903259069219487ca12496977424.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ewan Delanoy")]], [#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/#comment-110164")[#strong[#text("Ewan Delanoy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2011")])]

#text("Minor typo : at the very beginning of the post, “for some real number $p$” should be “for some real number $\\alpha$”. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b46266b6c9148ab5106c834424e9e88c99015ed4314bfced4acb6a658b37d4b0-80a75405fa7d0dc9b2fb26bb8e65a0c2323f33d9bf6b5d440a2d2a98f52ae6a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of js")]], [#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/#comment-146499")[#strong[#text("js")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2012")])]

#text("A remark on the derivation of proposition 1 : applying (a corollary of) Selberg’s version of the Bessel inequality (lemma 1.7 in Montgomery’s “Topics in multiplicative number theory”) to vectors $\\phi_p : n \\mapsto f(pn)$ and $\\xi = \\mu$ (with notations from the reference above), one immediately gets the result (once Turan-Kubilius is applied).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pzorin")]], [#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/#comment-152680")[#strong[#text("pzorin")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2012")])]

#text("It took me some time to figure out what js meant, so I will spell out his/her argument here. Lemma 1.7 from the reference says that for vectors ")#mi("\\xi,\\phi_{1}, \\dots, \\phi_{R}")#text(" in a Hilbert space one has")#linebreak()#text(" ")#tao-math("\\displaystyle \\sum_{r}\\left|( \\xi, \\phi_{r} )\\right| \\leq \\left\\|\\xi\\right\\| ( \\sum_{r,s}\\left|(\\phi_{r},\\phi_{s})\\right| )^{1/2}.", block: false)

#text("This is used to estimate")#linebreak()#text(" ")#tao-math("\\displaystyle \\left| \\sum_{p\\in P}\\sum_{m\\leq x/p} \\mu(m)f(pm) \\right| \\leq \\sum_{p\\in P} \\left| \\sum_{m\\leq x/W} \\mu(m) \\phi_{p}(m) \\right|,", block: false)#linebreak()#text(" where ")#mi("\\phi_{p}(m)=f(pm)1_{\\{m\\leq x/p\\}}(m)")#text(".")

#text("The lemma provides the estimate")#linebreak()#text(" ")#tao-math("\\displaystyle (x/W)^{1/2} ( \\sum_{p,q\\in P} \\left|\\sum_{m\\leq \\min(x/p,x/q)} f(pm)\\bar f(qm)\\right| )^{1/2},", block: false)#linebreak()#text(" and the hypothesis allows to bound this by")#linebreak()#text(" ")#mi("\\displaystyle (x/W)^{1/2} ( \\sum_{p\\neq q\\in P} o_{p,q}(\\min(x/p,x/q)) + O(xA) )^{1/2},")#linebreak()#text(" where the bound ")#mi("o_{p,q}")#text(" depends on p and q.")#linebreak()#text(" If H grows sufficiently slowly then the remaining sum is O(x) and this gives the estimate ")#mi("O(xA^{1/2}/W^{1/2}) = O(xA)")#text(" as required.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Chowla conjecture and the Sarnak conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/#comment-182161")[#strong[#text("The Chowla conjecture and the Sarnak conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2012")])]

#text("[…] control on the error terms than , in particular gains of some power of are usually needed. See this previous blog post for more discussion.) Remark 1 The Chowla conjecture resembles an assertion that, for chosen […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 6: A cheap version of the theorems of Halasz and Matomaki-Radziwill | What's new")]], [#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/#comment-452366")[#strong[#text("254A, Supplement 6: A cheap version of the theorems of Halasz and Matomaki-Radziwill | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2015")])]

#text("[…] a criterion of Katai and Bourgain-Sarnak-Ziegler for Möbius orthogonality estimates in this previous blog post. See also Section 5 of Notes 1 for some similar […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An averaged form of Chowla’s conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/#comment-453191")[#strong[#text("An averaged form of Chowla’s conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2015")])]

#text("[…] uniformly for all . For “major arc” , close to a rational for small , we can establish this bound from a generalisation of a recent result of Matomaki and Radziwill (discussed in this previous post) on averages of multiplicative functions in short intervals. For “minor arc” , we can proceed instead from an argument of Katai and Bourgain-Sarnak-Ziegler (discussed in this previous post). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Correlations of the von Mangoldt and higher divisor functions II. Divisor correlations in short ranges | What's new")]], [#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/#comment-490844")[#strong[#text("Correlations of the von Mangoldt and higher divisor functions II. Divisor correlations in short ranges | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2017")])]

#text("[…] functions, we used Plancherel’s theorem to estimate the global norm , and then also used the Katai-Bourgain-Sarnak-Ziegler orthogonality criterion to control local norms , where was a minor arc interval of length about , and these two estimates […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3205d8eeb9c554b4dd0cc3d073ee0fccb7caa8f5245405e7db9ef43dfd7e2b5-a4d99c4307912feff11c653ffa27243560eff8a237c725adfd34835995912cc1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A viewpoint on Katai’s orthogonality criterion | I Can't Believe It's Not Random!")]], [#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/#comment-503299")[#strong[#text("A viewpoint on Katai’s orthogonality criterion | I Can't Believe It's Not Random!")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2018")])]

#text("[…] to do so to keep the main idea more clear, one can find a good presentation of the full proof in Tao’s blog post on the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/#comment-686913")[#strong[#text("Peter Sarnak is Coming to Town – Let’s Celebrate it with a Post on Möbius Randomness , Computational Complexity, and AI | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2024")]

#text("[…] A special case of degree-2 polynomials is the Rudin-Shapiro sequence. I asked about this special case over MO and it was proved by Terry Tao . His solution relies on the Katai-Bourgain-Sarnak-Ziegler orthogonality criterion. […]")
]
