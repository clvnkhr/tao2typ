// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/09/04/254a-announcement-analytic-prime-number-theory-2/
// Converted to Typst by tao2typ: "2026-10-14T10:54:10.723231+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A announcement: Analytic prime number theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A announcement: Analytic prime number theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 September 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/09/04/254a-announcement-analytic-prime-number-theory-2/")[#text("https://terrytao.wordpress.com/2019/09/04/254a-announcement-analytic-prime-number-theory-2/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In the fall quarter (starting Sep 27) I will be teaching a ")#link("https://ccle.ucla.edu/course/view/19F-MATH254A-1")[#text("graduate course on analytic prime number theory")]#text(". This will be similar to ")#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/")[#text("a graduate course I taught in 2015")]#text(", and in particular will reuse several of the ")#link("https://terrytao.wordpress.com/category/teaching/254a-analytic-prime-number-theory/")[#text("lecture notes from that course")]#text(", though it will also incorporate some new material (and omit some material covered in the previous course, to compensate). I anticipate covering the following topics:")

#enum(start: 1, 
[#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Elementary multiplicative number theory")]],
[#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Complex-analytic multiplicative number theory")]],
[#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/")[#text("The entropy decrement argument")]],
[#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/")[#text("Bounds for exponential sums")]],
[#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/")[#text("Zero density theorems")]],
[#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/")[#text("Halasz’s theorem and the Matomaki-Radziwill theorem")]],
[#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/")[#text("The circle method")]],
[#text("(If time permits) Chowla’s conjecture and the Erdos discrepancy problem [Update: I did not end up writing notes on this topic.]")]
)

#text("Lecture notes for topics 3, 6, and 8 will be forthcoming.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/04/254a-announcement-analytic-prime-number-theory-2/#comment-521321")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2019")])]

#text("The new material (topics 3, 6, 8) seems to be really new (recent research material !)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/502df7f5ef7b18d9ffcdaaf31018351265ccc5085e2b86bc385aa5510b77b3d0-fa2e73a449ab510629ecf13fce3febeb0d7638221c3ea7cadc8a8d18a1034f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rafik zeraoulia")]], [#link("https://terrytao.wordpress.com/2019/09/04/254a-announcement-analytic-prime-number-theory-2/#comment-521324")[#strong[#text("rafik zeraoulia")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2019")])]

#text("Is there any link to follow your courses ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2009f587be401e228d6b38f6456c325a7b59c56fa4740e49f864ae5613f6cd77-81909f95b534c179dd7e35a85b347f8bed2744e4ba720706a50ceeabe4bdfa3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wesley")]], [#link("https://terrytao.wordpress.com/2019/09/04/254a-announcement-analytic-prime-number-theory-2/#comment-521329")[#strong[#text("Wesley")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2019")])]

#text("How can I enroll??")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2019/09/04/254a-announcement-analytic-prime-number-theory-2/#comment-521375")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2019")])]

#text("Is this separate from your higher-order Fourier analysis course?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d29702d65d0ab579bb44dfd81179fcdd86d3119f355e382de1573e052ae4aa9-db30d05ac674f9a61a36ce52ae4bad2d5dfb5a1a0af08b11686f6c773c748444.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steffen Yount")]], [#link("https://terrytao.wordpress.com/2019/09/04/254a-announcement-analytic-prime-number-theory-2/#comment-521915")[#strong[#text("Steffen Yount")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")])]

#text("This material is almost all stuff I’m really interested in!")

#text("I wish I could audit this course!")

#text("Is there any chance you could record the lectures and make the course publicly available online?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/197a19a49d7502b9d5023a58f4c0c634435866e17423947c290bc080e027d73e-6fd55a888bbbcc64664c430b99ddc32156ef09d79f141694a168a883b2c6acae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of U")]], [#link("https://terrytao.wordpress.com/2019/09/04/254a-announcement-analytic-prime-number-theory-2/#comment-522082")[#strong[#text("U")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2019")])]

#text("1. Why is the entropy decrement argument a topic to study?")

#text("2. Would Diophantine objects and discrepancy be covered?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/04/254a-announcement-analytic-prime-number-theory-2/#comment-522132")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2019")])]

#text("The entropy decrement argument can be used to establish a number of cases of (the logarithmically averaged version of) Chowla’s conjecture, particularly when combined with the Matomaki-Radziwill theorem and the circle method; but there are some more recent applications of the method that do not require these additional tools (for instance, my student has recently used this method to obtain a new proof of the prime number theorem), so I have decided to give it a separate set of notes (particularly since the use of that method requires a review of the Shannon entropy inequalities, which are rather separate from the other techniques in this set of notes.")

#text("I will not cover Diophantine approximation or discrepancy in these notes (and indeed will be omitting several other core topics in analytic number theory, notably sieve theory). Montgomery’s “Ten lectures in harmonic analysis” is still quite a good general reference for this subject.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4620d7fc3d915cd65b645f741e523fcacc48304af0a27888e0096835dc0a71a2-b72d6cf244299644aa43152c06c62081dbebb48c46ba7a402bc31a858e40d281.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grend")]], [#link("https://terrytao.wordpress.com/2019/09/04/254a-announcement-analytic-prime-number-theory-2/#comment-523240")[#strong[#text("Grend")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2019")])]

#text("How does the entropy decrement argument end up leading to a proof of the prime number theorem, roughly? Does it allow one to get around dealing with zero-free regions?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/704b81e58ca29743b47850bb62f82d988587af8aa950d2d86ccec5d2d2505f3a-ae78c7c51eb8b92e65e74b0790dfb510525c2923707a533c2fcc07a150e39602.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of plm")]], [#link("https://terrytao.wordpress.com/2019/09/04/254a-announcement-analytic-prime-number-theory-2/#comment-522885")[#strong[#text("plm")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2019")])]

#text("Dear Terence Tao, I hope you will finally decide to publish your analytic number theory notes -in the GSM series. I always thought they were some of your most valuable expository writings, especially because of the growing gap between the research front and textbook material on number theory -too often very introductory, elementary, and not presenting modern philosophies. Don’t hesitate to add even the most fleeting intuition, all the mental simplifications that guide experts but are scattered throughout litterature, if expressed at all. Thank you very much.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/320a618ef53c7c1b58cd60d2e39e12834d571c3ee06f1153970cdea61608cdc4-4ab92598afa3bd4a40d062a0dae8dc0fb8d4ef6280441e32dd192fcf0b23163b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan")]], [#link("https://terrytao.wordpress.com/2019/09/04/254a-announcement-analytic-prime-number-theory-2/#comment-595041")[#strong[#text("Ryan")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("Dear Terry,")

#text("were the notes for 3, 6, and 8 ever completed?")

#text("Warmly,")

#text("Ryan")

#emph[#text("[Links updated -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e60833ebbd45dfe89a67b82efc61fbcf40bcfe03c6c4745fb64f20ecc6133f4a-7635b029dc775a546cdb9a47875b0a64ddb55427dd5bf108f546a32d42b3c765.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grad Student")]], [#link("https://terrytao.wordpress.com/2019/09/04/254a-announcement-analytic-prime-number-theory-2/#comment-658162")[#strong[#text("Grad Student")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2022")])]

#text("Since there is no link on your current teaching… is the current quarter 254A material same as those in this post?")

#emph[#text("[I am using the same set of notes, but may cover a different subset of them than in previous instances of this course – T.]")]
]
