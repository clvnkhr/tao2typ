// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/
// Converted to Typst by tao2typ: "2026-10-14T11:06:42.983891+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Partially specified mathematical objects, ambient parameters, and asymptotic notation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Partially specified mathematical objects, ambient parameters, and asymptotic notation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 May 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/")[#text("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In orthodox first-order logic, variables and expressions are only allowed to take one value at a time; a variable ")#mi("{x}")#text(", for instance, is not allowed to equal ")#mi("{+3}")#text(" and ")#mi("{-3}")#text(" simultaneously. We will call such variables ")#emph[#text("completely specified")]#text(". If one really wants to deal with multiple values of objects simultaneously, one is encouraged to use the language of set theory and/or logical quantifiers to do so.")

#text("However, the ability to allow expressions to become only partially specified is undeniably convenient, and also rather intuitive. A classic example here is that of the ")#link("http://en.wikipedia.org/wiki/Quadratic_formula")[#text("quadratic formula")]#text(":")

#tao-aligned(keep: true)[


#tao-math("\\text{If } x,a,b,c  & \\in {\\bf R} \\text{ with } a \\neq 0, \\text{ then }", block: true)

#metadata(none) <tao-13dcdad13b695e3fb389>

#tao-math("ax^2+bx+c & =0 \\text{ if and only if } x = \\frac{-b \\pm \\sqrt{b^2-4ac}}{2a}.", block: true, numbering: n => [#text("(1)")])
]

#text("Strictly speaking, the expression ")#mi("{x = \\frac{-b \\pm \\sqrt{b^2-4ac}}{2a}}")#text(" is not well-formed according to the grammar of first-order logic; one should instead use something like")

#align(center)[#tao-fit-display[#mitex("x = \\frac{-b - \\sqrt{b^2-4ac}}{2a} \\text{ or } x = \\frac{-b + \\sqrt{b^2-4ac}}{2a}")]]

#text("or")

#align(center)[#tao-fit-display[#mitex("x \\in \\left\\{ \\frac{-b - \\sqrt{b^2-4ac}}{2a}, \\frac{-b + \\sqrt{b^2-4ac}}{2a} \\right\\}")]]

#text("or")

#align(center)[#tao-fit-display[#mitex("x = \\frac{-b + \\epsilon \\sqrt{b^2-4ac}}{2a} \\text{ for some } \\epsilon \\in \\{-1,+1\\}")]]

#text("in order to strictly adhere to this grammar. But none of these three reformulations are as compact or as conceptually clear as the original one. In a similar spirit, a mathematical English sentence such as")

#metadata(none) <tao-90e97eba84cce7000a54>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\text{The sum of two odd numbers is an even number}")]]

#text(" ")#text(" is also not a first-order sentence; one would instead have to write something like")

#metadata(none) <tao-2c7a7906bd7927953fab>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\text{For all odd numbers } x, y, \\text{ the number } x+y \\text{ is even}")]]

#text("or")

#metadata(none) <tao-9fb65b5a4be08d206e44>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\text{For all odd numbers } x,y \\text{ there exists an even number } z")]]

#align(center)[#tao-fit-display[#mitex("\\text{ such that } x+y=z")]]

#text("instead. These reformulations are not all that hard to decipher, but they do have the aesthetically displeasing effect of cluttering an argument with temporary variables such as ")#mi("{x,y,z}")#text(" which are used once and then discarded.")

#text("Another example of partially specified notation is the innocuous ")#mi("{\\ldots}")#text(" notation. For instance, the assertion")

#align(center)[#tao-fit-display[#mitex("\\pi=3.14\\ldots,")]]

#text("when written formally using first-order logic, would become something like")

#tao-aligned(keep: true)[


#tao-math("\\pi  & = 3 + \\frac{1}{10} + \\frac{4}{10^2} + \\sum_{n=3}^\\infty \\frac{a_n}{10^n} \\text{ for some sequence } (a_n)_{n=3}^\\infty", block: true)



#tao-math("\\text{ with } a_n  & \\in \\{0,1,2,3,4,5,6,7,8,9\\} \\text{ for all } n,", block: true)
]

#text("which is not exactly an elegant reformulation. Similarly with statements such as")

#align(center)[#tao-fit-display[#tao-math("\\tan x = x + \\frac{x^3}{3} + \\ldots \\text{ for } \\left|x\\right| < \\pi/2", block: true)]]

#text("or")

#align(center)[#tao-fit-display[#tao-math("\\tan x = x + \\frac{x^3}{3} + O(\\left|x\\right|^5) \\text{ for } \\left|x\\right| < \\pi/2.", block: true)]]

#text("Below the fold I’ll try to assign a formal meaning to partially specified expressions such as ")#link(<tao-13dcdad13b695e3fb389>)[#text("(1)")]#text(", for instance allowing one to condense ")#link(<tao-90e97eba84cce7000a54>)[#text("(2)")]#text(", ")#link(<tao-2c7a7906bd7927953fab>)[#text("(3)")]#text(", ")#link(<tao-9fb65b5a4be08d206e44>)[#text("(4)")]#text(" to just")

#align(center)[#tao-fit-display[#mitex("\\text{odd} + \\text{odd} = \\text{even}.")]]

#text("When combined with another common (but often implicit) extension of first-order logic, namely the ability to reason using ")#emph[#text("ambient parameters")]#text(", we become able to formally introduce ")#emph[#text("asymptotic notation")]#text(" such as the ")#link("https://en.wikipedia.org/wiki/Big_O_notation")[#text("big-O notation")]#text(" ")#mi("{O()}")#text(" or the little-o notation ")#mi("{o()}")#text(". We will explain how to do this at the end of this post.")

#metadata(none) <tao-cfb893b6b641d64ec8d2>

#heading(level: 1)[#strong[#text(" — 1. Partially specified objects — ")]]

#text("Let’s try to assign a formal meaning to partially specified mathematical expressions. We now allow expressions ")#mi("{X}")#text(" to not necessarily be a single (completely specified) mathematical object, but more generally a partially specified instance of a ")#link("https://en.wikipedia.org/wiki/Class_(set_theory)")[#text("class")]#text(" ")#mi("{\\{X\\}}")#text(" of mathematical objects. For instance, ")#mi("{\\pm 3}")#text(" denotes a partially specified instance of the class ")#mi("{\\{ \\pm 3 \\} = \\{ 3, -3\\}}")#text(" of numbers consisting of ")#mi("{3}")#text(" and ")#mi("{-3}")#text("; that is to say, a number which is either ")#mi("{-3}")#text(" and ")#mi("{+3}")#text(". A single completely specified mathematical object, such as the number ")#mi("{3}")#text(", can now be also interpreted as the (unique) instance of a class ")#mi("{\\{ 3 \\}}")#text(" consisting only of ")#mi("{3}")#text(". Here we are using set notation to describe classes, ignoring for now the well known issue from ")#link("http://en.wikipedia.org/wiki/Russell%27s_paradox")[#text("Russell’s paradox")]#text(" that some extremely large classes are technically not sets, as this is not the main focus of our discussion here.")

#text("For reasons that will become clearer later, we will use the symbol ")#mi("{==}")#text(" rather than ")#mi("{=}")#text(" to denote the assertion that two partially specified objects range across exactly the same class. That is to say, we use ")#mi("{X==Y}")#text(" as a synonym for ")#mi("{\\{X\\} = \\{Y\\}}")#text(". Thus, for instance, it is not the case that ")#mi("{3 == \\pm 3}")#text(", because the class ")#mi("{\\{\\pm 3\\}}")#text(" has instances that ")#mi("{\\{3\\}}")#text(" does not.")

#text("Any finite sequence ")#mi("{x_1,\\dots,x_n}")#text(" of objects can also be viewed as a partially specified instance of a class ")#mi("{\\{x_1,\\dots,x_n\\}}")#text(", which I will denote ")#mi("{x_1|\\dots|x_n}")#text(" in analogy with ")#link("https://en.wikipedia.org/wiki/Regular_expression")[#text("regular expressions")]#text(", thus we now also have a new name ")#mi("{\\{x_1|\\dots|x_n\\}}")#text(" for the set ")#mi("{\\{x_1,\\dots,x_n\\}}")#text(". (One could in fact propose ")#mi("{x_1,\\dots,x_n}")#text(" as the notation for ")#mi("{x_1|\\dots|x_n}")#text(", as is done implicitly in assertions such as “")#mi("{P(n)}")#text(" is true for ")#mi("{n=1,2,3}")#text("“, but this creates notational conflicts with other uses of the comma in mathematics, such as the notation ")#mi("{(x_1,\\dots,x_n)}")#text(" for an ")#mi("{n}")#text("-tuple, so I will use the regular expression symbol ")#mi("{|}")#text(" here to avoid ambiguity.) For instance, ")#mi("{1|3|5}")#text(" denotes an partially specified instance from the class ")#mi("{\\{1|3|5\\}=\\{1,3,5\\}}")#text(", that is to say a number which is either ")#mi("{1}")#text(", ")#mi("{3}")#text(", and ")#mi("{5}")#text(". Similarly, we have")

#align(center)[#tao-fit-display[#mitex("\\pm 3 == 3|-3 == -3|3")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("3 == 3|3.")]]

#text("One can mimic set builder notation and denote a partially specified instance of a class ")#mi("{{\\mathcal C}}")#text(" as ")#mi("{(x: x \\in {\\mathcal C})}")#text(" (or one can replace ")#mi("{x}")#text(" by any other variable name one pleases); similarly, one can use ")#mi("{(x \\in A: P(x))}")#text(" to denote a partially specified element of ")#mi("{A}")#text(" that obeys the predicate ")#mi("{P(x)}")#text(". Thus for instance")

#align(center)[#tao-fit-display[#mitex("(n \\in {\\bf Z}: n \\text{ odd})")]]

#text("would denote a partially specified odd number. By a slight abuse of notation, we can abbreviate ")#mi("{(x \\in A: P(x))}")#text(" as ")#mi("{(x: P(x))}")#text(" or simply ")#mi("{P}")#text(", if the domain ")#mi("{A}")#text(" of ")#mi("{x}")#text(" is implicitly understood from context. For instance, under this convention,")

#align(center)[#tao-fit-display[#mitex("\\text{odd} == (n \\in {\\bf Z}: n \\text{ odd} )")]]

#text("refers to an partially specified odd integer, while")

#align(center)[#tao-fit-display[#mitex("\\text{integer} == (n: n \\in {\\bf Z})")]]

#text("refers to a partially specified integer. Under these conventions, it now becomes theoretically possible that the class one is drawing from becomes empty, and instantiation becomes vacuous. For instance, with our conventions, ")#mi("{\\text{odd perfect}}")#text(" refers to a partially specified ")#link("https://en.wikipedia.org/wiki/Perfect_number#Odd_perfect_numbers")[#text("odd perfect number")]#text(", which is conjectured to not exist. As it turns out, our notation can handle instances of empty classes without difficulty (basically thanks to the concept of a ")#link("https://en.wikipedia.org/wiki/Vacuous_truth")[#text("vacuous truth")]#text("), but we will avoid dwelling on this edge case much here since this concept is not intuitive for beginners. (But if one does want to confront this possibility, one can use a symbol such as ")#mi("{\\perp}")#text(" to denote an instance of the empty class, i.e., an object that has no specifications whatsoever.")

#text("The symbol ")#mi("{|}")#text(" introduced above can now be extended to be a binary operation on partially specified objects, defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\{ x|y \\} == \\{x\\} \\cup \\{y\\}.")]]

#text("Thus for instance")

#align(center)[#tao-fit-display[#mitex("\\text{odd} | \\text{even} == \\text{integer}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("x \\pm y == (x+y) | (x-y).")]]

#text("One can then define other logical operations on partially specified objects if one wishes. For instance, we could define an “and” operator ")#mi("{\\&}")#text(" by defining")

#align(center)[#tao-fit-display[#mitex("\\{ x \\& y \\} == \\{x\\} \\cap \\{y\\}.")]]

#text("Thus for instance")

#tao-aligned(keep: true)[


#tao-math("(5 \\pm 3) \\& (10 \\pm 2)  & == 8,", block: true)



#tao-math("\\text{odd} \\& \\text{perfect}  & == \\text{odd perfect}", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\text{odd} \\& \\text{even} == \\perp.")]]

#text("(Here we are deviating from the syntax of regular expression, but I am not insisting that the entirety of mathematical notation conform to that syntax, and in any event regular expressions do not appear to have a direct analogue of this “and” operation.) We leave it to the reader to propose other logical operations on partially specified objects, though the “or” operator ")#mi("{|}")#text(" and the “and” operator ")#mi("{\\&}")#text(" will suffice for our purposes.")

#text("Any operation on completely specified mathematical objects ")#mi("{x}")#text(" can be extended to partially specified of mathematical objects ")#mi("{X}")#text(" by applying that operation to arbitrary instances of the class ")#mi("{\\{X\\}}")#text(", with the convention that if a class appears multiple times in an expression, then we allow each instance of that class to take different values. For instance, if ")#mi("{x, y}")#text(" are partially specified numbers, we can define ")#mi("{x+y}")#text(" to be the class of all numbers formed by adding an instance of ")#mi("{x}")#text(" to an instance of ")#mi("{y}")#text(" (this is analogous to the operation of ")#link("http://en.wikipedia.org/wiki/Minkowski_addition")[#text("Minkowski addition")]#text(" for sets, or ")#link("https://en.wikipedia.org/wiki/Interval_arithmetic")[#text("interval arithmetic")]#text(" in numerical analysis). For example,")

#align(center)[#tao-fit-display[#mitex("5 \\pm 3 == 5 + (\\pm 3) == 2| 8")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\pm 5 \\pm 3 == (\\pm 5) + (\\pm 3) == -8|-2| 2|8")]]

#text("(recall that there is no requirement that the signs here align). Note that")

#align(center)[#tao-fit-display[#mitex("(\\pm 3)^2 == 9")]]

#text("but that")

#align(center)[#tao-fit-display[#mitex("(\\pm 3) \\times (\\pm 3) == \\pm 9.")]]

#text("So we now see the first sign that some care has to be taken with the ")#link("https://en.wikipedia.org/wiki/First-order_logic#Equality_and_its_axioms")[#text("law of substitution")]#text("; we have")

#align(center)[#tao-fit-display[#mitex("x \\times x = x^2")]]

#text("but we do ")#emph[#text("not")]#text(" have")

#align(center)[#tao-fit-display[#mitex("(\\pm 3) \\times (\\pm 3) == (\\pm 3)^2.")]]

#text("However, the law of substitution works fine as long as the variable being substituted appears exactly once on both sides of the equation.")

#text("One can have an unbounded number of partially specified instances of a class, for instance ")#mi("{\\sum_{i=1}^n \\pm 1}")#text(" will be the class of all integers between ")#mi("{-n}")#text(" and ")#mi("{+n}")#text(" with the same parity as ")#mi("{n}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" When working with signs ")#mi("{\\pm}")#text(", one sometimes wishes to keep all signs aligned, with ")#mi("{\\mp}")#text(" denoting the sign opposite to ")#mi("{\\pm}")#text(", thus for instance with this notation one would have the geometric series formula")

#align(center)[#tao-fit-display[#mitex("(1 \\pm \\varepsilon)^{-1} = 1 \\mp \\varepsilon + \\varepsilon^2 \\mp \\varepsilon^3 \\dots")]]

#text("whenever ")#tao-math("{\\left|\\varepsilon\\right| < 1}", block: false)#text(". However, this notation is difficult to place in the framework used in this blog post without causing additional confusion, and as such we will not discuss it further here. (The syntax of ")#link("https://en.wikipedia.org/wiki/Regular_expression")[#text("regular expressions")]#text(" does have some tools for encoding this sort of alignment, but in first-order logic we also have the perfectly servicable tool of named variables and quantifiers (or plain old ")#link("https://terrytao.wordpress.com/advice-on-writing-papers/take-advantage-of-the-english-language/")[#text("mathematical English")]#text(") to do so also.)")
]

#text("One can also extend binary relations, such as ")#mi("{<}")#text(" or ")#mi("{=}")#text(", to partially specified objects, by requiring that ")#emph[#text("every")]#text(" instance on the left-hand side of the relation relates to ")#emph[#text("some")]#text(" instance on the right-hand side (thus binary relations become ")#link("http://en.wikipedia.org/wiki/Arithmetical_hierarchy")[#mi("{\\Pi_2}")#text(" sentences")]#text("). Again, if class is instantiated multiple times, we allow different appearances to correspond to different classes. For instance, the statement ")#mi("{5 \\pm 3 \\leq 8}")#text(" is true, because every instance of ")#mi("{5 \\pm 3}")#text(" is less than or equal to ")#mi("{8}")#text(":")

#align(center)[#tao-fit-display[#mitex("5 \\pm 3 == (2|8) \\leq 8.")]]

#text("But the statement ")#mi("{5 \\pm 3 \\leq 6}")#text(" is false. Similarly, the statement ")#mi("{8 = 5 \\pm 3}")#text(" is true, because ")#mi("{8}")#text(" is an instance of ")#mi("{5 \\pm 3}")#text(":")

#align(center)[#tao-fit-display[#mitex("8 = (2|8) == 5 \\pm 3.")]]

#text("The statement ")#mi("{5 \\pm 3 < 6 \\pm 3}")#text(" is also true, because every instance of ")#mi("{5 \\pm 3}")#text(" is less than some instance of ")#mi("{6 \\pm 3}")#text(":")

#align(center)[#tao-fit-display[#mitex("5 \\pm 3 == (2|8) < (3|9) == 6 \\pm 3.")]]

#text("The relationship between a partially specified representative ")#mi("{x_1|\\dots|x_n}")#text(" of a class ")#mi("{\\{x_1|\\dots|x_n\\}}")#text(" can then be summarised as")

#align(center)[#tao-fit-display[#mitex("x_1|\\dots|x_n \\in \\{x_1|\\dots|x_n\\} = \\{x_1,\\dots,x_n\\}.")]]

#text("Note how this convention treats the left-hand side and right-hand side of a relation involving partially specified expressions asymmetrically. In particular, for partially specified expressions ")#mi("{x, y}")#text(", the relation ")#mi("{x=y}")#text(" is no longer equivalent to ")#mi("{y=x}")#text("; the former states that every instance of ")#mi("{x}")#text(" is also an instance of ")#mi("{y}")#text(", while the latter asserts the converse. For instance, ")#mi("{3 = \\pm 3}")#text(" is a true statement, but ")#mi("{\\pm 3 = 3}")#text(" is a false statement (much as “")#mi("{3}")#text(" is prime” is a true statement (or “")#mi("{3 = \\text{prime}}")#text(" in our notation), but “primes are ")#mi("{3}")#text("” (or ")#mi("{\\text{prime} = 3}")#text(" in our notation) is false). In particular, we see a distinction between equality ")#mi("{=}")#text(" and equivalence ")#mi("{==}")#text("; indeed, ")#mi("{x == y}")#text(" holds if and only if ")#mi("{x=y}")#text(" ")#emph[#text("and")]#text(" ")#mi("{y=x}")#text(". On the other hand, as can be easily checked, the following three basic laws of mathematics remain valid for partially specified expressions ")#mi("{x,y,z}")#text(":")

#list(
[#text("(i) (Reflexivity) ")#mi("{x=x}")#text(".")],
[#text("(ii) (Transitivity) If ")#mi("{x = y}")#text(" and ")#mi("{y = z}")#text(", then ")#mi("{x=z}")#text(". Similarly, if ")#mi("{x < y}")#text(" and ")#mi("{y < z}")#text(", then ")#mi("{x < z}")#text(", etc..")],
[#text("(iii) (Substitution) If ")#mi("{x = y}")#text(", then ")#mi("{f(x) = f(y)}")#text(" for any function ")#mi("{f}")#text(". Similarly, if ")#mi("{x \\leq y}")#text(", then ")#mi("{f(x) \\leq f(y)}")#text(" for any monotone function ")#mi("{f}")#text(", etc..")]
)

#text("These conventions for partially specified expressions align well with informal mathematical English. For instance, as discussed in the introduction, the assertion")

#align(center)[#tao-fit-display[#mitex("\\text{The sum of two odd numbers is an even number}")]]

#text("can now be expressed as")

#align(center)[#tao-fit-display[#mitex("\\text{odd} + \\text{odd} = \\text{even}.")]]

#text("Similarly, the even ")#link("http://en.wikipedia.org/wiki/Goldbach%27s_conjecture")[#text("Goldbach’s conjecture")]#text(" can now be stated as")

#align(center)[#tao-fit-display[#mitex("\\text{even number} \\& (\\text{greater than } 2) = \\text{prime} + \\text{prime},")]]

#text("while the ")#link("http://en.wikipedia.org/wiki/Archimedean_property")[#text("Archimedean property")]#text(" of the reals can be reformulated as the assertion that")

#align(center)[#tao-fit-display[#mitex("\\text{real} \\leq \\text{natural number} \\times \\varepsilon")]]

#text("for any ")#mi("{\\varepsilon > 0}")#text(". Note also how the equality symbol ")#mi("{=}")#text(" for partially specified expressions corresponds well with the multiple meanings of the word “is” in English (consider for instance “two plus two is four”, “four is even”, and “the sum of two odd numbers is even”); the set-theoretic counterpart of this concept would be a sort of amalgam of the ordinary equality relation ")#mi("{=}")#text(", the inclusion relation ")#mi("{\\in}")#text(", and the subset relation ")#mi("{\\subset}")#text(".")

#text("There are however a number of caveats one has to keep in mind, though, when dealing with formulas involving partially specified objects. The first, which has already been mentioned, is a lack of symmetry: ")#mi("{x=y}")#text(" does not imply ")#mi("{y=x}")#text("; similarly, ")#mi("{x<y}")#text(" does not imply ")#mi("{y>x}")#text(". The second is that negation behaves very strangely, so much so that one should basically avoid using partially specified notation for any sentence that will eventually get negated. For instance, observe that the statements ")#mi("{3 = \\pm 3}")#text(" and ")#mi("{3 \\neq \\pm 3}")#text(" are both true, while ")#mi("{\\pm 3 = 3}")#text(" and ")#mi("{\\pm 3 \\neq 3}")#text(" are both false. In fact, the negation of such statements as ")#mi("{x=y}")#text(" or ")#mi("{x \\leq y}")#text(" involving partially specified objects usually cannot be expressed succinctly in partially specified notation, and one must resort to using several quantifiers instead. (In the language of the ")#link("https://en.wikipedia.org/wiki/Arithmetical_hierarchy")[#text("arithmetic hierarchy")]#text(", the negation of a ")#mi("{\\Pi_2}")#text(" sentence is a ")#mi("{\\Sigma_2}")#text(" sentence, rather than an another ")#mi("{\\Pi_2}")#text(" sentence.)")

#text("Another subtlety, already mentioned earlier, arises from our choice to allow different instantiations of the same class to refer to different instances, namely that the law of ")#link("https://en.wikipedia.org/wiki/Universal_instantiation")[#text("universal instantiation")]#text(" does not always work if the symbol being instantiated occurs more than once on the left-hand side. For instance, the identity")

#align(center)[#tao-fit-display[#mitex("x - x = 0")]]

#text("is of course true for all real numbers ")#mi("{x}")#text(", but if one naively substitutes in the partially specified expression ")#mi("{\\pm 1}")#text(" for ")#mi("{x}")#text(" one obtains the claim")

#align(center)[#tao-fit-display[#mitex("\\pm 1 - (\\pm 1) = 0")]]

#text("which is a false statement under our conventions (because the two instances of the sign ")#mi("{\\pm 1, \\pm 1}")#text(" do not have to match). However, there is no problem with repeated instantiations on the right-hand side, as long as there is at most a single instance on the left-hand side. For instance, starting with the identity")

#align(center)[#tao-fit-display[#mitex("x = 2x - x")]]

#text("we can validly instantiate the partially specified expression ")#mi("{\\pm 1}")#text(" for ")#mi("{x}")#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("\\pm 1 = 2(\\pm 1) - (\\pm 1).")]]

#text("A common practice that helps avoid these sorts of issues is to keep the partially specified quantities on the ")#emph[#text("right-hand side")]#text(" of one’s relations, or if one is working with a chain of relations such as ")#mi("{x \\leq y \\leq z \\leq w}")#text(", to keep the partially specified quantities away from the left-most side (so that ")#mi("{y}")#text(", ")#mi("{z}")#text(", and ")#mi("{w}")#text(" are allowed to be multi-valued, but not ")#mi("{x}")#text("). This doesn’t automatically prevent all issues (for instance, one may still be tempted to “cancel” an expression such as ")#mi("{\\pm 1 - (\\pm 1)}")#text(" that might arise partway through a chain of relations), but it can reduce the chance of accidentally making an error.")

#text("One can of course translate any formula that involves partially specified objects into a more orthodox first-order logic sentence by inserting the relevant quantifiers in the appropriate places – but note that the variables used in quantifiers are always completely specified, rather than partially specified. For instance, if one expands “")#mi("{x = \\pm y}")#text("” (for some completely specified quantities ")#mi("{x,y}")#text(") as “there exists ")#mi("{\\epsilon = \\pm 1}")#text(" such that ")#mi("{x = \\epsilon y}")#text("“, the quantity ")#mi("{\\epsilon}")#text(" is completely specified; it is not the partially specified ")#mi("{\\pm 1}")#text(". (If ")#mi("{x}")#text(" or ")#mi("{y}")#text(" were also partially specified, the first-order translation of the expression “")#mi("{x = \\pm y}")#text("” would be more complicated, as it would need more quantifiers.)")

#text("One can combine partially specified notation with set builder notation, for instance the set ")#mi("{\\{ x \\in {\\bf R}: x = \\pm 10 \\pm 1 \\}}")#text(" is just the four-element set ")#mi("{\\{ -11, -9, +9, +11\\}}")#text(", since these are indeed the four real numbers ")#mi("{x}")#text(" for which the formula ")#mi("{x = \\pm 10 \\pm 1}")#text(" is true. I would however avoid combining particularly heavy uses of set-theoretic notation with partially specified notation, as it may cause confusion.")

#text("Our examples above of partially specified objects have been drawn from number systems, but one can use this notation for other classes of objects as well. For instance, within the class of functions ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" from the reals to themselves, one can make assertions like")

#align(center)[#tao-fit-display[#mitex("\\text{increasing} + \\text{increasing} == \\text{increasing}")]]

#text("where ")#mi("{\\text{increasing}}")#text(" is the class of monotone increasing functions; similarly we have")

#tao-aligned(keep: false)[


#tao-math("- \\text{increasing}  & == \\text{decreasing}", block: true)



#tao-math("\\text{increasing} | \\text{decreasing}  & == \\text{monotone}", block: true)



#tao-math("\\text{positive increasing} \\cdot \\text{negative increasing}  & = \\text{negative decreasing}", block: true)



#tao-math("\\text{bounded} \\& \\text{monotone}  & = \\text{converges at infinity}", block: true)



#tao-math("\\text{analytic}  & = \\text{smooth} = \\text{differentiable} = \\text{continuous} = \\text{measurable}", block: true)



#tao-math("\\text{continuous} / \\text{continuous nonvanishing}  & = \\text{continuous}", block: true)



#tao-math("\\text{square integrable} \\cdot \\text{square integrable}  & == \\text{absolutely integrable}", block: true)



#tao-math("{\\mathcal F} \\text{square integrable}  & == \\text{square integrable}", block: true)
]

#text("(with ")#mi("{{\\mathcal F}}")#text(" denoting the Fourier transform) and so forth. Or, in the class of topological spaces, we have for instance")

#tao-aligned(keep: true)[


#tao-math("\\text{compact} \\& \\text{discrete}  & == \\text{finite},", block: true)



#tao-math("\\text{continuous}(\\text{compact})  & = \\text{compact},", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\pi_1( \\text{simply connected} ) = \\text{trivial group}")]]

#text("while conversely the ")#link("https://en.wikipedia.org/wiki/Classifying_space")[#text("classifying space construction")]#text(" gives (among other things)")

#align(center)[#tao-fit-display[#mitex("\\text{group} == \\pi_1( \\text{topological space} ).")]]

#text("Restricting to metric spaces, we have the well known equivalences")

#align(center)[#tao-fit-display[#mitex("\\text{compact} == \\text{sequentially compact} == \\text{complete} \\& \\text{totally bounded}.")]]

#text("Note in the last few examples, we are genuinely working with ")#link("https://en.wikipedia.org/wiki/Class_(set_theory)")[#text("proper classes")]#text(" now, rather than sets. As the above examples hopefully demonstrate, mathematical sentences involving partially specified objects can align very well with the syntax of informal mathematical English, as long as one takes care to distinguish the asymmetric equality relation ")#mi("{=}")#text(" from the symmetric equivalence relation ")#mi("{==}")#text(".")

#text("As an example of how such notation might be integrated into an actual mathematical argument, we prove a simple and well known topological result in this notation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" Let ")#mi("{f: X \\rightarrow Y}")#text(" be a continuous bijection from a compact space ")#mi("{X}")#text(" to a Hausdorff space ")#mi("{Y}")#text(". Then ")#mi("{f}")#text(" is a homeomorphism.")
]

#emph[#text("Proof:")]#text(" We have")

#tao-aligned(keep: true)[


#tao-math("f( \\text{open subset of }X)  & = f(X \\backslash \\text{closed subset of } X)", block: true)



#tao-math(" & = Y \\backslash f(\\text{closed subset of } X)", block: true)
]

#text("(since ")#mi("{f}")#text(" is a bijection)")

#align(center)[#tao-fit-display[#mitex("= Y \\backslash f(\\text{compact subset of } X)")]]

#text("(since ")#mi("{X}")#text(" is compact)")

#align(center)[#tao-fit-display[#mitex("= Y \\backslash (\\text{compact subset of } Y)")]]

#text("(since ")#mi("{f}")#text(" is continuous)")

#align(center)[#tao-fit-display[#mitex("= Y \\backslash (\\text{closed subset of } Y)")]]

#text("(since ")#mi("{Y}")#text(" is Hausdorff)")

#align(center)[#tao-fit-display[#mitex("= \\text{open subset of } Y.")]]

#text("Thus ")#mi("{f}")#text(" is open, hence ")#mi("{f^{-1}}")#text(" is continuous. Since ")#mi("{f}")#text(" was already continuous, ")#mi("{f}")#text(" is a homeomorphism. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 2. Working with parameters — ")]]

#text("In order to introduce asymptotic notation, we will need to combine the above conventions for partially specified objects with separate common adjustment to the grammar of mathematical logic, namely the ability to work with ambient parameters. This is a special case of the more general situation of interpreting logic over an ")#link("https://en.wikipedia.org/wiki/Topos#Elementary_topoi_(topoi_in_logic)")[#text("elementary topos")]#text(", but we will not develop the general theory of topoi here. As this adjustment is orthogonal to the adjustments in the preceding section, we shall for simplicity revert back temporarily to the traditional notational conventions for completely specified objects, and not refer to partially specified objects at all in this section.")

#text("In the formal language of ")#link("http://en.wikipedia.org/wiki/First-order_logic")[#text("first-order logic")]#text(", variables such as ")#mi("{x,n,X}")#text(" are understood to range in various ")#link("https://en.wikipedia.org/wiki/Domain_of_discourse")[#text("domains of discourse")]#text(" (e.g., ")#mi("{x}")#text(" could range in the real numbers, ")#mi("{n}")#text(" could range in the natural numbers, and ")#mi("{X}")#text(" in the class of sets). One can then construct ")#link("https://en.wikipedia.org/wiki/Formula_(mathematical_logic)")[#text("various formulas")]#text(", such as ")#mi("{P(x,n,X)}")#text(", in which involve zero or more input variables (known as ")#emph[#text("free variables")]#text("), and have a truth value in ")#mi("{\\{ \\text{true}, \\text{false} \\}}")#text(" for any given choice of free variables. For instance, ")#mi("{P(x,n,X)}")#text(" might be true for some triples ")#mi("{x \\in {\\bf R}, n \\in {\\bf N}, X \\in \\mathrm{Set}}")#text(", and false for others. One can create formulas either by applying relations to various terms (e.g., applying the inequality relation ")#mi("{\\leq}")#text(" to the terms ")#mi("{x+y, z+w}")#text(" gives the formula ")#mi("{x+y \\leq z+w}")#text(" with free variables ")#mi("{x,y,z,w}")#text("), or by combining existing formulas together with logical connectives (such as ")#mi("{\\wedge, \\vee, \\not, \\implies}")#text(") or quantifiers (")#mi("{\\forall}")#text(" and ")#mi("{\\exists}")#text("). Formulas with no free variables (e.g. ")#mi("{\\forall x \\forall y: x+y=y+x}")#text(") are known as ")#link("https://en.wikipedia.org/wiki/Sentence_(mathematical_logic)")[#text("sentences")]#text("; once one fixes the domains of discourse, sentences are either true or false. We will refer to this first-order logic as ")#emph[#text("orthodox first-order logic")]#text(", to distinguish it from the parameterised first-order logic we shall shortly introduce.")

#text("We now generalise this setup by working relative to some ambient set of ")#emph[#text("parameters")]#text(" – some finite collection of variables that range in some specified sets (or classes) and may be subject to one or more constraints. For instance, one may be working with some natural number parameters ")#mi("{n,N \\in {\\bf N}}")#text(" with the constraint ")#mi("{n \\leq N}")#text("; we will keep this particular choice of parameters as a running example for the discussion below. Once one selects these parameters, all other variables under consideration are not just single elements of a given domain of discourse, but rather a ")#emph[#text("family")]#text(" of such elements, parameterised by the given parameters; we will refer to these variables as ")#emph[#text("parameterised variables")]#text(" to distinguish them from the orthodox variables of first-order logic. For instance, with the above parameters, when one refers to a real number ")#mi("{x}")#text(", one now refers not just to a single element of ")#mi("{{\\bf R}}")#text(", but rather to a function ")#mi("{x: (n,N) \\mapsto x(n,N)}")#text(" that assigns a real number ")#mi("{x(n,N)}")#text(" to each choice of parameters ")#mi("{(n,N)}")#text("; we will refer to such a function ")#mi("{x: (n,N) \\mapsto x(n,N)}")#text(" as a ")#emph[#text("parameterised real")]#text(", and often write ")#mi("{x = x(n,N)}")#text(" to indicate the dependence on parameters. Each of the ambient parameters can of course be viewed as a parameterised variable, thus for instance ")#mi("{n}")#text(" can (by abuse of notation) be viewed as the parameterised natural number that maps ")#mi("{(n,N)}")#text(" to ")#mi("{n}")#text(" for each choice ")#mi("{(n,N)}")#text(" of parameters.")

#text("The specific ambient set of parameters, and the constraints on them, tends to vary as one progresses through various stages of a mathematical argument, with these changes being announced by various standard phrases in mathematical English. For instance, if at some point a proof contains a sentence such as “Let ")#mi("{N}")#text(" be a natural number”, then one is implicitly adding ")#mi("{N}")#text(" to the set of parameters; if one later states “Let ")#mi("{n}")#text(" be a natural number such that ")#mi("{n \\leq N}")#text("“, then one is implicitly also adding ")#mi("{n}")#text(" to the set of parameters and imposing a new constraint ")#mi("{n \\leq N}")#text(". If one divides into cases, e.g., “Suppose now that ")#mi("{n}")#text(" is odd… now suppose instead that ")#mi("{n}")#text(" is even”, then the constraint that ")#mi("{n}")#text(" is odd is temporarily imposed, then replaced with the complementary constraint that ")#mi("{n}")#text(" is even, then presumably the two cases are combined and the constraint is removed completely. A bit more subtly, parameters can disappear at the conclusion of a portion of an argument (e.g., at the end of a proof of a lemma or proposition in which the parameter was introduced), replaced instead by a summary statement (e.g., “To summarise, we have shown that whenever ")#mi("{n,N}")#text(" are natural numbers with ")#mi("{n \\leq N}")#text(", then …”) or by the statement of the lemma or proposition in whose proof the parameter was temporarily introduced. One can also remove a variable from the set of parameters by specialising it to a specific value.")

#text("Any term that is well-defined for individual elements of a domain, is also well-defined for parameterised elements of the domain by pointwise evaluation. For instance, if ")#mi("{x = x(n,N)}")#text(" and ")#mi("{y = y(n,N)}")#text(" are parameterised real numbers, one can form the sum ")#mi("{x+y = (x+y)(n,N)}")#text(", which is another parameterised real number, by the formula")

#align(center)[#tao-fit-display[#mitex("(x+y)(n,N) := x(n,N) + y(n,N).")]]

#text("Given a relation between terms involving parameterised variables, we will interpret the relation as being true (for the given choice of parameterised variables) if it holds for ")#emph[#text("all")]#text(" available choices of parameters ")#mi("{(n,N)}")#text(" (obeying all ambient constraints), and false otherwise (i.e., if it fails for at least one choice of parameters). For instance, the relation")

#align(center)[#tao-fit-display[#mitex("x \\leq y")]]

#text("would be interpreted as true if one has ")#mi("{x(n,N) \\leq y(n,N)}")#text(" for all choice of parameters ")#mi("{(n,N)}")#text(", and false otherwise.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" In the framework of ")#link("https://en.wikipedia.org/wiki/Non-standard_analysis")[#text("nonstandard analysis")]#text(", the interpretation of truth is slightly different; the above relation would be considered true if the set of parameters for which the relation holds lies in a given (non-principal) ")#link("https://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilter")]#text(". The main reason for doing this is that it allows for a significantly more general transfer principle than the one available in this setup; however we will not discuss the nonstandard analysis framework further here. (Our setup here is closer in spirit to the “cheap” version of nonstandard analysis discussed in ")#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/")[#text("this previous post")]#text(".)")
]

#text("With this convention an annoying subtlety emerges with regard to boolean connectives (conjunction ")#mi("{\\wedge}")#text(", disjunction ")#mi("{\\vee}")#text(", implication ")#mi("{\\implies}")#text(", and negation ")#mi("{\\neg}")#text("), in that one now has to distinguish between ")#emph[#text("internal")]#text(" interpretation of the connectives (applying the connectives pointwise for each choice of parameters before quantifying over parameters), and ")#emph[#text("external")]#text(" interpretation (applying the connectives after quantifying over parameters); there is not a general ")#link("https://en.wikipedia.org/wiki/Transfer_principle")[#text("transfer principle")]#text(" from the former to the latter. For instance, the sentence")

#align(center)[#tao-fit-display[#mitex("n \\text{ is odd}")]]

#text("is false in parameterised logic, since not every choice of parameter ")#mi("{n}")#text(" is odd. On the other hand, the internal negation")

#align(center)[#tao-fit-display[#mitex("\\neg( n \\text{ is odd})")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("n \\text{ is even}")]]

#text("is also false in parameterised logic, since not every choice of parameter ")#mi("{n}")#text(" is even. To put it another way, the internal disjunction")

#align(center)[#tao-fit-display[#mitex("(n \\text{ is odd}) \\vee (n \\text{ is even})")]]

#text("is true in parameterised logic, but the individual statements ")#mi("{n \\text{ is odd}}")#text(" and ")#mi("{n \\text{ is even}}")#text(" are not (so the ")#emph[#text("external")]#text(" disjunction of these statements is false). To maintain this distinction, I will reserve the boolean symbols (")#mi("{\\vee, \\wedge, \\implies, \\neg}")#text(") for internal boolean connectives, and reserve the corresponding English connectives (“and”, “or”, “implies”, “not”) for external boolean connectives.")

#text("Because of this subtlety, orthodox dichotomies and trichotomies do not automatically transfer over to the parameterised setting. In the orthodox natural numbers, a natural number ")#mi("{n}")#text(" is either odd or even; but a parameterised natural number ")#mi("{n}")#text(" could be neither even all the time nor odd all the time. Similarly, given two parameterised real numbers ")#mi("{x,y}")#text(", it could be that none of the statements ")#mi("{x<y}")#text(", ")#mi("{x=y}")#text(", ")#mi("{x>y}")#text(" are true all the time. However, one can recover these dichotomies or trichotomies by subdividing the parameter space into cases. For instance, in the latter example, one could divide the parameter space into three regions, one where ")#mi("{x<y}")#text(" is always true, one where ")#mi("{x=y}")#text(" is always true, and one where ")#mi("{x>y}")#text(" is always true. If one can prove a single statement in all three subregions of parameter space, then of course this implies the statement in the original parameter space. So in practice one can still use dichotomies and trichotomies in parameterised logic, so long as one is willing to subdivide the parameter space into cases at various stages of the argument and recombine them later.")

#text("There is a similar distinction between internal quantification (quantifying over orthodox variables before quantifying over parameters), and external quantification (quantifying over parameterised variables after quantifying over parameters); we will again maintain this distinction by reserving the symbols ")#mi("{\\forall, \\exists}")#text(" for internal quantification and the English phrases “for all” and “there exists” for external quantification. For instance, the assertion")

#align(center)[#tao-fit-display[#mitex("x+y = y+x \\text{ for all } x, y \\in {\\bf R}")]]

#text("when interpreted in parameterised logic, means that for all parameterised reals ")#mi("{x: (n,N) \\mapsto x(n,N)}")#text(" and ")#mi("{y: (n,N) \\mapsto y(n,N)}")#text(", the assertion ")#mi("{x(n,N)+ y(n,N) = y(n,N) + x(n,N)}")#text(" holds for all ")#mi("{n,N}")#text(". In this case it is clear that this assertion is true and is in fact equivalent to the orthodox sentence ")#mi("{\\forall x,y \\in {\\bf R}: x+y = y+x}")#text(". More generally, we do have a restricted transfer principle in that any true sentence in orthodox logic that involves only quantifiers and no boolean connectives, will transfer over to parameterised logic (at least if one is willing to use the axiom of choice freely, which we will do in this post). We illustrate this (somewhat arbitrarily) with the ")#link("https://en.wikipedia.org/wiki/Lagrange%27s_four-square_theorem")[#text("Lagrange four square theorem")]

#metadata(none) <tao-07026a4df5486d62e512>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\forall m \\in {\\bf N} \\exists a,b,c,d \\in {\\bf N}: m = a^2+b^2+c^2+d^2.")]]

#text("This sentence, true in orthodox logic, implies the parameterised assertion that for every parameterised natural number ")#mi("{m: (n,N) \\mapsto m(n,N)}")#text(", there exist parameterised natural numbers ")#mi("{a: (n,N) \\mapsto a(n,N)}")#text(", ")#mi("{b: (n,N) \\mapsto b(n,N)}")#text(", ")#mi("{c: (n,N) \\mapsto c(n,N)}")#text(", ")#mi("{d: (n,N) \\mapsto d(n,N)}")#text(", such that ")#mi("{m(n,N) = a(n,N)^2 + b(n,N)^2 + c(n,N)^2 + d(n,N)^2}")#text(" for all choice of parameters ")#mi("{(n,N)}")#text(". To see this, we can ")#link("https://en.wikipedia.org/wiki/Skolem_normal_form")[#text("Skolemise")]#text(" the four-square theorem ")#link(<tao-07026a4df5486d62e512>)[#text("(5)")]#text(" to obtain functions ")#mi("{\\tilde a: m \\mapsto \\tilde a(m)}")#text(", ")#mi("{\\tilde b: m \\mapsto \\tilde b(m)}")#text(", ")#mi("{\\tilde c: m \\mapsto \\tilde c(m)}")#text(", ")#mi("{\\tilde d: m \\mapsto \\tilde d(m)}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("m = \\tilde a(m)^2 + \\tilde b(m)^2 + \\tilde c(m)^2 + \\tilde d(m)^2")]]

#text("for all orthodox natural numbers ")#mi("{m}")#text(". Then to obtain the parameterised claim, one simply sets ")#mi("{a(n,N) := \\tilde a(m(n,N))}")#text(", ")#mi("{b(n,N) := \\tilde b(m(n,N))}")#text(", ")#mi("{c(n,N) := \\tilde c(m(n,N))}")#text(", and ")#mi("{d(n,N) := \\tilde d(m(n,N))}")#text(". Similarly for other sentences that avoid boolean connectives. (There are some further classes of sentences that use boolean connectives in a restricted fashion that can also be transferred, but we will not attempt to give a complete classification of such classes here; in general it is better to work out some examples of transfer by hand to see what can be safely transferred and which ones cannot.)")

#text("So far this setup is not significantly increasing the expressiveness of one’s language, because any statement constructed so far in parameterised logic can be quickly translated to an equivalent (and only slightly longer) statement in orthodox logic. However, one gains more expressive power when one allows one or more of the parameterised variables to have a specified type of dependence on the parameters, and in particular depending only on a subset of the parameters. For instance, one could introduce a real number ")#mi("{C}")#text(" which is an ")#emph[#text("absolute constant")]#text(" in the sense that it does not depend on either of the parameters ")#mi("{n,N}")#text("; these are a special type of parameterised real, in much the same way that constant functions are a special type of function. Or one could consider a parameterised real ")#mi("{a = a(N)}")#text(" that depends on ")#mi("{N}")#text(" but not on ")#mi("{n}")#text(", or a parameterised real ")#mi("{b = b(n)}")#text(" that depends on ")#mi("{n}")#text(" but not on ")#mi("{N}")#text(". (One could also place other types of constraints on parameterised quantities, such as continuous or measurable dependence on the parameters, but we will not consider these variants here.)")

#text("By quantifying over these restricted classes of parameterised functions, one can now efficiently write down a variety of statements in parameterised logic, of types that actually occur quite frequently in analysis. For instance, we can define a parameterised real ")#mi("{x = x(n,N)}")#text(" to be bounded if there exists an absolute constant ")#mi("{C}")#text(" such that ")#tao-math("{\\left|x\\right| \\leq C}", block: false)#text("; one can of course write this assertion equivalently in orthodox logic as")

#align(center)[#tao-fit-display[#tao-math("\\exists C \\forall n,N: ((n \\leq N) \\implies (\\left|x(n,N)\\right| \\leq C).", block: true)]]

#text("One can also define the stronger notion of ")#mi("{x}")#text(" being ")#emph[#mi("{1}")#text("-bounded")]#text(", by which we mean ")#tao-math("{\\left|x\\right| \\leq 1}", block: false)#text(", or in orthodox logic")

#align(center)[#tao-fit-display[#tao-math("\\forall n,N: ((n \\leq N) \\implies (\\left|x(n,N)\\right| \\leq 1).", block: true)]]

#text("In the opposite direction, we can assert the weaker statement that ")#mi("{x = x(n,N)}")#text(" is bounded in magnitude by a quantity ")#mi("{C = C(N)}")#text(" that depends on ")#mi("{N}")#text(" but not on ")#mi("{n}")#text("; in orthodox logic this becomes")

#align(center)[#tao-fit-display[#tao-math("\\forall N \\exists C \\forall n \\leq N: \\left|x(n,N)\\right| \\leq C.", block: true)]]

#text("As before, each of the example statements in parameterised logic can be easily translated into a statement in traditional logic. On the other hand, consider the assertion that a parameterised real ")#mi("{x = x(n,N)}")#text(" is expressible as the sum ")#mi("{x = y + z}")#text(" of a quantity ")#mi("{y = y(n)}")#text(" depending only on ")#mi("{n}")#text(" and a quantity ")#mi("{z = z(N)}")#text(" depending on ")#mi("{N}")#text(". (For instance, the parameterised real ")#mi("{x = (N+n)(N-n) = N^2 - n^2}")#text(" would be of this form, but the parameterised real ")#mi("{x = Nn}")#text(" cannot.) Now it becomes significantly harder to translate this statement into first-order logic! One can still do so fairly readily using ")#link("https://en.wikipedia.org/wiki/Second-order_logic")[#text("second-order logic")]#text(" (in which one also is permitted to quantify over operators as well as variables), or by using the language of set theory (so that one can quantify over a set of functions of various forms). Indeed if one is parameterising over proper classes rather than sets, it is even possible to create sentences in parameterised logic that are ")#link("https://en.wikipedia.org/wiki/Nonfirstorderizability")[#text("non-firstorderisable")]#text("; see ")#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/")[#text("this previous blog post")]#text(" for more discussion.")

#text("Another subtle distinction that arises once one has parameters is the distinction between “internal” or `parameterised” sets (sets depending on the choice of parameters), and external sets (sets of parameterised objects). For instance, the interval ")#mi("{[n,N]}")#text(" is an internal set – it assigns an orthodox set ")#mi("{\\{ x \\in {\\bf R}: n \\leq x \\leq N \\}}")#text(" of reals to each choice of parameters ")#mi("{(n,N)}")#text("; elements of this set consist of all the parameterised reals ")#mi("{x = x(n,N)}")#text(" such that ")#mi("{n \\leq x(n,N) \\leq N}")#text(" for all ")#mi("{n,N}")#text(". On the other hand, the collection ")#mi("{{\\mathcal O}(1)}")#text(" of bounded reals – i.e., parameterised reals ")#mi("{x = x(n,N)}")#text(" such that there is a constant ")#mi("{C}")#text(" for which ")#tao-math("{\\left|x(n,N)\\right| \\leq C}", block: false)#text(" for all choices of parameters ")#mi("{(n,N)}")#text(" – is not an internal set; it does not arise from taking an orthodox set of reals ")#mi("{X(n,N)}")#text(" for each choice of parameters. (Indeed, if it did do so, since every constant real is bounded, each ")#mi("{X(n,N)}")#text(" would contain all of ")#mi("{{\\bf R}}")#text(", which would make ")#mi("{{\\mathcal O}(1)}")#text(" the set of all parameterised reals, rather than just the bounded reals.) To maintain this distinction, we will reserve set builder notation such as ")#mi("{\\{ x \\in X: P(x) \\}}")#text(" for internally defined sets, and use English words (such as “the collection of all bounded parameterised reals”) to denote external sets. In particular, we do not make sense of such expressions as ")#mi("{\\{ x \\in {\\bf R}: x \\text{ bounded} \\}}")#text(" (or ")#mi("{\\{ x \\in {\\bf R}: x = O(1) \\}}")#text(", once asymptotic notation is introduced). In general, I would recommend that one avoids combining asymptotic notation with heavy use of set theoretic notation, unless one knows exactly what one is doing.")

#heading(level: 1)[#strong[#text(" — 3. Asymptotic notation — ")]]

#text("We now simultaneously introduce the two extensions to orthodox first order logic discussed in previous sections. In other words,")

#enum(start: 1, 
[#text("We permit the use of partially specified mathematical objects in one’s mathematical statements (and in particular, on either side of an equation or inequality).")],
[#text("We allow all quantities to depend on one or more of the ambient parameters.")]
)

#text("In particular, we allow for the use of partially specified mathematical quantities that also depend on one or more of the ambient parameters. This allows us now formally introduce asymptotic notation. There are many variants of this notation, but here is one set of asymptotic conventions that I for one like to use:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4 (Asymptotic notation)")]#text(" Let ")#mi("{X}")#text(" be a non-negative quantity (possibly depending on one or more of the ambient parameters).")

#list(
[#text("We use ")#mi("{O(X)}")#text(" to denote a partially specified quantity in the class of quantities ")#mi("{Y}")#text(" (that can depend on one or more of the ambient parameters) that obeys the bound ")#tao-math("{\\left|Y\\right| \\leq CX}", block: false)#text(" for some absolute constant ")#mi("{C > 0}")#text(". More generally, given some ambient parameters ")#mi("{\\lambda_1,\\dots,\\lambda_k}")#text(", we use ")#mi("{O_{\\lambda_1,\\dots,\\lambda_k}(X)}")#text(" to denote a partially specified quantity in the class of quantities ")#mi("{Y}")#text(" that obeys the bound ")#tao-math("{\\left|Y\\right| \\leq C_{\\lambda_1,\\dots,\\lambda_k}(X)}", block: false)#text(" for some constant ")#mi("{C > 0}")#text(" that can depend on the ")#mi("{\\lambda_1,\\dots,\\lambda_k}")#text(" parameters, but not on the other ambient parameters.")],
[#text("We also use ")#mi("{X \\ll Y}")#text(" or ")#mi("{Y \\gg X}")#text(" as a synonym for ")#mi("{X = O(Y)}")#text(", and ")#mi("{X \\asymp Y}")#text(" as a synonym for ")#mi("{X \\ll Y \\ll X}")#text(". (In some fields of analysis, ")#mi("{X \\lesssim Y}")#text(", ")#mi("{X \\gtrsim Y}")#text(", and ")#mi("{X \\sim Y}")#text(" are used instead of ")#mi("{X \\ll Y}")#text(", ")#mi("{X \\gg Y}")#text(", and ")#mi("{X \\asymp Y}")#text(".)")],
[#text("If ")#mi("{x}")#text(" is a parameter and ")#mi("{x_*}")#text(" is a limiting value of that parameter (i.e., the parameter space for ")#mi("{x}")#text(" and ")#mi("{x_*}")#text(" both lie in some topological space, with ")#mi("{x_*}")#text(" an adherent point of that parameter space), we use ")#mi("{o_{x \\rightarrow x_*}(X)}")#text(" to denote a partially specified quantity in the class of quantities ")#mi("{Y}")#text(" (that can depend on ")#mi("{x}")#text(" as well as the other the ambient parameters) that obeys a bound of the form ")#tao-math("{\\left|Y\\right| \\leq c(x) X}", block: false)#text(" for all ")#mi("{x}")#text(" in some neighborhood of ")#mi("{x_*}")#text(", and for some quantity ")#mi("{c(x) > 0}")#text(" depending only on ")#mi("{x}")#text(" such that ")#mi("{c(x) \\rightarrow 0}")#text(" as ")#mi("{x \\rightarrow x_*}")#text(". More generally, given some further ambient parameters ")#mi("{\\lambda_1,\\dots,\\lambda_k}")#text(", we use ")#mi("{o_{x \\rightarrow x_*; \\lambda_1,\\dots,\\lambda_k}(X)}")#text(" to denote a partially specified quantity in the class of quantities ")#mi("{Y}")#text(" that obey a bound of the form ")#tao-math("{\\left|Y\\right| \\leq c_{\\lambda_1,\\dots,\\lambda_k}(x) X}", block: false)#text(" for all ")#mi("{x}")#text(" in a neighbourhood of ")#mi("{x_*}")#text(" (which can also depend on ")#mi("{\\lambda_1,\\dots,\\lambda_k}")#text(") where ")#mi("{c_{\\lambda_1,\\dots,\\lambda_k}(x) > 0}")#text(" depends on ")#mi("{\\lambda_1,\\dots,\\lambda_k,x}")#text(" and goes to zero as ")#mi("{x \\rightarrow x_*}")#text(". (In this more general form, the limit point ")#mi("{x_*}")#text(" is now also permitted to depend on the parameters ")#mi("{\\lambda_1,\\dots,\\lambda_k}")#text(").")]
)

#text("Sometimes (by explicitly declaring one will do so) one suppresses the dependence on one or more of the additional parameters ")#mi("{\\lambda_1,\\dots,\\lambda_k}")#text(", and/or the asymptotic limit ")#mi("{x \\rightarrow x_*}")#text(", in order to reduce clutter.")
]

#text("(This is the “non-asymptotic” form of the ")#mi("{O()}")#text(" notation, in which the bounds are assumed to hold for ")#emph[#text("all")]#text(" values of parameters. There is also an “asymptotic” variant of this notation that is commonly used in some fields, in which the bounds in question are only assumed to hold in some neighbourhood of an asymptotic value ")#mi("{x_*}")#text(", but we will not focus on that variant here.)")

#text("Thus, for instance, ")#mi("{n}")#text(" is a free variable taking values in the natural numbers, and ")#mi("{f(n), g(n), h(n)}")#text(" are quantities depending on ")#mi("{n}")#text(", then the statement ")#mi("{f(n) = g(n) + O(h(n))}")#text(" denotes the assertion that ")#mi("{f(n) = g(n) + k(n)}")#text(" for all natural numbers ")#mi("{n}")#text(", where ")#mi("{k(n)}")#text(" is another quantity depending on ")#mi("{n}")#text(" such that ")#tao-math("{\\left|k(n)\\right| \\leq C h(n)}", block: false)#text(" for all ")#mi("{n}")#text(", and some absolute constant ")#mi("{C}")#text(" independent of ")#mi("{n}")#text(". Similarly, ")#mi("{f(n) \\leq g(n) + O(h(n))}")#text(" denotes the assertion that ")#mi("{f(n) \\leq g(n) + k(n)}")#text(" for all natural numbers ")#mi("{n}")#text(", where ")#mi("{k(n)}")#text(" is as above.")

#text("For a slightly more sophisticated example, consider the statement ")#metadata(none) <tao-be5488bce5b1018708c8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("O(n) + O(n^2) \\leq O(n^2),")]]

#text(" ")#text(" where again ")#mi("{n}")#text(" is a free variable taking values in the natural numbers. Using the conventions for multi-valued expressions, we can translate this expression into first-order logic as the assertion that whenever ")#mi("{f(n), g(n)}")#text(" are quantities depending on ")#mi("{n}")#text(" such that there exists a constant ")#mi("{C_1}")#text(" such that ")#tao-math("{\\left|f(n)\\right| \\leq C_1 n}", block: false)#text(" for all natural numbers ")#mi("{n}")#text(", and there exists a constant ")#mi("{C_2}")#text(" such that ")#tao-math("{\\left|g(n)\\right| \\leq C_2 n^2}", block: false)#text(" for all natural numbers ")#mi("{n}")#text(", then we have ")#mi("{f(n)+g(n) \\leq h(n)}")#text(" for all ")#mi("{n}")#text(", where ")#mi("{h}")#text(" is a quantity depending on natural numbers ")#mi("{n}")#text(" with the property that there exists a constant ")#mi("{C_3}")#text(" such that ")#tao-math("{\\left|h(n)\\right| \\leq C_3 n^2}", block: false)#text(". Note that the first-order translation of ")#link(<tao-be5488bce5b1018708c8>)[#text("(6)")]#text(" is substantially longer than ")#link(<tao-be5488bce5b1018708c8>)[#text("(6)")]#text(" itself; and once one gains familiarity with the big-O notation, ")#link(<tao-be5488bce5b1018708c8>)[#text("(6)")]#text(" can be deciphered much more quickly than its formal first-order translation.")

#text("It can be instructive to rewrite some basic notions in analysis in this sort of notation, just to get a slightly different perspective. For instance, if ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a function, then:")

#list(
[#mi("{f}")#text(" is continuous iff one has ")#mi("{f(y) = f(x) + o_{y \\rightarrow x; f,x}(1)}")#text(" for all ")#mi("{x,y \\in {\\bf R}}")#text(".")],
[#mi("{f}")#text(" is uniformly continuous iff one has ")#tao-math("{f(y) = f(x) + o_{\\left|y-x\\right| \\rightarrow 0; f}(1)}", block: false)#text(" for all ")#mi("{x,y \\in {\\bf R}}")#text(".")],
[#text("A sequence ")#mi("{F = (f_n)_{n \\in {\\bf N}}}")#text(" of functions is equicontinuous if one has ")#mi("{f_n(y) = f_n(x) + o_{y \\rightarrow x; F,x}(1)}")#text(" for all ")#mi("{x,y \\in {\\bf R}}")#text(" and ")#mi("{n \\in {\\bf N}}")#text(" (note that the implied constant depends on the family ")#mi("{F}")#text(", but not on the specific function ")#mi("{f_n}")#text(" or on the index ")#mi("{n}")#text(").")],
[#text("A sequence ")#mi("{F = (f_n)_{n \\in {\\bf N}}}")#text(" of functions is uniformly equicontinuous if one has ")#tao-math("{f_n(y) = f_n(x) + o_{\\left|y-x\\right| \\rightarrow 0; F}(1)}", block: false)#text(" for all ")#mi("{x,y \\in {\\bf R}}")#text(" and ")#mi("{n \\in {\\bf N}}")#text(".")],
[#mi("{f}")#text(" is differentiable iff one has ")#tao-math("{f(y) = f(x) + (y-x) f^{\\prime}(x) + o_{y \\rightarrow x; f,x}(\\left|y-x\\right|)}", block: false)#text(" for all ")#mi("{x,y \\in {\\bf R}}")#text(".")],
[#text("Similarly for uniformly differentiable, equidifferentiable, etc..")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" One can define additional variants of asymptotic notation such as ")#mi("{\\Omega(X)}")#text(", ")#mi("{\\omega(X)}")#text(", or ")#mi("{\\Theta(X)}")#text("; see ")#link("https://en.wikipedia.org/wiki/Big_O_notation#Related_asymptotic_notations")[#text("this wikipedia page for some examples")]#text(". See also the related notion of “")#link("https://en.wikipedia.org/wiki/Eventually_(mathematics)")[#text("sufficiently large")]#text("” or “sufficiently small”. However, one can usually reformulate such notations in terms of the above-mentioned asymptotic notations with a little bit of rearranging. For instance, the assertion")

#align(center)[#tao-fit-display[#mitex("\\text{For all sufficiently large } n, P(n) \\text{ is true}")]]

#text("can be rephrased as an alternative:")

#align(center)[#tao-fit-display[#mitex("\\text{If } n \\text{ is a natural number, then } P(n) \\text{, or } n = O(1).")]]
]

#text("When used correctly, asymptotic notation can suppress a lot of distracting quantifiers (“there exists a ")#mi("{C}")#text(" such that for every ")#mi("{n}")#text(" one has…”) or temporary notation which is introduced once and then discarded (“where ")#mi("{C}")#text(" is a constant, not necessarily the same as the constant ")#mi("{C}")#text(" from the preceding line…”). It is particularly well adapted to situations in which the order of magnitude of a quantity of interest is of more importance than its exact value, and can help capture precisely such intuitive notions as “large”, “small”, “lower order”, “main term”, “error term”, etc.. Furthermore, I find that analytic assertions phrased using asymptotic notation tend to align better with the natural sentence structure of mathematical English than their logical equivalents in other notational conventions (e.g. first-order logic).")

#text("On the other hand, the notation can be somewhat confusing to use at first, as expressions involving asymptotic notation do not always obey the familiar laws of mathematical deduction if applied blindly; but the failures can be explained by the changes to orthodox first order logic indicated above. For instance, if ")#mi("{n}")#text(" is a positive integer (which we will assume to be at least say ")#mi("{100}")#text(", in order to make sense of quantities such as ")#mi("{\\log\\log n}")#text("), then")

#list(
[#text("(i) (Asymmetry of equality) We have ")#mi("{O(n) = O(n^2)}")#text(", but it is not true that ")#mi("{O(n^2) = O(n)}")#text(". In the same spirit, ")#mi("{O(n) \\leq O(n^2)}")#text(" is a true statement, but ")#mi("{O(n^2) \\geq O(n)}")#text(" is a false statement. Similarly for the ")#mi("{o()}")#text(" notation. This of course stems from the asymmetry of the equality relation ")#mi("{=}")#text(" that arises once one introduces partially specified objects.")],
[#text("(ii) (Intransitivity of equality) We have ")#mi("{n+1 = O(n)}")#text(", and ")#mi("{n+2 = O(n)}")#text(", but ")#mi("{n+1 \\neq n+2}")#text(". This is again stemming from the asymmetry of the equality relation.")],
[#text("(iii) (Incompatibility with functional notation) ")#mi("{O(n)}")#text(" generally refers to a function of ")#mi("{n}")#text(", but ")#mi("{O(1)}")#text(" usually does not refer to a function of ")#mi("{1}")#text(" (for instance, it is true that ")#mi("{\\frac{1}{n} = O(1)}")#text("). This is a slightly unfortunate consequence of the overloaded nature of the parentheses symbols in mathematics, but as long as one keeps in mind that ")#mi("{O}")#text(" and ")#mi("{o}")#text(" are not function symbols, one can avoid ambiguity.")],
[#text("(iv) (Incompatibility with mathematical induction) We have ")#mi("{O(n+1)=O(n)}")#text(", and more generally ")#mi("{O(n+k+1)=O(n+k)}")#text(" for any ")#mi("{k \\geq 1}")#text(", but one cannot blindly apply induction and conclude that ")#mi("{O(n+k)=O(n)}")#text(" for all ")#mi("{n,k \\geq 1}")#text(" (with ")#mi("{k}")#text(" viewed as an additional parameter). This is because to induct on an internal parameter such as ")#mi("{n}")#text(", one is only allowed to use internal predicates ")#mi("{P(n)}")#text("; the assertion ")#mi("{O(n+1)=O(n)}")#text(", which also quantifies externally over some implicit constants ")#mi("{C}")#text(", is not an internal predicate. However, external induction is still valid, permitting one to conclude that ")#mi("{O(n+k)=O(n)}")#text(" for any ")#emph[#text("fixed")]#text(" (external) ")#mi("{k \\geq 1}")#text(", or equivalently that ")#mi("{O(n+k) = O_k(n)}")#text(" if ")#mi("{k}")#text(" is now viewed instead as a parameter.")],
[#text("(v) (Failure of the ")#link("http://en.wikipedia.org/wiki/Generalization_(logic)")[#text("law of generalisation")]#text(") Every specific (or “fixed”) positive integer, such as ")#mi("{57}")#text(", is of the form ")#mi("{O(1)}")#text(", but the positive integer ")#mi("{n}")#text(" is not of the form ")#mi("{O(1)}")#text(". (Again, this can be fixed by allowing implied constants to depend on the parameter one is generalising over.) Like (iv), this arises from the need to distinguish between external (fixed) variables and internal parameters.")],
[#text("(vi) (Failure of the ")#link("https://en.wikipedia.org/wiki/Axiom_schema_of_specification")[#text("axiom schema of specification")]#text(") Given a set ")#mi("{X}")#text(" and a predicate ")#mi("{P(x)}")#text(" involving elements ")#mi("{x}")#text(" of ")#mi("{X}")#text(", the axiom of specification allows one to use ")#link("https://en.wikipedia.org/wiki/Set-builder_notation")[#text("set builder notation")]#text(" to form the set ")#mi("{\\{ x \\in X: P(x) \\}}")#text(". However, this is no longer possible if ")#mi("{P}")#text(" involves asymptotic notation. For instance, one cannot form the “set” ")#mi("{\\{ x \\in {\\bf R}: x = O(1) \\}}")#text(" of bounded real numbers, which somehow manages to contain all fixed numbers such as ")#mi("{57}")#text(", but not any unbounded free parameters such as ")#mi("{n}")#text(". (But, if one uses the nonstandard analysis formalism, it becomes possible again to form such sets, with the important caveat that such sets are now ")#link("https://en.wikipedia.org/wiki/Nonstandard_analysis")[#text("external sets")]#text(" rather than ")#link("https://en.wikipedia.org/wiki/Internal_set")[#text("internal sets")]#text(". For instance, the external set ")#mi("{\\{ x \\in {}^* {\\bf R}: x = O(1) \\}}")#text(" of bounded nonstandard reals becomes a proper subring of the ring of nonstandard reals.) This failure is again related to the distinction between internal and external predicates.")],
[#text("(vii) (Failure of ")#link("http://en.wikipedia.org/wiki/Trichotomy_(mathematics)")[#text("trichotomy")]#text(") For non-asymptotic real numbers ")#mi("{X,Y}")#text(", exactly one of the statements ")#mi("{X<Y}")#text(", ")#mi("{X=Y}")#text(", ")#mi("{X>Y}")#text(" hold. As discussed in the previous section, this is not the case for asymptotic quantities: none of the three statements ")#tao-math("{O(\\left|\\sin(n)\\right|) = O(\\left|\\cos(n)\\right|)}", block: false)#text(", ")#tao-math("{O(\\left|\\sin(n)\\right|) > O(\\left|\\cos(n)\\right|)}", block: false)#text(", or ")#tao-math("{O(\\left|\\sin(n)\\right|) < O(\\left|\\cos(n)\\right|)}", block: false)#text(" are true, while all three of the statements ")#mi("{O(n) < O(n)}")#text(", ")#mi("{O(n) = O(n)}")#text(", and ")#mi("{O(n) > O(n)}")#text(" are true. (This trichotomy can however be restored by using the nonstandard analysis formalism, or (in some cases) by restricting ")#mi("{n}")#text(" to an appropriate subsequence whenever necessary.)")],
[#text("(viii) (Unintuitive interaction with ")#mi("{\\neq}")#text(") Asymptotic notation interacts in strange ways with the ")#mi("{\\neq}")#text(" symbol, to the extent that combining the two together is not recommended. For instance, the statement ")#mi("{O(n) \\neq O(n)}")#text(" is a true statement, because for any expression ")#mi("{a_n}")#text(" of order ")#mi("{a_n = O(n)}")#text(", one can find another expression ")#mi("{b_n}")#text(" of order ")#mi("{b_n = O(n)}")#text(" such that ")#mi("{a_n \\neq b_n}")#text(" for all ")#mi("{n}")#text(". Instead of using statements such as ")#mi("{X \\neq Y}")#text(" in which one of ")#mi("{X,Y}")#text(" contain asymptotic notation, I would instead recommend using the different statement “it is not the case that ")#mi("{X=Y}")#text("“, e.g. “it is not the case that ")#mi("{O(n^2)=O(n)}")#text("“. And even then, I would generally only use negation of asymptotic statements in order to demonstrate the incorrectness of some particular argument involving asymptotic notation, and not as part of any positive argument involving such notations. These issues are of course related to (vii).")],
[#text("(ix) (Failure of ")#link("http://en.wikipedia.org/wiki/Cancellation_law")[#text("cancellation law")]#text(") We have ")#mi("{O(n) + O(n) = O(n)}")#text(", but one cannot cancel one of the ")#mi("{O(n)}")#text(" terms and conclude that ")#mi("{O(n) = 0}")#text(". Indeed, ")#mi("{O(n)-O(n)}")#text(" is not equal to ")#mi("{0}")#text(" in general. (For instance, ")#mi("{2n = O(n)}")#text(" and ")#mi("{n=O(n)}")#text(", but ")#mi("{2n-n \\neq 0}")#text(".) More generally, ")#mi("{O(X)-O(Y)}")#text(" is not in general equal to ")#mi("{O(X-Y)}")#text(" or even to ")#tao-math("{O(\\left|X-Y\\right|)}", block: false)#text(" (although there is an important exception when one of ")#mi("{X,Y}")#text(" dominates the other). Similarly for the ")#mi("{o()}")#text(" notation. This stems from the care one has to take in the law of substitution when working with partially specified quantities that appear multiple times on the left-hand side.")],
[#text("(x) (")#mi("{O()}")#text(", ")#mi("{o()}")#text(" do not commute with signed multiplication) If ")#mi("{X,Y}")#text(" are non-negative, then ")#mi("{X \\cdot O(Y) = O(XY)}")#text(" and ")#mi("{X \\cdot o_{n \\rightarrow \\infty}(Y) = o_{n \\rightarrow \\infty}(XY)}")#text(". However, these laws do not work if ")#mi("{X}")#text(" is signed; indeed, as currently defined ")#mi("{O(XY)}")#text(" and ")#mi("{o_{n \\rightarrow \\infty}(XY)}")#text(" do not even make sense. Thus for instance ")#mi("{-O(n)}")#text(" cannot be written as ")#mi("{O(-n)}")#text(". (However, one does have ")#tao-math("{X \\cdot O(Y) = O(\\left|X\\right| Y)}", block: false)#text(" and ")#tao-math("{X \\cdot o_{n \\rightarrow \\infty}(Y) = o_{n \\rightarrow \\infty}(\\left|X\\right| Y)}", block: false)#text(" when ")#mi("{X}")#text(" is signed.) This comes from the absolute values present in the ")#mi("{O()}")#text("-notation. For beginners, I would recommend not placing any signed quantities inside the ")#mi("{O()}")#text(" and ")#mi("{o()}")#text(" symbols if at all possible.")],
[#text("(xi) (")#mi("{O()}")#text(" need not distribute over summation) For each fixed ")#mi("{k}")#text(", ")#mi("{k = O(1)}")#text(", and ")#mi("{\\sum_{k=1}^n 1 = n}")#text(", but it is not the case that ")#mi("{\\sum_{k=1}^n k = O(n)}")#text(". This example seems to indicate that the assertion ")#mi("{\\sum_{k=1}^n O(1) = O( \\sum_{k=1}^n 1 )}")#text(" is not true, but that is because we have conflated an external (fixed) quantity ")#mi("{k}")#text(" with an internal parameter ")#mi("{k}")#text(" (the latter being needed to define the summation ")#mi("{\\sum_{k=1}^n}")#text("). The more precise statements (with ")#mi("{k}")#text(" now consistently an internal parameter) are that ")#mi("{k = O_k(1)}")#text(", and that the assertion ")#mi("{\\sum_{k=1}^n O_k(1) = O( \\sum_{k=1}^n 1 )}")#text(" is not true, but the assertion ")#mi("{\\sum_{k=1}^n O(1) = O( \\sum_{k=1}^n 1 )}")#text(" is still true (why?).")],
[#text("(xii) (")#mi("{o()}")#text(" does not distribute over summation, I) Let ")#mi("{\\varepsilon_k(n) := \\exp(\\exp(n)) 1_{k \\geq \\log\\log n - 1}}")#text(", then for each fixed ")#mi("{k}")#text(" one has ")#mi("{\\varepsilon_k(n) = o_{n \\rightarrow \\infty}(1)}")#text("; however, ")#mi("{\\sum_{k=1}^{\\log\\log n} \\varepsilon_k(n) \\geq \\exp(\\exp(n))}")#text(". Thus an expression of the form ")#mi("{\\sum_{k=1}^{\\log\\log n} o_{n \\rightarrow \\infty}(1)}")#text(" can in fact grow extremely fast in ")#mi("{n}")#text(" (and in particular is not of the form ")#mi("{o_{n \\rightarrow \\infty}(\\log\\log n)}")#text(" or even ")#mi("{O(\\log\\log n)}")#text("). Of course, one could replace ")#mi("{\\log\\log n}")#text(" here by any other growing function of ")#mi("{n}")#text(". This is a similar issue to (xi); it shows that the assertion")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=1}^N o_{n \\rightarrow \\infty;k}(1) = o_{n \\rightarrow \\infty}(\\sum_{k=1}^N 1)")]]

#text("can fail, but if one has uniformity in the ")#mi("{k}")#text(" parameter then things are fine:")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=1}^N o_{n \\rightarrow \\infty}(1) = o_{n \\rightarrow \\infty}(\\sum_{k=1}^N 1).")]]],
[#text("(xiii) (")#mi("{o()}")#text(" does not distribute over summation, II) In the previous example, the ")#mi("{o_{n \\rightarrow \\infty}(1)}")#text(" summands were not uniformly bounded. If one imposes uniform boundedness, then one now recovers the ")#mi("{O()}")#text(" bound, but one can still lose the ")#mi("{o()}")#text(" bound. For instance, let ")#mi("{\\varepsilon_k(n) := 1_{k \\geq \\log\\log n}}")#text(", then ")#mi("{\\varepsilon_k(n)}")#text(" is now uniformly bounded in magnitude by ")#mi("{1}")#text(", and for each fixed ")#mi("{k}")#text(" one has ")#mi("{\\varepsilon_k(n) = o_{n \\rightarrow \\infty}(1)}")#text("; however, ")#mi("{\\sum_{k=1}^n \\varepsilon_k(n) = n - O(\\log\\log n)}")#text(". Thus, viewing ")#mi("{k}")#text(" now as a parameter, the expression ")#mi("{\\sum_{k=1}^n o_{n \\rightarrow \\infty;k}(1)}")#text(" is bounded by ")#mi("{O(n)}")#text(", but not by ")#mi("{o_{n \\rightarrow \\infty}(n)}")#text(". (However, one ")#emph[#text("can")]#text(" write ")#tao-math("{\\sum_{k=1}^n o_{n \\rightarrow \\infty}(a_k) = o_{n \\rightarrow \\infty}(\\sum_{k=1}^n \\left|a_k\\right|)}", block: false)#text(" since by our conventions the implied decay rates in the ")#mi("{o_{n \\rightarrow \\infty}(a_k)}")#text(" summands are uniform in ")#mi("{n}")#text(".)")],
[#text("(xiv) (")#mi("{o()}")#text(" does not distribute over summation, III) If ")#mi("{a_k}")#text(" are non-negative quantities, and one has a summation of the form ")#mi("{\\sum_{k=1}^n (1+o_{n \\rightarrow \\infty}(1)) a_k}")#text(" (noting here that the decay rate is not allowed to depend on ")#mi("{k}")#text("), then one can “factor out” the ")#mi("{1+o_{n \\rightarrow \\infty}(1)}")#text(" term to write this summation as ")#mi("{(1 + o_{n \\rightarrow \\infty}(1)) (\\sum_{k=1}^n a_k)}")#text(". However this is far from being true if the sum ")#mi("{\\sum_{k=1}^n a_k}")#text(" exhibits significant cancellation. This is most vivid in the case when the sum ")#mi("{\\sum_{k=1}^n a_k}")#text(" actually vanishes. For another example, the sum ")#mi("{\\sum_{k=1}^{n} (1 + \\frac{(-1)^k}{\\log\\log n}) (-1)^k}")#text(" is equal to ")#mi("{\\frac{n}{\\log\\log n} + O(1)}")#text(", despite the fact that ")#mi("{1 + \\frac{(-1)^k}{\\log\\log n} = 1 + o_{n \\rightarrow\\infty}(1)}")#text(" uniformly in ")#mi("{k}")#text(", and that ")#mi("{\\sum_{k=1}^n (-1)^k = O(1)}")#text(". For oscillating ")#mi("{a_k}")#text(", the best one can say in general is that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k=1}^n (1+o_{n \\rightarrow \\infty}(1)) a_k = \\sum_{k=1}^n a_k + o_{n \\rightarrow \\infty}( \\sum_{k=1}^n \\left|a_k\\right| ).", block: true)]]

#text("Similarly for the ")#mi("{O()}")#text(" notation. I see this type of error often among beginner users of asymptotic notation. Again, the general remedy is to avoid putting any signed quantities inside the ")#mi("{O()}")#text(" or ")#mi("{o()}")#text(" notations.")]
)

#text("Perhaps the quickest way to develop some basic safeguards is to be aware of certain “red flags” that indicate incorrect, or at least dubious, uses of asymptotic notation, as well as complementary “safety indicators” that give more reassurance that the usage of asymptotic notation is valid. From the above examples, we can construct a small table of such red flags and safety indicators for any expression or argument involving asymptotic notation:")

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Red flag")],
table.cell(colspan: 1, rowspan: 1)[#text("Safety indicator")],
table.cell(colspan: 1, rowspan: 1)[#text("Signed quantities in RHS")],
table.cell(colspan: 1, rowspan: 1)[#text("Absolute values in RHS")],
table.cell(colspan: 1, rowspan: 1)[#text("Casually using iteration/induction")],
table.cell(colspan: 1, rowspan: 1)[#text("Explicitly allowing bounds to depend on length of iteration/induction")],
table.cell(colspan: 1, rowspan: 1)[#text("Casually summing an unbounded number of terms")],
table.cell(colspan: 1, rowspan: 1)[#text("Keeping number of terms bounded and/or ensuring uniform bounds on each term")],
table.cell(colspan: 1, rowspan: 1)[#text("Casually changing a “fixed” quantity to a “variable” or “bound” one")],
table.cell(colspan: 1, rowspan: 1)[#text("Keeping track of what parameters implied constants depend on")],
table.cell(colspan: 1, rowspan: 1)[#text("Casually establishing lower bounds or asymptotics")],
table.cell(colspan: 1, rowspan: 1)[#text("Establishing upper bounds and/or being careful with signs and absolute values")],
table.cell(colspan: 1, rowspan: 1)[#text("Signed algebraic manipulations (e.g., cancellation law)")],
table.cell(colspan: 1, rowspan: 1)[#text("Unsigned algebraic manipulations")],
table.cell(colspan: 1, rowspan: 1)[#mi("{X \\neq Y}")],
table.cell(colspan: 1, rowspan: 1)[#text("Negation of ")#mi("{X=Y}")#text("; or, better still, avoiding negation altogether")],
table.cell(colspan: 1, rowspan: 1)[#text("Swapping LHS and RHS")],
table.cell(colspan: 1, rowspan: 1)[#text("Not swapping LHS and RHS")],
table.cell(colspan: 1, rowspan: 1)[#text("Using trichotomy of order")],
table.cell(colspan: 1, rowspan: 1)[#text("Not using trichotomy of order")],
table.cell(colspan: 1, rowspan: 1)[#text("Set-builder notation")],
table.cell(colspan: 1, rowspan: 1)[#text("Not using set-builder notation (or, in non-standard analysis, distinguishing internal sets from external sets)")]
)

#text("When I say here that some mathematical step is performed “casually”, I mean that it is done without any of the additional care that is necessary when this step involves asymptotic notation (that is to say, the step is performed by blindly applying some mathematical law that may be valid for manipulation of non-asymptotic quantities, but can be dangerous when applied to asymptotic ones). It should also be noted that many of these red flags can be disregarded if the portion of the argument containing the red flag is free of asymptotic notation. For instance, one could have an argument that uses asymptotic notation in most places, except at one stage where mathematical induction is used, at which point the argument switches to more traditional notation (using explicit constants rather than implied ones, etc.). This is in fact the opposite of a red flag, as it shows that the author is aware of the potential dangers of combining induction and asymptotic notation. Similarly for the other red flags listed above; for instance, the use of set-builder notation that conspicuously avoids using the asymptotic notation that appears elsewhere in an argument is reassuring rather than suspicious.")

#text("If one finds oneself trying to use asymptotic notation in a way that raises one or more of these red flags, I would strongly recommend working out that step as carefully as possible, ideally by writing out both the hypotheses and conclusions of that step in non-asymptotic language (with all quantifiers present and in the correct order), and seeing if one can actually derive the conclusion from the hypothesis by traditional means (i.e., without explicit use of asymptotic notation ). Conversely, if one is reading a paper that uses asymptotic notation in a manner that casually raises several red flags without any apparent attempt to counteract them, one should be particularly skeptical of these portions of the paper.")

#text("As a simple example of asymptotic notation in action, we give a proof that convergent sequences also ")#link("https://en.wikipedia.org/wiki/Ces%C3%A0ro_summation")[#text("converge in the Césaro sense")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6")]#text(" If ")#mi("{\\vec x = (x_n)_{n \\in {\\bf N}}}")#text(" is a sequence of real numbers converging to a limit ")#mi("{L}")#text(", then the averages ")#mi("{\\frac{1}{N} \\sum_{n=1}^N x_n}")#text(" also converge to ")#mi("{L}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(".")
]

#emph[#text("Proof:")]#text(" Since ")#mi("{x_n}")#text(" converges to ")#mi("{L}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("x_n = L + o_{n \\rightarrow \\infty; \\vec x}(1)")]]

#text("so in particular for any ")#mi("{M \\geq 1}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("x_n = L + o_{M \\rightarrow \\infty; \\vec x}(1)")]]

#text("whenever ")#mi("{n > M}")#text(". For ")#mi("{N \\geq M}")#text(", we thus have")

#tao-aligned(keep: true)[


#tao-math("\\frac{1}{N} \\sum_{n=1}^N x_n  & = \\frac{1}{N} ( \\sum_{n=1}^M x_n + \\sum_{n=M+1}^N x_n)", block: true)



#tao-math(" & = \\frac{1}{N}( O_{M,\\vec x}(1) + \\sum_{n=M+1}^N (L + o_{M \\rightarrow \\infty; \\vec x}(1)))", block: true)



#tao-math(" & = \\frac{1}{N}( O_{M,\\vec x}(1) + (N-M) L + o_{M \\rightarrow \\infty; \\vec x}(N))", block: true)



#tao-math(" & = O_{M,\\vec x}(1/N) + L - O_{M,L}(1/N) + o_{M \\rightarrow \\infty; \\vec x}(1)", block: true)



#tao-math(" & = L + o_{M \\rightarrow \\infty; \\vec x}(1) + o_{N \\rightarrow \\infty; \\vec x, M, L}(1)", block: true)
]

#text("whenever ")#mi("{N \\geq M}")#text(". Setting ")#mi("{M}")#text(" to grow sufficiently slowly to infinity as ")#mi("{N \\rightarrow \\infty}")#text(" (for fixed ")#mi("{\\vec x, \\vec L}")#text("), we may simplify this to")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_{n=1}^N x_n = o_{N \\rightarrow \\infty; \\vec x, L}(1)")]]

#text("for all ")#mi("{N \\geq 1}")#text(", and the claim follows. ")#mi("\\Box")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (43)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643586")[#strong[#text("Partially specified mathematical objects, ambient parameters, and asymptotic notation – Marxist Statistics")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2022")]

#text("[…] Partially specified mathematical objects, ambient parameters, and asymptotic notation […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643588")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2022")])]

#text("x = -b/2a, I was just teaching a student that you can find the axis of symmetry by studying the quadratic formula (for standard parabolas of course, not ones that are rotated [x=y^2]). What a nice coincidence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c89ef3d9ab2f539d1fb9362fb1ac08aada70b0c6aac59ff83f3c0c0358dacb70-f517807a99ce6b39f54b77c56950c2a9aa2f4cd30d57eb02b2f0cedc78b2b182.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of waltonmath")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643589")[#strong[#text("waltonmath")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2022")])]

#text("I think Remark 1’s “")#mi("\\epsilon \\pm \\epsilon^2")#text("” should read “")#mi("\\epsilon + \\epsilon^2")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b9d2b471a95950cf9ab900a2a956433a802e53dd7dce19b8f99e969eecbfb6d-928b219cdc034ba412fab685a5c24ece80537934e15e706cc872bf337f74deba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of allenknutson")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643595")[#strong[#text("allenknutson")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2022")])]

#text("I’m curious what sent you down this rabbit hole, of needing to know “what’s really going on” with statements in common usage by mathematicians.")

#text("The failure of symmetry of statements like “n+1 = O(n)” reminds me of the following needle-scratch moment in probability.")#linebreak()#text(" “Let X be so-and-so random variable.")#linebreak()#text(" “What’s the probability that X=2?” GOOD")#linebreak()#text(" “What’s the probability that 2=X?” DOUBLE PLUS UNGOOD but why?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643604")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2022")])]

#text("Actually this is a post that has been developing for a couple years; I worked on it a little each time one of my graduate students struggled with the accepted practices for writing asymptotic notation in research papers, being a little frustrated that there does not appear to be much explicit guidance on these topics in the literature. In spoken English there are many grammatical rules (e.g., regarding the ")#link("https://en.wikipedia.org/wiki/Adjective#Order")[#text("preferred order of adjectives")]#text(") that native speakers often just pick up without being explicitly taught, and the same occurs in mathematical English as well. It might be an interesting linguistic exercise to try to make explicit more of the analogous rules of mathematical English. [Sample puzzle in this vein: why is it that ")#mi("2\\pi i")#text(" looks “correct”, but the other five permutations ")#mi("2i\\pi")#text(", ")#mi("i2\\pi")#text(", ")#mi("i\\pi 2")#text(", ")#mi("\\pi 2i")#text(", ")#mi("\\pi i2")#text(" look “incorrect” despite formally describing the exact same quantity? Similarly for ")#mi("z=x+iy")#text(" versus ")#mi("z=x+yi")#text(", ")#mi("e^{i\\theta}")#text(" versus ")#mi("e^{\\theta i}")#text(", etc.. -T.]")

#text("With regards to your example, it is an implicit standard (in the more analytic areas of mathematics, at least) when writing equations or inequalities to put the “primary” (and usually more complicated) quantity on the left and the “secondary” (less complicated) quantity on the right (or, alternatively, to upper and lower bound the primary quantity by two secondary quantities by placing it in the middle of a chain of inequalities). Perhaps this convention was influenced by the ")#link("https://en.wikipedia.org/wiki/Subject%E2%80%93verb%E2%80%93object_word_order")[#text("subject-verb-object ordering of English")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac4778118a8d264b9820fde72dd4c6d3d9906cee46b9c1ff55e001650de098c2-3dda8610965b2e699940de7f5f8a56f889dfbf5c89c8c0bc7597d9e1f301f1da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of antoniojpan")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643682")[#strong[#text("antoniojpan")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2022")])]

#text("In addition, I would say that there have been times in history of mathematics when a proper notation has been a greater advance than a new theorem. One never knows…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b4a1c26001d9306c3dddd8069aa2850e348def74d0fc339be82e6b790e9125a-ada560f8efcf397b4d37dd7fe92e73b223b21e98053be0005dfe0cdbc016fe44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aurel")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643817")[#strong[#text("Aurel")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2022")])]

#mi("2i\\pi")#text(" looks fine to me, and I think it is quite common in French math. I think that the explanation is that its pronunciation flows better (“deuzipi”) than $2\\pi i$ (“deupi-i” where you need to make a stop between the two “i” sounds).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e67ccdef6418653754409683c1d747a63579f2eea27718d91bd692d48950f042-49cc1f4a9ee95676b31f546ebd3ddb0a7bc67c7c3e2ad4292088c4f9a4a120dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Kirby")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643599")[#strong[#text("Jonathan Kirby")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2022")])]

#text("I am also curious as to your motivation for this post. Mathematical notation and conventions exist in various degrees of formalism. Formalism is important for clear communication and recognising (and preventing) imprecision, but beyond that it quickly becomes confusing.")

#text("It might be easier to clarify asymptotic notation by writing")#linebreak()#text(" ")#mi("n+1 \\in O(n)")#linebreak()#text(" rather than giving a lot of new rules for manipulating the equals sign in this context.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643605")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2022")])]

#text("See my reply to Allen for my primary motivation for this post.")

#text("The symbol ")#mi("\\in")#text(" only is a viable solution in a portion of the use cases. For instance, an assertion such as ")#mi("O(n) \\cdot O(n) = O(n^2)")#text(" would not be correctly describable as ")#mi("O(n) \\cdot O(n) \\in O(n^2)")#text(". Perhaps ")#mi("O(n) \\cdot O(n) \\subset O(n^2)")#text(" would be defensible, but now one has to devote a non-trivial amount of thought into deciding which of the connectives ")#mi("=, \\in, \\ni, \\subset, \\supset")#text(" to use in a given context. For instance the assertion “Since ")#tao-math("\\sin(y) = \\sin(x) + O(\\left|y-x\\right|)", block: false)#text(", we have ")#mi("\\sin(x+O(1/n)) = \\sin(x) + O(1/n)")#text("” would now become “Since ")#tao-math("\\sin(y) \\in \\sin(x) + O(\\left|y-x\\right|)", block: false)#text(", we have ")#mi("\\sin(x+O(1/n)) \\subset \\sin(x) + O(1/n)")#text("“. Using the equality sign for all of these use cases instead is more intuitive and corresponds more closely to how the verb “is” (“to be”) is actually used in mathematical English.")

#text("[Also, the use of set notation such as ")#mi("\\in")#text(" or ")#mi("\\subset")#text(" gets particularly confusing when the objects one is manipulating are themselves sets. For instance, the fact that a continuous function ")#mi("f: {\\bf R}^d \\to {\\bf R}^d")#text(" maps bounded sets to bounded sets can be described in my notation as ")#mi("f(B(0,O(1))) \\subset B(0,O(1))")#text(", or equivalently that ")#mi("f(x) \\in B(0,O(1))")#text(" whenever ")#mi("x \\in B(0,O(1))")#text(". These relationships become significantly more difficult to describe if one is already using ")#mi("\\in, \\subset")#text(" as connectives, as described above.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e67ccdef6418653754409683c1d747a63579f2eea27718d91bd692d48950f042-49cc1f4a9ee95676b31f546ebd3ddb0a7bc67c7c3e2ad4292088c4f9a4a120dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Kirby")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643637")[#strong[#text("Jonathan Kirby")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2022")])]

#text("It’s great that you are trying to explain these usually unspoken conventions. I do think maybe you are overloading notation a bit much to the extent that it obscures clarity, but maybe that’s just because I am not used to it.")

#mi("O(n)")#text(" can be thought of as an ideal in a valued field or ring of functions (where the field or ring is often unspecified) and if you think of it like that, it is clear enough which connectives to use. But maybe this is too abstract an approach for most people using asymptotic notation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643694")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2022")])]

#text("It’s a question of ")#link("https://en.wikipedia.org/wiki/Mereology")[#text("mereology")]#text(". The orthodox foundations of mathematics are based on set theory and first-order logic, and so mereological assertions such as “3 is a prime” and “primes larger than 2 are odd” are translated either into set-theoretic assertions such as ")#mi("3 \\in \\{ \\mathrm{primes}\\}")#text(" and ")#mi("\\{\\mathrm{primes} \\} \\cap \\{ \\mathrm{greater\\ than\\ } 2\\} \\subset \\{\\mathrm{odd}\\}")#text(" or into first-order logic sentences such as ")#mi("\\mathrm{IsPrime}(3)")#text(" and ")#mi("\\forall n: \\mathrm{IsPrime}(n) \\& (n > 2) \\implies \\mathrm{IsOdd}(n)")#text(". With years of training, we all get used to these translations, and even internalize them to the point where we don’t notice anymore that a translation has actually occurred (except when we have to teach confused undergraduates who have not yet had experience with such translation). Nevertheless most of us still often ")#strong[#text("think")]#text(" in mereological terms rather than set-theoretic or first-order terms (unless when actually dealing with sets as geometric or other structured spaces, or when focusing on logical, computational, or game-theoretic aspects of one’s assertions, in which case the set-theoretic or first-order formalism becomes advantageous). One mathematician can say to another, “By Heine-Borel, compactness in a Euclidean space is the same as being closed and bounded” and understand and use it immediately without requiring translation to set theory or first order logic; indeed, such a translation would only serve to slow that mathematician down as he or she would usually have translate it back into mereological form in order to wield it effectively. Because of this, I think it is worth adjusting our notational conventions to more closely align with our actual thought processes, especially if it can be done without sacrificing any precision or rigour. For instance, the two statements discussed above would now be translated as “")#mi("3 = \\text{prime}")#text("” and “")#mi("\\mathrm{prime} \\& \\mathrm{greater\\ than\\ } 2 = \\mathrm{odd}")#text("“, thus having almost identical grammatical structure to mathematical English.")

#text("The approach of viewing asymptotic orders as ideals is certainly a useful one, particularly when one wants to apply algebraic modes of reasoning to one’s problem (e.g., one may want to “mod out” lower order terms). This approach combines particularly well with the nonstandard analysis formalism for asymptotic notation, in which for instance the space ")#mi("o({\\bf R}) := \\{ x \\in {}^* {\\bf R}: x=o(1)\\}")#text(" of infinitesimal nonstandard reals is indeed an ideal of the ring ")#mi("O({\\bf R}) := \\{ x \\in {}^* {\\bf R}: x = O(1)\\}")#text(" of bounded nonstandard reals, with a useful short exact sequence ")#mi("0 \\to o({\\bf R}) \\to O({\\bf R}) \\stackrel{\\mathrm{st}}{\\to} {\\bf R} \\to 0")#text(". It is particularly suitable for situations in which asymptotic notation is used exclusively to describe additive errors, e.g., ")#mi("X = Y + O(Z)")#text(" (which one can rewrite suggestively as ")#mi("X = Y \\text{ mod } O(Z)")#text("). However, there are other use-cases of asymptotic notation (particularly those involving nonlinear functions such as the exponential) in which the ideal-theoretic approach is less helpful. For instance, I don’t see much advantage in interpreting each instance of the ")#mi("O()")#text(" notation in the exponential type bound ")#mi("f(n) = O(\\exp(O(n^{O(1)})))")#text(" or the calculation ")#mi("(1 + O(1/n))^{O(n)} = \\exp( O(1/n) \\cdot O(n) ) = \\exp(O(1)) = O(1)")#text(" (for ")#mi("n")#text(" sufficiently large), in terms of ideals.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643700")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2022")])]

#text("It should be remarked that Leibniz envisioned a universal symbolic language for the representation and analysis of mathematical, scientific and metaphysical concepts, see")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/Alphabet_of_human_thought")[#text("https://en.wikipedia.org/wiki/Alphabet_of_human_thought")]#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/Characteristica_universalis")[#text("https://en.wikipedia.org/wiki/Characteristica_universalis")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e67ccdef6418653754409683c1d747a63579f2eea27718d91bd692d48950f042-49cc1f4a9ee95676b31f546ebd3ddb0a7bc67c7c3e2ad4292088c4f9a4a120dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Kirby")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643725")[#strong[#text("Jonathan Kirby")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2022")])]

#text("That makes a lot of sense. I think the standard formalisation of mathematical language (if such a thing exists) is second-order logic rather than first-order but I agree that the equivalence between intensional properties and extensional sets is not obvious until you are used to it.")#linebreak()#text(" For me the sticking point with asymptotic notation was always the overloading of the = symbol to mean something which is obviously not symmetric. In similar contexts I try to use something else (e.g. the word “is”). Maybe if the ideas in your blogpost become widely propagated and accepted then other people will not have the same problem when they are learning about it.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643611")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2022")])]

#text("It seems that an object is completely specified by a property iff the set of object satisfying the property is a singleton (whose only element is the completely specified object)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643613")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2022")])]

#text("In the Wikipedia page (")#link("https://en.wikipedia.org/wiki/Big_O_notation#Formal_definition")[#text("https://en.wikipedia.org/wiki/Big_O_notation#Formal_definition")]#text("), ")#mi("f(x)=O(g(x))")#text(" means ")#tao-math("\\left|f(x)\\right|\\leq C g(x)", block: false)#text(" *eventually* (instead of for the whole domain) for some constant ")#mi("C")#text(", assuming ")#mi("g")#text(" is positive. How would one write this in terms those in Definition 4?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643693")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2022")])]

#text("I would introduce a different notation for this type of “asymptotic” type of bound, for instance ")#mi("f(x) = O_{x \\to \\infty}(g(x))")#text(". But one can express it also in terms of the notation provided, namely as ")#mi("f(x) = O(g(x)) + o_{x \\to \\infty}(0)")#text(". (I now realize by the way that my previous definition of ")#mi("o()")#text(" notation contained a slight inaccuracy, in that one should only require the bound ")#tao-math("\\left|Y\\right| \\leq c(x) X", block: false)#text(" to hold on a neighbourhood of ")#mi("x_*")#text(", rather than globally; this is now fixed.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643821")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2022")])]

#text("I’m a bit confused with the remark under Definition 4:")

#text("(This is the “non-asymptotic” form of the ")#mi("{O()}")#text(" and ")#mi("{o()}")#text(" notation, in which the bounds are assumed to hold for all values of parameters. There is also an “asymptotic” variant of these notation that is commonly used in some fields, in which the bounds in question are only assumed to hold in some neighbourhood of an asymptotic value ")#mi("{x_*}")#text(", but we will not focus on that variant here.)")

#text("It seems that the ")#mi("O()")#text(" notation is non-asymptotic but ")#mi("o()")#text(" notation is actually asymptotic already in Definition 4, as it is written that “… for all ")#mi("{x}")#text(" in some neighborhood of ")#mi("{x_*}")#text("“.")

#emph[#text("[Oops, this referred to an older version of the blog post in which ")#mi("o()")#text(" was also defined non-asymptotically. The remark has now been updated – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643616")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2022")])]

#text("This post feels like an entry application to Grothendieck society:) Amazing amount of formalism.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643617")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2022")])]

#text("Dr. Tao:")#linebreak()#text(" Why do you introduce a “symmetric equivalence relation” ")#mi("==")#text(" while the standard equivalence relation is ")#mi("\\sim")#text("? By being an equivalence relation, it is automatically symmetric. Isn’t ")#mi("==")#text(" unnecessary?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e4fc75a3eb62a0338f020f0cf2bba96e4293554c41ec1df929f1c1519021f94-cb3ff6abcadfbd58db3d6fe1389fa75c81309c07869bc6f80fb4df1b0a689f52.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643642")[#strong[#text("S")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2022")])]

#text("Thanks for this formalization: many people who have only occasional encounters with asymptotic notation get bothered by it and propose using set notation everywhere instead of “abusing” the equals sign; this post finally is something to point to about how to use and interpret asymptotic notation in its usual form.")

#text("Donald Knuth once mentioned an unfulfilled dream (in a letter to AMS, available e.g. ")#link("https://shreevatsa.wordpress.com/2014/03/13/big-o-notation-a-couple-of-sources/")[#text("here")]#text(") of writing a book called “O Calculus”, doing everything with O notation: for example, he wrote, a function ")#mi("f")#text(" is continuous at a point ")#mi("x")#text(" if ")#mi("f(x + \\epsilon) = f(x) + o(1)")#text(". In the language of this post, I guess that the more precise version would be: ")#mi("{f(x + \\epsilon) = f(x) + o_{\\epsilon \\rightarrow 0; f,x}(1)}")#text(" for all ")#mi("x")#text(". Anyway, looking at this post, it seems that writing such a text would be both a bit more nontrivial than expected, but also actually possible and likely instructive. Interesting to think about!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643651")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2022")])]

#text("Is my interpretation of the asymptotic notation correct for continuity? I am not sure about converting the parameter of the little o notation to the usual ")#mi("\\epsilon, \\delta")#text(" notation for continuity. Please check:")#linebreak()#text(" To write ")#mi("f")#text(" is continuous in asymptotic notion:")

#mi("\\displaystyle f(y)-f(x) = o_{y\\rightarrow x;f,x}(1)")

#text("According to Definition 4, it means")

#tao-math("\\displaystyle \\left|f(y)-f(x)\\right|\\leq c(f,x)(y)\\cdot 1", block: false)

#text("for some ")#mi("c(f,x)>0")#text(" such that ")#mi("c(f,x)\\rightarrow0")#text(" as ")#mi("y\\rightarrow x")#text(".")

#text("We can choose ")#tao-math("c(f,x)=\\left|y-x\\right|", block: false)#text(", then it follows that")

#tao-math("\\displaystyle \\left|f(y)-f(x)\\right|\\leq \\left|y-x\\right|", block: false)

#text("which goes to 0 as ")#mi("y\\rightarrow x")#text(", which is the definition of continuity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643696")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2022")])]

#text("The function ")#tao-math("\\left|y-x\\right|", block: false)#text(" is one choice for ")#mi("c(f,x)")#text(", but it is not the only possible choice. This choice confirms that ")#mi("1")#text("-Lipschitz functions are continuous, but the converse is certainly not true; there exist continuous functions that are not Lipschitz.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Babayoga")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643689")[#strong[#text("Babayoga")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2022")])]

#text("But can you make M theory rigorous?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chorasimilarity")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643721")[#strong[#text("chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2022")])]

#text("Your LHS = RHS notation seems to me like the statement “each instance of LHS is obtained after a (finite? uniform?) sequence of rewrites of an instance of RHS” so in a sense LHS = RHS may say either that LHS is an interesting consequence of RHS or that RHS is an interesting cause of LHS. But also: LHS is reachable in a constrained (inteligent? human?) evolution from RHS, or RHS is a range of an unconstrained evolution of LHS.")

#text("To me it looks that all this is not about multiple values, but about strategies of control of multiple possible rewrites.")

#text("Both strategies (constrain the path of rewrites, let the rewrites explode to cover a territory) are useful to the skilled human.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adrian Fellhauer")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643782")[#strong[#text("Adrian Fellhauer")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2022")])]

#text("an partially specified instance => a partially specified instance")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643793")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2022")])]

#text("Do we always use “contractible” instead of “contractable” in math? Google the two words, they mean the same thing, and “contractible” is not even regarded as a word. So is “contractibility” unique in math language?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643901")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2022")])]

#text("My understanding is that an object is ")#link("https://www.lexico.com/en/definition/contractible")[#text("contractible")]#text(" if it can be (intransitively) contracted, whereas an object is ")#link("https://www.lexico.com/en/definition/contractable")[#text("contractable")]#text(" if it can be (transitively) contracted to something else. For instance, a disease can be contractable (to a recipient), but not contractible (the disease vector cannot be contracted into a smaller shape), whereas for topological spaces the situation is reversed.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a574a7eef7bebcdb6e602fff06626fe1c372a3d4149dd1a2bc5aedd4fb5f558d-8aa1cbd2db3e509e6413c2cfed9ba63227245c9ecb620fd45eb9aaa7a438848d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643805")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2022")])]

#text("In teaching math to undergraduates – both math majors and engineers – I have for many years incorporated asymptotic notation from the very start (following a suggestion of D. Knuth), thus e.g. defining the derivative of a function not via the usual difference quotient but as the unique solution of the asymptotic equation f(x+h) = f(x) + f'(x)h + o(h). In my experience, this has had major pedagogical advantages, e.g. the proof of the product rule becomes much clearer and the transition to multivariable calculus becomes much smoother. However, in my first few attempts students have always been struggling with the fact that = is no longer a symmetric relation. Once I replaced the equality sign by the element and subset symbols, these problems went away, and the exam results of the students improved quite drastically. Later on, it was no problem to convert the notation to the one you are suggesting, but from a pedagogical point of view I believe that it is useful to insist, at least initially, that o(h) stands for a class of functions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11eed6da60c8c3306b786526064a8733f4f9d93b704ca3e0f3fb4adf50337aaf-60a0d2262bea3c0344fd29fb667c13ed056a99cc3408620fae5cf70e30ad4e21.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Mertens")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-644032")[#strong[#text("Martin Mertens")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2022")])]

#text("“in my first few attempts students have always been struggling with the fact that = is no longer a symmetric relation”")

#text("My solution is to write something along the lines of")

#text("f(x+h) = f(x) + f'(x)h + ϕ(h) for some ϕ ∈ o(h)")

#text("After we’ve proved the product rule, chain rule, etc. I’ll introduce the standard notation f(x+h) = f(x) + f'(x)h + o(h) as a shortcut. But I’m not a math teacher so I haven’t tested this with students.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b4a1c26001d9306c3dddd8069aa2850e348def74d0fc339be82e6b790e9125a-ada560f8efcf397b4d37dd7fe92e73b223b21e98053be0005dfe0cdbc016fe44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aurel")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643819")[#strong[#text("Aurel")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2022")])]

#text("In definition 4, shouldn’t ")#mi("o_{x\\to\\infty}")#text(" be ")#mi("o_{x\\to x_*}")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643823")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2022")])]

#text("No. It is correctly stated.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643824")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2022")])]

#text("Does anyone know the latex comment for integral average? i.e. the integral sign ")#mi("\\int")#text(", but with a horizontal bar across the centre. Couldn’t find it anywhere.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b71017f3ba0f543c5044556f27512e72972ffa9e69a8bf9184eadd8f7695b8bf-bea05fabd012afb0eff4e8714fccbbf0a0ed5d4690e1d374727fd01c1f9ac003.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Ruxton")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-644095")[#strong[#text("Michael Ruxton")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2022")])]

#text("Look for Scott Pakin’s Comprehensive LATEX Symbol List")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liewyee")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-643872")[#strong[#text("Liewyee")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2022")])]

#text("I can clearly find out the association between the underlying logic （logic）and the elegant-number-sequences（language of mathmetic/set theory and etc.）which behind them through this blog，thank U Tao.")#linebreak()#text(" and have a nice day of 520.")#linebreak()#text(" I love U.")#linebreak()#text(" A poem for U in mine，hope U like it～^____^")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-644304")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2022")])]

#text("l wish you all the peace at Dragon Boat Festival.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-644781")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2022")])]

#text("Is this related to plural logic?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abc838d222f5b3e391c7058ef5d31c4591efe53627896e6140c10a517fca9f5d-23b5ce02f51a78f798414c41dfce4c9f9f7dac65388a3c5263f19998eaf591f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of m")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-644846")[#strong[#text("m")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2022")])]

#text("“”A bit more subtly, parameters can disappear at the conclusion of a portion of an argument….")

#text("The axioms of topology and many (most?) consequences of compactness/uniformity can be expressed as rules of inference")#linebreak()#text(" stating that “parameters can disappear” in many particular situations, see examples below.")#linebreak()#text(" Of course, it is precisely the intuition (e.g., explained to a student) of compactness/uniformity")#linebreak()#text(" but what formalism for topology would make this explicit? Is there a formalism for parametrised logic allowing")#linebreak()#text(" to add and remove parameters explicitly ?")

#text("For example, axiom “the intersection of open subsets is open” we first reformulate as")#linebreak()#text(" “a set is open if it contains an open neighbourhood of each point”, and then express it as follows.")#linebreak()#text(" ")#emph[#linebreak()#text(" Given a subset ")#mi("X")#text(", if there is an parametrised open neighbourhood ")#mi("x\\in U(x) \\subset X")#linebreak()#text(" for each parameter ")#mi("x\\in X")#text(",")#linebreak()#text(" then")#linebreak()#text(" there is an absolute (i.e. non-parametrised, constant) open neighbourhood ")#mi("x\\in U \\subset X")#text(" for each ")#mi("x\\in X")#text(".")#linebreak()#text(" ")]#text(" (necessarily ")#mi("U=X")#text(").")

#text("Similarly, axiom “the intersection of finitely many open subsets is open” we first reformulate as")

#emph[#text("“if a point can be separated by a neighbourhood from each of the finitely many subsets, then it")#linebreak()#text(" can be separated by a neighbourhood from all of them at the same time”.")#linebreak()#text(" ")]

#text("Now we reformulate this using parametrised variables and see that")#linebreak()#text(" it claims that a parameter can disappear in a particular situation:")

#emph[#linebreak()#text(" “if a point ")#mi("x")#text(" can be separated by a parametrised neighbourhood ")#mi("x\\in U(n)")#linebreak()#text(" from a parametrised subset ")#mi("X(n)")#text(", for parameter ")#mi("n\\leq N")#linebreak()#text(" (i.e. there is an parametrised open neighbourhood ")#mi("x\\in U(n)")#text(" such that ")#mi("U(n) \\cap X(n) =\\emptyset")#text(" for each parameter ")#mi("0\\leq n \\leq N")#text(")")#linebreak()#text(" then ")#mi("x")#text(" can be separated by a non-parametrised neighbourhood ")#mi("x\\in U(n)")#linebreak()#text(" from the parametrised subset ")#mi("X(n)")#linebreak()#text(" (i.e. there is an non-parametrised open neighbourhood ")#mi("x\\in U")#text(" such that ")#mi("U \\cap X(n)=\\emptyset")#text(" for each ")#mi("x\\in X")#text(".)")#linebreak()#text(" ")]#linebreak()#text(" In fact, this remains true if we let parameter ")#mi("n")#text(" vary over a compact domain; this is what is used in the standard proof")#linebreak()#text(" that a Hausdorff compact is normal.")#linebreak()#text(" “” For instance, we can define a parameterised real ")#mi("{x = x(n,N)}")#text(" to be bounded if there exists an absolute")#linebreak()#text(" constant ")#mi("{C}")#text(" such that ")#tao-math("{\\left|x\\right| \\leq C}", block: false)#text(";")

#text("Yet another example is the consequence of compactness stating that on a compact domain")#linebreak()#text(" each function is bounded, i.e. in your terminology, that")#linebreak()#text(" each real ")#mi("x=x(t)")#text(" continuously parametrised over a compact domain $t\\in K$ is bounded")#linebreak()#text(" by an absolute constant $C$ such that $|x|\\leq C$.")

#text("This can be expressed literally as a rule making parameter disappear in a specific situation, as follows.")

#text("From the (trivially true) hypothesis that ")#emph[#text("for parameter ")#mi("t")#text(" varying over a compact domain ")#mi("K")#text(",")#linebreak()#text(" for each parametrised continuous real variable ")#mi("x=x(t)")#text(" there is a parametrised real variable ")#mi("y=y(t)")#text(" such that ")#mi("x\\leq y")]#linebreak()#text(" it follows that")#linebreak()#text(" ")#emph[#text("for parameter ")#mi("t")#text(" varying over a compact domain ")#mi("K")#text(",")#linebreak()#text(" for each parametrised continuous real variable ")#mi("x=x(t)")#linebreak()#text(" there is an absolute (i.e. non-parametrised) real variable ")#mi("y")#linebreak()#text(" such that ")#mi("x \\leq y")#text(".")#linebreak()#text(" ")]

#text("In what formalism this would be the definition of compactness ? Could any of the examples above can be understood")#linebreak()#text(" in terms of elementary topos you mention ? Is there a formalism (proof system) for parametrised logic ?")

#text("Let me finish by mentioning a few other examples of topological statements and definitions")#linebreak()#text(" which can be reformulated in this way, as rules of inference stating that parameters can disappear:")#linebreak()#text(" the image of a closed set is closed; Lebesgue number Lemma; paracompactness.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-644998")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2022")])]

#text("I believe that the formalism of ")#link("https://en.wikipedia.org/wiki/Dependent_type")[#text("dependent type theory")]#text(" can be used to capture this sort of parameterised reasoning formally. Probably one can also formalize things in topos-theoretic terms, but I have not looked into this carefully.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0a097419eee8270506ad8f05935937359bd590c640a61761e39671028d81380-ac0234c5dedd65a57f910ff87c001258a7f5f8cb91e8f9a2e9d79f8044bf0203.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of robertkhan397")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-646006")[#strong[#text("robertkhan397")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2022")])]

#text("Math can be pretty amazing, as I learned from this blog post. I never knew there were so many cool details and facts about math! This website is a great resource for learning more about math, with plenty of information and tutorials. I also found some other sites , blogs and and online courses that are worth checking out for anyone who wants to learn more about ")#link("https://lead-academy.org/course/functional-skills-maths-level-2/")[#text("mathematics.")]#text(" Thanks for sharing this information!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arnie Bebita-Dris")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-677721")[#strong[#text("Arnie Bebita-Dris")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2023")])]

#text("I enjoyed reading this blog post, Professor Tao, though admittedly some of it were beyond me.")

#text("If I may just ask, are you trying to develop mathematical notation/syntax for formalizing sigma/factor chain proofs, which are currently automated using high-speed computers?")

#text("Seeing that you mentioned odd perfect numbers early on when you introduced the concept of partially specified mathematical expressions, and having dived into this blog post and having digested what I could understand and “read”, I feel and believe that your discussion here lends itself well to such an approach.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bounding sums or integrals of non-negative quantities | What's new")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-681882")[#strong[#text("Bounding sums or integrals of non-negative quantities | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2023")])]

#text("[…] where is a quantity that goes to zero as the parameters of the problem go to infinity (or some other limit). (For a deeper dive into asymptotic notation in general, see this previous blog post.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-685661")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2024")])]

#text("It is intriguing that Definition 4 employs the ‘non-asymptotic’ form of the ")#emph[#text("asymptotic")]#text(" notation ")#mi("O()")#text(".")

#text("Is this choice primarily a matter of preference, or are there subtleties that necessitate using one version over the other? In analysis, how frequently does one need to maintain control for all values, as opposed to merely for sufficiently large parameters?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/#comment-685664")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2024")])]

#text("Generally speaking, subjects in analysis often start in a “qualitative” stage, in which asymptotic results are only obtained in sufficiently large ranges without any explicit control on what “sufficiently large” means, but as the subject develops, the estimates become more and more “quantitative”, and in particular conditions on certain parameters being sufficiently large are often either made much more explicit, or discarded altogether. All things being equal, it is preferable to have estimates that are valid for the entire range of parameters rather than for sufficiently large parameters, as they are easier to use as input into other estimates, particularly if one wishes to apply some change of variable in which a key parameter may not necessarily be “sufficiently large” any more. A common case when this occurs is when one wishes to apply some estimate at a scale that is the ratio ")#mi("X/Y")#text(" of two large parameters ")#mi("X")#text(" and ")#mi("Y")#text(" with ")#mi("1 \\leq Y \\leq X")#text("; both of these parameters may separately be “sufficiently large”, but this does not guarantee that the ratio is, and so it becomes important ensure that the estimate one is applying is non-asymptotic in nature, lest one make some serious mistakes in the analysis.")
]
]
