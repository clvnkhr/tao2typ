// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/12/08/the-story-of-erdos-problem-126/
// Converted to Typst by tao2typ: "2026-10-14T15:21:09.024656+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The story of Erdős problem #1026", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The story of Erdős problem #1026")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 December 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/12/08/the-story-of-erdos-problem-126/")[#text("https://terrytao.wordpress.com/2025/12/08/the-story-of-erdos-problem-126/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://www.erdosproblems.com/1026")[#text("Problem 1026 on the Erdős problem web site")]#text(" recently got solved through an interesting combination of existing literature, online collaboration, and AI tools. The purpose of this blog post is to try to tell the story of this collaboration, and also to supply a complete proof.")

#text("The original problem of Erdős, ")#link("https://users.renyi.hu/~p_erdos/1971-25.pdf")[#text("posed in 1975")]#text(", is rather ambiguous. Erdős starts by ")#link("https://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93Szekeres_theorem")[#text("recalling his famous theorem with Szekeres")]#text(" that says that given a sequence of ")#mi("{k^2+1}")#text(" distinct real numbers, one can find a subsequence of length ")#mi("{k+1}")#text(" which is either increasing or decreasing; and that one cannot improve the ")#mi("{k^2+1}")#text(" to ")#mi("{k^2}")#text(", by considering for instance a sequence of ")#mi("{k}")#text(" blocks of length ")#mi("{k}")#text(", with the numbers in each block decreasing, but the blocks themselves increasing. He also noted a ")#link("https://zbmath.org/0090.01302")[#text("result of Hanani")]#text(" that every sequence of length ")#mi("{k(k+3)/2}")#text(" can be decomposed into the union of ")#mi("{k}")#text(" monotone sequences. He then wrote “As far as I know the following question is not yet settled. Let ")#mi("{x_1,\\dots,x_n}")#text(" be a sequence of distinct numbers, determine")

#align(center)[#tao-fit-display[#mitex("S(x_1,\\dots,x_n) = \\max \\sum_r x_{i_r}")]]

#text("where the maximum is to be taken over all monotonic sequences ")#mi("{x_{i_1},\\dots,x_{i_m}}")#text("“.")

#text("This problem was added to the Erdős problem site on September 12, 2025, with a note that the problem was rather ambiguous. For any fixed ")#mi("{n}")#text(", this is an explicit piecewise linear function of the variables ")#mi("{x_1,\\dots,x_n}")#text(" that could be computed by a simple brute force algorithm, but Erdős was presumably seeking optimal bounds for this quantity under some natural constraint on the ")#mi("{x_i}")#text(". The day the problem was posted, Desmond Weisenberg proposed studying the quantity ")#mi("{c(n)}")#text(", defined as the largest constant such that")

#align(center)[#tao-fit-display[#mitex("S(x_1,\\dots,x_n) \\geq c(n) \\sum_{i=1}^n x_i")]]

#text("for all choices of (distinct) real numbers ")#mi("{x_1,\\dots,x_n}")#text(". Desmond noted that for this formulation one could assume without loss of generality that the ")#mi("{x_i}")#text(" were positive, since deleting negative or vanishing ")#mi("{x_i}")#text(" does not increase the left-hand side and does not decrease the right-hand side. By a limiting argument one could also allow collisions between the ")#mi("{x_i}")#text(", so long as one interpreted monotonicity in the weak sense.")

#text("Though not stated on the web site, one can formulate this problem in game theoretic terms. Suppose that Alice has a stack of ")#mi("{N}")#text(" coins for some large ")#mi("{N}")#text(". She divides the coins into ")#mi("{n}")#text(" piles of consisting of ")#mi("{x_1,\\dots,x_n}")#text(" coins each, so that ")#mi("{\\sum_{i=1}^n x_i = N}")#text(". She then passes the piles to Bob, who is allowed to select a monotone subsequence of the piles (in the weak sense) and keep all the coins in those piles. What is the largest fraction ")#mi("{c(n)}")#text(" of the coins that Bob can guarantee to keep, regardless of how Alice divides up the coins? (One can work with either a discrete version of this problem where the ")#mi("{x_i}")#text(" are integers, or a continuous one where the coins can be split fractionally, but in the limit ")#mi("{N \\rightarrow \\infty}")#text(" the problems can easily be seen to be equivalent.)")

#text("AI-generated images continue to be problematic for a number of reasons, but here is one such image that somewhat manages at least to convey the idea of the game:")

#image("../assets/d308edc5a078bcd7fa685c3f74325455d95961231963275bd1651fc239f9747e-6128f3822dc318f3524068890457daa874ce2671c996820d82f8c9491e88d39b.jpg", width: 90%)

#text("For small ")#mi("{n}")#text(", one can work out ")#mi("{c(n)}")#text(" by hand. For ")#mi("{n=1}")#text(", clearly ")#mi("{c(1)=1}")#text(": Alice has to put all the coins into one pile, which Bob simply takes. Similarly ")#mi("{c(2)=1}")#text(": regardless of how Alice divides the coins into two piles, the piles will either be increasing or decreasing, so in either case Bob can take both. The first interesting case is ")#mi("{n=3}")#text(". Bob can again always take the two largest piles, guaranteeing himself ")#mi("{2/3}")#text(" of the coins. On the other hand, if Alice ")#emph[#text("almost")]#text(" divides the coins evenly, for instance into piles ")#mi("{((1/3 + \\varepsilon)N, (1/3-2\\varepsilon) N, (1/3+\\varepsilon)N)}")#text(" for some small ")#mi("{\\varepsilon>0}")#text(", then Bob cannot take all three piles as they are non-monotone, and so can only take two of them, allowing Alice to limit the payout fraction to be arbitrarily close to ")#mi("{2/3}")#text(". So we conclude that ")#mi("{c(3)=2/3}")#text(".")

#text("An hour after Desmond’s comment, ")#link("https://www.erdosproblems.com/forum/thread/1026#post-466")[#text("Stijn Cambie noted")]#text(" (though not in the language I used above) that a similar construction to the one above, in which Alice divides the coins into ")#mi("{k^2}")#text(" pairs that are almost even, in such a way that the longest monotone sequence is of length ")#mi("{k}")#text(", gives the upper bound ")#mi("{c(k^2) \\leq 1/k}")#text(". It is also easy to see that ")#mi("{c(n)}")#text(" is a non-increasing function of ")#mi("{n}")#text(", so this gives a general bound ")#mi("{c(n) \\leq (1+o(1))/\\sqrt{n}}")#text(". Less than an hour after that, ")#link("https://www.erdosproblems.com/forum/thread/1026#post-467")[#text("Wouter van Doorn noted")]#text(" that the Hanani result mentioned above gives the lower bound ")#mi("{c(n) \\geq (\\frac{1}{\\sqrt{2}}-o(1))/\\sqrt{n}}")#text(", and posed the problem of determining the asymptotic limit of ")#mi("{\\sqrt{n} c(n)}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", given that this was now known to range between ")#mi("{1/\\sqrt{2}-o(1)}")#text(" and ")#mi("{1+o(1)}")#text(". This version was ")#link("https://www.erdosproblems.com/forum/thread/1026#post-473")[#text("accepted by Thomas Bloom")]#text(", the moderator of the Erdős problem site, as a valid interpretation of the original problem.")

#text("The next day, ")#link("https://www.erdosproblems.com/forum/thread/1026#post-478")[#text("Stijn computed")]#text(" the first few values of ")#mi("{c(n)}")#text(" exactly:")

#align(center)[#tao-fit-display[#mitex("1, 1, 2/3, 1/2, 1/2, 3/7, 2/5, 3/8, 1/3.")]]

#text("While the general pattern was not yet clear, this was enough data for Stijn to conjecture that ")#mi("{c(k^2)=1/k}")#text(", which would also imply that ")#mi("{\\sqrt{n} c(n) \\rightarrow 1}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". (EDIT: as later located by an AI deep research tool, this conjecture was also made in Section 12 of ")#link("https://zbmath.org/0832.60012")[#text("this 1980 article of Steele")]#text(".) Stijn also described the extremizing sequences for this range of ")#mi("{n}")#text(", but did not continue the calculation further (a naive computation would take runtime exponential in ")#mi("{n}")#text(", due to the large number of possible subsequences to consider).")

#text("The problem then lay dormant for almost two months, until December 7, 2025, in which Boris Alexeev, as part of a systematic sweep of the Erdős problems using the AI tool ")#link("https://arxiv.org/abs/2510.01346")[#text("Aristotle")]#text(", was able to get this tool to ")#link("https://github.com/plby/lean-proofs/blob/main/src/v4.24.0/ErdosProblems/Erdos1026.lean")[#text("autonomously solve")]#text(" this conjecture ")#mi("{c(k^2)=1/k}")#text(" in the proof assistant language Lean. The proof converted the problem to a rectangle-packing problem.")

#text("This was one further addition to a recent sequence of examples where an Erdős problem had been automatically solved in one fashion or another by an AI tool. Like the previous cases, the proof turned out to not be particularly novel. Within an hour, Koishi Chan gave an alternate proof deriving the required bound ")#mi("{c(k^2) \\geq 1/k}")#text(" from the original Erdős-Szekeres theorem by a standard “blow-up” argument which we can give here in the Alice-Bob formulation. Take a large ")#mi("{M}")#text(", and replace each pile of ")#mi("{x_i}")#text(" coins with ")#mi("{(1+o(1)) M^2 x_i^2}")#text(" new piles, each of size ")#mi("{(1+o(1)) x_i}")#text(", chosen so that the longest monotone subsequence in this collection is ")#mi("{(1+o(1)) M x_i}")#text(". Among all the new piles, the longest monotone subsequence has length ")#mi("{(1+o(1)) M S(x_1,\\dots,x_n)}")#text(". Applying Erdős-Szekeres, one concludes the bound")

#align(center)[#tao-fit-display[#mitex("M S(x_1,\\dots,x_n) \\geq (1-o(1)) (\\sum_{i=1}^{k^2} M^2 x_i^2)^{1/2}")]]

#text("and on canceling the ")#mi("{M}")#text("‘s, sending ")#mi("{M \\rightarrow \\infty}")#text(", and applying Cauchy-Schwarz, one obtains ")#mi("{c(k^2) \\geq 1/k}")#text(" (in fact the argument gives ")#mi("{c(n) \\geq 1/\\sqrt{n}}")#text(" for all ")#mi("{n}")#text(").")

#text("Once this proof was found, it was natural to try to see if it had already appeared in the literature. AI deep research tools have successfully located such prior literature in the past, but in this case they did not succeed, and a more “old-fashioned” Google Scholar job turned up some relevant references: a ")#link("https://arxiv.org/abs/1608.04153")[#text("2016 paper by Tidor, Wang and Yang")]#text(" contained this precise result, citing an ")#link("https://arxiv.org/abs/1612.00471")[#text("earlier paper of Wagner")]#text(" as inspiration for applying “blowup” to the Erdős-Szekeres theorem.")

#text("But the story does not end there! Upon reading the above story the next day, I realized that the problem of estimating ")#mi("{c(n)}")#text(" was a suitable task for ")#link("https://arxiv.org/abs/2506.13131")[#text("AlphaEvolve")]#text(", which I have used recently as mentioned in ")#link("https://terrytao.wordpress.com/2025/11/05/mathematical-exploration-and-discovery-at-scale/")[#text("this previous post")]#text(". Specifically, one could task to obtain upper bounds on ")#mi("{c(n)}")#text(" by directing it to produce real numbers (or integers) ")#mi("{x_1,\\dots,x_n}")#text(" summing up to a fixed sum (I chose ")#mi("{10^6}")#text(") with a small a value of ")#mi("{S(x_1,\\dots,x_n)}")#text(" as possible. After an hour of run time, AlphaEvolve produced the following upper bounds on ")#mi("{c(n)}")#text(" for ")#mi("{1 \\leq n \\leq 16}")#text(", with some intriguingly structured potential extremizing solutions:")

#image("../assets/422419de95c28d216ace5ec74892b8beb638aa5c600738842727e44f5f6d8118-bbddf38b27d525fcb93b47890e69eab0cfbdcc96d4dbae6063195e6f8c6bb8fb.png", width: 90%)

#text("The numerical scores (divided by ")#mi("{10^6}")#text(") were pretty obviously trying to approximate simple rational numbers. There were a variety of ways (including modern AI) to extract the actual rational numbers they were close to, but I searched for a dedicated tool and found this useful ")#link("https://www.johndcook.com/rational_approximation.html")[#text("little web page of John Cook")]#text(" that did the job:")

#align(center)[#tao-fit-display[#mitex("1, 1, 2/3, 1/2, 1/2, 3/7, 2/5, 3/8, 1/3, 1/4.")]]

#align(center)[#tao-fit-display[#mitex("1/3, 4/13, 3/10, 4/14, 3/11, 4/15, 1/4.")]]

#text("I could not immediately see the pattern here, but after some trial and error in which I tried to align numerators and denominators, I eventually organized this sequence into a more suggestive form:")

#align(center)[#tao-fit-display[#mitex("1,")]]

#align(center)[#tao-fit-display[#mitex("1/1, \\mathbf{2/3}, 1/2,")]]

#align(center)[#tao-fit-display[#mitex("2/4, \\mathbf{3/7}, 2/5, \\mathbf{3/8}, 2/6,")]]

#align(center)[#tao-fit-display[#mitex("3/9, \\mathbf{4/13}, 3/10, \\mathbf{4/14}, 3/11, \\mathbf{4/15}, 3/12.")]]

#text("This gave a somewhat complicated but predictable conjecture for the values of the sequence ")#mi("{c(n)}")#text(". On posting this, Boris found a clean formulation of the conjecture, namely that")

#metadata(none) <tao-d1a73570aa079cee4251>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("c(k^2 + 2a + 1) = \\frac{k}{k^2+a}")]]

#text("whenever ")#mi("{k \\geq 1}")#text(" and ")#mi("{-k \\leq a \\leq k}")#text(". After a bit of effort, he also produced an explicit upper bound construction:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" If ")#mi("{k \\geq 1}")#text(" and ")#mi("{-k \\leq a \\leq k}")#text(", then ")#mi("{c(k^2+2a+1) \\leq \\frac{k}{k^2+a}}")#text(".")
]

#emph[#text("Proof:")]#text(" Consider a sequence ")#mi("{x_1,\\dots,x_{k^2+2a+1}}")#text(" of numbers clustered around the “red number” ")#tao-math("{\\left|a\\right|}", block: false)#text(" and “blue number” ")#tao-math("{\\left|a+1\\right|}", block: false)#text(", consisting of ")#tao-math("{\\left|a\\right|}", block: false)#text(" blocks of ")#tao-math("{k-\\left|a\\right|}", block: false)#text(" “blue” numbers, followed by ")#tao-math("{\\left|a+1\\right|}", block: false)#text(" blocks of ")#tao-math("{\\left|a+1\\right|}", block: false)#text(" “red” numbers, and then ")#tao-math("{k-\\left|a\\right|}", block: false)#text(" further blocks of ")#mi("{k}")#text(" “blue” numbers. When ")#mi("{a \\geq 0}")#text(", one should take all blocks to be slightly decreasing within each block, but the blue blocks should be are increasing between each other, and the red blocks should also be increasing between each other. When ")#mi("{a < 0}")#text(", all of these orderings should be reversed. The total number of elements is indeed")

#align(center)[#tao-fit-display[#tao-math("\\left|a\\right| \\times (k-\\left|a\\right|) + \\left|a+1\\right| \\times \\left|a+1\\right| + (k-\\left|a\\right|) \\times k", block: true)]]

#align(center)[#tao-fit-display[#mitex("= k^2 + 2a + 1")]]

#text("and the total sum is close to")

#align(center)[#tao-fit-display[#tao-math("\\left|a\\right| \\times (k-\\left|a\\right|) \\times \\left|a+1\\right| + \\left|a+1\\right| \\times \\left|a+1\\right| \\times \\left|a\\right|", block: true)]]

#align(center)[#tao-fit-display[#tao-math("+ (k-\\left|a\\right|) \\times k \\times \\left|a+1\\right| = (k^2 + a) |a+1|.", block: true)]]

#text("With this setup, one can check that any monotone sequence consists either of at most ")#tao-math("{\\left|a+1\\right|}", block: false)#text(" red elements and at most ")#tao-math("{k-\\left|a\\right|}", block: false)#text(" blue elements, or no red elements and at most ")#mi("{k}")#text(" blue elements, in either case giving a monotone sum that is bounded by either")

#align(center)[#tao-fit-display[#tao-math("\\left|a+1\\right| \\times \\left|a\\right| + (k-\\left|a\\right|) \\times \\left|a+1\\right| = k \\left|a+1\\right|", block: true)]]

#text("or")

#align(center)[#tao-fit-display[#tao-math("0 + k \\times \\left|a+1\\right| = k \\left|a+1\\right|,", block: true)]]

#text("giving the claim. ")#mi("\\Box")

#text("Here is a figure illustrating the above construction in the ")#mi("{a \\geq 0}")#text(" case (obtained after starting with a ChatGPT-provided file and then manually fixing a number of placement issues):")

#image("../assets/595b6f9c7ddda2f69a8bf7b9dfec81f8bcf729b58f8a86851458867b65c66981-2a5d94c10b815f75185175614ad5c7b7235d8d0d813e169e1c51f74fa9202655.png", width: 90%)

#text("Here is a plot of ")#mi("1/c(n)")#text(" (produced by ChatGPT Pro), showing that it is basically a piecewise linear approximation to the square root function:")

#image("../assets/975b0fc2bf4d232b6f8de58c1db4f60eac03a1ba8449377e19c14c83d7300fd1-8c4d29e3666841b220e13bb2ae7581897fb8a82928dccf1acef0a3d06f5c5ab2.png", width: 90%)

#text("Shortly afterwards, Lawrence Wu clarified the connection between this problem and a square packing problem, which was also ")#link("https://www.erdosproblems.com/106")[#text("due to Erdős (Problem 106)")]#text(". Let ")#mi("{f(n)}")#text(" be the least number such that, whenever one packs ")#mi("{n}")#text(" squares of sidelength ")#mi("{d_1,\\dots,d_n}")#text(" into a square of sidelength ")#mi("{D}")#text(", with all sides parallel to the coordinate axes, one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^n d_i \\leq f(n) D.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" For any ")#mi("{n}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("c(n) \\geq \\frac{1}{f(n)}.")]]
]

#emph[#text("Proof:")]#text(" Given ")#mi("{x_1,\\dots,x_n}")#text(" and ")#mi("{1 \\leq i \\leq n}")#text(", let ")#mi("{S_i}")#text(" be the maximal sum over all increasing subsequences ending in ")#mi("{x_i}")#text(", and ")#mi("{T_i}")#text(" be the maximal sum over all decreasing subsequences ending in ")#mi("{x_i}")#text(". For ")#mi("{i < j}")#text(", we have either ")#mi("{S_j \\geq S_i + x_j}")#text(" (if ")#mi("{x_j \\geq x_i}")#text(") or ")#mi("{T_j \\geq T_i + x_j}")#text(" (if ")#mi("{x_j \\leq x_i}")#text("). In particular, the squares ")#mi("{(S_i-x_i, T_i-x_i)}")#text(" and ")#mi("{(S_j-x_j, T_j-x_j)}")#text(" are disjoint. These squares pack into the square ")#mi("{[0, S(x_1,\\dots,x_n)]^2}")#text(", so by definition of ")#mi("{f}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^n x_i \\leq f(n) S(x_1,\\dots,x_n),")]]

#text("and the claim follows. ")#mi("\\Box")

#text("This idea of using packing to prove Erdős-Szekeres type results goes back to a 1959 paper of ")#link("https://zbmath.org/0085.15003")[#text("Seidenberg")]#text(", although it was a discrete rectangle-packing argument that was not phrased in such an elegantly geometric form. It is possible that Aristotle was “aware” of the Seidenberg argument via its training data, as it had incorporated a version of this argument in its proof.")

#text("Here is an illustration of the above argument using the AlphaEvolve-provided example")

#align(center)[#tao-fit-display[#mitex("[99998, 99997, 116305, 117032, 116304,")]]

#align(center)[#tao-fit-display[#mitex("58370, 83179, 117030, 92705, 99080]")]]

#text("for ")#mi("n=10")#text(" to convert it to a square packing (image produced by ChatGPT Pro):")

#image("../assets/7c2fb5ae95900a87474513e28bbe349a7fdc97ae88f4af36085034233daf2f1b-f8633a117bc89b04abf5b0a53717c0702c623c5d7a264d4a82d354a52f442f0b.png", width: 90%)

#text("At this point, Lawrence performed another AI deep research search, this time ")#link("https://www.erdosproblems.com/forum/thread/1026#post-2108")[#text("successfully locating a paper")]#text(" from just last year by ")#link("https://arxiv.org/abs/2411.07274")[#text("Baek, Koizumi, and Ueoro")]#text(", where they show that")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(" ")#metadata(none) <tao-66e16dd53ecf4fd7b2d4>#text(" For any ")#mi("{k \\geq 1}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("f(k^2+1) \\leq k")]]
]

#text("which, when combined with a ")#link("https://zbmath.org/1178.52014")[#text("previous argument of Praton")]#text(", implies")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4")]#text(" ")#metadata(none) <tao-bd97b2556d67f7301627>#text(" For any ")#mi("{k \\geq 1}")#text(" and ")#mi("{c \\in {\\bf Z}}")#text(" with ")#mi("{k^2+2c+1 \\geq 1}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("f(k^2+2c+1) \\leq k + \\frac{c}{k}.")]]
]

#text("This proves the conjecture!")

#text("There just remained the issue of putting everything together. I did feed all of the above information into a large language model, which was able to ")#link("https://chatgpt.com/share/69373cfb-fa70-800e-af98-ade8926ca5e1")[#text("produce a coherent proof")]#text(" of ")#link(<tao-d1a73570aa079cee4251>)[#text("(1)")]#text(" assuming the results of Baek-Koizumi-Ueoro and Praton. Of course, LLM outputs are prone to hallucination, so it would be preferable to formalize that argument in Lean, but this looks quite doable with current tools, and I expect this to be accomplished shortly. But I was also able to reproduce the arguments of Baek-Koizumi-Ueoro and Praton, which I include below for completeness.")

#emph[#text("Proof:")]#text(" (Proof of Theorem ")#link(<tao-66e16dd53ecf4fd7b2d4>)[#text("3")]#text(", adapted from Baek-Koizumi-Ueoro) We can normalize ")#mi("{D=k}")#text(". It then suffices to show that if we pack the length ")#mi("{k}")#text(" torus ")#mi("{({\\bf Z}/k{\\bf Z})^2}")#text(" by ")#mi("{k^2+1}")#text(" axis-parallel squares of sidelength ")#mi("{d_1,\\dots,d_{k^2+1}}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^{k^2+1} d_i \\leq k^2.")]]

#text("Pick ")#mi("{x_0, y_0 \\in {\\bf R}/k{\\bf Z}}")#text(". Then we have a ")#mi("{k \\times k}")#text(" grid")

#align(center)[#tao-fit-display[#mitex("(x_0 + {\\bf Z}) \\times (y_0 + {\\bf Z}) \\pmod {k{\\bf Z}^2}")]]

#text("inside the torus. The ")#mi("{i^{th}}")#text(" square, when restricted to this grid, becomes a discrete rectangle ")#mi("{A_{i,x_0} \\times B_{i,y_0}}")#text(" for some finite sets ")#mi("{A_{i,x_0}, B_{i,y_0}}")#text(" with")

#metadata(none) <tao-2dd411308b37266d33c9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|\\# A_{i,x_0} -\\# B_{i,y_0}\\right| \\leq 1.", block: true)]]

#text("By the packing condition, we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^{k^2+1} \\# A_{i,x_0} \\# B_{i,y_0} \\leq k^2.")]]

#text("From ")#link(<tao-2dd411308b37266d33c9>)[#text("(2)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("(\\# A_{i,x_0} - 1) (\\# B_{i,y_0} - 1) \\geq 0")]]

#text("hence")

#align(center)[#tao-fit-display[#mitex("\\# A_{i,x_0} \\# B_{i,y_0} \\geq \\# A_{i,x_0} + \\# B_{i,y_0} - 1.")]]

#text("Inserting this bound and rearranging, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^{k^2+1} \\# A_{i,x_0} + \\sum_{i=1}^{k^2+1} \\# B_{i,y_0} \\leq 2k^2 + 1.")]]

#text("Taking the supremum over ")#mi("{x_0,y_0}")#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sup_{x_0} \\sum_{i=1}^{k^2+1} \\# A_{i,x_0} + \\sup_{y_0} \\sum_{i=1}^{k^2+1} \\# B_{i,y_0} \\leq 2k^2 + 1")]]

#text("so by the pigeonhole principle one of the summands is at most ")#mi("{k^2}")#text(". Let’s say it is the former, thus")

#align(center)[#tao-fit-display[#mitex("\\sup_{x_0} \\sum_{i=1}^{k^2+1} \\# A_{i,x_0} \\leq k^2.")]]

#text("In particular, the average value of ")#mi("{\\sum_{i=1}^{k^2+1} \\# A_{i,x_0}}")#text(" is at most ")#mi("{k^2}")#text(". But this can be computed to be ")#mi("{\\sum_{i=1}^{k^2+1} d_i}")#text(", giving the claim. Similarly if it is the other sum. ")#mi("\\Box")

#text("UPDATE: Actually, the above argument also proves Theorem 4 with only minor modifications. Nevertheless, we give the original derivation of Theorem 4 using the embedding argument of Praton below for sake of completeness.")

#emph[#text("Proof:")]#text(" (Proof of Theorem ")#link(<tao-bd97b2556d67f7301627>)[#text("4")]#text(", adapted from Praton) We write ")#tao-math("{c = \\epsilon \\left|c\\right|}", block: false)#text(" with ")#mi("{\\epsilon = \\pm 1}")#text(". We can rescale so that the square one is packing into is ")#mi("{[0,k]^2}")#text(". Thus, we pack ")#tao-math("{k^2+2\\varepsilon \\left|c\\right|+1}", block: false)#text(" squares of sidelength ")#tao-math("{d_1,\\dots,d_{k^2+2\\varepsilon \\left|c\\right|+1}}", block: false)#text(" into ")#mi("{[0,k]^2}")#text(", and our task is to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i=1}^{k^2+2\\varepsilon\\left|c\\right|+1} d_i \\leq k^2 + \\varepsilon |c|.", block: true)]]

#text("We pick a large natural number ")#mi("{N}")#text(" (in particular, larger than ")#mi("{k}")#text("), and consider the three nested squares")

#align(center)[#tao-fit-display[#tao-math("[0,k]^2 \\subset [0,N]^2 \\subset [0,N + \\left|c\\right| \\frac{N}{N-\\varepsilon}]^2.", block: true)]]

#text("We can pack ")#mi("{[0,N]^2 \\backslash [0,k]^2}")#text(" by ")#mi("{N^2-k^2}")#text(" unit squares. We can similarly pack")

#align(center)[#tao-fit-display[#tao-math("[0,N + \\left|c\\right| \\frac{N}{N-\\varepsilon}]^2 \\backslash [0,N]^2", block: true)]]

#align(center)[#tao-fit-display[#tao-math("=[0, \\frac{N}{N-\\varepsilon} (N+\\left|c\\right|-\\varepsilon)]^2 \\backslash [0, \\frac{N}{N-\\varepsilon} (N-\\varepsilon)]^2", block: true)]]

#text("into ")#tao-math("{(N+\\left|c\\right|-\\varepsilon)^2 - (N-\\varepsilon)^2}", block: false)#text(" squares of sidelength ")#mi("{\\frac{N}{N-\\varepsilon}}")#text(". All in all, this produces")

#align(center)[#tao-fit-display[#tao-math("k^2+2\\varepsilon \\left|c\\right|+1 + N^2-k^2 + (N+\\left|c\\right|-\\varepsilon)^2 - (N-\\varepsilon)^2", block: true)]]

#align(center)[#tao-fit-display[#tao-math("= (N+\\left|c\\right|)^2 + 1", block: true)]]

#text("squares, of total length")

#align(center)[#tao-fit-display[#tao-math("(\\sum_{i=1}^{k^2+2\\varepsilon \\left|c\\right|+1} d_i) +(N^2-k^2) + ((N+\\left|c\\right|-\\varepsilon)^2 - (N-\\varepsilon)^2) \\frac{N}{N-\\varepsilon}.", block: true)]]

#text("Applying Theorem ")#link(<tao-66e16dd53ecf4fd7b2d4>)[#text("3")]#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("(\\sum_{i=1}^{k^2+2\\varepsilon \\left|c\\right|+1} d_i) +(N^2-k^2)", block: true)]]

#align(center)[#tao-fit-display[#tao-math("+ ((N+\\left|c\\right|-\\varepsilon)^2 - (N-\\varepsilon)^2) \\frac{N}{N-\\varepsilon} \\leq (N+\\left|c\\right|) (N + \\left|c\\right| \\frac{N}{N-\\varepsilon}).", block: true)]]

#text("The right-hand side is")

#align(center)[#tao-fit-display[#tao-math("N^2 + 2|c| N + \\left|c\\right|^2 + \\varepsilon \\left|c\\right| + O(1/N)", block: true)]]

#text("and the left-hand side similarly evaluates to")

#align(center)[#tao-fit-display[#tao-math("(\\sum_{i=1}^{k^2+2c+1} d_i) + N^2 -k^2 + 2|c| N + \\left|c\\right|^2 + O(1/N)", block: true)]]

#text("and so we simplify to")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i=1}^{k^2+2\\varepsilon \\left|c\\right|+1} d_i \\leq k^2 + \\varepsilon \\left|c\\right| + O(1/N).", block: true)]]

#text("Sending ")#mi("{N \\rightarrow \\infty}")#text(", we obtain the claim. ")#mi("\\Box")

#text("One striking feature of this story for me is how important it was to have a diverse set of people, literature, and tools to attack this problem. To be able to state and prove the precise formula for ")#mi("{c(n)}")#text(" required multiple observations, including some version of the following:")

#list(
[#text("The sequence can be numerically computed as a sequence of rational numbers.")],
[#text("When appropriately normalized and arranged, visible patterns in this sequence appear that allow one to conjecture the form of the sequence.")],
[#text("This problem is a weighted version of the Erdős-Szekeres theorem.")],
[#text("Among the many proofs of the Erdős-Szekeres theorem is the proof of Seidenberg in 1959, which can be interpreted as a discrete rectangle packing argument.")],
[#text("This problem can be reinterpreted as a continuous square packing problem, and in fact is closely related to (a generalized axis-parallel form of) Erdős problem 106, which concerns such packings.")],
[#text("The axis-parallel form of Erdős problem 106 was recently solved by Baek-Koizumi-Ueoro.")],
[#text("The paper of Praton shows that Erdős Problem 106 implies the generalized version needed for this problem. This implication specializes to the axis-parallel case.")]
)

#text("It was only through the combined efforts of all the contributors and their tools that all these key inputs were able to be assembled within 48 hours. It seems plausible that a more traditional effort involving just one or two mathematicians and simpler programming and literature search tools may eventually have been able to put all these pieces together, but I believe this process would have taken much longer (on the order of weeks or even months).")

#text("Another key ingredient was the ")#link("https://www.erdosproblems.com/forum/")[#text("balanced AI policy")]#text(" on the Erdős problem website, which encourages disclosed AI usage while strongly discouraging undisclosed use. To quote from that policy: “Comments prepared with the assistance of AI are permitted, provided (a) this is disclosed, (b) the contents (including mathematics, code, numerical data, and the existence of relevant sources) have been carefully checked and verified by the user themselves without the assistance of AI, and (c) the comment is not unreasonably long.”")

#heading(level: 1)[#text("Comments (17)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/08/the-story-of-erdos-problem-126/#comment-689272")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2025")])]

#text("Paragraph 2: “…; ")#emph[#strong[#text("and that")]]#text(" one cannot improve…”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e4fc75a3eb62a0338f020f0cf2bba96e4293554c41ec1df929f1c1519021f94-cb3ff6abcadfbd58db3d6fe1389fa75c81309c07869bc6f80fb4df1b0a689f52.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S")]], [#link("https://terrytao.wordpress.com/2025/12/08/the-story-of-erdos-problem-126/#comment-689273")[#strong[#text("S")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2025")])]

#text("Minor thing but the link “little web page of John Cook” currently points to the image in this post instead.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e4fc75a3eb62a0338f020f0cf2bba96e4293554c41ec1df929f1c1519021f94-cb3ff6abcadfbd58db3d6fe1389fa75c81309c07869bc6f80fb4df1b0a689f52.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S")]], [#link("https://terrytao.wordpress.com/2025/12/08/the-story-of-erdos-problem-126/#comment-689406")[#strong[#text("S")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2025")])]

#text("As an aside, now that I can see ")#link("https://www.johndcook.com/rational_approximation.html")[#text("the page")]#text(", I’m reminded I also made a ")#link("https://shreevatsa.net/fraction/best")[#text("similar page")]#text(" a while ago, to show all “best rational approximations” of both kinds. :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/08/the-story-of-erdos-problem-126/#comment-689275")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2025")])]

#text("“due to Erdős (Problem 16)” should be “due to Erdős (Problem 106)” – Lawrence")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/08/the-story-of-erdos-problem-126/#comment-689276")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2025")])]

#text("WHEN WILL ASI SOLVE THE ERDOS CONJECTURE ON ARITHMETIC PROGRESSIONS?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/08/the-story-of-erdos-problem-126/#comment-689295")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2025")])]

#text("Awesome! Super cool to see all this collaboration and AI used as a tool to facilitate this!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/08/the-story-of-erdos-problem-126/#comment-689297")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2025")])]

#text("Is there an asymmetric version, like the Erdős–Szekeres result which considers a length r monotonically increasing sequence, or a length s monotonically decreasing sequence?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/12/08/the-story-of-erdos-problem-126/#comment-689304")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2025")])]

#text("Good question! One is now square-packing a rectangle rather than a square. By counting areas, one gets the general inequality")

#mi("\\displaystyle \\sum_i x_i^2 \\leq (\\max_\\nearrow \\sum x_{i_r}) (\\max_\\searrow \\sum x_{i_r}) \\quad (1)")

#text("where the two maxima are over (weakly) increasing and decreasing sequences respectively. This (together with Cauchy-Schwarz) recovers the square case ")#mi("c(k^2) \\geq 1/k")#text(" of the result, as well as classical Erdos-Szekeres I believe (after rescaling the ")#mi("x_i")#text(" to all be extremely close to 1), but getting a completely optimal result in the general case may be trickier (but perhaps it is possible to adapt the proof of Theorem 3 to square packings of rectangles to say something).")

#text("EDIT: Optimizing the proof of Theorem 3 seens to give the general inequality")#linebreak()#text(" ")#mi("\\displaystyle \\sum_i x_i \\leq \\lfloor \\frac{1}{2} \\lceil \\max_\\nearrow \\sum x_{i_r}\\rceil \\lceil \\max_\\searrow \\sum x_{i_r} \\rceil + \\frac{1}{2} n \\rfloor.")

#text("One can try to optimize this somewhat by dilating ")#mi("x_i")#text(", but the result of that optimization may be a little complicated.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/08/the-story-of-erdos-problem-126/#comment-689322")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2025")])]

#text("Thanks! I feel like the first inequality in your response feels both sharper (even if it doesn’t actually imply the second), and nicer. Since the Erdős question was vague to begin with, perhaps (1) was the right generalization.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/094d3a4afafc4b15d41318284c2793f669c652fa25de78d54e81ec79d56b06d1-7bd83a067de926febbd326d5fbb07a8c24c7f8180773830f5b707328a9a6bdd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boris Alexeev")]], [#link("https://terrytao.wordpress.com/2025/12/08/the-story-of-erdos-problem-126/#comment-689360")[#strong[#text("Boris Alexeev")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2025")])]

#text("I tried to determine whether this “general inequality” is tight. I first realized that there’s a problem even for ")#mi("n=1")#text(", if the ratio between the increasing and decreasing sums is too big. For example, if ")#mi("\\max_{\\nearrow} \\le 1")#text(" while ")#mi("\\max_{\\searrow} \\le 10")#text(", then the best bound obtained via dilating is ")#mi("5")#text(" while of course the true maximum sum is just ")#mi("1")#text(". But that’s easy to handle.")

#text("Let’s rescale so that ")#mi("\\max_{\\nearrow} \\le 1")#text(" and ")#mi("\\max_{\\searrow} \\le y")#text(" for some ")#mi("y \\ge 1")#text(". Then the loose example I just described was fundamentally because ")#mi("y> n")#text(", so the easiest way to get rid of it is to simply insist that ")#mi("1 \\le y \\le n")#text(". Then I think ")#mi("n=1")#text(" and ")#mi("n=2")#text(" are tight.")

#text("But for ")#mi("n=3")#text(", I think there’s a real example. I think anything in the range ")#mi("1<y<\\frac 3 2")#text(" is loose, but let’s try ")#mi("y=\\frac 4 3")#text(" specifically. In that case, I believe the true maximum sum is ")#mi("\\frac{11}6")#text(" obtained with the sequence ")#mi("(\\frac56, \\frac 1 2-\\varepsilon, \\frac 1 2)")#text(".")

#text("Write ")#mi("z")#text(" for the dilation factor in the general inequality. I think that ")#mi("z \\in\\{1, \\frac32, 2\\}")#text(" are all optimal dilations obtaining the same bound of ")#mi("2")#text(", which is weaker than ")#mi("\\frac{11}6")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/08/the-story-of-erdos-problem-126/#comment-689310")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2025")])]

#text("Terry, this was a very inspiring read.")

#strong[#text("Critically ")]#text("– I think there is room for a lot of AI based enhancements to TFBloom’s website, integrating all external artifacts, such as the git, RAG, and all other relevant community and paper based resources.")

#text("OpenAI has group chat ")#link("https://openai.com/index/group-chats-in-chatgpt/")[#text("https://openai.com/index/group-chats-in-chatgpt/")]#text(" but I think this calls for something more botique and custom built. An agentic flow that can properly ")#strong[#text("cite")]#text(", track, synthesize, and realtime integrate contributions from a diverse set of mathematicians.")

#text("It will not just be looking to help spark ideas and solve problems, but aggressively determining possibilities for re-use in related questions. It could perhaps help prioritize mathlib coverage.")

#text("Most importantly in this agent flow will be the citing capability, providing strong motivations and incentives for people to get credibly involved.")

#text("The architecture of the flow should be built in a way that domain experts can enhance and customize it’s thinking. The idea is to take care of all the glue-code problems so experts don’t need to worry about that.")

#text("I really do hope you will think about reaching out to the labs to get them to help invest in something like this. Perhaps with the guarantee that they can use it as free training material they might be interested providing credits, though I’d like to think the halo effect should be value enough.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/08/the-story-of-erdos-problem-126/#comment-689313")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2025")])]

#text("In the construction in Proposition 1, why can’t you take a red block (increasing, of size ")#mi("a+1")#text(", of value ")#mi("a")#text("), followed by a blue block (increasing, of size ")#mi("k")#text(", of value ")#mi("a+1")#text("), to get a monotonic subsequence with sum ")#mi("S= (k+a)(a+1)")#text(", beating the value given and invalidating the proposition? At least for ")#mi("a")#text(" positive. Have I missed something?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/12/08/the-story-of-erdos-problem-126/#comment-689316")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2025")])]

#text("Oops, I had transposed “increasing” and “decreasing” from Boris’s construction at a crucial place. Hopefully it is fixed now. ")#emph[#text("[EDIT: added a figure, using the slightly frustrating, but still on balance time-saving, method of asking an AI to supply the initial image and then manually correcting all the visual mis-placements.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/08/the-story-of-erdos-problem-126/#comment-689357")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2025")])]

#text("correct me if I am wrong")

#text("it seems Ai is able to get the asymptotic case by itself (lean) and then goes on to help researchers generate small values, semantically dig through related results to reduce the problem until a precise result is found. So Ai played a powerful assistant in this entire effort.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/08/the-story-of-erdos-problem-126/#comment-689407")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2025")])]

#text("This case study reveals the future of AI-assisted[1] work, far beyond mathematics.")

#text("It relies on a combination of Humans, LLMs (‘General Tools’), Domain-Specific Tools, and Deep Research.")

#text("It is apparent that the static data encoded within an LLM is not enough; one must re-fetch sources and digest them fresh for the context of the conversation.")

#text("In this workflow, AlphaEvolve, Aristotle, and LEAN are the ‘PhDs’ on the team, while the LLM is the Full Stack Developer that glues them all together.")

#text("[1] If one likes pompous terms, this is what ‘AGI’ will actually look like.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11638286a33e50db1e7bbd88a3e6796f864f8ecd3ecdaefe6377e4e2cabd1510-331ce6df462396fef41ee578c58ec7e70aea7db131c1d3537463d8488c49ae61.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/08/the-story-of-erdos-problem-126/#comment-689479")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2025")])]

#text("“since deleting negative or vanishing xi does not decrease the left-hand side and does not increase the right-hand side.” Is this a typo? Shouldn’t deleting a negative term increase the sum and therefore increase de RHS?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/08/the-story-of-erdos-problem-126/#comment-689534")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2025")])]

#text("A small structural observation that may or may not be useful: in the torus square-packing reformulation, the existence of a single closed-form regime seems tied not just to symmetry reducing complexity, but to symmetry ")#emph[#text("splitting")]#text(" otherwise merged extremal mechanisms.")

#text("In some exploratory experiments with higher-dimensional axis-parallel packings on tori, one sees a small number of qualitatively distinct “macro” regimes (detectable both in slopes of the extremal value function and in coarse concentration signatures of the extremal configurations). Full coordinate symmetry appears to stabilise and separate these regimes; breaking symmetry causes some of them to merge rather than proliferate.")

#text("This suggests a slightly different heuristic from “symmetry simplifies”: symmetry can actually increase the ")#emph[#text("resolution")]#text(" of the extremal landscape by protecting distinctions that are otherwise washed out.")

#text("I don’t know whether this viewpoint is already standard in this circle, but it helped me understand why the 2D case collapses to a single formula while nearby problems do not.")
]
