// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/
// Converted to Typst by tao2typ: "2026-10-14T15:21:01.161477+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Planar point sets with forbidden four-point patterns and few distinct distances", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Planar point sets with forbidden four-point patterns and few distinct distances")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 September 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/")[#text("https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper “")#link("https://arxiv.org/abs/2409.01343")[#text("Planar point sets with forbidden ")#mi("{4}")#text("-point patterns and few distinct distance")]#text("“. This (very) short paper was a byproduct of my recent explorations of the ")#link("https://www.erdosproblems.com")[#text("Erdös problem website")]#text(" in recent months, with a vague emerging plan to locate a suitable problem that might be suitable for some combination of a crowdsourced “Polymath” style project and/or a test case for emerging AI tools. The question below was one potential candidate; however, upon reviewing the literature on the problem, I noticed that the existing techniques only needed one additional tweak to fully resolve the problem. So I ended up writing this note instead to close off the problem.")

#text("I’ve arranged this post so that this additional trick is postponed to below the fold, so that the reader can, if desired, try to guess for themselves what the final missing ingredient needed to solve the problem was. Here is the problem (")#link("https://www.erdosproblems.com/135")[#text("Erdös problem #135")]#text("), which ")#link("https://zbmath.org/0303.52006")[#text("was")]#text(" ")#link("https://zbmath.org/0563.10003")[#text("asked")]#text(" ")#link("https://zbmath.org/0595.52013")[#text("multiple")]#text(" ")#link("https://zbmath.org/0663.05013")[#text("times")]#text(" ")#link("https://zbmath.org/0849.11024")[#text("by")]#text(" ")#link("https://zbmath.org/0872.05020")[#text("Erdös")]#text(" over more than two decades (and who even offered a small prize for the solution on ")#link("https://zbmath.org/0872.05020")[#text("one of these occasions")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 1 (Erdös #135)")]#text(" Let ")#mi("{A \\subset {\\bf R}^2}")#text(" be a set of ")#mi("{n}")#text(" points such that any four points in the set determine at least five distinct distances. Must ")#mi("{A}")#text(" determine ")#mi("{\\gg n^2}")#text(" many distances?")
]

#text("This is a cousin of the significantly more famous ")#link("https://en.wikipedia.org/wiki/Erd%C5%91s_distinct_distances_problem")[#text("Erdös distinct distances problem")]#text(" (")#link("https://www.erdosproblems.com/89")[#text("Erdös problem #89")]#text("), which asks what is the minimum number of distances determined by a set ")#mi("{A \\subset {\\bf R}^2}")#text(" of ")#mi("{n}")#text(" points in the plane, without the restriction on four-point configurations. The example of a square grid ")#mi("{\\{0,\\dots,\\sqrt{n}-1\\}^2}")#text(" (assuming for sake of argument that ")#mi("{n}")#text(" is a perfect square), together with some standard analytic number theory calculations, shows that ")#mi("{A}")#text(" can determine ")#mi("{\\asymp n/\\sqrt{\\log n}}")#text(" distances, and it is conjectured that this is best possible up to constants. A celebrated ")#link("https://zbmath.org/1310.52019")[#text("result of Guth and Katz")]#text(", discussed in ")#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/")[#text("this previous blog post")]#text(", shows that ")#mi("{A}")#text(" will determine at least ")#mi("{\\gg n/\\log n}")#text(" distances. Note that the lower bound ")#mi("{\\gg n^2}")#text(" here is far larger, and in fact comparable to the total number ")#mi("{\\binom{n}{2}}")#text(" of distances available, thus expressing the belief that the “local” condition that every four points determine at least five distances forces the global collection distances to be almost completely distinct. In fact, in ")#link("https://core.ac.uk/download/pdf/82667115.pdf")[#text("one of the papers posing the problem")]#text(", Erdös made the even stronger conjecture that the set ")#mi("{A}")#text(" must contain a subset ")#mi("{A^{\\prime}}")#text(" of cardinality ")#mi("{\\gg n}")#text(" for which ")#emph[#text("all")]#text(" the ")#tao-math("{\\binom{\\left|A^{\\prime}\\right|}{2}}", block: false)#text(" distances generated by ")#mi("{A}")#text(" are distinct.")

#text("A ")#link("https://zbmath.org/1443.52012")[#text("paper of Dumitrescu")]#text(" came close to resolving this problem. Firstly, the number of ways in which four points could fail to determine five distinct distances was classified in that paper, with the four-point configurations necessarily being one of the following eight patterns:")

#list(
[#mi("{\\pi_1}")#text(": An equilateral triangle plus an arbitrary vertex.")],
[#mi("{\\pi_2}")#text(": A parallelogram.")],
[#mi("{\\pi_3}")#text(": An isosceles trapezoid (four points on a line, ")#mi("{P_1,P_2,P_3,P_4}")#text(", where ")#mi("{\\overleftrightarrow{P_1P_2} = \\overleftrightarrow{P_3P_4}}")#text(", form a degenerate isosceles trapezoid).")],
[#mi("{\\pi_4}")#text(": A star with three edges of the same length.")],
[#mi("{\\pi_5}")#text(": A path with three edges of the same length.")],
[#mi("{\\pi_6}")#text(": A kite.")],
[#mi("{\\pi_7}")#text(": An isosceles triangle plus an edge incident to a base endpoint, and whose length equals the length of the base.")],
[#mi("{\\pi_8}")#text(": An isosceles triangle plus an edge incident to the apex, and whose length equals the length of the base.")]
)

#text("(See Figure 1 and Lemma 1 of ")#link("https://zbmath.org/1443.52012")[#text("Dumitrescu’s paper")]#text(".) So the question is asking whether if an ")#mi("{n}")#text(" point set ")#mi("{A}")#text(" avoids all of these patterns ")#mi("{\\pi_1,\\dots,\\pi_8}")#text(", then it must generate ")#mi("{\\gg n^2}")#text(" distances.")

#text("Given that the grid ")#mi("{\\{0,\\dots,n-1\\}^2}")#text(" determine only ")#mi("{\\asymp n^2 / \\sqrt{\\log n}}")#text(" distances, one could seek a counterexample to this by finding a set of ")#mi("{\\asymp n}")#text(" points in the grid ")#mi("{\\{0,\\dots,n-1\\}^2}")#text(" that avoided all of the eight patterns ")#mi("{\\pi_1,\\dots,\\pi_8}")#text(".")

#text("Dumitrescu then counted how often each of the patterns ")#mi("{\\pi_1,\\dots,\\pi_8}")#text(" occured inside the grid ")#mi("{\\{0,\\dots,n-1\\}^2}")#text(". The answer is:")

#list(
[#mi("{\\pi_1}")#text(" does not occur at all. (This is related to the irrationality of ")#mi("{\\sin \\pi/3 = \\sqrt{3}/2}")#text(".)")],
[#mi("{\\pi_2}")#text(" occurs ")#mi("{\\asymp n^6}")#text(" times.")],
[#mi("{\\pi_3}")#text(" occurs ")#mi("{\\asymp n^5}")#text(" times.")],
[#mi("{\\pi_4}")#text(" occurs ")#mi("{O(n^{14/3} \\log n)}")#text(" times.")],
[#mi("{\\pi_5}")#text(" occurs ")#mi("{O(n^{14/3} \\log n)}")#text(" times.")],
[#mi("{\\pi_6}")#text(" occurs ")#mi("{\\asymp n^5}")#text(" times.")],
[#mi("{\\pi_7}")#text(" occurs ")#mi("{O(n^{14/3} \\log n)}")#text(" times.")],
[#mi("{\\pi_8}")#text(" occurs ")#mi("{O(n^{14/3} \\log n)}")#text(" times.")]
)

#text("(The bounds involving ")#mi("{O(n^{14/3} \\log n)}")#text(" were obtained using the ")#link("https://en.wikipedia.org/wiki/Szemer%C3%A9di%E2%80%93Trotter_theorem")[#text("Szemerédi-Trotter theorem")]#text(", and might not be optimal for this problem.) In particular, with the exception of the parallelogram pattern ")#mi("{\\pi_2}")#text(", the other seven forbidden ")#mi("{4}")#text("-point patterns ")#mi("{\\pi_1,\\pi_3,\\dots,\\pi_8}")#text(" occur at most ")#mi("{O(n^5)}")#text(" times.")

#text("Using this and a standard probabilistic argument, Dumitrescu then established the following “near miss” to a negative answer to the above problem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (First near miss)")]#text(" ")#metadata(none) <tao-a7937b64b8caa58f0372>#text(" If ")#mi("{n}")#text(" is sufficiently large, then there exists a subset of ")#mi("{\\{0,\\dots,n-1\\}^2}")#text(" of cardinality ")#mi("{\\asymp n}")#text(" which avoids all of the patterms ")#mi("{\\pi_1, \\pi_3,\\dots,\\pi_8}")#text(".")
]

#text("In particular, this generates a set of ")#mi("{\\asymp n}")#text(" points with ")#mi("{O(n^2/\\sqrt{\\log n})}")#text(" distances that avoids seven out of the eight required forbidden patterns; it is only the parallelograms ")#mi("{\\pi_2}")#text(" that are not avoided, and are the only remaining obstacle to a negative answer to the problem.")

#emph[#text("Proof:")]#text(" Let ")#mi("{\\varepsilon>0}")#text(" be a small constant, and let ")#mi("{A}")#text(" be a random subset of ")#mi("{\\{0,\\dots,n-1\\}^2}")#text(", formed by placing each element of ")#mi("{\\{0,\\dots,n-1\\}^2}")#text(" with an independent probability of ")#mi("{\\varepsilon/n}")#text(". A standard application of Hoeffding’s inequality (or even the second moment method) shows that this set ")#mi("{A}")#text(" will have cardinality ")#mi("{\\asymp \\varepsilon n}")#text(" with high probability if ")#mi("{n}")#text(" is large enough. On the other hand, each of the ")#mi("{O(n^5)}")#text(" patterns ")#mi("{\\pi_1,\\pi_3,\\dots,\\pi_8}")#text(" has a probability ")#mi("{\\varepsilon^4/n^4}")#text(" of lying inside ")#mi("{A}")#text(", so by linearity of expectation, the total number of such patterns inside ")#mi("{A}")#text(" is ")#mi("{O( n^5 \\varepsilon^4 / n^4 ) = O(\\varepsilon^4 n)}")#text(" on the average. In particular, by Markov’s inequality, we can find a set ")#mi("{A}")#text(" of cardinality ")#mi("{\\asymp \\varepsilon n}")#text(" with only ")#mi("{O(\\varepsilon^4 n)}")#text(" such patterns. Deleting all of these patterns from ")#mi("{A}")#text(", we obtain a set ")#mi("{A^{\\prime}}")#text(" of cardinality ")#mi("{\\asymp \\varepsilon n - O(\\varepsilon^4 n)}")#text(", which is ")#mi("{\\asymp n}")#text(" if ")#mi("{\\varepsilon}")#text(" is a sufficiently small constant. This establishes the claim. ")#mi("\\Box")

#text("Unfortunately, this random set contains far too many parallelograms ")#mi("{\\pi_2}")#text(" (")#mi("{\\asymp n^2}")#text(" such parallelograms, in fact) for this deletion argument to work. On the other hand, in earlier work ")#link("https://zbmath.org/0830.05014")[#text("of Thiele")]#text(" and ")#link("https://zbmath.org/1199.52031")[#text("of Dumitrescu")]#text(", a separate construction of a set of ")#mi("{\\asymp n}")#text(" points in ")#mi("{\\{0,\\dots,n-1\\}^2}")#text(" that avoids all of the parallelograms ")#mi("{\\pi_2}")#text(" was given:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Second near miss)")]#text(" ")#metadata(none) <tao-16367aacb67a4a017c8d>#text(" For ")#mi("{n}")#text(" large, there exists a subset ")#mi("{S}")#text(" of ")#mi("{\\{0,\\dots,n-1\\}^2}")#text(" of cardinality ")#mi("{\\asymp n}")#text(" which contains no parallelograms ")#mi("{\\pi_2}")#text(". Furthermore, this set is in general position: no three points in ")#mi("{S}")#text(" are collinear, and no four are concyclic. As a consequence, this set ")#mi("{S}")#text(" in fact avoids the three patterns ")#mi("{\\pi_1, \\pi_2, \\pi_3}")#text(" (the pattern in ")#mi("{\\pi_3}")#text(" is concyclic, and the pattern ")#mi("{\\pi_1}")#text(" does not occur at all in the grid).")
]

#emph[#text("Proof:")]#text(" One uses an explicit algebraic construction, going back to an ")#link("https://zbmath.org/0061.07301")[#text("old paper of Erdös and Turán")]#text(" involving constructions of ")#link("https://en.wikipedia.org/wiki/Sidon_sequence")[#text("Sidon sets")]#text(". Namely, one considers the set ")#metadata(none) <tao-a172cedcae47474b615c>#mi("\\displaystyle  S := \\{ (x,y) \\in \\{0,\\dots,n-1\\}^2: y = x^2 \\text{ mod } p \\} \\ \\ \\ \\ \\ (1)")#text(" ")#text(" where ")#mi("{p}")#text(" is a prime between ")#mi("{4n}")#text(" and ")#mi("{8n}")#text(" (the existence of which is guaranteed by Bertrand’s postulate). Standard Gauss sum estimates can be used to show that ")#mi("{S}")#text(" has cardinality ")#mi("{\\asymp n}")#text(". If ")#mi("{S}")#text(" contained four points that were in a parallelogram or on a circle, or three points in a line, then one could lift up from ")#mi("{\\{0,\\dots,n-1\\}^2}")#text(" to the finite field plane ")#mi("{{\\mathbf F}_p^2}")#text(" and conclude that the finite field parabola ")#mi("{\\{ (x,x^2): x \\in {\\bf F}_p \\}}")#text(" also contained four points in a parallelogram or a circle, or three points on a line. But straightforward algebraic calculations can be performed to show that none of these scenarios can occur. For instance, if ")#mi("{P, P+H, P+K, P+H+K}")#text(" were four points on a parallelogram that were contained in a parabola, this would imply that an alternating sum of the form")

#align(center)[#tao-fit-display[#mitex("(x, x^2) - (x+h, (x+h)^2) - (x+k, (x+k)^2) + (x+h+k, (x+h+k)^2)")]]

#text("would vanish for some non-zero ")#mi("{h,k}")#text("; but this expression simplifies to ")#mi("{(0, 2hk)}")#text(", which cannot vanish for non-zero ")#mi("{h,k}")#text(" as ")#mi("{p}")#text(" is odd. (For the concylic claim, the parabola in ")#mi("{{\\mathbf F}_p^2}")#text(" can in fact contain four points on a circle, but only if their ")#mi("{x}")#text(" coordinates sum to zero, and this cannot happen in ")#mi("{S}")#text(")")

#text("Given that we have one “near-miss” in the literature that avoids ")#mi("{\\pi_1, \\pi_3, \\dots, \\pi_8}")#text(", and another “near-miss” that avoids ")#mi("{\\pi_1, \\pi_2, \\pi_3}")#text(", it is natural to try to combine these two constructions to obtain a set that avoids all eight patterns ")#mi("{\\pi_1,\\dots,\\pi_8}")#text(". This inspired the following problem of Dumitrescu (see ")#link("https://zbmath.org/1443.52012")[#text("Problem 2")]#text(" of this paper):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 4")]#text(" Does the set ")#mi("{S}")#text(" in ")#link(<tao-a172cedcae47474b615c>)[#text("(1)")]#text(" contain a subset of cardinality ")#mi("{\\gg n}")#text(" that avoids all eight of the patterns ")#mi("{\\pi_1, \\dots, \\pi_8}")#text("?")
]

#text("Unfortunately, this problem looked difficult, as the number-theoretic task of counting the patterns ")#mi("{\\pi_4,\\dots,\\pi_8}")#text(" in ")#mi("{S}")#text(" looked quite daunting.")

#text("This ends the survey of the prior literature on this problem. Can you guess the missing ingredient needed to resolve the problem? I will place the answer below the fold.")

#metadata(none) <tao-7b853a8af2018d762156>

#text("The missing ingredient is to randomize the parabola appearing in ")#link(<tao-a172cedcae47474b615c>)[#text("(1)")]#text(". The crucial property of being free of parallelograms is preserved under affine transformations of the finite field plane ")#mi("{{\\bf F}_p^2}")#text(", so we apply a random invertible affine transformation to the parabola to create the candidate set")

#align(center)[#tao-fit-display[#mitex("A := \\{ (x,y) \\in \\{0,\\dots,n-1\\}^2: (ax+by)^2 = cx+dy+e \\text{ mod } p \\}")]]

#text("where ")#mi("{a,b,c,d,e}")#text(" are randomly chosen elements of ")#mi("{{\\bf F}_p}")#text(", subject to the non-degeneracy condition")

#align(center)[#tao-fit-display[#mitex("ad-bc \\neq 0.")]]

#text("A routine application of the second moment method shows that ")#mi("{A}")#text(" has cardinality ")#mi("{\\asymp n}")#text(" with high probability. The algebraic calculation that showed that ")#mi("{S}")#text(" avoided the parallelogram pattern ")#mi("{\\pi_2}")#text(", also shows that ")#mi("{A}")#text(" avoids ")#mi("{\\pi_2}")#text(". We know that the grid ")#mi("{\\{0,\\dots,n-1\\}^2}")#text(" avoids the pattern ")#mi("{\\pi_1}")#text(". What about the other six patterns ")#mi("{\\pi_3,\\dots,\\pi_8}")#text("? I struggled with counting these patterns for a while. At first I tried to understand the discrete circles ")#mi("{\\{ (x,y) \\in {\\bf Z}^2: x^2+y^2 = r\\}}")#text(" for various ")#mi("{r = O(n^2)}")#text(", focusing for instance of triples ")#mi("{u,v,w}")#text(" in that circle that obeyed some specified linear constraint ")#mi("{w = au+bv}")#text(" modulo ")#mi("{p}")#text("; but this looked like it required quite a bit of analytic number theory to properly control. I also briefly played around with the rotation group ")#mi("{SO_2({\\bf F}_p)}")#text(", hoping that its equidistribution properties would be helpful, but again this was a challenge. In the end, I found that abandoning any distance-related considerations was the most effective way forward. A key calculation is that any four distinct points ")#mi("{P_1,P_2,P_3,P_4}")#text(" of ")#mi("{{\\bf F}_p^2}")#text(" (regardless of what pattern they form) will all lie in the parabola")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y) \\in {\\bf F}_p^2: (ax+by)^2 = cx+dy+e \\}")]]

#text("with a probability of ")#mi("{O(1/p^4) \\asymp O(1/n^4)}")#text(". There are two cases. If three of the points are collinear, then the probability is in fact zero, because a line cannot intersect a parabola in three points by Bezout’s theorem. If instead the four points are in general position, then by affine invariance one can normalize the four points as ")#mi("{(0,0)}")#text(", ")#mi("{(1,0)}")#text(", ")#mi("{(0,1)}")#text(", ")#mi("{(s,t)}")#text(" for some non-zero ")#mi("{s,t}")#text(". Then one is asking for solutions ")#mi("{(a,b,c,d,e)}")#text(" to the system of equations")

#tao-aligned(keep: true)[


#tao-math("0  & = e", block: true)



#tao-math("a^2  & = c + e", block: true)



#tao-math("b^2  & = d + e", block: true)



#tao-math("(as+bt)^2  & = cs+dt+e", block: true)
]

#text("and it is a routine matter to show that there are only ")#mi("{O(p)}")#text(" solutions to this system, giving the desired probability of ")#mi("{O(1/p^4)}")#text(".")

#text("Once one has this calculation, the deletion argument finishes the job. Indeed, the expected number of patterns ")#mi("{\\pi_3,\\dots,\\pi_8}")#text(" in ")#mi("{A}")#text(" is ")#mi("{O(n^5/n^4) = O(n)}")#text(". If we refine further by an additional factor of ")#mi("{\\varepsilon}")#text(" as in the proof of Theorem ")#link(<tao-a7937b64b8caa58f0372>)[#text("2")]#text(", we obtain (with high probability) a set of cardinality ")#mi("{\\asymp \\varepsilon n}")#text(" that contains ")#mi("{O(\\varepsilon^4 n)}")#text(" forbidden patterns. Deleting these, we have finally obtained a set of cardinality ")#mi("{\\asymp n}")#text(" in the grid ")#mi("{\\{0,\\dots,n-1\\}^2}")#text(" (and thus generating ")#mi("{O(n^2/\\sqrt{\\log n})}")#text(" distances) that avoid ")#emph[#text("all")]#text(" of the eight patterns ")#mi("{\\pi_1,\\dots,\\pi_8}")#text(", and thus give a negative answer to the original problem of Erdös.")

#text("There are still open problems in the area. One is the following: what is the best ")#emph[#text("lower bound")]#text(" on the number of distances determined by ")#mi("{n}")#text(" points in the plane, for which every four points determine at least five distances (i.e., one avoids all eight patterns ")#mi("{\\pi_1,\\dots,\\pi_8}")#text(")? The Guth-Katz theorem gives the lower bound of ")#mi("{\\gg n/\\log n}")#text(", but in this case we can get the better bound of ")#mi("{\\frac{n-1}{2}}")#text(" by the following trivial argument: if ")#mi("{P_0}")#text(" is one point in the set, then the other ")#mi("{n-1}")#text(" points determine at least ")#mi("{\\frac{n-1}{2}}")#text(" distinct distances to ")#mi("{P_0}")#text(", because the same distance cannot occur three times as this would create a star ")#mi("{\\pi_4}")#text(". Can one do better than this? Specifically, can one achieve a super-linear bound? This was posed as Problem 3 in ")#link("https://zbmath.org/1443.52012")[#text("Dumitrescu’s paper")]#text(". I do not know how to make progress on this question, other than a vague suspicion that the polynomial method might be relevant here, and that one should somehow try to capture many of the points in a set that only has a linear number of distances in a reasonably low degree algebraic curve.")

#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2fa9f0b61dbf0e9461e71029dee182cc4be56ff79d1da92eaa621430cca2328-5d70ecb80cdc2674f94f108181c120e83d908726a7226f06bcca1d69610c7595.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xiaozhuangyang")]], [#link("https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/#comment-685708")[#strong[#text("xiaozhuangyang")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2024")])]

#text("Dr.Tao")

#text("you are right")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2fa9f0b61dbf0e9461e71029dee182cc4be56ff79d1da92eaa621430cca2328-5d70ecb80cdc2674f94f108181c120e83d908726a7226f06bcca1d69610c7595.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xiaozhuangyang")]], [#link("https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/#comment-685710")[#strong[#text("xiaozhuangyang")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2024")])]

#text("Dr.TAO")

#text("If we do addition and multiplication in this way, we can consider all nodes as probabilities. In fact, the overall probability is a Taniyama Shimura theorem,")

#text("We assume that there is a curve in the p domain, and another curve in the p+2 domain, each of which is a pair. If there are countless curves, we can prove the twin problem,")

#text("Assuming that all nodes have a relationship between p and p+2 or p and p+6, then p+2 is addition and p+6 is multiplication. Therefore, you are right. Considering the Markov process of the log and θ structure of this problem, we can also use log as p+2 and θ as p+6. It can be seen that all nodes are induced into a dynamical system, so it is understood as chaotic")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/#comment-685711")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2024")])]

#text("Since this problem seemed to be quite important to Erdos (he even offered some money for it), I wonder if solving it leads to some (far-reaching) consequences. As you also mentioned, Erdos typically asked questions which sounded “random”, but in reality he knew very well, why he asked it:)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/#comment-685712")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2024")])]

#text("I am guessing that he was searching for a plausible distance set analogue of the ")#link("https://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93Hajnal_conjecture")[#text("Erdos-Hajnal conjecture")]#text(" in graph theory. In that latter context there does seem to be a phenomenon that forbidding local structures can lead to quite global structures emerging. Even though the problem here as stated did have a negative answer, it could still be that the only counterexamples do have to have some algebraic structure. There are some hints of this in the nearby subject of constructing Sidon sets (which is analogous in this context to forbidding the parallelogram pattern ")#mi("\\pi_2")#text("). As discussed for instance ")#link("https://arxiv.org/abs/2107.05744")[#text("by Eberhard and Manners")]#text(", there are intriguing hints that dense Sidon sets only seem to be constructible from algebraic constructions similar to the parabolae discussed here. Potentially there is some sort of “inverse theorem” for sets with few distances that avoid patterns such as ")#mi("\\pi_1,\\dots,\\pi_8")#text(", in that they all have to be related somehow to an algebraic curve or other similarly structured object? It’s not clear to me exactly what to conjecture here, but perhaps this is a direction for future study on distance set problems to look into.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ced3e9ca3ac3a4fbeaeabc78fa033428f6c52d4fc05409e4794cca44ef22915-4b1027730e02d9a8b7abbf37c1479c0807765e6c4c27325ed00f142e0bf7e916.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zach Hunter")]], [#link("https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/#comment-685721")[#strong[#text("Zach Hunter")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2024")])]

#text("Ah, this is a good trick. I swear I’ve come across very similar ideas a few times, but I can’t recall where at the moment.")

#text("In any case, here’s a basic remark: concentration/second moment is not needed.")

#text("Let ")#mi("A")#text(" be a random ")#mi("\\epsilon")#text("-dense subset of a random non-degenerate parabola. Have ")#tao-math("X:=\\left|A\\right|", block: false)#text(" count the size of this set, and ")#mi("Y_i")#text(" count the bad patterns of type ")#mi("i")#text(".")

#text("One gets ")#mi("\\mathbb{E}[X] \\ge \\epsilon cn, \\mathbb{E}[Y_i]\\le \\epsilon^4 C_i n")#text(" for some constants ")#mi("c,C_1,\\dots,C_8")#text(".")

#text("Defining ")#mi("A^{\\prime} \\subset A")#text(" to be the points that were contained in no bad patterns, we have that ")#tao-math("\\mathbb{E}[\\left|A^{\\prime}\\right|] \\ge \\mathbb{E}[X] - 4\\sum_i \\mathbb{E}[Y_i]", block: false)#text(" by linearity of expectation. Choosing ")#mi("\\epsilon")#text(" so that ")#mi("c-4\\epsilon(C_1+\\dots +C_8)>c/2")#text(", there must exist some outcome where we get a good set ")#tao-math("\\left|A^{\\prime}\\right|\\ge \\epsilon(c/2)n", block: false)#text(". QED")

#emph[#text("[Thanks, I will add this alternate argument in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ced3e9ca3ac3a4fbeaeabc78fa033428f6c52d4fc05409e4794cca44ef22915-4b1027730e02d9a8b7abbf37c1479c0807765e6c4c27325ed00f142e0bf7e916.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zach Hunter")]], [#link("https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/#comment-685722")[#strong[#text("Zach Hunter")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2024")])]

#text("How few distances can a Sidon set have?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ced3e9ca3ac3a4fbeaeabc78fa033428f6c52d4fc05409e4794cca44ef22915-4b1027730e02d9a8b7abbf37c1479c0807765e6c4c27325ed00f142e0bf7e916.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zach Hunter")]], [#link("https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/#comment-685724")[#strong[#text("Zach Hunter")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2024")])]

#text("Oh I guess the circle has ")#mi("\\sim n/2")#text(" distances. But then any subset of this avoiding a trapezoid has size ")#mi("O(\\sqrt{n})")#text(" (using Behrend, you can take a subset of size ")#mi("n^{1-o(1)}")#text(" so that I have no isoceles triangles, so that means you can avoid everything pattern 3 with a nearly linear amount of distances).")

#text("So being a Sidon set (avoiding pattern 2) is not enough to make things hard. But my hunch is it is tough to avoid both pattern 2 and 3 simultaneously.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/#comment-685728")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2024")])]

#text("Perhaps a model problem is to assume that the configuration is in general position (no three collinear, no four concylic, and more generally no ")#mi("k")#text(" points on an algebraic curve with at most ")#mi("k-1")#text(" degrees of freedom for any fixed ")#mi("k")#text("), no parallelograms (i.e., a Sidon set), and no isosceles triangles (i.e. all pinned distances to a point are distinct), and see if one can get any significant improvement to the number of distances over the trivial lower bound of ")#mi("n-1")#text(" coming from considering all distances to a single point. I don’t even see how to improve the bound to ")#mi("n")#text(".")

#text("One vague thought I had was to somehow adapt the rank arguments from ")#link("https://arxiv.org/abs/1211.0330")[#text("Dvir-Saraf-Wigderson")]#text(" to somehow force many points of the set to relate to some moderately low degree algebraic curve, but I don’t see how to actually make this work.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/#comment-685729")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2024")])]

#text("A couple of questions:")

#enum(start: 1, 
[#text("How do you feel about all the interest the Erdos problems website has generated? Do you think it has created mathematical progress that wouldn’t have existed otherwise?")],
[#text("Is there a reason why your recent results on these problems have all been answering questions in the negative? Perhaps mathematicians systematically under-explore constructions? Or perhaps the fact that they were unanswered for so long makes it more likely the answers are negative?")]
)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/#comment-685742")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2024")])]

#text("Certainly it has allowed for more progress on the less well known problems of Erdos. Previously it was quite difficult to ascertain the most up-to-date status of any such problem that one happened to come across. In general I think we have a shortage of well-curated mathematical databases; while there are noteworthy resources of this type (with the OEIS perhaps being the most successful), there are definitely areas of mathematics where progress would be faster if we had more standardized collection of relevant data, particularly with the incipient infusion of machine learning and AI tools into the field.")

#text("It is possible that this problem database could also be used for some metamathematical studies on the activity of mathematical problem solving itself, for instance in the spirit of your second question, though I haven’t actually seen any such studies yet (but this is quite a new database). If one looks at the other recently solved Erdos problems on the site, rather than on my blog, I think there is actually a fairly even split between positive and negative solutions (restricting of course to those questions which were formulated to have a yes/no answer, as opposed to say “what is the growth rate of …” type problems), so I don’t think there is any strong conclusion to be drawn here. [Even within my own blog, several of my posts have been about positive solutions, e.g., to #39, #437, or (going somewhat further back in time) #67, #4, and #219.] But I do think that Erdos tended to choose questions for which the answer itself, as well as the proof method used to obtain that answer, would be illuminating; by such information-theoretic metrics, questions which had a 50-50 chance of a positive or negative answer would, all other things being equal, be more valuable to pose than ones for which he was already say 90% sure that the answer would be positive.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37432c98750e4022b84c1e02476ca47a145927ff594ef0eb39e820fe7e06b425-ce55d07280b037e17918e2e1908cc9c00ecabf3d55d9d47936fe5043346ccd52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/#comment-685749")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2024")])]

#text("I would think that constructions are more likely to be found quickly, by a mathematician who has just seen the problem and spends at most a few days thinking about it, compared to nonexistence results. Nonexistence results more often require long, difficult arguments building on the work of multiple mathematicians, while existence results based on a construction more often rely on a single clever trick missed in prior work. So it’s not surprising to see a high proportion of constructions on this blog given your method of looking through the list trying to find problems you can solve relatively quickly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/#comment-685750")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2024")])]

#text("Good point! And this actually highlights one of the values added by having databases of problems – by lowering the “friction” costs of locating interesting questions and finding their most recent status, it facilitates a different way of making progress in a mathematical field, by scanning large numbers of problems for “quick wins”, which is a largely orthogonal approach to the more traditional method of thinking long and hard on one (or a very few) difficult problems at a time. In the near and medium term, I would expect the traditional approach to still be dominant, but I also expect it to be increasingly complemented by these other approaches. (In particular, I suspect that AI-based or crowdsource-based strategies may be more suited to such a scattershot approach, while being of much more limited use for human experts working on deep, specific problems.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/#comment-685764")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2024")])]

#text("I guess it’s also another objective benchmark to measure AI progress in mathematics, if a more advanced version of something like AlphaProof is able to just solve some ErdH{o}s questions.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/#comment-685751")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2024")])]

#text("What are you planning to do with the Erdös prize money ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/#comment-685787")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2024")])]

#text("Erdos passed away in 1996, so the prizes are now defunct and only of historical interest. (Ron Graham did keep the prize tradition alive for a while for the graph theory problems at least, but he also passed away in 2020.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/#comment-685767")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2024")])]

#text("I fail as human, didn’t understand even the first paragraph and the first equations 😭😮‍💨")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2fa9f0b61dbf0e9461e71029dee182cc4be56ff79d1da92eaa621430cca2328-5d70ecb80cdc2674f94f108181c120e83d908726a7226f06bcca1d69610c7595.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xiaozhuangyang")]], [#link("https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/#comment-685794")[#strong[#text("xiaozhuangyang")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2024")])]

#text("Teacher Tao,")#linebreak()#text(" There is a very interesting question. The Chinese want Yang Yang to be the leader. It’s better for us to admit this situation. In fact, I am also a human. Britain tried to use protein chip technology to control me, but they failed. I found a funny thing. I have never been to the military, but they regarded me as a soldier, that is, they want to replace me with Yang Yang. I think I will disclose a lot of computer technology. They think I am a spy, but I am obviously not")#linebreak()#text(" I estimate that my life is coming to an end, and I hope Teacher Tao can not forget that the basic purpose of studying mathematics is to solve problems")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/03/planar-point-sets-with-forbidden-four-point-patterns-and-few-distinct-distances/#comment-685936")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2024")])]

#text("yeah，you are right！👍His point is interesting enough")
]
]
]
