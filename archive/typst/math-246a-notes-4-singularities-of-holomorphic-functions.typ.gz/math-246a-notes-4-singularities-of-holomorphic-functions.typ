// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/
// Converted to Typst by tao2typ: "2026-10-14T15:19:48.779706+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Math 246A, Notes 4: singularities of holomorphic functions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Math 246A, Notes 4: singularities of holomorphic functions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 October 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Previous set of notes: ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(". Next set of notes: ")#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/")[#text("Notes 5")]#text(".")

#text("In the ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-conmsequences/")[#text("previous set of notes")]#text(" we saw that functions ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" that were holomorphic on an open set ")#mi("{U}")#text(" enjoyed a large number of useful properties, particularly if the domain ")#mi("{U}")#text(" was simply connected. In many situations, though, we need to consider functions ")#mi("{f}")#text(" that are only holomorphic (or even well-defined) on ")#emph[#text("most")]#text(" of a domain ")#mi("{U}")#text(", thus they are actually functions ")#mi("{f: U \\backslash S \\rightarrow {\\bf C}}")#text(" outside of some small ")#emph[#text("singular set")]#text(" ")#mi("{S}")#text(" inside ")#mi("{U}")#text(". (In this set of notes we only consider ")#emph[#text("interior")]#text(" singularities; one can also discuss singular behaviour at the boundary of ")#mi("{U}")#text(", but this is a whole separate topic and will not be pursued here.) Since we have only defined the notion of holomorphicity on open sets, we will require the singular sets ")#mi("{S}")#text(" to be closed, so that the domain ")#mi("{U \\backslash S}")#text(" on which ")#mi("{f}")#text(" remains holomorphic is still open. A typical class of examples are the functions of the form ")#mi("{\\frac{f(z)}{z-z_0}}")#text(" that were already encountered in the Cauchy integral formula; if ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" is holomorphic and ")#mi("{z_0 \\in U}")#text(", such a function would be holomorphic save for a singularity at ")#mi("{z_0}")#text(". Another basic class of examples are the rational functions ")#mi("{P(z)/Q(z)}")#text(", which are holomorphic outside of the zeroes of the denominator ")#mi("{Q}")#text(".")

#text("Singularities come in varying levels of “badness” in complex analysis. The least harmful type of singularity is the ")#link("https://en.wikipedia.org/wiki/Removable_singularity")[#text("removable singularity")]#text(" – a point ")#mi("{z_0}")#text(" which is an ")#link("https://en.wikipedia.org/wiki/Isolated_singularity")[#text("isolated singularity")]#text(" (i.e., an ")#link("https://en.wikipedia.org/wiki/Isolated_point")[#text("isolated point")]#text(" of the singular set ")#mi("{S}")#text(") where the function ")#mi("{f}")#text(" is undefined, but for which one can extend the function across the singularity in such a fashion that the function becomes holomorphic in a neighbourhood of the singularity. A typical example is that of the complex sinc function ")#mi("{\\frac{\\sin(z)}{z}}")#text(", which has a removable singularity at the origin ")#mi("{0}")#text(", which can be removed by declaring the sinc function to equal ")#mi("{1}")#text(" at ")#mi("{0}")#text(". The detection of isolated removable singularities can be accomplished by ")#link("https://en.wikipedia.org/wiki/Removable_singularity")[#text("Riemann’s theorem on removable singularities")]#text(" (Exercise 37 from ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text("): if a holomorphic function ")#mi("{f: U \\backslash S \\rightarrow {\\bf C}}")#text(" is bounded near an isolated singularity ")#mi("{z_0 \\in S}")#text(", then the singularity at ")#mi("{z_0}")#text(" may be removed.")

#text("After removable singularities, the mildest form of singularity one can encounter is that of a ")#link("https://en.wikipedia.org/wiki/Pole_(complex_analysis)")[#text("pole")]#text(" – an isolated singularity ")#mi("{z_0}")#text(" such that ")#mi("{f(z)}")#text(" can be factored as ")#mi("{f(z) = \\frac{g(z)}{(z-z_0)^m}}")#text(" for some ")#mi("{m \\geq 1}")#text(" (known as the ")#emph[#text("order")]#text(" of the pole), where ")#mi("{g}")#text(" has a removable singularity at ")#mi("{z_0}")#text(" (and is non-zero at ")#mi("{z_0}")#text(" once the singularity is removed). Such functions have already made a frequent appearance in previous notes, particularly the case of ")#emph[#text("simple poles")]#text(" when ")#mi("{m=1}")#text(". The behaviour near ")#mi("{z_0}")#text(" of function ")#mi("{f}")#text(" with a pole of order ")#mi("{m}")#text(" is well understood: for instance, ")#tao-math("{\\left|f(z)\\right|}", block: false)#text(" goes to infinity as ")#mi("{z}")#text(" approaches ")#mi("{z_0}")#text(" (at a rate comparable to ")#tao-math("{\\left|z-z_0\\right|^{-m}}", block: false)#text("). These singularities are not, strictly speaking, removable; but if one ")#link("https://en.wikipedia.org/wiki/Compactification_(mathematics)")[#text("compactifies")]#text(" the range ")#mi("{{\\bf C}}")#text(" of the holomorphic function ")#mi("{f: U \\backslash S \\rightarrow {\\bf C}}")#text(" to a slightly larger space ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" known as the ")#link("https://en.wikipedia.org/wiki/Riemann_sphere")[#text("Riemann sphere")]#text(", then the singularity can be removed. In particular, functions ")#mi("{f: U \\backslash S \\rightarrow {\\bf C}}")#text(" which only have isolated singularities that are either poles or removable can be extended to holomorphic functions ")#mi("{f: U \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" to the Riemann sphere. Such functions are known as ")#link("https://en.wikipedia.org/wiki/Meromorphic_function")[#text("meromorphic functions")]#text(", and are nearly as well-behaved as holomorphic functions in many ways. In fact, in one key respect, the family of meromorphic functions is better: the meromorphic functions on ")#mi("{U}")#text(" turn out to form a field, in particular the quotient of two meromorphic functions is again meromorphic (if the denominator is not identically zero).")

#text("Unfortunately, there are isolated singularities that are neither removable or poles, and are known as ")#link("https://en.wikipedia.org/wiki/Essential_singularity")[#text("essential singularities")]#text(". A typical example is the function ")#mi("{f(z) = e^{1/z}}")#text(", which turns out to have an essential singularity at ")#mi("{z=0}")#text(". The behaviour of such essential singularities is quite wild; we will show here the ")#link("https://en.wikipedia.org/wiki/Casorati%E2%80%93Weierstrass_theorem")[#text("Casorati-Weierstrass theorem")]#text(", which shows that the image of ")#mi("{f}")#text(" near the essential singularity is dense in the complex plane, as well as the more difficult ")#link("https://en.wikipedia.org/wiki/Picard%27s_great_theorem")[#text("great Picard theorem")]#text(" which asserts that in fact the image can omit at most one point in the complex plane. Nevertheless, around any isolated singularity (even the essential ones) ")#mi("{z_0}")#text(", it is possible to expand ")#mi("{f}")#text(" as a variant of a Taylor series known as a ")#link("https://en.wikipedia.org/wiki/Laurent_series")[#text("Laurent series")]#text(" ")#mi("{\\sum_{n=-\\infty}^\\infty a_n (z-z_0)^n}")#text(". The ")#mi("{\\frac{1}{z-z_0}}")#text(" coefficient ")#mi("{a_{-1}}")#text(" of this series is particularly important for contour integration purposes, and is known as the ")#link("https://en.wikipedia.org/wiki/Residue_(complex_analysis)")[#text("residue")]#text(" of ")#mi("{f}")#text(" at the isolated singularity ")#mi("{z_0}")#text(". These residues play a central role in a common generalisation of Cauchy’s theorem and the Cauchy integral formula known as the ")#link("https://en.wikipedia.org/wiki/Residue_theorem")[#text("residue theorem")]#text(", which is a particularly useful tool for computing (or at least transforming) contour integrals of meromorphic functions, and has proven to be a particularly popular technique to use in analytic number theory. Within complex analysis, one important consequence of the residue theorem is the ")#link("https://en.wikipedia.org/wiki/Argument_principle")[#text("argument principle")]#text(", which gives a topological (and analytical) way to control the zeroes and poles of a meromorphic function.")

#text("Finally, there are the non-isolated singularities. Little can be said about these singularities in general (for instance, the residue theorem does not directly apply in the presence of such singularities), but certain types of non-isolated singularities are still relatively easy to understand. One particularly common example of such non-isolated singularity arises when trying to invert a non-injective function, such as the complex exponential ")#mi("{z \\mapsto \\exp(z)}")#text(" or a power function ")#mi("{z \\mapsto z^n}")#text(", leading to ")#link("https://en.wikipedia.org/wiki/Principal_branch")[#text("branches")]#text(" of multivalued functions such as the complex logarithm ")#mi("{z \\mapsto \\log(z)}")#text(" or the ")#mi("{n^{th}}")#text(" root function ")#mi("{z \\mapsto z^{1/n}}")#text(" respectively. Such branches will typically have a non-isolated singularity along a ")#link("https://en.wikipedia.org/wiki/Branch_point#Branch_cuts")[#text("branch cut")]#text("; this branch cut can be moved around the complex domain by switching from one branch to another, but usually cannot be eliminated entirely, unless one is willing to lift up the domain ")#mi("{U}")#text(" to a more general type of domain known as a ")#link("https://en.wikipedia.org/wiki/Riemann_surface")[#text("Riemann surface")]#text(". As such, one can view branch cuts as being an “artificial” form of singularity, being an artefact of a choice of local coordinates of a Riemann surface, rather than reflecting any intrinsic singularity of the function itself. The further study of Riemann surfaces is an important topic in complex analysis (as well as the related fields of ")#link("https://en.wikipedia.org/wiki/Complex_geometry")[#text("complex geometry")]#text(" and ")#link("https://en.wikipedia.org/wiki/Algebraic_geometry")[#text("algebraic geometry")]#text("), but this topic will be postponed to the next course in this sequence.")

#metadata(none) <tao-c2c785061d6304ab1176>

#heading(level: 1)[#strong[#text(" — 1. Laurent series — ")]]

#text("Suppose we are given a holomorphic function ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" and a point ")#mi("{z_0}")#text(" in ")#mi("{U}")#text(". For a sufficiently small radius ")#mi("{r > 0}")#text(", the circle ")#mi("{\\gamma_{z_0,r,\\circlearrowleft}}")#text(" and its interior both lie in ")#mi("{U}")#text(", and the Cauchy integral formula tells us that")

#align(center)[#tao-fit-display[#mitex("f(z) = \\frac{1}{2\\pi i} \\int_{\\gamma_{z_0,r,\\circlearrowleft}} \\frac{f(w)}{w-z}\\ dw")]]

#text("in the interior of this circle. In Corollary 20 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(", this was used to form a convergent Taylor series expansion")

#align(center)[#tao-fit-display[#mitex("f(z) = \\sum_{n=0}^\\infty a_n (z-z_0)^n")]]

#text("in the interior of this circle, where the coefficients ")#mi("{a_n}")#text(" could be reconstructed from the values of ")#mi("{f}")#text(" on the circle ")#mi("{\\gamma_{z_0,r,\\circlearrowleft}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("a_n := \\frac{1}{2\\pi i} \\int_{\\gamma_{z_0,r,\\circlearrowleft}} \\frac{f(w)}{(w-z_0)^{n+1}}\\ dw.")]]

#text("Now suppose that ")#mi("{f: U \\backslash \\{z_0\\} \\rightarrow {\\bf C}}")#text(" is only known to be holomorphic outside of ")#mi("{z_0}")#text(". Then the Cauchy integral formula no longer directly applies, because the interiors of contours such as ")#mi("{\\gamma_{z_0,r,\\circlearrowleft}}")#text(" are no longer contained in the region ")#mi("{U \\backslash \\{z_0\\}}")#text(" where ")#mi("{f}")#text(" is holomorphic. To deal with this issue, we use the following convenient decomposition.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Cauchy integral formula decomposition in annular regions)")]#text(" ")#metadata(none) <tao-48eada4fbfd35409c043>#text(" Let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a holomorphic function. Let ")#mi("{\\gamma_1}")#text(", ")#mi("{\\gamma_2}")#text(" be simple closed anticlockwise curves in ")#mi("{U}")#text(" such that ")#mi("{\\gamma_2}")#text(" is contained in the interior ")#mi("{\\mathrm{int}(\\gamma_1)}")#text(" of ")#mi("{\\gamma_1}")#text(" (or equivalently, by Exercise 51 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(", that ")#mi("{\\gamma_1}")#text(" is contained in the exterior ")#mi("{\\mathrm{ext}(\\gamma_2)}")#text(" of ")#mi("{\\gamma_2}")#text("). Suppose also that the “annular region” ")#mi("{\\mathrm{int}(\\gamma_1) \\cap \\mathrm{ext}(\\gamma_2)}")#text(" is contained in ")#mi("{U}")#text(". Then there exists a decomposition")

#align(center)[#tao-fit-display[#mitex("f = f_1 + f_2")]]

#text("on ")#mi("{U}")#text(", where ")#mi("{f_1: U \\cup \\mathrm{int}(\\gamma_1) \\rightarrow {\\bf C}}")#text(" is holomorphic on the union of ")#mi("{U}")#text(" and the interior of ")#mi("{\\gamma_1}")#text(", and ")#mi("{f_2: U \\cup \\mathrm{ext}(\\gamma_2) \\rightarrow {\\bf C}}")#text(" is holomorphic on the union of ")#mi("{U}")#text(" and the exterior of ")#mi("{\\gamma_2}")#text(", with ")#mi("{f_2(z) \\rightarrow 0}")#text(" as ")#mi("{z \\rightarrow \\infty}")#text(". Furthermore, this decomposition is unique.")

#text("In addition, we have the Cauchy integral type formulae")

#align(center)[#tao-fit-display[#mitex("f_1(z) = \\frac{1}{2\\pi i} \\int_{\\gamma_1} \\frac{f(w)}{w-z}\\ dw")]]

#text("for ")#mi("{z}")#text(" in the interior of ")#mi("{\\gamma_1}")#text(", and")

#align(center)[#tao-fit-display[#mitex("f_2(z) = - \\frac{1}{2\\pi i} \\int_{\\gamma_2} \\frac{f(w)}{w-z}\\ dw")]]

#text("for ")#mi("{z}")#text(" in the exterior of ")#mi("{\\gamma_2}")#text(". In particular, we have")

#metadata(none) <tao-9b6b882bf8be9361dacc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("f(z) = \\frac{1}{2\\pi i} \\int_{\\gamma_1} \\frac{f(w)}{w-z}\\ dw - \\frac{1}{2\\pi i} \\int_{\\gamma_2} \\frac{f(w)}{w-z}\\ dw")]]

#text("for ")#mi("{z}")#text(" in ")#mi("{\\mathrm{int}(\\gamma_1) \\cap \\mathrm{ext}(\\gamma_2)}")#text(".")
]

#image("../assets/b2bd1659eb8878c05951d6d3da08f83475e6f38d8a0de065552edf8dcdb40e53-5afe84b65f4c821b4dedaffa3c68e7c58d8b744c56ce4efe388f2e1303086646.png", width: 90%)

#emph[#text("Proof:")]#text(" We begin with uniqueness. Suppose we have two decompositions")

#align(center)[#tao-fit-display[#mitex("f = f_1 + f_2 = g_1 + g_2")]]

#text("on ")#mi("{U}")#text(", where ")#mi("{f_1,g_1: U \\cup \\mathrm{int}(\\gamma_1) \\rightarrow {\\bf C}}")#text(" and ")#mi("{f_2,g_2: U \\cup \\mathrm{ext}(\\gamma_2) \\rightarrow {\\bf C}}")#text(" holomorphic, and ")#mi("{f_2, g_2}")#text(" both going to zero at infinity. Then the holomorphic functions ")#mi("{f_1-g_1: U \\cup \\mathrm{int}(\\gamma_1) \\rightarrow {\\bf C}}")#text(" and ")#mi("{g_2 - f_2: U \\cup \\mathrm{ext}(\\gamma_2) \\rightarrow {\\bf C}}")#text(" agree on the common domain ")#mi("{U}")#text(" and are hence restrictions of a single entire function ")#mi("{F: {\\bf C} \\rightarrow {\\bf C}}")#text(". But ")#mi("{F}")#text(" goes to zero at infinity and is hence bounded; applying Liouville’s theorem (Theorem 30 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(") we see that ")#mi("{F}")#text(" vanishes entirely. This gives ")#mi("{f_1=g_1}")#text(" on ")#mi("{U \\cap \\mathrm{int}(\\gamma_1)}")#text(" and ")#mi("{f_2=g_2}")#text(" on ")#mi("{U \\cap \\mathrm{ext}(\\gamma_2)}")#text(".")

#text("Now for existence. Suppose that we can establish the identity ")#link(<tao-9b6b882bf8be9361dacc>)[#text("(1)")]#text(" for ")#mi("{z}")#text(" in ")#mi("{\\mathrm{int}(\\gamma_1) \\cap \\mathrm{ext}(\\gamma_2)}")#text(". Then we can define ")#mi("{f_1}")#text(" on ")#mi("{\\mathrm{int}(\\gamma_1)}")#text(" by")

#align(center)[#tao-fit-display[#mitex("f_1(z) := \\frac{1}{2\\pi i} \\int_{\\gamma_1} \\frac{f(w)}{w-z}\\ dw")]]

#text("and on ")#mi("{U \\cap \\mathrm{ext}(\\gamma_2)}")#text(" by")

#align(center)[#tao-fit-display[#mitex("f_1(z) := f(z) + \\frac{1}{2\\pi i} \\int_{\\gamma_2} \\frac{f(w)}{w-z}\\ dw,")]]

#text("noting from ")#link(<tao-9b6b882bf8be9361dacc>)[#text("(1)")]#text(" that this consistently defines ")#mi("{f_1}")#text(" on")

#align(center)[#tao-fit-display[#mitex("\\mathrm{int}(\\gamma_1) \\cup (U \\cap \\mathrm{ext}(\\gamma_2)) = U \\cup \\mathrm{int}(\\gamma_1).")]]

#text("From Exercise 38 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(" (after first using Cauchy’s theorem to temporarily deform ")#mi("{\\gamma_1}")#text(" to a polygonal path) we see that ")#mi("{f_1}")#text(" is holomorphic. Similarly if we define ")#mi("{f_2}")#text(" on ")#mi("{\\mathrm{ext}(\\gamma_2)}")#text(" by")

#align(center)[#tao-fit-display[#mitex("f_2(z) := - \\frac{1}{2\\pi i} \\int_{\\gamma_2} \\frac{f(w)}{w-z}\\ dw")]]

#text("and on ")#mi("{U \\cap \\mathrm{int}(\\gamma_1)}")#text(" by")

#align(center)[#tao-fit-display[#mitex("f_2(z) := f(z) - \\frac{1}{2\\pi i} \\int_{\\gamma_1} \\frac{f(w)}{w-z}\\ dw.")]]

#text("One can then verify that ")#mi("{f_1,f_2}")#text(" obey all the required properties.")

#text("Thus it remains to establish ")#link(<tao-9b6b882bf8be9361dacc>)[#text("(1)")]#text(". This follows from the homology form of the Cauchy integral formula (Exercise 15(v) of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text("), but we can also avoid explicit use of homology by the following “keyhole contour” argument. For ")#mi("{z \\in \\mathrm{int}(\\gamma_1) \\cap \\mathrm{ext}(\\gamma_2)}")#text(", we have from the definition of winding number that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi i} \\int_{\\gamma_1} \\frac{1}{w-z}\\ dw = 1")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi i} \\int_{\\gamma_2} \\frac{1}{w-z}\\ dw = 0")]]

#text("and so to prove ")#link(<tao-9b6b882bf8be9361dacc>)[#text("(1)")]#text(", it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi i} \\int_{\\gamma_1} \\frac{f(w)-f(z)}{w-z}\\ dw = \\frac{1}{2\\pi i} \\int_{\\gamma_2} \\frac{f(w)-f(z)}{w-z}\\ dw.")]]

#text("By the factor theorem (Corollary 24 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(") it thus suffices to show that")

#metadata(none) <tao-813ea375fb2626d01032>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\int_{\\gamma_1} F(w)\\ dw = \\int_{\\gamma_2} F(w)\\ dw")]]

#text("whenever ")#mi("{F: U \\rightarrow {\\bf C}}")#text(" is holomorphic.")

#text("By perturbing ")#mi("{\\gamma_1,\\gamma_2}")#text(" using Cauchy’s theorem we may assume that these curves are simple closed polygonal paths (if one wishes, one can also restrict the edges to be horizontal and vertical, although this is not strictly necessary for the argument). By connecting a point in ")#mi("{\\gamma_1}")#text(" to a point in ")#mi("{\\gamma_2}")#text(" by a polygonal path in the interior of ")#mi("{\\gamma_1}")#text(", and removing loops, self-intersections, or excursions into the interior (or image) of ")#mi("{\\gamma_2}")#text(", we can find a simple polygonal path ")#mi("{\\gamma_3}")#text(" from a point ")#mi("{z_1}")#text(" in ")#mi("{\\gamma_1}")#text(" to a point ")#mi("{z_2}")#text(" in ")#mi("{\\gamma_2}")#text(" that lies entirely in ")#mi("{\\mathrm{int}(\\gamma_1) \\cap \\mathrm{ext}(\\gamma_2)}")#text(" except at the endpoints. By rearranging ")#mi("{\\gamma_1}")#text(" and ")#mi("{\\gamma_2}")#text(" we may assume that ")#mi("{z_1}")#text(" is the initial and terminal point of ")#mi("{\\gamma_1}")#text(", and ")#mi("{z_2}")#text(" is the initial and terminal point of ")#mi("{\\gamma_2}")#text(". Then the closed polygonal path ")#mi("{\\gamma_1 + \\gamma_3 + (-\\gamma_2) + (-\\gamma_3)}")#text(" has vanishing winding number in the interior of ")#mi("{\\gamma_2}")#text(" or exterior of ")#mi("{\\gamma_1}")#text(", thus ")#mi("{U}")#text(" contains all the points where the winding number is non-zero. This path is not simple, but we can approximate it to arbitrary accuracy ")#mi("{\\varepsilon}")#text(" by a simple closed polygonal path ")#mi("{\\gamma_\\varepsilon}")#text(" by shifting the simple polygonal paths ")#mi("{\\gamma_3}")#text(" and ")#mi("{-\\gamma_3}")#text(" slightly; for ")#mi("{\\varepsilon}")#text(" small enough, the interior of ")#mi("{\\gamma_\\varepsilon}")#text(" will then lie in ")#mi("{U}")#text(". Applying Cauchy’s theorem (Theorem 54 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(") we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_\\varepsilon} F(w)\\ dw = 0;")]]

#text("taking limits as ")#mi("{\\varepsilon \\rightarrow 0}")#text(" we obtain ")#link(<tao-813ea375fb2626d01032>)[#text("(2)")]#text(" as claimed. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Let ")#mi("{\\gamma_0}")#text(" be a simple closed anticlockwise curve, and let ")#mi("{\\gamma_1,\\dots,\\gamma_n}")#text(" be simple closed anticlockwise curves in the interior ")#mi("{\\mathrm{int}(\\gamma_0)}")#text(" of ")#mi("{\\gamma_0}")#text(" whose images are disjoint, and such that the interiors ")#mi("{\\mathrm{int}(\\gamma_1),\\dots,\\mathrm{int}(\\gamma_n)}")#text(" are also disjoint. Let ")#mi("{U}")#text(" be an open set containing ")#mi("{\\gamma_0,\\gamma_1,\\dots,\\gamma_n}")#text(" and the region")

#align(center)[#tao-fit-display[#mitex("\\Omega := \\mathrm{int}(\\gamma_0) \\cap \\mathrm{ext}(\\gamma_1) \\cap \\dots \\cap \\mathrm{ext}(\\gamma_n).")]]

#text("Let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be holomorphic. Show that for any ")#mi("{z_0 \\in \\Omega}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("f(z_0) = \\frac{1}{2\\pi i} \\int_{\\gamma_0} \\frac{f(z)}{z-z_0}\\ dz - \\sum_{j=1}^n \\frac{1}{2\\pi i} \\int_{\\gamma_j} \\frac{f(z)}{z-z_0}\\ dz.")]]

#text("(")#emph[#text("Hint:")]#text(" induct on ")#mi("{n}")#text(" using Lemma ")#link(<tao-48eada4fbfd35409c043>)[#text("1")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3 (Painlevé’s theorem on removable singularities)")]#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(". Let ")#mi("{S}")#text(" be a compact subset of ")#mi("{U}")#text(" which has zero length in the following sense: for any ")#mi("{\\varepsilon>0}")#text(", one can cover ")#mi("{S}")#text(" by a countable number of disks ")#mi("{D(z_n,r_n)}")#text(" such that ")#mi("{\\sum_n r_n < \\varepsilon}")#text(". Let ")#mi("{f: U \\backslash S \\rightarrow {\\bf C}}")#text(" be a bounded holomorphic function. Show that the singularities in ")#mi("{S}")#text(" are removable in the sense that there is an extension ")#mi("{\\tilde f: U \\rightarrow {\\bf C}}")#text(" of ")#mi("{f}")#text(" to ")#mi("{U}")#text(" which remains holomorphic. (")#emph[#text("Hint:")]#text(" one can work locally in some disk in ")#mi("{U}")#text(" that contains a portion of ")#mi("{S}")#text(". Cover this portion by a finite number of small disks, group them into connected components, use the previous exercise, and take an appropriate limit.) Note that this result generalises Riemann’s theorem on removable singularities, see Exercise 37 from ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(". The situation when ")#mi("{S}")#text(" has positive length is considerably more subtle, and leads to the theory of ")#link("https://en.wikipedia.org/wiki/Analytic_capacity")[#text("analytic capacity")]#text(", which we will not discuss further here.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4 (Variant of mean value theorem)")]#text(" Let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a holomorphic function on an open subset ")#mi("{U}")#text(" of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{\\gamma}")#text(" be a simple closed contour in ")#mi("{U}")#text(", whose interior is also contained in ")#mi("{U}")#text(". Show that for any ")#mi("{z}")#text(" in the interior of ")#mi("{\\gamma}")#text(", there exists ")#mi("{w}")#text(" in the image of ")#mi("{\\gamma}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{f(z)-f(w)}{z-w}\\right| \\geq \\left|f^{\\prime}(z)\\right|.", block: true)]]

#text("(Hint: use the Riemann singularity removal theorem and the maximum principle.)")
]

#text("Now suppose that ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" is holomorphic for some annulus of the form ")#metadata(none) <tao-49915e0d7d4b402e3017>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("U = \\{ z \\in {\\bf C}: r < \\left|z-z_0\\right| < R \\}", block: true)]]

#text(" ")#text(" for some ")#mi("{z_0 \\in {\\bf C}}")#text(" and ")#mi("{0 \\leq r < R \\leq \\infty}")#text(". From Lemma ")#link(<tao-48eada4fbfd35409c043>)[#text("1")]#text(", we can split ")#mi("{f = f_1 + f_2}")#text(", where ")#mi("{f_1}")#text(" is holomorphic in ")#mi("{D(z_0,R)}")#text(", and ")#mi("{f_2}")#text(" is holomorphic in the exterior region ")#tao-math("{\\{ z: \\left|z-z_0\\right| > r \\}}", block: false)#text(", with ")#mi("{f_2(z)}")#text(" going to zero as ")#mi("{z \\rightarrow \\infty}")#text(". From Corollary 20 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(", one has a Taylor expansion")

#align(center)[#tao-fit-display[#mitex("f_1(z) = \\sum_{n=0}^\\infty a_n (z-z_0)^n")]]

#text("for some coefficients ")#mi("{a_0,a_1,\\dots \\in {\\bf C}}")#text(" that is absolutely convergent in the disk ")#mi("{D(z_0,R)}")#text(". One cannot directly apply this Taylor expansion to ")#mi("{f_2}")#text(". However, observe that the function ")#mi("{z \\mapsto f_2(z_0 + \\frac{1}{z})}")#text(" is holomorphic in the punctured disk ")#mi("{D(0,1/r) \\backslash \\{0\\}}")#text(", and goes to zero as one approaches zero. By Riemann’s theorem (Exercise 37 from ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text("), this function may be extended to ")#mi("{D(0,1/r)}")#text(" to a holomorphic function that vanishes at the origin. Applying Corollary 20 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(" again, we conclude that there is a Taylor expansion")

#align(center)[#tao-fit-display[#mitex("f_2( z_0 + \\frac{1}{z} ) = \\sum_{n=1}^\\infty a_{-n} z^n")]]

#text("for some coefficients ")#mi("{a_{-1}, a_{-2},\\dots \\in {\\bf C}}")#text(" that is absolutely convergent in the punctured disk ")#mi("{D(0,1/r) \\backslash \\{0\\}}")#text(". Changing variables, we conclude that")

#align(center)[#tao-fit-display[#mitex("f_2(z) = \\sum_{n=-\\infty}^{-1} a_n (z-z_0)^n")]]

#text("for ")#mi("{z}")#text(" in ")#tao-math("{\\{ z: \\left|z-z_0\\right| > r \\}}", block: false)#text(", and thus")

#metadata(none) <tao-204fb6b2a5fddfef1e9a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("f(z) = \\sum_{n=-\\infty}^\\infty a_n (z-z_0)^n")]]

#text("for all ")#mi("{z}")#text(" in ")#link(<tao-49915e0d7d4b402e3017>)[#text("(3)")]#text(", with the doubly infinite series on the right-hand side being absolutely convergent. This series is known as the ")#link("https://en.wikipedia.org/wiki/Laurent_series")[#text("Laurent series")]#text(" in the annulus ")#link(<tao-49915e0d7d4b402e3017>)[#text("(3)")]#text(". The coefficients ")#mi("{a_n}")#text(" may be explicitly computed in terms of ")#mi("{f}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5 (Fourier inversion formula)")]#text(" ")#metadata(none) <tao-04efaf080f5a3e74e1c2>#text(" Let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be holomorphic on some open set ")#mi("{U}")#text(" that contains an annulus of the form ")#link(<tao-49915e0d7d4b402e3017>)[#text("(3)")]#text(", and let ")#mi("{a_n}")#text(" be the coefficients of the Laurent expansion ")#link(<tao-204fb6b2a5fddfef1e9a>)[#text("(4)")]#text(" in this annulus. Show that the coefficients ")#mi("{a_n}")#text(" are uniquely determined by ")#mi("{f}")#text(" and ")#mi("{r,R}")#text(", and are given by the formula")

#align(center)[#tao-fit-display[#mitex("a_n = \\frac{1}{2\\pi i} \\int_\\gamma \\frac{f(z)}{(z-z_0)^{n+1}}\\ dz")]]

#text("for all integers ")#mi("{n}")#text(", whenever ")#mi("{\\gamma}")#text(" is a simple closed curve in the annulus with ")#mi("{W_\\gamma(z_0) = 1}")#text(". Also establish the bounds")

#metadata(none) <tao-63518250301558366648>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\liminf_{n \\rightarrow +\\infty} \\left|a_n\\right|^{-1/n} \\geq R", block: true)]]

#text("and")

#metadata(none) <tao-ab5b62081b1d305e78d0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\liminf_{n \\rightarrow +\\infty} \\left|a_{-n}\\right|^{-1/n} \\geq 1/r.", block: true)]]
]

#text("The following modification of the above exercise may help explain the terminology “Fourier inversion formula”.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6 (Fourier inversion formula, again)")]#text(" Let ")#mi("{0 < r < 1 < R}")#text(".")

#list(
[#text("(i) Show that if ")#mi("{f}")#text(" is holomorphic on the annulus ")#tao-math("{\\{ z: r < \\left|z\\right| < R\\}}", block: false)#text(", then we have the Fourier expansion")

#metadata(none) <tao-dce7cce055566bed799f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("f(e^{i\\theta}) = \\sum_{n=-\\infty}^\\infty a_n e^{in\\theta}")]]

#text("for all ")#mi("{\\theta \\in {\\bf R}}")#text(", where the Fourier coefficients ")#mi("{a_n}")#text(" are given by the formula")

#metadata(none) <tao-8d7ec9aa29b87f7634b2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("a_n := \\frac{1}{2\\pi} \\int_0^{2\\pi} f(e^{i\\theta}) e^{-in\\theta}\\ d\\theta.")]]

#text("Furthermore, show that the Fourier series in ")#link(<tao-dce7cce055566bed799f>)[#text("(7)")]#text(" is absolutely convergent, and the coefficients ")#mi("{a_n}")#text(" obey the asymptotic bounds ")#link(<tao-63518250301558366648>)[#text("(5)")]#text(", ")#link(<tao-ab5b62081b1d305e78d0>)[#text("(6)")]#text(".")],
[#text("(ii) Conversely, if ")#mi("{a_n, n \\in {\\bf Z}}")#text(" are complex numbers obeying the asymptotic bounds ")#link(<tao-63518250301558366648>)[#text("(5)")]#text(", ")#link(<tao-ab5b62081b1d305e78d0>)[#text("(6)")]#text(", show that there exists a function ")#mi("{f}")#text(" holomorphic on the annulus ")#tao-math("{\\{ z: r < \\left|z\\right| < R\\}}", block: false)#text(" obeying the Fourier expansion ")#link(<tao-dce7cce055566bed799f>)[#text("(7)")]#text(" and the inversion formula ")#link(<tao-8d7ec9aa29b87f7634b2>)[#text("(8)")]#text(".")]
)
]

#text("The Laurent series for a given function can vary as one varies the annulus. Consider for instance the function ")#mi("{f(z) = \\frac{1}{1-z}}")#text(". In the annulus ")#tao-math("{\\{ z: 0 < \\left|z\\right| < 1 \\}}", block: false)#text(", the Laurent expansion coincides with the Taylor expansion:")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{1-z} = \\sum_{n=0}^\\infty z^n = 1 + z + z^2 + \\dots.")]]

#text("On the other hand, in the exterior region ")#tao-math("{\\{ z: \\left|z\\right| > 1\\}}", block: false)#text(", the Taylor expansion is no longer convergent. Instead, if one writes ")#mi("{\\frac{1}{1-z} = \\frac{-1/z}{1-1/z}}")#text(" and uses the geometric series formula, one instead has the Laurent expansion")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{1-z} = \\sum_{n=-\\infty}^{-1} -z^n = -\\frac{1}{z} - \\frac{1}{z^2} - \\dots")]]

#text("in this region.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Find the Laurent expansions for the function ")#mi("{f(z) := \\frac{1}{(z-1)(z-2)}}")#text(" in the regions ")#tao-math("{\\{ z: 0 < \\left|z\\right| < 1 \\}}", block: false)#text(", ")#tao-math("{\\{ z: 1 < \\left|z\\right| < 2 \\}}", block: false)#text(", and ")#tao-math("{\\{ z: \\left|z\\right| > 2 \\}}", block: false)#text(". (")#emph[#text("Hint:")]#text(" use partial fractions.)")
]

#text("We can use Laurent series to analyse an isolated singularity. Suppose that ")#mi("{f: D(z_0,r) \\backslash \\{z_0\\} \\rightarrow {\\bf C}}")#text(" is holomorphic on a punctured disk ")#mi("{D(z_0,r) \\backslash \\{z_0\\}}")#text(". By the above discussion, we have a Laurent series expansion ")#link(<tao-204fb6b2a5fddfef1e9a>)[#text("(4)")]#text(" in this punctured disk. If the singularity is removable, then the Laurent series must coincide with the Taylor series (by the uniqueness component of Exercise ")#link(<tao-04efaf080f5a3e74e1c2>)[#text("5")]#text("), so in partcular ")#mi("{a_n=0}")#text(" for all negative ")#mi("{n}")#text("; conversely, if ")#mi("{a_n}")#text(" vanishes for all negative ")#mi("{n}")#text(", then the Laurent series matches up with a convergent Taylor series and so the singularity is removable. We then adopt the following classification:")

#list(
[#text("(i) ")#mi("{f}")#text(" has a ")#emph[#text("removable singularity")]#text(" at ")#mi("{z_0}")#text(" if one has ")#mi("{a_n=0}")#text(" for all negative ")#mi("{n}")#text(". If furthermore there is an ")#mi("{m \\geq 0}")#text(" such that ")#mi("{a_m \\neq 0}")#text(" and ")#mi("{a_n=0}")#text(" for ")#mi("{n < m}")#text(", we say that ")#mi("{f}")#text(" has a ")#emph[#text("zero of order ")#mi("{m}")]#text(" at ")#mi("{z_0}")#text(" (after removing the singularity). Zeroes of order ")#mi("{1}")#text(" are known as ")#emph[#text("simple zeroes")]#text(", zeroes of order ")#mi("{2}")#text(" are known as ")#emph[#text("double zeroes")]#text(", and so forth.")],
[#text("(ii) ")#mi("{f}")#text(" has a ")#link("https://en.wikipedia.org/wiki/Pole_(complex_analysis)")[#text("pole of order ")#mi("{m}")]#text(" at ")#mi("{z_0}")#text(" for some ")#mi("{m \\geq 1}")#text(" if one has ")#mi("{a_{-m} \\neq 0}")#text(", and ")#mi("{a_n=0}")#text(" for all ")#mi("{n < -m}")#text(". Poles of order ")#mi("{1}")#text(" are known as ")#emph[#text("simple poles")]#text(", poles of order ")#mi("{2}")#text(" are ")#emph[#text("double poles")]#text(", and so forth.")],
[#text("(iii) ")#mi("{f}")#text(" has an ")#link("https://en.wikipedia.org/wiki/Essential_singularity")[#text("essential singularity")]#text(" if ")#mi("{a_n \\neq 0}")#text(" for infinitely many negative ")#mi("{n}")#text(".")]
)

#text("It is clear that any holomorphic function ")#mi("{f: D(z_0,r) \\backslash \\{z_0\\} \\rightarrow {\\bf C}}")#text(" will be of exactly one of the above three categories, unless it is identically zero. Also, from the uniqueness of Laurent series, shrinking ")#mi("{r}")#text(" does not affect which of the three categories ")#mi("{f}")#text(" will lie in (or what order of pole ")#mi("{f}")#text(" will have, in the second category). Thus, we can classify any isolated singularity ")#mi("{z_0 \\in S}")#text(" of a holomorphic function ")#mi("{f: U \\backslash S \\rightarrow {\\bf C}}")#text(" with singularities as being either removable, a pole of some finite order, or an essential singularity by restricting ")#mi("{f}")#text(" to a small punctured disk ")#mi("{D(z_0,r) \\backslash \\{z_0\\}}")#text(" and inspecting the Laurent coefficients ")#mi("{a_n}")#text(" for negative ")#mi("{n}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 8")]#text(" The function ")#mi("{z \\mapsto e^{1/z}}")#text(" has a Laurent expansion")

#align(center)[#tao-fit-display[#mitex("e^{1/z} = 1 + \\frac{1}{z} + \\frac{1}{2! z^2} + \\dots")]]

#text("and thus has an essential singularity at ")#mi("{z=0}")#text(".")
]

#text("It is clear from the definition (and the holomorphicity of Taylor series) that (as discussed in the introduction), a holomorphic function ")#mi("{f: U \\backslash S \\rightarrow {\\bf C}}")#text(" has a pole of order ")#mi("{m}")#text(" at an isolated singularity ")#mi("{z_0 \\in S}")#text(" if and only if it is of the form ")#mi("{f(z) = \\frac{g(z)}{(z-z_0)^m}}")#text(" for some holomorphic ")#mi("{g: U \\backslash S \\cup \\{z_0\\} \\rightarrow {\\bf C}}")#text(" with ")#mi("{g(z_0) \\neq 0}")#text(". Similarly, a holomorphic function would have a zero of order ")#mi("{m}")#text(" at ")#mi("{z_0}")#text(" if and only if ")#mi("{f(z) = g(z) (z-z_0)^m}")#text(" for some ")#mi("{g: U \\backslash S \\cup \\{z_0\\} \\rightarrow {\\bf C}}")#text(" with ")#mi("{g(z_0) \\neq 0}")#text(".")

#text("We can now define a class of functions that only have “nice” singularities:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 9 (Meromorphic functions)")]#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(". A function ")#mi("{f:U \\backslash S \\rightarrow {\\bf C}}")#text(" defined on ")#mi("{U}")#text(" outside of a closed singular set ")#mi("{S}")#text(" is said to be ")#link("https://en.wikipedia.org/wiki/Meromorphic_function")[#text("meromorphic")]#text(" on ")#mi("{U}")#text(" if")

#list(
[#text("(i) ")#mi("{S}")#text(" is closed in ")#mi("{U}")#text(" and ")#link("https://en.wikipedia.org/wiki/Isolated_point")[#text("discrete")]#text(" (i.e., all points in ")#mi("{S}")#text(" are isolated);")],
[#text("(ii) ")#mi("{f}")#text(" is holomorphic on ")#mi("{U \\backslash S}")#text("; and")],
[#text("(iii) Every ")#mi("{z_0 \\in S}")#text(" is either a removable singularity or a pole of finite order.")]
)
]

#text("Two meromorphic functions ")#mi("{f_1: U \\backslash S_1 \\rightarrow {\\bf C}}")#text(", ")#mi("{f_2: U \\backslash S_2 \\rightarrow {\\bf C}}")#text(" are said to be ")#emph[#text("equivalent")]#text(" if they agree on their common domain of definition ")#mi("{U \\backslash (S_1 \\cup S_2)}")#text(". It is easy to see that this is an equivalence relation. It is common to identify meromorphic functions up to equivalence, similarly to how in measure theory it is common to identify functions which agree almost everywhere.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Meromorphic functions form a field)")]#text(" Let ")#mi("{M(U)}")#text(" denote the space of meromorphic functions on a connected open set ")#mi("{U \\subset {\\bf C}}")#text(", up to equivalence. Show that ")#mi("{M(U)}")#text(" is a field (with the obvious field operations). What happens if ")#mi("{U}")#text(" is not connected?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11 (Order is a valuation)")]#text(" Let ")#mi("{U \\subset {\\bf C}}")#text(" be an open connected set. If ")#mi("{f: U \\backslash S \\rightarrow {\\bf C}}")#text(" is a meromorphic function, and ")#mi("{z_0 \\in U}")#text(", define the ")#emph[#text("order")]#text(" ")#mi("{\\mathrm{ord}_{z_0}(f)}")#text(" of ")#mi("{f}")#text(" at ")#mi("{z_0}")#text(" as follows:")

#list(
[#text("(a) If ")#mi("{f}")#text(" has a removable singularity at ")#mi("{z_0}")#text(", and has a zero of order ")#mi("{m}")#text(" at ")#mi("{z_0}")#text(" once the singularity is removed, then ")#mi("{\\mathrm{ord}_{z_0}(f) := m}")#text(".")],
[#text("(b) If ")#mi("{f}")#text(" is holomorphic at ")#mi("{z_0}")#text(", and has a zero of order ")#mi("{m}")#text(" at ")#mi("{z_0}")#text(", then ")#mi("{\\mathrm{ord}_{z_0}(f) := m}")#text(".")],
[#text("(c) If ")#mi("{f}")#text(" has a pole of order ")#mi("{m}")#text(" at ")#mi("{z_0}")#text(", then ")#mi("{\\mathrm{ord}_{z_0}(f) := -m}")#text(".")],
[#text("(d) If ")#mi("{f}")#text(" is identically zero, then ")#mi("{\\mathrm{ord}_{z_0}(f) = +\\infty}")#text(".")]
)

#text("Establish the following facts:")

#list(
[#text("(i) If ")#mi("{f_1: U \\backslash S_1 \\rightarrow {\\bf C}}")#text(" and ")#mi("{f_2: U \\backslash S_2 \\rightarrow {\\bf C}}")#text(" are equivalent meromorphic functions, then ")#mi("{\\mathrm{ord}_{z_0}(f_1) = \\mathrm{ord}_{z_0}(f_2)}")#text(" for all ")#mi("{z_0 \\in U}")#text(". In particular, one can meaningfully define the order of an element of ")#mi("{M(U)}")#text(" at any point ")#mi("{z_0}")#text(" in ")#mi("{U}")#text(", where ")#mi("{M(U)}")#text(" is as in the preceding exercise.")],
[#text("(ii) If ")#mi("{f,g \\in M(U)}")#text(" and ")#mi("{z_0 \\in U}")#text(", show that ")#mi("{\\mathrm{ord}_{z_0}(fg) = \\mathrm{ord}_{z_0}(f) + \\mathrm{ord}_{z_0}(g)}")#text(". If ")#mi("{g}")#text(" is not zero, show that ")#mi("{\\mathrm{ord}_{z_0}(f/g) = \\mathrm{ord}_{z_0}(f) - \\mathrm{ord}_{z_0}(g)}")#text(".")],
[#text("(iii) If ")#mi("{f,g \\in M(U)}")#text(" and ")#mi("{z_0 \\in U}")#text(", show that ")#mi("{\\mathrm{ord}_{z_0}(f+g) \\geq \\min( \\mathrm{ord}_{z_0}(f), \\mathrm{ord}_{z_0}(g) )}")#text(". Furthermore, show if ")#mi("{\\mathrm{ord}_{z_0}(f) \\neq \\mathrm{ord}_{z_0}(g)}")#text(", then the above inequality is in fact an equality.")]
)

#text("In the language of abstract algebra, the above facts are asserting that ")#mi("{\\mathrm{ord}_{z_0}}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Valuation_(algebra)")[#text("valuation")]#text(" on the field ")#mi("{M(U)}")#text(".")
]

#text("The behaviour of a holomorphic function near an isolated singularity depends on the type of singularity.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 12")]#text(" ")#metadata(none) <tao-082880fec97cd1a5dfa3>#text(" Let ")#mi("{f: U \\backslash S \\rightarrow {\\bf C}}")#text(" be holomorphic on an open set ")#mi("{U}")#text(" outside of a closed singular set ")#mi("{S}")#text(", and let ")#mi("{z_0}")#text(" be an isolated singularity in ")#mi("{S}")#text(".")

#list(
[#text("(i) If ")#mi("{z_0}")#text(" is a removable singularity of ")#mi("{f}")#text(", then ")#mi("{f(z)}")#text(" converges to a finite limit as ")#mi("{z \\rightarrow z_0}")#text(".")],
[#text("(ii) If ")#mi("{z_0}")#text(" is a pole of ")#mi("{f}")#text(", then ")#tao-math("{\\left|f(z)\\right| \\rightarrow \\infty}", block: false)#text(" as ")#mi("{z \\rightarrow z_0}")#text(".")],
[#text("(iii) (")#link("https://en.wikipedia.org/wiki/Casorati%E2%80%93Weierstrass_theorem")[#text("Casorati-Weierstrass theorem")]#text(") If ")#mi("{z_0}")#text(" is an essential singularity of ")#mi("{f}")#text(", then every point ")#mi("{c}")#text(" of ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" is a limit point of ")#mi("{f(z)}")#text(" as ")#mi("{z \\rightarrow z_0}")#text(", that is to say there exists a sequence ")#mi("{z_n}")#text(" converging to ")#mi("{z_0}")#text(" such that ")#mi("{f(z_n)}")#text(" converges to ")#mi("{c}")#text(" (where we adopt the convention that ")#mi("{f(z_n)}")#text(" converges to ")#mi("{\\infty}")#text(" if ")#tao-math("{\\left|f(z_n)\\right|}", block: false)#text(" converges to ")#mi("{\\infty}")#text(").")]
)
]

#emph[#text("Proof:")]#text(" Part (i) is obvious. Part (ii) is immediate from the factorisation ")#mi("{f(z) = g(z) / (z-z_0)^m}")#text(" and noting that ")#mi("{g(z)}")#text(" converges to the non-zero value ")#mi("{g(z_0)}")#text(" as ")#mi("{z \\rightarrow z_0}")#text(". The ")#mi("{c=\\infty}")#text(" case of (iii) follows from Riemann’s theorem on removable singularities (Exercise 37 from ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text("). Now suppose ")#mi("{c}")#text(" is finite. If (iii) failed, then there exist ")#mi("{\\varepsilon, r > 0}")#text(" such that ")#mi("{f}")#text(" avoids the disk ")#mi("{D(c,\\varepsilon)}")#text(" on the domain ")#mi("{D(z_0,r) \\backslash \\{z_0\\}}")#text(". In particular, the function ")#mi("{\\frac{1}{f-c}}")#text(" is bounded and holomorphic on ")#mi("{D(z_0,r) \\backslash \\{z_0\\}}")#text(", and thus extends holomorphically to ")#mi("{D(z_0,r)}")#text(" by Riemann’s theorem. This function cannot vanish identically, so we must have ")#mi("{\\frac{1}{f(z)-c} = (z-z_0)^m g(z)}")#text(" on ")#mi("{D(z_0,r) \\backslash \\{z_0\\}}")#text(" for some ")#mi("{m \\geq 0}")#text(" and some holomorphic ")#mi("{g: D(z_0,r) \\rightarrow {\\bf C}}")#text(" that does not vanish at ")#mi("{z_0}")#text(". Rearranging this as ")#mi("{f(z) = c + \\frac{1/g(z)}{(z-z_0)^m}}")#text(", we see that ")#mi("{f}")#text(" has a pole or removable singularity at ")#mi("{z_0}")#text(", a contradiction. ")#mi("\\Box")

#text("In Theorem ")#link(<tao-053ea4804ef1bb33d4a3>)[#text("57")]#text(" below we will establish a significant strengthening of the Casorati-Weierstrass theorem known as the ")#link("https://en.wikipedia.org/wiki/Picard_theorem")[#text("Great Picard Theorem")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Let ")#mi("{f: {\\bf C} \\backslash S \\rightarrow {\\bf C}}")#text(" be holomorphic in ")#mi("{{\\bf C}}")#text(" outside of a discrete set ")#mi("{S}")#text(" of singularities. Let ")#mi("{z_0 \\in {\\bf C} \\backslash S}")#text(". Show that the radius of convergence of the Taylor series of ")#mi("{f}")#text(" around ")#mi("{z_0}")#text(" is equal to the distance from ")#mi("{z_0}")#text(" to the nearest non-removable singularity in ")#mi("{S}")#text(", or ")#mi("{+\\infty}")#text(" if no such non-removable singularity exists. (This fact provides a neat way to understand the rate of growth of a sequence ")#mi("{a_n}")#text(": form its generating function ")#mi("{\\sum_{n=0}^\\infty a_n z^n}")#text(", locate the singularities of that function, and find out how close they get to the origin. This is a simple example of the methods of ")#link("https://en.wikipedia.org/wiki/Analytic_combinatorics")[#text("analytic combinatorics")]#text(" in action.)")
]

#text("A curious feature of the singularities in complex analysis is that the order of singularity is “quantised”: one can have a pole of order ")#mi("{1}")#text(", ")#mi("{2}")#text(", or ")#mi("{3}")#text(" (for instance), but not a pole of order ")#mi("{2.5}")#text(" or ")#mi("{0.7}")#text(". This quantisation can be exploited: if for instance one somehow knows that the order of the pole is less than ")#mi("{m+1-\\varepsilon}")#text(" for some integer ")#mi("{m}")#text(" and real number ")#mi("{\\varepsilon>0}")#text(", then the singularity must be removable or a pole of order at most ")#mi("{m}")#text(". The following exercise formalises this assertion:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" ")#metadata(none) <tao-7327d4d86dcf6bd569c0>#text(" Let ")#mi("{f: D(z_0,r) \\backslash \\{z_0\\} \\rightarrow {\\bf C}}")#text(" be holomorphic on a disk ")#mi("{D(z_0,r)}")#text(" except for a singularity at ")#mi("{z_0}")#text(". Let ")#mi("{m}")#text(" be an integer, and suppose that there exist ")#mi("{C>0}")#text(", ")#mi("{\\varepsilon>0}")#text(" such that one has the upper bound")

#align(center)[#tao-fit-display[#tao-math("\\left|f(z)\\right| \\leq C \\left|z-z_0\\right|^{-m-1+\\varepsilon}", block: true)]]

#text("for all ")#mi("{z \\in D(z_0,r) \\backslash \\{z_0\\}}")#text(". Show that the singularity of ")#mi("{f}")#text(" at ")#mi("{z_0}")#text(" is either removable, or a pole of order at most ")#mi("{m}")#text(" (the latter option is only possible for ")#mi("{m}")#text(" positive, of course). (")#emph[#text("Hint:")]#text(" use Exercise ")#link(<tao-04efaf080f5a3e74e1c2>)[#text("5")]#text(" and a limiting argument to evaluate the Laurent coefficients ")#mi("{a_n}")#text(" for ")#mi("{n \\leq -1}")#text(".) In particular, if one has")

#align(center)[#tao-fit-display[#tao-math("\\left|f(z)\\right| \\leq C \\left|z-z_0\\right|^{-1+\\varepsilon}", block: true)]]

#text("for all ")#mi("{z \\in D(z_0,r) \\backslash \\{z_0\\}}")#text(", then the singularity is removable.")
]

#text("As mentioned in the introduction, the theory of meromorphic functions becomes cleaner if one replaces the complex plane ")#mi("{{\\bf C}}")#text(" with the ")#link("https://en.wikipedia.org/wiki/Riemann_sphere")[#text("Riemann sphere")]#text(". This sphere is a model example of a ")#link("https://en.wikipedia.org/wiki/Riemann_surface")[#text("Riemann surface")]#text(", and we will now digress to briefly introduce this more general concept (though we will not develop the general theory of Riemann surfaces in any depth here). To motivate the definition, let us first recall from differential geometry the notion of a ")#link("https://en.wikipedia.org/wiki/Differentiable_manifold")[#text("smooth ")#mi("{n}")#text("-dimensional manifold")]#text(" ")#mi("{M}")#text(" (over the reals).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 15 (Smooth manifold)")]#text(" Let ")#mi("{n \\geq 1}")#text(", and let ")#mi("{M}")#text(" be a topological space. An (")#mi("{n}")#text("-dimensional real) ")#link("https://en.wikipedia.org/wiki/Atlas_(topology)")[#text("atlas")]#text(" for ")#mi("{M}")#text(" is an open cover ")#mi("{(U_\\alpha)_{\\alpha \\in A}}")#text(" of ")#mi("{M}")#text(" together with a family of homeomorphisms ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow V_\\alpha}")#text(" (known as ")#emph[#text("coordinate charts")]#text(") from each ")#mi("{U_\\alpha}")#text(" to an open subset ")#mi("{V_\\alpha}")#text(" of ")#mi("{{\\bf R}^n}")#text(". Furthermore, the atlas is said to be ")#emph[#text("smooth")]#text(" if for any ")#mi("{\\alpha,\\beta \\in A}")#text(", the ")#emph[#text("transition map")]#text(" ")#mi("{\\phi_\\beta \\circ \\phi_\\alpha^{-1}: \\phi_\\alpha(U_\\alpha \\cap U_\\beta) \\rightarrow \\phi_\\beta(U_\\alpha \\cap U_\\beta)}")#text(", which maps one open subset of ")#mi("{{\\bf R}^n}")#text(" to another, is required to be smooth (i.e., infinitely differentiable). A map ")#mi("{f: M \\rightarrow M^{\\prime}}")#text(" from one topological space ")#mi("{M}")#text(" (equipped with a smooth atlas of coordinate charts ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow V_\\alpha}")#text(" for ")#mi("{\\alpha \\in A}")#text(") to another ")#mi("{M^{\\prime}}")#text(" (equipped with a smooth atlas of coordinate charts ")#mi("{\\phi^{\\prime}_\\beta: U^{\\prime}_\\beta \\rightarrow V^{\\prime}_\\beta}")#text(" for some ")#mi("{\\beta \\in B}")#text(") is said to be ")#emph[#text("smooth")]#text(" if it is continuous, for any ")#mi("{\\alpha \\in A}")#text(" and ")#mi("{\\beta \\in B}")#text(", the maps ")#mi("{\\phi^{\\prime}_\\beta \\circ f \\circ \\phi_\\alpha^{-1}: \\phi_\\alpha( f^{-1}(U^{\\prime}_\\beta) \\cap U_\\alpha ) \\rightarrow V_\\beta}")#text(" are smooth; if ")#mi("{f}")#text(" is invertible and ")#mi("{f}")#text(" and ")#mi("{f^{-1}}")#text(" are both smooth, we say that ")#mi("{f}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Diffeomorphism")[#text("diffeomorphism")]#text(", and that ")#mi("{M}")#text(" and ")#mi("{M^{\\prime}}")#text(" are ")#emph[#text("diffeomorphic")]#text(". Two smooth atlases on ")#mi("{M}")#text(" are said to be ")#emph[#text("equivalent")]#text(" if the identity map from ")#mi("{M}")#text(" (equipped with one of the two atlases) to ")#mi("{M}")#text(" (equipped with the other atlas) is a diffeomorphism; this is easily seen to be an equivalence relation, and an equivalence class of such atlases is called a ")#emph[#text("smooth structure")]#text(" on ")#mi("{M}")#text(". A ")#emph[#text("smooth ")#mi("{n}")#text("-dimensional real manifold")]#text(" is a Hausdorff topological space ")#mi("{M}")#text(" equipped with a smooth structure. (In some texts the mild additional condition of ")#link("https://en.wikipedia.org/wiki/Second-countable_space")[#text("second countability")]#text(" on ")#mi("{M}")#text(" is also imposed.) A map ")#mi("{f: M \\rightarrow M^{\\prime}}")#text(" between two smooth manifolds is said to be ")#emph[#text("smooth")]#text(", if the map ")#mi("{f}")#text(" from ")#mi("{M}")#text(" (equipped with one of the atlases in the smooth structure on ")#mi("{M}")#text(") to ")#mi("{M^{\\prime}}")#text(" (equipped with one of the atlases in the smooth structure on ")#mi("{M^{\\prime}}")#text(") is smooth; it is easy to see that this definition is independent of the choices of atlas. We may similarly define the notion of a diffeomorphism between two smooth manifolds.")
]

#text("This definition may seem excessively complicated, but it captures the modern geometric philosophy that one should strive as much as possible to work with objects that are ")#emph[#text("coordinate-independent")]#text(" in that they do not depend on which atlas of coordinate charts one picks within the equivalence class of the given smooth structure in order to perform computations or to define foundational concepts. One can also define smooth manifolds more abstractly, without explicit reference to atlases, by working instead with the ")#link("https://en.wikipedia.org/wiki/Ringed_space")[#text("structure sheaf")]#text(" of the rings ")#mi("{C^\\infty(U)}")#text(" of smooth real-valued functions on open subsets ")#mi("{U}")#text(" of the manifold ")#mi("{M}")#text(", but we will not need to do so here.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 16")]#text(" A simple example of a smooth ")#mi("{1}")#text("-dimensional manifold is the unit circle ")#tao-math("{S^1 = \\{ z \\in {\\bf C}: \\left|z\\right| = 1 \\}}", block: false)#text("; there are many equivalent atlases one could place on this circle to define the smooth structure, but one example would be the atlas consisting of the two charts ")#mi("{\\phi_1: U_1 \\rightarrow V_1}")#text(", ")#mi("{\\phi_2: U_2 \\rightarrow V_2}")#text(", defined by setting ")#mi("{V_1 := (-\\pi, \\pi)}")#text(", ")#mi("{V_2 := (0, 2\\pi)}")#text(", ")#mi("{U_1 := \\{ e^{i \\theta}: \\theta \\in V_1 \\} = S^1 \\backslash \\{-1\\}}")#text(", ")#mi("{U_2 := \\{ e^{i\\theta}: \\theta \\in V_2 \\} = S^1 \\backslash \\{1\\}}")#text(", ")#mi("{\\phi_1(e^{i\\theta}) := \\theta}")#text(" for ")#mi("{\\theta \\in U_1}")#text(", and ")#mi("{\\phi_2(e^{i\\theta}) := \\theta}")#text(" for ")#mi("{\\theta \\in U_2}")#text(". Another smooth manifold, which turns out to be diffeomorphic to the unit circle ")#mi("{S^1}")#text(", is the ")#link("https://en.wikipedia.org/wiki/Alexandroff_extension")[#text("one-point compactification")]#text(" ")#mi("{{\\bf R} \\cup \\{\\infty\\}}")#text(" of the real numbers, with the two charts ")#mi("{\\phi_1: U_1 \\rightarrow V_1}")#text(", ")#mi("{\\phi_2: U_2 \\rightarrow V_2}")#text(" defined by setting ")#mi("{V_1=V_2:={\\bf R}}")#text(", ")#mi("{U_1 := {\\bf R}}")#text(", ")#mi("{U_2 := ({\\bf R} \\backslash \\{0\\}) \\cup \\{\\infty\\}}")#text(", ")#mi("{\\phi_1}")#text(" to be the identity map, and ")#mi("{\\phi_2}")#text(" defined by setting ")#mi("{\\phi_2(x) := 1/x}")#text(" for ")#mi("{x \\in {\\bf R} \\backslash \\{0\\}}")#text(" and ")#mi("{\\phi_2(\\infty) := 0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Verify that the unit circle ")#mi("{S^1}")#text(" is indeed diffeomorphic to the one-point compactification ")#mi("{{\\bf R} \\cup \\{\\infty\\}}")#text(".")
]

#text("A Riemann surface is defined similarly to a smooth manifold, except that the dimension ")#mi("{n}")#text(" is restricted to be one, the reals ")#mi("{{\\bf R}}")#text(" are replaced with the complex numbers, and the requirement of smoothness is replaced with holomorphicity (thus Riemann surfaces are to the complex numbers as smooth curves are to the real numbers). More precisely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 18 (Riemann surface)")]#text(" ")#metadata(none) <tao-e00dcb8fb28b3438d5af>#text(" Let ")#mi("{M}")#text(" be a Hausdorff topological space. A ")#emph[#text("holomorphic atlas")]#text(" on ")#mi("{M}")#text(" is an open cover ")#mi("{(U_\\alpha)_{\\alpha \\in A}}")#text(" of ")#mi("{M}")#text(" together with a family of homeomorphisms ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow V_\\alpha}")#text(" (known as ")#emph[#text("coordinate charts")]#text(") from each ")#mi("{U_\\alpha}")#text(" to an open subset ")#mi("{V_\\alpha}")#text(" of ")#mi("{{\\bf C}}")#text(", such that, for any ")#mi("{\\alpha,\\beta \\in A}")#text(", the ")#emph[#text("transition map")]#text(" ")#mi("{\\phi_\\beta \\circ \\phi_\\alpha^{-1}: \\phi_\\alpha(U_\\alpha \\cap U_\\beta) \\rightarrow \\phi_\\beta(U_\\alpha \\cap U_\\beta)}")#text(", which maps one open subset of ")#mi("{{\\bf C}}")#text(" to another, is required to be holomorphic. A map ")#mi("{f: M \\rightarrow M^{\\prime}}")#text(" from one space ")#mi("{M}")#text(" (equipped with coordinate charts ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow V_\\alpha}")#text(" for ")#mi("{\\alpha \\in A}")#text(") to another ")#mi("{M^{\\prime}}")#text(" (equipped with coordinate charts ")#mi("{\\phi^{\\prime}_\\beta: U^{\\prime}_\\beta \\rightarrow V^{\\prime}_\\beta}")#text(" for some ")#mi("{\\beta \\in B}")#text(") is said to be ")#emph[#text("holomorphic")]#text(" if it is continuous and, for any ")#mi("{\\alpha \\in A}")#text(" and ")#mi("{\\beta \\in B}")#text(", the maps ")#mi("{\\phi^{\\prime}_\\beta \\circ f \\circ \\phi_\\alpha^{-1}: \\phi_\\alpha( f^{-1}(U^{\\prime}_\\beta) \\cap U_\\alpha ) \\rightarrow V^{\\prime}_\\beta}")#text(" are holomorphic; if ")#mi("{f}")#text(" is invertible and ")#mi("{f}")#text(" and ")#mi("{f^{-1}}")#text(" are both holomorphic, we say that ")#mi("{f}")#text(" is a ")#emph[#text("complex diffeomorphism")]#text(", and that ")#mi("{M}")#text(" and ")#mi("{M^{\\prime}}")#text(" are ")#emph[#text("complex diffeomorphic")]#text(". Two holomorphic atlases on ")#mi("{M}")#text(" are said to be ")#emph[#text("equivalent")]#text(" if the identity map from ")#mi("{M}")#text(" (equipped with one of the atlases) to ")#mi("{M}")#text(" (equipped with the other atlas) is a complex diffeomorphism; this is easily seem to be an equivalence relation, and we refer to such an equivalence class as a (one-dimensional) ")#emph[#text("complex structure")]#text(" on ")#mi("{M}")#text(". A ")#emph[#text("Riemann surface")]#text(" is a Hausdorff topological space ")#mi("{M}")#text(", equipped with a one-dimensional complex structure. (Again, in some texts the hypothesis of second countability is imposed. This makes little difference in practice, as most Riemann surfaces one actually encounters will be second countable.)")
]

#text("By considering dimensions ")#mi("{n}")#text(" greater than one, one can arrive at the more general notion of a ")#link("https://en.wikipedia.org/wiki/Complex_manifold")[#text("complex manifold")]#text(", the study of which is the focus of ")#link("https://en.wikipedia.org/wiki/Complex_geometry")[#text("complex geometry")]#text(" (and also plays a central role in the closely related fields of ")#link("https://en.wikipedia.org/wiki/Several_complex_variables")[#text("several complex variables")]#text(" and complex ")#link("https://en.wikipedia.org/wiki/Algebraic_geometry")[#text("algebraic geometry")]#text("). However, we will not need to deal with higher-dimensional complex manifolds in this course. The notion of a Riemann surface should not be confused with that of a ")#link("https://en.wikipedia.org/wiki/Riemannian_manifold")[#text("Riemannian manifold")]#text(", which is the topic of study of ")#link("https://en.wikipedia.org/wiki/Riemannian_geometry")[#text("Riemannian geometry")]#text(" rather than complex geometry.")

#text("Clearly any open subset ")#mi("{U}")#text(" of the complex numbers ")#mi("{{\\bf C}}")#text(" is a Riemann surface, in which one can use the atlas that only consists of one “tautological” chart, the identity map ")#mi("{\\phi: U \\rightarrow U}")#text(". More generally, any open subset of a Riemann surface is again a Riemann surface. If ")#mi("{U,V}")#text(" are open subsets of the complex numbers, and ")#mi("{f: U \\rightarrow V}")#text(" is a map, then by unpacking all the definitions we see that ")#mi("{f: U \\rightarrow V}")#text(" is holomorphic in the sense of Definition ")#link(<tao-e00dcb8fb28b3438d5af>)[#text("18")]#text(" if and only if it is holomorphic in the usual sense.")

#text("Now we come to the Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(", which is to the complex numbers as ")#mi("{{\\bf R} \\cup \\{\\infty\\}}")#text(" is to the real numbers. As a set, this is the complex numbers ")#mi("{{\\bf C}}")#text(" with one additional point (the ")#emph[#text("point at infinity")]#text(") ")#mi("{\\infty}")#text(" attached. Topologically, this is the ")#link("https://en.wikipedia.org/wiki/Alexandroff_extension")[#text("one-point compactification")]#text(" of the complex numbers ")#mi("{{\\bf C}}")#text(": the open sets of ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" are either subsets of ")#mi("{{\\bf C}}")#text(" that were already open, or complements ")#mi("{({\\bf C} \\cup \\{\\infty\\}) \\backslash K}")#text(" of compact subsets ")#mi("{K}")#text(" of ")#mi("{{\\bf C}}")#text(". As a Riemann surface, the complex structure can be described by the atlas of coordinate charts ")#mi("{\\phi_1: U_1 \\rightarrow V_1}")#text(", ")#mi("{\\phi_2: U_2 \\rightarrow V_2}")#text(", where ")#mi("{V_1 = V_2 := {\\bf C}}")#text(", ")#mi("{U_1 := {\\bf C}}")#text(", ")#mi("{U_2 := ({\\bf C} \\backslash \\{0\\}) \\cup \\{\\infty\\}}")#text(", ")#mi("{\\phi_1}")#text(" is the identity map, and ")#mi("{\\phi_2(z)}")#text(" equals ")#mi("{1/z}")#text(" for ")#mi("{z \\in {\\bf C} \\backslash \\{0\\}}")#text(" with ")#mi("{\\phi_2(\\infty) = 0}")#text(". It is not difficult to verify that this is indeed a Riemann surface (basically because the map ")#mi("{z \\mapsto \\frac{1}{z}}")#text(" is holomorphic on ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text("). One can identify the Riemann sphere with a geometric sphere, and specifically the sphere ")#tao-math("{S^2 := \\{ (z,t) \\in {\\bf C} \\times {\\bf R}: \\left|z\\right|^2 + (t-\\frac{1}{2})^2 = \\frac{1}{4} \\}}", block: false)#text(", through the device of ")#link("https://en.wikipedia.org/wiki/Stereographic_projection")[#text("stereographic projection")]#text(" through the north pole ")#mi("{N := (0,1) \\in {\\bf C} \\times {\\bf R}}")#text(", identifying a point ")#mi("{z}")#text(" in ")#mi("{{\\bf C} \\subset {\\bf C} \\cup \\{\\infty\\}}")#text(" with the point ")#tao-math("{(\\frac{z}{1+\\left|z\\right|^2}, \\frac{\\left|z\\right|^2}{1+\\left|z\\right|^2})}", block: false)#text(" on ")#mi("{S^2 \\backslash \\{N\\}}")#text(" collinear with that point, and the point at infinity ")#mi("{\\infty}")#text(" identified with the north pole ")#mi("{N}")#text(". This geometric perspective is especially helpful when thinking about ")#link("https://en.wikipedia.org/wiki/M%C3%B6bius_transformation")[#text("Möbius transformations")]#text(", as is for instance exemplified by ")#link("https://www.youtube.com/watch?v=0z1fIsUNhO4")[#text("this excellent video")]#text(". (We may cover Möbius transformations in a subsequent set of notes.)")

#text("By unpacking the definitions, we can now work out what it means for a function to be holomorphic to or from the Riemann sphere. For instance, if ")#mi("{f: U \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" is a map from an open subset ")#mi("{U}")#text(" of ")#mi("{{\\bf C}}")#text(" to the Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(", then ")#mi("{f}")#text(" is holomorphic if and only if")

#list(
[#text("(i) ")#mi("{f}")#text(" is continuous;")],
[#text("(ii) ")#mi("{f}")#text(" is holomorphic on the set ")#mi("{\\{ z \\in U: f(z) \\neq \\infty\\}}")#text(" (which is open thanks to (i)); and")],
[#text("(iii) ")#mi("{1/f}")#text(" is holomorphic on the set ")#mi("{\\{ z \\in U: f(z) \\neq 0 \\}}")#text(" (which is open thanks to (i)), where we adopt the convention ")#mi("{1/\\infty = 0}")#text(".")]
)

#text("Similarly, if a function ")#mi("{f: U \\rightarrow {\\bf C} \\cup \\{ \\infty\\}}")#text(" is a map from an open subset ")#mi("{U}")#text(" of the Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" to the Riemann sphere, then ")#mi("{f}")#text(" is holomorphic if and only if")

#list(
[#text("(i) ")#mi("{z \\mapsto f(z)}")#text(" is holomorphic on ")#mi("{U \\cap {\\bf C}}")#text("; and")],
[#text("(ii) ")#mi("{z \\mapsto f(1/z)}")#text(" is holomorphic on ")#mi("{\\{ z \\in {\\bf C}: 1/z \\in U \\}}")#text(", where we adopt the convention ")#mi("{1/0=\\infty}")#text(".")]
)

#text("We can then identify meromorphic functions with holomorphic functions on the Riemann sphere:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Let ")#mi("{U \\subset {\\bf C}}")#text(" be open connected, let ")#mi("{S}")#text(" be a closed discrete subset of ")#mi("{U}")#text(", and let ")#mi("{f: U \\backslash S \\rightarrow {\\bf C}}")#text(" be a function. Show that the following are equivalent:")

#list(
[#text("(i) ")#mi("{f}")#text(" is meromorphic on ")#mi("{U}")#text(".")],
[#text("(ii) ")#mi("{f}")#text(" is the restriction of a holomorphic function ")#mi("{\\tilde f: U \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" to the Riemann sphere, that is not identically equal to ")#mi("{\\infty}")#text(".")]
)

#text("Furthermore, if (ii) holds, show that ")#mi("{\\tilde f}")#text(" is uniquely determined by ")#mi("{f}")#text(", and is unaffected if one replaces ")#mi("{f}")#text(" with an equivalent meromorphic function.")
]

#text("Among other things, this exercise implies that the composition of two meromorphic functions is again meromorphic (outside of where the composition is undefined, of course).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Let ")#mi("{f: {\\bf C} \\cup \\{\\infty\\} \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" be a holomorphic map from the Riemann sphere to itself. Show that ")#mi("{f}")#text(" is either identically ")#mi("{\\infty}")#text(", or is a rational function in the sense that there exist polynomials ")#mi("{P(z), Q(z)}")#text(" of one complex variable, with ")#mi("{Q}")#text(" not identically zero, such that ")#mi("{f(z) = P(z) / Q(z)}")#text(" for all ")#mi("{z \\in {\\bf C}}")#text(" with ")#mi("{Q(z) \\neq 0}")#text(". (")#emph[#text("Hint:")]#text(" show that ")#mi("{f}")#text(" has finitely many poles, and eliminate them by multiplying ")#mi("{f}")#text(" by appropriate linear factors. Then use Exercise 31 from ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21 (Partial fractions)")]#text(" Let ")#mi("{P(z)}")#text(" be a polynomial of one complex variable, which by the fundamental theorem of algebra we may write as")

#align(center)[#tao-fit-display[#mitex("P(z) = a (z-z_1)^{d_1} \\dots (z-z_k)^{d_k}")]]

#text("for some distinct roots ")#mi("{z_1,\\dots,z_k \\in {\\bf C}}")#text(", some non-zero ")#mi("{a}")#text(", and some positive integers ")#mi("{d_1,\\dots,d_k}")#text(". Let ")#mi("{Q(z)}")#text(" be another polynomial of one complex variable. Show that there exist unique polynomials ")#mi("{R_1(z),\\dots,R_k(z),S(z)}")#text(", with each ")#mi("{R_i}")#text(" having degree less than ")#mi("{d_i}")#text(" for ")#mi("{i=1,\\dots,k}")#text(", such that one has the ")#link("https://en.wikipedia.org/wiki/Partial_fraction_decomposition")[#text("partial fraction decomposition")]

#align(center)[#tao-fit-display[#mitex("\\frac{Q(z)}{P(z)} = \\sum_{j=1}^k \\frac{R_j(z)}{(z-z_j)^{d_j}} + S(z)")]]

#text("for all ")#mi("{z \\in {\\bf C} \\backslash \\{z_1,\\dots,z_k\\}}")#text(". Furthermore, show that ")#mi("{S}")#text(" vanishes if the degree ")#mi("{\\mathrm{deg}(Q)}")#text(" of ")#mi("{Q}")#text(" is less than the degree ")#mi("{\\mathrm{deg}(P)}")#text(" of ")#mi("{P}")#text(", and has degree ")#mi("{\\mathrm{deg}(Q)-\\mathrm{deg}(P)}")#text(" otherwise.")
]

#heading(level: 1)[#strong[#text(" — 2. The residue theorem — ")]]

#text("Now we can prove a significant generalisation of the Cauchy theorem and Cauchy integral formula, known as the ")#link("https://en.wikipedia.org/wiki/Residue_theorem")[#text("residue theorem")]#text(".")

#text("Suppose one has a function ")#mi("{f: U \\backslash S \\rightarrow {\\bf C}}")#text(" holomorphic on an open set ")#mi("{U \\subset {\\bf C}}")#text(" outside of a closed singular set ")#mi("{S}")#text(". If ")#mi("{z_0 \\in S}")#text(" is an isolated singularity of ")#mi("{f}")#text(", then we have a Laurent expansion")

#align(center)[#tao-fit-display[#mitex("f(z) = \\sum_{n=-\\infty}^\\infty a_n (z-z_0)^n")]]

#text("which is convergent in some punctured disk ")#mi("{D(z_0,r) \\backslash \\{z_0\\}}")#text(". The coefficient ")#mi("{a_{-1}}")#text(" plays a privileged role and is known as the ")#link("https://en.wikipedia.org/wiki/Residue_(complex_analysis)")[#text("residue")]#text(" of ")#mi("{f}")#text(" at ")#mi("{z_0}")#text("; we denote it by ")#mi("{\\mathrm{Res}(f; z_0)}")#text(". Clearly this is quantity is local in the sense that it only depends on the behaviour of ")#mi("{f}")#text(" in a neighbourhood of ")#mi("{z_0}")#text("; in particular, it does not depend on the domain ")#mi("{U}")#text(" so long as ")#mi("{z_0}")#text(" remains inside of that domain. By convention, we also set ")#mi("{\\mathrm{Res}(f;z_0)=0}")#text(" if ")#mi("{f}")#text(" is holomorphic at ")#mi("{z_0}")#text(" (i.e., if ")#mi("{z_0 \\in U \\backslash S}")#text(").")

#text("We then have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 22 (Residue theorem)")]#text(" Let ")#mi("{U \\subset {\\bf C}}")#text(" be a simply connected open set, and let ")#mi("{f: U \\backslash S \\rightarrow {\\bf C}}")#text(" be holomorphic outside of a closed discrete singular set ")#mi("{S}")#text(" (thus all singularities in ")#mi("{S}")#text(" are isolated singularities). Let ")#mi("{\\gamma}")#text(" be a closed curve in ")#mi("{U \\backslash S}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi i} \\int_\\gamma f(z)\\ dz = \\sum_{z_0 \\in S} W_\\gamma(z_0) \\mathrm{Res}(f; z_0),")]]

#text("where only finitely many of the terms on the right-hand side are non-zero.")
]

#emph[#text("Proof:")]#text(" Being simply connected, ")#mi("{\\gamma}")#text(" can be contracted to a point inside ")#mi("{U}")#text(". This homotopy takes values inside some compact subset ")#mi("{K}")#text(" of ")#mi("{U}")#text(", and thus only contains finitely many of the singularities in ")#mi("{S}")#text(". By Rouche’s theorem for winding number (Corollary 44 from ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3), the winding number ")#mi("{W_\\gamma(z_0)}")#text(" then vanishes for any singularity ")#mi("{z_0}")#text(" in ")#mi("{S \\backslash K}")#text(" (since ")#mi("{\\gamma}")#text(" can be contracted to a point without touching ")#mi("{z_0}")#text("). Hence on the right-hand side we may replace ")#mi("{S}")#text(" by ")#mi("{S \\cap K}")#text(" without loss of generality. ")]

#text("Next, we exploit the linearity of the residue theorem in ")#mi("{f}")#text(" to reduce to the case where all the residues ")#mi("{\\mathrm{Res}(f;z_0)}")#text(" vanish. We introduce the rational function ")#mi("{g: {\\bf C} \\backslash (S \\cap K) \\rightarrow {\\bf C}}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("g(z) := \\sum_{z_0 \\in S \\cap K} \\frac{\\mathrm{Res}(f;z_0)}{z-z_0}.")]]

#text("From Laurent expansion around each singularity ")#mi("{z_0}")#text(" we see that ")#mi("{\\mathrm{Res}(g;z_0) = \\mathrm{Res}(f;z_0)}")#text(" for all ")#mi("{z_0 \\in S}")#text(", thus ")#mi("{\\mathrm{Res}(f-g;z_0) = 0}")#text(". Also, from the definition of winding number (see Definition 40 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(") we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi i} \\int_\\gamma g(z)\\ dz = \\sum_{z_0 \\in S \\cap K} W_\\gamma(z_0) \\mathrm{Res}(f; z_0).")]]

#text("Setting ")#mi("{F := f-g}")#text(", it thus suffices to show that")

#metadata(none) <tao-4c3c1a768371ae3329cb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\int_\\gamma F(z)\\ dz = 0.")]]

#text("As ")#mi("{U}")#text(" is simply connected, ")#mi("{\\gamma: [a,b] \\rightarrow U}")#text(" is homotopic in ")#mi("{U}")#text(" (as closed curves) to a point. Let ")#mi("{\\tilde \\gamma: [0,1] \\times [a,b] \\rightarrow K}")#text(" denote the homotopy. We would like to mimic the proof of Cauchy’s theorem (Theorem 4 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(") to conclude ")#link(<tao-4c3c1a768371ae3329cb>)[#text("(9)")]#text(". The difficulty is that the homotopy ")#mi("{\\tilde \\gamma}")#text(" may pass through points ")#mi("{z_0}")#text(" in ")#mi("{S \\cap K}")#text(". However, note from the vanishing of the residue ")#mi("{\\mathrm{Res}(F;z_0)}")#text(" that one has a Laurent expansion of the form")

#align(center)[#tao-fit-display[#mitex("F(z) = \\sum_{n=0}^\\infty a_n (z-z_0)^n + \\sum_{n=-\\infty}^{-2} a_n (z-z_0)^n")]]

#text("for some coefficients ")#mi("{a_n, n \\neq -1}")#text(", in some punctured disk ")#mi("{D(z_0,r) \\backslash \\{z_0\\}}")#text(", with both series being absolutely convergent in this punctured disk. From term by term differentiation (see Theorem 15 of ")#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/")[#text("Notes 1")]#text(") we see that ")#mi("{F}")#text(" has an antiderivative in this punctured disk, namely")

#align(center)[#tao-fit-display[#mitex("G(z) := \\sum_{n=0}^\\infty a_n \\frac{(z-z_0)^{n+1}}{n+1} + \\sum_{n=-\\infty}^{-2} a_n \\frac{(z-z_0)^{n+1}}{n+1}")]]

#text("(note how crucial it is that the ")#mi("{n=-1}")#text(" term is absent in order to form this antiderivative). The absolute convergence of the series on the right-hand side in ")#mi("{D(z_0,r) \\backslash \\{z_0\\}}")#text(" can be seen from the comparison test. From the fundamental theorem of calculus, we thus conclude that ")#mi("{F}")#text(" is conservative on ")#mi("{D(z_0,r) \\backslash \\{z_0\\}}")#text(". Also, for any ")#mi("{z_0 \\in K}")#text(" that is ")#emph[#text("not")]#text(" in ")#mi("{S \\cap K}")#text(", we see from Cauchy’s theorem that ")#mi("{F}")#text(" is conservative on ")#mi("{D(z_0,r)}")#text(" for some radius ")#mi("{r>0}")#text(". Putting this together using a compactness argument, we conclude that there exists a radius ")#mi("{r>0}")#text(", such that for all ")#mi("{z_0}")#text(" in the image of the homotopy ")#mi("{\\tilde \\gamma}")#text(", the function ")#mi("{F}")#text(" is conservative in ")#mi("{D(z_0,r) \\backslash (S \\cap K)}")#text(".")

#text("Now we repeat the proof of Cauchy’s theorem (Theorem 4 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text("), discretising the homotopy ")#mi("{\\tilde \\gamma}")#text(" into short closed polygonal paths ")#mi("{C_{i,j}}")#text(" (each of diameter less than ")#mi("{r}")#text(") around which the integral of ")#mi("{F}")#text(" is zero, to conclude ")#link(<tao-4c3c1a768371ae3329cb>)[#text("(9)")]#text(". The argument is completely analogous, save for the technicality that the paths ")#mi("{C_{i,j}}")#text(" may occasionally pass through one of the points in ")#mi("{S \\cap K}")#text(". But this can be easily rectified by perturbing each of the paths ")#mi("{C_{i,j}}")#text(" by adding a short detour around any point of ")#mi("{S}")#text(" that is passed through; we leave the details to the interested reader. ")#mi("\\Box")

#text("Combining the residue theorem with the Jordan curve theorem, we obtain the following special case, which is already enough for many applications:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 23 (Residue theorem for simple closed curves)")]#text(" Let ")#mi("{\\gamma}")#text(" be a simple closed anticlockwise curve in ")#mi("{{\\bf C}}")#text(". Suppose that ")#mi("{f: U \\backslash S \\rightarrow {\\bf C}}")#text(" is holomorphic on an open set ")#mi("{U}")#text(" containing the image and interior of ")#mi("{\\gamma}")#text(", outside of a closed discrete ")#mi("{S}")#text(" that does not intersect the image of ")#mi("{\\gamma}")#text(". Then we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi i} \\int_\\gamma f(z)\\ dz = \\sum_{z_0 \\in S \\cap \\mathrm{int}(\\gamma)} \\mathrm{Res}(f;z_0).")]]

#text("If ")#mi("{\\gamma}")#text(" is oriented clockwise instead of anticlockwise, then we instead have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi i} \\int_\\gamma f(z)\\ dz = -\\sum_{z_0 \\in S \\cap \\mathrm{int}(\\gamma)} \\mathrm{Res}(f;z_0).")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24 (Homology version of residue theorem)")]#text(" Show that the residue theorem continues to hold when the closed curve ")#mi("{\\gamma}")#text(" is replaced by a ")#mi("{1}")#text("-cycle (as in Exercise 15 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(") that avoids all the singularities in ")#mi("{S}")#text(", and the requirement that ")#mi("{U}")#text(" be simply connected is replaced by the requirement that ")#mi("{U}")#text(" contains all the points ")#mi("{z_0}")#text(" outside of the image of ")#mi("{\\gamma}")#text(" where ")#mi("{W_\\gamma(z_0) \\neq 0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25 (Exterior version of residue theorem)")]#text(" Let ")#mi("{\\gamma}")#text(" be a simple closed anticlockwise curve in ")#mi("{{\\bf C}}")#text(". Suppose that ")#mi("{f: U \\backslash S \\rightarrow {\\bf C}}")#text(" is holomorphic on an open set ")#mi("{U}")#text(" containing the image and ")#emph[#text("exterior")]#text(" of ")#mi("{\\gamma}")#text(", outside of a finite ")#mi("{S}")#text(" that does not intersect the image of ")#mi("{\\gamma}")#text(". Suppose also that ")#mi("{z f(z)}")#text(" converges to a finite limit ")#mi("{c}")#text(" in the limit ")#tao-math("{\\left|z\\right| \\rightarrow \\infty}", block: false)#text(". Show that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi i} \\int_\\gamma f(z)\\ dz = c-\\sum_{z_0 \\in S \\cap \\mathrm{ext}(\\gamma)} \\mathrm{Res}(f;z_0).")]]

#text("If ")#mi("{\\gamma}")#text(" is oriented clockwise instead of anticlockwise, show instead that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi i} \\int_\\gamma f(z)\\ dz = -c+\\sum_{z_0 \\in S \\cap \\mathrm{ext}(\\gamma)} \\mathrm{Res}(f;z_0).")]]
]

#text("In order to use the residue theorem effectively, one of course needs some tools to compute the residue at a given point. The Fourier inversion formula ")#link(<tao-04efaf080f5a3e74e1c2>)[#text("(5)")]#text(" expresses such residues as a contour integral, but this is not so useful in practice as often the best way to compute such integrals is via the residue theorem, leaving one back where one started! But if the singularity is not an essential one, we have some useful formulae:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" Let ")#mi("{f: U \\backslash S \\rightarrow {\\bf C}}")#text(" be holomorphic on an open set ")#mi("{U}")#text(" outside of a closed singular set ")#mi("{S}")#text(", and let ")#mi("{z_0}")#text(" be an isolated point of ")#mi("{S}")#text(".")

#list(
[#text("(i) If ")#mi("{f}")#text(" has a removable singularity at ")#mi("{z_0}")#text(", show that ")#mi("{\\mathrm{Res}(f;z_0)=0}")#text(".")],
[#text("(ii) If ")#mi("{f}")#text(" has a simple pole at ")#mi("{z_0}")#text(", show that ")#mi("{\\mathrm{Res}(f;z_0)=\\lim_{z \\rightarrow z_0; z \\in U \\backslash S} f(z) (z-z_0)}")#text(".")],
[#text("(iii) If ")#mi("{f}")#text(" has a pole of order at most ")#mi("{m}")#text(" at ")#mi("{z_0}")#text(" for some ")#mi("{m \\geq 1}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Res}(f;z_0)= \\frac{1}{(m-1)!} \\lim_{z \\rightarrow z_0; z \\in U \\backslash S} \\frac{d^{m-1}}{dz^{m-1}} (f(z) (z-z_0)^m).")]]

#text("In particular, if ")#mi("{f(z) = g(z)/(z-z_0)^m}")#text(" near ")#mi("{z_0}")#text(" for some ")#mi("{g}")#text(" that is holomorphic at ")#mi("{z_0}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Res}(f;z_0)= \\frac{1}{(m-1)!} \\frac{d^{m-1}}{dz^{m-1}} g(z_0).")]]]
)

#text("Using these facts, show that Cauchy’s theorem (Theorem 14 from ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text("), the Cauchy integral formula (Theorem 39 from ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text("), and the higher order Cauchy integral formula (Exercise 42 from ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(") can be derived from the residue theorem. (Of course, this is not an independent proof of these theorems, as they were used in the ")#emph[#text("proof")]#text(" of the residue theorem!)")
]

#text("The residue theorem can be applied in countless ways; we give only a small sample of them below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" Use the residue theorem to give an alternate proof of the fundamental theorem of algebra, by considering the integral ")#mi("{\\int_{\\gamma_{0,R,\\circlearrowleft}} \\frac{z^{n-1}}{P(z)}\\ dz}")#text(" for a polynomial ")#mi("{P}")#text(" of degree ")#mi("{n}")#text(" and some large radius ")#mi("{R}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" Let ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" be a ")#link("https://www.encyclopediaofmath.org/index.php/Dirichlet_polynomial")[#text("Dirichlet polynomial")]#text(" of the form")

#align(center)[#tao-fit-display[#mitex("f(s) := \\sum_{n=1}^\\infty \\frac{a_n}{n^s}")]]

#text("for some sequence ")#mi("{a_1,a_2,\\dots}")#text(" of complex numbers, with only finitely many of the ")#mi("{a_n}")#text(" non-zero. Establish ")#link("https://en.wikipedia.org/wiki/Perron%27s_formula")[#text("Perron’s formula")]

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} a_n = \\lim_{T \\rightarrow +\\infty} \\frac{1}{2\\pi i} \\int_{\\gamma_{c-iT \\rightarrow c+iT}} f(s) \\frac{x^s}{s}\\ ds")]]

#text("for any real numbers ")#mi("{x,c>0}")#text(" with ")#mi("{x}")#text(" not an integer. What happens if ")#mi("{x}")#text(" is an integer? Generalisations and variants of this formula, particularly with the Dirichlet polynomial replaced by more general ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/dirichlet series")[#text("Dirichlet series")]#text(" in which infinitely many of the ")#mi("{a_n}")#text(" are allowed to be non-zero, are of particular use in analytic number theory; see for instance ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("this previous blog post")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29 (Spectral theorem for matrices)")]#text(" This exercise presumes some familiarity with linear algebra. Let ")#mi("{n}")#text(" be a positive integer, and let ")#mi("{M_n({\\bf C})}")#text(" denote the ring of ")#mi("{n \\times n}")#text(" complex matrices. Let ")#mi("{A}")#text(" be a matrix in ")#mi("{M_n({\\bf C})}")#text(". The ")#link("https://en.wikipedia.org/wiki/Characteristic_polynomial")[#text("characteristic polynomial")]#text(" ")#mi("{\\Delta(z) := \\mathrm{det}(A - zI)}")#text(", where ")#mi("{I}")#text(" is the ")#mi("{n \\times n}")#text(" identity matrix, is a polynomial of degree ")#mi("{n}")#text(" in ")#mi("{z}")#text(" with leading coefficient ")#mi("{(-1)^n}")#text("; we let ")#mi("{z_1,\\dots,z_k}")#text(" be the distinct zeroes of this polynomial, and let ")#mi("{d_1,\\dots,d_k}")#text(" be the multiplicities; thus by the fundamental theorem of algebra we have")

#align(center)[#tao-fit-display[#mitex("\\mathrm{det}(A-zI) = (-1)^n (z-z_1)^{d_1} \\dots (z-z_k)^{d_k}.")]]

#text("We refer to the set ")#mi("{\\{z_1,\\dots,z_k\\}}")#text(" as the ")#link("https://en.wikipedia.org/wiki/Spectrum_of_a_matrix")[#text("spectrum")]#text(" of ")#mi("{A}")#text(". Let ")#mi("{\\gamma}")#text(" be any closed anticlockwise curve that contains the spectrum of ")#mi("{A}")#text(" in its interior, and let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(" that contains ")#mi("{\\gamma}")#text(" and its interior.")

#list(
[#text("(i) Show that the ")#link("https://en.wikipedia.org/wiki/Resolvent_formalism")[#text("resolvent")]#text(" ")#mi("{(A-zI)^{-1}}")#text(" is a meromorphic function on ")#mi("{{\\bf C}}")#text(" with poles at the spectrum of ")#mi("{A}")#text(", where we call a matrix-valued function meromorphic if each of its ")#mi("{n^2}")#text(" components are meromorphic. (")#emph[#text("Hint:")]#text(" use the ")#link("https://en.wikipedia.org/wiki/Adjugate_matrix")[#text("adjugate matrix")]#text(".)")],
[#text("(ii) For any holomorphic ")#mi("{f: U \\rightarrow {\\bf C}}")#text(", we define the matrix ")#mi("{f(A) := M_n({\\bf C})}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("f(A) := -\\frac{1}{2\\pi i} \\int_\\gamma f(z) (A-zI)^{-1}\\ dz")]]

#text("(cf. the Cauchy integral formula). We refer to ")#mi("{f(A)}")#text(" as the ")#link("https://en.wikipedia.org/wiki/Holomorphic_functional_calculus")[#text("holomorphic functional calculus")]#text(" for ")#mi("{A}")#text(" applied to ")#mi("{f}")#text(". Show that the matrix ")#mi("{f(A)}")#text(" does not depend on the choice of ")#mi("{\\gamma}")#text(", depends linearly on ")#mi("{f}")#text(", and equals the identity matrix when ")#mi("{f}")#text(" is the constant function ")#mi("{1}")#text(". Furthermore, if ")#mi("{g: U \\rightarrow {\\bf C}}")#text(" is the function ")#mi("{g(z) := z f(z)}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("g(A) = A f(A) = f(A) A.")]]

#text("Conclude in particular that if ")#mi("{P}")#text(" is a polynomial")

#align(center)[#tao-fit-display[#mitex("P(z) = a_m z^m + \\dots + a_1 z + a_0")]]

#text("with complex coefficients ")#mi("{a_0,\\dots,a_m \\in {\\bf C}}")#text(", then the function ")#mi("{P(A)}")#text(" (as defined by the holomorphic functional calculus) matches how one would define ")#mi("{P(A)}")#text(" algebraically, in the sense that")

#align(center)[#tao-fit-display[#mitex("P(A) = a_m A^m + \\dots + a_1 A + a_0 I.")]]],
[#text("(iii) Prove the Cayley-Hamilton theorem ")#mi("{\\Delta(A)=0}")#text(". (Note from (ii) that it does not matter whether one interprets ")#mi("{\\Delta(A)}")#text(" algebraically, or via the holomorphic functional calculus.)")],
[#text("(iv) If ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" is holomorphic, show that the matrix-valued function ")#mi("{z \\mapsto (f(A)-f(z)) (A-zI)^{-1}}")#text(" has only removable singularities in ")#mi("{U}")#text(".")],
[#text("(v) If ")#mi("{f,g: U \\rightarrow {\\bf C}}")#text(" are holomorphic, establish the identity")

#align(center)[#tao-fit-display[#mitex("(fg)(A) = f(A) g(A).")]]],
[#text("(vi) Show that there exist matrices ")#mi("{P_1,\\dots,P_k \\in M_n({\\bf C})}")#text(" that are idempotent (thus ")#mi("{P_j^2=P_j}")#text(" for all ")#mi("{j=1,\\dots,k}")#text("), commute with each other and with ")#mi("{A}")#text(", sum to the identity (thus ")#mi("{P_1+\\dots+P_k = I}")#text("), annihilate each other (thus ")#mi("{P_j P_{j^{\\prime}} = 0}")#text(" for all distinct ")#mi("{j,j^{\\prime} = 1,\\dots,k}")#text(") and are such that for each ")#mi("{j=1,\\dots,k}")#text(", one has the nilpotency property")

#align(center)[#tao-fit-display[#mitex("(P_j (A - z_j I) P_j)^{d_j} = 0.")]]

#text("In particular, we have the ")#emph[#text("spectral decomposition")]

#align(center)[#tao-fit-display[#mitex("A = \\sum_{j=1}^k P_j (z_j I + N_j) P_j")]]

#text("where each ")#mi("{N_j}")#text(" is a nilpotent matrix with ")#mi("{N_j^{d_j} = 0}")#text(". Finally, show that the range of ")#mi("{P_j}")#text(" (viewed as a linear operator from ")#mi("{{\\bf C}^n}")#text(" to itself) has dimension ")#mi("{d_j}")#text(". Find a way to interpret each ")#mi("{P_j}")#text(" as the (negative of the) “residue” of the resolvent operator ")#mi("{(A-zI)^{-1}}")#text(" at ")#mi("{z_j}")#text(".")]
)
]

#text("Under some additional hypotheses, it is possible to extend the analysis in the above exercise to infinite-dimensional matrices or other linear operators, but we will not do so here.")

#heading(level: 1)[#strong[#text(" — 3. The argument principle — ")]]

#text("We have not yet defined the complex logarithm ")#mi("{\\log z}")#text(" of a complex number ")#mi("{z}")#text(", but one of the properties we would expect of this logarithm is that its derivative should be the reciprocal function: ")#mi("{\\frac{d}{dz} \\log z = \\frac{1}{z}}")#text(". In particular, by the chain rule we would expect the formula ")#metadata(none) <tao-07397d633f25a7101990>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\frac{d}{dz} \\log f(z) = \\frac{f^{\\prime}(z)}{f(z)}")]]

#text(" ")#text(" for a holomorphic function ")#mi("{f}")#text(", at least away from the zeroes of ")#mi("{f}")#text(". Inspired by this formal calculation, we refer to the function ")#mi("{\\frac{f^{\\prime}(z)}{f(z)}}")#text(" as the ")#link("https://en.wikipedia.org/wiki/Logarithmic_derivative")[#text("log-derivative")]#text(" of ")#mi("{f}")#text(". Observe the product rule and quotient rule, when applied to complex differentiable functions ")#mi("{f,g}")#text(" that are non-zero at some point ")#mi("{z}")#text(", gives the formulae")

#metadata(none) <tao-7e9e5ac30f2216fd0fd6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\frac{(fg)^{\\prime}(z)}{(fg)(z)} = \\frac{f^{\\prime}(z)}{f(z)} + \\frac{g^{\\prime}(z)}{g(z)}")]]

#text("and")

#metadata(none) <tao-ddc6e2b224d0fd821669>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\frac{(f/g)^{\\prime}(z)}{(f/g)(z)} = \\frac{f^{\\prime}(z)}{f(z)} - \\frac{g^{\\prime}(z)}{g(z)}")]]

#text("which are of course consistent with the formal calculation ")#link(<tao-07397d633f25a7101990>)[#text("(10)")]#text(", given how we expect the logarithm to act on products and quotients. Thus, for instance, if ")#mi("{P}")#text(", ")#mi("{Q}")#text(" are polynomials that are factored as")

#align(center)[#tao-fit-display[#mitex("P(z) = a (z-z_1)^{d_1} \\dots (z-z_k)^{d_k}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("Q(z) = b (z-w_1)^{e_1} \\dots (z-w_l)^{e_l}")]]

#text("for some non-zero complex numbers ")#mi("{a,b}")#text(", distinct complex numbers ")#mi("{z_1,\\dots,z_k,w_1,\\dots,w_l}")#text(", and positive integers ")#mi("{d_1,\\dots,d_k,e_1,\\dots,e_l}")#text(", then the log-derivative of the rational function ")#mi("{P/Q}")#text(" is given by")

#align(center)[#tao-fit-display[#mitex("\\frac{(P/Q)^{\\prime}(z)}{(P/Q)(z)} = \\frac{d_1}{z-z_1} + \\dots + \\frac{d_k}{z-z_k} - \\frac{e_1}{z-w_1} - \\dots - \\frac{e_l}{z-w_l}.")]]

#text("In particular, the log-derivative of ")#mi("{P/Q}")#text(" is meromorphic with poles at ")#mi("{z_1,\\dots,z_k, w_1,\\dots,w_l}")#text(", with a residue of ")#mi("{+d_j}")#text(" at each zero ")#mi("{z_j}")#text(" of ")#mi("{P/Q}")#text(", and a residue of ")#mi("{-e_j}")#text(" at each pole ")#mi("{w_j}")#text(" of ")#mi("{P/Q}")#text(".")

#text("A general rule of thumb in complex analysis is that holomorphic functions behave like generalisations of polynomials, and meromorphic functions behave like generalisations of rational functions. In view of this rule of thumb and the above calculation, the following lemma should thus not be surprising:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 30")]#text(" ")#metadata(none) <tao-f464d7d71c06e47a535c>#text(" Let ")#mi("{f: U \\backslash S \\rightarrow {\\bf C}}")#text(" be a holomorphic function on an open set ")#mi("{U \\subset {\\bf C}}")#text(" outside of a closed singular set ")#mi("{S}")#text(", and let ")#mi("{z_0}")#text(" be either an element of ")#mi("{U \\backslash S}")#text(" or an isolated point of ")#mi("{S}")#text(".")

#list(
[#text("(i) If ")#mi("{f}")#text(" is holomorphic and non-zero at ")#mi("{z_0}")#text(", then the log-derivative ")#mi("{\\frac{f^{\\prime}(z)}{f(z)}}")#text(" is also holomorphic at ")#mi("{z_0}")#text(".")],
[#text("(ii) If ")#mi("{f}")#text(" is holomorphic at ")#mi("{z_0}")#text(" with a zero of order ")#mi("{m \\geq 1}")#text(", then the log-derivative ")#mi("{\\frac{f^{\\prime}(z)}{f(z)}}")#text(" has a simple pole at ")#mi("{z_0}")#text(" with residue ")#mi("{m}")#text(".")],
[#text("(iii) If ")#mi("{f}")#text(" has a removable singularity at ")#mi("{z_0}")#text(", and is non-zero once the singularity is removed, then the log-derivative ")#mi("{\\frac{f^{\\prime}(z)}{f(z)}}")#text(" has a removable singularity at ")#mi("{z_0}")#text(".")],
[#text("(iv) If ")#mi("{f}")#text(" has a removable singularity at ")#mi("{z_0}")#text(", and has a zero of order ")#mi("{m \\geq 1}")#text(" once the singularity is removed, then the log-derivative ")#mi("{\\frac{f^{\\prime}(z)}{f(z)}}")#text(" has a simple pole at ")#mi("{z_0}")#text(" with residue ")#mi("{m}")#text(".")],
[#text("(v) If ")#mi("{f}")#text(" has a pole of order ")#mi("{m\\geq 1}")#text(" at ")#mi("{z_0}")#text(", then the log-derivative ")#mi("{\\frac{f^{\\prime}(z)}{f(z)}}")#text(" has a simple pole at ")#mi("{z_0}")#text(" with residue ")#mi("{-m}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" The claim (i) is obvious. For (ii), we use Taylor expansion to factor ")#mi("{f(z) = (z-z_0)^m g(z)}")#text(" for some ")#mi("{g}")#text(" holomorphic and non-zero near ")#mi("{z_0}")#text(", and then from ")#link(<tao-7e9e5ac30f2216fd0fd6>)[#text("(11)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\frac{f^{\\prime}(z)}{f(z)} = \\frac{g^{\\prime}(z)}{g(z)} + \\frac{m}{z-z_0}.")]]

#text("Since ")#mi("{\\frac{g^{\\prime}}{g}}")#text(" is holomorphic at ")#mi("{z_0}")#text(", the claim (ii) follows. The claim (v) is proven similarly using a factorisation ")#mi("{f(z) = g(z) / (z-z_0)^m}")#text(", and using ")#link(<tao-ddc6e2b224d0fd821669>)[#text("(12)")]#text(" in place of ")#link(<tao-7e9e5ac30f2216fd0fd6>)[#text("(11)")]#text(". The claims (iii), (iv) then follow from (i), (ii) respectively after removing the singularity. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 31")]#text(" Note that the lemma does not cover all possible singularity and zero scenarios. For instance, ")#mi("{f}")#text(" could be identically zero, in which case the log-derivative is nowhere defined. If ")#mi("{f}")#text(" has an essential singularity then the log-derivative can be a pole (as seen for instance by the example ")#mi("{f(z) = \\exp( 1 / z^m )}")#text(" for some ")#mi("{m \\geq 1}")#text(") or another essential singularity (as can be seen for instance by the example ")#mi("{f(z) = \\exp(\\exp(1/z))}")#text("). Finally, if ")#mi("{f}")#text(" has a non-isolated singularity, then the log-derivative could exhibit a wide range of behaviour (but probably will be quite wild as one approaches the singular set).")
]

#text("By combining the above lemma with the residue theorem, we obtain the ")#link("https://en.wikipedia.org/wiki/Argument_principle")[#text("argument principle")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 32 (Argument principle)")]#text(" ")#metadata(none) <tao-3df61483d1c4183b4446>#text(" Let ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" be a simple closed anticlockwise curve. Let ")#mi("{U}")#text(" be an open set containing ")#mi("{\\gamma}")#text(" and its interior. Let ")#mi("{f}")#text(" be a meromorphic function on ")#mi("{U}")#text(" that is holomorphic and non-zero on the image of ")#mi("{\\gamma}")#text(". Suppose that after removing all the removable singularities of ")#mi("{f}")#text(", ")#mi("{f}")#text(" has zeroes ")#mi("{z_1,\\dots,z_k}")#text(" in the interior of ")#mi("{\\gamma}")#text(" (of orders ")#mi("{d_1,\\dots,d_k}")#text(" respectively), and poles ")#mi("{w_1,\\dots,w_l}")#text(" in the interior of ")#mi("{\\gamma}")#text(" (of orders ")#mi("{e_1,\\dots,e_l}")#text(" respectively). (")#mi("{f}")#text(" is also allowed to have zeroes and poles in the exterior of ")#mi("{\\gamma}")#text(".) Then we have")

#metadata(none) <tao-b25f03dedd69be07f356>

#tao-aligned(keep: true)[


#tao-math("\\sum_{j=1}^k d_j - \\sum_{j=1}^l e_j  & = \\frac{1}{2\\pi i} \\int_\\gamma \\frac{f^{\\prime}(z)}{f(z)}\\ dz", block: true, numbering: n => [#text("(13)")])



#tao-math(" & = W_{f \\circ \\gamma}(0)", block: true)
]

#text("where ")#mi("{f \\circ \\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" is the closed curve ")#mi("{t \\mapsto f(\\gamma(t))}")#text(".")
]

#emph[#text("Proof:")]#text(" The first equality of ")#link(<tao-b25f03dedd69be07f356>)[#text("(13)")]#text(" follows from the residue theorem and Lemma ")#link(<tao-f464d7d71c06e47a535c>)[#text("30")]#text(". From the change of variables formula (Exercise 17(ix) of ")#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/")[#text("Notes 2")]#text(") we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi i} \\int_\\gamma \\frac{f^{\\prime}(z)}{f(z)}\\ dz = \\frac{1}{2\\pi i} \\int_{f \\circ \\gamma} \\frac{1}{z}\\ dz")]]

#text("and the second identity also follows. ")#mi("\\Box")

#text("We isolate the special case of the argument principle when there are no poles for special mention:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 33 (Special case of argument principle)")]#text(" ")#metadata(none) <tao-94e3f4c6633c15d0fc25>#text(" Let ")#mi("{\\gamma}")#text(" be a simple closed anticlockwise curve, let ")#mi("{U}")#text(" be an open set containing the image of ")#mi("{\\gamma}")#text(" and its interior, and let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be holomorphic. Suppose that ")#mi("{f}")#text(" has no zeroes on the image of ")#mi("{\\gamma}")#text(". Then the number of zeroes of ")#mi("{f}")#text(" (counting multiplicity) in the interior of ")#mi("{\\gamma}")#text(" is equal to the winding number ")#mi("{W_{f \\circ \\gamma}(0)}")#text(" of ")#mi("{f \\circ \\gamma}")#text(" around the origin.")
]

#text("Recalling that the winding number is a homotopy invariant (Lemma 43 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text("), we conclude that the number of zeroes of a holomorphic function ")#mi("{f}")#text(" in the interior of a simple closed anticlockwise curve is also invariant with respect to continuous perturbations, so long as zeroes never cross the curve itself. More precisely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 34 (Stability of number of zeroes)")]#text(" ")#metadata(none) <tao-289a9c9cffb746ba9e0b>#text(" Let ")#mi("{U}")#text(" be an open set. Let ")#mi("{\\gamma_0: [a,b] \\rightarrow U}")#text(", ")#mi("{\\gamma_1: [a,b] \\rightarrow U}")#text(" be simple closed anticlockwise curves that are homotopic as closed curves via some homotopy ")#mi("{\\gamma: [0,1] \\times [a,b] \\rightarrow U}")#text("; suppose also that ")#mi("{U}")#text(" contains the interiors of ")#mi("{\\gamma_0}")#text(" and ")#mi("{\\gamma_1}")#text(". Let ")#mi("{f_0, f_1: U \\rightarrow {\\bf C}}")#text(" be holomorphic, and let ")#mi("{f: [0,1] \\times U \\rightarrow {\\bf C}}")#text(" be a continuous function such that ")#mi("{f(0,z) = f_0(z)}")#text(" and ")#mi("{f(1,z) = f_1(z)}")#text(" for all ")#mi("{z \\in U}")#text(". Suppose that ")#mi("{f(s,\\gamma(s,t)) \\neq 0}")#text(" for all ")#mi("{s \\in [0,1]}")#text(" and ")#mi("{t \\in [a,b]}")#text(" (i.e., at time ")#mi("{s}")#text(", the curve ")#mi("{\\gamma(s,\\cdot)}")#text(" never encounters any zeroes of ")#mi("{f(s,\\cdot)}")#text("). Then the number of zeroes (counting multiplicity) of ")#mi("{f_0}")#text(" in the interior of ")#mi("{\\gamma_0}")#text(" equals the number of zeroes of ")#mi("{f_1}")#text(" in the interior of ")#mi("{\\gamma_1}")#text(" (counting multiplicity).")
]

#emph[#text("Proof:")]#text(" By Corollary ")#link(<tao-94e3f4c6633c15d0fc25>)[#text("33")]#text(", it suffices to show that")

#align(center)[#tao-fit-display[#mitex("W_{f_0 \\circ \\gamma_0}(0) = W_{f_1 \\circ \\gamma_1}(0).")]]

#text("But the curves ")#mi("{f_0 \\circ \\gamma_0: [a,b] \\rightarrow {\\bf C} \\backslash \\{0\\}}")#text(" and ")#mi("{f_1 \\circ \\gamma_1: [a,b] \\rightarrow {\\bf C} \\backslash \\{0\\}}")#text(" are homotopic as closed curves in ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(", using the homotopy ")#mi("{F: [0,1] \\times [a,b] \\rightarrow {\\bf C} \\backslash \\{0\\}}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("F( s, t ):= f(s,\\gamma(s,t))")]]

#text("(note that this avoids the origin by hypothesis). The claim then follows from Lemma 43 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(". ")#mi("\\Box")

#text("Informally, the above corollary asserts that zeroes of holomorphic functions cannot be created or destroyed, as long as they are confined within a closed curve.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 35")]#text(" Let ")#mi("{\\gamma}")#text(" be the unit circle ")#mi("{\\gamma = \\gamma_{0,1,\\circlearrowleft}}")#text(". The polynomial ")#mi("{f_0(z) := z^2}")#text(" has a double zero at ")#mi("{0}")#text(", so (counting multiplicity) has two zeroes in the interior of ")#mi("{\\gamma}")#text(". If we consider instead the perturbation ")#mi("{f_\\varepsilon(z) = z^2 + \\varepsilon}")#text(" for some ")#mi("{\\varepsilon>0}")#text(", this has simple zeroes at ")#mi("{+i\\sqrt{\\varepsilon}}")#text(" and ")#mi("{-i\\sqrt{\\varepsilon}}")#text(" respectively, so as long as ")#mi("{\\varepsilon<1}")#text(", the holomorphic function ")#mi("{f_\\varepsilon}")#text(" also has two zeroes in the interior of ")#mi("{\\gamma}")#text("; but as ")#mi("{\\varepsilon}")#text(" crosses ")#mi("{1}")#text(", the zeroes of ")#mi("{f_\\varepsilon}")#text(" pass through ")#mi("{\\gamma}")#text(", and one no longer has any zeroes of ")#mi("{f_\\varepsilon}")#text(" in the interior of ")#mi("{\\gamma}")#text(". The situation can be contrasted with the real case: the function ")#mi("{x \\mapsto x^2+\\varepsilon}")#text(" has a double zero at the origin when ")#mi("{\\varepsilon=0}")#text(", but as soon as ")#mi("{\\varepsilon}")#text(" becomes positive, the zeroes immediately disappear from the real line. Note that the stability of zeroes fails if we do not count zeroes with multiplicity; thus, as a general rule of thumb, one should always try to count zeroes with multiplicity when doing complex analysis. (Heuristically, one can think of a zero of order ")#mi("{m}")#text(" as ")#mi("{m}")#text(" simple zeroes that are “infinitesimally close together”.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 36")]#text(" When one considers meromorphic functions instead of holomorphic ones, then the number of zeroes inside a region need not be stable any more, but the number of zeroes ")#emph[#text("minus")]#text(" the number of poles will be stable. Consider for instance the meromorphic function ")#mi("{f_0(z) = \\frac{z^2}{z^2}}")#text(", which has a removable singularity at ")#mi("{0}")#text(" but no zeroes or poles. If we perturb it to ")#mi("{f_\\varepsilon(z) := \\frac{z^2+\\varepsilon}{z^2}}")#text(" for some ")#mi("{\\varepsilon>0}")#text(", then we suddenly have a double pole at ")#mi("{0}")#text(", but this is balanced by two simple zeroes at ")#mi("{+i\\sqrt{\\varepsilon}}")#text(" and ")#mi("{-i\\sqrt{\\varepsilon}}")#text("; in the limit as ")#mi("{\\varepsilon \\rightarrow 0}")#text(" we see that the two zeroes “collide” with the double pole, annihilating both the zeroes and the poles.")
]

#text("A particularly useful special case of the stability of zeroes is ")#link("https://en.wikipedia.org/wiki/Rouch%C3%A9%27s_theorem")[#text("Rouche’s theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 37 (Rouche’s theorem)")]#text(" Let ")#mi("{\\gamma}")#text(" be a simple closed curve, and let ")#mi("{U}")#text(" be an open set containing the image of ")#mi("{\\gamma}")#text(" and its interior. Let ")#mi("{f, g: U \\rightarrow {\\bf C}}")#text(" be holomorphic. If one has ")#tao-math("{\\left|g(z)\\right| < \\left|f(z)\\right|}", block: false)#text(" for all ")#mi("{z}")#text(" in the image of ")#mi("{\\gamma}")#text(", then ")#mi("{f}")#text(" and ")#mi("{f+g}")#text(" have the same number of zeroes (counting multiplicity) in the interior of ")#mi("{\\gamma}")#text(".")
]

#emph[#text("Proof:")]#text(" We may assume without loss of generality that ")#mi("{\\gamma}")#text(" is anticlockwise. By hypothesis, ")#mi("{f}")#text(" and ")#mi("{f+g}")#text(" cannot have zeroes on the image of ")#mi("{\\gamma}")#text(". The claim then follows from Corollary ")#link(<tao-289a9c9cffb746ba9e0b>)[#text("34")]#text(" with ")#mi("{\\gamma_0=\\gamma_1=\\gamma}")#text(", ")#mi("{\\gamma(s,t) := \\gamma(t)}")#text(", ")#mi("{f_0(z) := f(z)}")#text(", ")#mi("{f_1(z) := f(z) + g(z)}")#text(", and ")#mi("{f(s,z) := f(z) + s g(z)}")#text(". ")#mi("\\Box")

#text("Rouche’s theorem has many consequences for complex analysis. One basic consequence is the ")#link("https://en.wikipedia.org/wiki/Open_mapping_theorem_(complex_analysis)")[#text("open mapping theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 38 (Open mapping theorem)")]#text(" ")#metadata(none) <tao-6e839d21bedb0ea901a8>#text(" Let ")#mi("{U}")#text(" be an open connected non-empty subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be holomorphic and not constant. Then ")#mi("{f(U)}")#text(" is also open.")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{z_0 \\in U}")#text(". As ")#mi("{f}")#text(" is not constant, the zeroes of ")#mi("{f(z)-f(z_0)}")#text(" are isolated (Corollary 26 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text("). Thus, for ")#mi("{r}")#text(" sufficiently small, ")#mi("{f(z)-f(z_0)}")#text(" is nonvanishing on the image of the circle ")#mi("{\\gamma_{z_0,r,\\circlearrowleft}}")#text(". Clearly ")#mi("{f(z)-f(z_0)}")#text(" has at least one zero in the interior of this circle. Thus, by Rouche’s theorem, if ")#mi("{w}")#text(" is sufficiently close to ")#mi("{f(z_0)}")#text(", then ")#mi("{f(z)-w}")#text(" will also have at least one zero in the interior of this circle. In particular, ")#mi("{f(U)}")#text(" contains a neighbourhood of ")#mi("{f(z_0)}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39")]#text(" Use Rouche’s theorem to obtain another proof of the fundamental theorem of algebra, by showing that a polynomial ")#mi("{P(z) = a_n z^n + \\dots + a_0}")#text(" with ")#mi("{a_n \\neq 0}")#text(" and ")#mi("{n \\geq 1}")#text(" has exactly ")#mi("{n}")#text(" zeroes (counting multiplicity) in the complex plane. (")#emph[#text("Hint:")]#text(" compare ")#mi("{P(z)}")#text(" with ")#mi("{a_n z^n}")#text(" inside some large circle ")#mi("{\\gamma_{0,R,\\circlearrowleft}}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 40 (Inverse function theorem)")]#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", let ")#mi("{z_0 \\in U}")#text(", and let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a holomorphic function such that ")#mi("{f^{\\prime}(z_0) \\neq 0}")#text(". Show that there exists a neighbourhood ")#mi("{V}")#text(" of ")#mi("{z_0}")#text(" in ")#mi("{U}")#text(" such that the map ")#mi("{f: V \\rightarrow f(V)}")#text(" is a complex ")#link("https://en.wikipedia.org/wiki/Diffeomorphism")[#text("diffeomorphism")]#text("; that is to say, it is holomorphic, invertible, and the inverse is also holomorphic. Finally, show that")

#align(center)[#tao-fit-display[#mitex("(f^{-1})^{\\prime}(w) = \\frac{1}{f^{\\prime}(f^{-1}(w))}")]]

#text("for all ")#mi("{w \\in f(V)}")#text(". (")#emph[#text("Hint:")]#text(" one can either mimic the real-variable proof of the ")#link("https://en.wikipedia.org/wiki/Inverse_function_theorem")[#text("inverse function theorem")]#text(" using the ")#link("https://en.wikipedia.org/wiki/Banach_fixed-point_theorem")[#text("contraction mapping theorem")]#text(", or one can use Rouche’s theorem and the open mapping theorem to construct the inverse.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 41")]#text(" ")#metadata(none) <tao-a175190e28d8d2c70803>#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", and ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a map. Show that the following are equivalent:")

#list(
[#text("(i) ")#mi("{f}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Local_diffeomorphism")[#text("local complex diffeomorphism")]#text(". That is to say, for every ")#mi("{z_0 \\in U}")#text(" there is a neighbourhood ")#mi("{V}")#text(" of ")#mi("{z_0}")#text(" in ")#mi("{U}")#text(" such that ")#mi("{f(V)}")#text(" is open and ")#mi("{f: V \\rightarrow f(V)}")#text(" is a complex diffeomorphism (as defined in the preceding exercise).")],
[#text("(ii) ")#mi("{f}")#text(" is holomorphic on ")#mi("{U}")#text(" and is a ")#link("https://en.wikipedia.org/wiki/Local_homeomorphism")[#text("local homeomorphism")]#text(". That is to say, for every ")#mi("{z_0 \\in U}")#text(" there is a neighbourhood ")#mi("{V}")#text(" of ")#mi("{z_0}")#text(" in ")#mi("{U}")#text(" such that ")#mi("{f(V)}")#text(" is open and ")#mi("{f: V \\rightarrow f(V)}")#text(" is a homeomorphism.")],
[#text("(iii) ")#mi("{f}")#text(" is holomorphic on ")#mi("{U}")#text(" and is locally injective. That is to say, for every ")#mi("{z_0 \\in U}")#text(" there is a neighbourhood ")#mi("{V}")#text(" of ")#mi("{z_0}")#text(" in ")#mi("{U}")#text(" such that ")#mi("{f: V \\rightarrow f(V)}")#text(" is injective.")],
[#text("(iv) ")#mi("{f}")#text(" is holomorphic on ")#mi("{U}")#text(", and the derivative ")#mi("{f^{\\prime}}")#text(" is nowhere vanishing.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42 (Hurwitz’s theorem)")]#text(" Let ")#mi("{U}")#text(" be an open connected non-empty subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{f_n: U \\rightarrow {\\bf C}}")#text(" be a sequence of holomorphic functions that converge uniformly on compact sets to a limit ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" (which is then necessarily also holomorphic, thanks to Theorem 36 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text("). Prove the following two versions of ")#link("https://en.wikipedia.org/wiki/Hurwitz%27s_theorem_(complex_analysis)")[#text("Hurwitz’s theorem")]#text(":")

#list(
[#text("(i) If none of the ")#mi("{f_n}")#text(" have any zeroes in ")#mi("{U}")#text(", show that either ")#mi("{f}")#text(" also has no zeroes in ")#mi("{U}")#text(", or is identically zero.")],
[#text("(ii) If all of the ")#mi("{f_n}")#text(" are univalent (that is to say, they are ")#emph[#text("injective")]#text(" holomorphic functions), show that either ")#mi("{f}")#text(" is also univalent, or is constant.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 43 (Bloch’s theorem)")]#text(" ")#metadata(none) <tao-5f392985a1297212e668>#text(" The purpose of this exercise is to establish a more quantitative variant of the open mapping theorem, due to Bloch; this will be useful later in this notes for proving the Picard and Montel theorems. Let ")#mi("{f: D(z_0,R) \\rightarrow {\\bf C}}")#text(" be a holomorphic function on a disk ")#mi("{D(z_0,R)}")#text(", and suppose that ")#mi("{f^{\\prime}(z_0)}")#text(" is non-zero")

#list(
[#text("(i) Suppose that ")#tao-math("{\\left|f^{\\prime}(z)\\right| \\leq 2 \\left|f^{\\prime}(z_0)\\right|}", block: false)#text(" for all ")#mi("{z \\in D(z_0,R)}")#text(". Show that there is an absolute constant ")#mi("{c>0}")#text(" such that ")#mi("{f(D(z_0,R))}")#text(" contains the disk ")#mi("{D(f(z_0), c|f^{\\prime}(z_0)| R)}")#text(". (")#emph[#text("Hint:")]#text(" one can normalise ")#mi("{z_0=0}")#text(", ")#mi("{R=1}")#text(", ")#mi("{f^{\\prime}(z_0)=1}")#text(". Use the higher order Cauchy integral formula to get some bound on ")#mi("{f^{\\prime\\prime}(z)}")#text(" for ")#mi("{z}")#text(" near the origin, and use this to approximate ")#mi("{f}")#text(" by ")#mi("{z}")#text(" near the origin. Then apply Rouche’s theorem.)")],
[#text("(ii) Without the hypothesis in (i), show that there is an absolute constant ")#mi("{c^{\\prime}>0}")#text(" such that ")#mi("{f(D(z_0,R))}")#text(" contains a disk of radius ")#mi("{c^{\\prime} |f^{\\prime}(z_0)| R}")#text(". (")#emph[#text("Hint:")]#text(" if one has ")#tao-math("{\\left|f^{\\prime}(z)\\right| \\leq 2 \\left|f^{\\prime}(z_0)\\right|}", block: false)#text(" for all ")#mi("{z \\in D(z_0,R/4)}")#text(", then we can apply (i) with ")#mi("{R}")#text(" replaced by ")#mi("{R/4}")#text(". If not, pick ")#mi("{z_1 \\in D(z_0,R/4)}")#text(" with ")#tao-math("{\\left|f^{\\prime}(z_1)\\right| > 2 \\left|f^{\\prime}(z_0)\\right|}", block: false)#text(", and start over with ")#mi("{z_0}")#text(" replaced by ")#mi("{z_1}")#text(" and ")#mi("{R}")#text(" replaced by ")#mi("{R/2}")#text(". One cannot iterate this process indefinitely as it will create a singularity of ")#mi("{f}")#text(" in ")#mi("{D(z_0,R)}")#text(".)")]
)
]

#heading(level: 1)[#strong[#text(" — 4. Branches of the complex logarithm — ")]]

#text("We have refrained until now from discussing one of the most basic transcendental functions in complex analysis, the ")#link("https://en.wikipedia.org/wiki/Complex_logarithm")[#text("complex logarithm")]#text(". In real analysis, the real logarithm ")#mi("{\\ln: (0,+\\infty) \\rightarrow {\\bf R}}")#text(" can be defined as the inverse of the exponential function ")#mi("{\\exp: {\\bf R} \\rightarrow (0,+\\infty)}")#text("; it can also be equivalently defined as the antiderivative of the function ")#mi("{x \\mapsto \\frac{1}{x}}")#text(", with the initial condition ")#mi("{\\ln(1) = 0}")#text(". (We use ")#mi("{\\ln}")#text(" here for the real logarithm in order to distinguish it from the complex logarithm below.)")

#text("Let’s see what happens when one tries to extend these definitions to the complex domain. We begin with the inversion of the complex exponential. From Euler’s formula we have that ")#mi("{e^{2\\pi i} = 1}")#text("; more generally, we have ")#mi("{e^z = e^w}")#text(" whenever ")#mi("{z = w + 2 k \\pi i}")#text(" for some integer ")#mi("{k}")#text(". In particular, the exponential function ")#mi("{\\exp: {\\bf C} \\rightarrow {\\bf C}}")#text(" is not injective. Indeed, for any non-zero ")#mi("{z \\in {\\bf C}}")#text(", we have a ")#emph[#text("multi-valued")]#text(" logarithm")

#align(center)[#tao-fit-display[#mitex("\\log(z) := \\{ w: e^w = z \\}")]]

#text("which, by Euler’s formula, can be written as")

#align(center)[#tao-fit-display[#tao-math("\\log(z) = \\ln \\left|z\\right| + i \\mathrm{arg}(z)", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{arg}(z) := \\{ \\theta \\in {\\bf R}: \\cos \\theta + i \\sin \\theta = \\frac{z}{\\left|z\\right|} \\}", block: true)]]

#text("denotes all the possible arguments of ")#mi("{z}")#text(" in polar form. These arguments are a coset of the group ")#mi("{2\\pi {\\bf Z} := \\{ 2\\pi k: k \\in {\\bf Z} \\}}")#text(", and so the complex logarithm ")#mi("{\\log(z)}")#text(" is a coset of the group ")#mi("{2\\pi i {\\bf Z} := \\{ 2\\pi i k: k \\in {\\bf Z}\\}}")#text(". For instance, if ")#mi("{z = 2i}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\mathrm{arg}(2i) = \\{ \\frac{\\pi}{2} + 2 k \\pi: k \\in {\\bf Z} \\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\log(2i) = \\{ \\ln 2 + \\frac{\\pi i}{2} + 2 k \\pi i: k \\in {\\bf Z} \\}.")]]

#text("The complex exponential never vanishes, so by our definitions we see that ")#mi("{\\log(0)}")#text(" is the empty set. As such, we will usually omit the origin from the domain ")#mi("{{\\bf C}}")#text(" when discussing the complex exponential.")

#text("Of course, one also encounters multi-valued functions in real analysis, starting when one tries to invert the squaring function ")#mi("{x \\mapsto x^2}")#text(", as any given positive number ")#mi("{y}")#text(" has two square roots. In the real case, one can eliminate this multi-valuedness by picking a branch of the square root function – a function which selects one of the multiple choices for that function at each point in the domain. In particular, we have the positive branch ")#mi("{x \\mapsto \\sqrt{x}}")#text(" of the square root function on ")#mi("{[0,+\\infty)}")#text(", as well as the negative branch ")#mi("{x \\mapsto - \\sqrt{x}}")#text(". One could also create more discontinuous branches of the square root function, for instance the function that sends ")#mi("{x}")#text(" to ")#mi("{\\sqrt{x}}")#text(" for ")#mi("{0 \\leq x \\leq 5}")#text(", and ")#mi("{x}")#text(" to ")#mi("{-\\sqrt{x}}")#text(" for ")#mi("{x > 5}")#text(". In the complex case it will often be appropriate to only construct branches on some subset of the domain of definition, in order to retain good properties of the branch, such as holomorphicity.")

#text("Suppose now that we have a branch ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" of the logarithm function, thus ")#mi("{U}")#text(" is an open subset of ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(" and ")#metadata(none) <tao-5a62008dc9712479544b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\exp(f(z))=z")]]

#text(" ")#text(" for any ")#mi("{z \\in U}")#text(". If ")#mi("{f}")#text(" is complex differentiable at some point ")#mi("{z_0 \\in U}")#text(", then by differentiating ")#link(<tao-5a62008dc9712479544b>)[#text("(14)")]#text(" at ")#mi("{z_0}")#text(" using the chain rule, we see that")

#align(center)[#tao-fit-display[#mitex("f^{\\prime}(z_0) \\exp( f(z_0) ) = 1")]]

#text("and hence by ")#link(<tao-5a62008dc9712479544b>)[#text("(14)")]#text(" again we have")

#align(center)[#tao-fit-display[#mitex("f^{\\prime}(z_0) = \\frac{1}{z_0}")]]

#text("(which is of course consistent with the real-variable formula ")#mi("{\\frac{d}{dx} \\log x = \\frac{1}{x}}")#text("). If now ")#mi("{\\gamma}")#text(" is a closed curve in ")#mi("{U}")#text(", and ")#mi("{f}")#text(" is differentiable on the entire image of ")#mi("{\\gamma}")#text(", then the fundamental theorem of calculus then tells us that")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma \\frac{dz}{z} = \\int_\\gamma f^{\\prime}(z)\\ dz = 0.")]]

#text("On the other hand, ")#mi("{\\int_\\gamma \\frac{dz}{z}}")#text(" is equal to ")#mi("{2\\pi i W_\\gamma(0)}")#text(". We thus conclude that for any branch ")#mi("{f}")#text(" of the complex logarithm, the set on which ")#mi("{f}")#text(" is complex differentiable cannot contain any closed curve that winds non-trivially around the origin. Thus for instance one cannot find a branch of ")#mi("{\\log}")#text(" that is holomorphic on all of ")#mi("{U}")#text(", or even on a neighbourhood of the unit circle (or any other curve going around the origin).")

#text("On the other hand, if ")#mi("{U}")#text(" is a ")#emph[#text("simply connected")]#text(" open subset of ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(", then from Cauchy’s theorem the function ")#mi("{\\frac{1}{z}}")#text(" is conservative on ")#mi("{U}")#text(". If we pick a point ")#mi("{z_0}")#text(" in ")#mi("{U}")#text(" and arbitrarily select a logarithm ")#mi("{w_0 \\in \\log(z_0)}")#text(" of ")#mi("{z_0}")#text(", we can then use the fundamental theorem of calculus to find an antiderivative ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" of ")#mi("{\\frac{1}{z}}")#text(" on ")#mi("{U}")#text(" with ")#mi("{f(z_0)=w_0}")#text(". By definition, ")#mi("{f}")#text(" is holomorphic, and from the chain rule we have for all ")#mi("{z \\in U}")#text(" that")

#tao-aligned(keep: true)[


#tao-math("\\frac{d}{dz} \\exp(f(z))  & = f^{\\prime}(z) \\exp(f(z))", block: true)



#tao-math(" & = \\frac{1}{z} \\exp(f(z))", block: true)
]

#text("and hence by the quotient rule")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dz} \\frac{\\exp(f(z))}{z} = 0.")]]

#text("As ")#mi("{U}")#text(" is connected, ")#mi("{\\frac{\\exp(f(z))}{z}}")#text(" must therefore be constant; by construction we have ")#mi("{\\frac{\\exp(f(z_0))}{z_0}=1}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\frac{\\exp(f(z))}{z} = 1")]]

#text("for all ")#mi("{z \\in U}")#text(". In other words, ")#mi("{f}")#text(" is a branch of the complex logarithm.")

#text("Thus, for instance, the region ")#mi("{{\\bf C} \\backslash \\{ -x: x \\geq 0\\}}")#text(" formed by excluding the negative real axis from the complex plane is simply connected (it is star-shaped around ")#mi("{1}")#text("), and so must admit a holomorphic branch of the complex logarithm. One such branch is the ")#emph[#text("standard branch")]#text(" ")#mi("{\\mathrm{Log}: {\\bf C} \\backslash \\{ -x: x \\geq 0\\} \\rightarrow {\\bf C}}")#text(" of the complex logarithm, defined as")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{Log}(z) := \\ln \\left|z\\right| + i \\mathrm{Arg}(z)", block: true)]]

#text("where ")#mi("{\\mathrm{Arg}(z)}")#text(" is the ")#emph[#text("standard branch")]#text(" of the argument, defined as the unique argument in ")#mi("{\\mathrm{arg}(z)}")#text(" in the interval ")#mi("{(-\\pi,\\pi]}")#text(". This branch of the logarithm is continuous on ")#mi("{{\\bf C} \\backslash \\{ -x: x \\geq 0\\}}")#text(", and hence (by the exercise below) is holomorphic on this region, and is thus an antiderivative of ")#mi("{1/z}")#text(" here; one can also extend the branch to ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(", but it becomes discontinuous when one does so. Similarly if one replaces the negative real axis by other rays emenating from the origin (or indeed from arbitrary simple curves from zero to infinity, see Exercise ")#link(<tao-507a9a8be3d145a86daa>)[#text("45")]#text(" below.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 44")]#text(" Let ")#mi("{U}")#text(" be a connected non-empty open subset of ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(".")

#list(
[#text("(i) If ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" and ")#mi("{g: U \\rightarrow {\\bf C}}")#text(" are continuous branches of the complex logarithm, show that there exists a natural number ")#mi("{k}")#text(" such that ")#mi("{f(z) = g(z) + 2\\pi i k}")#text(" for all ")#mi("{z \\in U}")#text(".")],
[#text("(ii) Show that any continuous branch ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" of the complex logarithm is holomorphic.")],
[#text("(iii) Show that there is a continuous branch ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" of the logarithm if and only if ")#mi("{0}")#text(" and ")#mi("{\\infty}")#text(" lie in the same connected component of ")#mi("{({\\bf C} \\cup \\{\\infty\\}) \\backslash U}")#text(". (")#emph[#text("Hint:")]#text(" for the “if” direction, use a continuity argument to show that the winding number of any closed curve in ")#mi("{U}")#text(" around ")#mi("{0}")#text(" vanishes. For the “only if”, you may use without proof the fact that if two points ")#mi("{x,y}")#text(" in a compact Hausdorff space ")#mi("{X}")#text(" do not lie in the same connected component, then there exists a clopen subset ")#mi("{K}")#text(" of ")#mi("{X}")#text(" that contains ")#mi("{x}")#text(" but not ")#mi("{y}")#text(" (sketch of proof: show that the intersection of all the clopen neighbourhoods of ")#mi("{x}")#text(" is connected and also contains all the connected sets containing ")#mi("{x}")#text("). Use this fact to encircle ")#mi("{0}")#text(" by a simple polygonal path in ")#mi("{U}")#text(".)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 45")]#text(" ")#metadata(none) <tao-507a9a8be3d145a86daa>#text(" Let ")#mi("{\\gamma: [0,+\\infty) \\rightarrow {\\bf C}}")#text(" be a continuous injective map with ")#mi("{\\gamma(0)=0}")#text(" and ")#mi("{\\gamma(t) \\rightarrow \\infty}")#text(" as ")#mi("{t \\rightarrow \\infty}")#text(".")

#list(
[#text("(i) Show that ")#mi("{\\gamma([0,+\\infty))}")#text(" is not all of ")#mi("{{\\bf C}}")#text(". (")#emph[#text("Hint:")]#text(" modify the construction in Section 4 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/#comments")[#text("Notes 3")]#text(" that showed that a simple closed curve admitted at least one point with non-zero winding number.)")],
[#text("(ii) Show that the complement ")#mi("{{\\bf C} \\backslash \\gamma([0,+\\infty))}")#text(" is simply connected. (")#emph[#text("Hint:")]#text(" modify the remaining arguments in Section 4 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/#comments")[#text("Notes 3")]#text("). In particular, by the preceding discussion, there is a branch of the complex logarithm that is holomorphic outside of ")#mi("{\\gamma([0,+\\infty))}")#text(".")]
)
]

#text("It is instructive to view the identity ")#metadata(none) <tao-0146932d7674476e808a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\int_{\\gamma_{0,1,\\circlearrowleft}} \\frac{dz}{z} = 2\\pi i")]]

#text(" ")#text(" , through the lens of branches of the complex logarithm such as the standard branch ")#mi("{\\mathrm{Log}}")#text(". From the fundamental theorem of calculus, one has")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma \\frac{dz}{z} = \\mathrm{Log}(\\gamma(b)) - \\mathrm{Log}(\\gamma(a))")]]

#text("for any curve ")#mi("{\\gamma}")#text(" that avoids the negative real axis. Of course, the contour ")#mi("{\\gamma_{0,1,\\circlearrowleft}}")#text(" does not avoid this negative axis, but it can be approximated by (non-closed) contours that do. More precisely, one has")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_{0,1,\\circlearrowleft}} \\frac{dz}{z} = \\lim_{\\varepsilon \\rightarrow 0^+} \\int_{\\gamma_{[-\\pi+\\varepsilon,\\pi-\\varepsilon]}} \\frac{dz}{z}")]]

#text("where ")#mi("{\\gamma_{[-\\pi+\\varepsilon,\\pi-\\varepsilon]}: [-\\pi+\\varepsilon,\\pi-\\varepsilon] \\rightarrow {\\bf C}}")#text(" is the map ")#mi("{t \\mapsto e^{it}}")#text(". As each ")#mi("{\\gamma_{[-\\pi+\\varepsilon,\\pi-\\varepsilon]}}")#text(" avoids the negative real axis, we thus have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_{0,1,\\circlearrowleft}} \\frac{dz}{z} = \\lim_{\\varepsilon \\rightarrow 0^+} \\mathrm{Log}( e^{i (\\pi-\\varepsilon)}) - \\mathrm{Log}( e^{i (-\\pi+\\varepsilon)}).")]]

#text("We observe that ")#mi("{\\mathrm{Log}}")#text(" has a jump discontinuity of ")#mi("{2\\pi i}")#text(" on the negative real axis, and specifically")

#align(center)[#tao-fit-display[#mitex("\\lim_{\\varepsilon \\rightarrow 0^+} \\mathrm{Log}(e^{i(\\pi-\\varepsilon)}) = i \\pi")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\lim_{\\varepsilon \\rightarrow 0^+} \\mathrm{Log}(e^{i(-\\pi+\\varepsilon)}) = -i \\pi,")]]

#text("which gives an alternate derivation of the identity ")#link(<tao-0146932d7674476e808a>)[#text("(15)")]#text(". More generally, the identity")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma} \\frac{dz}{z} = 2\\pi i W_\\gamma(0)")]]

#text("for any closed curve ")#mi("{\\gamma}")#text(" avoiding the origin can be interpreted using the standard branch of the logarithm as a version of the ")#link("https://en.wikipedia.org/wiki/Winding_number#Alexander_numbering")[#text("Alexander numbering rule")]#text(" (Exercise 57 of Notes 3): each crossing of ")#mi("{\\gamma}")#text(" across the branch cut triggers a jump up or down in the count towards the winding number, depending on whether the crossing was in the anticlockwise or clockwise direction.")

#text("One can use branches of the complex logarithm to create branches of the ")#mi("{n^{\\mathrm{th}}}")#text(" root functions ")#mi("{z \\mapsto z^{1/n}}")#text(" for natural numbers ")#mi("{n>1}")#text(". As with the complex exponential, the function ")#mi("{z \\mapsto z^n}")#text(" is not injective, and so ")#mi("{z^{1/n}}")#text(" is multivalued (see Exercise 15 of ")#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/")[#text("Notes 0")]#text("). One cannot form a continuous branch of this function on ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(" for any ")#mi("{n \\geq 2}")#text(", as the corresponding branch of ")#mi("{1/z^{1/n}}")#text(" would then contradict the quantisation of order of singularities (Exercise ")#link(<tao-7327d4d86dcf6bd569c0>)[#text("14")]#text("). However, on any domain ")#mi("{U}")#text(" where there is a holomorphic branch ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" of the complex logarithm, one can define a holomorphic branch ")#mi("{g: U \\rightarrow {\\bf C}}")#text(" of the ")#mi("{n^{\\mathrm{th}}}")#text(" root function by the formula")

#align(center)[#tao-fit-display[#mitex("g(z) := \\exp( f(z) / n ).")]]

#text("It is easy to see that ")#mi("{g}")#text(" is indeed holomorphic with ")#mi("{g(z)^n = z}")#text(" for all ")#mi("{z \\in U}")#text(". Thus for instance we have the standard branch ")#mi("{z \\mapsto \\exp( (\\mathrm{Log} z) / n )}")#text(" of the ")#mi("{n^{\\mathrm{th}}}")#text(" root function, which is holomorphic away from the negative real axis. More generally, one can define a “standard branch of ")#mi("{z \\mapsto z^\\alpha}")#text("” for any complex ")#mi("{\\alpha}")#text(" by the formula ")#mi("{z \\mapsto \\exp( \\alpha \\mathrm{Log} z )}")#text(", for instance the standard branch of ")#mi("{i^i}")#text(" can be computed to be ")#mi("{e^{-\\pi/2}}")#text(".")

#text("The presence of branch cuts can prevent one from directly applying the residue theorem to calculate integrals involving branches of multi-valued functions. But in some cases, the presence of the branch cut can actually be ")#emph[#text("exploited")]#text(" to compute an integral. The following exercise provides an example:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 46")]#text(" Compute the improper integral")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty \\frac{dx}{\\sqrt{x} (x+1)} := \\lim_{\\varepsilon \\rightarrow 0, R \\rightarrow \\infty} \\int_\\varepsilon^R \\frac{dx}{\\sqrt{x} (x+1)}")]]

#text("by applying the residue theorem to the function ")#mi("{\\frac{f(z)}{z+1}}")#text(" for some branch ")#mi("{f(z)}")#text(" of ")#mi("{z \\mapsto z^{-1/2}}")#text(" with branch cut on the ")#emph[#text("positive")]#text(" real axis, and using a “keyhole” contour that is a perturbation of")

#align(center)[#tao-fit-display[#mitex("\\gamma_{0,\\varepsilon,\\circlearrowright} + \\gamma_{\\varepsilon \\rightarrow R} + \\gamma_{0,R,\\circlearrowleft} + \\gamma_{R \\rightarrow \\varepsilon};")]]

#text("the key point is that the branch cut makes the contribution of (the perturbations) of ")#mi("{\\gamma_{\\varepsilon \\rightarrow R}}")#text(" and ")#mi("{\\gamma_{R \\rightarrow \\varepsilon}}")#text(" fail to cancel each other.")
]

#text("The construction of holomorphic branches of ")#mi("{\\log z}")#text(" can be extended to other logarithms:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 47")]#text(" ")#metadata(none) <tao-619bc82e0d200e4ad4e6>#text(" Let ")#mi("{U}")#text(" be a simply connected subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a holomorphic function with no zeroes on ")#mi("{U}")#text(".")

#list(
[#text("(i) Show that there exists a holomorphic branch ")#mi("{g: U \\rightarrow {\\bf C}}")#text(" of the complex logarithm ")#mi("{\\log f}")#text(", thus ")#mi("{\\exp(g) = f}")#text(". Furthermore, this branch is unique up to the addition of an integer multiple of ")#mi("{2\\pi i}")#text(" (i.e., if ")#mi("{g,\\tilde g}")#text(" are two such branches, then ")#mi("{\\tilde g = g + 2 k \\pi i}")#text(" for some integer ")#mi("{k}")#text(").")],
[#text("(ii) Show that for any natural number ")#mi("{n > 1}")#text(", there exists a holomorphic branch ")#mi("{h: U \\rightarrow {\\bf C}}")#text(" of the root function ")#mi("{f^{1/n}}")#text(", thus ")#mi("{h^n = f}")#text(".")]
)
]

#text("Actually, one can invert other non-injective holomorphic functions than the complex exponential, provided that these functions are a ")#link("https://en.wikipedia.org/wiki/Covering_space")[#text("covering map")]#text(". We recall this topological concept:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 48 (Covering map)")]#text(" Let ")#mi("{f: M \\rightarrow N}")#text(" be a continuous map between two connected topological spaces ")#mi("{M, N}")#text(". We say that ")#mi("{f}")#text(" is a ")#emph[#text("covering map")]#text(" if, for each ")#mi("{z_0 \\in N}")#text(", there exists an open neighbourhood ")#mi("{U}")#text(" of ")#mi("{z_0}")#text(" in ")#mi("{N}")#text(" such that the preimage ")#mi("{f^{-1}(U)}")#text(" is the disjoint union of open subsets ")#mi("{V_\\alpha, \\alpha \\in A}")#text(" of ")#mi("{M}")#text(", such that for each ")#mi("{\\alpha \\in A}")#text(", the map ")#mi("{f: V_\\alpha \\rightarrow U}")#text(" is a homeomorphism. In this situation, we call ")#mi("{M}")#text(" a ")#emph[#text("covering space")]#text(" of ")#mi("{N}")#text(".")
]

#text("In complex analysis, one specialises to the situation in which ")#mi("{M,N}")#text(" are Riemann surfaces (e.g. they could be open subsets of ")#mi("{{\\bf C}}")#text("), and ")#mi("{f}")#text(" is a holomorphic map. In that case, the homeomorphisms ")#mi("{f: V_\\alpha \\rightarrow U}")#text(" are in fact complex diffeomorphisms, thanks to Exercise ")#link(<tao-a175190e28d8d2c70803>)[#text("41")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 49")]#text(" The exponential map ")#mi("{\\exp: {\\bf C} \\rightarrow {\\bf C} \\backslash \\{0\\}}")#text(" is a covering map, because for any element of ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(" written in polar form as ")#mi("{r e^{i\\theta}}")#text(", one can pick (say) the neighbourhood")

#align(center)[#tao-fit-display[#mitex("U := \\{ s e^{i\\alpha}: r/2 < s < 2r; \\theta - \\frac{\\pi}{2} < \\alpha < \\theta + \\frac{\\pi}{2} \\}")]]

#text("of ")#mi("{re^{i\\theta}}")#text(", and observe that the preimage ")#mi("{\\exp^{-1}(U) = \\log U}")#text(" of ")#mi("{U}")#text(" is the disjoint union of the open sets")

#align(center)[#tao-fit-display[#mitex("V_k := \\{ x + i \\alpha: \\ln(r/2) < x < \\ln(r); \\theta + 2 k \\pi - \\frac{\\pi}{2} < \\alpha < \\theta + \\frac{\\pi}{2} \\}")]]

#text("for ")#mi("{k \\in {\\bf Z}}")#text(", and that the exponential map ")#mi("{\\exp: V_k \\rightarrow U}")#text(" is a diffeomorphism. A similar calculation shows that for any natural number ")#mi("{n > 1}")#text(", the map ")#mi("{z \\mapsto z^n}")#text(" is a covering map from ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(" to ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(". However, the map ")#mi("{z \\mapsto z^n}")#text(" is ")#emph[#text("not")]#text(" a covering map from ")#mi("{{\\bf C}}")#text(" to ")#mi("{{\\bf C}}")#text(", because it fails to be a local diffeomorphism at zero due to the vanishing derivative (here we use Exercise ")#link(<tao-a175190e28d8d2c70803>)[#text("41")]#text("). One final (non-)example: the map ")#mi("{z \\mapsto z^3}")#text(" is ")#emph[#text("not")]#text(" a covering map from the upper half-plane ")#mi("{\\{ z \\in {\\bf C}: \\mathrm{Im}(z)>0\\}}")#text(" to ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(", because the preimage of any small disk ")#mi("{D(1,r)}")#text(" around ")#mi("{1}")#text(" splits into two disconnected regions, and only one of them is homeomorphic to ")#mi("{D(1,r)}")#text(" via the map ")#mi("{z \\mapsto z^3}")#text(".")
]

#text("From topology we have the following lifting property:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 50 (Lifting lemma)")]#text(" ")#metadata(none) <tao-5364b92e50b1944f33d1>#text(" Let ")#mi("{f: M \\rightarrow N}")#text(" be a continuous covering map between two path-connected and ")#link("https://en.wikipedia.org/wiki/Locally_connected_space")[#text("locally path-connected")]#text(" topological spaces ")#mi("{M,N}")#text(". Let ")#mi("{U}")#text(" be a simply connected and path connected topological space, and let ")#mi("{g: U \\rightarrow N}")#text(" be continuous. Let ")#mi("{z_0 \\in U}")#text(", and let ")#mi("{p \\in M}")#text(" be such that ")#mi("{f(p) = g(z_0)}")#text(". Then there exists a unique continuous map ")#mi("{h: U \\rightarrow M}")#text(" such that ")#mi("{g = f \\circ h}")#text(" and ")#mi("{h(z_0)=p}")#text(", which we call a ")#emph[#text("lift")]#text(" of ")#mi("{g}")#text(" by ")#mi("{f}")#text(".")
]

#emph[#text("Proof:")]#text(" We first verify uniqueness. If we have two continuous functions ")#mi("{h_1, h_2: U \\rightarrow N}")#text(" with ")#mi("{h_1(z_0) = h_2(z_0) = p}")#text(" and ")#mi("{g = f \\circ h_1 = f \\circ h_2}")#text(", then the set ")#mi("{\\Omega := \\{ z \\in U: h_1(z) = h_2(z) \\}}")#text(" is clearly closed in ")#mi("{N}")#text(" and contains ")#mi("{z_0}")#text(". From the covering map property we also see that ")#mi("{\\Omega}")#text(" is open, and hence by connectedness we have ")#mi("{h_1=h_2}")#text(" on all of ")#mi("{U}")#text(", giving the claim.")

#text("To verify existence of the lift, we first prove the existence of ")#link("https://en.wikipedia.org/wiki/Monodromy")[#text("monodromy")]#text(". More precisely, given any curve ")#mi("{\\gamma:[a,b] \\rightarrow U}")#text(" with ")#mi("{\\gamma(a) = z_0}")#text(" we show that there exists a unique curve ")#mi("{\\tilde \\gamma: [a,b] \\rightarrow M}")#text(" such that ")#mi("{\\tilde \\gamma(a) = p}")#text(" and ")#mi("{f \\circ \\tilde \\gamma = g \\circ \\gamma}")#text(" (the reader is encouraged to draw a picture to describe this situation). Uniqueness follows from the connectedness argument used to prove uniqueness of the lift ")#mi("{h}")#text(", so we turn to existence. As in previous notes, we rely on a continuity argument. Let ")#mi("{\\Omega}")#text(" be the set of all ")#mi("{a \\leq t \\leq b}")#text(" for which there exists a curve ")#mi("{\\tilde \\gamma_{[a,t]}: [a,t] \\rightarrow M}")#text(" such that ")#mi("{\\tilde \\gamma_{[a,t]}(a) = p}")#text(" and ")#mi("{f \\circ \\tilde \\gamma_{[a,t]} = g \\circ \\gamma_{[a,t]}}")#text(", where ")#mi("{\\gamma_{[a,t]}}")#text(" is the restriction of ")#mi("{\\gamma}")#text(" to ")#mi("{[a,t]}")#text(". Clearly ")#mi("{\\Omega}")#text(" contains ")#mi("{a}")#text("; using the covering map property (and the uniqueness of lifts) it is not difficult to show that ")#mi("{\\Omega}")#text(" is also open and closed in ")#mi("{[a,b]}")#text(". Thus ")#mi("{\\Omega}")#text(" is all of ")#mi("{[a,b]}")#text(", giving the claim.")

#text("Now let ")#mi("{\\gamma_0: [a,b] \\rightarrow U}")#text(", ")#mi("{\\gamma_1: [a,b] \\rightarrow U}")#text(" be homotopic curves with fixed endpoints, with initial point ")#mi("{\\gamma_0(a)=\\gamma_1(a)=z_0}")#text(" and some terminal point ")#mi("{z_1}")#text(", and let ")#mi("{\\gamma: [0,1] \\times [a,b] \\rightarrow U}")#text(" be a homotopy. For each ")#mi("{s \\in [0,1]}")#text(", we have a curve ")#mi("{\\gamma_s: [a,b] \\rightarrow U}")#text(" given by ")#mi("{\\gamma_s(t) := \\gamma(s,t)}")#text(", and by the preceding paragraph we can associate a curve ")#mi("{\\tilde \\gamma_s: [a,b] \\rightarrow M}")#text(" such that ")#mi("{\\tilde \\gamma_s(a) = p}")#text(" and ")#mi("{f \\circ \\tilde \\gamma_s = g \\circ \\gamma_s}")#text(". Another application of the continuity method shows that for all ")#mi("{t \\in [a,b]}")#text(", the map ")#mi("{s \\mapsto \\tilde \\gamma_s(t)}")#text(" is continuous; in particular, the map ")#mi("{s \\rightarrow \\tilde \\gamma_s(b)}")#text(" is continuous. On the other hand, ")#mi("{\\tilde \\gamma_s(b)}")#text(" lies in ")#mi("{f^{-1}(g(z_1))}")#text(", which is a discrete set thanks to the covering map property. We conclude that ")#mi("{\\tilde \\gamma_s(b)}")#text(" is constant in ")#mi("{s}")#text(", and in particular that ")#mi("{\\tilde \\gamma_0(b) = \\tilde \\gamma_1(b)}")#text(".")

#text("Since ")#mi("{U}")#text(" is simply connected, any two curves ")#mi("{\\gamma_0, \\gamma_1:[a,b] \\rightarrow U}")#text(" with fixed endpoints are homotopic. We can thus define a function ")#mi("{h: U \\rightarrow M}")#text(" by declaring ")#mi("{h(z_1)}")#text(" for any ")#mi("{z_1 \\in U}")#text(" to be the point ")#mi("{\\tilde \\gamma(1)}")#text(", where ")#mi("{\\gamma: [0,1] \\rightarrow U}")#text(" is any curve from ")#mi("{z_0}")#text(" to ")#mi("{z_1}")#text(", and ")#mi("{\\tilde \\gamma}")#text(" is constructed as before. By construction we have ")#mi("{g = f \\circ h}")#text(", and from the local path connectedness of ")#mi("{N}")#text(" and the covering map property of ")#mi("{f}")#text(" we can check that ")#mi("{h}")#text(" is continuous. The claim follows. ")#mi("\\Box")

#text("We can specialise this to the complex case and obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 51 (Holomorphic lifting lemma)")]#text(" ")#metadata(none) <tao-f97ab7d41b89dc4eb365>#text(" Let ")#mi("{f: M \\rightarrow N}")#text(" be a holomorphic covering map between two connected Riemann surfaces ")#mi("{M,N}")#text(". Let ")#mi("{U}")#text(" be a simply connected and path connected Riemann surface, and let ")#mi("{g: U \\rightarrow N}")#text(" be holomorphic. Let ")#mi("{z_0 \\in U}")#text(", and let ")#mi("{p \\in M}")#text(" be such that ")#mi("{f(p) = g(z_0)}")#text(". Then there exists a unique holomorphic map ")#mi("{h: U \\rightarrow M}")#text(" such that ")#mi("{g = f \\circ h}")#text(" and ")#mi("{h(z_0)=p}")#text(", which we call a ")#emph[#text("lift")]#text(" of ")#mi("{g}")#text(" by ")#mi("{f}")#text(".")
]

#emph[#text("Proof:")]#text(" A Riemann surface is automatically locally path-connected, and a connected Riemann surface is automatically path connected (observe that the set of all points on the surface that can be path-connected to a reference point ")#mi("{p}")#text(" is open, closed, and non-empty). Applying Lemma ")#link(<tao-5364b92e50b1944f33d1>)[#text("50")]#text(", we obtain all the required claims, except that the lift ")#mi("{h}")#text(" produced is only known to be continuous rather than holomorphic. But then we can locally express ")#mi("{h}")#text(" as the composition of one of the local inverses of ")#mi("{f}")#text(" with ")#mi("{g}")#text(". Applying Exercise ")#link(<tao-a175190e28d8d2c70803>)[#text("41")]#text(", these local inverses are holomorphic, and so ")#mi("{h}")#text(" is holomorphic also. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 52")]#text(" It is also possible to establish the above corollary using the ")#link("https://en.wikipedia.org/wiki/Monodromy_theorem")[#text("monodromy theorem")]#text(" and analytic continuation.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 53")]#text(" Establish Exercise ")#link(<tao-619bc82e0d200e4ad4e6>)[#text("47")]#text(" using Corollary ")#link(<tao-f97ab7d41b89dc4eb365>)[#text("51")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 54")]#text(" ")#metadata(none) <tao-b6813f3af2d45fbfc768>#text(" Let ")#mi("{U}")#text(" be simply connected, and let ")#mi("{f: U \\rightarrow {\\bf C} \\backslash \\{-1,+1\\}}")#text(" be holomorphic and avoid taking the values ")#mi("{+1,-1}")#text(". Show that there exists a holomorphic function ")#mi("{g: U \\rightarrow {\\bf C}}")#text(" such that ")#mi("{f = \\cos g}")#text(". (This can be proven either through Corollary ")#link(<tao-f97ab7d41b89dc4eb365>)[#text("51")]#text(", or by using the quadratic formula to solve for ")#mi("{e^{ig}}")#text(" and then applying Exercise ")#link(<tao-619bc82e0d200e4ad4e6>)[#text("47")]#text(".)")
]

#text("In some cases it is also possible to obtain lifts in non-simply connected domains:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 55")]#text(" Show that there exists a holomorphic function ")#mi("{f: {\\bf C} \\backslash [0,1] \\rightarrow {\\bf C}}")#text(" such that ")#mi("{\\exp(f(z)) = \\frac{z-1}{z}}")#text(" for all ")#mi("{z \\in {\\bf C} \\backslash [0,1]}")#text(". (")#emph[#text("Hint:")]#text(" use the Schwarz reflection principle, see Exercise 39 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences")[#text("Notes 3")]#text(".)")
]

#text("As an illustration of what one can do with all this machinery, let us now prove the ")#link("https://en.wikipedia.org/wiki/Picard_theorem")[#text("Picard theorems")]#text(". We begin with the easier “little” Picard theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 56 (Little Picard theorem)")]#text(" Let ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" be entire and non-constant. Then ")#mi("{f({\\bf C})}")#text(" omits at most one point of ")#mi("{{\\bf C}}")#text(".")
]

#text("The example of the exponential function ")#mi("{\\exp: {\\bf C} \\rightarrow {\\bf C}}")#text(", whose range omits the origin, shows that one cannot make any stronger conclusion about ")#mi("{f({\\bf C})}")#text(".")

#emph[#text("Proof:")]#text(" Suppose for contradiction that we have an entire non-constant function ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" such that ")#mi("{f({\\bf C})}")#text(" omits at least two points. After applying a linear transformation, we may assume that ")#mi("{f({\\bf C})}")#text(" avoids ")#mi("{0}")#text(" and ")#mi("{1}")#text(", thus ")#mi("{f}")#text(" takes values in ")#mi("{{\\bf C} \\backslash \\{0,1\\}}")#text(".")

#text("At this point, the most natural thing to do from a Riemann surface point of view would be to cover ")#mi("{{\\bf C} \\backslash \\{0,1\\}}")#text(" by a bounded region, so that Liouville’s theorem may be applied. This can be done easily once one has the machinery of ")#link("https://en.wikipedia.org/wiki/Elliptic_function")[#text("elliptic functions")]#text("; but as we do not have this machinery yet, we will instead use a more ")#emph[#text("ad hoc")]#text(" covering of ")#mi("{{\\bf C} \\backslash \\{0,1\\}}")#text(" using the exponential and trigonometric functions to achieve a passable substitute for this strategy.")

#text("We turn to the details. Since ")#mi("{f({\\bf C})}")#text(" avoids ")#mi("{0}")#text(", we may apply Exercise ")#link(<tao-619bc82e0d200e4ad4e6>)[#text("47")]#text(" to write ")#mi("{f = \\exp(2\\pi i g)}")#text(" for some entire ")#mi("{g: {\\bf C} \\rightarrow {\\bf C}}")#text(". As ")#mi("{f({\\bf C})}")#text(" avoids ")#mi("{1}")#text(", ")#mi("{g({\\bf C})}")#text(" must avoid the integers ")#mi("{{\\bf Z}}")#text(".")

#text("Next, we apply Exercise ")#link(<tao-b6813f3af2d45fbfc768>)[#text("54")]#text(" to write ")#mi("{g = \\cos(h)}")#text(" for some entire ")#mi("{h: {\\bf C} \\rightarrow {\\bf C}}")#text(". The set ")#mi("{h({\\bf C})}")#text(" must now avoid all complex numbers of the form ")#mi("{\\pm i \\cosh^{-1}(j) + 2 \\pi k}")#text(" for natural numbers ")#mi("{j}")#text(" and integers ")#mi("{k}")#text(". In particular, if ")#mi("{C}")#text(" is large enough, we see that ")#mi("{h({\\bf C})}")#text(" does not contain any disk of the form ")#mi("{D(w,C)}")#text(". Applying Bloch’s theorem (Exercise ")#link(<tao-5f392985a1297212e668>)[#text("43")]#text("(ii)) in the contrapositive, we conclude that for any disk ")#mi("{D(z_0,R)}")#text(" in ")#mi("{{\\bf C}}")#text(", one has ")#tao-math("{\\left|h^{\\prime}(z_0)\\right|\\leq C^{\\prime}/R}", block: false)#text(" for some absolute constant ")#mi("{C^{\\prime}}")#text(". Sending ")#mi("{R}")#text(" to infinity and using the fundamental theorem of calculus, we conclude that ")#mi("{h}")#text(" is constant, hence ")#mi("{g}")#text(" and ")#mi("{f}")#text(" are also constant, a contradiction. ")#mi("\\Box")

#text("Now we prove the more difficult “great” Picard theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 57 (Great Picard theorem)")]#text(" ")#metadata(none) <tao-053ea4804ef1bb33d4a3>#text(" Let ")#mi("{f: D(z_0,r) \\backslash \\{z_0\\} \\rightarrow {\\bf C}}")#text(" be holomorphic on a disk ")#mi("{D(z_0,r)}")#text(" outside of a singularity at ")#mi("{z_0}")#text(". If this singularity is essential, then ")#mi("{f( D(z_0,r) \\backslash \\{z_0\\} )}")#text(" omits at most one point of ")#mi("{{\\bf C}}")#text(".")
]

#text("Note that if one only has a pole at ")#mi("{z_0}")#text(", e.g. if ")#mi("{f(z) = (z-z_0)^{-m}}")#text(" for some natural number ")#mi("{m}")#text(", then the conclusion of the great Picard theorem fails. This result easily implies both the little Picard theorem (because if ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" is entire and non-polynomial, then ")#mi("{f(1/z)}")#text(" has an essential singularity at the origin) and the Casorati-Weierstrass theorem (Theorem ")#link(<tao-082880fec97cd1a5dfa3>)[#text("12")]#text("(iii)). By repeatedly passing to smaller neighbourhoods, one in fact sees that with at most one exception, every complex number ")#mi("{c \\in {\\bf C}}")#text(" is attained infinitely often by a function holomorphic in a punctured disk around an essential singularity.")

#emph[#text("Proof:")]#text(" This will be a variant of the proof of the little Picard theorem; it would again be more natural to use elliptic functions, but we will use some passable substitutes for such functions concocted in an ")#emph[#text("ad hoc")]#text(" fashion out of exponential and trigonometric functions.")

#text("Assume for contradiction that ")#mi("{f: D(z_0,r) \\backslash \\{z_0\\} \\rightarrow {\\bf C}}")#text(" has an essential singularity at ")#mi("{z_0}")#text(" and avoids at least two points in ")#mi("{{\\bf C}}")#text(". Applying linear transformations to both the domain and range of ")#mi("{f}")#text(", we may normalise ")#mi("{z_0=0}")#text(", ")#mi("{r=1}")#text(", and assume that ")#mi("{f}")#text(" avoids ")#mi("{0}")#text(" and ")#mi("{1}")#text(", thus we have a holomorphic map ")#mi("{f: D(0,1) \\backslash \\{0\\} \\rightarrow {\\bf C} \\backslash \\{0,1\\}}")#text(" with an essential singularity at ")#mi("{0}")#text(".")

#text("The domain ")#mi("{D(0,1) \\backslash \\{0\\}}")#text(" is not simply connected, so we work instead with the function")

#align(center)[#tao-fit-display[#mitex("F: \\{ z \\in {\\bf C}: \\mathrm{Re}(z) > 0 \\} \\rightarrow {\\bf C} \\backslash \\{0,1\\}")]]

#text("defined by")

#align(center)[#tao-fit-display[#mitex("F(z) := f( \\exp(-z) ).")]]

#text("Clearly ")#mi("{F}")#text(" is holomorphic on the right-half plane ")#mi("{\\{ z \\in {\\bf C}: \\mathrm{Re}(z) > 0 \\}}")#text(" and avoids ")#mi("{0,1}")#text(". We also observe that ")#mi("{F}")#text(" obeys the periodicity property")

#metadata(none) <tao-0db9df7d8e7ff24ae598>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("F(z + 2\\pi i) = F(z).")]]

#text("As the right-half plane is simply connected, we may (as before) express ")#mi("{F = \\exp(2\\pi i G)}")#text(" for some holomorphic function ")#mi("{G: \\{ z \\in {\\bf C}: \\mathrm{Re}(z) > 0 \\} \\rightarrow {\\bf C} \\backslash {\\bf Z}}")#text(", and then write ")#mi("{G = \\cos(H)}")#text(" for some holomorphic function ")#mi("{H: \\{z \\in {\\bf C}: \\mathrm{Re}(z) > 0 \\} \\rightarrow {\\bf C}}")#text(" that avoids all numbers of the form ")#mi("{\\pm i \\cosh^{-1}(j) + 2 \\pi k}")#text(" for natural numbers ")#mi("{j}")#text(" and integers ")#mi("{k}")#text(". Using Bloch’s theorem as before, we see that for any disk ")#mi("{D(z_0,R)}")#text(" in the right-half plane ")#mi("{\\{z \\in {\\bf C}: \\mathrm{Re}(z) > 0 \\}}")#text(", we have ")#tao-math("{\\left|H^{\\prime}(z_0)\\right| \\leq C / R}", block: false)#text(" for some absolute constant ")#mi("{C}")#text(". We cannot set ")#mi("{R}")#text(" to infinity any more, but we can make ")#mi("{R}")#text(" as large as the real part of ")#mi("{z_0}")#text(", giving the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|H^{\\prime}(z_0)\\right| \\leq \\frac{C}{\\mathrm{Re}(z_0)}.", block: true)]]

#text("In particular, on integrating along a line segment from ")#mi("{2+iy}")#text(" to ")#mi("{x+iy}")#text(", and using the boundedness of ")#mi("{H}")#text(" on the compact set ")#mi("{\\{ 2+iy: 0 \\leq y \\leq 2\\pi\\}}")#text(", we obtain a bound of the form")

#align(center)[#tao-fit-display[#tao-math("\\left|H(x+iy)\\right| \\leq A \\ln x", block: true)]]

#text("for some ")#mi("{A > 0}")#text(", and all ")#mi("{x \\geq 2}")#text(" and ")#mi("{0 \\leq y \\leq 2\\pi}")#text(". Taking cosines using the formula ")#mi("{\\cos(z) = (e^{iz}+e^{-iz})/2}")#text(", we obtain a polynomial type bound")

#metadata(none) <tao-2fe840e13244a9d74888>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\left|G(x+iy)\\right| \\leq x^{A}", block: true)]]

#text("for all ")#mi("{x \\geq 2}")#text(" and ")#mi("{0 \\leq y \\leq 2\\pi}")#text(".")

#text("On the other hand, from ")#link(<tao-0db9df7d8e7ff24ae598>)[#text("(16)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\exp( 2\\pi i G( z + 2\\pi i ) ) = \\exp( 2\\pi i G(z) )")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("G(z+2\\pi i) - G(z) \\in {\\bf Z}")]]

#text("for all ")#mi("{z}")#text(" in the right half-plane. The set ")#mi("{{\\bf Z}}")#text(" is discrete, the function ")#mi("{z \\mapsto G(z+2\\pi i)-G(z)}")#text(" is continuous, and the right half-plane is connected, so this function must in fact be constant. That is to say, there exists an integer ")#mi("{k}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("G(z+2\\pi i) - G(z) = k")]]

#text("for all ")#mi("{z}")#text(" in the upper half plane. Equivalently, the function ")#mi("{G(z) - \\frac{kz}{2\\pi i}}")#text(" is periodic with period ")#mi("{2\\pi i}")#text(". From ")#link(<tao-2fe840e13244a9d74888>)[#text("(17)")]#text(" and the triangle inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\left|G(x+iy) - \\frac{k(x+iy)}{2\\pi i}\\right| \\leq x^A + \\frac{\\left|k\\right|}{2\\pi} (x + 2\\pi)", block: true)]]

#text("for all ")#mi("{x \\geq 2}")#text(" and ")#mi("{0 \\leq y \\leq 2\\pi}")#text(", hence by periodicity we get this bound also for any ")#mi("{x \\geq 2}")#text(" and ")#mi("{y \\in {\\bf R}}")#text(". We simplify the right-hand side somewhat as")

#metadata(none) <tao-f3cf3f52140e146702cb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\left|G(x+iy) - \\frac{k(x+iy)}{2\\pi i}\\right| \\leq C x^{A^{\\prime}}", block: true)]]

#text("for all ")#mi("{x \\geq 2}")#text(", ")#mi("{y \\in {\\bf R}}")#text(" and some constants ")#mi("{C, A^{\\prime}}")#text(" (that can depend on ")#mi("{k}")#text(", ")#mi("{A}")#text(").")

#text("We now upgrade this bound on ")#link(<tao-f3cf3f52140e146702cb>)[#text("(18)")]#text(" by exploiting the quantisation of pole orders (Exercise ")#link(<tao-7327d4d86dcf6bd569c0>)[#text("14")]#text("). As the function ")#mi("{G(z)-\\frac{kz}{2\\pi i}}")#text(" is periodic with period ")#mi("{2\\pi i}")#text(" on ")#mi("{\\{ z: \\mathrm{Re}(z) \\geq 2 \\}}")#text(", we may write ")#metadata(none) <tao-cd8afab5b1562accac66>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("G(z) - \\frac{k z}{2\\pi i} = g( \\exp( -z ) )")]]

#text(" ")#text(" for some function ")#mi("{g: D(0,e^{-2}) \\backslash \\{0\\} \\rightarrow {\\bf C}}")#text(", which is holomorphic thanks to the chain rule. From ")#link(<tao-f3cf3f52140e146702cb>)[#text("(18)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|g(z)\\right| \\leq C \\ln^{A^{\\prime}} \\frac{1}{\\left|z\\right|}", block: true)]]

#text("when ")#tao-math("{0 < \\left|z\\right| \\leq e^{-2}}", block: false)#text(". Applying Exercise ")#link(<tao-7327d4d86dcf6bd569c0>)[#text("14")]#text(" (with, say, ")#mi("{m=0}")#text(" and ")#mi("{\\varepsilon=1/2}")#text("), we conclude that ")#mi("{g}")#text(" has a removable singularity and is thus in particular bounded on (say) the disk ")#mi("{D(0,e^{-3})}")#text(". From ")#link(<tao-cd8afab5b1562accac66>)[#text("(19)")]#text(" we conclude that ")#mi("{G(z)-\\frac{kz}{2\\pi i}}")#text(" is bounded on the region ")#mi("{\\{ z: \\mathrm{Re}(z) \\geq 2 \\}}")#text("; since ")#mi("{F(z) = \\exp(2\\pi i G(z))}")#text(", we conclude that ")#mi("{F(z) e^{-kz}}")#text(" is also bounded on this region. Since ")#mi("{F(z) = f(\\exp(-z))}")#text(", we conclude that ")#mi("{f(z) z^k}")#text(" is bounded on ")#mi("{D(0,e^{-3}) \\backslash \\{0\\}}")#text(", and thus by Riemann’s theorem (Exercise 37 from ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(") has a removable singularity at the origin. But by taking Laurent series, this implies that ")#mi("{f}")#text(" has a pole of order at most ")#mi("{k}")#text(" at the origin, contradicting the hypothesis that the singularity of ")#mi("{f}")#text(" at the origin was essential. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 58 (Montel’s theorem)")]#text(" Let ")#mi("{U}")#text(" be an open subset of the complex plane. Define a ")#link("https://en.wikipedia.org/wiki/Normal_family")[#text("holomorphic normal family")]#text(" on ")#mi("{U}")#text(" to be a collection ")#mi("{{\\mathcal F}}")#text(" of holomorphic functions ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" with the following property: given any sequence ")#mi("{f_n}")#text(" in ")#mi("{{\\mathcal F}}")#text(", there exists a subsequence ")#mi("{f_{n_j}}")#text(" which is uniformly convergent on compact sets (i.e., for every compact subset ")#mi("{K}")#text(" of ")#mi("{U}")#text(", the sequence ")#mi("{f_{n_j}}")#text(" converges uniformly on ")#mi("{K}")#text(" to some limit). Similarly, define a ")#emph[#text("meromorphic normal family")]#text(" to be a collection ")#mi("{{\\mathcal F}}")#text(" of meromorphic functions ")#mi("{f: U \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" such that for any sequence ")#mi("{f_n}")#text(" in ")#mi("{{\\mathcal F}}")#text(", there exists a subsequence ")#mi("{f_{n_j}: U \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" that are uniformly convergent on compact sets, using the metric on the Riemann sphere induced by the identification with the geometric sphere ")#tao-math("{\\{ (z,t) \\in {\\bf C} \\times {\\bf R}: \\left|z\\right|^2 + (t-1/2)^2 = 1/4\\}}", block: false)#text(". (More succinctly, normal families are those families of holomorphic or meromorphic functions that are precompact in the locally uniform topology.)")

#list(
[#text("(i) (")#link("https://en.wikipedia.org/wiki/Montel%27s_theorem")[#text("Little Montel theorem")]#text(") Suppose that ")#mi("{{\\mathcal F}}")#text(" is a collection of holomorphic functions ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" that are uniformly bounded on compact sets (i.e., for each compact ")#mi("{K \\subset U}")#text(" there exists a constant ")#mi("{C_K}")#text(" such that ")#tao-math("{\\left|f(z)\\right| \\leq C_K}", block: false)#text(" for all ")#mi("{f \\in {\\mathcal F}}")#text(" and ")#mi("{z \\in K}")#text("). Show that ")#mi("{{\\mathcal F}}")#text(" is a holomorphic normal family. (")#emph[#text("Hint:")]#text(" use the higher order Cauchy integral formula to establish some ")#link("https://en.wikipedia.org/wiki/Equicontinuity")[#text("equicontinuity")]#text(" on this family on compact sets, then use the ")#link("https://en.wikipedia.org/wiki/Arzel%C3%A0%E2%80%93Ascoli_theorem")[#text("Arzelá-Ascoli theorem")]#text(".")],
[#text("(ii) (")#link("https://en.wikipedia.org/wiki/Montel%27s_theorem")[#text("Great Montel theorem")]#text(") Let ")#mi("{z_0,z_1,z_2 \\in {\\bf C} \\cup \\{\\infty\\}}")#text(" be three distinct elements of the Riemann sphere, and suppose that ")#mi("{{\\mathcal F}}")#text(" is a family of meromorphic functions ")#mi("{f: U \\rightarrow ({\\bf C} \\cup \\{\\infty\\}) \\backslash \\{z_0,z_1,z_2\\}}")#text(" which avoid the three points ")#mi("{z_0,z_1,z_2}")#text(". Show that ")#mi("{{\\mathcal F}}")#text(" is a meromorphic normal family. (")#emph[#text("Hint:")]#text(" use some elementary transformations to reduce to the case ")#mi("{z_0=0, z_1=1, z_2=\\infty}")#text(". Then, as in the proof of the Picard theorems, express each element ")#mi("{f}")#text(" of ")#mi("{{\\mathcal F}}")#text(" locally in the form ")#mi("{f = \\exp(2\\pi i \\cos(h))}")#text(" and use Bloch’s theorem to get some uniform bounds on ")#mi("{h^{\\prime}}")#text(".)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 59 (Harnack principle)")]#text(" Let ")#mi("{U}")#text(" be an open connected subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{u_n: U \\rightarrow {\\bf R}}")#text(" be a sequence of harmonic functions which is pointwise nondecreasing (thus ")#mi("{u_{n+1}(z) \\geq u_n(z)}")#text(" for all ")#mi("{z \\in U}")#text(" and ")#mi("{n \\geq 1}")#text("). Show that ")#mi("{\\sup_n u_n}")#text(" is either infinite everywhere on ")#mi("{U}")#text(", or is harmonic. (")#emph[#text("Hint:")]#text(" work locally in a disk. Write each ")#mi("{u_n}")#text(" on this disk as the real part of a holomorphic function ")#mi("{f_n}")#text(", and apply Montel’s theorem followed by the Hurwitz theorem to ")#mi("{e^{-f_n}}")#text(".) This result is known as ")#link("https://en.wikipedia.org/wiki/Harnack%27s_principle")[#text("Harnack’s principle")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 60")]

#list(
[#text("(i) Show that the function ")#tao-math("{z \\mapsto \\log\\left|z\\right|}", block: false)#text(" is harmonic on ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(" but has no harmonic conjugate.")],
[#text("(ii) Let ")#mi("{r>0}")#text(", and let ")#mi("{u: D(0,r) \\backslash \\{0\\} \\rightarrow {\\bf R}}")#text(" be a harmonic function obeying the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|u(z)\\right| \\leq C_1 \\log \\frac{1}{\\left|z\\right|} + C_2", block: true)]]

#text("for all ")#mi("{z \\in D(0,r) \\backslash \\{0\\}}")#text(" and some constants ")#mi("{C_1,C_2}")#text(". Show that there exists a real number ")#mi("{c}")#text(" and a harmonic function ")#mi("{w: D(0,r) \\rightarrow {\\bf R}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("u(z) = c \\log \\left|z\\right| + w(z)", block: true)]]

#text("for all ")#mi("{z \\in D(0,r)}")#text(". (")#emph[#text("Hint:")]#text(" one can find a conjugate of ")#mi("{u}")#text(" outside of some branch cut, say the negative real axis restricted to ")#mi("{B(0,r)}")#text(". Adjust ")#mi("{u}")#text(" by a multiple of ")#tao-math("{\\log \\left|z\\right|}", block: false)#text(" until the conjugate becomes continuous on this branch cut.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 61 (Local description of holomorphic maps)")]#text(" Let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a holomorphic function on an open subset ")#mi("{U}")#text(" of ")#mi("{{\\bf C}}")#text(", let ")#mi("{z_0}")#text(" be a point in ")#mi("{U}")#text(", and suppose that ")#mi("{f}")#text(" has a zero of order ")#mi("{n}")#text(" at ")#mi("{z_0}")#text(" for some ")#mi("{n \\geq 1}")#text(". Show that there exists a neighbourhood ")#mi("{V}")#text(" of ")#mi("{z_0}")#text(" in ")#mi("{U}")#text(" on which one has the factorisation ")#mi("{f(z) = g(z)^n}")#text(", where ")#mi("{g: V \\rightarrow {\\bf C}}")#text(" is holomorphic with a simple zero at ")#mi("{z_0}")#text(" (and hence a complex diffeomorphism from a sufficiently small neighbourhood of ")#mi("{z_0}")#text(" to a neighbourhood of ")#mi("{0}")#text("). Use this to give an alternate proof of the open mapping theorem (Theorem ")#link(<tao-6e839d21bedb0ea901a8>)[#text("38")]#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 62 (Winding number and lifting)")]#text(" Let ")#mi("{z_0 \\in {\\bf C}}")#text(", let ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C} \\backslash \\{z_0\\}}")#text(" be a closed curve avoiding ")#mi("{z_0}")#text(", and let ")#mi("{k}")#text(" be an integer. Show that the following are equivalent:")

#list(
[#text("(i) ")#mi("{W_{\\gamma}(z_0) = k}")#text(".")],
[#text("(ii) There exists a complex number ")#mi("{w}")#text(" and a curve ")#mi("{\\eta: [a,b] \\rightarrow {\\bf C}}")#text(" from ")#mi("{w}")#text(" to ")#mi("{w+2k\\pi i}")#text(" such that ")#mi("{\\gamma(t) = z_0 + \\exp(\\eta(t))}")#text(" for all ")#mi("{t \\in [a,b]}")#text(".")],
[#text("(iii) ")#mi("{\\gamma}")#text(" is homotopic up to reparameterisation as closed curves in ")#mi("{{\\bf C} \\backslash \\{z_0\\}}")#text(" to the curve ")#mi("{\\gamma_{z_0,r,m \\circlearrowleft}: [0,2\\pi] \\rightarrow {\\bf C} \\backslash \\{z_0\\}}")#text(" that maps ")#mi("{t}")#text(" to ")#mi("{z_0 + r e^{imt}}")#text(" for some ")#mi("{r>0}")#text(".")]
)
]

#heading(level: 1)[#text("Comments (179)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-3/#comment-643466")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2022")])]

#text("In theorem 12, is ")#mi("U")#text(" assumed to be an open subset of ")#mi("{\\bf C}")#text(" or the Riemann sphere ")#mi("{\\bf C}\\cup\\{\\infty\\}")#text("? Or for arbitrary Riemann surfaces? ")#emph[#text("[In ")#mi("{\\bf C}")#text(", since the Riemann sphere or other Riemann surfaces have not been introduced yet. However, it is not difficult to extend this theorem to those settings by using appropriate coordinate charts. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-3/#comment-643475")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2022")])]

#text("Typo in")

#text("… we see that ")#mi("{F}")#text(" has an antiderivative in this punctured disk, namely")#linebreak()#text(" ")#mi("\\displaystyle  G(z) := \\sum_{n=0}^\\infty a_n \\frac{(z-z_0)^n}{n+1} + \\sum_{n=-\\infty}^{-2} a_n \\frac{(z-z_0)^n}{n+1}")

#text("The exponent on ")#mi("(z-z_0)")#text(" is ")#mi("n+1")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-3/#comment-643476")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2022")])]

#mi("\\sum_{n=-\\infty}^{-2}")#text(" is funny abuse of notation… (index ")#mi("n")#text(" cannot be ")#mi("-\\infty")#text("; one can parse what that means though.)")

#emph[#text("[This is a natural variation of the same notation used for other infinite sums such as ")#mi("\\sum_{n=1}^\\infty a_n")#text(". -T]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-497892")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2018")])]

#text("In the definition 14 and 17，if a function f is said to be smooth or holomorphic, then should every f^{-1}(U’_β)∩U_α be open? if f can’t ensure every f^{-1}(U’_β)∩U_α to be open , then f can’t be said to be smooth or holomorphic ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-497901")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2018")])]

#text("As ")#mi("f")#text(" is a homeomorphism, the sets ")#mi("f^{-1}(U^{\\prime}_\\beta)")#text(" and hence ")#mi("f^{-1}(U^{\\prime}_\\beta) \\cap U_\\alpha")#text(" will be open.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-497946")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2018")])]

#text("In the definition 14 and 17, when you define a smooth or holomorphic function f:M->M’ from one topological space M to another M’, you don’t require f should be homemorphism or even continuous on M. I try proving that a smooth or holomorphic function as you defined in definition 14 and 17 is continuous on M, and find this proof requires every f^{-1}(U’_β)∩U_α to be open. So I have that trivial problem.(i.e. if f can’t ensure every f^{-1}(U’_β)∩U_α to be open , then f can’t be said to be smooth or holomorphic ?) , if f can be holomorphic or smooth without ensuring every f^{-1}(U’_β)∩U_α to be open, then f can be holomorphic or smooth but not continuous on M.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-498049")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2018")])]

#text("Thanks for pointing this out. I’ve added the hypothesis of continuity to both definitions.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f23128c9c4c88c5ee0832947d12d346d0127323bb71f4b582223821aae2b2e79-03bdfc4ab7cb7805533053cfb7f951e30c17f66b4b609f9d8dbf95242e59292b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Weibo Shu")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-498094")[#strong[#text("Weibo Shu")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2018")])]

#text("Thanks for your reply, It’s my pleasure to do this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-498474")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2018")])]

#text("In chapter 4 of Wolff’s Harmonic analysis notes, in calculating the Fourier transform of")

#tao-math("\\displaystyle h_a(x) = \\frac{\\Gamma(a/2)}{\\pi^{a/2}} \\left|x\\right|^{-a},\\quad x\\in{\\bf R}^n", block: false)

#text("where ")#mi("0<Re(a)<n")#text(", one ends up with showing that the map")

#tao-math("\\displaystyle z\\mapsto \\int \\left|x\\right|^{-z}\\phi(x)\\ dx\\quad \\phi\\in\\mathcal{S}({\\bf R}^n)", block: false)

#text("is holomorphic. How can one estimate the integral")

#mi("\\displaystyle \\int A_{h,z}(x)\\phi(x)\\ dx")#linebreak()#text(" where")#linebreak()#text(" ")#tao-math("\\displaystyle A_{h,z}(x) = \\frac{1}{h}[\\left|x\\right|^{-(z+h)}-\\left|x\\right|^{-z}]", block: false)#linebreak()#text(" so that one can take complex differentiation under the integral sign? Does one have")

#tao-math("\\displaystyle \\left\\|\\frac{d}{dz}\\left|x\\right|^{-z}\\right\\|_\\infty<\\infty?", block: false)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-498533")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2018")])]

#text("Generally speaking, to show that an integral expression is holomorphic, it is easiest to proceed using Morera’s theorem, rather than differentiation under the integral sign, as it is easier to interchange integrals than to interchange a derivative and an integral.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-498586")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2018")])]

#text("Thanks for the comment. I think I see your point of using Moreara’s theorem: one can use Fubini’s theorem and the fact that the map ")#tao-math("z\\mapsto \\left|x\\right|^{-z}", block: false)#text(" is analytic when ")#mi("x\\neq 0")#text(".")

#text("Is it still possible to exploit the differentiation approach? In this case,")

#tao-math("\\displaystyle \\frac{d}{dz}\\left|x\\right|^{-z} = \\frac{d}{dz}e^{-z \\log \\left|x\\right|} = -\\log\\left|x\\right|\\cdot e^{-z \\log \\left|x\\right|}.", block: false)

#text("Since ")#mi("Re(z)>0")#text(", one can expect a bound (on ")#mi("{\\bf R}")#text(") of the map")

#tao-math("\\displaystyle x\\mapsto -\\log\\left|x\\right|\\cdot e^{-z \\log \\left|x\\right|}", block: false)#text(".")

#text("But this seems to be rather useless for bounding the difference quotient ")#mi("A_{h,z}(x)")#text(" since mean value theorem is not necessarily true for complex-valued functions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-498851")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2018")])]

#text("In Wolff’s notes (chapter 4), he pointed out that the analyticity of")

#tao-math("\\displaystyle  z\\mapsto \\int \\left|x\\right|^{-z}\\phi(x)\\ dx", block: false)

#text("“may be done by using the dominated convergence theorem to justify complex differentiation under the integral sign.” Hardly can I guess how he did it.")

#text("This seems to be a bit different from the “compilation errors” mentioned in the advice (")#link("https://plus.google.com/u/0/+TerenceTao27/posts/TGjjJPUdJjk")[#text("https://plus.google.com/u/0/+TerenceTao27/posts/TGjjJPUdJjk")]#text(")")#linebreak()#text(" since it is very unlikely (in the notes) that the author would come back to discuss this little step.")

#text("One can take this for granted (or give an alternative proof) though, it is quite “frustrating” to read ahead without really knowing what the author intended to say in such a small step. And it seems that this is a type of “runtime exception” that is not mentioned in the advice (")#link("https://plus.google.com/u/0/+TerenceTao27/posts/TGjjJPUdJjk")[#text("https://plus.google.com/u/0/+TerenceTao27/posts/TGjjJPUdJjk")]#text(").")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-601942")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2020")])]

#text("While “contour integrals” is understood as complex integrals for continuous curves in notes 2, the term “contours” refers to the piecewise smooth curves. Does “contour” simply mean “continuous curves” in Lemma 1 (and various other places in this set of notes)?")

#emph[#text("[Yes; wording has now been changed to reflect this – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-602153")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2020")])]

#text("Yes, it doesn’t need to be rectifiable.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Image crop error")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-602601")[#strong[#text("Image crop error")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2020")])]

#text("I think that the a portion (towards the right) of first image in the section on Laurent series gets cropped out. Also pulling the image using cursor works.")

#emph[#text("[Now corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-605807")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2020")])]

#text("Is the topology on ")#mi("{\\bf C}\\cup\\{\\infty\\}")#text(" the same as the subspace topology of the unit sphere in ")#mi("{\\bf R}^3")#text("? Is there any advantage of using the definition of one point compactification in this note?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-605813")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2020")])]

#text("Yes, once one sets up the appropriate stereographic projection, one can show that the Riemann sphere ")#mi("{\\bf C} \\cup \\infty")#text(" is homeomorphic to a round sphere in ")#mi("{\\bf R}^3")#text(" with the subspace topology. This is certainly one very useful model for the Riemann sphere, as it allows one to use one’s existing geometric intuition about round spheres to understand the Riemann sphere. However, it makes the coordinate charts on the sphere moderately complicated (one has to invert the stereographic projection). The model ")#mi("{\\bf C} \\cup \\infty")#text(" of the Riemann sphere based on the one-point compactification of ")#mi("{\\bf C}")#text(" is more convenient for many algebraic calculations due to the simplicity of the coordinate charts (they are just given by ")#mi("z \\mapsto z")#text(" and ")#mi("z \\mapsto 1/z")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-605837")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2020")])]

#text("Last day prof. Tao posed the problem of finding an open map that is not continuous.")

#text("We notice that if we can construct a map ")#mi("f: \\mathbf{R} \\to \\mathbf{R}")#text(" such that ")#mi("f")#text(" is not continuous, but for any non-empty open interval ")#mi("(x,y) \\in \\mathbf{R}")#text(" (with ")#mi("x < y")#text(") we have ")#mi("f[(x,y)] := \\{ f(z) ~ : ~ z \\in (x,y) \\} = \\mathbf{R},")#text(" then we are done (since any open set in ")#mi("\\mathbf{R}")#text(" can be written as a union of open intervals).")

#text("One way to construct such functions is to play around with the expressions of reals in base 10 or other bases.")

#text("I wonder if we can find an explicit expression for such a function which is open but not continuous.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-605856")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2020")])]

#text("In Definition 17,")

#text("when defining the holomorphicity of a map between manifolds:")

#emph[]

#text("… the maps ")#mi("{\\phi^{\\prime}_\\beta \\circ f \\circ \\phi_\\alpha: \\phi_\\alpha^{-1}( f^{-1}(U^{\\prime}_\\beta) \\cap U_\\alpha ) \\rightarrow V_\\beta}")#text(" are holomorphic")

#text("Is there a typo there? I think the map should be")

#mi("{\\phi^{\\prime}_\\beta \\circ f \\circ \\phi_\\alpha^{-1}: \\phi_\\alpha( f^{-1}(U^{\\prime}_\\beta) \\cap U_\\alpha ) \\rightarrow V_\\beta}")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-605859")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2020")])]

#text("and ")#mi("V_\\beta")#text(" should be ")#mi("V_\\beta^{\\prime}")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-605860")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2020")])]

#text("In Exercise 45, how does one interpret ")#mi("\\lim_{\\varepsilon\\to0, R\\to\\infty}")#text("? Is it ")#mi("\\lim_{\\varepsilon\\to0}\\lim_{R\\to\\infty}")#text(", ")#mi("\\lim_{R\\to\\infty}\\lim_{\\varepsilon\\to0}")#text(", or something else?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ef416d4d65005c8c948ba1d552bca5b19817468eb0dee8254d21e31a58194c6-223b876ebec382062e2d73b2f69e1cb83720cbf9b4506b21b5e50432ab15b78f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-605863")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2020")])]

#text("It should be understood as a joint limit: saying that ")#mi("\\lim_{\\varepsilon\\to 0,R\\to\\infty}f(\\varepsilon,R)=c")#text(" is defined as saying ")#mi("\\forall\\delta>0\\exists\\varepsilon_0>0,R_0>0")#text(" such that ")#mi("\\forall 0<\\varepsilon\\leq\\varepsilon_0,R\\geq R_0")#text(" we have ")#tao-math("\\left|f(\\varepsilon,R)-c\\right|<\\delta", block: false)#text(". – Ben")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-606036")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2020")])]

#text("Can the discrete set ")#mi("S")#text(" in Exercise 18 be infinite? (Exercise 19 seems to suggest that it should be finite.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ef416d4d65005c8c948ba1d552bca5b19817468eb0dee8254d21e31a58194c6-223b876ebec382062e2d73b2f69e1cb83720cbf9b4506b21b5e50432ab15b78f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-606046")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2020")])]

#mi("S")#text(" can be infinite in the setting of Exercise 18; for example, we could have ")#tao-math("U=\\{z\\in\\mathbb{C}:\\left|z\\right|<1\\}", block: false)#text(" and ")#mi("S=\\{1-\\frac{1}{n}:n\\in\\mathbb{N}\\}")#text(". In general, discrete sets are characterized by not having any accumulation points inside the ambient space. The notion of \"ambient space\" is important here: while ")#mi("S")#text(" above doesn't have any accumulation points in ")#mi("U")#text(", it does accumulate in ")#mi("\\mathbb{C}")#text(" (namely, to the point ")#mi("1")#text(").")

#text("In the setting of Exercise 19, ")#mi("S")#text(" will always be finite, because the (sequential) compactness of ")#mi("\\mathbb{C}\\cup\\{\\infty\\}")#text(" implies that all infinite subsets have an accumulation point. – Ben")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-606055")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2020")])]

#text("In the “Laurent expansion” in the definition of residue of ")#mi("f")#text(" at ")#mi("z_0")#text(", there are several interpretations of the double-sided sum ")#mi("\\sum_{-\\infty}^{\\infty}")#text(". Does one have the absolute convergence there so that all the interpretations are equivalent or the double-sided sum refers to a particular limit?")

#emph[#text("[Yes, one has absolute convergence of the doubly infinite series near the singularity; see the comments after (4). -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ef416d4d65005c8c948ba1d552bca5b19817468eb0dee8254d21e31a58194c6-223b876ebec382062e2d73b2f69e1cb83720cbf9b4506b21b5e50432ab15b78f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-606119")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2020")])]

#text("The series does converge absolutely on the punctured disk ")#mi("D(z_0,r)\\setminus\\{z_0\\}")#text(". – Ben")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-606144")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2020")])]

#text("The absolute convergence region for the series is (generally) for an annular region whose inner radius may be positive (not necessarily zero as for the particular case of the punctured disk example.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-606099")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2020")])]

#text("Can one define the contour integral of functions on the Riemann sphere so that the interior and exterior residue theorems are unified as one theorem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ef416d4d65005c8c948ba1d552bca5b19817468eb0dee8254d21e31a58194c6-223b876ebec382062e2d73b2f69e1cb83720cbf9b4506b21b5e50432ab15b78f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-606117")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2020")])]

#text("For integrating over Riemann surfaces, one has to consider instead the integral of the one-form ")#mi("f(z)dz")#text(" instead of the integral of the function ")#mi("f(z)")#text(". One can reformulate the notion of residue to work for holomorphic one-forms (whereby our definition of residue is understood as the residue of ")#mi("f(z)dz")#text(", obtained by multiplying ")#mi("f")#text(" by the canonical choice of one-form in ")#mi("\\mathbb{C}")#text(", ")#mi("dz")#text("). Reformulating the discussion as such, the interior and exterior theorems are equivalent. – Ben")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d3db63a14499f515e659279e4d35701a2819662249f41df9f4908f0563d2650-23e80627858ab164099d57cb25de32406797962ca1136188a4ab103d85291853.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chaikens")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-606136")[#strong[#text("chaikens")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2020")])]

#text("Typo in the uniqueness proof of the lifting lemma: ")#mi("\\Omega")#text(" is clearly closed in ")#mi("U")#text(" (not $latex N)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-606167")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2020")])]

#text("In Corollary 33, is the statement still true if ")#mi("f")#text(" is only separately continuous in ")#mi("t")#text(" and ")#mi("z")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-606339")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2020")])]

#text("I think it is false. A near-example is provided by ")#mi("f(s,z) = \\frac{z-\\gamma(s)}{z-1/\\overline{\\gamma(s)}}")#text(", ")#mi("0 \\leq s < 1")#text(" where ")#mi("\\gamma")#text(" is a curve in ")#mi("D(0,1)")#text(" that approaches a boundary point non-tangentially, so that the pointwise limit is ")#mi("f(1,z) = 1")#text(", and the zero at ")#mi("\\gamma(s)")#text(" inside the disk disappears in the limit. These functions have poles just outside the unit disk and so this isn't directly a counterexample, but I believe if one replaces each ")#mi("f(s,\\cdot)")#text(" with a Taylor series approximation (where the order of approximation goes to infinity as ")#mi("s \\to 1")#text(") one should be able to build a suitable counterexample.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-606516")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2020")])]

#text("In the Proof of Lemma 49, when proving the monodromy is path-independent, should")

#emph[#linebreak()#text(" in particular, the map ")#mi("{b \\rightarrow \\tilde \\gamma_s(b)}")#text(".")#linebreak()#text(" ")]

#text("be “… ")#mi("{s \\rightarrow \\tilde \\gamma_s(b)}")#text("“?")

#text("In the definition of the lifted map:")

#emph[#linebreak()#text(" for which there exists a curve ")#mi("{\\tilde \\gamma_{[a,t]}: [a,t] \\rightarrow M}")#text(" such that ")#mi("{f \\circ \\tilde \\gamma_{[a,t]} = g \\circ \\gamma_{[a,t]}}")#linebreak()#text(" ")]

#text("is the condition ")#mi("\\tilde \\gamma_{[a,t]}(a)=p")#text(" missing?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-607223")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2020")])]

#text("This may just be a pedantic comment.")

#text("The symbol ")#mi("\\log")#text(" is used for the multivalued complex logarithm while ")#mi("\\ln")#text(" is used for the real logarithm. But throughout the proof of Theorem 56, ")#mi("\\log")#text(" is used when it really means ")#mi("\\ln")#text(".")

#text("(Maybe it is just a (confusing) “convention” that when the input ")#mi("z")#text(" is a positive real number, the expression “")#mi("\\log z")#text("” is considered the same as ")#mi("\\ln z")#text(".)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-607538")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2020")])]

#text("In the proof of Great Picard,")

#emph[#linebreak()#text(" … the function ")#mi("{G(z)-\\frac{kz}{2\\pi i}}")#text(" is periodic with period ")#mi("{2\\pi i}")#text(" on the right half-plane, we may write")]

#mi("\\displaystyle  G(z) - \\frac{k z}{2\\pi i} = g( \\exp( -z ) ) \\ \\ \\ \\ \\ (19)")

#text("for some function ")#mi("{g: D(0,1) \\backslash \\{0\\} \\rightarrow {\\bf C}}")#text(",")#linebreak()

#text("I see why periodicity is necessary for the factorization in (19), why is it sufficient?")

#text("Also, why is ")#mi("D(0,1)")#text(" the domain of ")#mi("g")#text("?")

#emph[#text("[The domain has been corrected to ")#mi("D(0,e^{-2})")#text(". One can use (19) as a definition of ")#mi("g")#text(", namely ")#mi("g(w) = G(z) - \\frac{kz}{2\\pi i}")#text(" whenever ")#mi("w = \\exp(-z)")#text(", or equivalently ")#mi("z = -\\log w")#text("; the periodicity of the RHS counteracts the multiplicity of the logarithm. Using branches of the logarithm one can verify that ")#mi("g")#text(" is holomorphic. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-607539")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2020")])]

#text("And should “on the right half-plane” be ")#mi("\\{\\textrm{Re}z>2\\}")#text("?")

#emph[#text("[Corrected, thanks, -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-607549")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2020")])]

#text("In the last sentence of the proof of Great Picard,")

#emph[#linebreak()#text(" this implies that ")#mi("{f}")#text(" has a pole of order at most ")#mi("{k}")#text(" at the origin…")#linebreak()#text(" ")]

#mi("{k}")#text(" should be ")#tao-math("\\left|{k}\\right|", block: false)#text(" since it could be negative?")

#emph[#text("[Here I am viewing a pole of negative order as a zero of the opposite order – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iota")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-608145")[#strong[#text("Iota")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2020")])]

#text("Prof. Tao")#linebreak()#text(" In reference to the sentence “In this set of notes we shall only consider interior singularities…….”, can you mention some places where other types of singularities are studied or appear.")

#emph[#text("[See e.g., ")#link("https://mathworld.wolfram.com/NaturalBoundary.html")[#text("https://mathworld.wolfram.com/NaturalBoundary.html")]#text(" -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-608574")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2020")])]

#text("In the proof of Lemma 1,")#linebreak()#text(" ")#emph[#linebreak()#text(" … From Exercise 36 of Notes 3 we see that ")#mi("{f_1}")#text(" is holomorphic.")#linebreak()#text(" ")]

#text("In the case when ")#mi("\\gamma_1")#text(" (similarly for ")#mi("\\gamma_2")#text(") is smooth (or piecewise smooth), one can write the integral in the definition of ")#mi("f_1")#text(" on ")#mi("\\text{int}(\\gamma_1)")#text(" as (by Ex16(iv) of Notes 2)")

#mi("\\displaystyle \\int_0^1\\frac{f(\\gamma_1(t))}{\\gamma_1(t)-z}\\gamma_1^{\\prime}(t)\\;dt")

#text("so that one can then apply Exercise 36 of Notes 3.")

#text("In the case when ")#mi("\\gamma_1")#text(" is only rectifiable, can one still use Exercise 36 of Notes 3?")

#text("If one wants to directly use the “Cauchy+Fubini+Morera” strategy in the proof of Exercise 36 of Notes 3, then one needs a version of “Fubini” that allows something like")

#mi("\\displaystyle \\int_{\\delta}\\int_\\gamma F(w,z)dwdz=\\int_\\gamma\\int_{\\delta} F(w,z)dzdw")

#text("In 245A Notes 6, it takes quite an amount of time to establish the Fubini theorem. Does one have a convenient way to convert the integral above in the setting of Lebesgue integrals so that one can indeed use the Fubini theorem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-608622")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2020")])]

#text("The simplest thing to do here is to first use Cauchy’s theorem to temporarily deform ")#mi("\\gamma_1")#text(" to a polygonal path so that Exercise 36 can be applied; I’ve adjusted the notes accordingly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-608690")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2020")])]

#text("In Exercise 13:")

#emph[#linebreak()#text(" … Hint: use Lemma 4 and a limiting argument to evaluate the Laurent coefficients ")#mi("{a_n}")#text(" for ")#mi("{n \\leq -1}")#text(".")#linebreak()#text(" ")]

#text("There is no Lemma 4 in the notes. It probably refers to something else?")

#emph[#text("[Corrected to Exercise 4 – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-608850")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2020")])]

#text("In Definition 14,")#linebreak()#text(" ")#emph[#linebreak()#text(" Two smooth atlases on ")#mi("{M}")#text(" are said to be equivalent if the identity map from ")#mi("{M}")#text(" (equipped with one of the two atlases) to ")#mi("{M}")#text(" (equipped with the other atlas) is a diffeomorphism;")#linebreak()#text(" ")]

#text("Is it sufficient to define the notion of equivalent atlases by requiring only that the identity above is smooth (instead of a diffeomorphism)?")

#text("(In other words, is it sufficient to say that ")#mi("\\phi_\\beta^{\\prime}\\circ \\phi_\\alpha^{-1}:\\phi_\\alpha(U_\\alpha\\cap U_\\beta^{\\prime})\\to V_\\beta^{\\prime}")#text(" is smooth for all ")#mi("\\alpha,\\beta")#text("?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-608889")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2020")])]

#text("No. For instance, consider the line ")#mi("M = {\\bf R}")#text(" with two different smooth structures: one coming from the standard coordinate chart ")#mi("\\phi: M \\to {\\bf R}")#text(" given by ")#mi("\\phi(x) = x")#text(" and the other coming from an exotic coordinate chart ")#mi("\\phi^{\\prime}: M \\to {\\bf R}")#text(" given by ")#mi("\\phi^{\\prime}(x) = x^3")#text(". Then the identity map from ")#mi("M")#text(" with the first structure to ")#mi("M")#text(" with the second is smooth, but the inverse is not smooth, so the two smooth structures are not equivalent.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-608920")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2020")])]

#text("I’m a bit confused with the notions of “atlases” and “smooth structures” in Definition 14. There seem to be different levels of equivalences.")

#text("Given a topological space ")#mi("M")#text(", one can have different “atlases”, say, ")#mi("\\mathcal{A}=\\{\\phi_\\alpha:U_\\alpha\\to V_\\alpha\\}")#text(" and ")#mi("\\mathcal{A}^{\\prime}=\\{\\phi_\\alpha^{\\prime}:U_\\alpha^{\\prime}\\to V_\\alpha^{\\prime}\\}")#text(".")

#text("If the *identity map* ")#mi("\\text{id}:(M,\\mathcal{A})\\to (M,\\mathcal{A}^{\\prime})")#linebreak()#text(" is a diffeomorphism, then we say that ")#mi("\\mathcal{A}")#text(" and ")#mi("\\mathcal{A}^{\\prime}")#text(" are equivalent “atlases”.")

#text("On the other hand, if one puts all the atlases that are equivalent to ")#mi("\\mathcal{A}")#text(" together, and denote the equivalent class as ")#mi("[\\mathcal{A}]")#text(", then ")#mi("[\\mathcal{A}]")#text(" is one smooth “structure” on ")#mi("M")#text(".")

#text("If we have two smooth “structures” on ")#mi("M")#text(", we can then ask if the two structures are “equivalent”.")

#text("If there exists a diffeomorphism ")#mi("f:(M,\\mathcal{A})\\to (M,\\mathcal{B})")#text(", then the two smooth structures, ")#mi("[\\mathcal{A}]")#text(" and ")#mi("[\\mathcal{B}]")#text(" are equivalent.")

#text("So it is possible that ")#mi("\\mathcal{A}")#text(" and ")#mi("\\mathcal{B}")#text(" are not equivalent “atlases”, but the two smooth structures, ")#mi("[\\mathcal{A}]")#text(" and ")#mi("[\\mathcal{B}]")#text(" can still be equivalent. Correct?")

#text("It seems that in Definition 14 (and similarly Definition 17), only “equivalent atlases” are defined, but not “equivalent smooth structures” (at least not explicitly). The former uses the identity map, while the latter needs only the existence of a diffeomorphism.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-608995")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2020")])]

#text("There is no notion of “equivalent smooth structures”. There are “equal smooth structures” and “diffeomorphic smooth structures”.")

#text("Two smooth manifolds ")#mi("({\\mathcal M}, [{\\mathcal A}])")#text(", ")#mi("({\\mathcal M}, [{\\mathcal B}])")#text(" are equal as smooth manifolds iff the underlying base manifold ")#mi("{\\mathcal M}")#text(" is the same and two representative atlases ")#mi("{\\mathcal A}, {\\mathcal B}")#text(" are equivalent.")

#text("Two smooth manifolds ")#mi("({\\mathcal M}, [{\\mathcal A}])")#text(", ")#mi("({\\mathcal N}, [{\\mathcal B}])")#text(" are diffeomorphic if there is an invertible map ")#mi("f: {\\mathcal M} \\to {\\mathcal N}")#text(" such that ")#mi("f, f^{-1}")#text(" are smooth maps between the smooth manifolds (which is equivalent to ")#mi("f: ({\\mathcal M}, {\\mathcal A}) \\to ({\\mathcal N}, {\\mathcal B})")#text(", ")#mi("f^{-1}: ({\\mathcal N}, {\\mathcal B}) \\to ({\\mathcal M}, {\\mathcal A})")#text(" being smooth maps for two representative atlases ")#mi("{\\mathcal A}, {\\mathcal B}")#text(".")

#text("In the example I provided in a different comment, ")#mi("({\\mathcal M}, [{\\mathcal A}])")#text(" and ")#mi("({\\mathcal M}, [{\\mathcal A}^{\\prime}])")#text(" are not the same smooth manifold, but they are diffeomorphic (using a non-identity map such as ")#mi("\\phi^{\\prime}")#text(" or ")#mi("(\\phi^{\\prime})^{-1}")#text(" to provide the diffeomorphism). On the other hand it does not make sense to ask whether the two smooth manifolds are “equivalent”.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-609095")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2020")])]

#text("Thanks for the clarification.")

#emph[#linebreak()#text(" There is no notion of “equivalent smooth structures”.")#linebreak()#text(" ")]

#text("Well, you said in the ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/#comment-608889")[#text("previous comment")]#text(" that “… so the two smooth structures are not equivalent”")#linebreak()#text(" (now I see you may just mean to say that they are not the same smooth manifold.)")

#text("Moreover, it seems that people do use the notion of “equivalent smooth structures” sometime: ")#link("https://en.wikipedia.org/wiki/Smooth_structure#Equivalence_of_smooth_structures")[#text("https://en.wikipedia.org/wiki/Smooth_structure#Equivalence_of_smooth_structures")]

#text("The Wikipedia page phrases the John Milnor result as “the 7-dimensional sphere admits a ")#emph[#text("smooth structure that is not equivalent to the standard smooth structure")]#text(".”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-643142")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2022")])]

#text("Could you elaborate on your comment why “it does not make sense to ask whether the two smooth manifolds are ‘equivalent'”?")

#text("I am a bit confused with the discussion of this thread here. Does it make sense to say the ")#emph[#text("set")]#text(" of all “smooth manifolds” ")#mi("(\\mathcal{M},[\\mathcal{A}])")#text("? Or is it only a ")#link("https://en.wikipedia.org/wiki/Class_(set_theory)")[#text("“proper class”")]#text("?")

#text("If one defines a relation ")#mi("\\sim")#text(" on the mentioned collection above such that ")#mi("({\\mathcal M}, [{\\mathcal A}])\\sim({\\mathcal N}, [{\\mathcal B}])")#text(" if and only if ")#mi("({\\mathcal M}, [{\\mathcal A}])")#text(" and ")#mi("({\\mathcal N}, [{\\mathcal B}])")#text(" are diffeomorphic (as in the penultimate paragraph of the comment), is this an equivalence relation?")

#text("This seems to be similar to asking whether (linear) isomorphism is an equivalence relation on the collection of all vector spaces, or where homomorphism is an equivalence relation on the collection of all topological spaces.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-643365")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2022")])]

#text("In my previous comment I defined two notions: equality of two smooth manifolds, and the relation that two smooth manifolds are diffeomorphic. If one wishes, one could declare “equivalence” of smooth manifolds to be one of these two options, but there does not appear to be any natural third option one could take to define this concept.")

#text("Technically, as you say, the relation of diffeomorphism is defined on a proper class (the class of smooth manifolds) rather than a set, but it still functions as an equivalence relation for pretty much all mathematical purposes (and if one limits to manifolds that are connected (or have some upper bound on the cardinality of connected components), the moduli space of smooth manifolds modulo diffeomorphism will be an actual set).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-608921")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2020")])]

#text("I just submitted a long comment. But I don’t know why it disappears.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-608923")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2020")])]

#text("So in your example, ")#mi("\\mathcal{A}=\\{\\phi:M\\to{\\bf R}\\}")#text(" and ")#mi("\\mathcal{A}^{\\prime}=\\{\\phi^{\\prime}:M\\to{\\bf R}\\}")#text(" are not equivalent atlases since the identity map ")#mi("\\text{id}:(M,\\mathcal{A})\\to(M,\\mathcal{A}^{\\prime})")#text(" is not a diffeomorphism (the inverse is not smooth).")

#text("But ")#mi("[\\mathcal{A}]")#text(" and ")#mi("[\\mathcal{A}^{\\prime}]")#text(" are two equivalent “smooth structures” since")#linebreak()#text(" ")#mi("(\\phi^{\\prime})^{-1}:(M,\\mathcal{A})\\to(M,\\mathcal{A}^{\\prime})")#text(" is a diffeomorphism (between manifolds). Correct?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-608890")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2020")])]

#text("In the definition of the topology on the Riemann sphere, what is the motivation of using ")#mi("({\\bf C}\\cup\\{\\infty\\})\\setminus K")#text(" (with ")#mi("K")#text(" compact in ")#mi("{\\bf C}")#text(") as open sets?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-608891")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2020")])]

#text("I think that helps us to avoid any ambiguity arising out of bounded-unboundedness.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-608990")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2020")])]

#text("This is the smallest possible enlargement of the space ")#mi("{\\bf C}")#text(" that preserves the topology of the subspace ")#mi("{\\bf C}")#text(" and which turns the space into a compact Hausdorff space; it is a special case of the ")#link("https://en.wikipedia.org/wiki/Alexandroff_extension")[#text("one-point compactification")]#text(" (or Alexandroff compactification).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-609039")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2020")])]

#text("Ah yes ! This subtle point was touched upon during the lectures. How bad that I forgot it !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-609161")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2020")])]

#text("The open interval ")#mi("(0,1)")#text(" has a compactification ")#mi("[0,1]")#text(", which gives another compactification for ")#mi("{\\bf R}")#text(" than ")#mi("{\\bf R}\\cup{\\infty}")#text(". Similarly one can consider the closed unit disk for ")#mi("{\\bf C}")#text(" as another compactification, or the closed upper-half complex plane. Are other compactifications less useful than the Riemann sphere when studying meromorphic functions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-609164")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2020")])]

#text("These are topological compactifications of the plane, but they are not Riemann surface compactifications (note that the disk and half-plane are merely homeomorphic to the plane, rather than being complex diffeomorphic to the plane). The Riemann sphere is the only compact Riemann surface that contains a copy of the complex plane as an open dense subset, though I don’t know of an elementary way to prove this (not using, for instance Riemann-Roch).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-608911")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2020")])]

#text("In Def 8, the singular set ")#mi("S")#text(" is required to be closed in ")#mi("U")#text(" while the assumptions in Exercise 18 do not explicitly state so. (So one implicitly assumes that ")#mi("S")#text(" is closed in ")#mi("U")#text(" if one says ")#mi("f:U\\setminus S\\to{\\bf C}")#text(" is meromorphic?)")

#emph[#text("[Yes, holomorphic and meromorphic functions are only defined on open domains in this series of notes. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-609686")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2020")])]

#text("In the proof of the Residue theorem (Theorem 21),")

#emph[#linebreak()#text(" The absolute convergence of the series on the right-hand side in ")#mi("{D(z_0,r)}")#text(" can be seen from the comparison test.")#linebreak()#text(" …")#linebreak()#text(" Also, for any ")#mi("{z_0 \\in K}")#text(" that is not in ")#mi("{S \\cap K}")#text(", we see from Cauchy’s theorem that ")#mi("{F}")#text(" is conservative on ")#mi("{D(z_0,r)}")#text(" for some radius ")#mi("{r>0}")#text(".")#linebreak()#text(" ")]

#text("Should both ")#mi("{D(z_0,r)}")#text(" above be ")#mi("{D(z_0,r) \\backslash \\{z_0\\}}")#text("?")

#emph[#text("[The first one yes; the second one no (note that when ")#mi("z_0 \\not \\in S")#text(" that all the negative coefficients in the Laurent series vanish) -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-609720")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2020")])]

#text("What “compactness argument” is the proof of Theorem 21 referring to?")

#text("In the proof of Corollary 13 (local Cauchy theorem), it is also said that “From compactness, there must exist a radius ")#mi("{r>0}")#text(" such that ")#mi("{D(\\gamma(s,t),r) \\subset U}")#text(" for all ")#mi("{s \\in [0,1]}")#text(" and ")#mi("{t \\in [a,b]}")#text(".”")

#text("(The image of the homotopy is compact, so it can always be covered by finitely many balls and one can then take the smallest radius ")#mi("r_0")#text(" and cover the bigger balls with finitely many balls of radius ")#mi("r_0")#text(" as well??)")

#text("How does one get the uniform radius ")#mi("r>0")#text(" and why one needs it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-609776")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2020")])]

#text("For each ")#mi("s,t")#text(", one can find a radius ")#mi("r_{s,t}>0")#text(" such that ")#mi("D(\\gamma(s,t),r_{s,t}) \\subset U")#text(". Now the disks ")#mi("D(\\gamma(s,t), r_{s,t}/2)")#text(" form an open cover of ")#mi("U")#text(", so one can find a finite subcover. Let ")#mi("r")#text(" be the smallest radius in this subcover, then one can check from the triangle inequality that ")#mi("D(\\gamma(s,t),r) \\subset U")#text(" for all ")#mi("s,t")#text(". The uniformity in ")#mi("r")#text(" is helpful in the proof of Corollary 13 of Notes 3 in order to ensure that all the quadrilateral curves ")#mi("C_{i,j}")#text(" are contained in a disk inside of ")#mi("U")#text("; if one only had the non-uniform disks ")#mi("D(\\gamma(s,t), r_{s,t})")#text(" it is not clear that one could ensure that every such ")#mi("C_{i,j}")#text(" was inside one of the disks. The situation is similar in Theorem 21.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a4e862e411af35c4243c9a9f9a79daefa671006463291d79788ac05b2913bf-988f1beec5199d6bf39fff81e0b3f82338377e1459b63d9eb92e510cfdf0d3a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-610631")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2020")])]

#text("Hello Sir,")

#text("In the Ex 26 (proof of fundamental thm of algebra using residue theorem) I have some problem.")

#text("In order to use residue theorem at first I assume that p(z) has no zero in large disk of radius R. Then by residue thm integral of z^(n-1)/p(z) is zero. But I want to show that integral of that function on large disk is non-zero then by contradiction we have our result. Now in large disk p(z) can be dominated by some leading term z^n but using this we can show only that modulus of given function is non zero but not for the given function.")#linebreak()#text(" There is any other way to recover this problem ?")

#text("Thanking you.")

#emph[#text("[Parameterise a large circle by ")#mi("z = Re^{i\\theta}")#text(" for ")#mi("0 \\leq \\theta \\leq 2\\pi")#text(", express the integral as an integral over ")#mi("\\theta")#text(", and apply the dominated convergence theorem. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 1: Zeroes, poles, and factorisation of meromorphic functions | What's new")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-612415")[#strong[#text("246B, Notes 1: Zeroes, poles, and factorisation of meromorphic functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2020")])]

#text("[…] again for avoiding the zeroes of both and . Thus we see that the zeroes and poles of a rational function describe the behaviour of that rational function, as well as close relatives of that function such as the log-magnitude and log-derivative . We have already seen these sorts of formulae arise in our treatment of the argument principle in 246A Notes 4. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-613092")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2020")])]

#text("The last paragraph of establishing (1) in the proof of Lemma 1 is sketchy and informal; it is not difficult to draw a “picture” according to the informal narrative, but a “picture”, while illustrating ideas, is not quite a substitute of a proof. You once mentioned that in practice, one uses the less formal")#linebreak()#text(" (but *still* ")#emph[#text("formalisible")]#text(") modes of mathematical reasoning when doing analysis.")

#text("But unlike the “hard analysis” that uses explicit ")#mi("\\epsilon,\\delta")#text(" estimates in lots of other proofs of this set of notes, or “soft analysis” (like “by compactness …”) that conceals the epsilon-delta, I find it very difficult to formalize the mentioned sketchy proof, even difficult to see a path that it is indeed formalisable. When I do attempt to write a more formal proof (at the level of loose epsilon-delta arguments) based on your sketch, I find it extremely tedious and much less illuminating than a picture; for instance, it is very difficult to formalize and convince oneself it is worth to formalize the notions such as “perturbing… the curves”, “removing loops, self-intersections, or excursions…”. This seems to be in sharp contrast to other hard/soft analysis arguments.")

#text("Is there a way to make the “geometry/topology” part of the proof (or at least make it more look like formalisable) formal and yet without going to the “formidable” world of homology and not being tedious/dull? Or if one wants a cleaner and more formal/formalisable proof, one has to use the machinery of algebraic topology?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-613191")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2020")])]

#text("The formalism of algebraic topology is the best solution we currently have in the long-term, but for topological arguments involving bounded complexity objects such as polygonal paths one can also use the language of algorithms. All the operations discussed in Lemma 1 can be coded as a computer algorithm in some idealised computer language, and the main mathematical tasks are then to show that the algorithms terminate in finite time and produce objects with the stated properties, which can often be done with a suitable induction argument (for instance, some sort of induction on the “complexity” of a path as it is being simplified by removal of loops etc.). Of course, coding can also be tedious and/or dull if approached inefficiently, but this is again the gap between arguments that are formalisable in principle, and arguments that are fully formalised. And indeed topological arguments have proven somewhat challenging to formalise properly, though not impossibly so. See for instance this article by Hales on the (ultimately successful) months-long project to formalise the proof of the Jordan curve theorem: ")#link("https://www.maths.ed.ac.uk/~v1ranick/papers/hales3.pdf")[#text("https://www.maths.ed.ac.uk/~v1ranick/papers/hales3.pdf")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-616259")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2021")])]

#text("Can the fact that any meromorphic function ")#mi("f: U \\setminus S \\to \\mathbf{C}")#text(" which is meromorphic on ")#mi("U")#text(" can be expressed as a ratio of two holomorphic functions on ")#mi("U")#text(" be proved by chasing the Laurent expansion somehow? Or does it require some all new tool to prove this?")

#emph[#text("[The standard proof uses a version of the Weierstrass factorisation theorem. See Exercise 19 of ")#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/")[#text("246B Notes 1")]#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-618935")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2021")])]

#text("In the proof of Lemma 1 when we want to proof eq (1) then we have to prove integral of F(w) := f(w)-f(z)/w-z over gamma_1 and gamma_2 are same. To prove this we used keyhole contour argument but I am wondering that it will be sufficient if we use gamma_1 can be deformed to gamma_2 and then by homotopy version we have our conclusion.")#linebreak()#text(" Am I correct ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-619366")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2021")])]

#text("This would also work, but it is surprisingly difficult to actually establish that ")#mi("\\gamma_1, \\gamma_2")#text(" are homotopic in ")#mi("U")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 2: Some connections with the Fourier transform | What's new")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-620191")[#strong[#text("246B, Notes 2: Some connections with the Fourier transform | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2021")])]

#text("[…] Exercise 5 (and Lemma 1) of 246A Notes 4 we already observed some links between complex analysis on the disk (or annulus) and Fourier series […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 3: Elliptic functions and modular forms | What's new")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-621855")[#strong[#text("246B, Notes 3: Elliptic functions and modular forms | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2021")])]

#text("[…] by the way, produces a very short proof of the little and great Picard theorems, which we proved in 246A Notes 4.) Functions on the modular curve (such as the -invariant) can be viewed as -invariant functions on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-621895")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2021")])]

#text("In exercise 4, why do we specifically need the curve ")#mi("\\gamma")#text(" to be simple ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-621917")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2021")])]

#text("It is not absolutely necessary as long as the Winding number is 1. The curve being simple makes integration easier.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-622317")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2021")])]

#text("In Exercise 25 don’t we need ")#mi("S")#text(" to be closed, so that ")#mi("U \\setminus S")#text(" is open and we can find a closed curve ")#mi("\\gamma")#text(" in ")#mi("U \\setminus S")#text(" with the winding number ")#mi("W_{\\gamma} (z_0) = 1")#text(" and also such that ")#mi("\\gamma")#text(" can be contracted to a point in ")#mi("(U \\setminus S) \\cup \\{ z_0 \\},")#text(" and then using Riemann’s theorem on removable singularities to obtain a holomorphic function ")#mi("F")#text(" defined on ")#mi("(U \\setminus S) \\cup \\{ z_0 \\},")#text(" and then use Cauchy’s theorem to get ")#mi("\\int_{\\gamma} F(z) dz = 0")#text(", and then finally notice that ")#mi("\\int_{\\gamma} F(z) dz = \\int_{\\gamma} f(z) dz")#text(" to conclude that residue of ")#mi("f")#text(" at ")#mi("z_0")#text(" (if ")#mi("z_0")#text(" is a removable singularity of ")#mi("f")#text(") is zero ?")

#emph[#text("[Singular sets are now explicitly required to be closed in these notes. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-622319")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2021")])]

#text("I also think that the proofs of the other two parts of Exercise 25 just follows by extracting the coefficient ")#mi("a_{-1}")#text(" of the Laurent series of ")#mi("f")#text(" in the annulus ")#mi("D(z_0 , r) \\setminus \\{ z_0 \\}")#text(" where ")#mi("r>0")#text(" is a radius such that ")#mi("D(z_0, r) \\setminus \\{ z_0 \\} \\subseteq U \\setminus S")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-622358")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2021")])]

#text("In the proof of Rouche’s theorem, how do we conclude that ")#mi("K")#text(" contains only finitely many singularities in ")#mi("S")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-622520")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2021")])]

#text("If you are referring to the proof of Theorem 21, a compact set can only contain finitely many elements of a discrete set since otherwise there would be an accumulation point of the latter by sequential compactness.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Math 246A, Notes 3: Cauchy’s theorem and its consequences | What's new")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-634693")[#strong[#text("Math 246A, Notes 3: Cauchy’s theorem and its consequences | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2021")])]

#text("[…] Previous set of notes: Notes 2. Next set of notes: Notes 4. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1d30f0fcb4d4865993d4d264bca7d12765aad36730246fbe3ffdd526246c92f-38be957fef8d5d3ed3ed31dbb7c6681901cde34051e6db932af66447abcf80ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Kowalski")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-636892")[#strong[#text("Matthew Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2021")])]

#text("As a heads up, in the proof of the Laurent series above exercise 5, you reference corollary 18 to show that a holomorphic function is analytic, but notes 3 was changed recently, so the fact that a holomorphic function is analytic is now shown in corollary 20.")

#emph[#text("[Corrected, as well as other references to Notes 3 here – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/996d0d60b53a13402cd449a554edb3f8f3cce0d25148151027008fdeedd554b3-a27d04320bb26ff8f49892f32b07f667ccc03c2df1ce25a5d69f9ea9ce887019.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pierre V")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-638982")[#strong[#text("Pierre V")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2022")])]

#text("Thank you professeur Tao for your precious notes.")

#text("In the exercise 58 – ii (Great Montel theorem), once we got a uniform bound on h’, how do we get back to f ? Since |h(0)| (if we work on the unit disk) could be arbitrary large and cos is not uniformly continuous on all C.")

#emph[#text("[Pass to a subsequence where ")#mi("f_n(0)")#text(" converges in the Riemann sphere; by applying a Mobius transformation permuting ")#mi("0,1,\\infty")#text(" one can assume that the limit point is not equal to the two most problematic points ")#mi("0, \\infty")#text(". Now ")#mi("h_n(0)")#text(" can be made uniformly bounded. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-639827")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2022")])]

#text("I am a bit confused with the statement in Exercise 5. It is said that the coefficients ")#mi("a_n")#text(" are uniquely determined by ")#mi("f")#text(" and ")#mi("r,R")#text(", where these ")#mi("r")#text(" and ")#mi("R")#text(" are from the annulus contained by the domain ")#mi("U")#text(". What if one considers a different annulus (hence different ")#mi("r")#text(" and ")#mi("R")#text(") contained in ")#mi("U")#text("? Then one has different ")#mi("a_n")#text(" and thus a different expansion for ")#mi("f")#text("? But then what happens to the intersection of the anulli?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-639832")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2022")])]

#text("If the annuli overlap, then the coefficients ")#mi("a_n")#text(" will agree; but if the domain ")#mi("U")#text(" contains two disjoint annuli, then the coefficients arising from different annuli can be different. I recommend working out Exercise 7 for an example of this phenomenon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-643068")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2022")])]

#text("It seems that the coefficients ")#mi("a_n")#text(" also depend on the center ")#mi("z_0")#text(" of the annuli, correct? For instance, ")#mi("f(z)=\\frac{1}{1-z}-\\frac{1}{2-z}")#text(" in ")#tao-math("\\{0<\\left|z\\right|<1\\}", block: false)#text(" has expansion")

#mi("\\displaystyle f(z)=\\sum_{n=0}^\\infty z^n+\\sum_{n=0}^\\infty \\frac{1}{2^{n+1}}z^n")

#text("while in ")#tao-math("\\{0<\\left|z-1\\right|<1\\}", block: false)#text(",")

#mi("\\displaystyle f(z)=\\frac{-1}{z-1}+\\sum_{n=0}^\\infty (z-1)^n")

#text("Can one thus define the map(s) ")#mi("a_n(z_0)")#text(" where it maps ")#mi("z_0")#text(" to the coefficient ")#mi("a_n")#text(" of the Laurent series on an annulus centered at ")#mi("z_0")#text("? Are there any interesting/trivial properties for this map?")

#emph[#text("[Yes, the coefficients vary with the center ")#mi("z_0")#text(". See also Exercise 18 of Notes 1. -T]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-639862")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2022")])]

#text("At the beginning of Section 1 (Laurent series), typo in the third formula for ")#mi("a_n")#text(": I think ")#mi("z")#text(" should be ")#mi("z_0")#text(" on the right.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-639863")[#strong[#text("J.")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2022")])]

#text("In the statement of Lemma 1, the unique decomposition ")#mi("f_1")#text(" and ")#mi("f_2")#text(" are given by the Cauchy integral formulae along ")#mi("\\gamma_1")#text(" and ")#mi("\\gamma_2")#text(". If one changes the orientation of the two (or one of) curves, would one have a different decomposition? (Or must one not reverse the orientation since the Cauchy integral formula fails?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-639877")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2022")])]

#text("If one reverses the orientation of the curve then the integral changes sign. So for instance one could state Lemma 1 for clockwise curves instead of anticlockwise ones if one reverses all the signs in the decompositions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-639880")[#strong[#text("J.")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2022")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("… Now suppose that ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" is holomorphic for some annulus of the form")#linebreak()#text(" ")#tao-math("\\displaystyle  U = \\{ z \\in {\\bf C}: r < \\left|z-z_0\\right| < R \\} \\ \\ \\ \\ \\ (3)", block: false)#linebreak()#text(" for some ")#mi("{z_0 \\in {\\bf C}}")#text(" and ")#mi("{0 \\leq r < R \\leq \\infty}")#text(". From Lemma 1, we can split ")#mi("{f = f_1 + f_2}")#text(", where ")#mi("{f_1}")#text(" is holomorphic in ")#mi("{D(z_0,R)}")#text(", and ")#mi("{f_2}")#text(" is holomorphic in the exterior region ")#tao-math("{\\{ z: \\left|z-z_0\\right| > r \\}}", block: false)#text(", with ")#mi("{f_2(z)}")#text(" going to zero as ")#mi("{z \\rightarrow \\infty}")#text(".")
]

#text("How exactly is Lemma used to split ")#mi("f=f_1+f_2")#text(" when ")#mi("U")#text(" is the annulus domain of the holomorphic ")#mi("f")#text(" given in (3)? It seems that ")#tao-math("\\gamma_1=\\{\\left|z\\right|=R\\}", block: false)#text(" and ")#tao-math("\\gamma_2=\\{\\left|z\\right|=r\\}", block: false)#text(". But these two curves are not contained in ")#mi("U")#text(" but the closure of ")#mi("U")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-639886")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2022")])]

#text("One can take ")#mi("\\gamma_1")#text(" and ")#mi("\\gamma_2")#text(" to be circles of radius ")#mi("R-\\varepsilon")#text(" and ")#mi("r+\\varepsilon")#text(" respectively for some small ")#mi("\\varepsilon>0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-639888")[#strong[#text("J.")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2022")])]

#text("Hmm, I was thinking of an ")#mi("\\varepsilon")#text("-room argument; but not sure how one should pass it to the limit. For each sufficiently small ")#mi("\\varepsilon")#text(", one has ")#mi("f_{1,\\varepsilon}, f_{2,\\varepsilon}")#text(" holomorphic on ")#tao-math("\\{\\left|z\\right|<R-\\varepsilon\\}", block: false)#text(" and ")#tao-math("\\{\\left|z\\right|> r+\\varepsilon\\}", block: false)#text(" respectively. But eventually one needs ")#mi("f_1")#text(" on ")#tao-math("\\left|z\\right|< R", block: false)#text(" and ")#mi("f_2")#text(" on ")#tao-math("\\left|z\\right|> r", block: false)#text(".")

#text("One may let ")#mi("f_1=f_{1,\\varepsilon}")#text(" on each ")#tao-math("\\{\\left|z\\right|<R-\\varepsilon\\}", block: false)#text(" since the ")#mi("f_{1,\\varepsilon}")#text(" agree on the common domain by uniqueness part of Lemma 1. Similarly for ")#mi("f_2")#text(". Is this what you suggest from the comment?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-639894")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2022")])]

#text("No limiting procedure is necessary. For a fixed ")#mi("\\varepsilon>0")#text(", ")#mi("f_1")#text(" is already holomorphic on ")#tao-math("U \\cup \\mathrm{int}(\\gamma_1) = \\{ \\left|z\\right| < R\\}", block: false)#text(", and ")#mi("f_2")#text(" is already holomorphic on ")#tao-math("U \\cup \\mathrm{ext}(\\gamma_2) = \\{ \\left|z\\right| > r \\}", block: false)#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-643072")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2022")])]

#emph[#linebreak()#text(" … Two holomorphic atlases on ")#mi("{M}")#text(" are said to be equivalent if the identity map from ")#mi("{M}")#text(" (equipped with one of the atlases) to ")#mi("{M}")#text(" (equipped with the other atlas) is a complex diffeomorphism; this is easily seem to be an equivalence relation, and we refer to such an equivalence class as a (one-dimensional) complex structure on ")#mi("{M}")#text(".")#linebreak()#text(" ")]

#text("Is the “collection” of all complex manifolds (topological manifolds that each has a complex structure) a set? Is the notion of “diffeomorphism” an equivalence relation on this set?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-643136")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2022")])]

#text("You can put all complex manifolds together, and call it a set. Not sure about the notion of diffeomorphism on all the manifolds. One manifold can have many atlases. The diffeomorphism in the notes refer to diffeomorphism between atlases.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-643231")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2022")])]

#text("Right above formula (14), it seems missing that ")#mi("U")#text(" is a non-empty open subset of ")#mi("{\\bf C}\\setminus\\{0\\}")#text(".")

#emph[#linebreak()#text(" … If now ")#mi("{\\gamma}")#text(" is a closed curve in ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(", and ")#mi("{f}")#text(" is differentiable on the entire image of ")#mi("{\\gamma}")#text(",…")#linebreak()#text(" ")]

#text("The function ")#mi("f")#text(" is only defined on ")#mi("U")#text(". So ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(" above is meant to be ")#mi("U")#text(" probably.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-643233")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2022")])]

#text("A branch, or branch cut is simply a notion to make multi-valued functions single valued, and it is not unique. For example, the standard branch for ")#mi("Log(z)")#text(" is the negative real axis, but you can choose any other branch for ")#mi("arg(z)")#text(" to make ")#mi("log(Z)")#text(" single valued. For example, a branch of the lower imaginary axis, then ")#mi("arg(z)")#text(" will be in the interval ")#mi("(-\\pi/2,3\\pi/2]")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-643242")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2022")])]

#text("In the proof of Rouche’s theorem (Theorem 37), Corollary 34 is used, which is proved by Corollary 33, which is proved by the Argument principle (Theorem 32). The Argument principle is proved by the residue theorem.")

#text("But at the beginning of the proof of the residue theorem (Theorem 22), Rouche’s theorem is used.")

#text("Is this circular?")

#text("What was wrong with the original version of the proof of the residue theorem where a topological argument is used to do the reduction as follows?")

#text("The image of ")#mi("\\gamma")#text(" can be enclosed in the interior of a polygonal Jordan curve contained in ")#mi("U")#text(". As ")#mi("U")#text(" is simply connected, the interior of this curve is also in ")#mi("U")#text(". The restriction of ")#mi("S")#text(" to the Jordan curve and its interior is both discrete and compact, and thus finite. By restricting both ")#mi("U")#text(" and ")#mi("S")#text(" to the interior of the Jordan curve, we may now assume without loss of generality that ")#mi("S")#text(" is finite.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-643369")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2022")])]

#text("The reference to Rouche’s theorem in Theorem 22 is to the Rouche theorem for winding number (Corollary 44 from Notes 3). I have edited the text to clarify this.")

#text("The alternate approach also eventually works, though it is not entirely trivial to establish the first claim you state (that ")#mi("\\gamma")#text(" can be enclosed inside a polygonal Jordan curve contained in ")#mi("U")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-643263")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2022")])]

#text("[Please delete the previous version of the comment that is not phrased clearly and had typos.]")

#text("1. Do you have a *formal* definition for the notion of “branch” of multi-valued functions in the notes?")

#text("The only place where it appears is (emphasis mine):")

#text("“… picking a branch of the square root function – a function which selects one of the multiple choices for that function at *each point in the domain*.”")

#text("This is close to a formal definition.")

#text("But in the later discussion, the function ")#mi("f:U\\to{\\bf C}")#text(" is also called a branch of the logarithm where ")#mi("U")#text(" is only a *subset* of the domain ")#mi("{\\bf C}\\setminus\\{0\\}")#text(".")

#text("In this “branch”, the function ")#mi("f")#text(" is undefined on ")#mi("({\\bf C}\\setminus\\{0\\})\\setminus U")#text("?")

#text("2.")#linebreak()#text(" ")#emph[#linebreak()#text(" and so must admit a holomorphic branch of the complex logarithm. One such branch is the standard branch ")#mi("{\\mathrm{Log}: {\\bf C} \\backslash \\{0\\} \\rightarrow {\\bf C}}")#text(" of the complex logarithm, defined as")]

#tao-math("\\displaystyle  \\mathrm{Log}(z) := \\ln \\left|z\\right| + i \\mathrm{Arg}(z)", block: false)

#text("where ")#mi("{\\mathrm{Arg}(z)}")#text(" is the standard branch of the argument, defined as the unique argument in ")#mi("{\\mathrm{arg}(z)}")#text(" in the interval ")#mi("{(-\\pi,\\pi]}")#text(".")#linebreak()

#text("Should ")#mi("{\\bf C} \\backslash \\{0\\}")#text(" above be ")#mi("{\\bf C} \\backslash (-\\infty,0]")#text(" since you are talking about a “holomorphic branch”? Is that a typo?")

#emph[#text("[Corrected, and some additional text to explain the concept of a branch added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-643425")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2022")])]

#text("In Exercise 43, can you please clarify what it means by ")#mi("c")#text(" being an absolute constant? Independent of all of ")#mi("R, z_0, f")#text(" or just a subset of these three quantities?")

#text("Later use of this exercise in the proof of Picard’s theorems seems to suggest that at least it is independent of ")#mi("R")#text(".")

#emph[#text("[Absolute constants, by definition, are independent of all parameters. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-643453")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2022")])]

#text("Here ")#mi("c=c(R, z_{0})")#text(" only, since ")#mi("R")#text(" and ")#mi("z_{0}")#text(" are fixed, we can say ")#mi("c")#text(" is an absolute constant, independent of ")#mi("z")#text(" and ")#mi("f")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-643429")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2022")])]

#text("Is it possible that any closed set with empty interior is the set of singularities for some holomorphic function on its complement?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-2/#comment-643433")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2022")])]

#text("Question is not well posed.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473177")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2016")])]

#text("Is it possible for the set of singularities to have Hausdorff dimension greater than 1 ? (it is known that dimension 1 is attainable by a natural boundary.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473182")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2016")])]

#text("Certainly; for instance the interior of the Koch snowflake is conformally equivalent to the unit disk thanks to the Riemann mapping theorem, so one can take your favourite example of a function with singularities on a significant portion on the unit circle and translate it to one with singularities on the snowflake (or many other fractals).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473180")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2016")])]

#text("In the beginning when you discuss compactifying the range of a holomorphic function to be the Riemann sphere, you say that ")#mi("f")#text(" can be extended to a function … ")#emph[#text("on")]#text(" the Riemann sphere, but I think you instead mean that ")#mi("f")#text(" can be extended to a function $f\\colon U\\to S\\cup\\{\\infty\\}$ ")#emph[#text("to")]#text(" the Riemann sphere.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473187")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2016")])]

#text("It seems that the concept of analytic continuation is necessary for a precise definition and classification of all types of singularities (also on the boundary of the domain ")#mi("U")#text(").")

#emph[#text("[Note added that we are not discussing boundary singularities in this set of notes. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473188")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2016")])]

#text("Since any non-polynomial entire function has (on the Riemann sphere) essential singularity at ")#mi("\\infty")#text(", Picard’s theorem applies also for these functions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473266")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2016")])]

#text("It is easy to verify that theorem 56 is equivalent to the (apparently stronger) formulation: Let ")#mi("z_0")#text(" be an essential singularity of ")#mi("f")#text(", then, with at most one exception, any complex number is attained by ")#mi("f")#text(" infinitely many times in any neighborhood of ")#mi("z_0")#text(".")

#emph[#text("[Fair enough; remark to this effect added. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M. Scorsese")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473273")[#strong[#text("M. Scorsese")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2016")])]

#text("You say in the beginning that there is a need to consider functions that are holomorphic only on a certain subset of $U$ to motivate the following discussion of singularities of homorphic functions resp. of meromorphic functions.")

#text("But where do such functions actually/naturally come up ? I understood the study of such function always as being intrinsically motivated, as they have nice properties, and not as bring motivated by some extrinsic need to understand them deeply.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473277")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2016")])]

#text("Well, one is always dividing one holomorphic function by another to obtain a quotient ")#mi("f(z)/g(z)")#text(" which is meromorphic (and thus only holomorphic away from the zeroes of ")#mi("g")#text("). There are also some important transcendental functions like the Gamma function ")#mi("\\Gamma(z)")#text(" and the zeta function ")#mi("\\zeta(s)")#text(" that have poles. Finally, with the Riemann sphere perspective, even functions that are entire (but are not polynomials) can be viewed as having an essential singularity at infinity, which can then be studied by these techniques.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473274")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2016")])]

#text("In the proof of theorem 55, ")#mi("h(\\mathbb C)")#text(" should avoid (all branches of) ")#mi("\\cos^{-1}(j) = i \\cosh^{-1}(j)")#text(" (not ")#mi("\\cosh^{-1}(j)")#text(") for any integer ")#mi("j")#text(". This “excluded set” has real part ")#mi("\\pm \\pi /2")#text(" (for ")#mi("j=0")#text(" or ")#mi("0")#text(" (for ")#mi("j \\neq 0")#text(") – which might affect the latter application of Bloch’s theorem (as the distance of any ")#mi("z_0")#text(" from the “excluded set” is not bounded – growing with ")#tao-math("\\left|\\Re z_0\\right|", block: false)#text(").")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473276")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2016")])]

#text("Correction: Since ")#mi("\\cos^{-1}(-j) = \\cos^{-1}(j) + (2 k -1) \\pi")#text(" where ")#mi("k")#text(" is any integer, it follows that the above “excluded set” corresponds only to nonnegative(!) integers ")#mi("j")#text(", and the “excluded set” corresponding to the remaining negative(!) integers ")#mi("j")#text(" is generated by (real!) translations of odd multiples of ")#mi("pi")#text(" of the previous “excluded set”. Therefore the distance of any ")#mi("z_0")#text(" from the full “excluded set” is bounded (as desired for the application of Bloch’s theorem).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473288")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2016")])]

#text("In the proof of theorem 55, the expression “")#mi("\\pm \\cosh^{-1}(j) + 2 \\pi i k")#text("” should be corrected to “")#mi("\\pm i \\cosh^{-1}(j) + 2 \\pi k")#text("” (as in the proof of theorem 56).")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473335")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2016")])]

#text("There is a typo in the ")#mi("2 \\pi k")#text(" term.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473303")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2016")])]

#text("Every rational function is meromorphic on the Riemann sphere, but it seems that the converse is also true (since any meromorphic function ")#mi("f")#text(" on the Riemann sphere has only finitely many poles as its singularities, so it can be written as ")#mi("f= g/Q")#text(" for some polynomial ")#mi("Q")#text(" and entire function ")#mi("g")#text(" with polynomial growth – implying that ")#mi("g")#text(" is also polynomial and therefore ")#mi("f")#text(" is rational).")

#emph[#text("[This is Exercise 19. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473310")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2016")])]

#text("“such a function would be holomorphic ")#emph[#text("save")]#text(" for a singularity at {z_0}.”")

#emph[#text("[This is what is written in the text – I am not sure what point you are making here. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473325")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2016")])]

#text("Ah, I just don’t understand what that sentence means… Sorry for my bad English. I thought the word “save” was a typo.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473336")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2016")])]

#text("Let ")#mi("f")#text(" be holomorphic on some open disk ")#mi("D(z_0, R)")#text(" in the complex plane. By analytic continuation it may be viewed as a restriction of its continuation to some (connected) Riemann surface ")#mi("M")#text(". If such ")#mi("M")#text(" is maximal (i.e. no further analytic continuation of ")#mi("f")#text(" to a larger Riemann surface is possible), is it uniquely determined? (i.e. is its topology uniquely determined and somehow encoded in the Taylor coefficients of ")#mi("f")#text(" at ")#mi("z_0")#text(" ?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473351")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2016")])]

#text("Not as stated. Suppose for instance we have a holomorphic function ")#mi("g: D(0,1) \\to {\\bf C}")#text(" with natural boundary on the unit circle, and with ")#mi("g^{\\prime}(0) \\neq 0")#text(". Let ")#mi("f")#text(" be the restriction of ")#mi("g")#text(" to a small ball ")#mi("D(0,\\varepsilon)")#text(", then of course we have a maximal extension of ")#mi("f")#text(" to ")#mi("D(0,1)")#text(". But ")#mi("f")#text(" on ")#mi("D(0,\\varepsilon)")#text(" can also be identified with the identity function on ")#mi("f(D(0,\\varepsilon))")#text(" (if ")#mi("\\varepsilon")#text(" is small enough), which has a maximal extension to the identity function on ")#mi("{\\bf C}")#text(". So the analytic continuation is not unique if we allow ")#mi("M")#text(" to be an arbitrary Riemann surface with an embedded copy of ")#mi("D(z_0,R)")#text(".")

#text("On the other hand, if we place the disk ")#mi("D(z_0,R)")#text(" inside a fixed Riemann surface ")#mi("N")#text(", then there is a unique maximal continuation of ")#mi("f")#text(" to some Riemann surface ")#mi("M")#text(" that projects down to ")#mi("N")#text(" and contains a copy of ")#mi("D(z_0,R)")#text(" on which the projection is the identity. Basically, ")#mi("M")#text(" consists of those paths from ")#mi("z_0")#text(" to a point in ")#mi("N")#text(" along which one has an analytic continuation, up to homotopy.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-474444")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2016")])]

#text("Is it possible to extend the above unique maximal continuation for each real analytic function in ")#mi("n")#text(" variables defined over some ball in ")#mi("R^n")#text(" to be analytic over some unique maximal ")#mi("n")#text("-dimensional complex manifold ?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473355")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2016")])]

#text("Every algebraic function has only finitely many branches on the Riemann sphere. Is the converse also true?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473363")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2016")])]

#text("I *think* this follows from Chow’s theorem, but am not 100% sure of this (maybe one also needs the Riemann existence theorem?).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473369")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2016")])]

#text("A more elementary (heuristic) approach is to assume ")#mi("n")#text(" meromorphic branches ")#mi("f_1, ... , f_n")#text(" for a function ")#mi("f")#text(" on the Riemann sphere, and observing that ")#mi("P(f, z) := \\prod_i (f - f_i)")#text(" is a polynomial in ")#mi("f")#text(" whose coefficients are symmetrical functions of ")#mi("f_1, ... , f_n")#text(" which are meromorphic outside the branch cuts and are the same (because of symmetry) at both sides of each branch cut. Therefore (using e.g. Morera’s theorem) the branch cuts are removable singularities for these coefficients of ")#mi("P(f, z)")#text(" which are meromorphic on the Riemann sphere and thereby (exercise 19) rational. Since (by its definition) ")#mi("P(f, z) = 0")#text(" on the Riemann sphere, it follows that ")#mi("f")#text(" is algebraic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473475")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Ah, yes, you’re right, Chow’s theorem is definitely overkill here. By the way, I found a reference for this result in Theorem 8.3 of Forster’s “Lectures on Riemann surfaces”.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Gubkin")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473359")[#strong[#text("Steven Gubkin")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2016")])]

#text("Another approach to the open mapping theorem (which may be a bit more memorable geometrically) is that one can always find local holomorphic coordinates about a point and its image so that the map is equal to z^(n+1) in those coordinates (where n is the order of the derivative at that point). Since these maps are all obviously open (even at the origin) the claim follows. Since you can prove this just with technology you have already developed, this might make a nice additional exercise for your students.")

#text("Really enjoying these notes!")

#emph[#text("[Exercise to this effect added to the end of the notes. Thanks for the suggestion -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473376")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2016")])]

#text("Few minor typos")#linebreak()#text(" 1. In the formula preceding (2) in the proof of Lemma 1, ")#mi("=0")#text(" at the end should be removed.")#linebreak()#text(" 2. Last paragraph in the proof of Lemma 1, ")#mi("{\\gamma_1 + \\gamma_3 + \\gamma_2 + (-\\gamma_1)}")#text(" should be ")#mi("{\\gamma_1 + \\gamma_3 + \\gamma_2 + (-\\gamma_3)}")#text(".")#linebreak()#text(" 3. Same sentence, “vanishing winding number in the .. exterior of ")#mi("{\\gamma_3}")#text(" should be ")#mi("{\\gamma_1}")#text(" instead. Actually, I am not sure where the vanishing of winding numbers is used here.")#linebreak()#text(" 4. In the first formula of Exercise 2 there should be intersection of n sets, e.g. ")#mi("\\mathrm{ext}(\\gamma_1) \\dots \\cap \\mathrm{ext}(\\gamma_n)")#text(".")#linebreak()#text(" 5. In the inequality statement of Exercise 13, replace m with -m (may also add that m is a positive integer).")#linebreak()#text(" 6. In Definition 17, ")#mi("{\\phi^{\\prime}_\\beta \\circ f \\circ \\phi_\\alpha: \\phi_\\alpha^{-1}( f^{-1}(U^{\\prime}_\\beta) \\cap U_\\alpha ) \\rightarrow V_\\beta}")#text(" should be ")#mi("{\\phi^{\\prime}_\\beta \\circ f \\circ \\phi_\\alpha^{-1}: \\phi_\\alpha( f^{-1}(U^{\\prime}_\\beta) \\cap U_\\alpha ) \\rightarrow V_\\beta}")#text(".")#linebreak()#text(" 7. The Exercise 24, the second formula is not true without an extra residue term at infinity (properly defined), or some assumption of behavior at infinity. A simple counterexample is ")#mi("f(z)=1/z")#text(".")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473380")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2016")])]

#text("In definition 14, a formula does not parse.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473382")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2016")])]

#text("I exercise 43, it may be added that a continuous branch of the complex logarithm exists on ")#mi("U")#text(" if and only if ")#mi("U")#text(" does not separate ")#mi("0")#text(" and ")#mi("\\infty")#text(" on the Riemann sphere (i.e. ")#mi("0")#text(" and ")#mi("\\infty")#text(" should belong to some connected component of the complement of ")#mi("U")#text(" on the Riemann sphere – to allow a connecting branch cut between them.)")#linebreak()#text(" ")#emph[#text("[Exercise expanded, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473412")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("As an interesting application, with the assumptions of theorem 31, the function ")#mi("f")#text(" has a holomorphic logarithm on (an open neighborhood of) the image of ")#mi("\\gamma")#text(" if and only if the image of ")#mi("f \\circ \\gamma")#text(" does not separate ")#mi("0")#text(" and ")#mi("\\infty")#text(" on the Riemann sphere – which is equivalent to the vanishing of the RHS of (13), and thereby equivalent to the vanishing of the LHS of (13).")#linebreak()#text(" This simple necessary and sufficient condition (that the sum of the orders of the zeros of ")#mi("f")#text(" inside ")#mi("\\gamma")#text(" equals(!) the sum of the orders of its poles) for the existence of holomorphic logarithm of ")#mi("f")#text(" on the image of ")#mi("\\gamma")#text(" may be (heuristically) explained by assuming that inside(!) ")#mi("\\gamma")#text(" the logarithm of ")#mi("f")#text(" has branch cuts connecting each zero of ")#mi("f")#text(" to a corresponding(!) pole of ")#mi("f")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dd138cf487ed7855627f5e11ab37a19680546d85d2dd35a526d2ac4071417d24-0b95bd06509487fb437598b1c152240812f1ee054402effda932964b968def47.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Just watched Donald Duck in Mathmagic Land – vamavamavama")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473384")[#strong[#text("Just watched Donald Duck in Mathmagic Land – vamavamavama")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2016")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/#&#8230")[#text("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/#&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473390")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2016")])]

#text("Is it possible to extend exercise 2 to the case of infinitely many contours?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473400")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2016")])]

#text("Yes, but only for the degenerate reason that only finitely many of the ")#mi("\\gamma_n")#text(" can encircle a point outside of ")#mi("U")#text(" (if not, one can use the Bolzano-Weierstrass theorem to locate an element of ")#mi("U")#text(" that is adherent to the complement of $latex $U$). I don’t know if there is a non-degenerate version of this exercise that usefully allows for an infinite number of singularities inside the big closed curve.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473398")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2016")])]

#text("If I understand correctly, a function is defined to be holomorphic only(!) on open sets, so its singular set is automatically closed. Therefore there seems to be no need for the remark in lines 9-10 (that we always deal with closed singular sets and open sets on which the function is holomorphic).")

#emph[#text("[Paragraph reworded to emphasise this – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473404")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2016")])]

#text("Third paragraph of section 2, ")#mi("{D(z_0,r) \\backslash \\{-1\\}}")#text(" should be ")#mi("{D(z_0,r) \\backslash \\{z_0\\}}")#linebreak()#text(" Proof of Corollary 50, first sentence is redundant (appears twice).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473409")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("In theorem 31, the summands in the LHS of (13) should have running index ")#mi("j")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473413")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("In the first line of theorem 31, ")#mi("U")#text(" should be ")#mi("mathbb C")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246A, Notes 5: conformal mapping | What's new")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473438")[#strong[#text("246A, Notes 5: conformal mapping | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("[…] Anonymous on Math 246A, Notes 4: singularit… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b47a28c30c4c0a3eb17e4f5c11d9b165e5656434ca8f7453911b81e194106b32-dbc47055a1fb5f3b01bc0718aec9dec6f34aa903d241bd0c80477cbd4405ee27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Georges Elencwajg")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473556")[#strong[#text("Georges Elencwajg")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2016")])]

#text("Dear Terence, Exercise 9 is correct only under the assumption that ")#mi("U")#text(" is connected : else ")#mi("M(U)")#text(" has non trivial zero divisors.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa64c9c253f65a7d9cc17341c4b22ebef482e1440374dcc9f37da48992a6c01-adae0e3099b1eca8bd0752161d24380b97aab9790b1fa32b2687d7d9e5d3dd74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Asimov")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473729")[#strong[#text("Dan Asimov")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2016")])]

#text("A little exercise (or puzzle): Let f: C —> C be holomorphic and onto with nowhere vanishing derivative. Is f necessarily invertible?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473753")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2016")])]

#text("No! (since ")#mi("f^{\\prime}")#text(" is a non-vanishing entire function, it has the form ")#mi("f^{\\prime} = e^g")#text(" for some entire function ")#mi("g")#text(". Now, to get a counterexample, let ")#mi("g")#text(" be any even(!) non-constant entire function, and assume the initial condition ")#mi("f(0) = 0")#text(". This determines ")#mi("f")#text(" as the odd(!) non-polynomial entire function ")#mi("f(z) = \\int_0 ^z e^{g(t)} d t")#text(". Since ")#mi("f(1/z)")#text(" has essential singularity at the origin, it follows from theorem 56 that ")#mi("f")#text(" omits at most one complex number ")#mi("w_0")#text(", say. But since ")#mi("f")#text(" is an odd function, if it omits ")#mi("w_0")#text(" it must omit also ")#mi("-w_0")#text(" which is possible only if ")#mi("w_0 = - w_0")#text(" i.e. ")#mi("w_0 = 0")#text(", but this contradicts the initial condition ")#mi("f(0) = 0")#text(". Hence, ")#mi("f")#text(" is onto, and by theorem 56, ")#mi("f")#text(" attains every(!) complex number infinitely many times!)")#linebreak()#text(" one of simplest counter-examples seems to be the error function ")#mi("f(z) = erf (z)")#text(" which (according to the above discussion) is an entire function with nowhere vanishing derivative, that attains every complex number infinitely many times.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473747")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2016")])]

#text("No! (e.g. the exponential function).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473748")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2016")])]

#text("My error! (the exponential function omits ")#mi("0")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473836")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2016")])]

#text("It seems that in equation (18), it should be |k|x instead of |k|. Also, the display equation after (19), 1/z should be 1/|z|, and the above typo of (18) would carry over, hence |k| should be |k| \\log(1/|z|).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473890")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2016")])]

#text("Dear professor, I can’t see why we need U to be connected in the proof of uniqueness of the decomposition in the very first lemma. By the definition given, ")#mi("f_1")#text(" ")#mi("f_1^{^{\\prime}}")#text(" are defined on ")#mi("U \\cup \\mathrm{int} \\gamma_1")#text(", ")#mi("f_2")#text(" ")#mi("f_2^{^{\\prime}}")#text(" are defined on ")#mi("U \\cup \\mathrm{ext} \\gamma_2")#text(". I think the overlap is U, not just ")#mi("\\mathrm{int} \\gamma_1 \\cap \\mathrm{ext} \\gamma_2")#text(".")

#emph[#text("[Fair enough – proof adjusted accordingly. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473974")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2016")])]

#text("I am wondering if the condition that S is compact is necessary in Exercise 3. It seems we want to prove integral of f along a simple closed polygonal contour $\\latex \\gamma$is zero, $\\latex int \\gamma \\cap \\gamma \\cap S$ is always compact, whether S is or not.")

#emph[#text("[Yes, one can extend Painleve’s theorem to non-compact closed singular sets of zero length also. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/048f3ef05cee3330d5510f2711874f759bd824aeac3e6805bf8850da4ec0b78d-fdd739afaacfea50630e13e65ee3bc7744c3594f409856de5dfb1ffdab8d1602.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473982")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2016")])]

#text("Typo, Exercise 20: “polynomial of one complex polynomial”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473985")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2016")])]

#text("In the beginning of line 7.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-473998")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2016")])]

#text("In the third line there is a latex typo.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-474005")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2016")])]

#text("The typo is still there.")

#emph[#text("[Hopefully fixed now – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57eafb37fb4df4541895ba1ddf57091d5c1d620b932c5e94ffbfe62e8ecaf4de-627c15d5715cf03e189a24de025b2fb36a57ffab4d1fbbc08bcc8fc89fd45bcb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-474231")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2016")])]

#text("In the last part of lemma 1, it seems the path ")#mi("\\gamma_1 + \\gamma_3 + \\gamma_2 + (-\\gamma_3)")#text(" does not have winding number zero – the third term should be ")#mi("(-\\gamma_2)")#text(" instead. Cheers, L.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/89bb0c29dac5c7c2999792e1a2015aff6d5eaff78014e4324deec42500540084-9db649c739c9a1f9c57cdf4cdd3dc17db5ef7d333d3479dafef3c3704c0f47b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JD")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-474631")[#strong[#text("JD")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2016")])]

#text("In Exercise 25 (iii), shouldn’t you divide by ")#mi("(m-1)!")#text(" instead of ")#mi("m!")#text("? (in order to cancel for the ")#mi("(m-1)!")#text(" that appears from the $m-1$th derivative)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-478926")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2017")])]

#text("Small typo in Exercise 6 (the very last set). ")#emph[#text("[Corrected, thanks – T.]")]

#text("——————–")#linebreak()#text(" 1. In the discussion right above Example 7, do we have any assumption regarding the “singular set” S? If S is a branch cut for some multivalued function, then z_0\\in S would be in none of the three categories? ")#emph[#text("[The discussion above Example 7 applies only to isolated singularities; elements of branch cuts are not isolated. -T.]")]

#text("2. In Definition 8, what would go wrong if one drops the condition (i) in the definition? Is there an example such that (ii) is satisfied but not meromorphic? ")#emph[#text("[Property (i) is mainly for emphasis, as the isolated nature of the elements of ")#mi("S")#text(" is already implicit in (ii). -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-479018")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2017")])]

#text("“For instance, if ")#mi("{f: U \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" is a map from an open subset ")#mi("{U}")#text(" of ")#mi("{{\\bf C}}")#text(" to the Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\} \\backslash \\{0\\}}")#text(", then ")#mi("{f}")#text(" is holomorphic if and only if…”")

#text("Typo in “to the Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\} \\backslash \\{0\\}}")#text("“?")

#emph[#text("[Typo corrected. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-479046")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2017")])]

#text("I saw in many textbooks (e.g. in Gameline) the following calculation using (10) is made. For a closed curve ")#mi("C")

#tao-math("\\displaystyle \\int_C\\frac{f^{\\prime}(z)}{f(z)}\\ dz= \\int_{C}\\frac{d}{dz}[\\log f(z)]\\ dz\\\\ =\\int_Cd\\log f(z)=\\int_Cd\\ln\\left|f(z)\\right|+i\\int_Cd arg\\ f(z)\\\\ =0+i\\int_Cd arg\\ f(z)", block: false)

#text("I think the first equality can be made rigorous by using similar argument in the discussion of (15) in this post. But by the Cauchy-Riemann equations, the map ")#tao-math("z\\mapsto \\ln \\left|f(z)\\right|", block: false)#text(" would not necessarily be holomorphic anywhere (unless ")#mi("f")#text(" is a constant?). It would not even make sense to talk about ")#tao-math("\\int_Cd\\ln\\left|f(z)\\right|", block: false)#text(".")

#text("Is there any way to make this rigorous?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-479050")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2017")])]

#text("One can also see in Ahlfors that")#linebreak()#text(" ")#tao-math("\\displaystyle \\int_\\gamma\\frac{1}{z-a}\\ dz =\\int_\\gamma d\\log(z-a)=\\int_\\gamma d\\log\\left|z-a\\right|+i\\int_\\gamma d\\text{arg}(z-a)", block: false)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-479135")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2017")])]

#text("One can interpret integrals such as ")#tao-math("\\int_C d \\ln \\left|f(z)\\right|", block: false)#text(" using ")#link("https://en.wikipedia.org/wiki/Differential_form#Integration")[#text("integration of differential forms")]#text(" (or ")#link("https://en.wikipedia.org/wiki/Line_integral")[#text("line integrals")]#text(") rather than contour integrals.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-479221")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2017")])]

#text("In the proof of Lemma 1, “… are hence restrictions of a single entire function ")#mi("F")#text("“: Why does such entire function ")#mi("F")#text(" exists?")

#emph[#text("[If two functions ")#mi("g_1: X_1 \\to Y")#text(" and ")#mi("g_2: X_2 \\to Y")#text(" agree on their common domain ")#mi("X_1 \\cap X_2")#text(", then they are restrictions of a single function ")#mi("g: X_1 \\cup X_2 \\to Y")#text(". As holomorphicity is a local condition, if one glues together two holomorphic functions in this fashion, the resulting function is also holomorphic. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-479222")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2017")])]

#text("In the uniqueness part of the proof of Lemma 1, why does one need the analytic continuation in the last sentence? Once one shows that ")#mi("F=0")#text(" by Liouville’s theorem, doesn’t one have ")#mi("f_1-f^{\\prime}_1=0")#text(" on ")#mi("U\\cap\\text{int}(\\gamma_1)")#text(" and similarly ")#mi("f_2-f^{\\prime}_2=0")#text(" on ")#mi("U\\cap\\text{ext}(\\gamma_2)")#text("?")

#emph[#text("[Fair enough; I have shortened this part of the argument accordingly. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-479223")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2017")])]

#text("In the proof of Lemma 1, might be better to use ")#mi("g_1,g_2")#text(" instead of ")#mi("f_1^{\\prime},f_2^{\\prime}")#text(", which might be confused with the derivatives of ")#mi("f_1,f_2")#text(".")

#emph[#text("[Notation changed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-479225")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2017")])]

#text("(Sorry for the separate comments.)")#linebreak()#text(" In the proof of Lemma 1 again, why do we need to put the extra term ")#mi("f(z)")#text(" in the definition of ")#mi("f_1")#text(" and ")#mi("f_2")#text("? How is Exercise 36 of Notes 3 relevant.")

#emph[#text("[Without the terms of ")#mi("f(z)")#text(", the two definitions of ")#mi("f_1")#text(" would not agree on their common domain, and similarly for ")#mi("f_2")#text(". If it were not for Exercise 36, how would one show that ")#mi("f_1")#text(" and ")#mi("f_2")#text(" were holomorphic in ")#mi("z")#text("? -T]")]

#text("In the statement of Lemma 1, if one replaces ")#mi("U\\cup \\text{int}(\\gamma_1)")#text(" with ")#mi("\\text{int}(\\gamma_1)")#text(" as the domain of ")#mi("f_1")#text(" and uses ")#mi("\\text{ext}(\\gamma_2)")#text(" as the domain of ")#mi("f_2")#text(", would the theorem be changed fundamentally?")

#emph[#text("[I think the existence component of this theorem might more inconvenient to use in some applications, as one may wish all the functions involved to be holomorphic on the original domain ")#mi("U")#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-479235")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2017")])]

#text("In the proof of Lemma 1:")

#text("1. How is the factor theorem needed for proving the identity above (2)? Isn’t it true that ")#mi("\\frac{f(w)-f(z)}{w-z}")#text(" is holomorphic on ")#mi("\\text{int}(\\gamma_1)\\cap\\text{ext}(\\gamma_2)")#text("?")

#emph[#text("[The function ")#mi("\\frac{f(w)-f(z)}{w-z}")#text(" is not defined at ")#mi("w=z")#text(" (but the factor theorem ensures that the singularity here is removable). -T]")]

#text("2. Why does (2) not directly follow from Theorem 4 (Cauchy’s theorem) in Notes 3?")

#emph[#text("[How does one know that ")#mi("\\gamma_1")#text(" and ")#mi("\\gamma_2")#text(" are homotopic in ")#mi("U")#text("? This is a true statement, but to prove it one basically needs the same sort of methods used in the proof provided for (2) (insertion of an auxiliary path ")#mi("\\gamma_3")#text(" and analysis of the winding number). -T.]")]

#text("3. What estimate does one need to justify rigorously the passage to limit in the very last sentence?")

#emph[#text("[Cauchy’s theorem ensures that the integral does not depend on ")#mi("\\varepsilon")#text(" once ")#mi("\\varepsilon")#text(" is small enough. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-479260")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2017")])]

#text("Thank you for the comments!")

#text("For 1, ")#mi("z\\in\\text{int}(\\gamma_1)\\cap\\text{ext}(\\gamma_2)")#text(", and ")#mi("w")#text(" is either on ")#mi("\\gamma_1")#text(" or ")#mi("\\gamma_2")#text(" in establishing (2), so ")#mi("w\\neq z")#text("… ?")

#text("For 3, I understand that")

#mi("\\displaystyle \\lim_{\\varepsilon\\to 0}\\int_{\\gamma_\\varepsilon}F(w)\\ dw=0")#text(" since for small enough ")#mi("\\varepsilon")#text(", ")#mi("\\int_{\\gamma_\\varepsilon}F(w)\\ dw=0")#text(".")

#text("How should one show that")

#mi("\\displaystyle \\lim_{\\varepsilon\\to 0}\\int_{\\gamma_\\varepsilon}F(w)\\ dw=\\int_{\\gamma}F(w)\\ dw")#text(" where ")#mi("\\gamma=\\gamma_1+\\gamma_3+(-\\gamma_2)+(-\\gamma_3)")#text("?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83662a2e66f3a4da17b5af093d6a2cedf119f8afdcfd6c907d6d2c1ba8083566-12b5b261a288d1f1d77448d8b885bbaa0af51cdf5054970edf6be16e0640fd07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jura05")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-479498")[#strong[#text("jura05")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2017")])]

#text("Dear Professor Tao!")

#text("In the definition of meromorphic function, I think we do not need that S is closed. If S is discrete, then ")#mi("U\\setminus S")#text(" is guaranteed to be open.")

#text("For example, if ")#mi("U=\\{z\\colon \\mathrm{Re}z > 0\\}")#text(", and $S=\\{1/n\\colon n=1,2,\\ldots\\}$ is discrete, but not closed. And there are meromophic functions on U with singular set S.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83662a2e66f3a4da17b5af093d6a2cedf119f8afdcfd6c907d6d2c1ba8083566-12b5b261a288d1f1d77448d8b885bbaa0af51cdf5054970edf6be16e0640fd07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jura05")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-479499")[#strong[#text("jura05")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2017")])]

#text("Sorry, it is not guaraneed, of course. I guess S should be “closed in U”, not just “closed”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6389ce7c3593c0b3fdeda317075cb3e693dae6b75f92170f2c10b5142adf7e37-9361ed76527be549df139beb8553b55a70326b3ee557f14c7cc2cd27658be283.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Five-Value Theorem of Nevanlinna – Elmar Klausmeier's Weblog")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-481928")[#strong[#text("Five-Value Theorem of Nevanlinna – Elmar Klausmeier's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2017")])]

#text("[…] Math 246A, Notes 4: singularities of holomorphic functions […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/caaf91c376e4e48500e8b94f30041ef6d86fc1463989845cf3a2e47f185cf0f6-c2d9f5eea383226f3413e4757cf857746268c05e257e8f4c9e1e39a6a303a286.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Hruska")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-482152")[#strong[#text("David Hruska")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2017")])]

#text("Hi, I’m a little bit stuck at the Exercise 28 devoted to the spectral theorem for matrices. In particular I don’t see how to prove that the contour integral from the resolvent equals identity matrix. Of course there is a standard way of proving that the holomorphic calculus “preserves” polynomials in general, from which this follows, but the structure of the execrise suggests that another (hopefully more elementary) approach can be used for matrices. Can somebody help? Thanks in advance.")

#emph[#text("[Move the contour to infinity – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-486527")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2017")])]

#text("In Stein-Shakarchi,")

#text("If ")#mi("f")#text(" is a nowhere vanishing holomorphic function in a simply connected region ")#mi("\\Omega")#text(", then there exists a holomorphic function ")#mi("g")#text(" on ")#mi("\\Omega")#text(" such that ")#mi("f(z)=e^{g(z)}")#text(". The function ")#mi("g(z)")#text(" in the theorem can be denoted by ")#mi("\\log f(z)")#text(", and determines a “branch” of that logarithm.")

#text("Is this alluded somewhere in this note? How should one understand “")#mi("g")#text(" determines a “branch” of that logarithm”?")

#emph[#text("[See Exercise 46. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-488097")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2017")])]

#text("It is said in Stein-Shakarchi that")

#text("“There is a general principle in the theory, already implicit in Riemann’s work, which states that analytic functions are in an essential way characterized by their singularities. That is to say, globally analytic functions are “effectively” determined by their zeros, and meromorphic functions by their zeros and poles.”")

#text("I don’t quite understand this. Can one find any theorems in this note that can serve as instances of the mentioned principle?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-488100")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2017")])]

#text("Partial fractions (Exercise 20) is an instance of this in the category of rational functions. The Residue theorem (Section 2) is an instance in the context of contour integration. But probably Stein and Shakarchi are referring most directly to factorisation theorems such as the ")#link("https://en.wikipedia.org/wiki/Weierstrass_factorization_theorem")[#text("Weierstrass factorisation theorem")]#text(", which was not covered in this course (typically at UCLA we cover it in the sequel to this course, 246B).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-488356")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2017")])]

#text("Can meromorphic functions have an essential singularity at infinity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-488573")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2017")])]

#text("If ")#mi("\\infty")#text(" is not part of the domain, then sure. For instance the exponential function is meromorphic on the complex plane but has an essential singularity at infinity (and as such, will not be meromorphic on the Riemann sphere).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-488616")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2017")])]

#text("Stein-Shakarchi shows the following chain of implications:")

#text("Cauchy integral formula, -> residue theorem, -> argument principle, -> Rouche theorem, -> open mapping theorem, -> maximum principle")

#text("Can this chain be closed as a circle so that everything mentioned is actually equivalent to the Cauchy integral formula?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-497332")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2018")])]

#text("In the definition of holomorphic function on open subset of CU{∞} (before the exercise 18) , it seems that the set described in (ii) should be {z∈C:1/z∈U} ，the open cover is U ∩ C and U ∩ C\\{0}U{∞}，so 1/z ∈ U ∩ C\\{0}U{∞}，for 1/z ∈ C\\{0}U{∞}，it should be z∈C. And then (ii) can be full definition based on the definition of holomorphic function on open subset of C before.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-497623")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2018")])]

#text("Pro Tao，I find that the definition of meromorphic in your Notes is a little different from it in Wiki and some other books. And there isn’t a inclusion relation between them. Because your definition requires that S is closed which isn’t needed in Wiki’s definition(poles can converge to a point doesn’t belong to U, so in Wiki’s definition closed is not confirm), while Wiki’s definition require S can’t include removable singularities which yours don’t require that. So, which one is better? In subsequent study, which definition should we choose?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-497635")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2018")])]

#text("The two definitions are equivalent after removing any singularities that are removable. Note that the set of singularities is necessarily closed, because one can only define the notion of being holomorphic at a point if there is a neighbourhood of that point that is free of singularities.")

#text("If one calls the two notions of meromorphic functions “meromorphic functions with removable singularities”, and “meromorphic functions with all removable singularities removed”, the former is analogous to non-reduced fractions such as ")#mi("6/4")#text(", and the latter to reduced fractions such as ")#mi("3/2")#text(". The advantage of the latter is that there is a canonical description: every fraction has a unique reduced form, and every meromorphic function has a unique representation after removing all singularities. In the former, one does not have unique forms any more, but it can be faster to manipulate the fractions and meromorphic functions because one does not have to keep checking that the numerators and denominators remain coprime, or that all singularities are genuine poles and not merely removable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-497656")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2018")])]

#text("Thanks for your exhaustive reply. But I still have a small problem. We know U is open in C, U\\S is open in C and S⊂U, with these condition I can just deduct that S is closed in U rather than in C. And the example is that a series of singularities converge to a point that is not in U, so S is not closed in C but U\\S can still be open.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-497657")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2018")])]

#text("This was a typo, now corrected: ")#mi("S")#text(" is required to be closed in ")#mi("U")#text(", but need not be closed in ")#mi("{\\bf C}")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-497670")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2018")])]

#text("Thanks for your patient reply. So in theorem 21(Residue theorem), if S is closed in U rather than in C, it seems that we can’t ensure the singularities in the large ball which contains γ are finite. Because without closed in C, we can’t ensure S restricted to the large ball is compact. Then the function g can’t be defined successfully without the assumption S is finite.")#linebreak()#text(" if we restrict S to the image of homotopic function γ^~, then S will be finite, g can be defined with z0 which belongs to the S, but if we do this and resume the left step in the proof，finally we just can derive the equality where S in the right-hand side is a restriction to image of homotopic function γ^~. we can’t ensure the point not in the image of homotopic function has 0 winding number, can we expand the restriction of S to the whole S?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-497688")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2018")])]

#text("Fair enough. I’ve changed this part of the argument to resolve this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-497766")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2018")])]

#text("I’ve seen that，but I have some new question about your revise，just about how we define “sufficiently fine grid”, “outer boundary” and “perturbing”. For “sufficiently fine grid”, my interpretation is that decompose a sufficiently big grid including the whole curve γ uniformly and repeatedly until every small grid which contains part of γ is in U. Then the union of the finite grid will contains all the γ. I don’t know whether I am right about “sufficiently fine grid”. And How to define “outer boundary” to keep it closed , polygonal and γ contained in? is the “outer boundary” self-intersected? if yes, how do we “perturbing”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-497794")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2018")])]

#text("The complement of the union of the collection ")#mi("{\\mathcal S}")#text(" of squares that touch ")#mi("\\gamma")#text(" partition the remainder of the complex plane into connected components, one of which is unbounded. The boundary of that component is the outer boundary; it is the union of a finite number of edges of the squares. It can be traversed as a piecewise linear closed contour (right-hand rule), but it may touch itself due to the possibility of two of the squares in ")#mi("{\\mathcal S}")#text(" touching each other at a vertex without sharing a common edge, and with neither of the two other squares at that vertex being in ")#mi("S")#text(". But then one can perturb the contour away from this vertex, for instance by replacing the both corners where the contour passes through that vertex with a diagonal “shortcut”. (This should be visually obvious once one draws a picture.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/comment-page-1/#comment-497816")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2018")])]

#text("thank you very much！")
]
]
]
]
]
