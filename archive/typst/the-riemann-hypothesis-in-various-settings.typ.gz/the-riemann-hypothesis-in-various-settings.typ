// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/
// Converted to Typst by tao2typ: "2026-10-14T16:37:11.304058+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Riemann hypothesis in various settings", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Riemann hypothesis in various settings")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 July 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/")[#text("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("[Note: the content of this post is standard number theoretic material that can be found in many textbooks (I am relying principally here on ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec and Kowalski")]#text("); I am not claiming any new progress on any version of the Riemann hypothesis here, but am simply arranging existing facts together.]")

#text("The ")#link("https://en.wikipedia.org/wiki/Riemann_hypothesis")[#text("Riemann hypothesis")]#text(" is arguably the most important and famous unsolved problem in number theory. It is usually phrased in terms of the ")#link("https://en.wikipedia.org/wiki/Riemann_zeta_function")[#text("Riemann zeta function")]#text(" ")#mi("{\\zeta}")#text(", defined by")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) = \\sum_{n=1}^\\infty \\frac{1}{n^s}")]]

#text("for ")#mi("{\\text{Re}(s)>1}")#text(" and extended meromorphically to other values of ")#mi("{s}")#text(", and asserts that the only zeroes of ")#mi("{\\zeta}")#text(" in the critical strip ")#mi("{\\{ s: 0 \\leq \\text{Re}(s) \\leq 1 \\}}")#text(" lie on the critical line ")#mi("{\\{ s: \\text{Re}(s)=\\frac{1}{2} \\}}")#text(".")

#text("One of the main reasons that the Riemann hypothesis is so important to number theory is that the zeroes of the zeta function in the critical strip control the distribution of the primes. To see the connection, let us perform the following formal manipulations (ignoring for now the important analytic issues of convergence of series, interchanging sums, branches of the logarithm, etc., in order to focus on the intuition). The starting point is the ")#link("https://en.wikipedia.org/wiki/Fundamental_theorem_of_arithmetic")[#text("fundamental theorem of arithmetic")]#text(", which asserts that every natural number ")#mi("{n}")#text(" has a unique factorisation ")#mi("{n = p_1^{a_1} \\ldots p_k^{a_k}}")#text(" into primes. Taking logarithms, we obtain the identity ")#metadata(none) <tao-091e7397b79ab9c586b9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\log n = \\sum_{d|n} \\Lambda(d)")]]

#text("for any natural number ")#mi("{n}")#text(", where ")#mi("{\\Lambda}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(", thus ")#mi("{\\Lambda(n) = \\log p}")#text(" when ")#mi("{n}")#text(" is a power of a prime ")#mi("{p}")#text(" and zero otherwise. If we then perform a “Dirichlet-Fourier transform” by viewing both sides of ")#link(<tao-091e7397b79ab9c586b9>)[#text("(1)")]#text(" as coefficients of a ")#link("https://en.wikipedia.org/wiki/Dirichlet_series")[#text("Dirichlet series")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{\\log n}{n^s} = \\sum_{n=1}^\\infty \\sum_{d|n} \\frac{\\Lambda(d)}{n^s},")]]

#text("formally at least. Writing ")#mi("{n=dm}")#text(", the right-hand side factors as")

#align(center)[#tao-fit-display[#mitex("(\\sum_{d=1}^\\infty \\frac{\\Lambda(d)}{d^s}) (\\sum_{m=1}^\\infty \\frac{1}{m^s}) = \\zeta(s) \\sum_{n=1}^\\infty \\frac{\\Lambda(n)}{n^s}")]]

#text("whereas the left-hand side is (formally, at least) equal to ")#mi("{-\\zeta^{\\prime}(s)}")#text(". We conclude the identity")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{\\Lambda(n)}{n^s} = -\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)},")]]

#text("(formally, at least). If we integrate this, we are formally led to the identity")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{\\Lambda(n)}{\\log n} n^{-s} = \\log \\zeta(s)")]]

#text("or equivalently to the exponential identity ")#metadata(none) <tao-164200a298bafec89fd3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\zeta(s) = \\exp( \\sum_{n=1}^\\infty \\frac{\\Lambda(n)}{\\log n} n^{-s} )")]]

#text("which allows one to reconstruct the Riemann zeta function from the von Mangoldt function. (It is instructive exercise in enumerative combinatorics to try to prove this identity directly, at the level of formal Dirichlet series, using the fundamental theorem of arithmetic of course.) Now, as ")#mi("{\\zeta}")#text(" has a simple pole at ")#mi("{s=1}")#text(" and zeroes at various places ")#mi("{s=\\rho}")#text(" on the critical strip, we expect a ")#link("https://en.wikipedia.org/wiki/Weierstrass_factorization_theorem")[#text("Weierstrass factorisation")]#text(" which formally (ignoring normalisation issues) takes the form")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) = \\frac{1}{s-1} \\times \\prod_\\rho (s-\\rho) \\times \\ldots")]]

#text("(where we will be intentionally vague about what is hiding in the ")#mi("{\\ldots}")#text(" terms) and so we expect an expansion of the form ")#metadata(none) <tao-e00443c76cfe2be97aa8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{n=1}^\\infty \\frac{\\Lambda(n)}{\\log n} n^{-s} = - \\log(s-1) + \\sum_\\rho \\log(s-\\rho) + \\ldots.")]]

#text("Note that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{s-\\rho} = \\int_1^\\infty t^{\\rho-s} \\frac{dt}{t}")]]

#text("and hence on integrating in ")#mi("{s}")#text(" we formally have")

#align(center)[#tao-fit-display[#mitex("\\log(s-\\rho) = -\\int_1^\\infty t^{\\rho-s-1} \\frac{dt}{\\log t}")]]

#text("and thus we have the heuristic approximation")

#align(center)[#tao-fit-display[#mitex("\\log(s-\\rho) \\approx - \\sum_{n=1}^\\infty \\frac{n^{\\rho-s-1}}{\\log n}.")]]

#text("Comparing this with ")#link(<tao-e00443c76cfe2be97aa8>)[#text("(3)")]#text(", we are led to a heuristic form of the ")#emph[#text("explicit formula")]#text(" ")#metadata(none) <tao-14af5bad46869a3da576>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\Lambda(n) \\approx 1 - \\sum_\\rho n^{\\rho-1}.")]]

#text("When trying to make this heuristic rigorous, it turns out (due to the rough nature of both sides of ")#link(<tao-14af5bad46869a3da576>)[#text("(4)")]#text(") that one has to interpret the explicit formula in some suitably weak sense, for instance by testing ")#link(<tao-14af5bad46869a3da576>)[#text("(4)")]#text(" against the indicator function ")#mi("{1_{[0,x]}(n)}")#text(" to obtain the formula ")#metadata(none) <tao-8172a6ce75682e598b50>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{n \\leq x} \\Lambda(n) \\approx x - \\sum_\\rho \\frac{x^{\\rho}}{\\rho}")]]

#text("which can in fact be made into a rigorous statement after some truncation (the ")#link("https://en.wikipedia.org/wiki/Explicit_formula")[#text("von Mangoldt explicit formula")]#text("). From this formula we now see how helpful the Riemann hypothesis will be to control the distribution of the primes; indeed, if the Riemann hypothesis holds, so that ")#mi("{\\text{Re}(\\rho) = 1/2}")#text(" for all zeroes ")#mi("{\\rho}")#text(", it is not difficult to use (a suitably rigorous version of) the explicit formula to conclude that ")#metadata(none) <tao-94e7a26a83dbb1ee0ec4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{n \\leq x} \\Lambda(n) = x + O( x^{1/2} \\log^2 x )")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(", giving a near-optimal “square root cancellation” for the sum ")#mi("{\\sum_{n \\leq x} \\Lambda(n)-1}")#text(". Conversely, if one can somehow establish a bound of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) = x + O( x^{1/2+\\epsilon} )")]]

#text("for any fixed ")#mi("{\\epsilon}")#text(", then the explicit formula can be used to then deduce that all zeroes ")#mi("{\\rho}")#text(" of ")#mi("{\\zeta}")#text(" have real part at most ")#mi("{1/2+\\epsilon}")#text(", which leads to the following remarkable amplification phenomenon (analogous, as we will see later, to the ")#link("http://www.tricki.org/article/The_tensor_power_trick")[#text("tensor power trick")]#text("): any bound of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) = x + O( x^{1/2+o(1)} )")]]

#text("can be automatically amplified to the stronger bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) = x + O( x^{1/2} \\log^2 x )")]]

#text("with both bounds being equivalent to the Riemann hypothesis. Of course, the Riemann hypothesis for the Riemann zeta function remains open; but partial progress on this hypothesis (in the form of zero-free regions for the zeta function) leads to partial versions of the asymptotic ")#link(<tao-94e7a26a83dbb1ee0ec4>)[#text("(6)")]#text(". For instance, it is known that there are no zeroes of the zeta function on the line ")#mi("{\\text{Re}(s)=1}")#text(", and this can be shown by some analysis (either complex analysis or Fourier analysis) to be equivalent to the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) =x + o(x);")]]

#text("see e.g. ")#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/")[#text("this previous blog post")]#text(" for more discussion.")

#text("The main engine powering the above observations was the fundamental theorem of arithmetic, and so one can expect to establish similar assertions in other contexts where some version of the fundamental theorem of arithmetic is available. One of the simplest such variants is to continue working on the natural numbers, but “twist” them by a ")#link("https://en.wikipedia.org/wiki/Dirichlet_character")[#text("Dirichlet character")]#text(" ")#mi("{\\chi: {\\bf Z} \\rightarrow {\\bf R}}")#text(". The analogue of the Riemann zeta function is then the ")#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/Dirichlet $latex {L}&fg=000000$-function")[#text("https://en.wikipedia.org/wiki/Multiplicative_function")]#text(", the equation ")#link(<tao-091e7397b79ab9c586b9>)[#text("(1)")]#text(", which encoded the fundamental theorem of arithmetic, can be twisted by ")#mi("{\\chi}")#text(" to obtain ")#metadata(none) <tao-07da0fe7d48689e99408>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\chi(n) \\log n = \\sum_{d|n} \\chi(d) \\Lambda(d) \\chi(\\frac{n}{d})")]]

#text("and essentially the same manipulations as before eventually lead to the exponential identity ")#metadata(none) <tao-7d1c66e278298829c6c3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("L(s,\\chi) = \\exp( \\sum_{n=1}^\\infty \\frac{\\chi(n) \\Lambda(n)}{\\log n} n^{-s} ).")]]

#text("which is a twisted version of ")#link(<tao-164200a298bafec89fd3>)[#text("(2)")]#text(", as well as twisted explicit formula, which heuristically takes the form ")#metadata(none) <tao-d2494f5039245af8954d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\chi(n) \\Lambda(n) \\approx - \\sum_\\rho n^{\\rho-1}")]]

#text("for non-principal ")#mi("{\\chi}")#text(", where ")#mi("{\\rho}")#text(" now ranges over the zeroes of ")#mi("{L(s,\\chi)}")#text(" in the critical strip, rather than the zeroes of ")#mi("{\\zeta(s)}")#text("; a more accurate formulation, following ")#link(<tao-8172a6ce75682e598b50>)[#text("(5)")]#text(", would be ")#metadata(none) <tao-4f5d2d1816915837124e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\sum_{n \\leq x} \\chi(n) \\Lambda(n) \\approx - \\sum_\\rho \\frac{x^{\\rho}}{\\rho}.")]]

#text("(See e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=1790423")[#text("Davenport’s book")]#text(" for a more rigorous discussion which emphasises the analogy between the Riemann zeta function and the Dirichlet ")#mi("{L}")#text("-function.) If we assume the ")#link("https://en.wikipedia.org/wiki/Generalized_Riemann_hypothesis")[#text("generalised Riemann hypothesis")]#text(", which asserts that all zeroes of ")#mi("{L(s,\\chi)}")#text(" in the critical strip also lie on the critical line, then we obtain the bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\chi(n) \\Lambda(n) = O( x^{1/2} \\log(x) \\log(xq) )")]]

#text("for any non-principal Dirichlet character ")#mi("{\\chi}")#text(", again demonstrating a near-optimal square root cancellation for this sum. Again, we have the amplification property that the above bound is implied by the apparently weaker bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\chi(n) \\Lambda(n) = O( x^{1/2+o(1)} )")]]

#text("(where ")#mi("{o(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{x \\rightarrow \\infty}")#text(" for any fixed ")#mi("{q}")#text("). Next, one can consider other number systems than the natural numbers ")#mi("{{\\bf N}}")#text(" and integers ")#mi("{{\\bf Z}}")#text(". For instance, one can replace the integers ")#mi("{{\\bf Z}}")#text(" with rings ")#mi("{{\\mathcal O}_K}")#text(" of integers in other ")#link("https://en.wikipedia.org/wiki/Number_field")[#text("number fields")]#text(" ")#mi("{K}")#text(" (i.e. finite extensions of ")#mi("{{\\bf Q}}")#text("), such as the quadratic extensions ")#mi("{K = {\\bf Q}[\\sqrt{D}]}")#text(" of the rationals for various square-free integers ")#mi("{D}")#text(", in which case the ring of integers would be the ring of quadratic integers ")#mi("{{\\mathcal O}_K = {\\bf Z}[\\omega]}")#text(" for a suitable generator ")#mi("{\\omega}")#text(" (it turns out that one can take ")#mi("{\\omega = \\sqrt{D}}")#text(" if ")#mi("{D=2,3\\text{ mod } 4}")#text(", and ")#mi("{\\omega = \\frac{1+\\sqrt{D}}{2}}")#text(" if ")#mi("{D=1 \\text{ mod } 4}")#text("). Here, it is not immediately obvious what the analogue of the natural numbers ")#mi("{{\\bf N}}")#text(" is in this setting, since rings such as ")#mi("{{\\bf Z}[\\omega]}")#text(" do not come with a natural ordering. However, we can adopt an algebraic viewpoint to see the correct generalisation, observing that every natural number ")#mi("{n}")#text(" generates a ")#link("https://en.wikipedia.org/wiki/Principal_ideal")[#text("principal ideal")]#text(" ")#mi("{(n) = \\{ an: a \\in {\\bf Z} \\}}")#text(" in the integers, and conversely every non-trivial ideal ")#mi("{{\\mathfrak n}}")#text(" in the integers is associated to precisely one natural number ")#mi("{n}")#text(" in this fashion, namely the ")#link("https://en.wikipedia.org/wiki/Ideal_norm")[#text("norm")]#text(" ")#tao-math("{N({\\mathfrak n}) := \\left|{\\bf Z} / {\\mathfrak n}\\right|}", block: false)#text(" of that ideal. So one can identify the natural numbers with the ideals of ")#mi("{{\\bf Z}}")#text(". Furthermore, with this identification, the prime numbers correspond to the ")#link("https://en.wikipedia.org/wiki/Prime_ideal")[#text("prime ideals")]#text(", since if ")#mi("{p}")#text(" is prime, and ")#mi("{a,b}")#text(" are integers, then ")#mi("{ab \\in (p)}")#text(" if and only if one of ")#mi("{a \\in (p)}")#text(" or ")#mi("{b \\in (p)}")#text(" is true. Finally, even in number systems (such as ")#mi("{{\\bf Z}[\\sqrt{-5}]}")#text(") in which the classical version of the fundamental theorem of arithmetic fail (e.g. ")#mi("{6 = 2 \\times 3 = (1-\\sqrt{-5})(1+\\sqrt{-5})}")#text("), we have ")#emph[#text("the fundamental theorem of arithmetic for ideals")]#text(": every ideal ")#mi("{\\mathfrak{n}}")#text(" in a ")#link("https://en.wikipedia.org/wiki/Dedekind_domain")[#text("Dedekind domain")]#text(" (which includes the ring ")#mi("{{\\mathcal O}_K}")#text(" of integers in a number field as a key example) is uniquely representable (up to permutation) as the product of a finite number of prime ideals ")#mi("{\\mathfrak{p}}")#text(" (although these ideals might not necessarily be principal). For instance, in ")#mi("{{\\bf Z}[\\sqrt{-5}]}")#text(", the principal ideal ")#mi("{(6)}")#text(" factors as the product of four prime (but non-principal) ideals ")#mi("{(2, 1+\\sqrt{-5})}")#text(", ")#mi("{(2, 1-\\sqrt{-5})}")#text(", ")#mi("{(3, 1+\\sqrt{-5})}")#text(", ")#mi("{(3, 1-\\sqrt{-5})}")#text(". (Note that the first two ideals ")#mi("{(2,1+\\sqrt{5}), (2,1-\\sqrt{5})}")#text(" are actually equal to each other.) Because we still have the fundamental theorem of arithmetic, we can develop analogues of the previous observations relating the Riemann hypothesis to the distribution of primes. The analogue of the Riemann hypothesis is now the ")#link("https://en.wikipedia.org/wiki/Dedekind_zeta_function")[#text("Dedekind zeta function")]

#align(center)[#tao-fit-display[#mitex("\\zeta_K(s) := \\sum_{{\\mathfrak n}} \\frac{1}{N({\\mathfrak n})^s}")]]

#text("where the summation is over all non-trivial ideals in ")#mi("{{\\mathcal O}_K}")#text(". One can also define a von Mangoldt function ")#mi("{\\Lambda_K({\\mathfrak n})}")#text(", defined as ")#mi("{\\log N( {\\mathfrak p})}")#text(" when ")#mi("{{\\mathfrak n}}")#text(" is a power of a prime ideal ")#mi("{{\\mathfrak p}}")#text(", and zero otherwise; then the fundamental theorem of arithmetic for ideals can be encoded in an analogue of ")#link(<tao-091e7397b79ab9c586b9>)[#text("(1)")]#text(" (or ")#link(<tao-07da0fe7d48689e99408>)[#text("(7)")]#text("), ")#metadata(none) <tao-2c2157e6eae909789cde>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\log N({\\mathfrak n}) = \\sum_{{\\mathfrak d}|{\\mathfrak n}} \\Lambda_K({\\mathfrak d})")]]

#text("which leads as before to an exponential identity ")#metadata(none) <tao-7d3195c54a8d20c5b006>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\zeta_K(s) = \\exp( \\sum_{{\\mathfrak n}} \\frac{\\Lambda_K({\\mathfrak n})}{\\log N({\\mathfrak n})} N({\\mathfrak n})^{-s} )")]]

#text("and an explicit formula of the heuristic form")

#align(center)[#tao-fit-display[#mitex("\\Lambda({\\mathfrak n}) \\approx 1 - \\sum_\\rho N({\\mathfrak n})^{\\rho-1}")]]

#text("or, a little more accurately, ")#metadata(none) <tao-7fcbbe5db9d3167e5a05>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\sum_{N({\\mathfrak n}) \\leq x} \\Lambda({\\mathfrak n}) \\approx x - \\sum_\\rho \\frac{x^{\\rho}}{\\rho}")]]

#text("in analogy with ")#link(<tao-8172a6ce75682e598b50>)[#text("(5)")]#text(" or ")#link(<tao-4f5d2d1816915837124e>)[#text("(10)")]#text(". Again, a suitable Riemann hypothesis for the Dedekind zeta function leads to good asymptotics for the distribution of prime ideals, giving a bound of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{N({\\mathfrak n}) \\leq x} \\Lambda({\\mathfrak n}) = x + O( \\sqrt{x} \\log(x) (d+\\log(Dx)) )")]]

#text("where ")#mi("{D}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Conductor_(class_field_theory)")[#text("conductor")]#text(" of ")#mi("{K}")#text(" (which, in the case of number fields, is the absolute value of the ")#link("https://en.wikipedia.org/wiki/Discriminant_of_an_algebraic_number_field")[#text("discriminant")]#text(" of ")#mi("{K}")#text(") and ")#mi("{d = \\text{dim}_{\\bf Q}(K)}")#text(" is the degree of the extension of ")#mi("{K}")#text(" over ")#mi("{{\\bf Q}}")#text(". As before, we have the amplification phenomenon that the above near-optimal square root cancellation bound is implied by the weaker bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{N({\\mathfrak n}) \\leq x} \\Lambda({\\mathfrak n}) = x + O( x^{1/2+o(1)} )")]]

#text("where ")#mi("{o(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{x \\rightarrow \\infty}")#text(" (holding ")#mi("{K}")#text(" fixed). See e.g. Chapter 5 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec-Kowalski")]#text(" for details.")

#text("As was the case with the Dirichlet ")#mi("{L}")#text("-functions, one can twist the Dedekind zeta function example by characters, in this case the ")#link("http://en.wikipedia.org/wiki/Hecke_character")[#text("Hecke characters")]#text("; we will not do this here, but see e.g. Section 3 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec-Kowalski")]#text(" for details.")

#text("Very analogous considerations hold if we move from number fields to function fields. The simplest case is the function field associated to the affine line ")#mi("{{\\mathbb A}^1}")#text(" and a finite field ")#mi("{{\\mathbb F} = {\\mathbb F}_q}")#text(" of some order ")#mi("{q}")#text(". The polynomial functions on the affine line ")#mi("{{\\mathbb A}^1/{\\mathbb F}}")#text(" are just the usual polynomial ring ")#mi("{{\\mathbb F}[t]}")#text(", which then play the role of the integers ")#mi("{{\\bf Z}}")#text(" (or ")#mi("{{\\mathcal O}_K}")#text(") in previous examples. This ring happens to be a unique factorisation domain, so the situation is closely analogous to the classical setting of the Riemann zeta function. The analogue of the natural numbers are the ")#link("http://en.wikipedia.org/wiki/Monic_polynomial")[#text("monic polynomials")]#text(" (since every non-trivial principal ideal is generated by precisely one monic polynomial), and the analogue of the prime numbers are the irreducible monic polynomials. The norm ")#mi("{N(f)}")#text(" of a polynomial is the order of ")#mi("{{\\mathbb F}[t] / (f)}")#text(", which can be computed explicitly as")

#align(center)[#tao-fit-display[#mitex("N(f) = q^{\\text{deg}(f)}.")]]

#text("Because of this, we will normalise things slightly differently here and use ")#mi("{\\text{deg}(f)}")#text(" in place of ")#mi("{\\log N(f)}")#text(" in what follows. The (local) zeta function ")#mi("{\\zeta_{{\\mathbb A}^1/{\\mathbb F}}(s)}")#text(" is then defined as")

#align(center)[#tao-fit-display[#mitex("\\zeta_{{\\mathbb A}^1/{\\mathbb F}}(s) = \\sum_f \\frac{1}{N(f)^s}")]]

#text("where ")#mi("{f}")#text(" ranges over monic polynomials, and the von Mangoldt function ")#mi("{\\Lambda_{{\\mathbb A}^1/{\\mathbb F}}(f)}")#text(" is defined to equal ")#mi("{\\text{deg}(g)}")#text(" when ")#mi("{f}")#text(" is a power of a monic irreducible polynomial ")#mi("{g}")#text(", and zero otherwise. Note that because ")#mi("{N(f)}")#text(" is always a power of ")#mi("{q}")#text(", the zeta function here is in fact periodic with period ")#mi("{2\\pi i / \\log q}")#text(". Because of this, it is customary to make a change of variables ")#mi("{T := q^{-s}}")#text(", so that")

#align(center)[#tao-fit-display[#mitex("\\zeta_{{\\mathbb A}^1/{\\mathbb F}}(s) = Z( {\\mathbb A}^1/{\\mathbb F}, T )")]]

#text("and ")#mi("{Z}")#text(" is the renormalised zeta function ")#metadata(none) <tao-4847694a6f9783c1ae70>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("Z( {\\mathbb A}^1/{\\mathbb F}, T ) = \\sum_f T^{\\text{deg}(f)}.")]]

#text("We have the analogue of ")#link(<tao-091e7397b79ab9c586b9>)[#text("(1)")]#text(" (or ")#link(<tao-07da0fe7d48689e99408>)[#text("(7)")]#text(" or ")#link(<tao-2c2157e6eae909789cde>)[#text("(11)")]#text("): ")#metadata(none) <tao-f4bf859bc4602dcb6ad5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\text{deg}(f) = \\sum_{g|f} \\Lambda_{{\\mathbb A}^1/{\\mathbb F}}(g),")]]

#text("which leads as before to an exponential identity ")#metadata(none) <tao-46b9219f8624018116cc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("Z( {\\mathbb A}^1/{\\mathbb F}, T ) = \\exp( \\sum_f \\frac{\\Lambda_{{\\mathbb A}^1/{\\mathbb F}}(f)}{\\text{deg}(f)} T^{\\text{deg}(f)} )")]]

#text("analogous to ")#link(<tao-164200a298bafec89fd3>)[#text("(2)")]#text(", ")#link(<tao-7d1c66e278298829c6c3>)[#text("(8)")]#text(", or ")#link(<tao-7d3195c54a8d20c5b006>)[#text("(12)")]#text(". It also leads to the explicit formula")

#align(center)[#tao-fit-display[#mitex("\\Lambda_{{\\mathbb A}^1/{\\mathbb F}}(f) \\approx 1 - \\sum_\\rho N(f)^{\\rho-1}")]]

#text("where ")#mi("{\\rho}")#text(" are the zeroes of the original zeta function ")#mi("{\\zeta_{{\\mathbb A}^1/{\\mathbb F}}(s)}")#text(" (counting each residue class of the period ")#mi("{2\\pi i/\\log q}")#text(" just once), or equivalently")

#align(center)[#tao-fit-display[#mitex("\\Lambda_{{\\mathbb A}^1/{\\mathbb F}}(f) \\approx 1 - q^{-\\text{deg}(f)} \\sum_\\alpha \\alpha^{\\text{deg}(f)},")]]

#text("where ")#mi("{\\alpha}")#text(" are the reciprocals of the roots of the normalised zeta function ")#mi("{Z( {\\mathbb A}^1/{\\mathbb F}, T )}")#text(" (or to put it another way, ")#mi("{1-\\alpha T}")#text(" are the factors of this zeta function). Again, to make proper sense of this heuristic we need to sum, obtaining")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\text{deg}(f) = n} \\Lambda_{{\\mathbb A}^1/{\\mathbb F}}(f) \\approx q^n - \\sum_\\alpha \\alpha^n.")]]

#text("As it turns out, in the function field setting, the zeta functions are always rational (this is part of the ")#link("http://en.wikipedia.org/wiki/Weil_conjectures")[#text("Weil conjectures")]#text("), and the above heuristic formula is basically exact up to a constant factor, thus ")#metadata(none) <tao-df3fbd4e10c08e293fda>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\sum_{\\text{deg}(f) = n} \\Lambda_{{\\mathbb A}^1/{\\mathbb F}}(f) = q^n - \\sum_\\alpha \\alpha^n + c")]]

#text("for an explicit integer ")#mi("{c}")#text(" (independent of ")#mi("{n}")#text(") arising from any potential pole of ")#mi("{Z}")#text(" at ")#mi("{T=1}")#text(". In the case of the affine line ")#mi("{{\\mathbb A}^1}")#text(", the situation is particularly simple, because the zeta function ")#mi("{Z( {\\mathbb A}^1/{\\mathbb F}, T)}")#text(" is easy to compute. Indeed, since there are exactly ")#mi("{q^n}")#text(" monic polynomials of a given degree ")#mi("{n}")#text(", we see from ")#link(<tao-4847694a6f9783c1ae70>)[#text("(14)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("Z( {\\mathbb A}^1/{\\mathbb F}, T ) = \\sum_{n=0}^\\infty q^n T^n = \\frac{1}{1-qT}")]]

#text("so in fact there are no zeroes whatsoever, and no pole at ")#mi("{T=1}")#text(" either, so we have an exact prime number theorem for this function field: ")#metadata(none) <tao-b747047a1e4c9442afd9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\sum_{\\text{deg}(f) = n} \\Lambda_{{\\mathbb A}^1/{\\mathbb F}}(f) = q^n")]]

#text("Among other things, this tells us that the number of irreducible monic polynomials of degree ")#mi("{n}")#text(" is ")#mi("{q^n/n + O(q^{n/2})}")#text(".")

#text("We can transition from an algebraic perspective to a geometric one, by viewing a given monic polynomial ")#mi("{f \\in {\\mathbb F}[t]}")#text(" through its roots, which are a finite set of points in the algebraic closure ")#mi("{\\overline{{\\mathbb F}}}")#text(" of the finite field ")#mi("{{\\mathbb F}}")#text(" (or more suggestively, as points on the affine line ")#mi("{{\\mathbb A}^1( \\overline{{\\mathbb F}} )}")#text("). The number of such points (counting multiplicity) is the degree of ")#mi("{f}")#text(", and from the factor theorem, the set of points determines the monic polynomial ")#mi("{f}")#text(" (or, if one removes the monic hypothesis, it determines the polynomial ")#mi("{f}")#text(" projectively). These points have an action of the ")#link("http://en.wikipedia.org/wiki/Galois_group")[#text("Galois group")]#text(" ")#mi("{\\text{Gal}( \\overline{{\\mathbb F}} / {\\mathbb F} )}")#text(". It is a classical fact that this Galois group is in fact a cyclic group generated by a single element, the (geometric) ")#link("http://en.wikipedia.org/wiki/Frobenius_map")[#text("Frobenius map")]#text(" ")#mi("{\\text{Frob}: x \\mapsto x^q}")#text(", which fixes the elements of the original finite field ")#mi("{{\\mathbb F}}")#text(" but permutes the other elements of ")#mi("{\\overline{{\\mathbb F}}}")#text(". Thus the roots of a given polynomial ")#mi("{f}")#text(" split into orbits of the Frobenius map. One can check that the roots consist of a single such orbit (counting multiplicity) if and only if ")#mi("{f}")#text(" is irreducible; thus the fundamental theorem of arithmetic can be viewed geometrically as as the orbit decomposition of any Frobenius-invariant finite set of points in the affine line.")

#text("Now consider the degree ")#mi("{n}")#text(" finite field extension ")#mi("{{\\mathbb F}_n}")#text(" of ")#mi("{{\\mathbb F}}")#text(" (it is a classical fact that there is exactly one such extension up to isomorphism for each ")#mi("{n}")#text("); this is a subfield of ")#mi("{\\overline{{\\mathbb F}}}")#text(" of order ")#mi("{q^n}")#text(". (Here we are performing a standard abuse of notation by overloading the subscripts in the ")#mi("{{\\mathbb F}}")#text(" notation; thus ")#mi("{{\\mathbb F}_q}")#text(" denotes the field of order ")#mi("{q}")#text(", while ")#mi("{{\\mathbb F}_n}")#text(" denotes the extension of ")#mi("{{\\mathbb F} = {\\mathbb F}_q}")#text(" of order ")#mi("{n}")#text(", so that we in fact have ")#mi("{{\\mathbb F}_n = {\\mathbb F}_{q^n}}")#text(" if we use one subscript convention on the left-hand side and the other subscript convention on the right-hand side. We hope this overloading will not cause confusion.) Each point ")#mi("{x}")#text(" in this extension (or, more suggestively, the affine line ")#mi("{{\\mathbb A}^1({\\mathbb F}_n)}")#text(" over this extension) has a ")#link("http://en.wikipedia.org/wiki/Minimal_polynomial_(field_theory)")[#text("minimal polynomial")]#text(" – an irreducible monic polynomial whose roots consist the Frobenius orbit of ")#mi("{x}")#text(". Since the Frobenius action is periodic of period ")#mi("{n}")#text(" on ")#mi("{{\\mathbb F}_n}")#text(", the degree of this minimal polynomial must divide ")#mi("{n}")#text(". Conversely, every monic irreducible polynomial of degree ")#mi("{d}")#text(" dividing ")#mi("{n}")#text(" produces ")#mi("{d}")#text(" distinct zeroes that lie in ")#mi("{{\\mathbb F}_d}")#text(" (here we use the classical fact that finite fields are ")#link("http://en.wikipedia.org/wiki/Perfect_field")[#text("perfect")]#text(") and hence in ")#mi("{{\\mathbb F}_n}")#text(". We have thus partitioned ")#mi("{{\\mathbb A}^1({\\mathbb F}_n)}")#text(" into Frobenius orbits (also known as ")#emph[#text("closed points")]#text("), with each monic irreducible polynomial ")#mi("{f}")#text(" of degree ")#mi("{d}")#text(" dividing ")#mi("{n}")#text(" contributing an orbit of size ")#mi("{d = \\text{deg}(f) = \\Lambda(f^{n/d})}")#text(". From this we conclude a geometric interpretation of the left-hand side of ")#link(<tao-b747047a1e4c9442afd9>)[#text("(18)")]#text(": ")#metadata(none) <tao-1f638d48d9ad50c436da>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\sum_{\\text{deg}(f) = n} \\Lambda_{{\\mathbb A}^1/{\\mathbb F}}(f) = \\sum_{x \\in {\\mathbb A}^1({\\mathbb F}_n)} 1.")]]

#text("The identity ")#link(<tao-b747047a1e4c9442afd9>)[#text("(18)")]#text(" thus is equivalent to the thoroughly boring fact that the number of ")#mi("{{\\mathbb F}_n}")#text("-points on the affine line ")#mi("{{\\mathbb A}^1}")#text(" is equal to ")#mi("{q^n}")#text(". However, things become much more interesting if one then replaces the affine line ")#mi("{{\\mathbb A}^1}")#text(" by a more general (geometrically) irreducible curve ")#mi("{C}")#text(" defined over ")#mi("{{\\mathbb F}}")#text("; for instance one could take ")#mi("{C}")#text(" to be an ellpitic curve ")#metadata(none) <tao-8198cf44658ba5777e75>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("E = \\{ (x,y): y^2 = x^3 + ax + b \\}")]]

#text("for some suitable ")#mi("{a,b \\in {\\mathbb F}}")#text(", although the discussion here applies to more general curves as well (though to avoid some minor technicalities, we will assume that the curve is projective with a finite number of ")#mi("{{\\mathbb F}}")#text("-rational points removed). The analogue of ")#mi("{{\\mathbb F}[t]}")#text(" is then the coordinate ring of ")#mi("{C}")#text(" (for instance, in the case of the elliptic curve ")#link(<tao-8198cf44658ba5777e75>)[#text("(20)")]#text(" it would be ")#mi("{{\\mathbb F}[x,y] / (y^2-x^3-ax-b)}")#text("), with polynomials in this ring producing a set of roots in the curve ")#mi("{C( \\overline{\\mathbb F})}")#text(" that is again invariant with respect to the Frobenius action (acting on the ")#mi("{x}")#text(" and ")#mi("{y}")#text(" coordinates separately). In general, we do not expect unique factorisation in this coordinate ring (this is basically because ")#link("http://en.wikipedia.org/wiki/B%C3%A9zout%27s_theorem")[#text("Bezout’s theorem")]#text(" suggests that the zero set of a polynomial on ")#mi("{C}")#text(" will almost never consist of a single (closed) point). Of course, we can use the algebraic formalism of ideals to get around this, setting up a zeta function")

#align(center)[#tao-fit-display[#mitex("\\zeta_{C/{\\mathbb F}}(s) = \\sum_{{\\mathfrak f}} \\frac{1}{N({\\mathfrak f})^s}")]]

#text("and a von Mangoldt function ")#mi("{\\Lambda_{C/{\\mathbb F}}({\\mathfrak f})}")#text(" as before, where ")#mi("{{\\mathfrak f}}")#text(" would now run over the non-trivial ideals of the coordinate ring. However, it is more instructive to use the geometric viewpoint, using the ideal-variety dictionary from algebraic geometry to convert algebraic objects involving ideals into geometric objects involving varieties. In this dictionary, a non-trivial ideal would correspond to a proper subvariety (or more precisely, a subscheme, but let us ignore the distinction between varieties and schemes here) of the curve ")#mi("{C}")#text("; as the curve is irreducible and one-dimensional, this subvariety must be zero-dimensional and is thus a (multi-)set of points ")#mi("{\\{x_1,\\ldots,x_k\\}}")#text(" in ")#mi("{C}")#text(", or equivalently an ")#link("http://en.wikipedia.org/wiki/Divisor_(algebraic_geometry)")[#text("effective divisor")]#text(" ")#mi("{[x_1] + \\ldots + [x_k]}")#text(" of ")#mi("{C}")#text("; this generalises the concept of the set of roots of a polynomial (which corresponds to the case of a principal ideal). Furthermore, this divisor has to be ")#emph[#text("rational")]#text(" in the sense that it is Frobenius-invariant. The prime ideals correspond to those divisors (or sets of points) which are irreducible, that is to say the individual Frobenius orbits, also known as ")#link("http://en.wikipedia.org/wiki/Closed_point")[#text("closed points")]#text(" of ")#mi("{C}")#text(". With this dictionary, the zeta function becomes")

#align(center)[#tao-fit-display[#mitex("\\zeta_{C/{\\mathbb F}}(s) = \\sum_{D \\geq 0} \\frac{1}{q^{\\text{deg}(D)}}")]]

#text("where the sum is over effective rational divisors ")#mi("{D}")#text(" of ")#mi("{C}")#text(" (with ")#mi("{k}")#text(" being the degree of an effective divisor ")#mi("{[x_1] + \\ldots + [x_k]}")#text("), or equivalently")

#align(center)[#tao-fit-display[#mitex("Z( C/{\\mathbb F}, T ) = \\sum_{D \\geq 0} T^{\\text{deg}(D)}.")]]

#text("The analogue of ")#link(<tao-1f638d48d9ad50c436da>)[#text("(19)")]#text(", which gives a geometric interpretation to sums of the von Mangoldt function, becomes")

#tao-aligned(keep: true)[


#tao-math("\\sum_{N({\\mathfrak f}) = q^n} \\Lambda_{C/{\\mathbb F}}({\\mathfrak f})  & = \\sum_{x \\in C({\\mathbb F}_n)} 1", block: true)



#tao-math(" & = \\left|C({\\mathbb F}_n)\\right|,", block: true)
]

#text("thus this sum is simply counting the number of ")#mi("{{\\mathbb F}_n}")#text("-points of ")#mi("{C}")#text(". The analogue of the exponential identity ")#link(<tao-46b9219f8624018116cc>)[#text("(16)")]#text(" (or ")#link(<tao-164200a298bafec89fd3>)[#text("(2)")]#text(", ")#link(<tao-7d1c66e278298829c6c3>)[#text("(8)")]#text(", or ")#link(<tao-7d3195c54a8d20c5b006>)[#text("(12)")]#text(") is then ")#metadata(none) <tao-9981661c03b5d4a67d33>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("Z( C/{\\mathbb F}, T ) = \\exp( \\sum_{n \\geq 1} \\frac{\\left|C({\\mathbb F}_n)\\right|}{n} T^n )", block: true)]]

#text("and the analogue of the explicit formula ")#link(<tao-df3fbd4e10c08e293fda>)[#text("(17)")]#text(" (or ")#link(<tao-8172a6ce75682e598b50>)[#text("(5)")]#text(", ")#link(<tao-4f5d2d1816915837124e>)[#text("(10)")]#text(" or ")#link(<tao-7fcbbe5db9d3167e5a05>)[#text("(13)")]#text(") is ")#metadata(none) <tao-ca978112ca1bbdcafac2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#tao-math("\\left|C({\\mathbb F}_n)\\right| = q^n - \\sum_\\alpha \\alpha^n + c", block: true)]]

#text("where ")#mi("{\\alpha}")#text(" runs over the (reciprocal) zeroes of ")#mi("{Z( C/{\\mathbb F}, T )}")#text(" (counting multiplicity), and ")#mi("{c}")#text(" is an integer independent of ")#mi("{n}")#text(". (As it turns out, ")#mi("{c}")#text(" equals ")#mi("{1}")#text(" when ")#mi("{C}")#text(" is a projective curve, and more generally equals ")#mi("{1-k}")#text(" when ")#mi("{C}")#text(" is a projective curve with ")#mi("{k}")#text(" rational points deleted.)")

#text("To evaluate ")#mi("{Z(C/{\\mathbb F},T)}")#text(", one needs to count the number of effective divisors of a given degree on the curve ")#mi("{C}")#text(". Fortunately, there is a tool that is particularly well-designed for this task, namely the ")#link("http://en.wikipedia.org/wiki/Riemann-Roch_Theorem")[#text("Riemann-Roch theorem")]#text(". By using this theorem, one can show (when ")#mi("{C}")#text(" is projective) that ")#mi("{Z(C/{\\mathbb F},T)}")#text(" is in fact a rational function, with a finite number of zeroes, and a simple pole at both ")#mi("{1}")#text(" and ")#mi("{1/q}")#text(", with similar results when one deletes some rational points from ")#mi("{C}")#text("; see e.g. Chapter 11 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec-Kowalski")]#text(" for details. Thus the sum in ")#link(<tao-ca978112ca1bbdcafac2>)[#text("(22)")]#text(" is finite. For instance, for the affine elliptic curve ")#link(<tao-8198cf44658ba5777e75>)[#text("(20)")]#text(" (which is a projective curve with one point removed), it turns out that we have")

#align(center)[#tao-fit-display[#tao-math("\\left|E({\\mathbb F}_n)\\right| = q^n - \\alpha^n - \\beta^n", block: true)]]

#text("for two complex numbers ")#mi("{\\alpha,\\beta}")#text(" depending on ")#mi("{E}")#text(" and ")#mi("{q}")#text(".")

#text("The Riemann hypothesis for (untwisted) curves – which is the deepest and most difficult aspect of the ")#link("http://en.wikipedia.org/wiki/Weil_conjectures")[#text("Weil conjectures")]#text(" for these curves – asserts that the zeroes of ")#mi("{\\zeta_{C/{\\mathbb F}}}")#text(" lie on the critical line, or equivalently that all the roots ")#mi("{\\alpha}")#text(" in ")#link(<tao-ca978112ca1bbdcafac2>)[#text("(22)")]#text(" have modulus ")#mi("{\\sqrt{q}}")#text(", so that ")#link(<tao-ca978112ca1bbdcafac2>)[#text("(22)")]#text(" then gives the asymptotic ")#metadata(none) <tao-ff2082aa78aea80a27cb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#tao-math("\\left|C({\\mathbb F}_n)\\right| = q^n + O( q^{n/2} )", block: true)]]

#text("where the implied constant depends only on the genus of ")#mi("{C}")#text(" (and on the number of points removed from ")#mi("{C}")#text("). For instance, for elliptic curves we have the ")#emph[#text("Hasse bound")]

#align(center)[#tao-fit-display[#tao-math("\\left|E({\\mathbb F}_n) - q^n\\right| \\leq 2 \\sqrt{q}.", block: true)]]

#text("As before, we have an important amplification phenomenon: if we can establish a weaker estimate, e.g. ")#metadata(none) <tao-7349efaa0c559c387dfa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#tao-math("\\left|C({\\mathbb F}_n)\\right| = q^n + O( q^{n/2 + O(1)} ),", block: true)]]

#text("then we can automatically deduce the stronger bound ")#link(<tao-ff2082aa78aea80a27cb>)[#text("(23)")]#text(". This amplification is not a mere curiosity; most of the ")#emph[#text("proofs")]#text(" of the Riemann hypothesis for curves proceed via this fact. For instance, by using the elementary method of Stepanov to bound points in curves (discussed for instance in ")#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/")[#text("this previous post")]#text("), one can establish the preliminary bound ")#link(<tao-7349efaa0c559c387dfa>)[#text("(24)")]#text(" for large ")#mi("{n}")#text(", which then amplifies to the optimal bound ")#link(<tao-ff2082aa78aea80a27cb>)[#text("(23)")]#text(" for all ")#mi("{n}")#text(" (and in particular for ")#mi("{n=1}")#text("). Again, see Chapter 11 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec-Kowalski")]#text(" for details. The ability to convert a bound with ")#mi("{q}")#text("-dependent losses over the optimal bound (such as ")#link(<tao-7349efaa0c559c387dfa>)[#text("(24)")]#text(") into an essentially optimal bound with no ")#mi("{q}")#text("-dependent losses (such as ")#link(<tao-ff2082aa78aea80a27cb>)[#text("(23)")]#text(") is important in analytic number theory, since in many applications (e.g. in those arising from sieve theory) one wishes to sum over large ranges of ")#mi("{q}")#text(".")

#text("Much as the Riemann zeta function can be twisted by a Dirichlet character to form a Dirichlet ")#mi("{L}")#text("-function, one can twist the zeta function on curves by various additive and multiplicative characters. For instance, suppose one has an affine plane curve ")#mi("{C \\subset {\\mathbb A}^2}")#text(" and an additive character ")#mi("{\\psi: {\\mathbb F}^2 \\rightarrow {\\bf C}^\\times}")#text(", thus ")#mi("{\\psi(x+y) = \\psi(x) \\psi(y)}")#text(" for all ")#mi("{x,y \\in {\\mathbb F}^2}")#text(". Given a rational effective divisor ")#mi("{D = [x_1] + \\ldots + [x_k]}")#text(", the sum ")#mi("{x_1+\\ldots+x_k}")#text(" is Frobenius-invariant and thus lies in ")#mi("{{\\mathbb F}^2}")#text(". By abuse of notation, we may thus define ")#mi("{\\psi}")#text(" on such divisors by")

#align(center)[#tao-fit-display[#mitex("\\psi( [x_1] + \\ldots + [x_k] ) := \\psi( x_1 + \\ldots + x_k )")]]

#text("and observe that ")#mi("{\\psi}")#text(" is multiplicative in the sense that ")#mi("{\\psi(D_1 + D_2) = \\psi(D_1) \\psi(D_2)}")#text(" for rational effective divisors ")#mi("{D_1,D_2}")#text(". One can then define ")#mi("{\\psi({\\mathfrak f})}")#text(" for any non-trivial ideal ")#mi("{{\\mathfrak f}}")#text(" by replacing that ideal with the associated rational effective divisor; for instance, if ")#mi("{f}")#text(" is a polynomial in the coefficient ring of ")#mi("{C}")#text(", with zeroes at ")#mi("{x_1,\\ldots,x_k \\in C}")#text(", then ")#mi("{\\psi((f))}")#text(" is ")#mi("{\\psi( x_1+\\ldots+x_k )}")#text(". Again, we have the multiplicativity property ")#mi("{\\psi({\\mathfrak f} {\\mathfrak g}) = \\psi({\\mathfrak f}) \\psi({\\mathfrak g})}")#text(". If we then form the twisted normalised zeta function")

#align(center)[#tao-fit-display[#mitex("Z( C/{\\mathbb F}, \\psi, T ) = \\sum_{D \\geq 0} \\psi(D) T^{\\text{deg}(D)}")]]

#text("then by twisting the previous analysis, we eventually arrive at the exponential identity ")#metadata(none) <tao-bf4c210159573d9cc9f8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("Z( C/{\\mathbb F}, \\psi, T ) = \\exp( \\sum_{n \\geq 1} \\frac{S_n(C/{\\mathbb F}, \\psi)}{n} T^n )")]]

#text("in analogy with ")#link(<tao-9981661c03b5d4a67d33>)[#text("(21)")]#text(" (or ")#link(<tao-164200a298bafec89fd3>)[#text("(2)")]#text(", ")#link(<tao-7d1c66e278298829c6c3>)[#text("(8)")]#text(", ")#link(<tao-7d3195c54a8d20c5b006>)[#text("(12)")]#text(", or ")#link(<tao-46b9219f8624018116cc>)[#text("(16)")]#text("), where the ")#emph[#text("companion sums")]#text(" ")#mi("{S_n(C/{\\mathbb F}, \\psi)}")#text(" are defined by")

#align(center)[#tao-fit-display[#mitex("S_n(C/{\\mathbb F},\\psi) = \\sum_{x \\in C({\\mathbb F}^n)} \\psi( \\text{Tr}_{{\\mathbb F}_n/{\\mathbb F}}(x) )")]]

#text("where the trace ")#mi("{\\text{Tr}_{{\\mathbb F}_n/{\\mathbb F}}(x)}")#text(" of an element ")#mi("{x}")#text(" in the plane ")#mi("{{\\mathbb A}^2( {\\mathbb F}_n )}")#text(" is defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\text{Tr}_{{\\mathbb F}_n/{\\mathbb F}}(x) = x + \\text{Frob}(x) + \\ldots + \\text{Frob}^{n-1}(x).")]]

#text("In particular, ")#mi("{S_1}")#text(" is the exponential sum")

#align(center)[#tao-fit-display[#mitex("S_1(C/{\\mathbb F},\\psi) = \\sum_{x \\in C({\\mathbb F})} \\psi(x)")]]

#text("which is an important type of sum in analytic number theory, containing for instance the Kloosterman sum")

#align(center)[#tao-fit-display[#mitex("K(a,b;p) := \\sum_{x \\in {\\mathbb F}_p^\\times} e_p( ax + \\frac{b}{x})")]]

#text("as a special case, where ")#mi("{a,b \\in {\\mathbb F}_p^\\times}")#text(". (NOTE: the sign conventions for the companion sum ")#mi("{S_n}")#text(" are not consistent across the literature, sometimes it is ")#mi("{-S_n}")#text(" which is referred to as the companion sum.)")

#text("If ")#mi("{\\psi}")#text(" is non-principal (and ")#mi("{C}")#text(" is non-linear), one can show (by a suitably twisted version of the Riemann-Roch theorem) that ")#mi("{Z}")#text(" is a rational function of ")#mi("{T}")#text(", with no pole at ")#mi("{T=q^{-1}}")#text(", and one then gets an explicit formula of the form ")#metadata(none) <tao-3e23e8160039594a3389>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("S_n(C/{\\mathbb F},\\psi) = -\\sum_\\alpha \\alpha^n + c")]]

#text("for the companion sums, where ")#mi("{\\alpha}")#text(" are the reciprocals of the zeroes of ")#mi("{S}")#text(", in analogy to ")#link(<tao-ca978112ca1bbdcafac2>)[#text("(22)")]#text(" (or ")#link(<tao-8172a6ce75682e598b50>)[#text("(5)")]#text(", ")#link(<tao-4f5d2d1816915837124e>)[#text("(10)")]#text(", ")#link(<tao-7fcbbe5db9d3167e5a05>)[#text("(13)")]#text(", or ")#link(<tao-df3fbd4e10c08e293fda>)[#text("(17)")]#text("). For instance, in the case of Kloosterman sums, there is an identity of the form ")#metadata(none) <tao-2e7d2c03a9507ae265ec>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\sum_{x \\in {\\mathbb F}_{p^n}^\\times} e_p( a \\text{Tr}(x) + \\frac{b}{\\text{Tr}(x)}) = -\\alpha^n - \\beta^n")]]

#text("for all ")#mi("{n}")#text(" and some complex numbers ")#mi("{\\alpha,\\beta}")#text(" depending on ")#mi("{a,b,p}")#text(", where we have abbreviated ")#mi("{\\text{Tr}_{{\\mathbb F}_{p^n}/{\\mathbb F}_p}}")#text(" as ")#mi("{\\text{Tr}}")#text(". As before, the Riemann hypothesis for ")#mi("{Z}")#text(" then gives a square root cancellation bound of the form ")#metadata(none) <tao-5f3731b52ad0fb2f820b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("S_n(C/{\\mathbb F},\\psi) = O( q^{n/2} )")]]

#text("for the companion sums (and in particular gives the very explicit Weil bound ")#tao-math("{\\left|K(a,b;p)\\right| \\leq 2\\sqrt{p}}", block: false)#text(" for the Kloosterman sum), but again there is the amplification phenomenon that this sort of bound can be deduced from the apparently weaker bound")

#align(center)[#tao-fit-display[#mitex("S_n(C/{\\mathbb F},\\psi) = O( q^{n/2 + O(1)} ).")]]

#text("As before, most of the known proofs of the Riemann hypothesis for these twisted zeta functions proceed by first establishing this weaker bound (e.g. one could again use Stepanov’s method here for this goal) and then amplifying to the full bound ")#link(<tao-5f3731b52ad0fb2f820b>)[#text("(28)")]#text("; see Chapter 11 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec-Kowalski")]#text(" for further details.")

#text("One can also twist the zeta function on a curve by a multiplicative character ")#mi("{\\chi: {\\mathbb F}^\\times \\rightarrow {\\bf C}^\\times}")#text(" by similar arguments, except that instead of forming the sum ")#mi("{x_1+\\ldots+x_k}")#text(" of all the components of an effective divisor ")#mi("{[x_1]+\\ldots+[x_k]}")#text(", one takes the product ")#mi("{x_1 \\ldots x_k}")#text(" instead, and similarly one replaces the trace")

#align(center)[#tao-fit-display[#mitex("\\text{Tr}_{{\\mathbb F}_n/{\\mathbb F}}(x) = x + \\text{Frob}(x) + \\ldots + \\text{Frob}^{n-1}(x)")]]

#text("by the norm")

#align(center)[#tao-fit-display[#mitex("\\text{Norm}_{{\\mathbb F}_n/{\\mathbb F}}(x) = x \\cdot \\text{Frob}(x) \\cdot \\ldots \\cdot \\text{Frob}^{n-1}(x).")]]

#text("Again, see Chapter 11 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec-Kowalski")]#text(" for details.")

#text("Deligne famously extended the above theory to higher-dimensional varieties than curves, and also to the closely related context of ")#emph[#mi("{\\ell}")#text("-adic sheaves")]#text(" on curves, giving rise to two separate proofs of ")#link("http://en.wikipedia.org/wiki/Weil_conjectures")[#text("the Weil conjectures")]#text(" in full generality. (Very roughly speaking, the former context can be obtained from the latter context by a sort of Fubini theorem type argument that expresses sums on higher-dimensional varieties as iterated sums on curves of various expressions related to ")#mi("{\\ell}")#text("-adic sheaves.) In this higher-dimensional setting, the zeta function formalism is still present, but is much more difficult to use, in large part due to the much less tractable nature of divisors in higher dimensions (they are now combinations of codimension one subvarieties or subschemes, rather than combinations of points). To get around this difficulty, one has to change perspective yet again, from an algebraic or geometric perspective to an ")#mi("{\\ell}")#text("-adic cohomological perspective. (I could imagine that once one is sufficiently expert in the subject, all these perspectives merge back together into a unified viewpoint, but I am certainly not yet at that stage of understanding.) In particular, the zeta function, while still present, plays a significantly less prominent role in the analysis (at least if one is willing to take Deligne’s theorems as a black box); the explicit formula is now obtained via a different route, namely the ")#link("http://en.wikipedia.org/wiki/Lefschetz_fixed-point_theorem")[#text("Grothendieck-Lefschetz fixed point formula")]#text(". I have written some notes on this material below the fold (based in part on some lectures of Philippe Michel, as well as the text of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec-Kowalski")]#text(" and also ")#link("http://www.ams.org/mathscinet-getitem?mr=955052")[#text("this book of Katz")]#text("), but I should caution that my understanding here is still rather sketchy and possibly inaccurate in places.")

#metadata(none) <tao-2c2e3c88b9a877500c2e>

#heading(level: 1)[#strong[#text(" — 1. l-adic sheaves and the etale fundamental group — ")]]

#text("From the point of view of applications to analytic number theory, one can view Deligne’s theorems as providing bounds of square root cancellation type for various sums of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\in U( {\\mathbb F} )} K(x)")]]

#text("where ")#mi("{U}")#text(" is some (quasi-projective) curve (or possibly a higher dimensional variety), and ")#mi("{K}")#text(" is a certain type of “structured” function on the set ")#mi("{U({\\mathbb F})}")#text(" of ")#mi("{{\\mathbb F}}")#text("-rational points on ")#mi("{U}")#text(", such that ")#mi("{K}")#text(" is not entirely degenerate (e.g. constant). In particular, Deligne’s results allow one to obtain square root cancellation bounds of the form ")#metadata(none) <tao-c2759e00b2fbbcba07ae>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#tao-math("\\left|\\sum_{x \\in {\\mathbb F}}^* K(x)\\right| \\ll q^{1/2}", block: true)]]

#text("for certain non-degenerate structured functions ")#mi("{K}")#text(" defined on ")#mi("{{\\mathbb F}}")#text(" except at a few points where ")#mi("{K}")#text(" is “singular”, and the restricted sum ")#mi("{\\sum^*}")#text(" denotes a sum over the non-singular points of ")#mi("{K}")#text(".")

#text("The class of functions that can be treated by Deligne’s machinery is very general. The Weil conjectures for curves (and twisted curves) already allows one to obtain bounds of the shape ")#link(<tao-c2759e00b2fbbcba07ae>)[#text("(29)")]#text(" for several useful classes of functions ")#mi("{K(x)}")#text(", such as phases")

#align(center)[#tao-fit-display[#mitex("e_p( \\frac{P(x)}{Q(x)} )")]]

#text("of rational functions, multiplicative characters ")#mi("{\\chi: {\\mathbb F}^\\times \\rightarrow {\\bf C}}")#text(", or products of the two. Deligne’s results enlarge this class of functions to include Fourier transforms of existing structured functions, such as")

#align(center)[#tao-fit-display[#mitex("K(x) = \\frac{1}{\\sqrt{q}} \\sum_{y \\in {\\mathbb F}^\\times} e_q( \\frac{a}{y} + xy);")]]

#text("in fact the class of structured functions is closed under a large number of operations, such as addition, multiplication, convolution or pullback, making it an excellent class to use in analytic number theory applications. The situation here is not dissimilar to that of characters ")#mi("{\\chi: g \\mapsto \\text{tr}(\\rho(g))}")#text(" of finite-dimensional ")#link("http://en.wikipedia.org/wiki/Group_representation")[#text("representations")]#text(" ")#mi("{\\rho: G \\rightarrow GL(V)}")#text(" of some group ")#mi("{G}")#text(", in that the class of characters is also closed under basic operations such as addition and multiplication (which correspond to tensor sum and tensor product of representations). Indeed, the formal definition of a structured function will involve such a finite-dimensional representation, but with two technical details: the vector space ")#mi("{V}")#text(" is not exactly defined over the complex numbers, but instead defined over the ")#mi("{\\ell}")#text("-adic numbers for some prime ")#mi("{\\ell}")#text(" coprime to ")#mi("{q}")#text(", and also the group ")#mi("{G}")#text(" is going to be the ")#link("http://en.wikipedia.org/wiki/%C3%89tale_fundamental_group")[#text("étale fundamental group")]#text(" ")#mi("{\\pi_1^{et}(U({\\mathbb F}))}")#text(" of ")#mi("{U( {\\mathbb F} )}")#text(".")

#text("We first describe (in somewhat vague terms) what the étale fundamental group ")#mi("{\\pi_1^{et}(U)}")#text(" of a connected variety ")#mi("{U=U/k}")#text(" (or more generally, a connected Noetherian scheme) defined over a field ")#mi("{k}")#text(". Crucially, we do not require the underlying field ")#mi("{k}")#text(" to be algebraically closed, and in our applications ")#mi("{k}")#text(" will in fact be the finite field ")#mi("{{\\mathbb F}}")#text(". The étale fundamental group is the common generalisation of the (profinite completion of the) ")#link("http://en.wikipedia.org/wiki/Fundamental_group")[#text("topological fundamental group")]#text(" ")#mi("{\\pi_1(M)}")#text(" (applied to, say, a smooth complex variety), and of the absolute Galois group ")#mi("{\\text{Gal}(k_{sep}/k)}")#text(" of a field ")#mi("{k}")#text(". (This point of view is nicely presented in this ")#link("http://www.ams.org/mathscinet-getitem?mr=2548205")[#text("recent book of Szamuely")]#text(".) To explain this, we first consider the ")#emph[#text("topological")]#text(" ")#link("http://en.wikipedia.org/wiki/Fundamental_group")[#text("fundamental group")]#text(" ")#mi("{\\pi^{top}_1(M) = \\pi^{top}_1(M,p)}")#text(" of a smooth connected manifold ")#mi("{M}")#text(" at some base point ")#mi("{p}")#text(" (the choice of which is not too important if one is willing to view the fundamental group up to conjugacy). This group is conventionally defined in terms of loops in ")#mi("{M}")#text(" based at ")#mi("{p}")#text(", but the notion of a loop does not make much sense in either Galois theory or algebraic geometry. Fortunately, as observed by Grothendieck, there is an alternate way to interpret this fundamental group as follows. Let ")#mi("{N}")#text(" be any ")#link("http://en.wikipedia.org/wiki/Covering_space")[#text("covering space")]#text(" of ")#mi("{M}")#text(", with covering map ")#mi("{\\phi: N \\rightarrow M}")#text("; then above the base point ")#mi("{p}")#text(" there is a discrete fibre ")#mi("{\\phi^{-1}(\\{p\\})}")#text(", and given any point ")#mi("{q}")#text(" in this fibre, every loop based at ")#mi("{p}")#text(" lifts by ")#link("http://en.wikipedia.org/wiki/Monodromy")[#text("monodromy")]#text(" to a path starting at ")#mi("{q}")#text(" and ending at another point in the fibre ")#mi("{\\phi^{-1}(\\{p\\})}")#text(". The endpoint is not affected by homotopy of the path, so this leads to an action ")#mi("{g: q \\mapsto gq}")#text(" of the fundamental group ")#mi("{\\pi^{top}_1(M)}")#text(" (or more precisely, of the ")#link("http://en.wikipedia.org/wiki/Opposite_group")[#text("opposite group")]#text(" ")#mi("{\\pi^{top}_1(M)^{op}}")#text(" to this fundamental group, but never mind this annoying technicality) on the fibre ")#mi("{\\phi^{-1}(\\{p\\})}")#text(" above ")#mi("{p}")#text(" of any covering space. For instance, if we take the ")#mi("{m}")#text("-fold cover ")#mi("{m: {\\bf R}/{\\bf Z} \\rightarrow {\\bf R}/{\\bf Z}}")#text(" of the unit circle by itself formed by multplying by a natural number ")#mi("{m}")#text(", then the fibre may be identified with ")#mi("{{\\bf Z}/m{\\bf Z}}")#text(", and the fundamental group ")#mi("{\\pi_1({\\bf R}/{\\bf Z}) \\equiv {\\bf Z}}")#text(" acts on this fibre by translation.")

#text("The actions of the fundamental group are ")#link("http://en.wikipedia.org/wiki/Natural_transformation")[#text("natural")]#text(" in the following sense: given a morphism ")#mi("{f: N \\rightarrow N^{\\prime}}")#text(" between two covering spaces ")#mi("{\\phi: N \\rightarrow M}")#text(", ")#mi("{\\phi^{\\prime}: N^{\\prime} \\rightarrow M}")#text(" of ")#mi("{M}")#text(" (so that ")#mi("{\\phi^{\\prime} \\circ f = \\phi}")#text("), then the action of the fundamental group is intertwined by ")#mi("{f}")#text(", thus ")#mi("{f( g q) = g f(q)}")#text(" for any ")#mi("{q \\in \\phi^{-1}(\\{p\\})}")#text(" and ")#mi("{g \\in \\pi^{top}_1(M)}")#text(". Conversely, every collection of actions on fibres ")#mi("{\\phi^{-1}(\\{p\\})}")#text(" that is natural in the above sense arises from a unique element of the fundamental group ")#mi("{\\pi^{top}_1(M)}")#text("; this can be easily seen by working with the ")#link("http://en.wikipedia.org/wiki/Universal_cover#Universal_covers")[#text("universal cover")]#text(" ")#mi("{\\tilde M}")#text(" of ")#mi("{M}")#text(", of which all other (connected) covers are quotients, and on whose fibre the fundamental group acts freely and transitively. Thus, one could ")#emph[#text("define")]#text(" the fundamental group ")#mi("{\\pi^{top}_1(M)}")#text(" as the group of all possible collections of isomorphisms on the fibres ")#mi("{\\phi^{-1}(\\{p\\})}")#text(" above ")#mi("{p}")#text(" which are natural in the above sense. (In category-theoretic terms, ")#mi("{\\pi^{top}_1(M)}")#text(" is the group of natural isomorphisms of the fibre functor that maps covers ")#mi("{\\phi: N \\rightarrow M}")#text(" to fibres ")#mi("{\\phi^{-1}(\\{p\\})}")#text(".)")

#text("There is an analogous way to view the absolute Galois group ")#mi("{\\text{Gal}(k^{sep}/k)}")#text(" of a field ")#mi("{k}")#text(". For simplicity we shall only discuss the case of ")#link("http://en.wikipedia.org/wiki/Perfect_field")[#text("perfect")]#text(" fields (such as finite fields) here, in which case there is no distinction between the separable closure ")#mi("{k^{sep}}")#text(" and the algebraic closure ")#mi("{\\overline{k}}")#text(", although the discussion below can be extended to the general case (and from a scheme-theoretic viewpoint it is in fact natural to not restrict oneself to the perfect case). The analogue of the covering spaces ")#mi("{N}")#text(" of the manifold ")#mi("{M}")#text(" are the finite extensions ")#mi("{L}")#text(" of ")#mi("{k}")#text(". Here, one encounters a “contravariance” problem in pursuing this analogy: for covering spaces, we have a map ")#mi("{\\pi: N \\rightarrow M}")#text(" from the covering space ")#mi("{N}")#text(" to the base space ")#mi("{M}")#text("; but for field extensions, one instead has an inclusion ")#mi("{\\iota: k \\rightarrow L}")#text(" from the base field to the extension field. To make the analogy more accurate, one has to dualise, with the role of the covering space ")#mi("{N}")#text(" being played not by the extension ")#mi("{L}")#text(", but rather by the set ")#mi("{\\text{Hom}(L \\rightarrow \\overline{k})}")#text(" of all field embeddings of ")#mi("{L}")#text(" into the algebraic closure ")#mi("{\\overline{k}}")#text(" (cf. the ")#link("http://en.wikipedia.org/wiki/Yoneda_lemma")[#text("Yoneda lemma")]#text("). (There is nothing too special about the algebraic closure ")#mi("{\\overline{k}}")#text(" here; any field which is in some sense “large enough” to support lots of embeddings of ")#mi("{L}")#text(" would suffice.) This set projects down to ")#mi("{\\text{Hom}(k \\rightarrow \\overline{k})}")#text(", which has a canonical point ")#mi("{p}")#text(", namely the standard embedding of ")#mi("{k}")#text(" in ")#mi("{\\overline{k}}")#text("; the fibre of ")#mi("{\\text{Hom}(L \\rightarrow \\overline{k})}")#text(" at ")#mi("{p}")#text(" is then the set ")#mi("{\\text{Hom}_k(L \\rightarrow \\overline{k})}")#text(" of field embeddings of ")#mi("{L}")#text(" to ")#mi("{\\overline{k}}")#text(" that fix ")#mi("{k}")#text(". It is a basic fact of Galois theory that if ")#mi("{L}")#text(" is an extension of ")#mi("{k}")#text(" of degree ")#mi("{n}")#text(", then this fibre ")#mi("{\\text{Hom}_k(L \\rightarrow \\overline{k})}")#text(" is a finite set of cardinality ")#mi("{n}")#text(" (for perfect fields, this can be easily deduced from the ")#link("http://en.wikipedia.org/wiki/Primitive_element_theorem")[#text("primitive element theorem")]#text("). The Galois group ")#mi("{\\text{Gal}(\\overline{k}/k)}")#text(" then acts on these fibres ")#mi("{\\text{Hom}_k(L \\rightarrow \\overline{k})}")#text(" by left-composition, and one can verify that the action of a given Galois group element ")#mi("{g}")#text(" is natural in the same category-theoretic sense as considered previously. Conversely, because the algebraic closure ")#mi("{\\overline{k}}")#text(" of ")#mi("{k}")#text(" can be viewed as the ")#link("http://en.wikipedia.org/wiki/Direct_limit")[#text("direct limit")]#text(" of finite extensions of ")#mi("{k}")#text(", one can show that every natural isomorphism of these fibres (or more precisely, the fibre functor from ")#mi("{L}")#text(" (or ")#mi("{\\text{Hom}(L \\rightarrow \\overline{k})}")#text(") to ")#mi("{\\text{Hom}_k(L \\rightarrow \\overline{k})}")#text(") comes from exactly one element of the Galois group ")#mi("{\\text{Gal}(\\overline{k}/k)}")#text(".")

#text("Now we can define the étale fundamental group ")#mi("{\\pi^{top}_1(U)}")#text(" of a general (connected, Noetherian) scheme ")#mi("{U}")#text(" with a specified base point ")#mi("{p}")#text(". (Actually, one minor advantages of schemes is that they come with a canonical point to pick here, namely the ")#link("http://en.wikipedia.org/wiki/Generic_point")[#text("generic point")]#text(", although the dependence on the base point is not a major issue here in any event.) The analogue of covering spaces or finite extensions are now the ")#link("http://en.wikipedia.org/wiki/%C3%89tale_morphism")[#text("finite étale covers")]#text(" ")#mi("{\\phi: W \\rightarrow U}")#text(" of ")#mi("{U}")#text(": morphisms from another scheme ")#mi("{W}")#text(" to ")#mi("{U}")#text(" that are étale (which, roughly, is like saying ")#mi("{\\phi}")#text(" is a local diffeomorphism) and finite (roughly, this means that ")#mi("{W}")#text(" locally looks like the product of ")#mi("{U}")#text(" with a finite set). Unlike the previous two contexts, in which a universal covering object was available, the category of finite étale covers of a given scheme ")#mi("{U}")#text(" usually does not have a universal object. (One can already see this in the category of algebraic Riemann surfaces: the universal cover of the punctured plane ")#mi("{{\\bf C}^\\times}")#text(" ought to be the complex plane ")#mi("{{\\bf C}}")#text(" with covering map given by the exponential map ")#mi("{\\exp: {\\bf C} \\rightarrow {\\bf C}^\\times}")#text("; this is what happens in the topological setting, but it is not allowed in the algebraic geometry setting because the exponential map is not algebraic.) Nevertheless, one can still define the étale fundamental group without recourse to a universal object, again by using actions on fibres ")#mi("{\\phi^{-1}(\\{p\\})}")#text(". Namely, the étale fundamental group ")#mi("{\\pi_1(U)}")#text(" consists of all objects ")#mi("{g}")#text(" which act by permutation on the fibres ")#mi("{\\phi^{-1}(\\{p\\})}")#text(" above ")#mi("{p}")#text(" of every finite cover of ")#mi("{U}")#text(", in such a way that this action is natural in the category-theoretic sense. (To actually construct the étale fundamental group as a well-defined set requires a small amount of set-theoretic care, because strictly speaking the class of finite étale covers of ")#mi("{U}")#text(" is only a class and not a set; but one can start with one representative from each equivalence class of finite étale covers first, with some designated morphisms between them with which to enforce the naturality conditions, and build the fundamental group from there by an inverse limit construction; see e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=2548205")[#text("Szamuely’s book")]#text(" for details.) As the étale fundamental group is defined through its actions on finite sets rather than arbitrary discrete sets, it will automatically be a ")#link("http://en.wikipedia.org/wiki/Profinite_group")[#text("profinite group")]#text(", and so differs slightly from the topological fundamental group in that regard. For instance, the punctured complex plane ")#mi("{{\\bf C}^\\times}")#text(" has a topological fundamental group of ")#mi("{{\\bf Z}}")#text(", but has an étale fundamental group of ")#mi("{\\hat {\\bf Z} = \\lim_{\\leftarrow} {\\bf Z}/n{\\bf Z}}")#text(" – the profinite integers, rather than the rational integers. More generally, for complex varieties, the étale fundamental group is always the profinite completion of the topological fundamental group (this comes from a deep connection between complex geometry and algebraic geometry known as the ")#link("http://en.wikipedia.org/wiki/Algebraic_geometry_and_analytic_geometry#Riemann.27s_existence_theorem")[#text("Riemann existence theorem")]#text("), but the situation can be more complicated in finite characteristic or in non-algebraically closed fields, due to the existence of étale finite covers that do not arise from classical topological covers. For instance, the étale fundamental group of a perfect field ")#mi("{k}")#text(" (which one can view geometrically as a point over ")#mi("{k}")#text(") turns out to be the absolute Galois group of ")#mi("{k}")#text(".")

#text("The étale fundamental group is functorial: every morphism ")#mi("{\\phi: U \\rightarrow V}")#text(" of schemes gives rise to a homomorphism ")#mi("{\\phi_*: \\pi^{et}_1(U) \\rightarrow \\pi^{et}_1(V)}")#text(" of fundamental groups. Among other things, this gives rise to a short exact sequence")

#align(center)[#tao-fit-display[#mitex("1 \\rightarrow \\pi_1^{et}( U/\\overline{k} ) \\rightarrow \\pi_1^{et}( U/k ) \\rightarrow \\text{Gal}(\\overline{k}/k) \\rightarrow 1")]]

#text("whenever ")#mi("{U}")#text(" is a variety defined over a perfect field ")#mi("{k}")#text(" (and hence also defined over its algebraic closure ")#mi("{\\overline{k}}")#text(", via ")#link("http://en.wikipedia.org/wiki/Base_change")[#text("base change")]#text(") which is geometrically connected (i.e. that ")#mi("{U/\\overline{k}}")#text(" is connected). (Again, it is more natural from a scheme-theoretic perspective to not restrict to the perfect case here, but we will do so here for sake of concreteness.) The groups ")#mi("{\\pi_1^{et}( U/k )}")#text(" and ")#mi("{\\pi_1^{et}( U/\\overline{k} )}")#text(" are known as the ")#emph[#text("arithmetic fundamental group")]#text(" and ")#emph[#text("geometric fundamental group")]#text(" of ")#mi("{U}")#text(" respectively. The latter should be viewed as a profinite analogue of the topological fundamental group of (a complex model of) ")#mi("{U}")#text("; this intuition is quite accurate in characteristic zero (due to the Riemann existence theorem mentioned earlier), but only partially accurate in positive characteristic ")#mi("{p>0}")#text(" (basically, one has to work with the prime-to-")#mi("{p}")#text(" components of these groups in order to see the correspondence). (See for instance ")#link("http://www.jmilne.org/math/CourseNotes/LEC.pdf")[#text("these notes of Milne")]#text(" for further discussion.)")

#text("The étale fundamental group ")#mi("{\\pi_1^{et}(U/k)}")#text(" can also be described “explicitly” in terms of Galois groups as follows. [Caution: I am not 100% confident in the accuracy of the assertions in this paragraph.] Let ")#mi("{K = k(U)}")#text(" be the ")#link("http://en.wikipedia.org/wiki/Function_field_of_an_algebraic_variety")[#text("function field")]#text(" on ")#mi("{U}")#text(", and let ")#mi("{K^{sep}}")#text(" be its ")#link("http://en.wikipedia.org/wiki/Separable_closure")[#text("separable closure")]#text(", so that one can form the Galois group ")#mi("{\\text{Gal}(K^{sep}/K)}")#text(". For any closed point ")#mi("{\\overline{x} \\in U_k}")#text(" of ")#mi("{U}")#text(" (basically, an orbit of ")#mi("{\\text{Gal}(k^{sep}/k)}")#text("), we can form a local version ")#mi("{K_{\\overline{x}}}")#text(" of ")#mi("{K}")#text(" (the ")#link("http://en.wikipedia.org/wiki/Henselization")[#text("Henselization")]#text(" of the ")#link("http://en.wikipedia.org/wiki/Discrete_valuation_ring")[#text("discrete valuation ring")]#text(" associated to ")#mi("{\\overline{x}}")#text(", which roughly speaking captures the formal power series around ")#mi("{\\overline{x}}")#text("), and a local version ")#mi("{D_{\\overline{x}} := \\text{Gal}(K^{sep}_{\\overline{x}}/K_{\\overline{x}})}")#text(" of the Galois group, known as the ")#emph[#text("decomposition group")]#text(" at ")#mi("{\\overline{x}}")#text(". As ")#mi("{K}")#text(" embeds into ")#mi("{K_{\\overline{x}}}")#text(", ")#mi("{D_{\\overline{x}}}")#text(" embeds into ")#mi("{\\text{Gal}(K^{sep}/K)}")#text(". Inside ")#mi("{D_{\\overline{x}}}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Ramification_theory_of_valuations")[#text("inertia group")]#text(" ")#mi("{I_{\\overline{x}}}")#text(", defined (I think) as the elements of ")#mi("{D_{\\overline{x}}}")#text(" which stabilise the residue field of ")#mi("{\\overline{x}}")#text(". Informally, this group measures the amount of ramification present at ")#mi("{\\overline{x}}")#text(". One can then identify the arithmetic fundamental group ")#mi("{\\pi_1^{et}(U/k)}")#text(" with the quotient of ")#mi("{\\text{Gal}(K^{sep}/K)}")#text(" by the normal subgroup ")#mi("{\\langle I_{\\overline{x}} \\rangle_{\\overline{x} \\in U_k}}")#text(" generated (as a normal subgroup) by all the inertia groups of closed points; informally, the étale fundamental group describes the unramified Galois representations of ")#mi("{\\text{Gal}(K^{sep}/K)}")#text(". The geometric fundamental group has a similar description, but with ")#mi("{\\text{Gal}(K^{sep}/K)}")#text(" replaced by the smaller group ")#mi("{\\text{Gal}(K^{sep}/\\overline{k} K)}")#text(".")

#text("(Note: as pointed out to me by Brian Conrad, one can also identify ")#mi("{\\pi_1^{et}(U/k)}")#text(" with ")#mi("{\\text{Gal}(K^{\\prime}/K)}")#text(" where ")#mi("{K^{\\prime}}")#text(" is the maximal Galois extension of ")#mi("{K}")#text(" which is unramified at the discrete valuations corresponding to all the closed points of ")#mi("{U}")#text(". A similar description can be given for higher-dimensional schemes ")#mi("{U}")#text(", if one replaces closed points with codimension-1 points, thanks to ")#link("http://en.wikipedia.org/wiki/Abhyankar's_lemma")[#text("Abhyankar’s lemma")]#text(".)")

#text("We have seen that fundamental groups (or absolute Galois groups) act on discrete sets, and specifically on the fibres of covering spaces (or field extensions, or étale finite covers). However, fundamental groups also naturally act on other spaces, and in particular on vector spaces ")#mi("{V}")#text(" over various fields. For instance, suppose one starts with a connected complex manifold ")#mi("{M}")#text(" and considers the holomorphic functions on this manifold. Typically, there are very few ")#emph[#text("globally")]#text(" holomorphic functions on ")#mi("{M}")#text(" (e.g. if ")#mi("{M}")#text(" is compact, then Liouville’s theorem will force a globally holomorphic function to be constant), so one usually works instead with ")#emph[#text("locally")]#text(" holomorphic functions, defined on some open subset ")#mi("{U}")#text(" of ")#mi("{M}")#text(". These local holomorphic functions then form a ")#link("http://en.wikipedia.org/wiki/Sheaf_(mathematics)")[#text("sheaf")]#text(" ")#mi("{{\\mathcal H}}")#text(" over ")#mi("{M}")#text(", with a vector space ")#mi("{{\\mathcal H}(U)}")#text(" of holomorphic functions on ")#mi("{U}")#text(" being attached to each open set ")#mi("{U}")#text(", as well as restriction maps from ")#mi("{{\\mathcal H}(U)}")#text(" to ")#mi("{{\\mathcal H}(U^{\\prime})}")#text(" for every open subset ")#mi("{U^{\\prime}}")#text(" of ")#mi("{U}")#text(" which obey a small number of axioms which I will not reproduce here (see e.g. ")#link("http://en.wikipedia.org/wiki/Sheaf_(mathematics)")[#text("the Wikipedia page on sheaves")]#text(" for the list of sheaf axioms).")

#text("Now let ")#mi("{p}")#text(" be a base point in ")#mi("{M}")#text(". We can then associate a natural complex vector space ")#mi("{V}")#text(" to ")#mi("{p}")#text(", namely the space of holomorphic ")#link("http://en.wikipedia.org/wiki/Germ_(mathematics)")[#text("germs")]#text(" at ")#mi("{p}")#text(" (the direct limit of ")#mi("{H(U)}")#text(" for neighbourhoods ")#mi("{U}")#text(" of ")#mi("{p}")#text("). Any loop based at ")#mi("{p}")#text(" then induces a map from ")#mi("{V}")#text(" to itself, formed by starting with a germ at ")#mi("{p}")#text(" and performing analytic continuation until one returns to ")#mi("{p}")#text(". As analytic continuation is a linear operation, this map from ")#mi("{V}")#text(" to itself is linear; it is also invertible by reversing the loop, so it lies in the general linear group ")#mi("{GL(V)}")#text(". From the locally unique nature of analytic continuation, this map is not affected by homotopy of the loop, and this therefore gives a linear representation ")#mi("{\\rho_{{\\mathcal H}}: \\pi_1(U) \\rightarrow GL(V)}")#text(" of the fundamental group. (Actually, to be pedantic, it gives a representation of the opposite group ")#mi("{\\pi_1(U)^{op}}")#text(", due to the usual annoyance that composition of functions works in the reverse order from concatenation of paths, but let us ignore this minor technicality.)")

#text("Of course, one can perform the same sort of construction for other sheaves over ")#mi("{M}")#text(" of holomorphic sections of various vector bundles (using the ")#link("http://en.wikipedia.org/wiki/Stalk_(sheaf)")[#text("stalk of the sheaf")]#text(" at ")#mi("{p}")#text(" for the space of germs), giving rise to other complex linear representations of the fundamental group. In analogy with this, we will ")#emph[#text("define")]#text(" the notion of a certain type of sheaf over a variety ")#mi("{U/{\\mathbb F}}")#text(" defined over a finite field ")#mi("{{\\mathbb F}}")#text(" in terms of such representations. Due to the profinite nature of the étale fundamental group, we do not work with complex representations, but rather with ")#mi("{\\ell}")#text("-adic representations, for some prime ")#mi("{\\ell}")#text(" that is invertible in ")#mi("{{\\mathbb F}}")#text(". However, as the ")#mi("{\\ell}")#text("-adics have characteristic zero, we can always choose an embedding ")#mi("{\\iota: {\\bf Q}_\\ell \\rightarrow {\\bf C}}")#text(" into the complex numbers, although it is not unique (and.")

#text("We can now give (a special case of) the definition of an ")#mi("{\\ell}")#text("-adic sheaf:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Lisse sheaf)")]#text(" Let ")#mi("{U/{\\mathbb F}}")#text(" be a non-empty affine curve defined over a finite field ")#mi("{{\\mathbb F} = {\\mathbb F}_q}")#text(", and let ")#mi("{\\ell}")#text(" be a prime not equal to to the characteristic ")#mi("{p}")#text(" of ")#mi("{{\\mathbb F}}")#text(" (i.e. ")#mi("{\\ell}")#text(" is invertible in ")#mi("{{\\mathbb F}}")#text("). An ")#emph[#mi("{\\ell}")#text("-adic lisse sheaf")]#text(" ")#mi("{{\\mathcal F}}")#text(" over ")#mi("{U}")#text(" (also known as an ")#emph[#mi("{\\ell}")#text("-adic local system")]#text(") is a continuous linear representation ")#mi("{\\rho_{\\mathcal F}: \\pi_1^{et}/U({\\mathbb F}) \\rightarrow GL(V)}")#text(" of the arithmetic fundamental group of ")#mi("{U}")#text(", where ")#mi("{V}")#text(" is a finite-dimensional vector space over the ")#mi("{\\ell}")#text("–")#link("http://en.wikipedia.org/wiki/P-adic_number")[#text("adics")]#text(" ")#mi("{{\\mathbb Q}_\\ell}")#text(". (Here, the continuity is with respect to the profinite topology on ")#mi("{\\pi_1^{et}/U({\\mathbb F})}")#text(" and the ")#mi("{\\ell}")#text("-adic topology on ")#mi("{GL(V)}")#text(".) We refer to ")#mi("{V}")#text(" as the ")#emph[#text("fibre")]#text(" of the sheaf. The dimension of ")#mi("{V}")#text(" is called the ")#emph[#text("rank")]#text(" of the sheaf.")
]

#text("One can define more general ")#mi("{\\ell}")#text("-adic sheaves (not necessarily lisse) over more general schemes, but the definitions are more complicated, and the lisse case already suffices for many analytic number theory applications. (However, even if one’s applications only involve lisse sheaves, it is natural to generalise to arbitrary sheaves when proving the key theorems about these sheaves, in particular Deligne’s theorems.)")

#text("As we see from the above definition, lisse sheaves are essentially just a linear representation of the arithmetic fundamental group (and hence also of the geometric fundamental group). As such, one can directly import many representation-theoretic concepts into the language of ")#mi("{\\ell}")#text("-adic lisse sheaves. For instance, one can form the direct sum ")#mi("{{\\mathcal F}_1 \\oplus {\\mathcal F}_2}")#text(" and direct product ")#mi("{{\\mathcal F}_1 \\otimes {\\mathcal F}_2}")#text(" of lisse sheaves by using the representation-theoretic direct sum and direct product, and one can take the contragradient sheaf ")#mi("{\\check {\\mathcal F}}")#text(" of a sheaf ")#mi("{{\\mathcal F}}")#text(" by replacing the representation ")#mi("{\\rho_{\\mathcal F}}")#text(" with its inverse transpose. Morphisms ")#mi("{\\phi: U \\rightarrow U^{\\prime}}")#text(" of the underlying curve give rise to a pullback operation ")#mi("{{\\mathcal F}^{\\prime} \\rightarrow \\phi^* {\\mathcal F}^{\\prime}}")#text(" from sheaves ")#mi("{{\\mathcal F^{\\prime}}}")#text(" over ")#mi("{U^{\\prime}}")#text(" to sheaves ")#mi("{\\phi^* {\\mathcal F}^{\\prime}}")#text(" of ")#mi("{U}")#text(". (There is also an important pushforward operation, but it is much more difficult to define and study.) We also have the notion of a trivial sheaf (in which ")#mi("{\\rho_{\\mathcal F}}")#text(" is the identity), an irreducible sheaf (which cannot be decomposed as an extension of a lower rank sheaf), a semisimple sheaf (a sheaf which factors as the direct sum of irreducibles), or an isotypic sheaf (the direct sum of isomorphic sheaves). By replacing the arithmetic fundamental group with its geometric counterpart, one also has geometric versions of many of the above concepts, thus for instance one can talk about geometrically irreducible sheaves, geometrically semisimple sheaves, etc.")

#text("Now let ")#mi("{\\overline{x} \\in U_{{\\mathbb F}}}")#text(" be a closed point in ")#mi("{U}")#text(" of degree ")#mi("{n}")#text(", with its associated decomposition group ")#mi("{D_{\\overline{x}}}")#text(" and inertia group ")#mi("{I_{\\overline{x}}}")#text(". The quotient ")#mi("{D_{\\overline{x}}/I_{\\overline{x}}}")#text(" can be viewed as the arithmetic fundamental group of ")#mi("{\\overline{x}}")#text(", or equivalently the absolute Galois group of the residue field at ")#mi("{\\overline{x}}")#text(", and this quotient embeds into the arithmetic fundamental group ")#mi("{\\pi_1^{et}(U({\\mathbb F}))}")#text(" of ")#mi("{U({\\mathbb F})}")#text(" since ")#mi("{\\overline{x}}")#text(" embeds into ")#mi("{U({\\mathbb F})}")#text(". On the other hand, as ")#mi("{\\overline{x}}")#text(" has degree ")#mi("{n}")#text(", the residue field is isomorphic to the degree ")#mi("{n}")#text(" extension ")#mi("{{\\mathbb F}_n}")#text(" of ")#mi("{{\\mathbb F}}")#text(", so ")#mi("{D_{\\overline{x}}/I_{\\overline{x}}}")#text(" is isomorphic to the absolute Galois group of ")#mi("{{\\mathbb F}_n}")#text(". This latter group is generated (topologically) by the arithmetic Frobenius map ")#mi("{x \\mapsto x^{q^n}}")#text(", and also by its inverse, known as the ")#link("http://en.wikipedia.org/wiki/Arithmetic_and_geometric_Frobenius")[#text("geometric")]#text(" Frobenius map. So the geometric Frobenius map is well defined (up to conjugacy) as an element of ")#mi("{D_{\\overline{x}}/I_{\\overline{x}}}")#text(" and hence ")#mi("{\\pi_1^{et}(U({\\mathbb F}))}")#text(". By abuse of notation, we will refer to elements of this conjugacy class in ")#mi("{\\pi_1^{et}(U({\\mathbb F}))}")#text(" as ")#mi("{\\text{Frob}_{\\overline{x}}}")#text(", bearing in mind that this object is only defined up to conjugacy. If we have a lisse ")#mi("{\\ell}")#text("-adic sheaf ")#mi("{{\\mathcal F}}")#text(", then ")#mi("{\\rho_{{\\mathcal F}}( \\text{Frob}_{\\overline{x}} )}")#text(" is defined up to conjugation, which implies that the trace ")#mi("{\\text{tr}( \\rho_{{\\mathcal F}}( \\text{Frob}_{\\overline{x}} ) | V )}")#text(" on ")#mi("{V}")#text(" is well-defined as an element of ")#mi("{{\\bf Q}_\\ell}")#text(". (Actually, a technical point: one should restrict the trace from ")#mi("{V}")#text(" to the subspace ")#mi("{V^{I_{\\overline{x}}}}")#text(" fixed by the inertia group of ")#mi("{\\overline{x}}")#text(", but as long as there is no ramification at ")#mi("{\\overline{x}}")#text(", this is all of ")#mi("{V}")#text("; we will ignore this technicality, as in practice we will delete the points of ")#mi("{U}")#text(" in which ramification occurs.) Fixing some embedding ")#mi("{\\iota: {\\bf Q}_\\ell \\rightarrow {\\bf C}}")#text(", we can then form the trace function")

#align(center)[#tao-fit-display[#mitex("K_{\\mathcal F}(\\overline{x}) := \\iota( \\text{tr}( \\rho_{{\\mathcal F}}( \\text{Frob}_{\\overline{x}} ) | V )")]]

#text("which is a function from ")#mi("{U_{\\mathbb F}}")#text(" to ")#mi("{{\\bf C}}")#text(", and in particular a function from ")#mi("{U({\\mathbb F})}")#text(" to ")#mi("{{\\bf C}}")#text(". (A certain subclass of) these trace functions will serve as the “structured” functions mentioned at the start of this section.")

#text("Now an important definition. For each unramified closed point ")#mi("{\\overline{x}}")#text(", ")#mi("{\\rho_{{\\mathcal F}}( \\text{Frob}_{\\overline{x}} )}")#text(" is an invertible linear transformation on the vector space ")#mi("{V}")#text(", which has dimension ")#mi("{r}")#text(" equal to the rank of ")#mi("{{\\mathcal F}}")#text(". In particular, this transformation has ")#mi("{r}")#text(" eigenvalues ")#mi("{\\alpha_1,\\ldots,\\alpha_r}")#text(" (depending on ")#mi("{\\overline{x}}")#text(", of course) in ")#mi("{{\\bf Q}_\\ell}")#text(", and hence in ")#mi("{{\\bf C}}")#text(" after selecting an embedding ")#mi("{\\iota: {\\bf Q}_\\ell \\rightarrow {\\bf C}}")#text(". We say that the sheaf ")#mi("{{\\mathcal F}}")#text(" is ")#emph[#text("pure of weight ")#mi("{w}")]#text(" for some real number ")#mi("{w}")#text(" if all of these eigenvalues (and their Galois conjugates) have magnitude exactly ")#tao-math("{\\left|k_{\\overline{x}}\\right|^{w/2} = q^{w\\text{deg}(\\overline{x})/2}}", block: false)#text(", where ")#mi("{k_{\\overline{x}}}")#text(" is the residue field at ")#mi("{\\overline{x}}")#text(". There is also the weaker concept of being ")#emph[#text("mixed of weight ")#mi("{w}")]#text(", in which the magnitude of the eigenvalues and their conjugates is merely assumed to be bounded above by ")#tao-math("{\\left|k_{\\overline{x}}\\right|^{w/2} = q^{w\\text{deg}(\\overline{x})/2}}", block: false)#text(". (A technical remark: this upper bound are initially only assumed for unramified closed points, but a result of Deligne allows one to extend this upper bound to ramified points also.) If the sheaf is pure or mixed of weight ")#mi("{w}")#text(", then one clearly has the pointwise bound")

#align(center)[#tao-fit-display[#tao-math("\\left|K_{\\mathcal F}(\\overline{x})\\right| \\leq r q^{w\\text{deg}(\\overline{x})/2};", block: true)]]

#text("in particular, for sheaves of weight zero and bounded rank, the trace function is ")#mi("{O(1)}")#text(".")

#text("The trace functions ")#mi("{K_{{\\mathcal F}}(\\overline{x})}")#text(" resemble characters of representations. For instance, taking the direct sum or product of two sheaves results in taking the sum or product of the two trace functions. If two sheaves have weight ")#mi("{w}")#text(", then their direct sum has weight ")#mi("{w}")#text(" as well, while if two sheaves have weights ")#mi("{w_1,w_2}")#text(", then their direct product has weight ")#mi("{w_1+w_2}")#text(". Taking the contragradient ")#mi("{\\check {\\mathcal F}}")#text(" of a sheaf of weight ")#mi("{w}")#text(" results in a sheaf of weight ")#mi("{-w}")#text("; in the weight zero case, the trace function simply gets conjugated. Pulling back a sheaf by some morphism of curves preserves the weight of that sheaf, and pulls back the trace functions accordingly.")

#text("It is a convenient fact that pure sheaves automatically have a “geometric semisimplification” which is a pure sheaf of the same weight, and whose trace function is identical to that of the original sheaf. Furthermore, the geometrically irreducible components of the geometrically semisimple sheaf have the same weight as the original sheaf. Because of this, one can often reduce to the study of geometrically irreducible pure sheaves.")

#text("In practice, one can normalise the weight of a pure or mixed sheaf to zero by the following simple construction. Given any algebraic integer ")#mi("{\\alpha}")#text(" over the ")#mi("{\\ell}")#text("-adics, we can define the ")#emph[#text("Tate sheaf")]#text(" associated to ")#mi("{\\alpha}")#text(" to be the unique rank one continuous representation ")#mi("{\\rho: \\pi_1^{et}(U/{\\mathbb F}) \\rightarrow {\\bf Q}_\\ell^\\times = GL_1({\\bf Q}_\\ell)}")#text(" that acts trivially on the geometric fundamental group, and maps the Frobenius map ")#mi("{\\text{Frob} \\in \\text{Gal}(\\overline{\\mathbb F}/{\\mathbb F}) \\subset \\pi_1^{et}(U/{\\mathbb F})}")#text(" of ")#mi("{{\\mathbb F}}")#text(" to ")#mi("{\\alpha}")#text(". If we set ")#mi("{\\alpha = q^{w/2}}")#text(", then this is a pure sheaf of weight ")#mi("{w}")#text(", and the associated trace function ")#mi("{K(\\overline{x})}")#text(" is equal to ")#mi("{q^{w\\text{deg}(\\overline{x})/2}}")#text("; it is geometrically trivial but arithmetically non-trivial (if ")#mi("{\\alpha \\neq 1}")#text("), and conversely all geometrically trivial and geometrically semisimple sheaves come from direct sums of Tate sheaves. Given any other pure or mixed sheaf ")#mi("{{\\mathcal F}}")#text(" of some weight ")#mi("{w^{\\prime}}")#text(", one can then tensor with the Tate sheaf of weight ")#mi("{w}")#text(" to create a pure or mixed sheaf ")#mi("{{\\mathcal F}(w)}")#text(" of weight ")#mi("{w^{\\prime}+w}")#text(", which at the level of trace functions amounts to multiplying the trace function by ")#mi("{q^{w\\text{deg}(\\overline{x})/2}}")#text(". In particular, setting ")#mi("{w=-w^{\\prime}}")#text(" one can perform a “Tate twist” to normalise these sheaves to be of weight zero.")

#text("There is also the notion of the “complexity” of an ")#mi("{\\ell}")#text("-adic sheaf, measured by a quantity known as the ")#emph[#text("conductor")]#text(" of the sheaf. This quantity is a bit complicated to define here, but basically it incorporates the genus of the underlying curve ")#mi("{U}")#text(", the rank of the sheaf, the number of singularities of the sheaf, and something called the ")#link("http://en.wikipedia.org/wiki/Artin_conductor")[#text("Swan conductor")]#text(" at each singularity of that sheaf; bounding the conductor then leads to a bound on all of these quantities. The conductor behaves well with respect to various sheaf-theoretic operations; for instance the direct sum or product of sheaves of bounded conductor will also be a sheaf of bounded conductor. I’ll use “bounded complexity” in place of “bounded conductor” in the text that follows.")

#text("The “structured functions” mentioned at the start of this section on a curve ")#mi("{C}")#text(" are then precisely the trace functions ")#mi("{K_{{\\mathcal F}}}")#text(" associated to sheaves on open dense subsets ")#mi("{U}")#text(" of this curve ")#mi("{C}")#text(" formed by deleting a bounded number of points at most from ")#mi("{C}")#text(", which are pure of weight zero and of bounded complexity. As discussed above, this class of functions is closed under pointwise sum, pointwise product, complex conjugation, and pullback, and are also pointwise bounded. It is also a deep fact (essentially due to Deligne, Laumon, and Katz) that this class is closed under other important analytic operations, such as Fourier transform and convolution.")

#text("Now we give some basic examples of structured functions, which can be combined with each other using the various closure properties of such functions discussed above. First we show how any additive character ")#mi("{\\psi: {\\mathbb F} \\rightarrow {\\bf C}^\\times}")#text(" can be interpreted as an structured function on the affine line ")#mi("{{\\mathbb A}^1}")#text(". The affine line ")#mi("{{\\mathbb A}^1}")#text(" is covered by itself via the finite étale covering map ")#mi("{\\phi: {\\mathbb A}^1 \\rightarrow {\\mathbb A}^1}")#text(" defined by ")#mi("{\\phi(x) := x - x^q}")#text(". The fibre of this map at ")#mi("{0}")#text(" is just the field ")#mi("{{\\mathbb F}}")#text(", and so the arithmetic fundamental group ")#mi("{\\pi_1^{et}({\\mathbb A}^1)}")#text(" acts on ")#mi("{{\\mathbb F}}")#text(". One can show that this action is a translation action (because of the translation symmetry of this covering space), and so we have a map from ")#mi("{\\pi_1^{et}({\\mathbb A}^1)}")#text(" to ")#mi("{{\\mathbb F}}")#text(", which on composition with ")#mi("{\\psi}")#text(" (and pulling back to ")#mi("{{\\bf Q}_\\ell^\\times}")#text(") gives a rank one sheaf, called the ")#emph[#text("Artin-Schrier sheaf")]#text(" associated to ")#mi("{\\psi}")#text(". The trace function here is just ")#mi("{\\psi}")#text(", and this is clearly a pure sheaf of weight ")#mi("{0}")#text("; it also has bounded complexity (indeed, the genus is zero and the only singularity is at ")#mi("{\\infty}")#text(", and the Swan conductor there can be computed to be ")#mi("{1}")#text(").")

#text("In a similar vein, any multiplicative character ")#mi("{\\chi: {\\mathbb F}^\\times \\rightarrow {\\bf C}^\\times}")#text(" can be viewed as an structured function on the multiplciative group ")#mi("{{\\mathbb G}_m := {\\mathbb A}^1 \\backslash \\{0\\}}")#text(" by a similar construction, using ")#mi("{x / x^q}")#text(" instead of ")#mi("{x - x^q}")#text(" (which is still an étale covering map, thanks to a baby case of ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_Theorem_90")[#text("Hilbert’s Theorem 90")]#text("), giving rise to a rank one, bounded complexity pure sheaf of weight ")#mi("{0}")#text(" on ")#mi("{{\\mathbb G}_m}")#text(" known as the ")#emph[#text("Kummer sheaf")]#text(", whose trace function is just ")#mi("{\\chi}")#text(".")

#text("These two examples, combined with the closure operations defined previously, already give a large number of useful structured functions, such as the function ")#mi("{x \\mapsto \\psi( f(x) ) \\chi(g(x))}")#text(" on the affine line with boundedly many points removed, where ")#mi("{f, g}")#text(" are on that affine line. But there is a deep and powerful additional closure property due to Deligne, Laumon, and Katz: if ")#mi("{{\\mathcal F}}")#text(" is a pure sheaf of weight zero on the affine line (with boundedly many points removed) of bounded complexity that does not contain any Artin-Schrier components, and ")#mi("{\\psi: {\\mathbb F} \\rightarrow {\\bf C}^\\times}")#text(" is a non-trivial additive character, then there is a “Fourier transform” ")#mi("{NFT_\\psi({\\mathcal F})}")#text(" of ")#mi("{{\\mathcal F}}")#text(", which is another pure sheaf of weight zero and bounded complexity with no Artin-Schrier components, with the property that the trace function of ")#mi("{NFT_\\psi({\\mathcal F})}")#text(" is the Fourier transform of the trace function of ")#mi("{{\\mathcal F}}")#text(" with respect to ")#mi("{\\psi}")#text(" on ")#mi("{{\\mathbb F}}")#text(":")

#align(center)[#tao-fit-display[#mitex("K_{NFT_\\psi({\\mathcal F})}(x) = \\frac{1}{\\sqrt{q}} \\sum_{y \\in {\\mathbb F}} K( y ) \\psi(xy).")]]

#text("See Theorem 8.2.3 of ")#link("http://www.ams.org/mathscinet-getitem?mr=955052")[#text("this book of Katz")]#text(" for details. (The construction here is analogous to that used in the ")#link("http://en.wikipedia.org/wiki/Fourier%E2%80%93Mukai_transform")[#text("Fourier-Mukai transform")]#text(", although I do not know how tight this analogy is.) This closure under Fourier transforms also implies a closure property with respect to convolutions, by the usual intertwining relationship between convolution and multiplication provided by the Fourier transform. Using these additional closure properties, one can now add many new and interesting examples of structured functions, such as the normalised Kloosterman sums")

#align(center)[#tao-fit-display[#mitex("K(a) = \\frac{1}{\\sqrt{q}} \\sum_{x,y \\in {\\mathbb F}: xy=a} \\psi( x + y )")]]

#text("or more generally the hyper-Kloosterman sums")

#align(center)[#tao-fit-display[#mitex("K_k(a) = \\frac{1}{q^{(k-1)/2}} \\sum_{x_1,\\ldots,x_k \\in {\\mathbb F}: x_1 \\ldots x_k =a} \\psi( x_1 + \\ldots + x_k )")]]

#text("for some non-principal additive character ")#mi("{\\psi}")#text(". These can then be combined with the previous examples of structured functions as before, for instance Kloosterman correlations ")#mi("{x \\mapsto K_k(x) \\overline{K_k(x+l)} \\psi(x)}")#text(" would now also be examples of structured functions.")

#text("We have now demonstrated that the class of structured functions ")#mi("{K(x)}")#text(" contains many examples of interest to analytic number theory, but we have not yet done anything with this class, in particular we have not obtained any control on “exponential sums” such as ")#metadata(none) <tao-fa37be71bea1abe98954>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\sum_{x \\in U({\\mathbb F})} K(x)")]]

#text("beyond the trivial bound of ")#mi("{O(q)}")#text(" that comes from the pointwise bound on ")#mi("{K(x)}")#text(" (and the elementary “Schwarz-Zippel” fact that a bounded complexity curve has at most ")#mi("{O(q)}")#text(" points over ")#mi("{{\\mathbb F}_q}")#text("). However, such control can be obtained through the important ")#link("http://en.wikipedia.org/wiki/Lefschetz_fixed-point_theorem")[#text("Grothendieck-Lefschetz fixed point formula")]#text(" ")#metadata(none) <tao-7e14c3d7dd12bbd0947a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("\\sum_{x \\in U({\\mathbb F}_n)} K_{\\mathcal F}(x) = \\sum_{i=0}^2 (-1)^i \\text{Tr}( \\text{Frob}^n | H^i_c(U/\\overline{\\mathbb F}, {\\mathcal F}) )")]]

#text("for any ")#mi("{n \\geq 1}")#text(", where ")#mi("{H^i_c(U/\\overline{\\mathbb F}, {\\mathcal F})}")#text(" are the ")#link("http://en.wikipedia.org/wiki/%C3%89tale_cohomology")[#mi("{\\ell}")#text("-adic cohomology groups")]#text(" with compact support in ")#mi("{U/\\overline{\\mathbb F}}")#text(" and coefficients in ")#mi("{{\\mathcal F}}")#text(". These groups are defined through the general homological algebra machinery of ")#link("http://en.wikipedia.org/wiki/Derived_category")[#text("derived categories")]#text(" (but can also be interpreted using either ")#link("http://en.wikipedia.org/wiki/Galois_cohomology")[#text("Galois cohomology")]#text(" or ")#link("http://en.wikipedia.org/wiki/Sheaf_cohomology")[#text("sheaf cohomology")]#text("), and I do not yet have a sufficiently good understanding of these topics to say much more about these groups, other than that they turn out to be finite-dimensional vector spaces over ")#mi("{{\\bf Q}_\\ell}")#text(", and carry an action of the (geometric) Frobenius map of ")#mi("{{\\mathbb F}}")#text(". (In fact they have a richer structure than this, being sheaves over ")#mi("{\\text{Spec}({\\mathbb F})}")#text("; this is useful when trying to iterate Deligne’s theorem to control higher-dimensional exponential sums, but we won’t directly use this structure here.) This formula is analogous to the explicit formulae ")#link(<tao-8172a6ce75682e598b50>)[#text("(5)")]#text(", ")#link(<tao-4f5d2d1816915837124e>)[#text("(10)")]#text(", ")#link(<tao-7fcbbe5db9d3167e5a05>)[#text("(13)")]#text(", ")#link(<tao-df3fbd4e10c08e293fda>)[#text("(17)")]#text(", ")#link(<tao-ca978112ca1bbdcafac2>)[#text("(22)")]#text(", ")#link(<tao-3e23e8160039594a3389>)[#text("(26)")]#text(", ")#link(<tao-2e7d2c03a9507ae265ec>)[#text("(27)")]#text(" from the introduction, and in fact easily implies the latter four explicit formulae. Specialising to the case ")#mi("{n=1}")#text(", we see that the sum ")#link(<tao-fa37be71bea1abe98954>)[#text("(30)")]#text(" takes the form")

#align(center)[#tao-fit-display[#mitex("\\text{Tr}( \\text{Frob} | H^0_c(U/\\overline{\\mathbb F}, {\\mathcal F}) ) - \\text{Tr}( \\text{Frob} | H^1_c(U/\\overline{\\mathbb F}, {\\mathcal F}) ) + \\text{Tr}( \\text{Frob} | H^2_c(U/\\overline{\\mathbb F}, {\\mathcal F}) ).")]]

#text("To proceed further, we need to understand the eigenvalues of the Frobenius map on these cohomology groups (and we also need some control on the dimensions of these groups, i.e. on ")#link("http://en.wikipedia.org/wiki/Betti_number")[#text("Betti numbers")]#text("). This can be done by the following deep result of Deligne, essentially the main result in his second proof of the Weil conjectures:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Deligne’s Weil II)")]#text(" If ")#mi("{{\\mathcal F}}")#text(" is a lisse ")#mi("{\\ell}")#text("-adic sheaf, pure of weight ")#mi("{w}")#text(", and ")#mi("{i \\geq 0}")#text(", then any eigenvalue of Frobenius on ")#mi("{H^i_c(U/\\overline{\\mathbb F}, {\\mathcal F})}")#text(" has magnitude at most ")#mi("{q^{(w+i)/2}}")#text(", as does any of its Galois conjugates.")
]

#text("If we form the zeta function")

#align(center)[#tao-fit-display[#mitex("Z( {\\mathcal F}, T ) = \\exp( \\sum_{n \\geq 1} \\frac{\\sum_{x \\in U({\\mathbb F}_n)} K_{\\mathcal F}(x)}{n} T^n )")]]

#text("in analogy with ")#link(<tao-164200a298bafec89fd3>)[#text("(2)")]#text(", ")#link(<tao-7d1c66e278298829c6c3>)[#text("(8)")]#text(", ")#link(<tao-7d3195c54a8d20c5b006>)[#text("(12)")]#text(", ")#link(<tao-46b9219f8624018116cc>)[#text("(16)")]#text(", ")#link(<tao-9981661c03b5d4a67d33>)[#text("(21)")]#text(", or ")#link(<tao-bf4c210159573d9cc9f8>)[#text("(25)")]#text(", Deligne’s theorem is equivalent to the Riemann hypothesis for ")#mi("{Z}")#text(", or at least to the “important” half of that hypothesis, namely that the zeroes have magnitude at most ")#mi("{\\sqrt{q}}")#text(". In many cases, one can use ")#link("http://en.wikipedia.org/wiki/Poincare_duality")[#text("Poincaré duality")]#text(" to derive a functional equation for ")#mi("{Z}")#text(" which shows that the zeroes in fact have magnitude exactly ")#mi("{\\sqrt{q}}")#text(", but for the purposes of upper bounds on exponential sums, it is only the upper bound on the zeroes which is relevant. Interestingly, once one has Deligne’s theorem, the zeta function ")#mi("{Z}")#text(" plays very little role in applications; however, the zeta function is used to some extent in the ")#emph[#text("proof")]#text(" of Deligne’s theorem. (In particular, my understanding is that Deligne establishes a preliminary zero-free region for this zeta function analogous to the classical zero-free region for the Riemann zeta function, which he then amplifies using a device similar to the amplification tricks mentioned previously.)")

#text("From Deligne’s theorem we conclude an important upper bound for ")#link(<tao-fa37be71bea1abe98954>)[#text("(30)")]#text(" for structured functions:")

#tao-aligned(keep: true)[


#tao-math("\\left|\\sum_{x \\in U({\\mathbb F})} K_{\\mathcal F}(x)\\right|  & \\leq \\text{dim}( H^0_c(U/\\overline{\\mathbb F}, {\\mathcal F}) ) + q^{1/2} \\text{dim}( H^1_c(U/\\overline{\\mathbb F}, {\\mathcal F}) )", block: true)



#tao-math(" & + q \\text{dim}( H^2_c(U/\\overline{\\mathbb F}, {\\mathcal F}) ).", block: true)
]

#text("To use this bound, we need bounds on the dimensions of the the cohomology groups, and we need the ")#mi("{H^2_c}")#text(" cohomology group to be trivial in order to get a non-trivial bound on the exponential sum ")#mi("{\\sum_{x \\in U({\\mathbb F})} K_{\\mathcal F}(x)}")#text(".")

#text("As is usual in cohomology, the extreme cohomology groups ")#mi("{H^0_c, H^2_c}")#text(" are relatively easy to compute; for instance, if ")#mi("{U}")#text(" is affine ")#mi("{H^0_c}")#text(" can be shown to vanish, and ")#mi("{H^2_c}")#text(" can be shown to vanish when ")#mi("{{\\mathcal F}}")#text(" is geometrically irreducible and non-trivial. In any case, when ")#mi("{{\\mathcal F}}")#text(" has bounded complexity, both of these groups have bounded dimension. This leads to the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{x \\in U({\\mathbb F})} K_{\\mathcal F}(x)\\right| \\leq O(1) + q^{1/2} \\text{dim}( H^1_c(U/\\overline{\\mathbb F}, {\\mathcal F}) )", block: true)]]

#text("when ")#mi("{{\\mathcal F}}")#text(" is geometrically irreducible and non-trivial with bounded complexity. Finally, to control the dimension of ")#mi("{H^1_c}")#text(", one uses a variant of the Grothendieck-Lefschetz formula, namely the ")#emph[#text("Euler-Poincaré formula")]#text(" ")#metadata(none) <tao-c23c23a7c71feb7e0bd8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("\\sum_{i=0}^2 (-1)^i \\text{dim}( H^i_c(U/\\overline{\\mathbb F}, {\\mathcal F}) ) = r \\chi(U) - \\sum_{\\overline{x} \\in \\text{Sing}({\\mathcal F})} \\text{Swan}_{\\overline{x}}({\\mathcal F})")]]

#text("where ")#mi("{r}")#text(" is the rank of ")#mi("{{\\mathcal F}}")#text(", ")#mi("{\\chi(U)}")#text(" is the geometric Euler characteristic of ")#mi("{U}")#text(" (i.e. ")#mi("{2-2g-k}")#text(", where ")#mi("{k}")#text(" is the number of points ")#mi("{U}")#text(" omits from its projective closure ")#mi("{C = \\overline{U}}")#text("), and ")#mi("{\\text{Swan}_{\\overline{x}}({\\mathcal F})}")#text(" are the Swan conductors. (A side note: this identity formally suggests that there is some extension of the Grothendieck-Lefschetz formula to the ")#mi("{n=0}")#text(" case, with the right-hand side of ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(32)")]#text(" being interpretable as some sort of sum over the “")#link("http://en.wikipedia.org/wiki/Field_with_one_element")[#text("field with one element")]#text("“, whatever that means. I wonder if such an interpretation has been fleshed out further?) All the quantities on the right-hand side of ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(32)")]#text(" are bounded if ")#mi("{{\\mathcal F}}")#text(" has bounded complexity (basically by the definition of complexity), so we conclude that ")#mi("{H^1_c}")#text(" has bounded dimension if ")#mi("{{\\mathcal F}}")#text(" has bounded complexity. (Here we are relying on the fact that ")#mi("{U}")#text(" is one-dimensional, so that there is only one “difficult” Betti number to understand, which can then be recovered through the Euler characteristic; the situation is more complicated, though still reasonably well under control, in higher dimensions.) So we finally recover the square root cancellation bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{x \\in U({\\mathbb F})} K_{\\mathcal F}(x)\\right| \\ll q^{1/2}", block: true)]]

#text("whenever ")#mi("{{\\mathcal F}}")#text(" is geometrically irreducible and geometrically non-trivial. We thus obtain the more general bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\in U({\\mathbb F})} K_{\\mathcal F}(x) = cq + O(q^{1/2})")]]

#text("for any geometrically semisimple lisse sheaf ")#mi("{{\\mathcal F}}")#text(" of bounded complexity and pure of weight ")#mi("{0}")#text(", where ")#mi("{c}")#text(" is an algebraic integer reflecting the Tate twists present in the geometrically trivial component of ")#mi("{{\\mathcal F}}")#text(" (in particular, ")#mi("{c=0}")#text(" if there is no such component). Thus we have a strong “structure vs randomness” dichotomy for this class of functions: either ")#mi("{K}")#text(" has a geometrically trivial component, or else ")#mi("{K}")#text(" exhibits square root cancellation. Informally, we are guaranteed square root cancellation for structured functions unless there is a clear geometric reason why such cancellation is not available.")

#text("From ")#link("http://en.wikipedia.org/wiki/Schur%27s_lemma")[#text("Schur’s lemma")]#text(", we then conclude the almost orthogonality relation")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\in U({\\mathbb F})} K_{\\mathcal F}(x) \\overline{K_{{\\mathcal F}^{\\prime}}(x)} = c \\delta_{{\\mathcal F} \\equiv {\\mathcal F}^{\\prime}} q + O( q^{1/2} )")]]

#text("for two geometrically irreducible sheaves ")#mi("{{\\mathcal F}, {\\mathcal F}^{\\prime}}")#text(" of bounded complexity and weight ")#mi("{0}")#text(", where ")#mi("{\\delta_{{\\mathcal F} \\equiv {\\mathcal F}^{\\prime}}}")#text(" is ")#mi("{1}")#text(" when ")#mi("{{\\mathcal F}, {\\mathcal F}^{\\prime}}")#text(" are geometrically isomorphic, and ")#mi("{0}")#text(" otherwise, and ")#mi("{c}")#text(" is an algebraic integer measuring the Tate twists in the geometric isomorphism between ")#mi("{{\\mathcal F}}")#text(" and ")#mi("{{\\mathcal F}^{\\prime}}")#text(" (in particular ")#mi("{c=1}")#text(" when ")#mi("{{\\mathcal F}={\\mathcal F}^{\\prime}}")#text("). This gives a useful dichotomy: two irreducible structured functions on a curve with boundedly many points removed are either multiples of each other by a root of unity (after restricting to their common domain of definition), or else have an inner product of ")#mi("{O(q^{1/2})}")#text(". (Among other things, this provides polynomial bounds on the number of distinct structured functions of bounded complexity, by using the Kabatjanskii-Levenstein bound mentioned in ")#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/")[#text("the previous post")]#text(".)")

#text("A typical application of this dichotomy is to correlations of the form ")#mi("{\\sum_{x \\in {\\mathbb F}}^* K(x+l) \\overline{K(x)}}")#text(" of some structured function ")#mi("{K}")#text(" (where the asterisk denotes a restriction to those ")#mi("{x}")#text(" that avoid the singularities of ")#mi("{K}")#text("); if ")#mi("{q}")#text(" is prime, one can show that this correlation is ")#mi("{O(q^{1/2})}")#text(" for all non-zero ")#mi("{l}")#text(", unless ")#mi("{K}")#text(" correlates with a linear phase (i.e. it has an Artin-Schrier component). In a similar fashion, ")#mi("{\\sum_{x \\in {\\mathbb F}}^* K(x+l) \\overline{K(x)} \\psi(mx)}")#text(" can be shown to be ")#mi("{O(q^{1/2})}")#text(" for all non-zero ")#mi("{l}")#text(" and any ")#mi("{m}")#text(", unless ")#mi("{K}")#text(" correlates with a quadratic phase. These facts are reminiscent of the inverse theorems in the theory of the Gowers uniformity norms, but in the case of structured functions one gets extremely good bounds (either perfect correlation, or square root cancellation). A bit more generally, one can study correlations of the form ")#mi("{\\sum_{x \\in {\\mathbb F}}^* K(x) K(\\gamma x)}")#text(", where ")#mi("{\\gamma}")#text(" is a fractional linear transformation, leading to an analysis of the automorphy group of ")#mi("{K}")#text(" with respect to the ")#mi("{SL_2}")#text(" action; see ")#link("http://www.math.ethz.ch/~kowalski/friedlander-iwaniec-sum.pdf")[#text("this note of Fouvry, Kowalski and Michel")]#text(" for details.")

#heading(level: 1)[#text("Comments (105)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d57d55e60f821c1d05e39e34c9f7770b30a9a51ebc94969c5c6db5cd7bae3144-2d1d60be21e3bf6a907ac9aa471919572194be3ccb33d6dbea29fe5343b9132d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hiklicepleh")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-450930")[#strong[#text("hiklicepleh")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2015")])]

#mi("\\displaystyle \\psi(x) = x - \\sum_\\rho \\frac{x{\\rho}}{\\rho} - \\frac{1}{2}\\log(1 - \\frac{1}{x^2}) - \\log 2\\pi + \\frac{1}{2}\\Lambda(x)")#text(" for ")#mi("\\displaystyle x > 1")

#mi("\\displaystyle \\sum_{n \\leq x} \\log n = \\sum_{n \\leq \\frac{x}{2}} \\psi(\\frac{x}{n})")

#mi("\\displaystyle \\sum_{n \\leq \\frac{x}{2}} \\psi(\\frac{x}{n}) = \\sum_{n \\leq \\frac{x}{2}} \\left\\lfloor \\frac{x}{n} \\right\\rfloor - \\sum_{n \\leq \\frac{x}{2}} \\sum_\\rho \\frac{{\\left\\lfloor \\frac{x}{n} \\right\\rfloor}^{\\rho}}{\\rho} - \\frac{1}{2}\\sum_{n \\leq \\frac{x}{2}} \\log(1 - \\frac{1}{{\\left\\lfloor \\frac{x}{n} \\right\\rfloor}^{2}}) - \\frac{x\\log 2\\pi}{2} + \\frac{1}{2}\\sum_{n \\leq \\frac{x}{2}} \\Lambda(\\frac{x}{n})")

#mi("\\displaystyle \\sum_{n \\leq x} \\Lambda(\\frac{x}{n}) = \\sum_{n \\leq \\pi({x}^{\\frac{1}{2k}})} (\\left\\lfloor \\frac{x}{{p_n}^{k}} \\right\\rfloor - \\left\\lfloor \\frac{x}{{p_n}^{k}+1} \\right\\rfloor)\\log {p_n}^{k} + O(x^{1/2} \\log x)")#text(" for ")#mi("\\displaystyle k \\ge 1")

#text("You can get a good estimate for the ")#mi("\\displaystyle \\sum_{n \\leq \\frac{x}{2}} \\sum_\\rho \\frac{{\\left\\lfloor \\frac{x}{n} \\right\\rfloor}^{\\rho}}{\\rho}")#text(".")

#mi("\\displaystyle \\sum_{n \\leq \\frac{x}{2}} \\sum_{\\frac{1}{2} + i\\beta} \\frac{{\\left\\lfloor \\frac{x}{n} \\right\\rfloor}^{\\frac{1}{2} + i\\beta}}{\\frac{1}{2} + i\\beta}")#text(" – How to evaluate this expression? Will give us a permanent inequality of the real part of non-trivial zeros?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-453500")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2015")])]

#tao-math("\\displaystyle \\left|\\pi (x) - Li(x)\\right| Li(x)+\\frac{1}{3}\\frac{x^{1/2}}{\\log x} \\log \\log \\log x", block: false)#linebreak()#text(" ")#mi("\\displaystyle \\pi (x) < Li(x)-\\frac{1}{3}\\frac{x^{1/2}}{\\log x} \\log \\log \\log x")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fde2eba1776c1e9e337452c28186b24cf400119475f5ae518b7195f1177a6be6-8d0cb955b2d4a6c09af3c7efb808a23f3d7663f3882b87a8b9539419e7b506f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tai")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-456126")[#strong[#text("tai")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2015")])]

#text("I solve Riemann Hypothesis.")

#text("Please see it.")

#link("http://vixra.org/abs/1403.0184")[#text("http://vixra.org/abs/1403.0184")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A wave equation approach to automorphic forms in analytic number theory | What's new")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-458178")[#strong[#text("A wave equation approach to automorphic forms in analytic number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2015")])]

#text("[…] e.g. this previous post for a discussion of this bound) to arrive at the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tai")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-459757")[#strong[#text("tai")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2015")])]

#text("I rewrite the paper.Please see it.")

#link("http://vixra.org/abs/1508.0122")[#text("http://vixra.org/abs/1508.0122")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-461985")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2015")])]

#text("Riemann Hypothesis (proven)")

#text("Two of the statements of Riemann.")

#text("1º- The series for the zeta function will have the particularity of (s= 1).")

#text("2º- Is very likely that the roots of a ")#mi("f(x)")#text(" are real.")

#text("is to say: ")#mi("\\zeta(a+ib) = 0")

#text("with: ")#mi("a = \\frac{1}{2} ; b = \\sum_{n}^{infty}\\frac{1}{n}")

#mi("f(x) = \\sum_{n=3}^{infty}\\frac{1}{n} = \\frac{1}{2}")

#mi("f(x) = \\sum_{n=4}^{infty}\\frac{1}{n} = \\frac{1}{3}")

#text("Indicated the beginning of a of the series for ")#mi("a = \\frac{1}{2}")

#tao-math("\\left|\\frac{1}{2}\\right|^{2} + \\left|i\\left(\\frac{1}{3} + \\frac{1}{6}\\right)\\right|^{2} = 0", block: false)

#tao-math("\\left|\\frac{1}{2}\\right|^{2} + \\left|i\\left(\\frac{1}{3} + \\frac{1}{9} + \\frac{1}{18}\\right)\\right|^{2} = 0", block: false)

#tao-math("\\left|\\frac{1}{2}\\right|^{2} + \\left|i\\left(\\frac{1}{3} + \\frac{1}{9} + \\frac{1}{24} + \\frac{1}{72}\\right)\\right|^{2} = 0", block: false)

#tao-math("\\left|\\frac{1}{2}\\right|^{2} + \\left|i\\left(\\frac{1}{3} + \\frac{1}{9} + \\frac{1}{24} + \\frac{1}{81} + \\frac{1}{648}\\right)\\right|^{2} = 0", block: false)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-474391")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2016")])]

#text("Is there an equivalent statement of the Riemann hypothesis in Quantum Theory (Quantum Field Theory, Quantum Mechanics, etc.)? If there is a statement in the Quantum Theory, which is logically equivalent to ")#mi("\\Pi_1")#text(" statement. Then this statement is independent of ")#mi("PA")#text("?")

#text("We know that RH is equivalent to a ")#mi("\\Pi_1")#text(" statement. Also we know that: “If a ")#mi("\\Pi_1")#text(" statement is independent of ")#mi("PA")#text(", then it is true”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-474476")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2016")])]

#text("I think that the sum of prime numbers are the imprint of some sequences +,-,+,-,+,-,+,-,+,- with continious function(‘s) (")#mi("(-f(x))^n")#text("). If this is true, then an error in the formula must be symmetrical. My assumption is based on Perron’s formula, and the sums of the form ")#mi("(-1)^n")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-474479")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2016")])]

#text("Of course, the Riemann Hypothesis is true!")

#text("Reference links:")

#link("https://www.researchgate.net/publication/300068776_Proof_of_Riemann_Hypothesis")[#text("https://www.researchgate.net/publication/300068776_Proof_of_Riemann_Hypothesis")]#text(";")

#link("https://www.researchgate.net/post/Why_is_the_Riemann_Hypothesis_true2")[#text("https://www.researchgate.net/post/Why_is_the_Riemann_Hypothesis_true2")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-474699")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2016")])]

#text("The Riemann Hypothesis (RH) is true!")

#text("It’s a SIN to think otherwise.")

#text("Q1. Where are all the primes in the critical strip, [0, 1] ?")

#text("Q2. Where are all the powers of primes in the critical strip, [0, 1]?")

#text("Q3. How are prime numbers and the nontrivial zeros of the Riemann zeta function connected?")

#text("Hints:")#linebreak()#text(" Please consider the Fundamental Theorem of Arithmetic, the Generalized Fundamental Theorem of Algebra, the Harmonic Series, and the very important PRIME NUMBER THEOREM since we are counting primes and predicting primes approximately.")

#text("If one can answer the above questions, then one understands why the Riemann Hypothesis is true!")

#text("Reference link: ")#link("https://www.researchgate.net/post/Why_is_the_Riemann_Hypothesis_true2")[#text("https://www.researchgate.net/post/Why_is_the_Riemann_Hypothesis_true2")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-474700")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2016")])]

#text("Hint for Q1: 1/2 , 1/3, 1/5, 1/7, 1/11, …., 1/p for some prime distinct number, p.")

#text("Hint for Q2: We have 1/n where n = ∏(p_i)^k_i over distinct prime numbers, p_i, for some integer, k_i ≥ 1 .")

#text("Note: p_1 = 2, p_2 = 3, p_3 = 5, …")

#text("Hint for Q3: Prime Number Theorem …")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-478250")[#strong[#text("The Fontaine-Winterberger theorem: going full tilt | Hard Arithmetic")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2017")]

#text("[…] For a taste of the veracity of this claim I would highly recommend reading this excellent post of Terry […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c5bfdbfd5fe3912d881cd368f86085e35c3df018ddc5bd7ca54974d0a86734b-698dc7791805d933a64c963450cc3f30df2bce61c1d56435c1660236bd448a5c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Remer")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-479045")[#strong[#text("Remer")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2017")])]

#text("Dear Prof. Tao,")

#text("I hope you are doing well.")

#text("I’m interested in this topic (Riemann hypothesis- which I believe it’s true) and since I love finding patterns this made me comment.")

#text("I know how busy you are but just in case you have time then I greatly appreciate it.")

#text("Actually I have difficulties to how I will start since I’m a novice in this area.")

#text("Let me say that I was motivated in writing this comment by the story of James Lovelock, one of the scientist invited by NASA for the search of life in Mars, all of the great minds were gathered for analyzing tools for detecting life/organism, then James Lovelock spoke-out his doubt (What if) this is not the way to detect life… then they realize (I’m not good in English but for those who are interested on the story you can find it in youtube).")

#text("I know I don’t have the right to say, but What If we just overlook some simple solution of Reimann. What if we need to look simply at once that the Riemann’s zeta function: enable the separation of composite numbers (to the left plane) and prime numbers (to the critical strip) that extracted from Euler equation at the right of the complex plane. That is the zeros of Riemann’s zeta function give us the properties of real numbers located on the corresponding plane – it just happens there is.")

#text("In my works, I named the Complex plane of Riemann by:")

#text("1st part where R(s)>1: the Composite and Prime number zone")#linebreak()#text(" 2nd part where 0<R(s)<1: Prime number zone")#linebreak()#text(" 3rd part where R(s)<0: Composite number zone")

#text(" Let me start in 3rd part where the value of is R(s)<0")

#text("I have named it since I’ve found connections between the trivial zeros (2,4,6,8..) of the function to the composite numbers.")

#text("I define a number as:")

#text("1. All natural numbers can be represented by a series of ratio of numbers (which carried its divisibility information), I call it “Spine” (I likely to compare it as their DNA). That is in order for a number to be composite its Spine should contain(s) either or combinations of 2,4,6.. (trivial zeros) – I can show it with formula")#linebreak()#text(" 2.The Spine of all natural numbers follows the cubic equations – I can prove and illustrate it")

#text("By the way I’m not sure if I can show you exactly my works here because I have to put some formulas and it will be supported by tables of numbers and drawings to show the behavior, especially in Prime number zone.")

#text("Hopefully there's a link to where I can send my works, that’s if you find it relevant.")

#text("Remer")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c5bfdbfd5fe3912d881cd368f86085e35c3df018ddc5bd7ca54974d0a86734b-698dc7791805d933a64c963450cc3f30df2bce61c1d56435c1660236bd448a5c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Remer")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-479089")[#strong[#text("Remer")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2017")])]

#text("Dear Prof. Tao,")

#text("I know how busy you are but just in case you have time then I greatly appreciate it.")#linebreak()#text(" I hope I’m not annoying here, for continuing my claimed in my previous post.")

#text("(Continuing at Composite number zone : R(s)<0)")#linebreak()#text(" I only consider odd numbers for obvious reason")

#text("Let me redefined my 1st claimed")

#text("1. All natural numbers (odd) can be represented by a series of ratio of numbers carrying its divisibility information; I call it “Spine” (I likely to compare it as their DNA). That is in order for a number to be composite its Spine should contain(s) either or combination of 2, 4, 6… (trivial zeros)")

#text("Let’s consider any composite number, P.")

#text("(Ex.1) P=9: its Spine can be shown as 5/4")#linebreak()#text(" 6/3 = 2")#linebreak()#text(" 7/2")

#text("(Ex.2) P=15: its Spine can be shown as 8/7")#linebreak()#text(" 9/6")#linebreak()#text(" 10/5 = 2")#linebreak()#text(" 11/4")#linebreak()#text(" 12/3 = 4")#linebreak()#text(" 13/2")

#text("(Ex.3) P=21: its Spine can be shown as 11/10")#linebreak()#text(" 12/9")#linebreak()#text(" 13/8")#linebreak()#text(" 14/7 = 2")#linebreak()#text(" 15/6")#linebreak()#text(" 16/5")#linebreak()#text(" 17/4")#linebreak()#text(" 18/3 = 6")#linebreak()#text(" 19/2")#linebreak()#text(" Anyone may wish to try it to all odd composite numbers, as long as you will maintain the Spine’s Pattern, you will come out with the same result.")

#text("• Trivial zeros are the imprint(s) of Composite’s Spine (any pattern lovers may conclude therefore that Non-trivial zeros are the imprint of Prime number’s Spine – yes, but its Spine is so unique that it only follows the rules inside the critical strip- I will illustrate it)")

#text("Pattern of Composite’s Spine")#linebreak()#text(" o let a= ath place of the odd number (P)")#linebreak()#text(" o that is P=2a+1")#linebreak()#text(" o sequence = (a+1)/a , (a+2)/(a-1) , (a+3)/(a-2) , (a+4)/(a-3)… (a+n)/2")#linebreak()#text(" o the denominator begins at “a” and ends at “2” (there’s a pattern why it should begins and terminate here, which I think unnecessary to explain)")

#text("The Composite’s Spine can help us to do")#linebreak()#text(" o Primality testing")#linebreak()#text(" o Prime sieving (I can illustrate it)")

#text("We can say that a number is composite if it satisfies to")

#text("[(a+1+n)/(a-n)] = m or to [P/(a-n)]-1 =m")

#text("where:")#linebreak()#text(" n= 1, 2, 3, 4…. any natural number {(n-1)th place of the number sequence)}")#linebreak()#text(" m= 2, 4, 6…. any the trivial zeros,")#linebreak()#text(" a= ath place of the odd number (P), That is P=2a+1")

#text("This is how beautifully a number can be interpreted (giving hope for non- technical person, like me, to explore) and I hope that there will be someone (mathematician) who will give progress in this insight.")

#text("Remer Catacutan")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MatjazG")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-479567")[#strong[#text("MatjazG")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2017")])]

#text("I am curious as to your thoughts on the recent progress in solving the Riemann hypothesis via the Hilbert-Pólya conjecture described in this Physical Review Letters article:")

#text("C. M. Bender, Dorje C. Brody, and Markus P. Müller, Hamiltonian for the Zeros of the Riemann Zeta Function, Phys. Rev. Lett. 188, 130201 (2017)")

#text("DOI: ")#link("https://doi.org/10.1103/PhysRevLett.118.130201")[#text("https://doi.org/10.1103/PhysRevLett.118.130201")]

#text("Abstract:")

#text("A Hamiltonian operator H is constructed with the property that if the eigenfunctions obey a suitable boundary condition, then the associated eigenvalues correspond to the nontrivial zeros of the Riemann zeta function. The classical limit of H is 2xp, which is consistent with the Berry-Keating conjecture. While H is not Hermitian in the conventional sense, iH is PT symmetric with a broken PT symmetry, thus allowing for the possibility that all eigenvalues of H are real. A heuristic analysis is presented for the construction of the metric operator to define an inner-product space, on which the Hamiltonian is Hermitian. If the analysis presented here can be made rigorous to show that H is manifestly self-adjoint, then this implies that the Riemann hypothesis holds true.")

#text("–")

#text("Is there hope that this could lead to something substantial?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2f1b04e9203ad3ba77d7796c24acd40e1187f75baa4260a83817eb793bed9d5-d42bcab2de4f4569fe63639212d11c2ced348e8c40c8f5654f2e9dc7f04d9e69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of int.math")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-480010")[#strong[#text("int.math")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2017")])]

#text("I have found that:")#linebreak()#text(" ")#mi("\\eta (s)=0\\iff\\sum_{n=1}^{\\infty}(2n-1)^{s-1}=0")#text(".")#linebreak()#text(" Does anyone know equivalent results?")#linebreak()#text(" (η(s):dirichlet eta function)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2f1b04e9203ad3ba77d7796c24acd40e1187f75baa4260a83817eb793bed9d5-d42bcab2de4f4569fe63639212d11c2ced348e8c40c8f5654f2e9dc7f04d9e69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of int.math")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-480075")[#strong[#text("int.math")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2017")])]

#text("I have also found a similar relation with Riemann zeta function:")#linebreak()#text(" ")#mi("\\zeta (s)=0\\iff\\sum_{n=1}^{\\infty}(2n)^{s-1}=0")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2f1b04e9203ad3ba77d7796c24acd40e1187f75baa4260a83817eb793bed9d5-d42bcab2de4f4569fe63639212d11c2ced348e8c40c8f5654f2e9dc7f04d9e69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of int.math")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-480095")[#strong[#text("int.math")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2017")])]

#text("Please, can someone check this:")#linebreak()#text(" ")#mi("\\zeta (s)=(\\frac{y}{2\\pi })^{0.5-x}e^{-i(yln(\\frac{y}{2\\pi})-y-\\frac{\\pi}{4})}\\zeta(1-s) , s=x+iy, y>0")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-480108")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2017")])]

#text("It seems that Stirling’s approximation(!) for the Gamma function was used in the Zeta functional equation (anyway, it is not an exact identity.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d187a34135d33024ccd60f2cf8f2ba799f7335215f14eafaabb7b7cabff71792-7c7c89e16274a42cc4cbdbf2e1764b959dacc78f4800a6cf730cd5956f3b4e24.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Cole")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-481212")[#strong[#text("David Cole")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2017")])]

#text("“If you can’t explain simply, you don’t understand it well enough.” — Albert Einstein.")#linebreak()#text(" ")#linebreak()#text(" What does the Riemann Hypothesis (RH) mean?")

#text("RH confirms the existence of prime numbers in an optimal way. Or rather, for all positive integers, k > 1, there exists a prime number, p, which divides k such that either p = k or p ≤ sqrt(k) = k^(1/2) where RH states the exponent of k is 1/2.")#linebreak()#text(" ")#linebreak()#text(" Please keep that fundamental fact in mind when discussing the truth of RH.")#linebreak()#text(" ")#linebreak()#text(" Reference link:")#linebreak()#text(" ")#link("https://www.researchgate.net/post/Why_is_the_Riemann_Hypothesis_true2")[#text("https://www.researchgate.net/post/Why_is_the_Riemann_Hypothesis_true2")]#text(".")

#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d187a34135d33024ccd60f2cf8f2ba799f7335215f14eafaabb7b7cabff71792-7c7c89e16274a42cc4cbdbf2e1764b959dacc78f4800a6cf730cd5956f3b4e24.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Cole")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-481378")[#strong[#text("David Cole")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2017")])]

#text("Does the nth non-trivial simple zero of the Riemann zeta function indicate the nth prime, p_n, occurs as a prime factor in all multiples of p_n?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d187a34135d33024ccd60f2cf8f2ba799f7335215f14eafaabb7b7cabff71792-7c7c89e16274a42cc4cbdbf2e1764b959dacc78f4800a6cf730cd5956f3b4e24.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Cole")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-481452")[#strong[#text("David Cole")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2017")])]

#text("Hmm. The short answer is a resounding yes! Wow! The great Riemann saw it all.")

#text("Reference link:")

#text("‘On the Number of Prime Numbers less than a")#linebreak()#text(" Given Quantity.(Ueber die Anzahl der Primzahlen unter einer")#linebreak()#text(" gegebenen Grosse.) ‘,")

#link("http://www.claymath.org/sites/default/files/ezeta.pdf")[#text("Click to access ezeta.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d187a34135d33024ccd60f2cf8f2ba799f7335215f14eafaabb7b7cabff71792-7c7c89e16274a42cc4cbdbf2e1764b959dacc78f4800a6cf730cd5956f3b4e24.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Cole")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-481497")[#strong[#text("David Cole")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2017")])]

#text("FYI:")

#text("Please an answer at link:")

#link("https://www.researchgate.net/post/Does_the_nth_nontrivial_simple_zero_of_the_Riemann_zeta_function_indicate_the_nth_prime_p_n_occurs_as_a_prime_factor_in_all_multiples_of_p_n")[#text("https://www.researchgate.net/post/Does_the_nth_nontrivial_simple_zero_of_the_Riemann_zeta_function_indicate_the_nth_prime_p_n_occurs_as_a_prime_factor_in_all_multiples_of_p_n")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heat flow and zeroes of polynomials II: zeroes on a circle | What's new")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-501371")[#strong[#text("Heat flow and zeroes of polynomials II: zeroes on a circle | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2018")])]

#text("[…] , then, as famously proven by Weil, the associated local zeta function (as defined for instance in this previous blog post) is known to take the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75a81f2214ae05cd91b405a5f653979e27684d525df38c839085bda1741cd880-682ebf6fdf567dadbbcfc7adb7f3c200c1c5008f4a776fc2ffac572494f0b0d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pallav Goyal")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-502030")[#strong[#text("Pallav Goyal")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2018")])]

#text("The summand in identity (2) isn’t defined when ")#mi("n=1")#text(", so maybe the sum should start from ")#mi("n=2")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-502040")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2018")])]

#text("Since ")#mi("\\Lambda (1) = 0")#text(", it seems that the first summand is ")#mi("0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75a81f2214ae05cd91b405a5f653979e27684d525df38c839085bda1741cd880-682ebf6fdf567dadbbcfc7adb7f3c200c1c5008f4a776fc2ffac572494f0b0d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pallav Goyal")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-502089")[#strong[#text("Pallav Goyal")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2018")])]

#text("Yeah. I guess the meaning of the expression is clear as such, this is just a pedantic correction.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-511175")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2019")])]

#text("I have always liked this image,")#link("http://en.wikipedia.org/wiki/Image:Zeta_polar.svg")[#text("http://en.wikipedia.org/wiki/Image:Zeta_polar.svg")]#text(", but could someone explain it? Is important or useful? Hides the secret of RH? Has some modular arithmetica?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-519796")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2019")])]

#text("This may seem like a stupid question, but what exactly does the Riemann hypothesis mean for the prime numbers? I mean the twin prime conjecture just means that there are infinitely many pairs of primes with difference 2, is there such a straightforward formulation for the consequences of the Riemann hypothesis?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-528122")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2019")])]

#text("Dear Terry,")

#text("Your definition of mixed sheaf seems to be a priori weaker than the usual one (there exists a finite filtration of subsheaves $\\mathscr{F}_1 \\subset \\cdots \\subset \\mathscr{F}_n = \\mathscr{F}$ such that the successive quotients are pure). Does it turn out to be equivalent? If so, is this easy to see?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/574fa4a5c1366caa0ae29edc13549d94f019364abdc6a24507708dda27e0f5fb-c9aa00c9917cacce1a10b1f81a8396bdf77cc08e9b305d139d1929ff11f2ddac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of How do you work in midage?")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-631042")[#strong[#text("How do you work in midage?")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2021")])]

#text("How are you able to do outstanding research in late 40s? Do you have any learning disabilities because of midage? Is there immunity to midage debilitation?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0545852da5807914429ef5ae24101202050d1b410f4c40859ea6459d39e306c7-d47625e23651b8423526a35f6e40ecdfa22a915d923b0d2c0d66cf3cf80cb2eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-640638")[#strong[#text("Daniel")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2022")])]

#text("You are all welcome to comment on my paper “On the Riemann hypothesis” at ")#link("https://vixra.org/pdf/2004.0533v3.pdf")[#text("https://vixra.org/pdf/2004.0533v3.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c4d8b9396a9d516e61b68ce7fc6f98ff2d0b18ea884597c59fadf79ea24776e4-cfd1698d13171adb6d0b044d2a2f9b7be87e9bb405fe4e740b2a1e53ad67d25b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sal Daouairi")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-668812")[#strong[#text("Sal Daouairi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2022")])]

#text("Great summary subject from Terrence, finaly the conjecture “Riemann Hypothesis” Solved few day ago 11/25/2022 in a")#linebreak()#text(" peer reviewed journal under link:")#linebreak()#text(" 10.5923.j.ijtmp.20221202.03.pdf")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b37167347d65be18bbfa6cc6e3f07610ae3e2539b9784cc31e103c0ec1564f3d-11eab5d05786011999e73f0735593daad3808580ea2c1110db8c36270dc80146.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wired for RH")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-673381")[#strong[#text("wired for RH")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2023")])]

#text("Is there any plans for you to do a video on Riemann hypothesis as in ")#link("https://twitter.com/WIRED/status/1620195277456941061")[#text("https://twitter.com/WIRED/status/1620195277456941061")]#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-2/#comment-688220")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2025")])]

#text("There are various things about Primes we do not know.. how to count, where do they exist, how far away they are etc etc. Yet we do not know a single (natural) statement about them which is undecidable. I am wondering if the concept of zeta functions in formal languages would be applicable if one could concoct a good enough, versatile definition of primes or such a useful definition of primes cannot be far from the trivial one known to Greeks which is still being employed everywhere?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c18b01ce7045b846d4b345c7e6a1f00fc78b7920dad1c72e409ae7ea7096c624-59149e3910509c0e2baab70107bfb50470121150beec3e39523e9f8ae21d2669.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of castover")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239182")[#strong[#text("castover")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2013")])]

#text("Reblogged this on ")#link("http://riemannianhunger.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/")[#text("riemannian hunger")]#text(" and commented:")#linebreak()#text(" So Terence Tao has posted a blog regarding the Riemann Hypothesis. He notes that his blog is one that makes “no new progress” on the hypothesis, but later refers to the entry as one in which he is “simply arranging existing facts together”.")#linebreak()#text(" And THAT, ladies and gentlemen, would be the perfect way for someone as amazing as Tao to provide a subtle, suave introduction to a long series of posts, the culmination of which could be an actual proof to Riemann’s actual hypothesis.")#linebreak()#text(" Has the already-brilliant Terry Tao solved the Riemann Hypothesis? Stay tuned to his quadrant of internet space to find out….")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-240152")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2013")])]

#text("dear castover,all people in the world are stupid,why we agree 17 .other turn down 45, i know the reason , for hate him, envy him.why, he is very young,also number one in the world.even perelman not compare him.i tell all the world that TERENCE TAO")#linebreak()#text(" solved 4/6 millenium problems.why i know, i am him, he is my self. i live outside the earth.why he not announce the result of 4/6 millenium ones.maths is like market,also competion, also for fame,also money.terence tao is humble, modest, yield.he not")#linebreak()#text(" compete.he is waiting every one announces milleniun maths.but nobody cannot do.he is the only one in the world.someday,you will find my conclusion correct. i am also a prophet")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a54492887f312e2642b8d36302f3a8f1ccd1b41a8a577146e3d38b2e67d047d-b9b708cb19745c7fc06f19e16fdf3f87191e82f81319ca05ab6cf7db10467b00.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zeeshan Mahmud")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-241835")[#strong[#text("Zeeshan Mahmud")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2013")])]

#text("Funny thing is should a question on RH were posted on SE or Mathoverflow, it would be shut down faster than an eyelid. Also, mathematics – paragon of logic and reason- seems to favor reputation by published authors to assess if any further paper is worth reading. I do not agree with your snide comment, but mathematics is becoming an elitist field, instead of being open to commoners. Look at the spite downvotings of the naif who asked what is a zero. Yes, we don’t help, but we downvote to assert our own dominance over others.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-455507")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2015")])]

#text("I suspect you’re wrong!")#linebreak()#text(" Prof. P. Fernandez")#linebreak()#text(" MSc. at the X Paris, Gottingen University, Germany, DSc., Continuum Mechanics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90be308eed25ee97422b84bb02b87e52566d4e296322a811776b8ebbfeb5cf46-92174fba00f66eede65dbb894aba8b12eabf1776e9882fcc866f44f1799e58b2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathtuition88")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239185")[#strong[#text("mathtuition88")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2013")])]

#text("Reblogged this on ")#link("http://mathtuition88.com/2013/07/20/the-riemann-hypothesis-in-various-settings/")[#text("Singapore Maths Tuition")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239186")[#strong[#text("Tao hablando de la hipótesis de Riemann | Adsu's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2013")]

#text("[…] máxima al abrir hoy el Reader de wordpress: Tao hablando de la hipótesis de Riemann en su blog!. Deja claro al principio del post que simplemente va a colocar junto todo lo que se conoce al […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Valentin")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239210")[#strong[#text("Valentin")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("Sorry for such basic a question, but what is a zero of zeta function? This is a complex number, isn’t it? So should only the real part, or only imaginary part, or both equal zero?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239218")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("A zero means a complex number where the function becomes zero (they are also called roots sometimes). For example, the zeros of the complex function ")#mi("z^4-1")#text(" are ")#mi("1,-1,i,-i")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Valentin")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239226")[#strong[#text("Valentin")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("But what is the ‘zero’ of a complex number? Function ")#mi("z^4-1")#text(" ‘outputs’ complex numbers, doesn’t it? So to qualify as a zero the ‘output’ must be ")#mi("(0,0)")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239241")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("Yes, the output must be ")#mi("(0,0)")#text(", i.e. the complex number ")#mi("0")#text(". BTW there is no such thing as the zero of a complex number. This post is about the zeros of certain complex functions (functions whose input and output are complex numbers).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Valentin")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239256")[#strong[#text("Valentin")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("Thanks, got it.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239242")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("both equal zero")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/353141aae94df7fa820777cb2404306103c8b4d2cb07198e646dd27cd03b4fd8-ae54acbeb25fd6976c81a2bd90e2755b6b6bf11acb02b45569f51a48e53cc15f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amarashiki")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239211")[#strong[#text("amarashiki")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("My contribution, from a purely physical viewpoint, here: ")#link("http://thespectrumofriemannium.wordpress.com/2012/11/07/log050-why-riemannium/")[#text("http://thespectrumofriemannium.wordpress.com/2012/11/07/log050-why-riemannium/")]#text(" and ")#link("http://thespectrumofriemannium.wordpress.com/2012/11/07/log051-zeta-zoology/")[#text("http://thespectrumofriemannium.wordpress.com/2012/11/07/log051-zeta-zoology/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b7e7e8ac4ff15f3c57a19cce156b32adf16045492076a55f1ca820a918687b00-84297b321d443d2fe29cd137930857f66e90c7b6e9903c5f7cb66330948410bc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edgar's Creative")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239224")[#strong[#text("Edgar's Creative")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("Reblogged this on ")#link("http://edgarventurescreative.wordpress.com/2013/07/20/the-riemann-hypothesis-in-various-settings/")[#text("Edgar's Creative")]#text(" and commented:")#linebreak()#text(" Terence Tao on The Riemann Hypothesis")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dab262b249e6b008de2defe2a9d55f776181f2faf2f8a2ae168348cdfb2adaf-097fe507317aee85ccf32427e06a89aeacc09d75464afe95cd265a14b70a7a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239259")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("A few minor comments:")

#text("1. (the short exact sequence of arithmetic and geometric fundamental groups) If ")#mi("U")#text(" is a variety over ")#mi("k")#text(", ")#mi("\\text{Spec} k")#text(" does not necessarily embed into ")#mi("U")#text(". The generic point construction gives an embedding of ")#mi("\\text{Spec} k(U)")#text(", which is a much bigger field. For some ")#mi("k")#text(" and ")#mi("U")#text(", we can verify that no splitting in the exact sequence exists, via cases of Grothendieck’s section conjecture.")

#text("2. The reason one must use ")#mi("l")#text("-adic coefficients instead of complex coefficients for lisse sheaves is merely that ")#mi("\\pi_1")#text(" is a profinite group and ")#mi("GL_n(\\mathbb C)")#text(" is a Lie group. Continuous maps from a profinite group to a Lie group factor through finite groups, so there are just not enough of them to represent all the structured functions we might want to use. ")#mi("GL_n(\\mathbb Q_l)")#text(", on the other hand, has a large profinite subgroup – ")#mi("GL_n(\\mathbb Z_l)")#text(" – and so there are many more continuous maps.")

#text("3. An irreducible lisse sheaf is one which cannot be decomposed as an extension of lisse sheaves, not one which cannot be decomposed as a direct sum of lisse sheaves.")

#text("4. A geometrically trivial sheaf is only a direct sum of Tate sheaves if it is semisimple.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239264")[#strong[#text("News From All Over | Not Even Wrong")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")]

#text("[…] for those with mathematical interests who have waded through the above, Terry Tao has a remarkable long expository piece about the Riemann hypothesis, ranging from analytic number theory aspects through the function field case and l-adic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239314")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2013")])]

#text("I have seen a generalization of the zeta function defined for a group by the formula ")#mi("\\sum_{H \\leq G} \\frac {1}{ [G:H]^s} = \\zeta_G(s)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5ae1a4656fbe12e4b6c7424b240f48d4d2060112c6d4ab820a0ed4a4ff6ee67-775694d3e88a94e075c2ee807c2fcdd5947bd6e897312da847ede06fff3274d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ron")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239343")[#strong[#text("Ron")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2013")])]

#text("There should be a space after Eq (8) “this is a twisted version”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e3c273a76f48dd3b19e0bde36ef29d74c508a35a2817f6fe9ad6599bf053b164-965d7ad9f91885bdf19fd4c77aa0cf8a1333e06427ea83b0e7e7c3fb5acdaef5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Nilson")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239366")[#strong[#text("Thomas Nilson")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2013")])]

#text("Try to factor x. x/y gives some number with decimals for some integer y. x/(y-1) and x/(y+1) should be correlated to the decimals from x/y in some way depending on how close you are to a factor to x. Since the zeta function runs through all numbers to the infinity and there is division in zeta function maybe the zeta function connects the above type of decimals with the distribution of primes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e3c273a76f48dd3b19e0bde36ef29d74c508a35a2817f6fe9ad6599bf053b164-965d7ad9f91885bdf19fd4c77aa0cf8a1333e06427ea83b0e7e7c3fb5acdaef5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thomasnilson")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-240444")[#strong[#text("thomasnilson")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2013")])]

#text("After thinking about it I found that “in some way depending on how close you are to a factor to x” is not true. The decimals tell that you haven’t found an integer factor.")#linebreak()#text(" Call the number of prime factors to an integer x the numbers dimensionality. x denotes area for 2 factors and volume for 3 factors. More factors to numbers comparable in size should mean more regularity to the number with more factors since you can view it’s regularity in space as area, volume etc. The numbers ")#mi("2^{n}")#text(" should be the most regular. I suggest that you can estimate a numbers randomness by calculating ")#mi("log(x)/(\\textrm{number of prime factors})=log(x)/(\\textrm{numbers dimensionality})")#text(". Where log is from the prime number theorem and the distribution of primes. For ")#mi("x=2^{n}")#text(" the randomness is ")#mi("log(2^{n})/n=n \\times log(2)/n=log(2)")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3fcdbceae10a9c7f4c4377dfe9ccbbd1c1513c024782954dc37837a8b9918e9-54fc6bc1ff54220f0f778aa22478489296f02014773fa054a245196758fb8990.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karl")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239383")[#strong[#text("Karl")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2013")])]

#text("Professor Tao,")#linebreak()#text(" Another very important conjecture is the ABC conjecture. There is a claim that it has been proved recently by a Japanese mathematician. Have you read his work? Would you have any comment on it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239387")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2013")])]

#text("* I am having a lot of trouble thinking of specific elements of these fundamental groups ")#mi("\\pi_{et}(U(\\mathbb{F}))")#text(" since the geometry is over ")#mi("\\mathbb{F}_q")#text(" (or possible ")#mi("\\mathbb{Q}_l")#text("). These must be cousins of the Frobenius maps ")#mi("x \\mapsto x^{q^n}")#text(".")

#text("For any curve, your trace is the trace of the action of the “etale” fundamental group ")#mi("\\pi_{et}")#text(" on the vector-bundle-like object ")#mi("\\mathcal{F}")#text(". Over ")#mi("\\mathbb{C}")#text(", these traces would never depend on the best point, but they do over ")#mi("{\\mathbb F}_p")#text("?")

#text("* Your definition of Lisse sheaf looks like what I would call “vector bundle over a curve with flat connection”. Branched covers and vector bundles are both representations of the fundamental group. These crude and pedestrian mnemonics help me follow difficult material until I figure out something better.")

#text("* There was a really nice book called Galois’ Dream which explained a “Galois Theory” of differential equations and related it to the fundamental group of surfaces. It has to do with monodromy solutions to differential equations as you move around a singularity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239407")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2013")])]

#text("As I understand it, the etale fundamental group (of a variety over a field) is sort of a combination of the geometric fundamental group and the absolute Galois group of the field (with the latter being nontrivial when working over a non-algebraically-closed field); Frobenius type elements give rise to the second factor of the group (at least when working over finite fields), but the former factor looks more like what one would expect from a topological group.")

#text("One simple example that I find instructive is that of the etale fundamental group of a punctured line ")#mi("({\\mathbb A}^1 \\backslash \\{0\\})/k = k^\\times")#text(" of an algebraically closed field ")#mi("k")#text("; here there is no Galois component and the situation is very close to that of the topological fundamental group of the punctured complex line ")#mi("{\\bf C}^\\times")#text(". In the latter case, we have a universal cover of ")#mi("{\\bf C}^\\times")#text(" by ")#mi("{\\bf C}")#text(" using the exponential map ")#mi("\\exp: {\\bf C} \\to {\\bf C}^\\times")#text(", which shows that the topological fundamental group of ")#mi("{\\bf C}^\\times")#text(" is isomorphic to the integers, which each integer representing a way to wind around the origin. In the etale setting, the exponential map is not available (this is not an algebraic map, and in any event is not defined for most fields); instead, we have a bunch of finite etale covers ")#mi("\\pi_n: k^\\times \\to k^\\times")#text(" coming from the ")#mi("n^{th}")#text(" power maps ")#mi("z \\mapsto z^n")#text(" (let’s say that ")#mi("k")#text(" has characteristic zero for simplicity, so we don’t have to worry about Artin-Schreier covers). (These covers were also present in the complex setting, but were factors of the exponential cover and so did not need to be considered separately.) As it turns out these are basically the only (connected) covers of ")#mi("k^\\times")#text(", and so an element of the etale fundamental group is completely determined by what it does to these covers. Indeed, the etale fundamental group of ")#mi("k^\\times")#text(" (at, say, the point ")#mi("1")#text(") is the profinite integers ")#mi("\\widehat{\\mathbb Z} = \\lim_{\\leftarrow} \\mathbb{Z}/n\\mathbb{Z}")#text(", and an element ")#mi("m")#text(" of the profinite integers corresponds to the operation on each finite etale cover ")#mi("\\pi_n: k^\\times \\to k^\\times")#text(" that rotates the fibre at ")#mi("1")#text(" (i.e. the ")#mi("n^{th}")#text(" roots of unity) by ")#mi("m \\text{ mod } n")#text(". This is pretty close to the topological situation except that we can’t necessarily glue together all these finite rotations into an integer rotation on the universal cover, because there is no longer any universal cover.")

#text("The situation when ")#mi("k")#text(" is not algebraically closed is more complicated, being a combination of some sort of profinite version of the topological group and a Galois group, and I don’t understand this much at all. Milne ")#link("http://www.jmilne.org/math/CourseNotes/LEC.pdf")[#text("calls")]#text(" the etale fundamental group of the twice-punctured plane ")#mi("({\\mathbb A} \\backslash \\{0,1\\})/{\\mathbb Q}")#text(" over the rationals “the most interesting object in mathematics” (see page 30 of the linked notes). This is perhaps an exaggeration, but it certainly is a complicated object.")

#text("Varying the base point corresponds to conjugating the etale fundamental group, much as is the case with the topological fundamental group. (I think the category theorists would say that one should really not be fussing over base points at all and work with fundamental groupoids instead of fundamental groups, but I’m not really familiar with this perspective.) The reason why the trace functions ")#mi("K(\\overline{x}) = \\text{tr}( \\text{Frob}_{\\overline{x}} | {\\mathcal F}_{\\overline{x}} )")#text(" are not simply constant in ")#mi("\\overline{x}")#text(" is that the action of Frobenius at ")#mi("\\overline{x}")#text(" is different at different values of ")#mi("\\overline{x}")#text(". For instance, in the Artin-Schreier sheaf ")#mi("\\phi: x \\mapsto x^q-x")#text(", the action of the (geometric) Frobenius map ")#mi("x \\mapsto x^q")#text(" on the fibre ")#mi("\\phi^{-1}(\\{a\\})")#text(" of a point ")#mi("a \\in {\\Bbb F}_q")#text(" is that of translation by ")#mi("a")#text(".")

#text("Yes, the lisse sheaves considered here can be thought of as having a “flat connection”, although for some reason the term “locally constant sheaf” is used in the literature instead. (Maybe because “flat” has another, unrelated meaning in algebra?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239559")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2013")])]

#text("It can be useful to think of a variety ")#mi("X")#text(" over a non-algebraically closed field k as a ")#emph[#text("family")]#text(" of manifolds ")#mi("X \\to B")#text(", in fact a fibration, where the fibers ")#mi("X_b")#text(" all look like ")#mi("X(C)")#text(" and the base ")#mi("B")#text(" has fundamental group ")#mi("\\text{Gal}(\\bar{k}/k)")#text(". In this situation, you get an action (or at least an outer action, since like Terry I’m going to ignore base point issues) of ")#mi("\\pi_1(B)")#text(" on ")#mi("\\pi_1(X(C))")#text(", which is a good way to think about the action of ")#mi("\\text{Gal}(\\bar{k}/k)")#text(" on the (etale) fundamental group of ")#mi("X/\\bar{k}")#text(". What’s more, any section from ")#mi("B")#text(" back to ")#mi("X")#text(" induces a section of the natural map ")#mi("\\pi_1(X) \\to \\pi_1(B)")#text("; in just the same way, when ")#mi("X/k")#text(" is a variety over ")#mi("k")#text(", points ")#mi("X(k)")#text(" (which are just sections of the map ")#mi("X \\to \\text{Spec} k")#text(") give you sections of the natural map ")#mi("\\pi_1(X) \\to \\text{Gal}(\\bar{k}/k)")#text(", and Grothendieck’s section conjecture is that for certain classes of “anabelian” varieties (including smooth proper curves) every such section actually arises from a point of ")#mi("X(k)")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dab262b249e6b008de2defe2a9d55f776181f2faf2f8a2ae168348cdfb2adaf-097fe507317aee85ccf32427e06a89aeacc09d75464afe95cd265a14b70a7a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239475")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2013")])]

#text("Depending on your familiarity with the theory of orbifolds, thinking of algebraic curves over ")#mi("\\mathbb F_p")#text(" as orbifolds might be a good idea. Each point behaves like a cone point, and the Frobenius element at that point is a small loop around that point. You are computing the trace of this element of the fundamental group, which clearly does depend on the point.")

#text("Finite etale covers and lisse sheaves behave almost exactly like branched covers and vector bundles with flat connection, so these mnemonics are not so crude and pedestrian – I believe they were used quite a bit by the brilliant mathematicians creating the theory! While one needs very different steps to define these things, they are very analogous.")

#text("The connections between the monodromy of differential equations over ")#mi("\\mathbb C")#text(" and lisse sheaves over finite fields is very deep, and there are even direct analogies between specific equations and sheaves. For instance, the Kloosterman sums are strongly related to hypergeometric differential equations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239484")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2013")])]

#text("(I am replaying to “myself” for neatness in this thread.)")

#text("@TerryTao I had heard the “most interesting mathematical object” was $SL(2,\\mathbb{Z})$. Personally, I would call the “twice-punctured plane” a 3-punctured sphere, $\\mathbb{P}^1 \\backslash {0, 1, \\infty}$. In fact, the mapping class group of the pair of pants is just $SL(2,\\mathbb{Z})$. (Did I say that right?)")

#text("The study of the Absolute Galois Group $Gal(\\overline{\\mathbb{Q}}/\\mathbb{Q})$ can be encoded with Dessins d’Enfants – of which I’ve only heard interesting things. These are two of the 3 objects in the exact sequence on page thirty.")

#tao-fit-display[#mitex("1 \\to \\pi_1(X_{\\mathbb{Q}^{al}, \\overline{x}) \\to \\pi_1(X,x) \\to Gal(\\overline{\\mathbb{Q}}/\\mathbb{Q}) \\to 1")]

#text("Quite awesomely, Deligne’s discussion of $\\pi_1(pants)$ is online. ")#link("http://quomodocumque.wordpress.com/2009/07/24/le-groupe-fondamental-de-la-droite-projective-moins-trois-points-is-now-online/")[#text("http://quomodocumque.wordpress.com/2009/07/24/le-groupe-fondamental-de-la-droite-projective-moins-trois-points-is-now-online/")]

#text("I have always found the analytic # theory estimates difficult to follow. At least, Deligne’s discussion offers a logic to these zeta functions from geometry.")

#text("And I will think about the orbifold intuition mentioned in this thread.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/697302509e786a35779ac56a1541bb598c8630617180c591298ddd3c6a7c8e73-4729ffd504aa49ad5740403c8144dcce62b54029f452a58377d3d33ba02a077b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zack")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239494")[#strong[#text("Zack")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2013")])]

#text("I saw some where that the roots have the form i(PI)/lnp and p is a prime !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239532")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2013")])]

#text("First of all, thank you for sharing this exposition!")

#text("One last question about “almost orthogonal” irreducible sheaves.")

#mi("\\sum_{x \\in U(\\mathbb{F})}  K_{\\mathcal{F}}(x)  \\overline{K_{\\mathcal{F^{\\prime}}}(x) } = c q \\; \\delta(\\mathcal{F} = \\mathcal{F}^{\\prime}) + o(q^{1/2})")

#text("Can you surmise what the normalization should be on the left hand side? I would wish to divide both sides by ")#mi("q")#text(" and say these characters are becoming more orthogonal as ")#mi("q \\to \\infty")#text(". Or maybe your picture of spreading points along a high-dimensional unit sphere, maximizing the angle between them, is more appropriate.")

#text("Could a sum over sheaves ")#mi("\\sum_{\\mathcal{F} \\text{ over } U(\\mathbb{F})}  K_{\\mathcal{F}}(x)  \\overline{K_{\\mathcal{F}}(y) } \\approx \\delta(x=y)")#text(" in any sense ?")

#text("Speculatively, this looks like the orthogonality of characters formula from Conformal Field Theory, where they study characters of the Virasoro algebra. I can say little more than that the two equations physically resemble each other, involve representations and use the letter ”q”. I will not qualify this further.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239555")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2013")])]

#text("The number of points in ")#mi("U({\\mathbb F})")#text(" is equal to ")#mi("q + O(q^{1/2})")#text(", so one can need normalise and view the correlation estimate as an assertion of almost orthogonality of (almost) unit vectors in ")#mi("L^2( U({\\mathbb F}) )")#text(" with the normalised uniform measure.")

#text("As for orthogonality in the sheaf direction, at one level this is trivial because of the ability to twist sheaves by tensoring with Artin-Schrier sheaves, which in effect multiplies the trace function ")#mi("K(x)")#text(" with an additive character without increasing the complexity of the sheaf, and so one can get orthogonality purely from the orthogonality of the additive characters. But note that unlike the situation with the Fourier basis, there are many more sheaves and trace functions than there are points. A simple model case is when restricting to quadratic phase functions ")#mi("x \\mapsto e_p( ax^2+bx)")#text(" on the affine line ")#mi("{\\mathbb F}_p")#text(" with coefficients ")#mi("a,b \\in {\\mathbb F}")#text("; these come from particularly simple sheaves (pullbacks of Artin-Schreier sheaves with respect to quadratic polynomials) and the orthogonality properties can be verified directly from elementary Gauss sum estimates rather than from any fancy l-adic cohomology. Note that in this case there are ")#mi("p^2")#text(" almost orthogonal functions (or unit vectors, if you will) in a ")#mi("p")#text("-dimensional space. One certainly has ")#mi("\\sum_{a,b\\in {\\mathbb F}_p} e_p(ax^2+bx) \\overline{e_p(ay^2+by)} = p^2 \\delta_{x=y}")#text("; indeed one only needs to average in the ")#mi("b")#text(" variable alone to get this sort of orthogonality.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An improved Type I estimate | What's new")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239915")[#strong[#text("An improved Type I estimate | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2013")])]

#text("[…] -adic sheaf on that is pure of weight and geometrically irreducible with conductor at most (see this previous post for definitions of these terms), then this is a class of structured functions (the almost […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/425e9af440224f70b2fdf2ee6db0b25fa530d49b4abcefba86b2ac9a5c18ff6b-47fc0714a2a9f66e1a077dce6ad71eceabeab9c306a959e880a9194e3340d86f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kamran Alam Khan")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-239929")[#strong[#text("Kamran Alam Khan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2013")])]

#text("Reblogged this on ")#link("http://kamranrmp.wordpress.com/2013/07/28/the-riemann-hypothesis-in-various-settings/")[#text("Observer")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cb3280d4a3ac59b59c4cf2c33043f35c9d5c9f277083c51cc4b2e3163aa25a7-6a9cd9f58b7183b2038ce7a394dc5461cc80a5a1b8a2711b65195916592b725c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo de Almeida")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-242222")[#strong[#text("Marcelo de Almeida")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2013")])]

#text("Reblogged this on ")#link("http://nucaltiado.wordpress.com/2013/08/17/the-riemann-hypothesis-in-various-settings/")[#text("Being simple")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c81d853835c2d20452b7e77f864c83020fa5f9033167a2048c01893bb23aee8b-d2f5573efb90213ee9a3f67c819fdc7d1a5dc951d3d48ba80ef68593efa97fe4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AL")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-243836")[#strong[#text("AL")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2013")])]

#text("I would be very interested in feedback on the paper in arXiv number theory")#linebreak()#text(" ")#link("http://arxiv.org/abs/1307.8395")[#text("http://arxiv.org/abs/1307.8395")]#text(" An equation is derived that is satisfied by the n-th zero that only depends on n, and I think it goes a long way towards proving RH, since it is derived on the critical line and agrees with counting formulas on the entire critical strip. I understand everyone is busy, but being mere physicists, we are eager to get feedback from some pure mathematicians. Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e311ec8f6550326173077572d5fad1a89ef7f27f0e5dd8ac5e80ae045715d6b-b04ef084646be9d92d8dc1adffda030043bf1866e98197f62aefdd0c339ff513.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of daniel james")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-248398")[#strong[#text("daniel james")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2013")])]

#text("in practice, i think (non mathematical term) that every decimal ends in zero, whereas in theory it does not. in this case the final zero is a function of it’s field. it is subject to; not governing. one disproves the other.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-245820")[#strong[#text("Polymath 8 – a Success! | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2013")]

#text("[…] this is something I would be happy to know a little more about. There is a nice recent post on the Riemann hypothesis in various settings on “What’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e311ec8f6550326173077572d5fad1a89ef7f27f0e5dd8ac5e80ae045715d6b-b04ef084646be9d92d8dc1adffda030043bf1866e98197f62aefdd0c339ff513.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of daniel james")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-248221")[#strong[#text("daniel james")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2013")])]

#text("similar but simpler hypothesis-")#linebreak()#text(" can any one help me to prove or disprove?")

#text("hypothesis;")#linebreak()#text(" the series’- (1+1=2, 2+1=3, 3+2=5, 5+3=8….)")#linebreak()#text(" (1+1=2, 2+2=4, 4+4=8, 8+8=16…)")#linebreak()#text(" (2051, 2051+2051=4102, 4102+2051=6153…)")#linebreak()#text(" …when written concurrently are a tangent to an asymptote.")#linebreak()#text(" i.e. there are no factors common to all three series’.")

#text("i am working on the principle that according to certain fields, there is no such thing as a straight line.")#linebreak()#text(" for increment (field), treat 2051, (7, 293, factors) 1, 2, 8,(300, sum of factors) as false zeros, working both in the + and the -. [a-(-b)=c].")

#text("i have derived the number 2051 from bible study.")#linebreak()#text(" the paradox of eternity.")

#text("as far as i can tell it is correct to 12 digits. then i ran out of fingers!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-253104")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("sorry i meant to say integers.. no common integers. 2051 is not prime.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e311ec8f6550326173077572d5fad1a89ef7f27f0e5dd8ac5e80ae045715d6b-b04ef084646be9d92d8dc1adffda030043bf1866e98197f62aefdd0c339ff513.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of daniel james")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-248397")[#strong[#text("daniel james")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2013")])]

#text("as above-")#linebreak()#text(" trajectory of partially common factors= ratio of predictable variance from non predictable field.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ba4bbbd5ec2022c4d2c416ce26986abcf57f3bc5cc91f39f46704b805cfdad1c-5f4be7c2dedbc0aff0e38d79a14c081334db35718af1b7f7008637fc1de17a29.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Riemann hypothesis in various settings | Edgar's Creative")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-252797")[#strong[#text("The Riemann hypothesis in various settings | Edgar's Creative")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2013")])]

#text("[…] The Riemann hypothesis in various settings. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a118ece2a03feb73969ee83182825517c071df0350d9605adea70fe0fdc62d1a-e7648cbec86f042e6d0732c7796b43915267bbd95e7c648077f3f2f151a4c177.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ocean Yu")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-263933")[#strong[#text("Ocean Yu")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2014")])]

#text("Thanks for Terry’s blog on RH! If allowed, I would like add comment here although which looks simple and naive.")

#text("If looking back to Riemman’s original paper “On the Number of Primes Less Than a Given Magnitude”, we can see one prime formula,")

#text("(1) ")#mi("f(x)=\\mathrm{Li}(x)-\\sum_{\\rho}(\\mathrm{Li}(x^\\rho)) - log(2) +\\int_x^{\\infty} \\frac{1}{t(t^2-1)log(t)}dt")

#mi("f(x)")#text(" is counting primes and prime power ")#mi("p^n")#text(", prime power is counting as ")#mi("\\frac{1}{n}")#text(".")

#text("Nowadays, above function is replaced by von Mangoldt function just for sake of convenience of research, which can be found at beginning of this blog.")

#text("For ")#mi("\\Pi(x)")#text(" ( # of primes less than x), it is well know that the RH equivalent form is,")

#mi("\\Pi(x) = \\mathrm{Li}(x)+O(x^\\frac{1}{2}\\log x")

#text("It should not be difficult to get RH equivalent form for above Riemann’s prime formula ")#mi("f(x)")#text(", which however, can not been found in official book. Is it something like,")

#text("(2) ")#mi("f(x)=\\mathrm{Li}(x)+O(???)")

#text("I leave it here as I believe someone can figure it out easily, I can’t BTW.")

#text("The reason why I comment here, is that seems that Riemann prime formula ")#mi("f(x)")#text(" was almost swiped out of RH’s researching, as replaced by von Mangoldt function. However, we can see ")#mi("f(x)")#text(" has direct relationship with zeta function’s non-trivial zeros, as showed in (1).")

#text("Let’s take the easiest L-functions,")

#mi("\\zeta_q=\\sum _{n =1}^{\\infty}\\frac{1}{n^{s}}, (q,n)=1")

#mi("(q,n)=1")#text(" means that no common prime factor between ")#mi("q")#text(" and ")#mi("n")#text(".")

#text("Accordingly, defines following prime formula,")

#mi("f_q(x)")

#text("which counts primes and prime power, counts prime power ")#mi("p^n")#text(" as ")#mi("\\frac{1}{n}")#text(", ")#mi("(q,n)=1")

#text("We may get following facts,")

#text("(a) ")#mi("\\zeta_q(s)")#text(" and ")#mi("\\zeta(s)")#text(" has identical non-trivial zeros in area of ")#mi("0<\\Re(s)")

#text("(b) ")#mi("f_q(x)")#text(" is expecting to contain ")#mi("\\mathrm{Li}(x)-\\sum_{\\rho}(\\mathrm{Li}(x^\\rho))")#text(", which is similar as,")

#text("(3) ")#mi("f_q(x)=\\mathrm{Li}(x)-\\sum_{\\rho}(\\mathrm{Li}(x^\\rho))+R(x,q)")

#mi("R(x,q)")#text(" is the function relating with x,q only.")

#text("(c) If q=2*3*5*7*11*… goes large enough, and ")#mi("x")#text(" is sufficient large, we should get following boundary, by connecting with (3),")

#text("(4) ")#mi("0<f_q(x)=\\mathrm{Li}(x)-\\sum_{\\rho}(\\mathrm{Li}(x^\\rho)) + Q(x,q)\\le {1}")

#text("It is interesting here that seems we dig a hole to enable us to see the secret of non-trivial zeros with function ")#mi("Q(x,q)")#text(" only.")

#text("So if one figures out (2) and details of ")#mi("Q(x,q)")#text(", couldn't we answer Hilbert's question after his 100 years' sleeping? On the other word, can we get close to proving RH?")

#text("Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a118ece2a03feb73969ee83182825517c071df0350d9605adea70fe0fdc62d1a-e7648cbec86f042e6d0732c7796b43915267bbd95e7c648077f3f2f151a4c177.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ocean Yu")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-264329")[#strong[#text("Ocean Yu")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("Again, thanks for Terry’s correction on typo!")

#text("I’ll bet that no one will comment on my very junior comments. Either RH should not be so simple to get closer, or idea in my comments had been already covered in discussion on L-function. I am still expect one tiny comment no matter positive(couldn’t be) or negative.")

#text("Seems to me (a) is obvious, (2) is easy, (3) is not like what I am assuming, whereas, in (4), ")#mi("Q(x,q)")#text(" is a wild horse which is too hard to be trained.")

#text("It is not a math researcher’s comment but a math fan. I will shut up and learn in door if it is annoying.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/065138e1b1902805d7f744a8b774918e0ccbb72d8c610f9cb5f0d04cde9795e3-c304526fcf69ae299ab157ae31b1f0cc68fc0ab5c24aaa809399deb8b52fce69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mats Granvik")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-268146")[#strong[#text("Mats Granvik")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2014")])]

#mi("\\Lambda(n)=\\lim\\limits_{s \\rightarrow 1} \\zeta(s)\\sum\\limits_{d|n} \\frac{\\mu(d)}{d^{(s-1)}}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of “New equidistribution estimates of Zhang type, and bounded gaps between primes” – and a retrospective | What's new")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-270284")[#strong[#text("“New equidistribution estimates of Zhang type, and bounded gaps between primes” – and a retrospective | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")])]

#text("[…] To go beyond this, we had to unpack Zhang’s proof of (a weakened version of) the Elliott-Halberstam type bound (3). His approach follows a well known sequence of papers by Bombieri, Friedlander, and Iwaniec on various restricted breakthroughs beyond the Bombieri-Vinogradov barrier, although with the key difference that Zhang did not use automorphic form techniques, which (at our current level of understanding) are almost entirely restricted to the regime where the residue class is fixed in (as opposed to varying amongst the roots of a polynomial modulo , which is what is needed for the current application). However, the remaining steps are familiar: first one uses the Heath-Brown identity to decompose (a variant of) the expression in (3) into some simpler bilinear and trilinear sums, which Zhang called “Type I”, “Type II”, and “Type III” (though one should caution that these are slightly different from the “Type I” and “Type II” sums arising from Vaughan-type identities). The Type I and Type II sums turn out to be treatable using a careful combination of the Cauchy-Schwarz inequality (as embodied in tools such as the dispersion method of Linnik), the Polya-Vinogradov completion of sums method, and estimates on one-dimensional exponential sums (which are variants of Kloosterman sums) which can ultimately be handled by the Riemann hypothesis for curves over finite fields, first established by Weil (and which can in this particular context also be proven by the elementary method of Stepanov). The Type III sums can be treated by a variant of these methods, except that one-dimensional exponential sum estimates are insufficient; Zhang instead needed to turn to the three-dimensional exponential sum estimates of Birch and Bombieri to get an adequate amount of cancellation, and these estimates ultimately arose from the deep work of Deligne on the Riemann hypothesis for higher dimensional varieties (see this previous blog post for a discussion of these hypotheses). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-273277")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2014")])]

#link("https://www.researchgate.net/publication/259646051_Riemann_Hypothesis_Proof")[#text("https://www.researchgate.net/publication/259646051_Riemann_Hypothesis_Proof")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d86ba3346a1138ac26344c6992ba22cd5b12f77df5eaee8a5e3fb71032e93922-3a24731f3aa9e51fbf5a27b55748b64aa5027de977e6ddd28bb2dac2a8470f77.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew001")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-275353")[#strong[#text("Andrew001")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2014")])]

#text("Well, I saw a book review ( book concerning the Riemann’s hypothesis) at:")

#link("https://www.kirkusreviews.com/book-reviews/jan-feliksiak/the-symphony-of-primes-distribution-of-primes-and-/")[#text("https://www.kirkusreviews.com/book-reviews/jan-feliksiak/the-symphony-of-primes-distribution-of-primes-and-/")]

#text("Quite impressive. Andrew001")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f29ebe36773965e05b33e8e5a9e05fbe501062c84d7463a6a57299fd60693f2-e505c68b844c0025743008f66b526292f74832dfb0ae41e5dcaa700c275a12e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tcne")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-315577")[#strong[#text("tcne")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2014")])]

#text("Proof of Riemann Hypothesis:")

#link("http://www.cqr.info:2013/MolyGrails/riemann-proof")[#text("http://www.cqr.info:2013/MolyGrails/riemann-proof")]

#text("Note: The orange upper arrow/triangle at the bottom of the screen will take the reader to the menu, where informal notes on the proof are available.")

#text("It is mentioned (in the informal note) about ‘principal value’ and inner")#linebreak()#text(" product, but I would like to re-emphasize:")

#text("If Zeta is re-interpreted to be represented only in vector form, with only")#linebreak()#text(" Hadamard product, then the notion of ‘principal value’ will not be needed.")#linebreak()#text(" As a result, g and g’ can be eliminated, observing that if the representing")#linebreak()#text(" vectors of the roots equal, the summations of the terms of the vectors or their")#linebreak()#text(" inner products with the identity vector equal as well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/030a79fcd292a66f008ccc34c90446ea640c51d84bba4470ba0cbd0be302d37e-e54e9601b46d2175cab6cd0439f0a5bb6bf45c7ccf6adec313887845c573c50f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bootheven")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-428781")[#strong[#text("bootheven")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2014")])]

#text("This would be miraculous if the link worked.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f29ebe36773965e05b33e8e5a9e05fbe501062c84d7463a6a57299fd60693f2-e505c68b844c0025743008f66b526292f74832dfb0ae41e5dcaa700c275a12e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tcne")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-320975")[#strong[#text("tcne")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2014")])]

#text("Summary of the Proof.")

#text("RH: all nontrivial roots are on real critical line x = 1/2.")

#text("Since we know all nontrivial roots are symmetric about the real line x = 1/2, the nontrivial roots are of the form ")#mi("(1/2 \\pm \\delta) \\pm it")#text(". Therefore, RH is nothing but ")#mi("(1/2 \\pm \\delta) \\pm it = 1/2 \\pm it")#text(", which is equivalent to the statement: ")#mi("\\delta = 0")#text(".")

#text("RH, in this interpretation, is to prove ")#mi("(1/2 + \\delta) \\pm it = (1/2 - \\delta) \\pm it")#text(". It is no more fancier than that.")

#text("We know that both ")#mi("(1/2 + \\delta) \\pm it")#text(" and ")#mi("(1/2 - \\delta) \\pm it")#text(" are roots of ")#mi("\\zeta")#text(", so ")#mi("\\zeta((1/2 + \\delta) \\pm it) = \\zeta((1/2 - \\delta) \\pm it) = 0")#text(".")

#text("If we can show ")#mi("\\zeta((1/2 + \\delta) \\pm it) = \\zeta((1/2 - \\delta) \\pm it)")#text(" implies ")#mi("(1/2 + \\delta) \\pm it = (1/2 - \\delta) \\pm it")#text(", we will have RH settled.")

#text("To show the above, we only need to demonstrate that the equality in the range of ")#mi("\\zeta")#text(" is preserved to its domain which is nothing but (C, +), the group of complex addition.")

#text("We observe that equality preservation happens in group isomorphism. Therefore, our proof boils down to showing the isomorphism.")

#text("The follow-up post is the full proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f29ebe36773965e05b33e8e5a9e05fbe501062c84d7463a6a57299fd60693f2-e505c68b844c0025743008f66b526292f74832dfb0ae41e5dcaa700c275a12e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tcne")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-320977")[#strong[#text("tcne")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2014")])]

#text("A Group Theoretic Approach to the Riemann Hypothesis")

#text("1. Introduction")

#text("In his 1859 paper Uber die Anzahl der Primzahlen unter einer gegebenen Grosse, Bernhard Riemann put forth a conjecture concerning ")#mi("\\zeta(c)=\\sum_{n=1}^\\infty{n^{-c}}")#text(" defined on the set ")#mi("\\mathbb{C}")#text(" of complex numbers, speculating that all nontrivial roots of ")#mi("\\zeta")#text(" fall on the (real) critical line of ")#mi("x=\\frac{1}{2}")#text(".")

#text("It is known that those roots are of the form ")#mi("(\\frac{1}{2}\\pm\\delta)\\pm it")#text(" for some real number ")#mi("0 \\leq \\delta < \\frac{1}{2}")#text(", but a proof for ")#mi("\\delta = 0")#text(" has been elusive.")

#text("2. Proof")

#text("We observe (")#mi("\\mathbb{C}, +")#text("), (")#mi("V \\backslash \\{\\mathbf{0}\\}, \\circ")#text(") and (")#mi("V \\backslash \\{\\mathbf{0}\\}, \\bullet")#text(") are (commutative) groups, where + is the normal complex number addition, and ")#mi("\\circ")#text(" and ")#mi("\\bullet")#text(" are respectively the term-wise (Hadamard) product and the inner product of infinite dimension vectors of the form ")#mi("V(c) = (v_{1}(c), v_{2}(c), v_{3}(c), ...)")#text(" where ")#mi("v_{n}(c) = n^{-c}")#text(" for complex variable ")#mi("c")#text(".")

#text("Let ")#mi("f: (\\mathbb{C}, +) \\longrightarrow (V\\backslash\\{\\mathbf{0}\\}, \\circ)")#text(" be defined as ")#mi("f(c) = V(c)")#text(", then ")#mi("f")#text(" is homomorphism (where ")#mi("\\times")#text(" is normal complex number multiplication):")

#mi("f(c_{_{1}}+c_{_{2}})")

#mi("= V(c_{_{1}}+c_{_{2}})")

#mi("= (v_{_{1}}(c_{_{1}}+c_{_{2}}), v_{_{2}}(c_{_{1}}+c_{_{2}}), v_{_{3}}(c_{_{1}}+c_{_{2}}), ...)")

#mi("= (1^{-(c_{_{1}}+c_{_{2}})}, 2^{-(c_{_{1}}+c_{_{2}})}, 3^{-(c_{_{1}}+c_{_{2}})}, ...)")

#mi("= (1^{-c_{_{1}}}\\times1^{-c_{_{2}}}, 2^{-c_{_{1}}}\\times2^{-c_{_{2}}}, 3^{-c_{_{1}}}\\times3^{-c_{_{2}}}, ...)")

#mi("= (v_{_{1}}(c_{_{1}})\\times v_{_{1}}(c_{_{2}}), v_{_{2}}(c_{_{1}})\\times v_{_{2}}(c_{_{2}}), v_{_{3}}(c_{_{1}})\\times v_{_{3}}(c_{_{2}}), ...)")

#mi("= V(c_{_{1}})\\circ V(c_{_{2}})")

#mi("= f(c_{_{1}})\\circ f(c_{_{2}})")

#text("Similarly, let ")#mi("g: (\\mathbb{C}, +) \\longrightarrow (V\\backslash\\{\\mathbf{0}\\}, \\bullet)")#text(" be defined as ")#mi("g(c) = g(c+0) = V(c+0)")#text(", then ")#mi("g")#text(" is homomorphism (just a mention and homomorphic property of ")#mi("g^{\\prime}")#text(" is not used in the proof):")

#mi("\\ \\ g(c_{_{1}}+c_{_{2}})")

#mi("= V(c_{_{1}}+c_{_{2}})")

#mi("= (v_{_{1}}(c_{_{1}}+c_{_{2}}) + v_{_{2}}(c_{_{1}}+c_{_{2}}) + v_{_{3}}(c_{_{1}}+c_{_{2}}) + ...)")

#mi("= (1^{-(c_{_{1}}+c_{_{2}})} + 2^{-(c_{_{1}}+c_{_{2}})} + 3^{-(c_{_{1}}+c_{_{2}})} + ...) = \\sum_{n=1}^{\\infty}\\frac{1}{n^{c_{_{1}}+c_{_{2}}}}")

#mi("= (1^{-c_{_{1}}}\\times1^{-c_{_{2}}} + 2^{-c_{_{1}}}\\times2^{-c_{_{2}}} + 3^{-c_{_{1}}}\\times3^{-c_{_{2}}} + ...)")

#mi("= (v_{_{1}}(c_{_{1}})\\times v_{_{1}}(c_{_{2}}) + v_{_{2}}(c_{_{1}})\\times v_{_{2}}(c_{_{2}}) + v_{_{3}}(c_{_{1}})\\times v_{_{3}}(c_{_{2}}) + ...)")

#mi("= V(c_{_{1}})\\bullet V(c_{_{2}})")

#mi("= g(c_{_{1}})\\bullet g(c_{_{2}})")

#text("and note:")

#mi("\\ \\ g(c+0) = V(c+0) = V(c) \\bullet V(0)")

#text("We observe that ")#mi("2{\\pi}i\\mathbb{Z}")#text(", for integer set ")#mi("\\mathbb{Z}")#text(", is kernel for ")#mi("f")#text(", therefore ")#mi("f^{\\prime}: (\\mathbb{C}/2{\\pi}i\\mathbb{Z}, +) \\longrightarrow (V\\backslash\\{\\mathbf{0}\\}, \\circ)")#text(" is isomorphism. Furthermore, since ")#mi("\\zeta")#text(" is on principal value, if we define ")#mi("g^{\\prime} : (\\mathbb{C}/2{\\pi}i\\mathbb{Z}, +) \\longrightarrow (V\\backslash\\{\\mathbf{0}\\}, \\bullet)")#text(", then ")#mi("g^{\\prime} = \\zeta")#text(".")

#text("Suppose ")#mi("c_{_{1}} = ((\\frac{1}{2} + \\delta) \\pm it)")#text(" and ")#mi("c_{_{2}} = ((\\frac{1}{2} - \\delta) \\pm it)")#text(" are two roots of ")#mi("\\zeta")#text(", then:")

#mi("\\zeta(c_{_{1}}) = 0 = \\zeta(c_{_{2}})")

#mi("\\Longrightarrow\\ g^{\\prime}(c_{_{1}}) = g^{\\prime}(c_{_{2}})")

#mi("\\Longrightarrow\\ g^{\\prime}((\\frac{1}{2} + \\delta) \\pm it)) = g^{\\prime}((\\frac{1}{2} - \\delta) \\pm it))")

#mi("\\Longrightarrow\\ g^{\\prime}((\\frac{1}{2} \\pm it) + \\delta) = g^{\\prime}((\\frac{1}{2} \\pm it) - \\delta)")

#mi("\\Longrightarrow\\ g^{\\prime}(\\frac{1}{2} \\pm it) \\bullet g^{\\prime}(\\delta)) = g^{\\prime}(\\frac{1}{2} \\pm it) \\bullet g^{\\prime}(-\\delta)")

#mi("\\Longrightarrow\\ g^{\\prime}(\\delta) = g^{\\prime}(-\\delta)")

#mi("\\Longrightarrow\\ V(\\delta) = V(-\\delta)")

#mi("\\Longrightarrow\\ f^{\\prime}(\\delta) = f^{\\prime}(-\\delta)")

#mi("\\Longrightarrow\\ \\delta = -\\delta")

#mi("\\Longrightarrow\\ \\delta = 0")

#text("(Q.E.D.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-321018")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2014")])]

#text("1. ")#mi("\\bullet")#text(" is not a group operation (in fact, it does not even map ")#mi("V \\backslash \\{0\\} \\times V \\backslash \\{0\\}")#text(" to ")#mi("V \\backslash \\{0\\}")#text(", instead mapping to the complex numbers ")#mi("{\\bf C}")#text("). In particular, it does not obey a cancellation law.")

#text("2. ")#mi("f")#text(" is not periodic with period ")#mi("2\\pi i{\\bf Z}")#text(". Each individual term ")#mi("s \\mapsto n^{-s}")#text(" is periodic with period ")#mi("\\frac{1}{\\log n} 2\\pi i")#text(", but there is no common period (the zeta function is not a periodic function).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f29ebe36773965e05b33e8e5a9e05fbe501062c84d7463a6a57299fd60693f2-e505c68b844c0025743008f66b526292f74832dfb0ae41e5dcaa700c275a12e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tcne")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-321313")[#strong[#text("tcne")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2014")])]

#text("Terry,")

#text("Thanks for the enlightenment.")

#text("My take is this. The world missed it by well over a century is not without a reason.")

#text("First, I think the mapping you mentioned (by ‘does not even map’) is the isomorphism of g’. That is exactly the issue, the reason why it appears so evasive.")

#text("I anticipated the ‘prejudice’ and explicitly advised to take the ‘vector’ view and NOT the ‘scalar’ view.")

#text("In essence, we do not (have to) rely on the isomorphism of g’, but on the isomorphism of f’ (that way we think in vectors not scalars).")

#text("You can go to the proof given here concerning RH again and see.")

#text("Let me elaborate.")

#text("1. The ‘group’ view, in light of your comment, may need just a little twist.")

#text("The group informally is: the complex numbers formed by the inner product of vectors (of the form specified for V) with the identity vector V(0). View it as a tuple: (V, s), i.e. the vector and its inner product with V(0). The ‘scalar’ value in the tuple is ‘side show’, since the vector always determines its value. Therefore in the tuple form, in Zeta operation, any two such tuples will form a new one by taking the Hadamard product of the vectors for the first entry (V), then the inner product of this new vector with V(0) as the ‘scalar’ complex value for the second entry (s).")

#text("Taking the tuple form, it is a group (closed, associative, inversible, and with identity (V(0) = (1, 1, 1, …), -1/2).")

#text("Furthermore, the tuple form is isomorphic to the vector form, since the ‘scalar’ entry in the tuple form is totally determined by the vector entry.")

#text("Therefore, if we forget about the ‘scalar’ part, we lose nothing.")

#text("2. If we are obsessed with g’ being isomorphic or not, it can be a ‘BIG’ thing! But we do not need it. (We can not even get RH settled, it is better that we introduce no more complications :))")

#text("In the proof, the version posted here earlier, we only used the group property of the range of g’, not the isomorphism property of it (the isomorphism of f’ IS however needed).")

#text("Let me further elaborate.")

#text("First, we use ‘it’ for the imaginary part. it is the same ‘it’ for two roots. Actually, it is obvious that only delta is the somehow ‘possible’ different quantity in the pair of ‘complementary’ roots. We are NOT doing anything with it[1] for one root and it[2] for another (with it[1] != it[2]).")

#text("Consequently, the range of g’ being a group, the cancellation property does apply. (By the way if we used it[1] and it[2], we would not be able to cancel! Even if the ‘scalar’ part equal)")

#text("Note, we did not open the mapping function, i.e. going from f'(d) = f'(-d) to d = -d till this stage, when d is a real not a complex number.")

#text("g'(d) = g'(-d) goes to V(d) = V(-d) is by definition.")

#text("Again, V(d) = V(-d) to f'(d) = f'(-d) is also by definition.")

#text("When we open up (i.e. going from f'(d) = f'(-d) to d = -d) is due to f’ being isomorphic. Note here, we did not (have to) say that g’ is isomorphism. We do NOT depend on that!")

#text("By the way, to be clear (I do not think it can be an issue with you), {0} is whatever multiplicative zero element is (but NOT the complex number zero). Since we do not touch this zero element in the proof, there is no need to elaborate or even be concerned.")

#text("Finally, I have been pretty sure of the validity of the proof (but could still be wrong in the end). Just that I was not sure what the reason for this over a century ‘openness’ is. It may be what I suspected all along.")

#text("If you have questions or anything I did not make clear, please feel free to let me know. (If you would like me to do LaTeX for this post, let me know. It is a bit of pain as I am not sure what your blog accepts, otherwise it is possible that I post things so garbled that nobody can read.)")

#text("Regards,")#linebreak()#text(" TCNE")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sylvain JULIEN")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-323243")[#strong[#text("Sylvain JULIEN")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2014")])]

#text("I would like to know whether the ideas considered in ")#link("http://polymathprojects.org/2014/01/20/two-polymath-of-a-sort-proposed-projects/#comments")[#text("http://polymathprojects.org/2014/01/20/two-polymath-of-a-sort-proposed-projects/#comments")]#text(" are worth developping or not. My guess is that universality for Zeta and maybe elements of the Selberg class if established (is it?) could be used to prove that the considered field automorphisms of C are continuous, but I’d like to get your opinion before getting into further painstaking investigations. Thank you in advance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dwork’s proof of rationality of the zeta function over finite fields | What's new")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-338595")[#strong[#text("Dwork’s proof of rationality of the zeta function over finite fields | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2014")])]

#text("[…] Riemann hypothesis, all the zeroes and poles of the -form lie on the critical lines for . (See this previous blog post for further comparison of various instantiations of the Riemann hypothesis.) Whereas Dwork uses […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f02d14a52e1e5cde003288f81c1a2bd64a62cca13f8243d6ab75389e90408c50-9eaf2dbc6da0d2c289b45aa2587391a72519f8ed7a482fcecc6a605faf6d4241.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ZZZZ")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-357911")[#strong[#text("ZZZZ")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2014")])]

#text("Do you think it possible to add such conditions to such")

#mi("\\displaystyle  \\sum_{n=1}^\\infty \\frac{d(n)}{n^s} = {\\zeta(s)}^{2}")

#text("To obtain the following expression for example")

#mi("\\displaystyle  \\sum_{n^m \\leq x} \\frac{d(n)}{n}")

#text("for the function d(n) or equivalent with which we have a good estimate.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-358150")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2014")])]

#text("The classical approach to expressing partial sums of multiplicative functions in terms of the associated Dirichlet series is Perron’s formula: ")#link("http://en.wikipedia.org/wiki/Perron's_formula")[#text("http://en.wikipedia.org/wiki/Perron's_formula")]#text(" . Personally I prefer the Fourier-analytic approach (e.g. replacing the partial sum by a smoother cutoff and then expressing that cutoff as a Fourier integral) over the complex-analytic approach, but this is largely a matter of personal taste, as the two approaches are broadly equivalent.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f02d14a52e1e5cde003288f81c1a2bd64a62cca13f8243d6ab75389e90408c50-9eaf2dbc6da0d2c289b45aa2587391a72519f8ed7a482fcecc6a605faf6d4241.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ZZZZ")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-358253")[#strong[#text("ZZZZ")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2014")])]

#text("Thank you. In essence, whether the above Dirichlet series transformed into \\displaystyle -\\frac{\\zeta'(s)}{\\zeta(s)} maybe you have already tried then could not describe what difficulties you encounter")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f02d14a52e1e5cde003288f81c1a2bd64a62cca13f8243d6ab75389e90408c50-9eaf2dbc6da0d2c289b45aa2587391a72519f8ed7a482fcecc6a605faf6d4241.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ZZZZ")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-358913")[#strong[#text("ZZZZ")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2014")])]

#text("Thanks for everything. It seems we’ve got.I combine and found the following equation \\displaystyle \\frac{\\zeta(s)}{\\zeta'(s)} = \\sum_{n=1}^\\infty \\frac{2*d(n)}{n^s}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f02d14a52e1e5cde003288f81c1a2bd64a62cca13f8243d6ab75389e90408c50-9eaf2dbc6da0d2c289b45aa2587391a72519f8ed7a482fcecc6a605faf6d4241.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ZZZZ")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-360435")[#strong[#text("ZZZZ")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2014")])]

#text("Could you help me?. I found a way to solve the Riemann Hypothesis")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e10bae79df2f71c77411d8710ae95d12b9dc9504eab16360c714001e1404f4e-5d49dc961bed9f9b15953080a8055cf119f2e89bb1def96bc52507e8069f5de5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lesh a _ tt")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-374846")[#strong[#text("lesh a _ tt")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2014")])]

#text("Do you think if it’s true rationale for this expression?")#linebreak()#text(" ")#mi("\\displaystyle \\int^x_0{\\Lambda }(t)dt")

#text("If we take an infinite sequence like this:")#linebreak()#text(" ")#mi("\\displaystyle \\sum_{n\\le x}{\\Lambda \\left(n\\right)}\\approx \\int^x_0{1}-\\sum_p{\\int^x_0{n^{p-1}}}")#linebreak()#text(" ")#mi("\\displaystyle \\int^x_0{\\Lambda }\\left(t\\right)dt\\approx {\\mathfrak{M}}_{\\left[{\\rm 0,x}\\right]}\\left({\\rm n}\\right){\\rm 1-}\\sum_{{\\rm p}}{{\\mathfrak{M}}_{\\left[{\\rm 0,x}\\right]}\\left({\\rm n}\\right)}{{\\rm n}}^{{\\rm p-1}}")#linebreak()#text(" ")#mi("\\displaystyle \\swarrow")#linebreak()#text(" ")#mi("\\displaystyle {\\mathfrak{M}}_{\\left[{\\rm 0,x}\\right]}\\left({\\rm n}\\right)\\Lambda \\left(t\\right)\\approx \\dots")#linebreak()#text(" ")#mi("\\displaystyle \\dots")#linebreak()#text(" And the difference between the functions of a special type of indicator is constant.Let this difference will increase, then we will see that ")#mi("\\epsilon=0")#text(" for some finite sequence, and in this sense to reduce the difference. But then you face some problems, it follows that there can be an increase or decrease of the difference to some constant.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ceb1288c5c7d39318e34df83c9bc183a1635a02a81b5ad434e893340210c878-1efdc87d5a859620cb4267301a5d7a998fa466b422d12d2865f2b84c994b7fab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 0_Lesh_a")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-389827")[#strong[#text("0_Lesh_a")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2014")])]

#text("Take the form below and find its")#linebreak()#text(" ")#mi("\\displaystyle \\sum_{n\\le x}{\\Lambda (n)\\left(\\frac{x}{n}-\\left\\lfloor \\frac{x}{n}\\right\\rfloor +1\\right)}")

#mi("\\displaystyle \\sum_{n\\le x}{\\frac{\\Lambda (n)}{n}}-\\frac{1}{2}\\frac{\\Lambda (x)}{x}={\\log  x\\ }-\\sum_p{\\frac{x^{p-1}}{p-1}}-\\frac{x{\\log  \\left(x+1\\right)\\ }-x{\\log  \\left(x-1\\right)\\ }-2}{2x}-\\gamma  \\sum^{\\infty }_{n=1}{\\frac{\\Lambda (n)}{n^{s+1}}}")#linebreak()#text(" ")#mi("\\displaystyle -\\frac{\\zeta ^{\\prime}(1)}{\\zeta (1)}")#linebreak()#text(" ")#mi("\\displaystyle \\sum_{n\\le x}{\\Lambda (n)\\left\\lfloor \\frac{x}{n}\\right\\rfloor }=\\sum_{n\\le x}{{\\log  n\\ }}")#linebreak()#text(" ")#mi("\\displaystyle \\sum_{n\\le x}{\\Lambda (n)\\left(\\frac{x}{n}-\\left\\lfloor \\frac{x}{n}\\right\\rfloor +1\\right)}=x{\\log  x\\ }-\\sum_p{\\frac{x^p}{p-1}}-\\frac{x{\\log  \\left(x+1\\right)\\ }-x{\\log  \\left(x-1\\right)\\ }-2}{2}-\\gamma x-\\sum_{n\\le x}{{\\log  n\\ }}+x-\\sum_p{\\frac{x^p}{p}}-\\frac{1}{2}{\\log  \\left(1-\\frac{1}{x^2}\\right)\\ }-{\\log  2\\pi \\ }+\\Lambda (x)")#linebreak()#text(" ")#mi("\\displaystyle -\\sum_p{\\frac{x^p}{p-1}}=\\sum_p{\\frac{x^p}{p}}")#linebreak()#text(" If")#linebreak()#text(" ")#mi("p=\\frac{1}{2}+i\\beta")#linebreak()#text(" But counting for n = 2,3,4,5 … gives a refutation")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ceb1288c5c7d39318e34df83c9bc183a1635a02a81b5ad434e893340210c878-1efdc87d5a859620cb4267301a5d7a998fa466b422d12d2865f2b84c994b7fab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 0_Lesh_a")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-390274")[#strong[#text("0_Lesh_a")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2014")])]

#text("Prof. Terence Tao")#linebreak()#text(" What do you yhink?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ceb1288c5c7d39318e34df83c9bc183a1635a02a81b5ad434e893340210c878-1efdc87d5a859620cb4267301a5d7a998fa466b422d12d2865f2b84c994b7fab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 0_Lesh_a")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-390384")[#strong[#text("0_Lesh_a")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2014")])]

#text("Acting as page 50-54 The book H.M.Edwards “Riemann’s Zeta function” 1974.")#linebreak()#text(" ")#mi("\\displaystyle -\\frac{\\zeta ^{\\prime}(s+1)}{\\zeta (s+1)}and\\ -\\frac{\\zeta ^{\\prime}\\left(1\\right)}{\\zeta \\left(1\\right)}\\$ addition")#text("latex x>0,c>0$")#linebreak()#text(" ")#mi("\\displaystyle frac{1}{2\\pi i}\\int^{c+i\\infty }_{c-i\\infty }{\\frac{x^s}{s^2}}={\\log  x\\ }")#linebreak()#text(" Choose ")#mi("R>c")#text(", and ")#mi("C:C(0,R)")#text(" for the circle centre 0, radius R.")#linebreak()#text(" ")#mi("\\displaystyle I\\left(C_1\\cup \\ L_r\\right):=\\frac{1}{2\\pi i}\\int_{C_1\\cup \\ L_r}{x^sds/s^2}")#linebreak()#text(" Write ")#mi("\\lambda ={\\log  x\\ }")#text(". Then ")#mi("\\frac{x^s}{s^2}=\\frac{e^{\\lambda s}}{s^2}=\\frac{1}{s^2}(1+\\lambda s+\\frac{1}{2}{\\lambda }^2s^2+\\dots )")

#text("This function of s is holomorphic inside the contour ")#mi("L_R\\cup \\ C_1")#text(", expect for a double pole at s=0, of residue ")#mi("\\lambda")#text(". As ")#tao-math("\\left|x^s\\right|=x^{\\sigma }", block: false)#text(", and x>1, on ")#mi("C_1")#text(" we have ")#tao-math("\\left|x^s\\right|\\le x^c", block: false)#text(", so ")#tao-math("\\left|\\frac{x^s}{s^2}\\right|\\le \\frac{x^c}{R^2}", block: false)#linebreak()#text(" ")#tao-math("\\displaystyle \\left|I\\left(C_1\\right)\\right|:=\\left|\\frac{1}{2\\pi i}\\int_{C_1}{\\frac{x^s}{s^2}}\\right|\\le \\frac{1}{2\\pi }\\frac{x^c}{R^2}2\\pi R=\\frac{x^c}{R}\\to 0", block: false)#linebreak()#text(" ")#mi("(R\\to \\infty )")#linebreak()#text(" By Cauchy’s Residue Theorem,")

#mi("\\displaystyle I\\left(C_1\\cup L_R\\right)=\\lambda, so I\\left(L_R\\right)\\to \\lambda ={\\log  x\\ }")#text(" as ")#mi("R\\to \\infty")#text(". This is the statement for ")#mi("x\\ge 1")

#text("And in this book on page 91-95 given the value of ")#mi("\\displaystyle -\\frac{\\zeta ^{\\prime}\\left(1\\right)}{\\zeta \\left(1\\right)}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ceb1288c5c7d39318e34df83c9bc183a1635a02a81b5ad434e893340210c878-1efdc87d5a859620cb4267301a5d7a998fa466b422d12d2865f2b84c994b7fab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 0_Lesh_a")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-390444")[#strong[#text("0_Lesh_a")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2014")])]

#text("Sorry that so many messages.")

#text("After the numerical experiment, the question remains, can be so large for some zeros x to infinity will be equal to 1/2. That is, whether there is an infinite sequence of zeros other. Irrationality of pi says that there is an infinite number of other zeros. Pity about that Euler constant gamma nothing")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ceb1288c5c7d39318e34df83c9bc183a1635a02a81b5ad434e893340210c878-1efdc87d5a859620cb4267301a5d7a998fa466b422d12d2865f2b84c994b7fab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 0_Lesh_a")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-390456")[#strong[#text("0_Lesh_a")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2014")])]

#text("Sorry I’m wrong to be proof.The irrationality of pi does not play here as it seems to me, but however there is no evidence")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd07dcea576c58f5ba8e26f5f8e1708a83f3310d14f777048c780246eaf4e033-60a38ffe34f6cd85111cf5c8281639cee7688a72a1427b77a339480f4513d484.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-390754")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2014")])]

#text("Claim that there are no zeros of the zeta function in a straight lina. Serious mistake because there are series for it.")

#text("Example:")

#text("1/2 = 1/3 + 1/9 + 1/24 + 1/81 + 1/648")

#text("1/2 = 1/3 + 1/9 + 1/24 + 1/81 + ……. + ……")

#text("see in: Universal Journal of Applied Mathematics Vol 1 (2): 2013")

#text("Title: convergents series for Riemann Hypothesis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ceb1288c5c7d39318e34df83c9bc183a1635a02a81b5ad434e893340210c878-1efdc87d5a859620cb4267301a5d7a998fa466b422d12d2865f2b84c994b7fab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 0_Lesh_a")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-391117")[#strong[#text("0_Lesh_a")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2014")])]

#text("In this book on page 94 there is a wonderful definition of the Euler constant. I hope with the help of this expression, we can prove the infinity of other roots.")#mi("\\displaystyle 1+{\\mathop{\\lim }_{s\\to 1} \\int^{\\infty }_1{t^{-1-s}\\left[\\psi \\left(t\\right)-t\\right]}\\ }dt")#linebreak()#text(" Where ")#mi("\\psi \\left(x\\right)")#text(" Chebyshev function")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ceb1288c5c7d39318e34df83c9bc183a1635a02a81b5ad434e893340210c878-1efdc87d5a859620cb4267301a5d7a998fa466b422d12d2865f2b84c994b7fab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 0_Lesh_a")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-391265")[#strong[#text("0_Lesh_a")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2014")])]

#text("Professor Terence Tao. Could you comment?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-407035")[#strong[#text("The Riemann hypothesis for graphs | in theory")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2014")]

#text("[…] refer the interested reader to this awesome post by Terry Tao, which gives a whirlwind tour of zeta functions and Riemann hypotheses all over mathematics, and we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-417511")[#strong[#text("Riemann zeta functions and linear operators | in theory")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2014")]

#text("[…] the time they spent answering questions. Part of this post will follow, almost word for word, this post of Terry Tao. All the errors and misconceptions below, however, are my own original […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d7a6d30b01d0123e5f27fdd462843a6eacb7c7a2d83a7ae007f9326eb69c147-f837a7b8173954e5ab8275fddd4d336632afad56162f6cfd38c947f5dc7b8094.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ocean Yu")]], [#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/comment-page-1/#comment-432371")[#strong[#text("Ocean Yu")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2014")])]

#text("Is it interesting that we reform RH like this way?")#linebreak()#text(" suppose $1/2+Ki$ is any one of non-trivial zero of $\\zeta$, RH is,")

#text("all K is transcendental number")
]
