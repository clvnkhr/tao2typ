// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/
// Converted to Typst by tao2typ: "2026-10-14T15:16:29.076328+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The crossing number inequality", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The crossing number inequality")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 September 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/")[#text("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("Today I’d like to discuss a beautiful inequality in graph theory, namely the ")#link("http://en.wikipedia.org/wiki/Crossing_number")[#text("crossing number inequality")]#text(". This inequality gives a useful bound on how far a given graph is from being planar, and has a number of applications, for instance to sum-product estimates. Its proof is also an excellent example of the ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("amplification trick")]#text(" in action; here the main source of amplification is the freedom to pass to subobjects, which is a freedom which I didn’t touch upon in the previous post on amplification. The crossing number inequality (and its proof) is well known among graph theorists but perhaps not among the wider mathematical community, so I thought I would publicise it here.")

#text("In this post, when I talk about a ")#link("http://en.wikipedia.org/wiki/Graph_%28mathematics%29")[#text("graph")]#text(", I mean an abstract collection of vertices V, together with some abstract edges E joining pairs of vertices together. We will assume that the graph is ")#emph[#text("undirected")]#text(" (the edges do not have a preferred orientation), ")#emph[#text("loop-free")]#text(" (an edge cannot begin and start at the same vertex), and ")#emph[#text("multiplicity-free")]#text(" (any pair of vertices is joined by at most one edge). More formally, we can model all this by viewing E as a subset of ")#tao-math("\\binom{V}{2} := \\{ e \\subset V: \\left|e\\right|=2 \\}", block: false)#text(", the set of 2-element subsets of V, and we view the graph G as an ordered pair G = (V,E). (The notation is set up so that ")#tao-math("\\left|\\binom{V}{2}\\right| = \\binom{\\left|V\\right|}{2}", block: false)#text(".)")

#text("Now one of the great features of graphs, as opposed to some other abstract maths concepts, is that they are easy to draw: the abstract vertices become dots on a plane, while the edges become line segments or curves connecting these dots. [To avoid some technicalities we do not allow these curves to pass through the dots, except if the curve is terminating at that dot.] Let us informally refer to such a concrete representation D of a graph G as a ")#link("http://en.wikipedia.org/wiki/Graph_drawing")[#text("drawing")]#text(" of that graph. Clearly, any non-trivial graph is going to have an infinite number of possible drawings. In some of these drawings, a pair of edges might cross each other; in other drawings, all edges might be disjoint (except of course at the vertices, where edges with a common endpoint are obliged to meet). If G has a drawing D of the latter type, we say that the graph G is ")#link("http://en.wikipedia.org/wiki/Planar_graph")[#text("planar")]#text(".")

#text("Given an abstract graph G, or a drawing thereof, it is not always obvious as to whether that graph is planar; just because the drawing that you currently possess of G contains crossings, does not necessarily mean that ")#emph[#text("all")]#text(" drawings of G do. The wonderful little web game “")#link("http://www.planarity.net/")[#text("Planarity")]#text("” illustrates this point excellently. Nevertheless, there are definitely graphs which are not planar; in particular the ")#link("http://en.wikipedia.org/wiki/Complete_graph")[#text("complete graph ")]#mi("K_5")#text(" on five vertices, and the ")#link("http://en.wikipedia.org/wiki/Complete_bipartite_graph")[#text("complete bipartite graph")]#text(" ")#mi("K_{3,3}")#text(" on two sets of three vertices, are non-planar.")

#image("../assets/3f0c38dd75fc959ecff3f9751280610abb57ac5e0647542f202c825cbacf71a4-c9eec913ed31c8a88fe338a4fc865e9a7910e361014e890dae8623454aadccd1.svg", width: 90%)#image("../assets/ae54a49b503bee95594d00e294db58cc359b68c3796efdafc2568865bcf38ea6-3b719082626725fd8c64a5bf44d3fdaee7f2864eb1915a51bef262dcfbe29fbf.svg", width: 90%)

#text("There is in fact a famous ")#link("http://en.wikipedia.org/wiki/Planar_graph#Kuratowski.27s_and_Wagner.27s_theorems")[#text("theorem of Kuratowski")]#text(" that says that these two graphs are the only “source” of non-planarity, in the sense that any non-planar graph contains (a ")#link("http://en.wikipedia.org/wiki/Subdivision_%28graph_theory%29")[#text("subdivision")]#text(" of) one of these graphs as a subgraph. (There is of course the even more famous ")#link("http://en.wikipedia.org/wiki/Four_color_theorem")[#text("four-colour theorem")]#text(" that asserts that every planar graphs is four-colourable, but this is not the topic of my post today.)")

#text("Intuitively, if we fix the number of vertices |V|, and increase the number of edges |E|, then the graph should become “increasingly non-planar”; conversely, if we keep the same number of edges |E| but spread them amongst a greater number of vertices |V|, then the graph should become “increasingly planar”. Is there a quantitative way to measure the “non-planarity” of a graph, and to formalise the above intuition as some sort of inequality?")#linebreak()#text(" ")#metadata(none) <tao-cd38f27fcd4a30d4f5e9>

#text("It turns out that there is an elegant inequality that does precisely this, known as the ")#link("http://en.wikipedia.org/wiki/Crossing_number#The_crossing_number_inequality")[#text("crossing number inequality")]#text(". It was first discovered by ")#link("http://www.ams.org/mathscinet-getitem?mr=806962")[#text("Ajtai-Chvátal-Newborn-Szemerédi")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=738751")[#text("by Leighton")]#text(" (the latter being motivated by optimising ")#link("http://en.wikipedia.org/wiki/VLSI")[#text("VLSI")]#text(" designs). Nowadays it can be proven by two elegant amplifications of ")#link("http://en.wikipedia.org/wiki/Euler_characteristic")[#text("Euler’s formula")]#text(", as we shall see.")

#text("If D is a drawing of a graph G, we define cr(D) to be the total number of crossings – where pairs of edges intersect at a point, for a reason other than sharing a common vertex. (If multiple edges intersect at the same point, each pair of edges counts once.) We then define the ")#emph[#text("crossing number")]#text(" cr(G) of G to be the minimal value of cr(D) as D ranges over the drawings of G. Thus for instance cr(G)=0 if and only if G is planar. One can also verify that the two graphs ")#mi("K_5")#text(" and ")#mi("K_{3,3}")#text(" have a crossing number of 1. This quantity cr(G) will be the measure of how non-planar our graph G is. The problem is to relate this quantity in terms of the number of vertices |V| and the number of edges |E|. We of course do not expect an exact identity relating these three quantities (two graphs with the same number of vertices and edges may have a different number of crossing numbers), so will settle for good upper and lower bounds on cr(G) in terms of |V| and |E|.")

#text("How big can the crossing number of a graph G = (V,E) be? A trivial upper bound is cr(G) = O( |E|^2 ), because if we place the vertices in general position (or on a circle) and draw the edges as line segments, then every pair of edges crosses at most once. But this bound does not seem very tight; we expect to be able to find drawings in which most pairs of edges in fact do not intersect.")

#text("Let’s turn our attention instead to lower bounds. We of course have the trivial lower bound ")#mi("\\text{cr}(G) \\geq 0")#text("; can we do better? Let’s first be extremely unambitious and see when one can get the minimal possible improvement on this bound, namely ")#mi("\\text{cr}(G) > 0")#text(". In other words, we want to find some conditions on |V| and |E| which will force G to be non-planar. We can turn this around by taking contrapositives: if G is planar, what does this tell us about |V| and |E|?")

#text("Here, the natural tool is ")#link("http://en.wikipedia.org/wiki/Euler_characteristic")[#text("Euler’s formula")]#text(" |V|-|E|+|F|=2, valid for any planar drawing, where |F| is the number of faces (including the unbounded face). [This is the one place where we shall really use the topological structure of the plane; the rest of the argument is combinatorial. There are some minor issues if the graph is disconnected, or if there are vertices of degree one or zero, but these are easily dealt with.] What do we know about |F|? Well, every face is adjacent to at least three edges, whereas every edge is adjacent to exactly two faces. By ")#link("http://en.wikipedia.org/wiki/Double_counting_%28proof_technique%29")[#text("double counting")]#text(" the edge-face incidences, we conclude that ")#tao-math("3\\left|F\\right|\\leq 2\\left|E\\right|", block: false)#text(". Eliminating |F|, we conclude that ")#tao-math("\\left|E\\right| \\leq 3\\left|V\\right|-6", block: false)#text(" for all connected planar graphs with at least one cycle (and this bound is tight when the graph is triangular), which then implies ")#tao-math("\\left|E\\right| \\leq 3\\left|V\\right|", block: false)#text(" in general. Taking contrapositives, we conclude")

#mi("\\text{cr}(G) > 0")#text(" whenever ")#tao-math("\\left|E\\right| > 3\\left|V\\right|", block: false)#text(". (*)")

#text("Now, let us ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("amplify")]#text(" this inequality by exploiting the freedom to delete edges. Indeed, observe that if a graph G can be drawn with only cr(G) crossings, then we can delete one of the crossings by removing an edge associated to that crossing, and so we can remove all the crossings by deleting at most cr(G) edges, leaving at least |E|-cr(G) edges (and |V| vertices). Combining this with (*) we see that regardless of the number of crossings, we have")

#tao-math("\\left|E\\right|-\\text{cr}(G) \\leq 3\\left|V\\right|", block: false)

#text("leading to the following amplification of (*):")

#tao-math("\\text{cr}(G) \\geq \\left|E\\right| - 3\\left|V\\right|", block: false)#text(". (**)")

#text("This is not the best bound, though, as one can already suspect by comparing (**) with the crude upper bound ")#tao-math("\\text{cr}(G) = O(\\left|E\\right|^2)", block: false)#text(". We can amplify (**) further by exploiting a second freedom, namely the ability to delete vertices. One could try the same sort of trick as before, deleting vertices which are associated to a crossing, but this turns out to be very inefficient (because deleting vertices also deletes an unknown number of edges, many of which had nothing to do with the crossing). Indeed, it would seem that one would have to be fiendishly clever to find an efficient way to delete a lot of crossings by deleting only very few vertices.")

#text("However, there is an amazing (and unintuitive) principle in combinatorics which states that when there is no obvious “best” choice for some combinatorial object (such as a set of vertices to delete), then often trying a ")#emph[#text("random")]#text(" choice will give a reasonable answer, if the notion of “random” is chosen carefully. (See ")#link("http://www.dpmms.cam.ac.uk/~wtg10/2cultures.pdf")[#text("this paper of Gowers ")]#text("for some further discussion of this principle.) The application of this principle is known as the ")#emph[#text("probabilistic method")]#text(", first introduced by Erdős.")

#text("Here is how it works in this current setting. Let ")#mi("0 < p \\leq 1")#text(" be a parameter to be chosen later. We will randomly delete all but a fraction p of the vertices, by letting each vertex be deleted with an independent probability of 1-p (and thus surviving with a probability of p). Let V’ be the set of vertices that remain. Once one deletes vertices, one also has to delete the edges attached to these vertices; let E’ denote the surviving edges (i.e. the edges connected to vertices in V’). Let G’=(V’,E’) be the surviving graph (known as the subgraph of G ")#link("http://en.wikipedia.org/wiki/Glossary_of_graph_theory#Subgraphs")[#text("induced")]#text(" by V’). Then from (**) we have")

#tao-math("\\text{cr}(G^{\\prime}) \\geq \\left|E^{\\prime}\\right| - 3\\left|V^{\\prime}\\right|", block: false)#text(".")

#text("Now, how do we get from this back to the original graph G = (V,E)? The quantities |V’|, |E’|, and cr(G’) all fluctuate randomly, and are difficult to compute. However, their ")#emph[#text("expectations")]#text(" are much easier to compute. Accordingly, we take expectations of both sides (this is an example of the ")#emph[#text("first moment method")]#text("). Using linearity of expectation, we have")

#tao-math("{\\Bbb E}(\\text{cr}(G^{\\prime})) \\geq {\\Bbb E}(\\left|E^{\\prime}\\right|) - 3 {\\Bbb E}(\\left|V^{\\prime}\\right|).", block: false)

#text("These quantities are all relatively easy to compute. The easiest is ")#tao-math("{\\Bbb E}(\\left|V^{\\prime}\\right|)", block: false)#text(". Each vertex in V has a probability p of ending up in V’, and thus contributing 1 to |V’|. Summing up (using linearity of expectation again), we obtain ")#tao-math("{\\Bbb E}(\\left|V^{\\prime}\\right|) = p\\left|V\\right|", block: false)#text(".")

#text("The quantity ")#tao-math("{\\Bbb E}(\\left|E^{\\prime}\\right|)", block: false)#text(" is almost as easy to compute. Each edge e in E will have a probability ")#mi("p^2")#text(" of ending up in E’, since both vertices have an independent probability of p of surviving. Summing up, we obtain ")#tao-math("{\\Bbb E}(\\left|E^{\\prime}\\right|) = p^2 \\left|E\\right|", block: false)#text(". (The events that each edge ends up in E’ are not quite independent, but the great thing about linearity of expectation is that it works even without assuming any independence.)")

#text("Finally, we turn to ")#mi("{\\Bbb E}(\\text{cr}(G^{\\prime}))")#text(". Let us draw G in the optimal way, with exactly cr(G) crossings. Observe that each crossing involves two edges and four vertices. (If the two edges involved in a crossing share a common vertex as well, thus forming an ")#mi("\\alpha")#text(" shape, one can reduce the number of crossings by 1 by swapping the two halves of the loop in the ")#mi("\\alpha")#text(" shape. So with the optimal drawing, the edges in a crossing do not share any vertices in common.) Passing to G’, we see that the probability that the crossing survives in this drawing is only ")#mi("p^4")#text(". By one last application of linearity of expectation, the expected number of crossings of this diagram that survive for G’ is ")#mi("p^4 \\text{cr}(G)")#text(". This particular diagram may not be the optimal one for G’, so we end up with an inequality ")#mi("{\\Bbb E} \\text{cr}(G^{\\prime}) \\leq p^4 \\text{cr}(G)")#text(". Fortunately for us, this inequality goes in the right direction, and we get a useful inequality:")

#tao-math("p^4 \\text{cr}(G) \\geq p^2 \\left|E\\right| - 3 p \\left|V\\right|", block: false)#text(".")

#text("In terms of cr(G), we have")

#tao-math("\\text{cr}(G) \\geq p^{-2} \\left|E\\right| - 3 p^{-3} \\left|V\\right|", block: false)#text(".")

#text("To finish the amplification, we need to optimise in p, subject of course to the restriction ")#mi("0 < p \\leq 1")#text(", since p is a probability. One can solve the optimisation problem exactly, but we will perform a cheaper computation by settling for a bound which is close to the optimal bound rather than exactly equal to it. A general principle is that optima are often obtained when two of the terms are roughly in balance. A bit of thought reveals that it might be particularly good to have ")#tao-math("3 p^{-3} \\left|V\\right|", block: false)#text(" just barely smaller than ")#tao-math("p^{-2} \\left|E\\right|", block: false)#text(". (If it is a lot smaller, then p will be large, and we don’t get a good bound on the right. If instead ")#tao-math("3 p^{-3} \\left|V\\right|", block: false)#text(" is a lot bigger, then we are likely to have a negative right-hand side.) For instance, we could choose p so that ")#tao-math("4 p^{-3} \\left|V\\right| = p^{-2} \\left|E\\right|", block: false)#text("; this is legal as long as ")#tao-math("\\left|E\\right| \\geq 4\\left|V\\right|", block: false)#text(". Substituting this we obtain the ")#emph[#text("crossing number inequality")]

#tao-math("\\text{cr}(G) \\geq \\frac{\\left|E\\right|^3}{64 \\left|V\\right|^2}", block: false)#text(" whenever ")#tao-math("\\left|E\\right| \\geq 4\\left|V\\right|", block: false)#text(". (***)")

#text("This is quite a strong amplification of (*) or (**) (except in the transition region in which |E| is comparable to |V|).")

#text("Is it sharp? We can compare it against the trivial bound ")#tao-math("\\text{cr}(G) = O(\\left|E\\right|^2)", block: false)#text(", and we observe that the two bounds match up to constants when |E| is comparable to ")#tao-math("\\left|V\\right|^2", block: false)#text(". (Clearly, |E| cannot be larger than ")#tao-math("\\left|V\\right|^2", block: false)#text(".) So the crossing number inequality is sharp (up to constants) for dense graphs, such as the complete graph ")#mi("K_n")#text(" on n vertices.")

#text("Are there any other cases where it is sharp? We can answer this by appealing to the symmetries of (***). By the nature of its proof, the inequality is basically symmetric under passage to random induced subgraphs, but this symmetry does not give any further examples, because random induced subgraphs of dense graphs again tend to be dense graphs (cf. the computation of ")#tao-math("{\\Bbb E} \\left|V^{\\prime}\\right|", block: false)#text(" and ")#tao-math("{\\Bbb E} \\left|E^{\\prime}\\right|", block: false)#text(" above). But there is a second symmetry of (***) available, namely that of ")#emph[#text("replication")]#text(". If one takes k disjoint copies of a graph G = (V,E), one gets a new graph with k|V| vertices and k|E| edges, and a moment’s thought will reveal that the new graph has a crossing number of k cr(G). Thus replication is a symmetry of (***). Thus, (***) is also sharp up to constants for replicated dense graphs. It is not hard to see that these examples basically cover all possibilities of |V| and |E| for which ")#tao-math("\\left|E\\right| \\geq 4\\left|V\\right|", block: false)#text(". Thus the crossing number inequality cannot be improved except for the constants. (The best constants known currently can be found in a recent paper of ")#link("http://www.ams.org/mathscinet-getitem?mr=2267545")[#text("Pach, Radoicic, Tardos, and Tóth")]#text(".)")

#text("[A general principle, by the way, is that one can roughly gauge the “strength” of an inequality by the number of independent symmetries (or approximate symmetries) it has. If for instance there is a three-parameter family of symmetries, then any example that demonstrates that sharpness of that inequality is immediately amplified to a three-parameter family of such examples (unless of course the example is fixed by a significant portion of these symmetries). The more examples that show an inequality is sharp, the more efficient it is – and the harder it is to prove, since one cannot afford to lose anything (other than perhaps some constants) in every one of the sharp example cases. This principle is of course consistent with my ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("previous post ")]#text("on arbitraging a weak asymmetric inequality into a strong symmetric one.]")

#text("— Application: the Szemerédi-Trotter theorem —")

#text("It was noticed ")#link("http://www.ams.org/mathscinet-getitem?mr=1464571")[#text("by Székely")]#text(" that the crossing number is powerful enough to give easy proofs of several difficult inequalities in combinatorial ")#link("http://en.wikipedia.org/wiki/Incidence_geometry")[#text("incidence geometry")]#text(". For instance, the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di-Trotter_theorem")[#text("Szemerédi-Trotter theorem")]#text(" concerns the number of ")#link("http://en.wikipedia.org/wiki/Incidence_%28geometry%29")[#text("incidences")]#text(" ")#tao-math("I(P,L) := \\left|\\{ (p,l) \\in P \\times L: p \\in l \\}\\right|", block: false)#text(" between a finite collection of points P and lines L in the plane. For instance, the three lines and three points of a triangle form six incidences; the five lines and ten points of a pentagram form 20 incidences; and so forth.")

#text("One can ask the question: given |P| points and |L| lines, what is the maximum number of incidences I(P,L) one can form between these points and lines? (The minimum number is obviously 0, which is a boring answer.) The trivial bound is ")#tao-math("I(P,L) \\leq \\left|P\\right| \\left|L\\right|", block: false)#text(", but one can do better than this, because it is not possible for every point to lie on every line. Indeed, if we use nothing more than the axiom that every two points determine at most one line, combined with the Cauchy-Schwarz inequality, it is not hard to show (by double-counting the space of triples ")#mi("(p,p^{\\prime},l) \\in P \\times P \\times L")#text(" such that ")#mi("p, p^{\\prime} \\in l")#text(") that")

#tao-math("\\left|I(P,L)\\right| \\leq \\left|P\\right| \\left|L\\right|^{1/2} + \\left|L\\right|", block: false)#text(". (****)")

#text("Dually, using the axiom that two lines intersect in at most one point, we obtain")

#tao-math("\\left|I(P,L)\\right| \\leq \\left|L\\right| \\left|P\\right|^{1/2} + \\left|P\\right|", block: false)#text(".")

#text("(One can also deduce one inequality from the other by ")#link("http://en.wikipedia.org/wiki/Duality_(projective_geometry)")[#text("projective duality")]#text(".)")

#text("Can one do better? The answer is yes, if we observe that a configuration of points and lines naturally determines a drawing of a graph, to which the crossing number can be applied. To see this, assume temporarily that every line in L is incident to at least two points in P. A line l in L which is incident to k points in P will thus contain k-1 line segments in P; k-1 is comparable to k. Since the sum of all the k is I(P,L) by definition, we see that there are roughly I(P,L) line segments of L connecting adjacent points in P; this is a diagram with |P| vertices and roughly |I(P,L)| edges. On the other hand, a crossing in this diagram can only occur when two lines in L intersect. Since two lines intersect in at most one point, the total number of crossings is O(|L|^2). Applying the crossing number inequality (***), we obtain")

#tao-math("\\left|L\\right|^2 \\gg I(P,L)^3/\\left|P\\right|^2", block: false)#text(" if I(P,L) is much larger than |P|")

#text("which leads to")

#tao-math("I(P,L) = O( \\left|L\\right|^{2/3} \\left|P\\right|^{2/3} + \\left|P\\right| )", block: false)#text(".")

#text("We can then remove our temporary assumption that lines in L are incident to at least two points, by observing that lines that are incident to at most one point will only contribute O(|L|) incidences, leading to the ")#emph[#text("Szemerédi-Trotter theorem")]

#tao-math("I(P,L) = O( \\left|L\\right|^{2/3} \\left|P\\right|^{2/3} + \\left|P\\right| + \\left|L\\right|)", block: false)#text(".")

#text("This bound is somewhat stronger than the previous bounds, and is in fact surprisingly sharp; a typical example that demonstrates this is when P is the lattice ")#mi("\\{1,\\ldots,N\\} \\times \\{1,\\ldots,N^2\\}")#text(" and L is the set of lines ")#mi("\\{ (x,y): y=mx+b\\}")#text(" with slope ")#mi("m \\in \\{1,\\ldots,N\\}")#text(" and intercept ")#mi("b \\in \\{1,\\ldots,N^2\\}")#text("; here ")#tao-math("\\left|P\\right|=\\left|L\\right|=N^3", block: false)#text(" and the number of incidences is roughly ")#mi("N^4")#text(".")

#text("The original proof of this theorem, by the way, proceeded by amplifying (****) using the method of ")#emph[#text("cell decomposition")]#text("; it is thus somewhat similar in spirit to Szekély’s proof, but was a bit more complicated technically. ")#link("http://www.ams.org/mathscinet-getitem?mr=1660476")[#text("Wolff conjectured")]#text(" a continuous version of this theorem for fractal sets, sometimes called the ")#emph[#text("Furstenberg set conjecture")]#text(", and related to the ")#link("http://en.wikipedia.org/wiki/Kakeya_conjecture")[#text("Kakeya conjecture")]#text("; a small amount of progress beyond the analogue of (****) is known, thanks to work of ")#link("http://www.ams.org/mathscinet-getitem?mr=1856956")[#text("Katz and myself")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1982147")[#text("of Bourgain")]#text(", but we are still far from the best possible result here.")

#text("— Application: sum-product estimates —")

#text("One striking application of the Szemerédi-Trotter theorem (and by extension, the crossing number inequality) is to the arena of ")#emph[#text("sum-product ")]#text("estimates in additive combinatorics, which is currently a very active area of research, especially in finite fields, due to its connections with some long-standing problems in analytic number theory, as well as to some computer science problems concerning randomness extraction and expander graphs. However, our focus here will be on the more classical setting of sum-product estimates in the real line ")#mi("{\\Bbb R}")#text(".")

#text("Let A be a finite non-empty set of non-zero real numbers. We can form the ")#emph[#text("sum set")]

#mi("A+A := \\{ a + b: a, b \\in A \\}")

#text("and the ")#emph[#text("product set")]

#mi("A \\cdot A = \\{ ab: a, b \\in A \\}")#text(".")

#text("If A is in “general position”, it is not hard to see that ")#mi("A+A")#text(" and ")#mi("A \\cdot A")#text(" both have cardinality comparable to ")#tao-math("\\left|A\\right|^2", block: false)#text(". However, in certain cases one can make one or the other sets significantly smaller. For instance, if A is an arithmetic progression ")#mi("\\{ a, a+r, \\ldots, a+(k-1)r\\}")#text(", then the sum set ")#mi("A+A")#text(" has cardinality comparable to just |A|. Similarly, if A is a geometric progression ")#mi("\\{ a, ar, \\ldots, ar^{k-1}\\}")#text(", then the product set ")#mi("A \\cdot A")#text(" has cardinality comparable to |A|. But clearly A cannot be an arithmetic progression and a geometric progression at the same time (unless it is very short). So one might conjecture that at least one of the sum set and product set should be significantly larger than A. Informally, this is saying that no finite set of reals can behave much like a subring of ")#mi("{\\Bbb R}")#text(".")

#text("This intuition was made precise ")#link("http://www.ams.org/mathscinet-getitem?mr=820223")[#text("by Erdős and Szemerédi")]#text(", who established the lower bound")

#tao-math("\\max( \\left|A+A\\right|, \\left|A \\cdot A\\right| ) \\gg \\left|A\\right|^{1+c}", block: false)

#text("for some small ")#mi("c>0")#text(" which they did not make explicit. They then conjectured that in fact c should be made arbitrary close to the optimal value of 1, and more precisely that")

#tao-math("\\max( \\left|A+A\\right|, \\left|A \\cdot A\\right| ) \\gg \\left|A\\right|^2 \\exp( - \\delta \\log \\left|A\\right|/\\log\\log\\left|A\\right| )", block: false)

#text("for large |A| and some absolute constant ")#mi("\\delta > 0")#text(".")

#text("The Erdős-Szemerédi conjecture remains open, however the value of c has been improved; currently, the best bound is due ")#link("http://www.ams.org/mathscinet-getitem?mr=2143727")[#text("to Solymosi")]#text(", who showed that c can be arbitrarily close to 3/11. Solymosi’s argument is based on an earlier argument ")#link("http://www.ams.org/mathscinet-getitem?mr=1472816")[#text("of Elekes")]#text(", who obtained c=1/4 by a short and elegant argument based on the Szemerédi-Trotter theorem which we will now present. The basic connection between the two problems stems from the familiar formula y=mx+b for a line, which clearly encodes a multiplicative and additive structure. We already used this connection implicitly in the example that demonstrated that the Szemerédi-Trotter theorem was sharp. For Elekes’ argument, the challenge is to show that if ")#mi("A+A")#text(" and ")#mi("A \\cdot A")#text(" are both small, then a suitable family of lines ")#mi("y=mx+b")#text(" associated to A will have a high number of incidences with some set of points associated to A, so that the Szemerédi-Trotter may then be profitably applied. It is not immediately obvious exactly how to do this, but Elekes settled upon the choice of letting ")#mi("P := (A \\cdot A) \\times (A + A)")#text(", and letting L be the space of lines y=mx+b with slope in ")#mi("A^{-1}")#text(" and intercept in A, thus ")#tao-math("\\left|P\\right| = \\left|A+A\\right| \\left|A \\cdot A\\right|", block: false)#text(" and ")#tao-math("\\left|L\\right| = \\left|A\\right|^2", block: false)#text(". One observes that each line in L is incident to |A| points in P, leading to ")#tao-math("\\left|A\\right|^3", block: false)#text(" incidences. Applying the Szemerédi-Trotter theorem and doing the algebra one eventually concludes that ")#tao-math("\\max( \\left|A+A\\right|, \\left|A \\cdot A\\right| ) \\gg \\left|A\\right|^{5/4}", block: false)#text(". (A more elementary proof of this inequality, not relying on the Szemerédi-Trotter theorem or crossing number bounds, and thus having the advantage on working on other archimedean fields such as ")#mi("{\\Bbb C}")#text(", was subsequently found ")#link("http://www.ams.org/mathscinet-getitem?mr=2212132")[#text("by Solymosi")]#text(", but the best bounds on the sum-product problem in ")#mi("{\\Bbb R}")#text(" still rely very much on the Szemerédi-Trotter inequality.)")

#heading(level: 1)[#text("Comments (58)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7d33eda86b7bbd80ca7e2624f4a6b7db4a8352cdcf008dea241c1c8167ff8790-2f1c5dc543b3202bf520d9f0ec11f84264b9b3d05cb8b9d56e255ceac5500300.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David P. Moulton")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-2/#comment-199841")[#strong[#text("David P. Moulton")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2012")])]

#text("Hi Terry.")

#text("But didn’t you have to take out the $6p^-4$ term because of the previous comment? They pointed out that you can’t have it in for arbitrary graphs, since it implies that the crossing number always is")#linebreak()#text(" positive, which it isn’t. In particular, when you use the probabilistic method, you’ll end up with some subgraphs for which the $+6$ doesn’t apply. I notice, in fact, that in the current version of the post, you don’t have the $+6$ when you take expectations, but you magically put it in when you evaluate. I think you just have to take it out everywhere, and then there’s no cubic to solve.")

#text("Thanks,")#linebreak()#text(" David")

#emph[#text("[Ah, I see what happened now. (I was working off of the published version, which predated the previous erratum, and got confused.) It should be fixed now – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-2/#comment-228783")[#strong[#text("Bird’s-eye views of Structure and Randomness (Series) | Abstract Art")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2013")]

#text("[…] Drawing networks on a plane (adapted from “The crossing number inequality“) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-2/#comment-229612")[#strong[#text("Drawing networks on a plane | Abstract Art")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2013")]

#text("[…] [1.10] The crossing number inequality […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-2/#comment-241552")[#strong[#text("Even more new results! | Some Plane Truths")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2013")]

#text("[…] lemma technique, as introduced by Székely (a nice introduction to this technique can be found in this post by Tao), the new proofs rely on polynomial partitionings (which I just discussed in this series of posts; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/acc0087dd97d6dd95107914b2f1478cba8fa8d5dc5126796a11aff22a2c05b3c-51efdb7e1e6e2b05dbe987a4d15ee798562ab897def7b673d5a9793b900b8b39.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dimension of projected sets and Fourier restriction | Almost Originality")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-2/#comment-350918")[#strong[#text("Dimension of projected sets and Fourier restriction | Almost Originality")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2014")])]

#text("[…] in the plane . Notice that by taking a geometric mean of the terms in the minimum one can get at the RHS, which has a worse exponent than Szemeredi-Trotter above. Indeed, one can prove that in the finite field setting this is optimal, and thus any proof of the Szemeredi-Trotter inequality in the real case can’t rely on algebraic means only – it needs to incorporate some topology or as well. This point is made very clear in the following post by Tao, in which he proves Szemeredi-Trotter via the crossing number inequality: ")#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/")[#text("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-2/#comment-429215")[#strong[#text("Problème de distances | Quentin Fortier")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2014")]

#text("[…] Pour sa preuve (particulièrement élégante) je renvoie à un excellent article de Terence Tao sur son blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-2/#comment-524331")[#strong[#text("Configurations with many incidences and no triangles – Cosmin Pohoata")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2019")]

#text("[…] this has been done in an absolutely beautiful indirect manner by Szekely with via the so-called crossing number inequality, however, more modernly, this has also been achieved in various other more practical ways by using […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6f35cd52575d3b70420c2058eaed4fd261c8b1f593a75e06fbda8ed59eee972-4f3a90a0bc891b73bfcea4a2b84eab1c9d34401b21aef32cef2ab2be223b7932.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Suresh")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-9774")[#strong[#text("Suresh")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2007")])]

#text("Another beautiful result by Szekely was on the related problem, “how many unit distance pairs exist in a set of n points in the plane”. The bound (n^{4/3}) had been proven twice before, but the first time with very ugly constants, and the second time with better constants using the cell decomposition method. Szekely’s proof was one of those ‘from the book’ proofs of this fact. And unlike the Hopcroft problem (line-point incidences), this bound is nowhere near tight; the lower bound is only slightly superlinear.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9117c280bcebaea0538a1837f0687f55474282a43800383770c6924b01f53b16-6e7d9f81fe77c07d18c320e4fbc37ce487fcab0533b3c3854feaa6f39bac88ce.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Webster")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-9793")[#strong[#text("Ben Webster")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2007")])]

#text("I get “Formula does not parse” for every single displayed formula in the post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-9796")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2007")])]

#text("me too(formula does not parse) using firefox")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-9807")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2007")])]

#text("Others have reported this problem sporadically (while others simultaneously see no difficulty); my theory is that there are multiple wordpress servers, and there is some lag in getting the LaTeX images propagated properly. So far, it seems that refreshing the page after some time solves the problem by itself.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Fitch")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-9808")[#strong[#text("Dan Fitch")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2007")])]

#text("Refreshing the page will usually make the markup re-calculate.")

#text("Neat proofs and explanations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0968fd592b1875615ed25ee401bd2b9d09f4e922ff732d45028f6696215f22e3-630c111989e921aefac15e316f2377d43db0ec1f6f005490a99dc36ac863733d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-9814")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2007")])]

#text("In case G is already planar isn’t cr(G) zero? But E^3/64V^2 is always positive, contradicting (***).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-9816")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2007")])]

#text("Dear anonymous,")

#text("(***) is only valid when |E| is larger than 4|V|. In contrast, in order for a graph to be planar, |E| cannot exceed 3|V|-6 (see (*)).")

#text("One can view 3|V|-6 as a threshold. If the number of edges lies below that number, there may be no crossings. But once one exceeds that threshold, the crossings build up quite quickly, and in fact starts growing like the cube of the number of edges (keeping |V| fixed).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-9828")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2007")])]

#text("Hi Terence,")

#text("There appears to be some type of hierarchy among graphs, maps, lattices and images.")

#text("1 – RE: E8")#linebreak()#text(" a – crystal graph [perhaps either a sagittal or coronal perspective, medicine]")#linebreak()#text(" b – map of the E8 root system [perhaps an axial perspective, medicine]")#linebreak()#text(" ")#link("http://aimath.org/E8/")[#text("http://aimath.org/E8/")]

#text("Using imaging programs similar to AstroMed, should one be able to construct a 3D image of E8 [calculate the missing coronal or sagittal perspective]?")

#text("AstoMed: “The goal of the Harvard IIC’s “Astronomical Medicine” (AM) project is to extend the state of the art of complex data understanding in two very different fields, astronomy and medical imaging, using a broad-based approach to data exploration and analysis.“ [modified Magnetic Resonance Imaging, MRI]")#linebreak()#text(" ")#link("http://astromed.iic.harvard.edu/")[#text("http://astromed.iic.harvard.edu/")]

#text("2 – Nuclear Magnetic Resonance [NMR] in ‘FirstGlance in Jmol’ reveals helices in many different molecules. The helices may likely have ionic molecules with a solenoid like effect? Example, Citrate Synthase:")#linebreak()#text(" ")#link("http://molvis.sdsc.edu/fgij/fg.htm?mol=2cts")[#text("http://molvis.sdsc.edu/fgij/fg.htm?mol=2cts")]

#text("The latter may have something in common with your phrase from the text of this post:")#linebreak()#text(" “… and by Leighton (the latter being motivated by optimising VLSI designs).”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-9830")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2007")])]

#text("Doug, a 3-D image wouldn’t be much help. ")#mi("E_8")#text(" has 248 dimensions, and even that’s not enough. You’re thinking of embedding it as a shape in some even ")#emph[#text("higher")]#text("-dimensional space, like we usually think of a 2-dimensional sphere living in 3-dimensional space.")

#text("Even if you just mean the root system, that’s really living in 8 dimensions thus, the 8 in ")#mi("E_8")#text(". It’s actually very well understood, even without drawing pictures, though. And that picture of the root system that was in all the papers is more because it looks pretty than for actual mathematical use.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-9835")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2007")]

#text("[…] The crossing number inequality Today I’d like to discuss a beautiful inequality in graph theory, namely the crossing number inequality. This […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Prashant V")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-9839")[#strong[#text("Prashant V")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2007")])]

#text("Dear Terry,")

#text("How did the following arise: ")#mi("e > 7.5n \\Rightarrow \\text{cr}(G) \\geq \\frac{e^3}{33.75n^2}")#text("?")

#text("Was it more of a “guess and check” process? Are there any ways to get more accurate bounds?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-9859")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2007")])]

#text("Dear Prashant,")

#text("This result is proven in a paper of Pach and Toth:")

#link("http://www.ams.org/mathscinet-getitem?mr=1606052")[#text("http://www.ams.org/mathscinet-getitem?mr=1606052")]

#text("On briefly skimming the article, it seems that one of the key new ideas is to consider multigraphs rather than just graphs.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mayifu")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-9866")[#strong[#text("Mayifu")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2007")])]

#text("Dear Terry,")

#text("Off Topic. Have you thought about N-representable problem of the two-particle reduced-density matrix of a many-particle wave function?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e83e634533f6ab29721858d7b4ed9d9b87c6fdee78a07616daeb66d455d57d01-307087ec1d27eca738f794a7e09874a469b76d6be67d62b8bbcabbf056b53f7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yoran")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-9904")[#strong[#text("Yoran")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2007")])]

#text("Dear Terence,")

#text("This is a great article! I’m a undergraduate Computer Science student and I had a course on graph theory last year. I find that subject very interesting. I knew about Euler’s formula, and Kuratowski as well, but I find this inequality very interesting. I think you explain it very well, and I never expected a Fields medal winner to write about something even an undergraduate can understand (I mean this in a positive way of course)!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-9906")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2007")])]

#text("I think a more exciting off-topic would be about incompatibilities")#linebreak()#text(" between various physical theories, e.g., quantum entangment")#linebreak()#text(" vs. special relativity or the Higgs’ particle controversy. However,")#linebreak()#text(" let me mention one topic which mathematicians are trying to deal")#linebreak()#text(" with. It is related to one of Terry’s previous posts.")#linebreak()#text(" Consider one of the Clay Institute problems: the incompressible")#linebreak()#text(" Navier-Stokes equations. From basic thermodynamics, pressure")#linebreak()#text(" is a function of density and temperature, e.g., in the ideal gas")#linebreak()#text(" law: p=kT\\rho. However, \\rho=const., therefore the gradient of")#linebreak()#text(" the pressure is really the gradient of the temperature. Question:")#linebreak()#text(" Does it make sense to use this equations in the health sciences?")#linebreak()#text(" In fact, as a rule, an equation of state is used to close the system")#linebreak()#text(" of compressible Euler equations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-9938")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2007")])]

#text("Hi John Armstrong,")

#text("I also posted at your blog in the post ‘Newton Fractals’.")

#text("Were dimensions always spatial I would readily agree with you.")

#text("Mathematical game theory has demonstrated that dimensions or degrees of freedom may also be strategic.")

#text("FUNDAMENTALS OF MRI: Part I, William G Bradley, MD, PhD, FACR")#linebreak()#text(" “MRI is based on a safe interaction between radio waves and hydrogen nuclei in the body in the presence of a strong magnetic field.”")#linebreak()#text(" “… volume element or “voxel” of tissue are translated by the computer into a two dimensional image composed of picture elements or “pixels”. ”")#linebreak()#text(" “… displays the body in thin tomographic slices …” [which can also mathematically be complied into a 3D image].")#linebreak()#text(" ")#link("http://www.e-radiography.net/mrict/fund%20mr1/MRI%20fund1.htm")[#text("http://www.e-radiography.net/mrict/fund%20mr1/MRI%20fund1.htm")]

#text("I suspect that significantly more than 248 hydrogen atoms are processed per tomographic slice as nodes [or vertices]. The total number may even exceed that of Monster dimensions for all slices.")

#text("I do not know if a 3D of E8 would be of use, but I suspect that it may. There may be a 3D with a time-D is nested or embedded within another 3D with time-D or there may exist 4-strategic-D [such as mass, temperature, pressure, vibration, etc] beyond the usual 3-spatial-D and time-D.")

#text("If the E8 crystal graph is identical for coronal and sagittal views, then combining them with the E8 root map may resemble a 3D torus?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/927b5d43d7b9c716986ffbcf8744112135a73af9a6adac81c5a2524a7662baed-7dc7bfe2252f25957b54848265da7f0c2b88b77d6ba7b28c8419362f26f919b1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nimbusgear")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-9943")[#strong[#text("nimbusgear")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2007")])]

#text("Dear Terence,")

#text("Fabulous post, I was wondering what you might draw from the connection between graphs and knot theory.. From what i’ve read of knot theory, any given knot can be reduced to an ‘unknot’ by moving that knot into higher dimensions.")

#text("Regarding planarity in graphs however, what i draw from is that there is the simplest form of non-planarity.. the equivalent of an ‘unknot’, in the K5 and K3,3 forms.")

#text("That is, higher dimensional quantized geometry projected down to two dimensions results in an unknot (the planar ‘parts’) and harmonics of the non-planar K5 and K3,3 forms.")

#text("If this is a correct supposition on my part, i’d like to conjecture that as the dimensionless physical constants can be seen as ratios of one another, these ratios are geometric, and take the shape of a graph when plotted. Further, that these ratios may be the result of two or more crossing points of higher dimensional curves perhaps, projected down to 3d.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-9946")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2007")])]

#text("But Doug, the dimensions of ")#mi("E_8")#text(" ")#emph[#text("are")]#text(" spatial. And the dimensions in which the root system lives ")#emph[#text("are")]#text(" spatial as well.")

#text("I may not specialize in Lie theory, but my ")#link("http://unapologetic.wordpress.com/category/atlas-of-lie-groups/")[#text("series of posts on the Atlas Project")]#text(" (which followed that news story back in March) should confirm that I know what I’m talking about.")

#text("Yes, “degrees of freedom” have other interpretations, but you’re talking about drawing a picture, which means spatial interpretations. The dimensions in the pixel example you cite are greyscale values. Then a “picture” of ")#mi("E_8")#text(" would be a collection of 248 points, each a different shade of grey. It doesn’t trigger human spatial intuition the way a pictorial representation is supposed to.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-9990")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2007")])]

#text("Dear nimbusgear,")

#text("There are certainly analogies between the topology of graphs and of knots; knots, for instance, also have crossing number as an important invariant. And any graph can be made non-crossing in three dimensions, by assigning each vertex to a random location in space and using line segments to draw the edges (the point is that in three dimensions, any two randomly chosen line segments will be disjoint with probability 1). I am not aware though of any work which lets one understand the two-dimensional crossing number of a graph in terms of a higher-dimensional representation of that graph.")

#text("I am not an expert in knot theory, but I gather that nowadays one analyses knots by placing additional structures on top of the three-dimensional ambient space (such as a vector bundle or a quantum field theory) rather than lifting that ambient space (or the knot itself) into a higher-dimensional one. It may be one day that something similar happens for graphs, but I do not know of results in this direction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-10041")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2007")])]

#text("Dr. Tao: Actually, there’s a growing trend to study knots from the purely combinatorial viewpoint, as with the Jones polynomial. And there’s one enterprising young mathematician I know of who used his dissertation to start the (possibly overly-)ambitious program of recasting all the old knot invariants as monoidal functors on suitable categories of tangles. Fascinating stuff, but he’s having a devil of a time getting hired anywhere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-10224")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2007")])]

#text("Hi Terence,")

#text("While doing more reading on MRI, I found this dissertation chapter")#linebreak()#text(" ‘Stationarity and Ergodicity’")#linebreak()#text(" ")#link("http://www.cs.utah.edu/~suyash/Dissertation_html/node25.html")[#text("http://www.cs.utah.edu/~suyash/Dissertation_html/node25.html")]#linebreak()#text(" in")#linebreak()#text(" Suyash P Awate, ‘Adaptive Nonparametric Markov Models and Information-Theoretic Methods for Image Restoration and Segmentation’, 2007-02-21.")#linebreak()#text(" ")#link("http://www.cs.utah.edu/~suyash/Dissertation_html/Dissertation.html")[#text("http://www.cs.utah.edu/~suyash/Dissertation_html/Dissertation.html")]

#text("I suspected that imaging was related to graphs and mapping, but was surprised by also having an ergodicity relation.")

#text("Hi John,")

#text("RE: your comment September 21st, 2007 at 4:55 pm")

#text("1 – I am not questioning your knowledge of E8 as currently understood by those who are expert on Lie theory..")#linebreak()#text(" I am questioning the current understanding that the supposedly spatial dimensions of E8 are necessarily spatial.")

#text("I think that Werner Heisenberg allows me to do this because of uncertainty.")#linebreak()#text(" I do understand that this idea applies specifically to position and momentum.")#linebreak()#text(" I may be over generalizing uncertainty when applied to types of dimensions.")

#text("If I am incorrect, then someone with better rigorous skills than my own, should be able to demonstrate this by contradiction.")

#text("Reasoning [correct any of my misconceptions]:")#linebreak()#text(" a – Monstrous Moonshine [MM] supposedly has 24-complex, 1-string, 1-time dimensions [D].")#linebreak()#text(" The 24-complex dimensions may be spatial or not?")

#text("b – M-theory has 1-time, 3-real-spatial, 6-compact, 1-[circle or line coupling] dimensions.")#linebreak()#text(" What if:")#linebreak()#text(" – The 6-compact consist of 3-real and 3-imaginary or perhaps simply 3-complex D.")#linebreak()#text(" – The 3-real-spatial may also actually be 3-complex D due to the work of Caspar Wessel [surveyor] and Charles Proteus Steinmetz [electrical engineer].")#linebreak()#text(" – The Earth and other celestial objects have an unseen but detectable 3D magnetosphere, perhaps due to imaginary numbers, plus the real 3D surface which is visible due to light electromagnetism.")#linebreak()#text(" – Thus there may be a nesting or embedding of 3-complex within 3-complex D.")#linebreak()#text(" – The coupling dimension may be equivalent to the string dimension.")#linebreak()#text(" – Thus M-theory may be of moonshine form: 6-complex, 1-string, 1-time dimension, total 8 D.")

#text("Could this be a version of E8?")#linebreak()#text(" I do not know the answer.")

#text("c – Perhaps MM is an eightfold nesting of 3-complex-D with 1 string-D, 1-time-D?")#linebreak()#text(" Perhaps MM is a threefold nesting of E8 with additional 1 string-D, 1-time-D?")

#text("2 – I suspect that you may be underestimating the power of mathematics as applied to greyscale imaging.")#linebreak()#text(" Quotes from Mark Dow, Research Assistant")#linebreak()#text(" Brain Development Lab, University of Oregon")#linebreak()#text(" “Space is a MS Windows application for the display, navigation, rendering, editing, and measurement of 3-D data sets.”")#linebreak()#text(" “While the program was developed for use with MRI data sets, no operations or tools are specific to MRI modalities.“")#linebreak()#text(" “Space Volume (.vol) native format, 8 bit grayscale, 8 bit indexed, 24 bit RGB color”")

#link("http://lcni.uoregon.edu/~mark/Space_software/Space_program/Space_program_description.htm")[#text("http://lcni.uoregon.edu/~mark/Space_software/Space_program/Space_program_description.htm")]#linebreak()#text(" in")#linebreak()#text(" ")#link("http://lcni.uoregon.edu/~mark/")[#text("http://lcni.uoregon.edu/~mark/")]

#text("3 – Additional reading suggest that I should have used the term ‘3D projection’")#linebreak()#text(" E8 (mathematics)")#linebreak()#text(" a – section ‘Applications’")#linebreak()#text(" “E8 is the U-duality group of supergravity on an eight-torus (in its split form).”")

#text("b – section ‘E8 root system’")#linebreak()#text(" Picture – Zome Model of the E8 Root System.")#linebreak()#text(" ")#link("http://en.wikipedia.org/wiki/E8_(mathematics)")[#text("http://en.wikipedia.org/wiki/E8_(mathematics)")]

#text("The zome structure pictured is more spherical than I visualized .")#linebreak()#text(" It may be a horn or spindle torus?")#linebreak()#text(" The E8 crystal graph suggested a much less rounded torus to me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-10269")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2007")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I am questioning the current understanding that the supposedly spatial dimensions of E8 are necessarily spatial.")

#text("I think that Werner Heisenberg allows me to do this because of uncertainty.")#linebreak()#text(" I do understand that this idea applies specifically to position and momentum.")#linebreak()#text(" I may be over generalizing uncertainty when applied to types of dimensions.")
]

#text("Uncertainty is not just about dimensions. It’s about when certain variables relate to each other in certain ways, like positions and momenta, or like time and energy. There’s a lot of extra structure here that just isn’t present in ")#mi("E_8")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Reasoning [correct any of my misconceptions]:")#linebreak()#text(" a – Monstrous Moonshine [MM] supposedly has 24-complex, 1-string, 1-time dimensions [D].")
]

#text("“Monstrous Moonshine” is a conjecture. Are you thinking of the “Moonshine Module”, defined by Frankel et. al.? In that case, it was not originally related to string theory, so invoking strings here is completely spurious. The moonshine module is just a representation of a very large, but ")#emph[#text("finite")]#text(" (not continuous) group. ")#mi("E_8")#text(" is related, but very obliquely.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The 24-complex dimensions may be spatial or not?")
]

#text("This is a module, which is based on a vector space, which is just a big, flat, 24-dimensional version of a plane. No visualization necessary.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("b – M-theory has 1-time, 3-real-spatial, 6-compact, 1-[circle or line coupling] dimensions.")
]

#text("M-theory has ")#emph[#text("nothing")]#text(". M-theory hasn’t been defined, much less rigorously laid out.")

#text("Still, in this context “spatial” and “temporal” have very specific meanings for the geometry. It’s not at all about interpretation or rendering.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Could this be a version of E8?")
]

#text("No. ")#mi("E_8")#text(" enters string theory in another way entirely.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("c – Perhaps MM is an eightfold nesting of 3-complex-D with 1 string-D, 1-time-D?")
]

#text("Again, the module is just a vector space.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("3 – Additional reading suggest that I should have used the term ‘3D projection’")
]

#text("Yes, I understand that that’s what you were describing. But you still miss my point. We have a 248-dimensional manifold that may need a 500-dimensional space to be embedded smoothly in. We lose ")#emph[#text("so much")]#text(" information projecting down to anything we can possibly visualize that it hardly matters if we use two or three dimensions to do it. And then invoking all these other concepts that you have only the haziest understanding of merely confuses the issue.")

#text("Look, I’m far from some sort of mathematical elitist that wants to keep these ideas the province of some sanctified priesthood, but the hallmark of the field is specifically-defined terms used in very specific ways. You can’t just take whatever words sound familiar and throw them together. If you do, you end up with ")#link("http://en.wikipedia.org/wiki/The_Tao_of_Physics")[#emph[#text("The Tao of Physics")]]#text(" (no relation to our host) or ")#link("http://physics.nyu.edu/~as2/transgress_v2/transgress_v2_singlefile.html")[#emph[#text(" Transgressing the Boundaries: Towards a Transformative Hermeneutics of Quantum Gravity ")]]#text(".")

#text("So yes, we can give all sorts of 3-dimensional projections of the manifold underlying ")#mi("E_8")#text(", and we can even do it without using any of the fancy technology you suggest. But none of them really help us in any way understand what ")#mi("E_8")#text(" ")#emph[#text("is")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-10343")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2007")])]

#text("The book “Transgressing the boundaries: …” has an interesting")#linebreak()#text(" and not well known piece of information, that Godel constructed")#linebreak()#text(" “an Einstein space-time admitting closed timelike curves: that is,")#linebreak()#text(" a universe in which it is possible to travel into one’s own past!”.")#linebreak()#text(" However, that laws of physics allow for time travel after the Big")#linebreak()#text(" Bang is a consequence of 19th century variational termodynamics")#linebreak()#text(" (exercise). A before the Big Bang version of this theory was used")#linebreak()#text(" by Perelman, who wrote that he knows it from string theory,")#linebreak()#text(" “where it describes the low energy effective action”, and the")#linebreak()#text(" functional is defined on “dilaton fields.” It has to be before, to")#linebreak()#text(" be compatible with the Higgs field electroweak unification, e.g.,")#linebreak()#text(" E. Witten, From superconductors and four-manifolds to weak")#linebreak()#text(" interactions, Bull. Amer. Math. Soc. 44 (2007), 361-391. See:")#linebreak()#text(" (4.4) and the modification into (4.9) after the Big Bang.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90fdb1bd4d15f572efec35fa286de980ea7ce5e0b6742ae2869a3a9971445f1e-293dd9203dbf167d17c222b9afc4a61570f16295d6865e4bb4f503ce61b2315c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yury")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-10358")[#strong[#text("yury")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2007")])]

#text("Dear Terence,")

#text("do you know if there’s an upper bound on cr(G) if it’s known that G could be embedded into a torus? a surface of genus g? This case seems to fall somewhere between the planar case and the |E|>4|V| case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-10371")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2007")])]

#text("Hi John,")

#text("I doubt that I have the ability to ever fully understand your point.")

#text("We appear to have different informational databases.")

#text("Example:")#linebreak()#text(" “Richard E. Borcherds will receive a medal for his work in the fields of algebra and geometry, in particular for his proof of the so-called Moonshine conjecture.”")#linebreak()#text(" “In 1989, Borcherds was able to cast some more light on the mathematical background of this topic and to produce a proof for the conjecture.”")

#link("http://www.icm2002.org.cn/general/prize/medal/1998.htm")[#text("http://www.icm2002.org.cn/general/prize/medal/1998.htm")]

#text("Additional reading [only 2 listed each category:")#linebreak()#text(" Books")#linebreak()#text(" 1 – Terry Gannon, Moonshine beyond the Monster: The Bridge Connecting Algebra, Modular Forms and Physics (Cambridge Monographs on Mathematical Physics)")

#text("2 – Mark Ronan, Symmetry and the Monster: The Story of One of the Greatest Quests of Mathematics")

#text("PDF")#linebreak()#text(" 1 – see R.I. Ivanov and M.P. Tuite, Rational Generalised Moonshine from Abelian Orbifoldings of the Moonshine Module, Nucl.Phys. B635 435-472 (2002), ")#link("http://arxiv.org/abs/math.QA/0106027")[#text("http://arxiv.org/abs/math.QA/0106027")]#text(".")#linebreak()#text(" from Generalised Monstrous Moonshine and Genus Two Conformal Field Theory [more pdf listed]")#linebreak()#text(" ")#link("http://www.maths-physics.nuigalway.ie/users/Tuite/generalised_monstrous_moonshine.htm")[#text("http://www.maths-physics.nuigalway.ie/users/Tuite/generalised_monstrous_moonshine.htm")]

#text("2 – Yang-Hui He. Dept. of Physics and Math/Physics RG, Univ. of Pennsylvannia. Modular Matrix Models & Monstrous Moonshine: hep-th/0306092")#linebreak()#text(" or")

#link("http://uw.physics.wisc.edu/~strings/group/slides.04.spring/he.pdf")[#text("Click to access he.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-10383")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2007")])]

#text("This is getting interesting. The simplicity of a group implies it is not")#linebreak()#text(" really an after Big Bang physical object. If ideas from string theory")#linebreak()#text(" were used to prove the Moonshine conjecture, then from")#linebreak()#text(" a philosophical perspective, does string theory tell us something")#linebreak()#text(" about the relationship between structures existing before the Big")#linebreak()#text(" Bang, and current physical reality? Maybe some kind of “homeopathic")#linebreak()#text(" imprint”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/927b5d43d7b9c716986ffbcf8744112135a73af9a6adac81c5a2524a7662baed-7dc7bfe2252f25957b54848265da7f0c2b88b77d6ba7b28c8419362f26f919b1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nimbusgear")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-10397")[#strong[#text("nimbusgear")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2007")])]

#text("I’ve been following your guy’s dialog, and would like to note that if you’re looking for big bang components, why not take a look at the fundamentals of quantization in the mathematical domain?")

#text("I speak of the various bases, operating on perhaps curves, perhaps other forms, but revealing a stage by stage quantization in terms of numeric value.")

#text("All forms at that level have fully defined symmetries, and are incredibly easy to grasp at in terms of quantization, harmonics, and modulations.")

#text("Looking to visualize the resonation of strings in the infinite scale infinite variation dimension, with a mathematical basis, it’s an easy go i’d highly suggest. ‘Just’ look at each symmetric combinational element (1 and 8 in base 9) as infinite length string moving in opposite directions operating on the base (9 in this case).")

#text("like so:")

#link("http://nimbusgear.files.wordpress.com/2007/04/bookofmath_04_quantumstring.jpg")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://nimbusgear.files.wordpress.com/2007/04/bookofmath_04_quantumstring.jpg?w=490")[Original image]]]]

#link("http://nimbusgear.files.wordpress.com/2007/04/bookofmath_19_morequantabases.jpg")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://nimbusgear.files.wordpress.com/2007/04/bookofmath_19_morequantabases.jpg?w=490")[Original image]]]]

#text("my apologies if this is too basic of a metaphor, the exponential version of this symmetric alignment in bases is more group theory:")

#link("http://mathworld.wolfram.com/ModuloMultiplicationGroup.html")[#text("http://mathworld.wolfram.com/ModuloMultiplicationGroup.html")]

#text("Which brings me to a question for you guys..")

#text("Given the multitude of possible dimensions, even theoretical wackyness like basic physical constants changing in different origination conditions.. are we being limited in our ability to comprehend metaphor and properly form mathematical precision concepts, simply because of our physical universes’ properties?")

#text("Like, are we in any way limited by the neurological physicality of our existence in perceiving ‘really easy, obvious’ things?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-10409")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2007")])]

#text("Dear Yuri: It is not difficult to adapt the crossing number inequality to surfaces of higher genus g; one simply replaces Euler’s formula |V|-|E|+|F|=2 with the more general |V|-|E|+|F|=2-2g. One gets essentially the same inequality at the end (with some changes in constants) as long as |E| > 4 g (say). If instead |E| = O(g) then one basically has no non-trivial lower bound on the crossing number.")

#text("Dear all: the conversation here may be interesting, but it is now veering significantly off topic, being more physics and metaphysics than mathematics. Perhaps one of the participants would like to start a blog posting elsewhere dedicated to these topics, and link back here?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-10455")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2007")])]

#text("I don’t think we are as limited in our ability to comprehend metaphor")#linebreak()#text(" as it seems. To properly form precision concepts, we need a better")#linebreak()#text(" collaborative effort between hard sciences. E.g., it would be nice to")#linebreak()#text(" see mathematicians spend more time checking compatibilities between")#linebreak()#text(" various intuitive physical theories, as often this requires soft “analysis”")#linebreak()#text(" “threading a needle” thinking (to me, hard “analysis” is putting")#linebreak()#text(" together big structures, e.g., the textbook one line argument in")#linebreak()#text(" which Yukawa predicted the mass of the pi meson mediating the")#linebreak()#text(" strong nuclear force, using just the uncertainty principle and E=mc^2).")#linebreak()#text(" Instead, they often spend time dueling in joint works, which can last")#linebreak()#text(" many rounds (e.g., the longest I went through was 5).")#linebreak()#text(" As for our perceiving `really easy, obvious’ things, I also don’t think")#linebreak()#text(" we are that limited by our neurological physicality. E.g., the Aborigines")#linebreak()#text(" had the philosophy of living in harmony with the vibrations of the Earth.")#linebreak()#text(" A somewhat similar idea was later used in Lovelock’s Gaia theory (e.g.,")#linebreak()#text(" Gaia: A New Look at Life on Earth, Oxford University Press , 2000),")#linebreak()#text(" an exceptionally deep and logical explanation of processes that go")#linebreak()#text(" on in the atmosphere and the oceans. The author, however, keeps")#linebreak()#text(" mum on what goes on in the core, and doesn’t use the variational")#linebreak()#text(" termodynamics assumption of interacting complexes, which would")#linebreak()#text(" hint at a modern philosophy more compatible with Greek myths.")#linebreak()#text(" I suggest we move the off-topics discussions to:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/")[#text("Another advice page, and an open thread")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90fdb1bd4d15f572efec35fa286de980ea7ce5e0b6742ae2869a3a9971445f1e-293dd9203dbf167d17c222b9afc4a61570f16295d6865e4bb4f503ce61b2315c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yury")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-10470")[#strong[#text("yury")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2007")])]

#text("Dear Terence: I was actually wondering about the upper bound. That is, if we know that a graph can be embedded in a torus, is it true that it can also be drawn on a plane without too many intersections?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-10483")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2007")])]

#text("That’s an interesting problem. If one takes the periodic lattice ")#mi("(\\frac{1}{N}{\\Bbb Z})^2 / {\\Bbb Z}^2")#text(" in the torus ")#mi("{\\Bbb R}^2/{\\Bbb Z}^2")#text(" and connects all adjacent vertices, one gets a graph embedded in the torus with ")#mi("O(N^2)")#text(" vertices and ")#mi("O(N^2)")#text(" edges, and no crossings. If one naively tries to draw this graph in the plane it seems that one needs roughly ")#mi("N^2")#text(" crossings, though I have not tried to prove this rigorously. (One might try counting how many K_5 and K_{3,3} subdivisions are contained in this graph, perhaps, to get some useful lower bound.) My conjecture is that this is the worst case, i.e. that any torus-planar graph can be embedded in the plane with only O(|E|) crossings. I don’t see how to prove this, though it vaguely has a “min-cut” flavour to it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-11267")[#strong[#text("Carnival of Math #18 « JD2718")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2007")]

#text("[…] The Crossing Number Inequality Graph Theory “Today I’d like to discuss a beautiful inequality in graph theory, namely the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5536e2ed5c1fa87e54776ade5c0361da235581bd08d9265280e5bf61c2141ed-12b84bee07fb83b2ffe132e11959371bef82c8c3b1a80d1c8030af90cbdec6dc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. Eppstein")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-11275")[#strong[#text("D. Eppstein")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2007")])]

#text("yury: see Wood and Telle, “Planar Decompositions and the Crossing Number of Graphs with an Excluded Minor”, arXiv:math.CO/0604467. It follows from their results that, if a graph can be embedded on a torus and it has bounded vertex degree, then it can be embedded in the plane with a linear number of crossings.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rolf Bardeli")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-11760")[#strong[#text("Rolf Bardeli")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2007")])]

#text("Dear Terence,")

#text("this article is absolutely lovely.")

#text("Could you give some details or a pointer to the literature as to what is meant by “using some analytic number theory to control the size of A*A”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-11927")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2007")])]

#text("Dear Rolf,")

#text("The recent article")

#link("http://front.math.ucdavis.edu/0607.5473")[#text("http://front.math.ucdavis.edu/0607.5473")]

#text("discusses the problem and gives some pointers to the literature. Basically, one needs a lot of (fairly standard) multiplicative estimates about the primes, such as the prime number theorem, and more generally the distribution of integers which are the product of k prime factors.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b82bf046c7e11accbfe3c4faaf4b8a21024b332d8287462b2b7144ee1e82acf-b75b8fc7a8eb889ba79c35fbbe6b841349d874675810116eac900d74ae56ff98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Samal")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-14915")[#strong[#text("Robert Samal")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2007")])]

#text("yury: Regarding the crossing number of a “toroidal” graph: The bounded degree")#linebreak()#text(" condition mentioned by D. Eppstein is necessary. To see this, take any")#linebreak()#text(" graph that embeds on the torus, but not on the plane (e.g. $K_5$). Then")#linebreak()#text(" replace every edge by k parallel edges (or paths, if you prefer simple graphs).")#linebreak()#text(" The graph will have O(k) edges, but the crossing number is $k^2$.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-31210")[#strong[#text("Extermal Combinatorics II: Some Geometry and Number Theory « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2008")]

#text("[…] the surprising connections that were found between the above problems. There is also a very nice post about this material on Terry Tao’s blog. To show you something new I will describe a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-32967")[#strong[#text("Lecture 5: Uniformizing graphs, multi-flows, and eigenvalues « tcs math - some mathematics of theoretical computer science")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2008")]

#text("[…] needed. The beautiful probabilistic proof of Chazelle, Sharir, and Welzl (see the exposition on Terry Tao’s blog) can be appropriately generalized to excluded-minor graphs, and even to families of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a8f42791831643275eaac45801facbf3154bb17428d1d82cdcc258c7c61ce29-97465f1e4eed3bfaad1deb39de9f6e1ccb360cae916cca78805b7f5d4fb52bfa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Serge")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-33458")[#strong[#text("Serge")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2008")])]

#text("I have established the existence of graphs with crossing number at most 11g but genus equal to g, for every g>=1. It does not look tight. So, do you know tighter series?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Szemerédi-Trotter theorem and the cell decomposition « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-39389")[#strong[#text("The Szemerédi-Trotter theorem and the cell decomposition « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2009")])]

#text("[…] proof of the Szemerédi-Trotter theorem is via the crossing number inequality (as discussed in this previous post), which ultimately relies on Euler’s famous formula ; thus in this argument it is topology […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcb7765dcebcb66b358418fd292f07b386c0a7291a90aeb9f6bca628bfb97942-d37902696adeaffae267d8a41e7d46cff565608798c847245651b7b074aca171.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spencer")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-39445")[#strong[#text("Spencer")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2009")])]

#text("Dear Terence,")

#text("The link which purports to be to one of Gowers’ papers to do with pseudorandomness/probabilistic methods seems to be sending me to his ‘Two Cultures’ Essay.")

#text("To which of his papers was the link intended to point?")

#text("Many Thanks,")

#text("Spencer")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcb7765dcebcb66b358418fd292f07b386c0a7291a90aeb9f6bca628bfb97942-d37902696adeaffae267d8a41e7d46cff565608798c847245651b7b074aca171.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spencer")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-39446")[#strong[#text("Spencer")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2009")])]

#text("Yep, just realised that perhaps you do mean this essay!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d75c1e506dc65356d0041c9ba11820cec5bd9dc4f51b1bfa0b6c26aa39d6149-4bb23d56be5f0bf17292f32542c2eca8123dbf53855b965bdefda6353bbcc15c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Kahle")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-45852")[#strong[#text("Matthew Kahle")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")])]

#text("I struggled for a minute trying to understand why each line was incident to ")#tao-math("\\left|A\\right|", block: false)#text(" points in Elekes’ argument. Finally I think I understand: ")#mi("P")#text(" should probably be ")#mi("(A \\cdot A) \\times (A +A)")#text(" rather than ")#mi("(A + A) \\times (A \\cdot A)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Guth-Katz bound on the Erdős distance problem « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-48202")[#strong[#text("The Guth-Katz bound on the Erdős distance problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2010")])]

#text("[…] random projection argument. This theorem can be proven by crossing number methods (as discussed in this previous blog post) or by cell decomposition (as discussed in this previous blog post). In both cases, the order […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e22ee564efac8cf668d35d58dec8ad9cea573e4019d2dbc3054a6d98de8e195-0068d51fc572c1a71ce48ff302651dc502b71f83abd245166d5930c81f73ccd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JamesL")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-49493")[#strong[#text("JamesL")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2011")])]

#text("It does not seem that setting A={1,2,…,N} gives the claimed exponential dependence in the lower bound. Ford’s result suggests that |A A| ~ N^2/(log N)^{0.08…}.")

#text("The paper of Erdos and Szmeredi uses a different construction:")

#link("http://193.224.79.1/~p_erdos/1983-18.pdf")[#text("Click to access 1983-18.pdf")]

#text("In particular, Solymosi proves that if |A+A| = O(|A|) then |A \\times A| is at least |A|^2/log |A|.")

#emph[#text("[Hmm, good point. I’ve deleted the relevant remark.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e139ebf8f1f5c0bb6b5cfe832b3698974f6b66567adf048ddf6057bac3dc1750-698e055189fb562346d431ad1537a1204972466a939afd88141ce9ebd2f5e024.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dion, Tobias and Tony")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-49593")[#strong[#text("Dion, Tobias and Tony")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2011")])]

#text("Dear Terry,")

#text("While reading your proof of the crossing number inequality we were quite puzzled by the")#linebreak()#text(" inequality")

#text("$p^4 \\hbox{cr}(G) \\geq p^2|E| – 3p |V| + 6$.")

#text("Surely this cannot hold for all $0< p < 1$. If $p$ is sufficiently small then the LHS is about 0 while the RHS is about 6.")#linebreak()#text(" After some discussions we decided that the explanation is that the inequality")

#text("$|E| \\leq 3|V| – 6$,")

#text("is not true for all planar graphs (and consequently (**) $\\hbox{cr}(G) \\geq |E|-3|V|+6$ is not valid for all graphs).")#linebreak()#text(" Counterexamples are the empty graph, the isolated vertex, and the edge.")#linebreak()#text(" This means that you cannot just use linearity of expectations to get")

#text("${\\Bbb E}(\\hbox{cr}(G'))\\geq {\\Bbb E}(|E'|)-3{\\Bbb E}(|V'|)+6$")

#text("since, for all $0<p<1$, there is a positive chance the inequality (**) is violated.")#linebreak()#text(" An easy fix is to use start from the inequality $\\hbox{cr}(G) \\geq |E|-3|V|$, which is valid for all graphs.")

#text("cheers")

#text("Dion, Tobias and Tony")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-49594")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2011")])]

#text("Thanks for the correction!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Szemeredi-Trotter theorem via the polynomial ham sandwich theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-50315")[#strong[#text("The Szemeredi-Trotter theorem via the polynomial ham sandwich theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2011")])]

#text("[…] theorem has many short existing proofs, including one via crossing number inequalities (as discussed in this previous post) or via a slightly different type of cell decomposition (as discussed here). The proof given below […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-135652")[#strong[#text("On Endre Szemerédi’s Gifts to Computer Science « Windows On Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2012")]

#text("[…] very simple “book proof” (that indeed can be found in page 285 of the book, see also here) was given by Noam Elkies. The proof outline is that, assuming otherwise, one considers the points […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-137787")[#strong[#text("Lecture 6 | ASGT")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2012")]

#text("[…] Here are the , and here’s a proof of the crossing number inequality. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7d33eda86b7bbd80ca7e2624f4a6b7db4a8352cdcf008dea241c1c8167ff8790-2f1c5dc543b3202bf520d9f0ec11f84264b9b3d05cb8b9d56e255ceac5500300.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David P. Moulton")]], [#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/comment-page-1/#comment-199419")[#strong[#text("David P. Moulton")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2012")])]

#text("Hi Terry.")

#text("Okay, this post was five years ago, and I just found it, but no one seems to have noticed a little error in something you said.")

#text("You said that to optimise the choice of p for the inequality")

#text("\\hbox{cr}(G) \\geq p^{-2} |E| – 3 p^{-3} |V|")

#text("you have to solve a cubic. But setting the derivative of the RHS")#linebreak()#text(" by p to 0 easily yields p = 9|V| / 2|E| and gives the optimal (for this technique) bound")

#text("\\hbox{cr}(G) \\geq \\frac{4|E|^3}{243 |V|^2} whenever |E| \\geq 9|V|/2.")

#text("Thanks for the nice article–I might have to check out more of your blog!")

#text("David")

#emph[#text("[I’ve edited the text accordingly. There was a ")#mi("6p^{-4}")#text(" term that was omitted previously, explaining the comment about the cubic. – T.]")]
]
