// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/01/07/mean-field-equations/
// Converted to Typst by tao2typ: "2026-10-14T15:17:36.007440+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mean field games", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mean field games")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 January 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/")[#text("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This week at UCLA, ")#link("http://en.wikipedia.org/wiki/Pierre-Louis_Lions")[#text("Pierre-Louis Lions")]#text(" gave one of this year’s ")#link("http://www.math.ucla.edu/dls/index.shtml")[#text("Distinguished Lecture Series")]#text(", on the topic of ")#emph[#text("mean field games")]#text(". These are a relatively novel class of systems of partial differential equations, that are used to understand the behaviour of multiple agents each individually trying to optimise their position in space and time, but with their preferences being partly determined by the choices of all the other agents, in the asymptotic limit when the number of agents goes to infinity. A good example here is that of traffic congestion: as a first approximation, each agent wishes to get from A to B in the shortest path possible, but the speed at which one can travel depends on the density of other agents in the area. A more light-hearted example is that of a ")#link("http://en.wikipedia.org/wiki/Audience_wave")[#text("Mexican wave")]#text(" (or audience wave), which can be modeled by a system of this type, in which each agent chooses to stand, sit, or be in an intermediate position based on his or her comfort level, and also on the position of nearby agents.")

#text("Under some assumptions, mean field games can be expressed as a coupled system of two equations, a ")#link("http://en.wikipedia.org/wiki/Fokker%E2%80%93Planck_equation")[#text("Fokker-Planck")]#text(" type equation evolving forward in time that governs the evolution of the density function ")#mi("{m}")#text(" of the agents, and a ")#link("http://en.wikipedia.org/wiki/Hamilton-Jacobi_equation")[#text("Hamilton-Jacobi")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Hamilton%E2%80%93Jacobi%E2%80%93Bellman_equation")[#text("Hamilton-Jacobi-Bellman")]#text(") type equation evolving ")#emph[#text("backward")]#text(" in time that governs the computation of the optimal path for each agent. The combination of both forward propagation and backward propagation in time creates some unusual “elliptic” phenomena in the time variable that is not seen in more conventional evolution equations. For instance, for Mexican waves, this model predicts that such waves only form for stadiums exceeding a certain minimum size (and this phenomenon has apparently been confirmed experimentally!).")

#text("Due to lack of time and preparation, I was not able to transcribe Lions’ lectures in full detail; but I thought I would describe here a heuristic derivation of the mean field game equations, and mention some of the results that Lions and his co-authors have been working on. (Video of a related series of lectures (in French) by Lions on this topic at the Collége de France is available ")#link("http://www.college-de-france.fr/default/EN/all/equ_der/index.htm")[#text("here")]#text(".)")

#text("To avoid (rather important) technical issues, I will work at a heuristic level only, ignoring issues of smoothness, convergence, existence and uniqueness, etc.")

#metadata(none) <tao-92d3abbc9113f6835f52>

#heading(level: 1)[#strong[#text(" — 1. Hamilton-Jacobi-Bellman equations — ")]]

#text("Before considering mean field games, let us consider a more classical problem in calculus of variations, namely that of a single agent trying to optimise his or her path in spacetime with respect to a fixed cost function to minimise against. (One could also reverse the sign here, and maximise a ")#link("http://en.wikipedia.org/wiki/Utility")[#text("utility function")]#text(" rather than minimise a cost function; mathematically, there is no distinction between the two. (A half-empty glass is mathematically equivalent to a half-full one.))")

#text("Specifically, suppose that an agent is at some location ")#mi("{x(0)}")#text(" at time ")#mi("{t=0}")#text(" in some ambient domain (which, for simplicity, we shall take to be a Euclidean space ")#mi("{{\\bf R}^d}")#text("), and would like to end up at some better location ")#mi("{x(T)}")#text(" at a later time ")#mi("{t=T>0}")#text(". To model this, we imagine that each location ")#mi("{x}")#text(" in the domain ")#mi("{{\\bf R}^d}")#text(" has some ")#emph[#text("cost")]#text(" ")#mi("{u(T,x) \\in {\\bf R}}")#text(" at this final time ")#mi("{T}")#text(", which is small when ")#mi("{x}")#text(" is a desirable location and large otherwise, so that the agent would like to minimise ")#mi("{u(T,x(T))}")#text(". (In the traffic problem, one may wish to be at a given location ")#mi("{B}")#text(" by time ")#mi("{T}")#text(", or failing that, on some location close to ")#mi("{B}")#text(", or perhaps at some secondary backup location in case ")#mi("{B}")#text(" is too inaccessible due to traffic; so the cost function may have a global minimum at ")#mi("{B}")#text(" but perhaps also have local minima elsewhere.)")

#text("If transportation was not a problem, this is an easy problem to solve: one simply finds the value of ")#mi("{x(T)}")#text(" that minimises ")#mi("{u(x(T))}")#text(", and the agent takes an arbitrary path (e.g. a constant velocity straight line path) from ")#mi("{x(0)}")#text(" at time ")#mi("{t=0}")#text(" to ")#mi("{x(T)}")#text(" at time ")#mi("{t=T}")#text(".")

#text("But now suppose that there is a transportation cost in addition to the cost of the final location – for instance, moving at too fast a velocity may incur an energy cost. To model this, we introduce a ")#emph[#text("velocity cost function")]#text(" ")#mi("{C: {\\bf R}^d \\rightarrow {\\bf R}}")#text(", where ")#mi("{C(v) dt}")#text(" measures the marginal cost of moving at a given velocity ")#mi("{v}")#text(" for time ")#mi("{dt}")#text(", and then define the ")#emph[#text("total cost")]#text(" of a trajectory ")#mi("{x: [0,T] \\rightarrow {\\bf R}^d}")#text(" by the formula ")#metadata(none) <tao-708919008a22125afc2c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("u(T, x(T)) + \\int_0^T C(x^{\\prime}(t))\\ dt.")]]

#text("The goal now is to select a trajectory that minimises this total cost. This is a simplified model, in which cost depends only on velocity and not on position and time; one could certainly consider more complicated cost functions ")#mi("{C(v,x,t)}")#text(" which depend on these parameters, in which case the ")#mi("{C(x^{\\prime}(t))}")#text(" term above would have to be replaced with ")#mi("{C(x^{\\prime}(t),x(t),t)}")#text(", but let us work with the above simplified model for the current discussion.")

#text("A model example of a cost function ")#mi("{C}")#text(" is a quadratic cost function ")#tao-math("{C(v) = \\frac{1}{2} \\left|v\\right|^2}", block: false)#text(" (other normalising factors than ")#mi("{\\frac{1}{2}}")#text(" can of course be used here). Thus one is penalised for moving too fast, or for “wasting” velocity by zig-zagging back and forth. In such a situation, the agent should move in a straight line at constant velocity to a location ")#mi("{x(T)}")#text(" with relatively low final cost ")#mi("{u(x(T))}")#text(" but which is also reasonably close to the original position ")#mi("{x(0)}")#text("; the global minimum for the final cost ")#mi("{u}")#text(" may no longer be the best place to shoot for, as it may be so far away that the transportation cost exceeds whatever cost savings one gets from the final cost.")

#text("More generally, it is natural to choose ")#mi("{C}")#text(" to be ")#emph[#text("convex")]#text(" – thus, for instance, given two velocities ")#mi("{v}")#text(" and ")#mi("{w}")#text(", ")#mi("{C(\\frac{v+w}{2})}")#text(" should be less than or equal to the average of ")#mi("{C(v)}")#text(" and ")#mi("{C(w)}")#text(". The reason for this is that one can effectively “simulate” a velocity of ")#mi("{\\frac{v+w}{2}}")#text(" by zig-zagging between velocities ")#mi("{v}")#text(" and velocities ")#mi("{w}")#text(", and so (assuming infinite maneuverability) one can always travel at an effective velocity of ")#mi("{\\frac{v+w}{2}}")#text(" at a mean cost of ")#mi("{\\frac{C(v)+C(w)}{2}}")#text(".")

#text("To avoid some technical issues, we will assume ")#mi("{C}")#text(" to be ")#emph[#text("strictly")]#text(" convex, and to make the formulae slightly nicer we will also assume that ")#mi("{C}")#text(" is even, thus ")#mi("{C(-v)=C(v)}")#text(".")

#text("One way to compute the optimal trajectory here is to solve the ")#link("http://en.wikipedia.org/wiki/Euler%E2%80%93Lagrange_equation")[#text("Euler-Lagrange equation")]#text(" associated to ")#link(<tao-708919008a22125afc2c>)[#text("(1)")]#text(", with the boundary condition that the initial position ")#mi("{x(0)}")#text(" is fixed. This is an ODE for ")#mi("{x(t)}")#text(" which can be solved by a variety of methods. But there is another approach, based on solving a PDE rather than an ODE, and which conveys more information about the solution (such as the dependence on the initial position). The idea is to generalise the initial time from ")#mi("{0}")#text(" to any other time ")#mi("{t_0}")#text(" between ")#mi("{0}")#text(" and ")#mi("{T}")#text(". More precisely, given any ")#mi("{0 \\leq t_0 \\leq T}")#text(" and ")#mi("{x_0 \\in {\\bf R}^d}")#text(", define the ")#emph[#text("optimal cost")]#text(" ")#mi("{u(t_0,x_0)}")#text(" at the point ")#mi("{(t_0,x_0)}")#text(" in spacetime to be the infimum of the cost")

#align(center)[#tao-fit-display[#mitex("u(T, x(T)) + \\int_{t_0}^T C(x^{\\prime}(t))\\ dt")]]

#text("over all (smooth) paths ")#mi("{x: [t_0,T] \\rightarrow {\\bf R}^d}")#text(" starting at ")#mi("{x(t_0) = x_0}")#text(" and with an arbitrary endpoint ")#mi("{x(T)}")#text(". Informally, this is the cost the agent would place on being at position ")#mi("{x_0}")#text(" at time ")#mi("{t_0}")#text(".")

#text("By definition, when ")#mi("{t_0 = T}")#text(", the optimal cost at ")#mi("{x_0}")#text(" coincides with the final cost at ")#mi("{x_0}")#text(", which justifies using the same symbol ")#mi("{u}")#text(" to denote both. The final cost ")#mi("{u(T,\\cdot)}")#text(" can thus be viewed as a ")#emph[#text("boundary condition")]#text(" for the optimal cost.")

#text("But what happens for times ")#mi("{t_0}")#text(" less than ")#mi("{T}")#text("? It turns out that (under some regularity hypotheses, which I will not discuss here) the optimal cost function ")#mi("{u}")#text(" obeys a partial differential equation, known as the ")#link("http://en.wikipedia.org/wiki/Hamilton-Jacobi-Bellman_equation")[#text("Hamilton-Jacobi-Bellman equation")]#text(", which we shall heuristically derive (using infinitesimals as an informal tool) as follows.")

#text("Imagine that the agent finds herself or himself at position ")#mi("{x_0}")#text(" at some time ")#mi("{t_0 < T}")#text(", and is deciding where to go next. Presumably there is some optimal velocity ")#mi("{v}")#text(" in which the agent should move in (")#emph[#text("a priori")]#text(", this velocity need not be unique). So, if ")#mi("{dt}")#text(" is an infinitesimal time, the agent should move at this velocity for time ")#mi("{dt}")#text(", ending up at a new position ")#mi("{x_0+vdt}")#text(" at time ")#mi("{t_0+dt}")#text(", and incurring a travel cost of ")#mi("{C(v) dt}")#text(". At this point, the optimal cost for the remainder of the agent’s journey is given by ")#mi("{u(t_0+dt,x_0+vdt)}")#text(", by definition of ")#mi("{u}")#text(". This leads to the heuristic formula ")#metadata(none) <tao-c073787b94ea6779f630>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("u(t_0,x_0) = u(t_0+dt,x_0+vdt) + C(v) dt")]]

#text("which on Taylor expansion (and omitting higher order terms) gives")

#align(center)[#tao-fit-display[#mitex("u(t_0,x_0) = u(t_0,x_0) + dt [ \\partial_t u(t_0,x_0) + v \\cdot \\nabla_x u(t_0,x_0) + C(v) ].")]]

#text("On the other hand, ")#mi("{v}")#text(" is being chosen to minimise the final cost. Thus we see that ")#mi("{v}")#text(" should be chosen to minimise the expression")

#align(center)[#tao-fit-display[#mitex("v \\cdot \\nabla_x u(t_0,x_0) + C(v).")]]

#text("Note from the strict convexity that this minimum ")#mi("{v}")#text(" will be unique, and will be some function of ")#mi("{\\nabla_x u(t_0,x_0)}")#text(". If we introduce the ")#link("http://en.wikipedia.org/wiki/Legendre_transformation")[#text("Legendre transform")]#text(" ")#mi("{H: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" of ")#mi("{C: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("H(p) := \\sup_{v \\in {\\bf R}^d} v \\cdot p - C(v)")]]

#text("then the minimal value of ")#mi("{v \\cdot \\nabla_x u(t_0,x_0) + C(v)}")#text(" is just ")#mi("{-H(\\nabla_x u(t_0,x_0))}")#text(" (here we use the hypothesis that ")#mi("{C}")#text(" is even). We conclude that")

#align(center)[#tao-fit-display[#mitex("u(t_0,x_0) = u(t_0,x_0) + dt [ \\partial_t u(t_0,x_0) - H(\\nabla_x u(t_0,x_0)]")]]

#text("leading to the ")#link("http://en.wikipedia.org/wiki/Hamilton%E2%80%93Jacobi%E2%80%93Bellman_equation")[#text("Hamilton-Jacobi-Bellman equation")]

#align(center)[#tao-fit-display[#mitex("-\\partial_t u + H(\\nabla_x u) = 0.")]]

#text("Note that this equation is being solved ")#emph[#text("backwards")]#text(" in time, as the optimal cost is prescribed at the final time ")#mi("{t=T}")#text(", but we are interested in its value at earlier times, and in particular when ")#mi("{t=0}")#text(".")

#text("Once one solves this equation, one can work out the optimal velocity ")#mi("{v = v(x_0,t_0)}")#text(" to travel at each location ")#mi("{(x_0,t_0)}")#text(". Indeed, from the above discussion we know that ")#mi("{v}")#text(" is to minimise the expression")

#align(center)[#tao-fit-display[#mitex("v \\cdot \\nabla_x u(t_0,x_0) + C(v),")]]

#text("and thus ")#mi("{\\tilde v := -v}")#text(" maximises the expression")

#align(center)[#tao-fit-display[#mitex("\\tilde v \\cdot p - C(\\tilde v)")]]

#text("where ")#mi("{p := \\nabla_x u(t_0,x_0)}")#text(". By definition, the value of this expression is equal to ")#mi("{H(p)}")#text(":")

#align(center)[#tao-fit-display[#mitex("H(p) = \\tilde v \\cdot p - C(\\tilde v).")]]

#text("We can view ")#mi("{\\tilde v}")#text(" as a function of ")#mi("{p}")#text(". As ")#mi("{\\tilde v}")#text(" maximises this expression for fixed ")#mi("{p}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial}{\\partial \\tilde v} ( \\tilde v \\cdot p - C(\\tilde v) ) = 0.")]]

#text("Applying the chain rule, we conclude that")

#align(center)[#tao-fit-display[#mitex("H^{\\prime}(p) = \\tilde v")]]

#text("and so the correct velocity to move in is given by ")#metadata(none) <tao-513f0cf2d1541434b341>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("v = - H^{\\prime}( \\nabla_x u ).")]]

#text("Now let us make things a little more interesting by adding some random noise. Suppose that the agent’s steering mechanism is subject to a little bit of fluctuation, so that if the agent wishes to get from ")#mi("{x_0}")#text(" to ")#mi("{x_0+vdt}")#text(" in time ")#mi("{dt}")#text(", the agent instead ends up at ")#mi("{x_0 + vdt + \\sigma dB_t}")#text(", where ")#mi("{dB_t}")#text(" is the infinitesimal of a standard ")#link("http://en.wikipedia.org/wiki/Brownian_motion")[#text("Brownian motion")]#text(" in ")#mi("{{\\bf R}^d}")#text(", and ")#mi("{\\sigma > 0}")#text(" is a parameter measuring the noise level. With this stochastic model, the total cost is now a stochastic quantity rather than a deterministic one, and so the rational thing for the agent to do now is to minimise the ")#emph[#text("expectation")]#text(" of the cost. Here we begin to see an advantage of the Hamilton-Jacobi approach over the Euler-Lagrange approach; while the latter approach becomes quite complicated technically in the presence of stochasticity, the former approach carries over without much difficulty. Indeed, we can define the optimal (expected) cost function ")#mi("{u(t_0,x_0)}")#text(" much as before, as the minimal expected cost over all strategies of the agent; this is a deterministic function due to the taking of expectations. The equation ")#link(<tao-c073787b94ea6779f630>)[#text("(2)")]#text(" is now modified to")

#align(center)[#tao-fit-display[#mitex("u(t_0,x_0) = {\\bf E} u(t_0+dt,x_0+vdt + \\sigma d B_t) + C(v) dt.")]]

#text("We Taylor expand this, using the ")#link("http://en.wikipedia.org/wiki/Ito's_formula")[#text("Ito’s formula")]#text(" heuristic ")#mi("{dB_t = O(dt^{1/2})}")#text(" to obtain")

#tao-aligned(keep: true)[


#tao-math("u(t_0,x_0)  & = {\\bf E} u(t_0,x_0) + \\partial_t u_0(t_0,x_0) dt + v \\cdot \\nabla_x u_0(t_0,x_0) dt", block: true)



#tao-math(" & + \\sigma dB_t \\cdot \\nabla_x u_0(t_0,x_0) + \\frac{\\sigma^2}{2} \\nabla^2 u(t_0,x_0)(d B_t,d B_t) + C(v) dt.", block: true)
]

#text("Now, Brownian motion ")#mi("{dB_t}")#text(" over time ")#mi("{dt}")#text(" has zero expectation, and each of the ")#mi("{d}")#text(" components has a variance of ")#mi("{dt^2}")#text(" (and the covariances are zero). As such, we can compute the expectation here and obtain")

#tao-aligned(keep: true)[


#tao-math("u(t_0,x_0)  & = u(t_0,x_0) + \\partial_t u_0(t_0,x_0) dt + v \\cdot \\nabla_x u_0(t_0,x_0) dt", block: true)



#tao-math(" & + \\frac{\\sigma^2}{2} \\Delta u(t_0,x_0) dt + C(v) dt.", block: true)
]

#text("So the only effect of the noise is to add an additional term ")#mi("{\\frac{\\sigma^2}{2} \\Delta u(t_0,x_0) dt}")#text(" to the right-hand side. This term does not depend on ")#mi("{v}")#text(" and so does not affect the remainder of the analysis; at the end of the day, one obtains the ")#emph[#text("viscous Hamilton-Jacobi-Bellman equation")]

#align(center)[#tao-fit-display[#mitex("-\\partial_t u - \\nu \\Delta u + H(\\nabla_x u) = 0")]]

#text("for the optimal expected cost, where ")#mi("{\\nu := \\frac{1}{2} \\sigma^2}")#text(" is the viscosity, and the optimal velocity is still given by the formula ")#link(<tao-513f0cf2d1541434b341>)[#text("(3)")]#text(". This can be viewed as a nonlinear backwards heat equation, which makes sense since we are solving for this cost backwards in time. The diffusive effect of the heat equation then reflects the uncertainty of future cost caused by the random noise. (A similar diffusive effect appears in the ")#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/")[#text("Black-Scholes equation")]#text(" for pricing options, for much the same reason.)")

#heading(level: 1)[#strong[#text(" — 2. Fokker-Planck equations — ")]]

#text("Now suppose that instead of having just one agent, one has a huge number ")#mi("{N}")#text(" of agents distributed throughout space. To simplify things, let us assume that the agents all have identical motivations (in particular, they are all trying to minimise the same cost function), which implies in particular that all the agents at a given point ")#mi("{(t_0,x_0)}")#text(" in spacetime will all move in a given velocity ")#mi("{v(t_0,x_0)}")#text(" (let us ignore the random noise for this initial discussion).")

#text("Rather than deal with each of the agents separately, we will pass to a continuum limit ")#mi("{N \\rightarrow \\infty}")#text(" and consider just the (normalised) density function ")#mi("{m(t,x)}")#text(" of the agents, which is a non-negative function with total mass ")#mi("{\\int_{{\\bf R}^d} m(t,x)\\ dx = 1}")#text(" for each time ")#mi("{t}")#text(". Informally, for an infinitesimal box in space ")#mi("{[x,x+dx]}")#text(", the number of agents in that box should be approximately ")#tao-math("{N m(t,x) \\left|dx\\right|}", block: false)#text(".")

#text("We now suppose that the velocity field ")#mi("{v}")#text(" is given to us, as well as the initial distribution ")#mi("{m(0,x)}")#text(" of the agents, and ask how the distribution will evolve as time goes forward. There are several ways to find the answer, but we will take a ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("distributional")]#text(" viewpoint and test the density ")#mi("{m(t,x)}")#text(" against various ")#emph[#text("test functions")]#text(" ")#mi("{F(x)}")#text(" – smooth, compactly supported functions of space (independent of time). The integral ")#mi("{\\int_{{\\bf R}^d} m(t,x) F(x) \\ dx}")#text(" can be viewed as the continuum limit of the sum ")#mi("{\\frac{1}{N} \\sum_{i=1}^N F(x_i(t))}")#text(", where ")#mi("{x_i(t)}")#text(" is the location of the ")#mi("{i^{th}}")#text(" agent at time ")#mi("{t}")#text(".")

#text("Let us see how this integral should vary in time. At time ")#mi("{t}")#text(", the ")#mi("{i^{th}}")#text(" agent should move at velocity ")#mi("{v(t,x_i(t))}")#text(". Differentiating both sides of")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} m(t,x) F(x)\\ dx \\approx \\frac{1}{N} \\sum_{i=1}^N F(x_i(t))")]]

#text("using the chain rule, we thus arrive at the heuristic formula")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} \\partial_t m(t,x) F(x)\\ dx \\approx \\frac{1}{N} \\sum_{i=1}^N v(t,x_i(t)) \\cdot \\nabla F(x_i(t)).")]]

#text("The right-hand side, in the continuum limit ")#mi("{N \\rightarrow \\infty}")#text(", should become")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} m(t,x) (v(t,x) \\cdot \\nabla F(x))\\ dx")]]

#text("which, after an integration by parts, becomes")

#align(center)[#tao-fit-display[#mitex("- \\int_{{\\bf R}^d} \\nabla\\cdot (mv)(t,x) F(x)\\ dx.")]]

#text("To summarise, for every test function ")#mi("{F}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} (\\partial_t m(t,x) + \\nabla\\cdot (mv)(t,x)) F(x)\\ dx = 0")]]

#text("which leads to the ")#link("http://en.wikipedia.org/wiki/Advection_equation")[#text("advection equation")]

#align(center)[#tao-fit-display[#mitex("\\partial_t m(t,x) + \\nabla\\cdot (mv)(t,x) = 0.")]]

#text("Now let us reintroduce the same random noise model that we considered in the previous section. Thus, of all the agents that are infinitesimally close to ")#mi("{x}")#text(" at time ")#mi("{t}")#text(", they will all try to move to ")#mi("{x+vdt}")#text(" at time ")#mi("{t+dt}")#text(", but instead each one ends up at a slightly different location ")#mi("{x+vdt+\\sigma dB_t}")#text(", where the Brownian path ")#mi("{dB_t}")#text(" is different for each agent. As such, we are led to the heuristic equation")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} m(t+dt,x) F(x)\\ dx \\approx \\frac{1}{N} \\sum_{i=1}^N F(x_i(t) + v(t,x_i(t)) dt + \\sigma dB_t).")]]

#text("Taylor expanding the right-hand side as before, and then passing to the continuum limit, we eventually see that the right-hand side takes the form")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} m(t,x) (F(x) + v dt \\cdot \\nabla F(x) + \\frac{\\sigma^2}{2} \\Delta F(x) dt)\\ dx")]]

#text("and then repeating the above computations leads us to the ")#link("http://en.wikipedia.org/wiki/Fokker%E2%80%93Planck_equation")[#text("Fokker-Planck equation")]#text(" ")#metadata(none) <tao-5aef96240bca5582e6fd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\partial_t m(t,x) - \\nu \\Delta m(t,x) + \\nabla \\cdot (mv)(t,x) = 0")]]

#text("with ")#mi("{\\nu := \\sigma^2/2}")#text(".")

#heading(level: 1)[#strong[#text(" — 3. Mean field games — ")]]

#text("In the derivation of the Hamilton-Jacobi-Bellman equations above, each agent had a fixed cost function to minimise, that did not depend on the location of the other agents. A ")#emph[#text("mean field game")]#text(" generalises this model, by allowing the cost function of each agent to also depend on the density function ")#mi("{m}")#text(" of all the other agents. For instance, when modeling traffic congestion, the cost function ")#mi("{C(v)}")#text(" may depend not only on the velocity ")#mi("{v(t,x)}")#text(" that one currently wishes to move at, but also on the density ")#mi("{m(t,x)}")#text(" of traffic at that point in space and time.")

#text("There are many ways to achieve such a generalisation. The simplest would be an additive model, in which the cost function ")#link(<tao-708919008a22125afc2c>)[#text("(1)")]#text(" is replaced with")

#align(center)[#tao-fit-display[#mitex("u(T, x(T)) + \\int_0^T C(x^{\\prime}(t))\\ dt + \\int_0^T F(m(t,x(t)))\\ dt")]]

#text("where ")#mi("{F: {\\bf R}^+ \\rightarrow {\\bf R}}")#text(" represents the marginal cost to an agent of having a given density at the current location. If ")#mi("{F}")#text(" is increasing, this intuitively means that the agent prefers to be away from the other agents (a reasonable hypothesis for traffic congestion), which should lead to a repulsive effect; conversely, a decreasing ")#mi("{F}")#text(" should lead to an attractive effect.")

#text("The Hamilton-Jacobi-Bellman equations can be heuristically derived for this cost functional by a similar analysis to before, leading (in the presence of viscosity) to the equation ")#metadata(none) <tao-7dfd8928a4a3162bbd66>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("-\\partial_t u - \\nu \\Delta u + H(\\nabla_x u) = F(m).")]]

#text("Meanwhile, the velocity field ")#mi("{v}")#text(" is still given by the formula ")#link(<tao-513f0cf2d1541434b341>)[#text("(3)")]#text(", so the Fokker-Planck equation ")#link(<tao-5aef96240bca5582e6fd>)[#text("(4)")]#text(" becomes (after reversing sign) ")#metadata(none) <tao-3cee866e173ffa8e53b9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("- \\partial_t m + \\nu \\Delta m + \\nabla_x \\cdot(m H^{\\prime}(\\nabla_x u)) = 0.")]]

#text("The system of ")#link(<tao-7dfd8928a4a3162bbd66>)[#text("(5)")]#text(", ")#link(<tao-3cee866e173ffa8e53b9>)[#text("(6)")]#text(", with prescribed final data ")#mi("{u(T,x)}")#text(" for ")#mi("{u}")#text(" at time ")#mi("{T}")#text(", and initial data ")#mi("{m(0,x)}")#text(" for ")#mi("{m}")#text(" at time ")#mi("{0}")#text(", is then an example of a mean field game. The backward evolution equation ")#link(<tao-7dfd8928a4a3162bbd66>)[#text("(5)")]#text(" represents the agents’ decisions based on where they want to be in the future; and the forward evolution equation ")#link(<tao-3cee866e173ffa8e53b9>)[#text("(6)")]#text(" represents where they actually end up, based on their initial distribution.")

#text("Solving this coupled system of equations, one evolving backwards in time, and one evolving forwards in time, is highly non-trivial, and in some cases existence or uniqueness or both break down (which suggests that the mean field approximation is not valid in this setting). However, there are various situations in which things behave well: having a small ")#mi("{T}")#text(" (so that the agents only plan ahead for a short period of time), having positive viscosity, and having an increasing ")#mi("{F}")#text(" (i.e. an aversion to crowds) all help significantly, and one typically has a good existence and uniqueness theory in such cases, based to a large extent on energy methods.")

#text("One interesting feature is that when ")#mi("{T}")#text(" becomes large enough (and in the attractive case when ")#mi("{F}")#text(" is decreasing), uniqueness can start to break down, due to the existence of standing waves that are sustained solely by nonlinear interactions between the forward evolution equation and the backward one.")

#text("The Mexican wave phenomenon can be modeled by a more complicated version of a mean field game. Here, the agents are the audience members of a stadium, and their position is modeled both by a horizontal position ")#mi("{x}")#text(" (which would be in a bounded two-dimensional domain), as well as an altitude ")#mi("{z}")#text(" (they could be sitting, standing, or be in an intermediate position). The agents cannot actually move in the ")#mi("{x}")#text(" direction, but only in the ")#mi("{z}")#text(" direction. The cost function consists of three terms: the familiar term ")#mi("{C(v)}")#text(" that penalises excessive movement, a “comfort” function ")#mi("{u(z)}")#text(" that penalises intermediate positions of ")#mi("{z}")#text(" between the sitting and standing positions (since it is not comfortable to stay in a half-standing position for any length of time), and the mean field component which penalises those agents at a position ")#mi("{x_0}")#text(" whose deviation height ")#mi("{z_0}")#text(" is too far from the height of nearby agents, in the sense that an integral such as ")#tao-math("{\\int_{\\left|x-x_0\\right| < \\varepsilon} |z-z_0| m(t,x,z)\\ dx dz}", block: false)#text(", is large. (An audience member who is sitting when everyone is standing, or vice versa, would presumably feel uncomfortable with this status; this is analogous to the attractive case of the potential ")#mi("{F}")#text(" in the previous example.) It turns out that under reasonable simplifying assumptions, one can create non-trivial travelling wave solutions to this mean field game – but only if the stadium is large enough. The causal mechanism for such waves is somewhat strange, though, due to the presence of the backward propagating equation – in some sense, the wave continues to propagate because the audience members expect it to continue to propagate, and act accordingly. (One wonders if these sorts of equations could provide a model for things like asset price bubbles, which seem to be governed by a similar mechanism.)")

#heading(level: 1)[#text("Comments (45)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43138")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2010")])]

#text("Thank you for the post!")

#text("I think there is a ")#mi("dt")#text(" missing from the ")#mi("\\frac{\\sigma^2}{2} \\Delta u(t_0,x_0) dt")#text(" term in the second-to-last equation in the Hamilton-Jacobi-Bellman equations section (and in the line after that).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2c7aa020a8e8e93da7e9ef6d2b7632651c61c0f2cf4518c6f50b2b76ef01bb0-5eef6e9836d32b25bb56112600c4ef17273ffe3d8e161d77b0a38e7fbe7c57f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Patrick O'Raifearteagh")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43143")[#strong[#text("Patrick O'Raifearteagh")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2010")])]

#text("There is a much simpler way to understand the most recent asset bubble pop without the use of PDEs:draw arrows from the the Wall Street firms to the corporate law firms to the congressman,senators and presidents. Or to put it another way: follow the money.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43144")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2010")])]

#text("While one can make a case that the decisions of various authorities and influential players exacerbated, or at least failed to mitigate, the effects of the most recent asset price bubble, I think the underlying phenomenon is indeed largely an emergent one arising from the collective behaviour of agents that are not consciously aware of the net consequences of their actions. For instance, similar bubbles have emerged in as mundane a market as that for Beanie Babies, which was unlikely to have been engineered by any government officials, bankers, or even by the toy company itself (which has been unable to replicate the phenomenon ever since, despite strenuous efforts).")

#text("Ultimately it would be good to have a theory that combined both the collective behaviour of a large number of “ordinary” agents with the decisions of a few key players of unusually large (relative) influence – some complicated combination of PDE and game theory, presumably – but our current mathematical technology is definitely insufficient for even a zeroth approximation to this task. Until then, I would take any overly simple explanatory theory (e.g. “follow the money”) with a healthy degree of skepticism, though there is undoubtedly a grain of truth to many such explanations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f7433c621e76d5a821cfcc82df58674c19a2d6e6f4956c11a5ba5a8265a42f2-08b98488205719b9064fbec8562c73f6aea6a5e32a0aa2cdd48adcbbb82bd5b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of earl thompson")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43209")[#strong[#text("earl thompson")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2010")])]

#text("It’s unlikely that modern bubble-creating bureaucrats consciously understand anything like the full magnitude of their anti-social behavior. Yet this new ruling elite has continually adopted startlingly selfish, small-group-optimal, positions at the social cost of a steady disenfranchisement of our middle class. The most recent example of this clubby behavior is the intellectual acceptance of Bernanke’s mid-2008 insistence on stable consumer prices and money supplies in the face of collapsing commodity prices. The trick to predicting such bubbles is to predict the conditions under which the governmental optimum is to empty out the middle class. See my “Predicting Bubbles” paper (#41 on my website), which spends most of its space showing that informationally competitive markets do not produce bubbles.")

#text("Beanie babies prices probably did not form a bubble, which require prices to be above fundamental values. Xmas Fashion is uncertain. If a November-produced good becomes a hot product in December, its price will soar. If cold, it’s price will plummet. Ho hum.")

#text("Our mathematical technology is just about able us to show that even informational monopolies permit only mini-bubbles, where the monopolist creates an array of minor near-future bubbles in order to prevent future free-riding on his superior future information.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/56afc470e563d6daecfb84c04075dec5d9fd72cdbc9c554fc8fcfcd58e012c55-0101040e3363b3a5728bf3d6946c7d36be2cbdc9f34a9c7ad23accf96b543866.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maria")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43319")[#strong[#text("Maria")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2010")])]

#text("In the case of the asset price bubble, low interest rates and large current account deficit generated excessive liquidity which both motivated and enabled the investment behavior of individual agents. With similar incentives, they behaved similarly and the collective behavior became quite influential. In this particular case, therefore, the collective behavior could be partly described by the incentives behind it, and we can easily put interest rate and CA deficit in a model. I guess describing the incentives rather than the actual behavior of individuals would be more convenient in some other cases as well.")

#text("Now, the asset price bubble is still somewhat there, partly due to low interest rates and large government stimulus. The former enabled banks to borrow at very low rates from central banks and use that money to buy high-yielding bonds like long-term Treasuries, and the effect of the later is becoming clear in countries like China where the large stimulus generated inflation. So perhaps some typical behavior of the individual agents could also be captured by setting the level of interest rates, the scale and direction of the stimulus and some other parameters.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/58bd31b0556affcab9ff92e5d8ab484b3404a4ee6a4f2dfe8d1f32fb0e4b32ad-748ffa7b442f658754fd3acca06ec542b3747088a0156d241b27af2bf369ac79.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Massimo Fornasier")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-479106")[#strong[#text("Massimo Fornasier")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2017")])]

#text("Not being informed of this particular Terry’s idea, sometimes ago (more or less in 2011) it happened to me to start a research program precisely on what I called “sparse mean-field optimal control”, which is a sort of nonlinear compressed sensing theory, where the nonlinearity is the evolution of a probability distribution and the control is the input to be sparsified to achieve a certain outcome. The possible (many and interesting) applications and implications are clear to grasp. See")

#link("https://www-m15.ma.tum.de/foswiki/pub/M15/Allgemeines/PublicationsEN/Massimo_Fornasier_proc_7thECM.pdf")[#text("Click to access Massimo_Fornasier_proc_7thECM.pdf")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43146")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2010")])]

#text("Hi,")

#text("great post. just a small remark: here (section 1) the Legendre transform should be")

#text("\\displaystyle H(p) := \\sup_{v \\in {\\mathbb R}^d} -v \\cdot p – C(v)")

#text("and not the usual one from classical mechanics")

#text("\\displaystyle H(p) := \\sup_{v \\in {\\mathbb R}^d} v \\cdot p – C(v)")

#text("Rgds,")#linebreak()#text(" Diogo Gomes")

#text("then the minimal value of {v \\cdot \\nabla_x u(t_0,x_0) + C(v)} is just {-H(\\nabla_x u(t_0,x_0))} (here we use the hypothesis that {C} is even). We conclude that")

#text("\\displaystyle u(t_0,x_0) = u(t_0,x_0) + dt [ \\partial_t u(t_0,x_0) – H(\\nabla_x u(t_0,x_0)]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43147")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2010")])]

#text("Actually, I think the current sign conventions are consistent (one has to make the substitution ")#mi("v \\mapsto -v")#text(" and use the hypothesis that C is even).")

#text("In Lions’ talk, he reversed time in order to eliminate some of these pesky minus signs, which made the equations slightly nicer but made the connection to the original physical setting less intuitive.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43149")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2010")])]

#text("You’re right – I didn’t see that C was even!")#linebreak()#text(" Thanks,")#linebreak()#text(" D.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43150")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2010")])]

#text("Professor Fellman, Southern New Hampshire University, commented to me by email as follows.")

#text("There’s also some strange attractor behavior as well as chaotic transients moving through the system. Think of people trying to get ahead of one another in traffic as a kind of Roshambo game (rock-paper-scissors) with all three different kinds of behavior around the Nash equilibrium depending upon mutation rates. That might help explain why adding more lanes usually creates more rather than less congestion. Also, there’s a problem of dimensionality, since adding more lanes means more orthogonal input which again has “strange” or “chaotic” results on linear or laminar flows. In that sense, I would think that David Ruelle and Floris Takens’ analysis of the transition to turbulence might have some bearing on the problem. There’s something about this buried in Farmer’s 1982 paper on infinite dimensional chaotic attractors as well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PIERRE")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43155")[#strong[#text("PIERRE")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2010")])]

#text("“but our current mathematical technology is definitely insufficient for even a zeroth approximation to this task”")

#text("Maths have been very useful in physics until now, because mathematics have been created to explain physical phenomenons, such as derivation, variation calculus, differential equation. In physics, you deal with natural phenomenons.")

#text("Take the example of planetary systems, meteorology, they are chaotic systems, but the are not impacted by human behaviour. But with economics, you deal with human phenomenons, which are totally different from the physical one.")

#text("Exept any recent breakthrough, (e.g games theory), all economic systems have evaded any description. I have seen any profitable application of mathematics in finance.")

#text("Put in an other way, is it possible to describe human behaviour with mathematics?")#linebreak()#text(" I dont think so.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43157")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2010")])]

#text("Well, with our current level of mathematical technology, modeling an individual human is not really feasible, with the important exception of game-theoretic models. But this does not preclude the existence of accurate models that can predict the ")#emph[#text("aggregate")]#text(" behaviour of large populations of human agents. For instance, even though we are unable to predict the behaviour of any given voter in an election a few weeks in the future, we can use electoral polls to obtain predictions as to electoral outcomes that, while not completely accurate, are often superior to any other means of electoral prediction. Large parts of modern advertising and marketing are now based, in part, on statistical models for preferences of human customers which again may not be 100% accurate, but certainly have a non-trivial impact on the effectiveness and utility of such marketing (and companies are willing to invest real sums of money in these sorts of models as a consequence). And mathematical finance has led to a highly liquid market for derivatives which, while obviously prone to rather gross abuse by financial speculators, have also been of significant benefit to the “real” economy. For instance, the wild swings in oil prices in recent years may have wreaked havoc to various speculators, but the sectors which would in the past have been extremely sensitive to such swings – e.g. aviation – have largely protected themselves through hedging, in part due to the ability of mathematical finance to facilitate the transfer of risk to those who are more willing to bear it. (It is true, though, that some financial institutions failed to understand exactly how much risk they were taking on as a consequence; like any other tool, abuses can happen if the underlying mathematical model and its assumptions are not properly understood. It also appears that some fraction of financial activity served not to take risk away from those who were unprepared to accept it, but instead to increase the net risk present in the system; one can hope that future reforms to the financial system can reduce this latter type of activity while preserving the valuable aspects of the former type.)")

#text("I believe that in the future, we will have mathematical models that will be better able to accommodate the partly predictable, and partly unknowable, aspects of human behaviour. (In particular, one could hope to develop mathematical tools to try to quantify the robustness of a given system, such as a financial system, to bursts of herd irrationality or other unpredictable group behaviour.) For instance, it is pretty clear that individual human agents in a market do not always behave perfectly rationally; but it is conceivable that if a market is designed in a certain way, that assumptions such as the efficient market hypothesis might still be valid so long as a sufficient proportion of the agents in the market behaved rationally or close to rationally, but that some sort of “phase transition” might occur if a critical mass of irrational agents appeared. I don’t think we currently have the mathematics to precisely discuss these sorts of questions, but in the future we might, and if so I believe these types of questions would be extremely interesting to study.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pierre")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43164")[#strong[#text("Pierre")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("Thank you for your reply")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43166")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("The late Dr. Isaac Asimov, Professor of Biochemistry at Boston University Medical School, based his “Foundation novels” (originally 3 novels, then integrated with others to make a coherent set of 10 novels, to which there are 3 authorized sequels) on the imaginary future science of “Psychohistory.”")

#text("This is a precise Mathematical predictive science of aggregate human behavior. Asimov (who as an undergraduate had trouble deciding between History and Chemistry as a major) hypothesized that for sufficiently large numbers of humans, cooperative effects would occur, and also analogized to the Kinetic Theory of gasses.")

#text("I conversed with him about this, as I was only the 2nd active member of Science Fiction Writers of America to have done a doctoral dissertation in Enzymology, and promised him a formal citation to his dissertation in a refereed work, which nobody had done before. Near the end of his prodigiously prolific life (over 500 books) he wrote a story that undercut the assumptions of Psychohistory, explicitly referring to Chaos Theory. The greatest psychohistorian of all time was Hari Seldon.")

#text("“I quite understand that psychohistory is a statistical science and cannot predict the future of a single man with any accuracy.”")

#text("Among his many books there is also the popularization Asimov On Numbers, Hardcover, 249 pages, Bell Publishing Co. (18 January 1984)")#linebreak()#text(" ISBN-10: 0517371456")#linebreak()#text(" ISBN-13: 978-0517371459")

#text("As the wikipdia entry on him summarizes: Asimov was a long-time member and Vice President of Mensa International, albeit reluctantly; he described some members of that organization as “brain-proud and aggressive about their IQs”, but he also stated that the only two people he had ever met who he would admit were more intelligent than himself were Marvin Minsky and Carl Sagan. He took more joy in being president of the American Humanist Association. The asteroid 5020 Asimov, a crater on the planet Mars, the magazine Asimov’s Science Fiction, a Brooklyn, New York elementary school, and two Isaac Asimov literary awards are named in his honor.")

#text("I wrote the biographical article on Isaac Asimov for the Gale Encyclopedia of Computer Science. Isaac Asimov (born Isaac Yudovich Ozimov, Russian: Исаак Юдович Озимов; c. 2 January 1920 – 6 April 1992).")

#text("I have an unpublished paper on Asimov Number as an equivalent of Erdos number, linking the biomedical literature’s network of coauthorship with that of Science Fiction.")

#text("“Those people who think they know everything are a great annoyance to those of us who do.” — Isaac Asimov.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22f0c527e265ed08bd12642d5c1becf053e15382d9ea72dfe4ee2982b6db1158-15b89af7dcc74921a108c6a3119208f32d5987777eb434a392002e8a41b551da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Chauvet")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43170")[#strong[#text("Jérôme Chauvet")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("Hereafter is what I would consider a first achievement in modelling with math collective agents behavior:")

#link("http://arxiv.org/PS_cache/arxiv/pdf/0912/0912.4760v1.pdf")[#text("Click to access 0912.4760v1.pdf")]

#text("This wonderful article shows how a 4-dimensional shape space + non lnear form on it has the ability to seize the complex behavior of a moving worm in 3d space. A moving sworm is the collective behavior of thousands of living cells, which relates the refrence above to the subject of this post.")

#text("Best wishes")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2c7aa020a8e8e93da7e9ef6d2b7632651c61c0f2cf4518c6f50b2b76ef01bb0-5eef6e9836d32b25bb56112600c4ef17273ffe3d8e161d77b0a38e7fbe7c57f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Patrick O'Raifearteagh")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43179")[#strong[#text("Patrick O'Raifearteagh")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("Jonathan Vos Post")

#text("It does seem to be the case that adding more traffic lanes does not lead to a decrease in traffic over time . Many Americans understand this from personal experience. I strongly suspect that the rason why this is true is because the US population is now over three hundred million. This would strongly indicate a disequillibrium between US population growth and infrastructure growth. This way of looking at things may give insight into creation and anihilation of economic bubbles.")

#text("By it is not a big secret any more as to why the US population continues to grow,grow and grow some more.")

#text("Perhaps a crude-or maybe not so crude-approximationtion of the economic bubble problem is to think of the problem in terms of the logistic equation. I don’t really know. I am just tossing it out.")

#text("Quite possible growth-growthmania is the economic world view of the dominant economic system in the US-is the problem. It is safe to say that most growth does come to an end.")

#text("Professor Tao")

#text("Suppose mathematicians and economists are smart enough to mathematically model the economic stuff that now is mathematically inscrutable…then what? A more basic question-to me at least-is the following?:what does mathematically modelling the economy at the fine grain level actually mean? What would be the whole point of doing this?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22f0c527e265ed08bd12642d5c1becf053e15382d9ea72dfe4ee2982b6db1158-15b89af7dcc74921a108c6a3119208f32d5987777eb434a392002e8a41b551da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Chauvet")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43181")[#strong[#text("Jérôme Chauvet")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("Our economical system is constantly “feedbacked” by human creativity : everytime one has seized a rule so as to use it for profit, another one brings in novelty in order to disturb the system and make its own profit out of it. Then, having a stable mathematical model for economy would give its discoverer the key to perfect business for a while, then surely generate concurrency, which would make the model incomplete, perhaps obsolete. Can one then envisage an evolving mathematical model, which grow in dimension with time. For economy, the use of endomorphisms is perhaps not convenient for that reason…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43184")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("As for potential applications of modeling (besides their intrinsic mathematical and scientific interest), one important one is that of planning. In Lions’ talks, he mentioned for instance that a good model of traffic congestion could lead to efficient ways to design (and to numerically test) congestion pricing schemes or other incentives in order to achieve as optimal a result as possible. (Note that the goal of traffic management is not always to minimise traffic congestion; in many cases, the goal is instead to maximise traffic capacity or throughput, which is a slightly different objective. Adding more lanes to a freeway is often more successful at the latter type of goal than the former.)")

#text("With regard to financial systems, one obvious future application of better mathematical modeling would be to design financial systems that are resistant to emergent effects such as bubbles, as well as to game-theoretic strategies such as collusion or conspiracy, much as modern cryptography allows us to design communication protocols that are resistant to various types of adversarial behaviour. There are already some limited examples of this type of robust system design, for instance in the design of modern spectrum auctions. A related goal is to design a system in such a way that one has some reliable advance warning when some sort of instability is about to occur.")

#text("It may well be that there are fundamental “uncertainty principles” that limit the predictability of a system due to the fact that intelligent agents could use such predictability to alter their strategies, but if so it would be good to quantify such uncertainty principles as much as possible, so that one can squeeze as much consistency and stability out of a system as one can (much as the Heisenberg uncertainty principle tells us that one should be shooting for the Shannon-Nyquist rate when processing band-limited signals).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pierre")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43187")[#strong[#text("Pierre")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("Can we consider human behaviour as atomic particle movement.")

#text("A single human as a total erratic, unexpectable, irrational, behaviour but on a very large scale, we can say that the group as a rational behaviour?")

#text("That’s sound easy to tell, harder to put in practice.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f970240807d21b377c3cb4ab4d90f4bd786a488b70f8048756a1d787b3f44a5-24d1ae48339e63820f5a400b1ed6a1e8c5a3eb52bcdf97e31cc02f20595e02e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Patrick O'Raiffearteagh")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43188")[#strong[#text("Patrick O'Raiffearteagh")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("Pierre, I think Professor Tao is making the case that statistically, psychological irrationality washes out in the aggregate and therfore not significant in understanding macroeconomic processes If this is true, is this unique to statistical equilibrium models? Another question how close is the dictionary between neoclassical economics and statistical mechanics? Is there a partition function analogy?")

#text("I think there is something called partial equillibrium models which allow a somewhat significant role of information flows within an economic process. Joseph Stiglitz won a Noble prize for theorizing about the role of information flows in economic processes. I know very little about this stuff.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22f0c527e265ed08bd12642d5c1becf053e15382d9ea72dfe4ee2982b6db1158-15b89af7dcc74921a108c6a3119208f32d5987777eb434a392002e8a41b551da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Chauvet")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43197")[#strong[#text("Jérôme Chauvet")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2010")])]

#text("What sounds risky in planning our economy from a model is the way one could preserve free-will and liberty in it. When we have such a model working in silico, we will be to enforce it into the human society by setting up all constants and variables the way they must be set up for it to work. Due to this, many people will be demanded to do so or so without more choice left, in order to fit with all requirements. If those persons do not earn as much as they wish to with this system (there surely will be some), they will feel like perverting it anyway. And if the only choice left to crack it up is to not cooperate, they will not cooperate, and freeze the machinery; in case there are around 100% agents cooperating in this non-cooperation status quo, one can imagine this could be harmful to the model.")

#text("Can whatever model fix this?… In such a model, anything has to be definitely well thought over, even the satisfaction level each agent feels to have in the system!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43201")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2010")])]

#text("“What sounds risky in planning our economy from a model is the way one could preserve free-will and liberty in it.” — there was failure of central Planning in the USSR approach has been said be, Mathematically, in terms of the an input-output model, which uses a matrix representation of a nation’s (or a region’s) economy to predict the effect of changes in one industry on others and by consumers, government, and foreign suppliers on the economy. Wassily Leontief (1905-1999) is credited with the development of this analysis. Francois Quesnay developed a cruder version of this technique called Tableau économique. Leontief won the Nobel Memorial Prize in Economic Sciences for his development of this model. The failure of the USSR approach was that, as they did not have (for 5-year plans) the computational ability to invert a 5,000 x 5,000 matrix, they used the economy itself to iteratively do the inversion, and it took more than 5 years to converge to the parameters of a 5-year plan.")

#text("Now, we can invert such matrices in silico. But that does not deal with the underlying metaphysics of “free-will and liberty” — as Isaac Asimov explained in narrative.")

#text("I’ve been working for over a year on a Model Theory development of Lies and Deception. This is part of a decade-long collaboration with prof. Philip Fellman (Southern New Hampshire University) on a Mathematical Theory of Disinformation. I’ve commented on this in the Blue Eyed Islanders thread. We deeply believe that intelligent agent simulations require axiomatic understanding of the ways in which agents attempt to deceive each other. There is a computational explosion if one naiovely models each agent’s belief set, its belief about each other agent’s belief set, and so to infinity. Hence one uses belief Revision algorithms to prune the tree. I have a hunch that Quantum Computers geat the exponential explosion, but that does not mean that the human brain is a quantum computer. Merely that such models are far from expert consensus. See:")

#text("The Definition of Lying and Deception")#linebreak()#text(" First published Thu Feb 21, 2008")#linebreak()#text(" ")#link("http://plato.stanford.edu/entries/lying-definition/")[#text("http://plato.stanford.edu/entries/lying-definition/")]

#text("Questions central to the philosophical discussion of lying to others and other-deception (or interpersonal deceiving) may be divided into two kinds. Questions of the first kind are definitional. They include the questions of how lying is to be defined, and how deceiving is to be defined, and whether lying is a form of intended deception. Questions of the second kind are moral. They include the questions of whether lying and deceiving are (defeasibly) morally wrong, and whether, if either lying or deception, or both, are defeasibly morally wrong, they are ever morally obligatory, and not just merely morally permissible. In this entry, we only consider questions of the first kind.")

#text("* 1. Definition of lying")#linebreak()#text(" o 1.1. Statement condition")#linebreak()#text(" o 1.2. Untruthfulness condition")#linebreak()#text(" o 1.3. Addressee condition")#linebreak()#text(" o 1.4. Intention to deceive addressee condition")#linebreak()#text(" o 1.5. Objections to the definition of lying")#linebreak()#text(" o 1.6. Alternative definitions of lying")#linebreak()#text(" * 2. Definition of deception")#linebreak()#text(" o 2.1. Objections to the definition of deception")#linebreak()#text(" o 2.2. Alternative definition of deception")#linebreak()#text(" * Bibliography")#linebreak()#text(" * Other Internet Resources")#linebreak()#text(" o Cited Resources")#linebreak()#text(" * Related Entries")

#text("1. Definition of lying")

#text("There is no universally accepted definition of lying to others (Kagan 1998, 113)….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22f0c527e265ed08bd12642d5c1becf053e15382d9ea72dfe4ee2982b6db1158-15b89af7dcc74921a108c6a3119208f32d5987777eb434a392002e8a41b551da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Chauvet")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43204")[#strong[#text("Jérôme Chauvet")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2010")])]

#text("Dear Jonathan,")

#text("Your post was really interesting, I mean, over all expectations (I did not know that this kind of study had been done). However, I meant “free-will” and “liberty” not in the metaphysical way, but rather according to the idea that:")

#text("– individuals of any system endowed with “free-will” are able to compute by themselves a choice between two or more known options")

#text("– individuals granted with “liberty” (or rather “action freedom”) are not hampered externally when performing the action they decided to do.")

#text("Regarding the definition of lying, I would say:")

#text("– Any system which, with respect to a same piece of information, uses two different versions of it for either keeping it in its own memory or communicating it to another system.")

#text("In this definition, if the wrong version is kept internally by the system and the right version is the one provided by it to the environment, then one can say the system is “lying to itself”, but it is not out of range of the definition. It needs perhaps a little more improvement, but it does sound rather universal to me.")

#text("Best,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b93f4a16c2d4c6656345507a938f1823073dd84c2ec272f3c5b9dc7a1416fe3-3de04658b0b85346d921abc8cca8fef6337682a48334bc80e067ccef9dac66ef.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michael webster")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43212")[#strong[#text("michael webster")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2010")])]

#text("In an stadium which is large enough, there will be a number of attempts to generate the wave. Some will fail, some will work, others meander. It is not clear from the initial size what the outcome will be, and typically there have to be confederates in the stadium for the wave to work.")

#text("What does the model say in this regard?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43214")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2010")])]

#text("This is not well understood at all, from what I gather from Lions’ talk. The mean field game equations describe self-consistent solutions – systems in which the actions of the agents match up with their optimisation computations (so that the agents are indeed correctly optimising their future cost in their current actions). What is not understood well at all right now is how an inconsistent solution (e.g. when some agents want to create a wave, but the wave is not actually appearing) transitions into a consistent one. The situation is more complicated than that of a traditional evolution equation (which only evolves forward in time, and not backward as well), in which one simply sets initial data and solves the relevant Cauchy problem. The causal relationship seems to be much more complicated when one incorporates the agents’ optimisation procedure into the model.")

#text("If you like, the mean field games are somewhat analogous to “steady state” solutions (thinking of time as a static variable now, rather than a dynamic one). I presume Pierre and his coauthors must also be thinking about these more general questions, but the mathematics may not yet be in place yet.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8b639a43211df10c1497a6a6d581ad39edf9adcc7d7df1d2780a6d95c609aae-fb030a1c4d0a1a639c6762bfa40be0bf334c84b04ba90ea3b6ba29fdb8564b06.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43508")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2010")])]

#text("Wikipedia seems to imply that the stadium waves go in the opposite direction in Australia. This is a prank, right?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22f0c527e265ed08bd12642d5c1becf053e15382d9ea72dfe4ee2982b6db1158-15b89af7dcc74921a108c6a3119208f32d5987777eb434a392002e8a41b551da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Chauvet")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43216")[#strong[#text("Jérôme Chauvet")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2010")])]

#text("These steady states could perhaps be seen as strange attractors of some chaotic system.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pierre")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-43217")[#strong[#text("Pierre")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2010")])]

#text("“These steady states could perhaps be seen as strange attractors of some chaotic system.”")

#text("If you don’t define very clearly what you are talking about, you can see strange attractors, chaotic systems, are this so called “butterfly effect” anywhere you want.")

#text("By the way Terence, (you are the one for this question), can we consider the set of prime numbers as a dynamical system,")

#text("and has ever been some applications of this field in prime number theory?")#linebreak()#text(" Thank you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-44044")[#strong[#text("Mean field games « Andrea Bedini")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2010")]

#text("[…] Mean field games Link: Mean field games […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-44147")[#strong[#text("Swarms, Crowds, and PDE’s « Big Numbers")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2010")]

#text("[…] a link to an earlier talk of Lions’ on mean field games at UCLA. Terence Tao has a lovely and more detailed exposition on his […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-48835")[#strong[#text("LOG | WHAT I BELIEVE")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2010")]

#text("[…] Mean field games seem to be potential tools for the project. This entry was posted in Log. Bookmark the permalink. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-50128")[#strong[#text("mean_field_games [Adam Tilton's Wiki]")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2011")]

#text("[…] ")#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/")[#text("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-51603")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2011")])]

#text("Hello,")

#text("Apologies if this is an embarrassing mistake. But isn’t there a missing $\\nabla_x$ in the definition of $p$ after the equation $\\tilde v \\cdot p – C(\\tilde v)$?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-251499")[#strong[#text("Les jeux à champ moyen | 2013, année des Mathématiques de la Planète Terre")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2013")]

#text("[…] long post du blog de T. Tao sur les jeux à champ moyen [En […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Riccardo")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-263457")[#strong[#text("Riccardo")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")])]

#text("Thank you Professor for this post. It was very interesting and very well explained.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cacac79f91de1ae3ccad27576ae10a6011bc2b26b288edbabf39e3aed9fac7bc-a8c5881e675a2f64dc4549ab5922e7759bec57abeb5505d4d6362138a54ee6ab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nikhil")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-275194")[#strong[#text("nikhil")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2014")])]

#text("Prof. Tao, this is a very nice expository article for an engineering student like me who is interested in doing more mathematical stuff……what is a good expository book on mean field games")#linebreak()#text(" Thanks")#linebreak()#text(" Nikhil")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68b80d6140e5077edac4fa733db70b8def37d29790c538ce013394aafbdb09e4-ee890e5bf0cec3601c75d0fe54ec994df35b51c8ea42c694a3b866779d057b39.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 2pg")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-275199")[#strong[#text("2pg")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2014")])]

#text("Hey.")#linebreak()#text(" Is the mean field games theory used in optimization techniques that involve flow?")#linebreak()#text(" Very interesting read for an engineering major")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95721a2b24f0a1960e1f71e66bea13635e913c76b2517a2526062f3dfa027ed0-67d5dd48d71366912102d5bec9f5cc37a4bbe920b225a0b5c2c4d9c1a935534b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leonid")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-444022")[#strong[#text("Leonid")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2014")])]

#text("Qualitatively, leaving aside the exact mathematical details, this is nothing conceptually new for economists — the structure described here is what is known as rational expectations economics. Agents make plans today based on their understanding (assumed to be perfect) of the future evolution of the aggregate economy, which itself depends on the individual choices.")

#text("There is a relation to bubbles, that’s correct. That’s just a special topic in the broader area (above), known as rational bubbles.")

#text("As for the interaction of the irrational and rational agents, this can be analyzed using conventional methods. There is a literature on market selection that deals with this exact question: how does the presence of irrational agents affect the aggregate market dynamics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/beb444ab896de60c4fde3c3836754df3ba03f102fce72bb5de93538766ecf903-43b18da0e0fe551d5aca901655f265dd4fe98169650817354eb95224dd641b5f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zhengli0817")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-469619")[#strong[#text("zhengli0817")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("Reblogged this on ")#link("https://dataquantblog.wordpress.com/2016/06/08/mean-field-games/")[#text("dataquantblog")]#text(" and commented:")#linebreak()#text(" A nice and intuitive introduction to mean field games")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e417c511d97ebe15c953fb05c12594919c6272bd259c8c7104def1f7fe940f3e-78119058a752e0b5ded5f675679d15c14e3a6d19ce211dc3935d939eda3b9034.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vincent Leclere")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-473306")[#strong[#text("Vincent Leclere")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2016")])]

#text("Thanks for this presentation. I remarked that the link to the Lion’s series of lecture is dead. Here is a working link on the subject :")#linebreak()#text(" MFG and application ")#link("https://www.college-de-france.fr/site/pierre-louis-lions/course-2010-11-12-09h00.htm")[#text("https://www.college-de-france.fr/site/pierre-louis-lions/course-2010-11-12-09h00.htm")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ddcfb6419e38c5dd9ca9cd3c997a84ba3607b63b8b0c58b8c0ea292e5086b127-84ae8bdeb314ea8162845b97c49841e6c17fa83a4797d9ef6c4fbfd49078f777.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Olivier Wang")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-474267")[#strong[#text("Olivier Wang")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2016")])]

#text("The key challenge one faces when trying to model bubbles is to embed intuitions like the self-fulfilling force you mention into familiar models of financial markets based on the principle of no-arbitrage. Often, this principle is too strong for the initial intuition to survive: to take your example, the modeler must defend why wealthy, risk-neutral traders who are less affected by the discomfort u(z) would not take advantage of the crowd of traders sensitive to u(z) by short-selling the asset, which eventually prevents the price bubble to form or grow. While each of the conditions implicit in my previous sentence could be relaxed in turn (for instance by arguing that these rational traders would need an enormous amount of wealth to be able to move the market, or that it would expose them to too much risk in the short-run, like LTCM ")#link("https://en.wikipedia.org/wiki/Long-Term_Capital_Management")[#text("https://en.wikipedia.org/wiki/Long-Term_Capital_Management")]#text("), here is an interesting example by Dilip Abreu and Markus Brunnermeier that relies on a concept you wrote about recently, common knowledge (or lack thereof): ")#link("https://www.princeton.edu/~markus/research/papers/bubbles_crashes.pdf")[#text("https://www.princeton.edu/~markus/research/papers/bubbles_crashes.pdf")]#linebreak()#text(" The idea is that even if these ‘rational’ traders exist and are well-informed enough to know that the asset is overvalued, it could be much harder for them to know whether other market participants also know that other market participants also know that … also know that the asset is overvalued.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/be0c187df7682283f1021282fb0d0c68790efa1da7b8c134585917f152c08081-1681a9f80b1104e4e35b14c74b2af38a4965dce1f14ca5fc671eef319097ee6d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kenneth")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-479377")[#strong[#text("kenneth")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2017")])]

#text("Some minor typos are spotted in the post. [a] In the third equation from the last of the first section on HJB, ")#mi("\\sigma")#text(" may be missing from the term ")#mi("\\sigma dB_t \\cdot \\nabla_x u_0")#text("; [b] There seems one more closing parenthesis included in the equation (6); [c] In the equation right before the equation (4), ")#mi("dt")#text(" may be missing right after the term ")#mi("\\Delta F(x)")#text("; [d] In the equation (4), the viscosity ")#mi("\\nu")#text(" may be better to be replaced by ")#mi("\\sigma^2/2")#text(", since ")#mi("\\nu")#text(" is just mentioned once way earlier in the first section.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48e1326c95be276acedb6747686616cc4eefaff062fbacfb5d9b94fa7b980734-3b7584db4b846a9e48c2d92c8529e366af008d002ca373f5c741a3961a991eb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Krishna Bhogaonker")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-484801")[#strong[#text("Krishna Bhogaonker")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2017")])]

#text("Hello Prof. Tao. This discussion on mean field games is fascinating. I was wondering if you have any more writings on the mathematics of human behavior, etc?")

#text("The reason I ask is because the viewpoint here does differ quite substantially from the classical political science or sociological approaches to human behavior analysis. For example, you mention two potential applications of human behavior modelling–planning and testing the robustness of systems (eg. financial). I think one strand of political/sociological thought (Frankfurt school) would suggest the dangers of this form of analysis as it could be used by the more powerful interests in society to enforce control over the 99% of the population. For example using behavior models to generate fake news that elects specific candidates who undermine healthcare for the people who elected them.")

#text("Of course there it truth on both sides of the argument. Modeling can have very positive effects to help improve the welfare of individuals, as well as very negative effects. So I think the real question is how to use modelling to create boundaries or guardrails that prevent these technologies being used for nefarious purposes–as best as possible.")

#text("If you have any additional views or writings on modelling behavior, could you please provide links. I know that you are terribly busy, so if you don’t have a chance to then I understand.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a27839c1eae30013fd3608a3c297c3fa83fcb431b9bb8a73fb28cd8ca8a9ab64-d293454ac454b02b700c88248734f7bdbdf33b00304d2fae42d24c1aa0e4c787.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sumit")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-632966")[#strong[#text("sumit")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2021")])]

#text("how can i do mean field game compute simulation?")#linebreak()#text(" any resource link would be much appreciated.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3a50558aa1b180def34b75df4928f170b17b189569422afc0b8a4b015794c311-28905f85011fa07e1bd29038ebe4728d044cde5ae5da1cdee99a560baaf94a61.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Just curious")]], [#link("https://terrytao.wordpress.com/2010/01/07/mean-field-equations/#comment-637035")[#strong[#text("Just curious")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2021")])]

#text("Can the techniques be helpful in crowd management just as it helps predict Mexican wave? ")#link("https://www.msn.com/en-us/sports/ncaabk/ucla-students-describe-terrifying-scene-amid-crush-of-bodies-outside-pauley-pavilion/ar-AAQEMy1")[#text("https://www.msn.com/en-us/sports/ncaabk/ucla-students-describe-terrifying-scene-amid-crush-of-bodies-outside-pauley-pavilion/ar-AAQEMy1")]
]
