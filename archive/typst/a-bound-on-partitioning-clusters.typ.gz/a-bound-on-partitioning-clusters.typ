// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/
// Converted to Typst by tao2typ: "2026-10-14T16:38:06.472518+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A bound on partitioning clusters", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A bound on partitioning clusters")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 February 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/")[#text("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://cseweb.ucsd.edu/~dakane/")[#text("Daniel Kane")]#text(" and I have just uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/1702.00912")[#text("A bound on partitioning clusters")]#text("“, submitted to the ")#link("http://www.combinatorics.org/")[#text("Electronic Journal of Combinatorics")]#text(". In this short and elementary paper, we consider a question that arose from biomathematical applications: given a finite family ")#mi("{X}")#text(" of sets (or “clusters”), how many ways can there be of partitioning a set ")#mi("{A \\in X}")#text(" in this family as the disjoint union ")#mi("{A = A_1 \\uplus A_2}")#text(" of two other sets ")#mi("{A_1, A_2}")#text(" in this family? That is to say, what is the best upper bound one can place on the quantity")

#align(center)[#tao-fit-display[#tao-math("\\left| \\{ (A,A_1,A_2) \\in X^3: A = A_1 \\uplus A_2 \\}\\right|", block: true)]]

#text("in terms of the cardinality ")#tao-math("{\\left|X\\right|}", block: false)#text(" of ")#mi("{X}")#text("? A trivial upper bound would be ")#tao-math("{\\left|X\\right|^2}", block: false)#text(", since this is the number of possible pairs ")#mi("{(A_1,A_2)}")#text(", and ")#mi("{A_1,A_2}")#text(" clearly determine ")#mi("{A}")#text(". In our paper, we establish the improved bound")

#align(center)[#tao-fit-display[#tao-math("\\left| \\{ (A,A_1,A_2) \\in X^3: A = A_1 \\uplus A_2 \\}\\right| \\leq \\left|X\\right|^{3/p}", block: true)]]

#text("where ")#mi("{p}")#text(" is the somewhat strange exponent ")#metadata(none) <tao-9f1f8e40627ec0511a3e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("p := \\log_3 \\frac{27}{4} = 1.73814\\dots,")]]



#text(" so that ")#mi("{3/p = 1.72598\\dots}")#text(". Furthermore, this exponent is best possible!")

#text("Actually, the latter claim is quite easy to show: one takes ")#mi("{X}")#text(" to be all the subsets of ")#mi("{\\{1,\\dots,n\\}}")#text(" of cardinality either ")#mi("{n/3}")#text(" or ")#mi("{2n/3}")#text(", for ")#mi("{n}")#text(" a multiple of ")#mi("{3}")#text(", and the claim follows readily from Stirling’s formula. So it is perhaps the former claim that is more interesting (since many combinatorial proof techniques, such as those based on inequalities such as the Cauchy-Schwarz inequality, tend to produce exponents that are rational or at least algebraic). We follow the common, though unintuitive, trick of ")#link("http://www.tricki.org/article/Simplify_your_problem_by_generalizing_it")[#text("generalising a problem to make it simpler")]#text(". Firstly, one generalises the bound to the “trilinear” bound")

#align(center)[#tao-fit-display[#tao-math("\\left| \\{ (A_1,A_2,A_3) \\in X_1 \\times X_2 \\times X_3: A_3 = A_1 \\uplus A_2 \\}\\right|", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\leq \\left|X_1\\right|^{1/p} \\left|X_2\\right|^{1/p} \\left|X_3\\right|^{1/p}", block: true)]]

#text("for arbitrary finite collections ")#mi("{X_1,X_2,X_3}")#text(" of sets. One can place all the sets in ")#mi("{X_1,X_2,X_3}")#text(" inside a single finite set such as ")#mi("{\\{1,\\dots,n\\}}")#text(", and then by replacing every set ")#mi("{A_3}")#text(" in ")#mi("{X_3}")#text(" by its complement in ")#mi("{\\{1,\\dots,n\\}}")#text(", one can phrase the inequality in the equivalent form")

#align(center)[#tao-fit-display[#tao-math("\\left| \\{ (A_1,A_2,A_3) \\in X_1 \\times X_2 \\times X_3: \\{1,\\dots,n\\} =A_1 \\uplus A_2 \\uplus A_3 \\}\\right|", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\leq \\left|X_1\\right|^{1/p} \\left|X_2\\right|^{1/p} \\left|X_3\\right|^{1/p}", block: true)]]

#text("for arbitrary collections ")#mi("{X_1,X_2,X_3}")#text(" of subsets of ")#mi("{\\{1,\\dots,n\\}}")#text(". We generalise further by ")#link("http://www.tricki.org/article/Turn_sets_into_functions")[#text("turning sets into functions")]#text(", replacing the estimate with the slightly stronger convolution estimate")

#align(center)[#tao-fit-display[#tao-math("f_1 * f_2 * f_3 (1,\\dots,1) \\leq \\left\\|f_1\\right\\|_{\\ell^p(\\{0,1\\}^n)} \\left\\|f_2\\right\\|_{\\ell^p(\\{0,1\\}^n)} \\left\\|f_3\\right\\|_{\\ell^p(\\{0,1\\}^n)}", block: true)]]

#text("for arbitrary functions ")#mi("{f_1,f_2,f_3}")#text(" on the Hamming cube ")#mi("{\\{0,1\\}^n}")#text(", where the convolution is on the integer lattice ")#mi("{\\bf Z}^n")#text(" rather than on the finite field vector space ")#mi("{\\bf F}_2^n")#text(". The advantage of working in this general setting is that it becomes very easy to apply induction on the dimension ")#mi("{n}")#text("; indeed, to prove this estimate for arbitrary ")#mi("{n}")#text(" it suffices to do so for ")#mi("{n=1}")#text(". This reduces matters to establishing the elementary inequality")

#align(center)[#tao-fit-display[#mitex("(ab(1-c))^{1/p} + (bc(1-a))^{1/p} + (ca(1-b))^{1/p} \\leq 1")]]

#text("for all ")#mi("{0 \\leq a,b,c \\leq 1}")#text(", which can be done by a combination of undergraduate multivariable calculus and a little bit of numerical computation. (The left-hand side turns out to have local maxima at ")#mi("{(1,1,0), (1,0,1), (0,1,1), (2/3,2/3,2/3)}")#text(", with the latter being the cause of the numerology ")#link(<tao-9f1f8e40627ec0511a3e>)[#text("(1)")]#text(".)")

#text("The same sort of argument also gives an energy bound")

#align(center)[#tao-fit-display[#tao-math("E(A,A) \\leq \\left|A\\right|^{\\log_2 6}", block: true)]]

#text("for any subset ")#mi("{A \\subset \\{0,1\\}^n}")#text(" of the Hamming cube, where")

#align(center)[#tao-fit-display[#tao-math("E(A,A) := \\left|\\{(a_1,a_2,a_3,a_4) \\in A^4: a_1+a_2 = a_3 + a_4 \\}\\right|", block: true)]]

#text("is the additive energy of ")#mi("{A}")#text(". The example ")#mi("{A = \\{0,1\\}^n}")#text(" shows that the exponent ")#mi("{\\log_2 6}")#text(" cannot be improved.")

#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3357f9caffa41f80d34f24eac153a8dd25889673999d5fc7bb0641309a2634f7-91ea8d65b625eb8a772cd38b2682a42c950f875fef90ce2e1c3736a8966f62d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ravenclawprefect")]], [#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-477606")[#strong[#text("ravenclawprefect")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2017")])]

#text("Should “elements of $\\{1,…,n\\}$” read “subsets” instead?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37bef795579c47764467263e219ba5a998170b029a3cb91caaed623e58a179e0-19b07a54336dd0d17a7e49e8231fff18ced0a12a91b396708c8ea039bf59768c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paata Ivanishvili")]], [#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-477609")[#strong[#text("Paata Ivanishvili")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2017")])]

#text("For ")#mi("n")#text(" functions the answer seems to be")#linebreak()#text(" ")#mi("\\frac{\\ln \\frac{n^{n}}{(n-1)^{n-1}}}{\\ln n}")#text(". And it approeaches to 1 as ")#mi("1+\\frac{1}{\\ln n}")#text(" when ")#mi("n")#text(" goes to infinity")

#emph[#text("[Hmm, I think you’re right, and the proof methods extend to this setting. We’ll add a remark to this effect in the next revision of the ms. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98f2002e9f38f3a93e7496287613303e4538d91adbff9c021b8f88319ee1246c-dc10f9099583a78c2a6d973fa5aedcf8dd9767e7aeee0daef551d72cd433e52e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of john doe")]], [#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-477614")[#strong[#text("john doe")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2017")])]

#text("a tiny comment:")#linebreak()#text(" In equation (1.1) S should be replaced with X")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. – T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d28195df14800315168ea974f4adf888eace7d3a34fc83513af492698793a2c-e2ad3cdfa379c5dcf139408dc5d555ac7c236dfa87abd3799a789b51ef5d74f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kodlu")]], [#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-477623")[#strong[#text("Kodlu")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2017")])]

#text("The notation f_1\\ast f_2\\ast f_3(1,\\ldots,1) is clear in the paper but is somewhat opaque in the post (or at least it was opaque to me!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of VMT")]], [#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-477672")[#strong[#text("VMT")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2017")])]

#text("Minor remark: I think there is a slightly simpler proof of inequality (1.4) in the paper.")#linebreak()#text(" If the left-hand side achieves a maximum for ")#mi("a,b,c\\in(0,1)^3")#text(", one can prove that ")#mi("(a,b,c)=(2/3,2/3,2/3)")#text(":")#linebreak()#text(" imposing the vanishing of the differential, one gets that ")#mi("A:=\\frac{1-a}{a}")#text(", ")#mi("B:=\\frac{1-b}{b}")#text(", ")#mi("C:=\\frac{1-c}{c}")#text(" satisfy")#linebreak()#text(" ")#mi("A^{1-1/p}(B^{1/p}+C^{1/p})=1\\ (*_A)")#text(" and the two other equations obtained by permutation of ")#mi("A,B,C")#text(".")#linebreak()#text(" Assuming wlog that ")#mi("A\\le B,C")#text(", we have ")#mi("\\lambda:=\\frac{B}{A}\\ge 1")#text(", ")#mi("\\mu:=\\frac{C}{A}\\ge 1")#text(". Comparison of ")#mi("(*_A)")#text(" and ")#mi("(*_B)")#text(" gives")#linebreak()#text(" ")#mi("\\lambda^{1/p}+\\mu^{1/p}=\\lambda^{1-1/p}(1+\\mu^{1/p})")#text(", but since ")#mi("\\frac{1}{p}\\le 1-\\frac{1}{p}")#text(" this equation can only hold if ")#mi("\\lambda=1")#text(". Similarly ")#mi("\\mu=1")#text(" and we deduce ")#mi("A=B=C=\\frac{1}{2}")#text(",")#linebreak()#text(" i.e. ")#mi("(a,b,c)=(2/3,2/3,2/3)")#text(". The case when (1.4) has a minimum on the boundary of the cube is simpler.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-477712")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2017")])]

#text("Unfortunately the inequality ")#mi("\\frac{1}{p} \\leq 1 - \\frac{1}{p}")#text(" is false. As discussed in the paper, there are other critical points arising from local minima rather than local maxima; in your notation, one of them is ")#mi("(A,B,C) \\approx (0.09343, 0.09343, 4.85147)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of VMT")]], [#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-477719")[#strong[#text("VMT")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2017")])]

#text("Whoops! Sorry for wasting your time…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-477674")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2017")])]

#text("Echoing Kodlu’s complaint: I originally assumed that ")#mi("\\ast")#text(" was convolution treating the Hamming cube as an abelian group of order ")#mi("2^n")#text(" . It was only after some confusion that I realized we were considering the Hamming cube as a subset of ")#mi("\\mathbb{Z}^n")#text(" and convolving in that group. The paper’s statement is ambiguous on this point as well, although by time I looked that up I was alert to the issue.")

#emph[#text("[Clarified here and in the next revision of the ms, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-477677")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2017")])]

#text("This optimal exponent implies that the ratio of the best known upper bound to the best known lower bound for the above number of partitions is ")#tao-math("\\left|X\\right|^{o(1)}", block: false)#text(". Can this growth estimate of this ratio be improved ? (or even be made bounded?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-477990")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2017")])]

#text("Probably it can be improved. One needs to replace the right-hand side ")#tao-math("\\left|X_1\\right|^{1/p} \\left|X_2\\right|^{1/p} \\left|X_3\\right|^{1/p}", block: false)#text(" in the fourth-display by some more complicated “Bellman function” ")#tao-math("F(\\left|X_1\\right|, \\left|X_2\\right|, \\left|X_3\\right|)", block: false)#text(" of the three sizes that grows a little bit more slowly than ")#tao-math("\\left|X\\right|^{3/p}", block: false)#text(" on the diagonal, and also gains something when the ")#tao-math("\\left|X_1\\right|, \\left|X_2\\right|, \\left|X_3\\right|", block: false)#text(" are different sizes from each other. One will probably have to do some Taylor expansion calculations near the critical point ")#mi("(a,b,c) = (2/3,2/3,2/3)")#text(" of the elementary inequality used here in order to make sure the induction closes properly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37bef795579c47764467263e219ba5a998170b029a3cb91caaed623e58a179e0-19b07a54336dd0d17a7e49e8231fff18ced0a12a91b396708c8ea039bf59768c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paata Ivanisvili")]], [#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-478060")[#strong[#text("Paata Ivanisvili")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2017")])]

#text("But how to close the induction? If little ")#mi("o")#text(" is in ")#mi("n")#text(" in the expression ")#tao-math("\\left|X\\right|^{o(1)}", block: false)#text(" then the “Bellman function” ")#mi("F")#text(" should also depend on ")#mi("n")#text(". I don’t quite see how these quantities propagate, or maybe I misunderstood the question.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-478062")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2017")])]

#text("In the paper, the gap between the upper and lower bounds is of the form ")#mi("1/n^{O(1)}")#text(", which is not quite the same thing as ")#tao-math("\\left|X\\right|^{o(1)}", block: false)#text(", though in the key examples, ")#mi("X")#text(" is of exponential size in ")#mi("n")#text(" so the gap should be something like ")#tao-math("1/\\log^{O(1)} \\left|X\\right|", block: false)#text(". To make the induction close, I think one should use a Bellman function that is independent of ")#mi("n")#text(" and which is smaller than ")#tao-math("\\left|X\\right|^{3/p}", block: false)#text(" by a power of ")#tao-math("\\log\\left|X\\right|", block: false)#text(" when ")#tao-math("\\left|X_1\\right|=\\left|X_2\\right|=\\left|X_3\\right|=\\left|X\\right|", block: false)#text("; it has to be carefully chosen not only in the main region where ")#tao-math("\\left|X_1\\right| \\sim \\left|X_2\\right| \\sim \\left|X_3\\right|", block: false)#text(" but also in the extreme cases when say one of the ")#tao-math("\\left|X_i\\right|", block: false)#text(" is much smaller than the other two (this corresponds to the fact that in addition to the main critical point ")#mi("(2/3,2/3,2/3)")#text(" of the key inequality, we also have critical points at ")#mi("(1,1,0)")#text(" and permutations). Finding the precise Bellman function that works may require a certain amount of trial and error and iteration (trying one Bellman function, finding out the locations where the induction fails to close, tweaking the Bellman function to repair the induction in that case, and then seeing if this causes the induction to stop working at some other location, repeating as necessary).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/580217f56e50c9414ba1201326b9ec2f4cbdec1c89643019a2be3bca619e3569-19b07a54336dd0d17a7e49e8231fff18ced0a12a91b396708c8ea039bf59768c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paata Ivanisvili")]], [#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-481278")[#strong[#text("Paata Ivanisvili")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2017")])]

#text("Given integer ")#tao-math("A=\\left|X\\right|>1", block: false)#text(" we want to find nonnegative function ")#mi("B")#text(" on ")#mi("[0,A]^{3}")#text(" such that ")#mi("B(1,1,1)=1")#text(" and ")#mi("B(a_{1},a_{2},b_{3})+B(a_{1},b_{2},a_{3}) +B(b_{1},a_{2},a_{3}) \\leq B(a_{1}+b_{1},a_{2}+b_{2},a_{3}+b_{3})")#text(". And the goal is to minimize ")#mi("B(A,A,A)")#text(". This problem was solved when ")#mi("A \\to \\infty")#text(" with ")#mi("B(x,y,z)=x^{1/p}y^{1/p}z^{1/p}")#text(". But for fixed ")#mi("A>1")#text(" the best possible ")#mi("B")#text(" does not have to be this one, it can be smaller. Is this what was meant in your first comment? The only thing that is not clear to me why this main inequality that I wrote on ")#mi("B")#text(" (and which closes induction easily) should be also necessary for the true ")#mi("B")#text(", i.e., I mean yes I agree, it is sufficient to solve the problem and find some bound, but is it also necessary, i.e., will the result give me sharp bound?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37bef795579c47764467263e219ba5a998170b029a3cb91caaed623e58a179e0-19b07a54336dd0d17a7e49e8231fff18ced0a12a91b396708c8ea039bf59768c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paata Ivanishvili")]], [#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-477679")[#strong[#text("Paata Ivanishvili")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2017")])]

#text("Here is the proof for the finite number of functions (not necessarily 2) which corresponds to ")#mi("n")#text(" partitions instead of $2$.")#linebreak()#text(" ")#link("https://www.dropbox.com/s/qq4i8ihuju2iltx/Partition.pdf?dl=0")[#text("https://www.dropbox.com/s/qq4i8ihuju2iltx/Partition.pdf?dl=0")]#linebreak()#text(" Again the question boils down to the Hamming cube ")#mi("\\{-1,1\\}")#text(" of dimension 1 and the best possible power for the convolution inequality is ")#mi("p = \\frac{\\ln \\frac{n^{n}}{(n-1)^{n-1}}}{\\ln n}")#text(", and for the number of ")#mi("n-1")#text(" partitions we obtain ")#mi("N/p")#text("( I am not sure if ")#mi("N/p")#text(" is the optimal power for N>3 (I just did not think about the example).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/706fdd5908540724f20e3106552db6d9ac5439a6fcf0889314bd86b25df41959-9c3888ebd42c24fd0a2a2c6508f3131b5f495461adebead4fa02f1972266e45d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matjaž Gomilšek")]], [#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-477769")[#strong[#text("Matjaž Gomilšek")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2017")])]

#text("Shouldn’t ")#tao-math("\\left|S\\right|", block: false)#text(" in the rhs of (1.1) be ")#tao-math("\\left|X\\right|", block: false)#text("?")

#emph[#text("[This will be corrected in the next version of the ms. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1beca012fb8797c6419c7407e50faa12d04cee3e27fbecc6675ac974f5a4eb63-9c3888ebd42c24fd0a2a2c6508f3131b5f495461adebead4fa02f1972266e45d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matjaž Gomilšek")]], [#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-477770")[#strong[#text("Matjaž Gomilšek")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2017")])]

#text("In the preprint, that is.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-478000")[#strong[#text("SSQR (@SumantriSQR)")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2017")]

#text("is this has any connection with cluster algebra that initiated by fomin-zelevinski??")

#emph[#text("[No. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-478253")[#strong[#text("A Gauss-Bonnet connection - Quantum Calculus")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2017")]

#text("[…] are cheap, one can find them in any library or now the internet. But it is also on the internet: An example. End Side […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/760ddd8bad27c570c5995a8ca954c5a38fd4fac69f38771b25a6b6db36d6b11e-4ad57592ce78782880a2c818635ada04dd6ba4cba69ace173598d068d4466749.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Romain Viguier")]], [#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-478460")[#strong[#text("Romain Viguier")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2017")])]

#text("you should make intervals, make in it a convergent series, make an increasing function on a subset n- (n- (n / i) of")#linebreak()#text(" the starting set for i ranging from 1 to n,")#linebreak()#text(" you make a deterministic decomposition (we know the arrival) of the function. Then you remove an interval, and we will have a cos and sin function.")#linebreak()#text(" The limit at 0 is n ^ 2 – n / i for i ranging from 1 to n.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad4c3e019150b140bc6294f3e40473e219b48a2efe695fd61fffd95ce371b23c-1911117f007cf12d1cf989d9df9995a20201c986ba4c70c42d080735f7970b92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergei Ofitserov")]], [#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-479346")[#strong[#text("Sergei Ofitserov")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2017")])]

#text("Dear Terence Tao! I proceed with big interest to read your notes and want to give reply on “trilinear” bound.")#linebreak()#text(" ——Quarks in quantum chromodynamics.—— In inequality |X1|~|X2|~|X3| it is necessary to apply meanings u,d,s. Accordingly:")#linebreak()#text(" |X1|=u, |X2|=d, |X3|=s, because quarks u,d,s to have various quantum numbers. In equality |X1|=|X2|=|X3|=|X| it is necessary to apply meaninqs u,u,u. Accordingly:–")#linebreak()#text(" |X1|=u, |X2|=u, |X3|=u, because quarks u,u,u to have identical quantum numbers and directions. Matrixs of Gell-Mann (3×3) to form algebra ASU(3). Thus, in this way gauge theory, base on group SU(3), open approach for theory of Yang-Mills.Constrained quarks in groups SU(3)=(u,d,s) or SU(3)=(u,u,u) give possibility to approach for demonstration of Rieman hypothesis with other side. Fourth-display=>this metric siqnature(+—). Thanks!Sergei.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02bac94babd1f10a61d6a34c6fef3ef21d52a84b8debdc2e02f5b15b3c10d5ae-2f8ff17e1311f739c91aab6a821816a2c8e48a73c1cf867d0451ddcd5379cdd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kaave")]], [#link("https://terrytao.wordpress.com/2017/02/05/a-bound-on-partitioning-clusters/#comment-480004")[#strong[#text("kaave")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2017")])]

#text("This is reminding me of a result of Manners:")

#link("https://arxiv.org/pdf/1512.06272.pdf")[#text("Click to access 1512.06272.pdf")]

#text("Appendix B, Proposition B.1.")
]
