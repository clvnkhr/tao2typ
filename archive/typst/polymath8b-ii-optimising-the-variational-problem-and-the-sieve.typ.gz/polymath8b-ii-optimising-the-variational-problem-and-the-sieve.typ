// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/
// Converted to Typst by tao2typ: "2026-10-14T15:18:52.328519+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath8b, II: Optimising the variational problem and the sieve", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath8b, II: Optimising the variational problem and the sieve")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 November 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/")[#text("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is the second thread for the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8b project")]#text(" to obtain new bounds for the quantity")

#align(center)[#tao-fit-display[#mitex("H_m := \\liminf_{n \\rightarrow\\infty} (p_{n+m} - p_n),")]]

#text("either for small values of ")#mi("{m}")#text(" (in particular ")#mi("{m=1,2}")#text(") or asymptotically as ")#mi("{m \\rightarrow \\infty}")#text(". The previous thread may be found ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/")[#text("here")]#text(". The currently best known bounds on ")#mi("{H_m}")#text(" are:")

#list(
[#text("(Maynard) ")#mi("{H_1 \\leq 600}")#text(".")],
[#text("(Polymath8b, tentative) ")#mi("{H_2 \\leq 484,276}")#text(".")],
[#text("(Polymath8b, tentative) ")#mi("{H_m \\leq \\exp( 3.817 m )}")#text(" for sufficiently large ")#mi("{m}")#text(".")],
[#text("(Maynard) Assuming the Elliott-Halberstam conjecture, ")#mi("{H_1 \\leq 12}")#text(", ")#mi("{H_2 \\leq 600}")#text(", and ")#mi("{H_m \\ll m^3 e^{2m}}")#text(".")]
)

#text("Following the strategy of Maynard, the bounds on ")#mi("{H_m}")#text(" proceed by combining four ingredients:")

#enum(start: 1, 
[#text("Distribution estimates ")#mi("{EH[\\theta]}")#text(" or ")#mi("{MPZ[\\varpi,\\delta]}")#text(" for the primes (or related objects);")],
[#text("Bounds for the minimal diameter ")#mi("{H(k)}")#text(" of an admissible ")#mi("{k}")#text("-tuple;")],
[#text("Lower bounds for the optimal value ")#mi("{M_k}")#text(" to a certain variational problem;")],
[#text("Sieve-theoretic arguments to convert the previous three ingredients into a bound on ")#mi("{H_m}")#text(".")]
)

#text("Accordingly, the most natural routes to improve the bounds on ")#mi("{H_m}")#text(" are to improve one or more of the above four ingredients.")

#text("Ingredient 1 was studied intensively in Polymath8a. The following results are known or conjectured (see ")#link("https://www.dropbox.com/s/16bei7l944twojr/newgap.pdf")[#text("the Polymath8a paper")]#text(" for notation and proofs):")

#list(
[#text("(Bombieri-Vinogradov) ")#mi("{EH[\\theta]}")#text(" is true for all ")#mi("{0 < \\theta < 1/2}")#text(".")],
[#text("(Polymath8a) ")#mi("{MPZ[\\varpi,\\delta]}")#text(" is true for ")#mi("{\\frac{600}{7} \\varpi + \\frac{180}{7}\\delta < 1}")#text(".")],
[#text("(Polymath8a, tentative) ")#mi("{MPZ[\\varpi,\\delta]}")#text(" is true for ")#mi("{\\frac{1080}{13} \\varpi + \\frac{330}{13} \\delta < 1}")#text(".")],
[#text("(Elliott-Halberstam conjecture) ")#mi("{EH[\\theta]}")#text(" is true for all ")#mi("{0 < \\theta < 1}")#text(".")]
)

#text("Ingredient 2 was also studied intensively in Polymath8a, and is more or less a solved problem for the values of ")#mi("{k}")#text(" of interest (with exact values of ")#mi("{H(k)}")#text(" for ")#mi("{k \\leq 342}")#text(", and quite good upper bounds for ")#mi("{H(k)}")#text(" for ")#mi("{k < 5000}")#text(", available at ")#link("http://math.mit.edu/~primegaps/")[#text("this page")]#text("). So the main focus currently is on improving Ingredients 3 and 4.")

#text("For Ingredient 3, the basic variational problem is to understand the quantity")

#align(center)[#tao-fit-display[#mitex("M_k({\\cal R}_k) := \\sup_F \\frac{\\sum_{m=1}^k J_k^{(m)}(F)}{I_k(F)}")]]

#text("for ")#mi("{F: {\\cal R}_k \\rightarrow {\\bf R}}")#text(" bounded measurable functions, not identically zero, on the simplex")

#align(center)[#tao-fit-display[#mitex("{\\cal R}_k := \\{ (t_1,\\ldots,t_k) \\in [0,+\\infty)^k: t_1+\\ldots+t_k \\leq 1 \\}")]]

#text("with ")#mi("{I_k, J_k^{(m)}}")#text(" being the quadratic forms")

#align(center)[#tao-fit-display[#mitex("I_k(F) := \\int_{{\\cal R}_k} F(t_1,\\ldots,t_k)^2\\ dt_1 \\ldots dt_k")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("J_k^{(m)}(F) := \\int_{{\\cal R}_{k-1}} (\\int_0^{1-\\sum_{i \\neq m} t_i} F(t_1,\\ldots,t_k)\\ dt_i)^2 dt_1 \\ldots dt_{m-1} dt_{m+1} \\ldots dt_k.")]]

#text("Equivalently, one has")

#align(center)[#tao-fit-display[#mitex("M_k({\\cal R}_k) := \\sup_F \\frac{\\int_{{\\cal R}_k} F {\\cal L}_k F}{\\int_{{\\cal R}_k} F^2}")]]

#text("where ")#mi("{{\\cal L}_k: L^2({\\cal R}_k) \\rightarrow L^2({\\cal R}_k)}")#text(" is the positive semi-definite bounded self-adjoint operator")

#align(center)[#tao-fit-display[#mitex("{\\cal L}_k F(t_1,\\ldots,t_k) = \\sum_{m=1}^k \\int_0^{1-\\sum_{i \\neq m} t_i} F(t_1,\\ldots,t_{m-1},s,t_{m+1},\\ldots,t_k)\\ ds,")]]

#text("so ")#mi("{M_k}")#text(" is the operator norm of ")#mi("{{\\cal L}}")#text(". Another interpretation of ")#mi("{M_k({\\cal R}_k)}")#text(" is that the probability that a rook moving randomly in the unit cube ")#mi("{[0,1]^k}")#text(" stays in simplex ")#mi("{{\\cal R}_k}")#text(" for ")#mi("{n}")#text(" moves is asymptotically ")#mi("{(M_k({\\cal R}_k)/k + o(1))^n}")#text(".")

#text("We now have a fairly good asymptotic understanding of ")#mi("{M_k({\\cal R}_k)}")#text(", with the bounds")

#align(center)[#tao-fit-display[#mitex("\\log k - 2 \\log\\log k -2 \\leq M_k({\\cal R}_k) \\leq \\log k + \\log\\log k + 2")]]

#text("holding for sufficiently large ")#mi("{k}")#text(". There is however still room to tighten the bounds on ")#mi("{M_k({\\cal R}_k)}")#text(" for small ")#mi("{k}")#text("; I’ll summarise some of the ideas discussed so far below the fold.")

#text("For Ingredient 4, the basic tool is this:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Maynard)")]#text(" ")#metadata(none) <tao-ee4d988c65de860fabbf>#text(" If ")#mi("{EH[\\theta]}")#text(" is true and ")#mi("{M_k({\\cal R}_k) > \\frac{2m}{\\theta}}")#text(", then ")#mi("{H_m \\leq H(k)}")#text(".")
]

#text("Thus, for instance, it is known that ")#mi("{M_{105} > 4}")#text(" and ")#mi("{H(105)=600}")#text(", and this together with the Bombieri-Vinogradov inequality gives ")#mi("{H_1\\leq 600}")#text(". This result is ")#link("http://arxiv.org/abs/1311.4600")[#text("proven in Maynard’s paper")]#text(" and an alternate proof is also given in ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/")[#text("the previous blog post")]#text(".")

#text("We have a number of ways to relax the hypotheses of this result, which we also summarise below the fold.")

#metadata(none) <tao-18357e321977b7618cff>

#heading(level: 1)[#strong[#text(" — 1. Improved sieving — ")]]

#text("A direct modification of the proof of Theorem ")#link(<tao-ee4d988c65de860fabbf>)[#text("1")]#text(" also shows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" ")#metadata(none) <tao-d96e09118a50a5652cf4>#text(" If ")#mi("{MPZ[\\varpi,\\delta]}")#text(" is true and ")#mi("{M_k({\\cal R}_k \\cap [0,\\frac{\\delta}{1/4+\\varpi}]^k) > \\frac{m}{1/4+\\varpi}}")#text(", then ")#mi("{H_m \\leq H(k)}")#text(".")
]

#text("Here ")#mi("{M_k}")#text(" is defined for the truncated simplex ")#mi("{{\\cal R}_k \\cap [0,\\frac{\\delta}{1/4+\\varpi}]^k}")#text(" in the obvious fashion. This allows us to use the MPZ-type bounds obtained in Polymath8a, at the cost of requiring the test functions ")#mi("{F}")#text(" to have somewhat truncated support. Fortunately, in the large ")#mi("{k}")#text(" setting, the functions we were using had such a truncated support anyway. It looks likely that we can replace the cube ")#mi("{[0,\\frac{\\delta}{1/4+\\varpi}]^k}")#text(" by significantly larger regions by using the (multiple) dense divisibility versions of ")#mi("{MPZ}")#text(", but we have not yet looked into this.")

#text("It also appears that if one generalises the Elliott-Halberstam conjecture ")#mi("{EH[\\theta]}")#text(" to also encompass more general Dirichlet convolutions ")#mi("{\\alpha * \\beta}")#text(" than the von Mangoldt function ")#mi("{\\Lambda}")#text(" (see e.g. Conjecture 1 of ")#link("http://link.springer.com/article/10.1007/BF02399204")[#text("Bombieri-Friedlander-Iwaniec")]#text("), then one can enlarge the simplex ")#mi("{{\\cal R}_k}")#text(" in Theorem ")#link(<tao-ee4d988c65de860fabbf>)[#text("1")]#text(" (and probably for Theorem ")#link(<tao-d96e09118a50a5652cf4>)[#text("2")]#text(" also) to the slightly larger region")

#align(center)[#tao-fit-display[#mitex("{\\cal R}^{\\prime}_k := \\{ (t_1,\\ldots,t_k) \\in [0,+\\infty)^k: \\sum_{i \\neq m} t_i \\leq 1 \\text{ for all } m=1,\\ldots,k \\}.")]]

#text("Basically, the reason for this is that the restriction to the simplex ")#mi("{{\\cal R}_k}")#text(" (as opposed to ")#mi("{{\\cal R}^{\\prime}_k}")#text(") is only needed to control the sum ")#mi("{\\sum_n \\nu(n)}")#text(", but by splitting ")#mi("{\\nu}")#text(" into products of simpler divisor sums, and using the Elliott-Halberstam hypothesis to control one of the factors, it looks like one can still control error terms in the larger region ")#mi("{{\\cal R}^{\\prime}_k}")#text(" (but this will have to be checked at some point, if we end up using this refinement). This is only likely to give a slight improvement, except when ")#mi("{k}")#text(" is small; from the inclusions")

#align(center)[#tao-fit-display[#mitex("{\\cal R}_k \\subset {\\cal R}^{\\prime}_k \\subset \\frac{k}{k-1} \\cdot {\\cal R}_k")]]

#text("and a scaling argument we see that")

#align(center)[#tao-fit-display[#mitex("M_k({\\cal R}_k) \\leq M_k({\\cal R}^{\\prime}_k) \\leq \\frac{k}{k-1} M_k( {\\cal R}_k ).")]]

#text("Assume EH. To improve the bound ")#mi("{H_1 \\leq 12}")#text(" to ")#mi("{H_1 \\leq 10}")#text(", it suffices to obtain a bound of the form")

#align(center)[#tao-fit-display[#mitex("P_0 + P_2 + P_6 + P_8 + P_{12} > 1 + P_{0,12}")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("P_h = \\sum_n 1_{n+h \\text{ prime}} \\nu(n) / \\sum_n \\nu(n)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("P_{0,12} = \\sum_n 1_{n,n+12 \\text{ prime}} \\nu(n) / \\sum_n \\nu(n).")]]

#text("With ")#mi("{\\nu}")#text(" given in terms of a cutoff function ")#mi("{F}")#text(", the left-hand side ")#mi("{P_0 + P_2 + P_6 + P_8 + P_{12}}")#text(" can be computed as usual as")

#align(center)[#tao-fit-display[#mitex("P_0 + P_2 + P_6 + P_8 + P_{12} = \\frac{1}{2} \\sum_{m=0}^5 J_5^{(m)}(F) / I_5(F) + o(1)")]]

#text("while we have the upper bound")

#tao-aligned(keep: true)[


#tao-math("P_{0,12}  & \\leq \\frac{1}{2} \\int \\frac{(\\int_{t_1+t_5 \\leq 1-t_2-t_3-t_4} F(t_1,t_2,t_3,t_4,t_5)\\ dt_1 dt_5)^2}{1-t_2-t_3-t_4}\\ dt_2 t_3 t_4 / I_5(F)", block: true)



#tao-math(" & + o(1)", block: true)
]

#text("and other bounds may be possible. (This is discussed in ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/")[#text("this comment")]#text(".)")

#text("For higher ")#mi("{k}")#text(", it appears that similar maneuvers will have a relatively modest impact, perhaps shaving ")#mi("{\\sqrt{k}}")#text(" or so off of the current values of ")#mi("{k}")#text(".")

#heading(level: 1)[#strong[#text(" — 2. Upper bound on ")#mi("{M_k}")#text(" — ")]]

#text("We have the upper bound")

#align(center)[#tao-fit-display[#mitex("M_k \\leq (1 + \\frac{1}{A}) \\log(1+Ak)")]]

#text("for any ")#mi("{A>0}")#text(". To see this, observe from Cauchy-Schwarz that")

#align(center)[#tao-fit-display[#mitex("(\\int_0^{1-\\sum_{i \\neq m} t_i} F(t_1,\\ldots,t_k)\\ dt_i)^2 \\leq")]]

#align(center)[#tao-fit-display[#mitex("(\\int_0^{1-\\sum_{i \\neq m} t_i} (1+Akt_m) F(t_1,\\ldots,t_k)^2\\ dt_i)")]]

#align(center)[#tao-fit-display[#mitex("\\times (\\int_0^1 \\frac{1}{1+Akt_m}\\ dt_m).")]]

#text("The final factor is ")#mi("{\\frac{1}{Ak} \\log (1+Ak)}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("J_k^{(m)}(F) \\leq \\frac{1}{Ak} \\log (1+Ak) \\int_{{\\cal R}_k} (1+Akt_m) F(t_1,\\ldots,t_k)^2\\ dt_1 \\ldots dt_k.")]]

#text("Summing in ")#mi("{m}")#text(" and noting that ")#mi("{t_1+\\ldots+t_k \\leq 1}")#text(" on the simplex we have")

#align(center)[#tao-fit-display[#mitex("J_k^{(m)}(F) \\leq \\frac{1}{Ak} \\log (1+Ak) \\int_{{\\cal R}_k} (k+Ak) F(t_1,\\ldots,t_k)^2\\ dt_1 \\ldots dt_k,")]]

#text("and the claim follows.")

#text("Setting ")#mi("{A = \\log k}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("M_k \\leq \\log k + \\log\\log k + 2")]]

#text("for sufficiently large ")#mi("{k}")#text(". There may be some room to improve these bounds a bit further.")

#heading(level: 1)[#strong[#text(" — 3. Lower bounds on ")#mi("{M_k}")#text(" — ")]]

#text("For small ")#mi("{k}")#text(", one can optimise the quadratic form")

#align(center)[#tao-fit-display[#mitex("\\frac{\\int F {\\cal L} F}{\\int F^2}")]]

#text("by specialising ")#mi("{F}")#text(" to a finite-dimensional space and then performing the appropriate linear algebra. It is known that we may restrict without loss of generality to symmetric ")#mi("{F}")#text("; one could in principle also restrict to the functions of the form")

#align(center)[#tao-fit-display[#mitex("F(t_1,\\ldots,t_k) = \\sum_{m=1}^k G( t_1,\\ldots,t_{m-1},t_{m+1},\\ldots,t_k)")]]

#text("for some symmetric function ")#mi("{G: {\\cal R}_{k-1} \\rightarrow {\\bf R}}")#text(" (indeed, morally at least ")#mi("{F}")#text(" should be an eigenfunction of ")#mi("{{\\cal L}}")#text("), although we have not been able to take much advantage of this yet.")

#text("For large ")#mi("{k}")#text(", we can use the bounds")

#align(center)[#tao-fit-display[#mitex("M_k({\\cal R}_k)^m \\geq \\int_{{\\cal R}_k} F {\\cal L}^m F")]]

#text("for any ")#mi("{m \\geq 1}")#text(" and any ")#mi("{F}")#text(" with ")#mi("{\\int_{{\\cal R}_k} F^2 \\leq 1}")#text("; we can also start with a given ")#mi("{F}")#text(" and improve it by replacing it with ")#mi("{{\\cal L} F}")#text(" (normalising in ")#mi("{L^2}")#text(" if desired), and perhaps even iterating and accelerating this process.")

#text("The basic functions ")#mi("{F}")#text(" we have been using take the form")

#align(center)[#tao-fit-display[#mitex("F(t_1,\\ldots,t_k) := 1_{t_1+\\ldots+t_k \\leq 1} \\prod_{i=1}^k \\frac{k^{1/2}}{m_2^{1/2}} g(k t_i)")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("g(t) := 1_{[0,T]} \\frac{1}{1+AT}")]]

#text("and")

#tao-aligned(keep: true)[


#tao-math("m_1  & := \\int_0^T g(t)\\ dt = \\frac{1}{A} \\log(1+AT)", block: true)



#tao-math("m_2  & := \\int_0^T g(t)^2\\ dt = \\frac{1}{A} (1 - \\frac{1}{1+AT}) = \\frac{T}{1+AT}.", block: true)
]

#text("Then ")#mi("{\\int_{{\\cal R}_k} F^2 \\leq 1}")#text(", and")

#align(center)[#tao-fit-display[#mitex("M_k \\geq \\int F {\\cal L} F \\geq \\frac{m_1^2}{m_2} {\\bf P}( X_1 + \\ldots + X_{k-1} \\geq k - T )")]]

#text("where ")#mi("{X_1,\\ldots,X_k}")#text(" are iid random variables on ")#mi("{[0,T]}")#text(" with density ")#mi("{\\frac{1}{m_2} g(t)^2\\ dt}")#text(". By Chebyshev’s inequality we then have")

#align(center)[#tao-fit-display[#mitex("M_k \\geq \\frac{m_1^2}{m_2} ( 1 - \\frac{(k-1)\\sigma^2}{(k-T-(k-1)\\mu)^2} )")]]

#text("if ")#mi("{k-T-(k-1)\\mu>0}")#text(", where")

#tao-aligned(keep: true)[


#tao-math("\\mu  & := \\frac{1}{m_2} \\int_0^T t g(t)^2\\ dt", block: true)



#tao-math(" & = \\frac{1}{m_2} \\frac{1}{A^2}( \\log(1+AT) - 1 + \\frac{1}{1+AT} )", block: true)
]

#text("and")

#tao-aligned(keep: true)[


#tao-math("\\sigma^2  & := \\frac{1}{m_2} \\int_0^T t^2 g(t)^2\\ dt - \\mu^2", block: true)



#tao-math(" & = \\frac{1}{m_2} (\\frac{T}{A^2} + \\frac{T}{A^2 (1+AT)} - \\frac{2\\log(1+AT)}{A^3}) - \\mu^2.", block: true)
]

#text("A lengthier computation for ")#mi("{\\int F {\\cal L}^2 F}")#text(" gives")

#tao-aligned(keep: true)[


#tao-math("M_k^2  & \\geq (1-\\frac{1}{k}) \\frac{m_1^4}{m_2^2} (1 - \\frac{(k-2)\\sigma^2}{(k-2T-(k-2)\\mu)^2})", block: true)



#tao-math(" & + \\frac{1}{k} \\frac{m_1^2}{m_2} (k-T-(k-1)\\mu)", block: true)
]

#text("assuming ")#mi("{k-2T-(k-2)\\mu > 0}")#text(".")

#heading(level: 1)[#text("Comments (129)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-252415")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("It might be time to start collecting upper and lower bounds for ")#mi("M_k")#text(" for small k (say, up to k=105) to get a sense of how much room there is for improvement here, and what one can hope to achieve from the MPZ estimates (or from using fancier symmetric functions). The fact that ")#mi("M_k")#text(" is now known to not grow any faster than ")#mi("\\log k")#text(" is a little disappointing for the large ")#mi("m")#text(" theory, but perhaps there is yet another way to modify the sieve to break this barrier (much as the GPY sieve, for which M_k never exceeded 4, was modified into the current sieve introduced by James). The only “hard” obstruction I know of is the parity obstruction, which basically stems from the belief that ")#mi("\\sum_n \\nu(n) \\mu(n+h)")#text(" is negligible for just about any sieve under consideration, which means in probabilistic terms that")

#mi("{\\bf P}( n+h \\text{ has an odd number of prime factors} ) = 1/2+o(1)")

#text("and in particular")

#mi("{\\bf P}( n+h \\text{ is prime} ) \\leq 1/2+o(1).")

#text("This translates to the trivial bound ")#mi("M_k \\leq k")#text(" in the current context, which is well short of the truth; it seems there is a substantial gap between “having an odd number of prime factors” and “is prime” when is working with k-tuple sieves.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-252451")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("I thought I’d play around with your heuristics for ")#mi("P_{0,12}")#text(".")

#text("If we plug in Maynard’s function")

#mi("F=(1-P_1)P_2")#text(" ")#mi("+ \\frac{7}{10}(1-P_1)^2")#text(" ")#mi("+\\frac{1}{14}P_2 - \\frac{3}{14}(1-P_1)")

#text("(where ")#mi("P_1,P_2")#text(" are the first two power-symmetric polynomials) into the upper-bound for ")#mi("P_{0,12}")#text(" (and dropping little-o terms) we get that ")#mi("1+P_{0,12}\\leq 1.11662")#text(". We needed to beat ")#mi("1.00058")#text(" to force ")#mi("k")#text(" down one.")

#text("I imagine that there are better choices for ")#mi("F")#text(" in this context, and I’ll start thinking about that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-252464")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("One can presumably get some gain by enlarging the support of F from the simplex to the larger (but more complicated) region ")#mi("\\{ t_1+\\ldots+t_5 \\leq 1 + \\min(t_1,\\ldots,t_5)\\}")#text(". (The cutoff ")#mi("t_1+t_5 \\leq 1-t_2-t_3-t_4")#text(" in the formula for ")#mi("P_{0,12}")#text(" would be similarly modified.) One would have to do a certain amount of fiddly numerics though to integrate on this more messy polytope.")

#text("Also, we’ve broken the symmetry a bit, and it’s no longer necessarily optimal to use F that are symmetric in all five variables; instead, it should just be symmetric in ")#mi("t_1,t_5")#text(" and in ")#mi("t_2,t_3,t_4")#text(". But perhaps we get a bit more flexibility with this broken symmetry.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-252649")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2013")])]

#text("In a ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251876")[#text("previous comment")]#text(", James indicated that if we simply inserted our best confirmed value ")#mi("\\varpi = 7/600")#text(" into the low k machinery, ignoring delta, we could potentially reduce k from 105 to 68 (and presumably we do a little better than this if we use the tentative value ")#mi("\\varpi = 13/1080")#text("). The main thing blocking us from making this a rigorous argument is that in order to use ")#mi("MPZ[\\varpi,\\delta]")#text(", we have to use test functions F that are not only restricted to the simplex, but also to the cube ")#mi("[0, \\frac{\\delta}{1/4+\\varpi}]^k")#text(". This is not a serious problem for the large k argument (because the test functions were already by design supported on the cube ")#mi("[0,T/k]^k")#text(") but is so for the low k argument (because we are instead using polynomials of the symmetric polynomials P_1 and P_2.")

#text("However, it could be, as was the experience in Zhang and Polymath8a, that the contributions outside of this cube are exponentially small and thus hopefully negligible (although we have to be careful because our values of k are now small enough that “exponentially small” does not _automatically_ imply negligibility any longer). Basically we could follow arguments similar to that in Section 4 of the Polymath8a paper, writing the truncated F as ")#mi("F_1 - F_2")#text(" where ")#mi("F_1")#text(" is untruncated and ")#mi("F_2")#text(" is the portion outside of the cube, and use the inequality")

#mi("\\int F {\\cal L} F \\geq \\int F_1 {\\cal L} F_1 - 2 \\int F {\\cal L} F_2")

#text("and upper bound the error term ")#mi("\\int F {\\cal L} F_2")#text(" by controlling the contribution when a given coordinate ")#mi("t_i")#text(" exceeds ")#mi("\\frac{\\delta}{1/4+\\varpi}")#text(". Here the point is that this is a small portion of the simplex; by volume, it is something like ")#mi("k (1 - \\frac{\\delta}{1/4+\\varpi} )^k")#text(".")

#text("At present, ")#mi("\\delta,k")#text(" are so small that this is actually not so negligible, but we can then pull out the other Polymath8a trick, which is to exploit dense divisibility and introduce another parameter ")#mi("\\delta^{\\prime}")#text(" . This allows us to enlarge the cube ")#mi("[0, \\frac{\\delta}{1/4+\\varpi}]^k")#text(" to something like the portion of ")#mi("[0, \\frac{\\delta^{\\prime}}{1/4+\\varpi}]^k")#text(" in which ")#mi("\\sum_{t_j > \\frac{\\delta}{1/4+\\varpi}} t_j > i \\delta^{\\prime} - \\delta")#text(" (this is basically Lemma 4.12(iv) from ")#link("https://www.dropbox.com/s/16bei7l944twojr/newgap.pdf")[#text("Polymath8a")]#text("), which should lead to better error terms as per Polymath8a.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-252740")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2013")])]

#text("A little bit more elaboration of the above idea, using some of the Cauchy-Schwarz arguments from the upper bound theory.")

#text("Let ")#mi("F_1")#text(" be some symmetric test function on the simplex, and let ")#mi("F")#text(" be the restriction of ")#mi("F_1")#text(" to the cube ")#mi("[0,\\tilde \\delta]^k")#text(" where ")#mi("\\tilde \\delta = \\frac{\\delta}{1/4+\\varpi}")#text(". Then ")#mi("F = F_1 - F_2")#text(" where ")#mi("F_2")#text(" is the portion of ")#mi("F_1")#text(" outside of the cube. We then have")

#mi("\\int F {\\cal L} F = \\int F_1 {\\cal L} F_1 - 2 \\int F {\\cal L} F_2 - \\int F_2 {\\cal L} F_2.")

#text("The last term we can bound by ")#mi("M_2 \\int F_2^2")#text(". Now we try to upper bound ")#mi("\\int F {\\cal L} F_2")#text(". By symmetry this is")

#mi("k \\int_{{\\cal R}_{k-1}} (\\int F(t_1,t_2,\\ldots,t_k)\\ dt_1) (\\int F_2(t^{\\prime}_1,t_2,\\ldots,t_k)\\ dt^{\\prime}_1)\\ dt_2 \\ldots dt_k")#text(". (1)")

#text("The integrand is only non-zero when ")#mi("t^{\\prime}_1 \\geq \\tilde \\delta \\geq t_1")#text(" and ")#mi("t_2,\\ldots,t_k \\leq \\tilde \\delta")#text(". By Cauchy-Schwarz we have")

#mi("\\displaystyle \\int F(t_1,t_2,\\ldots,t_k)\\ dt_1 \\leq \\frac{\\log^{1/2}(1+kA\\tilde \\delta)}{(kA)^{1/2}}")

#mi("\\displaystyle ( \\int F(t_1,\\ldots,t_k)^2 (1+kAt_1)\\ dt_1 )^{1/2}")

#text("and")

#mi("\\displaystyle \\int F_2(t_1,t_2,\\ldots,t_k)\\ dt_1 \\leq (1-\\tilde \\delta)^{1/2} ( \\int F_2(t_1,\\ldots,t_k)^2\\ dt_1 )^{1/2}")

#text("and so by the AM-GM inequality we can bound (1) by")

#mi("\\displaystyle \\frac{1}{2} \\frac{k^{1/2} \\log^{1/2}(1+kA \\tilde \\delta)}{A^{1/2}} (1-\\tilde \\delta)^{1/2} (k^{-1/2} \\varepsilon \\int F^2 (1+kAt_1)\\ dt_1 \\ldots dt_k")#linebreak()#text(" ")#mi("\\displaystyle + k^{1/2} \\varepsilon^{-1} \\int_{t_2,\\ldots,t_k \\leq \\tilde \\delta} F_2^2\\ dt_1 \\ldots dt_k )")

#text("for any ")#mi("\\varepsilon")#text(", which symmetrises to")

#mi("\\displaystyle \\frac{1}{2} \\frac{\\log^{1/2}(1+kA \\tilde \\delta)}{A^{1/2}} (1-\\tilde \\delta)^{1/2} (\\varepsilon \\int F^2 (1+A)\\ dt_1 \\ldots dt_k")#linebreak()#text(" ")#mi("\\displaystyle + \\varepsilon^{-1} \\int F_2^2\\ dt_1 \\ldots dt_k )")

#text("(here we use the disjoint supports of the various ")#mi("F_2")#text(" integrals) so on optimising in ")#mi("\\varepsilon")#text(" we obtain a bound of")

#mi("\\displaystyle \\log^{1/2}(1+kA \\tilde \\delta) (1+\\frac{1}{A})^{1/2} (1-\\tilde \\delta)^{1/2} (\\int F^2)^{1/2} (\\int F_2^2)^{1/2}")

#text("so one just need a reasonably good bound on ")#mi("\\int F_2^2")#text(" (compared with ")#mi("\\int F^2")#text(") to be able to neglect these errors. As I said before, the ratio of ")#mi("\\int F_2^2")#text(" to ")#mi("\\int F^2")#text(" is likely to be something like ")#mi("k (1 - \\tilde \\delta)^k")#text("; this doesn’t look too good for the values of k we are considering (i.e. below 105), but maybe if we split into two deltas as before, then it won’t be so bad.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-252663")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2013")])]

#text("In the above definition of ")#mi("J_k^{(m)}")#text(", the subscript ")#mi("i")#text(" in")#linebreak()#text(" ")#mi("d t_i, d t_{i-1}, d t _{i+1}")#text(" should be replaced by ")#mi("m")#text(".")#linebreak()#text(" (with similar correction in the proof of the upper bound on ")#mi("M_k")#text(".)")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-252693")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2013")])]

#text("This typo still appears in several places")

#text("1. In the definition of ")#mi("j_k^{(m)}")#text(", ")#mi("d t_i")#text(" should be ")#mi("d t_m")#text(" and the last ")#mi("d t")#text(" in the integral should be ")#mi("d t_k")#text(".")

#text("2. In the proof of the upper bound on ")#mi("M_k")#text(", in the first two integrals")#linebreak()#text(" ")#mi("d t_i")#text(" should be ")#mi("d t_m")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-252679")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2013")])]

#text("In the proof of the upper bound on ")#mi("M_k")#text(", it should be")#linebreak()#text(" “noting that ")#mi("t_1 + ... + t_k \\leq 1")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-252684")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2013")])]

#text("Here is an idea that might not pan out, but I’m throwing it out there anyways.")

#text("Take k=3 for brevity. Right now, we need to control sums such as ")#mi("\\sum_n \\Lambda(n) \\nu(n)")#text(", where ")#mi("\\nu(n)")#text(" is a divisor sum basically of the form")

#mi("\\sum_{d_1|n, d_2|n+2, d_3|n+6} \\lambda_{d_1,d_2,d_3}.")

#text("We can then set ")#mi("d_1=1")#text(" and are looking at a sum of the form")

#mi("\\sum_{d_2,d_3} \\lambda_{1,d_2,d_3} \\sum_{n: n=-2\\ (d_2), n = -6\\ (d_3)} \\Lambda(n).")

#text("We can compare the inner sum against its expected value ")#mi("E_{d_2,d_3} = \\frac{x}{\\phi([d_2,d_3])}")#text(", and are left with dealing with an error term")

#mi("\\sum_{d_2,d_3} \\lambda_{1,d_2,d_3} ( \\sum_{n: n=-2\\ (d_2), n = -6\\ (d_3)} \\Lambda(n) - E_{d_2,d_3} ).")

#text("Now at this point, what Zhang and Polymath8a do is to take absolute values and start looking at something roughly of the shape")

#tao-math("\\sum_d \\left| \\sum_{n=a\\ (d)} \\Lambda(n) - E_d\\right|", block: false)

#text("where ")#mi("d")#text(" came from ")#mi("[d_2,d_3]")#text(" and ")#mi("a\\ (d)")#text(" is something formed from the Chinese remainder theorem (and thus could potentially be quite large). But this throws away two things: firstly, that the residue class ")#mi("a\\ (d)")#text(" came from two residue classes which were bounded, and secondly, that the coefficients ")#mi("\\lambda_{1,d_2,d_3}")#text(" were not completely arbitrary, but instead had a somewhat multiplicative structure (basically of the form ")#mi("\\mu( d_2 d_3 )")#text("). It may be that if we delve into the Type I/II estimates, we can exploit this extra structure to go beyond the exponents that we currently do. In particular, the coefficients ")#mi("c_{q,r}")#text(" that show up in Polymath8a roughly seem to have the shape ")#mi("\\mu(q) \\mu(r)")#text(" (times smooth factors), and so ")#mi("c_{q,r} c_{q^{\\prime},r}")#text(" has some smoothness in r which looks helpful (but somewhat difficult to exploit).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-252720")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2013")])]

#text("Am I right in assuming that the recent “Deligne-free” values from Pace that are shown on the “world records” page are derived assuming only B-V, following James’s paper? If so, perhaps it would be of interest to do as in Polymath8a and have a look at what k0 values the Deligne-free [varpi,delta] derived on July 30th gives rise to in the post-Maynard universe?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253054")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("This is something we can certainly do without much difficulty once our results have stabilised, but at present the four benchmarks we have (m=1 from BV, m=1 using Polymath8a, m=2 from BV, m=2 using Polymath8a) are covering enough of the “parameter space” that any further benchmarking would probably just be confusing (although perhaps a m=3 case, say using the best Polymath8a result, might be worth looking at).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ba4bbbd5ec2022c4d2c416ce26986abcf57f3bc5cc91f39f46704b805cfdad1c-5f4be7c2dedbc0aff0e38d79a14c081334db35718af1b7f7008637fc1de17a29.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao’s ”What’s New”- The Polymath. | Edgar's Creative")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-252783")[#strong[#text("Terence Tao’s ”What’s New”- The Polymath. | Edgar's Creative")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2013")])]

#text("[…] Polymath8b, II: Optimising the variational problem and the sieve. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-252860")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2013")])]

#text("The upper and lower bounds on ")#mi("M_k")#text(" may be improved (in particular for small ")#mi("k")#text(") by generalizing the basic function ")#mi("1+A t")#text(" (e.g. by ")#mi("1+ A t + B t^2")#text(") and optimizing over the additional parameters (e.g. ")#mi("B")#text(") as well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-252943")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2013")])]

#text("I don’t understand (8.9) in Maynard’s paper (the integral is divergent.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-252945")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2013")])]

#text("There is a minor typo. He just dropped ")#mi("\\prod_{i=2}^{k} g(u_i)^2")#text(" from the integral.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-252946")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2013")])]

#text("To see the equality in (8.9) after that factor is reinserted, just integrate each summand separately, and count.")

#text("By the way, I had your very question earlier. There seems to be a second typo in the line above (8.13). It says that ")#mi("\\int_{0}^{T} u g(u)^2 du=\\mu")#text(", but I believe the RHS should be ")#mi("\\mu\\gamma")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-252948")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2013")])]

#text("Thanks for the explanation!")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253090")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("Just to confirm: Everything that Pace says is correct. Both of these are typos in the paper – sorry for the confusion this caused.")

#text("If anyone happens to spot similar typos I’d quite like to hear – either emailing me or mentioning on here would be appreciated!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-252993")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2013")])]

#text("I can now modify the Cauchy-Schwarz argument to prove the clean upper bound")

#mi("\\displaystyle M_k \\leq \\frac{k}{k-1} \\log k")#text(" (1)")

#text("which saves a ")#mi("\\log\\log k")#text(" or so from the previous bound.")

#text("The key estimate is")

#mi("\\displaystyle (\\int_0^{1-t_2-\\ldots-t_k} F(t_1,\\ldots,t_k)\\ dt_1)^2")

#mi("\\displaystyle \\leq \\frac{\\log k}{k-1} \\int_0^{1-t_2-\\ldots-t_k} F(t_1,\\ldots,t_k)^2 (1 - t_1-\\ldots-t_k+ kt_1)\\ dt_1.")#text(" (2)")

#text("Assuming this estimate, we may integrate in ")#mi("t_2,\\ldots,t_k")#text(" to conclude that")

#mi("\\displaystyle J_k^{(1)}(F) \\leq \\frac{\\log k}{k-1} \\int F^2 (1-t_1-\\ldots-t_k+kt_1)\\ dt_1 \\ldots dt_k")

#text("which symmetrises to")

#mi("\\displaystyle \\sum_{m=1}^k J_k^{(m)}(F) \\leq k \\frac{\\log k}{k-1} \\int F^2\\ dt_1 \\ldots dt_k")

#text("giving (1).")

#text("It remains to prove (2). By Cauchy-Schwarz, it suffices to show that")

#mi("\\displaystyle \\int_0^{1-t_2-\\ldots-t_k} \\frac{dt_1}{1 - t_1-\\ldots-t_k+ kt_1} \\leq \\frac{\\log k}{k-1}.")

#text("But writing ")#mi("s = t_2+\\ldots+t_k")#text(", the left-hand side evaluates to")

#mi("\\frac{1}{k-1} (\\log k(1-s) - \\log (1-s) ) = \\frac{\\log k}{k-1}")

#text("as required.")

#text("This also suggests that extremal F behave like multiples of ")#mi("1 / (1-t_1-\\ldots-t_k + kt_1)")#text(" in the ")#mi("t_1")#text(" variable for typical fixed choices of ")#mi("t_2,\\ldots,t_k")#text(".")

#text("In the converse direction, I have an asymptotic bound")

#mi("\\displaystyle M_k \\geq \\log k - \\log\\log\\log k + O(1)")

#text("for sufficiently large k. Using the notation of the previous post, we have the lower bound")

#mi("\\displaystyle M_k \\geq \\frac{m_1^2}{m_2} {\\bf P}( X_1 + \\ldots + X_{k-1} \\geq k - T )")

#text("whenever ")#mi("g")#text(" is supported on ")#mi("[0,T]")#text(", ")#mi("m_i = \\int_0^T g(t)^i\\ dt")#text(", and ")#mi("X_1,\\ldots,X_k")#text(" are independent random variables on [0,T] with density ")#mi("\\frac{1}{m_2} g(t)^2\\ dt")#text(". We select the function")

#mi("g(t) = \\frac{1}{1 + A t}")

#text("with ")#mi("A := \\log k")#text(", and ")#mi("T := \\varepsilon \\frac{k}{A}")#text(" for some ")#mi("0 < \\varepsilon < 1")#text(" to be chosen later. We have")

#mi("m_1 = \\frac{1}{A} \\log(1+AT) = \\frac{1}{\\log k} \\log( 1 + \\varepsilon k)")

#text("and")

#mi("m_2 = \\int_0^T \\frac{1}{(1+At)^2}\\ dt")#linebreak()#text(" ")#mi("= \\frac{1}{A} - \\frac{1}{A (1+AT)}")#linebreak()#text(" ")#mi("\\leq \\frac{1}{A} = \\frac{1}{\\log k}")

#text("and so")

#mi("\\displaystyle M_k \\geq \\frac{\\log^2(1+\\varepsilon k)}{\\log k} {\\bf P}( X_1 + \\ldots + X_{k-1} \\geq k - T ).")

#text("Observe that the random variables ")#mi("X_i")#text(" have mean")

#mi("\\mu = \\frac{1}{m_2} \\frac{1}{A^2} (\\log(1+AT)-1+\\frac{1}{1+AT})")

#mi("= (A + \\frac{1}{\\varepsilon k}) (\\log(1+\\varepsilon k)-1+\\frac{1}{1+\\varepsilon k})")

#mi("\\leq 1 - \\frac{1}{\\log k} + O( \\frac{\\log k}{\\varepsilon k} ).")

#text("The variance ")#mi("\\sigma^2")#text(" may be bounded crudely by")

#mi("\\sigma^2 \\leq \\frac{1}{m_2} \\int_0^T \\frac{t^2}{(1+At)^2}\\ dt")#linebreak()#text(" ")#mi("= O( A \\frac{T}{A^2} ) = O( \\frac{\\varepsilon k}{\\log^2 k} ).")

#text("Thus the random variable ")#mi("X_1 + \\ldots + X_{k-1}")#text(" has mean at most ")#mi("k - \\frac{k}{\\log k} + O( \\frac{\\log k}{\\varepsilon} )")#text(" and variance ")#mi("O( \\frac{\\varepsilon k^2}{\\log^2 k} )")#text(", with each variable bounded in magnitude by ")#mi("T = \\frac{\\varepsilon k}{\\log k}")#text(". By Hoefding’s inequality, this implies that ")#mi("X_1 + \\ldots + X_{k-1}")#text(" is at most ")#mi("k - T")#text(" with probability at most ")#mi("O( \\exp(- c / \\varepsilon^2 )")#text(" for some absolute constant ")#mi("c")#text(". If we set ")#mi("\\varepsilon = C / (\\log \\log k)^{1/2}")#text(" for a sufficiently large absolute constant ")#mi("C")#text(", we thus have")

#mi("\\displaystyle {\\bf P}( X_1 + \\ldots + X_{k-1} \\geq k - T ) = 1 - O( 1 / \\log k)")

#text("and thus")

#mi("\\displaystyle M_k \\geq \\log k - \\log\\log\\log k + O(1)")

#text("as claimed.")

#text("Hoeffding’s bound is proven by the exponential moment method, which more generally gives the bound")

#mi("\\displaystyle M_k \\geq \\frac{m_1^2}{m_2} (1 - e^{-s(k-T)} (\\frac{1}{m_2} \\int_0^T g(t)^2 e^{st}\\ dt)^{k-1} )")

#text("for any ")#mi("s > 0")#text(", which is a somewhat complicated, but feasible-looking, optimisation problem in A, T, s. (Roughly speaking, one expects to take A close to ")#mi("\\log k")#text(", T a bit smaller than ")#mi("k/log k")#text(", and ")#mi("s")#text(" roughly of the order of ")#mi("\\log k / k")#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253038")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("As an interesting application of this upper bound, we have")

#text("1. ")#mi("M_4 \\leq 1.848... < 2")#text(", so under EH the current method is limited to")#linebreak()#text(" ")#mi("k_0 = 5")#text(".")

#text("2. ")#mi("M_{50} \\le 3.9918... < 4")#text(", so Under EH[1/2] the current method is limited to ")#mi("k_0 \\geq 51")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253056")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("Or 42 under the polymath8a results, yes? (I believe the confirmed and tentative versions both give this value.) Or am I overinterpreting earlier posts concerning the derivability of M from varpi?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253399")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2013")])]

#text("Unfortunately, the particular ")#mi("F")#text(" above (used for the derivation of the upper bound) is not in ")#mi("L^2(\\mathcal R_k)")#text(" (since the integration of ")#mi("F^2")#text(" with respect to ")#mi("t_1")#text(" gives ")#mi("1/(k(1- t_2 - ... - t_k))")#text(" – which is not integrable over ")#mi("\\mathcal R_{k-1}")#text(") – so this ")#mi("F")#text(" can’t be used as a basis function for lower bounds evaluation.")

#text("It should be remarked that ")#mi("\\mathcal L F \\in L^2(\\mathcal R_k)")#text(" – since it has only logarithmic singularity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255837")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2013")])]

#text("For ")#mi("k=5")#text(" the upper bound is ")#mi("M_5 \\le 2.011797...")#text(", while from (7.19) in Maynard’s paper ")#mi("M_5 \\ge 2.001162...")#text(" – showing that the upper bound is surprisingly good even for ")#mi("k=5")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-445084")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2014")])]

#text("It seems that there is an error in the above derivation of the lower bound since ")#mi("m_2 \\leq 1/A = 1/\\log k")#text(" (not ")#mi("\\log k")#text(" as in the above derivation!)")

#emph[#text("[Corrected, thanks – there was a similar factor missing in the ")#mi("m_1")#text(" bound which cancels out the error. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-451331")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2015")])]

#text("There is another error in the lower bound derivation:")#linebreak()#text(" It seems that Hoeffding’s inequality (which is independent of the variance) gives ")#mi("O(\\exp(-c/(k \\varepsilon^2)))")#text(" for the probability estimate – which is clearly too crude!")#linebreak()#text(" The problem in using this inequality is that the denominator in the exponent is ")#mi("(k-1) T^2")#text(" while the (much smaller!) numerator is only ")#mi("O((k/\\log k)^2)")#text(".")

#text("Fortunately, by using the above variance estimate, it follows from Bennett’s inequality (or even from Bernstein’s inequality) the probability estimate ")#mi("O(\\exp(-c/ \\varepsilon))")#text(" which implies the (slightly weaker) lower bound")

#mi("M_k \\geq \\log k - 2 \\log \\log \\log k + O(1)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-447656")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2014")])]

#text("For the last lower bound on ")#mi("M_k")#text(", it is easy to verify that the lower bound is maximized by (temporarily) fixing ")#mi("T, s > 0")#text(" and maximizing the integral ")#mi("m_1")#text(" over ")#mi("g \\in L^2(0, T)")#text(" under the two (integral) constraints that ")#mi("m_2")#text(" and ")#mi("\\lambda := \\int_0^T g(t)^2 e^{s t}dt")#text(" are fixed. It is easy to show that the optimal function ")#mi("g(t)")#text(" has the form ")#mi("g(t) = 1/(e^{s t}+C)")#text(" for some ")#mi("C > -1")#text(".")#linebreak()#text(" Fortunately, the resulting integrals representing ")#mi("m_1, m_2, \\lambda")#text(" (needed for the lower bound) are simple elementary functions of ")#mi("T, s, C")#text(" – enabling simpler optimization of the lower bound over the parameters ")#mi("T, s, C")#text(".")#linebreak()#text(" For large ")#mi("k")#text(", it seems that the paremeters ")#mi("T, s, C")#text(" can be reparametrized by")#linebreak()#text(" ")#mi("s = \\alpha \\log k \\log \\log k /k")#linebreak()#text(" ")#mi("T = \\beta k / \\log k")#linebreak()#text(" ")#mi("C = -1 + \\gamma \\log \\log k /k")

#text("Where ")#mi("1 \\ll \\alpha, \\beta, \\gamma \\ll 1")#text(" are the new parameters.")#linebreak()#text(" (Unfortunately, it seems that asymptotically we still get the above lower bound implied by Hoeffding inequality.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253005")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2013")])]

#text("Seems k0 can drop some, assuming the implementation is correct.")

#text("With ")#mi("\\frac{1080}{13}\\varpi + \\frac{330}{13}\\delta <1")#text(": ")#mi("k")#text("=")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi1080d13_339.mpl")[#text("339")]

#text("Without using the ")#mi("\\varpi, \\delta")#text(" inequalities: ")#mi("k")#text("=")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpinull_385.mpl")[#text("385")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253064")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("Two small thoughts:")

#text("1. The Cauchy-Schwarz argument giving upper bounds on ")#mi("M_k")#text(" might more generally be able to give upper bounds for the quantity")

#mi("\\sum_{m=1}^k \\sum_n \\nu(n) 1_{n+h_i \\text{ prime}}/\\sum_n \\nu(n)")

#text("for any Selberg sieve")

#mi("\\nu(n) = (\\sum_{d_1|n_h+1,\\ldots,d_k|n+h_k} \\lambda_{d_1,\\ldots,d_k})^2")

#text("regardless of the choice of coefficients ")#mi("\\lambda_{d_1,\\ldots,d_k}")#text(", assuming that the error terms are manageable (which presumably means something like ")#mi("d_1 \\ldots d_k \\leq x^{\\theta/2}")#text(" where ")#mi("\\theta")#text(" is the level of distribution) and also some mild size conditions on the coefficients (e.g. all of size ")#mi("x^{o(1)}")#text("). Upper bounds are of course less directly satisfying than lower bounds (particularly for the purposes of advancing the “world records” table) but would help give a picture of what more one can expect to squeeze out of these methods. (And we also have some possible ways to evade these upper bounds, e.g. by utilising the two-point correlations ")#mi("\\sum_n \\nu(n) 1_{n+h_i, n+h_j \\text{ prime}}")#text(" as discussed previously; one could also hope to use other sieves than the Selberg sieve, though I don’t see at present what alternatives would be viable.)")

#text("2. As mentioned in Maynard’s paper, the method here would also allow one to produce small gaps in other sets than the primes, as long as one had a non-trivial level of distribution ")#mi("\\theta")#text(". For instance, if one replaced primes by semiprimes (products of exactly two primes) ")#link("http://arxiv.org/abs/math/0609615")[#text("Goldston-Graham-Pintz-Yildirim")]#text(" obtained the bounds ")#mi("H_1 \\leq 6")#text(" and ")#mi("H_m \\leq m e^{m-\\gamma}  (1+o(1))")#text(" unconditionally. These bounds are already quite good (semiprimes are significantly denser than primes, which is why the results here are better than those for primes) but perhaps there is further room for improvement.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253072")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("Just did a quick calculation: using Maynard’s sieve (with T equal to, say, ")#mi("k^{1/2}")#text(") the quantity ")#mi("\\sum_n \\nu(n) 1_{n+h_i \\text{ semiprime}} / \\sum_n \\nu(n)")#text(" looks to be roughly on the order of ")#mi("\\log^2 k /k")#text(" (compared to ")#mi("\\log k/k")#text(" in the case of primes), by counting products of two primes each of size at least ")#mi("x^{T/k}")#text(". (For semiprimes with smaller factors than this, the sieve weight ")#mi("\\nu(n)")#text(" becomes smaller.) So this would give something like ")#mi("H_k \\ll \\exp( O( \\sqrt{k} ) )")#text(" for semiprimes, and more generally ")#mi("H_k \\ll \\exp( O( k^{1/r} ) )")#text(" for products of exactly r primes (with implied constants depending on r).")

#text("Actually, in many ways, the numerology for our current problem with primes is very similar to the GGPY numerology for semiprimes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253118")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("Looks like the Cauchy-Schwarz argument does indeed block the Selberg sieve from doing much better than ")#mi("\\log k")#text(" primes in a k-tuple, assuming that the weights are fairly uniform in magnitude, which among other things, allows one to discard the small fraction of weights in which the heuristic ")#mi("g(r) \\approx \\varphi(r) \\approx r")#text(" mentioned in Section 6 of Maynard’s paper fails. The analogue of the ratio ")#mi("\\sum_m J_k^{(m)}(F) / I_k(F)")#text(" is then (in the notation of the paper)")

#mi("\\displaystyle \\frac{W}{\\phi(W) \\log N} ( \\sum_{m=1}^k \\sum_{r_1,\\ldots,r_k: r_m=1} \\frac{1}{r_1 \\ldots r_k} (\\sum_{a_m} \\frac{y_{r_1,\\ldots,r_{m-1},a_m,r_{m+1},\\ldots,r_k}}{a_m} )^2 )")#linebreak()#text(" ")#mi("\\displaystyle / \\sum_{r_1,\\ldots,r_k} y_{r_1,\\ldots,r_k}^2 / r_1 \\ldots r_k.")

#text("Cauchy-Schwarz then gives")

#mi("\\displaystyle (\\sum_{a_m} \\frac{y_{r_1,\\ldots,r_{m-1},a_m,r_{m+1},\\ldots,r_k}}{a_m} )^2")#linebreak()#text(" ")#mi("\\displaystyle \\ll \\frac{\\phi(W) \\log N}{W} \\frac{\\log(1+kA)}{kA} \\sum_{a_m} \\frac{y_{r_1,\\ldots,r_{m-1},a_m,r_{m+1},\\ldots,r_k}^2}{a_m} (1 + k A \\frac{\\log a_m}{\\log N} )")

#text("for any ")#mi("A>0")#text(" (using the fact that ")#mi("a_m")#text(" is constrained to be coprime to ")#mi("W")#text("); using this and summing in ")#mi("m")#text(" (using the constraint ")#mi("r_1 \\ldots r_{m-1} a_m r_{m+1} \\ldots r_k \\ll R")#text(") shows that the ratio is of size ")#mi("\\ll \\frac{A+1}{A} \\log(1+kA)")#text(", which for bounded choices of A gives a bound of ")#mi("O(\\log k)")#text(". If one works this argument more carefully we get the same upper bounds that we do for the integral variational problem ")#mi("M_k")#text(".")

#text("There is a potential loophole in using sieve weights that focus on those moduli r with a unusually large number of prime factors (so that ")#mi("g(r), \\varphi(r), r")#text(" are no longer close to each other), but this is a very sparse set of moduli, to the point where the error terms in the sieve analysis now overwhelm the main terms. Also, intuitively one should not be able to get a good sieve by using only a sparse set of the available moduli.")

#text("To me, this suggests that the main remaining hope for breaking the logarithmic barrier is to work with a wider class of sieves than the Selberg sieve. In principle there are a lot of other possible sieves to use (e.g. beta sieve or other combinatorial sieves), but numerically these sieves tend to underperform the Selberg sieve for these sorts of problems (enveloping the primes in a sieve weighted on almost primes in order to make the density of the primes as large as possible). It’s tempting to try to perturb the Selberg sieve in some combinatorial fashion, but the trick is to keep the sieve non-negative (which is crucial in our argument, unless one can somehow get excellent control on the negative portion of the sieve); once one leaves the Selberg sieve form ")#mi("\\nu(n) = \\gamma(n)^2")#text(" this becomes quite non-trivial.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253151")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2013")])]

#text("Perhaps there is some generalization to a sieve combining translates of several admissible tuples.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253191")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2013")])]

#text("I’m now leaning towards the view that any replacement for the Selberg sieve ")#mi("\\nu")#text(" will also encounter a logarithmic type barrier, in that the density ")#mi("\\sum_n \\nu(n) 1_{n+h_i\\text{ prime}}/\\sum_n \\nu_n")#text(" is unlikely to be much higher than ")#mi("O(\\log k/k)")#text(". Actually it is rather miraculous that we get the logarithmic gain at all, a naive heuristic computation (which I give below) suggests that ")#mi("O(1/k)")#text(" should be the threshold.")

#text("To motivate things, suppose we start with a one-dimensional sieve ")#mi("\\nu(n) = \\sum_{d|n} \\alpha_d")#text(", where ")#mi("\\alpha_d")#text(" are some coefficients for ")#mi("d")#text(" up to some height ")#mi("x^c")#text(". In the Selberg sieve case this divisor sum is the square of some other divisor sum ")#mi("\\sum_{d|n: d \\leq R} \\lambda_d")#text(" to ensure non-negativity, but we will not assume here that the sieve is of Selberg type.")

#text("The primality density ")#mi("\\sum_n \\nu(n) 1_{n \\text{ prime}} / \\sum_n \\nu(n)")#text(" of such a sieve cannot be much larger than ")#mi("O(c)")#text(". This is because all ")#mi("x^c")#text("-rough numbers (numbers with no prime factor less than ")#mi("x^c")#text(") are assigned the same value by the sieve ")#mi("\\nu")#text(", and by the asymptotics for the Dickman-de Bruijn function, the primes in ")#mi("[x,2x]")#text(" form a proportion of about ")#mi("c")#text(" of all the ")#mi("x^c")#text("-rough numbers in ")#mi("[x,2x]")#text(".")

#text("Now we look at a multidimensional sieve ")#mi("\\nu(n) = \\sum_{d_1|n+h_1;\\ldots;d_k|n+h_k} \\alpha_{d_1,\\ldots,d_k}")#text(", where again we do not assume the sieve to be of Selberg type, but we impose a restriction of the shape ")#mi("d_1 \\ldots d_k \\leq x^{O(1)}")#text(" since we are unlikely to control the sieve error terms without such a hypothesis, even assuming the strongest Elliott-Halberstam type conjectures. Heuristically, this limits each of the ")#mi("d_j")#text(" to be typically of size ")#mi("x^{O(1/k)}")#text(", and then the one-dimensional argument suggests that the primality density ")#mi("\\sum_n \\nu(n) 1_{n+h_i\\text{ prime}}/\\sum_n \\nu_n")#text(" should not be much larger than ")#mi("O(1/k)")#text(" for each ")#mi("i")#text(".")

#text("Now the Maynard sieve does do a bit better than this, because each factor ")#mi("d_i")#text(" is allowed to be a bit higher than ")#mi("x^{O(1/k)}")#text(" on occasion (there is a weight roughly of the shape ")#mi("\\frac{1}{1 + k \\frac{\\log d_j}{\\log x}}")#text(" in the sieve), since one can rely on concentration of measure (or the law of large numbers, if you wish) to keep the product ")#mi("d_1 \\ldots d_k")#text(" of a reasonable size ")#mi("x^{O(1)}")#text(". This occasional use of higher moduli seems to just barely be sufficient to diminish the sieve ")#mi("\\nu(n)")#text(" on some of the other ")#mi("x^{O(1/k)}")#text("-rough numbers than the primes to boost the prime density from ")#mi("O(1/k)")#text(" to ")#mi("O(\\log k/k)")#text(". But it seems unlikely that a clever choice of sieve weights could do much better than this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253204")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2013")])]

#text("Do you have a heuristic which explains the gain in the log, without looking too much at the sieve functions themselves?")

#text("I ask because I’d been working under the same heuristic that you mention above, and it surprised me that the modified weights were able to win by a full factor of a log. I don’t have any good heuristic explanation as to how one might be able to `see’ that these weights do this well a priori. Obviously, although logs are critical in the small-gaps argument, they are very small in comparison to ")#mi("k")#text(", and so we shouldn’t necessarily be surprised a heuristic breaks down at this level of accuracy.")

#text("That said, I liked this heuristic because it seemed to work well with similar problems. It seems to explain quite naturally the results of GGPY/Thorne on small gaps between numbers with ")#mi("r")#text(" prime factors, results on sifting limits and results on the number of prime factors of ")#mi("\\prod (n+h_i)")#text(". (Some of these are more `robust’ to a log factor than others). The `superiority’ of the Selberg sieve over other sieves for larger ")#mi("k")#text(" seemed to me just that the implied constants in the ")#mi("O")#text("-terms were better.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253246")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2013")])]

#text("Unfortunately I don’t have much of an explanation for this – at a formal level it shares a lot of similarities with the logarithmic divergences that show up in the endpoint Sobolev inequalities in harmonic analysis, in that one gets contributions from logarithmically many dyadic scales (which, in this case, would be something like the contribution of moduli between ")#mi("x^{2^j/k}")#text(" and ")#mi("x^{2^{j+1}/k}")#text(" for ")#mi("j=1,\\ldots,\\log k")#text(") but the way in which these scales interact seems rather specific to the Selberg sieve, and it is possible that some other sieve might give a different power of log (or more likely, no logarithmic gain at all).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253076")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("Asking the converse question: is there any N for which there are already known to be infinitely many x such that both x and x+2 are products of exactly N primes? If not, is it plausible that Maynard’s methods can be used to identify such an N? (Or if so, to reduce the known N?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253079")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("No, this is blocked by the parity problem. Given any sieve candidate ")#mi("\\nu(n)")#text(", we expect ")#mi("\\sum_n \\mu(n) \\nu(n)")#text(" and ")#mi("\\sum_n \\mu(n+2) \\nu(n)")#text(" to be negligible (this is part of the “Mobius pseudorandomness heuristic”), which basically means that if ")#mi("n")#text(" is drawn at random from the ")#mi("\\nu(n) / \\sum_m \\nu(m)")#text(" distribution, then ")#mi("n")#text(" has a probability ")#mi("1/2+o(1)")#text(" of having an even number of factors, and ")#mi("1/2+o(1)")#text(" of having an odd number of factors. Similarly for ")#mi("n+2")#text(". The upshot of this is that one cannot use purely sieve-theoretic methods to prescribe the parity of the number of prime factors of both ")#mi("n")#text(" and ")#mi("n+2")#text(". But it turns out (as worked out ")#link("http://www.ams.org/mathscinet-getitem?mr=396435")[#text("by Bombieri")]#text(") that on EH, one can basically do anything that does not run into this parity obstruction; for instance one can find infinitely many prime n such that n+2 is the product of either 2013 or 2014 primes. (This should be discussed in Friedlander-Iwaniec’s “Opera del Cribro”, though I don’t have this reference handy at present.)")

#text("Breaking the parity barrier for twins would be an absolutely huge breakthrough, even if conditional on Elliott-Halberstam. But it’s going to take a radically new idea; it’s not just a matter of tweaking the sieves.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253131")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("I was wondering if you could elaborate on the intuition for why it will take a radically new idea (similarly, I think I remember you saying that proving or disproving $P versus NP$ will require a new idea. how do you know?) Is it just that a lot of people have tried to solve these problems using many different techniques and failed or is it something else? Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253183")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2013")])]

#text("I discuss the parity problem further in my old blog post ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253266")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2013")])]

#text("Thanks.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253082")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("Three days ago I started running some computations. Here are the results. Throughout, I will be assuming EH.")

#text("————————–")

#text("Take ")#mi("k=5")#text(". Let ")#mi("F(t_1,t_2,t_3,t_4,t_5)")#text(" be an arbitrary polynomial function of total degree ")#mi("d")#text(", which is symmetric in ")#mi("t_1,t_5")#text(" and in ")#mi("t_2,t_3,t_4")#text(" separately. Working over the original simplex ")#mi("\\mathcal{R}_{4}")#text(" of Maynard, set")

#mi("P:= \\displaystyle  \\frac{1}{2} \\sum_{m=0}^5 J_5^{(m)}(F) / I_5(F) -  \\frac{1}{2} \\int \\frac{(\\int_{t_1+t_5 \\leq 1-t_2-t_3-t_4} F(t_1,t_2,t_3,t_4,t_5)\\ dt_1 dt_5)^2}{1-t_2-t_3-t_4}\\ dt_2 t_3 t_4 / I_5(F)")#text(".")

#text("Using a numerical optimizer (so results are not necessarily optimal, but should be close), we get:")

#text("For ")#mi("d=3")#text(", ")#mi("P\\approx -0.0860")#text(".")#linebreak()#text(" For ")#mi("d=4")#text(", ")#mi("P\\approx -0.0799")#text(".")

#text("It is not difficult to increase ")#mi("d")#text(" a little more. Probably up to ")#mi("d=10")#text(" is feasible.")

#text("————————–")

#text("Take ")#mi("k=4")#text(". Let ")#mi("F(t_1,t_2,t_3,t_4)")#text(" be an arbitrary polynomial function of total degree ")#mi("d")#text(", which is symmetric in the variables. Working over the original simplex ")#mi("\\mathcal{R}_{4}")#text(" of Maynard, and again using a numerical optimizer, we get:")

#text("For ")#mi("d=4")#text(", ")#mi("(1/2)M_4(F)\\gtrapprox 0.9222")#text(".")#linebreak()#text(" For ")#mi("d=5")#text(", ")#mi("(1/2)M_4(F)\\gtrapprox 0.9225")#text(".")#linebreak()#text(" For ")#mi("d=6")#text(", ")#mi("(1/2)M_4(F)\\gtrapprox 0.9226")#text(".")

#text("This is already very close to the upper bound of ")#mi("0.924")#text(" recently discovered by Terry.")

#text("————————-")

#text("I then tried to do the ")#mi("k=4")#text(" case for the new simplex ")#mi("\\mathcal{R}_{4}^{\\prime}")#text(", but the numerics give weird answers. For instance, when ")#mi("d=4")#text(", we get ")#mi("\\approx 0.522")#text(". The reason I didn’t post these computations earlier is that I’ve been trying to figure our where my error is. After two days I still have not been able to track down my error. I wrote up a LaTeX document explaining the computation, and I’m willing to email it (and the mathematica file) to anyone who is interested.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253087")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("I reran the computations I alluded to at the beginning of the previous post.")

#text("My calculations agree with yours for the original simplex ")#mi("\\mathcal{R}_k")#text(" (I get the slightly better bound ")#mi("(1/2) M_4>0.9226")#text(" when ")#mi("d=5")#text(".)")

#text("This is for ")#mi("k=4")#text(", using the enlarged simplex ")#mi("\\mathcal{R}_4^{\\prime}")#text(". As you have done, I’m taking ")#mi("F")#text(" to be an arbitrary symmetric polynomial of degree ")#mi("d")#text(" on ")#mi("\\mathcal{R}_k^{\\prime}")#text(", and then I’m using the linear-programming method from my paper to calculate the eigenvector which corresponds to the optimal choice of coefficients of ")#mi("F")#text(".")

#text("I then get the bounds")#linebreak()#text(" ")#mi("d=4:")#text(" ")#mi("(1/2) M_4>0.9612")#linebreak()#text(" ")#mi("d=5:")#text(" ")#mi("(1/2) M_4>0.9623")#linebreak()#text(" ")#mi("d=6:")#text(" ")#mi("(1/2) M_4>0.9629")#linebreak()#text(" This was my reason for saying using the enlarged simplex gets `about half way’ to obtaining gaps of size 8: we’ve improved from a lower bound of about 0.92 to about 0.96, and we want to get it to 1.")

#text("It appears that the convergence as ")#mi("d")#text(" increases is for the enlarged simplex is noticeably slower than for the original simplex.")

#text("I can give more details of how I did the calculations if interested.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253097")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("When I figure out where my computational error is, now I’ll know what numerics to look for. Thank you!")

#text("P.S. The reason I didn’t send those typos I mentioned above to you, is that I’m reading through your paper with Roger Baker (here at BYU) and he is compiling a list of the typos we run across. He will be sending that to you, probably in a couple of weeks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253116")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("Oops, there was a small typo in my program. The corrected bounds I get are")#linebreak()#text(" ")#mi("d=4:")#text(" ")#mi("(1/2)M_4>0.9686")#linebreak()#text(" ")#mi("d=5:")#text(" ")#mi("(1/2)M_4>0.9688")#linebreak()#text(" ")#mi("d=6:")#text(" ")#mi("(1/2)M_4>0.9689")#linebreak()#text(" and the convergence with ")#mi("d")#text(" seems good.")

#text("Summary of my calculation:")#linebreak()#text(" ")#mi("\\displaystyle J=\\int \\dots \\int (\\int F(t_1,t_2,t_3,t_4)dt_1)^2dt_2 dt_3 dt_4")#text(",")#linebreak()#text(" we can notice that if ")#mi("F")#text(" is symmetric, then ")#mi("J")#text(" is symmetric in ")#mi("t_2,t_3,t_4")#text(". This means the region with ")#mi("t_2>t_3>t_4")#text(" will contribute ")#mi("1/6")#text(" of the total. In this region, it is straightforward to put exact limits on each integration variable. We get")#linebreak()#text(" ")#mi("\\displaystyle J=\\int_0^{1/3}\\int_{t_4}^{(1-t_4)/2}\\int_{t_3}^{1-t_3-t_4} (\\int_0^{1-t_2-t_3} F(t_1,t_2,t_3,t_4)dt_1)^2 dt_2 dt_3 dt_4.")#linebreak()#text(" We also get a similar expression for ")#mi("I")#text(". Again, these are quadratic forms in the coefficients of ")#mi("F")#text(", and so we can find the optimal choice of ")#mi("F")#text(" of given degree by calculating the largest eigenvalue of a matrix.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39d042cd343763a0074f825ecdf61ade3a1f833c09d7322d7ed33b69d91748e0-004ee65ff1042e640b0bfa8bf9563704de056663a81b46994f471f2da9bfde76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bogdan")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253145")[#strong[#text("Bogdan")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2013")])]

#text("I am a bit confused: the upper bound of 0.924 is reported in post for 25 November, 2013 at 5:14 am, and the conclusion was that “so under EH the current method is limited to k_0=5”, and now you get the lower bound of 0.9689! Is this because of “using the enlarged simplex”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253193")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2013")])]

#text("Bogdan: Yes, the upper bound of 0.924 was for functions whose support was restricted to the smaller simplex ")#mi("\\mathcal{R}_k")#text(". By comparison, we are getting a lower bound of 0.922 in this case, so these seem to be in good agreement.")

#text("If we use a modification of the original method (such as extending the support to the slightly large simplex ")#mi("\\mathcal{R}^{\\prime}_k")#text(" or incorporating the ")#mi("1_{n,n+12 prime}")#text(" terms) then this upper bound no longer applies. In particular, the lower bound of 0.96 using the larger simplex isn’t in contradiction to the earlier bound.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253228")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2013")])]

#text("The fast convergence (using polynomials) indicates the (possible) existence of a smooth maximizer.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253095")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("Comments (from a non-mathematician who is interested in mathematics):")

#text("In ")#link("http://arxiv.org/abs/1311.4600")[#text("Maynard’s paper")]#text(", it is stated that ")#mi("H_m \\ll m^3e^{4m}")#text(", but in the post, it is stated that ")#mi("H_m \\ll m^3e^{2m}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253100")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("The bound ")#mi("H_m \\ll m^3 e^{4m}")#text(" is unconditional, but the improved bound ")#mi("H_m \\ll m^3 e^{2m}")#text(" is available if one assumes the Elliott-Halberstam conjecture; this isn’t explicitly stated in Maynard’s paper but it follows easily from the methods of the paper (so if James is revising the paper anyway, one may as well add in that remark).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253096")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("@Maynard:")

#text("* The subscript “")#mi("max")#text("” should be “")#mi("\\max")#text("”.")#linebreak()#text(" * When typing maps, one should use “\\colon” instead of “:” in order to get the correct spacing aroung the colon.")

#text("(Typographical comments, valid throughout the paper.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253179")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2013")])]

#text("I’m wondering whether it is possible (or desirable) to reformulate the progress being made here on M_k in a manner that more closely resembles prior work, in particular Polymath8a. Taking things down to their barest essentials, I gather that we can informally say that Maynard and polymath8b have improved the k for which DHL[k,m+1] is implied by EH[theta] (but see below) from an exponentially decreasing function of (theta – m/2) (i.e. GPY) to something on the order of e^(2m/theta). I appreciate that there are good mathematical reasons for working centrally with the quantity M_k, but it’s not clear to me whether the evolving bounds on M as a function of k can be “inverted” to give bounds on k as a direct function of m and theta. If that were possible, I think that for expository purposes it would be of great interest.")

#text("Also, I have a somewhat similar question relating to polymath8a. Is it possible to state an explicit version of EH[theta] (let’s call it EH’[theta]) that is implied (up to a value of theta that is a function of i. varpi and delta) by MPZ(i)[varpi,delta], and that also suffices to imply DHL[k,m+1] for sufficiently large k? If that were possible, it seems like it would constitute a nicely clean way, again for expository purposes, to separate the progress in reducing delta from the progress in reducing k for a given theta (and m). Can someone please clarify this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253181")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2013")])]

#text("The various upper and lower bounds on Maynard’s sieve all correspond to asymptotics of the form ")#mi("DHL[ k, (\\frac{\\theta}{2} + o(1)) \\log k ]")#text(" for large ")#mi("k")#text(", which in particular implies ")#mi("H_m \\leq \\exp( (\\frac{2}{\\theta} + o(1)) m)")#text(" for large ")#mi("m")#text("; the only difference between them lies in the precise nature of the o(1) error term. Once the bounds stabilise, one can of course work these things out more accurately.")

#text("The Bombieri-Vinogradov theorem already implies ")#mi("DHL[k,m+1]")#text(" for sufficiently large k, and is a known theorem and is thus implied by any MPZ type statement. We do have some implications that do a little better than this by exploiting an MPZ hypothesis, by using a cutoff function F for Maynard’s sieve that is supported in an appropriate cube; again, the asymptotics for large m or large k are as above (in particular, the role of delta is asymptotically negligible), but the situation seems to be more complicated in the non-asymptotic regime, e.g. when m=1 or m=2.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253184")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2013")])]

#text("Thanks! On the first point, absolutely – I just couldn’t exclude the possibility that this inversion might be so easy that there would be no reason to defer it. On the second point, sure, I was of course referring to an EH’ that would do the job for theta > 1/2; however I was mainly referring simply to the pre-Maynard universe and wondering whether this kind of condensation of i, varpi and delta down to a single parameter theta is possible at all.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253196")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2013")])]

#text("In other words, when I wrote “for sufficiently large k” I should have written “for the same k that MPZ(i)[varpi,delta] itself does”.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253205")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2013")])]

#text("A minor (and standard) remark: the Selberg sieve ")#mi("\\nu(n) = (\\sum_{d_i | n+h_i} \\lambda_{d_1,\\ldots,d_k})^2")#text(" can be rewritten as")

#mi("\\displaystyle \\nu(n) = (\\sum_{d_1,\\ldots,d_k} \\frac{\\mu(d_1) \\ldots \\mu(d_k)}{\\phi(d_1)\\ldots \\phi(d_k)} y_{d_1,\\ldots,d_k} c_{d_1}(n+h_1) \\ldots c_{d_k}(n+h_k))^2")

#text("where ")#mi("y_{d_1,\\ldots,d_k}")#text(" are as in Maynard’s paper and ")#mi("c_d(n)")#text(" are the Ramanujan sums")

#mi("c_d(n) = \\sum_{a \\in ({\\bf Z}/d{\\bf Z})^\\times} e_d(an) = \\prod_{p|d} (p 1_{p|n} - 1)")

#text("(restricting to squarefree ")#mi("d")#text("); this is basically equation (5.8) of Maynard’s paper after some rearranging.")

#text("The functions ")#mi("n \\mapsto c_d(n+h_i)")#text(" behave approximately like independent random variables as ")#mi("d, i")#text(" vary, which heuristically explains why the mean value of ")#mi("\\nu")#text(" is basically ")#mi("\\sum_{d_1,\\ldots,d_k} \\frac{y_{d_1,\\ldots,d_k}^2}{\\phi(d_1) \\ldots \\phi(d_k)}")#linebreak()#text(" and can also give heuristic justification for the asymptotic for ")#mi("\\sum_n \\nu(n) 1_{n+h_i \\text{ prime}}")#text(" in terms of the ")#mi("y_{d_1,\\ldots,d_k}")#text(" (Lemma 5.2 of Maynard’s paper). I wasn’t able to use this representation of the Selberg sieve for much else, though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253215")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2013")])]

#text("Typographical comment to Terry: If you use $\\dots$ instead of $\\ldots$, LaTeX will take case of correct placement of the dots; they shouldn’t always be lowered to the base of the line.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253221")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2013")])]

#text("In the definition of ")#mi("M_k")#text(", the functions ")#mi("F")#text(" need only to be in")#linebreak()#text(" ")#mi("L^2")#text(" (i.e. not necessarily bounded.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253225")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2013")])]

#text("In the spirit of “A poor man’s improvement on Zhang’s result”, I was playing around with Maynards mathematica notebook. I found that increasing “p[5]” to “p[6]” (and increasing the number of variables to 56, and precomputing polynomials up to degree 13) allows one to push ")#mi("k=102")#text(". This was confirmed by Maynard. [It appears that no further gain is made in such an easy manner by just increasing the degree further.]")

#text("Obviously, further improvements are available if we incorporate some of the higher order power-symmetric polynomials like P_3.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9de13c3c77059e2381357dce91d8408811e186d9d73d672aa8a814d24502a97-6908235e9bb52c626e6c19f1d38e16ef432f563317e7085fab69ed891489f3c0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sniffnoy")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253251")[#strong[#text("Sniffnoy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2013")])]

#text("102 or 103? It says 102 here but 103 on the wiki and I’m wondering whether that is a typo here or a copying error there (the H value listed there is for 103).")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253342")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2013")])]

#text("Here is a possible way to generalise the Selberg sieve. We’ll use the “multiimensional GPY” formulation")

#mi("\\displaystyle \\nu(n) = (\\sum_{d_1|n+h_1,\\ldots,d_k|n+h_k} \\mu(d_1)\\ldots \\mu(d_k) F(\\frac{\\log d_1}{\\log R},\\ldots,\\frac{\\log d_k}{\\log R}))^2")

#text("for the sieve, where F is a smooth function supported on the simplex (or the enlarged simplex). We can square this out as")

#mi("\\displaystyle \\nu(n) = \\sum_{d_1,d^{\\prime}_1|n+h_1,\\ldots,d_k,d^{\\prime}_k|n+h_k} \\mu(d_1)\\mu(d^{\\prime}_1)\\ldots \\mu(d_k)\\mu(d^{\\prime}_k)")#linebreak()#text(" ")#mi("\\displaystyle F(\\frac{\\log d_1}{\\log R},\\ldots,\\frac{\\log d_k}{\\log R}) F(\\frac{\\log d^{\\prime}_1}{\\log R},\\ldots,\\frac{\\log d^{\\prime}_k}{\\log R}).")

#text("One can then consider the more general sieve")

#mi("\\displaystyle \\nu(n) = \\sum_{d_1,d^{\\prime}_1|n+h_1,\\ldots,d_k,d^{\\prime}_k|n+h_k} \\mu(d_1)\\mu(d^{\\prime}_1)\\ldots \\mu(d_k)\\mu(d^{\\prime}_k)")#linebreak()#text(" ")#mi("\\displaystyle \\tilde F(\\frac{\\log d_1}{\\log R},\\ldots,\\frac{\\log d_k}{\\log R}, \\frac{\\log d^{\\prime}_1}{\\log R},\\ldots,\\frac{\\log d^{\\prime}_k}{\\log R})")

#text("for some smooth function ")#mi("\\tilde F")#text(" supported on the product of two simplices. This function obeys similar asymptotics to the original sieve (this can be seen for instance by using Stone-Weierstrass to approximate ")#mi("\\tilde F")#text(" by a finite linear combination of tensor products, or else by direct computation); for instance one has")

#mi("\\displaystyle \\sum_n \\nu(n) 1_{n+h_1 \\text{ prime}}/\\sum_n \\nu(n)")

#mi("\\displaystyle = \\int \\tilde F_{2,\\ldots,k,2^{\\prime},\\ldots,k^{\\prime}}( 0, t_2,\\ldots,t_k,0,t_2,\\ldots,t_k)\\ dt_2 \\ldots dt_k")#linebreak()#text(" ")#mi("/ \\int \\tilde F_{1,\\ldots,k,1^{\\prime},\\ldots,k^{\\prime}}(t_1,\\ldots,t_k,t_1,\\ldots,t_k)\\ dt_1 \\ldots t_k + o(1)")

#text("if the denominator is non-zero, where the subscripts on F denote differentiation in one or more of the variables ")#mi("t_1,\\ldots,t_k,t^{\\prime}_1,\\ldots,t^{\\prime}_k")#text(". The main problem is that without further hypotheses on ")#mi("\\tilde F")#text(", the sieve weight ")#mi("\\nu")#text(" is not necessarily non-negative, which is a crucial property in the argument. In the case that ")#mi("F")#text(" is positive semidefinite (viewed as a “matrix” or “quadratic form” on the simplex), one obtains the non-negativity; but in this case one can diagonalise F into a non-negative combination of Selberg sieves, which cannot give better ratios than a pure Selberg sieve. However, it may be possible to have ")#mi("\\nu")#text(" non-negative even without ")#mi("\\tilde F")#text(" being positive semidefinite, leading to a genuinely more general class of sieve. The positivity requirement is a bit complicated though, even in the base case k=1; a typical condition is")

#mi("\\tilde F(0,0) - \\tilde F(t_1,0) - \\tilde F(t_2,0) + \\tilde F(t_1+t_2,0)")#linebreak()#text(" ")#mi("-\\tilde F(0,t_1) + \\tilde F(t_1,t_1) + \\tilde F(t_2,t_1) - \\tilde F(t_1+t_2,t_1)")#linebreak()#text(" ")#mi("-\\tilde F(0,t_2) + \\tilde F(t_1,t_2) + \\tilde F(t_2,t_2) - \\tilde F(t_1+t_2,t_2)")#linebreak()#text(" ")#mi("+\\tilde F(0,t_1+t_2) - \\tilde F(t_1,t_1+t_2) - \\tilde F(t_2,t_1+t_2) + \\tilde F(t_1+t_2,t_1+t_2) \\geq 0")

#text("whenever ")#mi("t_1+t_2 =\\frac{\\log x}{\\log R}")#text(". This condition demonstrates the non-negativity of ")#mi("\\nu")#text(" for products of two primes; one needs similar conditions for products of ")#mi("r")#text(" primes for any bounded r, and this should suffice (note that these sieves are concentrated on numbers with only a bounded number of prime factors).")#linebreak()#text(" These conditions are implied by positive semi-definiteness of ")#mi("\\tilde F")#text(", but hopefully they are a bit weaker, allowing for more test functions ")#mi("\\tilde F")#text(" to play with.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253414")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2013")])]

#text("A cute inequality related to the above considerations: for any smooth function ")#mi("F: [0,1] \\to {\\bf R}")#text(", one has")

#mi("\\sum_{r=1}^\\infty \\frac{1}{r!} \\int_{{\\cal R}_{r-1}} \\Delta_{t_1} \\ldots \\Delta_{t_r} F(0)|^2\\ \\frac{dt_1 \\ldots dt_{r-1}}{t_1 \\ldots t_r}")

#tao-math("\\leq \\int_0^1 \\left|F^{\\prime}(t)\\right|^2\\ dt", block: false)

#text("where ")#mi("t_r := 1-t_1-\\ldots-t_{r-1}")#text(" and ")#mi("\\Delta_h")#text(" is the difference operator ")#mi("\\Delta_h F(t):= F(t+h)-F(t)")#text(". Thus for instance")

#tao-math("\\frac{1}{2} \\int_0^1 \\frac{\\left|F(0)-F(t)-F(1-t)+F(1)\\right|^2}{t}\\ dt \\leq \\int_0^1 \\left|F^{\\prime}(t)\\right|^2\\ dt.", block: false)

#text("The sieve theoretic interpretation is that the right-hand side is an appropriately normalised version of ")#mi("\\sum_n \\nu(n)")#text(" if ")#mi("\\nu(n) = (\\sum_{d|n} \\mu(d) F(\\frac{\\log d}{\\log R})^2")#text(", and the left-hand side is the contribution to ")#mi("\\sum_n \\nu(n)")#text(" coming from products of exactly ")#mi("r")#text(" primes for ")#mi("r=1,2,\\ldots")#text(". For sufficiently smooth functions F (e.g. finite linear combinations of exponentials), the inequality is in fact an identity, as can be seen by a rather fun computation. The claim can also be proven from the recursive distributional identity")

#mi("S(F)(T) = F(0)^2 \\delta_0(T) + \\frac{1}{T} \\int_0^T S( \\Delta_\\tau F)(T-\\tau)\\ d\\tau")

#text("for ")#mi("T \\in [0,+\\infty)")#text(", where ")#mi("S")#text(" is the nonlinear operator")

#mi("S(F)(T) :=F(0)^2 \\delta_0(T) + \\int_0^T F^{\\prime}(t)^2\\ dt.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253441")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2013")])]

#text("A couple of calculations regarding attempts to modify the ")#mi("k_0=5")#text(" case to obtain gaps of size 8:")

#text("Using the enlarged simplex, I get that ")#mi("(1/2)M_5>1.029...")#text(" (and I would expect this to be close to the truth). This means that the `probability’ that one of the elements of a 5-tuple is prime is ")#mi("\\approx 1.029/5\\approx 0.205")#text(". If we assume independence, then we would expect the probability that both ")#mi("n")#text(" and ")#mi("n+12")#text(" are prime to be ")#mi("\\approx 0.205^2\\approx 0.0424")#text(" (since we don’t expect to be able to get an asymptotic for this quantity, in reality we have to satisfy ourselves with an upper bound, which would be worse than this). This means that the modification of taking away the contribution form the times when ")#mi("n")#text(" and ")#mi("n+12")#text(" are simultaneously prime would (in the most optimistic scenario) leave us with a total of ")#mi("1.029..-0.0424\\approx 0.987<1")#text(". This means we need at least one new idea to improve the situation. We'd need a lower bound on ")#mi("(1/2)M_5")#text(" which is certainly greater than ")#mi("5(5-\\sqrt{21})/2\\approx 1.04...")#text(" for this modification to get us over the edge.")

#text("I also tested the upper bound to see how it fared numerically. My calculations should be treated as very provisional, since I haven't checked them properly. In the scenario above, I find that taking a suitable polynomial for ")#mi("F")#text(", we get a lower bound for the modified version of ")#mi("M^{\\prime}_5")#text(" which gives ")#mi("(1/2)M_5^{\\prime}\\ge 0.966")#text(". This compares well with the most optimistic bound of ")#mi("0.987")#text(" from above. This also corresponds to an upper bound for ")#mi("1_{n,n+12 prime}")#text(" of size ")#mi("\\approx 0.062")#text(", which again is close to the guessed asymptotic value of ")#mi("\\approx 0.042")#text(".")

#text("Since these bounds performed quite well, it is maybe reasonable to expect us to get decent upper bounds when we are considering ")#mi("k=102")#text(" or similar. I don't know how we would evaluate the integrals that arise, however.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253451")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2013")])]

#text("Thanks for these calculations! Due to the parity problem, I expect that any upper bound we obtain on ")#mi("1_{n,n+12\\text{ prime}}")#text(" is going to be off by a factor of at least 2 from the truth (so in this case, it would be like ")#mi("0.085")#text(" rather than ")#mi("0.042")#text("). This isn’t consistent with the ")#mi("0.062")#text(" number that you are provisionally reporting, but perhaps the numerology for the ")#mi("M^{\\prime}_5")#text(" optimiser is a bit different from that for the ")#mi("M_5")#text(" optimiser. For instance, it may be advantageous to break symmetry a bit and work with polynomials F that behave differently in the ")#mi("t_1,t_5")#text(" variables than in the ")#mi("t_2,t_3,t_4")#text(", lowering the probability that n is prime and n+12 is prime (in order to also lower the probability that n,n+12 are both prime) while also raising the probability that n+2,n+6,n+8 are prime.")

#text("0.987 is tantalisingly close to 1, so there is still hope :) Certainly things should look better for larger k. One relatively cheap thing to try is just to take the best polynomial we have for ")#mi("M_{102}")#text(" and compute the upper bounds on ")#mi("1_{n+h_i,n+h_j \\text{ prime}}")#text(" (note though that if we retreat from EH to Bombieri-Vinogradov, some of the 1/2 factors in the previous formula for this quantity degrade to 1/4).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253452")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2013")])]

#text("A small observation: somewhat frustratingly, the Zhang/Maynard methods do not quite seem to be able to establish Goldbach’s conjecture up to bounded error (i.e. all sufficiently large numbers are within O(1) of the sum of two primes). But one can “split the difference” between bounds on H and establishing Goldbach conjecture with bounded error. For instance, assuming Elliott-Halberstam, one can show that at least one of the following statements hold:")

#text("1. ")#mi("H_1 \\leq 6")#text(" (thus improving over the current bound of ")#mi("H_1 \\leq 12")#text("); or")

#text("2. Every sufficiently large even number lies within 6 of a sum of two primes.")

#text("To prove this, let N be a large multiple of 6, and consider the tuple n, n+2, n+6, N-n, N-n-2. One can check that this tuple is admissible in the sense that for every prime p, there is an n such that all five elements of the tuple are coprime to p. A slight modification of the proof of DHL[5,2] then shows that there lots of n for which at least two of the five elements of this tuple are prime; either these two elements are within 6 of each other, or sum to a number between N-2 and N+6.")

#text("If we can ever get DHL[4,2] (or more precisely, a variant of this assertion for the tuple n, n+2, N-n, N-n-2), we get a more appealing dichotomy of this type: either the twin prime conjecture is true, or every sufficiently multiple of six lies within 2 of a sum of two primes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253700")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2013")])]

#text("Wow! This immediately raises two questions that would surely be of wide interest:")

#text("1) For k=5, can one split the difference unevenly, i.e. lower the value 6 in one statement at the expense of using a number larger than 6 in the other? If so, how unevenly – all the way to TP or Goldbach?")

#text("2) Can analogous statements be made for larger k? In particular, for k large enough to require only BV (or MPZ) rather than EH?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253731")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2013")])]

#text("In fact, much better would be to unify the above questions in the obvious way, as follows:")

#text("If we denote by “GBE[n]” (Goldbach up to bounded error n – is there an established name for this conjecture?) the assertion that all even numbers are within n of an even sum of two primes (I’m omitting “sufficiently large” here only because I presume that “sufficiently” can easily be shown in this context to be within the range for which GC itself has already been computationally verified – apologies if that’s not true), then for which [a,b,c] can we say that DHL[a,2] implies DHL[b,2] or GBE[c] ? Terry’s observations constitute this statement for [a,b,c] = [5,3,6] and [4,2,4]. How far can the allowed values be broadened?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253488")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2013")])]

#text("I feel that Goldbach’s conjecture / twin primes conjecture are very close to be proved.")#linebreak()#text(" All originated from Zhang’s work!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253503")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2013")])]

#text("I am curious about is the following. Consider a random subset of primes (taking every prime with probability p, independently, and say p=1/2). Now consider only integers involving these primes. I think that it is known that this system of “integers” satisfies (almost surely) ")#strong[#text("PNT")]#text(" but not at all ")#strong[#text("RH")]#text(". We can consider for such systems the properties ")#strong[#text("BV")]#text(" (Bombieri Vinogradov), or more generally ")#strong[#text("EH(θ) ")]#text("and the quantities ")#mi("H_m")#text(". For such systems does BV typically hold? or it is rare like RH. Is Meynard’s implication applies in this generality? Nicely, here we can hope even for infinite consecutive primes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253685")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2013")])]

#text("Strictly speaking, if only takes half of the primes, then the remaining integers is a very sparse set – about ")#mi("x^{1/2}")#text(" elements up to ")#mi("x")#text(" – which makes all the numerology very different from that of the full primes.")

#text("You may be thinking instead of the Beurling integers, in which the primes are replaced by some other set of positive reals with the same asymptotic density properties. These integers enjoy many of the same “multiplicative number theory” properties as the usual integers (e.g. the prime number theorem), but one usually loses all of the “additive number theory” properties, basically because the Beurling integers are not translation-invariant: if n is a Beurling integer, then n+2 usually isn’t, and so asking for things like twin Beurling primes is not really a natural question; similarly for questions about distributions of Beurling primes in residue classes (Bombieri-Vinogradov, EH, etc.) (unless one also somehow creates a theory of “Beurling Dirichlet characters” to go with the Beurling primes, but I do not know how to make this work for anything that isn’t already coming from a number field).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253722")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2013")])]

#text("Terry, how can it be ")#mi("x^{1/2}")#text(" if you leave half the primes alive?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253726")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2013")])]

#text("Oops, I miscalculated; the density is now ")#mi("1/\\log^{1/2} x")#text(" rather than ")#mi("1/x^{1/2}")#text(", so I drop my previous objection to the question :). (My error was thinking that the average number of divisors of n would remain comparable to ")#mi("\\log x")#text(", when instead it drops to ")#mi("\\log^{1/2} x")#text(".) The main technical difficulty now is with counting such quantities as the number of integers n less than x such that n and n+2 are both divisible by the surviving primes; offhand I don’t see a promising technique to answer this question (as well as more general questions in which several shifts of n are involved, and some congruence class conditions on n are also imposed) but it looks like an interesting problem.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253733")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2013")])]

#text("Indeed, I was thinking about Beurling integers, and my questions can be asked about them but I wanted a very very specific model which will make computations easier. I think that it is not that easy to work with general Beurling primes and finding a concrete stochastic models (like random graphs, sort of) may be more fruitful.")

#text("If we want to keep the density of primes on the nose we can possibly still take p_n with independent but not identical probabilities not to corrupt asymptotic density properties, or do some other “correction”, but perhaps taking half the primes is also of interest.")

#text("All the questions I asked refer only to the relative ordering of the Beurling integers and *not* to their additive properties. So “twin primes” refers to two Beurling primes with a single composite Beurling integer in between. And “consequtive primes” refers to two Beurling primes without any composite Beurling integer in between (Alas, we don’t have them often in the usual case.) I think that PNT, RH, BV (Bombieri Vinogradov), or more generally EH(θ), and ")#mi("H_m")#text(" (in the *ordinal*, not *additive* sense) continue to make sense (perhaps even more than one sense) for Beurling primes and it is interesting to see if Meynard implication extends, but it looks to me that considering a stochastic model based on the primes will make the issue more tractable (and perhaps useful).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253764")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2013")])]

#text("If I understand your question correctly, then I would have thought for such a system you would get (almost surely) ")#mi("EH(\\theta)")#text(" for this subset of the primes, whenever ")#mi("EH(\\theta)")#text(" holds for the primes themselves. (And so bounded gaps with ")#mi("m")#text(" primes).")

#text("If ")#mi("X_{a,q}")#text(" is the number of chosen primes in the residue class ")#mi("a \\pmod{q}")#text(" which are at most ")#mi("x")#text(", then ")#mi("X_{a,q}")#text(" is distributed as a binomial random variable ")#mi("B(\\pi(x;q,a),1/2)")#text(". Therefore, we should get, for some constant ")#mi("C>")

#tao-math("\\displaystyle\\mathbb{P}(\\left|X_{a,q}-\\pi(x;q,a)/2\\right|\\ge t\\sqrt{\\pi(x,q,a)})\\ll \\exp(-C t^2)", block: false)#text(".")

#text("In particular, over all ")#mi("a,q")#text(" for which ")#mi("\\pi(x;q,a)\\gg x/\\phi(q)")#text(" we have almost surely ")#mi("X_{a,q}=\\pi(x;q,a)/2+O(\\log^2{x} (x/q)^{1/2})")#text(". (There are ")#mi("O(x^2)")#text(" such pairs ")#mi("a,q")#text(", and we take ")#mi("t=\\log{x}")#text(" above). The errors from these ")#mi("O")#text("-terms are negligible. The errors from those pairs ")#mi("a,q")#text(" for which `")#mi("\\pi(x;q,a)\\gg x/\\phi(q)")#text("‘ does not hold, and the errors ")#mi("\\pi(x;q,a)/2-\\pi(x)/(2\\phi(q))")#text(" can be bounded by regular ")#mi("EH(\\theta)")#text(" for all primes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253790")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2013")])]

#text("I agree that this form of ")#mi("EH[\\theta]")#text(" will hold almost surely, but I think for applications to bounded gaps between these Beurling-type integers one needs a significantly stronger version of ")#mi("EH[\\theta]")#text(" in which one not only counts those ")#mi("n = a\\ (q)")#text(" for which ")#mi("n")#text(" is a Beurling prime, but also ")#mi("n+h_j-h_i")#text(" is a Beurling integer for the other elements ")#mi("h_j")#text(" in the tuple.")

#text("Actually, never mind bounded gaps between Beurling primes: bounded gaps between Beurling ")#emph[#text("integers")]#text(" is already somewhat non-trivial problem, particularly if one wants the correct asymptotic for how often this occurs; this is probably the main obstacle to extending the various results for gaps between primes to this Beurling setting.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253813")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2013")])]

#text("Can you not use the sieve as before, comparing ")#mi("\\sum_{i=1}^k \\mathbf{1}_{Beurling prime}(n+h_i)")#text(" to just the constant function 1 (supported on all integers, Beurling-type or not)?")

#text("Since you have ")#mi("EH(\\theta)")#text(" for these primes, you should be able to calculate an asymptotic for the sieve weighted by these terms (which will be 1/2 of what we get for primes). Since ")#mi("M_k")#text(" tends to infinity, I would have thought we should then get ")#mi("m")#text(" primes in a ")#mi("k")#text("-tuple whenever we would have got ")#mi("2m")#text(" primes before.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253833")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2013")])]

#text("Well, if one uses the existing sieve ")#mi("\\nu")#text(" without any modification, the density ")#mi("\\sum_n \\nu(n) 1_{Beurling\\ prime}(n+h_i) / \\sum_n \\nu(n)")#text(" will only be of the order of ")#mi("1 /\\log^{1/2} x")#text(", which is too sparse to pick up more than one prime in the tuple. Things are presumably better if one replaces ")#mi("\\nu(n)")#text(" by ")#mi("\\nu(n) \\prod_{j=1}^k 1_{Beurling\\ integer}(n+h_i)")#text(", but then one needs asymptotics for things like ")#mi("\\sum_{n = a\\ (q)} \\prod_{j=1}^k 1_{Beurling\\ integer}(n+h_i)")#text(", which is presumably doable but requires some calculation. (It is vaguely reminiscent of the Titchmarsh-type divisor problem of finding integers n, n+h with specified divisor function.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253789")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2013")])]

#text("A new paper on the arXiv by William D. Banks, Tristan Freiberg, and Caroline L. Turnage-Butterbaugh: “")#link("http://arxiv.org/abs/1311.7003")[#text("Consecutive primes in tuples")]#text("“. Basically they show that Maynard’s result can be boosted to guarantee that the m primes involved are consecutive, although they have to increase k somewhat (to be double exponential in m rather than single exponential) to do this. (It may be, though, that one can avoid this by computing asymptotics for ")#mi("\\sum_n \\nu(n) 1_{n+h \\text{ prime}}")#text(" for h not in the tuple, much as in the original GPY paper, or by using the ideas of Pintz as is done for instance in ")#link("http://arxiv.org/abs/1305.6289")[#text("http://arxiv.org/abs/1305.6289")]#text(" .)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253806")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2013")])]

#text("Perhaps this new type of ")#mi("H_m")#text(" (for consecutive primes) may be studied here as well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kalpesh Muchhal")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-254672")[#strong[#text("Kalpesh Muchhal")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2013")])]

#text("Hi, Corollary 3 of the Banks-Freiberg-TB paper shows that consecutive primes can be part of an AP, while the Green-Tao theorem shows that primes can be consecutive terms of an AP. Can these results be somehow combined to prove consecutive primes can be consecutive terms of an AP infinitely often?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-254679")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2013")])]

#text("Unfortunately, the primes that we can capture in short intervals are so sparse (one roughly has only ")#mi("\\log H")#text(" or so primes in an interval of length H) that it is not presently possible to force them into arithmetic progression. (My arguments with Ben can produce arithmetic progressions of primes in ")#mi("[x,x+x^{o(1)}]")#text(" – this was explicitly noted in a later paper of myself with Ziegler – and in view of more recent work (particularly that of Conlon, Fox, and Zhao) it is likely that one can narrow this to ")#mi("[x,x+\\log^{O(1)} x]")#text(" – but this is still a bit too wide to expect that the primes produced in this fashion will be consecutive.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2865f968936d49bf25378451892fe21b5008575ff0f435b2c98ee89aa6957080-997ef30b72a70d6066724f69bbf1faf08c34e3048c0f9afe2532ae7ef1ea26bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Granville")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-254079")[#strong[#text("Andrew Granville")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2013")])]

#text("I do not see why one needs to increase k. If the m-prime result is obtained from the k-tuple, {x+0, x+a_2,…, x+a_k} then we can restrict ourselves to a congruence class (for x) so that x+j has a given smallish prime factor p_j for each j<a_k, which is not an a_i. The congruence x=-j mod p_j, combine to mean we can write x = Q n +b (where Q = prod_j a_j). Hence we work instead with the k-tuple Qn+b, Qn+b+a_2,…,Qn+b+a_k")#linebreak()#text(" I think that one can apply the main theorem directly to this k-tuple, so it has (single) exponential size in m")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2865f968936d49bf25378451892fe21b5008575ff0f435b2c98ee89aa6957080-997ef30b72a70d6066724f69bbf1faf08c34e3048c0f9afe2532ae7ef1ea26bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Granville")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-254091")[#strong[#text("Andrew Granville")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2013")])]

#text("Beurling primes do not satisfy RH in general… You should look for the beautiful 2006 paper of Diamond, Montgomery and Vorhauer. In fact they show that one can have a Siegel-type zero (which perhaps explains why these are so hard to deal with in the actual prime case).")

#text("There was also some mention, amongst these comments, of probabilistic models… of course the Gauss-Cramer model, where a random number n is “prime” with probability 1/log n, predicts that there are many prime pairs n, n+1, so needs some adjusting to take account of correlations arising from local divisibility. Sound and i showed some years ago that all of the obvious models proposed to make these sort of corrections have serious flaws (see our paper “An arithmetic uncertainty principle”).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-254139")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2013")])]

#text("More about systems of Beurling primes:")

#text("About my initial suggestion to take half the primes at random, since a quarter of all pairs of primes survive anyway it does not look that the implication (if it applies) from BV(Bombieri-Vinogradov) or EH(θ) to bounded gap is useful here.")

#text("Regarding Beurling primes in general. I see three issues")

#text("1) Does (or when) Meynard implication from EH(θ) (or just BV) to bounded gaps applies to general systems of Beurling primes with the right density.")

#text("2) Can you either show it more easily or apply it more easily for stochastic systems based on ordinary primes.")

#text("3) If (or when) the implication is correct, can you get something useful from it for the current project (or even just interesting consequences otherwise.)")

#text("I don’t know about 1) but let me just assume it.")

#text("Regarding 2) for most natural models small gap pair of primes will survive. (maybe for k-tuples for large k interesting things can be said. since their rate of survival decay exponentially.) Another stochastic model that is interesting is to take all primes *with* repetitions and to take every prime with (say) Poisson or exponential distribution of mean 1. (For applying it we may need bounds on gaps between 2 to m, so that we can ignore repeated primes.) (One of the most beautiful and useful ideas in modern statistics is to study sequences by sampling from them with repetitions.)")

#text("Regarding 3) there are various things to think about. You can delete for your Beurling system all pair of primes of gaps at most 1000 (say). Now, for what we know on the number of primes involved with a gap at most 1000 is too high for the statement of Bombieri-Vinogradov to remain correct automatically. (But it is interesting if it remains correct.) However, we may try using it as part of an argument showing that there are many primes of gaps 1000 or less: If the density of those is small then when we delete them EH is not harmed and we can apply the reduction again. This is not a complete argument since new pairs of primes with small gaps (with respect to the new system) may emerge.")

#text("Since the estimates for k-tuples density are especially week compared to reality this type of hypothetical argument may work for them better.")

#text("Another similar suggestion is to choose for our Beurling system a random prime from every second interval of integers of length 1000. This automatically eliminate (additive) gaps below 1000.")

#text("(If such considerations can “just” lead to new examples of Beurling primes which violate RH, BV, or EH this would also be nice, of course.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-254942")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2013")])]

#text("On more thought, I don’t see how to formulate the above questions for general Beurling primes without the additive structure.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-254848")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2013")])]

#text("I’m recording how to use multiple dense divisibility to (in principle at least) improve the value of k, although at present we can only effectively calculate the various integrals involved when the function F is basically built from a tensor product ")#mi("\\prod_i g(t_i)")#text(", which isn’t the case for our best value 102 for k at m=2, but only for the larger value 339 (for m=2) or 43,134 (for m=3).")

#text("To review the situation: under ")#mi("EH[\\theta]")#text(", we can obtain ")#mi("DHL[k,m+1]")#text(" (and hence ")#mi("H_m \\leq H(k)")#text(") whenever we can find a (bounded measurable) symmetric function ")#mi("F")#text(" supported on the simplex ")#mi("{\\cal R}_{k}")#text(" with")

#tao-math("\\int_{{\\cal R}_{k}} \\left|F\\right|^2\\ dt_1 \\ldots dt_k \\leq 1", block: false)#text(" (1)")

#text("and")

#tao-math("k \\int_{{\\cal R}_{k-1}} \\left|\\int  F\\ dt_k\\right|^2\\ dt_1 \\ldots t_{k_1} > \\frac{2m}{\\theta}", block: false)#text(". (2)")

#text("A good choice for F here is a function of the form")

#mi("F(t_1,\\ldots,t_k) = 1_{{\\cal R}_k}(t_1,\\ldots,t_k) \\prod_{i=1}^k \\frac{k^{1/2}}{m_2^{1/2}} g(k t_i)")

#text("where ")#mi("g(t) = \\frac{1}{1+At} 1_{[0,T]}(t)")#text(" for some parameters ")#mi("A,T>0")#text(" (in practice we take ")#mi("A")#text(" close to ")#mi("\\log k")#text(" and ")#mi("T")#text(" close to ")#mi("k/\\log k")#text("), and ")#mi("m_i := \\int_0^T g(t)^i\\ dt")#text(". Hypothesis (1) is automatic, and the left-hand side of (2) can be bounded from below by")

#mi("\\frac{m_1^2}{m_2} ( 1 - {\\bf P}( X_1 + \\ldots + X_{k-1}  \\geq k - T ) )")#text(" (3)")

#text("where ")#mi("X_1,\\ldots,X_{k-1}")#text(" are iid random variables with distribution ")#mi("\\frac{1}{m_2} g(t)^2\\ dt")#text(".")

#text("If one wishes to use ")#mi("MPZ[\\varpi,\\delta]")#text(" as the starting hypothesis instead of ")#mi("EH[\\theta]")#text(", one replaces ")#mi("\\frac{2}{\\theta}")#text(" by ")#mi("\\frac{m}{1/4+\\varpi}")#text(", and one has to add the additional hypothesis that ")#mi("F")#text(" is supported in the cube ")#mi("[0,\\tilde \\delta]^k")#text(" with ")#mi("\\tilde \\delta := \\frac{\\delta}{1/4+\\varpi}")#text(". The latter hypothesis is obeyed if")

#mi("\\frac{T}{k} \\leq \\tilde \\delta.")#text(" (4)")

#text("If one uses the stronger hypothesis ")#mi("MPZ^{(i)}[\\varpi,\\delta]")#text(" instead, one can relax the support condition on ")#mi("F")#text(" to the intersection of the larger cube ")#mi("[0, \\tilde \\delta^{\\prime}]^k")#text(" and the set of ")#mi("(t_1,\\ldots,t_k)")#text(" such that")

#mi("\\sum_{1 \\leq j \\leq k: t_j < \\tilde \\delta} t_j > \\theta")

#text("where")

#mi("\\theta := \\frac{ (i\\delta^{\\prime}-\\delta)/2+ \\varpi}{1/4 + \\varpi}")

#text("and ")#mi("\\delta^{\\prime} > \\delta")#text(" is arbitrary with ")#mi("\\tilde \\delta^{\\prime} := \\frac{\\delta^{\\prime}}{1/4+\\varpi}")#text("; this follows from Lemma 4.13 of the Polymath8a paper. This has the effect of relaxing (4) to")

#mi("\\frac{T}{k} \\leq \\tilde \\delta^{\\prime}.")#text(" (4)’")

#text("at the cost of worsening (3) to")

#mi("\\frac{m_1^2}{m_2} ( 1 - {\\bf P}( X_1 + \\ldots + X_{k-1}  \\geq k - T )")

#mi("- {\\bf P}( \\sum_{1 \\leq j \\leq k-1: X_j< \\tilde \\delta k} X_j < \\theta k ) )")#text(". (3′)")

#text("We may optimise ")#mi("\\tilde \\delta^{\\prime}")#text(" by making (4)’ an equality.")

#text("Using the exponential moment method, we can lower bound (3′) by")

#mi("\\frac{m_1^2}{m_2} ( 1 - \\kappa_1 -  \\kappa_2 )")

#text("where")

#mi("\\kappa_1 := e^{-s(k-T)} (\\frac{1}{m_2}\\int_0^T e^{st} g(t)^2\\ dt)^{k-1}")

#text("and")

#mi("\\kappa_2 := e^{s^{\\prime} \\theta k} (\\frac{1}{m_2}\\int_0^{\\tilde \\delta k} e^{-s^{\\prime}t} g(t)^2\\ dt)^{k-1}")

#text("and s,s’ may be chosen as we please. Thus: we obtain ")#mi("DHL[k_0,m+1]")#text(" whenever we can find ")#mi("\\varpi, \\delta, A, T, s, s^{\\prime}")#text(" obeying")

#mi("\\frac{m_1^2}{m_2} ( 1 - \\kappa_1 -  \\kappa_2 ) > \\frac{m}{1/4+\\varpi}")

#text("with ")#mi("\\delta^{\\prime}")#text(" given by equality in (4′), with ")#mi("\\delta \\leq \\delta^{\\prime}")#text(". Our best estimate for ")#mi("MPZ^{(i)}[\\varpi,\\delta]")#text(" is with ")#mi("i=4")#text(" and ")#mi("\\frac{1080}{13} \\varpi + \\frac{330}{13} {\\delta} < 1")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-254945")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2013")])]

#mi("\\kappa_2")#text(" above can be made arbitrarily small (no lower bound on ")#mi("s^{\\prime}")#text(".)")

#emph[#text("[Oops, there was a typo in the definition of ")#mi("\\kappa_2")#text(", now corrected. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255149")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2013")])]

#text("There is a typo in the last inequality (last line.) ")#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255153")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2013")])]

#text("I spent some time this weekend reading up on the beta sieve (and on its role in the proof of Chen’s theorem that there are infinitely many primes p such that p+2 is an almost prime (the product of at most two primes)), in the hope that it could be a viable substitute for the Selberg sieve for this project; in particular, I think it would be a great result if one could find an alternate proof of bounded gaps between primes that did not rely fundamentally on a Selberg-type sieve. Unfortunately, it seems that while just about any of the standard sieves (including the beta sieve) can produce probability distributions for which one has ")#mi("{\\bf P}( n + h_i \\text{ prime } ) > \\frac{c}{k}")#text(" for some small constant c and all i=1,…,k, it seems thus far that only the Selberg sieve can get c larger than 1 (which gives bounded gaps between primes) and to even grow logarithmically in k (which gives bounds on ")#mi("H_m")#text(" for all m). I still do not have a clean conceptual understanding of why the Selberg sieve can do this; I have a vague sense that there is some interplay between the “L^2” nature of the Selberg sieve, and the “L^1” nature of density of primes in that sieve, but my intuition on this is still lacking. For the beta sieve, the best I can do is to multiply together k one-dimensional beta sieves of level ")#mi("x^{1/k}")#text("; it is not obvious to me how to create a genuinely k-dimensional beta sieve, although this is perhaps worth pursuing. (I was intending to write up some notes on the beta sieve but they would basically duplicate a chapter of “Opera del Cribro”, in particular there are some rather tricky calculations involving delayed difference equations which I have thus far been unable to avoid.)")

#text("Incidentally, in “Opera del Cribro” it is noted that one can prove Chen’s theorem using a combination of beta and Selberg sieves if one uses the FI distribution theorems (which roughly speaking give a level of distribution of 4/7 (or in our notation, ")#mi("\\varpi=1/28")#text(") when specialised specifically to the twin prime problem). Roughly speaking, the beta sieve gives a lower bound on the number of numbers ")#mi("n \\leq x")#text(" with ")#mi("n+2")#text(" prime such that ")#mi("n")#text(" has no prime factors less than ")#mi("x^{3/11}")#text(", and the Selberg sieve gives an upper bound on the number of primes ")#mi("m")#text(" such that ")#mi("m-2")#text(" is the product of three primes greater than ")#mi("x^{3/11}")#text(", and subtracting the two one gets a positive lower bound for the pairs needed for Chen’s theorem. It may be worth revisiting the proof of the FI distribution theorem and see if it may somehow be combined with some of Zhang’s ideas to get new distribution theorems that are usable for the k-tuple problem and not just the twin prime problem. (I did check to see if one can use the special structure of the coefficients in the error terms in the Zhang/Polymath8a arguments, but these coefficients get eliminated as a by-product of the van der Corput process and other necessary applications of Cauchy-Schwarz, so it is not obvious how to exploit the structure. Though FI, BFI, etc. did somehow manage this…)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255280")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2013")])]

#text("Here is a side benefit of the multidimensional sieve in Maynard’s paper: it gives a new upper bound on the number of ")#mi("n \\leq x")#text(" such that ")#mi("n+h_1,\\ldots,n+h_k")#text(" are all prime, i.e. the number of fully prime k-tuplets. The standard sieves (Selberg sieve, large sieve, beta sieve) all give an upper bound of ")#mi("(Ck)^k {\\frak G} \\frac{x}{\\log^k x}")#text(" for this quantity for some absolute constant C and sufficiently large x, as can be seen by looking up Friedlander-Iwaniec’s book; here ")#mi("{\\frak G}")#text(" is the singular series, thus this bound is basically ")#mi("(Ck)^k")#text(" worse than what the prime tuples conjecture predicts. (The large sieve and Selberg sieve give a slightly better value for C here than the beta sieve.) If one inserts in the multidimensional sieve, one can improve this to ")#mi("(\\frac{Ck}{\\log k})^k {\\frak G} \\frac{x}{\\log^k x}")#text(" (in fact one gets this bound whenever one sieves k residue classes modulo p for all large primes p from an interval of length x). Basically, the problem is now to minimise the ratio")

#tao-math("\\displaystyle \\frac{\\int_{{\\cal R}_k} F_{1\\dots k}^2}{\\left|F(0,\\ldots,0)\\right|^2}", block: false)

#text("rather than maximise the ratio")

#mi("\\displaystyle \\frac{ \\sum_{i=1}^k \\int_{{\\cal R}_{k-1}} F_{1 \\dots i-1,i+1 \\dots k}(t_1,\\ldots,t_{i-1},0,t_{i+1},\\ldots,t_k)^2}{\\int_{{\\cal R}_k} F_{1\\dots k}^2}")

#text("but the two variational problems are comparable in much the same way that the root test and ratio test are comparable in undergraduate analysis.")

#text("In the converse direction, if one can find another sieve that gives a bound of ")#mi("o(k)^k {\\frak G} \\frac{x}{\\log^k x}")#text(" for the number of fully prime k-tuplets, then this sieve is likely to also be able to obtain bounded gaps between primes, or to find short intervals with many primes in them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255349")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2013")])]

#text("Oops, turns out I made an arithmetic error :(. The sieve in Maynard’s paper actually gives the same bound ")#mi("(Ck)^k")#text(" as existing sieves, and this is the limit of the Selberg sieve method (with ")#mi("C = \\frac{2}{e\\theta}")#text(", ")#mi("\\theta")#text(" being the level of distribution), basically because the volume of the simplex is ")#mi("1/k!")#text(". As with the root and ratio tests, one only has one direction of the implication: a sieve that can beat the ")#mi("(Ck)^k")#text(" bound for the k-tuple problem will also likely give many primes in short intervals, but the converse is not necessarily true.")

#text("Still it looks like an interesting problem to get ")#mi("o(k)^k")#text(" for the k-tuple problem. In the converse direction, the parity problem obstruction suggests a lower bound of ")#mi("2^k")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46e7a76cd66a757d19d9f5af908aaed13cda328d2dc85fc45cb638835f8f0b2a-8f4cfbdf2ec7a89c9d4c76f0eb76619c0bc29a5ea4ff8cf298140822c00bc6f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andre")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255351")[#strong[#text("Andre")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2013")])]

#text("Is there still a need for your new simplified minimization problem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255563")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2013")])]

#text("I was asking, because I think I have found polynomials ")#mi("P_{k,m}")#text(" of degree ")#mi("m>0")#text(" with")#linebreak()#text(" ")#mi("\\int_{{\\mathcal R}_k}P_{k,m}^2 = 2m^2 \\prod_{l=-1}^k (2m+l)^{-1}")#linebreak()#text(" and ")#mi("P_{k,m}(0) = 1")#text(",")#linebreak()#text(" which would have given better bounds than the trivial ")#mi("F := 1")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255593")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2013")])]

#text("I should have mentioned that in the simplified variational problem, F has to vanish to sufficiently high order on the boundary of the simplex to be admissible. With that assumption, one obtains from the fundamental theorem of calculus that ")#mi("F(0) = \\int_{{\\cal R}_k} F_{1\\dots k}")#text(", and so the Cauchy-Schwarz inequality tells us that the extremum occurs when ")#mi("F_{1\\ldots k} = 1")#text(" on the simplex (strictly speaking, one has to smoothly truncate this near the boundary of the simplex, but the error incurred from this can be made arbitrarily small), so the infimal value of this ratio is the reciprocal of the volume of the simplex, i.e. ")#mi("k!")#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73c0e3d57b00886275d80464e248e1bcebafdecaa7b53d9714bdc35de9b99145-e014b284c49640ea982cdd01e62212e14ba40c4e3a909d0cc69bec699d0aa292.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The new Prime gap | On the learning curve...")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255517")[#strong[#text("The new Prime gap | On the learning curve...")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2013")])]

#text("[…] discussed within the community. Terrance Tao again has this nicely articulated and maintains a polymath page for us. As an onlooker, I am as excited as many others to see this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255577")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2013")])]

#text("I thought I would give a quick update on some recent progress in optimizing the methods described in James’ preprint. (As these ideas are already implicit in James’ paper, I’ve told him he is free to use these bounds in the final version of his paper, so they are not properly part of the polymath8b project, but they still might be of interest to people here.)")

#text("As usual, let ")#mi("k")#text(" be fixed. Let ")#mi("a_1\\geq a_2 \\geq \\ldots \\geq a_k\\geq 0")#text(" be a sequence of integers. We say that ")#mi("\\alpha=(a_1,a_2,\\ldots, a_k)")#text(" is the signature for the monomial symmetric polynomial ")#mi("m(\\alpha)=\\sum_{\\sigma \\in S_k}x_{\\sigma(1)}^{a_1}x_{\\sigma(2)}^{a_2}\\cdots x_{\\sigma(k)}^{a_k}")#text(", and that ")#mi("d=\\sum_{i=1}^{k}a_i")#text(" is the degree. The monomial symmetric polynomials form a vector space basis for the space of symmetric polynomials, and James has a good way of integrating these polynomials over ")#mi("\\mathcal{R}_k")#text(", with a formula already appearing in his preprint.")

#text("So, I wrote a program to search for an optimal solution using such polynomials, up to a given degree. It turns out that there are significant gains over previous computations, and for degree ")#mi("d=10")#text(" one can get ")#mi("k=74")#text(" and this is optimal for that degree. Increasing the degree further increases ")#mi("k")#text(" further, but because of the way I coded the program it runs into RAM issues for ")#mi("d=11")#text(". [It has problems computing the permutations of the set ")#mi("\\{(1,0),(1,0),\\ldots, (1,0),(0,1),(0,1),\\ldots,(0,1)\\}")#text(" (where ")#mi("(1,0),(0,1)")#text(" each occur exactly 11 times.]")

#text("To overcome this, I starting doing what James does in his paper, working with polynomials of the form ")#mi("\\{m(\\alpha) : {\\rm deg}(\\alpha)\\leq 10\\} \\cup \\{(1-P_1)^a m(\\alpha) : {\\rm deg}(\\alpha)=10, 0\\leq a\\leq a_0\\}")#text(". Taking ")#mi("a_0=3")#text(" allows one to get down to ")#mi("k=64")#text(".")

#text("We are hopeful that eventually these computations will get the optimal ")#mi("k")#text(", but there is still a lot of optimizing to do. Currently, taking ")#mi("a_0=5")#text(", the computation takes about 1 day for a single value of ")#mi("k")#text(".")

#text("James and I have some ideas about how to fix the RAM issue and so further improvements are forthcoming. [For example, one option is to restrict to signatures ")#mi("\\alpha")#text(" for which the number of nonzero terms is at most 10.] Anyone interested in running the Mathematica code on their own computer can email me. (Running it shouldn’t be a problem, but I didn’t make many comments in the code, so it may take a bit of work to understand it.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255595")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2013")])]

#text("Very nice to hear! For comparison, the upper bound ")#mi("M_k \\leq \\frac{k}{k-1} \\log k")#text(" shows that k should not be able to go below 50, and for k=64, we have ")#mi("M_k \\leq 4.22")#text(" (we need ")#mi("M_k > 4")#text(" to win here on Bombieri-Vinogradov). So things are pretty consistent here (and the upper bound is looking remarkably sharp, all things considered – this may suggest some sort of clue as to what the extremising F are behaving like, and possibly to suggest a better theoretical ansatz for F than the one we are currently using (a truncated tensor product) that has only managed to get down to k=339 thus far).")

#text("One might hope that the computations get a little bit faster as k drops. Hopefully it becomes small enough that we can begin computing the effect of truncating the simplex a bit to use MPZ (and also to enlarge the simplex to the slightly larger convex body that is available, and perhaps also to try to use the upper bounds on ")#mi("P_{ij}")#text(" to shave a little bit more off of H).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255621")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("For ")#mi("m=2")#text(", this implies that under EH the best ")#mi("k")#text(" under the current method is in ")#mi("[51, 64]")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255629")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("Currently, the dependence of the timing of the computation on the value of ")#mi("k")#text(" is minimal–it just changes the coefficients a bit but the number of coefficients is unchanged. Eventually ")#mi("k")#text(" would have an effect, by limiting the lengths of signatures, but as I suggested above, we may need to artificially impose a limit on such lengths to make the computations feasible. (And for ")#mi("k=51")#text(" this effect would only naturally start taking place when ")#mi("d=25")#text(" or so.)")

#text("I too have thought about whether or not these computations would give us a better idea where to look for the optimal ")#mi("F")#text(". I’ll try to look for a pattern in the structure of the optimal ")#mi("F")#text(" for a given degree as ")#mi("d")#text(" increases, and report back if I see anything.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255632")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("Pace, could you post a list of the optimal F you’ve found for each degree up to 10? I think it would be fun for everyone to look for such a pattern.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255659")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("Aubrey,")

#text("How would you like the data? Would the coefficients of the monomial symmetric polynomials ")#mi("m(\\alpha)")#text(" work for you?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255660")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("Well, I’m not equipped to make nearly so much use of the data as others here, so I’d prefer to defer to the group as to format. I guess I was assuming that you would essentially emulate equation 7.18 from James’s paper, but please use whatever format seems most convenient and we can all complain as needed :-)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255642")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("For a given polynomial ")#mi("F")#text(", let ")#mi("F_j := \\mathcal L ^j F")#text(". My suggestion is to use ")#mi("F_1, ..., F_N")#text(" (for some N) as a new basis (or add them to the current basis.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Childman")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255596")[#strong[#text("Childman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2013")])]

#text("Since it may get increasingly computationally intensive to get lower values of k, it may be a good idea to rewrite the optimization code for some kind of grid or distributed computing..")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255582")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2013")])]

#text("For ")#mi("k = 64")#text(", we have a bound ")#mi("H = 330")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255663")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("As suggested by Aubrey and Roger Baker here at BYU, I’ve now looked at the coefficients of the maximizing function ")#mi("F")#text(" of a given degree. I have not seen any pattern, but that may be due to a number of different factors. Here is a partial list of the data. For the full list just email me and I’ll send you the file.")

#text("Throughout, take ")#mi("k=59")#text(" (which gives gap sizes of ")#mi("H=300")#text(", so it would be really nice to reach this point). First, let me list the lower bounds on ")#mi("M_k")#text(" for each degree.")

#text("For ")#mi("d=1")#text(", ")#mi("M_k \\geq 2.8560278...")#text(".")#linebreak()#text(" For ")#mi("d=2")#text(", ")#mi("M_k \\geq 3.1819534...")#text(".")#linebreak()#text(" For ")#mi("d=3")#text(", ")#mi("M_k \\geq 3.3686854...")#text(".")#linebreak()#text(" For ")#mi("d=4")#text(", ")#mi("M_k \\geq 3.5046840...")#text(".")#linebreak()#text(" For ")#mi("d=5")#text(", ")#mi("M_k \\geq 3.6092828...")#text(".")#linebreak()#text(" For ")#mi("d=6")#text(", ")#mi("M_k \\geq 3.6922649...")#text(".")#linebreak()#text(" For ")#mi("d=7")#text(", ")#mi("M_k \\geq 3.7596139...")#text(".")#linebreak()#text(" For ")#mi("d=8")#text(", ")#mi("M_k \\geq 3.8147156...")#text(".")#linebreak()#text(" For ")#mi("d=9")#text(", ")#mi("M_k \\geq 3.8604234...")#text(".")#linebreak()#text(" For ")#mi("d=10")#text(", ")#mi("M_k \\geq 3.8984021...")#text(".")

#text("Any idea if this sequence is converging below 4?")

#text("To give the coefficients of ")#mi("F")#text(", we first need a way to order the signatures. First, to save space we can drop any zeros from the end of a signature, so the signatures correspond to the partitions of the degree. I then order the signatures first according to total degree, and then according to how Mathematica orders the partitions (which is by taking the maximal ")#mi("a_1")#text(", then the maximal ")#mi("a_2")#text(" etc…).")

#text("So, my signatures start out as: ")#mi("\\{\\}, \\{1\\},\\{2\\},\\{1,1\\},\\{3\\},\\{2,1\\},\\{1,1,1\\},\\ldots")#text(".")

#text("For ")#mi("d=1")#text(", the coefficients are ")#mi("0.7074087...,-0.7068046...")#text(".")#linebreak()#text(" For ")#mi("d=2")#text(", the coefficients are ")#mi("0.3116618...,-0.6281882...,0.3290948...,0.6324104...")#text(".")#linebreak()#text(" For ")#mi("d=3")#text(", the coefficients are ")#mi("-0.0932515...,0.2857225...,-0.3188407...,-0.5819451...,0.1238405...,0.3236689...,0.5909730...")#text(".")

#text("The entries continue to decrease as ")#mi("d")#text(" increases.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255664")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("(Of course, the above was also suggested by Terry.)")

#text("When I said that the entries decrease, I meant in absolute value. They continue to change signs.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46e7a76cd66a757d19d9f5af908aaed13cda328d2dc85fc45cb638835f8f0b2a-8f4cfbdf2ec7a89c9d4c76f0eb76619c0bc29a5ea4ff8cf298140822c00bc6f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andre")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255665")[#strong[#text("Andre")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("perhaps with some more digits, the inverse symbolic calculator might help")#linebreak()#text(" ")#link("http://oldweb.cecm.sfu.ca/projects/ISC/ISCmain.html")[#text("http://oldweb.cecm.sfu.ca/projects/ISC/ISCmain.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255668")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("Thanks!")

#text("I doubt, tentatively, that the sequence M_k[d] which you give converges below 4. By simplistic inspection, I notice that the ratio of (M_k[d+1] – M_k[d]) to (M_k[d+2] – M_k[d+1]) decreases monotonically with increasing d, being around 1.2 for the largest k you list; this makes it look highly unlikely that M_k[15] < 4. However, there is a disconcerting \"wobble\" in the sequence, in that the last few values of this ratio decrease by 0.029, 0,008, 0.017 and 0.003, inviting apprehension that it might start to increase again, conceivably sharply enough to allow M_k[d] to converge below 4. Let's hope you can push your code that far! (Though, actually the wobble would almost entirely go away if M_k[7] were actually around 3.761 rather than 3.759 – worth a check?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255671")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("The ratios of the last four consecutive differences are quite stable:")#linebreak()#text(" ")#mi("0.8309..., 0.8295..., 0.8181..., 0.8116...")#text(" – indicating linear convergence (with a rate of about 0.8) to a limit of about ")#mi("4.06")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255672")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("Yes indeed – my numbers are of course just the reciprocals of yours. The wobble is still evident (differences of 0.014, 0.114, 0.065). I’m still betting Pace will update M_k[7] !")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255674")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("I meant 0.0014, 0.0114, 0.0065 of course.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255680")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("I double checked it, and the value I gave for M_k[7] is correct (and will not improve, unless there is a bug in my program).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255685")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("Thanks. I actually made a decimal-place error in my own calculations, and the M_59[7] that I should have said I was expecting was actually 3.7594 – but if the wobble is real, so be it!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255679")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("According to this (linear convergence) hypothesis of the lower bounds, it seems that the minimal ")#mi("d")#text(" needed to conclude that ")#mi("M_{59} > 4")#text(" is ")#mi("d =15")#text(" (or ")#mi("d = 16")#text(" – in case of small extrapolation errors.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255681")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("Just to give one more data point: Using the notation in my earlier post, and taking ")#mi("k=59,d=10,a_0=5")#text(" yields the bound ")#mi("M_k\\geq 3.95608...")#text(". (One can view this as an approximate ")#mi("d=15")#text(" computation.) So it looks like there can be a big difference between using all symmetric polynomials of a given degree, and just using those of the form ")#mi("(1-P_1)^a m(\\alpha)")#text(" for ")#mi("\\alpha")#text(" of medium degree.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255760")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2013")])]

#text("Assuming (as described above) that ")#mi("M_{59}")#text(" is about ")#mi("4.06")#text(" and (by the current upper and lower bounds on ")#mi("M_k")#text(") that")#linebreak()#text(" ")#mi("M_k - M_{k-1}")#text(" is about ")#mi("1/k")#text(", it seems that the minimal ")#mi("k")#text(" for which ")#mi("M_k > 4")#text(" is ")#mi("k = 56")#text(".")#linebreak()#text(" Therefore, I suggest to concentrate in particular on ")#mi("k = 55, 56")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255761")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2013")])]

#text("That makes sense – but while there remains a major issue around CPU time, and especially while our speculations as to the sequence for d>10 remain so tentative, I can also see a case for working down from k=64 one step at a time. There is also, of course, the consideration that at any moment Terry or others may chime in with a rigorisation of MPZ in the small-k setting that renders all this BV-context work largely peripheral.")

#text("Additionally, I hope people haven’t forgotten too much about m > 1. I guess xfxie has been busy elsewhere lately, but it would be great (especially for Drew!) if there could be an update on the best obtainable k for m=2 arising from Terry’s progress in exploiting the exponential moment method.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255669")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("First pair looks like ")#mi("\\pm \\sqrt{2}")#text(". Is it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255682")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("No. They are accurate to the decimals I gave, so they are not ")#mi("\\pm \\sqrt{2}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255740")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2013")])]

#text("Hm, but they differ from +/- 1/sqrt(2) by very very nearly exactly the same amount – their average is 0.70710665, and sqrt(2) is 0.70710678. Can that really be a coincidence?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-256028")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2013")])]

#text("I just realized something silly.")

#text("The switching of signs, the decreasing of absolute values, and the pair above looking like ")#mi("\\pm \\sqrt{2}")#text(" are all artifacts of Mathematica normalizing the optimal ")#mi("F")#text(".")

#text("Recall that ")#mi("F")#text(" is really only determined up to a constant. What we should have been doing this whole time is normalizing so that the constant term is exactly 1. Sorry for not realizing this earlier.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-256035")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2013")])]

#text("Ha! OK: can you post revised values?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255677")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("Pace: it might be instructive if we could do this kind of intuitive analysis for smaller k, not least to see what sort of value of d (in other words, how much work in optimising your code) seems likely to be needed to determine what is the truly minimal k obtainable using current ideas. Do you yet have a M_k[d] sequence for k = 58, 57 etc?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255678")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("PS: Naturally I’m also thinking about k < 51, in anticipation of progress in rigorising the post-Maynard validity of MPZ (and thereby lowering the required M_k below 4).")

#text("Also: I'm unclear as to the impact of raising a_0. You mentioned earlier that you obtained k=64 using a_0=3, but also that you are currently experimenting with a_0=5. Can you give us a sense of what you're seeing in terms of the dependence of k on a_0 (rather than just d)? The magnitude of that impact would somewhat inform whether it is worth taking the time to derive a set of M_k sequences for k = 58, 57 … for a_0 = 3 (or 4) in order to enable the above analysis.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255683")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("I’m seeing the following: Increasing ")#mi("a_0")#text(" by 1 increases the run-time by double, but also seems to decrease ")#mi("k")#text(" by one or two (in the short term). So taking ")#mi("a_0=4")#text(" should let us get ")#mi("k=63")#text(" or ")#mi("62")#text(".")

#text("On the other hand, increasing ")#mi("d")#text(" by $1$ multiplies the run-time in a quadratic fashion. So ")#mi("d=6")#text(" takes 8 seconds, ")#mi("d=7")#text(" takes 21 seconds, ")#mi("d=8")#text(" takes 110 seconds, ")#mi("d=9")#text(" takes 14 minutes, and ")#mi("d=10")#text(" takes a little over 2 hours. I expect ")#mi("d=11")#text(" to take about a day, etc…")

#text("When I get some time, I’ll try to derive the sequence ")#mi("M_{59}")#text(" for different ")#mi("a_0")#text(". Currently, my computer processor is busy doing a few other computations.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255762")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2013")])]

#text("Pace: could you please re-post that sequence for d=3? – it is appearing truncated after the first five values, and I now have a feeling that the last two could be quite informative. Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255766")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2013")])]

#text("The last few are -0.5819451…,0.1238405…,0.3236689…,0.5909730….")

#text("(You can also see them by scrolling over the LaTeX.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255770")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2013")])]

#text("Many thanks. (The scroll-over doesn’t work for me – browser issue I guess.) I think I’m ready for the complete file – please send it to ")#link("mailto:aubrey@sens.org")[#text("aubrey@sens.org")]#text(" – thanks!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75a7f7ea5e8c1e2ae94d73c80133f113244da3402d20374ab42e89f28a0007d8-69af76fda1ecb5b019dd09a9852822ac1e6a80afba05383fdf5c4bae2a5ddce5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phil Dee")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255928")[#strong[#text("Phil Dee")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2013")])]

#text("So what are the tentative values for H_1 at the moment ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8b, III: Numerical optimisation of the variational problem, and a search for new sieves | What's new")]], [#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-255956")[#strong[#text("Polymath8b, III: Numerical optimisation of the variational problem, and a search for new sieves | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2013")])]

#text("[…] for small values of (in particular ) or asymptotically as . The previous thread may be found here. The currently best known bounds on […]")
]
