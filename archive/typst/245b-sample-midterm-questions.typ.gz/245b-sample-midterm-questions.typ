// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/01/25/245b-sample-midterm-questions/
// Converted to Typst by tao2typ: "2026-10-14T07:10:25.120734+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245B: Sample midterm questions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245B: Sample midterm questions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 January 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/01/25/245b-sample-midterm-questions/")[#text("https://terrytao.wordpress.com/2009/01/25/245b-sample-midterm-questions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Below the fold, I am giving some sample questions for the 245B midterm next week. These are drawn from my previous 245A and 245B exams (with some modifications), and the solutions can be found by searching my ")#link("http://www.math.ucla.edu/%7Etao/245a.1.04f")[#text("previous")]#text(" ")#link("http://www.math.ucla.edu/~tao/245b.1.05w/index.html")[#text("web pages")]#text(" for those courses. (The homework assignments are, of course, another good source of practice problems.) Note that the actual midterm questions are likely to be somewhat shorter than the ones provided here (this is particularly the case for those questions with multiple parts). More info on the midterm can be found at the ")#link("http://www.math.ucla.edu/~tao/245b.1.09w")[#text("class web page")]#text(", of course.")

#text("(These questions are of course primarily intended for my students than for my regular blog readers; but anyone is welcome to comment if they wish.)")

#metadata(none) <tao-e8b7edb7497b9a2cfdec>

#strong[#text("Question 1.")]#text(" Let ")#mi("(X, {\\mathcal X}, \\mu)")#text(" be a ")#mi("\\sigma")#text("-finite measure space, and let ")#mi("\\nu: {\\mathcal X} \\to {\\Bbb R}")#text(" be a signed ")#mi("\\sigma")#text("-finite measure. Show that the following are equivalent:")

#enum(start: 1, 
[#mi("-\\mu \\leq \\nu \\leq \\mu")#text(".")],
[#tao-math("\\left|\\nu\\right| \\leq \\mu", block: false)#text(".")],
[#mi("\\nu \\ll \\mu")#text(" and ")#tao-math("\\left|\\frac{d\\nu}{d\\mu}\\right| \\leq 1", block: false)#text(" ")#mi("\\mu")#text("-a.e.. ")#mi("\\diamond")]
)

#strong[#text("Question 2.")]#text(" Let ")#mi("({\\Bbb R}, {\\mathcal B})")#text(" be the real line with the Borel ")#mi("\\sigma")#text("-algebra, and let ")#mi("\\mu: {\\mathcal B} \\to [0,+\\infty)")#text(" be a ")#mi("\\sigma")#text("-finite unsigned measure. Show that it is not possible for counting measure ")#mi("\\#")#text(" on the real line (restricted to ")#mi("{\\mathcal B}")#text(") to be absolutely continuous with respect to ")#mi("\\mu")#text(", i.e. ")#mi("\\# \\not \\ll \\mu")#text(". ")#mi("\\diamond")

#strong[#text("Question 3.")]#text(" Let ")#mi("1 \\leq p < \\infty")#text(", let ")#mi("\\ell^p({\\Bbb N})")#text(" be the Banach space of ")#mi("p^{th}")#text(" power summable real sequences ")#mi("(a_n)_{n \\in {\\Bbb N}}")#text(" with the usual ")#mi("\\ell^p")#text(" norm. For each natural number n, let ")#mi("e_n")#text(" be the element of ")#mi("\\ell^p({\\Bbb N})")#text(" consisting of the sequence which equals 1 at the ")#mi("n^{th}")#text(" entry and 0 elsewhere, thus ")#mi("(e_n)_m = 1")#text(" when ")#mi("n=m")#text(" and ")#mi("(e_n)_m =0")#text(" otherwise. Let ")#mi("a_1, a_2, a_3, \\ldots")#text(" be a sequence in a Banach space X.")

#enum(start: 1, 
[#text("Show that there is at most one continuous linear transformation ")#mi("T: \\ell^p({\\Bbb N}) \\to X")#text(" with the property that ")#mi("T e_n = a_n")#text(" for all natural numbers n.")],
[#text("If ")#mi("p=1")#text(", show that there exists a continuous linear transformation ")#mi("T: \\ell^1({\\Bbb N}) \\to X")#text(" with ")#mi("T e_n = a_n")#text(" for all natural numbers n if and only if the sequence ")#mi("a_1, a_2, \\ldots")#text(" is bounded. ")#mi("\\diamond")],
[#text("If ")#mi("p=\\infty")#text(", show that the uniqueness claim 1. can fail. ")#mi("\\diamond")]
)

#strong[#text("Question 4.")]#text(" Let W be a vector space, let A be an index set, and for every ")#mi("\\alpha \\in A")#text(", let ")#mi("V_\\alpha")#text(" be a subspace of W which is equipped with a norm ")#mi("\\| \\|_{V_\\alpha}")#text(". Suppose that for each ")#mi("\\alpha")#text(", the normed vector space ")#mi("(V_\\alpha, \\| \\|_{V_\\alpha})")#text(" is a Banach space. Assume also the following compatibility condition: if ")#mi("\\alpha, \\beta \\in A")#text(" and ")#mi("x_n")#text(" is a sequence in ")#mi("V_\\alpha \\cap V_\\beta")#text(" which converges in ")#mi("V_\\alpha")#text(" norm to x and in ")#mi("V_\\beta")#text(" norm to y, then x is necessarily equal to y. Show that the space")

#align(center)[#tao-fit-display[#tao-math("V := \\{ x \\in \\bigcap_{\\alpha \\in A} V_\\alpha: \\sum_{\\alpha \\in A} \\left\\| x\\right\\|_{V_\\alpha} < \\infty \\},", block: true)]]

#text("equipped with the norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\| x \\right\\|_V = \\sum_{\\alpha \\in A} \\left\\|x\\right\\|_{V_\\alpha},", block: true)]]

#text("is also a Banach space. ")#mi("\\diamond")

#strong[#text("Question 5.")]#text(" Let H be a Hilbert space, and let")

#align(center)[#tao-fit-display[#mitex("V_1 \\subset V_2 \\subset V_3 \\subset \\ldots \\subset H")]]

#text("be an increasing sequence of closed subspaces of H. Let ")#mi("V := \\overline{\\bigcup_{n=1}^\\infty V_n}")#text(" be the closure of the union of these subspaces; this is another closed subspace of H. Show that for any x in H, the sequence ")#mi("\\pi_{V_n}(x)")#text(" converges in norm to ")#mi("\\pi_V(x)")#text(", where ")#mi("\\pi_V(x)")#text(" is the orthogonal projection of x to V, and similarly for ")#mi("\\pi_{V_n}(x)")#text(". ")#mi("\\diamond")

#strong[#text("Question 6.")]#text(" Let H be a Hilbert space, and let V be a closed subspace of H which is non-trivial (i.e. not equal to ")#mi("\\{0\\}")#text("). Let ")#mi("\\pi_V")#text(" be the orthogonal projection onto V.")

#enum(start: 1, 
[#text("Show that ")#mi("\\pi_V")#text(" has operator norm 1.")],
[#text("Show that ")#mi("\\pi_V")#text(" is self-adjoint, i.e. ")#mi("\\pi_V^* = \\pi_V")#text(".")],
[#text("Show that ")#mi("\\pi_V")#text(" is ")#link("http://en.wikipedia.org/wiki/Idempotent")[#text("idempotent")]#text(", i.e. ")#mi("\\pi_V^2 = \\pi_V")#text(".")],
[#text("Conversely, if ")#mi("P: H \\to H")#text(" is a self-adjoint idempotent continuous linear transformation of operator norm 1, show that ")#mi("P = \\pi_V")#text(" for some non-trivial subspace of H. ")#mi("\\diamond")]
)

#text("[")#emph[#text("Update")]#text(", Feb 2: Question 4 corrected.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/25/245b-sample-midterm-questions/#comment-35253")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2009")])]

#text("What’s this “ocunting measure” in question 2? Sounds dirty … ")#emph[#text("[Fixed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/25/245b-sample-midterm-questions/#comment-35343")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2009")])]

#text("For question 2, I also don’t understand the counting measure. So it lives on the sigma-algebra consisting of all the subsets of R, but niu is with Borel sigma-algebra. So they lives on different sigma-algebra.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/25/245b-sample-midterm-questions/#comment-35345")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2009")])]

#text("Fair enough; I intended to restrict counting measure to the Borel sigma algebra, and have now indicated this accordingly. (A measure on a sigma algebra can always be restricted to a sub-sigma algebra without difficulty.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/25/245b-sample-midterm-questions/#comment-38188")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2009")])]

#text("Dear professor!")

#text("I have a question which relate adjoint space. That is: ” Is ")#mi("C^*[0,1]")#text(" linear isomorphism with ")#mi("C[0,1]")#text("?” ")#mi("C[0,1]")#text(" is space of continous function in ")#mi("[0,1]")#text(". If we choose inner product of ")#mi("C[0,1]")#text(" is ")#mi(": C[0,1]\\longrightarrow\\Bbb{R}")#text(", by ")#mi("=\\int_0^1 f(x)g(x)dx")#text(" then ")#mi("C*[0,1] = C[0,1]")#text(" (isormophism)?")

#text("Thank you very much!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8005d57f3f9820cfbbd79dfed5dff6bb439ae89ccb3d8b11b558767ff5d02036-5430d6ca8c3c58e749e87538965caa293e1a45370f3db3b143a6ded179a01ba0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam Azzam")]], [#link("https://terrytao.wordpress.com/2009/01/25/245b-sample-midterm-questions/#comment-215923")[#strong[#text("Adam Azzam")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2013")])]

#text("I hate to be this comment; but I suppose that ")#mi("V")#text(" should also be non-trivial (so that the operator norm of the orthogonal projection is non-zero). ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2009/01/25/245b-sample-midterm-questions/#comment-671112")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2022")])]

#text("Wow, I really like this collection of problems.")#linebreak()#text(" Do you also have a sample final term, or is it possible to share the actualy finals and actual mid term questions? I followed this series of lectures very closely, and would surely like to give the problems a shot.")#linebreak()#text(" (I’d soon post my solutions / attempts to solve these problems in a comment below.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2009/01/25/245b-sample-midterm-questions/#comment-671113")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2022")])]

#text("Solution to Q6:")#linebreak()#text(" Part 1: Follows from Pythagorean theorem, and by taking a unit vector in the subspace.")

#text("Part 2: We have ")#mi("\\langle \\pi _V (x) , y \\rangle = \\langle \\pi _V (x) , \\pi _V (y ) \\rangle + \\langle \\pi _V (x) , y - \\pi _V (y) \\rangle")#text(" but the second term vanishes since the residual ")#mi("y - \\pi _V (y)")#text(" is orthogonal to every element of ")#mi("V")#text(" and hence in particular it is orthogonal to ")#mi("\\pi _V (x).")#text(" Similarly, one has ")#mi("\\langle x , \\pi _V (y) \\rangle = \\langle \\pi _v (x) , \\pi _V (y) \\rangle.")

#text("Part 3: This follows from definition, since ")#mi("\\pi_v (y)")#text(" is the unique element of ")#mi("z \\in V")#text(" which minimizes ")#tao-math("\\left|\\left|z - x\\right|\\right|", block: false)#text(" over all ")#mi("z \\in V.")

#text("Part 4: First of all notice that the range of a bounded idempotent operator is closed (")#mi("P x_n \\to z \\implies P(x_n) = P^2 (x_n) \\to P(z)")#text(" thus ")#mi("P(z) = z")#text(" in particular ")#mi("z")#text(" is in the range of ")#mi("P")#text(").")#linebreak()#text(" Let ")#mi("V")#text(" be the range of ")#mi("P;")#text(" then one has (thanks to idempotent property) ")#mi("x = Px")#text(" for all ")#mi("x \\in V.")#text(" Now we have ")#mi("\\langle x , y \\rangle = \\langle Px , y \\rangle = \\langle x , Py \\rangle (thanks to self-adjoint property), thus we get")#text("latex \\langle x , y – Py \\rangle = 0$ for all ")#mi("x \\in V;")#text(" but this is equivalent to saying that ")#tao-math("\\left|\\left| y - Py\\right|\\right| = \\inf_{z \\in V} \\left|\\left|y-z\\right|\\right|", block: false)#text(" or in other words, that ")#mi("Py")#text(" is the orthogonal projection of ")#mi("y")#text(" onto ")#mi("V.")#text(" The claim follows. ")#mi("\\square")

#text("Solution to Q5: We will use the fact that projections are bounded linear operators. (One way to show this is to use Part 1 of Q6.)")#linebreak()#text(" To begin, notice that since ")#mi("V_n")#text(" is a closed subspace of ")#mi("V")#text(" so ")#mi("\\pi_{V_n} \\circ \\pi_V = \\pi _{V_n}.")#text(" Thus it suffices to show that ")#tao-math("\\left|\\left| \\pi_{V_n} (y) - y \\right|\\right| \\to 0", block: false)#text(" for all ")#mi("y \\in V.")#linebreak()#text(" If ")#mi("y \\in V")#text(" then there is a sequence ")#mi("(y_n)")#text(" of points ")#mi("y_n \\in V_n")#text(" such that ")#tao-math("\\left|\\left|y_n - y\\right|\\right| \\to 0", block: false)#text(" as ")#mi("n \\to \\infty.")#text(" One has (by the triangle inequality):")#linebreak()#text(" ")#tao-math("\\left|\\left| \\pi _{V_n} (y) - y \\right|\\right| \\le \\left|\\left| \\pi_{V_n} (y_n) - y_n\\right|\\right| + \\left|\\left| \\pi_{V_n} ( y ) - \\pi _{V_n} (y_n)\\right|\\right| + \\left|\\left|y_n - y\\right|\\right|;", block: false)#text(" using uniform boundedness principle the second term on the right hand side of the line of display goes to zero as ")#mi("n \\to \\infty,")#text(" and the other quantities also go to zero as ")#mi("n \\to \\infty")#text(" since ")#mi("y_n \\to y,")#text(" as ")#mi("n \\to \\infty.")

#text("(PS: The comment above this one was made without reading that the solutions are already available; so I’ll post the solutions, only if I find signficantly distinct solutions to the remaining ones’.)")
]
