// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/03/14/rectification-and-the-lefschetz-principle/
// Converted to Typst by tao2typ: "2026-10-14T16:36:59.877608+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Rectification and the Lefschetz principle", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Rectification and the Lefschetz principle")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 March 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/03/14/rectification-and-the-lefschetz-principle/")[#text("https://terrytao.wordpress.com/2013/03/14/rectification-and-the-lefschetz-principle/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#emph[#text("rectification principle")]#text(" in arithmetic combinatorics asserts, roughly speaking, that very small subsets (or, alternatively, small structured subsets) of an additive group or a field of large characteristic can be modeled (for the purposes of arithmetic combinatorics) by subsets of a group or field of zero characteristic, such as the integers ")#mi("{{\\bf Z}}")#text(" or the complex numbers ")#mi("{{\\bf C}}")#text(". The additive form of this principle is known as the ")#emph[#text("Freiman rectification principle")]#text("; it has several formulations, going back of course to the ")#link("http://www.ams.org/mathscinet-getitem?mr=360496")[#text("original work of Freiman")]#text(". Here is one formulation as ")#link("http://www.ams.org/mathscinet-getitem?mr=1608875")[#text("given by Bilu, Lev, and Ruzsa")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Additive rectification)")]#text(" ")#metadata(none) <tao-0a473ebefc5a26e43017>#text(" Let ")#mi("{A}")#text(" be a subset of the additive group ")#mi("{{\\bf Z}/p{\\bf Z}}")#text(" for some prime ")#mi("{p}")#text(", and let ")#mi("{s \\geq 1}")#text(" be an integer. Suppose that ")#tao-math("{\\left|A\\right| \\leq \\log_{2s} p}", block: false)#text(". Then there exists a map ")#mi("{\\phi: A \\rightarrow A^{\\prime}}")#text(" into a subset ")#mi("{A^{\\prime}}")#text(" of the integers which is a ")#link("http://planetmath.org/FreimanIsomorphism.html")[#text("Freiman isomorphism of order ")#mi("{s}")]#text(" in the sense that for any ")#mi("{x_1,\\ldots,x_s,y_1,\\ldots,y_s \\in A}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("x_1+\\ldots+x_s = y_1+\\ldots+y_s")]]

#text("if and only if")

#align(center)[#tao-fit-display[#mitex("\\phi(x_1)+\\ldots+\\phi(x_s) = \\phi(y_1)+\\ldots+\\phi(y_s).")]]

#text("Furthermore ")#mi("{\\phi}")#text(" is a right-inverse of the obvious projection homomorphism from ")#mi("{{\\bf Z}}")#text(" to ")#mi("{{\\bf Z}/p{\\bf Z}}")#text(".")
]

#text("The original version of the rectification principle allowed the sets involved to be substantially larger in size (cardinality up to a small constant multiple of ")#mi("{p}")#text("), but with the additional hypothesis of bounded doubling involved; see the above-mentioned papers, as well as this ")#link("http://www.ams.org/mathscinet-getitem?mr=2201602")[#text("later paper of Green and Ruzsa")]#text(", for further discussion.")

#text("The proof of Proposition ")#link(<tao-0a473ebefc5a26e43017>)[#text("1")]#text(" is quite short (see Theorem 3.1 of ")#link("http://www.ams.org/mathscinet-getitem?mr=1608875")[#text("Bilu-Lev-Ruzsa")]#text("); the main idea is to use ")#link("http://en.wikipedia.org/wiki/Minkowski's_theorem")[#text("Minkowski’s theorem")]#text(" to find a non-trivial dilate ")#mi("{aA}")#text(" of ")#mi("{A}")#text(" that is contained in a small neighbourhood of the origin in ")#mi("{{\\bf Z}/p{\\bf Z}}")#text(", at which point the rectification map ")#mi("{\\phi}")#text(" can be constructed by hand.")

#text("Very recently, ")#link("http://arxiv.org/abs/1303.2363")[#text("Codrut Grosu")]#text(" obtained an arithmetic analogue of the above theorem, in which the rectification map ")#mi("{\\phi}")#text(" preserves both additive and multiplicative structure:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Arithmetic rectification)")]#text(" ")#metadata(none) <tao-9c8c2643095d646511d6>#text(" Let ")#mi("{A}")#text(" be a subset of the finite field ")#mi("{{\\bf F}_p}")#text(" for some prime ")#mi("{p \\geq 3}")#text(", and let ")#mi("{s \\geq 1}")#text(" be an integer. Suppose that ")#tao-math("{\\left|A\\right| < \\log_2 \\log_{2s} \\log_{2s^2} p - 1}", block: false)#text(". Then there exists a map ")#mi("{\\phi: A \\rightarrow A^{\\prime}}")#text(" into a subset ")#mi("{A^{\\prime}}")#text(" of the complex numbers which is a ")#emph[#text("Freiman field isomorphism of order ")#mi("{s}")]#text(" in the sense that for any ")#mi("{x_1,\\ldots,x_n \\in A}")#text(" and any polynomial ")#mi("{P(x_1,\\ldots,x_n)}")#text(" of degree at most ")#mi("{s}")#text(" and integer coefficients of magnitude summing to at most ")#mi("{s}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("P(x_1,\\ldots,x_n)=0")]]

#text("if and only if")

#align(center)[#tao-fit-display[#mitex("P(\\phi(x_1),\\ldots,\\phi(x_n))=0.")]]
]

#text("Note that it is necessary to use an algebraically closed field such as ")#mi("{{\\bf C}}")#text(" for this theorem, in contrast to the integers used in Proposition ")#link(<tao-0a473ebefc5a26e43017>)[#text("1")]#text(", as ")#mi("{{\\bf F}_p}")#text(" can contain objects such as square roots of ")#mi("{-1}")#text(" which can only map to ")#mi("{\\pm i}")#text(" in the complex numbers (once ")#mi("{s}")#text(" is at least ")#mi("{2}")#text(").")

#text("Using Theorem ")#link(<tao-9c8c2643095d646511d6>)[#text("2")]#text(", one can transfer results in arithmetic combinatorics (e.g. sum-product or Szemerédi-Trotter type theorems) regarding finite subsets of ")#mi("{{\\bf C}}")#text(" to analogous results regarding sufficiently small subsets of ")#mi("{{\\bf F}_p}")#text("; see ")#link("http://arxiv.org/abs/1303.2363")[#text("the paper of Grosu")]#text(" for several examples of this. This should be compared with the ")#link("http://www.ams.org/mathscinet-getitem?mr=2835338")[#text("paper of Vu, Wood, and Wood")]#text(", which introduces a converse principle that embeds finite subsets of ")#mi("{{\\bf C}}")#text(" (or more generally, a characteristic zero integral domain) in a Freiman field-isomorphic fashion into finite subsets of ")#mi("{{\\bf F}_p}")#text(" for arbitrarily large primes ")#mi("{p}")#text(", allowing one to transfer arithmetic combinatorical facts from the latter setting to the former.")

#text("Grosu’s argument uses some quantitative elimination theory, and in particular a quantitative variant of a ")#link("http://www.ams.org/mathscinet-getitem?mr=2006555")[#text("lemma of Chang")]#text(" that ")#link("https://terrytao.wordpress.com/2011/07/05/polynomial-bounds-via-nonstandard-analysis/")[#text("was discussed previously")]#text(" on this blog. In that previous blog post, it was observed that (an ineffective version of) Chang’s theorem could be obtained using only qualitative algebraic geometry (as opposed to quantitative algebraic geometry tools such as elimination theory results with explicit bounds) by means of ")#link("http://en.wikipedia.org/wiki/Nonstandard_analysis")[#text("nonstandard analysis")]#text(" (or, in what amounts to essentially the same thing in this context, the use of ")#link("http://en.wikipedia.org/wiki/Ultraproduct")[#text("ultraproducts")]#text("). One can then ask whether one can similarly establish an ineffective version of Grosu’s result by nonstandard means. The purpose of this post is to record that this can indeed be done without much difficulty, though the result obtained, being ineffective, is somewhat weaker than that in Theorem ")#link(<tao-9c8c2643095d646511d6>)[#text("2")]#text(". More precisely, we obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Ineffective arithmetic rectification)")]#text(" ")#metadata(none) <tao-d9059e9a4fb2bfab2799>#text(" Let ")#mi("{s, n \\geq 1}")#text(". Then if ")#mi("{{\\bf F}}")#text(" is a field of characteristic at least ")#mi("{C_{s,n}}")#text(" for some ")#mi("{C_{s,n}}")#text(" depending on ")#mi("{s,n}")#text(", and ")#mi("{A}")#text(" is a subset of ")#mi("{{\\bf F}}")#text(" of cardinality ")#mi("{n}")#text(", then there exists a map ")#mi("{\\phi: A \\rightarrow A^{\\prime}}")#text(" into a subset ")#mi("{A^{\\prime}}")#text(" of the complex numbers which is a Freiman field isomorphism of order ")#mi("{s}")#text(".")
]

#text("Our arguments will not provide any effective bound on the quantity ")#mi("{C_{s,n}}")#text(" (though one could in principle eventually extract such a bound by deconstructing the proof of Proposition ")#link(<tao-03f03be21462b76ccb5f>)[#text("4")]#text(" below), making this result weaker than Theorem ")#link(<tao-9c8c2643095d646511d6>)[#text("2")]#text(" (save for the minor generalisation that it can handle fields of prime power order as well as fields of prime order as long as the characteristic remains large).")

#text("Following the principle that ultraproducts can be used as a bridge to connect quantitative and qualitative results (as discussed in ")#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")[#text("these previous")]#text(" ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("blog posts")]#text("), we will deduce Theorem ")#link(<tao-d9059e9a4fb2bfab2799>)[#text("3")]#text(" from the following (well-known) qualitative version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (Baby Lefschetz principle)")]#text(" ")#metadata(none) <tao-03f03be21462b76ccb5f>#text(" Let ")#mi("{k}")#text(" be a field of characteristic zero that is finitely generated over the rationals. Then there is an isomorphism ")#mi("{\\phi: k \\rightarrow \\phi(k)}")#text(" from ")#mi("{k}")#text(" to a subfield ")#mi("{\\phi(k)}")#text(" of ")#mi("{{\\bf C}}")#text(".")
]

#text("This principle (first laid out in an appendix of ")#link("http://www.ams.org/mathscinet-getitem?mr=56950")[#text("Lefschetz’s book")]#text("), among other things, often allows one to use the methods of complex analysis (e.g. Riemann surface theory) to study many other fields of characteristic zero. There are many variants and extensions of this principle; see for instance ")#link("http://mathoverflow.net/questions/90551/")[#text("this MathOverflow post")]#text(" for some discussion of these. I used this baby version of the Lefschetz principle recently in ")#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/")[#text("a paper on expanding polynomial maps")]#text(".")

#emph[#text("Proof:")]#text(" We give two proofs of this fact, one using transcendence bases and the other using Hilbert’s nullstellensatz.")

#text("We begin with the former proof. As ")#mi("{k}")#text(" is finitely generated over ")#mi("{{\\bf Q}}")#text(", it has finite ")#link("http://en.wikipedia.org/wiki/Transcendence_degree")[#text("transcendence degree")]#text(", thus one can find algebraically independent elements ")#mi("{x_1,\\ldots,x_m}")#text(" of ")#mi("{k}")#text(" over ")#mi("{{\\bf Q}}")#text(" such that ")#mi("{k}")#text(" is a finite extension of ")#mi("{{\\bf Q}(x_1,\\ldots,x_m)}")#text(", and in particular by the ")#link("http://en.wikipedia.org/wiki/Primitive_element_theorem")[#text("primitive element theorem")]#text(" ")#mi("{k}")#text(" is generated by ")#mi("{{\\bf Q}(x_1,\\ldots,x_m)}")#text(" and an element ")#mi("{\\alpha}")#text(" which is algebraic over ")#mi("{{\\bf Q}(x_1,\\ldots,x_m)}")#text(". (Here we use the fact that characteristic zero fields are separable.) If we then define ")#mi("{\\phi}")#text(" by first mapping ")#mi("{x_1,\\ldots,x_m}")#text(" to generic (and thus algebraically independent) complex numbers ")#mi("{z_1,\\ldots,z_m}")#text(", and then setting ")#mi("{\\phi(\\alpha)}")#text(" to be a complex root of of the minimal polynomial for ")#mi("{\\alpha}")#text(" over ")#mi("{{\\bf Q}(x_1,\\ldots,x_m)}")#text(" after replacing each ")#mi("{x_i}")#text(" with the complex number ")#mi("{z_i}")#text(", we obtain a field isomorphism ")#mi("{\\phi: k \\rightarrow \\phi(k)}")#text(" with the required properties.")

#text("Now we give the latter proof. Let ")#mi("{x_1,\\ldots,x_m}")#text(" be elements of ")#mi("{k}")#text(" that generate that field over ")#mi("{{\\bf Q}}")#text(", but which are not necessarily algebraically independent. Our task is then equivalent to that of finding complex numbers ")#mi("{z_1,\\ldots,z_m}")#text(" with the property that, for any polynomial ")#mi("{P(x_1,\\ldots,x_m)}")#text(" with rational coefficients, one has")

#align(center)[#tao-fit-display[#mitex("P(x_1,\\ldots,x_m) = 0")]]

#text("if and only if")

#align(center)[#tao-fit-display[#mitex("P(z_1,\\ldots,z_m) = 0.")]]

#text("Let ")#mi("{{\\mathcal P}}")#text(" be the collection of all polynomials ")#mi("{P}")#text(" with rational coefficients with ")#mi("{P(x_1,\\ldots,x_m)=0}")#text(", and ")#mi("{{\\mathcal Q}}")#text(" be the collection of all polynomials ")#mi("{P}")#text(" with rational coefficients with ")#mi("{P(x_1,\\ldots,x_m) \\neq 0}")#text(". The set")

#align(center)[#tao-fit-display[#mitex("S := \\{ (z_1,\\ldots,z_m) \\in {\\bf C}^m: P(z_1,\\ldots,z_m)=0 \\text{ for all } P \\in {\\mathcal P} \\}")]]

#text("is the intersection of countably many ")#link("http://en.wikipedia.org/wiki/Algebraic_set")[#text("algebraic sets")]#text(" and is thus also an ")#link("http://en.wikipedia.org/wiki/Algebraic_set")[#text("algebraic set")]#text(" (by the Hilbert basis theorem or the Noetherian property of algebraic sets). If the desired claim failed, then ")#mi("{S}")#text(" could be covered by the algebraic sets ")#mi("{\\{ (z_1,\\ldots,z_m) \\in {\\bf C}^m: Q(z_1,\\ldots,z_m) = 0 \\}}")#text(" for ")#mi("{Q \\in {\\mathcal Q}}")#text(". By decomposing into irreducible varieties and observing (e.g. from the Baire category theorem) that a variety of a given dimension over ")#mi("{{\\bf C}}")#text(" cannot be covered by countably many varieties of smaller dimension, we conclude that ")#mi("{S}")#text(" must in fact be covered by a finite number of such sets, thus")

#align(center)[#tao-fit-display[#mitex("S \\subset \\bigcup_{i=1}^n \\{ (z_1,\\ldots,z_m) \\in {\\bf C}^m: Q_i(z_1,\\ldots,z_m) = 0 \\}")]]

#text("for some ")#mi("{Q_1,\\ldots,Q_n \\in {\\bf C}^m}")#text(". By the ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_Nullstellensatz")[#text("nullstellensatz")]#text(", we thus have an identity of the form")

#align(center)[#tao-fit-display[#mitex("(Q_1 \\ldots Q_n)^l = P_1 R_1 + \\ldots + P_r R_r")]]

#text("for some natural numbers ")#mi("{l,r \\geq 1}")#text(", polynomials ")#mi("{P_1,\\ldots,P_r \\in {\\mathcal P}}")#text(", and polynomials ")#mi("{R_1,\\ldots,R_r}")#text(" with coefficients in ")#mi("{\\overline{{\\bf Q}}}")#text(". In particular, this identity also holds in the algebraic closure ")#mi("{\\overline{k}}")#text(" of ")#mi("{k}")#text(". Evaluating this identity at ")#mi("{(x_1,\\ldots,x_m)}")#text(" we see that the right-hand side is zero but the left-hand side is non-zero, a contradiction, and the claim follows. ")#mi("\\Box")

#text("From Proposition ")#link(<tao-03f03be21462b76ccb5f>)[#text("4")]#text(" one can now deduce Theorem ")#link(<tao-d9059e9a4fb2bfab2799>)[#text("3")]#text(" by a routine ultraproduct argument (the same one used in ")#text("these")#text(" ")#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")[#text("previous")]#text(" ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("blog posts")]#text("). Suppose for contradiction that Theorem ")#link(<tao-d9059e9a4fb2bfab2799>)[#text("3")]#text(" fails. Then there exists natural numbers ")#mi("{s,n \\geq 1}")#text(", a sequence of finite fields ")#mi("{{\\bf F}_i}")#text(" of characteristic at least ")#mi("{i}")#text(", and subsets ")#mi("{A_i=\\{a_{i,1},\\ldots,a_{i,n}\\}}")#text(" of ")#mi("{{\\bf F}_i}")#text(" of cardinality ")#mi("{n}")#text(" such that for each ")#mi("{i}")#text(", there does not exist a Freiman field isomorphism of order ")#mi("{s}")#text(" from ")#mi("{A_i}")#text(" to the complex numbers. Now we select a ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("non-principal ultrafilter")]#text(" ")#mi("{\\alpha \\in \\beta {\\bf N} \\backslash {\\bf N}}")#text(", and construct the ultraproduct ")#mi("{{\\bf F} := \\prod_{i \\rightarrow \\alpha} {\\bf F}_i}")#text(" of the finite fields ")#mi("{{\\bf F}_i}")#text(". This is again a field (and is a basic example of what is known as a ")#link("http://en.wikipedia.org/wiki/Pseudo-finite_field")[#text("pseudo-finite field")]#text("); because the characteristic of ")#mi("{{\\bf F}_i}")#text(" goes to infinity as ")#mi("{i \\rightarrow \\infty}")#text(", it is easy to see (using ")#link("http://en.wikipedia.org/wiki/Los%27s_theorem#.C5.81o.C5.9B.27s_theorem")[#text("Los’s theorem")]#text(") that ")#mi("{{\\bf F}}")#text(" has characteristic zero and can thus be viewed as an extension of the rationals ")#mi("{{\\bf Q}}")#text(".")

#text("Now let ")#mi("{a_j := \\lim_{i \\rightarrow \\alpha} a_{i,j}}")#text(" be the ultralimit of the ")#mi("{a_{i,j}}")#text(", so that ")#mi("{A := \\{a_1,\\ldots,a_n\\}}")#text(" is the ultraproduct of the ")#mi("{A_i}")#text(", then ")#mi("{A}")#text(" is a subset of ")#mi("{{\\bf F}}")#text(" of cardinality ")#mi("{n}")#text(". In particular, if ")#mi("{k}")#text(" is the field generated by ")#mi("{{\\bf Q}}")#text(" and ")#mi("{A}")#text(", then ")#mi("{k}")#text(" is a finitely generated extension of the rationals and thus, by Proposition ")#link(<tao-03f03be21462b76ccb5f>)[#text("4")]#text(" there is an isomorphism ")#mi("{\\phi: k \\rightarrow \\phi(k)}")#text(" from ")#mi("{k}")#text(" to a subfield ")#mi("{\\phi(k)}")#text(" of the complex numbers. In particular, ")#mi("{\\phi(a_1),\\ldots,\\phi(a_n)}")#text(" are complex numbers, and for any polynomial ")#mi("{P(x_1,\\ldots,x_n)}")#text(" with integer coefficients, one has")

#align(center)[#tao-fit-display[#mitex("P(a_1,\\ldots,a_n) = 0")]]

#text("if and only if")

#align(center)[#tao-fit-display[#mitex("P(\\phi(a_1),\\ldots,\\phi(a_n)) = 0.")]]

#text("By Los’s theorem, we then conclude that for all ")#mi("{i}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(", one has for all polynomials ")#mi("{P(x_1,\\ldots,x_n)}")#text(" of degree at most ")#mi("{s}")#text(" and whose coefficients are integers whose magnitude sums up to ")#mi("{s}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("P(a_{i,1},\\ldots,a_{i,n}) = 0")]]

#text("if and only if")

#align(center)[#tao-fit-display[#mitex("P(\\phi(a_1),\\ldots,\\phi(a_n)) = 0.")]]

#text("But this gives a Freiman field isomorphism of order ")#mi("{s}")#text(" between ")#mi("{A_i}")#text(" and ")#mi("{\\phi(A)}")#text(", contradicting the construction of ")#mi("{A_i}")#text(", and Theorem ")#link(<tao-d9059e9a4fb2bfab2799>)[#text("3")]#text(" follows.")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a382183d3ed7cf33b841b9044414e6aa0b91df1f4ea991fed59aa4ff2caf406-aa091041e3d91f48464237b83b2439f11d347b3a9aaa0c27dc2e4ef3724cb570.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of g")]], [#link("https://terrytao.wordpress.com/2013/03/14/rectification-and-the-lefschetz-principle/#comment-219496")[#strong[#text("g")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2013")])]

#text("I like the condition p>=3 in the statement of Theorem 2. I mean, for the result to be nontrivial we need s>=2 and |A|>=1, in which case we have 1 8^(4^(2^2)) = 8^256 = 2^768. Just as well you specified that p>=3!")

#text("(For the other conditions to be possible, even if trivial, we need s>=1 and |A|>=0, in which case we have 0 2^(2^(2^1)) = 16.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/03/14/rectification-and-the-lefschetz-principle/#comment-219518")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2013")])]

#text("Just a typo – Codrut’s surname is Grosu.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf321d2381e42eadefd8656eac9e6e7b6d3ff9a7151d5d15179969026eac88b8-6feb69172594a33a6fb9335aa62951fddf7db2d141a6be16bbeb13cf2f217a2a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of murphmath")]], [#link("https://terrytao.wordpress.com/2013/03/14/rectification-and-the-lefschetz-principle/#comment-219547")[#strong[#text("murphmath")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2013")])]

#text("In the last few paragraphs there’s a limit taken as i–>p and Los’s theorem is applied for i sufficiently close to p — should it be alpha instead of p?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da0b0eef4bc9fc2fc8b4c2f5f11e9db93f9ba007cc26e260c5743c2f41510ed6-a9a2604e5dfd7eb6dda7531813f331032f1679105ac4edce0bb9fdcb0dd3a5b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2013/03/14/rectification-and-the-lefschetz-principle/#comment-220723")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2013")])]

#text("Dear prof Tao, do you think discreetness in nature is an emergent property? Or are continuus objects derived from discrete objects? Riemann zeta function is a continuous function which encodes the property of the primes, but mathematics and physics (even string theory) itself is formulated using finite discrete symbols.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f34b3e2a15b0cc4432e4d4b0d43c92097fe600938f12005eb1fef603efcb7edf-05dcadc2be8616f16d6b091ab0787b2e8f264c56b9e28a03d3601cc5e4b6af67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pierre")]], [#link("https://terrytao.wordpress.com/2013/03/14/rectification-and-the-lefschetz-principle/#comment-220940")[#strong[#text("Pierre")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2013")])]

#text("Dear Terry,")#linebreak()#text(" I discussed this question with Udi Hrushovski a few months ago.")#linebreak()#text(" If I am not mistaken, one can use constructive Nullstellensatz to obtain a similar result. In fact, Theorem 1 of this paper: Sharp estimates for the arithmetic Nullstellensatz (T. Krick, L.M. Pardo, M. Sombra)")#linebreak()#text(" seems to give better bounds of the form |A| << log(log(p)) to some power depending on s, where p is the characteristic of the finite field.")
]
