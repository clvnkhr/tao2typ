// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/03/12/hamidounes-freiman-kneser-theorem-for-nonabelian-groups/
// Converted to Typst by tao2typ: "2026-10-14T16:36:26.565666+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Hamidoune’s Freiman-Kneser theorem for nonabelian groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Hamidoune’s Freiman-Kneser theorem for nonabelian groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 March 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/03/12/hamidounes-freiman-kneser-theorem-for-nonabelian-groups/")[#text("https://terrytao.wordpress.com/2011/03/12/hamidounes-freiman-kneser-theorem-for-nonabelian-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A few days ago, I received the sad news that ")#link("http://www.math.jussieu.fr/~hamidoune/hamidoune.html")[#text("Yahya Ould Hamidoune")]#text(" had recently died. Hamidoune worked in additive combinatorics, and ")#link("http://arxiv.org/abs/1006.5074")[#text("had recently solved")]#text(" a ")#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/")[#text("question on noncommutative Freiman-Kneser theorems posed by myself on this blog last year")]#text(". Namely, Hamidoune showed")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Noncommutative Freiman-Kneser theorem for small doubling)")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" Let ")#mi("{0 < \\epsilon \\leq 1}")#text(", and let ")#mi("{S \\subset G}")#text(" be a finite non-empty subset of a multiplicative group ")#mi("{G}")#text(" such that ")#tao-math("{\\left|A \\cdot S\\right| \\leq (2-\\epsilon) \\left|S\\right|}", block: false)#text(" for some finite set ")#mi("{A}")#text(" of cardinality ")#tao-math("{\\left|A\\right|}", block: false)#text(" at least ")#tao-math("{\\left|S\\right|}", block: false)#text(", where ")#mi("{A \\cdot S := \\{ as: a \\in A, s \\in S \\}}")#text(" is the product set of ")#mi("{A}")#text(" and ")#mi("{S}")#text(". Then there exists a finite subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" with cardinality ")#tao-math("{\\left|H\\right| \\leq C(\\epsilon) \\left|S\\right|}", block: false)#text(", such that ")#mi("{S}")#text(" is covered by at most ")#mi("{C^{\\prime}(\\epsilon)}")#text(" right-cosets ")#mi("{H \\cdot x}")#text(" of ")#mi("{H}")#text(", where ")#mi("{C(\\epsilon), C^{\\prime}(\\epsilon) > 0}")#text(" depend only on ")#mi("{\\epsilon}")#text(".")
]

#text("One can of course specialise here to the case ")#mi("{A=S}")#text(", and view this theorem as a classification of those sets ")#mi("{S}")#text(" of doubling constant at most ")#mi("{2-\\epsilon}")#text(".")

#text("In fact Hamidoune’s argument, which is completely elementary, gives the very nice explicit constants ")#mi("{C(\\epsilon) := \\frac{2}{\\epsilon}}")#text(" and ")#mi("{C^{\\prime}(\\epsilon) := \\frac{2}{\\epsilon} - 1}")#text(", which are essentially optimal except for factors of ")#mi("{2}")#text(" (as can be seen by considering an arithmetic progression in an additive group). This result was also independently established (in the ")#mi("{A=S}")#text(" case) by Tom Sanders (unpublished) by a more Fourier-analytic method, in particular drawing on ")#link("http://arxiv.org/abs/0912.0308")[#text("Sanders’ deep results")]#text(" on the Wiener algebra ")#mi("{A(G)}")#text(" on arbitrary non-commutative groups ")#mi("{G}")#text(".")

#text("This type of result had previously been known when ")#mi("{2-\\epsilon}")#text(" was less than the golden ratio ")#mi("{\\frac{1+\\sqrt{5}}{2}}")#text(", as first observed ")#link("http://www.ams.org/mathscinet-getitem?mr=435006")[#text("by Freiman")]#text("; see ")#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/")[#text("my previous blog post")]#text(" for more discussion.")

#text("Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" is not, strictly speaking, contained in Hamidoune’s paper, but can be extracted from his arguments, which share some similarity with the recent simple proof of the Ruzsa-Plünnecke inequality ")#link("http://arxiv.org/abs/1101.3507")[#text("by Petridis")]#text(" (as discussed ")#link("http://gowers.wordpress.com/2011/02/10/a-new-way-of-proving-sumset-estimates/")[#text("by Tim Gowers here")]#text("), and this is what I would like to do below the fold. I also include (with permission) Sanders’ unpublished argument, which proceeds instead by Fourier-analytic methods. ")#metadata(none) <tao-600cdf8e641298f38512>

#heading(level: 1)[#strong[#text(" — 1. Hamidoune’s argument — ")]]

#text("Fix ")#mi("{S}")#text(", ")#mi("{G}")#text(", and ")#mi("{\\epsilon}")#text(". For any finite set ")#mi("{A}")#text(" (possibly empty), and any real number ")#mi("{K \\in {\\bf R}}")#text(", consider the quantity ")#mi("{c(A) = c_{K,S}(A)}")#text(" defined by the formula")

#align(center)[#tao-fit-display[#tao-math("c(A) := \\left|A\\cdot S\\right| - K|A|.", block: true)]]

#text("This measures the extent to which ")#mi("{S}")#text(" “expands” ")#mi("{A}")#text(", compared against the reference expansion constant ")#mi("{K}")#text(". Clearly, this quantity is left-invariant, thus ")#metadata(none) <tao-360f84035942243c6a36>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("c( x \\cdot A ) = c( A )")]]



#text(" for all finite sets ")#mi("{A}")#text(" and ")#mi("{x \\in G}")#text(". It also obeys an important ")#link("http://en.wikipedia.org/wiki/Supermodular_function")[#text("submodularity inequality")]#text(" (also implicitly exploited ")#link("http://arxiv.org/abs/1101.3507")[#text("by Petridis")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Submodularity)")]#text(" ")#metadata(none) <tao-6d9e26c2e0533e2488c7>#text(" For any finite subsets ")#mi("{A, B, S}")#text(" of ")#mi("{G}")#text(", and any ")#mi("{K \\in {\\bf R}}")#text(" one has")

#align(center)[#tao-fit-display[#mitex("c( A \\cup B ) + c( A \\cap B ) \\leq c( A ) + c( B ).")]]
]

#emph[#text("Proof:")]#text(" From the inclusion-exclusion principle one has ")#metadata(none) <tao-e885bbaa72bbeecb87b7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|A \\cup B\\right| + \\left|A \\cap B\\right| = \\left|A\\right| + \\left|B\\right|", block: true)]]



#text(" and")

#align(center)[#tao-fit-display[#tao-math("\\left|(A \\cdot S) \\cup (B \\cdot S)\\right| + \\left|(A \\cdot S) \\cap (B \\cdot S)\\right| = \\left|A \\cdot S\\right| + \\left|B \\cdot S\\right|.", block: true)]]

#text("Since")

#align(center)[#tao-fit-display[#mitex("(A \\cup B) \\cdot S = (A \\cdot S) \\cup (B \\cdot S)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(A \\cap B) \\cdot S \\subset (A \\cdot S) \\cap (B \\cdot S)")]]

#text("we thus have")

#align(center)[#tao-fit-display[#tao-math("\\left|(A \\cup B) \\cdot S\\right| + \\left|(A \\cap B) \\cdot S\\right| \\leq \\left|A \\cdot S\\right| + \\left|B \\cdot S\\right|,", block: true)]]

#text("and the claim follows after subtracting ")#mi("{K}")#text(" copies of ")#link(<tao-e885bbaa72bbeecb87b7>)[#text("(2)")]#text(". ")#mi("\\Box")

#text("Following Hamidoune, we make the following definitions, for fixed ")#mi("{K}")#text(" and ")#mi("{S}")#text(":")

#list(
[#text("The ")#emph[#text("connectivity")]#text(" ")#mi("{\\kappa = \\kappa_K(S)}")#text(" is the infimum of ")#mi("{c(A)}")#text(" over all finite non-empty sets ")#mi("{A}")#text(".")],
[#text("A ")#emph[#text("fragment")]#text(" is a finite non-empty set ")#mi("{A}")#text(" that attains the infimum ")#mi("{\\kappa}")#text(": ")#mi("{c(A) = \\kappa}")#text(".")],
[#text("An ")#emph[#text("atom")]#text(" is a finite non-empty fragment ")#mi("{A}")#text(" of minimal cardinality.")]
)

#text("Hamidoune only considered the ")#mi("{K=1}")#text(" case, but much of his machinery extends to the case ")#mi("{K \\leq 1}")#text(", and in fact becomes slightly simpler for ")#mi("{K<1}")#text(". (In contrast, the argument of Petridis is more focused on the case when ")#mi("{K}")#text(" is large, and in particular on the unique ")#mi("{K}")#text(" for which ")#mi("{\\kappa}")#text(" vanishes.) In this argument, we will specialise ")#mi("{K}")#text(" to be")

#align(center)[#tao-fit-display[#mitex("K := 1 - \\epsilon/2.")]]

#text("With this choice, observe that for any ")#mi("{A}")#text(", we have ")#metadata(none) <tao-cc35c048b250c73f5299>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("c(A) \\geq \\left|A\\right| - K\\left|A\\right| = \\epsilon \\left|A\\right| / 2.", block: true)]]



#text(" In particular, ")#mi("{c(A)}")#text(" is always positive for non-empty ")#mi("{A}")#text(", and takes on a discrete set of values. This implies that ")#mi("{\\kappa}")#text(" is positive, and that at least one fragment exists, which (by the well-ordering principle) implies that at least one atom exists.")

#text("From ")#link(<tao-360f84035942243c6a36>)[#text("(1)")]#text(" we see that any left-translate of a fragment is a fragment, and any left-translate of an atom is an atom.")

#text("Let ")#mi("{A}")#text(" and ")#mi("{B}")#text(" be fragments with non-empty intersection, then from Lemma ")#link(<tao-6d9e26c2e0533e2488c7>)[#text("2")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("c(A \\cup B) + c(A \\cap B) \\leq c(A) + c(B) = 2\\kappa.")]]

#text("On the other hand, since ")#mi("{A \\cup B}")#text(" and ")#mi("{A \\cap B}")#text(" are finite and non-empty, we have ")#mi("{c(A \\cup B), c(A \\cap B) \\geq \\kappa}")#text(". This forces ")#mi("{c(A \\cup B) = c(A \\cap B) = \\kappa}")#text(", and so ")#mi("{A \\cup B}")#text(" and ")#mi("{A \\cap B}")#text(" are also fragments. Specialising to atoms (which, by definition, do not contain any strictly smaller fragments), we conclude that any two atoms ")#mi("{A, B}")#text(" are either equal or disjoint. From this and the left-invariance of the atoms, we see that there is a unique atom ")#mi("{H}")#text(" that contains the identity. This atom is either equal or disjoint to any of its left-translates, which implies that ")#mi("{H}")#text(" is a finite group.")

#text("Now we use the hypothesis that there exists a set ")#mi("{A}")#text(" with ")#tao-math("{\\left|A\\right| \\geq \\left|S\\right|}", block: false)#text(" and ")#tao-math("{\\left|A \\cdot S\\right| \\leq (2-\\epsilon) \\left|S\\right|}", block: false)#text(", which implies that")

#align(center)[#tao-fit-display[#tao-math("c(A) \\leq (2-\\epsilon)\\left|S\\right| - (1-\\epsilon/2) \\left|S\\right| = (1-\\epsilon/2) |S|.", block: true)]]

#text("In particular, we have ")#tao-math("{c(H) = \\kappa \\leq c(A) \\leq (1 - \\epsilon/2) \\left|S\\right|}", block: false)#text(", which by ")#link(<tao-cc35c048b250c73f5299>)[#text("(3)")]#text(" implies an upper bound on ")#mi("{H}")#text(":")

#align(center)[#tao-fit-display[#tao-math("\\left|H\\right| \\leq (\\frac{2}{\\epsilon} - 1) |S|.", block: true)]]

#text("We can also expand the inequality ")#tao-math("{c(H) \\leq (1-\\epsilon/2) \\left|S\\right|}", block: false)#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\left|H \\cdot S\\right| \\leq (1 - \\epsilon/2) \\left|S\\right| + (1-\\epsilon/2) \\left|H\\right|;", block: true)]]

#text("bounding ")#tao-math("{\\left|S\\right|}", block: false)#text(" crudely by ")#tao-math("{\\left|H \\cdot S\\right|}", block: false)#text(" and rearranging, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|H \\cdot S\\right| \\leq (\\frac{2}{\\epsilon} - 1) |H|.", block: true)]]

#text("We conclude that ")#mi("{H \\cdot S}")#text(" (and hence ")#mi("{S}")#text(") can be covered by at most ")#mi("{\\frac{2}{\\epsilon} - 1}")#text(" translates of ")#mi("{H}")#text(", and the claim follows.")

#heading(level: 1)[#strong[#text(" — 2. Sanders’ argument — ")]]

#text("To motivate Sanders’ argument, let us first establish a continuous qualitative analogue of the non-commutative Freiman theorem, in the context of open precompact sets in a locally compact group ")#mi("{G}")#text(" with a bi-invariant Haar measure ")#mi("{\\mu}")#text(". (By convention, Haar measures assign a positive finite measure to every non-empty open precompact set.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Qualitative noncommutative Freiman-Kneser theorem in locally compact groups)")]#text(" Let ")#mi("{G}")#text(" be a locally compact Hausdorff group with a bi-invariant Haar measure ")#mi("{\\mu}")#text(", and let ")#mi("{A \\subset G}")#text(" be an open precompact non-empty subset of ")#mi("{G}")#text(" such that ")#mi("{\\mu( A \\cdot A ) \\leq (2-\\epsilon) \\mu( A )}")#text(" for some ")#mi("{\\epsilon>0}")#text(". Then there exists a compact open subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(", and ")#mi("{A \\cdot A^{-1}}")#text(" is the union of finitely many right cosets of ")#mi("{H}")#text(".")
]

#emph[#text("Proof:")]#text(" We consider the convolution")

#tao-aligned(keep: true)[


#tao-math("f(x)  & := \\frac{1}{\\mu(A)} 1_{A} * 1_{A^{-1}}(x)", block: true)



#tao-math(" & = \\frac{1}{\\mu(A)} \\int_G 1_{A}(y) 1_{A^{-1}}( y^{-1} x )\\ d\\mu(y)", block: true)



#tao-math(" & = \\frac{1}{\\mu(A)} \\mu( A \\cap x \\cdot A ).", block: true)
]

#text("Since ")#mi("{1_A, 1_{A^{-1}}}")#text(" are bounded, compactly supported functions, we see that the convolution ")#mi("{f = 1_A * 1_{A^{-1}}}")#text(" is a continuous, compactly supported function. If ")#mi("{x}")#text(" lies in the support ")#mi("{A \\cdot A^{-1}}")#text(" of ")#mi("{f}")#text(", then ")#mi("{x \\in A \\cdot A^{-1}}")#text(", and thus ")#mi("{x = ab^{-1}}")#text(" for some ")#mi("{a,b \\in A}")#text(". But then")

#align(center)[#tao-fit-display[#mitex("f(x) = \\frac{1}{\\mu(A)} \\mu( (a \\cdot A) \\cap (b \\cdot A) ).")]]

#text("Since ")#mi("{a \\cdot A}")#text(" and ")#mi("{b \\cdot A}")#text(" both lie in ")#mi("{A \\cdot A}")#text(" and have measure ")#mi("{\\mu(A)}")#text(", we see from the hypothesis ")#mi("{\\mu(A \\cdot A) \\leq (2-\\epsilon) \\mu(A)}")#text(" and the inclusion-exclusion principle that we thus have the uniform lower bound ")#metadata(none) <tao-44f1dd2e9ea52424b0c4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("f(x) \\geq \\epsilon")]]



#text(" on the support ")#mi("{A \\cdot A^{-1}}")#text(" of ")#mi("{f}")#text(". In other words, there is a “gap” in the range of ")#mi("{f}")#text(", in that it cannot take on values in the interval ")#mi("{(0,\\epsilon)}")#text(". This gap disconnects the support ")#mi("{A \\cdot A^{-1}}")#text(" from its complement; both sets become both open and closed. In particular, ")#mi("{A \\cdot A^{-1}}")#text(" is now compact. By continuity and compactness, this implies that there exists a neighbourhood ")#mi("{U}")#text(" of the identity such that ")#mi("{U \\cdot A \\cdot A^{-1} = A \\cdot A^{-1}}")#text(". Letting ")#mi("{H}")#text(" be the group generated by ")#mi("{U}")#text(", we conclude that ")#mi("{H}")#text(" is open and contained in the compact set ")#mi("{A \\cdot A^{-1}}")#text(", and thus must also be compact, with ")#mi("{A \\cdot A^{-1}}")#text(" the union of finitely many right-cosets of ")#mi("{H}")#text(" as required. ")#mi("\\Box")

#text("Now we return to the discrete setting. Again, we analyse the function")

#tao-aligned(keep: true)[


#tao-math("f(x)  & := \\frac{1}{\\left|A\\right|} 1_A * 1_{A^{-1}}(x)", block: true)



#tao-math(" & := \\frac{1}{\\left|A\\right|} \\sum_{y \\in G} 1_A(y) 1_A( y^{-1} x )", block: true)



#tao-math(" & = \\frac{1}{\\left|A\\right|} |A \\cap x \\cdot A|.", block: true)
]

#text("As in the continuous case, we can show that ")#mi("{f}")#text(" is bounded away from zero on its support, in the sense that ")#metadata(none) <tao-14f91bc93dc4f0ff486e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("f(x) \\geq \\epsilon")]]



#text(" for all ")#mi("{x}")#text(" in the support ")#mi("{A \\cdot A^{-1}}")#text(" of ")#mi("{f}")#text(". So we once again have a gap in the range of ")#mi("{f}")#text(". However, in this discrete setting, we do not have any obvious quantitative control on the “continuity” of the convolution ")#mi("{f}")#text(" to exploit this gap (this is ultimately because ")#mi("{A}")#text(" does not have good “measurability” properties). However, it turns out that ")#mi("{f}")#text(" is controlled in a certain ")#emph[#text("Wiener algebra")]#text(" ")#mi("{A(G)}")#text(", which roughly speaking is the non-commutative analogue of functions with absolutely convergent Fourier transform. In the abelian setting, the fact that we have control in the Wiener algebra is a consequence of Plancherel’s theorem (that asserts that ")#mi("{L^2}")#text(" functions have square-summable Fourier coefficients), the Cauchy-Schwarz inequality, and the observation that convolution corresponds to pointwise multiplication of Fourier coefficients. It turns out that an analogous statement can be made in the non-abelian case.")

#text("In the classical setting of Fourier series, functions in the Wiener algebra have absolutely convergent Fourier series, and in particular are necessarily continuous. A ")#link("http://arxiv.org/abs/0912.0308")[#text("deep result of Sanders asserts")]#text(", roughly speaking, that in more general non-abelian groups ")#mi("{G}")#text(", functions in the Wiener algebra ")#mi("{A(G)}")#text(" can be uniformly approximated by continuous functions “outside of a set of negligible measure”. A precise version of this statement is as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (Almost uniform approximation by continuous functions)")]#text(" Let ")#mi("{f}")#text(" be as above, and let ")#mi("{\\sigma > 0}")#text(". Then there exists symmetric subset ")#mi("{S^{\\prime}}")#text(" of the identity with ")#tao-math("{\\left|S^{\\prime}\\right| \\gg_\\sigma \\left|A\\right|}", block: false)#text(" and a function ")#mi("{F: G \\rightarrow {\\bf R}^+}")#text(" such that ")#metadata(none) <tao-0a7cb27e52927eacabbb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|F(s^{\\prime} x) - F(x)\\right| \\ll \\sigma", block: true)]]



#text(" and ")#metadata(none) <tao-26d44010e3a666aa47d7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("(\\sum_{s^{\\prime} \\in S^{\\prime}} \\left|F(s^{\\prime} x) - f(s^{\\prime}x)\\right|^2)^{1/2} \\ll \\sigma \\left|S^{\\prime}\\right|^{1/2}", block: true)]]



#text(" for all ")#mi("{s^{\\prime} \\in S^{\\prime}}")#text(" and ")#mi("{x \\in G}")#text(".")
]

#emph[#text("Proof:")]#text(" See Proposition 20.1 of this ")#link("http://arxiv.org/abs/0912.0308")[#text("paper of Sanders")]#text(". The “continuous” function ")#mi("{F}")#text(" is in fact of the form ")#tao-math("{F := \\frac{1}{\\left|S\\right|} 1_S * \\frac{1}{\\left|S\\right|} 1_S * f}", block: false)#text(" for some set ")#mi("{S}")#text(" larger than ")#mi("{S^{\\prime}}")#text(" (but small compared to ")#mi("{A}")#text(").")

#text("We remark that Sanders’ paper uses a nontrivial amount of spectral theory (or nonabelian Fourier analysis). It is possible to use “softer” (and significantly simpler) methods to obtain weaker regularity results on convolutions (giving “")#mi("{L^p}")#text(" continuity” rather than “")#mi("{L^\\infty}")#text(" continuity”), as was done ")#link("http://arxiv.org/abs/1003.2978")[#text("by Croot and Sisask")]#text(", but unfortunately it does not appear that these easier results suffice for the application here (which relies on iterating the control given by continuity, and so cannot handle the small exceptional sets allowed by an ")#mi("{L^p}")#text(" regularity result). ")#mi("\\Box")

#text("Let ")#mi("{\\sigma > 0}")#text(" be a sufficiently small parameter depending on ")#mi("{\\epsilon}")#text(" to be chosen later, and let ")#mi("{F}")#text(" be the approximation to ")#mi("{f}")#text(" given above. From ")#link(<tao-0a7cb27e52927eacabbb>)[#text("(6)")]#text(", ")#link(<tao-26d44010e3a666aa47d7>)[#text("(7)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("(\\sum_{s^{\\prime} \\in S^{\\prime}} \\left|F(x) - f(s^{\\prime}x)\\right|^2)^{1/2} \\ll \\sigma \\left|S^{\\prime}\\right|^{1/2}.", block: true)]]

#text("From this and the gap property ")#link(<tao-14f91bc93dc4f0ff486e>)[#text("(5)")]#text(" we see that ")#mi("{F}")#text(" also has a gap, in that it cannot take values in the interval ")#mi("{[\\epsilon/3,2\\epsilon/3]}")#text(" (say) if ")#mi("{\\sigma}")#text(" is small enough. In particular, from this and ")#link(<tao-0a7cb27e52927eacabbb>)[#text("(6)")]#text(" we see that the set ")#mi("{\\Omega := \\{ x \\in G: F(x) > 2\\epsilon/3 \\}}")#text(" is closed under left-multiplication by ")#mi("{S^{\\prime}}")#text(", if ")#mi("{\\sigma}")#text(" is small enough; since this set contains ")#mi("{1}")#text(", it must therefore contain the group ")#mi("{H}")#text(" generated by ")#mi("{S^{\\prime}}")#text(". On the other hand, ")#mi("{F}")#text(" has an ")#mi("{\\ell^1}")#text(" norm of ")#tao-math("{O(\\left|A\\right|)}", block: false)#text(", and so by Markov’s inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\left|H\\right| \\leq \\left|\\Omega\\right| \\ll \\left|A\\right| / \\epsilon;", block: true)]]

#text("in the other direction we have")

#align(center)[#tao-fit-display[#tao-math("\\left|H\\right| \\geq \\left|S^{\\prime}\\right| \\gg_\\sigma \\left|A\\right|,", block: true)]]

#text("so ")#mi("{H}")#text(" is of comparable size to ")#mi("{A}")#text(". As ")#mi("{F}")#text(" is large (")#mi("{\\gg \\epsilon}")#text(") on ")#mi("{H}")#text(", we can use ")#link(<tao-26d44010e3a666aa47d7>)[#text("(7)")]#text(" to ensure (for ")#mi("{\\sigma}")#text(" small enough) that ")#mi("{f}")#text(" is also large on ")#mi("{H}")#text(" on average (specifically, ")#tao-math("{\\left\\|f\\right\\|_{\\ell^2(H)} \\gg \\left|H\\right|^{1/2} / \\epsilon}", block: false)#text("); this ensures from the pigeonhole principle that some right-translate of ")#mi("{A}")#text(" has large intersection (cardinality ")#tao-math("{\\gg \\left|H\\right|/\\epsilon}", block: false)#text(") with ")#mi("{H}")#text(", and this combined with the bounded doubling of ")#mi("{A}")#text(" ensures that ")#mi("{A}")#text(" is covered by ")#tao-math("{O( \\frac{\\left|A\\right|}{\\epsilon \\left|H\\right|} ) = O_{\\epsilon,\\sigma}(1)}", block: false)#text(" right-translates of ")#mi("{H}")#text(", and the claim follows.")

#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/072454b49454a644d072ad0efe50a12fa5d3ba56d2f7c8fff30945abdb68f200-dbdc60e01b068521411818095509ba9934b663e6d5fa5606218bfe8337f82300.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Petridis")]], [#link("https://terrytao.wordpress.com/2011/03/12/hamidounes-freiman-kneser-theorem-for-nonabelian-groups/#comment-50725")[#strong[#text("Petridis")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2011")])]

#text("Both proofs are very nice. Is the approach of using the submodularity to deduce the uniqueness of the atom containing the identity new?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/12/hamidounes-freiman-kneser-theorem-for-nonabelian-groups/#comment-50732")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2011")])]

#text("I got this from Proposition 2.6 of Hamidoune’s paper, which dates back to this 1984 (!) paper of Hamidoune: ")#link("http://www.ams.org/mathscinet-getitem?mr=782052")[#text("http://www.ams.org/mathscinet-getitem?mr=782052")]

#text("The term ")#link("http://en.wikipedia.org/wiki/Supermodular_function")[#text("submodularity")]#text(" is, strictly speaking, not used in these papers, but if one looks at the proofs, one eventually sees that this is what is underlying the arguments.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/072454b49454a644d072ad0efe50a12fa5d3ba56d2f7c8fff30945abdb68f200-dbdc60e01b068521411818095509ba9934b663e6d5fa5606218bfe8337f82300.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Petridis")]], [#link("https://terrytao.wordpress.com/2011/03/12/hamidounes-freiman-kneser-theorem-for-nonabelian-groups/#comment-50736")[#strong[#text("Petridis")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2011")])]

#text("Thanks for this. In any case it is a very neat proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/03/12/hamidounes-freiman-kneser-theorem-for-nonabelian-groups/#comment-50741")[#strong[#text("Weekly Picks « Mathblogging.org — the Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2011")]

#text("[…] a more research related note, Terry Tao wrote about the late Yahya Ould Hamidoune version of the Freiman-Kneser theorem, at the n-Category Cafe you read about homotopy type theory and Almost Sure announced a new series […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb3ecdff714503271026e0b788f5d9f0b35183404929d38dc5c98c28bd3ea1a0-3844e5e2796c13322d5df07501a83d5f79a96168c262f95a485f2b8e6122ee95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vu ha Van")]], [#link("https://terrytao.wordpress.com/2011/03/12/hamidounes-freiman-kneser-theorem-for-nonabelian-groups/#comment-50743")[#strong[#text("Vu ha Van")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2011")])]

#text("My condolences, Van.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2011/03/12/hamidounes-freiman-kneser-theorem-for-nonabelian-groups/#comment-50751")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2011")])]

#text("In the statement of Thm 1, don’t you want an ")#emph[#text("upper bound")]#text(" on the cardinality of ")#mi("H")#text("? (you actually derive one in the text). If I’m not confused, some lower bound ought to follow from the condition that ")#mi("AH")#text(" covers ")#mi("S")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of obryant")]], [#link("https://terrytao.wordpress.com/2011/03/12/hamidounes-freiman-kneser-theorem-for-nonabelian-groups/#comment-50868")[#strong[#text("obryant")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2011")])]

#text("Typo: the definition of atom should refer to fragments. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/03/12/hamidounes-freiman-kneser-theorem-for-nonabelian-groups/#comment-50897")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2011")])]

#text("Yahya Ould Hamidoune death is a big loss of the entire world.we have to wait for an other 1000 year so one like him will comeback.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/61f541debef78581a7e89dbfba07980c34a00be6e3b6e1d52b6f7652d0f52883-ae929343b95d1855e82ffaa3d4e23e2f69a7347293d77fda2fea131501196395.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sidilimam")]], [#link("https://terrytao.wordpress.com/2011/03/12/hamidounes-freiman-kneser-theorem-for-nonabelian-groups/#comment-50907")[#strong[#text("Sidilimam")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2011")])]

#text("Yahya Ould Hamidoune is a Mauritanien just as I am, and his departure from our world is a tremendous loss that can never be recompensated.")#linebreak()#text(" It is a duty on the backs of all the Mathematiciens worldwide to commemorate him along with his unforgattable scientific additions in the field.")#linebreak()#text(" May God put His mercy on him")#linebreak()#text(" Amen")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef8a778f7e7f6b120f5ebdbda11af965ee35e83bbf255355675dfd8c7c5cdb5a-07068c1a1c787c357dacb261addeffdf9e0650cf13d870638d788d6483e6d544.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiaoxi")]], [#link("https://terrytao.wordpress.com/2011/03/12/hamidounes-freiman-kneser-theorem-for-nonabelian-groups/#comment-51114")[#strong[#text("Xiaoxi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2011")])]

#text("Yesterday in Paris, a Jornee in memoiry of Yahya Ould Hamidoune was organized by his friends from Paris, Lyon and Barcelona, during which he talked about Yahya’s main contributions to math.")

#text("see the link:")

#link("http://people.math.jussieu.fr/~balandraud/YoH/YoH.html")[#text("http://people.math.jussieu.fr/~balandraud/YoH/YoH.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A variant of Kemperman’s theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/03/12/hamidounes-freiman-kneser-theorem-for-nonabelian-groups/#comment-118735")[#strong[#text("A variant of Kemperman’s theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2011")])]

#text("[…] us now prove Theorem 2. It uses a submodularity argument related to one discussed in this previous post. We fix and with , and define the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/03/12/hamidounes-freiman-kneser-theorem-for-nonabelian-groups/#comment-118742")[#strong[#text("A variant of Kemperman’s theorem | t1u")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2011")]

#text("[…] us now prove Theorem 2. It uses a submodularity argument related to one discussed in this previous post. We fix and with , and define the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ce7bb754e523f74c0803a484fdd7d315ec203cb6be1f2027fc450e50c0bf5c0-a1c8e93b75b1f9571cbdeaaf34f711157528c980867c5a95a9e4b0c52f5b8ed1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alireza Abdollahi")]], [#link("https://terrytao.wordpress.com/2011/03/12/hamidounes-freiman-kneser-theorem-for-nonabelian-groups/#comment-474274")[#strong[#text("Alireza Abdollahi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2016")])]

#text("In the statement of Theorem 1, what is $c(\\epsilon)$? is it the same as $C'(\\epsilon)$?")

#emph[#text("[Yes – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/924f619cd561509d347abb630471ab7e27da3a83a54cbd508850fb94452190f2-6d7f368d6c6e9dffd03c55a7d957de165e68f6cc09738777e6542658926fbdd0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Med-94")]], [#link("https://terrytao.wordpress.com/2011/03/12/hamidounes-freiman-kneser-theorem-for-nonabelian-groups/#comment-522966")[#strong[#text("Med-94")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("Yahya ould Hamidoun was a way more than a scientist who loved what he was doing and more than an accomplished mathmatician , he was a thinker who worked on so many things -perhaps unpublished work- and we as Mauritanians have a great loss in his departure.")#linebreak()#text(" I also admire Mr. Terence Tao for his extensive involvement in introducing other mathematicians and their work.")
]
