// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/12/17/on-the-distribution-of-eigenvalues-of-gue-and-its-minors-at-fixed-index/
// Converted to Typst by tao2typ: "2026-10-14T11:12:54.997992+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On the distribution of eigenvalues of GUE and its minors at fixed index", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On the distribution of eigenvalues of GUE and its minors at fixed index")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 December 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/12/17/on-the-distribution-of-eigenvalues-of-gue-and-its-minors-at-fixed-index/")[#text("https://terrytao.wordpress.com/2024/12/17/on-the-distribution-of-eigenvalues-of-gue-and-its-minors-at-fixed-index/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv the paper “")#link("https://arxiv.org/abs/2412.10889")[#text("On the distribution of eigenvalues of GUE and its minors at fixed index")]#text("“. This is a somewhat technical paper establishing some estimates regarding one of the most well-studied random matrix models, the Gaussian Unitary Ensemble (GUE), that were not previously in the literature, but which will be needed for some forthcoming work of ")#link("https://www.tifr.res.in/~hariharan.narayanan/")[#text("Hariharan Narayanan")]#text(" on the limiting behavior of “hives” with GUE boundary conditions (building upon our ")#link("https://terrytao.wordpress.com/2023/06/20/sums-of-gue-matrices-and-concentration-of-hives-from-correlation-decay-of-eigengaps/")[#text("previous joint work with Sheffield")]#text(").")

#text("For sake of discussion we normalize the GUE model to be the random ")#mi("{N \\times N}")#text(" Hermitian matrix ")#mi("{H}")#text(" whose probability density function is proportional to ")#mi("{e^{-\\mathrm{tr} H^2}}")#text(". With this normalization, the famous ")#emph[#text("Wigner semicircle law")]#text(" will tell us that the eigenvalues ")#mi("{\\lambda_1 \\leq \\dots \\leq \\lambda_N}")#text(" of this matrix will almost all lie in the interval ")#mi("{[-\\sqrt{2N}, \\sqrt{2N}]}")#text(", and after dividing by ")#mi("{\\sqrt{2N}}")#text(", will asymptotically be distributed according to the semicircle distribution")

#align(center)[#tao-fit-display[#mitex("\\rho_{\\mathrm{sc}}(x) := \\frac{2}{\\pi} (1-x^2)_+^{1/2}.")]]

#text("In particular, the normalized ")#mi("{i^{th}}")#text(" eigenvalue ")#mi("{\\lambda_i/\\sqrt{2N}}")#text(" should be close to the ")#emph[#text("classical location")]#text(" ")#mi("{\\gamma_{i/N}}")#text(", where ")#mi("{\\gamma_{i/N}}")#text(" is the unique element of ")#mi("{[-1,1]}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_{-\\infty}^{\\gamma_{i/N}} \\rho_{\\mathrm{sc}}(x)\\ dx = \\frac{i}{N}.")]]

#text("Eigenvalues can be described by their ")#emph[#text("index")]#text(" ")#mi("{i}")#text(" or by their (normalized) ")#emph[#text("energy")]#text(" ")#mi("{\\lambda_i/\\sqrt{2N}}")#text(". In principle, the two descriptions are related by the classical map ")#mi("{i \\mapsto \\gamma_{i/N}}")#text(" defined above, but there are microscopic fluctuations from the classical location that create subtle technical difficulties between “fixed index” results in which one focuses on a single index ")#mi("{i}")#text(" (and neighboring indices ")#mi("{i+1, i-1}")#text(", etc.), and “fixed energy” results in which one focuses on a single energy ")#mi("{x}")#text(" (and eigenvalues near this energy). The phenomenon of ")#emph[#text("eigenvalue rigidity")]#text(" does give some control on these fluctuations, allowing one to relate “averaged index” results (in which the index ")#mi("{i}")#text(" ranges over a mesoscopic range) with “averaged energy” results (in which the energy ")#mi("{x}")#text(" is similarly averaged over a mesoscopic interval), but there are technical issues in passing back from averaged control to pointwise control, either for the index or energy.")

#text("We will be mostly concerned in the ")#emph[#text("bulk region")]#text(" where the index ")#mi("{i}")#text(" is in an inteval of the form ")#mi("{[\\delta n, (1-\\delta)n]}")#text(" for some fixed ")#mi("{\\delta>0}")#text(", or equivalently the energy ")#mi("{x}")#text(" is in ")#mi("{[-1+c, 1-c]}")#text(" for some fixed ")#mi("{c > 0}")#text(". In this region it is natural to introduce the ")#emph[#text("normalized eigenvalue gaps")]

#align(center)[#tao-fit-display[#mitex("g_i := \\sqrt{N/2} \\rho_{\\mathrm{sc}}(\\gamma_{i/N}) (\\lambda_{i+1} - \\lambda_i).")]]

#text("The semicircle law predicts that these gaps ")#mi("{g_i}")#text(" have mean close to ")#mi("{1}")#text("; however, due to the aforementioned fluctuations around the classical location, this type of claim is only easy to establish in the “fixed energy”, “averaged energy”, or “averaged index” settings; the “fixed index” case was only ")#link("https://terrytao.wordpress.com/2012/03/07/the-asymptotic-distribution-of-a-single-eigenvalue-gap-of-a-wigner-matrix/")[#text("achieved by myself as recently as 2013")]#text(", where I showed that each such gap in fact asymptotically had the expected distribution of the Gaudin law, using manipulations of determinantal processes. A significantly more general result, avoiding the use of determinantal processes, was subsequently ")#link("https://zbmath.org/1333.15031")[#text("obtained by Erdos and Yau")]#text(".")

#text("However, these results left open the possibility of bad tail behavior at extremely large or small values of the gaps ")#mi("{g_i}")#text("; in particular, moments of the ")#mi("{g_i}")#text(" were not directly controlled by previous results. The first result of the paper is to push the determinantal analysis further, and obtain such results. For instance, we obtain moment bounds")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} g_i^p \\ll_p 1")]]

#text("for any fixed ")#mi("{p > 0}")#text(", as well as an exponential decay bound")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf P} (g_i > h) \\ll \\exp(-h/4)")]]

#text("for ")#mi("{0 < h \\ll \\log\\log N}")#text(", and a lower tail bound")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf P} (g_i \\leq h) \\ll h^{2/3} \\log^{1/2} \\frac{1}{h}")]]

#text("for any ")#mi("{h>0}")#text(". We also obtain good control on sums ")#mi("{g_i + \\dots + g_{i+m-1}}")#text(" of ")#mi("{m}")#text(" consecutive gaps for any fixed ")#mi("{m}")#text(", showing that this sum has mean ")#mi("{m + O(\\log^{4/3} (2+m))}")#text(" and variance ")#mi("{O(\\log^{7/3} (2+m))}")#text(". (This is significantly less variance than one would expect from a sum of ")#mi("{m}")#text(" independent random variables; this variance reduction phenomenon is closely related to the eigenvalue rigidity phenomenon alluded to earlier, and reflects the tendency of eigenvalues to repel each other.)")

#text("A key point in these estimates is that no factors of ")#mi("{\\log N}")#text(" occur in the estimates, which is what one would obtain if one tried to use existing eigenvalue rigidity theorems. (In particular, if one normalized the eigenvalues ")#mi("{\\lambda_i}")#text(" at the same scale at the gap ")#mi("{g_i}")#text(", they would fluctuate by a standard deviation of about ")#mi("{\\sqrt{\\log N}}")#text("; it is only the gaps between eigenvalues that exhibit much smaller fluctuation.) On the other hand, the dependence on ")#mi("{h}")#text(" is not optimal, although it was sufficient for the applications I had in mind.")

#text("As with my previous paper, the strategy is to try to replace fixed index events such as ")#mi("{g_i > h}")#text(" with averaged energy events. For instance, if ")#mi("{g_i > h}")#text(" and ")#mi("{i}")#text(" has classical location ")#mi("{x}")#text(", then there is an interval of normalized energies ")#mi("{t}")#text(" of length ")#mi("{\\gg h}")#text(", with the property that there are precisely ")#mi("{N-i}")#text(" eigenvalues to the right of ")#mi("{f_x(t)}")#text(" and no eigenvalues in the interval ")#mi("{[f_x(t), f_x(t+h/2)]}")#text(", where")

#align(center)[#tao-fit-display[#mitex("f_x(t) = \\sqrt{2N}( x + \\frac{t}{N \\rho_{\\mathrm{sc}}(x)})")]]

#text("is an affine rescaling to the scale of the eigenvalue gap. So matters soon reduce to controlling the probability of the event")

#align(center)[#tao-fit-display[#mitex("(N_{x,t} = N-i) \\wedge (N_{x,t,h/2} = 0)")]]

#text("where ")#mi("{N_{x,t}}")#text(" is the number of eigenvalues to the right of ")#mi("{f_x(t)}")#text(", and ")#mi("{N_{x,t,h/2}}")#text(" is the number of eigenvalues in the interval ")#mi("{[f_x(t), f_x(t+h/2)]}")#text(". These are fixed energy events, and one can use the theory of determinantal processes to control them. For instance, each of the random variables ")#mi("{N_{x,t}}")#text(", ")#mi("{N_{x,t,h/2}}")#text(" separately have the distribution of sums of independent Boolean variables, which are extremely well understood. Unfortunately, the coupling is a problem; conditioning on the event ")#mi("{N_{x,t} = N-i}")#text(", in particular, affects the distribution of ")#mi("{N_{x,t,h/2}}")#text(", so that it is no longer the sum of independent Boolean variables. However, it is still a ")#emph[#text("mixture")]#text(" of such sums, and with this (and the Plancherel-Rotach asymptotics for the GUE determinantal kernel) it is possible to proceed and obtain the above estimates after some calculation.")

#text("For the intended application to GUE hives, it is important to not just control gaps ")#mi("{g_i}")#text(" of the eigenvalues ")#mi("{\\lambda_i}")#text(" of the GUE matrix ")#mi("{M}")#text(", but also the gaps ")#mi("{g^{\\prime}_i}")#text(" of the eigenvalues ")#mi("{\\lambda^{\\prime}_i}")#text(" of the top left ")#mi("{N-1 \\times N-1}")#text(" minor ")#mi("{M^{\\prime}}")#text(" of ")#mi("{M}")#text(". This minor of a GUE matrix is basically again a GUE matrix, so the above theorem applies verbatim to the ")#mi("{g^{\\prime}_i}")#text("; but it turns out to be necessary to control the ")#emph[#text("joint")]#text(" distribution of the ")#mi("{g_i}")#text(" and ")#mi("{g^{\\prime}_i}")#text(", and also of the interlacing gaps ")#mi("{\\tilde g_i}")#text(" between the ")#mi("{\\lambda_i}")#text(" and ")#mi("{\\lambda^{\\prime}_i}")#text(". For fixed energy, these gaps are in principle well understood, due to previous work ")#link("https://arxiv.org/abs/1006.2956")[#text("of Adler-Nordenstam-van Moerbeke")]#text(" and ")#link("https://zbmath.org/1127.60047")[#text("of Johansson-Nordenstam")]#text(" which show that the spectrum of both matrices is asymptotically controlled by the Boutillier bead process. This also gives averaged energy and averaged index results without much difficulty, but to get to fixed index information, one needs some universality result in the index ")#mi("{i}")#text(". For the gaps ")#mi("{g_i}")#text(" of the original matrix, such a universality result is available due to the aforementioned work of Erdos and Yau, but this does not immediately imply the corresponding universality result for the joint distribution of ")#mi("{g_i}")#text(" and ")#mi("{g^{\\prime}_i}")#text(" or ")#mi("{\\tilde g_i}")#text(". For this, we need a way to relate the eigenvalues ")#mi("{\\lambda_i}")#text(" of the matrix ")#mi("{M}")#text(" to the eigenvalues ")#mi("{\\lambda^{\\prime}_i}")#text(" of the minors ")#mi("{M^{\\prime}}")#text(". By a standard Schur’s complement calculation, one can obtain the equation")

#align(center)[#tao-fit-display[#tao-math("a_{NN} - \\lambda_i - \\sum_{j=1}^{N-1}\\frac{\\left|X_j\\right|^2}{\\lambda^{\\prime}_j - \\lambda_i} = 0", block: true)]]

#text("for all ")#mi("{i}")#text(", where ")#mi("{a_{NN}}")#text(" is the bottom right entry of ")#mi("{M}")#text(", and ")#mi("{X_1,\\dots,X_{N-1}}")#text(" are complex gaussians independent of ")#mi("{\\lambda^{\\prime}_j}")#text(". This gives a random system of equations to solve for ")#mi("{\\lambda_i}")#text(" in terms of ")#mi("{\\lambda^{\\prime}_j}")#text(". Using the previous bounds on eigenvalue gaps (particularly the concentration results for sums of consecutive gaps), one can localize this equation to the point where a given ")#mi("{\\lambda_i}")#text(" is mostly controlled by a bounded number of nearby ")#mi("{\\lambda^{\\prime}_j}")#text(", and hence a single gap ")#mi("{g_i}")#text(" is mostly controlled by a bounded number of ")#mi("{g^{\\prime}_j}")#text(". From this, it is possible to leverage the existing universality result of Erdos and Yau to obtain universality of the joint distribution of ")#mi("{g_i}")#text(" and ")#mi("{g^{\\prime}_i}")#text(" (or of ")#mi("{\\tilde g_i}")#text("). (The result can also be extended to more layers of the minor process than just two, as long as the number of minors is held fixed.)")

#text("This at last brings us to the final result of the paper, which is the one which is actually needed for the application to GUE hives. Here, one is interested in controlling the variance of a linear combination ")#mi("{\\sum_{l=1}^m a_l \\tilde g_{i+l}}")#text(" of a fixed number ")#mi("{l}")#text(" of consecutive interlacing gaps ")#mi("{\\tilde g_{i+l}}")#text(", where the ")#mi("{a_l}")#text(" are arbitrary deterministic coefficients. An application of the triangle and Cauchy-Schwarz inequalities, combined with the previous moment bounds on gaps, shows that this randomv ariable has variance ")#tao-math("{\\ll m \\sum_{l=1}^m \\left|a_i\\right|^2}", block: false)#text(". However, this bound is not expected to be sharp, due to the expected decay between correlations of eigenvalue gaps. In this paper, I improve the variance bound to")

#align(center)[#tao-fit-display[#tao-math("\\ll_A \\frac{m}{\\log^A(2+m)} \\sum_{l=1}^m \\left|a_i\\right|^2", block: true)]]

#text("for any ")#mi("{A>0}")#text(", which is what was needed for the application.")

#text("This improvement reflects some decay in the covariances between distant interlacing gaps ")#mi("{\\tilde g_i, \\tilde g_{i+h}}")#text(". I was not able to establish such decay directly. Instead, using some Fourier analysis, one can reduce matters to studying the case of modulated linear statistics such as ")#mi("{\\sum_{l=1}^m e(\\xi l) \\tilde g_{i+l}}")#text(" for various frequencies ")#mi("{\\xi}")#text(". In “high frequency” cases one can use the triangle inequality to reduce matters to studying the original eigenvalue gaps ")#mi("{g_i}")#text(", which can be handled by a (somewhat complicated) determinantal process calculation, after first using universality results to pass from fixed index to averaged index, thence to averaged energy, then to fixed energy estimates. For low frequencies the triangle inequality argument is unfavorable, and one has to instead use the determinantal kernel of the full minor process, and not just an individual matrix. This requires some classical, but tedious, calculation of certain asymptotics of sums involving Hermite polynomials.")

#text("The full argument is unfortunately quite complex, but it seems that the combination of having to deal with minors, as well as fixed indices, places this result out of reach of many prior methods.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/17/on-the-distribution-of-eigenvalues-of-gue-and-its-minors-at-fixed-index/#comment-686922")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2024")])]

#text("(You might want to add a proper predicate into the first sentence of the post.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf8826caba1eb9c794ac1fc2344cc00ac1a7fc0bd04151a26a226c6241b0901f-d0f1e51de9d9ed994d07fc2f2707f2e12e6bc414d163826a93f9e5d69a25bdf1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of raphaelberger4f0aa1a9cc")]], [#link("https://terrytao.wordpress.com/2024/12/17/on-the-distribution-of-eigenvalues-of-gue-and-its-minors-at-fixed-index/#comment-686928")[#strong[#text("raphaelberger4f0aa1a9cc")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2024")])]

#text("I have a question most likely emerging from a very poor understanding: The eigenvalues of a unitary matrix lie on the complex unit circle. So it is not too difficult to imagine that if one takes samples from a random ensemble of unitary matrices that the eigenvalues will be kind of evenly distriubuted over this unit circle. My question is, if there is a way from this heuristics to one for the distribution of eigenvalues of an ensemble of random hermititan matrices. I assume an answer would involve decomposing the (random) hermitian matrix into unitary matrices and understanding what will happen to the eigenvalues under this decomposition.")

#text("There is also a small typo: “for smoe fixed” -> “for some fixed”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/12/17/on-the-distribution-of-eigenvalues-of-gue-and-its-minors-at-fixed-index/#comment-686934")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2024")])]

#text("Thanks for pointing out the typo!")

#text("The eigenvalues of a random unitary matrix are distributed according to the ")#link("https://en.wikipedia.org/wiki/Circular_ensemble")[#text("circular unitary ensemble")]#text(" (CUE), which do indeed share many similarities with the ")#link("https://en.wikipedia.org/wiki/Random_matrix#Gaussian_ensembles")[#text("Gaussian unitary ensemble")]#text(" (GUE) that govern the distribution of random Hermitian matrices with suitably independent and normalized gaussian entries. For instance, both ensembles exhibit a rather strong eigenvalue repulsion phenomenon, and are both governed by determinantal processes. However, the GUE has some additional features that make it more complicated than the CUE. For instance, the GUE has two edges to its spectrum, with the most extreme eigenvalues governed by the Tracy-Widom law; no such edge phenomenon exists for the CUE (circles do not have edges). So one often views the CUE as a simplified toy model of the GUE, rather than a tool to directly understand the GUE.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf8826caba1eb9c794ac1fc2344cc00ac1a7fc0bd04151a26a226c6241b0901f-d0f1e51de9d9ed994d07fc2f2707f2e12e6bc414d163826a93f9e5d69a25bdf1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of raphaelberger4f0aa1a9cc")]], [#link("https://terrytao.wordpress.com/2024/12/17/on-the-distribution-of-eigenvalues-of-gue-and-its-minors-at-fixed-index/#comment-686953")[#strong[#text("raphaelberger4f0aa1a9cc")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2024")])]

#text("Thank you very much, this is very interesting!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonimous")]], [#link("https://terrytao.wordpress.com/2024/12/17/on-the-distribution-of-eigenvalues-of-gue-and-its-minors-at-fixed-index/#comment-686933")[#strong[#text("Anonimous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2024")])]

#text("How much reference 14 (work by Nazarov) is important for the proof ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/12/17/on-the-distribution-of-eigenvalues-of-gue-and-its-minors-at-fixed-index/#comment-686935")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2024")])]

#text("Ah, that was a remnant from an older argument that is no longer needed in the current version. I will remove the reference.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/17/on-the-distribution-of-eigenvalues-of-gue-and-its-minors-at-fixed-index/#comment-686962")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2024")])]

#text("Thanks for the explanation. I am however curious why uncertainty principle may be connected to random matrix theory.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/17/on-the-distribution-of-eigenvalues-of-gue-and-its-minors-at-fixed-index/#comment-695924")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Thanks for your share！")
]
