// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/
// Converted to Typst by tao2typ: "2026-10-14T16:37:11.037247+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Computing convolutions of measures", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Computing convolutions of measures")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 July 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/")[#text("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("If ")#mi("{f: {\\bf R}^n \\rightarrow {\\bf C}}")#text(" and ")#mi("{g: {\\bf R}^n \\rightarrow {\\bf C}}")#text(" are two absolutely integrable functions on a Euclidean space ")#mi("{{\\bf R}^n}")#text(", then the ")#link("http://en.wikipedia.org/wiki/Convolution")[#text("convolution")]#text(" ")#mi("{f*g: {\\bf R}^n \\rightarrow {\\bf C}}")#text(" of the two functions is defined by the formula")

#align(center)[#tao-fit-display[#mitex("f*g(x) := \\int_{{\\bf R}^n} f(y) g(x-y)\\ dy = \\int_{{\\bf R}^n} f(x-z) g(z)\\ dz.")]]

#text("A simple application of the ")#link("http://en.wikipedia.org/wiki/Fubini_theorem")[#text("Fubini-Tonelli theorem")]#text(" shows that the convolution ")#mi("{f*g}")#text(" is well-defined almost everywhere, and yields another absolutely integrable function. In the case that ")#mi("{f=1_F}")#text(", ")#mi("{g=1_G}")#text(" are indicator functions, the convolution simplifies to ")#metadata(none) <tao-c380779f6175766fdbe9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("1_F*1_G(x) = m( F \\cap (x-G) ) = m( (x-F) \\cap G )")]]

#text("where ")#mi("{m}")#text(" denotes Lebesgue measure. One can also define convolution on more general locally compact groups than ")#mi("{{\\bf R}^n}")#text(", but we will restrict attention to the Euclidean case in this post.")

#text("The convolution ")#mi("{f*g}")#text(" can also be defined by duality by observing the identity")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} f*g(x) h(x)\\ dx = \\int_{{\\bf R}^n} \\int_{{\\bf R}^n} h(y+z)\\ f(y) dy g(z) dz")]]

#text("for any bounded measurable function ")#mi("{h: {\\bf R}^n \\rightarrow {\\bf C}}")#text(". Motivated by this observation, we may define the convolution ")#mi("{\\mu*\\nu}")#text(" of two finite ")#link("http://en.wikipedia.org/wiki/Borel_measure")[#text("Borel measures")]#text(" on ")#mi("{{\\bf R}^n}")#text(" by the formula ")#metadata(none) <tao-4ae47b2b94176a5dbcf5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\int_{{\\bf R}^n} h(x)\\ d\\mu*\\nu(x) := \\int_{{\\bf R}^n} \\int_{{\\bf R}^n} h(y+z)\\ d\\mu(y) d\\nu(z)")]]

#text("for any bounded (Borel) measurable function ")#mi("{h: {\\bf R}^n \\rightarrow {\\bf C}}")#text(", or equivalently that ")#metadata(none) <tao-0de71918a31335ca82c3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\mu*\\nu(E) = \\int_{{\\bf R}^n} \\int_{{\\bf R}^n} 1_E(y+z)\\ d\\mu(y) d\\nu(z)")]]

#text("for all Borel measurable ")#mi("{E}")#text(". (In another equivalent formulation: ")#mi("{\\mu*\\nu}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Pushforward_measure")[#text("pushforward")]#text(" of the product measure ")#mi("{\\mu \\times \\nu}")#text(" with respect to the addition map ")#mi("{+: {\\bf R}^n \\times {\\bf R}^n \\rightarrow {\\bf R}^n}")#text(".) This can easily be verified to again be a finite Borel measure.")

#text("If ")#mi("{\\mu}")#text(" and ")#mi("{\\nu}")#text(" are probability measures, then the convolution ")#mi("{\\mu*\\nu}")#text(" also has a simple probabilistic interpretation: it is the law (i.e. probability distribution) of a random varible of the form ")#mi("{X+Y}")#text(", where ")#mi("{X, Y}")#text(" are independent random variables taking values in ")#mi("{{\\bf R}^n}")#text(" with law ")#mi("{\\mu,\\nu}")#text(" respectively. Among other things, this interpretation makes it obvious that the ")#link("http://en.wikipedia.org/wiki/Support_(measure_theory)")[#text("support")]#text(" of ")#mi("{\\mu*\\nu}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Minkowski_sum")[#text("sumset")]#text(" of the supports of ")#mi("{\\mu}")#text(" (when the supports are compact; the situation is more subtle otherwise) and ")#mi("{\\nu}")#text(", and that ")#mi("{\\mu*\\nu}")#text(" will also be a probability measure.")

#text("While the above discussion gives a perfectly rigorous ")#emph[#text("definition")]#text(" of the convolution of two measures, it does not always give helpful guidance as to how to ")#emph[#text("compute")]#text(" the convolution of two explicit measures (e.g. the convolution of two surface measures on explicit examples of surfaces, such as the sphere). In simple cases, one can work from first principles directly from the definition ")#link(<tao-4ae47b2b94176a5dbcf5>)[#text("(2)")]#text(", ")#link(<tao-0de71918a31335ca82c3>)[#text("(3)")]#text(", perhaps after some application of tools from several variable calculus, such as the ")#link("http://en.wikipedia.org/wiki/Change_of_variables_formula")[#text("change of variables formula")]#text(". Another technique proceeds by regularisation, approximating the measures ")#mi("{\\mu, \\nu}")#text(" involved as the ")#link("http://en.wikipedia.org/wiki/Weak_topology")[#text("weak limit")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Vague_topology")[#text("vague limit")]#text(") of absolutely integrable functions")

#align(center)[#tao-fit-display[#mitex("\\mu = \\lim_{\\epsilon \\rightarrow 0} f_\\epsilon; \\quad \\nu =\\lim_{\\epsilon \\rightarrow 0} g_\\epsilon")]]

#text("(where we identify an absolutely integrable function ")#mi("{f}")#text(" with the associated absolutely continuous measure ")#mi("{dm_f(x) := f(x)\\ dx}")#text(") which then implies (assuming that the sequences ")#mi("{f_\\epsilon,g_\\epsilon}")#text(" are ")#link("http://en.wikipedia.org/wiki/Tightness_of_measures")[#text("tight")]#text(") that ")#mi("{\\mu*\\nu}")#text(" is the weak limit of the ")#mi("{f_\\epsilon * g_\\epsilon}")#text(". The latter convolutions ")#mi("{f_\\epsilon * g_\\epsilon}")#text(", being convolutions of functions rather than measures, can be computed (or at least estimated) by traditional integration techniques, at which point the only difficulty is to ensure that one has enough uniformity in ")#mi("{\\epsilon}")#text(" to maintain control of the limit as ")#mi("{\\epsilon \\rightarrow 0}")#text(".")

#text("A third method proceeds using the Fourier transform")

#align(center)[#tao-fit-display[#mitex("\\hat \\mu(\\xi) := \\int_{{\\bf R}^n} e^{-2\\pi i x \\cdot \\xi}\\ d\\mu(x)")]]

#text("of ")#mi("{\\mu}")#text(" (and of ")#mi("{\\nu}")#text("). We have")

#align(center)[#tao-fit-display[#mitex("\\widehat{\\mu*\\nu}(\\xi) = \\hat{\\mu}(\\xi) \\hat{\\nu}(\\xi)")]]

#text("and so one can (in principle, at least) compute ")#mi("{\\mu*\\nu}")#text(" by taking Fourier transforms, multiplying them together, and applying the (distributional) inverse Fourier transform. Heuristically, this formula implies that the Fourier transform of ")#mi("{\\mu*\\nu}")#text(" should be concentrated in the intersection of the frequency region where the Fourier transform of ")#mi("{\\mu}")#text(" is supported, and the frequency region where the Fourier transform of ")#mi("{\\nu}")#text(" is supported. As the regularity of a measure is related to decay of its Fourier transform, this also suggests that the convolution ")#mi("{\\mu*\\nu}")#text(" of two measures will typically be more regular than each of the two original measures, particularly if the Fourier transforms of ")#mi("{\\mu}")#text(" and ")#mi("{\\nu}")#text(" are concentrated in different regions of frequency space (which should happen if the measures ")#mi("{\\mu,\\nu}")#text(" are suitably “transverse”). In particular, it can happen that ")#mi("{\\mu*\\nu}")#text(" is an absolutely continuous measure, even if ")#mi("{\\mu}")#text(" and ")#mi("{\\nu}")#text(" are both singular measures.")

#text("Using intuition from ")#link("http://en.wikipedia.org/wiki/Microlocal_analysis")[#text("microlocal analysis")]#text(", we can combine our understanding of the spatial and frequency behaviour of convolution to the following heuristic: a convolution ")#mi("{\\mu*\\nu}")#text(" should be supported in regions of phase space ")#mi("{\\{ (x,\\xi): x \\in {\\bf R}^n, \\xi \\in {\\bf R}^n \\}}")#text(" of the form ")#mi("{(x,\\xi) = (x_1+x_2,\\xi)}")#text(", where ")#mi("{(x_1,\\xi)}")#text(" lies in the region of phase space where ")#mi("{\\mu}")#text(" is concentrated, and ")#mi("{(x_2,\\xi)}")#text(" lies in the region of phase space where ")#mi("{\\nu}")#text(" is concentrated. It is a challenge to make this intuition perfectly rigorous, as one has to somehow deal with the obstruction presented by the ")#link("http://en.wikipedia.org/wiki/Uncertainty_principle")[#text("Heisenberg uncertainty principle")]#text(", but it can be made rigorous in various asymptotic regimes, for instance using the machinery of ")#link("http://en.wikipedia.org/wiki/Wave_front_set")[#text("wave front sets")]#text(" (which describes the high frequency limit of the phase space distribution).")

#text("Let us illustrate these three methods and the final heuristic with a simple example. Let ")#mi("{\\mu}")#text(" be a singular measure on the horizontal unit interval ")#mi("{[0,1] \\times \\{0\\} = \\{ (x,0): 0 \\leq x \\leq 1 \\}}")#text(", given by weighting Lebesgue measure on that interval by some test function ")#mi("{\\phi: {\\bf R} \\rightarrow {\\bf C}}")#text(" supported on ")#mi("{[0,1]}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^2} f(x,y)\\ d\\mu(x,y) := \\int_{\\bf R} f(x,0) \\phi(x)\\ dx.")]]

#text("Similarly, let ")#mi("{\\nu}")#text(" be a singular measure on the vertical unit interval ")#mi("{\\{0\\} \\times [0,1] = \\{ (0,y): 0 \\leq y \\leq 1 \\}}")#text(" given by weighting Lebesgue measure on that interval by another test function ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf C}}")#text(" supported on ")#mi("{[0,1]}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^2} g(x,y)\\ d\\nu(x,y) := \\int_{\\bf R} g(0,y) \\psi(y)\\ dy.")]]

#text("We can compute the convolution ")#mi("{\\mu*\\nu}")#text(" using ")#link(<tao-4ae47b2b94176a5dbcf5>)[#text("(2)")]#text(", which in this case becomes")

#tao-aligned(keep: true)[


#tao-math("\\int_{{\\bf R}^2} h( x, y ) d\\mu*\\nu(x,y)  & = \\int_{{\\bf R}^2} \\int_{{\\bf R}^2} h(x_1+x_2, y_1+y_2)\\ d\\mu(x_1,y_1) d\\nu(x_2,y_2)", block: true)



#tao-math(" & = \\int_{\\bf R} \\int_{\\bf R} h( x_1, y_2 )\\ \\phi(x_1) dx_1 \\psi(y_2) dy_2", block: true)
]

#text("and we thus conclude that ")#mi("{\\mu*\\nu}")#text(" is an absolutely continuous measure on ")#mi("{{\\bf R}^2}")#text(" with density function ")#mi("{(x,y) \\mapsto \\phi(x) \\psi(y)}")#text(": ")#metadata(none) <tao-bfd02a383c54184530cb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("d(\\mu*\\nu)(x,y) = \\phi(x) \\psi(y) dx dy.")]]

#text("In particular, ")#mi("{\\mu*\\nu}")#text(" is supported on the unit square ")#mi("{[0,1]^2}")#text(", which is of course the sumset of the two intervals ")#mi("{[0,1] \\times\\{0\\}}")#text(" and ")#mi("{\\{0\\} \\times [0,1]}")#text(".")

#text("We can arrive at the same conclusion from the regularisation method; the computations become lengthier, but more geometric in nature, and emphasises the role of transversality between the two segments supporting ")#mi("{\\mu}")#text(" and ")#mi("{\\nu}")#text(". One can view ")#mi("{\\mu}")#text(" as the weak limit of the functions")

#align(center)[#tao-fit-display[#mitex("f_\\epsilon(x,y) := \\frac{1}{\\epsilon} \\phi(x) 1_{[0,\\epsilon]}(y)")]]

#text("as ")#mi("{\\epsilon \\rightarrow 0}")#text(" (where we continue to identify absolutely integrable functions with absolutely continuous measures, and of course we keep ")#mi("{\\epsilon}")#text(" positive). We can similarly view ")#mi("{\\nu}")#text(" as the weak limit of")

#align(center)[#tao-fit-display[#mitex("g_\\epsilon(x,y) := \\frac{1}{\\epsilon} 1_{[0,\\epsilon]}(x) \\psi(y).")]]

#text("Let us first look at the model case when ")#mi("{\\phi=\\psi=1_{[0,1]}}")#text(", so that ")#mi("{f_\\epsilon,g_\\epsilon}")#text(" are renormalised indicator functions of thin rectangles:")

#align(center)[#tao-fit-display[#mitex("f_\\epsilon = \\frac{1}{\\epsilon} 1_{[0,1]\\times [0,\\epsilon]}; \\quad g_\\epsilon = \\frac{1}{\\epsilon} 1_{[0,\\epsilon] \\times [0,1]}.")]]

#text("By ")#link(<tao-c380779f6175766fdbe9>)[#text("(1)")]#text(", the convolution ")#mi("{f_\\epsilon*g_\\epsilon}")#text(" is then given by")

#align(center)[#tao-fit-display[#mitex("f_\\epsilon*g_\\epsilon(x,y) := \\frac{1}{\\epsilon^2} m( E_\\epsilon )")]]

#text("where ")#mi("{E_\\epsilon}")#text(" is the intersection of two rectangles:")

#align(center)[#tao-fit-display[#mitex("E_\\epsilon := ([0,1] \\times [0,\\epsilon]) \\cap ((x,y) - [0,\\epsilon] \\times [0,1]).")]]

#text("When ")#mi("{(x,y)}")#text(" lies in the square ")#mi("{[\\epsilon,1] \\times [\\epsilon,1]}")#text(", one readily sees (especially if one draws a picture) that ")#mi("{E_\\epsilon}")#text(" consists of an ")#mi("{\\epsilon \\times \\epsilon}")#text(" square and thus has measure ")#mi("{\\epsilon^2}")#text("; conversely, if ")#mi("{(x,y)}")#text(" lies outside ")#mi("{[0,1+\\epsilon] \\times [0,1+\\epsilon]}")#text(", ")#mi("{E_\\epsilon}")#text(" is empty and thus has measure zero. In the intermediate region, ")#mi("{E_\\epsilon}")#text(" will have some measure between ")#mi("{0}")#text(" and ")#mi("{\\epsilon^2}")#text(". From this we see that ")#mi("{f_\\epsilon*g_\\epsilon}")#text(" converges pointwise almost everywhere to ")#mi("{1_{[0,1] \\times [0,1]}}")#text(" while also being dominated by an absolutely integrable function, and so converges weakly to ")#mi("{1_{[0,1] \\times [0,1]}}")#text(", giving a special case of the formula ")#link(<tao-bfd02a383c54184530cb>)[#text("(4)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Use a similar method to verify ")#link(<tao-bfd02a383c54184530cb>)[#text("(4)")]#text(" in the case that ")#mi("{\\phi, \\psi}")#text(" are continuous functions on ")#mi("{[0,1]}")#text(". (The argument also works for absolutely integrable ")#mi("{\\phi,\\psi}")#text(", but one needs to invoke the ")#link("http://en.wikipedia.org/wiki/Lebesgue_differentiation_theorem")[#text("Lebesgue differentiation theorem")]#text(" to make it run smoothly.)")
]

#text("Now we compute with the Fourier-analytic method. The Fourier transform ")#mi("{\\hat \\mu(\\xi,\\eta)}")#text(" of ")#mi("{\\mu}")#text(" is given by")

#tao-aligned(keep: true)[


#tao-math("\\hat \\mu(\\xi,\\eta)  & =\\int_{{\\bf R}^2} e^{-2\\pi i (x \\xi + y \\eta)}\\ d\\mu(x,y)", block: true)



#tao-math(" & = \\int_{\\bf R} \\phi(x) e^{-2\\pi i x \\xi}\\ dx", block: true)



#tao-math(" & = \\hat \\phi(\\xi)", block: true)
]

#text("where we abuse notation slightly by using ")#mi("{\\hat \\phi}")#text(" to refer to the one-dimensional Fourier transform of ")#mi("{\\phi}")#text(". In particular, ")#mi("{\\hat \\mu}")#text(" decays in the ")#mi("{\\xi}")#text(" direction (by the Riemann-Lebesgue lemma) but has no decay in the ")#mi("{\\eta}")#text(" direction, which reflects the horizontally grained structure of ")#mi("{\\mu}")#text(". Similarly we have")

#align(center)[#tao-fit-display[#mitex("\\hat \\nu(\\xi,\\eta) = \\hat \\psi(\\eta),")]]

#text("so that ")#mi("{\\hat \\nu}")#text(" decays in the ")#mi("{\\eta}")#text(" direction. The convolution ")#mi("{\\mu*\\nu}")#text(" then has decay in both the ")#mi("{\\xi}")#text(" and ")#mi("{\\eta}")#text(" directions,")

#align(center)[#tao-fit-display[#mitex("\\widehat{\\mu*\\nu}(\\xi,\\eta) = \\hat \\phi(\\xi) \\hat \\psi(\\eta)")]]

#text("and by inverting the Fourier transform we obtain ")#link(<tao-bfd02a383c54184530cb>)[#text("(4)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Let ")#mi("{AB}")#text(" and ")#mi("{CD}")#text(" be two non-parallel line segments in the plane ")#mi("{{\\bf R}^2}")#text(". If ")#mi("{\\mu}")#text(" is the uniform probability measure on ")#mi("{AB}")#text(" and ")#mi("{\\nu}")#text(" is the uniform probability measure on ")#mi("{CD}")#text(", show that ")#mi("{\\mu*\\nu}")#text(" is the uniform probability measure on the parallelogram ")#mi("{AB + CD}")#text(" with vertices ")#mi("{A+C, A+D, B+C, B+D}")#text(". What happens in the degenerate case when ")#mi("{AB}")#text(" and ")#mi("{CD}")#text(" are parallel?")
]

#text("Finally, we compare the above answers with what one gets from the microlocal analysis heuristic. The measure ")#mi("{\\mu}")#text(" is supported on the horizontal interval ")#mi("{[0,1] \\times \\{0\\}}")#text(", and the cotangent bundle at any point on this interval points in the vertical direction. Thus, the wave front set of ")#mi("{\\mu}")#text(" should be supported on those points ")#mi("{((x_1,x_2),(\\xi_1,\\xi_2))}")#text(" in phase space with ")#mi("{x_1 \\in [0,1]}")#text(", ")#mi("{x_2 = 0}")#text(" and ")#mi("{\\xi_1=0}")#text(". Similarly, the wave front set of ")#mi("{\\nu}")#text(" should be supported at those points ")#mi("{((y_1,y_2),(\\xi_1,\\xi_2))}")#text(" with ")#mi("{y_1 = 0}")#text(", ")#mi("{y_2 \\in [0,1]}")#text(", and ")#mi("{\\xi_2=0}")#text(". The convolution ")#mi("{\\mu * \\nu}")#text(" should then have wave front set supported on those points ")#mi("{((x_1+y_1,x_2+y_2), (\\xi_1,\\xi_2))}")#text(" with ")#mi("{x_1 \\in [0,1]}")#text(", ")#mi("{x_2 = 0}")#text(", ")#mi("{\\xi_1=0}")#text(", ")#mi("{y_1=0}")#text(", ")#mi("{y_2 \\in [0,1]}")#text(", and ")#mi("{\\xi_2=0}")#text(", i.e. it should be spatially supported on the unit square and have zero (rescaled) frequency, so the heuristic predicts a smooth function on the unit square, which is indeed what happens. (The situation is slightly more complicated in the non-smooth case ")#mi("{\\phi=\\psi=1_{[0,1]}}")#text(", because ")#mi("{\\mu}")#text(" and ")#mi("{\\nu}")#text(" then acquire some additional singularities at the endpoints; namely, the wave front set of ")#mi("{\\mu}")#text(" now also contains those points ")#mi("{((x_1,x_2),(\\xi_1,\\xi_2))}")#text(" with ")#mi("{x_1 \\in \\{0,1\\}}")#text(", ")#mi("{x_2=0}")#text(", and ")#mi("{\\xi_1,\\xi_2}")#text(" arbitrary, and ")#mi("{\\nu}")#text(" similarly contains those points ")#mi("{((y_1,y_2), (\\xi_1,\\xi_2))}")#text(" with ")#mi("{y_1=0}")#text(", ")#mi("{y_2 \\in \\{0,1\\}}")#text(", and ")#mi("{\\xi_1,\\xi_2}")#text(" arbitrary. I’ll leave it as an exercise to the reader to compute what this predicts for the wave front set of ")#mi("{\\mu*\\nu}")#text(", and how this compares with the actual wave front set.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Let ")#mi("{\\mu}")#text(" be the uniform measure on the unit sphere ")#mi("{S^{n-1}}")#text(" in ")#mi("{{\\bf R}^n}")#text(" for some ")#mi("{n \\geq 2}")#text(". Use as many of the above methods as possible to establish multiple proofs of the following fact: the convolution ")#mi("{\\mu*\\mu}")#text(" is an absolutely continuous multiple ")#mi("{f(x)\\ dx}")#text(" of Lebesgue measure, with ")#mi("{f(x)}")#text(" supported on the ball ")#mi("{B(0,2)}")#text(" of radius ")#mi("{2}")#text(" and obeying the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x)\\right| \\ll \\frac{1}{\\left|x\\right|}", block: true)]]

#text("for ")#tao-math("{\\left|x\\right| \\leq 1}", block: false)#text(" and")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x)\\right| \\ll (2-\\left|x\\right|)^{(n-3)/2}", block: true)]]

#text("for ")#tao-math("{1 \\leq \\left|x\\right| \\leq 2}", block: false)#text(", where the implied constants are allowed to depend on the dimension ")#mi("{n}")#text(". (")#emph[#text("Hint:")]#text(" try the ")#mi("{n=2}")#text(" case first, which is particularly simple due to the fact that the addition map ")#mi("{+: S^1 \\times S^1 \\rightarrow {\\bf R}^2}")#text(" is mostly a local diffeomorphism. The Fourier-based approach is instructive, but requires either asymptotics of Bessel functions or the principle of stationary phase.)")
]

#heading(level: 1)[#text("Comments (24)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-239795")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2013")])]

#text("Missing sentence perhaps, after")

#text("This can easily be verified to again be a finite Borel measure. As")

#emph[#text("[Sorry, that sentence fragment has now been deleted. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a6351b8ac7aaaf1226949432cb775f977c07e0da0338f15b40ab464bfaa5b15c-b8faa30f60ad996e03e225c56fee47f31cf1f4df586a575cda27acb2fd46e63d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alok Tiwari")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-239820")[#strong[#text("Alok Tiwari")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2013")])]

#text("Is there a typo in equation 1?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27e8412f888c569a9be1ea171fca277001b3529b40fd5b744477630ab233b68c-05bad328c0ff3a76596d1574691a67abec98c1884bc3f88e4c852126de63b9c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mircea")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-239836")[#strong[#text("mircea")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2013")])]

#text("If you utilize exterior product then you can extend formula (3) also to currents; the other ideas also nicely extend to this, plus you get a nice geometric operation. This is a way of producing new submanifolds, e.g. the Windows symbol (as an oriented submanifold) is the “convolution” of the two curves dividing it in 4. Also, e.g. for an oriented circle C in R² the convolution of C with itself is zero.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ff39422bba87564dc362dba86346d189c9f13ca60591c0da8772f2d6a73db39-476ea7aed1980e9919a56099f0ba871fd83e9da2e7284c64684097196a1c55a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of omar aboura")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-239847")[#strong[#text("omar aboura")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2013")])]

#text("In “Another technique proceeds by reularisation, …” reularisation should be regularisation.")

#text("In “…given by weighting Lebesgue masure…” masure should be measure.")

#text("In the equation after “We can compute the convolution {\\mu*\\nu} using (2), which in this case becomes”, \\int_{{\\bf R}^n} should be \\int_{{\\bf R}^2}.")

#text("In “…the actual waave front set” waave should be wave.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-239860")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2013")])]

#text("In the paragraph beginning with")#linebreak()#text(" “A third method proceeds using the Fourier transform…”")#linebreak()#text(" should the integration variable be x in the definition of Fourier transform of measure mu?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-239861")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2013")])]

#text("* The object you’ve described in Exercise 2 is the ")#link("http://en.wikipedia.org/wiki/Minkowski_addition")[#text("Minkowski Sum")]#text(" of two line segments in the plane. I know what that is. You offer ")#strike[#text("three")]#text(" 4 different ways to work out the problem.")

#text("If I remember correctly, you can approximate measures as linear combinations of step functions (… dusting off analysis notes …) So you’re defining a measure version of Minkowski addition")#strong[#text("?")]#text(" I need to draw pictures.")

#text("* Using the identity: ")#mi("\\int e^{2\\pi i \\xi x} \\; d\\xi = \\delta(x)")#text(" we see that a point measure is infinitely spread out in space. That’s definitely one way of expressing wave-particle duality. ")#link("http://en.wikipedia.org/wiki/Wave_packet")[#text("Wavepackets")]#text(" are a compromise, kind-of localized in space and kind-of localized in time.")

#text("In Ex 2, you seem to be describing a “quantum line segment” localized along a line, or even a “quantum parallelogram”. I wonder now what these shapes look like in momentum space?")

#text("* Naively, I picture the wave-front as a bunch of circle emanating from the point with increasing radius. I am having trouble reconciling Hormander’s definition ")#mi("WF(f) = \\{(x,\\xi)\\in T^*X: \\xi \\in \\Sigma_x(f)   \\}")#text(" with the mental image given from ")#link("http://en.wikipedia.org/wiki/Wavefront")[#text("optics")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b7e7e8ac4ff15f3c57a19cce156b32adf16045492076a55f1ca820a918687b00-84297b321d443d2fe29cd137930857f66e90c7b6e9903c5f7cb66330948410bc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edgar's Creative")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-239863")[#strong[#text("Edgar's Creative")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2013")])]

#text("Reblogged this on ")#link("http://edgarventurescreative.wordpress.com/2013/07/27/computing-convolutions-of-measures/")[#text("Edgar's Creative")]#text(" and commented:")#linebreak()#text(" Another brilliant take by Terry Tao on an important Mathematical subject. Breathtaking!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/425e9af440224f70b2fdf2ee6db0b25fa530d49b4abcefba86b2ac9a5c18ff6b-47fc0714a2a9f66e1a077dce6ad71eceabeab9c306a959e880a9194e3340d86f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kamran Alam Khan")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-239928")[#strong[#text("Kamran Alam Khan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2013")])]

#text("Reblogged this on ")#link("http://kamranrmp.wordpress.com/2013/07/28/computing-convolutions-of-measures/")[#text("Observer")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/425e9af440224f70b2fdf2ee6db0b25fa530d49b4abcefba86b2ac9a5c18ff6b-47fc0714a2a9f66e1a077dce6ad71eceabeab9c306a959e880a9194e3340d86f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kamran Alam Khan")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-240210")[#strong[#text("Kamran Alam Khan")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2013")])]

#text("Reblogged this on ")#link("http://kamranrmp.wordpress.com/2013/07/30/computing-convolutions-of-measures-2/")[#text("Observer")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cb3280d4a3ac59b59c4cf2c33043f35c9d5c9f277083c51cc4b2e3163aa25a7-6a9cd9f58b7183b2038ce7a394dc5461cc80a5a1b8a2711b65195916592b725c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo de Almeida")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-240833")[#strong[#text("Marcelo de Almeida")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2013")])]

#text("Reblogged this on ")#link("http://nucaltiado.wordpress.com/2013/08/05/computing-convolutions-of-measures/")[#text("Being simple")]#text(" and commented:")#linebreak()#text(" About Bessel functions and other special functions, I suggest the well-known online book DLMF: ")#link("http://dlmf.nist.gov/10")[#text("http://dlmf.nist.gov/10")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-240842")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2013")])]

#text("This online updated version of the original A&S is very useful indeed! (for example, Auluck’s formula – used in the upper bound for ")#mi("\\kappa_3")#text(" – appears as formula 10.22.5 in DLMF , but not in the original A&S !)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cb3280d4a3ac59b59c4cf2c33043f35c9d5c9f277083c51cc4b2e3163aa25a7-6a9cd9f58b7183b2038ce7a394dc5461cc80a5a1b8a2711b65195916592b725c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo de Almeida")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-240850")[#strong[#text("Marcelo de Almeida")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2013")])]

#text("This online book is/was very important to me.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-464844")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2016")])]

#text("What is the “surface measure” in this note? I read throughout your math 245abc notes but I don’t see this concept.")

#emph[#text("[Surface measure on a k-dimensional manifold is the restriction of k-dimensional Hausdorff measure to that manifold. It can also be defined locally using a local parameterisation of the manifold as the pushforward of k-dimensional Lebesgue measure, multiplied by an appropriate Jacobian factor; see Exercise 12 of ")#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/")[#text("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/")]#text(" . A third definition is to take Lebesgue measure restricted to an ")#mi("\\varepsilon")#text("-neighbourhood of the manifold, normalise by ")#mi("\\varepsilon^{n-k}")#text(", and take weak limits. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4db85f45e3b423cfba479b62f4ae6bc65554e70a42e435f5d0ce9707e089e0d5-28b2e7e7bea23a181a13feb8b2bfa943ed870dbece83d9e2389586afd57510d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abraham")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-477291")[#strong[#text("Abraham")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2017")])]

#text("Can anyone point me to a reference/textbook that shows that the support of the convolution of two probability measures, f \\ast g, defined on uncountable sample spaces is the sumset of the support of the individual measures? I can only find results of the form supp{ f\\ast g} \\subseteq supp{f} \\oplus supp{g}. I can see how it follows when the sample space is countable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-477318")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2017")])]

#text("Use the inequality ")#mi("f \\ast g( B(x+y,r+s) ) \\geq f(B(x,r)) g(B(y,s))")#text(" for any two balls ")#mi("B(x,r), B(y,s)")#text(", and the fact that ")#mi("f(B(x,r)) > 0")#text(" whenever ")#mi("x")#text(" is in the support of ")#mi("f")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-482611")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2017")])]

#text("Would you elaborate what you mean by “The convolution ")#mi("{f*g}")#text(" can also be defined by duality…” ? What is the duality here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-483059")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2017")])]

#text("A locally integrable function ")#mi("F")#text(" (or more generally, a measure or a distribution) can be defined (up to almost everywhere equivalence) by specifying its inner products ")#mi("\\int F g")#text(" against a suitable class of test functions ")#mi("g")#text(" in a predual space. (In some cases, a representation theorem, such as the Riesz representation theorem, may need to be invoked in order to guarantee that ")#mi("F")#text(" actually exists.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-497529")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2018")])]

#text("In Folland’s Real Analysis, it is said that if ")#mi("A")#text(" is the “closure” of ")#mi("\\{ x + y : x \\in supp(f), y \\in supp(g) \\}")#text(", then ")#mi("supp(f *g) \\subset A")#text(". But in Wolff’s harmonic analysis lecture notes, the author states that")

#mi("\\displaystyle supp(\\phi*f)\\subset supp(\\phi)+supp(f)")#linebreak()#text(" where the “closure” is not used. Which version is correct?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-497530")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2018")])]

#text("The answer depends on the definition of support (set-theoretic support, topological support, or essential support). But for compactly supported functions both inclusions hold for all notions of support.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-497575")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2018")])]

#text("Presumably, there is a default version for an analyst when the definition is not given explicitly (e.g. I don’t see which definition is used in this post)? Folland does states explicitly that the support of ")#mi("f:{\\bf R}^d\\to{\\bf R}")#text(" is defined topologically as the closure of the subset of ")#mi("X")#text(" where ")#mi("f")#text(" is non-zero. Wolff did not give the definition but restricted the discussion mostly in the Euclidean space in his notes and when he wrote")#linebreak()#text(" ")#mi("\\displaystyle \\text{supp}(\\phi*f)\\subset \\text{supp}(\\phi)+supp(f),")#linebreak()#text(" functions do not need to have compact support.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-497591")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2018")])]

#text("If you keep reading Wolff’s notes until the point where the concept of support is actually used, you should be able to determine from that context what the intended definition of support is, and whether the closure operation was implicitly omitted. (See also my ")#link("https://plus.google.com/u/0/+TerenceTao27/posts/TGjjJPUdJjk")[#text("general advice")]#text(" on how to read mathematical texts without “crashing” due to “compilation errors”.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed576e75b1d808a468944c73139ae1cb839a572c94edf0eb48d700ecab39efab-0651c0b56c2e435805228ca11fcdd43c1247d1d085a9d2ec5ac117028e36c80f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joaquin")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-507371")[#strong[#text("Joaquin")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2018")])]

#text("Insignificant typo in the Fourier transform of mu. Integration variable must be x.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/56f289e9808e48320ceeb95df9082997fd24673523fcd310015424af4ba4c6ce-6d040766ed9c463f2d644d3ff5615ac29406a9d73b1906ea07ebd8a680eeebc1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Iosevich")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-518076")[#strong[#text("Alex Iosevich")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2019")])]

#text("The bound in Exercise 3 (for dimensions three and higher) appears to depend only on non-vanishing curvature. At least for the small |x| bound, smoothness does not appear to play any role (beyond what is needed to define curvature).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/26/computing-convolutions-of-measures/#comment-657392")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2022")])]

#text("Dr. Tao: For the identity between equation (1) and (2), i.e. ")#mi("\\int f\\ast g(x)h(x)dx = ...")#text(", you mentioned that the convolution ")#mi("f\\ast g")#text(" can be defined by duality using this identity. I can verify that the identity is true by direct computation, but not sure of what you mean by “duality”.")

#emph[#text("[By the Riesz representation theorem, specifying the inner products of (say) an ")#mi("L^2")#text(" function ")#mi("f \\ast g")#text(" with every test function $h$ is sufficient information to uniquely describe ")#mi("f \\ast g")#text(". -T]")]
]
