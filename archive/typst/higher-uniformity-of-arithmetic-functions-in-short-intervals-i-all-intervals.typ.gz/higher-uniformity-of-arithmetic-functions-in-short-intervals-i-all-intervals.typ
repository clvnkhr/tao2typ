// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/04/10/higher-uniformity-of-arithmetic-functions-in-short-intervals-i-all-intervals/
// Converted to Typst by tao2typ: "2026-10-14T11:06:36.278636+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Higher uniformity of arithmetic functions in short intervals I. All intervals", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Higher uniformity of arithmetic functions in short intervals I. All intervals")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 April 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/04/10/higher-uniformity-of-arithmetic-functions-in-short-intervals-i-all-intervals/")[#text("https://terrytao.wordpress.com/2022/04/10/higher-uniformity-of-arithmetic-functions-in-short-intervals-i-all-intervals/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://users.utu.fi/ksmato/")[#text("Kaisa Matomäki")]#text(", ")#link("https://math.as.uky.edu/users/xsh228")[#text("Xuancheng Shao")]#text(", ")#link("https://sites.google.com/view/joniteravainen/")[#text("Joni Teräväinen")]#text(", and myself have just uploaded to the arXiv our preprint “")#link("http://arxiv.org/abs/2204.03754")[#text("Higher uniformity of arithmetic functions in short intervals I. All intervals")]#text("“. This paper investigates the higher order (Gowers) uniformity of standard arithmetic functions in analytic number theory (and specifically, the ")#link("https://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(" ")#mi("{\\mu}")#text(", the ")#link("https://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(" ")#mi("{\\Lambda}")#text(", and the ")#link("https://en.wikipedia.org/wiki/Divisor_function")[#text("generalised divisor functions")]#text(" ")#mi("{d_k}")#text(") in short intervals ")#mi("{(X,X+H]}")#text(", where ")#mi("{X}")#text(" is large and ")#mi("{H}")#text(" lies in the range ")#mi("{X^{\\theta+\\varepsilon} \\leq H \\leq X^{1-\\varepsilon}}")#text(" for a fixed constant ")#mi("{0 < \\theta < 1}")#text(" (that one would like to be as small as possible). If we let ")#mi("{f}")#text(" denote one of the functions ")#mi("{\\mu, \\Lambda, d_k}")#text(", then there is extensive literature on the estimation of short sums")

#align(center)[#tao-fit-display[#mitex("\\sum_{X < n \\leq X+H} f(n)")]]

#text("and some literature also on the estimation of exponential sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{X < n \\leq X+H} f(n) e(-\\alpha n)")]]

#text("for a real frequency ")#mi("{\\alpha}")#text(", where ")#mi("{e(\\theta) := e^{2\\pi i \\theta}}")#text(". For applications in the additive combinatorics of such functions ")#mi("{f}")#text(", it is also necessary to consider more general correlations, such as polynomial correlations")

#align(center)[#tao-fit-display[#mitex("\\sum_{X < n \\leq X+H} f(n) e(-P(n))")]]

#text("where ")#mi("{P: {\\bf Z} \\rightarrow {\\bf R}}")#text(" is a polynomial of some fixed degree, or more generally")

#align(center)[#tao-fit-display[#mitex("\\sum_{X < n \\leq X+H} f(n) \\overline{F}(g(n) \\Gamma)")]]

#text("where ")#mi("{G/\\Gamma}")#text(" is a nilmanifold of fixed degree and dimension (and with some control on structure constants), ")#mi("{g: {\\bf Z} \\rightarrow G}")#text(" is a polynomial map, and ")#mi("{F: G/\\Gamma \\rightarrow {\\bf C}}")#text(" is a Lipschitz function (with some bound on the Lipschitz constant). Indeed, thanks to the inverse theorem for the Gowers uniformity norm, such correlations let one control the Gowers uniformity norm of ")#mi("{f}")#text(" (possibly after subtracting off some renormalising factor) on such short intervals ")#mi("{(X,X+H]}")#text(", which can in turn be used to control other multilinear correlations involving such functions.")

#text("Traditionally, asymptotics for such sums are expressed in terms of a “main term” of some arithmetic nature, plus an error term that is estimated in magnitude. For instance, a sum such as ")#mi("{\\sum_{X < n \\leq X+H} \\Lambda(n) e(-\\alpha n)}")#text(" would be approximated in terms of a main term that vanished (or is negligible) if ")#mi("{\\alpha}")#text(" is “minor arc”, but would be expressible in terms of something like a ")#link("https://en.wikipedia.org/wiki/Ramanujan%27s_sum")[#text("Ramanujan sum")]#text(" if ")#mi("{\\alpha}")#text(" was “major arc”, together with an error term. We found it convenient to cancel off such main terms by subtracting an ")#emph[#text("approximant")]#text(" ")#mi("{f^\\sharp}")#text(" from each of the arithmetic functions ")#mi("{f}")#text(" and then getting upper bounds on remainder correlations such as ")#metadata(none) <tao-ab88ea80fdee69b28b0f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|\\sum_{X < n \\leq X+H} (f(n)-f^\\sharp(n)) \\overline{F}(g(n) \\Gamma)\\right|", block: true)]]

#text(" ")#text(" (actually for technical reasons we also allow the ")#mi("{n}")#text(" variable to be restricted further to a subprogression of ")#mi("{(X,X+H]}")#text(", but let us ignore this minor extension for this discussion). There is some flexibility in how to choose these approximants, but we eventually found it convenient to use the following choices.")

#list(
[#text("For the Möbius function ")#mi("{\\mu}")#text(", we simply set ")#mi("{\\mu^\\sharp = 0}")#text(", as per the Möbius pseudorandomness conjecture. (One could choose a more sophisticated approximant in the presence of a Siegel zero, as I did with Joni in ")#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/")[#text("this recent paper")]#text(", but we do not do so here.)")],
[#text("For the von Mangoldt function ")#mi("{\\Lambda}")#text(", we eventually went with the Cramér-Granville approximant ")#mi("{\\Lambda^\\sharp(n) = \\frac{W}{\\phi(W)} 1_{(n,W)=1}}")#text(", where ")#mi("{W = \\prod_{p < R} p}")#text(" and ")#mi("{R = \\exp(\\log^{1/10} X)}")#text(".")],
[#text("For the divisor functions ")#mi("{d_k}")#text(", we used a somewhat complicated-looking approximant ")#mi("{d_k^\\sharp(n) = \\sum_{m \\leq X^{\\frac{k-1}{5k}}} P_m(\\log n)}")#text(" for some explicit polynomials ")#mi("{P_m}")#text(", chosen so that ")#mi("{d_k^\\sharp}")#text(" and ")#mi("{d_k}")#text(" have almost exactly the same sums along arithmetic progressions (see the paper for details).")]
)

#text("The objective is then to obtain bounds on sums such as ")#link(<tao-ab88ea80fdee69b28b0f>)[#text("(1)")]#text(" that improve upon the “trivial bound” that one can get with the triangle inequality and standard number theory bounds such as the ")#link("https://en.wikipedia.org/wiki/Brun%E2%80%93Titchmarsh_theorem")[#text("Brun-Titchmarsh inequality")]#text(". For ")#mi("{\\mu}")#text(" and ")#mi("{\\Lambda}")#text(", the ")#link("https://en.wikipedia.org/wiki/Siegel%E2%80%93Walfisz_theorem")[#text("Siegel-Walfisz theorem")]#text(" suggests that it is reasonable to expect error terms that have “strongly logarithmic savings” in the sense that they gain a factor of ")#mi("{O_A(\\log^{-A} X)}")#text(" over the trivial bound for any ")#mi("{A>0}")#text("; for ")#mi("{d_k}")#text(", the ")#link("https://en.wikipedia.org/wiki/Dirichlet_hyperbola_method")[#text("Dirichlet hyperbola method")]#text(" suggests instead that one has “power savings” in that one should gain a factor of ")#mi("{X^{-c_k}}")#text(" over the trivial bound for some ")#mi("{c_k>0}")#text(". In the case of the Möbius function ")#mi("{\\mu}")#text(", there is an additional trick (introduced ")#link("https://arxiv.org/abs/1911.09076")[#text("by Matomäki and Teräväinen")]#text(") that allows one to lower the exponent ")#mi("{\\theta}")#text(" somewhat at the cost of only obtaining “weakly logarithmic savings” of shape ")#mi("{\\log^{-c} X}")#text(" for some small ")#mi("{c>0}")#text(".")

#text("Our main estimates on sums of the form ")#link(<tao-ab88ea80fdee69b28b0f>)[#text("(1)")]#text(" work in the following ranges:")

#list(
[#text("For ")#mi("{\\theta=5/8}")#text(", one can obtain strongly logarithmic savings on ")#link(<tao-ab88ea80fdee69b28b0f>)[#text("(1)")]#text(" for ")#mi("{f=\\mu,\\Lambda}")#text(", and power savings for ")#mi("{f=d_k}")#text(".")],
[#text("For ")#mi("{\\theta=3/5}")#text(", one can obtain weakly logarithmic savings for ")#mi("{f = \\mu, d_k}")#text(".")],
[#text("For ")#mi("{\\theta=5/9}")#text(", one can obtain power savings for ")#mi("{f=d_3}")#text(".")],
[#text("For ")#mi("{\\theta=1/3}")#text(", one can obtain power savings for ")#mi("{f=d_2}")#text(".")]
)

#text("Conjecturally, one should be able to obtain power savings in all cases, and lower ")#mi("{\\theta}")#text(" down to zero, but the ranges of exponents and savings given here seem to be the limit of current methods unless one assumes additional hypotheses, such as GRH. The ")#mi("{\\theta=5/8}")#text(" result for correlation against Fourier phases ")#mi("{e(\\alpha n)}")#text(" was established ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1141240")[#text("previously by Zhan")]#text(", and the ")#mi("{\\theta=3/5}")#text(" result for such phases and ")#mi("{f=\\mu}")#text(" was established previously by ")#link("https://arxiv.org/abs/1911.09076")[#text("by Matomäki and Teräväinen")]#text(".")

#text("By combining these results with tools from additive combinatorics, one can obtain a number of applications:")

#list(
[#text("Direct insertion of our bounds in the ")#link("https://arxiv.org/abs/2004.01125")[#text("recent work of Kanigowski, Lemanczyk, and Radziwill")]#text(" on the prime number theorem on dynamical systems that are analytic skew products gives some improvements in the exponents there.")],
[#text("We can obtain a “short interval” version of a multiple ergodic theorem along primes established ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2361086")[#text("by Frantzikinakis-Host-Kra")]#text(" and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2999293")[#text("Wooley-Ziegler")]#text(", in which we average over intervals of the form ")#mi("{(X,X+H]}")#text(" rather than ")#mi("{[1,X]}")#text(".")],
[#text("We can obtain a “short interval” version of the “linear equations in primes” asymptotics obtained by Ben Green, Tamar Ziegler, and myself in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2680398")[#text("this")]#text(" ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2877066")[#text("sequence")]#text(" ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2950773")[#text("of papers")]#text(", where the variables in these equations lie in short intervals ")#mi("{(X,X+H]}")#text(" rather than long intervals such as ")#mi("{[1,X]}")#text(".")]
)

#text("We now briefly discuss some of the ingredients of proof of our main results. The first step is standard, using combinatorial decompositions (based on the Heath-Brown identity and (for the ")#mi("{\\theta=3/5}")#text(" result) the Ramaré identity) to decompose ")#mi("{\\mu(n), \\Lambda(n), d_k(n)}")#text(" into more tractable sums of the following types:")

#list(
[#emph[#text("Type ")#mi("{I}")#text(" sums")]#text(", which are basically of the form ")#mi("{\\sum_{m \\leq A:m|n} \\alpha(m)}")#text(" for some weights ")#mi("{\\alpha(m)}")#text(" of controlled size and some cutoff ")#mi("{A}")#text(" that is not too large;")],
[#emph[#text("Type ")#mi("{II}")#text(" sums")]#text(", which are basically of the form ")#mi("{\\sum_{A_- \\leq m \\leq A_+:m|n} \\alpha(m)\\beta(n/m)}")#text(" for some weights ")#mi("{\\alpha(m)}")#text(", ")#mi("{\\beta(n)}")#text(" of controlled size and some cutoffs ")#mi("{A_-, A_+}")#text(" that are not too close to ")#mi("{1}")#text(" or to ")#mi("{X}")#text(";")],
[#emph[#text("Type ")#mi("{I_2}")#text(" sums")]#text(", which are basically of the form ")#mi("{\\sum_{m \\leq A:m|n} \\alpha(m) d_2(n/m)}")#text(" for some weights ")#mi("{\\alpha(m)}")#text(" of controlled size and some cutoff ")#mi("{A}")#text(" that is not too large.")]
)

#text("The precise ranges of the cutoffs ")#mi("{A, A_-, A_+}")#text(" depend on the choice of ")#mi("{\\theta}")#text("; our methods fail once these cutoffs pass a certain threshold, and this is the reason for the exponents ")#mi("{\\theta}")#text(" being what they are in our main results.")

#text("The Type ")#mi("{I}")#text(" sums involving nilsequences can be treated by methods similar to those in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2877066")[#text("this previous paper of Ben Green and myself")]#text("; the main innovations are in the treatment of the Type ")#mi("{II}")#text(" and Type ")#mi("{I_2}")#text(" sums.")

#text("For the Type ")#mi("{II}")#text(" sums, one can split into the “abelian” case in which (after some Fourier decomposition) the nilsequence ")#mi("{F(g(n)\\Gamma)}")#text(" is basically of the form ")#mi("{e(P(n))}")#text(", and the “non-abelian” case in which ")#mi("{G}")#text(" is non-abelian and ")#mi("{F}")#text(" exhibits non-trivial oscillation in a central direction. In the abelian case we can adapt ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=4300228")[#text("arguments of Matomaki and Shao")]#text(", which uses Cauchy-Schwarz and the equidistribution properties of polynomials to obtain good bounds unless ")#mi("{e(P(n))}")#text(" is “major arc” in the sense that it resembles (or “pretends to be”) ")#mi("{\\chi(n) n^{it}}")#text(" for some Dirichlet character ")#mi("{\\chi}")#text(" and some frequency ")#mi("{t}")#text(", but in this case one can use classical multiplicative methods to control the correlation. It turns out that the non-abelian case can be treated similarly. After applying Cauchy-Schwarz, one ends up analyzing the equidistribution of the four-variable polynomial sequence")

#align(center)[#tao-fit-display[#mitex("(n,m,n^{\\prime},m^{\\prime}) \\mapsto (g(nm)\\Gamma, g(n^{\\prime}m)\\Gamma, g(nm^{\\prime}) \\Gamma, g(n^{\\prime}m^{\\prime}\\Gamma))")]]

#text("as ")#mi("{n,m,n^{\\prime},m^{\\prime}}")#text(" range in various dyadic intervals. Using the known multidimensional equidistribution theory of polynomial maps in nilmanifolds, one can eventually show in the non-abelian case that this sequence either has enough equidistribution to give cancellation, or else the nilsequence involved can be replaced with one from a lower dimensional nilmanifold, in which case one can apply an induction hypothesis.")

#text("For the type ")#mi("{I_2}")#text(" sum, a model sum to study is")

#align(center)[#tao-fit-display[#mitex("\\sum_{X < n \\leq X+H} d_2(n) e(\\alpha n)")]]

#text("which one can expand as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n,m: X < nm \\leq X+H} e(\\alpha nm).")]]

#text("We experimented with a number of ways to treat this type of sum (including automorphic form methods, or methods based on the ")#link("https://en.wikipedia.org/wiki/Voronoi_formula")[#text("Voronoi formula")]#text(" or van der Corput’s inequality), but somewhat to our surprise, the most efficient approach was an elementary one, in which one uses the ")#link("https://en.wikipedia.org/wiki/Dirichlet%27s_approximation_theorem")[#text("Dirichlet approximation theorem")]#text(" to decompose the hyperbolic region ")#mi("{\\{ (n,m) \\in {\\bf N}^2: X < nm \\leq X+H \\}}")#text(" into a number of arithmetic progressions, and then uses equidistribution theory to establish cancellation of sequences such as ")#mi("{e(\\alpha nm)}")#text(" on the majority of these progressions. As it turns out, this strategy works well in the regime ")#mi("{H > X^{1/3+\\varepsilon}}")#text(" unless the nilsequence involved is “major arc”, but the latter case is treatable by existing methods as discussed previously; this is why the ")#mi("{\\theta}")#text(" exponent for our ")#mi("{d_2}")#text(" result can be as low as ")#mi("{1/3}")#text(".")

#text("In a sequel to this paper (currently in preparation), we will obtain analogous results for ")#emph[#text("almost all")]#text(" intervals ")#mi("{(x,x+H]}")#text(" with ")#mi("{x}")#text(" in the range ")#mi("{[X,2X]}")#text(", in which we will be able to lower ")#mi("{\\theta}")#text(" all the way to ")#mi("{0}")#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f0b9a908987dfdfc75dae02356a635e8ff78f8d3d1ca98913514ae4baf88d46-d00c0befd789903b432aea6071945fa92bf8636b4820e83fbd2e6a03dea15f9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2022/04/10/higher-uniformity-of-arithmetic-functions-in-short-intervals-i-all-intervals/#comment-642658")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2022")])]

#text("Beautiful result!")

#text("> the ranges of exponents and savings given here seem to be the limit of current methods unless one assumes additional hypotheses, such as GRH.")

#text("What sort of improvements could be made under GRH?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/04/10/higher-uniformity-of-arithmetic-functions-in-short-intervals-i-all-intervals/#comment-642668")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2022")])]

#text("Certainly on GRH I expect all the strongly logarithmic savings ")#mi("O_A(\\log^{-A} X)")#text(" can be improved to power savings ")#mi("O(X^{-c})")#text(" for some ")#mi("c>0")#text(". There should also be some improvements on the value of ")#mi("\\theta")#text(", because GRH should allow one to get better control on major arc sums like ")#mi("\\sum_{X < n \\leq X+H} d_k(n) n^{iT}")#text(" for various ")#mi("k, T")#text(", and this should move the needle on the constraints on ")#mi("\\theta")#text(". Note though that even for the extremely well studied sum ")#mi("\\sum_{X < n \\leq X+H} \\Lambda(n)")#text(" we don't know how to get ")#mi("\\theta")#text(" below 1/2 even on GRH, so there are still limitations to this method.")

#text("Also for ")#mi("d_2, d_3")#text(" it may be possible to use the more sophisticated progress on the divisor sum problem of estimating the error term in ")#mi("\\sum_{n \\leq X} d_k(n)")#text(" to lower these exponents further, although our methods for tackling ")#mi("d_2")#text(" seem to have a hard barrier at ")#mi("\\theta=1/3")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liewyee")]], [#link("https://terrytao.wordpress.com/2022/04/10/higher-uniformity-of-arithmetic-functions-in-short-intervals-i-all-intervals/#comment-642799")[#strong[#text("Liewyee")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2022")])]

#text("I have to leave with a pity，because someone we know，which you choose to care，thanks for your polite company，anyway…goodbye and goodluck…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebfc592b1dfe7fbc6b3db328a99edb83965e209243aac288de1eab2dfbe8d3f1-16dafef2e9965161b0fbab76d6686363904d5e3a458785859ad5a274d999afb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian Finn")]], [#link("https://terrytao.wordpress.com/2022/04/10/higher-uniformity-of-arithmetic-functions-in-short-intervals-i-all-intervals/#comment-642662")[#strong[#text("Ian Finn")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2022")])]

#text("“to obtain bounded on sums” –> I think you mean bounds?")

#emph[#text("[corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/04/10/higher-uniformity-of-arithmetic-functions-in-short-intervals-i-all-intervals/#comment-642666")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2022")])]

#text("Are these methods sufficient to extend the setimates for ")#mi("f=d_4")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/04/10/higher-uniformity-of-arithmetic-functions-in-short-intervals-i-all-intervals/#comment-642669")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2022")])]

#text("Our arguments for ")#mi("\\Lambda, \\mu, d_4")#text(" all hit the same barrier at ")#mi("\\theta=5/8")#text(". The model problem is to obtain some non-trivial asymptotic for")

#mi("\\sum_{X < n \\leq X+H} d_4(n) n^{-iT}")

#text("with ")#mi("H = X^{5/8-\\varepsilon}")#text(" and ")#mi("T = X^{O(1)}")#text(" (note that by a suitable Taylor expansion one can approximate ")#mi("n^{iT} \\approx e(P(n))")#text(" for a suitable polynomial ")#mi("P")#text("). The most dangerous contribution to ")#mi("d_4(n) = \\sum_{abcd=n} 1")#text(" comes from the case where all four factors ")#mi("a,b,c,d")#text(" are comparable to ")#mi("X^{1/4}")#text(". Here it turns out that all of our techniques (Type I methods, Type II methods, Type I_2 methods, or major arc methods) break down once ")#mi("\\theta")#text(" dips below ")#mi("5/8")#text(" (in fact only the major arc methods come close to tackling this sum in this regime). (This obstruction was known to previous authors such as Zhan and Baker-Harman-Pintz; unfortunately we do not have anything new to say about this obstacle.) As mentioned in my other comment, though, one can presumably improve this exponent on GRH. Also, any improvement on the ")#mi("\\theta=5/8")#text(" exponent for the ")#mi("d_4")#text(" problem is likely to also lead to similar improvements ")#mi("\\mu, \\Lambda")#text(", or ")#mi("d_k")#text(" for ")#mi("k>4")#text(" (the model problem above is in some sense the “only” thing preventing improvement of the 5/8 exponent).")

#text("There may be more hope in improving the 5/9 exponent for ")#mi("d_3")#text(". This estimate is basically a consequence the 1/3 exponent estimate for ")#mi("d_2")#text(" and the triangle inequality. Any improvement at all over the crude triangle inequality here should lead to some gain, but we were not able to secure any additional cancellation for this purpose.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adrian Fellhauer")]], [#link("https://terrytao.wordpress.com/2022/04/10/higher-uniformity-of-arithmetic-functions-in-short-intervals-i-all-intervals/#comment-642695")[#strong[#text("Adrian Fellhauer")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2022")])]

#text("I’ve just been reading about ")#link("https://en.wikipedia.org/wiki/Jang_Yeong-sil")[#text("https://en.wikipedia.org/wiki/Jang_Yeong-sil")]#text(" , who was promoted to a major scientific figure under Sejong the Great, despite coming from a lower-class social background.")

#text("Jesus Christ, how long shall my results remain un-used?")

#text("If I survive, I’ll get a readable version on-line next month (there was indeed a minor mistake; the n-th power does not generalise Buchstab’s function adequately, but the function which is obtained instead satisfies the same limit behaviour). I’m even in the process of learning about the geometry of numbers, so that I can calculate the error integrals for prime ideals of a number ring.")

#text("It’s just not fair.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2022/04/10/higher-uniformity-of-arithmetic-functions-in-short-intervals-i-all-intervals/#comment-642782")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2022")])]

#text("Just keep going. The Internet will connect you to who needs to see it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adrian Fellhauer")]], [#link("https://terrytao.wordpress.com/2022/04/10/higher-uniformity-of-arithmetic-functions-in-short-intervals-i-all-intervals/#comment-643742")[#strong[#text("Adrian Fellhauer")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2022")])]

#text("I proudly present the corrected version of my calculations:")

#link("https://www.researchgate.net/profile/Adrian-Fellhauer/publication/360365423_THE_ASYMPTOTIC_DISTRIBUTION_OF_PRIME_ELEMENTS/links/62728e3f107cae291988d37a/THE-ASYMPTOTIC-DISTRIBUTION-OF-PRIME-ELEMENTS.pdf")[#text("Click to access THE-ASYMPTOTIC-DISTRIBUTION-OF-PRIME-ELEMENTS.pdf")]

#text("I don’t wish for a conflict, but I’m beginning to fail to care about my work being ignored by the experts. Instead, I’m beginning to re-prove many mathematical theorems in simpler ways, and also to introduce new terminology which makes more sense. (How on the Earth is a border-free set “open”? How is a limit-faithful function continuous, even if it is defined on two disjoint intervals? And how are the Gaussian integers, a classic example for an arithmonid, a ring???) The new terminology will prevail in the end.")

#text("See for example my proof of the Nullstellensatz, which is, in my opinion, much more in the spirit of Grothendieck than the other ones: ")#link("https://mathoverflow.net/questions/15226/elementary-interesting-proofs-of-the-nullstellensatz/410619#410619")[#text("https://mathoverflow.net/questions/15226/elementary-interesting-proofs-of-the-nullstellensatz/410619#410619")]

#text("While I’m at it, let me give you a bit of advice. Instead of defeatistically giving up on Sendov’s conjecture, why don’t you lower the exponent to zero? (Similar for other “almost proved” conjectures.) Why don’t you give courses on your good results, such as sets with few ordinary lines, the Conze-Lesigne classification, the joint work with Van Vu etc.? Can these proofs be simplified? Can parts of the proofs be re-used for other results?")

#text("Finally: There are enough conjectures for all of us.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/04/10/higher-uniformity-of-arithmetic-functions-in-short-intervals-i-all-intervals/#comment-642990")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2022")])]

#text("Is it possible that the required size of the averaging interval H is somehow dependent on the algorithmic complexity of the function f(n)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/04/10/higher-uniformity-of-arithmetic-functions-in-short-intervals-i-all-intervals/#comment-643034")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2022")])]

#text("I think there is only a loose connection at best. These sorts of uniformity results aim to establish statistical pseudorandomness properties of arithmetic functions such as the Mobius function short intervals. Statistical pseudorandomness is somewhat analogous to computational complexity pseudorandomness, but there is no tight relationship betweeen the two properties. In any event, lower bounds on the computational complexity of functions such as the Mobius function are extremely difficult to establish and unlikely to be the route to make further progress on these statistical uniformity questions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liewyee")]], [#link("https://terrytao.wordpress.com/2022/04/10/higher-uniformity-of-arithmetic-functions-in-short-intervals-i-all-intervals/#comment-643464")[#strong[#text("Liewyee")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2022")])]

#text("I take back what I said…hope it’s not too late…so how is everything going？：-）")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/04/10/higher-uniformity-of-arithmetic-functions-in-short-intervals-i-all-intervals/#comment-649496")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2022")])]

#text("Hello Dr. Tao,")

#text("There is an interesting paper by Louis De Branges that attempts to prove the Generalized Riemann Hypothesis in its stronger form by considering Hecke L-Functions. If you have already researched De Branges’ works in some capacity and do not need to look further in regards to his ideas, you may ignore this. Despite my own interest in mathematics with some side research, I am currently pursuing a different career. However, that is not without saying my deep appreciation for professionals such as yourself who are advancing the field, ways in which one could only dream of. Based on some observations of your research and proofs, I see that you tap into multiple areas of mathematics. When I began researching the Riemann Hypothesis, The Langlands Program, and some of the possible theories in order to understand the connections between the discrete and analysis, I found a ton of interesting attempts at proving the well-behaved randomness of analytic number theoretic functions. In particular, I found the case of Louis De Branges to be the most interesting, as his background and consideration of rich ideas to prove such things as the Bieberbach Conjecture were initially viewed with some skepticism. In fact, if you have not had the chance to look at how obscure his case is in regards to his attempted proof of the more gen. R.H., there is a book called The Strange Case of Louis De Branges. It was published in 2004 by Karl Sabbagh, and because 18 years have passed, I am currently trying to find out if a mathematician has rigorously reviewed his work. However, as I began to look at his work, just to get a bit of understanding on what approaches he took, his ideas utilize algebras, operators, and different ideas of analysis which seem incredibly rich. Although his proof may or may not be accurate, I thought it might be of interest for you to look at some of his ideas. I must say that this proof of his is pretty lengthy, clocking in at approx. 88 pages of detail. Since some of your studies seem to touch upon a couple of fields in his paper, I thought it might be of interest for you to look at his works on spectral and operator theories as well as others he has produced. There is no absolute guarantee that any observation of such theories developed further by De Branges will lead to a significant proof of the behavior of some L-functions. However, because this has been on my mind lately, I felt the urge to anonymously shed light on De Branges for his beautiful ideas which may help, with some collaboration with him in some capacity or manner, to potentially solve the Riemann Hypothesis and other long-standing questions. I think that’s about it.")

#text("Sincerely,")#linebreak()#text(" Anonymous")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Higher uniformity of arithmetic functions in short intervals II. Almost all intervals | What's new")]], [#link("https://terrytao.wordpress.com/2022/04/10/higher-uniformity-of-arithmetic-functions-in-short-intervals-i-all-intervals/#comment-686735")[#strong[#text("Higher uniformity of arithmetic functions in short intervals II. Almost all intervals | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2024")])]

#text("[…] of arithmetic functions in short intervals II. Almost all intervals“. This is a sequel to our previous paper from 2022. In that paper, discorrelation estimates such […]")
]
