// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/
// Converted to Typst by tao2typ: "2026-10-14T08:55:00.651474+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 7: The least singular value", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 7: The least singular value")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 March 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/")[#text("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Now we turn attention to another important spectral statistic, the ")#emph[#text("least singular value")]#text(" ")#mi("{\\sigma_n(M)}")#text(" of an ")#mi("{n \\times n}")#text(" matrix ")#mi("{M}")#text(" (or, more generally, the least non-trivial singular value ")#mi("{\\sigma_p(M)}")#text(" of a ")#mi("{n \\times p}")#text(" matrix with ")#mi("{p \\leq n}")#text("). This quantity controls the invertibility of ")#mi("{M}")#text(". Indeed, ")#mi("{M}")#text(" is invertible precisely when ")#mi("{\\sigma_n(M)}")#text(" is non-zero, and the operator norm ")#tao-math("{\\left\\|M^{-1}\\right\\|_{op}}", block: false)#text(" of ")#mi("{M^{-1}}")#text(" is given by ")#mi("{1/\\sigma_n(M)}")#text(". This quantity is also related to the ")#link("http://en.wikipedia.org/wiki/Condition_number")[#text("condition number")]#text(" ")#tao-math("{\\sigma_1(M)/\\sigma_n(M) = \\left\\|M\\right\\|_{op} \\left\\|M^{-1}\\right\\|_{op}}", block: false)#text(" of ")#mi("{M}")#text(", which is of importance in numerical linear algebra. As we shall see in the next set of notes, the least singular value of ")#mi("{M}")#text(" (and more generally, of the shifts ")#mi("{\\frac{1}{\\sqrt{n}} M - zI}")#text(" for complex ")#mi("{z}")#text(") will be of importance in rigorously establishing the ")#emph[#text("circular law")]#text(" for iid random matrices ")#mi("{M}")#text(", as it plays a key role in computing the ")#emph[#text("Stieltjes transform")]#text(" ")#mi("{\\frac{1}{n} \\text{tr} (\\frac{1}{\\sqrt{n}} M - zI)^{-1}}")#text(" of such matrices, which as we have already seen is a powerful tool in understanding the spectra of random matrices.")

#text("The least singular value")

#align(center)[#tao-fit-display[#tao-math("\\sigma_n(M) = \\inf_{\\left\\|x\\right\\|=1} \\left\\|Mx\\right\\|,", block: true)]]

#text("which sits at the “hard edge” of the spectrum, bears a superficial similarity to the operator norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|M\\right\\|_{op} = \\sigma_1(M) = \\sup_{\\left\\|x\\right\\|=1} \\left\\|Mx\\right\\|", block: true)]]

#text("at the “soft edge” of the spectrum, that was discussed back in ")#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("Notes 3")]#text(", so one may at first think that the methods that were effective in controlling the latter, namely the epsilon-net argument and the moment method, would also work to control the former. The epsilon-net method does indeed have some effectiveness when dealing with rectangular matrices (in which the spectrum stays well away from zero), but the situation becomes more delicate for square matrices; it can control some “low entropy” portions of the infimum that arise from “structured” or “compressible” choices of ")#mi("{x}")#text(", but are not able to control the “generic” or “incompressible” choices of ")#mi("{x}")#text(", for which new arguments will be needed. As for the moment method, this can give the coarse order of magnitude (for instance, for rectangular matrices with ")#mi("{p=yn}")#text(" for ")#mi("{0 < y < 1}")#text(", it gives an upper bound of ")#mi("{(1-\\sqrt{y}+o(1))n}")#text(" for the singular value with high probability, thanks to the ")#emph[#text("Marchenko-Pastur law")]#text("), but again this method begins to break down for square matrices, although one can make some partial headway by considering ")#emph[#text("negative")]#text(" moments such as ")#mi("{\\text{tr} M^{-2}}")#text(", though these are more difficult to compute than positive moments ")#mi("{\\text{tr} M^k}")#text(".")

#text("So one needs to supplement these existing methods with additional tools. It turns out that the key issue is to understand the distance between one of the ")#mi("{n}")#text(" rows ")#mi("{X_1,\\ldots,X_n \\in {\\bf C}^n}")#text(" of the matrix ")#mi("{M}")#text(", and the hyperplane spanned by the other ")#mi("{n-1}")#text(" rows. The reason for this is as follows. First suppose that ")#mi("{\\sigma_n(M)=0}")#text(", so that ")#mi("{M}")#text(" is non-invertible, and there is a linear dependence between the rows ")#mi("{X_1,\\ldots,X_n}")#text(". Thus, one of the ")#mi("{X_i}")#text(" will lie in the hyperplane spanned by the other rows, and so one of the distances mentioned above will vanish; in fact, one expects many of the ")#mi("{n}")#text(" distances to vanish. Conversely, whenever one of these distances vanishes, one has a linear dependence, and so ")#mi("{\\sigma_n(M)=0}")#text(".")

#text("More generally, if the least singular value ")#mi("{\\sigma_n(M)}")#text(" is small, one generically expects many of these ")#mi("{n}")#text(" distances to be small also, and conversely. Thus, control of the least singular value is morally equivalent to control of the distance between a row ")#mi("{X_i}")#text(" and the hyperplane spanned by the other rows. This latter quantity is basically the dot product of ")#mi("{X_i}")#text(" with a unit normal ")#mi("{n_i}")#text(" of this hyperplane.")

#text("When working with random matrices with jointly independent coefficients, we have the crucial property that the unit normal ")#mi("{n_i}")#text(" (which depends on all the rows other than ")#mi("{X_i}")#text(") is ")#emph[#text("independent")]#text(" of ")#mi("{X_i}")#text(", so even after conditioning ")#mi("{n_i}")#text(" to be fixed, the entries of ")#mi("{X_i}")#text(" remain independent. As such, the dot product ")#mi("{X_i \\cdot n_i}")#text(" is a familiar scalar random walk, and can be controlled by a number of tools, most notably Littlewood-Offord theorems and the Berry-Esséen central limit theorem. As it turns out, this type of control works well except in some rare cases in which the normal ")#mi("{n_i}")#text(" is “compressible” or otherwise highly structured; but epsilon-net arguments can be used to dispose of these cases. (This general strategy was first developed for the technically simpler singularity problem ")#link("http://www.ams.org/mathscinet-getitem?mr=221962")[#text("by Komlós")]#text(", and then extended to the least singular value problem ")#link("http://www.ams.org/mathscinet-getitem?mr=2434885")[#text("by Rudelson")]#text(".)")

#text("These methods rely quite strongly on the joint independence on all the entries; it remains a challenge to extend them to more general settings. Even for Wigner matrices, the methods run into difficulty because of the non-independence of some of the entries (although it turns out one can understand the least singular value in such cases by rather different methods).")

#text("To simplify the exposition, we shall focus primarily on just one specific ensemble of random matrices, the ")#emph[#text("Bernoulli ensemble")]#text(" ")#mi("{M = (\\xi_{ij})_{1 \\leq i,j \\leq n}}")#text(" of random sign matrices, where ")#mi("{\\xi_{ij} = \\pm 1}")#text(" are independent Bernoulli signs. However, the results can extend to more general classes of random matrices, with the main requirement being that the coefficients are jointly independent.")

#metadata(none) <tao-4a4b99e918ecdf39911a>

#heading(level: 1)[#strong[#text(" — 1. The epsilon-net argument — ")]]

#text("We begin by using the epsilon net argument to establish a lower bound in the rectangular case, ")#link("http://www.ams.org/mathscinet-getitem?mr=2146352")[#text("due to Litvak, Pajor, Rudelson, and Tomczak-Jaegermann")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Lower bound)")]#text(" ")#metadata(none) <tao-fd26db45a8b53034aa38>#text(" Let ")#mi("{M = (\\xi_{ij})_{1\\leq i\\leq p; 1\\leq j \\leq n}}")#text(" be an ")#mi("{n \\times p}")#text(" Bernoulli matrix, where ")#mi("{1 p \\leq (1-\\delta) n}")#text(" for some ")#mi("{\\delta > 0}")#text(" (independent of ")#mi("{n}")#text("). Then with exponentially high probability (i.e. ")#mi("{1-O(e^{-cn})}")#text(" for some ")#mi("{c>0}")#text("), one has ")#mi("{\\sigma_p(M) \\geq c \\sqrt{n}}")#text(", where ")#mi("{c > 0}")#text(" depends only on ")#mi("{\\delta}")#text(".")
]

#text("This should be compared with the upper bound ")#metadata(none) <tao-3301b5f09b5573bf6950>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\|M\\right\\|_{op} = \\sigma_1(M) \\leq C \\sqrt{n}", block: true)]]

#text("for some absolute constant ")#mi("{C}")#text(" that holds with overwhelming probability from ")#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("Notes 3")]#text(" (indeed, one can take any ")#mi("{C>2}")#text(" here).")

#text("We use the epsilon-net method introduced in Notes 3, but with a smaller value of ")#mi("{\\epsilon > 0}")#text(" than used for the largest singular value. We write")

#align(center)[#tao-fit-display[#tao-math("\\sigma_p(M) = \\inf_{x \\in {\\bf C}^p: \\left\\|x\\right\\|=1} \\left\\|Mx\\right\\|.", block: true)]]

#text("Taking ")#mi("{\\Sigma}")#text(" to be a maximal ")#mi("{\\epsilon}")#text("-net of the unit sphere in ")#mi("{{\\bf C}^p}")#text(", with ")#mi("{\\epsilon > 0}")#text(" to be chosen later, we have that")

#align(center)[#tao-fit-display[#tao-math("\\sigma_p(M) \\geq \\inf_{x \\in \\Sigma} \\left\\|Mx\\right\\| - \\epsilon \\left\\|M\\right\\|_{op}", block: true)]]

#text("and thus by ")#link(<tao-3301b5f09b5573bf6950>)[#text("(1)")]#text(", we have with overwhelming probability that")

#align(center)[#tao-fit-display[#tao-math("\\sigma_p(M) \\geq \\inf_{x \\in \\Sigma} \\left\\|Mx\\right\\| - C \\epsilon \\sqrt{n},", block: true)]]

#text("and so it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf P}( \\inf_{x \\in \\Sigma} \\left\\|Mx\\right\\| \\leq 2C\\epsilon \\sqrt{n} )", block: true)]]

#text("is exponentially small in ")#mi("{n}")#text(". From the union bound, we can upper bound this by")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in \\Sigma} \\mathop{\\bf P}( \\left\\|Mx\\right\\| \\leq 2C\\epsilon \\sqrt{n} ).", block: true)]]

#text("From the volume packing argument we have ")#metadata(none) <tao-1de359b3c5945c905eca>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|\\Sigma\\right| \\leq O(1/\\epsilon)^p \\leq O(1/\\epsilon)^{(1-\\delta) n}.", block: true)]]

#text("So we need to upper bound, for each ")#mi("{x \\in \\Sigma}")#text(", the probability")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}(\\left\\|Mx\\right\\| \\leq 2C\\epsilon \\sqrt{n}).", block: true)]]

#text("If we let ")#mi("{Y_1,\\ldots,Y_n \\in {\\bf C}^p}")#text(" be the rows of ")#mi("{M}")#text(", we can write this as")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\sum_{j=1}^n \\left|Y_j \\cdot x\\right|^2 \\leq 4 C^2 \\epsilon^2 n ).", block: true)]]

#text("By Markov’s inequality, the only way that this event can hold is if we have")

#align(center)[#tao-fit-display[#tao-math("\\left|Y_j \\cdot x\\right|^2 \\leq 8 C^2 \\epsilon^2/\\delta", block: true)]]

#text("for at least ")#mi("{(1-\\delta/2)n}")#text(" values of ")#mi("{j}")#text(". We do not know in advance what the set of ")#mi("{j}")#text(" is for which this event holds. But the number of possible values of such sets of ")#mi("{j}")#text(" is at most ")#mi("{2^n}")#text(". Applying the union bound (and paying the entropy cost of ")#mi("{2^n}")#text(") and using symmetry, we may thus bound the above probability by")

#align(center)[#tao-fit-display[#tao-math("\\leq 2^n {\\bf P}( \\left|Y_j \\cdot x\\right|^2 \\leq 8 C^2 \\epsilon^2/\\delta \\text{ for } 1 \\leq j \\leq (1-\\delta/2)n ).", block: true)]]

#text("Now observe that the random variables ")#mi("{Y_j \\cdot x}")#text(" are independent, and so we can bound this expression by")

#align(center)[#tao-fit-display[#tao-math("\\leq 2^n {\\bf P}( \\left|Y \\cdot x\\right| \\leq \\sqrt{8/\\delta} C \\epsilon )^{(1-\\delta/2)n}", block: true)]]

#text("where ")#mi("{Y = (\\xi_1,\\ldots,\\xi_n)}")#text(" is a random vector of iid Bernoulli signs.")

#text("We write ")#mi("{x = (x_1,\\ldots,x_p)}")#text(", so that ")#mi("{Y \\cdot x}")#text(" is a random walk")

#align(center)[#tao-fit-display[#mitex("Y \\cdot x = \\xi_1 x_1 + \\ldots + \\xi_p x_p.")]]

#text("To understand this walk, we apply (a slight variant) of the Berry-Esséen theorem from ")#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/")[#text("Notes 2")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Show that")

#align(center)[#tao-fit-display[#tao-math("\\sup_t {\\bf P}( \\left|Y \\cdot x - t\\right| \\leq r ) \\ll \\frac{r}{\\left\\|x\\right\\|} + \\frac{1}{\\left\\|x\\right\\|^3} \\sum_{j=1}^p \\left|x_j\\right|^3", block: true)]]

#text("for any ")#mi("{r>0}")#text(" and any non-zero ")#mi("{x}")#text(". (Actually, for the purposes of this set of notes, it would suffice to establish a weaker form of the Berry-Esséen theorem with ")#tao-math("{\\sum_{j=1}^p \\left|x_j\\right|^3 / \\left\\|x\\right\\|^3}", block: false)#text(" replaced by ")#tao-math("{(\\sum_{j=1}^p \\left|x_j\\right|^3 / \\left\\|x\\right\\|^3)^c}", block: false)#text(" for any fixed ")#mi("{c>0}")#text("). (")#emph[#text("Hint:")]#text(" first normalise ")#tao-math("{\\left\\|x\\right\\|=1}", block: false)#text(", then adapt the proof of the Berry-Esséen theorem.)")

#text("Conclude in particular that if")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j: \\left|x_j\\right| \\leq \\epsilon} \\left|x_j\\right|^2 \\geq \\eta^2", block: true)]]

#text("for some ")#mi("{\\eta>0}")#text(" then")

#align(center)[#tao-fit-display[#tao-math("\\sup_t {\\bf P}( \\left|Y \\cdot x-t\\right| \\leq \\sqrt{8/\\delta} C \\epsilon ) \\ll_{\\eta,\\delta} \\epsilon.", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" condition out all the ")#mi("{x_j}")#text(" with ")#tao-math("{\\left|x_j\\right| > \\epsilon}", block: false)#text(".)")
]

#text("Let us temporarily call ")#mi("{x}")#text(" ")#emph[#text("incompressible")]#text(" if")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j: \\left|x_j\\right| \\leq \\epsilon} \\left|x_j\\right|^2 \\geq \\eta^2", block: true)]]

#text("for somme ")#mi("{\\eta>0}")#text(" to be chosen later, and ")#emph[#text("compressible")]#text(" otherwise. If we only look at the incompressible elements of ")#mi("{\\Sigma}")#text(", we can now bound")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}(\\left\\|Mx\\right\\| \\leq 2C\\epsilon \\sqrt{n}) \\ll (O_{\\eta,\\delta}(\\epsilon))^{(1-\\delta/2)n},", block: true)]]

#text("and comparing this against the entropy cost ")#link(<tao-1de359b3c5945c905eca>)[#text("(2)")]#text(" we obtain an acceptable contribution for ")#mi("{\\eta}")#text(" small enough, and ")#mi("{\\epsilon}")#text(" small enough depending on ")#mi("{\\eta,\\delta}")#text(" (here we are crucially using the rectangular condition ")#mi("{p \\leq (1-\\delta) n}")#text(").")

#text("It remains to deal with the compressible vectors. Observe that such vectors lie within ")#mi("{\\eta}")#text(" of a ")#emph[#text("sparse")]#text(" unit vector which is only supported in at most ")#mi("{\\epsilon^{-2}}")#text(" positions. The ")#mi("{\\eta}")#text("-entropy of these sparse vectors (i.e. the number of balls of radius ")#mi("{\\eta}")#text(" needed to cover this space) can easily be computed to be of polynomial size ")#mi("{O(n^{O_{\\epsilon,\\eta}(1)})}")#text(" in ")#mi("{n}")#text(". Meanwhile, we have the following crude bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" For any unit vector ")#mi("{x}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|Y \\cdot x\\right| \\leq \\kappa ) \\leq 1-\\kappa", block: true)]]

#text("for ")#mi("{\\kappa > 0}")#text(" small enough. (")#emph[#text("Hint:")]#text(" Use the ")#link("http://en.wikipedia.org/wiki/Paley%E2%80%93Zygmund_inequality")[#text("Paley-Zygmund inequality")]#text(". Bounds on higher moments on ")#tao-math("{\\left|Y \\cdot x\\right|}", block: false)#text(" can be obtained for instance using Hoeffding’s inequality, or by direct computation.) Use this to show that")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf P}( \\left\\|Mx\\right\\| \\leq 2C\\eta \\sqrt{n} ) \\ll \\exp(-cn)", block: true)]]

#text("for all such ")#mi("{x}")#text(" and ")#mi("{\\eta}")#text(" sufficiently small, with ")#mi("{c>0}")#text(" independent of ")#mi("{\\eta}")#text(" and ")#mi("{n}")#text(".")
]

#text("Thus the compressible vectors give a net contribution of ")#mi("{O( n^{O_{\\epsilon,\\eta}(1)} ) \\times \\exp(-cn)}")#text(", which is acceptable. This concludes the proof of Theorem ")#link(<tao-fd26db45a8b53034aa38>)[#text("1")]#text(".")

#heading(level: 1)[#strong[#text(" — 2. Singularity probability — ")]]

#text("Now we turn to square Bernoulli matrices ")#mi("{M = (\\xi_{ij})_{1 \\leq i,j \\leq n}}")#text(". Before we investigate the size of the least singular value, we first tackle the easier problem of bounding the ")#emph[#text("singularity probability")]

#align(center)[#tao-fit-display[#mitex("{\\bf P}(\\sigma_n(M) = 0),")]]

#text("i.e. the probability that ")#mi("{M}")#text(" is not invertible. The problem of computing this probability exactly is still not completely settled. Since ")#mi("{M}")#text(" is singular whenever the first two rows (say) are identical, we obtain a lower bound")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(\\sigma_n(M) = 0) \\geq \\frac{1}{2^n},")]]

#text("and it is conjectured that this bound is essentially tight in the sense that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(\\sigma_n(M) = 0) = (\\frac{1}{2}+o(1))^n,")]]

#text("but this remains open; the best bound currently is ")#link("http://arxiv.org/abs/0905.0461")[#text("due to Bourgain, Vu, and Wood")]#text(", and gives")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(\\sigma_n(M) = 0) \\leq (\\frac{1}{\\sqrt{2}}+o(1))^n.")]]

#text("We will not prove this bound here, but content ourselves with a weaker bound, essentially ")#link("http://www.ams.org/mathscinet-getitem?mr=221962")[#text("due to Komlós")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" We have ")#mi("{{\\bf P}(\\sigma_n(M) = 0) \\ll 1/n^{1/2}}")#text(".")
]

#text("To show this, we need the following combinatorial fact, ")#link("http://www.ams.org/mathscinet-getitem?mr=14608")[#text("due to Erdös")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Erdös Littlewood-Offord theorem)")]#text(" ")#metadata(none) <tao-495743e84ebedc618663>#text(" Let ")#mi("{x = (x_1,\\ldots,x_n)}")#text(" be a vector with at least ")#mi("{k}")#text(" nonzero entries, and let ")#mi("{Y = (\\xi_1,\\ldots,\\xi_n)}")#text(" be a random vector of iid Bernoulli signs. Then ")#mi("{{\\bf P}(Y \\cdot x = 0) \\ll k^{-1/2}}")#text(".")
]

#emph[#text("Proof:")]#text(" By taking real and imaginary parts we may assume that ")#mi("{x}")#text(" is real. By eliminating zero coefficients of ")#mi("{x}")#text(" we may assume that ")#mi("{k=n}")#text("; reflecting we may then assume that all the ")#mi("{x_i}")#text(" are positive. Observe that the set of ")#mi("{Y = (\\xi_1,\\ldots,\\xi_n) \\in \\{-1,1\\}^n}")#text(" with ")#mi("{Y \\cdot x = 0}")#text(" forms an ")#link("http://en.wikipedia.org/wiki/Antichain")[#text("antichain")]#text(" in ")#mi("{\\{-1,1\\}^n}")#text(". The claim now easily follows from ")#link("http://en.wikipedia.org/wiki/Sperner_family")[#text("Sperner’s theorem")]#text(" and ")#link("http://en.wikipedia.org/wiki/Stirling%27s_approximation")[#text("Stirling’s formula")]#text(". ")#mi("\\Box")

#text("Note that we also have the obvious bound ")#metadata(none) <tao-c3ccedf562d9529001d8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("{\\bf P}(Y \\cdot x = 0) \\leq 1/2")]]

#text("for any non-zero ")#mi("{x}")#text(".")

#text("Now we prove the theorem. In analogy with the arugments of the previou ssection, we write")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(\\sigma_n(M) = 0) = {\\bf P}( Mx = 0 \\text{ for some nonzero } x \\in {\\bf C}^n )")]]

#text("(actually we can take ")#mi("{x \\in {\\bf R}^n}")#text(" since ")#mi("{M}")#text(" is real). We divide into compressible and incompressible vectors as before, but our definition of compressibility and incompressibility is slightly different now. Also, one has to do a certain amount of technical maneuvering in order to preserve the crucial independence between rows and columns.")

#text("Namely, we pick an ")#mi("{\\epsilon > 0}")#text(" and call ")#mi("{x}")#text(" ")#emph[#text("compressible")]#text(" if it is supported on at most ")#mi("{\\epsilon n}")#text(" coordinates, and ")#emph[#text("incompressible")]#text(" otherwise.")

#text("Let us first consider the contribution of the event that ")#mi("{Mx=0}")#text(" for some nonzero compressible ")#mi("{x}")#text(". Pick an ")#mi("{x}")#text(" with this property which is as sparse as possible, say ")#mi("{k}")#text(" sparse for some ")#mi("{1 \\leq k < \\epsilon n}")#text(". Let us temporarily fix ")#mi("{k}")#text(". By paying an entropy cost of ")#mi("{\\binom{n}{k}}")#text(", we may assume that it is the first ")#mi("{k}")#text(" entries that are non-zero for some ")#mi("{1 \\leq k \\leq \\epsilon n}")#text(". This implies that the first ")#mi("{k}")#text(" columns ")#mi("{Y_1,\\ldots,Y_k}")#text(" of ")#mi("{M}")#text(" have a linear dependence given by ")#mi("{x}")#text("; by minimality, ")#mi("{Y_1,\\ldots,Y_{k-1}}")#text(" are linearly independent. Thus, ")#mi("{x}")#text(" is uniquely determined (up to scalar multiples) by ")#mi("{Y_1,\\ldots,Y_k}")#text(". Furthermore, as the ")#mi("{n \\times k}")#text(" matrix formed by ")#mi("{Y_1,\\ldots,Y_k}")#text(" has rank ")#mi("{k-1}")#text(", there is some ")#mi("{k \\times k}")#text(" minor which already determines ")#mi("{x}")#text(" up to constants; by paying another entropy cost of ")#mi("{\\binom{n}{k}}")#text(", we may assume that it is the top left minor which does this. In particular, we can now use the first ")#mi("{k}")#text(" rows ")#mi("{X_1,\\ldots,X_k}")#text(" to determine ")#mi("{x}")#text(" up to constants. But the remaining ")#mi("{n-k}")#text(" rows are independent of ")#mi("{X_1,\\ldots,X_k}")#text(" and still need to be orthogonal to ")#mi("{x}")#text("; by Proposition ")#link(<tao-495743e84ebedc618663>)[#text("3")]#text(" and ")#link(<tao-c3ccedf562d9529001d8>)[#text("(3)")]#text(", this happens with probability at most ")#mi("{\\min( O( k^{1/2} ), 1/2 )^{n-k}}")#text(", giving a total cost of")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq k \\leq \\epsilon n} \\binom{n}{k}^2 \\min( O( k^{1/2} ), 1/2 )^{n-k},")]]

#text("which by Stirling’s formula is acceptable (in fact this gives an exponentially small contribution).")

#text("The same argument gives that the event that ")#mi("{y^* M=0}")#text(" for some nonzero compressible ")#mi("{y}")#text(" also has exponentially small probability. The only remaining event to control is the event that ")#mi("{Mx=0}")#text(" for some incompressible ")#mi("{x}")#text(", but that ")#mi("{Mz \\neq 0}")#text(" and ")#mi("{y^* M \\neq 0}")#text(" for all nonzero compressible ")#mi("{z,y}")#text(". Call this event ")#mi("{E}")#text(".")

#text("Since ")#mi("{Mx=0}")#text(" for some incompressible ")#mi("{x}")#text(", we see that for at least ")#mi("{\\epsilon n}")#text(" values of ")#mi("{k \\in \\{1,\\ldots,n\\}}")#text(", the column ")#mi("{Y_k}")#text(" lies in the vector space ")#mi("{V_k}")#text(" spanned by the remaining ")#mi("{n-1}")#text(" columns of ")#mi("{M}")#text(". Let ")#mi("{E_k}")#text(" denote the event that ")#mi("{E}")#text(" holds, and that ")#mi("{X_k}")#text(" lies in ")#mi("{V_k}")#text("; then we see from double counting that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(E) \\leq \\frac{1}{\\epsilon n} \\sum_{k=1}^n {\\bf P}(E_k).")]]

#text("By symmetry, we thus have")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(E) \\leq \\frac{1}{\\epsilon} {\\bf P}(E_n).")]]

#text("To compute ")#mi("{{\\bf P}(E_n)}")#text(", we freeze ")#mi("{Y_1,\\ldots,Y_{n-1}}")#text(" consider a normal vector ")#mi("{x}")#text(" to ")#mi("{V_{n-1}}")#text("; note that we can select ")#mi("{x}")#text(" depending only on ")#mi("{Y_1,\\ldots,Y_{n-1}}")#text(". We may assume that an incompressible normal vector exists, since otherwise the event ")#mi("{E_n}")#text(" would be empty. We make the crucial observation that ")#mi("{Y_n}")#text(" is still independent of ")#mi("{x}")#text(". By Proposition ")#link(<tao-495743e84ebedc618663>)[#text("3")]#text(", we thus see that the conditional probability that ")#mi("{Y_n \\cdot x = 0}")#text(", for fixed ")#mi("{Y_1,\\ldots,Y_{n-1}}")#text(", is ")#mi("{O_\\epsilon(n^{-1/2})}")#text(". We thus see that ")#mi("{{\\bf P}(E) \\ll_\\epsilon 1/n^{1/2}}")#text(", and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Further progress has been made on this problem by a finer analysis of the concentration probability ")#mi("{{\\bf P}(Y \\cdot x = 0)}")#text(", and in particular in classifying those ")#mi("{x}")#text(" for which this concentration probability is large (this is known as the ")#emph[#text("inverse Littlewood-Offord problem")]#text("). Important breakthroughs in this direction were made ")#link("http://www.ams.org/mathscinet-getitem?mr=494478")[#text("by Halász")]#text(" (introducing Fourier-analytic tools) and ")#link("http://www.ams.org/mathscinet-getitem?mr=1260107")[#text("by Kahn, Komlós, and Szemerédi")]#text(" (introducing an efficient “swapping” argument). ")#link("http://www.ams.org/mathscinet-getitem?mr=2291914")[#text("Van Vu and I")]#text(" introduced tools from additive combinatorics (such as Freiman’s theorem) to obtain further improvements, leading eventually to the results ")#link("http://arxiv.org/abs/0905.0461")[#text("of Bourgain, Vu, and Wood")]#text(" mentioned earlier.")
]

#heading(level: 1)[#strong[#text(" — 3. Lower bound for the least singular value — ")]]

#text("Now we return to the least singular value ")#mi("{\\sigma_n(M)}")#text(" of an iid Bernoulli matrix, and establish a lower bound. Given that there are ")#mi("{n}")#text(" singular values between ")#mi("{0}")#text(" and ")#mi("{\\sigma_1(M)}")#text(", which is typically of size ")#mi("{O(\\sqrt{n})}")#text(", one expects the least singular value to be of size about ")#mi("{1/\\sqrt{n}}")#text(" on the average. Another argument supporting this heuristic scomes from the following identity:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3 (Negative second moment identity)")]#text(" ")#metadata(none) <tao-16367aacb67a4a017c8d>#text(" Let ")#mi("{M}")#text(" be an invertible ")#mi("{n \\times n}")#text(" matrix, let ")#mi("{X_1,\\ldots,X_n}")#text(" be the rows of ")#mi("{M}")#text(", and let ")#mi("{R_1,\\ldots,R_n}")#text(" be the columns of ")#mi("{M^{-1}}")#text(". For each ")#mi("{1 \\leq i \\leq n}")#text(", let ")#mi("{V_i}")#text(" be the hyperplane spanned by all the rows ")#mi("{X_1,\\ldots,X_n}")#text(" other than ")#mi("{X_i}")#text(". Show that ")#tao-math("{\\left\\|R_i\\right\\| = \\text{dist}(X_i,V_i)^{-1}}", block: false)#text(" and ")#mi("{\\sum_{i=1}^n \\sigma_i(M)^{-2} = \\sum_{i=1}^n \\text{dist}(X_i,V_i)^{-2}}")#text(".")
]

#text("From Talagrand’s inequality (")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text("), we expect each ")#mi("{\\text{dist}(X_i,V_i)}")#text(" to be of size ")#mi("{O(1)}")#text(" on the average, which suggests that ")#mi("{\\sum_{i=1}^n \\sigma_i(M)^{-2} = O(n)}")#text("; this is consistent with the heuristic that the singular values ")#mi("{\\sigma_i(M)}")#text(" should be roughly evenly spaced in the interval ")#mi("{[0,2\\sqrt{n}]}")#text(" (so that ")#mi("{\\sigma_{n-i}(M)}")#text(" should be about ")#mi("{(i+1)/\\sqrt{n}}")#text(").")

#text("Now we give a rigorous lower bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Lower tail estimate for the least singular value)")]#text(" ")#metadata(none) <tao-6903e2b76da53ba85cea>#text(" For any ")#mi("{\\lambda > 0}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( \\sigma_n(M) \\leq \\lambda / \\sqrt{n} ) \\ll o_{\\lambda \\rightarrow 0}(1) + o_{n \\rightarrow \\infty;\\lambda}(1)")]]

#text("where ")#mi("{o_{\\epsilon \\rightarrow 0}(1)}")#text(" goes to zero as ")#mi("{\\lambda \\rightarrow 0}")#text(" uniformly in ")#mi("{n}")#text(", and ")#mi("{o_{n \\rightarrow \\infty;\\lambda}(1)}")#text(" goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(" for each fixed ")#mi("{\\lambda}")#text(".")
]

#text("This is a weaker form of a ")#link("http://www.ams.org/mathscinet-getitem?mr=2407948")[#text("result of Rudelson and Vershynin")]#text(" (which obtains a bound of the form ")#mi("{O(\\lambda) + O(c^n)}")#text(" for some ")#mi("{c<1}")#text("), which builds upon earlier work ")#link("http://www.ams.org/mathscinet-getitem?mr=2434885")[#text("of Rudelson")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2480613")[#text("of Vu and myself")]#text(", which obtained variants of the above result.")

#text("The scale ")#mi("{1/\\sqrt{n}}")#text(" that we are working at here is too fine to use epsilon net arguments (unless one has a ")#emph[#text("lot")]#text(" of control on the entropy, which can be obtained in some cases thanks to powerful inverse Littlewood-Offord theorems, but is difficult to obtain in general.) We can prove this theorem along similar lines to the arguments in the previous section; we sketch the method as follows. We can take ")#mi("{\\lambda}")#text(" to be small. We write the probability to be estimated as")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left\\|Mx\\right\\| \\leq \\lambda/\\sqrt{n} \\text{ for some unit vector } x \\in {\\bf C}^n ).", block: true)]]

#text("We can assume that ")#tao-math("{\\left\\|M\\right\\|_{op} \\leq C \\sqrt{n}}", block: false)#text(" for some absolute constant ")#mi("{C}")#text(", as the event that this fails has exponentially small probability.")

#text("We pick an ")#mi("{\\epsilon > 0}")#text(" (not depending on ")#mi("{\\lambda}")#text(") to be chosen later. We call a unit vector ")#mi("{x \\in {\\bf C}^n}")#text(" ")#emph[#text("compressible")]#text(" if ")#mi("{x}")#text(" lies within a distance ")#mi("{\\epsilon}")#text(" of a ")#mi("{\\epsilon n}")#text("-sparse vector. Let us first dispose of the case in which ")#tao-math("{\\left\\|Mx\\right\\| \\leq \\lambda \\sqrt{n}}", block: false)#text(" for some compressible ")#mi("{x}")#text(". By paying an entropy cost of ")#mi("{\\binom{n}{\\lfloor \\epsilon n\\rfloor}}")#text(", we may assume that ")#mi("{x}")#text(" is within ")#mi("{\\epsilon}")#text(" of a vector ")#mi("{y}")#text(" supported in the first ")#mi("{\\lfloor \\epsilon n\\rfloor}")#text(" coordinates. Using the operator norm bound on ")#mi("{M}")#text(" and the triangle inequality, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|My\\right\\| \\leq (\\lambda + C\\epsilon) \\sqrt{n}.", block: true)]]

#text("Since ")#mi("{y}")#text(" has norm comparable to ")#mi("{1}")#text(", this implies that the least singular value of the first ")#mi("{\\lfloor \\epsilon n \\rfloor}")#text(" columns of ")#mi("{M}")#text(" is ")#mi("{O( (\\lambda + \\epsilon)\\sqrt{n} )}")#text(". But by Theorem ")#link(<tao-fd26db45a8b53034aa38>)[#text("1")]#text(", this occurs with probability ")#mi("{O(\\exp(-cn))}")#text(" (if ")#mi("{\\lambda,\\epsilon}")#text(" are small enough). So the total probability of the compressible event is at most ")#mi("{\\binom{n}{\\lfloor \\epsilon n\\rfloor} O(\\exp(-cn))}")#text(", which is acceptable if ")#mi("{\\epsilon}")#text(" is small enough.")

#text("Thus we may assume now that ")#tao-math("{\\left\\|M x \\right\\| > \\lambda/\\sqrt{n}}", block: false)#text(" for all compressible unit vectors ")#mi("{x}")#text("; we may similarly assume that ")#tao-math("{\\left\\| y^* M \\right\\| > \\lambda/\\sqrt{n}}", block: false)#text(" for all compressible unit vectors ")#mi("{y}")#text(". Indeed, we may also assume that ")#tao-math("{\\left\\|y^* M_i \\right\\| > \\lambda/\\sqrt{n}}", block: false)#text(" for every ")#mi("{i}")#text(", where ")#mi("{M_i}")#text(" is ")#mi("{M}")#text(" with the ")#mi("{i^{th}}")#text(" column removed.")

#text("The remaining case is if ")#tao-math("{\\left\\|Mx\\right\\| \\leq \\lambda/\\sqrt{n}}", block: false)#text(" for some incompressible ")#mi("{x}")#text(". Let us call this event ")#mi("{E}")#text(". Write ")#mi("{x=(x_1,\\ldots,x_n)}")#text(", and let ")#mi("{Y_1,\\ldots,Y_n}")#text(" be the column of ")#mi("{M}")#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\| x_1 Y_1 + \\ldots + x_n Y_n \\right\\| \\leq \\lambda/\\sqrt{n}.", block: true)]]

#text("Letting ")#mi("{W_i}")#text(" be the subspace spanned by all the ")#mi("{Y_1,\\ldots,Y_n}")#text(" except for ")#mi("{Y_i}")#text(", we conclude upon projecting to the orthogonal complement of ")#mi("{W_i}")#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\left|x_i\\right| \\text{dist}(Y_i,W_i) \\leq \\lambda/\\sqrt{n}", block: true)]]

#text("for all ")#mi("{i}")#text(" (compare with Exercise ")#link(<tao-16367aacb67a4a017c8d>)[#text("3")]#text("). On the other hand, since ")#mi("{x}")#text(" is incompressible, we see that ")#tao-math("{\\left|x_i\\right| \\geq \\epsilon/\\sqrt{n}}", block: false)#text(" for at least ")#mi("{\\epsilon n}")#text(" values of ")#mi("{i}")#text(", and thus ")#metadata(none) <tao-aa5014ed3b401cbba9f5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\text{dist}(Y_i,W_i) \\leq \\lambda/\\epsilon.")]]

#text("for at least ")#mi("{\\epsilon n}")#text(" values of ")#mi("{i}")#text(". If we let ")#mi("{E_i}")#text(" be the event that ")#mi("{E}")#text(" and ")#link(<tao-aa5014ed3b401cbba9f5>)[#text("(4)")]#text(" both hold, we thus have from double-counting that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(E) \\leq \\frac{1}{\\epsilon n} \\sum_{i=1}^n {\\bf P}(E_i)")]]

#text("and thus by symmetry")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(E) \\leq \\frac{1}{\\epsilon} {\\bf P}(E_n)")]]

#text("(say). However, if ")#mi("{E_n}")#text(" holds, then setting ")#mi("{y}")#text(" to be a unit normal vector to ")#mi("{W_i}")#text(" (which is necessarily incompressible, by the hypothesis on ")#mi("{M_i}")#text("), we have")

#align(center)[#tao-fit-display[#tao-math("\\left|Y_i \\cdot y\\right| \\leq \\lambda/\\epsilon.", block: true)]]

#text("Again, the crucial point is that ")#mi("{Y_i}")#text(" and ")#mi("{y}")#text(" are independent. The incompressibility of ")#mi("{y}")#text(", combined with a Berry-Esséen type theorem, then gives")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Show that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|Y_i \\cdot y\\right| \\leq \\lambda/\\epsilon ) \\ll \\epsilon^2", block: true)]]

#text("(say) if ")#mi("{\\lambda}")#text(" is sufficiently small depending on ")#mi("{\\epsilon}")#text(", and ")#mi("{n}")#text(" is sufficiently large depending on ")#mi("{\\epsilon}")#text(".")
]

#text("This gives a bound of ")#mi("{O(\\epsilon)}")#text(" for ")#mi("{{\\bf P}(E)}")#text(" if ")#mi("{\\lambda}")#text(" is small enough depending on ")#mi("{\\epsilon}")#text(", and ")#mi("{n}")#text(" is large enough; this gives the claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" A variant of these arguments, based on inverse Littlewood-Offord theorems rather than the Berry-Esséen theorem, gives the variant estimate ")#metadata(none) <tao-036b300b9ee452180978>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sigma_n( \\frac{1}{\\sqrt{n}} M_n - z I ) \\geq n^{-A}")]]

#text("with high probability for some ")#mi("{A>0}")#text(", and any ")#mi("{z}")#text(" of polynomial size in ")#mi("{n}")#text(". There are several results of this type, with overlapping ranges of generality (and various values of ")#mi("{A}")#text(") ")#link("http://arxiv.org/abs/math/0702386")[#text("by Götze-Tikhimirov")]#text(", ")#link("http://arxiv.org/abs/0705.3773")[#text("Pan-Zhou")]#text(", and ")#link("http://arxiv.org/abs/0708.2895")[#text("Vu and myself")]#text("; the exponent ")#mi("{A}")#text(" is known to degrade if one has too few moment assumptions on the underlying random matrix ")#mi("{M}")#text(". This type of result (with an unspecified ")#mi("{A}")#text(") is important for the circular law, discussed in the next set of lectures.")
]

#heading(level: 1)[#strong[#text(" — 4. Upper bound for the least singular value — ")]]

#text("One can complement the lower tail estimate with an upper tail estimate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Upper tail estimate for the least singular value)")]#text(" ")#metadata(none) <tao-f03ca1223071cfa7a4d8>#text(" For any ")#mi("{\\lambda > 0}")#text(", one has ")#metadata(none) <tao-8e6a0ab2937027144d3c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("{\\bf P}( \\sigma_n(M) \\geq \\lambda / \\sqrt{n} ) \\ll o_{\\lambda \\rightarrow \\infty}(1) + o_{n \\rightarrow \\infty;\\lambda}(1).")]]
]

#text("We prove this using an ")#link("http://arxiv.org/abs/0805.3407")[#text("argument of Rudelson and Vershynin")]#text(". Suppose that ")#mi("{\\sigma_n(M) > \\lambda / \\sqrt{n}}")#text(", then ")#metadata(none) <tao-9baf3a40312f39849f46>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left\\|y^* M^{-1}\\right\\| \\leq \\sqrt{n} \\left\\|y\\right\\| / \\lambda", block: true)]]

#text("for all ")#mi("{y}")#text(".")

#text("Next, let ")#mi("{X_1,\\ldots,X_n}")#text(" be the rows of ")#mi("{M}")#text(", and let ")#mi("{R_1,\\ldots,R_n}")#text(" be the columns of ")#mi("{M^{-1}}")#text(", thus ")#mi("{R_1,\\ldots,R_n}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Dual_basis")[#text("dual basis")]#text(" for ")#mi("{X_1,\\ldots,X_n}")#text(". From ")#link(<tao-9baf3a40312f39849f46>)[#text("(7)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i=1}^n \\left|y \\cdot R_i\\right|^2 \\leq n \\left\\|y\\right\\|^2/\\lambda^2.", block: true)]]

#text("We apply this with ")#mi("{y}")#text(" equal to ")#mi("{X_n - \\pi_n(X_n)}")#text(", where ")#mi("{\\pi_n}")#text(" is the orthogonal projection to the space ")#mi("{V_{n-1}}")#text(" spanned by ")#mi("{X_1,\\ldots,X_{n-1}}")#text(". On the one hand, we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|y\\right\\|^2 = \\text{dist}(X_n,V_{n-1})^2", block: true)]]

#text("and on the other hand we have for any ")#mi("{1 \\leq i < n}")#text(" that")

#align(center)[#tao-fit-display[#mitex("y \\cdot R_i = - \\pi_n(X_n) \\cdot R_i = - X_n \\cdot \\pi_n(R_i)")]]

#text("and so ")#metadata(none) <tao-8e60a80b015666bd707f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\sum_{i=1}^{n-1} \\left|X_n \\cdot \\pi_n(R_i)\\right|^2 \\leq n \\text{dist}(X_n,V_{n-1})^2 / \\lambda^2.", block: true)]]

#text("If ")#link(<tao-8e60a80b015666bd707f>)[#text("(8)")]#text(" holds, then ")#tao-math("{\\left|X_n \\cdot \\pi_n(R_i)\\right|^2 = O( \\text{dist}(X_n,V_{n-1})^2 / \\lambda^2 )}", block: false)#text(" for at least half of the ")#mi("{i}")#text(", so the probability in ")#link(<tao-8e6a0ab2937027144d3c>)[#text("(6)")]#text(" can be bounded by")

#align(center)[#tao-fit-display[#tao-math("\\ll \\frac{1}{n} \\sum_{i=1}^{n-1} {\\bf P} ( \\left|X_n \\cdot \\pi_n(R_i)\\right|^2 = O( \\text{dist}(X_n,V_{n-1})^2 / \\lambda^2 ) )", block: true)]]

#text("which by symmetry can be bounded by")

#align(center)[#tao-fit-display[#tao-math("\\ll {\\bf P} ( \\left|X_n \\cdot \\pi_n(R_1)\\right|^2 = O( \\text{dist}(X_n,V_{n-1})^2 / \\lambda^2 ) ).", block: true)]]

#text("Let ")#mi("{\\epsilon > 0}")#text(" be a small quantity to be chosen later. From Talagrand’s inequality (")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text(") we know that ")#mi("{\\text{dist}(X_n,V_{n-1}) = O_\\epsilon(1)}")#text(" with probability ")#mi("{1-O(\\epsilon)}")#text(", so we obtain a bound of")

#align(center)[#tao-fit-display[#mitex("\\ll {\\bf P} ( X_n \\cdot \\pi_n(R_1) = O_\\epsilon( 1 / \\lambda ) ) + O(\\epsilon).")]]

#text("Now a key point is that the vectors ")#mi("{\\pi_n(R_1),\\ldots,\\pi_n(R_{n-1})}")#text(" depend only on ")#mi("{X_1,\\ldots,X_{n-1}}")#text(" and not on ")#mi("{X_n}")#text("; indeed, they are the dual basis for ")#mi("{X_1,\\ldots,X_{n-1}}")#text(" in ")#mi("{V_{n-1}}")#text(". Thus, after conditioning ")#mi("{X_1,\\ldots,X_{n-1}}")#text(" and thus ")#mi("{\\pi_n(R_1)}")#text(" to be fixed, ")#mi("{X_n}")#text(" is still a Bernoulli random vector. Applying a Berry-Esséen inequality, we obtain a bound of ")#mi("{O(\\epsilon)}")#text(" for the conditional probability that ")#mi("{X_n \\cdot \\pi_n(R_1) = O_\\epsilon( 1 / \\lambda )}")#text(" for ")#mi("{\\lambda}")#text(" sufficiently small depending on ")#mi("{\\epsilon}")#text(", unless ")#mi("{\\pi_n(R_1)}")#text(" is compressible (in the sense that, say, it is within ")#mi("{\\epsilon}")#text(" of an ")#mi("{\\epsilon n}")#text("-sparse vector). But this latter possibility can be controlled (with exponentially small probability) by the same type of arguments as before; we omit the details.")

#heading(level: 1)[#strong[#text(" — 5. Asymptotic for the least singular value — ")]]

#text("The distribution of singular values of a gaussian random matrix can be computed explicitly by techniques similar to those employed in ")#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/")[#text("Notes 6")]#text(". In particular, if ")#mi("{M}")#text(" is a real gaussian matrix (with all entries iid with distribution ")#mi("{N(0,1)_{\\bf R}}")#text("), it was shown by Edelman that ")#mi("{\\sqrt{n} \\sigma_n(M)}")#text(" converges in distribution to the distribution ")#mi("{\\mu_E := \\frac{1+\\sqrt{x}}{2\\sqrt{x}} e^{-x/2 - \\sqrt{x}}\\ dx}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". It turns out that this result can be extended to other ensembles with the same mean and variance. In particular, we have the following ")#link("https://terrytao.wordpress.com/2009/03/06/random-matrices-the-distribution-of-the-smallest-singular-values")[#text("result of Van Vu and myself")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6")]#text(" ")#metadata(none) <tao-65322be4021bbae80eee>#text(" If ")#mi("{M}")#text(" is an iid Bernoulli matrix, then ")#mi("{\\sqrt{n} \\sigma_n(M)}")#text(" also converges in distribution to ")#mi("{\\mu_E}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". (In fact there is a polynomial rate of convergence.)")
]

#text("This should be compared with Theorems ")#link(<tao-6903e2b76da53ba85cea>)[#text("4")]#text(", ")#link(<tao-f03ca1223071cfa7a4d8>)[#text("5")]#text(", which show that ")#mi("{\\sqrt{n} \\sigma_n(M)}")#text(" have a tight sequence of distributions in ")#mi("{(0,+\\infty)}")#text(". The arguments of Van and myself thus provide an alternate proof of these two theorems.")

#text("We do not establish the limit ")#mi("{\\mu_E}")#text(" directly, but instead use Edelman’s result as a black box, focusing instead on establishing the ")#emph[#text("universality")]#text(" of the limiting distribution of ")#mi("{\\sqrt{n} \\sigma_n(M)}")#text(", and in particular that this limiting distribution is the same whether one has a Bernoulli ensemble or a gaussian ensemble.")

#text("The arguments are somewhat technical and we will not present them in full here, but instead give a sketch of the key ideas.")

#text("In previous sections we have already seen the close relationship between the least singular value ")#mi("{\\sigma_n(M)}")#text(", and the distances ")#mi("{\\text{dist}(X_i,V_i)}")#text(" between a row ")#mi("{X_i}")#text(" of ")#mi("{M}")#text(" and the hyperplane ")#mi("{V_i}")#text(" spanned by the other ")#mi("{n-1}")#text(" rows. It is not hard to use the above machinery to show that as ")#mi("{n \\rightarrow \\infty}")#text(", ")#mi("{\\text{dist}(X_i,V_i)}")#text(" converges in distribution to the absolute value ")#tao-math("{\\left|N(0,1)_{\\bf R}\\right|}", block: false)#text(" of a Gaussian regardless of the underlying distribution of the coefficients of ")#mi("{M}")#text(" (i.e. it is asymptotically universal). The basic point is that one can write ")#mi("{\\text{dist}(X_i,V_i)}")#text(" as ")#tao-math("{\\left|X_i \\cdot n_i\\right|}", block: false)#text(" where ")#mi("{n_i}")#text(" is a unit normal of ")#mi("{V_i}")#text(" (we will assume here that ")#mi("{M}")#text(" is non-singular, which by previous arguments is true asymptotically almost surely). The previous machinery lets us show that ")#mi("{n_i}")#text(" is incompressible with high probability, and then claim then follows from the Berry-Esséen theorem.")

#text("Unfortunately, despite the presence of suggestive relationships such as Exercise ")#link(<tao-16367aacb67a4a017c8d>)[#text("3")]#text(", the asymptotic universality of the distances ")#mi("{\\text{dist}(X_i,V_i)}")#text(" does not directly imply asymptotic universality of the least singular value. However, it turns out that one can obtain a higher-dimensional version of the universality of the scalar quantities ")#mi("{\\text{dist}(X_i,V_i)}")#text(", as follows. For any small ")#mi("{k}")#text(" (say, ")#mi("{1 \\leq k \\leq n^c}")#text(" for some small ")#mi("{c>0}")#text(") and any distinct ")#mi("{i_1,\\ldots,i_k \\in \\{1,\\ldots,n\\}}")#text(", a modification of the above argument shows that the covariance matrix ")#metadata(none) <tao-d9eb257f7dbec86f56f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("( \\pi( X_{i_a} ) \\cdot \\pi(X_{i_b}) )_{1 \\leq a,b \\leq k}")]]

#text("of the orthogonal projections ")#mi("{\\pi(X_{i_1}),\\ldots,\\pi(X_{i_k})}")#text(" of the ")#mi("{k}")#text(" rows ")#mi("{X_{i_1},\\ldots,X_{i_k}}")#text(" to the complement ")#mi("{V^\\perp_{i_1,\\ldots,i_k}}")#text(" of the space ")#mi("{V_{i_1,\\ldots,i_k}}")#text(" spanned by the other ")#mi("{n-k}")#text(" rows of ")#mi("{M}")#text(", is also universal, converging in distribution to the covariance matrix ")#mi("{( G_a \\cdot G_b )_{1 \\leq a,b \\leq k}}")#text(" of ")#mi("{k}")#text(" iid gaussians ")#mi("{G_a \\equiv N(0,1)_{\\bf R}}")#text(" (note that the convergence of ")#mi("{\\text{dist}(X_i,V_i)}")#text(" to ")#tao-math("{\\left|N(0,1)_{\\bf R}\\right|}", block: false)#text(" is the ")#mi("{k=1}")#text(" case of this claim). (These covariance matrix distributions are also known as ")#emph[#text("Wishart distributions")]#text(".) The key point is that one can show that the complement ")#mi("{V^\\perp_{i_1,\\ldots,i_k}}")#text(" is usually “incompressible” in a certain technical sense, which implies that the projections ")#mi("{\\pi(X_{i_a})}")#text(" behave like iid gaussians on that projection thanks to a multidimensional Berry-Esséen theorem.")

#text("On the other hand, the covariance matrix ")#link(<tao-d9eb257f7dbec86f56f0>)[#text("(9)")]#text(" is closely related to the inverse matrix ")#mi("{M^{-1}}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Show that ")#link(<tao-d9eb257f7dbec86f56f0>)[#text("(9)")]#text(" is also equal to ")#mi("{A^* A}")#text(", where ")#mi("{A}")#text(" is the ")#mi("{n \\times k}")#text(" matrix formed from the ")#mi("{i_1,\\ldots,i_k}")#text(" columns of ")#mi("{M^{-1}}")#text(".")
]

#text("In particular, this shows that the singular values of ")#mi("{k}")#text(" randomly selected columns of ")#mi("{M^{-1}}")#text(" have a universal distribution.")

#text("Recall our goal is to show that ")#mi("{\\sqrt{n} \\sigma_n(M)}")#text(" has an asymptotically universal distribution, which is equivalent to asking that ")#tao-math("{\\frac{1}{\\sqrt{n}} \\left\\|M^{-1}\\right\\|_{op}}", block: false)#text(" has an asymptotically universal distribution. The goal is then to extract the operator norm of ")#mi("{M^{-1}}")#text(" from looking at a random ")#mi("{n \\times k}")#text(" minor ")#mi("{B}")#text(" of this matrix. This comes from the following application of the second moment method:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" ")#metadata(none) <tao-fdd33982464b25638709>#text(" Let ")#mi("{A}")#text(" be an ")#mi("{n \\times n}")#text(" matrix with columns ")#mi("{R_1,\\ldots,R_n}")#text(", and let ")#mi("{B}")#text(" be the ")#mi("{n \\times k}")#text(" matrix formed by taking ")#mi("{k}")#text(" of the columns ")#mi("{R_1,\\ldots,R_n}")#text(" at random. Show that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left\\| A^* A - \\frac{n}{k} B^* B \\right\\|_F^2 \\leq \\frac{n}{k} \\sum_{k=1}^n \\left\\|R_k\\right\\|^4,", block: true)]]

#text("where ")#mi("{\\|\\|_F}")#text(" is the Frobenius norm.")
]

#text("Recall from Exercise ")#link(<tao-16367aacb67a4a017c8d>)[#text("3")]#text(" that ")#tao-math("{\\left\\|R_k\\right\\| = 1 / \\text{dist}(X_k,V_k)}", block: false)#text(", so we expect each ")#tao-math("{\\left\\|R_k\\right\\|}", block: false)#text(" to have magnitude about ")#mi("{O(1)}")#text(". This, together with the Hoeffman-Wielandt inequality (")#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/")[#text("Notes 3b")]#text(") means that we expect ")#mi("{\\sigma_1( (M^{-1})^* (M^{-1}) ) = \\sigma_n(M)^{-2}}")#text(" to differ by ")#mi("{O( n^2/k )}")#text(" from ")#mi("{\\frac{n}{k} \\sigma_1(B^* B) = \\frac{n}{k} \\sigma_1(B)^2}")#text(". In principle, this gives us asymptotic universality on ")#mi("{\\sqrt{n} \\sigma_n(M)}")#text(" from the already established universality of ")#mi("{B}")#text(".")

#text("There is one technical obstacle remaining, however: while we know that each ")#mi("{\\text{dist}(X_k,V_k)}")#text(" is distributed like a Gaussian, so that each individual ")#mi("{R_k}")#text(" is going to be of size ")#mi("{O(1)}")#text(" with reasonably good probability, in order for the above exercise to be useful, one needs to bound ")#emph[#text("all")]#text(" of the ")#mi("{R_k}")#text(" ")#emph[#text("simultaneously")]#text(" with high probability. A naive application of the union bound leads to terrible results here. Fortunately, there is a strong correlation between the ")#mi("{R_k}")#text(": they tend to be large together or small together, or equivalently that the distances ")#mi("{\\text{dist}(X_k,V_k)}")#text(" tend to be small together or large together. Here is one indication of this:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7")]#text(" For any ")#mi("{1 \\leq k < i \\leq n}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\text{dist}(X_i, V_i) \\geq \\frac{\\left\\|\\pi_i(X_i)\\right\\|}{1 + \\sum_{j=1}^k \\frac{\\left\\| \\pi_i(X_j) \\right\\|}{\\left\\|\\pi_i(X_i)\\right\\| \\text{dist}(X_j,V_j)}},", block: true)]]

#text("where ")#mi("{\\pi_i}")#text(" is the orthogonal projection onto the space spanned by ")#mi("{X_1,\\ldots,X_k,X_i}")#text(".")
]

#emph[#text("Proof:")]#text(" We may relabel so that ")#mi("{i=k+1}")#text("; then projecting everything by ")#mi("{\\pi_i}")#text(" we may assume that ")#mi("{n=k+1}")#text(". Our goal is now to show that")

#align(center)[#tao-fit-display[#tao-math("\\text{dist}(X_n, V_{n-1}) \\geq \\frac{\\left\\| X_n\\right\\|}{1 + \\sum_{j=1}^{n-1} \\frac{\\left\\| X_j \\right\\|}{\\left\\|X_n\\right\\| \\text{dist}(X_j,V_j)}}.", block: true)]]

#text("Recall that ")#mi("{R_1,\\ldots,R_n}")#text(" is a dual basis to ")#mi("{X_1,\\ldots,X_n}")#text(". This implies in particular that")

#align(center)[#tao-fit-display[#mitex("x = \\sum_{j=1}^n (x \\cdot X_j) R_j")]]

#text("for any vector ")#mi("{x}")#text("; applying this to ")#mi("{X_n}")#text(" we obtain")

#align(center)[#tao-fit-display[#tao-math("X_n = \\left\\|X_n\\right\\|^2 R_n + \\sum_{j=1}^{n-1} (X_j \\cdot X_n) R_j", block: true)]]

#text("and hence by the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|X_n\\right\\|^2 \\left\\|R_n\\right\\| \\leq \\left\\|X_n\\right\\| + \\sum_{j=1}^{n-1} \\left\\|X_j\\right\\| \\left\\|X_n\\right\\| \\|R_j\\|.", block: true)]]

#text("Using the fact that ")#tao-math("{\\left\\|R_j\\right\\| = 1/\\text{dist}(X_j,R_j)}", block: false)#text(", the claim follows. ")#mi("\\Box")

#text("In practice, once ")#mi("{k}")#text(" gets moderately large (e.g. ")#mi("{k=n^c}")#text(" for some small ")#mi("{c>0}")#text("), one can control the expressions ")#tao-math("{\\left\\|\\pi_i(X_j)\\right\\|}", block: false)#text(" appearing here by Talagrand’s inequality (")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text("), and so this inequality tells us that once ")#mi("{\\text{dist}(X_j,V_j)}")#text(" is bounded away from zero for ")#mi("{j=1,\\ldots,k}")#text(", it is bounded away from zero for all other ")#mi("{k}")#text(" also. This turns out to be enough to get enough uniform control on the ")#mi("{R_j}")#text(" to make Exercise ")#link(<tao-fdd33982464b25638709>)[#text("6")]#text(" useful, and ultimately to complete the proof of Theorem ")#link(<tao-65322be4021bbae80eee>)[#text("6")]#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a91dbbd5705f8085aa4b368877768575736327e83b5112c35d161fc17b40dd-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrescaicedo")]], [#link("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/#comment-43798")[#strong[#text("andrescaicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2010")])]

#text("Dear Terry, one of your tags reads “Littlewood-Offord theoremslewood-Offord theorems”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mads Sørensen")]], [#link("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/#comment-43807")[#strong[#text("Mads Sørensen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2010")])]

#text("Mr. Tao.")

#text("I believe something is missing in Theorem~5; what does one have for ")#mi("\\lambda > 0")#text("? :-)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The circular law « What’s new")]], [#link("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/#comment-43888")[#strong[#text("254A, Notes 8: The circular law « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2010")])]

#text("[…] asymptotically almost surely for the least singular value of . This has the effect of capping off the integrand to be of size . Next, by using Stieltjes transform methods, the convergence of to in an appropriate metric (e.g. the Levi distance metric) was shown to be polynomially fast, so that the distance decayed like for some . The gain can safely absorb the loss, and this leads to a proof of the circular law assuming enough boundedness and continuity hypotheses to ensure the least singular value bound and the convergence rate. This basic paradigm was also followed by later works such as that of Gotze-Tikhomirov, Pan-Zhou, and Tao-Vu, with the main new ingredient being the advances in the understanding of the least singular value (Notes 7). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1de735fa27a69a8efe44ff56d5e17917d2a5dbf93881626187879849dc9c239-76f06f3a3d2ea44d49c3b6253babead8b129d6205db6034382ea04835d035fd1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gabriel")]], [#link("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/#comment-43993")[#strong[#text("Gabriel")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2010")])]

#text("Dear Terry,")

#text("Given an n\\times n matrix A (not necessarily hermitian), what is the relation between the p-Schatten norm (0<p<\\infty) and the l_{p} norm of the rows and columns?")

#text("How exercise 3 can be rewritten in this terms?")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/#comment-44004")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2010")])]

#text("The Schatten norm only has a nice relationship with the norms of the rows and columns when p=2; the 2-Schatten norm (also known as the Hilbert-Schmidt norm, or Frobenius norm) is also the l^2 norm of the matrix entries.")

#text("The infinity-Schatten norm is the operator norm, which by Schur’s test is bounded by the geometric mean of the maximal l^1 norm of the rows, and the maximal l^1 norm of the columns. Presumably one can then interpolate with the 2-Schatten norm to get some inequalities for the p-Schatten norm for 2 <= p <= infty (a sort of non-commutative Hausdorff-Young inequality), but that's more or less the only general inequality I am aware of. (Note that for circulant matrices, the p-Schatten norm is basically the l^p norm of the Fourier transform of a row, and the only l^p estimates obeyed by the Fourier transform are given by the Hausdorff-Young inequality, so this suggests that there are no further general inequalities of this type beyond these ones.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cd3293b17fc4102811ce87a71f982a006bff024f4fadf65e5afe06087907fc0-4ba76bf4fed42f8a2ca5c337f3ef79cd4db842b060b6a124a522d20c80bf75fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mustafa")]], [#link("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/#comment-50596")[#strong[#text("Mustafa")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2011")])]

#text("Suppose that ")#mi("X, Y")#text(" are ")#mi("n\\times n")#text(" independent matrices that are chosen with uniform distribution on the sphere ")#mi("S^{n^2 -1}")#text(". I want to find a lower bound on")

#tao-math("\\mathbb{E} ((\\inf_(A, B) | [A,B] = 0) \\left|\\left|X-A\\right|\\right|_F + \\left|\\left|Y-B\\right|\\right|_F)", block: false)

#text("How do I juggle ")#mi("mathbb{E}")#text(" and ")#mi("\\inf")#text("?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1de735fa27a69a8efe44ff56d5e17917d2a5dbf93881626187879849dc9c239-76f06f3a3d2ea44d49c3b6253babead8b129d6205db6034382ea04835d035fd1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gabriel")]], [#link("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/#comment-43994")[#strong[#text("Gabriel")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2010")])]

#text("I also think there is a typo in exercise 3. Shouldn’t it be")

#text("$$")#linebreak()#text(" \\sum_{i=1}^{n}{\\sigma_{i}(M)^{-2}}=\\sum_{i=1}^{n}{dist(X_{i},V_{i})^{-2}}?")#linebreak()#text(" $$")

#text("Thanks!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit")]], [#link("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/#comment-46443")[#strong[#text("Sujit")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2010")])]

#text("The line above Hint in Exercise 1 needs to be fixed ($t$ missing)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e14070aaf61842c0399191a9bb95788359f444b55267237580b942af839d574f-5dbdb8aba3911f781f4bd724deb9f69ac307ad1183c7a744942ebc691dd981f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of weiyu")]], [#link("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/#comment-46493")[#strong[#text("weiyu")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2010")])]

#text("Hi,")#linebreak()#text(" In the paragraph right above Section 5, when you write ")#mi("V_{n}")#text(" for the dual basis vectors, do you mean ")#mi("V_{n-1}")#text("?")

#text("There might be some latex typing error in the formulation of Theorem 6.")

#text("Wonderful notes! Especially studying the smallest singular value can be reduced to studying the projection distances.That is beautiful.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/adaf83934ef9e83041fdd0b5ad16e455b02b1c2e6eb01568a16f9884d8d5f8fd-4cb33d494f6365ff4f85492980c809be6fde69086d5ddfee0bef924d0a084420.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/#comment-229032")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2013")])]

#text("In the proof of Proposition 2, the sparse case, for the final sum to be exponentially small we will need the implied constant from the Erdos Littlewood-Offord bound to be less than 1, or alternatively we can use (3) for small values of ")#mi("k")#text(".")

#text("In exercise 1, I think the denominator of the first term should be ")#tao-math("\\left|\\left|x\\right|\\right|", block: false)#text(", not ")#tao-math("\\left|\\left|x\\right|\\right|^2", block: false)#text(".")

#text("Also in that exercise, I see how a combination of having a lot of energy at low levels and conditioning out large components should do the trick, but I don’t see how the specific assumption ")#tao-math("\\sum_{j:\\left|x_j\\right|\\le \\epsilon^{100}}\\left|x_j\\right|^2\\ge \\epsilon^{10}", block: false)#text(" can work. It seems that only conditioning on ")#mi("Y_j")#text(" for which ")#tao-math("\\left|x_j\\right|\\ge 1/2", block: false)#text(" will still allow the third moment term in the Berry-Esseen bound to be large. If we freeze all variables with ")#tao-math("\\left|x_j\\right|\\ge \\epsilon^{100}", block: false)#text(", this term is under control, but the first term $\\latex r/||x||$ is of order ")#mi("\\epsilon^{-9}")#text(".")

#text("It can be done by saying that ")#mi("x")#text(" is incompressible if ")#tao-math("\\sum_{j:\\left|x_j\\right|\\le \\epsilon^2}\\left|x_j\\right|^2\\ge \\epsilon", block: false)#text(", and freezing all variables ")#mi("Y_j")#text(" with ")#tao-math("\\left|x_j\\right|> \\epsilon^2", block: false)#text(". This gives a final bound ")#mi("O(\\sqrt{\\epsilon})")#text(" rather than ")#mi("O(\\epsilon)")#text(", but this is still enough.")

#text("Typo under exercise 1: flip the inequality in the definition of incompressible vs compressible.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/#comment-229138")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2013")])]

#text("Thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/adaf83934ef9e83041fdd0b5ad16e455b02b1c2e6eb01568a16f9884d8d5f8fd-4cb33d494f6365ff4f85492980c809be6fde69086d5ddfee0bef924d0a084420.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/#comment-229294")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2013")])]

#text("Two more problems:")

#text("One is with the correction I just gave! Getting a bound of size ")#mi("O(\\sqrt{\\epsilon})")#text(" is actually not sufficient to beat the entropy cost of size ")#mi("O(1/\\epsilon)^{n(1-\\delta)}")#text(" from the net. If we define ")#mi("x")#text(" to be ")#mi("(\\epsilon,\\eta)")#text("-compressible when ")#tao-math("\\sum_{j:\\left|x_j\\right|\\le \\epsilon}\\left|x_j\\right|^2\\ge \\eta^2", block: false)#text(", then we get a bound ")#mi("O_\\eta(\\epsilon)")#text(".")

#text("The second problem is with the bound written above exercise 1. With this exponent of ")#mi("n/2")#text(" we still won’t be able to beat the entropy cost (when ")#mi("\\delta\\le 1/2")#text(" at least). We can replace it with a bound ")#tao-math("2^n{\\bf P}(\\left|Y\\cdot x\\right|\\le 2\\sqrt{K}C\\delta)^{n(1-1/K}", block: false)#text(" valid for any positive ")#mi("K")#text(". Taking ")#mi("K")#text(" large enough depending on ")#mi("\\delta")#text(", we can beat the entropy factor.")

#text("Then for the compressible vectors, these all lie within distance ")#mi("\\eta")#text(" of a ")#mi("1/\\epsilon^2")#text("-sparse vector, so we can use a ")#mi("2\\eta")#text("-net on the compressible vectors. Using this net, one is able to solve Exercise 2, in the course of which one will fix ")#mi("\\eta")#text(" sufficiently small, after which one can go back and take ")#mi("\\epsilon")#text(" sufficiently small depending on ")#mi("\\eta")#text(" and ")#mi("K")#text(".")

#text("I think this works – sorry to introduce 2 new parameters! I didn’t see a cleaner way (maybe LiPaRuTo have one).")

#emph[#text("[Corrections implemented, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/#comment-682701")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2024")])]

#text("Hi!")#linebreak()#text(" I’m reading this chapter and I’m currently getting stuck in proving Exercise 2. Would you like to elaborate on how to use the \\eta-net to prove this result? Thank you!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/176d35f294e80f7e32b1a9ca1914c7530ffe95d432c46472720375969279d1dc-1532f691c5b6efa1bfb99cb25b804f9f894c58caee717eb771a5390e2ad037bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/#comment-492039")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("Prof. Tao,")

#text("Is that possible to achieve stronger singularity probability by replacing random sign with uniform integers in [-t, t] for a large enough t?")#linebreak()#text(" I guess in the paper by Bourgain, Vu and Wood they studied the case when t = O(1). But in general can we hope for the singularity probability to be t^{-\\Omega(n)} for arbitrarily large t?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keej")]], [#link("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/#comment-515914")[#strong[#text("keej")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2019")])]

#text("In Exercise 3 (the negative second moment identity), should the power of dist be -2 instead of 2? Then the identity would scale correctly under M -> tM.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/#comment-544807")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")])]

#text("I am wondering if there are studies about the 2-norm (or largest singular value) of a rectangular random matrix M, but with strong dependence structure. Say, M is n by k and is generated by f(X, Y), where one sample iid n samples from the random variable X and k iid samples from Y")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60f68694669350f55d0fdf867409fd250b2e518af44336f2866d35797d26db90-21c485f35426996c98f6d449f131ef64c2350f8178bcda6ed6a608b043cc20d2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dterjek")]], [#link("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/#comment-679108")[#strong[#text("dterjek")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2023")])]

#text("Dear Terence,")

#text("Starting before Exercise 1, Y and x are indexed from 1 to n. Shouldn’t they be indexed from 1 to p?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/#comment-682702")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2024")])]

#text("Dear Prof. Tao:")

#text("Hi! Would you like to hint on how to use the first part of Exercise 2 to prove the second part? I can’t see this very clearly. Thank you!")
]
