// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/06/28/mini-polymath-3-time-and-date/
// Converted to Typst by tao2typ: "2026-10-14T09:11:52.783119+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mini-polymath 3 time and date", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mini-polymath 3 time and date")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 June 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/06/28/mini-polymath-3-time-and-date/")[#text("https://terrytao.wordpress.com/2011/06/28/mini-polymath-3-time-and-date/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Following the results from the ")#link("https://terrytao.wordpress.com/2011/06/09/mini-polymath-3-2011-imo-question/")[#text("recent poll")]#text(" on this blog, the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2011")[#text("mini-polymath3 project")]#text(" (which will focus on one of the problems from the ")#link("https://www.imo2011.nl/")[#text("2011 IMO")]#text(") will start at ")#link("http://www.timeanddate.com/worldclock/fixedtime.html?year=2011&month=7&day=19&hour=20&min=0&sec=0")[#text("July 19 8pm UTC")]#text(", and be run concurrently on this blog, on the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2011")[#text("polymath wiki")]#text(", and on the ")#link("http://polymathprojects.org/")[#text("polymath blog")]#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/06/28/mini-polymath-3-time-and-date/#comment-54813")[#strong[#text("Mini-Polymath 3 « Euclidean Ramsey Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2011")]

#text("[…] Let me update this. The time of the mini-polymath will be July 19 8pm UTC. That is 1pm Los Angeles times. I found that out here. Also see this post. […]")
]
