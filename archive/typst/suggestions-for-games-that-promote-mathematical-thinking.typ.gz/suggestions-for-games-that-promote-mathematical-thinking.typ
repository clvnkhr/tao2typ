// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/
// Converted to Typst by tao2typ: "2026-10-14T15:17:45.277919+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Suggestions for games that promote mathematical thinking?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Suggestions for games that promote mathematical thinking?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 April 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/")[#text("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("A friend of mine recently asked me for some suggestions for games or other activities for children that would help promote quantitative reasoning or mathematical skills, while remaining fun to play (i.e. more than just homework-type questions poorly disguised in game form). The initial question was focused on computer games (and specifically, on iPhone apps), but I think the broader question would also be of interest.")

#text("I myself have not seriously played these sorts of games for years, so I could only come up with a few examples immediately: the game “")#link("http://www.planarity.net/")[#text("Planarity")]#text("“, and the game “")#link("http://home.scarlet.be/~bbonte/factoryballs.html")[#text("Factory Balls")]#text("” (and ")#link("http://home.scarlet.be/~bbonte/factoryballs2/")[#text("two")]#link("http://www.bartbonte.com/factoryballs3/")[#text(" sequels")]#text("). (Edit: Rubik’s cube and its countless cousins presumably qualify also, due to their implicit use of group theory.) I am hopeful though that readers may be able to come up with more suggestions.")

#text("There is of course no shortage of “educational” games, computer-based or otherwise, available, but I think what I (and my friend) would be looking for here are games with production values comparable to other, less educational games, and for which the need for mathematical thinking arises naturally in the gameplay rather than being artificially inserted by fiat (e.g. “solve this equation to proceed”). (Here I interpret “mathematical thinking” loosely, to include not just numerical or algebraic thinking, but also geometric, abstract, logical, probabilistic, etc.)")

#text("[Question for ")#link("http://mathoverflow.net/")[#text("MathOverflow")]#text(" experts: would this type of question be suitable for crossposting there? The requirement that such questions be “research-level” seems to suggest not.]")

#heading(level: 1)[#text("Comments (86)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af45d79e5b098ceb6de38fde366406c35900957c8d6b7df4dd04d7299dee2e9f-577326d8a604a42aebab67c6282a15db482f82e7fc3459676170911250f1955e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim van Beek")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-44654")[#strong[#text("Tim van Beek")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2010")])]

#text("I’d add to chess that the demonstration of a tactical strike, namly that a certain move will win whatever the reaction of the opposing player is, is close to the encounter of your first mathematical proof.")#linebreak()#text(" And the mastery of the game requires hard work, concentration etc. which is close to what learning mathematics is like. The game itself however is more about intuition that about logic (does it sound familiar?).")

#text("The advanced dungeons and dragons games have a complex rule system that require basic probability reasoning and game theory (and the pen-and-paper versions use dodecahedron and icosahedron as dice :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39d3a1b71c24044d03d9bd15dc84b8729a2e13070076d2f32ad39bf852095b8d-a0fed3133bc299a8c9a18e572254cdc5b71b9c7c3d15c2c80ea40aed5941c6aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-44656")[#strong[#text("Miguel")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2010")])]

#text("What about Chess?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39d3a1b71c24044d03d9bd15dc84b8729a2e13070076d2f32ad39bf852095b8d-a0fed3133bc299a8c9a18e572254cdc5b71b9c7c3d15c2c80ea40aed5941c6aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-44659")[#strong[#text("Miguel")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2010")])]

#text("Consider the following modification of standard chess. The rules are the same except that each player makes two moves every turn. Show that there is no wining strategy for black.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b4bee2eb3718639b023b9bbf4ea91bc5f8b13af76bbcf74569860c4e0311d8af-5bb61b84662d47d40ed8ad5e513399e345c76604c317f49ec458ffa8959522d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jair")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-44663")[#strong[#text("Jair")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2010")])]

#text("Here’s a very simple game I invented that can be played with only a pad of paper and two differently colored pencils. It’s essentially a two-dimensional version of that old game of picking a number from one to a hundred and trying to get closest to some unknown number. Two players alternate putting dots of their color inside a square (or circle, or other shape) until they each have a certain number (say three) of dots. Then some kind of random mechanism is used to mark a random point in the shape (for example, closing your eyes and dropping a pencil onto it). Then the players find the point that is the closest to the random pencil mark; the owner of that color wins a point. Thus the strategy is to cover the largest area on the shape in the sense of having a point of your color closest to every point in that region. This can be modified to be played with any number of players.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b936027b16d564ae3bce702ec552aa6f4a3e691b31290889bad8f9a782252787-cd9c9a03ea60126224fd195c4660bf737d509f34928b1ec7f5a7eb17fd180cbf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ron")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-44715")[#strong[#text("Ron")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2010")])]

#text("An alternative angle of attack is to start with the games the kids play and point out how math can inform their choice of strategy in the game.")

#text("In simple facebook-games such as farmville and social city, avid players publish spreadsheets that work out what goods in the game maximize their profits, given its value, production cost and production time. (In social city for instance, it reveals that gamers are rewarded for taking many production jobs with a short timescale, keeping them online for as long as possible. An important part of the game’s business model no doubt)")

#text("In other games, it’s useful for the gamer to consider how many tries are needed to find the right combination of two items, given a choice of n items. The same goes for probability of success in attacking an opponent in certain games.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-44718")[#strong[#text("Carnival of Mathematics #65 « Maxwell’s Demon")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2010")]

#text("[…] who can understand and apply the mathematical ideas. The great Terrance Tao gives some ideas on games that help you develop this mathematical thinking. From Let’s Play Math, you can even have a bit of fun with […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-44724")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2010")])]

#text("Ricochet Robots is a good board game for multiple players involving figuring out how to move “robots” into certain squares on a grid given that they can only change direction when they hit walls. I only played it a couple of times but it was quite interesting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-44725")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2010")])]

#text("Oh yeah, also Chromatron at ")#link("http://silverspaceship.com/chromatron")[#text("http://silverspaceship.com/chromatron")]#text(". Use mirrors and eventually lots of other things to direct laser beams to the right places.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00c3756d89d6ad71353a1f23a4dd32c6332678737eb4bce4b634cc4209147015-f4405fe9f3fbe4c0ae391b47974ac1eb1eb6f8dd6d28c3142fda107bdaa0f01d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erik Christensen")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-44754")[#strong[#text("Erik Christensen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2010")])]

#text("Chess is a fine game that I play with my wife. I like also Sudoku, which is a very effective stimulant of brain functions (‘a sudoku a day keeps dementia away’). I have made a sudoku program, which you can see at my website. This program has many facilities and is very user-friendly. Best regards EC")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33c234ea8634575b8fb3de26ca009aba6c65655c2f96d779c52620a6f1856d04-5428f352c19b9e341f44807e5bc234f6848fca221bb357f5752f211fd4551d7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yiwei")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-44756")[#strong[#text("Yiwei")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2010")])]

#text("It could be interesting if someone designed some chess game for two players, so that the players may go through the textbook of linear algabra in the game (each step is definite) . I call this chess-encoding.")

#text("I recently consider to encode some math textbook into aerobics. If finished, one may learn math by dancing…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8c546338cd1351022872420aa4d61ef38fd72f330859babbcc12d89668e6580f-31ca8ed47e4dc2fd4d4cf88a799333dad9a0e468cf6065409ff51461234bf337.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vinayak")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-44784")[#strong[#text("Vinayak")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2010")])]

#text("I remember reading this article by Douglas Hofstadter where he had described a game that had rules for changing its own rules. I forgot the name of the game though. Does anyone know what I am talking about?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b1af1467332c044b32fef284f74a15e5e0b92a5ab33bd6559de953169e35dba6-7016c2facdd4edbda653da370c7176b83d8130e5c4de046415caa5df1c3f6c84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Zelinsky")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-44787")[#strong[#text("Joshua Zelinsky")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2010")])]

#text("Vinayak, possibly Nomic?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/897613dfedeb1866ced8f842544ec8f89a7b876064f0b66e35eff9001a1586e1-666daf97e215a7c06a91e43d845943f5725b6dffe64d8017f9fff1d2082ec871.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of EastwoodDC")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-44790")[#strong[#text("EastwoodDC")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2010")])]

#text("At risk of repeating some that were previously mentioned, here is a short list of games which demonstrates some fundamental concepts that show up in many other games.")

#text("Nim – Demonstrates the first (last) move advantage.")

#text("Candyland – demonstrates Markoff chains.")

#text("Monopoly – is usually described as a Markoff chain, but can also be view as a Random Walk: ")#link("http://giantbattlingrobots.blogspot.com/2009/01/random-walk-down-monopoly-lane.html")[#text("http://giantbattlingrobots.blogspot.com/2009/01/random-walk-down-monopoly-lane.html")]

#text("Cribbage – A fairly simple example of the basic point scoring framework. and can be thought of as a time-to-failure model (See Birnbaum-Saunder Distribution for metal fatigue). This same framework applies to just about every wargame/boardgame ever made.")

#text("Trivial Pursuit – demonstrates the geometric distribution (moving around) and negative binomial distribution (6 wedges + 1 to win).")

#text("Finally, and with apologies for “blowing my own horn”, this is a topic of particular interest to me. I’ve written about most of the games I mention above on my blog, and I’m always on the lookout for new ideas – And this thread has been absolutely packed with great ideas – Thanks Terence!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-44973")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2010")])]

#text("How about Beyond Waymark: ")#link("http://www.octaspire.com/beyondwaymark/")[#text("http://www.octaspire.com/beyondwaymark/")]

#text("Not an educational game, but extremely challenging and requires planning and logical thinking. Some of the levels, specially the later ones might take quite a long time to pass.")#linebreak()#text(" Contains also some quite challenging and unique(?) game objects like automatons that can/must be programmed by the player to carry out different tasks to change the structure of the level.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59544565fa1561151c757d781165c0a915489326abdc583698e78bd63ee1562b-df080695638b1c27dedf31d94a1a3fa65e211b334b48bf3a92ac8c4e5271ce12.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Patrick")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-45023")[#strong[#text("Patrick")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2010")])]

#text("SET is an awesome game that at least fosters mathematical thought processes even if one doesn’t actually approach it mathematically. There is an iPhone game called Thruple which is a one-player puzzler that is essentially the same mechanic.")

#text("Nurikabe and Sudoku are both heavy on logic. There are lots of Sudoku apps and a few Nurikabe apps (notably Nurikabe Vault).")

#text("Subway is a great set of logic puzzles on the iPhone.")

#text("Untangle Maniak is a Planarity app for the iPhone.")

#text("Math Zombie on the iPhone is great addition practice.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59544565fa1561151c757d781165c0a915489326abdc583698e78bd63ee1562b-df080695638b1c27dedf31d94a1a3fa65e211b334b48bf3a92ac8c4e5271ce12.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Patrick")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-45024")[#strong[#text("Patrick")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2010")])]

#text("Oh, Colorbind is another great logic puzzle for the iPhone.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/19a8a010440dadb2f364bdf7c5fd050f55f1fdd7b5f75f9444ee49bde56e6771-49f2ce622bbeca9b503d64297a7063a0028dd26256c19a1c674aae4bc4ff8ca2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of capitanhook")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-45590")[#strong[#text("capitanhook")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2010")])]

#text("there are lots of pysics games need math in flash websites")#linebreak()#text(" check out")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-45594")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2010")])]

#text("Portal")

#text("“http://store.steampowered.com/app/400/”")

#text("just the 2007 best game")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c4b7c03aa93c9bed7d5f6055cc57f8adc6b8a43617ac768927b4e89893f787b9-6cf2547d0f0394edc48c7b4ec23ea4c7735b58747f16bfe386644bc468f51cf6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Snyder")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-45658")[#strong[#text("David Snyder")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2010")])]

#link("http://blackflip.org/")[#text("http://blackflip.org/")]

#text("a good way to learn logic and goal-oriented reasoning.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a30d20983d2cad6f2a593ca0196d36893e1bfa68ddfdadf253852b0cffb73e9-96ceaf2064466f2ce988a397bc83b388091d4f974c1fe5f32c5621bb106e5318.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gameshed")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-46107")[#strong[#text("gameshed")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2010")])]

#text("I personally recommend Weapons Of Maths Destruction. It’s a flash game where the player have to destroy enemy tanks by answering simple math questions")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16f5a79b0715d154e3f527283f85d0572dcb814e954dbd6b5cdc32e2a21a7570-fe42d275e5dfc629b010c33d7df718f00bac541b978b17e38d540ada76e0ed0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gamesce")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-49638")[#strong[#text("Gamesce")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2011")])]

#text("Furthermore I think that most (normal) children will like Starcraft (2) much more than games like chess, draughts or go")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16f5a79b0715d154e3f527283f85d0572dcb814e954dbd6b5cdc32e2a21a7570-fe42d275e5dfc629b010c33d7df718f00bac541b978b17e38d540ada76e0ed0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of haggle")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-49639")[#strong[#text("haggle")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2011")])]

#text("Oh, Colorbind is another great logic puzzle for the iPhone.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67b1a5a3d1d6b1d2a43360c136c677485d5fec35795173bff22919c3258934da-eca552485863c54e3d4cfbc38a00522444071b66750183e6d9ceac5fd67c514a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Juan Miguel Montes")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-49645")[#strong[#text("Juan Miguel Montes")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2011")])]

#text("I used to play a guessing game with my family for when we would go on trips, that we could play in the care / bus.")

#text("This is not a video game so I’m not sure if it qualifies as a game.")

#text("It is a very simple game, we take turns and whoever is “it” thinks of a product of prime numbers in his head – usually at least products of two digit prime numbers to begin with – and then tells everyone what product of two prime numbers he/she is thinking.")

#text("Everyone then tries to figure out the factors without using calculators or pen and paper, and the first person to guess the factors wins that round and gets to be the next “it”")

#text("So the challenge here is to mentally factor as quick as you can (yes my family is a bit nerdy).")

#text("It might not be a game for most kids itself, but me and my siblings and dad found it fun just for the quirkiness of it!")

#text("If it gets to be too easy then longer digit products of prime numbers can be said. I realize though that it doesn’t have the “crunch” factor that makes games addictive to play, because starting with smaller digit primes (say two digit primes) one quickly runs out of pairs to guess and three digit primes can be harder for most people to be enjoyable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67b1a5a3d1d6b1d2a43360c136c677485d5fec35795173bff22919c3258934da-eca552485863c54e3d4cfbc38a00522444071b66750183e6d9ceac5fd67c514a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Juan Miguel Montes")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-49646")[#strong[#text("Juan Miguel Montes")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2011")])]

#text("sorry for typo, “…that we could play in the car/bus”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/897613dfedeb1866ced8f842544ec8f89a7b876064f0b66e35eff9001a1586e1-666daf97e215a7c06a91e43d845943f5725b6dffe64d8017f9fff1d2082ec871.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of EastwoodDC")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-49647")[#strong[#text("EastwoodDC")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2011")])]

#text("Juan MM> This is not a video game so I’m not sure if it qualifies as a game.")

#text("“Video” is not required to make it a game. As far as promoting mathematical thinking goes, a video/computer aspect may not even be helpful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b65250bb5838c66ca74ae006e465d2c97993d53ae65a1872331c95224125dbc-f63b062d12effd708db263692f4c9be00d3d9dc57248c9b85c47ece75e841b1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of science and math")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-49692")[#strong[#text("science and math")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2011")])]

#text("Playing number and math games with children help children to grow mathematical reasoning and increases interest in mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c56c5954b332368e8c5fd735ee4a961e1162458080ad1093e09e2a66ae6502d4-ebd8fc4fd68857d18bc26d53ca9a59c42ad2e640f51df1de893b4c9f6363ae49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Niklas F")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-65396")[#strong[#text("Niklas F")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2011")])]

#text("I would really recommend Impasse.")#linebreak()#text(" ")#link("http://www.bartbonte.com/portal/impasse.html")[#text("http://www.bartbonte.com/portal/impasse.html")]

#text("It really forces you to think ahead in discrete steps.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/529e2364f6b46d373193db36edf186e235bb21bffe9e7cb80e2f8fec21e72cdc-2f2699526767c7fd465fb0e2b856ea74ccacd9c14e22cbf70bee8907241a62d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jake wak")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-138346")[#strong[#text("jake wak")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2012")])]

#text("Check out spanish sites too…")#linebreak()#text(" ")#link("http://www.frip.com")[#text("http://www.frip.com")]#linebreak()#text(" ")#link("http://www.juegosdedisparosgratis.com")[#text("http://www.juegosdedisparosgratis.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f5d35f8555993056990a9fbcdee0f726ca5ede7e41fe4db74c6aedb82983715-e7d804bb6a0a7ff3b926b52409a8ffc430478c82fb0dc61d3b1021dc2cd7cbac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pramod Ponnaluri")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-451798")[#strong[#text("Pramod Ponnaluri")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2015")])]

#text("Check out Three Sticks. It’s a highly creative and challenging board game that is based on geometry. ")#link("http://igg.me/at/threesticks")[#text("http://igg.me/at/threesticks")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02d64c58e528929265f1725dc64d74f1f98c25551cb22b58546c7adffc456f7e-e8eb8611b4d43726fe19b955b5db2b0478694f2614886855d6e05cad2940a233.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 60to5 (@60to5)")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-2/#comment-465703")[#strong[#text("60to5 (@60to5)")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2016")])]

#text("New streamlined basic arithmetic online game. Check out ")#link("http://60to5.com")[#text("http://60to5.com")]#text(" where you get 60 seconds to answer 5 questions. How far can you go?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44485")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("Ed Pegg Jr.’s favorite puzzle game (and mine as well) is Deadly Rooms of Death.")

#link("http://www.drod.net/")[#text("http://www.drod.net/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d462171b316f271710c9d465db8dcc14eaef376a3a899b0a5d83b31dd811715-4879073d7a2217c811484ecdeafc8a7fccaa7566eb6b4e162247451b1380e64b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Todd Trimble")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44488")[#strong[#text("Todd Trimble")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("Do you want games where children are *likely* to discover mathematical structure in the course of play? For example, the first example that came to my mind is ")#link("http://en.wikipedia.org/wiki/Dots_and_Boxes")[#text("Dots-and-Boxes")]#text(", which turns out to be mathematically deep, but it’s not clear how many kids get beyond the stage of making moves at random unless they are given hints. Similarly, there’s ")#link("http://en.wikipedia.org/wiki/Sprouts_%28game%29")[#text("Sprouts")]#text(", and there are others described in ")#link("http://en.wikipedia.org/wiki/Winning_Ways_for_your_Mathematical_Plays")[#text("Winning Ways")]#text(", which need only paper and pencil, but the same issues may apply.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44489")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("Hmm, good point; merely having mathematical structure in a game may not be sufficient to actually encourage a child to think mathematically, if it is too difficult to do so or if a random strategy (or greedy algorithm, etc.) is already fairly effective. (I suggested Rubik’s cube above, but this has the same problem: the probability that a child will learn enough group theory to solve the puzzle by reasoning alone is close to zero.)")

#text("So I guess the ideal game for promoting mathematical thinking would have to walk a fine line: difficult enough that random play or other simple strategies will soon become insufficient, thus forcing one to think more systematically, but not so difficult that a child playing the game will get discouraged long before obtaining the payoff for such systematic thinking.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44490")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("Incidentally, there is a parallel discussion thread of this article at my Buzz page:")

#link("http://www.google.com/buzz/114134834346472219368/bBd3tyNsjvC/Suggestions-for-games-that-promote-mathematical")[#text("http://www.google.com/buzz/114134834346472219368/bBd3tyNsjvC/Suggestions-for-games-that-promote-mathematical")]

#text("Suggestions made there include Sudoku, Lights Out, Twenty-Four, and virtually any card game. (Blackjack, for instance, is remarkably good at teaching its players what combinations of numbers add up to 21.)")

#text("I recall playing “Think ahead” many years ago, which is particularly pure demonstration of the minimax principle, and can be found online for instance ")#link("http://gamescene.com/Think_Ahead.html")[#text("here")]#text(". Sokoban is another good game, though I would classify it more as a puzzle game than a mathematical game ")#emph[#text("per se")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc52ea2e6118796f73fc9f3668c1d217b5ff6ade497fb59a5ea4f12103b729a8-4c71f2e16e7dbdc63b30d78b9f7611dde52818e5548438d0b07e80a778649629.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elizabeth")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44579")[#strong[#text("Elizabeth")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2010")])]

#text("I agree on card games, and I think Cribbage is a particularly good choice because developing a strategy involves thinking through various permutations of cards and reasoning probabilistically about cards you have yet to see. Yet it’s no so complex that kids who are used to card games can’t develop reasonable rules for playing.")

#text("Russian Bank is another good one since, although the rules are simple, it requires thinking through many moves in advance (since you have to rearrange certain cards in the fewest moves possible).")

#text("I’ll also add that, in my experience, adults who don’t play many card games themselves vastly underestimate the sophistication of card games that children can pick up at an early age, with repeated exposure. Start with simple games that have elements used a lot (e.g., Crazy 8s for picking up and discarding; Hearts for taking tricks; Gin Rummy for trade-offs between different ways of grouping cards) and once those elements are in place, kids can easily learn much more complicated games.")

#text("If, however, your family culture involves letting kids win a lot, they will have a harder time with this since they won’t get accurate feedback on strategies.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44491")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("definitely chess")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44492")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("There is the card game SET in particular, and the following article by Peter Norvig discusses some mathematical aspects that may occur to someone in normal play: .")

#text("Bridge is probably a good one. Any games of chance or betting (cards or otherwise). There are also strategy games like Risk and the like that promote strategic thinking with some implicit mathematical flavor (minimax ideas, game theory, …).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d27aa9edfbfb4aa0602ad0d54cc0fe50eac90cf32ae67bd9d76ea53f6116b8ee-4c855d4f11ae5cd918a3135730c28aa57e709a674260716f45473b1a6186bef3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Clemens Koppensteiner")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44493")[#strong[#text("Clemens Koppensteiner")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("While I cannot think of any good purely mathematical games for children (what age are we talking about? probably too young to suggest Go?) here are some related suggestions:")

#text("For me THE classic puzzle game is ")#emph[#link("http://en.wikipedia.org/wiki/The_Incredible_Machine")[#text("The Incredible Machine")]]#text(" (now available at ")#link("http://www.gog.com/en/gamecard/the_incredible_machine_mega_pack")[#text("gog.com")]#text(". It forces systematic thinking, while still being fun to play with all those cats running around.")

#text("The ")#link("http://en.wikipedia.org/wiki/Myst")[#emph[#text("Myst")]]#text(" games (also available at gog.com) have some mathematical puzzles.")

#text("In “real life playing”, ")#link("http://en.wikipedia.org/wiki/Lego_Technic")[#text("Lego Technic")]#text(" is more mechanics than math, but it does train the three-dimensional thinking.")

#text("Not technically games, there are lots of ")#link("http://en.wikipedia.org/wiki/Educational_programming_language#Children")[#text("programming languages for children")]#text(". Of course, ")#link("http://en.wikipedia.org/wiki/Lego_Mindstorms")[#text("Lego Mindstorms")]#text(" is a combination of programming and mechanics. (I never used it, so I do not know how powerful and fun it actually is.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44494")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("Sorry, the Norvig link was cut out. It’s at ")#link("http://norvig.com/SET.html")[#text("http://norvig.com/SET.html")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d462171b316f271710c9d465db8dcc14eaef376a3a899b0a5d83b31dd811715-4879073d7a2217c811484ecdeafc8a7fccaa7566eb6b4e162247451b1380e64b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Todd Trimble")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44495")[#strong[#text("Todd Trimble")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("Actually, I turned my 3rd grade son on to ")#link("http://en.wikipedia.org/wiki/KenKen")[#text("KenKen")]#text(", which is a 1-person puzzle, and he finds it fun. For kids that young, the 4 x 4 and 5 x 5 grids are probably sufficient, and they can be very gratifying to solve.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44496")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("Starcraft(and soon Starcraft 2) is great for exposing older kids to game theory and decision theory. See course syllabus from a Berkeley Decal class here:")#linebreak()#text(" ")#link("http://sc2portal.blogspot.com/2009/02/uc-berkeley-starcraft-decal-syllabus.html")[#text("http://sc2portal.blogspot.com/2009/02/uc-berkeley-starcraft-decal-syllabus.html")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Noud")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44520")[#strong[#text("Noud")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2010")])]

#text("I completely agree with this.")

#text("Starcarft is by far some of the hardest games I ever played. It is an RTS with so many choices and you have to make these choices fast. When I started playing Starcraft I discovered that I was able to make decisions much faster then I was before. Especially harddecisions, because you have to make them very fast.")#linebreak()#text(" Also game theory is very important in Starcraft. If you are playing it on a medium/high level, you must have (and there are!) some rather complex strategies.")

#text("On first sight Starcraft does not seem to have any mathematics involved. However, it is a hard game to play and it forces you to really think about the moves you do. You almost always lose a game because you make wrong moves. So it certainly develops your quantitative reasoning and mathematical skills.")#linebreak()#text(" Furthermore I think that most (normal) children will like Starcraft (2) much more than games like chess, draughts or go.")

#text("Also this game is still played a lot in Korea, it still has a large progamer scene. If you are interested, here is a good example of some strategy behind Starcraft: ")#link("http://blip.tv/file/3496145")[#text("http://blip.tv/file/3496145")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b9d3d590d2841f1b860536c4a581927ddd44c835409f9e639103146ba8df3bd-9004082287cd6d01678c2786627b9d5ee63984ec6b07eaee297dc4fe76bc1e91.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Franciscus Rebro")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44497")[#strong[#text("Franciscus Rebro")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("Nim, of course!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f496d414839b477b09dad05804da1160cb30045e9e564d49cec05b99adafc338-cf858b87e63b5eb097ec7faaa8cfb7044db6e94c133ef3110a1e109143dc00b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Giudici")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44502")[#strong[#text("Michael Giudici")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("I agree. We use Nim here at UWA as an activity during visits by school students. It works well. Occasionally we use Northcott’s game instead in case we have students who have already seen Nim.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d75bc6de91d6ff22b7be2419de05948c2b219b3960c7accaabec5a7cdcb7efd-bc86511c57fd21f2f2b1c9e0b7e12fee5a62abbffc792877fcb8eea580ba1115.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Drake")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44498")[#strong[#text("Dan Drake")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("When these kinds of questions come up, I try to think broadly. If you’re looking for games whose *purpose* is to teach math, lots of “Winning Ways”-style games are great. If you’re looking for a game whose purpose is fun, and something you will play over and over again, I’d look at some of the so-called “Euro games” that you find at, say, ")#link("http://boardgamegeek.com")[#text("http://boardgamegeek.com")]#text(".")

#text("Favorites of mine that are pretty mathematical:")

#text("Lost Cities (")#link("http://boardgamegeek.com/boardgame/50/lost-cities")[#text("http://boardgamegeek.com/boardgame/50/lost-cities")]#text(")")

#text("6 Takes (")#link("http://boardgamegeek.com/boardgame/432/category-5")[#text("http://boardgamegeek.com/boardgame/432/category-5")]#text(")")

#text("Battle Line (")#link("http://boardgamegeek.com/boardgame/760/battle-line")[#text("http://boardgamegeek.com/boardgame/760/battle-line")]#text(")")

#text("Slightly less mathematical, but very good: Hive (")#link("http://boardgamegeek.com/boardgame/2655/hive")[#text("http://boardgamegeek.com/boardgame/2655/hive")]#text(")")

#text("I second the suggestions for good card games. Games like Bridge and Sheepshead require a lot of logic, deduction, and strategy. Plus they’re fun! Your friend is looking for games for children, so teach them fun games and as they play, show them how to use quantitative reasoning to play better.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e3c293498cf0e10850e1f6d1d8f006a354e5491ad009449759e122425bfbb772-467fe5b33078d97d401b27fa7e721dd6310b1509f99266c0532c95044c117b36.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Schnitzius")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44499")[#strong[#text("Mark Schnitzius")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("I was watching a travel show a while back — they were in Korea, and a group of people were playing a drinking game. The way it worked was, one person was “it”. This person says something like, “ready, set…” then points at one other player and calls out a number (call it x) between 2 and n (where n is the number of people playing). At the same time, everyone else also points at one other player. Then, for whatever number got call out, you jump that many steps from the “it” person, and that person has to drink. So if I call out “two” and point at Joe, and Joe points at Bob, then Bob has to drink.")

#text("I think the game is pretty interesting, mathematically, and could easily be adapted to be a game for kids. It’s especially interesting when you relax the x<=n rule. One interesting thing I found: with n=3, if you call x=7, you are guaranteed to stick the player you initially point at, no matter who points to whom.")

#text("Some interesting questions to ponder about it:")#linebreak()#text(" 1. Without the x<=n rule, what is the smallest number the 'it' person can call that guarantees he will not stick himself?")

#text("2. With the x<=n rule in place, what is the safest number to call for any given n, if the other players choose randomly?")

#text("3. If you're TRYING to lose, what number should you call, both with and without the x<=n rule?")

#text("4. What are the odds of winning or losing, for all the answers above?")

#text("Hint for questions 1 and 2: prime numbers come in to play!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44500")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("I haven’t seen anyone mention Yahtzee yet. Besides just fast addition and multiplication (adding values on the dice) it also teaches probabilistic thinking.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2daa964c2a4dbcdf9ec1938041f3c79a3a19dd3abbccfadefebb52e5641f26b9-3b2dfe4e72dd1e617c332fdfc69af7256e44b65d582e8ef555edf9d2dc29b902.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trevor Owens")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44501")[#strong[#text("Trevor Owens")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("Not sure if it is what you are looking for, but The JASON Project’s EcoDefenders game has some nice light weight numerical data analysis in it.")

#link("http://www.jason.org/digital_library/8241.aspx")[#text("http://www.jason.org/digital_library/8241.aspx")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/897613dfedeb1866ced8f842544ec8f89a7b876064f0b66e35eff9001a1586e1-666daf97e215a7c06a91e43d845943f5725b6dffe64d8017f9fff1d2082ec871.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Eastwood")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44503")[#strong[#text("Dan Eastwood")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("Here are some suggestions:")

#text("Graph Paper Race – basic vectors")#linebreak()#text(" ")#link("http://giantbattlingrobots.blogspot.com/2009/01/graph-paper-race.html")[#text("http://giantbattlingrobots.blogspot.com/2009/01/graph-paper-race.html")]

#text("Itatsi – a Scrabble like game, demonstrates probability and genetic algorithms (sort of)")#linebreak()#text(" ")#link("http://itatsi.com/")[#text("http://itatsi.com/")]

#text("Candyland and Monopoly demonstrate Markov chains")

#text("Attack Vector Tactical – Space combat with real physics (maybe for the older kids)")#linebreak()#text(" ")#link("http://www.boardgamegeek.com/boardgame/6767/attack-vector-tactical")[#text("http://www.boardgamegeek.com/boardgame/6767/attack-vector-tactical")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5cf273ec4a10dec4173ff0b323e853d0f052ecfbd813b914a0c64d5d91ef2e3-0873da587afe1b333d14da0d1982bea855075657c779de7a7f7779d52c138e97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kelly Johnson")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44504")[#strong[#text("Kelly Johnson")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("Indeed, Nim is great for thinking strategically, while remaining simple enough for kids to learn relatively quickly:")

#link("http://www.transience.com.au/pearl.html")[#text("http://www.transience.com.au/pearl.html")]

#text("and sequels:")

#link("http://www.transience.com.au/pearl2.html")[#text("http://www.transience.com.au/pearl2.html")]

#link("http://www.transience.com.au/pearl3.html")[#text("http://www.transience.com.au/pearl3.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e85d428bafa38673739a8d134ce14cfd9f0941951aa01b8763f0df958d070130-80d3f4247dc18d4da2c4b594e91fe383bb6517ebc7672500259c6abb90ff6b2c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nathan Dunfield")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44505")[#strong[#text("Nathan Dunfield")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("Perhaps these are a little too obviously educational, but I like Jeff Weeks’ various ")#text("topology games")#text(". Most are fairly simple (e.g. tic-tac-toe, chess, maze games on torus/klein bottles), though the new ")#link("http://www.geometrygames.org/HyperbolicGames/index.html")[#text("hyperbolicgames")]#text(", which includes pool on your favorite compact hyperbolic surface is pretty challenging.")

#text("When I was a kid in the late 80s, I loved ")#link("http://en.wikipedia.org/wiki/Robot_Odyssey")[#text("Robot Odyssey")]#text(", which has to be one of best educational games of all time; sure, you learn stuff but the setup is so good it doesn’t feel at all artificial in the “solve the math problem to get to the next level” way. There’s a modern port of this called ")#link("http://mysite.verizon.net/thomasfoote/DQ/index.htm")[#text("DroidQuest")]#text(", though I haven’t actually tried it out.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mmailliw/william")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44513")[#strong[#text("mmailliw/william")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("If it’s a game on a torus you want, wouldn’t Asteroids do the job as well as anything?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4aa6d4d04f406ca02d8190b00165ef50e61ec2a75dc6e65f6ff09d0d89d80e1f-57ec1f1c3d6bfe1192022fa96614c73933d7ac7b90255739962c927a6b9a3618.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew O'Meara")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44506")[#strong[#text("Matthew O'Meara")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("Hi,")

#text("I highly recommend euro style board games such as Settlers of Catan. The goal objectives are often quite subtle. I believe they help develop creativity and thinking clearly about what strategies will achieve objectives on different scales–skills that are valuable for mathematical thinking.")

#link("http://www.boardgamegeek.com")[#text("http://www.boardgamegeek.com")]#text(" is a good place to start.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/93473a81d2e304982d34ad2e882dbec50863a0fd2242986ffa76c43aa5254597-c8beac965d82bd55033583583bb03a2b15f6f89e177b6afb66fc5c74217312b5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hal")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44508")[#strong[#text("hal")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("These are way outdated, but when I was a kid, the following games for the Apple II series were VERY fun and quite mathematical…. ")#link("http://www.abandonia.com/games/834/GertrudesSecrets")[#text("Gertrude’s Secrets")]#text(", ")#link("http://www.abandonia.com/en/games/831/Rockys+Boots.html")[#text("Rocky’s Boots")]#text(" (one of my all time favorites — basically teaching logic) and another that I can’t remember the name of or find, but it involved shooting ball through tubes that turned. Someone also pointed out the Incredible Machine, which was a bit past my childhood but still tons of fun.")

#text("I think all those examples are fundamentally different than card games / board games. They’re also different than “solve this math puzzle to get ammo so you can continue shooting people”, which is just annoying. They’re fundamentally thinking tasks, but the designers found a way to wrap really fun games around them (or at least really fun to me as a kid :P).")

#text("I don’t know of any modern examples (sorry, I know that was the point of this post!), but I think you’re probably better off looking at education software that’s fun, rather than games that have been retrofitted to include something educational. The latter was always a giant disappointment in my kid-eyes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b1af1467332c044b32fef284f74a15e5e0b92a5ab33bd6559de953169e35dba6-7016c2facdd4edbda653da370c7176b83d8130e5c4de046415caa5df1c3f6c84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Zelinsky")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44510")[#strong[#text("Joshua Zelinsky")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("Zendo is an excellent game which can be played at very different levels of difficulty. Essentially the game works in which one player makes a rule for what configurations of pieces are valid (the rule might be something like a configuration is valid if it has a prime number of pieces, or is valid if it doesn’t have a blue piece, etc.) The goal of the other players is to then present configurations which get split into valid and invalid. If a player correctly figures out the rule, they then get to make the next rule. (And no you can’t make rules that involve order of play, who plays or the like.)")

#text("The game in some ways focuses more on the scientific method but also teaches logic very well. It can be played at fairly young ages (say around 10 or so) and is a lot of fun for adults as well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jo in OKC")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44512")[#strong[#text("Jo in OKC")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("There are 3 different Zoombini software games that are fun and that teach some math along the way (I remember binary in one activity, exploring combinations in another).")

#text("For non-software games:")#linebreak()#text(" Play Dominos. Scoring requires adding and knowing multiples of 5. To make it harder, we switched which multiples score (like switching to multiples of 8 instead of multiples of 5) and switched from double-6 dominos to double-9 or double-12 dominos.")

#text("Hi, Ho, Cheerio! is a board game that teaches simple addition and subtraction (mostly +1 and -1, although you can lose your whole basket) up to 5. It’s meant to be one of the first board games a child has.")

#text("My daughter loved being the banker in Monopoly Junior. The Junior version had a smaller board and no choices at a turn (you HAVE to buy the house, etc.). Being the banker in regular Monopoly would also have the same benefits.")

#text("We also really enjoyed a 3D tic-tac-toe game that had 4 layers of 4×4 boards.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mmailliw/william")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44514")[#strong[#text("mmailliw/william")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("I’m amazed that no one has suggested Tetris yet!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hoeteck")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44515")[#strong[#text("hoeteck")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("I discovered Rush Hour the semester I was at IPAM; it’s available as an iPhone app too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44517")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("There is a question similar to the one asked here on Math Overflow:")

#link("http://mathoverflow.net/questions/13638/which-popular-games-are-the-most-mathematical")[#text("http://mathoverflow.net/questions/13638/which-popular-games-are-the-most-mathematical")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0fd56049a8189a380fda42273fee0bc2b9ce50a7a224700afce1fe96194008-d71b4d207f9bb85a02159d9eb02ffc3ded2bfbce61de425e7d3d85b4f53db867.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uwe Stroinski")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44518")[#strong[#text("Uwe Stroinski")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2010")])]

#text("I frequently use Ubongo with its countless variants")

#link("http://en.wikipedia.org/wiki/Ubongo")[#text("http://en.wikipedia.org/wiki/Ubongo")]

#text("Later then the alread mentioned Set (Mensa Select 1991)")

#link("http://en.wikipedia.org/wiki/Set_%28game%29")[#text("http://en.wikipedia.org/wiki/Set_%28game%29")]

#text("Both are easy to learn with a direct relation to mathematics.")

#text("A popular “mathematical” game is Dominion (Mensa Select 2009)")

#link("http://en.wikipedia.org/wiki/Dominion_%28card_game%29")[#text("http://en.wikipedia.org/wiki/Dominion_%28card_game%29")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d573031373cc3aad07c93d20757b474fde40fd1b82df4caba12e0c34b87cace0-d99a015d94be725eb2da9d6e320c7a5c2015d1564862f381492a74f8dc333d26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Olof")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44519")[#strong[#text("Olof")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2010")])]

#text("I think Connect Four has some mathematical value, and it’s the kind of game that eases one into developing strategies. There are strategies of various complexities, and it has the added bonus that one is quite likely to find simple strategies even by playing somewhat randomly. Once one has won using or been defeated by a simple strategy, even if it arose randomly, I think one is almost certain to recognise it as a strategy and try to find others.")

#text("Guess Who? also involves logical thinking and is very accessible. Though I don’t think strategies jump out at one quite as readily there.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5c1e92edd989197e8184760d8353564b081d7294c72392ed01852c3cbd00a0fc-be36c809338bff845d7694ffd3279427f2125ba0e61806c4490895dc99646ad4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maria H. Andersen")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44524")[#strong[#text("Maria H. Andersen")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2010")])]

#text("I’ll suggest that readers who are interested in the idea of using games to teach math (not practice math, but TEACH it), watch the presentation I recently did at TexMATYC called “Playing to Learn Math?” … it can be found on Prezi: ")#link("http://prezi.com/r2lbb3lfomg5")[#text("http://prezi.com/r2lbb3lfomg5")]

#text("In particular, I’ll suggest two games which are stellar for pushing the mathematics to be something woven into the gameplay:")

#text("Flower Power (teaches ordering of fractions, decimals, and percents through wickedly addicting gameplay)")

#text("FactorTris (teaches idea of multiplication as an area and encourages knowledge of many factor pairs for any given number)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da73b19ebf16f1442188b0821b68d80f3f49c354cb218629e9e1ef456c215117-17979c364c9bcd4f81dc6c1873bc6d57de5100258a4c27a34d567fb40334b085.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44525")[#strong[#text("Henry")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2010")])]

#text("No mention of poker? Of course, it has a gambling element that might be considered unsavoury by the parents, but this can hopefully be downplayed. The basics help with arithmetic (counting chips). Beginner’s strategy helps with probability (calculating the probability of certain cards falling in order to make better decisions). More advanced strategy helps with algebra (finding the values of variables required for a play to be profitable). More advanced analysis helps with calculus (finding Nash equilibrium for certain simplified “toy games”, see The Mathematics of Poker, Bill Chen and Jerrod Ankenman (2006)). There are also statistical and financial skills that could be taught but those are more specific to professional poker players, which might be pushing the boundary too much,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da73b19ebf16f1442188b0821b68d80f3f49c354cb218629e9e1ef456c215117-17979c364c9bcd4f81dc6c1873bc6d57de5100258a4c27a34d567fb40334b085.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44526")[#strong[#text("Henry")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2010")])]

#text("*Nash equilibria")

#text("*boundary too much.")

#text("Note that is by no means an exclusive list, there are some others I’m likely forgetting, plus certain “abstract reasoning” qualities that Terry can probably define better than I can.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44527")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2010")])]

#text("Fair Games, R. Guy")#linebreak()#text(" Winning Ways for Your Mathematical Games, E. Berlekemp, J.H. Conway, R. Guy")#linebreak()#text(" Dots and Boxes, E.Berlekemp")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44528")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2010")])]

#text("Backgammon’s a pretty obvious one. To get any good at it, you have to understand how and when to take risks, and to understand that you need to get a good feel for probability (or, better still, actually work out some probabilities). The doubling cube is particularly good in that respect: if you can understand why accepting a double may be the right thing to do even when your chances of winning are under 50%, then you must have learnt some maths.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78bd6ccfc0b6099ec8a34c9b60a435c0141b0b62b146e028cb0c1dbde8d29faf-7f6a5f27a7043225c441d2411053411801684fb1acf03987843408e890e8ac5b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amirs")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44535")[#strong[#text("amirs")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2010")])]

#text("Hi")

#text("some games:")#linebreak()#text(" ")#link("http://www.mathplayground.com/logicgames.html")[#text("http://www.mathplayground.com/logicgames.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44536")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2010")])]

#text("I second Zoombinis, and also Dr. Brain (")#link("http://en.wikipedia.org/wiki/The_Lost_Mind_of_Dr._Brain")[#text("http://en.wikipedia.org/wiki/The_Lost_Mind_of_Dr._Brain")]#text(")")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b9d3d590d2841f1b860536c4a581927ddd44c835409f9e639103146ba8df3bd-9004082287cd6d01678c2786627b9d5ee63984ec6b07eaee297dc4fe76bc1e91.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Franciscus Rebro")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44564")[#strong[#text("Franciscus Rebro")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2010")])]

#text("The Lost Mind of Dr. Brain is awesome! Totally blew my mind when I was like 9.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ff16e931e85f1c3cd85ccc7a7c84890c3808f939c23a90b6d6a207accf032755-bea49347367a21cd6f917516ced7fd450f72ce33509dc4514053f0e3ceb654a1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kit")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44537")[#strong[#text("kit")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2010")])]

#text("on ")#link("http://www.hankit.com")[#text("http://www.hankit.com")]#text(" there are 3 interactive games that require reasoning skills: Rubiks Cube, Sliding Puzzle, and Tower Of Hanoi.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fh")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44539")[#strong[#text("fh")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2010")])]

#text("“Settlers of Catan” is great for kids. Mathematical Thinking, such as figuring out the probabilities for the sums of two dice, computing expectations, …will give you an advantage, but even if you you understand them, the game remains fun. Also teaches kids lot about economics – scarcity, bargaining…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44540")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2010")])]

#text("1) I personally would have no trouble with a post like this in MathOverflow. It is valid as a math education question; one could even argue that it has direct research value.")

#text("2) On the other hand, in my experience, games per se are never quite a perfect fit for mathematical thinking at any age. To be sure, there is a very interesting intersection, but my experience is that children soon encounter the same dichotomy as adults between games and mathematics. I would see games more as a way to motivate mathematics than as a way to teach it.")

#text("3) So in that spirit, I think that the Rubik’s cube is excellent. Yes, almost no one will learn group theory in isolation from the Rubik’s cube, but that’s the wrong question. It’s an excellent motivation.")

#text("Other examples of such games that come to mind are Set, Twixt, and Mastermind. They are each small games that can motivate great topics in mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44544")[#strong[#text("Top Posts — WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2010")]

#text("[…] Suggestions for games that promote mathematical thinking? A friend of mine recently asked me for some suggestions for games or other activities for children that would help […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44545")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2010")])]

#text("I have never played this game, it’s just an idea of a two player game to try to understand what a prime is. It may not work.")

#text("Get a sand timer and a large number of blocks. When time starts, player one takes a big handful of blocks, and player two tries to arrange these blocks in a rectangle. As soon as a rectangle is made, you keep only one row in the larger dimension (if player 2 made a 4 by 7 rectangle, you keep 7). Then player one tries to arrange these in a rectangle and the game continues until time runs out.")

#text("(When modified slightly, you can play the game over any ring and primes are exactly the winning strategies… I’m just curious whether the above version actually works in real life — it might not.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88f960abb240071ec5c4aa54d3187e9bff3dd84aad66fe70ee95485f3968f7a3-718b4ba8ad69503b5648093eb26b0a75a4d2d615a5c0531b4b690665c89fe58c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Patrice Ossona de Mendez")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44548")[#strong[#text("Patrice Ossona de Mendez")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2010")])]

#text("I would suggest the game of hex and, of course, go.")

#text("Both games train topological views and display local/global and long term interactions. Both allow a system of handicap, specially go which allows interesting games betweens players of really different levels.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44549")[#strong[#text("Randomly Found Software: Planarity « Dijkstrabühl")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2010")]

#text("[…] Found Software: Planarity Planarity (via) is a nice game where you get a graph with intersecting edges and have to move its vertices such […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b969614ac837f7ac2e79c19069c6394596353daa034c32391d0f585eb6647ffb-03c1f9181bc7e7c77d77c765018c7b4a27079d9ef1d7dda6072497cc0c6d74c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter J McNamara")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44552")[#strong[#text("Peter J McNamara")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2010")])]

#text("Unfortunately in my experiene, your average player of a game will not end up appreciating its mathematical subtleties, even though an understanding of such almost always improves your gameplay. A more advanced example is diplomacy, with its connections to game theory (in the mathematical sense of the term). It is possible to reach endgame positions where a player has a strategy that wins with probability p for all p less than 1 (but not a guaranteed win). The tradeoff is that as p tends to 1, the expected time to winning the game tends to infinity. I don’t know what percentage of players end up understanding and appreciating something like this, but I’m not overly optimistic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b969614ac837f7ac2e79c19069c6394596353daa034c32391d0f585eb6647ffb-03c1f9181bc7e7c77d77c765018c7b4a27079d9ef1d7dda6072497cc0c6d74c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter J McNamara")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44554")[#strong[#text("Peter J McNamara")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2010")])]

#text("and regarding mathoverflow, I would recommend not crossposting, for the major reason that it will fork the discussion. (and that big list questions are frowned upon by a sizable collection of mo users).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14b36f2aa6730add862d5d74448029f7a7ab6aed5430bb6e329c51bc4d98343-8b4979f72051d7abd84ae73d0102b308717f3e804cbcac729f52c2b087233dad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of popodepok")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44558")[#strong[#text("popodepok")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2010")])]

#text("We all know that in the early days children are spending too much time watching TV. But now days the problems has been change. Currently children are more and more connected to the computers, especially when they are playing computer games, for parents this is certainly troubling because they assumed that computer games are not useful")

#text("especially with the number of in-game content that is deemed inappropriate for young children such as violence and nudity. this is of course frustrating for parents who feared the disruption of their children’s psychological development.")

#text("But In reality, children can benefit from computer games. For example, students may use the flash game that offers a mathematical test. They are more interested in solving mathematical equations in documents with full color graphics and sound. Computer interactive quiz can also help students remember their tables faster. There is a lot off educational software that parents can download for free or buy it from the site.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2186afb848ba3670eedc71581b31eef59eda3363155ad53e313580cc1bc7dd44-f3a14379cd0e10a915c9d96ebd3d08121156937f9793c3e96efa660ee69516b5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marten Saflund")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44568")[#strong[#text("Marten Saflund")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2010")])]

#text("Excuse me for this shameless plug, but I think my game Chrome-8 qualifies. ")#link("http://www.chrome-8.com")[#text("http://www.chrome-8.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1accc0835429874bf3cb844178ec58aea6de9dc0bd9cc92f829324a5b671f5e6-b02aa94fbf6188af04a16952d9bf11580528aa2f3fabace0f85b9debe21085f5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44578")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2010")])]

#text("An excellent program would be Reasoning Mind. It’s an interactive software program for young children (starts at grade 2 and moves up to, I think, grade 8). The CEO is a former Russian mathematician who came to the US in the early 1990s. The software was originally created for his son (now at Cambridge), but they expanded it for all children as well. The curriculum is largely based off the work from Russian mathematicans and educationa specialists. The program allows children to work at their own pace, and it gives very accurate feedback of what a child’s strengths and weakenesses are. Children can be enrolled through their school (if their school is a participating one), or individually–if they have reasonably fast internet access. I know Paul Sally Jr. (of the U of C) and James Milgram (of Stanford) have both endorsed it. This might be a viable option. They have a website: ")#link("http://www.reasoningmind.org")[#text("http://www.reasoningmind.org")]

#text("I would strongly suggest you look at the “News” articles to get an idea of what the program is about. Also they have a 20 minute video on google video, explaining the program, with some amusing interviews with students participating in the program.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/05cac2aba5ce74483aba96c4fc571ecb0b6dba7c86413d8dcfa5ac424df9641c-a29170ecfb04e4c3ffda1a7beec3bde8071504ed1ec1913cd1f93dae13e563be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyla")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44583")[#strong[#text("Kyla")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2010")])]

#text("We had a game called Numble when I was a kid. It was basically a mathematical version of Scrabble:")

#link("http://www.boardgamegeek.com/boardgame/4737/numble")[#text("http://www.boardgamegeek.com/boardgame/4737/numble")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8fb99ea86767dc5427b9c6666fc7e0ba61d2d9fcfb35b9b369151a292134dc8b-8bb760d6c636a39da5c9510352a5424b7aae63e318a119622e8dda6907a5543a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of patzer")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44586")[#strong[#text("patzer")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2010")])]

#text("chess is definitely a game which develops deep combinatorial understanding furthermore it’s one of the best games humanity ever")#linebreak()#text(" invented")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd83ab57967ccfe2fec3a7390f8ee470a99d34703c8a83778c9a2dff057d0298-fd0b212ab9166c7049cdb64effce4a7b0cb415ba88a6226266fd2fd598d74fd0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bane")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44590")[#strong[#text("bane")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2010")])]

#text("I’ll mention something that (like Sudoku) isn’t a 2-player game, and which I think may have helped my general mathematical reasoning skills. In the UK there are puzzle books called “Logic Problems”")

#link("http://www.puzzler.com/Puzzles-encyclopedia/LogicProblem.htm")[#text("http://www.puzzler.com/Puzzles-encyclopedia/LogicProblem.htm")]

#text("dunno if they exist elsewhere (eg, the US). The basic idea is figuring out “tuples of attributes” from a big set of attributes unqiuesly satisfying a 5-8 natural language conditions. (It’s easier to see from concrete examples on the page given.) Mathematically it’s attractive because some of the patterns of reasoning that one uses in mathematics (eg, neither “condition” A nor B determine C but using A and B simultaneously determines C, trickly worded conditions can teach care about what elements a quantification applies to, etc, again these are easier to see in the web-page examples). Psychologically it’s attractive because it looks like detective work more than teaching thinking skills.The big issue is that, being basically a piece of paper if the child isn’t interested they can mentally drift off, whilst at least with two-player/computer games they force the player to at least do something every so often so games may help “less natural” students learn something, whilst if the child doesn’t take to logic problems then they’ll probably learn nothing.")

#text("I did quite a lot of these for fun when I was around 11-12 and I think they helped me with basic skills. (I stopped doing them because they take about an hour of intense concentration and I suddenly had interesting textbooks and computers.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/778b162bceae6c67b03a5b8f8c3f87559320e863361c0ec50d9a06f2724415ba-38d615848b8f49948687061870d820258feaf6d56d4ca9f2a26536daabc3924d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44641")[#strong[#text("Dave")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2010")])]

#text("One of the first posts mentioned the puzzle game DROD (Deadly Rooms of Death)–I think this is the best of the lot.")

#text("It’s a turn-based 2D game in which the movements of monsters are entirely predictable by design. Your 1-square character has a 1-square sword that he can rotate in 8 directions; either rotating the sword by 45 degrees or taking a step will use up a turn and give all the monsters in the room each a chance to move. If any monster occupies the same square as the character’s sword, the monster dies; if any monster occupies the same square as the character, the character dies. There are many distinct monsters with different behaviors; the simplest of these merely advances directly towards the player, while the most complex are pretty devious…")

#text("You end up having to figure out what will happen many turns in advance if you wish to clear a room, of course. This involves learning to recognize common patterns as well as work out what will happen on your own… Will the roach eggs mature before you can get your sword around? Will that snake reach the door and therefore you before you can hit the switch to close it, thereby ensuring its destruction? I spent many a stimulating afternoon as a high school student trying to solve the free Architects’ Edition.")

#text("Still haven’t completed it…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10146f3b04a025d848c6dccdb9b433ecbc4cf3c9c50e10847753928f9d04233e-f75329265a9ad4e461a33f84d2ab302abd1da23a9a5ff84204c07a6bde2eb7be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antonio Vera")]], [#link("https://terrytao.wordpress.com/2010/04/29/suggestions-for-games-that-promote-mathematical-thinking/comment-page-1/#comment-44643")[#strong[#text("Antonio Vera")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2010")])]

#text("Sites like TopCoder or the Valladolid online judge provide many interesting programming problems which require mathematical thinking and problem solving skills. In particular, TopCoder organizes regular online competitions, maintaining a rating system which make this seem like an ATP tour of algorithmics. Nice!")
]
