// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/05/12/steins-maximal-principle/
// Converted to Typst by tao2typ: "2026-10-14T16:36:29.320435+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Stein’s maximal principle", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Stein’s maximal principle")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 May 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/05/12/steins-maximal-principle/")[#text("https://terrytao.wordpress.com/2011/05/12/steins-maximal-principle/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Suppose one has a measure space ")#mi("{X = (X, {\\mathcal B}, \\mu)}")#text(" and a sequence of operators ")#mi("{T_n: L^p(X) \\rightarrow L^p(X)}")#text(" that are bounded on some ")#mi("{L^p(X)}")#text(" space, with ")#mi("{1 \\leq p < \\infty}")#text(". Suppose that on some dense subclass of functions ")#mi("{f}")#text(" in ")#mi("{L^p(X)}")#text(" (e.g. continuous compactly supported functions, if the space ")#mi("{X}")#text(" is reasonable), one already knows that ")#mi("{T_n f}")#text(" converges pointwise almost everywhere to some limit ")#mi("{Tf}")#text(", for another bounded operator ")#mi("{T: L^p(X) \\rightarrow L^p(X)}")#text(" (e.g. ")#mi("{T}")#text(" could be the identity operator). What additional ingredient does one need to pass to the limit and conclude that ")#mi("{T_n f}")#text(" converges almost everywhere to ")#mi("{Tf}")#text(" for ")#emph[#text("all")]#text(" ")#mi("{f}")#text(" in ")#mi("{L^p(X)}")#text(" (and not just for ")#mi("{f}")#text(" in a dense subclass)?")

#text("One standard way to proceed here is to study the ")#emph[#text("maximal operator")]

#align(center)[#tao-fit-display[#tao-math("T_* f(x) := \\sup_n \\left|T_n f(x)\\right|", block: true)]]

#text("and aim to establish a ")#emph[#text("weak-type maximal inequality")]#text(" ")#metadata(none) <tao-36d69fc49a37c6dd5a47>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| T_* f \\right\\|_{L^{p,\\infty}(X)} \\leq C \\left\\| f \\right\\|_{L^p(X)}", block: true)]]



#text("for all ")#mi("{f \\in L^p(X)}")#text(" (or all ")#mi("{f}")#text(" in the dense subclass), and some constant ")#mi("{C}")#text(", where ")#mi("{L^{p,\\infty}}")#text(" is the weak ")#mi("{L^p}")#text(" norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^{p,\\infty}(X)} := \\sup_{t > 0} t \\mu( \\{ x \\in X: \\left|f(x)\\right| \\geq t \\})^{1/p}.", block: true)]]

#text("A standard approximation argument using ")#link(<tao-36d69fc49a37c6dd5a47>)[#text("(1)")]#text(" then shows that ")#mi("{T_n f}")#text(" will now indeed converge to ")#mi("{Tf}")#text(" pointwise almost everywhere for all ")#mi("{f}")#text(" in ")#mi("{L^p(X)}")#text(", and not just in the dense subclass. See for instance ")#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/")[#text("these lecture notes of mine")]#text(", in which this method is used to deduce the ")#link("http://en.wikipedia.org/wiki/Lebesgue_differentiation_theorem")[#text("Lebesgue differentiation theorem")]#text(" from the ")#link("http://en.wikipedia.org/wiki/Hardy-Littlewood_maximal_operator")[#text("Hardy-Littlewood maximal inequality")]#text(". This is by now a very standard approach to establishing pointwise almost everywhere convergence theorems, but it is natural to ask whether it is strictly necessary. In particular, is it possible to have a pointwise convergence result ")#mi("{T_n f \\mapsto T f}")#text(" without being able to obtain a weak-type maximal inequality of the form ")#link(<tao-36d69fc49a37c6dd5a47>)[#text("(1)")]#text("?")

#text("In the case of ")#emph[#text("norm")]#text(" convergence (in which one asks for ")#mi("{T_n f}")#text(" to converge to ")#mi("{Tf}")#text(" in the ")#mi("{L^p}")#text(" norm, rather than in the pointwise almost everywhere sense), the answer is no, thanks to the ")#link("http://en.wikipedia.org/wiki/Uniform_boundedness_principle")[#text("uniform boundedness principle")]#text(", which among other things shows that norm convergence is only possible if one has the uniform bound ")#metadata(none) <tao-ef379363dd0cb7be6663>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\sup_n \\left\\| T_n f \\right\\|_{L^p(X)} \\leq C \\left\\| f \\right\\|_{L^p(X)}", block: true)]]



#text(" for some ")#mi("{C>0}")#text(" and all ")#mi("{f \\in L^p(X)}")#text("; and conversely, if one has the uniform bound, and one has already established norm convergence of ")#mi("{T_n f}")#text(" to ")#mi("{Tf}")#text(" on a dense subclass of ")#mi("{L^p(X)}")#text(", ")#link(<tao-ef379363dd0cb7be6663>)[#text("(2)")]#text(" will extend that norm convergence to all of ")#mi("{L^p(X)}")#text(".")

#text("Returning to pointwise almost everywhere convergence, the answer in general is “yes”. Consider for instance the rank one operators")

#align(center)[#tao-fit-display[#mitex("T_n f(x) := 1_{[n,n+1]} \\int_0^1 f(y)\\ dy")]]

#text("from ")#mi("{L^1({\\bf R})}")#text(" to ")#mi("{L^1({\\bf R})}")#text(". It is clear that ")#mi("{T_n f}")#text(" converges pointwise almost everywhere to zero as ")#mi("{n \\rightarrow \\infty}")#text(" for any ")#mi("{f \\in L^1({\\bf R})}")#text(", and the operators ")#mi("{T_n}")#text(" are uniformly bounded on ")#mi("{L^1({\\bf R})}")#text(", but the maximal function ")#mi("{T_*}")#text(" does not obey ")#link(<tao-36d69fc49a37c6dd5a47>)[#text("(1)")]#text(". One can modify this example in a number of ways to defeat almost any reasonable conjecture that something like ")#link(<tao-36d69fc49a37c6dd5a47>)[#text("(1)")]#text(" should be necessary for pointwise almost everywhere convergence.")

#text("In spite of this, a remarkable ")#link("http://www.ams.org/mathscinet-getitem?mr=125392")[#text("observation of Stein")]#text(", now known as ")#emph[#text("Stein’s maximal principle")]#text(", asserts that the maximal inequality ")#emph[#text("is")]#text(" necessary to prove pointwise almost everywhere convergence, if one is working on a compact group and the operators ")#mi("{T_n}")#text(" are translation invariant, and if the exponent ")#mi("{p}")#text(" is at most ")#mi("{2}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Stein maximal principle)")]#text(" ")#metadata(none) <tao-bc82075b41273afbad3b>#text(" Let ")#mi("{G}")#text(" be a compact group, let ")#mi("{X}")#text(" be a ")#link("http://en.wikipedia.org/wiki/Homogeneous_space")[#text("homogeneous space")]#text(" of ")#mi("{G}")#text(" with a finite Haar measure ")#mi("{\\mu}")#text(", let ")#mi("{1\\leq p \\leq 2}")#text(", and let ")#mi("{T_n: L^p(X) \\rightarrow L^p(X)}")#text(" be a sequence of bounded linear operators commuting with translations, such that ")#mi("{T_n f}")#text(" converges pointwise almost everywhere for each ")#mi("{f \\in L^p(X)}")#text(". Then ")#link(<tao-36d69fc49a37c6dd5a47>)[#text("(1)")]#text(" holds.")
]

#text("This is not quite the most general vesion of the principle; some additional variants and generalisations are given in the ")#link("http://www.ams.org/mathscinet-getitem?mr=125392")[#text("original paper of Stein")]#text(". For instance, one can replace the discrete sequence ")#mi("{T_n}")#text(" of operators with a continuous sequence ")#mi("{T_t}")#text(" without much difficulty. As a typical application of this principle, we see that ")#link("http://en.wikipedia.org/wiki/Carleson%27s_theorem")[#text("Carleson’s celebrated theorem")]#text(" that the partial Fourier series ")#mi("{\\sum_{n=-N}^N \\hat f(n) e^{2\\pi i nx}}")#text(" of an ")#mi("{L^2({\\bf R}/{\\bf Z})}")#text(" function ")#mi("{f: {\\bf R}/{\\bf Z} \\rightarrow {\\bf C}}")#text(" converge almost everywhere is in fact equivalent to the estimate ")#metadata(none) <tao-764a3c150d23024847d2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\| \\sup_{N>0} \\left|\\sum_{n=-N}^N \\hat f(n) e^{2\\pi i n\\cdot}\\right|\\right\\|_{L^{2,\\infty}({\\bf R}/{\\bf Z})} \\leq C \\left\\|f\\right\\|_{L^2({\\bf R}/{\\bf Z})}.", block: true)]]



#text(" And unsurprisingly, most of the proofs of this (difficult) theorem have proceeded by first establishing ")#link(<tao-764a3c150d23024847d2>)[#text("(3)")]#text(", and Stein’s maximal principle strongly suggests that this is the optimal way to try to prove this theorem.")

#text("On the other hand, the theorem does fail for ")#mi("{p>2}")#text(", and almost everywhere convergence results in ")#mi("{L^p}")#text(" for ")#mi("{p>2}")#text(" can be proven by other methods than weak ")#mi("{(p,p)}")#text(" estimates. For instance, the convergence of Bochner-Riesz multipliers in ")#mi("{L^p({\\bf R}^n)}")#text(" for any ")#mi("{n}")#text(" (and for ")#mi("{p}")#text(" in the range predicted by the Bochner-Riesz conjecture) was verified for ")#mi("{p > 2}")#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=972135")[#text("by Carbery, Rubio de Francia, and Vega")]#text(", despite the fact that the weak ")#mi("{(p,p)}")#text(" of even a ")#emph[#text("single")]#text(" Bochner-Riesz multiplier, let alone the maximal function, has still not been completely verified in this range. (Carbery, Rubio de Francia and Vega use weighted ")#mi("{L^2}")#text(" estimates for the maximal Bochner-Riesz operator, rather than ")#mi("{L^p}")#text(" type estimates.) For ")#mi("{p \\leq 2}")#text(", though, Stein’s principle (after localising to a torus) does apply, though, and pointwise almost everywhere convergence of Bochner-Riesz means is equivalent to the weak ")#mi("{(p,p)}")#text(" estimate ")#link(<tao-36d69fc49a37c6dd5a47>)[#text("(1)")]#text(".")

#text("Stein’s principle is restricted to compact groups (such as the torus ")#mi("{({\\bf R}/{\\bf Z})^n}")#text(" or the rotation group ")#mi("{SO(n)}")#text(") and their homogeneous spaces (such as the torus ")#mi("{({\\bf R}/{\\bf Z})^n}")#text(" again, or the sphere ")#mi("{S^{n-1}}")#text("). As stated, the principle fails in the noncompact setting; for instance, in ")#mi("{{\\bf R}}")#text(", the convolution operators ")#mi("{T_n f := f * 1_{[n,n+1]}}")#text(" are such that ")#mi("{T_n f}")#text(" converges pointwise almost everywhere to zero for every ")#mi("{f \\in L^1({\\bf R}^n)}")#text(", but the maximal function is not of weak-type ")#mi("{(1,1)}")#text(". However, in many applications on non-compact domains, the ")#mi("{T_n}")#text(" are “localised” enough that one can transfer from a non-compact setting to a compact setting and then apply Stein’s principle. For instance, Carleson’s theorem on the real line ")#mi("{{\\bf R}}")#text(" is equivalent to Carleson’s theorem on the circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(" (due to the localisation of the Dirichlet kernels), which as discussed before is equivalent to the estimate ")#link(<tao-764a3c150d23024847d2>)[#text("(3)")]#text(" on the circle, which by a scaling argument is equivalent to the analogous estimate on the real line ")#mi("{{\\bf R}}")#text(".")

#text("Stein’s argument from his 1961 paper can be viewed nowadays as an application of the ")#link("http://en.wikipedia.org/wiki/Probabilistic_method")[#text("probabilistic method")]#text("; starting with a sequence of increasingly bad counterexamples to the maximal inequality ")#link(<tao-36d69fc49a37c6dd5a47>)[#text("(1)")]#text(", one randomly combines them together to create a single “infinitely bad” counterexample. To make this idea work, Stein employs two basic ideas:")

#enum(start: 1, 
[#text("The ")#emph[#text("random rotations (or random translations) trick")]#text(". Given a subset ")#mi("{E}")#text(" of ")#mi("{X}")#text(" of small but positive measure, one can randomly select about ")#tao-math("{\\left|X\\right|/\\left|E\\right|}", block: false)#text(" translates ")#mi("{g_i E}")#text(" of ")#mi("{E}")#text(" that cover most of ")#mi("{X}")#text(".")],
[#text("The ")#emph[#text("random sums trick")]#text(" Given a collection ")#mi("{f_1,\\ldots,f_n: X \\rightarrow {\\bf C}}")#text(" of signed functions that may possibly cancel each other in a deterministic sum ")#mi("{\\sum_{i=1}^n f_i}")#text(", one can perform a random sum ")#mi("{\\sum_{i=1}^n \\pm f_i}")#text(" instead to obtain a random function whose magnitude will usually be comparable to the square function ")#tao-math("{(\\sum_{i=1}^n \\left|f_i\\right|^2)^{1/2}}", block: false)#text("; this can be made rigorous by ")#link("http://en.wikipedia.org/wiki/Concentration_of_measure")[#text("concentration of measure")]#text(" results, such as ")#link("http://en.wikipedia.org/wiki/Khintchine_inequality")[#text("Khintchine’s inequality")]#text(".")]
)

#text("These ideas have since been used repeatedly in harmonic analysis. For instance, I used the random rotations trick in a ")#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/")[#text("recent paper with Jordan Ellenberg and Richard Oberlin")]#text(" on Kakeya-type estimates in finite fields. The random sums trick is by now a standard tool to build various counterexamples to estimates (or to convergence results) in harmonic analysis, for instance being used ")#link("http://www.ams.org/mathscinet-getitem?mr=296602")[#text("by Fefferman")]#text(" in his famous paper disproving the boundedness of the ball multiplier on ")#mi("{L^p({\\bf R}^n)}")#text(" for ")#mi("{p \\neq 2}")#text(", ")#mi("{n \\geq 2}")#text(". Another use of the random sum trick is to show that Theorem ")#link(<tao-bc82075b41273afbad3b>)[#text("1")]#text(" fails once ")#mi("{p>2}")#text("; see Stein’s original paper for details.")

#text("Another use of the random rotations trick, closely related to Theorem ")#link(<tao-bc82075b41273afbad3b>)[#text("1")]#text(", is the ")#emph[#text("Nikishin-Stein factorisation theorem")]#text(". Here is Stein’s formulation of this theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Stein factorisation theorem)")]#text(" ")#metadata(none) <tao-50ee13e444b21c075584>#text("Let ")#mi("{G}")#text(" be a compact group, let ")#mi("{X}")#text(" be a homogeneous space of ")#mi("{G}")#text(" with a finite Haar measure ")#mi("{\\mu}")#text(", let ")#mi("{1\\leq p \\leq 2}")#text(" and ")#mi("{q>0}")#text(", and let ")#mi("{T: L^p(X) \\rightarrow L^q(X)}")#text(" be a bounded linear operator commuting with translations and obeying the estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\|T f \\right\\|_{L^q(X)} \\leq A \\left\\|f\\right\\|_{L^p(X)}", block: true)]]

#text("for all ")#mi("{f \\in L^p(X)}")#text(" and some ")#mi("{A>0}")#text(". Then ")#mi("{T}")#text(" also maps ")#mi("{L^p(X)}")#text(" to ")#mi("{L^{p,\\infty}(X)}")#text(", with")

#align(center)[#tao-fit-display[#tao-math("\\left\\|T f \\right\\|_{L^{p,\\infty}(X)} \\leq C_{p,q} A \\left\\|f\\right\\|_{L^p(X)}", block: true)]]

#text("for all ")#mi("{f \\in L^p(X)}")#text(", with ")#mi("{C_{p,q}}")#text(" depending only on ")#mi("{p, q}")#text(".")
]

#text("This result is trivial with ")#mi("{q \\geq p}")#text(", but becomes useful when ")#mi("{q<p}")#text(". In this regime, the translation invariance allows one to freely “upgrade” a strong-type ")#mi("{(p,q)}")#text(" result to a weak-type ")#mi("{(p,p)}")#text(" result. In other words, bounded linear operators from ")#mi("{L^p(X)}")#text(" to ")#mi("{L^q(X)}")#text(" automatically factor through the inclusion ")#mi("{L^{p,\\infty}(X) \\subset L^q(X)}")#text(", which helps explain the name “factorisation theorem”. Factorisation theory has been developed further by many authors, including ")#link("http://www.ams.org/mathscinet-getitem?mr=344931")[#text("Maurey")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=863711")[#text("Pisier")]#text(".")

#text("Stein’s factorisation theorem (or more precisely, a variant of it) is useful in the theory of Kakeya and restriction theorems in Euclidean space, as first observed ")#link("http://www.ams.org/mathscinet-getitem?mr=1097257")[#text("by Bourgain")]#text(".")

#text("In 1970, ")#link("http://www.ams.org/mathscinet-getitem?mr=296584")[#text("Nikishin")]#text(" obtained the following generalisation of Stein’s factorisation theorem in which the translation-invariance hypothesis can be dropped, at the cost of excluding a set of small measure:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Nikishin-Stein factorisation theorem)")]#text(" ")#metadata(none) <tao-daf7691e51e2ace1f80c>#text("Let ")#mi("{X}")#text(" be a finite measure space, let ")#mi("{1\\leq p \\leq 2}")#text(" and ")#mi("{q>0}")#text(", and let ")#mi("{T: L^p(X) \\rightarrow L^q(X)}")#text(" be a bounded linear operator obeying the estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\|T f \\right\\|_{L^q(X)} \\leq A \\left\\|f\\right\\|_{L^p(X)}", block: true)]]

#text("for all ")#mi("{f \\in L^p(X)}")#text(" and some ")#mi("{A>0}")#text(". Then for any ")#mi("{\\epsilon > 0}")#text(", there exists a subset ")#mi("{E}")#text(" of ")#mi("{X}")#text(" of measure at most ")#mi("{\\epsilon}")#text(" such that ")#metadata(none) <tao-76efbfa34c5092b6c4b1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\|T f \\right\\|_{L^{p,\\infty}(X \\backslash E)} \\leq C_{p,q,\\epsilon} A \\left\\|f\\right\\|_{L^p(X)}", block: true)]]



#text(" for all ")#mi("{f \\in L^p(X)}")#text(", with ")#mi("{C_{p,q,\\epsilon}}")#text(" depending only on ")#mi("{p, q, \\epsilon}")#text(".")
]

#text("One can recover Theorem ")#link(<tao-50ee13e444b21c075584>)[#text("2")]#text(" from Theorem ")#link(<tao-daf7691e51e2ace1f80c>)[#text("3")]#text(" by an averaging argument to eliminate the exceptional set; we omit the details.")

#metadata(none) <tao-d629461bf2178d2a4664>

#heading(level: 1)[#strong[#text(" — 1. Sketch of proofs — ")]]

#text("We now sketch how Stein’s maximal principle is proven. We may normalise ")#mi("{\\mu(X)=1}")#text(". Suppose the maximal inequality ")#link(<tao-36d69fc49a37c6dd5a47>)[#text("(1)")]#text(" fails for any ")#mi("{C}")#text(". Then, for any ")#mi("{A \\geq 1}")#text(", we can find a non-zero function ")#mi("{f \\in L^p(X)}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T_* f\\right\\|_{L^{p,\\infty}(X)} \\geq A \\left\\|f\\right\\|_{L^p(X)}.", block: true)]]

#text("By homogeneity, we can arrange matters so that")

#align(center)[#tao-fit-display[#tao-math("\\mu( E ) \\geq A^p \\left\\|f\\right\\|_{L^p(X)}^p,", block: true)]]

#text("where ")#tao-math("{E := \\{ x \\in X: \\left|T_* f(x)\\right| \\geq 1 \\}}", block: false)#text(".")

#text("At present, ")#mi("{E}")#text(" could be a much smaller set than ")#mi("{X}")#text(": ")#mi("{\\mu(E) \\ll 1}")#text(". But we can amplify ")#mi("{E}")#text(" by using the random rotations trick. Let ")#mi("{m}")#text(" be a natural number comparable to ")#mi("{1/\\mu(E)}")#text(", and let ")#mi("{g_1,\\ldots,g_m}")#text(" be elements of ")#mi("{G}")#text(", chosen uniformly at random. Each element ")#mi("{x}")#text(" of ")#mi("{X}")#text(" has a probability ")#mi("{1 - (1-\\mu(E))^m \\sim 1}")#text(" of lying in at least one of the translates ")#mi("{g_1 E, \\ldots, g_m E}")#text(" of ")#mi("{E}")#text(". From this and the first moment method, we see that with probability ")#mi("{\\sim 1}")#text(", the set ")#mi("{g_1 E \\cup \\ldots \\cup g_m E}")#text(" has measure ")#mi("{\\sim 1}")#text(".")

#text("Now form the function ")#mi("{F := \\sum_{j=1}^m \\epsilon_j \\tau_{g_j} f}")#text(", where ")#mi("{\\tau_{g_j} f(x) := f(g_j^{-1} x)}")#text(" is the left-translation of ")#mi("{f}")#text(" by ")#mi("{g_j}")#text(", and the ")#mi("{\\epsilon_j = \\pm 1}")#text(" are randomly chosen signs. On the one hand, an application of moment methods (such as the ")#link("http://en.wikipedia.org/wiki/Paley%E2%80%93Zygmund_inequality")[#text("Paley-Zygmund inequality")]#text("), one can show that each element ")#mi("{x}")#text(" of ")#mi("{g_1 E \\cup \\ldots \\cup g_m E}")#text(" will be such that ")#tao-math("{\\left|T_* F(x)\\right| \\gtrsim 1}", block: false)#text(" with probability ")#mi("{\\sim 1}")#text(". On the other hand, an application of Khintchine’s inequality shows that with high probability ")#mi("{F}")#text(" will have an ")#mi("{L^p(X)}")#text(" norm bounded by")

#align(center)[#tao-fit-display[#tao-math("\\lesssim \\left\\| (\\sum_{j=1}^m \\left|\\tau_{g_j} f\\right|^2)^{1/2} \\right\\|_{L^p(X)}.", block: true)]]

#text("Now we crucially use the hypothesis ")#mi("{p \\leq 2}")#text(" to replace the ")#mi("{\\ell^2}")#text("-summation here by an ")#mi("{\\ell^p}")#text(" summation. Interchanging the ")#mi("{\\ell^p}")#text(" and ")#mi("{L^p}")#text(" norms, we then conclude that with high probability we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|F\\right\\|_{L^p(X)} \\lesssim m^{1/p} \\left\\|f\\right\\|_{L^p(X)} \\lesssim 1/A.", block: true)]]

#text("To summarise, using the probabilistic method, we have constructed (for arbitrarily large ")#mi("{A}")#text(") a function ")#mi("{F = F_A}")#text(" whose ")#mi("{L^p}")#text(" norm is only ")#mi("{O(1/A)}")#text(" in size, but such that ")#tao-math("{\\left|T_* F(x)\\right| \\gtrsim 1}", block: false)#text(" on a subset of ")#mi("{X}")#text(" of measure ")#mi("{\\sim 1}")#text(". By sending ")#mi("{A}")#text(" rapidly to infinity and taking a suitable combination of these functions ")#mi("{F}")#text(", one can then create a function ")#mi("{G}")#text(" in ")#mi("{L^p}")#text(" such that ")#mi("{T_* G}")#text(" is infinite on a set of positive measure, which contradicts the hypothesis of pointwise almost everywhere convergence.")

#text("Stein’s factorisation theorem is proven in a similar fashion. For Nikishin’s factorisation theorem, the group translation operations ")#mi("{\\tau_{g_j}}")#text(" are no longer available. However, one can substitute for this by using the failure of the hypothesis ")#link(<tao-76efbfa34c5092b6c4b1>)[#text("(4)")]#text(", which among other things tells us that if one has a number of small sets ")#mi("{E_1,\\ldots,E_i}")#text(" in ")#mi("{X}")#text(" whose total measure is at most ")#mi("{\\epsilon}")#text(", then we can find another function ")#mi("{f_{i+1}}")#text(" of small ")#mi("{L^p}")#text(" norm for which ")#mi("{T f_{i+1}}")#text(" is large on a set ")#mi("{E_{i+1}}")#text(" outside of ")#mi("{E_1 \\cup \\ldots \\cup E_i}")#text(". Iterating this observation and choosing all parameters carefully, one can eventually establish the result.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" A systematic discussion of these and other maximal principles is given in ")#link("http://www.ams.org/mathscinet-getitem?mr=596037")[#text("this book of Guzman")]#text(".")
]

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4514941d939bcef900e626ddde66fad70a4d7ce517ec98a7260ab82e54f56f4-3ec7286dccac13182ba58953e5421dd8e4bfac68008adf391d2c13c5aecfc590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ming Wang")]], [#link("https://terrytao.wordpress.com/2011/05/12/steins-maximal-principle/#comment-52614")[#strong[#text("Ming Wang")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2011")])]

#text("Dear Professor Tao,")#linebreak()#text(" Could you give some useful examples of ")#mi("X")#text(" included in $\\latex R^n$? Since I am not familar with the concepts compact group and homogeneous space. Thank you very much!")

#emph[#text("[Some material added in this direction – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0407444868fc42987e0e767c3fa8c7571cd73af435533bcece7a36bd594b0514-2ae27efe97fcf1ece7ea67e36afa94eee62825664716dc4ee7cf030a881d77c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shannon7774")]], [#link("https://terrytao.wordpress.com/2011/05/12/steins-maximal-principle/#comment-52641")[#strong[#text("shannon7774")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2011")])]

#text("In paragraph 4 or 5 you said, “Returning to pointwise almost everywhere convergence, the answer in general is “no”. ” Since the question was whether there is a counterexample, shouldn’t the answer here be “yes”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/12/steins-maximal-principle/#comment-52643")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2011")])]

#text("Dear Prof. Tao")

#text("In the first paragraph I believe it should read “conclude that T_n f converges”")#linebreak()#text(" instead of T f_n")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/05/12/steins-maximal-principle/#comment-53073")[#strong[#text("Sixth Linkfest")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2011")]

#text("[…] Tao: Stein’s maximal principle, Stein’s spherical maximal theorem, Locally compact topological vector […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Bailey")]], [#link("https://terrytao.wordpress.com/2011/05/12/steins-maximal-principle/#comment-63319")[#strong[#text("Andrew Bailey")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2011")])]

#text("Small typo when you talk about Bochner-Riesz multipliers in the second paragraph after the statement of Theorem 1: “depsite”. ")#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/12/steins-maximal-principle/#comment-70558")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2011")])]

#text("Dear Prof. Tao,")#linebreak()#text(" 1)Minor typo: general version instead of “general vesion” in the first line after Theorem 1.")

#text("2)I don’t understand this sentence:")#linebreak()#text(" On the one hand, an application of moment methods (such as the Paley-Zygmund inequality), one can show that each element {x} of {g_1 E \\cup \\ldots \\cup g_m E} will be such that {|T_* F(x)| \\gtrsim 1} with probability {\\sim 1}.")#linebreak()#text(" If someone (Prof Tao?) could give one or two lines on this… Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/12/steins-maximal-principle/#comment-70596")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2011")])]

#text("Thanks for the correction. The Paley-Zygmund inequality can be used to show that if one has a sequence ")#mi("x_1,\\ldots,x_k")#text(" of real numbers with ")#tao-math("\\left|x_1\\right| \\gtrsim 1", block: false)#text(", and one forms the random sum ")#mi("X := \\varepsilon_1 x_1 + \\ldots + \\varepsilon_k x_k")#text(", then one has ")#tao-math("\\left|X\\right| \\gtrsim 1", block: false)#text(" with probability ")#mi("\\gtrsim 1")#text(" (this is basically because ")#tao-math("{\\bf E} \\left|X\\right|^4 \\lesssim ({\\bf E} \\left|X\\right|^2)^2", block: false)#text(", which is a special case of Khintchine’s inequality; it also reflects the intuitive fact that random walks cannot converge to the origin). If one applies this fact to the numbers ")#mi("x_j = T_n \\tau_{g_j} f(x)")#text(", where n is chosen to make ")#mi("x_1")#text(" large, one obtains the claim.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/12/steins-maximal-principle/#comment-71081")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2011")])]

#text("Thank you very much!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/12/steins-maximal-principle/#comment-263876")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2014")])]

#text("Must the operator in Theorem 3 commute with translations ?")

#emph[#text("[Ah, that is a typo, the hypothesis should be removed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c81bc0a85f4ad3e8f35ed0cbf528be9f28feb502b77ae3634ddde3e743c9c93e-0e89568c804089056540b9386d4ee8fb2bdea457ddad60543afe64a50b291d62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/12/steins-maximal-principle/#comment-410630")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2014")])]

#text("Dear Prof. Tao,")

#text("In the paragraph where the random rotation trick is introduced, you said “one can randomly select about ${|G|/|E|}$ translates ${g_i E}$ of ${E}$ that cover most of ${X}$”, should it be ${|X|/|E|}$ instead of ${|G|/|E|}$?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/12/steins-maximal-principle/#comment-546824")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2020")])]

#text("Dear Prof. Tao,")

#text("I saw an article about restriction problem for hyperbolic paraboloid in J. Funct. Anal. claim that the Stein’s factorisation theorem (maybe a variant) works for parabolic setting, but with no proof. Could you please tell me if this is obvious? as I only see Bourgain apply the factorisation theorem for spherical restriction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b64abe43412dc7f11e3ee247ad175b71fde999420e1b399c19ea8c6c464376a-c662b882fe24a1718eb7f2117e0b1baa53af593586a47d2de533176114846933.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of extremal010101")]], [#link("https://terrytao.wordpress.com/2011/05/12/steins-maximal-principle/#comment-554536")[#strong[#text("extremal010101")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2020")])]

#text("Under the assumptions of Theorem 1 with ")#mi("p=2")#text(", can one conclude (1) where in the left hand side the weak-type norm is replaced by the strong norm ")#mi("\\|\\cdot \\|_{2}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/12/steins-maximal-principle/#comment-554643")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2020")])]

#text("Interesting question! My inclination would be that the answer is “no”, even when say ")#mi("G = X = {\\bf R}/{\\bf Z}")#text(", but I do not have an explicit counterexample. Carleson’s theorem proved the weak type (2,2) of the Carleson maximal operator, but the strong type (2,2) did not seem to obviously follow as a consequence, and was only proven later by the ")#mi("L^p")#text(" extension of Carleson’s result due to Hunt. There have since been several subsequent proofs of Carleson’s theorem (see eg ")#link("https://arxiv.org/abs/math/0307008")[#text("https://arxiv.org/abs/math/0307008")]#text("), but from memory the weak type (2,2) is always strictly easier to prove than the strong type (2,2), suggesting that there is no general implication of this form. But this is not yet a formal proof.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2011/05/12/steins-maximal-principle/#comment-554647")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2020")])]

#text("This is false, as was pointed out to me by Fedja Nazarov: https://mathoverflow.net/a/25552/630.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 247B, Notes 4: almost everywhere convergence of Fourier series | What's new")]], [#link("https://terrytao.wordpress.com/2011/05/12/steins-maximal-principle/#comment-559713")[#strong[#text("247B, Notes 4: almost everywhere convergence of Fourier series | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2020")])]

#text("[…] inequality; see for instance this previous blog post. A remarkable observation of Stein, known as Stein’s maximal principle, allows one to reverse this implication in certain cases by exploiting a symmetry of the problem. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/12/steins-maximal-principle/#comment-684737")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2024")])]

#text("Dear Prof. Tao,")

#text("In Stein maximum principle(Theorem 1), is there any other options to drop or exchange the condition commuting with translations?")
]
