// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/
// Converted to Typst by tao2typ: "2026-10-14T15:18:05.383442+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Locally compact topological vector spaces", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Locally compact topological vector spaces")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 May 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/")[#text("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Recall that a (real) ")#link("http://en.wikipedia.org/wiki/Topological_vector_space")[#text("topological vector space")]#text(" is a real vector space ")#mi("{V = (V, 0, +, \\cdot)}")#text(" equipped with a topology ")#mi("{{\\mathcal F}}")#text(" that makes the vector space operations ")#mi("{+: V \\times V \\rightarrow V}")#text(" and ")#mi("{\\cdot: {\\bf R} \\times V \\rightarrow V}")#text(" continuous. One often restricts attention to ")#link("http://en.wikipedia.org/wiki/Hausdorff_space")[#text("Hausdorff")]#text(" topological vector spaces; in practice, this is not a severe restriction because it turns out that any topological vector space can be made Hausdorff by quotienting out the closure ")#mi("{\\overline{\\{0\\}}}")#text(" of the origin ")#mi("{\\{0\\}}")#text(". One can also discuss complex topological vector spaces, and the theory is not significantly different; but for sake of exposition we shall restrict attention here to the real case.")

#text("An obvious example of a topological vector space is a finite-dimensional vector space such as ")#mi("{{\\bf R}^n}")#text(" with the usual topology. Of course, there are plenty of infinite-dimensional topological vector spaces also, such as infinite-dimensional ")#link("http://en.wikipedia.org/wiki/Normed_vector_space")[#text("normed vector spaces")]#text(" (with the ")#link("http://en.wikipedia.org/wiki/Strong_topology")[#text("strong")]#text(", ")#link("http://en.wikipedia.org/wiki/Weak_topology")[#text("weak")]#text(", or ")#link("http://en.wikipedia.org/wiki/Weak_topology#The_weak-.2A_topology")[#text("weak-*")]#text(" topologies) or ")#link("http://en.wikipedia.org/wiki/Frechet_space")[#text("Frechet spaces")]#text(".")

#text("One way to distinguish the finite and infinite dimensional topological vector spaces is via ")#link("http://en.wikipedia.org/wiki/Locally_compact_space")[#text("local compactness")]#text(". Recall that a topological space is locally compact if every point in that space has a compact neighbourhood. From the Heine-Borel theorem, all finite-dimensional vector spaces (with the usual topology) are locally compact. In infinite dimensions, one can trivially make a vector space locally compact by giving it a trivial topology, but once one restricts to the Hausdorff case, it seems impossible to make a space locally compact. For instance, in an infinite-dimensional normed vector space ")#mi("{V}")#text(" with the ")#link("http://en.wikipedia.org/wiki/Strong_topology")[#text("strong topology")]#text(", an iteration of the ")#link("http://en.wikipedia.org/wiki/Riesz%27s_lemma")[#text("Riesz lemma")]#text(" shows that the closed unit ball ")#mi("{B}")#text(" in that space contains an infinite sequence with no convergent subsequence, which (by the Heine-Borel theorem) implies that ")#mi("{V}")#text(" cannot be locally compact. If one gives ")#mi("{V}")#text(" the ")#link("http://en.wikipedia.org/wiki/Weak_topology#The_weak-.2A_topology")[#text("weak-* topology")]#text(" instead, then ")#mi("{B}")#text(" is now compact by the ")#link("http://en.wikipedia.org/wiki/Banach%E2%80%93Alaoglu_theorem")[#text("Banach-Alaoglu theorem")]#text(", but is no longer a neighbourhood of the identity in this topology. In fact, we have the following result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" ")#metadata(none) <tao-740fc4991133b1523bc4>#text(" Every locally compact Hausdorff topological vector space is finite-dimensional.")
]

#text("The first proof of this theorem that I am aware of is ")#link("http://www.ams.org/mathscinet-getitem?mr=234930")[#text("by André Weil")]#text(". There is also a related result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" ")#metadata(none) <tao-25bf8e1a2393f1108d37>#text(" Every finite-dimensional Hausdorff topological vector space has the usual topology.")
]

#text("As a corollary, every locally compact Hausdorff topological vector space is in fact isomorphic to ")#mi("{{\\bf R}^n}")#text(" with the usual topology for some ")#mi("{n}")#text(". This can be viewed as a very special case of the ")#link("http://www.ams.org/mathscinet-getitem?mr=49203")[#text("theorem of Gleason")]#text(", which is a key component of the solution to ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_fifth_problem")[#text("Hilbert’s fifth problem")]#text(", that a locally compact group ")#mi("{G}")#text(" with ")#emph[#text("no small subgroups")]#text(" (in the sense that there is a neighbourhood of the identity that contains no non-trivial subgroups) is necessarily isomorphic to a Lie group. Indeed, Theorem ")#link(<tao-740fc4991133b1523bc4>)[#text("1")]#text(" is in fact used in the proof of Gleason’s theorem (the rough idea being to first locate a “tangent space” to ")#mi("{G}")#text(" at the origin, with the tangent vectors described by “one-parameter subgroups” of ")#mi("{G}")#text(", and show that this space is a locally compact Hausdorff topological space, and hence finite dimensional by Theorem ")#link(<tao-740fc4991133b1523bc4>)[#text("1")]#text(").")

#text("Theorem ")#link(<tao-25bf8e1a2393f1108d37>)[#text("2")]#text(" may seem devoid of content, but it does contain some subtleties, as it hinges crucially on the ")#emph[#text("joint")]#text(" continuity of the vector space operations ")#mi("{+: V \\times V \\rightarrow V}")#text(" and ")#mi("{\\cdot: {\\bf R} \\times V \\rightarrow V}")#text(", and not just on the separate continuity in each coordinate. Consider for instance the one-dimensional vector space ")#mi("{{\\bf R}}")#text(" with the ")#emph[#text("co-compact")]#text(" topology (a non-empty set is open iff its complement is compact in the usual topology). In this topology, the space is ")#mi("{T_1}")#text(" (though not Hausdorff), the scalar multiplication map ")#mi("{\\cdot: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf R}}")#text(" is jointly continuous as long as the scalar is not zero, and the addition map ")#mi("{+: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf R}}")#text(" is continuous in each coordinate (i.e. translations are continuous), but not jointly continuous; for instance, the set ")#mi("{\\{ (x,y) \\in {\\bf R}: x+y \\not \\in [0,1]\\}}")#text(" does not contain a non-trivial Cartesian product of two sets that are open in the co-compact topology. So this is not a counterexample to Theorem ")#link(<tao-25bf8e1a2393f1108d37>)[#text("2")]#text(". Similarly for the cocountable or cofinite topologies on ")#mi("{{\\bf R}}")#text(" (the latter topology, incidentally, is the same as the Zariski topology on ")#mi("{{\\bf R}}")#text(").")

#text("Another near-counterexample comes from the topology of ")#mi("{{\\bf R}}")#text(" inherited by pulling back the usual topology on the unit circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(". Admittedly, this pullback topology is not quite Hausdorff, but the addition map ")#mi("{+: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf R}}")#text(" is jointly continuous. On the other hand, the scalar multiplication map ")#mi("{\\cdot: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf R}}")#text(" is not continuous at all. A slight variant of this topology comes from pulling back the usual topology on the torus ")#mi("{({\\bf R}/{\\bf Z})^2}")#text(" under the map ")#mi("{x \\mapsto (x,\\alpha x)}")#text(" for some irrational ")#mi("{\\alpha}")#text("; this restores the Hausdorff property, and addition is still jointly continuous, but multiplication remains discontinuous.")

#text("As some final examples, consider ")#mi("{{\\bf R}}")#text(" with the discrete topology; here, the topology is Hausdorff, addition is jointly continuous, and every dilation is continuous, but multiplication is not jointly continuous. If one instead gives ")#mi("{{\\bf R}}")#text(" the ")#link("http://en.wikipedia.org/wiki/Lower_limit_topology")[#text("half-open topology")]#text(", then again the topology is Hausdorff and addition is jointly continuous, but scalar multiplication is only jointly continuous once one restricts the scalar to be non-negative.")

#text("Below the fold, I record the textbook proof of Theorem ")#link(<tao-25bf8e1a2393f1108d37>)[#text("2")]#text(" and Theorem ")#link(<tao-740fc4991133b1523bc4>)[#text("1")]#text(". There is nothing particularly original in this presentation, but I wanted to record it here for my own future reference, and perhaps these results will also be of interest to some other readers.")

#metadata(none) <tao-76fa17ad605c09d73fe8>

#heading(level: 1)[#strong[#text(" — 1. Proof of Theorem 2 — ")]]

#text("Let ")#mi("{V}")#text(" be a finite-dimensional Hausdorff topological vector space, with topology ")#mi("{{\\mathcal F}}")#text(". We need to show that every set which is open in the usual topology, is open in ")#mi("{{\\mathcal F}}")#text(", and conversely.")

#text("Let ")#mi("{v_1,\\ldots,v_n}")#text(" be a basis for the finite-dimensional space ")#mi("{V}")#text(". From the continuity of the vector space operations, we easily verify that the linear map ")#mi("{T: {\\bf R}^n \\rightarrow V}")#text(" given by")

#align(center)[#tao-fit-display[#mitex("T( x_1,\\ldots,x_n) := x_1 v_1 + \\ldots + x_n v_n")]]

#text("is continuous. From this, we see that any set which is open in ")#mi("{{\\mathcal F}}")#text(", is also open in the usual topology.")

#text("Now we show conversely that every set which is open in the usual topology, is open in ")#mi("{{\\mathcal F}}")#text(". It suffices to show that there is a bounded open neighbourhood of the origin in ")#mi("{{\\mathcal F}}")#text(", since one can then translate and dilate this open neighbourhood to obtain a (sub-)base for the usual topology. (Here, “bounded” refers to the usual sense of the term, for instance with respect to an arbitrarily selected norm on ")#mi("{V}")#text(" (note that on a finite-dimensional space, all norms are equivalent).)")

#text("We use ")#mi("{T}")#text(" to identify ")#mi("{V}")#text(" (as a vector space) with ")#mi("{{\\bf R}^n}")#text(". As ")#mi("{T}")#text(" is continuous, every set which is compact in the usual topology, is compact in ")#mi("{{\\mathcal F}}")#text(". In particular, the unit sphere ")#tao-math("{S^{n-1} := \\{x \\in {\\bf R}^n: \\left\\|x\\right\\|=1\\}}", block: false)#text(" (in, say, the Euclidean norm ")#mi("{\\| \\|}")#text(" on ")#mi("{{\\bf R}^n}")#text(") is compact in ")#mi("{{\\mathcal F}}")#text(". Using this and the Hausdorff assumption on ")#mi("{{\\mathcal F}}")#text(", we can find an open neighbourhood ")#mi("{U}")#text(" of the origin in ")#mi("{F}")#text(" which is disjoint from ")#mi("{S^{n-1}}")#text(".")

#text("At present, ")#mi("{U}")#text(" need not be bounded (note that we are not assuming ")#mi("{V}")#text(" to be ")#link("http://en.wikipedia.org/wiki/Locally_connected_space")[#text("locally connected")]#text(" ")#emph[#text("a priori")]#text("). However, we can fix this as follows. Using the joint continuity of the scalar multiplication map, one can find another open neighbourhood ")#mi("{U^{\\prime}}")#text(" of the origin and an open interval ")#mi("{(-\\epsilon,\\epsilon)}")#text(" around ")#mi("{0}")#text(" such that the product set ")#mi("{(-\\epsilon,\\epsilon) \\cdot U^{\\prime} := \\{ t x: t \\in (-\\epsilon,\\epsilon); x \\in U^{\\prime} \\}}")#text(" is contained in ")#mi("{U}")#text(". Since ")#mi("{U}")#text(" avoids the unit sphere ")#mi("{S^{n-1}}")#text(", ")#mi("{U^{\\prime}}")#text(" must avoid the region ")#tao-math("{\\{ x \\in {\\bf R}^n: \\left\\|x\\right\\| > 1/\\epsilon \\}}", block: false)#text(" and is thus bounded, as required.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3")]#text(" ")#metadata(none) <tao-5835a2460f0994134d10>#text(" In a Hausdorff topological vector space ")#mi("{V}")#text(", every finite-dimensional subspace ")#mi("{W}")#text(" is closed.")
]

#emph[#text("Proof:")]#text(" It suffices to show that every vector ")#mi("{x \\in V \\backslash W}")#text(" is in the exterior of ")#mi("{W}")#text(". But this follows from Theorem ")#link(<tao-25bf8e1a2393f1108d37>)[#text("2")]#text(" after restricting to the finite-dimensional space spanned by ")#mi("{W}")#text(" and ")#mi("{x}")#text(". ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 2. Proof of Theorem 1 — ")]]

#text("Let ")#mi("{V}")#text(" be a locally compact Hausdorff space, thus there exists a compact neighbourhood ")#mi("{K}")#text(" of the origin. Then the dilate ")#mi("{\\frac{1}{2} K}")#text(" is also a neighbourhood of the origin, and so by compactness ")#mi("{K}")#text(" can be covered by finitely many translates of ")#mi("{\\frac{1}{2} K}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("K \\subset S + \\frac{1}{2} K")]]

#text("for some finite set ")#mi("{S}")#text(". If we let ")#mi("{W}")#text(" be the finite-dimensional vector space generated by ")#mi("{S}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("K \\subset W + \\frac{1}{2} K.")]]

#text("Iterating this we have")

#align(center)[#tao-fit-display[#mitex("K \\subset W + 2^{-n} K")]]

#text("for any ")#mi("{n \\geq 1}")#text(". On the other hand, if ")#mi("{U}")#text(" is a neighbourhood of the origin, then for every ")#mi("{x \\in V}")#text(" we see that ")#mi("{2^{-n} x \\in U}")#text(" for sufficiently large ")#mi("{n}")#text(". By compactness of ")#mi("{K}")#text(" (and continuity of the scalar multiplication map at zero), we conclude that ")#mi("{2^{-n} K \\subset U}")#text(" for some sufficiently large ")#mi("{n}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("K \\subset W + U")]]

#text("for any neighbourhood ")#mi("{U}")#text(" of the origin; thus ")#mi("{K}")#text(" is in the closure of ")#mi("{W}")#text(". By Corollary ")#link(<tao-5835a2460f0994134d10>)[#text("3")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("K \\subset W.")]]

#text("But ")#mi("{K}")#text(" is a neighbourhood of the origin, thus for every ")#mi("{x \\in V}")#text(" we have ")#mi("{2^{-n} x \\in K}")#text(" for all sufficiently large ")#mi("{n}")#text(", and thus ")#mi("{x \\in 2^n W = W}")#text(". Thus ")#mi("{V=W}")#text(", and the claim follows.")

#heading(level: 1)[#text("Comments (20)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5beb3feca10d19b0247b6e3b0011f7dcabfdeda5d7abcbb0c2352efeb2fa916b-cb218bb16e551e56b82041d5c93422040394e380fcb8420e9454f33bd8f7e041.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JuanPi")]], [#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/#comment-53066")[#strong[#text("JuanPi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2011")])]

#text("Hi,")#linebreak()#text(" Thanks for the round-up. I am reading . Khatskevich, D.Shoikhet, Differentiable Operators and Nonlinear Equations so this is a nice backup.")

#text("Now, I have a more or less green-horn question: If we have D a nonlinear differential operator acting on some Hilbert space of functions. Is there anything we can tell about the set of all solutions q of the problem D(q) = 0? In the linear case we know they are vector space (the nullspace), what can be said in the nonlinear case?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/#comment-53072")[#strong[#text("Sixth Linkfest")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2011")]

#text("[…] Terence Tao: Stein’s maximal principle, Stein’s spherical maximal theorem, Locally compact topological vector spaces […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a3c0751212841776ea85cd07493de1fc352d294d20d6c739586190d5adb067e-605d33dcbd66e2f3524ee271784e5412b1690e21c6b83bbea5cae3124ade75ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MysticTerminator")]], [#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/#comment-53078")[#strong[#text("MysticTerminator")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2011")])]

#text("How is R in the cocompact topology Hausdorff?")

#emph[#text("[Ah, yes, it isn’t – thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec7c6b0e3060e1c806f619bf4b492030a739cda006aaf0a178402739ff75194-2c3659f7497f4bb1cf1e6e85fafd68a9d10b53737c2f3b03f29c35b080ae39ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/#comment-53079")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2011")])]

#text("Theorem 2, as presently stated, is a bit too strong.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d39c5b7fe87d446011308cd8e945dce85bde2d6f582f43707840d0294cef5dc9-b7b6bec90a864e7e3d2b10833032e7728bdd0129bbec856587cf1aa6a2011c97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous Rex")]], [#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/#comment-53089")[#strong[#text("Anonymous Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2011")])]

#text("Hi, tiny typo: In “Combining the two statements, we see that for every {x \\in U”}, we have {sx \\in U} for every {x \\in (-\\epsilon,\\epsilon)}”, you use x twice. I assume you mean for s to be the scalar.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d5b71f6516927a87676910349d15761dfeae3786ad5922d00fe89d4def7d8dfd-12bbf3ac74b52cd72ba208ea634fe48580c63ec9f0761af42154e78e591561a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/#comment-53254")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2011")])]

#text("Dear Professor Tao,")

#text("Grothendieck (MR0372565 (51 #8772)) attributes Theorem 1 to Banach, but")#linebreak()#text(" the oldest reference I could find was the 1953 edition of Bourbaki’s TVS")#linebreak()#text(" (MR0910295 (88g:46002)), so Weil may have done it first after all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hilbert’s fifth problem and Gleason metrics « What’s new")]], [#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/#comment-54024")[#strong[#text("Hilbert’s fifth problem and Gleason metrics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2011")])]

#text("[…] space, it must be isomorphic to a finite-dimensional vector space with the usual topology (see this blog post for a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e11019d8052cfafc8b4ca3f4790c9008393005d142d44e53d862697b2c98f5b3-961813b524da733bfaf25d6a2ab59a63652bc72603d934630028f3234fece9ff.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wildildildlife")]], [#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/#comment-126527")[#strong[#text("wildildildlife")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2012")])]

#text("In the first sentence below the head ‘1. Proof of Theorem 2 ‘, and in Corollary 3, you write ‘topological space’ which should be ‘topological vector space’.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6598694526cf1985410ebd735b6dfa658d8db6fe2c9b8394acc91684d11add4f-2a8c5d384c4fc4dc48c68ad1919569e2971893800148cab32c07e26dc4bbd626.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Hevener")]], [#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/#comment-141944")[#strong[#text("Richard Hevener")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2012")])]

#text("Thanks for a very nice treatment of these results.")

#text("I believe the last part of your proof of Thm. 2 can be simplified quite a bit: Given your U, by the continuity of scalar mult., we can find a nbhd. U’ of the origin and a nbhd. N = (-e,e) of 0 such that if x is in U’ and s is in N, then sx is in U. As at the end of your argument, since U avoids the unit sphere, U’ must be contained in the 1/e ball.")

#emph[#text("[Simplification incorporated, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6598694526cf1985410ebd735b6dfa658d8db6fe2c9b8394acc91684d11add4f-2a8c5d384c4fc4dc48c68ad1919569e2971893800148cab32c07e26dc4bbd626.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Hevener")]], [#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/#comment-141991")[#strong[#text("Richard Hevener")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2012")])]

#text("Inside the brackets, you should say (-e,e) instead of (1-e,1+e).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6598694526cf1985410ebd735b6dfa658d8db6fe2c9b8394acc91684d11add4f-2a8c5d384c4fc4dc48c68ad1919569e2971893800148cab32c07e26dc4bbd626.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Hevener")]], [#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/#comment-142016")[#strong[#text("Richard Hevener")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2012")])]

#text("One more typo: again inside the braces, it should be (-e,e) instead of (e,e).")

#emph[#text("[Gah! Corrected -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/#comment-244095")[#strong[#text("Number of group topologies on the real line | Mathematical Notes")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2013")]

#text("[…] locally compact topological vector space is finite-dimensional (the reader might see Tao’s article on his blog or Bourbaki’s book, Topological vector spaces). Therefore, the weak topologies […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/faf28f5bc1d877ce352114bf945a6b568c9934738d25674c1e82ed75e998b8e2-fe3398e923a1f21989d339ff765c0dfbc9b9e6cabf18bc787564793b12206539.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kasper Henriksen")]], [#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/#comment-453844")[#strong[#text("Kasper Henriksen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2015")])]

#text("I think I’ve found a slightly different argument that doesn’t require introducing an open neighbourhood $U$ of $0$. If $\\dim V = 0$, there is obviously nothing to prove. Otherwise we can write $V$ as the union of its one-dimensional subspaces (“L” is for lines):")#linebreak()#text(" ")#tao-fit-display[#mitex("\\mathcal{L} = \\{L \\subseteq V : L \\leq V,\\ \\dim L = 1\\}.")]#linebreak()#text(" Then")#linebreak()#text(" \\[ \\bigcap_n 2^{-n}K")#linebreak()#text(" = \\bigcup_{L \\in \\mathcal{L}} \\left(\\bigcap_n 2^{-n}K \\cap L\\right)")#linebreak()#text(" = \\bigcup_{L \\in \\mathcal{L}} \\{0\\}")#linebreak()#text(" = \\{0\\}")#linebreak()#text(" \\]")#linebreak()#text(" by compactness of $K \\cap L$ and the fact that $L \\cong \\mathbb F$.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/#comment-460400")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2015")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("in an infinite-dimensional normed vector space ")#mi("V")#text(" with the strong topology, an iteration of the Riesz lemma shows that the closed unit ball ")#mi("B")#text(" in that space contains an infinite sequence with no convergent subsequence, which (")#emph[#text("by the Heine-Borel theorem")]#text(") implies that ")#mi("V")#text(" cannot be locally compact.")
]

#text("Would you elaborate how the Heine-Borel theorem (which says that in a metric space a subset is compact if and only if it is complete and totally bounded) is used here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/#comment-460412")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2015")])]

#text("The formulation of the Heine-Borel theorem I am using here is that for a metric space X, the properties of (a) being topologically compact (every open cover has a finite subcover), (b) sequentially compact (every sequence has a convergent subsequence), and (c) being complete and totally bounded, are equivalent. For this particular application only the equivalence of (a) and (b) is needed.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/#comment-460401")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2015")])]

#text("What does the “usual topology” mean in the statement of Theorem 2? Let ")#mi("(X,\\tau)")#text(" be a hausdorff TVS (over ")#mi("\\bf{R}")#text(") of finite dimension ")#mi("d")#text(". Do you mean that ")#mi("\\tau")#text(" must be the standard topology on ")#mi("{\\bf R}^d")#text(", which means you are ")#emph[#text("identifying")]#text(" ")#mi("X")#text(" with ")#mi("{\\bf R}^d")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/#comment-460413")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2015")])]

#text("Yes. Or more precisely, one selects a linear isomorphism between ")#mi("X")#text(" and ")#mi("{\\bf R}^d")#text(", and then uses this isomorphism to pull back the usual topology on ")#mi("{\\bf R}^d")#text(". This is independent of the choice of isomorphism, because all linear maps from ")#mi("{\\bf R}^d")#text(" to itself are automatically continuous in the standard topology.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/febddf0ae40a02fe94a6fb7d4b7393c10459b251689cb22a90ac4017bc85940f-f86be7f2e57fb401afeea419774343730d1618178cb9e7e0f31074c2f2f604ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/#comment-517217")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2019")])]

#text("In the proof of Theorem 1, why does ")#mi("2^{-n}K \\subset U")#text(" for some large enough ")#mi("n")#text("? From compactness there exists a finite set ")#mi("F")#text(" such that, ")#mi("K\\subset \\bigcup_{i\\in F} 2^i U")#text(". It seems for me that the (non-obvious, and probably not true) fact that for ")#mi("i<j")#text(", ")#mi("2^iU \\subset 2^jU")#text(", was used.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/febddf0ae40a02fe94a6fb7d4b7393c10459b251689cb22a90ac4017bc85940f-f86be7f2e57fb401afeea419774343730d1618178cb9e7e0f31074c2f2f604ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/#comment-517219")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2019")])]

#text("I’ve looked up more. I found that we can assume without loss of generality that U is a balanced set, which fixes every problem I had earlier.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3672c5bb32afd30bc6b8fb086b180b3ec38ad24adb0992ab16725b2d61326b5-b049f18ececbb3da60d4908519ba58192f4310448c455d53c3dc71c287302b35.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jochen Wengenroth")]], [#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/#comment-673797")[#strong[#text("Jochen Wengenroth")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2023")])]

#text("Theorem 2 is stated and proved in A. Tychonoff, Ein Fixpunktsatz, Math. Ann. 111, 767–776 (1935).")
]
