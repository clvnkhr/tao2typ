// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/
// Converted to Typst by tao2typ: "2026-10-14T15:16:55.950595+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Kakeya conjecture and the Ham Sandwich theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Kakeya conjecture and the Ham Sandwich theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 November 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/")[#text("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of my favourite family of conjectures (and one that has preoccupied a ")#link("http://www.math.ucla.edu/~tao/preprints/kakeya.html")[#text("significant fraction")]#text(" of my own research) is the family of ")#link("http://en.wikipedia.org/wiki/Kakeya_conjecture#Kakeya_conjecture")[#text("Kakeya conjectures")]#text(" in geometric measure theory and harmonic analysis. There are many (not quite equivalent) conjectures in this family. The cleanest one to state is the set conjecture:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("http://en.wikipedia.org/wiki/Kakeya_conjecture#Kakeya_conjecture")[#strong[#text("Kakeya set conjecture")]#text(":")]#text(" Let ")#mi("n \\geq 1")#text(", and let ")#mi("E \\subset {\\Bbb R}^n")#text(" contain a unit line segment in every direction (such sets are known as ")#emph[#text("Kakeya sets")]#text(" or ")#emph[#text("Besicovitch sets")]#text("). Then E has ")#link("http://en.wikipedia.org/wiki/Hausdorff_dimension")[#text("Hausdorff dimension")]#text(" and ")#link("http://en.wikipedia.org/wiki/Minkowski_dimension")[#text("Minkowski dimension ")]#text("equal to n.")
]

#text("One reason why I find these conjectures fascinating is the sheer variety of mathematical fields that arise both in the partial results towards this conjecture, and in the applications of those results to other problems. See for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=1660476")[#text("this survey of Wolff")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1820041")[#text("my Notices article")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2358378")[#text("this article of Łaba")]#text(" on the connections between this problem and other problems in Fourier analysis, PDE, and additive combinatorics; there have even been some connections ")#link("http://www.ams.org/mathscinet-getitem?mr=1863693")[#text("to number theory")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2206765")[#text("to cryptography")]#text(". At the other end of the pipeline, the mathematical tools that have gone ")#emph[#text("into")]#text(" the proofs of various partial results have included:")

#list(
[#text("Maximal functions, covering lemmas, ")#mi("L^2")#text(" methods (")#link("http://www.ams.org/mathscinet-getitem?mr=447949")[#text("Cordoba")]#text(", Strömberg, ")#link("http://www.ams.org/mathscinet-getitem?mr=433117")[#text("Cordoba-Fefferman")]#text(");")],
[#text("Fourier analysis (")#link("http://www.ams.org/mathscinet-getitem?mr=466470")[#text("Nagel-Stein-Wainger")]#text(");")],
[#text("Multilinear integration (")#link("http://www.ams.org/mathscinet-getitem?mr=684547")[#text("Drury")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=763948")[#text("Christ")]#text(")")],
[#text("Paraproducts (")#link("http://www.ams.org/mathscinet-getitem?mr=1711029")[#text("Katz")]#text(");")],
[#text("Combinatorial incidence geometry (")#link("http://www.ams.org/mathscinet-getitem?mr=1097257")[#text("Bourgain")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1363209")[#text("Wolff")]#text(");")],
[#text("Multi-scale analysis (")#link("http://www.ams.org/mathscinet/search/publdoc.html?pg1=MR&s1=1393383&loc=fromreflist")[#text("Barrionuevo")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1804528")[#text("Katz-Łaba-Tao")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1866801")[#text("Łaba-Tao")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1960122")[#text("Alfonseca-Soria-Vargas")]#text(");")],
[#text("Probabilistic constructions (")#link("http://www.ams.org/mathscinet-getitem?mr=2367175")[#text("Bateman-Katz")]#text(", ")#link("http://arxiv.org/abs/math/0703559")[#text("Bateman")]#text(");")],
[#text("Additive combinatorics and graph theory (")#link("http://www.ams.org/mathscinet-getitem?mr=1692486")[#text("Bourgain")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1804528")[#text("Katz-Łaba-Tao")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1739220")[#text("Katz-Tao")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1945284")[#text("Katz-Tao")]#text(");")],
[#text("Sum-product theorems (")#link("http://www.ams.org/mathscinet-getitem?mr=2053599")[#text("Bourgain-Katz-Tao")]#text(");")],
[#text("Bilinear estimates (")#link("http://www.ams.org/mathscinet-getitem?mr=1625056")[#text("Tao-Vargas-Vega")]#text(");")],
[#text("Perron trees (Perron, ")#link("http://www.ams.org/mathscinet-getitem?mr=146698")[#text("Schoenberg")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1664129")[#text("Keich")]#text(");")],
[#text("Group theory (")#link("http://www.ams.org/mathscinet-getitem?mr=2157367")[#text("Katz")]#text(");")],
[#text("Low-degree algebraic geometry (")#link("http://www.ams.org/mathscinet-getitem?mr=1631271")[#text("Schlag")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2225076")[#text("Tao")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2031165")[#text("Mockenhaupt-Tao")]#text(");")],
[#text("High-degree algebraic geometry (")#link("http://arxiv.org/abs/0803.2336")[#text("Dvir")]#text(", ")#link("http://arxiv.org/abs/0808.2499")[#text("Saraf-Sudan")]#text(");")],
[#text("Heat flow monotonicity formulae (")#link("http://www.ams.org/mathscinet-getitem?mr=2275834")[#text("Bennett-Carbery-Tao")]#text(")")]
)

#text("[This list is not exhaustive.]")

#text("Very recently, I was pleasantly surprised to see yet another mathematical tool used to obtain new progress on the Kakeya conjecture, namely (a generalisation of) the famous ")#link("http://en.wikipedia.org/wiki/Ham_sandwich_theorem")[#text("Ham Sandwich theorem")]#text(" from algebraic topology. This was recently used ")#link("http://arxiv.org/abs/0811.2251")[#text("by Guth")]#text(" to establish a certain endpoint multilinear Kakeya estimate left open by the work ")#link("http://www.ams.org/mathscinet-getitem?mr=2275834")[#text("of Bennett, Carbery, and myself")]#text(". With regards to the Kakeya set conjecture, Guth’s arguments assert, roughly speaking, that the only Kakeya sets that can fail to have full dimension are those which obey a certain “planiness” property, which informally means that the line segments that pass through a typical point in the set must be essentially coplanar. (This property first surfaced in my ")#link("http://www.ams.org/mathscinet-getitem?mr=1804528")[#text("paper with Katz and Łaba")]#text(".) Guth’s arguments can be viewed as a partial analogue of ")#link("http://arxiv.org/abs/0803.2336")[#text("Dvir’s arguments")]#text(" in the finite field setting (which I discussed in ")#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/")[#text("this blog post")]#text(") to the Euclidean setting; in particular, both arguments rely crucially on the ability to create a polynomial of controlled degree that vanishes at or near a large number of points. Unfortunately, while these arguments fully settle the Kakeya conjecture in the finite field setting, it appears that some new ideas are still needed to finish off the problem in the Euclidean setting. Nevertheless this is an interesting new development in the long history of this conjecture, in particular demonstrating that the polynomial method can be successfully applied to continuous Euclidean problems (i.e. it is not confined to the finite field setting).")

#text("In this post I would like to sketch some of the key ideas in Guth’s paper, in particular the role of the Ham Sandwich theorem (or more precisely, a polynomial generalisation of this theorem first observed ")#link("http://www.ams.org/mathscinet-getitem?mr=1978494")[#text("by Gromov")]#text(").")

#heading(level: 1)[#metadata(none) <tao-dec4cdadca0f8e31a174>#text("— The polynomial Ham Sandwich theorem —")]

#text("Let us first recall the classical Ham Sandwich theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("http://en.wikipedia.org/wiki/Ham_sandwich_theorem")[#strong[#text("Ham Sandwich theorem. ")]]#text(" Let ")#mi("U_1, \\ldots, U_n")#text(" be n bounded open sets in ")#mi("{\\Bbb R}^n")#text(". Then there exists a ")#link("http://en.wikipedia.org/wiki/Hyperplane")[#text("hyperplane")]#text(" in ")#mi("{\\Bbb R}^n")#text(" that divides each of the open sets ")#mi("U_1,\\ldots,U_n")#text(" into two sets of equal volume.")
]

#text("(The name of the theorem derives from the special case when ")#mi("n=3")#text(" and ")#mi("U_1,U_2,U_3")#text(" are two slices of bread and a slice of ham. One can view this theorem as a “thickened” version of the Euclidean geometry axiom that every n points in ")#mi("{\\Bbb R}^n")#text(" determine at least one hyperplane.)")

#text("There are many proofs of this theorem, but I will focus on the proof that is based on the Borsuk-Ulam theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("http://en.wikipedia.org/wiki/Borsuk%E2%80%93Ulam_theorem")[#strong[#text("Borsuk-Ulam theorem")]]#text(": Let ")#mi("f: S^n \\to {\\Bbb R}^n")#text(" be a continuous map from the n-dimensional sphere ")#mi("S^n \\subset {\\Bbb R}^{n+1}")#text(" to the Euclidean space ")#mi("{\\Bbb R}^n")#text(" which is antipodal (which means that ")#mi("f(-x)=-f(x)")#text(" for all ")#mi("x \\in S^n")#text(". Then ")#mi("f(x)=0")#text(" for at least one ")#mi("x \\in S^n")#text(".")
]

#strong[#text("Proof.")]#text(" (Sketch) The set of zeroes of an antipodal map automatically come in antipodal pairs x,-x. To prove the theorem, we shall establish the stronger fact that ")#mi("f(x)=0")#text(" for an odd number of disjoint antipodal pairs, counting multiplicity (avoiding the degenerate antipodal maps which vanish at an infinite set of points). To see this, first observe that this is true for at least one antipodal map (e.g. one can use the horizontal projection map ")#mi("(x_1,\\ldots,x_{n+1}) \\mapsto (x_1,\\ldots,x_n)")#text("). Also, the space of all antipodal maps is a vector space, and thus connected (though it takes some effort to show that the space of ")#emph[#text("non-degenerate")]#text(" antipodal maps is still connected). So one just needs to show that the parity of the number of pairs of antipodal points where f vanishes (counting multiplicity) is unchanged with respect to continuous deformations of f. But some elementary ")#link("http://en.wikipedia.org/wiki/Degree_(continuous_map)")[#text("degree")]#text(" theory (or ")#link("http://en.wikipedia.org/wiki/Morse_theory")[#text("Morse theory")]#text(") shows that any (non-degenerate) perturbation of f can annihilate two such antipodal pairs by collision, or (by the reverse procedure) spontaneously create two such antipodal pairs from nothing, but cannot otherwise affect the number of pairs; thus the parity of the number of such pairs remains invariant. (It takes some non-trivial effort to make this informal argument rigorous; see for instance ")#link("http://kam.mff.cuni.cz/~matousek/bu-zhbu.ps.gz")[#text("this chapter")]#text(" of ")#link("http://kam.mff.cuni.cz/~matousek/akt.html")[#text("Matousek’s book ")]#text("on the Borsuk-Ulam theorem, which also contains a number of other proofs of this result. [Thanks to Benny Sudakov for this great reference.] One can also formalise this argument using the language of ")#mi("{\\Bbb Z}_2")#text(" ")#link("http://en.wikipedia.org/wiki/Singular_cohomology")[#text("singular cohomology")]#text(".) ")#mi("\\Box")

#strong[#text("Remark 1.")]#text(" The Borsuk-Ulam theorem is tied to the more general theory of ")#link("http://en.wikipedia.org/wiki/Lyusternik-Schnirelmann_category")[#text("Lyusternik-Schnirelmann category")]#text(", which is the viewpoint taken in Guth’s paper, but we will not explicitly use this theory here. ")#mi("\\diamond")

#strong[#text("Proof of the Ham-Sandwich theorem using the Borsuk-Ulam theorem.")]#text(" We can identify ")#mi("{\\Bbb R}^{n+1}")#text(" with the space of affine-linear forms ")#mi("(x_1,\\ldots,x_n) \\mapsto a_1 x_1 + \\ldots + a_n x_n + a_0")#text(" on ")#mi("{\\Bbb R}^n")#text(". Each non-trivial affine-linear form ")#mi("P \\in {\\Bbb R}^{n+1} \\backslash 0")#text(" determines a hyperplane ")#mi("\\{P=0\\}")#text(" that divides ")#mi("{\\Bbb R}^n")#text(" into two half-spaces ")#mi("\\{ P > 0 \\}")#text(" and ")#mi("\\{P < 0\\}")#text(". We can then define ")#mi("f: {\\Bbb R}^{n+1} \\backslash \\{0\\} \\to {\\Bbb R}^n")#text(" to be the function whose ")#mi("j^{th}")#text(" coordinate ")#mi("f_j(P)")#text(" at P is the volume of ")#mi("U_j \\cap \\{ P > 0 \\}")#text(" minus the volume of ")#mi("U_j \\cap \\{ P < 0 \\}")#text("; thus f measures the extent to which the hyperplane ")#mi("\\{P=0\\}")#text(" fails to bisect all of the ")#mi("U_1,\\ldots,U_n")#text(". It is easy to see that f is continuous, homogeneous of degree zero, and odd, and so its restriction to ")#mi("S^n")#text(" is an antipodal map. By the Borsuk-Ulam theorem, there exists P such that ")#mi("f(P)=0")#text(", and the claim follows. ")#mi("\\Box")

#link("http://www.ams.org/mathscinet-getitem?mr=1978494")[#text("Gromov observed")]#text(" the following polynomial generalisation of the Ham Sandwich theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Polynomial Ham Sandwich theorem.")]#text(" Let ")#mi("d \\geq 1")#text(", and let ")#mi("U_1, \\ldots, U_{\\binom{n+d}{d} - 1}")#text(" be bounded open sets in ")#mi("{\\Bbb R}^n")#text(". Then there exists a non-trivial polynomial ")#mi("P: {\\Bbb R}^n \\to {\\Bbb R}")#text(" of degree at most d such that the sets ")#mi("\\{ P > 0 \\}")#text(", ")#mi("\\{ P < 0 \\}")#text(" partition each of the ")#mi("U_1,\\ldots,U_{\\binom{n+d}{d}-1}")#text(" into two sets of equal measure.")
]

#text("Note that the ordinary Ham-Sandwich theorem corresponds to the d=1 case of this theorem. This theorem can be deduced from the Borsuk-Ulam theorem in exactly the same way that the ordinary one is (note that the space of polynomials of degree at most d has dimension ")#mi("\\binom{n+d}{d}")#text("; the continuity of the appropriate antipodal function ")#mi("f: S^{\\binom{n+d}{d}-1} \\to {\\Bbb R}^{\\binom{n+d}{d}-1}")#text(" follows from the ")#link("http://en.wikipedia.org/wiki/Dominated_convergence_theorem")[#text("dominated convergence theorem")]#text(" and the basic observation that a non-trivial polynomial is non-zero almost everywhere).")

#strong[#text("Remark 2. ")]#text(" One can also deduce the polynomial Ham Sandwich theorem directly from the ordinary Ham Sandwich theorem (in ")#mi("\\binom{n+d}{d}-1")#text(" dimensions) by embedding ")#mi("{\\Bbb R}^n")#text(" into ")#mi("{\\Bbb R}^{\\binom{n+d}{d}-1}")#text(" via the ")#link("http://en.wikipedia.org/wiki/Veronese_surface")[#text("Veronese embedding")]#text(", and then thickening the images of ")#mi("U_1,\\ldots,U_{\\binom{n+d}{d}-1}")#text(" slightly in an appropriate fashion; we leave the details as an exercise to the reader. ")#mi("\\diamond")

#text("The polynomial Ham Sandwich theorem should be compared with the following finitary counterpart, which morally corresponds to the case when all the ")#mi("U_j")#text(" are points (but works over arbitrary fields F), and which was a key tool in ")#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/")[#text("Dvir’s proof of the Kakeya conjecture in finite fields")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma.")]#text(" Let ")#mi("d \\geq 1")#text(" and let ")#mi("u_1,\\ldots,u_{\\binom{n+d}{d}-1}")#text(" be points in ")#mi("F^n")#text(" for some field F. Then there exists a non-trivial polynomial ")#mi("P: F^n \\to F")#text(" of degree at most d which vanishes on all of ")#mi("u_1,\\ldots,u_{\\binom{n+d}{d}-1}")#text(".")
]

#strong[#text("Proof.")]#text(" The evaluation map ")#mi("P \\mapsto (P(u_1),\\ldots,P(u_{\\binom{n+d}{d}-1})")#text(" is a linear map from a ")#mi("\\binom{n+d}{d}")#text("-dimensional space to a ")#mi("\\binom{n+d}{d}-1")#text("-dimensional space, and must therefore have a non-trivial kernel. ")#mi("\\Box")

#heading(level: 1)[#text("— Connection with the Kakeya problem —")]

#text("Now we connect the polynomial Ham Sandwich theorem to the Kakeya problem. We begin by replacing the continuous Kakeya set conjecture with a more quantitative “")#mi("\\delta")#text("-discretised” problem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("http://en.wikipedia.org/wiki/Kakeya_conjecture#Kakeya_maximal_function")[#strong[#text("Kakeya maximal conjecture.")]]#text(" Let ")#mi("0 < \\delta < 1")#text(", and let ")#mi("T_1, \\ldots, T_M")#text(" be a collection of ")#mi("\\delta \\times 1")#text(" cylindrical tubes pointing in a ")#mi("\\delta")#text("-separated set of directions (thus the directions of any two of the tubes make an angle of at least ")#mi("\\delta")#text("). For each ")#mi("\\mu \\geq 1")#text(", let ")#mi("E_\\mu")#text(" be the set of points x which are contained in at least ")#mi("\\mu")#text(" of the tubes ")#mi("T_1,\\ldots,T_M")#text(". Then the volume ")#tao-math("\\left|E_\\mu\\right|", block: false)#text(" of ")#mi("E_\\mu")#text(" obeys the bound ")#tao-math("\\left|E_\\mu\\right| \\lesssim_{\\varepsilon} \\delta^{-\\varepsilon} \\mu^{-n/(n-1)}", block: false)#text(" for any ")#mi("\\varepsilon > 0")#text(".")
]

#text("Here we are using the asymptotic notation that ")#mi("X \\gtrsim Y")#text(" if ")#mi("X \\geq cY")#text(" for some positive constant c (if the ")#mi("\\gtrsim")#text(" is subscripted by parameters, this indicates that c is allowed to depend on those parameters); we always allow constants to depend on the dimension n. This conjecture (which is limiting the extent to which tubes in different directions can overlap) implies the Kakeya set conjecture (for both Minkowski and Hausdorff dimension) by fairly standard arguments from geometric measure theory, see e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=1097257")[#text("this paper of Bourgain")]#text(" or ")#link("http://www.math.ucla.edu/%7Etao/254b.1.99s/notes5.dvi")[#text("these lecture notes of myself")]#text(". The factor of ")#mi("\\mu^{-n/(n-1)}")#text(" is natural (and best possible), as can be seen by considering the example in which ")#mi("M \\sim \\delta^{1-n}")#text(" and all the tubes pass through a common point.")

#text("[The name “")#link("http://en.wikipedia.org/wiki/Kakeya_conjecture#Kakeya_maximal_function")[#text("maximal conjecture")]#text("” has to do with the formulation of the above conjecture involving the Kakeya maximal function, which I will not discuss here.]")

#text("The maximal conjecture (and the set conjecture) is verified in the two-dimensional case ")#mi("n=2")#text(" (with the one-dimensional case ")#mi("n=1")#text(" being trivial), but only partial results are known in higher dimensions. However, one can do better if one only considers certain types of overlap. Let us say (somewhat informally) that a point x has ")#emph[#text("non-planar multiplicity")]#text(" ")#mi("\\gtrsim \\mu")#text(" with respect to a given collection of tubes ")#mi("T_1,\\ldots,T_M")#text(" if there exist ")#mi("n")#text(" separate families of ")#mi("\\gtrsim \\mu")#text(" tubes each passing through x, such that given any ")#mi("n")#text(" tubes from each of these ")#mi("n")#text(" families, the solid angle between the ")#mi("n")#text(" directions is comparable to 1. (Informally, this is a stronger assertion than saying that x has ")#mi("\\gtrsim \\mu")#text(" tubes passing through it, because we prohibit these tubes from being essentially contained in a hyperplane). Then, as a special case of Guth’s results, one has")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Multilinear Kakeya conjecture (special case):")]#text(" Let ")#mi("\\delta, n, T_1,\\ldots,T_M, \\mu")#text(" be as in the Kakeya maximal conjecture, and let ")#mi("E_\\mu^*")#text(" be the set of points with non-planar multiplicity ")#mi("\\gtrsim \\mu")#text(". Then ")#tao-math("\\left|E_\\mu^*\\right| \\lesssim \\mu^{-n/(n-1)}", block: false)#text(".")
]

#text("Informally, this implies that the only counterexamples to the Kakeya maximal conjecture can come from configurations of tubes such that the tubes that pass through a typical point largely lie in a hyperplane. A previous ")#link("http://www.ams.org/mathscinet-getitem?mr=2275834")[#text("paper of Bennett, Carbery, and myself")]#text(" established this estimate with an additional loss of ")#mi("\\delta^\\varepsilon")#text(" by a totally different method (based on heat flow monotonicity formulae). For a precise statement of the full multilinear Kakeya conjecture (which is now proven without any epsilon loss), I refer you to that paper (or the ")#link("http://arxiv.org/abs/0811.2251")[#text("paper of Guth")]#text(").")

#text("Let’s now sketch why the above result is true (details can be found in the ")#link("http://arxiv.org/abs/0811.2251")[#text("paper of Guth")]#text("). I’ll drop the dependence of implied constants on n. Let ")#mi("x_1,\\ldots,x_A")#text(" be a maximal ")#mi("\\delta")#text("-net of ")#mi("E^*_\\mu")#text(" (i.e. a set of ")#mi("\\delta")#text("-separated points in ")#mi("E^*_\\mu")#text(" that is maximal with respect to set inclusion), then it will suffice to show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1).")])
#mitex("A \\lesssim \\delta^{-n} \\mu^{-n/(n-1)}")]]

#text("Let ")#mi("Q_j")#text(" be the cube of sidelength ")#mi("\\delta")#text(" centred at ")#mi("x_j")#text(" with sides parallel to the axes. Applying the polynomial Ham Sandwich theorem, we can find a non-trivial polynomial P of degree ")#mi("O( A^{1/n})")#text(" whose zero locus ")#mi("V := \\{P=0\\}")#text(" bisects each of the cubes ")#mi("Q_1,\\ldots,Q_A")#text(".")

#text("For each j, we claim that the hypersurfaces ")#mi("V \\cap Q_j")#text(" have surface area ")#mi("\\gtrsim \\delta^{n-1}")#text(". Indeed, if instead one of the ")#mi("V \\cap Q_j")#text(" had surface area ")#mi("o(\\delta^{n-1})")#text(", this would imply that the projection of ")#mi("V \\cap Q_j")#text(" to any (n-1)-dimensional coordinate subspace of ")#mi("Q_j")#text(" has area ")#mi("o(\\delta^{n-1})")#text(", in contrast with the projection of ")#mi("Q_j")#text(" itself which has area ")#mi("\\delta^{n-1}")#text(". Thus for each ")#mi("1 \\leq i \\leq n")#text(" the complement of V in ")#mi("Q_j")#text(" contains a subset of ")#mi("Q_j")#text(" of relative density ")#mi("1-o(1)")#text(" that consists entirely of line segments of length ")#mi("\\delta")#text(" in the basis direction ")#mi("e_i")#text(". From this it is not hard to see that ")#mi("Q_j \\backslash V")#text(" contains a path-connected component of relative density ")#mi("1-o(1)")#text(", which contradicts the claim that ")#mi("V")#text(" bisects ")#mi("Q_j")#text(".")

#text("On the other hand, we know that ")#mi("Q_j")#text(" meets ")#mi("\\gtrsim \\mu")#text(" tubes ")#mi("T_k")#text(", which are arranged in a non-planar fashion. Because of this, one can show that for a “typical” tube ")#mi("T_k")#text(" hitting ")#mi("Q_j")#text(", the projection of ")#mi("V \\cap Q_j")#text(" to the orthogonal complement of the direction of ")#mi("T_k")#text(" has area ")#mi("\\gtrsim \\delta^{n-1}")#text(". (Basically, the point is that at any given point of ")#mi("V \\cap Q_j")#text(", the normal vector cannot be perpendicular (or close to perpendicular) to all the directions of all the ")#mi("T_k")#text(" simultaneously, due to non-planarity.) To simplify the exposition, let us assume that in fact ")#emph[#text("all")]#text(" tubes ")#mi("T_k")#text(" touching ")#mi("Q_j")#text(" are typical.")

#text("Each ")#mi("Q_j")#text(" touches ")#mi("\\sim \\mu")#text(" tubes ")#mi("T_k")#text(" (they may touch more than this, but for sake of exposition let us suppose that they touch exactly this number of tubes). By ")#link("http://en.wikipedia.org/wiki/Double_counting_(proof_technique)")[#text("double counting")]#text(", this means that each tube ")#mi("T_k")#text(" touches about")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\lambda := A \\mu / M \\gtrsim \\delta^{n-1} A \\mu")]]

#text("cubes ")#mi("Q_j")#text(" on the average, where the inequality in (2) comes from the ")#mi("\\delta")#text("-separated directions of the tubes. In particular, we can find a (typical) tube ")#mi("T_k")#text(" which touches at least ")#mi("\\lambda")#text(" such balls. Let ")#mi("v_k")#text(" be the direction vector of ")#mi("T_k")#text(".")

#text("Now look at ")#mi("V \\cap T_k")#text(". (Technically, one has to replace ")#mi("T_k")#text(" by a slight thickening of itself here, but let us ignore this technicality.) This set contains ")#mi("\\gtrsim \\lambda")#text(" disjoint sets of the form ")#mi("V \\cap Q_j")#text(". Each of these sets, when projected to the orthogonal complement of ")#mi("T_k")#text(", has measure ")#mi("\\gtrsim \\delta^{n-1}")#text(". On the other hand, ")#mi("T_k")#text(" itself, when projected to this complement, has a measure of ")#mi("O(\\delta^{n-1})")#text(". By the pigeonhole principle, we may thus find a positive measure family of lines ")#mi("\\ell")#text(" in the direction ")#mi("v_k")#text(" passing through ")#mi("T_k")#text(" which intersect at ")#mi("\\gtrsim \\lambda")#text(" of the ")#mi("V \\cap Q_j")#text(". In particular, all lines ")#mi("\\ell")#text(" in this family intersect V in ")#mi("\\gtrsim \\lambda")#text(" different points.")

#text("On the other hand, the restriction of P to ")#mi("\\ell")#text(" is a polynomial of degree ")#mi("O( A^{1/n} )")#text(". If this degree is much less than ")#mi("\\lambda")#text(", this forces P to vanish on each line ")#mi("\\ell")#text(" [cf. ")#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/")[#text("Dvir’s argument")]#text("]; since the set of such lines has positive measure, this forces P to be identically zero, a contradiction. Hence we must have")

#align(center)[#tao-fit-display[#mitex("A^{1/n} \\gtrsim \\lambda")]]

#text("which when combined with (2), gives (1).")

#heading(level: 1)[#text("Comments (22)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-33677")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2008")])]

#text("Errata:")

#text("When The Polynomial Ham Sanwich theorem is stated, the subindex of the sets ")#mi("U")#text(" are not well writed. It may be changed ")#mi("U_n")#text(" by ")#mi("U_{\\binom{n+d}{d}-1}")#text(".")

#text("Yours,")

#text("Jordi-Lluis Figeras Romero")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-33685")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2008")])]

#text("Why do you call it “Borsak-Ulam theorem” instead of “Borsuk-Ulam theorem”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-33691")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2008")])]

#text("Thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3be9bda587877fdef1ff3139bfcb76a628eb928f219960590f1b226772289815-9e3951eb3553e765bc07e16c1dc236ad627fde566927a3ebe927dc17a70d0a49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of terence tao’s blog « orgtheory.net")]], [#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-33704")[#strong[#text("terence tao’s blog « orgtheory.net")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2008")])]

#text("[…] simply called “What’s new?” Much of it is research level math (e.g., “The Kakeya Conjecture and the Ham Sandwich Theorem“), but I think any practicing academic might enjoy his career advice. Skip over parts that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-33706")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2008")])]

#text("I have a related question about theorem naming/attribution. In your additive combinatorics book, on numerous occasions you use a non-lexicographical name for a theorem (such as, say, the “Bob-Alice theorem”). I don’t want to give specific examples as to not make this into a discussion involving specific results/individuals, but a glance through the index will produce several example. Is there a particular significance to these cases?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-33710")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2008")])]

#text("One I can think of is “Balog-Szemeredi-Gowers theorem”. This result states that if a set ")#mi("A")#text(" inside some ambient abelian group has many additive quadruples then there is a large subset of ")#mi("A")#text(" which has small doubling. The theorem was proved in this qualitative form by Balog and Szemeredi, but some time later Tim Gowers supplied a new proof that gave much more quantitative information concerning the relationship between “many” and “large” in the above statement. In the form that the result is typically used, it should perhaps be called “Gowers’ theorem”, but that would be to ignore the contribution of Balog and Szemeredi in identifying that this was the right kind of question to ask. One might talk, then, of a result of Balog-Szemeredi and Gowers, in which case the standard ordering seems to be the right one. Another factor in this is that Gowers generally talks of “the Balog-Szemeredi theorem” in his lectures and papers, and so to many of us in the subject the words Balog and Szemeredi simply cannot be split in this context.")

#text("I’m interested to know how generally well-known it is that pure mathematicians use simple alphabetical ordering on their papers, a practice that does not seem to be the norm in other branches of science, where the ordering conveys all sorts of mysterious information. For example, has Terry himself ever received comment on his being the second, third or fourth author on the great majority of his papers?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tom")]], [#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-33716")[#strong[#text("tom")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2008")])]

#text("The practice of using strict lexicographical ordering of authors is probably not-well known at all outside pure maths. Now if we look at ")#link("http://en.wikipedia.org/wiki/Category:Mathematical_theorems")[#text("a list of theorems on wikipedia")]#text(" we see such a rule does suffer regularly some exceptions when one wishes to convey some chronological information (e.g. the theorems called Heine-Borel, Nash-Moser, Poincaré-Hopf… ).")

#text("The “mysterious information” Ben alludes to is in fact quite rational, it’s just some folk knowledge one learns along the way, e.g. in biology the last name is that of the big boss, the first one that of the hard-working postdoc, and those in between being other less-involved postdocs/senior guys/lab technicians.")

#text("As long as people are aware that other rules may apply outside of their own area, I would imagine no serious confusion would arise.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asdf")]], [#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-33755")[#strong[#text("asdf")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2008")])]

#text("The mathematics in this post is no doubt very interesting, but I’m unable to think about it because the repeated mention of ham sandwiches has made me hungry. Off to dinner!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcb7765dcebcb66b358418fd292f07b386c0a7291a90aeb9f6bca628bfb97942-d37902696adeaffae267d8a41e7d46cff565608798c847245651b7b074aca171.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spencer")]], [#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-35505")[#strong[#text("Spencer")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("Hi everyone,")

#text("Perhaps somebody here could shed some light on the following for me:")

#text("In Prof. Tao’s 1999 paper “The Bochner Riesz Conjecture implies the Restriction Conjecture” he states a whole collection of conjectures in harmonic analysis/geometric measure and produces a very helpful diagram (on what is page 372 of the journal in which it appears) depicting the relationships between these conjectures (which ones imply which other ones). This diagram seems to show that Bochner Riesz implies the Minkowski dimension part of the Kakeya set Conjecture.")

#text("Also, on Izabella Laba’s page about conections between Kakeya and harmonic analysis (")#link("http://www.math.ubc.ca/~ilaba/kakeya.html")[#text("http://www.math.ubc.ca/~ilaba/kakeya.html")]#text(") she states that Fefferman’s counterexample to the ball multiplier conjecture “would provide a counterexample to the Bochner-Riesz conjecture, if one could construct a Besicovitch set in Rn of Hausdorff dimension less than n.” So the claim here is surely that Bochner Riesz implies the Hausdorff dimension part of the Kakeya Set Conjecture.")

#text("What has confused me greatly is that there is a paper on the arxiv by Yong Cheol Kim (arXiv:math/0407013v3 [math.CA]) entitled “A proof of the Bochner Riesz Conjecture”.")

#text("The details of most of what I’ve referenced are beyond me at present so I have not checked the maths but I was certainly under the impression that Kakeya had not been solved. Could anyone point out to me what’s gone wrong here?")

#text("Many Thanks,")

#text("Spencer")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-35508")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("Dear Spencer,")

#text("The Kim paper is known to be incorrect, though I do not know why the author (who has acknowledged the error) has not yet withdrawn it from the arXiv.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcb7765dcebcb66b358418fd292f07b386c0a7291a90aeb9f6bca628bfb97942-d37902696adeaffae267d8a41e7d46cff565608798c847245651b7b074aca171.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spencer")]], [#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-35518")[#strong[#text("Spencer")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("Ah right, I thought that that might be the case.")

#text("Many Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Kakeya set and maximal conjectures for algebraic varieties over finite fields « What’s new")]], [#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-36631")[#strong[#text("The Kakeya set and maximal conjectures for algebraic varieties over finite fields « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2009")])]

#text("[…] that has established the endpoint multilinear Kakeya maximal function estimate in this setting, see this blog post for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Recent progress on the Kakeya conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-38694")[#strong[#text("Recent progress on the Kakeya conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2009")])]

#text("[…] bisects a ball, then the intersection of that hypersurface with the ball has a large area; see this blog post for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Guth-Katz bound on the Erdős distance problem « What’s new")]], [#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-48200")[#strong[#text("The Guth-Katz bound on the Erdős distance problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2010")])]

#text("[…] of cell decomposition. A key new insight is that the polynomial method (and more specifically, the polynomial Ham Sandwich theorem, discussed previously on this blog) can be used to efficiently create […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An incidence theorem in higher dimensions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-50819")[#strong[#text("An incidence theorem in higher dimensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2011")])]

#text("[…] Geometry. In this paper we use the polynomial Ham Sandwich method of Guth and Katz (as discussed previously on this blog) to establish higher-dimensional versions of the Szemerédi-Trotter […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-89969")[#strong[#text("拓扑学奇趣之Borsuk-Ulam定理 « Fight with Infinity")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2011")]

#text("[…] Tao The Kakeya conjecture and the Ham Sandwich theorem […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aefe90abfdcf6da2e5cc0db005fc9734c37b2421ad91c5f18ab436fb1a0e0ac9-6fa9516300886fbd323052487d3d436f4797adc69e83d1a4da1222868cd11808.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of El teorema del revuelto de patatas y pimientos | Cifras y Teclas")]], [#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-246438")[#strong[#text("El teorema del revuelto de patatas y pimientos | Cifras y Teclas")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2013")])]

#text("[…] de la demostración en Mathworld, en inglés. También en inglés, te recomiendo esta entrada de Terence Tao. Si prefieres leer algo en español, puedes hacerlo en esta entrada de Pablo Soberón. El propio […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-265922")[#strong[#text("El teorema del revuelto de patatas y pimientos | cocinaymatematicas")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2014")]

#text("[…] tienes una idea de la demostración en Mathworld, en inglés. También en inglés, te recomiendoesta entrada de Terence Tao. Si prefieres leer algo en español, puedes hacerlo en esta entrada de Pablo Soberón. El propio […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a98f3df9b6a5632a4bf0a0fd81541d05b67cf74565788c0ac7e2b54344839a8-9f492533d2b15b4f3760c8e5384c0b7fc68e7d2905a9a6ffcacc05f60becac33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hu")]], [#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-472771")[#strong[#text("Hu")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2016")])]

#text("people have not found counter example with Kakeya set conjecture with any dimension n,do they?")

#emph[#text("[The Kakeya conjecture is currently open – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-518184")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2019")])]

#text("from each of these three families (why three? typo?)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-614631")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2021")])]

#text("Is it possible to show that the extension equivalent version of the restriction conjecture implies Kakeya directly? Without using this very fact, that it’s equivalent to restriction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb93277246d27483db84dbdf8b958efe326e092bd255e477b90b7e0ecb44ab12-86f20ba181a3633c7728b3039c49825d1088a9248cab6746d91b450b369d6de0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kakeya 转针问题 & 何为维度 – 南外数学逻辑与生活社")]], [#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/#comment-637986")[#strong[#text("Kakeya 转针问题 & 何为维度 – 南外数学逻辑与生活社")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2021")])]

#text("[…] Kakeya 猜想与拓扑中的 Ham Sandwich Theorem — ")#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/")[#text("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/")]#text(" […]")
]
