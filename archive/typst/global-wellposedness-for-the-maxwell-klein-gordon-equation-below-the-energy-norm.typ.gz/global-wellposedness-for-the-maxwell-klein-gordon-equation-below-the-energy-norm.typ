// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/10/12/global-wellposedness-for-the-maxwell-klein-gordon-equation-below-the-energy-norm/
// Converted to Typst by tao2typ: "2026-10-14T16:35:54.232241+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Global wellposedness for the Maxwell-Klein-Gordon equation below the energy norm", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Global wellposedness for the Maxwell-Klein-Gordon equation below the energy norm")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 October 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/10/12/global-wellposedness-for-the-maxwell-klein-gordon-equation-below-the-energy-norm/")[#text("https://terrytao.wordpress.com/2009/10/12/global-wellposedness-for-the-maxwell-klein-gordon-equation-below-the-energy-norm/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("http://www.math.umn.edu/~keel/")[#text("Mark Keel")]#text(", ")#link("http://www.math.ucla.edu/~triroy/")[#text("Tristan Roy")]#text(", and I have just uploaded to the arXiv the paper “")#link("http://arxiv.org/abs/0910.1850")[#text("Global well-posedness for the Maxwell-Klein-Gordon equation below the energy norm")]#text("“, submitted to Discrete and Continuous Dynamical Systems. This project started about eight years ago, and was in fact a partial result was essentially finished by 2002, but managed to get put on the backburner for a while due to many other priorities. Anyway, this paper applies the ")#link("http://tosio.math.toronto.edu/wiki/index.php/I-method")[#text("I-method")]#text(" to the ")#link("http://tosio.math.toronto.edu/wiki/index.php/Maxwell-Klein-Gordon_Equations")[#text("Maxwell-Klein-Gordon system of equations")]#text(" in the ")#link("http://tosio.math.toronto.edu/wiki/index.php/Coulomb_gauge")[#text("Coulomb gauge")]#text(" (a simplified model for the hyperbolic Yang-Mills equations) in three spatial dimensions. Previously to this paper, it was known that the Cauchy problem was globally well-posed in the energy norm (which is essentially ")#mi("H^1({\\Bbb R}^3)")#text(") and locally well-posed in ")#mi("H^s({\\Bbb R}^3)")#text(" for ")#mi("s > 1/2")#text(", with this condition being essentially best possible except for the endpoint. Here we manage to lower the regularity threshold for global wellposedness to ")#mi("s > \\sqrt{3}/2 \\approx 0.866")#text(". (The partial result alluded to earlier was for ")#mi("s > 7/8 = 0.875")#text("; at one point we had announced an improvement to ")#mi("5/6 \\approx 0.833")#text(", but the argument turned out to be flawed.) This is part of what is now quite a large family of such “global well-posedness below the energy norm” results, but there are some notable technical features here which were not present in earlier works. Firstly, we can show that there is no smoothing effect in the nonlinearity, ruling out use of the ")#link("http://tosio.math.toronto.edu/wiki/index.php/Fourier_truncation_method")[#text("Fourier truncation method")]#text(". Secondly, due to our use of rescaling, supercritical quantities such as the ")#mi("L^2")#text(" norm are not under control, which necessitates some unusual treatment of the low frequency portions of the scalar and vector fields. Namely, they are estimated in ")#mi("L^p")#text(" spaces rather than ")#mi("L^2")#text(" ones. This complicates a number of tasks, ranging from controlling the elliptic theory, to understanding the coercive nature of the Hamiltonian, to establishing the nonlinear commutator estimates underlying the almost conservation law.")

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aea5dc3ccce4d2998afcba4aa0f5aad07e48c12eadd2ca64e3d67e43b0f88dfc-687143c090ce7cda98eca9ff668ba7e06b5335006c506f530a5e2d912a4a37ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron Sterling")]], [#link("https://terrytao.wordpress.com/2009/10/12/global-wellposedness-for-the-maxwell-klein-gordon-equation-below-the-energy-norm/#comment-41830")[#strong[#text("Aaron Sterling")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2009")])]

#text("I apologize for the off-topic comment, but I’m not sure where to ask this.")

#text("I’m part of a seminar that has started to review Additive Combinatorics, and there’s a fact known as the “Popularity Principle.” (Problem 1.1.4, page 5.) We can’t figure out why it bears this name, and Google doesn’t seem to help. Could someone enlighten me, please?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/12/global-wellposedness-for-the-maxwell-klein-gordon-equation-below-the-energy-norm/#comment-41831")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2009")])]

#text("My blog page for the book,")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("Additive combinatorics")]
]

#text("is probably the most appropriate place for this type of question.")

#text("In any case, the name derives from Gowers’ first paper on his proof of Szemeredi’s theorem, in which he starts with a collection of differences a-b (with a in A and b in B) in a small set, and extracts out the “popular” differences – those differences d with many representations in the form a-b. The point is that most differences a-b (counting multiplicity tend to be popular, simply because unpopular differences d don’t arise from too many pairs (a,b).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aea5dc3ccce4d2998afcba4aa0f5aad07e48c12eadd2ca64e3d67e43b0f88dfc-687143c090ce7cda98eca9ff668ba7e06b5335006c506f530a5e2d912a4a37ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron Sterling")]], [#link("https://terrytao.wordpress.com/2009/10/12/global-wellposedness-for-the-maxwell-klein-gordon-equation-below-the-energy-norm/#comment-41832")[#strong[#text("Aaron Sterling")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2009")])]

#text("Thank you. I’ll post in the right place next time if other things come up. :-)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd4bfb06bd050a989093ed573685723febc2f7fbc97be93869ddd8bab3257fc9-7fe956b9f8b7dae1686b686a0691c02b9667dd8802e8de59c9cf328efac02d71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A semana nos arXivs… « Ars Physica")]], [#link("https://terrytao.wordpress.com/2009/10/12/global-wellposedness-for-the-maxwell-klein-gordon-equation-below-the-energy-norm/#comment-41871")[#strong[#text("A semana nos arXivs… « Ars Physica")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2009")])]

#text("[…] Global well-posedness of the Maxwell-Klein-Gordon equation below the energy norm. (arXiv:0910.1850v1 [math.AP]), com direito a comentários do próprio autor: Global wellposedness for the Maxwell-Klein-Gordon equation below the energy norm […]")
]
