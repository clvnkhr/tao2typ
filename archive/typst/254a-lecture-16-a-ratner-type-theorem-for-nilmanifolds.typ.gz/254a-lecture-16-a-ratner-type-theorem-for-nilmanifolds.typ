// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/03/09/254a-lecture-16-a-ratner-type-theorem-for-nilmanifolds/
// Converted to Typst by tao2typ: "2026-10-14T06:57:03.899610+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Lecture 16: A Ratner-type theorem for nilmanifolds", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Lecture 16: A Ratner-type theorem for nilmanifolds")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 March 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/03/09/254a-lecture-16-a-ratner-type-theorem-for-nilmanifolds/")[#text("https://terrytao.wordpress.com/2008/03/09/254a-lecture-16-a-ratner-type-theorem-for-nilmanifolds/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("The last two lectures of this course will be on ")#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/")[#text("Ratner’s theorems")]#text(" on equidistribution of orbits on homogeneous spaces. Due to lack of time, I will not be able to cover all the material here that I had originally planned; in particular, for an introduction to this family of results, and its connections with number theory, I will have to refer readers to my previous ")#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/")[#text("blog post on these theorems")]#text(". In this course, I will discuss two special cases of Ratner-type theorems. In this lecture, I will talk about Ratner-type theorems for discrete actions (of the integers ")#mi("{\\Bbb Z})")#text(" on nilmanifolds; this case is much simpler than the general case, because there is a simple criterion in the nilmanifold case to test whether any given orbit is equidistributed or not. Ben Green and I ")#link("http://arxiv.org/abs/0709.3562")[#text("had need recently")]#text(" to develop quantitative versions of such theorems for a number-theoretic application. In the next and final lecture of this course, I will discuss Ratner-type theorems for actions of ")#mi("SL_2({\\Bbb R})")#text(", which is simpler in a different way (due to the semisimplicity of ")#mi("SL_2({\\Bbb R})")#text(", and lack of compact factors).")

#metadata(none) <tao-22f80312021771ef49fc>#text(" — Nilpotent groups —")

#text("Before we can get to Ratner-type theorems for nilmanifolds, we will need to set up some basic theory for these nilmanifolds. We begin with a quick review of the concept of a ")#link("http://en.wikipedia.org/wiki/Nilpotent_group")[#text("nilpotent group")]#text(" – a generalisation of that of an abelian group. Our discussion here will be purely algebraic (no manifolds, topology, or dynamics will appear at this stage).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1.")]#text(" (Commutators) Let G be a (multiplicative) group. For any two elements g,h in G, we define the ")#link("http://en.wikipedia.org/wiki/Commutator")[#text("commutator")]#text(" [g,h] to be ")#mi("{}[g,h] := g^{-1}h^{-1}gh")#text(" (thus g and h commute if and only if the commutator is trivial). If H and K are subgroups of G, we define the ")#link("http://en.wikipedia.org/wiki/Commutator_subgroup")[#text("commutator")]#text(" ")#mi("{}[H,K]")#text(" to be the group generated by all the commutators ")#mi("\\{ [h,k]: h \\in H, k \\in K \\}")#text(".")
]

#text("For future reference we record some trivial identities regarding commutators:")

#mi("gh = hg[g,h] = [g^{-1},h^{-1}]hg")#text(" (1)")

#mi("h^{-1} g h = g [g,h] = [h,g^{-1}] g")#text(" (2)")

#mi("{}[g,h]^{-1} = [h,g]")#text(". (3)")

#strong[#text("Exercise 1.")]#text(" Let H, K be subgroups of a group G.")

#enum(start: 1, 
[#text("Show that [H,K] = [K,H].")],
[#text("Show that H is ")#link("http://en.wikipedia.org/wiki/Abelian_group")[#text("abelian")]#text(" if and only if [H,H] is trivial.")],
[#text("Show that H is ")#link("http://en.wikipedia.org/wiki/Central_subgroup")[#text("central")]#text(" if and only if [H,G] is trivial.")],
[#text("Show that H is ")#link("http://en.wikipedia.org/wiki/Normal_subgroup")[#text("normal")]#text(" if and only if ")#mi("{}[H,G] \\subset H")#text(".")],
[#text("Show that [H,G] is always normal.")],
[#text("If ")#mi("L \\lhd H, K")#text(" is a normal subgroup of both H and K, show that ")#mi("{}[H,K] / ([H,K] \\cap L) \\equiv [H/L, K/L]")#text(".")],
[#text("Let HK be the group generated by ")#mi("H \\cup K")#text(". Show that ")#mi("{}[H,K]")#text(" is a normal subgroup of HK, and when one ")#link("http://en.wikipedia.org/wiki/Quotient_group")[#text("quotients")]#text(" by this subgroup, the images of H and K are groups that commute with each other. ")#mi("\\diamond")]
)

#strong[#text("Exercise 2.")]#text(" Let G be a group. Show that the group G/[G,G] is abelian, and is the ")#link("http://en.wikipedia.org/wiki/Universal_property")[#text("universal")]#text(" ")#link("http://en.wikipedia.org/wiki/Abelianization#Abelianization")[#text("abelianisation")]#text(" of G in the sense that every ")#link("http://en.wikipedia.org/wiki/Group_homomorphism")[#text("homomorphism")]#text(" ")#mi("\\phi: G \\to H")#text(" from G to an abelian group H can be uniquely factored as ")#mi("\\phi = \\tilde \\phi \\circ \\pi")#text(", where ")#mi("\\pi: G \\to G/[G,G]")#text(" is the quotient map and ")#mi("\\tilde \\phi: G/[G,G] \\to H")#text(" is a homomorphism. ")#mi("\\diamond")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2.")]#text(" (Nilpotency) Given any group G, define the ")#link("http://en.wikipedia.org/wiki/Central_series#Lower_central_series")[#text("lower central series")]

#mi("G = G_0 = G_1 \\rhd G_2 \\rhd G_3 \\rhd \\ldots")#text(" (4)")

#text("by setting ")#mi("G_0, G_1 := G")#text(" and ")#mi("G_{i+1} := [G_i,G]")#text(" for ")#mi("i \\geq 1")#text(". We say that G is ")#link("http://en.wikipedia.org/wiki/Nilpotent_group")[#text("nilpotent")]#text(" of step s if ")#mi("G_{s+1}")#text(" is trivial (and ")#mi("G_s")#text(" is non-trivial).")
]

#strong[#text("Examples 1.")]#text(" A group is nilpotent of step 0 if and only if it is trivial. It is nilpotent of step 1 if and only if it is non-trivial and abelian. Any subgroup or ")#link("http://en.wikipedia.org/wiki/Group_homomorphism")[#text("homomorphic image")]#text(" of a nilpotent group of step s is nilpotent of step at most s. The ")#link("http://en.wikipedia.org/wiki/Direct_product#Group_direct_product")[#text("direct product")]#text(" of two nilpotent groups is again nilpotent, but the ")#link("http://en.wikipedia.org/wiki/Semidirect_product")[#text("semi-direct product")]#text(" of nilpotent groups is merely ")#link("http://en.wikipedia.org/wiki/Solvable_group")[#text("solvable")]#text(" in general. If G is any group, then ")#mi("G/G_{s+1}")#text(" is nilpotent of step at most s. ")#mi("\\diamond")

#strong[#text("Example 2. ")]#text("Let ")#mi("n \\geq 1")#text(" be an integer, and let")

#mi("U_n({\\Bbb R)} = \\begin{pmatrix} 1 & {\\Bbb R} & \\ldots & {\\Bbb R} \\\\ 0 & 1 & \\ldots & {\\Bbb R} \\\\ \\vdots & \\vdots & \\ddots & \\vdots \\\\ 0 & 0 & \\ldots & 1 \\end{pmatrix}")#text(" (5)")

#text("be the group of all upper-triangular ")#mi("n \\times n")#text(" real matrices with ")#mi("1")#text("s on the diagonal (i.e. the group of ")#link("http://en.wikipedia.org/wiki/Unipotent")[#text("unipotent")]#text(" upper-triangular matrices). Then ")#mi("U_n({\\Bbb R})")#text(" is nilpotent of step n. Similarly if ")#mi("{\\Bbb R}")#text(" is replaced by other fields. ")#mi("\\diamond")

#strong[#text("Exercise 3.")]#text(" Let G be an arbitrary group.")

#enum(start: 1, 
[#text("Show that each element ")#mi("G_i")#text(" of the lower central series is a ")#link("http://en.wikipedia.org/wiki/Characteristic_subgroup")[#text("characteristic subgroup")]#text(" of G, i.e. ")#mi("\\phi(G_i)=G_i")#text(" for all ")#link("http://en.wikipedia.org/wiki/Automorphism")[#text("automorphisms")]#text(" ")#mi("\\phi: G \\to G")#text(". (Specialising to ")#link("http://en.wikipedia.org/wiki/Inner_automorphism")[#text("inner automorphisms")]#text(", this shows that the ")#mi("G_i")#text(" are all normal subgroups of G.)")],
[#text("Show the ")#link("http://en.wikipedia.org/wiki/Filtration_%28mathematics%29")[#text("filtration")]#text(" property ")#mi("{}[G_i,G_j] \\subset G_{i+j}")#text(" for all ")#mi("i,j \\geq 0")#text(". (Hint: induct on i+j; then, holding i+j fixed, quotient by ")#mi("G_{i+j}")#text(", and induct on (say) i. Note that once one quotients by ")#mi("G_{i+j}")#text(", all elements of ")#mi("{}[G_{i-1},G_j]")#text(" are central (by the first induction hypothesis), while ")#mi("G_{i-1}")#text(" commutes with ")#mi("{}[G,G_j]")#text(" (by the second induction hypothesis). Use these facts to show that all the generators of ")#mi("{}[G,G_{i-1}]")#text(" commute with ")#mi("G_j")#text(".) ")#mi("\\diamond")]
)

#strong[#text("Exercise 4. ")]#text(" Let G be a nilpotent group of step 2. Establish the identity")

#mi("g^n h^n = (gh)^n [g,h]^{\\binom{n}{2}}")#text(" (6)")

#text("for any integer n and any ")#mi("g,h \\in G")#text(", where ")#mi("\\binom{n}{2} := \\frac{n(n-1)}{2}")#text(". (This can be viewed as a discrete version of the first two terms of the ")#link("http://en.wikipedia.org/wiki/Baker-Campbell-Hausdorff_formula")[#text("Baker-Campbell-Hausdorff formula")]#text(".) Conclude in particular that the space of ")#emph[#text("Hall-Petresco sequences")]#text(" ")#mi("n \\mapsto g_0 g_1^n g_2^{\\binom{n}{2}}")#text(", where ")#mi("g_i \\in G_i")#text(" for ")#mi("i=0,1,2")#text(", is a group under pointwise multiplication (this group is known as the ")#emph[#text("Hall-Petresco group")]#text(" of G). There is an analogous identity (and an analogous group) for nilpotent groups of higher step; see for instance this ")#link("http://www.ams.org/mathscinet-getitem?mr=1608723")[#text("paper of Leibman")]#text(" for details. The Hall-Petresco group is rather useful for understanding multiple recurrence and polynomial behaviour in nilmanifolds; we will not discuss this in detail, but see Exercise 5 below for a hint as to the connection. ")#mi("\\diamond")

#strong[#text("Exercise 5.")]#text(" (Arithmetic progressions in nilspaces are constrained) Let X be a nilspace of step ")#mi("s \\leq 2")#text(", and consider two arithmetic progressions ")#mi("x, gx, \\ldots g^{s+1}x")#text(" and ")#mi("y, hy,\\ldots,h^{s+1} y")#text(" of length s+2 in X, where ")#mi("x,y \\in X")#text(" and ")#mi("g, h \\in G")#text(". Show that if these progressions agree in the first s+1 places (thus ")#mi("g^i x = h^i y")#text(" for all ")#mi("i=0,\\dots,s")#text(" then they also agree in the last place. (Hint: the only tricky case is s=2. For this, either use direct algebraic computation, or experiment with the group of Hall-Petresco sequences from the previous exercise. The claim is in fact true for general s, because the Hall-Petresco group exists in every step.) ")#mi("\\diamond")

#strong[#text("Remark 1")]#text(". By Exercise 3.2, the lower central series is a filtration with respect to the commutator operation ")#mi("g, h \\mapsto [g,h]")#text(". Conversely, if G admits a filtration ")#mi("G = G_{(0)} = G_{(1)} \\geq \\ldots")#text(" with ")#mi("{}[G_{(i)},G_{(j)}] \\subset G_{(i+j)}")#text(" and ")#mi("G_{(j)}")#text(" trivial for ")#mi("j > s")#text(", then it is nilpotent of step at most s. It is sometimes convenient for inductive purposes to work with filtrations rather than the lower central series (which is the “minimal” filtration available to a group G); see for instance ")#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/")[#text("my paper with Ben Green")]#text(" on this topic. ")#mi("\\diamond")

#strong[#text("Remark 2.")]#text(" Let G be a nilpotent group of step s. Then ")#mi("{}[G,G_s] = G_{s+1}")#text(" is trivial and so ")#mi("G_s")#text(" is central (by Exercise 1), thus abelian and normal. By another application of Exercise 1, we see that ")#mi("G/G_s")#text(" is nilpotent of step s-1. Thus we see that any nilpotent group G of step s is an ")#emph[#text("abelian ")#link("http://en.wikipedia.org/wiki/Group_extension")[#text("extension")]]#text(" of a nilpotent group ")#mi("G/G_s")#text(" of step s-1, in the sense that we have a ")#link("http://en.wikipedia.org/wiki/Exact_sequence")[#text("short exact sequence")]

#mi("0 \\to G_s \\to G \\to G/G_s \\to 0")#text(" (6)")

#text("where the kernel ")#mi("G_s")#text(" is abelian. Conversely, every abelian extension of an s-1-step nilpotent group is nilpotent of step at most s. In principle, this gives a recursive description of s-step nilpotent groups as an s-fold iterated tower of abelian extensions of the trivial group. Unfortunately, while abelian groups are of course very well understood, abelian ")#emph[#text("extensions")]#text(" are a little inconvenient to work with algebraically; the sequence (6) is not quite enough, for instance, to assert that G is a ")#link("http://en.wikipedia.org/wiki/Semidirect_product")[#text("semi-direct product")]#text(" of ")#mi("G_s")#text(" and ")#mi("G/G_s")#text(" (this would require some means of embedding ")#mi("G/G_s")#text(" back into G, which is not available in general). One can identify G (using the axiom of choice) with a product set ")#mi("G/G_s \\times G_s")#text(" with a group law ")#mi("(g,n) \\cdot (h,m) = (gh, nm \\phi(g,h))")#text(", where ")#mi("\\phi: G/G_s \\times G/G_s \\to G_s")#text(" is a map obeying various cocycle-type identities, but the algebraic structure of ")#mi("\\phi")#text(" is not particularly easy to exploit. Nevertheless, this recursive tower of extensions seems to be well suited for understanding the ")#emph[#text("dynamical")]#text(" structure of nilpotent groups and their quotients, as opposed to their ")#emph[#text("algebraic")]#text(" structure (cf. our use of recursive towers of extensions in our previous lectures in dynamical systems and ergodic theory). ")#mi("\\diamond")

#text("In our applications we will not be working with nilpotent groups G directly, but rather with their ")#link("http://en.wikipedia.org/wiki/Homogeneous_space")[#text("homogeneous spaces")]#text(" X, i.e. spaces with a ")#link("http://en.wikipedia.org/wiki/Transitivity_%28mathematics%29")[#text("transitive")]#text(" ")#link("http://en.wikipedia.org/wiki/Group_action")[#text("left-action")]#text(" of G. (Later we will also add some topological structure to these objects, but let us work in a purely algebraic setting for now.) Such spaces can be identified with group quotients ")#mi("X \\equiv G/\\Gamma")#text(" where ")#mi("\\Gamma \\leq G")#text(" is the ")#link("http://en.wikipedia.org/wiki/Group_action#Orbits_and_stabilizers")[#text("stabiliser")]#text(" ")#mi("\\Gamma = \\{ g \\in G: gx = x \\}")#text(" of some point x in X. (By the transitivity of the action, all stabilisers are conjugate to each other.) It is important to note that in general, ")#mi("\\Gamma")#text(" is not normal, and so X is not a group; it has a left-action of G but not right-action of G. Note though that any central subgroup of G acts on either the left or the right.")

#text("Now let G be s-step nilpotent, and let us temporarily refer to ")#mi("X=G/\\Gamma")#text(" as an ")#emph[#text("s-step nilspace")]#text(". Then G_s acts on the right in a manner that commutes with the left-action of G. If we set ")#mi("\\Gamma_s := G_s \\cap \\Gamma \\lhd G_s")#text(", we see that the right-action of ")#mi("\\Gamma_s")#text(" on ")#mi("G/\\Gamma")#text(" is trivial; thus we in fact have a right-action of the abelian group ")#mi("T_s := G_s/\\Gamma_s")#text(". (In our applications, ")#mi("T_s")#text(" will be a ")#link("http://en.wikipedia.org/wiki/Torus")[#text("torus")]#text(".) This action can be easily verified to be ")#link("http://en.wikipedia.org/wiki/Group_action#Types_of_actions")[#text("free")]#text(". If we let ")#mi("\\overline{X} := X/T_s")#text(" be the quotient space, then we can view X as a ")#link("http://en.wikipedia.org/wiki/Principal_bundle")[#text("principal ")#mi("T_s")#text("-bundle")]#text(" over ")#mi("\\overline{X}")#text(". It is not hard to see (cf. the ")#link("http://en.wikipedia.org/wiki/Isomorphism_theorem")[#text("isomorphism theorems")]#text(") that ")#mi("\\overline{X} \\equiv \\pi(G)/\\pi(\\Gamma)")#text(", where ")#mi("\\pi: G \\to G/G_s")#text(" is the quotient map. Observe that ")#mi("\\pi(G)")#text(" is nilpotent of step s-1, and ")#mi("\\pi(\\Gamma)")#text(" is a subgroup. Thus we have expressed an arbitrary s-step nilspace as a principal bundle (by some abelian group) over an s-1-step nilspace, and so s-step nilspaces can be viewed as towers of abelian principal bundles, just as s-step nilpotent groups can be viewed as towers of abelian extensions.")

#text("— Nilmanifolds —")

#text("It is now time to put some topological structure (and in particular, Lie structure) on our nilpotent groups and nilspaces.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3")]#text(" (Nilmanifolds). An s-step nilmanifold is a nilspace ")#mi("G/\\Gamma")#text(", where G is a finite-dimensional ")#link("http://en.wikipedia.org/wiki/Lie_group")[#text("Lie group")]#text(" which is nilpotent of step s, and ")#mi("\\Gamma")#text(" is a ")#link("http://en.wikipedia.org/wiki/Discrete_space")[#text("discrete ")]#text("subgroup which is ")#link("http://en.wikipedia.org/wiki/Cocompact_group_action")[#text("cocompact")]#text(" or uniform in the sense that the quotient ")#mi("G/\\Gamma")#text(" is compact.")
]

#strong[#text("Remark 3.")]#text(" In the literature, it is sometimes assumed that the nilmanifold ")#mi("G/\\Gamma")#text(" is connected, and that the group G is connected, or at least that its group ")#mi("\\pi_0(G) := G/G^\\circ")#text(" of connected components (")#mi("G^\\circ \\lhd G")#text(" being the identity component of ")#mi("G")#text(") is finitely generated (one can often easily reduce to this case in applications). It is also convenient to assume that ")#mi("G^\\circ")#text(" is ")#link("http://en.wikipedia.org/wiki/Simply_connected")[#text("simply connected")]#text(" (again, one can usually reduce to this case in applications, by passing to the ")#link("http://en.wikipedia.org/wiki/Covering_space")[#text("universal cover")]#text(" of ")#mi("G^\\circ")#text(" if necessary), as this implies (by the ")#link("http://en.wikipedia.org/wiki/Baker-Campbell-Hausdorff_formula")[#text("Baker-Campbell-Hausdorff formula")]#text(") that the nilpotent Lie group ")#mi("G^\\circ")#text(" is ")#emph[#text("exponential")]#text(", i.e. the ")#link("http://en.wikipedia.org/wiki/Exponential_map")[#text("exponential map")]#text(" ")#mi("\\exp: {\\mathfrak g} \\to G^\\circ")#text(" is a homeomorphism. ")#mi("\\diamond")

#strong[#text("Example 3.")]#text(" (Skew torus) If we define")

#mi("G := \\begin{pmatrix} 1 & {\\Bbb R} & {\\Bbb R} \\\\ 0 & 1 & {\\Bbb Z} \\\\ 0 & 0 & 1 \\end{pmatrix}; \\quad \\Gamma := \\begin{pmatrix} 1 & {\\Bbb Z} & {\\Bbb Z} \\\\ 0 & 1 & {\\Bbb Z} \\\\ 0 & 0 & 1 \\end{pmatrix}")#text(" (7)")

#text("(thus G consists of the upper-triangular unipotent matrices whose middle right entry is an integer, and ")#mi("\\Gamma")#text(" is the subgroup in which all entries are integers) then ")#mi("G/\\Gamma")#text(" is a 2-step nilmanifold. If we write")

#mi("{}[x,y] := \\begin{pmatrix} 1 & x & y \\\\ 0 & 1 & 0 \\\\ 0 & 0 & 1 \\end{pmatrix} \\Gamma")#text(" (8)")

#text("then we see that ")#mi("G/\\Gamma")#text(" is isomorphic to the square ")#mi("\\{ [x,y]: 0 \\leq x,y \\leq 1 \\}")#text(" with the identifications ")#mi("{}[x,1] \\equiv [x,0]")#text(" and ")#mi("{}[0,y] := [1,y]")#text(". (Topologically, this is homeomorphic to the ordinary 2-torus ")#mi("({\\Bbb R}/{\\Bbb Z})^2")#text(", but the skewness will manifest itself when we do dynamics.) ")#mi("\\diamond")

#strong[#text("Example 4.")]#text(" (Heisenberg nilmanifold) If we set")

#mi("G := \\begin{pmatrix} 1 & {\\Bbb R} & {\\Bbb R} \\\\ 0 & 1 & {\\Bbb R} \\\\ 0 & 0 & 1 \\end{pmatrix}; \\quad \\Gamma := \\begin{pmatrix} 1 & {\\Bbb Z} & {\\Bbb Z} \\\\ 0 & 1 & {\\Bbb Z} \\\\ 0 & 0 & 1 \\end{pmatrix}")#text(" (9)")

#text("then ")#mi("G/\\Gamma")#text(" is a 2-step nilmanifold. It can be viewed as a three-dimensional cube with the faces identified in a somewhat skew fashion, similarly to the skew torus in Example 3. ")#mi("\\diamond")

#text("Let ")#mi("{\\mathfrak g}")#text(" be the ")#link("http://en.wikipedia.org/wiki/Lie_algebra")[#text("Lie algebra")]#text(" of G. Every element g of G acts linearly on ")#mi("{\\mathfrak g}")#text(" by conjugation. Since G is nilpotent, it is not hard to see (by considering the iterated commutators of g with an infinitesimal perturbation of the identity) that this linear action is ")#link("http://en.wikipedia.org/wiki/Unipotent")[#text("unipotent")]#text(", and in particular has determinant 1. Thus, any constant ")#link("http://en.wikipedia.org/wiki/Volume_form")[#text("volume form")]#text(" on this Lie algebra will be preserved by conjugation, which by basic differential geometry allows us to create a volume form (and hence a measure) on G which is invariant under both left and right translation; this ")#link("http://en.wikipedia.org/wiki/Haar_measure")[#text("Haar measure")]#text(" is clearly unique up to scalar multiplication. (In other words, nilpotent Lie groups are ")#link("http://en.wikipedia.org/wiki/Unimodular_group")[#text("unimodular")]#text(".) Restricting this measure to a fundamental domain of ")#mi("G/\\Gamma")#text(" and then descending to the nilmanifold we obtain a left-invariant Haar measure, which (by compactness) we can normalise to be a Borel probability measure. (Because of the existence of a left-invariant probability measure ")#mi("\\mu")#text(" on ")#mi("G/\\Gamma")#text(", we refer to the discrete subgroup ")#mi("\\Gamma")#text(" of G as a ")#link("http://en.wikipedia.org/wiki/Lattice_%28discrete_subgroup%29")[#text("lattice")]#text(".) One can show that this left-invariant Borel probability measure is unique.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4. ")]#text(" (Nilsystem) An ")#emph[#text("s-step nilsystem (or nilflow)")]#text(" is a topological measure-preserving system (i.e. both a topological dynamical system and a measure-preserving system) with underlying space ")#mi("G/\\Gamma")#text(" a s-step nilmanifold (with the Borel ")#mi("\\sigma")#text("-algebra and left-invariant probability measure), with a shift T of the form ")#mi("T: x \\mapsto g x")#text(" for some ")#mi("g \\in G")#text(".")
]

#strong[#text("Example 5.")]#text(" The Kronecker systems ")#mi("x \\mapsto x+\\alpha")#text(" on compact abelian Lie groups are 1-step nilsystems. ")#mi("\\diamond")

#strong[#text("Example 6. ")]#text(" The skew shift system ")#mi("(x,y) \\mapsto (x+\\alpha,y+x)")#text(" on the torus ")#mi("({\\Bbb R}/{\\Bbb Z})^2")#text(" can be identified with a nilflow on the skew torus (Example 3), after identifying (x,y) with [x,y] and using the group element")

#mi("g := \\begin{pmatrix} 1 & \\alpha & 0 \\\\ 0 & 1 & 1 \\\\ 0 & 0 & -1 \\end{pmatrix}")#text(" (10)")

#text("to create the flow. ")#mi("\\diamond")

#strong[#text("Example 7.")]#text(" Consider the Heisenberg nilmanifold (Example 4) with a flow generated by a group element")

#mi("g := \\begin{pmatrix} 1 & \\gamma & \\beta \\\\ 0 & 1 & \\alpha \\\\ 0 & 0 & 1 \\end{pmatrix}")#text(" (11)")

#text("for some real numbers ")#mi("\\alpha,\\beta,\\gamma")#text(". If we identify")

#mi("{}[x,y,z] := \\begin{pmatrix} 1 & z & y \\\\ 0 & 1 & x \\\\ 0 & 0 & 1 \\end{pmatrix} \\Gamma")#text(" (12)")

#text("then one can verify that")

#mi("T^n: [x,y,z] \\mapsto [ \\{ x+n\\alpha\\}, y+n\\beta + \\frac{n(n-1)}{2} \\alpha \\gamma - \\lfloor x")

#mi("+ n\\alpha \\rfloor(z+n\\gamma) \\text{ mod } 1, z+n\\gamma \\text{ mod } 1]")#text(" (13)")

#text("where ")#mi("\\lfloor \\rfloor")#text(" and ")#mi("\\{ \\}")#text(" are the ")#link("http://en.wikipedia.org/wiki/Floor_and_ceiling_functions")[#text("integer part")]#text(" and ")#link("http://en.wikipedia.org/wiki/Fractional_part")[#text("fractional part")]#text(" functions respectively. Thus we see that orbits in this nilsystem are vaguely quadratic in n, but for the presence of the not-quite-linear operators ")#mi("\\lfloor \\rfloor")#text(" and ")#mi("\\{ \\}")#text(". (These expressions are known as ")#emph[#text("bracket polynomials")]#text(", and are intimately related to the theory of nilsystems.) ")#mi("\\diamond")

#text("Given that we have already seen that nilspaces of step s are principal abelian bundles of nilspaces of step s-1, it should be unsurprising that nilsystems of step s are abelian extensions of nilsystems of step s-1. But in order to ensure that topological structure is preserved correctly, we do need to verify one point:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" Let ")#mi("G/\\Gamma")#text(" be an s-step nilmanifold, with G connected and simply connected. Then ")#mi("\\Gamma_s := G_s \\cap \\Gamma")#text(" is a discrete cocompact subgroup of ")#mi("G_s")#text(". In particular, ")#mi("T_s := G_s/\\Gamma_s")#text(" is a compact connected abelian Lie group (in other words, it is a ")#link("http://en.wikipedia.org/wiki/Torus")[#text("torus")]#text(").")
]

#strong[#text("Proof. ")]#text("Recall that G is exponential and thus identifiable with its Lie algebra ")#mi("{\\mathcal g}")#text(". The commutators ")#mi("G_i")#text(" can be similarly identified with the Lie algebra commutators ")#mi("{\\mathcal g}_i")#text("; in particular, the ")#mi("G_i")#text(" are all connected, simply connected Lie groups.")

#text("The key point to verify is the cocompact nature of ")#mi("\\Gamma_s")#text(" in ")#mi("G_s")#text("; all other claims are straightforward. We first work in the abelianisation ")#mi("G/G_2")#text(", which is identifiable with its Lie algebra and thus isomorphic to a vector space. The image of ")#mi("\\Gamma")#text(" under the quotient map ")#mi("G \\to G/G_2")#text(" is a cocompact subgroup of this vector space; in particular, it contains a basis of this space. This implies that ")#mi("\\Gamma")#text(" contains an “abelianised” basis ")#mi("e_1,\\ldots,e_d")#text(" of G in the sense that every element of G can be expressed in the form ")#mi("e_1^{t_1} \\ldots e_d^{t_d}")#text(" modulo an element of the normal subgroup ")#mi("G_2")#text(" for some real numbers ")#mi("t_1,\\ldots,t_d")#text(", where we take advantage of the exponential nature of G to define real exponentiation ")#mi("g^t := \\exp( t \\log(g) )")#text(". Taking commutators s times (which eliminates all the “modulo ")#mi("G_2")#text("” errors), we then see that ")#mi("G_s")#text(" is generated by expressions of the form ")#mi("{} [e_{i_1},[e_{i_2},[\\ldots,e_{i_s}]\\ldots]^t")#text(" for ")#mi("i_1,\\ldots,i_s \\in \\{1,\\ldots,d\\}")#text(" and real t. Observe that these expressions lie in ")#mi("\\Gamma_s")#text(" if t is integer. As ")#mi("G_s")#text(" is abelian, we conclude that each element in ")#mi("G_s")#text(" can be expressed as an element of ")#mi("\\Gamma_s")#text(", times a bounded number of elements of the form ")#mi("{} [e_{i_1},[e_{i_2},[\\ldots,e_{i_s}]\\ldots]^t")#text(" with ")#mi("0 \\leq t < 1")#text(". From this we conclude that the quotient map ")#mi("G_s \\mapsto G_s/\\Gamma_s")#text(" is already surjective on some bounded set, which we can take to be compact, and so ")#mi("G_s/\\Gamma_s")#text(" is compact as required. ")#mi("\\Box")

#text("As a consequence of this lemma, we see that if ")#mi("X = G/\\Gamma")#text(" is an s-step nilmanifold with G connected and simply connected, then ")#mi("X/T_s")#text(" is an s-1-step nilmanifold (with G still connected and simply connected), and that X is a principal ")#mi("T_s")#text("-bundle over ")#mi("X/T_s")#text(" in the topological sense as well as in the purely algebraic sense. One consequence of this is that every s-step nilsystem (with G connected and simply connected) can be viewed as a ")#emph[#text("toral extension")]#text(" (i.e. a group extension by a torus) of an s-1-step nilsystem (again with G connected and simply connected). Thus for instance the skew shift system (Example 6) is a circle extension of a circle shift, while the Heisenberg nilsystem (Example 7) is a circle extension of an abelian 2-torus shift.")

#strong[#text("Remark 4.")]#text(" One should caution though that the converse of the above statement is not necessarily true; an extension ")#mi("X \\times_\\phi T")#text(" of an s-1-step nilsystem X by a torus T using a cocycle ")#mi("\\phi: X \\to T")#text(" need not be isomorphic to an s-step nilsystem (the cocycle ")#mi("\\phi")#text(" has to obey an an additional equation (or more precisely, a system of equations when ")#mi("s > 2")#text("), known as the ")#emph[#text("Conze-Lesigne equation")]#text(", before this is the case. See for instance this paper ")#link("http://www.ams.org/mathscinet-getitem?mr=2257397")[#text("of Ziegler")]#text(" for further discussion. ")#mi("\\diamond")

#strong[#text("Exercise 6.")]#text(" Show that Lemma 1 continues to hold if we relax the condition that G is connected and simply connected, to instead require that ")#mi("G/\\Gamma")#text(" is connected, that ")#mi("G/G^\\circ")#text(" is finitely generated, and that ")#mi("G^\\circ")#text(" is simply connected. (I believe that all three of these hypotheses are necessary, but haven’t checked this carefully.) ")#mi("\\diamond")

#strong[#text("Exercise 7. ")]#text("Show that Lemma 1 continues to hold if ")#mi("G_s")#text(" and ")#mi("\\Gamma_s")#text(" are replaced by ")#mi("G_i")#text(" and ")#mi("\\Gamma_i = G_i \\cap \\Gamma")#text(" for any ")#mi("0 \\leq i \\leq s")#text(". In particular, setting i=2, we obtain a projection map ")#mi("\\pi: X \\to X_2")#text(" from X to the Kronecker nilmanifold ")#mi("X_2 = (G/G_2)/(\\Gamma G_2/G_2)")#text(". ")#mi("\\diamond")

#strong[#text("Remark 5.")]#text(" One can take the structural theory of nilmanifolds much further, in particular developing the theory of ")#emph[#text("Mal’cev bases")]#text(" (of which the elements ")#mi("e_1,\\ldots,e_d")#text(" used to prove Lemma 1 were a very crude prototype). See the ")#link("http://www.ams.org/mathscinet-getitem?mr=28842")[#text("foundational paper of Mal’cev")]#text(" (or its ")#link("http://www.ams.org/mathscinet-getitem?mr=39734")[#text("English translation")]#text(") for details, as well as the later paper ")#link("http://www.ams.org/mathscinet-getitem?mr=2122919")[#text("of Leibman")]#text(" which addresses the case in which G is not necessarily connected. ")#mi("\\diamond")

#text("— A criterion for ergodicity —")

#text("We now give a useful criterion to determine when a given nilsystem is ergodic.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1. ")]#text("Let ")#mi("(X,T) = (G/\\Gamma, x \\mapsto gx)")#text(" be an s-step nilsystem with G connected and simply connected, and let ")#mi("(X_2, T_2)")#text(" be the underlying Kronecker factor, as defined in Exercise 7. Then X is ergodic if and only if ")#mi("X_2")#text(" is ergodic.")
]

#text("This result is originally due to ")#link("http://www.ams.org/mathscinet-getitem?mr=126504")[#text("Leon Green")]#text(", using spectral theory methods. We will use an argument ")#link("http://www.ams.org/mathscinet-getitem?mr=260975")[#text("of Parry")]#text(" (and adapted ")#link("http://www.ams.org/mathscinet-getitem?mr=2122919")[#text("by Leibman")]#text("), relying on “vertical” Fourier analysis and topological arguments, which we have already used for the skew shift in Proposition 1 of ")#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")[#text("Lecture 9")]#text(".")

#strong[#text("Proof.")]#text(" If X is ergodic, then the factor ")#mi("X_2")#text(" is certainly ergodic. To prove the converse implication, we induct on s. The case ")#mi("s \\leq 1")#text(" is trivial, so suppose ")#mi("s>1")#text(" and the claim has already been proven for s-1. Then if ")#mi("X_2")#text(" is ergodic, we already know from induction hypothesis that ")#mi("X/T_s")#text(" is ergodic. Suppose for contradiction that X is not ergodic, then we can find a non-constant shift-invariant function on X. Using Fourier analysis (or representation theory) of the vertical torus ")#mi("T_s")#text(" as in Proposition 1 of ")#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")[#text("Lecture 9")]#text(", we may thus find a non-constant shift-invariant function f which has a ")#emph[#text("single vertical frequency")]#text(" ")#mi("\\chi")#text(" in the sense that one has ")#mi("f( g_s x ) = \\chi(g_s) f(x)")#text(" for all ")#mi("x \\in X")#text(", ")#mi("g_s \\in G_s")#text(", and some character ")#mi("\\chi: G_s \\to S^1")#text(". If the character ")#mi("\\chi")#text(" is trivial, then f descends to a non-constant shift-invariant function on ")#mi("X/T_s")#text(", contradicting the ergodicity there, so we may assume that ")#mi("\\chi")#text(" is non-trivial. Also, |f| descends to a shift-invariant function on ")#mi("X/T_s")#text(" and is thus constant by ergodicity; by normalising we may assume ")#tao-math("\\left|f\\right|=1", block: false)#text(".")

#text("Now let ")#mi("g_{s-1} \\in G_{s-1}")#text(", and consider the function ")#mi("F_{g_{s-1}}(x) := f( g_{s-1} x) \\overline{f(x)}")#text(". As ")#mi("G_s")#text(" is central, we see that ")#mi("F_{g_{s-1}}")#text(" is ")#mi("G_s")#text("-invariant and thus descends to ")#mi("X/T_s")#text(". Furthermore, as f is shift-invariant (so ")#mi("f(g x) = f(x)")#text("), and ")#mi("{}[g_{s-1},g] \\in G_s")#text(", some computation reveals that ")#mi("F_{g_{s-1}}")#text(" is an eigenfunction:")

#mi("F_{g_{s-1}}( g x ) = \\chi([g_{s-1},g]) F_{g_{s-1}}(x)")#text(". (14)")

#text("In particular, if ")#mi("\\chi([g_{s-1},g]) \\neq 1")#text(", then ")#mi("F_{g_{s-1}}")#text(" must have mean zero. On the other hand, by continuity (and the fact that |f|=1) we know that ")#mi("F_{g_{s-1}}")#text(" has non-zero mean for ")#mi("g_{s-1}")#text(" close enough to the identity. We conclude that ")#mi("\\chi([g_{s-1},g]) = 1")#text(" for all ")#mi("g_{s-1}")#text(" close to the identity; as the map ")#mi("g_{s-1} \\mapsto \\chi([g_{s-1},g])")#text(" is a homomorphism, we conclude in fact that ")#mi("\\chi([g_{s-1},g]) = 1")#text(" for all ")#mi("g_{s-1}")#text(". In particular, from (14) and ergodicity we see that ")#mi("F_{g_{s-1}}")#text(" is constant, and so ")#mi("f(g_{s-1} x) = c(g_{s-1}) f(x)")#text(" for some ")#mi("c(g_{s-1}) \\in S^1")#text(".")

#text("Now let ")#mi("h \\in G")#text(" be arbitrary. Observe that")

#mi("\\int_G f(h g_{s-1} x) \\overline{f(x)}\\ d\\mu = \\int_G f(h y) \\overline{f(g_{s-1}^{-1} y)}\\ d\\mu")

#mi("= c(g_{s-1}) \\int_G f(hy) \\overline{f(y)}\\ d\\mu")

#mi("= \\int_G f(g_{s-1} hy) \\overline{f(y)}\\ d\\mu")

#mi("= \\chi([g_{s-1},h]) \\int_G f(h g_{s-1} y) \\overline{f(y)}\\ d\\mu")#text(". (15)")

#text("For h and ")#mi("g_{s-1}")#text(" close enough to the identity, the integral is non-zero, and we conclude that ")#mi("\\chi([g_{s-1},h])=1")#text(" in this case. The map ")#mi("(g_{s-1},h) \\mapsto \\chi([g_{s-1},h])")#text(" is a homomorphism in each variable and so is constant. Since ")#mi("G_s = [G_{s-1},G]")#text(", we conclude that ")#mi("\\chi")#text(" is trivial, a contradiction. ")#mi("\\Box")

#strong[#text("Remark 6.")]#text(" The hypothesis that G is connected and simply connected can be dropped; see the paper ")#link("http://www.ams.org/mathscinet-getitem?mr=2122919")[#text("of Leibman")]#text(" for details. ")#mi("\\diamond")

#text("One pleasant fact about nilsystems, as compared with arbitrary dynamical systems, is that ergodicity can automatically be upgraded to unique ergodicity:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2.")]#text(" Let (X,T) be an ergodic nilsystem. Then (X,T) is also uniquely ergodic. Equivalently, for every ")#mi("x \\in X")#text(", the orbit ")#mi("(T^n x)_{n \\in {\\Bbb Z}}")#text(" is equidistributed.")
]

#strong[#text("Exercise 8. ")]#text("By inducting on step and adapting the proof of Proposition 3 from ")#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")[#text("Lecture 9")]#text(", prove Theorem 2. ")#mi("\\diamond")

#text("— a Ratner-type theorem —")

#text("A subnilsystem of a nilsystem ")#mi("(X,T) = (G/\\Gamma,T)")#text(" is a compact subsystem ")#mi("(Y,S)")#text(" which is of the form ")#mi("Y = Hx")#text(" for some ")#mi("x \\in X")#text(" and some closed subgroup ")#mi("H \\leq G")#text(". One easily verifies that a subnilsystem is indeed a nilsystem.")

#text("From the above theorems we quickly obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1")]#text(" (Dichotomy between structure and randomness) Let (X,T) be a nilsystem with group G connected and simply connected, and let ")#mi("x \\in X")#text(". Then exactly one of the following statements is true:")

#enum(start: 1, 
[#text("The orbit ")#mi("(T^n x)_{n \\in {\\Bbb Z}}")#text(" is equidistributed.")],
[#text("One can partition ")#mi("{\\Bbb Z}")#text(" into finitely many congruence classes $P$, such that for each class $P$, the orbit ")#mi("(T^n x)_{n \\in P}")#text(" is contained in a proper subnilsystem (Y,S) with group H connected and simply connected, and with dimension strictly smaller than that of G.")]
)
]

#strong[#text("Proof.")]#text(" It is clear that 1. and 2. cannot both be true. Now suppose that 1. is false. By Theorem 2, this means that (X,T) is not ergodic; by Theorem 1, this implies that the Kronecker system ")#mi("(X_2,T_2)")#text(" is not ergodic. Expanding functions on ")#mi("X_2 \\equiv G/G_2")#text(" into characters and using Fourier analysis, we conclude that there is a non-trivial character ")#mi("\\chi: G/G_2 \\to S^1")#text(" which is ")#mi("T_2")#text("-invariant. Writing ")#mi("\\chi = \\tilde \\chi^m")#text(" for some primitive $\\tilde \\chi$, we conclude that $\\tilde \\chi$ is ")#mi("T_2^m")#text("-invariant. If we let ")#mi("\\pi: G \\to G/G_2")#text(" be the canonical projection, then ")#mi("\\chi: G \\to S^1")#text(" is a continuous homomorphism, and the kernel H is a closed connected subgroup of G of strictly lower dimension. Furthermore, Hx is equal to a level set of ")#mi("\\chi")#text(" and is thus compact. Since ")#mi("\\chi")#text(" is ")#mi("T_2^m")#text(" invariant, we see that ")#mi("T^n x \\in Hx")#text(" for all n in the congruence class ")#mi("0 \\text{ mod } m")#text(", and similarly for other congruence classes of this modulus. The claim follows. ")#mi("\\Box")

#text("Iterating this, we obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2")]#text(" (Ratner-type theorem for nilmanifolds) Let (X,T) be a nilsystem with group G connected and simply connected, and let ")#mi("x \\in X")#text(". Then one can partition ")#mi("{\\Bbb Z}")#text(" into finitely many congruence classes such that on each such class, the orbit ")#mi("(T^n x)_{n \\in P}")#text(" is equidistributed in some subnilmanifold (Y,S) of (X,T). (In particular, this orbit is dense in Y.) Furthermore, Y= Hx for some closed connected subgroup H of G.")
]

#strong[#text("Remark 7.")]#text(" Analogous claims also hold when G is not assumed to be connected or simply connected, and if the orbit ")#mi("(T^n x)_{n \\in {\\Bbb Z}}")#text(" is replaced with a polynomial orbit ")#mi("(T^{p(n)} x)_{n \\in {\\Bbb Z}}")#text("; see this paper ")#link("http://www.ams.org/mathscinet-getitem?mr=2122919")[#text("of Leibman")]#text(" for details (and ")#link("http://www.ams.org/mathscinet-getitem?mr=2122920")[#text("this followup paper ")]#text("for the case of ")#mi("{\\Bbb Z}^d")#text("-actions. In a different direction, such discrete Ratner-type theorems have been extended to other unipotent actions on finite volume homogeneous spaces ")#link("http://www.ams.org/mathscinet-getitem?mr=1699367")[#text("by Shah")]#text(". Quantitative versions of this theorem have also been obtained ")#link("http://arxiv.org/abs/0709.3562")[#text("by Ben Green and myself")]#text(". ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", June 29: minor corrections.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/09/254a-lecture-16-a-ratner-type-theorem-for-nilmanifolds/#comment-30623")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2008")])]

#text("Hello Professor,")

#text("in equation (13) there are some misprints concerning LaTeX.")

#text("Is there the possibility that there is a miscalculation on the second term?")

#text("Yours sincerersly,")

#text("Jordi-Lluis Figueras Romero")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/09/254a-lecture-16-a-ratner-type-theorem-for-nilmanifolds/#comment-30656")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2008")])]

#text("Dear Jordi-Lluis: thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marker lectures II, “Linear equations in primes” « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/09/254a-lecture-16-a-ratner-type-theorem-for-nilmanifolds/#comment-33585")[#strong[#text("Marker lectures II, “Linear equations in primes” « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2008")])]

#text("[…] , and F is some reasonable (e.g. piecewise smooth) function on this nilmanifold. (See my lecture notes, this paper of Bergelson and Leibman, or this paper of Ben and myself for details.) The relevance […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/03/09/254a-lecture-16-a-ratner-type-theorem-for-nilmanifolds/#comment-45660")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2010")])]

#text("Dear Professor Tao:")#linebreak()#text(" I think there are some problems in (7) and (8) and (10). It seems the position of Z in the first term in (7) is not true. Also, I don’t get the second identification that [0,y] := [1,y+x mod 1], isn’t it [0,y]=[1,y]?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siming Tu")]], [#link("https://terrytao.wordpress.com/2008/03/09/254a-lecture-16-a-ratner-type-theorem-for-nilmanifolds/#comment-80524")[#strong[#text("Siming Tu")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2011")])]

#text("Dear Professor Tao：")#linebreak()#text(" In Exercise 1.(7)，you say that H/[H,K],K/[H,K] become abelian.But I’m a bit confused with these words.Since [H,K] may not be a subgroup of H,and at this time we can not do the quotient operation.And even if [H,K] is a subgroup of H,the quotient group may still not abelian,for example K is the trivial group {1} and H nonabelian.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/09/254a-lecture-16-a-ratner-type-theorem-for-nilmanifolds/#comment-80629")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2011")])]

#text("Oops, that was a typo; what I meant to say here was that the images of H and K under the quotient map become groups that commute with each other (but need not be abelian).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siming Tu")]], [#link("https://terrytao.wordpress.com/2008/03/09/254a-lecture-16-a-ratner-type-theorem-for-nilmanifolds/#comment-92580")[#strong[#text("Siming Tu")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2011")])]

#text("Dear Professor Tao:")#linebreak()#text(" I think in (13) ")#mi("\\frac{n(n+1)}{2}")#text(" should be ")#mi("\\frac{n(n-1)}{2}")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Multiple recurrence and convergence results associated to $F_{p}^{omega}$-actions | What's new")]], [#link("https://terrytao.wordpress.com/2008/03/09/254a-lecture-16-a-ratner-type-theorem-for-nilmanifolds/#comment-230674")[#strong[#text("Multiple recurrence and convergence results associated to $F_{p}^{omega}$-actions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2013")])]

#text("[…] class of constraint involving two-step nilsystems which we will not detail here, but see e.g. this previous blog post for more discussion. Nevertheless there is still a similar limit formula to previous examples, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2008/03/09/254a-lecture-16-a-ratner-type-theorem-for-nilmanifolds/#comment-514117")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2019")])]

#text("I wonder whether this works for Lie groups that are not necessarily nilpotent, but are hypocentral, ie. if one extends the definition of the lower central series to ordinals by making the limit group the intersection of all previous groups, then there exists an ordinal (hence a least ordinal) that makes the group trivial.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2008/03/09/254a-lecture-16-a-ratner-type-theorem-for-nilmanifolds/#comment-515297")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2019")])]

#text("(Upon replacing the Euclidean structure by a Banach space structure, of course.)")
]
]
