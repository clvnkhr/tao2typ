// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/
// Converted to Typst by tao2typ: "2026-10-29T13:24:25.948726+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "oai-math-revised: a community hub for revising OpenAI’s math write-ups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("oai-math-revised: a community hub for revising OpenAI’s math write-ups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/")[#text("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-29 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://www.ohsu.edu/people/abhinav-nellore-phd")[#text("Abhinav Nellore")]#text(", ")#link("https://johannesschmitt.gitlab.io/")[#text("Johannes Schmitt")]#text(", ")#link("https://www.ams.jhu.edu/villar/")[#text("Soledad Villar")]#text(", and ")#link("https://oden.utexas.edu/people/directory/rachel--ward/")[#text("Rachel Ward")]#text(" – T.]")]

#text("OpenAI’s math write-ups at ")#link("https://github.com/openai/math")[#text("https://github.com/openai/math")]#text(" can be difficult to understand and can have incomplete citations.")

#link("https://github.com/mathcommunity/oai-math-revised/ ")[#text("https://github.com/mathcommunity/oai-math-revised/ ")]#text("seeks to be an inclusive effort to improve these write-ups, and the broader math community–students, postdocs, professors, and enthusiasts–is invited to participate.")

#text("The repo is browsable at ")#link("https://mathcommunity.github.io/oai-math-revised/")[#text("https://mathcommunity.github.io/oai-math-revised/")]

#text("We also invite the community to email ")#link("mailto:mathcommunityadmin@gmail.com")[#text("mathcommunityadmin@gmail.com")]#text(" if they want to serve as admins/reviewers and for which categories from ")#link("https://github.com/openai/math/blob/main/overview.pdf")[#text("https://github.com/openai/math/blob/main/overview.pdf")]#text(" they’d be appropriate for reviews.")

#heading(level: 1)[#text("Comments (27)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698721")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("So it is up to unpaid volunteers to sift through OpenAI’s slop and refine their output for them? After all the fanciful debate about putting pressure on these trillion-dollar companies, nothing has fundamentally shifted in our approach?")

#text("It’s good to know that you can always count on academia to never change for the better even in the face of the most extreme circumstances.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698734")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("Why do you think it’s “for them” and not for the community itself?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698744")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("Do people honestly think that OpenAI has a moral (or legal?) obligation to do this work? They solved a bunch of problems, for their own self interest of course, and released the solutions, and somehow they still owe work to others? If their solutions were not helpful to us, we could surely just ignore them, right? And if they didn’t release this work now, what do you think will happen if, say in 1 or 2 years, anyone with a few spare bucks can prompt a paid version of some chatbot and get a slop proof of the RH? Will you ask everyone and their mother using an AI to dutifully “refine” their output as well?")

#text("Obviously, what they did greatly affects the mathematical ecosystem, but that is due to academia’s own set of issues, and I don’t think OpenAI de-slopfying their proofs would change anything in that regard. I in fact do think that if OpenAI worked more closely with academia it could be good for them, and for us as well, but I doubt they would do it with people shouting “BIG CORPORATION BAD” and demanding things.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698764")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("Sorry, no. “Big Corporation Bad” and going viral is literally the only thing Silicon Valley reacts to.")

#text("Academics could tell all students at all universities to boycott Silicon Valley in general, to switch off their iPhones in protest and no longer use and web services apart from search and email.")

#text("You remember how Facebook went viral? Through Harvard! You could do the same in the opposite direction, and Gen-Z and Gen-Alpha hate the Internet more than Gen-X and millenials.")

#text("Students reading this: You can also do it on your own! .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698747")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("There are hundreds of AI-generated write-ups here, and they often don’t cite the people who deserve citation, people who spent so much time trying to see just a little further than those who came before, and part of what makes math human is that we acknowledge who came before, we give credit where it’s due, including to those who are no longer with us, who can no longer speak for themselves, and so even if we disagree on digestion, we can perhaps agree on attribution, on the simple act of our saying to each other, “I see you,” one pull request at a time.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a2d50c5efee25d34bbb27088c5295a8d4f1812e26dfa198ca7fdfe0f097e3024-581b5155ff02e1d89d19661562044f82a48ce213ee4ad9fc602ae8932e154037.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Skip Tich")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698722")[#strong[#text("Skip Tich")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("Given the nature of the existing tension between the mathematical community and frontier labs, I have to wonder, is this really the right thing to do? To engage with the labs in good faith, cleaning up and polishing their results for them?")

#text("It seems that this will mainly serve to validate the approach that OpenAI has taken, and to pigeonhole mathematicians into the role of interpreting the “gifts” the “machine gods” have bestowed upon us, further distracting them from what should be their main purpose right now, which is figuring out how to act autonomously as a community going forward.")

#text("In addition, these improved writeups will be used as training data for the future models. OpenAI will eat these up and spit you out without so much as a thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698724")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("Several of the authors appear to be heavily involved in machine learning and AI for math. While it is expected that initiatives would come from such a direction, it is not really a neutral organization.")

#text("The repository is separate from OpenAI, but participants will work for free for OpenAI.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63b49eb890ed710b8c76993bc58baae29a2e3c8cccefffcddbfee8eec8351751-0b5f8ed2fd0af0be5adcb141fe77cbdbe858a8085e65a8f6a868d46e73aa5efe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698725")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("Why is it our job to revise OpenAI’s manuscripts? They are the authors and they are responsible for the content and the quality of the writing.")

#text("We are interested in understanding the scientific advance, regardless of the source, and we are fully within our rights to produce review articles and share ")#emph[#text("our")]#text(" understanding, but it seems weird for me to spend volunteer efforts into improving write-ups that belong to a wealthy for-profit company. If they want these services they should pay for them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96b45a32eefa345f3c18dfcadba0898bef39bd44505afcdab4ad7c12648091f6-d907b1b1dabc87087ff2462e4899695a8b4655fe28c67815c539d7baf76a3ce1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698733")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("Really strange. Why would I revise somebody else’s manuscript? I would use the result (or idea) and cite it as it is.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698769")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("Was “understanding” was our actual goal?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698789")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("Believe it or not, such things (people producing more comprehensible expositions of incomprehensible works) are not so uncommon in mathematics history…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b39c546bc3a8d246fc03ff76ef7d9e96a8153964ce35658ea698b91690d55991-bf75e3bc72f11dd8e9323226b8a9b353242914d872fd29e731e6a64fc85d69ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jaume")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698742")[#strong[#text("Jaume")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("What OpenAI did to math is akin to somebody dropping a gigantic database of environmental DNA (")#link("https://en.wikipedia.org/wiki/Environmental_DNA")[#text("https://en.wikipedia.org/wiki/Environmental_DNA")]#text(") without really explaining the provenance or anything about it, in order to show the world they have the biggest, baddest DNA sequencing machine. This is quite different from actually writing 300 biology papers.")

#text("Now biologists will wish to use that database for interesting stuff of course! Including crowd-sourcing efforts to understand what’s in there. But claiming that we are cleaning up 100s of papers of the DNA dumper… the dumper just dumped a pile of stuff without any intention to meaningfully engage academically.")

#text("One could claim that the individual raw OAI dump pieces have more potential academic value than contextless DNA. I think that’s 2025 thinking")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698750")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("I will quote something on Gowers’ blog:")

#text("“Under the circumstances, I think the best we can do is recognise the changes that are coming and try to work out the least unsatisfactory way of dealing with them.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698762")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("I agree. In fact, for everything except the most major advances, I think humans should do nothing with the Open AI results. I think it’s best to wait and let the AI companies work on making the maths more comprehensible and improving the quality of exposition and citation. That will happen I’m sure so to me it seems that it’s a colossal waste of time doing that by hand when in a year the AIs will do that themselves.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b7b7a239469affa1a4b1a2acf2ce3aa78f2d545704d09e87f1fa3c5387858562-d9818fdeb577d9cf5e16963235b3497e0377868f47041ab711b5b995b8e6fb95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nestor")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698737")[#strong[#text("Nestor")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("This is not “revising” as in, fixing their work for them. This is “revising” as in … a big corporation dumped a bunch of toxic sludge over a national park, and people are volunteering to help clean up the sludge because they care deeply about the long term well being of the park.")

#text("We can talk later about how said corporation will be held accountable for their toxic sludge dump")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698775")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("Not sure why so many people are downvoting this, as this is a great analogy. Maybe because you are too optimistic that they will actually be “held accountable”? (Or because we have too many OpenAI fans on this page at this point?). Either way, how do you think we could hold them accountable? This (the “toxic sludge dump”) is not going to court. The only thing I can think of is that fair use act needs to be adapted (many cases in court currently). Locally run LLMs that are created for education and true benefit of humanity and not just for profit with a “machine god” as the goal are another.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5af229732d765dd4c27f31294124214db630170866a7e407b1e33080fab8a436-1e44f5e82e084d21f07422992b132e1719ac21581828c9df3348865d785f9de0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ke zhang")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698741")[#strong[#text("ke zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("Not sure revision is the right approach to take. It makes more sense to have independent papers on the same results, and have the website serve as a reference to these papers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698746")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("If I’m being honest, the OpenAI results should never have been made public. This is the Shinichi Mochizuki situation multiplied by a few hundred. And don’t tell me that Lean makes things everything better that’s completely unreadable.")

#text("OpenAI should have distributed their generations to top mathematicians *in private* and offered them some compensation for turning their work into something artful. Public release, it’s just bystander effect, no one wants to exposit on something that they won’t get credit for.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698766")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("Why did they make it public in unpolished form? Because they got accused of theft for their Navier-Stokes result! Mathematicians said “LLMs cant do that, only with human ideas” etc. So they said F that! Here are all the results. Thankfully not cluttering arxiv but instead in a git repo. In also remember the time we all wanted to know what 100 results where to be puplished and urged them to release them. Damned if they don’t, damned if they do ..")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698790")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("OP here. OpenAI should not have publicly announced the 100 results in the first place. They dug their own hole!! Haven’t they learned the tacit rules in academia for announcing results and releasing them when they’re ready???")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e68ad5ef30f6d67b90d51b5f9a35ea5d361caaa31659cce10cfbfbfffba1383b-288477e4f6db6fdd9682494dece194578bb941ce85ea010830cfc9cb3f3b6379.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kunal Relia")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698749")[#strong[#text("Kunal Relia")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("@Guest post writers: Thank you for this initiative! Not sure if this makes sense: is there any way to add another family tag to the problems where contributions, even if true, are overstated?")

#text("For instance, in family 102 (The Unique Games Conjecture and optimal approximation thresholds) within TCS, if UGC is true (as claimed in “")#link("https://mathcommunity.github.io/oai-math-revised/papers/The-Unique-Games-Theorem-September-23-2026/")[#text("The Unique Games Theorem")]#text("“), then many results are already known to hold. Hence, contributions of such papers, as stated in the abstract, are an oversell.")

#text("For example, the abstract in ")#link("https://mathcommunity.github.io/oai-math-revised/papers/The-Factor-Two-Hardness-Threshold-for-Vertex-Cover-September-23-2026/")[#text("The Factor-Two Hardness Threshold for Vertex Cover")]#text(" claims that “We prove that minimum Vertex Cover is NP-hard to approximate within every fixed factor below two, even on simple unweighted graphs.”. However, given UGC is true, Khot and Regev already proved this bound in 2008. Hence, the significance of the Vertex Cover result becomes unclear. Yes, newer methods may be introduced, but the paper should clearly highlight what the contribution is. As such, it currently seems to oversell. This is not an isolated case within this family (another e.g., Max-Cut hardness was also established by Khot, Kindler, Mossel, and O’Donnell in 2007), and hence, may also be seen in other families.")

#text("Overall, an outcome of this additional tag is that it may help us channelize the efforts more appropriately?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698765")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("As an example of what a contribution to this repository might look like, I can mention my ")#link("https://github.com/mathcommunity/oai-math-revised/pull/2")[#text("own")]#text(" ")#link("https://github.com/mathcommunity/oai-math-revised/pull/3")[#text("pull requests to the repo")]#text(", regarding the OpenAI document establishing the non-existence of Siegel zeroes. The revised version now also mentions the subsequent preprints of Banks, Kerr, and Green, as well as the blog post of myself.")

#text("My understanding of the project is that it seeks to allow all the separate discussions about individual manuscripts in the release to be coordinated, by having a central, community-owned location where corrections, followup work, or criticism can be placed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698776")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("Everyone should read this: ")#link("https://arxiv.org/abs/2610.27251v1")[#text("https://arxiv.org/abs/2610.27251v1")]

#text("The unintelligible is a feature not a bug.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6449c72cac47a1e5b32dcbcc95a4ef6460de317547386ddeda6779e99896f305-ea9c8824520501d89b6ef706552c581f2c5b51604b15234985ca3b92d9956378.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698781")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("For those who don’t know it yet, there is a relevant site focusing on discussing/commenting on OAI-generated papers, by professional mathematicians (in a non-profit manner): ")#link("https://mathhelm.org/")[#text("https://mathhelm.org/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698784")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("Would people be generally happy if the citations in introductions are cleaned up and authors are properly attributed?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf21df28bd6b406801a965b260c7561daea71ad6ced31977440031661fd4ea75-50a49222b94a78adf93515f71b5b30ddade1e6993340216c29c0893be4a922a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698808")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("And thus mathematicians keep on feeding new materials into those AI giant machineries.")

#list(
[#text("We clean their junks and hence provide free, extremely valuable labels.")],
[#text("We talk a lot about what to do with our future, Math 2.0 and so on across multiple platforms, and hence provide new ideas about what the machines should just work on next.")]
)

#text("Nobody has tried to imagine OAI’s next move to claim their decisive victory over human intelligence. They failed to claim it once, they will surely come back. Until we have a clear, equal alternative than ChatGPT, maths (be it a maths conjecture, or an existing area, or a new initiave and mathematical framwork) will just repeatedly serve as an experimental site and a scapegoat.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/comment-page-1/#comment-698901")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("has anyone looked into why the mathlib keeps filing to compile? I’m getting missing Mathlib errors when I try to compile the millenium proofs. I’m not really sure how to fix the dependencies in lakefile.lean")
]
