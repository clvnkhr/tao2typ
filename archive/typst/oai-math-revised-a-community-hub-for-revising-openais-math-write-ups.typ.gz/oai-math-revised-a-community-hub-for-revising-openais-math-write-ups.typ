// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/
// Converted to Typst by tao2typ: "2026-11-24T18:00:19.900495+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "oai-math-revised: a community hub for revising OpenAI’s math write-ups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("oai-math-revised: a community hub for revising OpenAI’s math write-ups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/")[#text("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-24 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://www.ohsu.edu/people/abhinav-nellore-phd")[#text("Abhinav Nellore")]#text(", ")#link("https://johannesschmitt.gitlab.io/")[#text("Johannes Schmitt")]#text(", ")#link("https://www.ams.jhu.edu/villar/")[#text("Soledad Villar")]#text(", and ")#link("https://oden.utexas.edu/people/directory/rachel--ward/")[#text("Rachel Ward")]#text(" – T.]")]

#text("OpenAI’s math write-ups at ")#link("https://github.com/openai/math")[#text("https://github.com/openai/math")]#text(" can be difficult to understand and can have incomplete citations.")

#link("https://github.com/mathcommunity/oai-math-revised/ ")[#text("https://github.com/mathcommunity/oai-math-revised/ ")]#text("seeks to be an inclusive effort to improve these write-ups, and the broader math community–students, postdocs, professors, and enthusiasts–is invited to participate.")

#text("The repo is browsable at ")#link("https://mathcommunity.github.io/oai-math-revised/")[#text("https://mathcommunity.github.io/oai-math-revised/")]

#text("We also invite the community to email ")#link("mailto:mathcommunityadmin@gmail.com")[#text("mathcommunityadmin@gmail.com")]#text(" if they want to serve as admins/reviewers and for which categories from ")#link("https://github.com/openai/math/blob/main/overview.pdf")[#text("https://github.com/openai/math/blob/main/overview.pdf")]#text(" they’d be appropriate for reviews.")

#heading(level: 1)[#text("Comments (28)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698721")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("So it is up to unpaid volunteers to sift through OpenAI’s slop and refine their output for them? After all the fanciful debate about putting pressure on these trillion-dollar companies, nothing has fundamentally shifted in our approach?")

#text("It’s good to know that you can always count on academia to never change for the better even in the face of the most extreme circumstances.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698734")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("Why do you think it’s “for them” and not for the community itself?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698744")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("Do people honestly think that OpenAI has a moral (or legal?) obligation to do this work? They solved a bunch of problems, for their own self interest of course, and released the solutions, and somehow they still owe work to others? If their solutions were not helpful to us, we could surely just ignore them, right? And if they didn’t release this work now, what do you think will happen if, say in 1 or 2 years, anyone with a few spare bucks can prompt a paid version of some chatbot and get a slop proof of the RH? Will you ask everyone and their mother using an AI to dutifully “refine” their output as well?")

#text("Obviously, what they did greatly affects the mathematical ecosystem, but that is due to academia’s own set of issues, and I don’t think OpenAI de-slopfying their proofs would change anything in that regard. I in fact do think that if OpenAI worked more closely with academia it could be good for them, and for us as well, but I doubt they would do it with people shouting “BIG CORPORATION BAD” and demanding things.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b2471604c8902ec9746d53afa441873dadc9012b5022d6ff0bc83852a9993e-b8d80f565218ccfbd08a65971f9e4d3de692f80225ef4b30178db5d2e2c01251.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698764")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("Sorry, no. “Big Corporation Bad” and going viral is literally the only thing Silicon Valley reacts to.")

#text("Academics could tell all students at all universities to boycott Silicon Valley in general, to switch off their iPhones in protest and no longer use and web services apart from search and email.")

#text("You remember how Facebook went viral? Through Harvard! You could do the same in the opposite direction, and Gen-Z and Gen-Alpha hate the Internet more than Gen-X and millenials.")

#text("Students reading this: You can also do it on your own! .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698747")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("There are hundreds of AI-generated write-ups here, and they often don’t cite the people who deserve citation, people who spent so much time trying to see just a little further than those who came before, and part of what makes math human is that we acknowledge who came before, we give credit where it’s due, including to those who are no longer with us, who can no longer speak for themselves, and so even if we disagree on digestion, we can perhaps agree on attribution, on the simple act of our saying to each other, “I see you,” one pull request at a time.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5db3a342e02baf848ff7ba3828f0f202a77b34639e900fd9aa71b564d12cba87-3ee22a8b7c4c3f51cf0cb4a49f65fe811072197dae2482aad6f6d2744ff772fe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Skip Tich")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698722")[#strong[#text("Skip Tich")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("Given the nature of the existing tension between the mathematical community and frontier labs, I have to wonder, is this really the right thing to do? To engage with the labs in good faith, cleaning up and polishing their results for them?")

#text("It seems that this will mainly serve to validate the approach that OpenAI has taken, and to pigeonhole mathematicians into the role of interpreting the “gifts” the “machine gods” have bestowed upon us, further distracting them from what should be their main purpose right now, which is figuring out how to act autonomously as a community going forward.")

#text("In addition, these improved writeups will be used as training data for the future models. OpenAI will eat these up and spit you out without so much as a thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b2471604c8902ec9746d53afa441873dadc9012b5022d6ff0bc83852a9993e-b8d80f565218ccfbd08a65971f9e4d3de692f80225ef4b30178db5d2e2c01251.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698724")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("Several of the authors appear to be heavily involved in machine learning and AI for math. While it is expected that initiatives would come from such a direction, it is not really a neutral organization.")

#text("The repository is separate from OpenAI, but participants will work for free for OpenAI.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698725")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("Why is it our job to revise OpenAI’s manuscripts? They are the authors and they are responsible for the content and the quality of the writing.")

#text("We are interested in understanding the scientific advance, regardless of the source, and we are fully within our rights to produce review articles and share ")#emph[#text("our")]#text(" understanding, but it seems weird for me to spend volunteer efforts into improving write-ups that belong to a wealthy for-profit company. If they want these services they should pay for them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39a0699ba9525075d5db4bc91d5c1300a04539d0b43a9c06a99573da5f4fa039-294cf81fd75a9628a7907f7fc252faec317a3b904a4fcb2b03fee6d66286ef76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698733")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("Really strange. Why would I revise somebody else’s manuscript? I would use the result (or idea) and cite it as it is.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698769")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("Was “understanding” was our actual goal?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698789")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("Believe it or not, such things (people producing more comprehensible expositions of incomprehensible works) are not so uncommon in mathematics history…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/89bb0c29dac5c7c2999792e1a2015aff6d5eaff78014e4324deec42500540084-9db649c739c9a1f9c57cdf4cdd3dc17db5ef7d333d3479dafef3c3704c0f47b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jaume")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698742")[#strong[#text("Jaume")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("What OpenAI did to math is akin to somebody dropping a gigantic database of environmental DNA (")#link("https://en.wikipedia.org/wiki/Environmental_DNA")[#text("https://en.wikipedia.org/wiki/Environmental_DNA")]#text(") without really explaining the provenance or anything about it, in order to show the world they have the biggest, baddest DNA sequencing machine. This is quite different from actually writing 300 biology papers.")

#text("Now biologists will wish to use that database for interesting stuff of course! Including crowd-sourcing efforts to understand what’s in there. But claiming that we are cleaning up 100s of papers of the DNA dumper… the dumper just dumped a pile of stuff without any intention to meaningfully engage academically.")

#text("One could claim that the individual raw OAI dump pieces have more potential academic value than contextless DNA. I think that’s 2025 thinking")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698750")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("I will quote something on Gowers’ blog:")

#text("“Under the circumstances, I think the best we can do is recognise the changes that are coming and try to work out the least unsatisfactory way of dealing with them.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698762")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("I agree. In fact, for everything except the most major advances, I think humans should do nothing with the Open AI results. I think it’s best to wait and let the AI companies work on making the maths more comprehensible and improving the quality of exposition and citation. That will happen I’m sure so to me it seems that it’s a colossal waste of time doing that by hand when in a year the AIs will do that themselves.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef56db71d958f5047139912a0c9b31b770236c367cfa407466708f3d3ed9626e-8536151e32c141f00c22d3db8a7c045b3e045c1ab1cdb6157c04c755d0e6b6c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nestor")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698737")[#strong[#text("Nestor")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("This is not “revising” as in, fixing their work for them. This is “revising” as in … a big corporation dumped a bunch of toxic sludge over a national park, and people are volunteering to help clean up the sludge because they care deeply about the long term well being of the park.")

#text("We can talk later about how said corporation will be held accountable for their toxic sludge dump")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698775")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("Not sure why so many people are downvoting this, as this is a great analogy. Maybe because you are too optimistic that they will actually be “held accountable”? (Or because we have too many OpenAI fans on this page at this point?). Either way, how do you think we could hold them accountable? This (the “toxic sludge dump”) is not going to court. The only thing I can think of is that fair use act needs to be adapted (many cases in court currently). Locally run LLMs that are created for education and true benefit of humanity and not just for profit with a “machine god” as the goal are another.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2cf9823f963dc97ce2d6c0f6f19a7318fa2b0b953dc4680833736e5fba65b42-5a0c24056d94e9f27c7dba7d0c90dda637ebba85866c817d392ef73d41cf3fed.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ke zhang")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698741")[#strong[#text("ke zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("Not sure revision is the right approach to take. It makes more sense to have independent papers on the same results, and have the website serve as a reference to these papers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698746")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("If I’m being honest, the OpenAI results should never have been made public. This is the Shinichi Mochizuki situation multiplied by a few hundred. And don’t tell me that Lean makes things everything better that’s completely unreadable.")

#text("OpenAI should have distributed their generations to top mathematicians *in private* and offered them some compensation for turning their work into something artful. Public release, it’s just bystander effect, no one wants to exposit on something that they won’t get credit for.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698766")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("Why did they make it public in unpolished form? Because they got accused of theft for their Navier-Stokes result! Mathematicians said “LLMs cant do that, only with human ideas” etc. So they said F that! Here are all the results. Thankfully not cluttering arxiv but instead in a git repo. In also remember the time we all wanted to know what 100 results where to be puplished and urged them to release them. Damned if they don’t, damned if they do ..")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698790")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("OP here. OpenAI should not have publicly announced the 100 results in the first place. They dug their own hole!! Haven’t they learned the tacit rules in academia for announcing results and releasing them when they’re ready???")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75c8255e03b8aaf5a54d980cb77b99bb8e1cc7ce1ebac3e417ad0ffbb9f2a491-7b0b3178b4ae3bfd276829385483a61bbe6b7b42982364a95e24882c11859ece.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kunal Relia")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698749")[#strong[#text("Kunal Relia")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("@Guest post writers: Thank you for this initiative! Not sure if this makes sense: is there any way to add another family tag to the problems where contributions, even if true, are overstated?")

#text("For instance, in family 102 (The Unique Games Conjecture and optimal approximation thresholds) within TCS, if UGC is true (as claimed in “")#link("https://mathcommunity.github.io/oai-math-revised/papers/The-Unique-Games-Theorem-September-23-2026/")[#text("The Unique Games Theorem")]#text("“), then many results are already known to hold. Hence, contributions of such papers, as stated in the abstract, are an oversell.")

#text("For example, the abstract in ")#link("https://mathcommunity.github.io/oai-math-revised/papers/The-Factor-Two-Hardness-Threshold-for-Vertex-Cover-September-23-2026/")[#text("The Factor-Two Hardness Threshold for Vertex Cover")]#text(" claims that “We prove that minimum Vertex Cover is NP-hard to approximate within every fixed factor below two, even on simple unweighted graphs.”. However, given UGC is true, Khot and Regev already proved this bound in 2008. Hence, the significance of the Vertex Cover result becomes unclear. Yes, newer methods may be introduced, but the paper should clearly highlight what the contribution is. As such, it currently seems to oversell. This is not an isolated case within this family (another e.g., Max-Cut hardness was also established by Khot, Kindler, Mossel, and O’Donnell in 2007), and hence, may also be seen in other families.")

#text("Overall, an outcome of this additional tag is that it may help us channelize the efforts more appropriately?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698765")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("As an example of what a contribution to this repository might look like, I can mention my ")#link("https://github.com/mathcommunity/oai-math-revised/pull/2")[#text("own")]#text(" ")#link("https://github.com/mathcommunity/oai-math-revised/pull/3")[#text("pull requests to the repo")]#text(", regarding the OpenAI document establishing the non-existence of Siegel zeroes. The revised version now also mentions the subsequent preprints of Banks, Kerr, and Green, as well as the blog post of myself.")

#text("My understanding of the project is that it seeks to allow all the separate discussions about individual manuscripts in the release to be coordinated, by having a central, community-owned location where corrections, followup work, or criticism can be placed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698776")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("Everyone should read this: ")#link("https://arxiv.org/abs/2610.27251v1")[#text("https://arxiv.org/abs/2610.27251v1")]

#text("The unintelligible is a feature not a bug.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b10e17911c4bb3addde89124f3d09e2dbd0e922b5be93a73c6f3818b8791647-0269d4b557b68f009161d10faf0a45633395ee7a3a567a7479717bf4c9ada785.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698781")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("For those who don’t know it yet, there is a relevant site focusing on discussing/commenting on OAI-generated papers, by professional mathematicians (in a non-profit manner): ")#link("https://mathhelm.org/")[#text("https://mathhelm.org/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698784")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("Would people be generally happy if the citations in introductions are cleaned up and authors are properly attributed?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bae3c66c9d6116673b2b47bd8260ed6ce387a4b106bbbaaea66991e4aa92410f-066d565535d92fba54129db603ddaac58aeb699db18cb62369f775655478bdd0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698808")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("And thus mathematicians keep on feeding new materials into those AI giant machineries.")

#list(
[#text("We clean their junks and hence provide free, extremely valuable labels.")],
[#text("We talk a lot about what to do with our future, Math 2.0 and so on across multiple platforms, and hence provide new ideas about what the machines should just work on next.")]
)

#text("Nobody has tried to imagine OAI’s next move to claim their decisive victory over human intelligence. They failed to claim it once, they will surely come back. Until we have a clear, equal alternative than ChatGPT, maths (be it a maths conjecture, or an existing area, or a new initiave and mathematical framwork) will just repeatedly serve as an experimental site and a scapegoat.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698901")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("has anyone looked into why the mathlib keeps filing to compile? I’m getting missing Mathlib errors when I try to compile the millenium proofs. I’m not really sure how to fix the dependencies in lakefile.lean")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9aeb61a1bef7a6823fab3a411bb0f13e9afb171523269a0065cdf42344b64540-fef28a7e80dd2bd86f5ef79eb96e64aa458ae29fd7b63595eddf5f0f384d58af.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stefan Best")]], [#link("https://terrytao.wordpress.com/2026/10/24/oai-math-revised-a-community-hub-for-revising-openais-math-write-ups/#comment-698914")[#strong[#text("Stefan Best")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("Check the lakefile.lean on GitHub, they’re not using mathlib")
]
