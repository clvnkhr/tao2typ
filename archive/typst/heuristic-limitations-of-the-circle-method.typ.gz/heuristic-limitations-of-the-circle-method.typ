// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/
// Converted to Typst by tao2typ: "2026-10-14T09:26:13.796386+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Heuristic limitations of the circle method", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Heuristic limitations of the circle method")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 May 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/")[#text("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the most basic methods in ")#link("http://en.wikipedia.org/wiki/Additive_number_theory")[#text("additive number theory")]#text(" is the ")#link("http://en.wikipedia.org/wiki/Hardy%E2%80%93Littlewood_circle_method")[#text("Hardy-Littlewood circle method")]#text(". This method is based on expressing a quantity of interest to additive number theory, such as the number of representations ")#mi("{f_3(x)}")#text(" of an integer ")#mi("{x}")#text(" as the sum of three primes ")#mi("{x = p_1+p_2+p_3}")#text(", as a Fourier-analytic integral over the unit circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(" involving exponential sums such as ")#metadata(none) <tao-643efd884376a624231a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("S(x,\\alpha) := \\sum_{p \\leq x} e( \\alpha p)")]]

#text("where the sum here ranges over all primes up to ")#mi("{x}")#text(", and ")#mi("{e(x) := e^{2\\pi i x}}")#text(". For instance, the expression ")#mi("{f(x)}")#text(" mentioned earlier can be written as ")#metadata(none) <tao-d2fd404cbf285947c80b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("f_3(x) = \\int_{{\\bf R}/{\\bf Z}} S(x,\\alpha)^3 e(-x\\alpha)\\ d\\alpha.")]]

#text("The strategy is then to obtain sufficiently accurate bounds on exponential sums such as ")#mi("{S(x,\\alpha)}")#text(" in order to obtain non-trivial bounds on quantities such as ")#mi("{f_3(x)}")#text(". For instance, if one can show that ")#mi("{f_3(x)>0}")#text(" for all odd integers ")#mi("{x}")#text(" greater than some given threshold ")#mi("{x_0}")#text(", this implies that all odd integers greater than ")#mi("{x_0}")#text(" are expressible as the sum of three primes, thus establishing all but finitely many instances of the ")#link("http://en.wikipedia.org/wiki/Goldbach%27s_weak_conjecture")[#text("odd Goldbach conjecture")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" In practice, it can be more efficient to work with smoother sums than the partial sum ")#link(<tao-643efd884376a624231a>)[#text("(1)")]#text(", for instance by replacing the cutoff ")#mi("{p \\leq x}")#text(" with a ")#link("http://www.tricki.org/article/Smoothing_sums")[#text("smoother cutoff")]#text(" ")#mi("{\\chi(p/x)}")#text(" for a suitable choice of cutoff function ")#mi("{\\chi}")#text(", or by replacing the restriction of the summation to primes by a more analytically tractable weight, such as the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(" ")#mi("{\\Lambda(n)}")#text(". However, these improvements to the circle method are primarily technical in nature and do not have much impact on the heuristic discussion in this post, so we will not emphasise them here. One can also certainly use the circle method to study additive combinations of numbers from other sets than the set of primes, but we will restrict attention to additive combinations of primes for sake of discussion, as it is historically one of the most studied sets in additive number theory.")
]

#text("In many cases, it turns out that one can get fairly precise evaluations on sums such as ")#mi("{S(x,\\alpha)}")#text(" in the ")#emph[#text("major arc")]#text(" case, when ")#mi("{\\alpha}")#text(" is close to a rational number ")#mi("{a/q}")#text(" with small denominator ")#mi("{q}")#text(", by using tools such as the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem#Prime_number_theorem_for_arithmetic_progressions")[#text("prime number theorem in arithmetic progressions")]#text(". For instance, the prime number theorem itself tells us that")

#align(center)[#tao-fit-display[#mitex("S(x,0) \\approx \\frac{x}{\\log x}")]]

#text("and the prime number theorem in residue classes modulo ")#mi("{q}")#text(" suggests more generally that")

#align(center)[#tao-fit-display[#mitex("S(x,\\frac{a}{q}) \\approx \\frac{\\mu(q)}{\\phi(q)} \\frac{x}{\\log x}")]]

#text("when ")#mi("{q}")#text(" is small and ")#mi("{a}")#text(" is close to ")#mi("{q}")#text(", basically thanks to the elementary calculation that the phase ")#mi("{e(an/q)}")#text(" has an average value of ")#mi("{\\mu(q)/\\phi(q)}")#text(" when ")#mi("{n}")#text(" is uniformly distributed amongst the residue classes modulo ")#mi("{q}")#text(" that are coprime to ")#mi("{q}")#text(". Quantifying the precise error in these approximations can be quite challenging, though, unless one assumes powerful hypotheses such as the ")#link("http://en.wikipedia.org/wiki/Generalized_Riemann_hypothesis")[#text("Generalised Riemann Hypothesis")]#text(".")

#text("In the ")#emph[#text("minor arc")]#text(" case when ")#mi("{\\alpha}")#text(" is not close to a rational ")#mi("{a/q}")#text(" with small denominator, one no longer expects to have such precise control on the value of ")#mi("{S(x,\\alpha)}")#text(", due to the “pseudorandom” fluctuations of the quantity ")#mi("{e(\\alpha p)}")#text(". Using the standard probabilistic heuristic (supported by results such as the central limit theorem or Chernoff’s inequality) that the sum of ")#mi("{k}")#text(" “pseudorandom” phases should fluctuate randomly and be of typical magnitude ")#mi("{\\sim \\sqrt{k}}")#text(", one expects upper bounds of the shape ")#metadata(none) <tao-7b496cbed62b73147bc2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|S(x,\\alpha)\\right| \\lessapprox \\sqrt{\\frac{x}{\\log x}}", block: true)]]

#text("for “typical” minor arc ")#mi("{\\alpha}")#text(". Indeed, a simple application of the Plancherel identity, followed by the prime number theorem, reveals that ")#metadata(none) <tao-98df9a59f0641d0c4409>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\int_{{\\bf R}/{\\bf Z}} \\left|S(x,\\alpha)\\right|^2\\ d\\alpha \\sim \\frac{x}{\\log x}", block: true)]]

#text("which is consistent with (though weaker than) the above heuristic. In practice, though, we are unable to rigorously establish bounds anywhere near as strong as ")#link(<tao-7b496cbed62b73147bc2>)[#text("(3)")]#text("; upper bounds such as ")#mi("{x^{4/5+o(1)}}")#text(" are far more typical.")

#text("Because one only expects to have upper bounds on ")#tao-math("{\\left|S(x,\\alpha)\\right|}", block: false)#text(", rather than asymptotics, in the minor arc case, one cannot realistically hope to make much use of phases such as ")#mi("{e(-x\\alpha)}")#text(" for the minor arc contribution to integrals such as ")#link(<tao-d2fd404cbf285947c80b>)[#text("(2)")]#text(" (at least if one is working with a single, deterministic, value of ")#mi("{x}")#text(", so that averaging in ")#mi("{x}")#text(" is unavailable). In particular, from upper bound information alone, it is difficult to avoid the “conspiracy” that the magnitude ")#tao-math("{\\left|S(x,\\alpha)\\right|^3}", block: false)#text(" oscillates in sympathetic resonance with the phase ")#mi("{e(-x\\alpha)}")#text(", thus essentially eliminating almost all of the possible gain in the bounds that could arise from exploiting cancellation from that phase. Thus, one basically has little option except to use the triangle inequality to control the portion of the integral on the minor arc region ")#mi("{\\Omega_{minor}}")#text(":")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{\\Omega_{minor}} S(x,\\alpha)^3 e(-x\\alpha)\\ d\\alpha\\right| \\leq \\int_{\\Omega_{minor}} \\left|S(x,\\alpha)\\right|^3\\ d\\alpha.", block: true)]]

#text("Despite this handicap, though, it is still possible to get enough bounds on both the major and minor arc contributions of integrals such as ")#link(<tao-d2fd404cbf285947c80b>)[#text("(2)")]#text(" to obtain non-trivial lower bounds on quantities such as ")#mi("{f(x)}")#text(", at least when ")#mi("{x}")#text(" is large. In particular, this sort of method can be developed to give a proof of ")#link("http://en.wikipedia.org/wiki/Vinogradov%27s_theorem")[#text("Vinogradov’s famous theorem")]#text(" that every sufficiently large odd integer ")#mi("{x}")#text(" is the sum of three primes; ")#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/")[#text("my own result that all odd numbers greater than ")#mi("{1}")#text(" can be expressed as the sum of at most five primes")]#text(" is also proven by essentially the same method (modulo a number of minor refinements, and taking advantage of some numerical work on both the Goldbach problems and on the Riemann hypothesis ). It is certainly conceivable that some further variant of the circle method (again combined with a suitable amount of numerical work, such as that of numerically establishing zero-free regions for the Generalised Riemann Hypothesis) can be used to settle the full odd Goldbach conjecture; indeed, under the assumption of the Generalised Riemann Hypothesis, this was already ")#link("http://www.ams.org/mathscinet-getitem?mr=1469323")[#text("achieved by Deshouillers, Effinger, te Riele, and Zinoviev")]#text(" back in 1997. I am optimistic that an unconditional version of this result will be possible within a few years or so, though I should say that there are still significant technical challenges to doing so, and some clever new ideas will probably be needed to get either the Vinogradov-style argument or numerical verification to work unconditionally for the three-primes problem at medium-sized ranges of ")#mi("{x}")#text(", such as ")#mi("{x \\sim 10^{50}}")#text(". (But the intermediate problem of representing all even natural numbers as the sum of at most four primes looks somewhat closer to being feasible, though even this would require some substantially new and non-trivial ideas beyond what is in my five-primes paper.)")

#text("However, I (and many other analytic number theorists) are considerably more skeptical that the circle method can be applied to the ")#link("http://en.wikipedia.org/wiki/Goldbach%27s_conjecture")[#text("even Goldbach problem")]#text(" of representing a large even number ")#mi("{x}")#text(" as the sum ")#mi("{x = p_1 + p_2}")#text(" of two primes, or the similar (and marginally simpler) ")#link("http://en.wikipedia.org/wiki/Twin_prime")[#text("twin prime conjecture")]#text(" of finding infinitely many pairs of twin primes, i.e. finding infinitely many representations ")#mi("{2 = p_1 - p_2}")#text(" of ")#mi("{2}")#text(" as the ")#emph[#text("difference")]#text(" of two primes. At first glance, the situation looks tantalisingly similar to that of the Vinogradov theorem: to settle the even Goldbach problem for large ")#mi("{x}")#text(", one has to find a non-trivial lower bound for the quantity ")#metadata(none) <tao-286b2d656b7f6fbd85a2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("f_2(x) = \\int_{{\\bf R}/{\\bf Z}} S(x,\\alpha)^2 e(-x\\alpha)\\ d\\alpha")]]

#text("for sufficiently large ")#mi("{x}")#text(", as this quantity ")#mi("{f_2(x)}")#text(" is also the number of ways to represent ")#mi("{x}")#text(" as the sum ")#mi("{x=p_1+p_2}")#text(" of two primes ")#mi("{p_1,p_2}")#text(". Similarly, to settle the twin prime problem, it would suffice to obtain a lower bound for the quantity ")#metadata(none) <tao-56db8ad52622b26d8b1d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\tilde f_2(x) = \\int_{{\\bf R}/{\\bf Z}} \\left|S(x,\\alpha)\\right|^2 e(-2\\alpha)\\ d\\alpha", block: true)]]

#text("that goes to infinity as ")#mi("{x \\rightarrow \\infty}")#text(", as this quantity ")#mi("{\\tilde f_2(x)}")#text(" is also the number of ways to represent ")#mi("{2}")#text(" as the difference ")#mi("{2 = p_1-p_2}")#text(" of two primes less than or equal to ")#mi("{x}")#text(".")

#text("In principle, one can achieve either of these two objectives by a sufficiently fine level of control on the exponential sums ")#mi("{S(x,\\alpha)}")#text(". Indeed, there is a trivial (and uninteresting) way to take any (hypothetical) solution of either the asymptotic even Goldbach problem or the twin prime problem and (artificially) convert it to a proof that “uses the circle method”; one simply begins with the quantity ")#mi("{f_2(x)}")#text(" or ")#mi("{\\tilde f_2(x)}")#text(", expresses it in terms of ")#mi("{S(x,\\alpha)}")#text(" using ")#link(<tao-286b2d656b7f6fbd85a2>)[#text("(5)")]#text(" or ")#link(<tao-56db8ad52622b26d8b1d>)[#text("(6)")]#text(", and then uses ")#link(<tao-286b2d656b7f6fbd85a2>)[#text("(5)")]#text(" or ")#link(<tao-56db8ad52622b26d8b1d>)[#text("(6)")]#text(" again to convert these integrals back into a the combinatorial expression of counting solutions to ")#mi("{x=p_1+p_2}")#text(" or ")#mi("{2=p_1-p_2}")#text(", and then uses the hypothetical solution to the given problem to obtain the required lower bounds on ")#mi("{f_2(x)}")#text(" or ")#mi("{\\tilde f_2(x)}")#text(".")

#text("Of course, this would not qualify as a genuine application of the circle method by any reasonable measure. One can then ask the more refined question of whether one could hope to get non-trivial lower bounds on ")#mi("{f_2(x)}")#text(" or ")#mi("{\\tilde f_2(x)}")#text(" (or similar quantities) purely from the upper and lower bounds on ")#mi("{S(x,\\alpha)}")#text(" or similar quantities (and of various ")#mi("{L^p}")#text(" type norms on such quantities, such as the ")#mi("{L^2}")#text(" bound ")#link(<tao-98df9a59f0641d0c4409>)[#text("(4)")]#text("). Of course, we do not yet know what the strongest possible upper and lower bounds in ")#mi("{S(x,\\alpha)}")#text(" are yet (otherwise we would already have made progress on major conjectures such as the Riemann hypothesis); but we can make plausible heuristic conjectures on such bounds. And this is enough to make the following heuristic conclusions:")

#list(
[#text("(i) For “binary” problems such as computing ")#link(<tao-286b2d656b7f6fbd85a2>)[#text("(5)")]#text(", ")#link(<tao-56db8ad52622b26d8b1d>)[#text("(6)")]#text(", the contribution of the minor arcs potentially dominates that of the major arcs (if all one is given about the minor arc sums is magnitude information), in contrast to “ternary” problems such as computing ")#link(<tao-d2fd404cbf285947c80b>)[#text("(2)")]#text(", in which it is the major arc contribution which is absolutely dominant.")],
[#text("(ii) Upper and lower bounds on the magnitude of ")#mi("{S(x,\\alpha)}")#text(" are not sufficient, by themselves, to obtain non-trivial bounds on ")#link(<tao-286b2d656b7f6fbd85a2>)[#text("(5)")]#text(", ")#link(<tao-56db8ad52622b26d8b1d>)[#text("(6)")]#text(" unless these bounds are ")#emph[#text("extremely")]#text(" tight (within a relative error of ")#mi("{O(1/\\log x)}")#text(" or better); but")],
[#text("(iii) obtaining such tight bounds is a problem of comparable difficulty to the original binary problems.")]
)

#text("I will provide some justification for these conclusions below the fold; they are reasonably well known “folklore” to many researchers in the field, but it seems that they are rarely made explicit in the literature (in part because these arguments are, by their nature, heuristic instead of rigorous) and I have been asked about them from time to time, so I decided to try to write them down here.")

#text("In view of the above conclusions, it seems that the best one can hope to do by using the circle method for the twin prime or even Goldbach problems is to reformulate such problems into a statement of roughly comparable difficulty to the original problem, even if one assumes powerful conjectures such as the Generalised Riemann Hypothesis (which lets one make very precise control on major arc exponential sums, but not on minor arc ones). These are not rigorous conclusions – after all, we have already seen that one can always artifically insert the circle method into any viable approach on these problems – but they do strongly suggest that one needs a method other than the circle method in order to fully solve either of these two problems. I do not know what such a method would be, though I can give some heuristic objections to some of the other popular methods used in additive number theory (such as sieve methods, or more recently the use of inverse theorems); this will be done at the end of this post.")

#metadata(none) <tao-9a7a6912db1e5e514034>

#heading(level: 1)[#strong[#text(" — 1. Minor arc dominance — ")]]

#text("Let us first explain why minor arc contributions to ")#link(<tao-286b2d656b7f6fbd85a2>)[#text("(5)")]#text(" or ")#link(<tao-56db8ad52622b26d8b1d>)[#text("(6)")]#text(" are expected to dominate. For sake of discussion let us just work with the twin prime integral ")#link(<tao-56db8ad52622b26d8b1d>)[#text("(6)")]#text(", as the situation with the even Goldbach integral ")#link(<tao-286b2d656b7f6fbd85a2>)[#text("(5)")]#text(" is similar.")

#text("First, let us get a crude heuristic prediction as to the size of the quantity ")#mi("{\\tilde f_2(x)}")#text(", which is the number of twin primes that are both less than ")#mi("{x}")#text(". Note that from the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(", an integer ")#mi("{n}")#text(" chosen uniformly at random between ")#mi("{1}")#text(" and ")#mi("{x}")#text(" has a probability about ")#mi("{1/\\log x}")#text(" of being prime, and similarly ")#mi("{n+2}")#text(" has a probability about ")#mi("{1/\\log x}")#text(" of being prime. Making the heuristic (but very nonrigorous) hypothesis that these two events are approximately independent, we thus expect a random number ")#mi("{n}")#text(" between ")#mi("{1}")#text(" and ")#mi("{x}")#text(" to have a probability about ")#mi("{1/\\log^2 x}")#text(" of being a twin prime, leading to the prediction ")#metadata(none) <tao-4b7832830e252177080f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\tilde f_2(x) \\sim \\frac{x}{\\log^2 x}.")]]

#text("As it turns out, this prediction is almost certainly inaccurate, due to “local” correlations between the primality of ")#mi("{n}")#text(" and primality of ")#mi("{n+2}")#text(" caused by residue classes with respect to small moduli (and in particular due to the parity of ")#mi("{n}")#text(", which clearly has an extremely large influence on whether ")#mi("{n}")#text(" and ")#mi("{n+2}")#text(" will be prime). However, the procedure for correcting for these local correlations is well known, and only ends up modifying the prediction ")#link(<tao-4b7832830e252177080f>)[#text("(7)")]#text(" by a multiplicative constant ")#mi("{\\Pi_2 = 1.3203\\ldots}")#text(" known as the ")#link("http://primes.utm.edu/glossary/xpage/TwinPrimeConstant.html")[#text("twin prime constant")]#text("; see for instance ")#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/")[#text("this previous blog post")]#text(" for more discussion. Our analysis here is focused on orders of growth in ")#mi("{x}")#text(" rather than on multiplicative constants, and so we will ignore the effect of the twin prime constant in this discussion.")

#text("Now let us predict the heuristic contribution of the major and minor arcs to ")#link(<tao-286b2d656b7f6fbd85a2>)[#text("(5)")]#text(". We begin with the primary major arc when ")#mi("{\\alpha}")#text(" is close to zero. As already noted, the prime number theorem gives")

#align(center)[#tao-fit-display[#mitex("S(x,0) = \\sum_{p \\leq x} 1 \\sim \\frac{x}{\\log x}.")]]

#text("From the uncertainty principle, we then expect")

#align(center)[#tao-fit-display[#tao-math("\\left|S(x,\\alpha)\\right| = \\left|\\sum_{p \\leq x} e(\\alpha p)\\right| \\sim \\frac{x}{\\log x}", block: true)]]

#text("when ")#mi("{\\alpha = O(1/x)}")#text(", because the phase ")#mi("{e(\\alpha p)}")#text(" does not go any significant oscillation in this case as ")#mi("{p}")#text(" ranges over the primes from ")#mi("{1}")#text(" to ")#mi("{x}")#text(". On the other hand, as ")#tao-math("{\\left|\\alpha\\right|}", block: false)#text(" begins to exceed ")#mi("{1/x}")#text(", we expect the exponential sum to start decaying, because the prime number theorem suggests the heuristic")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} e(\\alpha p) \\approx \\frac{1}{\\log x} \\sum_{n \\leq x} e(\\alpha n)")]]

#text("for ")#tao-math("{\\left|\\alpha\\right|}", block: false)#text(" slightly larger than ")#mi("{1/x}")#text(", and the latter sum does decay as ")#tao-math("{\\left|\\alpha\\right|}", block: false)#text(" begins to exceed ")#mi("{1/x}")#text(". (Admittedly, the decay is rather slow, of the order of ")#tao-math("{\\frac{1}{x\\left|\\alpha\\right|}}", block: false)#text(", but one can speed it up by using smooth cutoffs in the exponential sum, and in any event the decay is already sufficient for analysing ")#mi("{L^2}")#text(" type expressions such as ")#link(<tao-286b2d656b7f6fbd85a2>)[#text("(5)")]#text(".) In view of this, we expect the contribution to ")#link(<tao-286b2d656b7f6fbd85a2>)[#text("(5)")]#text(" of the major arc when ")#mi("{\\alpha}")#text(" is close to ")#mi("{0}")#text(" to be roughly")

#align(center)[#tao-fit-display[#mitex("(\\frac{x}{\\log x})^2 \\times O(\\frac{1}{x}) = O(\\frac{x}{\\log^2 x})")]]

#text("which, encouragingly, agrees with the heuristic prediction ")#link(<tao-4b7832830e252177080f>)[#text("(7)")]#text(" (and indeed, if one unpacks all the Fourier analysis, one sees that these two predictions are ultimately coming from the same source). Furthermore, it is not difficult to make these sorts of heuristics rigorous using summation by parts and some version of the prime number theorem with an explicit error term; but this will not be our concern here.")

#text("Next, we look at the major arcs when ")#mi("{\\alpha}")#text(" is close to ")#mi("{a/q}")#text(" for some fixed (and fairly small) ")#mi("{q}")#text(", and when ")#mi("{a}")#text(" is coprime to ")#mi("{q}")#text(". We begin with the study of")

#align(center)[#tao-fit-display[#mitex("S(x,a/q) = \\sum_{p \\leq x} e(ap/q).")]]

#text("The prime number theorem in arithmetic progressions suggests that the ")#mi("{\\sim x/\\log x}")#text(" primes are equally distributed in the ")#mi("{\\phi(q)}")#text(" residue classes ")#mi("{b \\mod q}")#text(" coprime to ")#mi("{q}")#text(", which heuristically suggests that")

#align(center)[#tao-fit-display[#mitex("S(x,a/q) \\approx \\frac{x}{\\log x} \\frac{1}{\\phi(q)} \\sum_{b \\mod q: (b,q)=1} e(ab/q).")]]

#text("A standard computation shows that ")#metadata(none) <tao-b737ca7ee563ae80e457>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\sum_{b \\mod q: (b,q)=1} e(ab/q) = - \\mu(q)")]]

#text("(this can be seen first by working in the case when ")#mi("{q}")#text(" is a prime or a power of a prime, and then handling the general case via the ")#link("http://en.wikipedia.org/wiki/Chinese_remainder_theorem")[#text("Chinese remainder theorem")]#text("). This leads to the heuristic")

#align(center)[#tao-fit-display[#mitex("S(x,a/q) \\approx \\frac{\\mu(q)}{\\phi(q)} \\frac{x}{\\log x}")]]

#text("and similarly from the uncertainty principle one expects ")#metadata(none) <tao-a12e7a818ad496a6ae7c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("S(x,\\alpha) \\approx \\frac{\\mu(q)}{\\phi(q)} \\frac{x}{\\log x}")]]

#text("when ")#tao-math("{\\left|\\alpha-a/q\\right| \\ll 1/x}", block: false)#text(", with some decay as ")#tao-math("{\\left|\\alpha-a/q\\right|}", block: false)#text(" begins to exceed ")#mi("{1/x}")#text(". On the other hand, the set of all ")#mi("{\\alpha}")#text(" in these arcs has measure ")#mi("{O( \\phi(q)/x )}")#text(". Thus, if one were to ignore the effects of the ")#mi("{e(-2\\alpha)}")#text(" term in ")#link(<tao-286b2d656b7f6fbd85a2>)[#text("(5)")]#text(", and just estimate things crudely by the triangle inequality, one would heuristically end up with a net bound of")

#align(center)[#tao-fit-display[#tao-math("O( \\frac{\\phi(q)}{x} ) \\times O( \\left|\\frac{\\mu(q)}{\\phi(q)} \\frac{x}{\\log x}\\right| )^2 = O( \\frac{\\mu^2(q)}{\\phi(q)} \\frac{x}{\\log^2 x} )", block: true)]]

#text("for any given ")#mi("{q}")#text(". This does decay in ")#mi("{q}")#text(", but too slowly to ensure absolute convergence; given that a positive proportion of integers are squarefree, and that ")#mi("{\\phi(q)}")#text(" is more or less comparable to ")#mi("{q}")#text(" for typical ")#mi("{q}")#text(", we expect the logarithmic divergence")

#align(center)[#tao-fit-display[#mitex("\\sum_{q \\leq Q} \\frac{\\mu^2(q)}{\\phi(q)} \\approx \\sum_{q \\leq Q} \\frac{1}{q} \\approx \\log Q")]]

#text("as ")#mi("{Q \\rightarrow \\infty}")#text(" (and indeed one can make this heuristic rigorous by standard methods for estimating sums of multiplicative functions, e.g. via ")#link("http://en.wikipedia.org/wiki/Dirichlet_series")[#text("Dirichlet series")]#text(" methods). This should be compared with the analogous situation for ")#link(<tao-d2fd404cbf285947c80b>)[#text("(2)")]#text(", in which the major arc contribution of a given denominator ")#mi("{q}")#text(", when estimated in absolute value by the same method, would be of size")

#align(center)[#tao-fit-display[#tao-math("O( \\frac{\\phi(q)}{x} ) \\times O( \\left|\\frac{\\mu(q)}{\\phi(q)} \\frac{x}{\\log x}\\right| )^3 = \\frac{\\mu^2(q)}{\\phi^2(q)} \\frac{x^2}{\\log^3 x}", block: true)]]

#text("and ")#mi("{\\sum_{q=1}^\\infty \\frac{\\mu^2(q)}{\\phi^2(q)}}")#text(" is convergent.")

#text("Now, the apparent divergence of the major arc contributions is not actually a problem, because we have an asymptotic for ")#mi("{S(x,\\alpha)}")#text(" rather than merely an upper bound, and can therefore exploit the cancellation coming from the ")#mi("{e(-2\\alpha)}")#text(" term. Indeed, if we apply the approximation ")#link(<tao-a12e7a818ad496a6ae7c>)[#text("(9)")]#text(" without discarding the ")#mi("{e(-2\\alpha)}")#text(" phase, we see (heuristically, at least) that the contribution of the major arcs at denominator ")#mi("{q}")#text(" are more like")

#align(center)[#tao-fit-display[#tao-math("O( \\frac{\\phi(q)}{x} ) \\times O( \\left|\\frac{\\mu(q)}{\\phi(q)} \\frac{x}{\\log x}\\right| )^2 \\times \\frac{1}{\\phi(q)} \\sum_{(a,q)=1} e(-2a/q).", block: true)]]

#text("Using ")#link(<tao-b737ca7ee563ae80e457>)[#text("(8)")]#text(", we thus expect the total contribution at denominator ")#mi("{q}")#text(" to actually be of order ")#mi("{O( \\frac{\\mu^2(q)}{\\phi(q)^2} \\frac{x}{\\log^2 x})}")#text(", gaining an additional factor of ")#mi("{1/\\phi(q)}")#text(" over the preceding bound, leading to a summable contribution of the major arcs. (And if one pursues this calculation more carefully, one even arrives at the more refined prediction of ")#mi("{\\Pi_2 \\frac{x}{\\log^2 x}}")#text(" for the net major arc contribution.)")

#text("So far, so good. But difficulties begin to arise when one turns attention to the minor arcs, and particularly when ")#mi("{\\alpha}")#text(" is only close to rationals ")#mi("{a/q}")#text(" with very large denominator ")#mi("{q}")#text(", such as ")#mi("{q \\sim \\sqrt{x}}")#text(", which is the typical scenario if one defines “close to” as “within ")#mi("{O(1/x)}")#text(" of”. Here, we do not expect to have the asymptotic ")#link(<tao-a12e7a818ad496a6ae7c>)[#text("(9)")]#text(", because the effect of random fluctuations in the primes on ")#mi("{S(x,\\alpha)}")#text(", which as discussed previously is expected to be of size ")#mi("{O(\\sqrt{\\frac{x}{\\log x}})}")#text(" and can thus dominate the main term in ")#link(<tao-a12e7a818ad496a6ae7c>)[#text("(9)")]#text(" if ")#mi("{q}")#text(" is close to ")#mi("{\\sqrt{x}}")#text(". (In any case, even on the Generalised Riemann Hypothesis, we are well short of being able to maintain the asymptotic ")#link(<tao-a12e7a818ad496a6ae7c>)[#text("(9)")]#text(" for anywhere near that large a value of ")#mi("{q}")#text(", instead only reaching levels such as ")#mi("{q \\sim x^{1/3}}")#text(" or so before the error terms begin to dominate the main term.) As such, we can no longer easily exploit the cancellation of the ")#mi("{e(-2\\alpha)}")#text(" phase, and are more or less forced to estimate the minor arc contribution by taking absolute values:")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{\\Omega_{minor}} \\right|S(x,\\alpha)\\left|^2 e(-2\\alpha)\\ d\\alpha\\right| \\leq \\int_{\\Omega_{minor}} \\left|S(x,\\alpha)\\right|^2\\ d\\alpha.", block: true)]]

#text("But now the problem is that, in view of heuristics such as ")#link(<tao-7b496cbed62b73147bc2>)[#text("(3)")]#text(" or ")#link(<tao-98df9a59f0641d0c4409>)[#text("(4)")]#text(", and keeping in mind that the set ")#mi("{\\Omega_{minor}}")#text(" of minor arcs have measure close to ")#mi("{1}")#text(", this absolute value integral is expected to be of the order of ")#mi("{\\frac{x}{\\log x}}")#text(", which exceeds the major arc contribution of ")#mi("{O(\\frac{x}{\\log^2 x})}")#text(" by a logarithmic factor. (One can also use ")#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/")[#text("Montgomery’s uncertainty principle")]#text(" to show that the major arc contributions are a fraction of the minor arc ones, for any reasonable choice of division between major and minor arc.) Thus we see that the minor arc contribution overwhelms the major arc one if we cannot control the oscillation of ")#tao-math("{\\left|S(x,\\alpha)\\right|^2}", block: false)#text(" on the minor arcs. (It is instructive to see why the situation is reversed with the ternary sum ")#link(<tao-d2fd404cbf285947c80b>)[#text("(2)")]#text(", in which case the major arc terms dominate.)")

#heading(level: 1)[#strong[#text(" — 2. Loose bounds do not suffice — ")]]

#text("A slightly different perspective on the difficulties in applying the circle method to binary problems can be seen by noting how “fragile” the truth of such problems is with respect to “edits” made to the set of primes. To describe what I mean by this, let us focus now on the even Goldbach problem of representing a large but fixed number ")#mi("{x}")#text(" as the sum of two primes ")#mi("{p_1,p_2}")#text(" (but the same discussion also applies, with minor modifications, to the twin prime problem). As discussed previously, we expect about ")#mi("{O(x / \\log^2 x)}")#text(" sums of this form (actually one expects slightly more sums than this when ")#mi("{x}")#text(" has a lot of prime factors, but never mind this for now). One can even establish this upper bound rigorously by sieve theory if one wishes, but this is not particularly relevant as will only be concerned with a heuristic discussion here.")

#text("The point is that the number of sums here is still significantly smaller than the total number of primes less than ")#mi("{x}")#text(", which is approximately ")#mi("{x/\\log x}")#text(" by the prime number theorem. To exploit this discrepancy, let us define the set of ")#emph[#text("redacted primes")]#text(" to be those primes less than ")#mi("{x}")#text(" which do ")#emph[#text("not")]#text(" arise in one of the representations of ")#mi("{x}")#text(" as the sum of two primes; in other words, a redacted prime is a prime ")#mi("{p}")#text(" less than ")#mi("{x}")#text(" such that ")#mi("{x-p}")#text(" is not a prime. Thus, from a relative viewpoint, the redacted primes comprise almost all of the actual primes less than ")#mi("{x}")#text("; only a proportion of ")#mi("{O(1/\\log x)}")#text(" or so of the primes less than ")#mi("{x}")#text(" are not redacted. As such, the redacted primes look very similar to the actual primes less than ")#mi("{x}")#text(", but with one key difference: there is no way to express ")#mi("{x}")#text(" as the sum of two redacted primes. So the even Goldbach property has been destroyed by passing from the primes to the redacted primes.")

#text("On the other hand, given that the redacted primes have density about ")#mi("{1-O(\\frac{1}{\\log x})}")#text(" in the set of all primes ")#mi("{p}")#text(" less than ")#mi("{x}")#text(", and are expected to be distributed more or less uniformly within that set (other than some local irregularities coming from small residue classes which turn out not to be terribly relevant), we thus expect heuristically that the redacted exponential sum")

#align(center)[#tao-fit-display[#mitex("S^{\\prime}(x,\\alpha) := \\sum^{\\prime}_{p \\leq x} e(\\alpha p)")]]

#text("where the sum is restricted to redacted primes, is typically close to the unredacted exponential sum ")#mi("{S(x,\\alpha)}")#text(" in the sense that ")#metadata(none) <tao-2da16e49ae3b727a81c8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("S^{\\prime}(x,\\alpha) = (1 - O(\\frac{1}{\\log x})) S(x,\\alpha).")]]

#text("(This is not quite a good heuristic when ")#mi("{S(x,\\alpha)}")#text(" happens to vanish, but writing a more accurate heuristic here would be messier and not add much illumination to the discussion.)")

#text("This has the following consequence. Suppose one is planning to prove the even Goldbach conjecture by using some approximations on ")#mi("{S(x,\\alpha)}")#text(", say of the form")

#align(center)[#tao-fit-display[#mitex("S(x,\\alpha) = f(x,\\alpha) + O( g(x,\\alpha) )")]]

#text("for some explicit quantities ")#mi("{f, g}")#text(". (One can (and should) also consider integral bounds rather than pointwise bounds, but let us discuss pointwise bounds here for sake of illustration.) If these bounds are too “loose” in the sense that ")#mi("{g(x,\\alpha) \\gg f(x,\\alpha) / \\log x}")#text(", then the preceding heuristics suggest that the redacted exponential sums are going to obey a similar estimate:")

#align(center)[#tao-fit-display[#mitex("S^{\\prime}(x,\\alpha) = f(x,\\alpha) + O( g(x,\\alpha) ).")]]

#text("However, as mentioned previously, the redacted version of ")#link(<tao-286b2d656b7f6fbd85a2>)[#text("(5)")]#text(" vanishes. Thus, one cannot hope to prove the even Goldbach conjecture purely by loose bounds, as these bounds are incapable of distinguishing between the genuine primes and the redacted primes. In particular, upper bounds of the type one expects to have available for the minor arc exponential sums are far too loose to be useful in this regard (as in such cases ")#mi("{f}")#text(" is simply zero).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One might object that the type of techniques used to prove minor arc exponential sum estimates (e.g. the Vinogradov-Vaughan method based on bilinear sums) rely on the special multiplicative structure of the primes, which is absent for the redacted primes. This is true, but is irrelevant for the purposes of determining the feasibility of the circle method, because the circle method only cares about possessing good bounds on ")#mi("{S(x,\\alpha)}")#text(", and not about where those bounds came from; it cannot distinguish a bound that came from a rigorous argument such as the Vinogradov-Vaughan method, from a bound that came from a heuristic argument such as ")#link(<tao-2da16e49ae3b727a81c8>)[#text("(10)")]#text(". If one wants to truly use multiplicative structure to distinguish the primes from the redacted primes, one has to use that structure directly to establish the desired Goldbach or twin prime problem, bypassing the circle method, which only sees the consequences of that structure on exponential sum estimates, rather than seeing the structure itself.")
]

#text("Admittedly, for major arc values of ")#mi("{\\alpha}")#text(", a sufficiently strong version of the prime number in arithmetic progressions will give tight bounds (in the sense that the error term improves upon the main term by at least a logarithmic factor). However, as pointed out in the preceding section, the major arcs are not the dominant contribution to ")#link(<tao-286b2d656b7f6fbd85a2>)[#text("(5)")]#text(". Furthermore, if one normalises the redacted exponential sum by dividing out by the relative density of the redacted primes in the actual primes, one expects the major arc value of ")#mi("{S^{\\prime}(x,\\alpha)}")#text(" to become much closer to that of ")#mi("{S(x,\\alpha)}")#text(", so that the two expressions become indistinguishable even to quite tight bounds.")

#text("It is also instructive to see how this situation is different in the ternary case, when one is trying to find triples ")#mi("{p_1,p_2,p_3}")#text(" of primes that sum to a given odd prime ")#mi("{x}")#text(". There, it is no longer possible to easily redact the primes to remove all such triples, because one expects the number of such triples to be on the order of ")#mi("{x^2/\\log^3 x}")#text(", compared with the total number ")#mi("{x/\\log x}")#text(" of primes. Indeed, it is known that Vinogradov’s theorem continues to hold even if one deletes a moderately large positive fraction of the primes (this is ")#link("http://www.ams.org/mathscinet-getitem?mr=2661445")[#text("a result of Li and Pan")]#text(", adapting ")#link("http://www.ams.org/mathscinet-getitem?mr=2180408")[#text("an earlier argument of Green")]#text(").")

#heading(level: 1)[#strong[#text(" — 3. Tight bounds are morally equivalent to binary problems — ")]]

#text("In the preceding two sections, we argued that the minor arc estimates are the most important, and that the bounds here must be quite tight in order to have any hope of solving the conjecture this way. On the other hand, if the bounds are tight enough, then indeed one has enough control to start proving some binary conjectures. As far as I am aware, the first results in the literature formalising this observation are due ")#link("http://www.ams.org/mathscinet-getitem?mr=566878")[#text("to Srinivasan")]#text(" (in the context of the even Goldbach problem). For the twin prime problem, a more precise formalisation was worked out recently ")#link("http://www.ams.org/mathscinet-getitem?mr=2584938")[#text("by Maier and Sankaranarayanan")]#text(". Roughly speaking, these latter authors show that if one can obtain a tight ")#mi("{L^2}")#text(" asymptotic for ")#mi("{S(x,\\alpha)}")#text(" on minor arcs, roughly of the form ")#metadata(none) <tao-3fe1406a8254afd471de>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\int_{I \\cap \\Omega_{minor}} \\left|S(x,\\alpha)\\right|^2\\ d\\alpha = (1 + O(\\log^{-A} x)) C |I| \\frac{x}{\\log x}", block: true)]]

#text("for some absolute constant ")#mi("{C,A}")#text(" and all intervals ")#mi("{I}")#text(" of size ")#tao-math("{\\left|I\\right| \\gg \\log^{-A} x}", block: false)#text(", then the twin prime conjecture holds, basically because one can then control the minor arc contribution to ")#link(<tao-56db8ad52622b26d8b1d>)[#text("(6)")]#text(" by an integration by parts. (Actually the constant ")#mi("{C}")#text(" is necessarily equal to ")#mi("{1}")#text(" in this conjecture, basically because of ")#link(<tao-98df9a59f0641d0c4409>)[#text("(4)")]#text(" and the fact that the major arcs only occupy a small fraction of the total ")#mi("{L^2}")#text(" norm.) Furthermore, the standard random fluctuation heuristics suggest that the conjecture ")#link(<tao-3fe1406a8254afd471de>)[#text("(11)")]#text(" is likely to be true (and Maier and Sankaranarayanan verify the conjecture when the primes are replaced with a certain set of almost primes). In fact, the bound ")#link(<tao-3fe1406a8254afd471de>)[#text("(11)")]#text(" is strong enough to similarly count the number of pairs ")#mi("{(p,p+h)}")#text(" for any fixed ")#mi("{h}")#text(", with a very good error term (smaller than the main term by several powers of ")#mi("{\\log x}")#text("); in other words, this conjecture would imply the binary case of the ")#link("http://mathworld.wolfram.com/k-TupleConjecture.html")[#text("Hardy-Littlewood prime tuples conjecture")]#text(" with the expected asymptotics.")

#text("On the other hand, it is not difficult to reverse this procedure and deduce the conjecture ")#link(<tao-3fe1406a8254afd471de>)[#text("(11)")]#text(" from the prime tuples conjecture (with the conjectured asymptotics and a sufficiently strong error term). This is because ")#tao-math("{\\left|S(x,\\alpha)\\right|^2}", block: false)#text(" is the Fourier transform of the prime tuples counting function ")#tao-math("{r(h) := \\left|\\{ p,p+h \\leq x: p,p+h \\text{ prime}\\}\\right|}", block: false)#text(":")

#align(center)[#tao-fit-display[#tao-math("\\left|S(x,\\alpha)\\right|^2 = \\sum_h r(h) e(-h\\alpha).", block: true)]]

#text("As such, strong bounds on ")#mi("{r(h)}")#text(" would be expected to yield strong bounds on ")#tao-math("{\\left|S(x,\\alpha)\\right|^2}", block: false)#text(", and in particular the expected bounds on the prime tuples conjecture leads to the expected bound ")#link(<tao-3fe1406a8254afd471de>)[#text("(11)")]#text(". So we see that tight bounds on minor arc exponential sums are basically just a Fourier reformulation of the underlying binary problems being considered, and any argument that established such bounds could likely be converted into a bound on the binary problem directly, without direct use of the circle method. As such, I believe that one has to look outside of the circle method in order to make progress on these binary problems.")

#heading(level: 1)[#strong[#text(" — 4. Other methods — ")]]

#text("Needless to say, I do not actually have a viable strategy in hand for solving these binary problems, but I can comment briefly on some of the other existing methods in additive number theory, which also unfortunately have well-known limitations in this regard.")

#text("The first obvious candidate for solving these problems is ")#link("http://en.wikipedia.org/wiki/Sieve_theory")[#text("sieve theory")]#text(", which was in fact invented specifically with problems such as the twin prime conjecture in mind. However, there is a major obstruction to using sieve theory to obtain non-trivial lower bounds (as opposed to upper bounds, which are much easier) on prime patterns, namely the ")#emph[#text("parity problem")]#text(". I discuss this problem in ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("this previous blog post")]#text(", and do not have much more to add here to what I already wrote in that post.")

#text("Another potential approach, following the methods of additive combinatorics (and particularly the sub-branch of additive combinatorics focused on arithmetic progressions), is to try to develop some sort of inverse theorem, in analogy with the Gowers-type inverse theorems that relate the lack of arithmetic progressions with some sort of correlation with a structured function (such as a Fourier character). Unfortunately, when it comes to binary patterns such as twins or pairs of numbers summing to a fixed sum ")#mi("{x}")#text(", one cannot have any simple class of structured functions that capture the absence of these patterns. We already saw a glimpse of this with the redacted primes in the even Goldbach problem, which are likely to have almost identical correlations with structured functions (such as characters) as the unredacted primes. One can also construct quite pseudorandom-looking sets that lack a binary pattern, for instance by randomly selecting one member of each pair ")#mi("{a<b}")#text(" that sums to ")#mi("{x}")#text(", and standard probabilistic computations then show that such sets will typically have low correlation with any set of structured functions of low entropy, which is the only type of functions for which we expect randomness heuristics (such as the Mobius randomness conjecture, discussed for instance in ")#link("http://publications.ias.edu/sites/default/files/Mahler%20Colloquium%20Lecture%204%20-Mobius%20randomness%20and%20dynamics.pdf")[#text("this lecture of Sarnak")]#text(") to hold.")

#text("In a similar vein, one can try to hope for some sort of transference principle argument, taking advantage of the fact that the primes lie inside the almost primes in order to model the primes by a much denser set of natural numbers. The lack of a good inverse theorem is going to be a major obstacle to this strategy; but actually, even if that problem was somehow evaded, the parity problem serves as a separate obstruction. Indeed, the parity problem suggests that the maximum density of the primes inside the almost primes that one can realistically hope to achieve (while still getting good control on the almost primes) is ")#mi("{1/2}")#text(". As such, the densest model one could hope for in the natural numbers would also have density ")#mi("{1/2}")#text(". But this is just the critical density for avoiding patterns such as twins or Goldbach-type pairs; for instance, the natural numbers which equal ")#mi("{0}")#text(" or ")#mi("{1}")#text(" mod ")#mi("{4}")#text(" have density ")#mi("{1/2}")#text(" but no twins. So even just a small loss of density in the model could potentially kill off all the twins, and in the absence of an inverse theorem there would be no computable statistic to prevent this from happening. (On the other hand, this obstruction does not prevent one from finding pairs of primes which differ by at most ")#mi("{4}")#text(", say; this is consistent with the ")#link("http://www.ams.org/mathscinet-getitem?mr=2552109")[#text("Goldston-Yildirim-Pintz results")]#text(" on small prime gaps, which does not exactly use a dense model, but works relative to the almost primes, treating the primes “as if” they were dense in some sense.)")

#text("One can view the “enemy” in these binary problems as a “conspiracy” amongst the primes to behave in a certain pathological way – avoiding twins, for instance, or refusing to sum together to some exceptional integer ")#mi("{x}")#text(". Conspiracies are typically very difficult to eliminate rigorously, about the only thing which is strong enough to rule out a conspiracy is a conflicting conspiracy (see ")#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/")[#text("my previous blog post on this topic")]#text("). A good example of this is ")#link("http://www.ams.org/mathscinet-getitem?mr=703977")[#text("Heath-Brown’s result")]#text(" that the existence of a Siegel zero (which is a conspiracy amongst primes that, among other things, would completely ruin the Generalised Riemann Hypothesis) implies the truth of the twin prime conjecture (basically by upending all the previous heuristics, and causing the major arc sums to dominate the minor arcs instead of vice versa). But since we do not expect ")#emph[#text("any")]#text(" conspiracies to occur amongst the primes, one cannot directly use these sorts of “dueling conspiracies” methods to unilaterally rule out any given conspiracy.")

#text("However, there is perhaps the outside chance that a binary conspiracy (such as a conspiracy between primes to stop having twins) could somehow be used to conspire against itself (in the spirit of “self-defeating object” arguments, ")#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/")[#text("discussed previously")]#text(" ")#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/")[#text("several times")]#text(" ")#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/")[#text("on this blog")]#text("). This is actually a fairly common technique in analytic number theory (though not usually described in such terms); for instance, ")#link("http://www.encyclopediaofmath.org/index.php/Dispersion_method")[#text("Linnik’s dispersion method")]#text(" can be viewed as a way to eliminate a potential conspiracy by transforming it to compete against itself; bilinear sum methods, such as those used to control the minor arc sum ")#mi("{S(x,\\alpha)}")#text(", can also be viewed in this way. However, these methods generally require some sort of underlying group action (such as multiplicative dilation) in order to transform the initial conspiracy into a competing conspiracy, and no obvious such action is present for these binary problems.")

#text("Finally, one can hope to solve the problem by producing explicit sequences of twin primes, or explicit primes that add up to a given integer ")#mi("{x}")#text(", which is perhaps the most obvious method to try for someone who has seen this sort of problem for the first time. However, it is notoriously difficult to come up with any explicit and tractable formula for producing primes; this type of problem (with “tractable” replaced by “deterministically computable in a reasonable time”) was considered in the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Finding_primes")[#text("Polymath4 project")]#text(", with only modest advances over the obvious brute-force algorithms located. On the other hand, the situation is significantly more promising if one works in the ")#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/")[#text("function field model")]#text(" in which the integers are replaced by the ring ")#mi("{F_q[t]}")#text(" of polynomials of one variable over a finite field, and the notion of prime is replaced by that of an monic irreducible polynomial. The main reason for this is in addition to having the arithmetic operations of addition and multiplication, polynomials also have the operation of ")#emph[#text("composition")]#text(" available to them. Furthermore, there is a relationship between the irreducibility of a polynomial ")#mi("{f(t)}")#text(" and that of a composition ")#mi("{f(g(t))}")#text("; indeed, except in degenerate cases, reducibility of the former implies reducibility of the latter, and conversely irreducibility of the former often ensures irreducibility of the latter in a manner that can be controlled (particularly after averaging in ")#mi("{g}")#text("). By using this method (known as the ")#emph[#text("substitution method")]#text(") one can prove some versions of the twin prime conjecture; for instance, it was shown ")#link("http://www.ams.org/mathscinet-getitem?mr=2437981")[#text("by Pollack")]#text(" (building upon a previous result of this type by Hall) that for if ")#mi("{q}")#text(" is an odd prime and ")#mi("{h \\in F_q}")#text(", then there exist infinitely many monic irreducible ")#mi("{f \\in F_q[t]}")#text(" such that ")#mi("{f+h}")#text(" is also irreducible. It is perhaps conceivable that other binary problems, such as the even Goldbach problem, can also be tackled over function fields by this method. However, this argument appears specific to the function field setting, as the substitution operation has no obvious counterpart in the rational integers.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (44)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e71d4acd626d34c6a9292f517688a52101e42cd7b113de50210a284d1f7ac0b-2478101b2a5251690cfdeb13ddaeb49a7cf5c0aff0ca22522493fb9fafaa6056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of foo")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-143806")[#strong[#text("foo")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2012")])]

#text("Wow…Thank you so much for this great post!!!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a3272bd1b160121fa2aebe3a98c6abc10327c23b209c2767f52b3eb8d9cc427-661816d5b0ecd158ba320c6763edc5581b6bd5fa514cdaaded3e5c7cc7aa4740.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aumeunier")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-513464")[#strong[#text("aumeunier")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2019")])]

#text("hello i think i should not be very loing")

#text("To demonstrate this Goldbach conjecture, I propose to use a theorem that I will demonstrate.")#linebreak()#text(" All compound numbers, have at least one prime factor smaller than or equal to its square root")#linebreak()#text(" 3*11=33 3 < sqrt(33)")

#text("a primorel is equal to the product of all consecutive prime numbers")#linebreak()#text(" primorel=2*3*5*7*11*….*pn")#linebreak()#text(" From these elements, I will build or make a prime number and not test an number to see if it is prime.")#linebreak()#text(" 2*3*5*7*…pn-a=b")

#text("if a and first with 2*3*5*5*7*…pn b not have one prime factor smaller than or equal to its square root so b is prime")

#text("2*3*5*7*11-2279=31 sqrt(31)=5.56 <11 31 is prime")

#text("From this demonstration, I will use this construction in Goldbach’s conjecture.")

#text("2*3*5*7*11-2279=31 ,2*3*5*7*11-2293=17")#linebreak()#text(" 31+17=48=2*(2*3*5*7*11)-(2279+2293) =48")#linebreak()#text(" 2*(2*3*5*7*11)- 4572 =48")

#text("we see that there is a conservation of the property because of the properties of the addition")

#text("sqrt(48) <11")

#text("So since I can write all the whole pair in this form, all the pairs are the sum of 2 prime number.")

#text("because")#linebreak()#text(" 2*(2*3*5*7*11*….pn) – a =b")

#text("a=a1+a2")

#text("2*3*5*7*11*….pn-a1 +2*3*5*7*11*….pn-a2")

#text("px + py =2n")

#text("cdl remy")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-144048")[#strong[#text("Waring’s Problem: Lecture 12 « Theorem of the week")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2012")]

#text("[…] you can find the relevant papers on his website. Terry Tao has just written an interesting blog post about the limitations of the circle method. Like this:LikeBe the first to like this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb462de27d1916faeb5629eb99d12d774ac8b36f1e3a37d3870f2ea4ca365c03-701c116888e455c639e2a8f17dd49317f0ee7737933c65b7673f2043a0e5973f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sumit Kumar Jha")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-144069")[#strong[#text("Sumit Kumar Jha")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2012")])]

#text("I think Vinogradov’s three prime theorem can be proved using Vaughn’s method of bilinear sums. In Remark 2, do you mean that it does not anyhow give a method to solve Goldbach or twin prime problem?")#linebreak()#text(" I had read about Vaughn’s method in the notes about three prime problem given by T. Gowers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-144177")[#strong[#text("Jon")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2012")])]

#text("It appears that Harald Helfgott is ")#link("http://arxiv.org/abs/1205.5252")[#text("announcing major progress")]#text(" on the ternary Golbach conjecture!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ghaith")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-144196")[#strong[#text("Ghaith")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2012")])]

#text("Thanks for a great post! I think the redacted primes")#linebreak()#text(" heuristic nails it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82e494cbb93604545c9a4905674939e942fe943e6102f1c972d6f4672e2857bb-af836d930689c7a8bf7d6376575f8a0e200c0e826d217f3b19db103860d0df48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wdjoyner")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-144200")[#strong[#text("wdjoyner")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2012")])]

#text("Very interesting post. Are you missing a “big O” in the x/(log x)^2 displayed equation?")

#text("I’m wondering if you have a comment on a paper recently posted to the arxiv: ")#link("http://arxiv.org/abs/1205.5252")[#text("http://arxiv.org/abs/1205.5252")]#text(". It seems to be a major step forward in the 3 primes problem, but I am not an expert on this. Just curious what you thought.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-144379")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2012")])]

#text("Thanks for the correction!")

#text("Yes, Harald and I have been in communication about his most recent preprint, which (by quite a bit of effort) squeezes a bit more out of the Vaughan identity method to improve the minor arc bounds by almost an order of magnitude over those in my previous paper in the regime of main interest. The main difficulty now resides in the major arcs (though an additional order of magnitude gain in the minor arcs might still be possible, and would certainly be helpful in the rest of the analysis). It’s conceivable that with a massive amount of computer power thrown at numerical verification of GRH, one could simply brute-force the major arc computation to the point where one could establish the three-primes result (or at least the four-primes one) using existing methods, but that would be somewhat inelegant, and I would prefer to see some new tools developed instead (e.g. using ideas from additive combinatorics) to reduce the reliance on numerical computation if possible (and also because such tools may be useful for other problems as well).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-146729")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2012")])]

#text("Hi Terry,")

#text("I thought I’d make a couple of comments.")

#text("(a) There is not much numerical “squeezing” in my paper. Rather, there are several qualitative improvements; some of them give gains of powers of log, rather than constant gains. Of course, a gain of log (or of anything else) translates as a (large) constant gain in the most sensitive case, in which all parameters are bounded (by large constants).")

#text("(b) One of these gains of log is in fact specific to Vaughan’s identity,")#linebreak()#text(" in that it gets back one of the logs that one gives away whenever one uses that identity. Other ideas in my paper, however, work for any identity. Some go back to 2006, when I was not using Vaughan but Bombieri-Selberg.")

#text("(c) Some numerical work is inevitable, no matter how you proceed. For one thing, it is very awkward to work without an assumption such as $n\\geq 10^{20}$ or $n\\geq 10^{25}$, and, in order to be able to assume that, one needs to use existing numerical work that implies that the conjecture holds up to a certain constant.")

#text("At the same time, I agree that it would be nice to reduce the range of q’s")#linebreak()#text(" to be checked, if only because the current range, while realistic, would be somewhat expensive. My feeling is that there may be room for at least one more paper. At some point we will have to consider whether the time of mathematicians or that of computers is more valuable.")

#text("Note also that the numerical work involved here is not ad-hoc, and will")#linebreak()#text(" certainly be useful right away for other problems: a verification of GRH")#linebreak()#text(" up to a given height and up to conductor $2\\cdot 10^6$ (or $10^6$, or")#linebreak()#text(" $4\\cdot 10^6$) will become a standard reference.")

#text("The least one can say is that the problem is now mortally wounded, and")#linebreak()#text(" that the way it is finished off is now in part a matter of expediency and")#linebreak()#text(" in part a matter of taste.")

#text("Best,")#linebreak()#text(" Harald")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-144255")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2012")])]

#text("Dear Prof. Tao, this is such a clear post, that introduces the “big picture”")#linebreak()#text(" with just enough detail (for me anyway) ! Most likely I’ll print it.")#linebreak()#text(" David Bernier")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-144616")[#strong[#text("Whats What Womens Stack Hammer Ankle")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2012")]

#text("[…] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e9b540dfb6879fe02e0cac1944aac36de8651674308fc1f0dcd266d94947c65-97b0ec0fa15e7247beb19e878b83652badf8c34f88a9f85aa98ffecac01131f5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dylan")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-144819")[#strong[#text("Dylan")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2012")])]

#text("As an undergraduate student interested in studying number theory, your posts are an inspiration. It would be very exciting to see a proof of Goldbach as I make my way through graduate school! Keep at it!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a3272bd1b160121fa2aebe3a98c6abc10327c23b209c2767f52b3eb8d9cc427-661816d5b0ecd158ba320c6763edc5581b6bd5fa514cdaaded3e5c7cc7aa4740.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of remy")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-146003")[#strong[#text("remy")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2012")])]

#text("hello")#linebreak()#text(" 2 * 3 * 5 * 7 * 11-x = y")#linebreak()#text(" if and only if x and a prime and smaller then 13 ^ 2 y and a prime number")

#text("because x and a prime number so it did not factor in commom with")#linebreak()#text(" 2,3,5,7,11")

#text("Goldbach conjecture")

#text("3 * 7 + 5 * 7 = 92 = 2 * 2 * 23")#linebreak()#text(" x + y = constant")#linebreak()#text(" x -a+ y+a = constant")

#text("it is therefore necessary that a is prime to x and y")

#text("a = 2 * 13")

#text("3 * 5 +2 * 13 +7 * 11-2 * 13 = 2 ^ 2 * 23")#linebreak()#text(" 41 + 51 = 92")#linebreak()#text(" 41 + 3 * 17 = 92")

#text("or")#linebreak()#text(" a = 2 * 2")

#text("3 * 5 + a 7 * 11-a = 92")#linebreak()#text(" 19 + 73 = 92")

#text("it is necessary to adapt the progression of x and y for the decrease in the decomposition")#linebreak()#text(" can no longer be possible for x and y and it is always possible because there is always a space between number of factorisable")#linebreak()#text(" Example 3 * 5-3 * 7> 0")

#text("but I grieve not speak English")

#text("remy")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a3272bd1b160121fa2aebe3a98c6abc10327c23b209c2767f52b3eb8d9cc427-661816d5b0ecd158ba320c6763edc5581b6bd5fa514cdaaded3e5c7cc7aa4740.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of remy")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-146006")[#strong[#text("remy")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2012")])]

#text("oops y <13^ 2")

#text("2*3*5*7*11-2153")#linebreak()#text(" 157")#linebreak()#text(" 2*3*5*7*11-2143")#linebreak()#text(" 167")#linebreak()#text(" 2*3*5*7*11-2141")#linebreak()#text(" 169")#linebreak()#text(" 2*3*5*7*11-2137")#linebreak()#text(" 173")#linebreak()#text(" 2*3*5*7*11-2131")#linebreak()#text(" 179")#linebreak()#text(" 2*3*5*7*11-2129")#linebreak()#text(" 181")#linebreak()#text(" 2*3*5*7*11-2113")#linebreak()#text(" 197")#linebreak()#text(" 2*3*5*7*11-2111")#linebreak()#text(" 199")#linebreak()#text(" ….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27710fde30574de47c168f3120abea06ce3507b9649cf9890b4a3ed973bbb4ed-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohamed Alaa EL Behairy")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-146696")[#strong[#text("Mohamed Alaa EL Behairy")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2012")])]

#text("Prof Tao, how do you think the full odd or even Goldbach conjecture will ever be proven using these methods that rely on statistical properties of the prime numbers without invoking the algebraic structure? It seems to me that any method that does not include the algebraic structure (multiplicative/additive) cannot see any “full” results, only results of the kind “for big enough N”. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a3272bd1b160121fa2aebe3a98c6abc10327c23b209c2767f52b3eb8d9cc427-661816d5b0ecd158ba320c6763edc5581b6bd5fa514cdaaded3e5c7cc7aa4740.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of remy")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-146760")[#strong[#text("remy")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2012")])]

#text("hello")#linebreak()#text(" 2*3*5*7-197")#linebreak()#text(" 13")#linebreak()#text(" 2*3*5*7-199")#linebreak()#text(" 11")#linebreak()#text(" 11 and 13 are numbers the first Twin")#linebreak()#text(" and 197, 199 are also numbers the first Twin")#linebreak()#text(" because in p1 * p2 * p3 * p4 … pn-px = py")#linebreak()#text(" py and a prime number if py <p (n +1) ^ 2")#linebreak()#text(" and if px ​​and the first with p1 * p2 * p3 * p4 … pn or px and a prime number")#linebreak()#text(" logical because it can be the first number in common")#linebreak()#text(" between p1 * p2 * p3 * p4 … pn and px")#linebreak()#text(" remy")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-229209")[#strong[#text("All odd integers greater than 7 are the sum of three odd primes! | The Aperiodical")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2013")]

#text("[…] unproven, and remains one of the long-standing unproven results in number theory. Sadly, it’s the opinion of Terence Tao, among others, that the method used to prove the weak conjecture probably won’t work on the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/280e83a17185e83c6aca2e8558482645e59d7cf5eb632e1f90e235e142eb8bfb-e7bfbf35b8f2419fcbb43f0509c2fc26bc1584c8dd71159d7c0c1da5fa160c8a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Green-Tao theorem and a relative Szemerédi theorem | Yufei Zhao")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-231255")[#strong[#text("The Green-Tao theorem and a relative Szemerédi theorem | Yufei Zhao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2013")])]

#text("[…] (the best result in this direction is due to Jingrun Chen), as all existing methods have severe limitations. But then again, the same could have been said about bounded gaps between primes before […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-237164")[#strong[#text("The ternary Goldbach conjecture | The value of the variable")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")]

#text("[…] (Incidentally: while we can start to treat the binary, or strong, Goldbach conjecture with the circle method, we soon hit a wall: the “noise” from the minor arcs overwhelms the contribution from the major arcs. This is well explained in this post by Tao.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of buy cialis")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-242967")[#strong[#text("buy cialis")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("Economies are in dire straits, but I can count on this!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sylvain JULIEN")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-248594")[#strong[#text("Sylvain JULIEN")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("I would like to get your opinion about the upper bound $r_{0}(n)\\ll \\log^{2}n$ given in ")#link("http://www.les-mathematiques.net/phorum/read.php?4,873826")[#text("http://www.les-mathematiques.net/phorum/read.php?4,873826")]#text(". Do you think it is correct? I think you can read mathematical French but otherwise I can provide a translation into English.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-248852")[#strong[#text("Harald Andrés Helfgott nos habla sobre su demostración de la conjetura débil de Goldbach - Gaussianos | Gaussianos")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2013")]

#text("[…] abruma la contribución de los arcos mayores. Ver la exposición de este problema en el post “Heuristic limitations of the circle method” de Terry Tao (20 de mayo de […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-249283")[#strong[#text("Some Simply Stated Open Problems | J. Zambrano's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2013")]

#text("[…] This problem is one of the most famous open problem in number theory. Its weak form, which states that every odd number greater than 7 can be written as the sum of three odd primes, seems to been solved by Harald Helfgott (awaiting verification). Other similar results have been proved as well. For instance, Terence Tao proved that every odd integer is the sum of at most five primes. Both of these proofs rely on a fairly technical method known as The Hardy-Littlewood Circle Method. Despite this progress, it seems that the original conjecture remains out of reach. It is interesting to note that the resolution of the Generalized Reimann Hypothesis implies the strong Goldbach Conjecture. A detailed discussion of results and possibilities for this conjecture’s resolution can be found on Terry Tao’s site. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-261196")[#strong[#text("Potential Scientific Advancements in 2014: Looking forward from 2013 | Sublime Illusions")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2014")]

#text("[…] and the details of the proof are too intricate for me to explain, but Terence Tao provides an excellent explanation of the proof on his blog. Directions for 2014? To quote, Helfgott, proving the “strong conjecture is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/42a4afba76fd0e577f37b42539cf5f635ce8e39f43706b5c5fbbf1263f49c60d-04f3787e772e41e8440532a5222fc2e69f557617979677939ebee7a8bf802dad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonny Pornel")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-272045")[#strong[#text("Jonny Pornel")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("Hello Terry. I was able to prove the Strong Goldbach conjecture. My approach was to look for an integer k such that n-k and n+k are primes. I calculated the number of such k given any n and then come up with a lower bound function. With it I proved that any even number greater than 34 can be expressed as a sum of two primes. The numbers 4 to 34 would of course be easy to prove that they satisfy Goldbach conjecture.")

#text("I would like to share my result to arxiv but incapable to do so because I need an endorser so I can upload my paper. Could you advice me on what to do with my paper. I am a young assistant professor in a university in the Philippines.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The parity problem obstruction for the binary Goldbach problem with bounded error | What's new")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-391135")[#strong[#text("The parity problem obstruction for the binary Goldbach problem with bounded error | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2014")])]

#text("[…] The above argument is not watertight, and one could envisage some ways around this problem. One of them is that the Möbius randomness principle could simply be false, in which case the parity obstruction vanishes. A good example of this is the result of Heath-Brown that shows that if there are infinitely many Siegel zeroes (which is a strong violation of the Möbius randomness principle), then the twin prime conjecture holds. Another way around the obstruction is to start controlling the discrepancy (1) for functions that are combinations of more than one multiplicative function, e.g. . However, controlling such functions looks to be at least as difficult as the twin prime conjecture (which is morally equivalent to obtaining non-trivial lower-bounds for ). A third option is not to use a sieve-theoretic argument, but to try a different method (e.g. the circle method). However, most other known methods also exhibit linearity in the “” variable and I would suspect they would be vulnerable to a similar obstruction. (In any case, the circle method specifically some other difficulties in tackling binary problems, as discussed in this previous post.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hiklicepleh")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-446651")[#strong[#text("hiklicepleh")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2014")])]

#text("|R(N)| <= c(N*(logN)^(-A)) is a theorem, where R(N) – the amount not exceeding N even numbers that can not be represented as a sum of two primes. Where (A) is an arbitrary number greater than zero. If you find an upper bound (c), can we say that the theorem will be proved?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-446731")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2014")])]

#text("In the known bounds on the number of exceptions ")#mi("R(N)")#text(" to the even Goldbach conjecture, the constant ")#mi("c = c_A")#text(" in the bound ")#mi("R(N) \\leq c_A N \\log^{-A} N")#text(" depends on ")#mi("A")#text(", and in particular goes to infinity as ")#mi("A")#text(" goes to infinity. As such, this bound does not immediately imply the Goldbach conjecture (which requires ")#mi("R(N)")#text(" to vanish entirely). It is true that if one could somehow make ")#mi("c_A")#text(" in this bound independent of ")#mi("A")#text(", then by sending ")#mi("A")#text(" to infinity one could settle the Goldbach conjecture, but pretty much the only way to make ")#mi("c_A")#text(" independent of ")#mi("A")#text(" is to prove the even Goldbach conjecture by some other means first.")

#text("(Incidentally, ")#link("http://www.ams.org/mathscinet-getitem?mr=374063")[#text("Montgomery and Vaughan proved")]#text(" the stronger estimate ")#mi("R(N) \\leq c N^{1-\\delta}")#text(" for some absolute constants ")#mi("c, \\delta > 0")#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d57d55e60f821c1d05e39e34c9f7770b30a9a51ebc94969c5c6db5cd7bae3144-2d1d60be21e3bf6a907ac9aa471919572194be3ccb33d6dbea29fe5343b9132d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hiklicepleh")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-446937")[#strong[#text("hiklicepleh")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2014")])]

#text("Thanks for the link. To improve the assessment, you can experiment with the equation p1+p2=n. Take the square root, and then convert to the form: g(p1)+f(p2)=n^1/2. Not sure that this is possible.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-452787")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2015")])]

#text("The last link to Pollack in this post is not working.")

#emph[#text("[Fixed, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-453603")[#strong[#text("254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2015")])]

#text("[…] reasons, unless the statement is replaced with something weaker, such as an averaged statement; see this previous blog post for further discussion. On the other hand, the methods here can obtain weaker versions of the even […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-453629")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2015")])]

#text("In section 4 (“Other methods”) above, in the beginning of the line with the link to GPY results, it seems (according to Polymath8b paper) that “at most 4” should be updated to “at most 6”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-459430")[#strong[#text("The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2015")])]

#text("[…] are known to be subject to the “parity problem” (discussed numerous times previously on this blog), which roughly speaking means that they cannot be proven solely using “linear” […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-460166")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2015")])]

#text("In section 4 (“other methods”), in the 3-4 lines from the end of the fourth paragraph, it seems (according the parity problem section in Polymath8b paper) that “at most 4” may now be updated to “at most 6”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sharma Kunapalli")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-468522")[#strong[#text("Sharma Kunapalli")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2016")])]

#text("Hello,")#linebreak()#text(" I have just completed a paper on additive number theory and it is closely related to this discussion. Would anyone be able to review my paper?")

#text("Thanks")

#text("Sharma")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-468899")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2016")])]

#mi("S(\\alpha )=\\sum_{p\\leq N}e^{2\\pi i\\alpha p}")#linebreak()#text(" ")#mi("I(N)")#text(" ")#mi("=\\int_{0}^{1}S^{2}(\\alpha )e^{-2\\pi i\\alpha N}d\\alpha")#text(" – the number of solutions of the equation ")#mi("p_{1}+p_{2}=N")#text(". What if you build the zeta function (")#mi("\\int_{0}^{\\infty }\\frac{1}{N^{s}}dJ(N)")#text(" – in the view I am not sure) and found a functional equation for it. Is there at least a small chance to shed light on the distribution of this function ")#mi("I(N)")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-480002")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2017")])]

#text("This sum ")#mi("F(z)=\\sum_{n=1}^{\\infty }z^{p_{n}}")#text(" (")#mi("p_{n}")#text(" – nth prime) is convergent at least for ")#tao-math("\\left|z\\right|<1-\\epsilon", block: false)#text(".")#linebreak()#text(" Now, we can apply the inversion of the Weierstrass transform for this function ")#mi("F(z)")#text(" and we get ")#mi("\\sum_{n=1}^{\\infty }H_{p_{n}}(\\frac{z}{2})")#text(",")#linebreak()#text(" where ")#mi("H_{p_{n}}")#text(" – Hermite polynomials. There is a connection between these polynomials and the theory of random matrices through van der Monde's determinant.")#linebreak()#text(" I do not know how difficult it will be to estimate such a sum, you will also need to understand what to select instead of ")#mi("z")#text(", but even if it does, then in the end we will need to apply the Weierstrass transformation to this estimate, which is very difficult, probably.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b56bc242ff57fc788fb8a7346acc4ef6c40b21c24132ffb4ea6216bb61d4b96f-9dd1bdd57e2549cf7159cb0fb4550a6cdacfd59387fb49ca052caea12c8390a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin M.")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-489827")[#strong[#text("Martin M.")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2017")])]

#text("Isn’t it possible to bring the Twin Primes into 1:1 correspondence to the integers to prove they are infinite? If each integer corresponded to a fraction and each fraction corresponded to a Twin Prime, wouldn’t this prove the Twin Primes were infinite? For instance, if the integer 1 corresponded to the irreducible fraction 1/2, and 1/2 (in the sum of it’s numerator and denominator) corresponded to the Twin Prime 3. Then each integer would correspond to some Irreducible fraction, translatable into a Twin Prime. For instance a few more terms would include (2, 2/3, 5), (3, 3/4, 7), (4, 4/7, 11), etc.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c4e6eedfb5a83ec41e37056f0d97f3d3ca44e4fbab5e7916bc6f537ce7758fc-6f6d9683c4eea1a2cc9006791c56eaf659f1f426fa2df727faa455f5abb46bb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Silverman")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-489861")[#strong[#text("Robert Silverman")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2017")])]

#text("Mr. Musatov is a well known crank in sci.math and has been")#linebreak()#text(" spewing this illucid nonsense about twin primes in recent threads,")#linebreak()#text(" as well as a lot of other nonsense over many years. Shun him.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b83bbd7a94cc71811b9a9397d388196a23f245102dd6e58079aa3aafe289565-3625ba68bcc18dbb4c72ce2446178147350b5b6ed8a1bc90b78081688da4b407.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zhang Tan")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-513010")[#strong[#text("Zhang Tan")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2019")])]

#text("The elementary proof to the twin prime conjecture")#linebreak()#text(" ")#link("https://drive.google.com/open?id=1N4PXLj_T-Q0m_-sj5JpF2a7HcBU4TW8H")[#text("https://drive.google.com/open?id=1N4PXLj_T-Q0m_-sj5JpF2a7HcBU4TW8H")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-518798")[#strong[#text("MARIO MARKUS ART | examplewordpresscom61817")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2019")]

#text("[…] abruma la contribución de los arcos mayores. Ver la exposición de este problema en el post “Heuristic limitations of the circle method” de Terry Tao (20 de mayo de […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0cc5c5b58984fd8189ecbd929d29b01a826651e0c09b23f3bd634be13eedaaa9-d6d1d5cfe1043cacae035da57d5d17ba965c8e55b19bbe97d948d36de7810dd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Waring’s problem and introduction to the circle method | Aditya Guha Roy's weblog")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-577591")[#strong[#text("Waring’s problem and introduction to the circle method | Aditya Guha Roy's weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2020")])]

#text("[…] the circle method finds a prominent place. The interested reader is suggested to take a look at this wonderful blog post on circle methods and its limitations (heuristics) authored by Prof. Terence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-597977")[#strong[#text("Can We Solve It? | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2020")]

#text("[…] he looked at Terence Tao’s blog post on this very issue. It helped that Maynard is an expert on the Hardy-Littlewood method, but perhaps thinking why it […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/#comment-691701")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2026")])]

#text("Beautiful post.")
]
