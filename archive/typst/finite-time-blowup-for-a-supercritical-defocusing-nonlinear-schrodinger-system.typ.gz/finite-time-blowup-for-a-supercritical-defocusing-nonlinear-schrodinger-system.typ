// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/
// Converted to Typst by tao2typ: "2026-10-14T15:19:50.348401+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Finite time blowup for a supercritical defocusing nonlinear Schrodinger system", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Finite time blowup for a supercritical defocusing nonlinear Schrodinger system")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 December 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/")[#text("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper ")#link("https://arxiv.org/abs/1612.00526")[#text("Finite time blowup for a supercritical defocusing nonlinear Schrödinger system")]#text(", submitted to ")#link("http://msp.org/apde/about/cover/cover.html")[#text("Analysis and PDE")]#text(". This paper is an analogue of a ")#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/")[#text("recent paper of mine")]#text(" in which I constructed a supercritical defocusing nonlinear wave (NLW) system ")#mi("{-\\partial_{tt} u + \\Delta u = (\\nabla F)(u)}")#text(" which exhibited smooth solutions that developed singularities in finite time. Here, we achieve essentially the same conclusion for the (inhomogeneous) supercritical defocusing nonlinear Schrödinger (NLS) equation ")#metadata(none) <tao-7e30cb8b63fde7d4f89e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("i \\partial_t u + \\Delta u = (\\nabla F)(u) + G")]]

#text("where ")#mi("{u: {\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf C}^m}")#text(" is now a system of scalar fields, ")#mi("{F: {\\bf C}^m \\rightarrow {\\bf R}}")#text(" is a potential which is strictly positive and homogeneous of degree ")#mi("{p+1}")#text(" (and invariant under phase rotations ")#mi("{u \\mapsto e^{i\\theta} u}")#text("), and ")#mi("{G: {\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf C}^m}")#text(" is a smooth compactly supported forcing term, needed for technical reasons.")

#text("To oversimplify somewhat, the equation ")#link(<tao-7e30cb8b63fde7d4f89e>)[#text("(1)")]#text(" is known to be globally regular in the ")#emph[#text("energy-subcritical")]#text(" case when ")#mi("{d \\leq 2}")#text(", or when ")#mi("{d \\geq 3}")#text(" and ")#mi("{p < 1+\\frac{4}{d-2}}")#text("; global regularity is also known (but is significantly more difficult to establish) in the ")#emph[#text("energy-critical")]#text(" case when ")#mi("{d \\geq 3}")#text(" and ")#mi("{p = 1 +\\frac{4}{d-2}}")#text(". (This is an oversimplification for a number of reasons, in particular in higher dimensions one only knows global well-posedness instead of global regularity. See ")#link("https://terrytao.wordpress.com/2016/03/08/finite-time-blowup-for-high-dimensional-nonlinear-wave-systems-with-bounded-smooth-nonlinearity/")[#text("this previous post")]#text(" for some exploration of this issue in the context of nonlinear wave equations.) The main result of this paper is to show that global regularity can break down in the remaining ")#emph[#text("energy-supercritical case")]#text(" when ")#mi("{d \\geq 3}")#text(" and ")#mi("{p > 1 + \\frac{4}{d-2}}")#text(", at least when the target dimension ")#mi("{m}")#text(" is allowed to be sufficiently large depending on the spatial dimension ")#mi("{d}")#text(" (I did not try to achieve the optimal value of ")#mi("{m}")#text(" here, but the argument gives a value of ")#mi("{m}")#text(" that grows quadratically in ")#mi("{d}")#text("). Unfortunately, this result does not directly impact the most interesting case of the defocusing scalar NLS equation ")#metadata(none) <tao-4d3fcaa9f296a40241fe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("i \\partial_t u + \\Delta u = \\left|u\\right|^{p-1} u", block: true)]]

#text("in which ")#mi("{m=1}")#text("; however it does establish a rigorous ")#emph[#text("barrier")]#text(" to any attempt to prove global regularity for the scalar NLS equation, in that such an attempt needs to crucially use some property of the scalar NLS that is not shared by the more general systems in ")#link(<tao-7e30cb8b63fde7d4f89e>)[#text("(1)")]#text(". For instance, any approach that is primarily based on the conservation laws of mass, momentum, and energy (which are common to both ")#link(<tao-7e30cb8b63fde7d4f89e>)[#text("(1)")]#text(" and ")#link(<tao-4d3fcaa9f296a40241fe>)[#text("(2)")]#text(") will not be sufficient to establish global regularity of supercritical defocusing scalar NLS.")

#text("The method of proof in this paper is broadly similar to that in ")#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/")[#text("the previous paper")]#text(" for NLW, but with a number of additional technical complications. Both proofs begin by reducing matters to constructing a discretely self-similar solution. In the case of NLW, this solution lived on a forward light cone ")#tao-math("{\\{ (t,x): \\left|x\\right| \\leq t \\}}", block: false)#text(" and obeyed a self-similarity")

#align(center)[#tao-fit-display[#mitex("u(2t, 2x) = 2^{-\\frac{2}{p-1}} u(t,x).")]]

#text("The ability to restrict to a light cone arose from the finite speed of propagation properties of NLW. For NLS, the solution will instead live on the domain")

#align(center)[#tao-fit-display[#mitex("H_d := ([0,+\\infty) \\times {\\bf R}^d) \\backslash \\{(0,0)\\}")]]

#text("and obey a parabolic self-similarity")

#align(center)[#tao-fit-display[#mitex("u(4t, 2x) = 2^{-\\frac{2}{p-1}} u(t,x)")]]

#text("and solve the homogeneous version ")#mi("{G=0}")#text(" of ")#link(<tao-7e30cb8b63fde7d4f89e>)[#text("(1)")]#text(". (The inhomogeneity ")#mi("{G}")#text(" emerges when one truncates the self-similar solution so that the initial data is compactly supported in space.) A key technical point is that ")#mi("{u}")#text(" has to be smooth everywhere in ")#mi("{H_d}")#text(", including the boundary component ")#mi("{\\{ (0,x): x \\in {\\bf R}^d \\backslash \\{0\\}\\}}")#text(". This unfortunately rules out many of the existing constructions of self-similar solutions, which typically will have some sort of singularity at the spatial origin.")

#text("The remaining steps of the argument can broadly be described as ")#link("https://en.wikipedia.org/wiki/Quantifier_elimination")[#text("quantifier elimination")]#text(": one systematically eliminates each of the degrees of freedom of the problem in turn by locating the necessary and sufficient conditions required of the remaining degrees of freedom in order for the constraints of a particular degree of freedom to be satisfiable. The first such degree of freedom to eliminate is the potential function ")#mi("{F}")#text(". The task here is to determine what constraints must exist on a putative solution ")#mi("{u}")#text(" in order for there to exist a (positive, homogeneous, smooth away from origin) potential ")#mi("{F}")#text(" obeying the homogeneous NLS equation")

#align(center)[#tao-fit-display[#mitex("i \\partial_t u + \\Delta u = (\\nabla F)(u).")]]

#text("Firstly, the requirement that ")#mi("{F}")#text(" be homogeneous implies the ")#link("https://en.wikipedia.org/wiki/Homogeneous_function#Positive_homogeneity")[#text("Euler identity")]

#align(center)[#tao-fit-display[#mitex("\\langle (\\nabla F)(u), u \\rangle = (p+1) F(u)")]]

#text("(where ")#mi("{\\langle,\\rangle}")#text(" denotes the standard real inner product on ")#mi("{{\\bf C}^m}")#text("), while the requirement that ")#mi("{F}")#text(" be phase invariant similarly yields the variant identity")

#align(center)[#tao-fit-display[#mitex("\\langle (\\nabla F)(u), iu \\rangle = 0,")]]

#text("so if one defines the ")#emph[#text("potential energy field")]#text(" to be ")#mi("{V = F(u)}")#text(", we obtain from the chain rule the equations")

#tao-aligned(keep: true)[


#tao-math("\\langle i \\partial_t u + \\Delta u, u \\rangle  & = (p+1) V", block: true)



#tao-math("\\langle i \\partial_t u + \\Delta u, iu \\rangle  & = 0", block: true)



#tao-math("\\langle i \\partial_t u + \\Delta u, \\partial_t u \\rangle  & = \\partial_t V", block: true)



#tao-math("\\langle i \\partial_t u + \\Delta u, \\partial_{x_j} u \\rangle  & = \\partial_{x_j} V.", block: true)
]

#text("Conversely, it turns out (roughly speaking) that if one can locate fields ")#mi("{u}")#text(" and ")#mi("{V}")#text(" obeying the above equations (as well as some other technical regularity and non-degeneracy conditions), then one can find an ")#mi("{F}")#text(" with all the required properties. The first of these equations can be thought of as a definition of the potential energy field ")#mi("{V}")#text(", and the other three equations are basically disguised versions of the conservation laws of mass, energy, and momentum respectively. The construction of ")#mi("{F}")#text(" relies on a classical ")#link("http://www.ams.org/mathscinet-getitem?mr=165392")[#text("extension theorem of Seeley")]#text(" that is a relative of the ")#link("https://en.wikipedia.org/wiki/Whitney_extension_theorem")[#text("Whitney extension theorem")]#text(".")

#text("Now that the potential ")#mi("{F}")#text(" is eliminated, the next degree of freedom to eliminate is the solution field ")#mi("{u}")#text(". One can observe that the above equations involving ")#mi("{u}")#text(" and ")#mi("{V}")#text(" can be expressed instead in terms of ")#mi("{V}")#text(" and the ")#emph[#text("Gram-type matrix")]#text(" ")#mi("{G[u,u]}")#text(" of ")#mi("{u}")#text(", which is a ")#mi("{(2d+4) \\times (2d+4)}")#text(" matrix consisting of the inner products ")#mi("{\\langle D_1 u, D_2 u \\rangle}")#text(" where ")#mi("{D_1,D_2}")#text(" range amongst the ")#mi("{2d+4}")#text(" differential operators")

#align(center)[#tao-fit-display[#mitex("D_1,D_2 \\in \\{ 1, i, \\partial_t, i\\partial_t, \\partial_{x_1},\\dots,\\partial_{x_d}, i\\partial_{x_1}, \\dots, i\\partial_{x_d}\\}.")]]

#text("To eliminate ")#mi("{u}")#text(", one thus needs to answer the question of what properties are required of a ")#mi("{(2d+4) \\times (2d+4)}")#text(" matrix ")#mi("{G}")#text(" for it to be the Gram-type matrix ")#mi("{G = G[u,u]}")#text(" of a field ")#mi("{u}")#text(". Amongst some obvious necessary conditions are that ")#mi("{G}")#text(" needs to be symmetric and positive semi-definite; there are also additional constraints coming from identities such as")

#tao-aligned(keep: true)[


#tao-math("\\partial_t \\langle u, u \\rangle  & = 2 \\langle u, \\partial_t u \\rangle", block: true)



#tao-math("\\langle i u, \\partial_t u \\rangle  & = - \\langle u, i \\partial_t u \\rangle", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\partial_{x_j} \\langle iu, \\partial_{x_k} u \\rangle - \\partial_{x_k} \\langle iu, \\partial_{x_j} u \\rangle = 2 \\langle i \\partial_{x_j} u, \\partial_{x_k} u \\rangle.")]]

#text("Ideally one would like a theorem that asserts (for ")#mi("{m}")#text(" large enough) that as long as ")#mi("{G}")#text(" obeys all of the “obvious” constraints, then there exists a suitably non-degenerate map ")#mi("{u}")#text(" such that ")#mi("{G = G[u,u]}")#text(". In the case of NLW, the analogous claim was basically a consequence of the ")#link("https://en.wikipedia.org/wiki/Nash_embedding_theorem")[#text("Nash embedding theorem")]#text(" (which can be viewed as a theorem about the solvability of the system of equations ")#mi("{\\langle \\partial_{x_j} u, \\partial_{x_k} u \\rangle = g_{jk}}")#text(" for a given positive definite symmetric set of fields ")#mi("{g_{jk}}")#text("). However, the presence of the complex structure in the NLS case poses some significant technical challenges (note for instance that the naive complex version of the Nash embedding theorem is false, due to obstructions such as Liouville’s theorem that prevent a compact complex manifold from being embeddable holomorphically in ")#mi("{{\\bf C}^m}")#text("). Nevertheless, by adapting the ")#emph[#text("proof")]#text(" of the Nash embedding theorem (in particular, the simplified proof ")#link("http://www.ams.org/mathscinet-getitem?mr=1159298")[#text("of Gunther")]#text(" that avoids the need to use the Nash-Moser iteration scheme) we were able to obtain a partial complex analogue of the Nash embedding theorem that sufficed for our application; it required an artificial additional “curl-free” hypothesis on the Gram-type matrix ")#mi("{G[u,u]}")#text(", but fortunately this hypothesis ends up being automatic in our construction. Also, this version of the Nash embedding theorem is unable to prescribe the component ")#mi("{\\langle \\partial_t u, \\partial_t u \\rangle}")#text(" of the Gram-type matrix ")#mi("{G[u,u]}")#text(", but fortunately this component is not used in any of the conservation laws and so the loss of this component does not cause any difficulty.")

#text("After applying the above-mentioned Nash-embedding theorem, the task is now to locate a matrix ")#mi("{G}")#text(" obeying all the hypotheses of that theorem, as well as the conservation laws for mass, momentum, and energy (after defining the potential energy field ")#mi("{V}")#text(" in terms of ")#mi("{G}")#text("). This is quite a lot of fields and constraints, but one can cut down significantly on the degrees of freedom by requiring that ")#mi("{G}")#text(" is spherically symmetric (in a tensorial sense) and also continuously self-similar (not just discretely self-similar). Note that this hypothesis is weaker than the assertion that the original field ")#mi("{u}")#text(" is spherically symmetric and continuously self-similar; indeed we do not know if non-trivial solutions of this type actually exist. These symmetry hypotheses reduce the number of independent components of the ")#mi("{(2d+4) \\times (2d+4)}")#text(" matrix ")#mi("{G}")#text(" to just six: ")#mi("{g_{1,1}, g_{1,i\\partial_t}, g_{1,i\\partial_r}, g_{\\partial_r, \\partial_r}, g_{\\partial_\\omega, \\partial_\\omega}, g_{\\partial_r, \\partial_t}}")#text(", which now take as their domain the ")#mi("{1+1}")#text("-dimensional space")

#align(center)[#tao-fit-display[#mitex("H_1 := ([0,+\\infty) \\times {\\bf R}) \\backslash \\{(0,0)\\}.")]]

#text("One now has to construct these six fields, together with a potential energy field ")#mi("{v}")#text(", that obey a number of constraints, notably some positive definiteness constraints as well as the aforementioned conservation laws for mass, momentum, and energy.")

#text("The field ")#mi("{g_{1,i\\partial_t}}")#text(" only arises in the equation for the potential ")#mi("{v}")#text(" (coming from Euler’s identity) and can easily be eliminated. Similarly, the field ")#mi("{g_{\\partial_r,\\partial_t}}")#text(" only makes an appearance in the current of the energy conservation law, and so can also be easily eliminated so long as the total energy is conserved. But in the energy-supercritical case, the total energy is infinite, and so it is relatively easy to eliminate the field ")#mi("{g_{\\partial_r, \\partial_t}}")#text(" from the problem also. This leaves us with the task of constructing just five fields ")#mi("{g_{1,1}, g_{1,i\\partial_r}, g_{\\partial_r,\\partial_r}, g_{\\partial_\\omega,\\partial_\\omega}, v}")#text(" obeying a number of positivity conditions, symmetry conditions, regularity conditions, and conservation laws for mass and momentum.")

#text("The potential field ")#mi("{v}")#text(" can effectively be absorbed into the angular stress field ")#mi("{g_{\\partial_\\omega,\\partial_\\omega}}")#text(" (after placing an appropriate counterbalancing term in the radial stress field ")#mi("{g_{\\partial_r, \\partial_r}}")#text(" so as not to disrupt the conservation laws), so we can also eliminate this field. The angular stress field ")#mi("{g_{\\partial_\\omega, \\partial_\\omega}}")#text(" is then only constrained through the momentum conservation law and a requirement of positivity; one can then eliminate this field by converting the momentum conservation law from an equality to an inequality. Finally, the radial stress field ")#mi("{g_{\\partial_r, \\partial_r}}")#text(" is also only constrained through a positive definiteness constraint and the momentum conservation inequality, so it can also be eliminated from the problem after some further modification of the momentum conservation inequality.")

#text("The task then reduces to locating just two fields ")#mi("{g_{1,1}, g_{1,i\\partial_r}}")#text(" that obey a mass conservation law")

#align(center)[#tao-fit-display[#mitex("\\partial_t g_{1,1} = 2 \\left(\\partial_r + \\frac{d-1}{r} \\right) g_{1,i\\partial r}")]]

#text("together with an additional inequality that is the remnant of the momentum conservation law. One can solve for the mass conservation law in terms of a single scalar field ")#mi("{W}")#text(" using the ansatz")

#tao-aligned(keep: true)[


#tao-math("g_{1,1}  & = 2 r^{1-d} \\partial_r (r^d W)", block: true)



#tao-math("g_{1,i\\partial_r}  & = r^{1-d} \\partial_t (r^d W)", block: true)
]

#text("so the problem has finally been simplified to the task of locating a single scalar field ")#mi("{W}")#text(" with some scaling and homogeneity properties that obeys a certain differential inequality relating to momentum conservation. This turns out to be possible by explicitly writing down a specific scalar field ")#mi("{W}")#text(" using some asymptotic parameters and cutoff functions.")

#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/#comment-474878")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2016")])]

#text("Concerning the barrier to prove global regularity for the scalar equation (2), is there any known (nontrivial) property of (2) which is not shared by (1) ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/#comment-474879")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2016")])]

#text("In the case when the exponent ")#mi("p")#text(" is an odd integer such as 5 or 7, then the scalar nonlinearity ")#tao-math("\\left|u\\right|^{p-1} u", block: false)#text(" is a polynomial in ")#mi("u")#text(" and its complex conjugate ")#mi("\\overline{u}")#text(", which is a property that is quite heavily exploited in a number of ways (e.g. it allows for fairly explicit computation of the Fourier transform of the nonlinearity). This property would not be shared by the more general nonlinearities ")#mi("F(u)")#text(" appearing in (2).")

#text("But most of the other properties of (2) that are used in the literature are also shared with (1), as they usually arise from some combination of the conservation laws or from the function space estimates enjoyed by the nonlinearity.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48048a75ee449e2bcc705599925361074967ec80fe577c592fcbf6860d2077e9-a5155697a0c292957c78216930a12d33e1666d2a437c58e3ee0637f19c39e21f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leo")]], [#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/#comment-474880")[#strong[#text("Leo")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2016")])]

#text("Dear Prof. Terence Tao,")

#text("Please excuse me if my question is not much related to this post. I’m reading your paper with M. Christ and J. Colliander about the ill-posedness of the nonlinear Schrodinger and wave equations. I’m interested in the range ")#mi("s \\in (-d/2, 0)")#text(". For the Schrodinger equation, you used the Galilean transform and the decoherence argument. For the wave equation, as I see in this paper, you said that one can use scaling and decoherence argument to treat this range. Is the scaling and decoherence argument sufficient to prove the ill-posedness for the Schrodinger equation in the range ")#mi("s\\in (-d/2,0)")#text("?")

#text("Thank you very much!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/#comment-474881")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2016")])]

#text("If I recall correctly, the treatment of the NLW case in the range ")#mi("s \\in (-d/2,0)")#text(" relied on special properties of the 1D wave equation, which would not be easily replicated in the NLS context.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48048a75ee449e2bcc705599925361074967ec80fe577c592fcbf6860d2077e9-a5155697a0c292957c78216930a12d33e1666d2a437c58e3ee0637f19c39e21f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leo")]], [#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/#comment-474882")[#strong[#text("Leo")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2016")])]

#text("Thank you for your response. But I still don’t get the idea. In this paper, you claimed that in the supercritical cases ")#mi("s<s_c")#text(" (Theorem 3, 4, 5 there), the proofs of ill-posedness for NLW can be proceeded in analogy with their NLS counterparts, using small dispersion analysis and scaling arguments. The proofs of these theorems do not use any special property of 1D wave equation. I see that for NLS, in the range ")#mi("s\\in (-d/2,0)")#text(", you use the Galilean transformation to construct the counter-example. But the NLW does not have this kind of invariance. Could you please to explain me about it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/#comment-474885")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2016")])]

#text("Theorems 3,4,5 do not cover the entirety of the range ")#mi("s \\in (-d/2,0)")#text("; only Corollary 7 (which is based on the 1D NLW) handles all of that range. As mentioned in the paper, we were not able to adapt the Galilean invariance-based argument to the case of NLW.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48048a75ee449e2bcc705599925361074967ec80fe577c592fcbf6860d2077e9-a5155697a0c292957c78216930a12d33e1666d2a437c58e3ee0637f19c39e21f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leo")]], [#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/#comment-474889")[#strong[#text("Leo")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2016")])]

#text("Thank you for you answer!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hiro")]], [#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/#comment-474887")[#strong[#text("Hiro")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2016")])]

#text("Perhaps, this is not answering your question in a direct manner.")

#text("One can prove norm inflation for NLS in the range $s \\in (-d/2, 0)$ (below the scaling critical regularity) by adapting the argument in Bejenaru-Tao and Iwabuchi-Ogawa. Nobu Kishimoto proved this result (unpublished note) some years ago. The argument does not use scaling in an explicit manner but uses high-to-low energy transfer.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48048a75ee449e2bcc705599925361074967ec80fe577c592fcbf6860d2077e9-a5155697a0c292957c78216930a12d33e1666d2a437c58e3ee0637f19c39e21f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leo")]], [#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/#comment-474890")[#strong[#text("Leo")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2016")])]

#text("Thank you for your indication!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rajesh")]], [#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/#comment-474928")[#strong[#text("Rajesh")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2016")])]

#text("Prof Terry Tao,")

#text("Is there an 1-D NLW version which necessarily has a solution which does not blow up in finite time (shocks are allowed) provided that initial data is small (TV is small), and does not have such a solution otherwise?")

#text("Thanks and Regards")#linebreak()#text(" Rajesh")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/#comment-474934")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2016")])]

#text("The 1D NLKG ")#mi("-u_{tt} + u_{xx} - u = -u^3")#text(" has global smooth solutions for small data (because the potential energy term in the conserved energy ")#mi("\\int_{\\bf R} \\frac{1}{2} u_t^2 + \\frac{1}{2} u_x^2 + \\frac{1}{2} u^2 - \\frac{1}{4} u^4\\ dx")#text(" can be controlled by the Gagliardo-Nirenberg inequality) but not for large data (as can be seen by considering the ODE when ")#mi("u")#text(" is constant in space; one can then localise in space using finite speed of propagation if desired).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/#comment-475011")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2016")])]

#text("– Reference 3: The title should be typeset in italic")#linebreak()#text(" – Reference 7: “Schrdinger” –> “Schrödinger”")#linebreak()#text(" – Reference 9: “Schrodinger” –> “Schrödinger”")#linebreak()#text(" – Reference 13: “Schrodinger” –> “Schrödinger”")#linebreak()#text(" – Reference 15: Remove “pp.” and add a full stop at the end")#linebreak()#text(" – Reference 16: “Schrdinger” –> “Schrödinger”")#linebreak()#text(" – Reference 17: “Proc. Amer. Math. Soc. 15 1964 625–626.” –> “Proc. Amer. Math. Soc. 15 [“15” in bold] (1964), 625–626.”")#linebreak()#text(" – Reference 18: The title should be typeset in italic")#linebreak()#text(" – Reference 19: “ Tao, Terence” –> “ T. Terence”")#linebreak()#text(" – Reference 22: “ 1-28” –> “ 1–28”")#linebreak()#text(" – Reference 23: “Schrdinger” –> “Schrödinger”")#linebreak()#text(" – Reference 25: “. 10, (1943).” –> “. 10 (1943),”")

#emph[#text("[These will be corrected in the next revision of the ms, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/#comment-475012")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2016")])]

#text("[19]: “Tao, Terence” –> “T. Tao”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MatjazG")]], [#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/#comment-475020")[#strong[#text("MatjazG")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2016")])]

#text("– p. 23, Remark 6.4: “requiements” -> “requirements”")#linebreak()#text(" – p. 24, bottom: “continiuty” -> “continuity”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/#comment-475935")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2016")])]

#text("I know its irrelevant, but happy new year prof Tao!")#linebreak()#text(" Your blog has been a great inspiration for me for the past year, and I will keep the hard work!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3170687540c66dc22acac3ff153a5f7b25b10303e42e1144b148a6cfe32bff3d-0c12835ec5ba8882b4301c470ff7175f999ad4539c3167aabdb48ab191ff6473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eulogio Garcia")]], [#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/#comment-476777")[#strong[#text("Eulogio Garcia")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2017")])]

#text("Professor Tao.")

#text("You may interested to know, the only equation for laminar motion. It defines all the events that originate in the motion of the fluid (vortex, oneness).")

#mi("f_{=}(x) \\neq 0")

#text("His mathematical expression is simple.")

#mi("f_{=}(x) = ax - a(x - n)")#text(" ; ")#mi("n > 0")#text(".")

#text("for: ")#mi("\\forall(x) = [0, \\infty]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad4c3e019150b140bc6294f3e40473e219b48a2efe695fd61fffd95ce371b23c-1911117f007cf12d1cf989d9df9995a20201c986ba4c70c42d080735f7970b92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergei")]], [#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/#comment-477091")[#strong[#text("Sergei")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2017")])]

#text("Dear Terence Tao! At present letter I want report to you,what wish repeated send you lost letter at 28December2016(at 9:19). In your last note")#linebreak()#text(" you touch sufficiently interesting subject construction of scalar fieds with calculation of application support-pressing elements. Particularly attracted my heed decision of non-linear Schrödinger equation. This entered some clarity in my reflections. So,construction of scalar fields contact with problem of multinumber breachs top layer or top field of scaly smooth multimanners. This breachs in chains of differential(linear) operators. Breachs in chains reestablish relations in lower layer or lower field of support hyperflatness (n-1), which cover all breachs and change breachs into closed circuits. Interaction of this two fields to the best advantage can to reveal arab numbers, if at they to exert influence through customary operation of partition. Schematic this interaction have such appearance:")#linebreak()#text(" 2017.4034.8069.6139")#linebreak()#text(" —|————(n-1)-(n-1)")#linebreak()#text(" 2016.4032.8065.6131")#linebreak()#text(" —|————(n-1)-(n-1)")#linebreak()#text(" 2015.4030.8061.6123")#linebreak()#text(" —|————(n-1)-(n-1) Thanks. Sergei.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On the universality of the incompressible Euler equation on compact manifolds | What's new")]], [#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/#comment-484244")[#strong[#text("On the universality of the incompressible Euler equation on compact manifolds | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2017")])]

#text("[…] theorem proceeds by an “elimination of variables” strategy that was used in some of my previous papers in this area, though in this particular case the Nash embedding theorem (or variants […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Some recent papers | What's new")]], [#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/#comment-535673")[#strong[#text("Some recent papers | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2020")])]

#text("[…] nonlinear Schrodinger equation (at least in certain dimensions and nonlinearities). I had a previous paper establishing a result like this if one “cheated” by replacing the nonlinear Schrodinger […]")
]
