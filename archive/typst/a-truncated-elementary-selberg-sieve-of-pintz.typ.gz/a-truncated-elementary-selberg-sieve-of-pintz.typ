// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/
// Converted to Typst by tao2typ: "2026-10-14T15:18:41.669114+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A truncated elementary Selberg sieve of Pintz", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A truncated elementary Selberg sieve of Pintz")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 June 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/")[#text("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This post is a continuation of the ")#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/")[#text("previous post on sieve theory")]#text(", which is an ongoing part of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8 project")]#text(". As the previous post was getting somewhat full, we are rolling the thread over to the current post.")

#text("In this post we will record a new truncation of the elementary Selberg sieve discussed in this previous post (and also analysed in the context of bounded prime gaps by ")#link("http://www.ams.org/mathscinet-getitem?mr=2515812")[#text("Graham-Goldston-Pintz-Yildirim")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2414788")[#text("Motohashi-Pintz")]#text(") that was recently worked out by Janos Pintz, who has kindly given permission to share this new idea with the Polymath8 project. This new sieve decouples the ")#mi("{\\delta}")#text(" parameter that was present in our previous analysis of Zhang’s argument into two parameters, a quantity ")#mi("{\\delta}")#text(" that used to measure smoothness in the modulus, but now measures a weaker notion of “dense divisibility” which is what is really needed in the Elliott-Halberstam type estimates, and a second quantity ")#mi("{\\delta^{\\prime}}")#text(" which still measures smoothness but is allowed to be substantially larger than ")#mi("{\\delta}")#text(". Through this decoupling, it appears that the ")#mi("{\\kappa}")#text(" type losses in the sieve theoretic part of the argument can be almost completely eliminated (they basically decay exponential in ")#mi("{\\delta^{\\prime}}")#text(" and have only mild dependence on ")#mi("{\\delta}")#text(", whereas the Elliott-Halberstam analysis is sensitive only to ")#mi("{\\delta}")#text(", allowing one to set ")#mi("{\\delta}")#text(" far smaller than previously by keeping ")#mi("{\\delta^{\\prime}}")#text(" large). This should lead to noticeable gains in the ")#mi("{k_0}")#text(" quantity in our analysis.")

#text("To describe this new truncation we need to review some notation. As in all previous posts (in particular, the ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("first post in this series")]#text("), we have an asymptotic parameter ")#mi("{x}")#text(" going off to infinity, and all quantities here are implicitly understood to be allowed to depend on ")#mi("{x}")#text(" (or to range in a set that depends on ")#mi("{x}")#text(") unless they are explicitly declared to be ")#emph[#text("fixed")]#text(". We use the usual asymptotic notation ")#mi("{O(), o(), \\ll}")#text(" relative to this parameter ")#mi("{x}")#text(". To be able to ignore local factors (such as the singular series ")#mi("{{\\mathfrak G}}")#text("), we also use the “")#mi("{W}")#text("-trick” (as discussed in the ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("first post in this series")]#text("): we introduce a parameter ")#mi("{w}")#text(" that grows very slowly with ")#mi("{x}")#text(", and set ")#mi("{W := \\prod_{p<w} p}")#text(".")

#text("For any fixed natural number ")#mi("{k_0}")#text(", define an ")#emph[#text("admissible ")#mi("{k_0}")#text("-tuple")]#text(" to be a fixed tuple ")#mi("{{\\mathcal H}}")#text(" of ")#mi("{k_0}")#text(" distinct integers which avoids at least one residue class modulo ")#mi("{p}")#text(" for each prime ")#mi("{p}")#text(". Our objective is to obtain the following conjecture ")#mi("{DHL[k_0,2]}")#text(" for as small a value of the parameter ")#mi("{k_0}")#text(" as possible:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1")]#text(" (")#mi("{DHL[k_0,2]}")#text(") Let ")#mi("{{\\mathcal H}}")#text(" be a fixed admissible ")#mi("{k_0}")#text("-tuple. Then there exist infinitely many translates ")#mi("{n+{\\mathcal H}}")#text(" of ")#mi("{{\\mathcal H}}")#text(" that contain at least two primes.")
]

#text("The twin prime conjecture asserts that ")#mi("{DHL[k_0,2]}")#text(" holds for ")#mi("{k_0}")#text(" as small as ")#mi("{2}")#text(", but currently we are only able to establish this result for ")#mi("{k_0 \\geq 6329}")#text(" (see ")#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234693")[#text("this comment")]#text("). However, with the new truncated sieve of Pintz described in this post, we expect to be able to lower this threshold ")#mi("{k_0 \\geq 6329}")#text(" somewhat.")

#text("In previous posts, we deduced ")#mi("{DHL[k_0,2]}")#text(" from a technical variant ")#mi("{MPZ[\\varpi,\\delta]}")#text(" of the Elliot-Halberstam conjecture for certain choices of parameters ")#mi("{0 < \\varpi < 1/4}")#text(", ")#mi("{0 < \\delta < 1/4+\\varpi}")#text(". We will use the following formulation of ")#mi("{MPZ[\\varpi,\\delta]}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2")]#text(" (")#mi("{MPZ[\\varpi,\\delta]}")#text(") Let ")#mi("{{\\mathcal H}}")#text(" be a fixed ")#mi("{k_0}")#text("-tuple (not necessarily admissible) for some fixed ")#mi("{k_0 \\geq 2}")#text(", and let ")#mi("{b\\ (W)}")#text(" be a primitive residue class. Then ")#metadata(none) <tao-6d7e04068fa604f0ea60>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\sum_{q \\in {\\mathcal S}_I: q< x^{1/2+2\\varpi}} \\sum_{a \\in C(q)} \\left|\\Delta_{b,W}(\\Lambda; q,a)\\right| = O( x \\log^{-A} x)", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(", where ")#mi("{I = (w,x^{\\delta})}")#text(", ")#mi("{{\\mathcal S}_I}")#text(" are the square-free integers whose prime factors lie in ")#mi("{I}")#text(", and ")#mi("{\\Delta_{b,W}(\\Lambda;q,a)}")#text(" is the quantity ")#metadata(none) <tao-c1a421182e1fb908168f>

#tao-aligned(keep: true)[


#tao-math("\\Delta_{b,W}(\\Lambda;q,a)  & := | \\sum_{x \\leq n \\leq 2x: n=b\\ (W); n = a\\ (q)} \\Lambda(n)", block: true, numbering: n => [#text("(2)")])



#tao-math(" & - \\frac{1}{\\phi(q)} \\sum_{x \\leq n \\leq 2x: n = b\\ (W)} \\Lambda(n)|.", block: true)
]

#text("and ")#mi("{C(q)}")#text(" is the set of congruence classes")

#align(center)[#tao-fit-display[#mitex("C(q) := \\{ a \\in ({\\bf Z}/q{\\bf Z})^\\times: P(a) = 0 \\}")]]

#text("and ")#mi("{P}")#text(" is the polynomial")

#align(center)[#tao-fit-display[#mitex("P(a) := \\prod_{h \\in {\\mathcal H}} (a+h).")]]
]

#text("The conjecture ")#mi("{MPZ[\\varpi,\\delta]}")#text(" is currently known to hold whenever ")#mi("{87 \\varpi + 17 \\delta < \\frac{1}{4}}")#text(" (see ")#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234670")[#text("this comment")]#text(" and ")#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234742")[#text("this confirmation")]#text("). Actually, we can prove a stronger result than ")#mi("{MPZ[\\varpi,\\delta]}")#text(" in this regime in a couple ways. Firstly, the congruence classes ")#mi("{C(q)}")#text(" can be replaced by a more general system of congruence classes obeying a certain controlled multiplicity axiom; see ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("this post")]#text(". Secondly, and more importantly for this post, the requirement that the modulus ")#mi("{q}")#text(" lies in ")#mi("{{\\mathcal S}_I}")#text(" can be relaxed; see below.")

#text("To connect the two conjectures, the previously best known implication was the folowing (see Theorem 2 from ")#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/")[#text("this post")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(" ")#metadata(none) <tao-ced2128f3bc92a5720f7>#text(" Let ")#mi("{0 < \\varpi < 1/4}")#text(", ")#mi("{0 < \\delta < 1/4 + \\varpi}")#text(" and ")#mi("{k_0 \\geq 2}")#text(" be such that we have the inequality ")#metadata(none) <tao-1fdbc74ccfd68d0714ae>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("(1 +4 \\varpi) (1-\\kappa^{\\prime}) > \\frac{j^2_{k_0-2}}{k_0(k_0-1)} (1+\\kappa)")]]

#text("where ")#mi("{j_{k_0-2} = j_{k_0-2,1}}")#text(" is the first positive zero of the Bessel function ")#mi("{J_{k_0-2}}")#text(", and ")#mi("{\\kappa,\\kappa^{\\prime}>0}")#text(" are the quantities")

#align(center)[#tao-fit-display[#mitex("\\kappa := \\sum_{1 \\leq n < \\frac{1+4\\varpi}{4\\delta}} \\frac{3^n+1}{2} \\frac{k_0^n}{n!} (\\int_{4\\delta/(1+4\\varpi)}^1 (1-t)^{k_0/2}\\ \\frac{dt}{t})^n")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\kappa^{\\prime} := \\sum_{2 \\leq n < \\frac{1+4\\varpi}{4\\delta}} \\frac{3^n-1}{2} \\frac{(k_0-1)^n}{n!}")]]

#align(center)[#tao-fit-display[#mitex("(\\int_{4\\delta/(1+4\\varpi)}^1 (1-t)^{(k_0-1)/2}\\ \\frac{dt}{t})^n.")]]

#text("Then ")#mi("{MPZ[\\varpi,\\delta]}")#text(" implies ")#mi("{DHL[k_0,2]}")#text(".")
]

#text("Actually there have been some slight improvements to the quantities ")#mi("{\\kappa,\\kappa^{\\prime}}")#text("; see the comments to ")#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/")[#text("this previous post")]#text(". However, the main error ")#mi("{\\kappa}")#text(" remains roughly of the order ")#mi("{\\delta^{-1} \\exp( - 2 k_0\\delta )}")#text(", which limits one from taking ")#mi("{\\delta}")#text(" too small.")

#text("To improve beyond this, the first basic observation is that the smoothness condition ")#mi("{q \\in {\\mathcal S}_I}")#text(", which implies that all prime divisors of ")#mi("{q}")#text(" are less than ")#mi("{x^\\delta}")#text(", can be relaxed in the proof of ")#mi("{MPZ[\\varpi,\\delta]}")#text(". Indeed, if one inspects the proof of this proposition (described in ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("these three")]#text(" ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("previous")]#text(" ")#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/")[#text("posts")]#text("), one sees that the key property of ")#mi("{q}")#text(" needed is not so much the smoothness, but a weaker condition which we will call (for lack of a better term) ")#emph[#text("dense divisibility")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4")]#text(" Let ")#mi("{y > 1}")#text(". A positive integer ")#mi("{q}")#text(" is said to be ")#emph[#mi("{y}")#text("-densely divisible")]#text(" if for every ")#mi("{1 \\leq R \\leq q}")#text(", one can find a factor of ")#mi("{q}")#text(" in the interval ")#mi("{[y^{-1} R, R]}")#text(". We let ")#mi("{{\\mathcal D}_y}")#text(" denote the set of positive integers that are ")#mi("{y}")#text("-densely divisible.")
]

#text("Certainly every integer which is ")#mi("{y}")#text("-smooth (i.e. has all prime factors at most ")#mi("{y}")#text(" is also ")#mi("{y}")#text("-densely divisible, as can be seen from the greedy algorithm; but the property of being ")#mi("{y}")#text("-densely divisible is strictly weaker than ")#mi("{y}")#text("-smoothness, which is a fact we shall exploit shortly.")

#text("We now define ")#mi("{MPZ^{\\prime}[\\varpi,\\delta]}")#text(" to be the same statement as ")#mi("{MPZ[\\varpi,\\delta]}")#text(", but with the condition ")#mi("{q \\in {\\mathcal S}_I}")#text(" replaced by the weaker condition ")#mi("{q \\in {\\mathcal S}_{[w,+\\infty)} \\cap {\\mathcal D}_{x^\\delta}}")#text(". The arguments in previous posts then also establish ")#mi("{MPZ^{\\prime}[\\varpi,\\delta]}")#text(" whenever ")#mi("{87 \\varpi + 17 \\delta < \\frac{1}{4}}")#text(".")

#text("The main result of this post is then the following implication, essentially due to Pintz:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5")]#text(" ")#metadata(none) <tao-ae861ab4a22e34d108da>#text(" Let ")#mi("{0 < \\varpi < 1/4}")#text(", ")#mi("{0 < \\delta \\leq \\delta^{\\prime} < 1/4 + \\varpi}")#text(", ")#mi("{A \\geq 0}")#text(", and ")#mi("{k_0 \\geq 2}")#text(" be such that")

#align(center)[#tao-fit-display[#mitex("(1 +4 \\varpi) (1-2\\kappa_1 - 2\\kappa_2 - 2\\kappa_3) > \\frac{j^2_{k_0-2}}{k_0(k_0-1)}")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("\\kappa_1  & := \\int_{\\theta}^1 (1-t)^{(k_0-1)/2}\\ \\frac{dt}{t}", block: true)



#tao-math("\\kappa_2  & := (k_0-1) \\int_{\\theta}^1 (1-t)^{k_0-1}\\ \\frac{dt}{t}", block: true)



#tao-math("\\kappa_3  & := e^A \\frac{G_{k_0-1,\\tilde \\theta}(0,0)}{G_{k_0-1}(0,0)} \\sum_{0 \\leq J \\leq 1/\\tilde \\delta} \\frac{(k_0-1)^J}{J!} (\\int_{\\tilde \\delta}^\\theta e^{-At} \\frac{dt}{t})^J", block: true)
]

#text("and")

#tao-aligned(keep: true)[


#tao-math("\\theta  & := \\frac{\\delta^{\\prime}}{1/4+\\varpi}", block: true)



#tao-math("\\tilde \\theta  & := \\frac{(\\delta^{\\prime} - \\delta)/2 + \\varpi}{1/4 + \\varpi}", block: true)



#tao-math("\\tilde \\delta  & := \\frac{\\delta}{1/4+\\varpi}", block: true)



#tao-math("G_{k_0-1}(0,0)  & := \\int_0^1 f(t)^2 \\frac{t^{k_0-2}}{(k_0-2)!}\\ dt", block: true)



#tao-math("G_{k_0-1,\\tilde \\theta}(0,0)  & := \\int_0^{\\tilde \\theta} f(t)^2 \\frac{t^{k_0-2}}{(k_0-2)!}\\ dt", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#mitex("f(t) := t^{1-k_0/2} J_{k_0-2}( \\sqrt{t} j_{k_0-2} ).")]]

#text("Then ")#mi("{MPZ^{\\prime}[\\varpi,\\delta]}")#text(" implies ")#mi("{DHL[k_0,2]}")#text(".")
]

#text("This theorem has rather messy constants, but we can isolate some special cases which are a bit easier to compute with. Setting ")#mi("{\\delta^{\\prime} = \\delta}")#text(", we see that ")#mi("{\\kappa_3}")#text(" vanishes (and the argument below will show that we only need ")#mi("{MPZ[\\varpi,\\delta]}")#text(" rather than ")#mi("{MPZ^{\\prime}[\\varpi,\\delta]}")#text("), and we obtain the following slight improvement of Theorem ")#link(<tao-ced2128f3bc92a5720f7>)[#text("3")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6")]#text(" ")#metadata(none) <tao-867be94271777b2bd5a2>#text(" Let ")#mi("{0 < \\varpi < 1/4}")#text(", ")#mi("{0 < \\delta < 1/4 + \\varpi}")#text(" and ")#mi("{k_0 \\geq 2}")#text(" be such that we have the inequality ")#metadata(none) <tao-603c4c0d45ea7a5573bd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("(1 +4 \\varpi) (1-2\\kappa_1-2\\kappa_2) > \\frac{j^2_{k_0-2}}{k_0(k_0-1)}")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("\\kappa_1  & := \\int_{4\\delta/(1+4\\varpi)}^1 (1-t)^{(k_0-1)/2}\\ \\frac{dt}{t}", block: true)



#tao-math("\\kappa_2  & := (k_0-1) \\int_{4\\delta/(1+4\\varpi)}^1 (1-t)^{k_0-1}\\ \\frac{dt}{t}.", block: true)
]

#text("Then ")#mi("{MPZ[\\varpi,\\delta]}")#text(" implies ")#mi("{DHL[k_0,2]}")#text(".")
]

#text("This is a little better than Theorem ")#link(<tao-ced2128f3bc92a5720f7>)[#text("3")]#text(", because the error ")#mi("{2\\kappa_1+2\\kappa_2}")#text(" has size about ")#mi("{\\frac{1}{2 k_0 \\delta} \\exp( - 2 k_0 \\delta) + \\frac{1}{2 \\delta} \\exp(-4 k_0 \\delta)}")#text(", which compares favorably with the error in Theorem ")#link(<tao-ced2128f3bc92a5720f7>)[#text("3")]#text(" which is about ")#mi("{\\frac{1}{\\delta} \\exp(-2 k_0 \\delta)}")#text(". This should already give a “cheap” improvement to our current threshold ")#mi("{k_0 \\geq 6329}")#text(", though it will fall short of what one would get if one fully optimised over all parameters in the above theorem.")

#text("Returning to the full strength of Theorem ")#link(<tao-ae861ab4a22e34d108da>)[#text("5")]#text(", let us obtain a crude upper bound for ")#mi("{\\kappa_3}")#text(" that is a little simpler to understand. Extending the ")#mi("{J}")#text(" summation to infinity and using the Taylor series for the exponential, we have")

#align(center)[#tao-fit-display[#mitex("\\kappa_3 \\leq \\frac{G_{k_0-1,\\tilde \\theta}(0,0)}{G_{k_0-1}(0,0)} \\exp( A + (k_0-1) \\int_{\\tilde \\delta}^\\theta e^{-At} \\frac{dt}{t} ).")]]

#text("We can crudely bound")

#align(center)[#tao-fit-display[#mitex("\\int_{\\tilde \\delta}^\\theta e^{-At} \\frac{dt}{t} \\leq \\frac{1}{A \\tilde \\delta}")]]

#text("and then optimise in ")#mi("{A}")#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("\\kappa_3 \\leq \\frac{G_{k_0-1,\\tilde \\theta}(0,0)}{G_{k_0-1}(0,0)} \\exp( 2 (k_0-1)^{1/2} \\tilde \\delta^{-1/2} ).")]]

#text("Because of the ")#mi("{t^{k_0-2}}")#text(" factor in the integrand for ")#mi("{G_{k_0-1}}")#text(" and ")#mi("{G_{k_0-1,\\tilde \\theta}}")#text(", we expect the ratio ")#mi("{\\frac{G_{k_0-1,\\tilde \\theta}(0,0)}{G_{k_0-1}(0,0)}}")#text(" to be of the order of ")#mi("{\\tilde \\theta^{k_0-1}}")#text(", although one will need some theoretical or numerical estimates on Bessel functions to make this heuristic more precise. Setting ")#mi("{\\tilde \\theta}")#text(" to be something like ")#mi("{1/2}")#text(", we get a good bound here as long as ")#mi("{\\tilde \\delta \\gg 1/k_0}")#text(", which at current values of ")#mi("{\\delta, k_0}")#text(" is a mild condition.")

#text("Pintz’s argument uses the elementary Selberg sieve, discussed in ")#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/")[#text("this previous post")]#text(", but with a more efficient estimation of the quantity ")#mi("{\\beta}")#text(", in particular avoiding the truncation to moduli ")#mi("{d}")#text(" between ")#mi("{x^{-\\delta} R}")#text(" and ")#mi("{R}")#text(" which was the main source of inefficiency in that previous post. The basic idea is to “linearise” the effect of the truncation of the sieve, so that this contribution can be dealt with by the union bound (basically, bounding the contribution of each large prime one at a time). This mostly avoids the more complicated combinatorial analysis that arose in the analytic Selberg sieve, as seen in ")#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/")[#text("this previous post")]#text(".")

#metadata(none) <tao-f4625d39a76520e00c26>

#heading(level: 1)[#strong[#text(" — 1. Review of previous material — ")]]

#text("In this section we collect some results from previous posts which we will need.")

#text("We first record an asymptotic for multiplicative functions. For any natural number ")#mi("{k}")#text(", define a ")#emph[#mi("{k}")#text("-dimensional multiplicative function")]#text(" to be a multiplicative function ")#mi("{f: {\\bf N} \\rightarrow {\\bf R}}")#text(" which obeys the asymptotic")

#align(center)[#tao-fit-display[#mitex("f(p) = k + O(\\frac{1}{p})")]]

#text("for all ")#mi("{p>w}")#text(". The following result is Lemma 8 from ")#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/")[#text("this previous post")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7")]#text(" ")#metadata(none) <tao-30b84cf23324188a95ee>#text(" Let ")#mi("{I = (w,+\\infty)}")#text(". Let ")#mi("{k}")#text(" be a fixed positive integer, and let ")#mi("{f: {\\bf N} \\rightarrow {\\bf R}}")#text(" be a multiplicative function of dimension ")#mi("{k}")#text(". Then for any fixed compactly supported, Riemann-integrable function ")#mi("{g: {\\bf R} \\rightarrow {\\bf R}}")#text(", and any ")#mi("{R>x^c}")#text(" for some fixed ")#mi("{c>0}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\in {\\mathcal S}_I} \\frac{f(d)}{d} g(\\frac{\\log d}{\\log R}) = (\\frac{\\phi(W)}{W} \\log R)^k ( \\int_0^\\infty g(t) \\frac{t^{k-1}}{(k-1)!}\\ dt + o(1) ).")]]
]

#text("Next, we record a criterion for ")#mi("{DHL[k_0,2]}")#text(", which is Lemma 7 from ")#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/")[#text("this previous post")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8 (Criterion for DHL)")]#text(" ")#metadata(none) <tao-d5963d22f572ba25cba0>#text(" Let ")#mi("{k_0 \\geq 2}")#text(". Suppose that for each fixed admissible ")#mi("{k_0}")#text("-tuple ")#mi("{{\\mathcal H}}")#text(" and each congruence class ")#mi("{b\\ (W)}")#text(" such that ")#mi("{b+h}")#text(" is coprime to ")#mi("{W}")#text(" for all ")#mi("{h \\in {\\mathcal H}}")#text(", one can find a non-negative weight function ")#mi("{\\nu: {\\bf N} \\rightarrow {\\bf R}^+}")#text(", fixed quantities ")#mi("{\\alpha,\\beta > 0}")#text(", a quantity ")#mi("{B>0}")#text(", and a fixed positive power ")#mi("{R}")#text(" of ")#mi("{x}")#text(" such that one has the upper bound ")#metadata(none) <tao-e8bc163c82eee1873328>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{x \\leq n \\leq 2x: n = b\\ (W)} \\nu(n) \\leq (\\alpha+o(1)) B\\frac{x}{W},")]]

#text("the lower bound ")#metadata(none) <tao-ad328846aa18b32a3358>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{x \\leq n \\leq 2x: n = b\\ (W)} \\nu(n) \\theta(n+h_i) \\geq (\\beta-o(1)) B\\frac{x}{W} \\log R")]]

#text("for all ")#mi("{h_i \\in {\\mathcal H}}")#text(", and the key inequality ")#metadata(none) <tao-2c70e12b7a0646f92279>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\frac{\\log R}{\\log x} > \\frac{1}{k_0} \\frac{\\alpha}{\\beta}")]]

#text("holds. Then ")#mi("{DHL[k_0,2]}")#text(" holds. Here ")#mi("{\\theta(n)}")#text(" is defined to equal ")#mi("{\\log n}")#text(" when ")#mi("{n}")#text(" is prime and ")#mi("{0}")#text(" otherwise.")
]

#heading(level: 1)[#strong[#text(" — 2. Pintz’s argument — ")]]

#text("We can now prove Theorem ")#link(<tao-ae861ab4a22e34d108da>)[#text("5")]#text(". Fix ")#mi("{\\varpi,\\delta,\\delta^{\\prime},k_0}")#text(" to obey the hypotheses of this theorem. Let ")#mi("{b\\ (W)}")#text(" be a congruence class with ")#mi("{b+h}")#text(" coprime to ")#mi("{W}")#text(" for all ")#mi("{h \\in {\\mathcal H}}")#text(" (this class exists by the admissibility of ")#mi("{{\\mathcal H}}")#text("). We apply Lemma ")#link(<tao-d5963d22f572ba25cba0>)[#text("8")]#text(" with")

#align(center)[#tao-fit-display[#mitex("B := (\\frac{\\phi(W)}{W} \\log R)^{k_0}")]]

#text("the elementary Selberg sieve ")#mi("{\\nu = \\nu_{\\mathcal X}}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("\\nu(n) := (\\sum_{d \\in {\\mathcal S}_{(w,+\\infty)}: d|P(n)} \\mu(d) a_d)^2")]]

#text("where ")#metadata(none) <tao-7e9e5ac30f2216fd0fd6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("a_d := \\frac{1}{\\Phi(d) \\Delta(d)} \\sum_{q \\in {\\mathcal S}_{(w,+\\infty)}: (q,d)=1; qd \\in {\\mathcal X}} \\frac{1}{\\Phi(q)} f^{\\prime}( \\frac{\\log dq}{\\log R} ),")]]

#mi("{\\Phi, \\Delta}")#text(" are the multiplicative functions")

#align(center)[#tao-fit-display[#mitex("\\Phi(d) := \\prod_{p|d} \\frac{p-k_0}{k_0}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\Delta(d) :=\\prod_{p|d} \\frac{k_0}{p},")]]

#text("the sieve level ")#mi("{R}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("R := x^{1/4 + \\varpi},")]]

#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a fixed smooth function supported on ")#mi("{[-1,1]}")#text(", and ")#mi("{{\\mathcal X}}")#text(" is a certain subset of ")#mi("{{\\mathcal S}_{(w,+\\infty)}}")#text(" to be chosen shortly. (The constraints ")#mi("{q \\in {\\mathcal S}_{(w,+\\infty)}}")#text(" and ")#mi("{(q,d)=1}")#text(" are redundant given that ")#mi("{qd \\in {\\mathcal X}}")#text(", but we retain them for emphasis.) We will assume that ")#mi("{f}")#text(" non-negative and non-increasing on ")#mi("{[0,1]}")#text(". In ")#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/")[#text("this previous post")]#text(", we considered this sieve with ")#mi("{{\\mathcal X}}")#text(" equal to either all of ")#mi("{{\\mathcal S}_{(w,+\\infty)}}")#text(", or the subset ")#mi("{{\\mathcal S}_{(w,x^\\delta)}}")#text(" consisting of smooth numbers. For now, we will discuss the estimates as far as we can without having to explicitly specify ")#mi("{{\\mathcal X}}")#text(".")

#text("We first consider the asymptotic ")#link(<tao-e8bc163c82eee1873328>)[#text("(5)")]#text(". By arguing exactly as in Section 2 (or Section 3) of ")#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/")[#text("this previous post")]#text(", we can write the left-hand side of ")#link(<tao-e8bc163c82eee1873328>)[#text("(5)")]#text(", up to errors of ")#mi("{o(B \\frac{x}{W})}")#text(", as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_0 \\in {\\mathcal X}} \\frac{1}{\\Phi(d_0)} f^{\\prime}(\\frac{\\log d_0}{\\log R})^2.")]]

#text("The summand here is non-negative, so we may crudely replace ")#mi("{{\\mathcal X}}")#text(" by all of ")#mi("{{\\mathcal S}_{(w,+\\infty)}}")#text(" and apply Lemma ")#link(<tao-30b84cf23324188a95ee>)[#text("7")]#text(" to obtain ")#link(<tao-e8bc163c82eee1873328>)[#text("(5)")]#text(" with")

#align(center)[#tao-fit-display[#mitex("\\alpha := \\int_0^1 f^{\\prime}(t)^2 \\frac{t^{k_0-1}}{(k_0-1)!}\\ dt.")]]

#text("Now we turn to the more difficult asymptotic ")#link(<tao-ad328846aa18b32a3358>)[#text("(6)")]#text(". The left-hand side expands as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2 \\in {\\mathcal S}_I} \\mu(d_1) a_{d_1} \\mu(d_2) a_{d_2} \\sum_{x \\leq n \\leq 2x: [d_1,d_2] | P(n); n = b\\ (W)} \\theta(n+h_i).")]]

#text("As observed in Section 2 of ")#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/")[#text("this previous post")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq 2x: [d_1,d_2] | P(n); n = b\\ (W)} \\theta(n+h) = \\frac{1}{\\phi(W)} x \\Delta^*([d_1,d_2]) + O( E^*([d_1,d_2]) )")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\Delta^*(q) := \\prod_{p|q} \\frac{k_0-1}{p-1}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("E^*(q) = \\sum_{a \\in C_i(q)} | \\sum_{x \\leq n \\leq 2x: n=b\\ (W); n = a\\ (q)} \\theta(n) - \\frac{x}{\\phi(Wq)}|.")]]

#text("Now let ")#mi("{\\epsilon>0}")#text(" be a small fixed constant to be chosen later, and suppose the following claim holds:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Claim 1 (Dense divisibility of moduli)")]#text(" ")#metadata(none) <tao-09f20eb14937cacb327f>#text(" Whenever ")#mi("{q = [d_1,d_2]}")#text(" and ")#mi("{a_{d_1},a_{d_2}}")#text(" are non-zero, then either ")#mi("{q \\leq x^{1/2-\\epsilon}}")#text(" or else ")#mi("{q \\in {\\mathcal D}_{x^\\delta}}")#text(".")
]

#text("Then from the Bombieri-Vinogradov theorem (for the ")#mi("{q \\leq x^{1/2-\\epsilon}}")#text(" moduli) or the hypothesis ")#mi("{MPZ^{\\prime}[\\varpi,\\delta]}")#text(" (for the larger moduli, noting that ")#mi("{q \\leq R^2 = x^{1/2+2\\varpi}}")#text(") and standard arguments (cf. Proposition 5 of ")#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/")[#text("this post")]#text(") we have")

#align(center)[#tao-fit-display[#mitex("\\sum_q h(q) E^*(q) \\ll x \\log^{-A} x")]]

#text("for any fixed ")#mi("{A>0}")#text(" and any multiplicative function ")#mi("{h}")#text(" of a fixed dimension ")#mi("{k}")#text(", where ")#mi("{q}")#text(" ranges only over those integers of the form ")#mi("{q=[d_1,d_2]}")#text(" with ")#mi("{a_{d_1},a_{d_2}}")#text(" non-zero. From this we easily see (arguing as in Section 2 of ")#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/")[#text("this previous post")]#text(") that the contribution of the ")#mi("{E^*}")#text(" error term is ")#mi("{o( B \\frac{x}{W}\\log R)}")#text(", and we are left with establishing the lower bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2 \\in {\\mathcal S}_{(w,\\infty)}} \\mu(d_1) a_{d_1} \\mu(d_2) a_{d_2} \\Delta^*([d_1,d_2])")]]

#align(center)[#tao-fit-display[#mitex("\\geq \\beta (\\frac{\\phi(W)}{W} \\log R)^{k_0+1}")]]

#text("up to errors of ")#mi("{o( (\\frac{\\phi(W)}{W} \\log R)^{k_0+1} )}")#text(" (henceforth referred to as ")#emph[#text("negligible errors")]#text(").")

#text("As in Section 2 of the ")#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/")[#text("previous post")]#text(", we can write the left-hand side as ")#metadata(none) <tao-e8d0d04fea35d6890558>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\sum_{d_0 \\in {\\mathcal S}_{(w,\\infty)}} \\frac{h(d_0)}{d_0} (\\sum_{m \\in {\\mathcal S}_{(w,\\infty)}: (m,d_0)=1; md_0 \\in {\\mathcal X}} \\frac{f^{\\prime}(\\frac{\\log d_0 m}{\\log R})}{\\phi(m)} )^2")]]

#text("where ")#mi("{h}")#text(" is the ")#mi("{k_0-1}")#text("-dimensional multiplicative function")

#align(center)[#tao-fit-display[#mitex("h(d) := \\prod_{p|d} (k_0-1) \\frac{(p-1)^2}{p(p-k_0)}.")]]

#text("So we would like to select ")#mi("{{\\mathcal X}}")#text(" small enough that Claim ")#link(<tao-09f20eb14937cacb327f>)[#text("(1)")]#text(" holds, but large enough that we can lower bound ")#link(<tao-e8d0d04fea35d6890558>)[#text("(9)")]#text(" by ")#mi("{\\beta (\\frac{\\phi(W)}{W} \\log R)^{k_0+1}}")#text(" up to negligible errors.")

#text("Pintz’s idea is to choose ")#mi("{{\\mathcal X}}")#text(" to be the set of all elements ")#mi("{d}")#text(" of ")#mi("{{\\mathcal S}_{(w,x^{\\delta^{\\prime}})}}")#text(" with the property that ")#metadata(none) <tao-5154ed9edd766c720bf7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\prod_{p|d:p < x^\\delta} p \\geq x^{(\\delta^{\\prime} - \\delta)/2 + \\varpi + \\epsilon/2}.")]]

#text("Let us first verify Claim ")#link(<tao-09f20eb14937cacb327f>)[#text("1")]#text(" with this definition. Suppose that ")#mi("{a_{d_1}, a_{d_2}}")#text(" is non-zero, then from ")#link(<tao-7e9e5ac30f2216fd0fd6>)[#text("(8)")]#text(" and the support of ")#mi("{f}")#text(" there are multiples ")#mi("{d_1r_1}")#text(", ")#mi("{d_2r_2}")#text(" of ")#mi("{d_1}")#text(", ")#mi("{d_2}")#text(" respectively with ")#mi("{d_1r_1,d_2r_2 \\in {\\mathcal X}}")#text(" (in particular ")#mi("{d_1,d_2,r_1,r_2 \\in {\\mathcal S}_{(w,x^{\\delta^{\\prime}})}}")#text(") and ")#mi("{d_1r_1, d_2 r_2 \\leq x^{1/4 + \\varpi}}")#text(". Since ")#mi("{d_1r_1 \\in {\\mathcal X}}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\prod_{p|d_1 r_1: p < x^\\delta} p \\geq x^{(\\delta^{\\prime} - \\delta)/2 + \\varpi + \\epsilon/2}")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("r_1 \\prod_{p|d_1: p < x^\\delta} p \\geq x^{(\\delta^{\\prime} - \\delta)/2 + \\varpi + \\epsilon/2}.")]]

#text("Similarly for ")#mi("{r_2}")#text(" and ")#mi("{d_2}")#text(". Multiplying, we obtain")

#align(center)[#tao-fit-display[#mitex("r_1 r_2 (d_1,d_2) \\prod_{p|[d_1,d_2]: p < x^\\delta} p \\geq x^{\\delta^{\\prime} - \\delta + 2\\varpi + \\epsilon}.")]]

#text("On the other hand,")

#align(center)[#tao-fit-display[#mitex("r_1 r_2 d_1 d_2 \\leq x^{1/4+\\varpi} x^{1/4+\\varpi}")]]

#text("and so on dividing we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{[d_1,d_2]} \\prod_{p|[d_1,d_2]: p < x^\\delta} p \\geq x^{-1/2 + \\delta^{\\prime} - \\delta + \\epsilon}.")]]

#text("We conclude that either ")#mi("{q := [d_1,d_2]}")#text(" is less than ")#mi("{x^{1/2-\\epsilon}}")#text(", or else ")#metadata(none) <tao-c35b21d6ca39aa7cc3b7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\prod_{p|[d_1,d_2]: p < x^\\delta} p \\geq x^{\\delta^{\\prime} - \\delta}.")]]

#text("The latter conclusion implies that ")#mi("{q}")#text(" is ")#mi("{x^\\delta}")#text("-densely divisible. Indeed, for any ")#mi("{1 \\leq R \\leq q}")#text(" we multiply together all the prime divisors of ")#mi("{q}")#text(" between ")#mi("{x^\\delta}")#text(" and ")#mi("{x^{\\delta^{\\prime}}}")#text(" one at a time until just before one reaches or exceeds ")#mi("{R}")#text(", or if one runs out of such prime divisors. In the former case one ends up at least as large as ")#mi("{x^{-\\delta^{\\prime}} R}")#text(", and in the latter case one has reached ")#mi("{q / \\prod_{p|q: p<x^\\delta} p}")#text(". Next, one multiplies to this the prime divisors of ")#mi("{q}")#text(" less than ")#mi("{x^\\delta}")#text(" until one reaches or exceeds ")#mi("{x^{-\\delta} R}")#text("; this is possible thanks to ")#link(<tao-c35b21d6ca39aa7cc3b7>)[#text("(11)")]#text(" in the former case and is automatic in the latter case, and gives a divisor between ")#mi("{x^{-\\delta} R}")#text(" and ")#mi("{R}")#text(" as required.")

#text("Now we need to obtain a lower bound for ")#link(<tao-e8d0d04fea35d6890558>)[#text("(9)")]#text(". If we write")

#align(center)[#tao-fit-display[#mitex("F(d_0) := \\sum_{m \\in {\\mathcal S}_{(w,\\infty)}: (m,d_0)=1} \\frac{-f^{\\prime}(\\frac{\\log d_0 m}{\\log R})}{\\phi(m)}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\tilde F(d_0) := \\sum_{m \\in {\\mathcal S}_{(w,\\infty)}: (m,d_0)=1; md_0 \\in {\\mathcal X}} \\frac{-f^{\\prime}(\\frac{\\log d_0 m}{\\log R})}{\\phi(m)}")]]

#text("(the minus sign being to compensate for the non-positive nature of ")#mi("{f^{\\prime}}")#text(") then we have")

#align(center)[#tao-fit-display[#mitex("0\\leq \\tilde F(d_0) \\leq F(d_0)")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\tilde F(d_0)^2 \\geq F(d_0)^2 - 2 F(d_0) (F(d_0)-\\tilde F(d_0)).")]]

#text("Note that this inequality replaces the quadratic expression ")#mi("{\\tilde F(d_0)^2}")#text(" with a linear expression in the truncation error ")#mi("{F(d_0)-\\tilde F(d_0)}")#text(", which will be more tractable for computing the effect of that error. We may thus lower bound ")#link(<tao-e8d0d04fea35d6890558>)[#text("(9)")]#text(" by the difference of ")#metadata(none) <tao-689983d7f004e53530d4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\sum_{d_0 \\in {\\mathcal S}_{(w,\\infty)}} \\frac{h(d_0)}{d_0} F(d_0)^2")]]

#text("and ")#metadata(none) <tao-4a4aea713f99f3e1927f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("2 \\sum_{d_0 \\in {\\mathcal S}_{(w,\\infty)}} \\frac{h(d_0)}{d_0} F(d_0) (F(d_0)-\\tilde F(d_0)).")]]

#text("In Section 2 of ")#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/")[#text("this post")]#text(" it is shown that")

#align(center)[#tao-fit-display[#mitex("F(d_0) = (\\frac{\\phi(W)}{W} \\log R) (f(\\frac{\\log d_0}{\\log R}) + O( \\frac{d_0}{\\phi(d_0)}-1 ) + o(1) ),")]]

#text("which implies that ")#link(<tao-689983d7f004e53530d4>)[#text("(12)")]#text(" is equal to")

#align(center)[#tao-fit-display[#mitex("(\\frac{\\phi(W)}{W} \\log R)^{k_0+1} \\int_0^1 f(t)^2 \\frac{t^{k_0-2}}{(k_0-2)!}\\ dt")]]

#text("up to negligible errors. Similar considerations show that ")#link(<tao-4a4aea713f99f3e1927f>)[#text("(13)")]#text(" is equal to ")#metadata(none) <tao-7223315e8e57664ea776>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("2 (\\frac{\\phi(W)}{W} \\log R) \\sum_{d_0 \\in {\\mathcal S}_{(w,\\infty)}} \\frac{h(d_0)}{d_0} f(\\frac{\\log d_0}{\\log R}) (F(d_0)-\\tilde F(d_0))")]]

#text("up to negligible errors. To upper bound ")#link(<tao-7223315e8e57664ea776>)[#text("(14)")]#text(", we need to upper bound")

#align(center)[#tao-fit-display[#mitex("F(d_0)-\\tilde F(d_0) = \\sum_{m \\in {\\mathcal S}_{(w,\\infty)}: (m,d_0)=1; md_0 \\not \\in {\\mathcal X}} \\frac{-f^{\\prime}(\\frac{\\log d_0 m}{\\log R})}{\\phi(m)}.")]]

#text("For this we need to catalog the ways in which ")#mi("{md_0}")#text(" can fail to be in ")#mi("{{\\mathcal X}}")#text(". In order for this to occur, at least one of the following three statements must hold:")

#list(
[#text("(i) ")#mi("{m}")#text(" could be divisible by a prime ")#mi("{p}")#text(" with ")#mi("{x^{\\delta^{\\prime}} \\leq x \\leq R}")#text(".")],
[#text("(ii) ")#mi("{d_0}")#text(" could be divisible by a prime ")#mi("{p}")#text(" with ")#mi("{x^{\\delta^{\\prime}} \\le x \\leq R}")#text(".")],
[#text("(iii) ")#mi("{d_0}")#text(" lies in ")#mi("{{\\mathcal S}_{(w,x^{\\delta^{\\prime}})}}")#text(", but ")#mi("{\\prod_{p|d_0: p < x^\\delta} p < x^{(\\delta^{\\prime} - \\delta)/2 + \\varpi + \\epsilon/2}}")#text(".")]
)

#text("We consider the contributions of (i), (ii), (iii) to ")#link(<tao-7223315e8e57664ea776>)[#text("(14)")]#text(". We begin with the contribution of (i). This is bounded above by")

#align(center)[#tao-fit-display[#mitex("2 (\\frac{\\phi(W)}{W} \\log R) \\sum_{x^{\\delta^{\\prime}} \\leq p \\leq R} \\sum_{d_0 \\in {\\mathcal S}_{(w,\\infty)}} \\frac{h(d_0)}{d_0}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\in {\\mathcal S}_{(w,\\infty)}} \\frac{-f^{\\prime}(\\frac{\\log d_0 p m}{\\log R})}{\\phi(m)\\phi(p)}.")]]

#text("Applying Lemma ")#link(<tao-30b84cf23324188a95ee>)[#text("7")]#text(", one can simplify this modulo negligible errors as")

#align(center)[#tao-fit-display[#mitex("2 (\\frac{\\phi(W)}{W} \\log R)^2 \\sum_{x^{\\delta^{\\prime}} \\leq p \\leq R} \\frac{1}{\\phi(p)} \\sum_{d_0 \\in {\\mathcal S}_{(w,\\infty)}} \\frac{h(d_0)}{d_0} f(\\frac{\\log d_0}{\\log R}) f( \\frac{\\log d_0}{\\log R} + \\frac{\\log p}{\\log R} )")]]

#text("which by another application of Lemma ")#link(<tao-30b84cf23324188a95ee>)[#text("7")]#text(" is equal to")

#align(center)[#tao-fit-display[#mitex("2 (\\frac{\\phi(W)}{W} \\log R)^{k_0+1} \\sum_{x^{\\delta^{\\prime}} \\leq p \\leq R} \\frac{1}{\\phi(p)} G_{k_0-1}( 0, \\frac{\\log p}{\\log R})")]]

#text("where we adopt the notation")

#align(center)[#tao-fit-display[#mitex("G_{k_0-1}(t_1,t_2) := \\int_0^1 f(t+t_1) f(t+t_2) \\frac{t^{k_0-2}}{(k_0-2)!}\\ dt.")]]

#text("Applying Mertens’ theorem and summation by parts, this expression is equal up to negligible errors to")

#align(center)[#tao-fit-display[#mitex("2 (\\frac{\\phi(W)}{W} \\log R)^{k_0+1} \\int_{\\theta}^1 G_{k_0-1}(0,t)\\ \\frac{dt}{t}")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\theta := \\frac{\\log x^{\\delta^{\\prime}}}{\\log R} = \\frac{\\delta^{\\prime}}{1/4 + \\varpi}.")]]

#text("Now we turn to the contribution of (ii) to ")#link(<tao-7223315e8e57664ea776>)[#text("(14)")]#text(". This is bounded above by")

#align(center)[#tao-fit-display[#mitex("2 (\\frac{\\phi(W)}{W} \\log R) \\sum_{x^{\\delta^{\\prime}} \\leq p \\le R} \\frac{h(p)}{p} \\sum_{d_0 \\in {\\mathcal S}_{(w,\\infty)}} \\frac{h(d_0)}{d_0} f(\\frac{\\log pd_0}{\\log R}) F(pd_0).")]]

#text("By Lemma ")#link(<tao-30b84cf23324188a95ee>)[#text("7")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("F(pd_0) \\leq (\\frac{\\phi(W)}{W} \\log R) (f(\\frac{\\log pd_0}{\\log R}) + o(1) )")]]

#text("and so we may bound this contribution up to negligible errors by")

#align(center)[#tao-fit-display[#mitex("2 (\\frac{\\phi(W)}{W} \\log R)^2 \\sum_{x^{\\delta^{\\prime}} \\leq p \\leq R} \\frac{h(p)}{p} \\sum_{d_0 \\in {\\mathcal S}_{(w,\\infty)}} \\frac{h(d_0)}{d_0} f(\\frac{\\log pd_0}{\\log R})^2")]]

#text("which by Lemma ")#link(<tao-30b84cf23324188a95ee>)[#text("7")]#text(" again is equal (up to negligible errors) to")

#align(center)[#tao-fit-display[#mitex("2 (\\frac{\\phi(W)}{W} \\log R)^{k_0+1} \\sum_{x^{\\delta^{\\prime}} \\leq p \\leq R} \\frac{h(p)}{p} G_{k_0-1}( \\frac{\\log p}{\\log R}, \\frac{\\log p}{\\log R} ).")]]

#text("By definition, ")#mi("{h(p) = k_0-1 + o(1)}")#text(". By Mertens’ theorem, we can thus write the above expression up to negligible errors as")

#align(center)[#tao-fit-display[#mitex("2(k_0-1) (\\frac{\\phi(W)}{W} \\log R)^{k_0+1} \\int_\\theta^1 G_{k_0-1}(t,t)\\ \\frac{dt}{t}.")]]

#text("Finally, we turn to the contribution of case (iii) to ")#link(<tao-7223315e8e57664ea776>)[#text("(14)")]#text(". By Lemma ")#link(<tao-30b84cf23324188a95ee>)[#text("7")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("F(d_0) \\leq (\\frac{\\phi(W)}{W} \\log R) (f(\\frac{\\log d_0}{\\log R}) + o(1) )")]]

#text("so we may bound this contribution up to negligible errors by")

#align(center)[#tao-fit-display[#mitex("2 (\\frac{\\phi(W)}{W} \\log R)^2 \\sum_{d_0} \\frac{h(d_0)}{d_0} f(\\frac{\\log d_0}{\\log R})^2")]]

#text("where ")#mi("{d_0}")#text(" is as in case (iii).")

#text("We introduce the quantities")

#align(center)[#tao-fit-display[#mitex("\\tilde \\theta := \\frac{\\log x^{(\\delta^{\\prime} - \\delta)/2 + \\varpi + \\epsilon/2}}{\\log R} = \\frac{(\\delta^{\\prime} - \\delta)/2 + \\varpi + \\epsilon/2}{1/4+\\varpi}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\tilde \\delta := \\frac{\\log x^\\delta}{\\log R} = \\frac{\\delta}{1/4+\\varpi}")]]

#text("so that case (iii) consists of those ")#mi("{d_0}")#text(" in ")#mi("{{\\mathcal S}_{(w, R^\\theta)}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\prod_{p|d_0: p < R^{\\tilde \\delta}} p < R^{\\tilde \\theta}.")]]

#text("From the support of ")#mi("{F}")#text(" we may also take ")#mi("{d_0 \\leq R}")#text(". This implies that we may factor")

#align(center)[#tao-fit-display[#mitex("d_0 = p_1 \\ldots p_J d")]]

#text("for some primes")

#align(center)[#tao-fit-display[#mitex("R^{\\tilde \\delta} \\leq p_1 < \\ldots < p_J \\leq R^{\\theta}")]]

#text("and some ")#mi("{d \\leq R^{\\tilde \\theta}}")#text(" coprime to ")#mi("{p_1,\\ldots,p_J}")#text(", with")

#align(center)[#tao-fit-display[#mitex("0 \\leq J \\leq \\frac{1}{\\tilde \\delta}.")]]

#text("The contribution of this case may thus be bounded by")

#align(center)[#tao-fit-display[#mitex("2 (\\frac{\\phi(W)}{W} \\log R)^2 \\sum_{0 \\leq J \\leq \\frac{1}{\\tilde \\delta}} \\sum_{R^{\\tilde \\delta} \\leq p_1 < \\ldots < p_J \\leq R^\\theta} \\frac{h(p_1 \\ldots p_J)}{p_1 \\ldots p_J}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq R^{\\tilde \\theta}} \\frac{h(d)}{d} f(\\frac{\\log d p_1 \\ldots p_J}{\\log R})^2.")]]

#text("Evaluating the inner sum using Lemma ")#link(<tao-30b84cf23324188a95ee>)[#text("7")]#text(", we obtain (up to negligible errors)")

#align(center)[#tao-fit-display[#mitex("2 (\\frac{\\phi(W)}{W} \\log R)^{k_0+1} \\sum_{0 \\leq J \\leq \\frac{1}{\\tilde \\delta}} \\sum_{R^{\\tilde \\delta} \\leq p_1 < \\ldots < p_J \\leq R^\\theta} \\frac{h(p_1 \\ldots p_J)}{p_1 \\ldots p_J}")]]

#align(center)[#tao-fit-display[#mitex("G_{k_0-1,\\tilde \\theta}( \\frac{\\log p_1 \\ldots p_J}{\\log R}, \\frac{\\log p_1 \\ldots p_J}{\\log R})")]]

#text("where ")#mi("{G_{k_0-1,\\tilde \\theta}}")#text(" is a truncation of ")#mi("{G_{k_0-1}}")#text(":")

#align(center)[#tao-fit-display[#mitex("G_{k_0-1, \\tilde \\theta}(t_1,t_2) := \\int_0^{\\tilde \\theta} f(t+t_1) f(t+t_2) \\frac{t^{k_0-2}}{(k_0-2)!}\\ dt.")]]

#text("Again we have ")#mi("{h(p_1 \\ldots p_J) = (k_0-1)^J + o(1)}")#text(". By Mertens’ theorem we may write this (up to negligible errors) as")

#align(center)[#tao-fit-display[#mitex("2 (\\frac{\\phi(W)}{W} \\log R)^{k_0+1} \\sum_{0 \\leq J \\leq \\frac{1}{\\tilde \\delta}} (k_0-1)^J \\int_{\\tilde \\delta \\leq t_1 < \\ldots < t_J \\leq \\theta}")]]

#align(center)[#tao-fit-display[#mitex("G_{k_0-1,\\tilde \\theta}( t_1 + \\ldots + t_J, t_1 + \\ldots + t_J)\\ \\frac{dt_1 \\ldots dt_J}{t_1 \\ldots t_J}.")]]

#text("Putting all this together, we have obtained the lower bound ")#link(<tao-ad328846aa18b32a3358>)[#text("(6)")]#text(" with")

#align(center)[#tao-fit-display[#mitex("\\beta = G_{k_0-1}(0,0) (1 - 2\\kappa_1 - 2\\kappa_2 - 2\\kappa_3)")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("\\kappa_1  & := G_{k_0-1}(0,0)^{-1} \\int_{\\theta}^1 G_{k_0-1}(0,t)\\ \\frac{dt}{t}", block: true)



#tao-math("\\kappa_2  & := (k_0-1) G_{k_0-1}(0,0)^{-1} \\int_{\\theta}^1 G_{k_0-1}(t,t)\\ \\frac{dt}{t}", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\kappa_3 = G_{k_0-1}(0,0)^{-1} \\sum_{0 \\leq J \\leq \\frac{1}{\\tilde \\delta}} (k_0-1)^J \\int_{\\tilde \\delta \\leq t_1 < \\ldots < t_J \\leq \\theta}")]]

#align(center)[#tao-fit-display[#mitex("G_{k_0-1,\\tilde \\theta}( t_1 + \\ldots + t_J, t_1 + \\ldots + t_J)\\ \\frac{dt_1 \\ldots dt_J}{t_1 \\ldots t_J}.")]]

#text("We now place upper bounds on ")#mi("{\\kappa_1,\\kappa_2,\\kappa_3}")#text(". In ")#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/")[#text("this previous post")]#text(", the bounds")

#align(center)[#tao-fit-display[#mitex("G_{k_0-1}(0,t) \\leq (1-t)^{(k_0-1)/2} G_{k_0-1}(0,0)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("G_{k_0-1}(t,t) \\leq (1-t)^{k_0-1} G_{k_0-1}(0,0)")]]

#text("for ")#mi("{0 < t < 1}")#text(" are proven. Thus we have")

#tao-aligned(keep: true)[


#tao-math("\\kappa_1  & \\leq \\int_{\\theta}^1 (1-t)^{(k_0-1)/2}\\ \\frac{dt}{t}", block: true)



#tao-math("\\kappa_2  & \\leq (k_0-1) \\int_{\\theta}^1 (1-t)^{k_0-1}\\ \\frac{dt}{t}.", block: true)
]

#text("These are already quite small for ")#mi("{\\theta \\approx 1/2}")#text(", say, which would correspond to ")#mi("{\\delta^{\\prime} \\approx 1/8}")#text(".")

#text("For ")#mi("{\\kappa_3}")#text(" we will use the crude estimate")

#align(center)[#tao-fit-display[#mitex("G_{k_0-1,\\tilde \\theta}( t_1 + \\ldots + t_J, t_1 + \\ldots + t_J) \\leq G_{k_0-1,\\tilde \\theta}(0,0);")]]

#text("this may surely be improved, but we will not do so here to simplify the exposition. Then we may bound")

#align(center)[#tao-fit-display[#mitex("\\kappa_3 \\leq \\frac{G_{k_0-1,\\tilde \\theta}(0,0)}{G_{k_0-1}(0,0)} \\sum_{0 \\leq J \\leq 1/\\tilde \\delta} \\frac{(k_0-1)^J}{J!} (\\log \\frac{\\theta}{\\tilde \\delta})^J.")]]

#text("The point here is that the first term ")#mi("{\\frac{G_{k_0-1,\\tilde \\theta}(0,0)}{G_{k_0-1}(0,0)}}")#text(" is exponentially decaying in ")#mi("{k_0}")#text(", which can compensate for the second term if ")#mi("{1/\\tilde \\delta \\ll k_0}")#text(" which is currently the case in the regime of interest.")

#text("One can do a bit better than this. For any parameter ")#mi("{A\\geq 0}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("G_{k_0-1,\\tilde \\theta}( t_1 + \\ldots + t_J, t_1 + \\ldots + t_J) \\leq e^A e^{-A(t_1 + \\ldots + t_J)} G_{k_0-1,\\tilde \\theta}(0,0)")]]

#text("since the left-hand side vanishes for ")#mi("{t_1+\\ldots+t_J \\geq 1}")#text(". This gives the bound")

#align(center)[#tao-fit-display[#mitex("\\kappa_3 \\leq e^A \\frac{G_{k_0-1,\\tilde \\theta}(0,0)}{G_{k_0-1}(0,0)} \\sum_{0 \\leq J \\leq 1/\\tilde \\delta} \\frac{(k_0-1)^J}{J!} (\\int_{\\tilde \\delta}^\\theta e^{-At} \\frac{dt}{t})^J.")]]

#text("If we insert these bounds into ")#link(<tao-2c70e12b7a0646f92279>)[#text("(7)")]#text(", send ")#mi("{\\epsilon}")#text(" to zero, and optimise in ")#mi("{f}")#text(" using Theorem 14 from ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("this previous post")]#text(", we obtain Theorem ")#link(<tao-ae861ab4a22e34d108da>)[#text("5")]#text(".")

#heading(level: 1)[#text("Comments (82)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235117")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("Has anyone worked out the “cheap” gain k0 mentioned after Theorem 6? (or better, a fully optimized k0, but even a cheap gain will give those working on optimizing H(k0) something to play with — we’re not used to working with the same k0 for more than 2 days at time :)).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235124")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("If I typed it all correctly, ")#mi("\\omega=2/733")#text(" allows ")#mi("k_0=5937")#text(".")

#text("Bz(k)=k+1.85575708149*k^(1/3)+1.033150/k^(1/3);")#linebreak()#text(" DELTA(om)=(1/4-87*om)/17;")#linebreak()#text(" KAPPA1(om,k0)=local(d);d=DELTA(om);intnum(t=4*d/(1+4*om),1,(1-t)^((k0-1)/2)/t);")#linebreak()#text(" KAPPA2(om,k0)=local(d);\\")#linebreak()#text(" d=DELTA(om);(k0-1)*intnum(t=4*d/(1+4*om),1,(1-t)^((k0-1))/t);")

#text("INEQ(om,k0)=(1+4*om)*(1-2*KAPPA1(om,k0)-2*KAPPA2(om,k0))-Bz(k0-2)^2/k0/(k0-1);")

#text("INEQ(2/733,5937)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235125")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235135")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("If I use the above ")#mi("\\kappa_3")#text(" bound and assume the ")#mi("G")#text("-quotient really is ")#mi("\\tilde\\theta^{k0-1}")#text(", I think that I get that ")#mi("\\omega=1/348-151/2000000")#text(" and ")#mi("\\delta^{\\prime}=\\delta+1/100")#text(" with ")#mi("\\delta")#text(" to satisfy the previous constraint, one can get ")#mi("k_0=5672")#text(". I should write a better program to optimize this though.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235141")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("From my other comment, I now think the G-quotient is going to be closer to ")#mi("\\exp( - k_0 (\\alpha - \\text{tanh} \\alpha + o(1) ))")#text(", where ")#mi("\\alpha := \\text{sech}^{-1} \\tilde \\theta")#text(". I can try to get more precise asymptotics for the ")#mi("o(1)")#text(" term, but perhaps it will be simpler just to compute the integral numerically (it will serve as a good sanity check to compare the numerics against the asymptotics though, and the asymptotics can give a rough idea of what region of parameter space to search in).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235144")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("In the range of interest, I seem to have ")#mi("\\kappa_3\\approx 10^{-4922}")#text(" and the other ")#mi("\\kappa")#text(" are also ")#mi("10^{-54}")#text(" and ")#mi("10^{-102}")#text(" respectively. So none of them matter. This assumes I am not making any errors or typos with formulas.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235145")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("I am really not sure where I came up with the above numbers, there is no obstacle to making ")#mi("\\omega")#text(" closer to 1/348. With the sech/tanh estimate (ignoring o(1)) I can take ")#mi("\\omega=1/348-9/2000000")#text(" and get ")#mi("k_0=5459")#text(" with ")#mi("\\delta^{\\prime}-\\delta=1/130")#text(", and ")#mi("\\kappa_3")#text(" is not of import again (make the delta-difference smaller if it is). I am not sure I trust all the numerics though (instability), but this is approaching the limit of previous analysis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235147")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("Looks like ")#mi("k-0=5456")#text(" with ")#mi("\\omega=1/348-7/2000000")#text(" and ")#mi("\\delta^{\\prime}-\\delta=1/300")#text(" works. If you try to take ")#mi("\\omega")#text(" smaller, then ")#mi("\\kappa_1")#text(" becomes not negligible, and you have the balance the delta-difference. Too hard to look at all parameters right now.")

#text("Ooops, looks like ")#mi("\\omega=1/348-5/2000000")#text(" and ")#mi("\\delta^{\\prime}-\\delta=1/800")#text(" and ")#mi("k_0=5454")#text(" works (with all ")#mi("\\kappa")#text(" in play).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235149")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("You can also make ")#mi("\\delta^{\\prime}-\\delta=1/900")#text(" in this last one, and then ")#mi("\\kappa_3")#text(" is irrelevant (")#mi("10^{-89}")#text(" in sech/tanh), while ")#mi("\\kappa_1")#text(" is then slightly bigger (5x), but not enough to vitiate key inequality.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235150")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("Managed to squeeze one more, ")#mi("\\omega=1/348-5.1/2000000")#text(" (larger than previous!) with a ")#mi("\\delta")#text("-difference of (say) ")#mi("1/750")#text(" allows ")#mi("k_0=5453")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235162")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("Slightly nicer form is ")#mi("k_0=5453")#text(" with ")#mi("\\omega=1/348-1/400000")#text(" and ")#mi("\\delta^{\\prime}-\\delta\\in [1/850,1/810]")#text(". I never checked that making ")#mi("\\delta")#text(" smaller than forced by ")#mi("\\omega")#text(" would not gain, but I don’t see why it would (probably follows by monotonicity).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235228")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("Cross-checking these computations with Maple. With ")#mi("k_0 = 5453")#text(" and ")#mi("\\varpi = 1/348 - 1/400000")#text(" we have ")#mi("\\delta = 87/6800000")#text(". Setting ")#mi("\\delta^{\\prime} := 1/820")#text(" (say) we have")

#mi("\\theta = 1740000 / 360796433")

#mi("\\tilde \\theta = 98909032 / 6133539361")

#mi("\\tilde \\delta = 7569 / 149598521")#text(".")

#text("We need ")#mi("2\\kappa_1+2\\kappa_2+2\\kappa_3")#text(" to not exceed")

#mi("1 - \\frac{j_{k_0-2}^2}{k_0(k_0-1) (1+4\\varpi)} = 0.3883 \\times 10^{-6}")#text(".")

#text("I get")

#mi("\\kappa_1 = 0.1336 \\times 10^{-6}")

#mi("\\kappa_2 = 0.7118 \\times 10^{-9}")

#text("which looks good so far. Now for ")#mi("\\kappa_3")#text(". Using the crude bound")

#mi("\\kappa_3 \\leq \\frac{G_{k_0-1,\\tilde \\theta}(0,0)}{G_{k_0-1}(0,0)} \\exp( 2(k_0-1)^{1/2} \\tilde \\theta^{-1/2} )")

#text("the exponential factor here is ")#mi("0.111 \\times 10^{506}")#text(", which looks scary. On the other hand, the G-ratio here is predicted to be roughly")

#mi("\\exp( - 2 k_0 ( \\alpha-\\tanh(\\alpha) ) ) \\approx 0.7615 \\times 10^{-8340}")

#text("with ")#mi("\\text{sech}(\\alpha) = \\tilde \\theta^{1/2}")#text(" (I made a slight mistake earlier in not having the square root and factor of 2 here but it fortunately turns out not to matter), and this is is completely negligible. In order to get an independent confirmation of the smallness of the G-ratio is, the Bessel function ")#mi("J_{k_0-2}")#text(" at ")#mi("\\sqrt{\\tilde \\theta} j_{k_0-2}")#text(" takes the value ")#mi("0.1805 \\times 10^{-4156}")#text(", and at ")#mi("0.999 j_{k_0-2}")#text(" takes the value ")#mi("0.0187")#text(", so it looks abundantly clear that the G-ratio is indeed ridiculously small in this regime.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235284")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("You have an error in your ")#mi("\\kappa_3")#text(" expression in the Maple check, it is ")#mi("\\tilde\\delta")#text(" in the denominator of the sqrt inside the exp, not ")#mi("\\tilde\\theta")#text(". I think the sech-sqrt fix breaks ")#mi("k_0=5453")#text(", I will check.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235306")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("Oops, sorry about that. Well, one can hope to squeeze something out of the full version of Theorem 5 (or at least the first display after Theorem 5) in which there is also the A parameter to optimise over. One can probably pick up some other ways to make the estimate for ")#mi("\\kappa_3")#text(" more efficient, but at the cost of simplicity. Pintz’s own notes have a slightly different way of estimating ")#mi("\\kappa_3")#text(", I can try to have a look at that instead.")

#text("There were two corrections I had to make; one (which worked against our favour) was the replacing of ")#mi("\\tilde \\theta")#text(" with its square root, but the other (which works for us) is the doubling of the exponential from ")#mi("\\exp( - k_0 (\\alpha - \\tanh(\\alpha)))")#text(" to ")#mi("\\exp( - 2k_0 (\\alpha - \\tanh(\\alpha)))")#text(". I had thought that the two effects roughly cancelled each other out, but I guess not quite…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235286")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("Currently, I can only get ")#mi("k_0=5455")#text(" with ")#mi("\\omega=1/348-6/2000000")#text(" and ")#mi("\\delta^{\\prime}\\in [1/720,1/900]")#text(". You can note the incredible impact that ")#mi("\\kappa_3")#text(" suddenly has if you change “6” to “5” in the numerator of the subtrahend of ")#mi("\\omega")#text(". So saving a few more in ")#mi("k_0")#text(" could occur from its more benevolent estimation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235311")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("I just realised that the estimate")

#mi("\\displaystyle \\int_{\\tilde \\delta}^{\\theta} e^{-At} \\frac{dt}{t} \\leq \\frac{1}{A \\tilde \\delta}")

#text("that I used below Theorem 6 can be improved to")

#mi("\\displaystyle \\int_{\\tilde \\delta}^{\\theta} e^{-At} \\frac{dt}{t} \\leq \\frac{e^{-A \\tilde \\delta}}{A \\tilde \\delta}")

#text("(by replacing ")#mi("\\theta")#text(" with infinity and replacing ")#mi("\\frac{1}{t}")#text(" with ")#mi("\\frac{1}{\\tilde \\delta}")#text("). This extra exponential factor makes it harder to optimise in A, but it should give a significant savings, hopefully enough to push back to 5453 and maybe even a bit further.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235131")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("I’m recording here some asymptotics of Bessel functions to help understand the ratio")

#mi("\\displaystyle \\frac{G_{k_0-1,\\tilde \\theta}(0,0)}{G_{k_0-1}(0,0)} = \\frac{\\int_0^{\\tilde \\theta^{1/2} j_{k_0-2}} J_{k_0-2}(x)^2 \\ x dx}{\\int_0^{j_{k_0-2}} J_{k_0-2}(x)^2\\ x dx}")#text(" (*)")

#text("in the regime where ")#mi("0 < \\tilde \\theta < 1")#text(" is fixed and ")#mi("k_0")#text(" is large. Here we have made the change of variable ")#mi("t = (x / j_{k_0-2})^2")#text(".")

#text("Write ")#mi("\\nu := k_0-2")#text(". By 9.3.23 of Abramowitz and Stegun (see e.g. ")#link("http://www.dam.brown.edu/people/mariom/AM282-01/HANDOUTS/Abramowitz_Stegun_Chapter_9.pdf")[#text("this link")]#text(") we have the asymptotic")

#mi("J_\\nu( \\nu + z \\nu^{1/3} ) = \\frac{2^{1/3}}{\\nu^{1/3}} \\text{Ai}(-2^{1/3} z) ( 1 + o(1) )")

#text("for bounded ")#mi("z")#text(", where ")#mi("\\text{Ai}")#text(" is the Airy function. This shows that the zero ")#mi("j_\\nu")#text(" has the asymptotic")

#mi("j_\\nu = \\nu + 2^{-1/3} c \\nu^{1/3} + o( \\nu^{1/3} )")

#text("where ")#mi("-c")#text(" is the first negative zero of the Airy function. It also suggests that")

#mi("\\int_0^{j_{k_0-2}} J_{k_0-2}(t)^2\\ t dt \\approx 2^{-2/3} \\nu^{-1/3} \\int_{-c}^\\infty \\text{Ai}( z )^2\\ dz")#text(".")

#text("Meanwhile, 9.3.7 of Abramowitz and Stegun (Debye asymptotic) tells us that")

#mi("J_\\nu( \\nu \\text{sech} \\alpha ) \\approx e^{\\nu( \\text{tanh} \\alpha - \\alpha + o(1) )}")

#text("for any ")#mi("\\alpha > 0")#text(" (this is also consistent with the exponential decay of the Airy function to the right), so if we set ")#mi("\\alpha := \\text{sech}^{-1} \\tilde \\theta")#text(" (EDIT: this should be ")#mi("\\alpha = \\text{sech}^{-1} \\tilde \\theta^{1/2}")#text("), the ratio (*) should take the form")

#mi("e^{\\nu(\\text{tanh} \\alpha - \\alpha + o(1)) }")

#text("(EDIT: this should be ")#mi("e^{2\\nu(\\text{tanh} \\alpha - \\alpha + o(1)) }")#text(") which is exponentially decaying in ")#mi("k_0")#text(" as claimed in the post. (Unfortunately, we cannot directly use these asymptotics to get explicit values of ")#mi("k_0")#text(" because we need control on the error terms, which standard sources (e.g. Abramowitz-Stegun) do not supply.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235294")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("Please note that the upper bound for the integration in the numerator is defined in theorem 5 to be ")#mi("\\tilde \\theta")#text(" (not its square), and in the presentation of Pintz argument it is defined (for a general pair")#linebreak()#text(" ")#mi("(t_1, t_2)")#text(") to be ")#mi("\\tilde \\delta")#text(", so it is not clear which is the correct one.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235299")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("In my last message I did not notice that the integrals are after change of variable, but I think that in the numerator ")#mi("\\tilde \\theta")#text(" should be replaced by its square root. And more importantly, the integral (at least for even ")#mi("k_0")#text(") can be precisely evaluated as a finite linear combination of squares of Bessel functions by finding the indefinite integral using the recursive formula (11.3.33) and the formula (11.3.34) in Abramowitz and Stegun.")#linebreak()#text(" (If there is a corresponding formula for ")#mi("k_0 - 2 = 1")#text(", then the recursive formula can be used to compute the integral for odd ")#mi("k_0")#text(" as well.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d1a093bb68b40e960ad9bfc4e71de74e9cc0573e03d2e3314b93b355061930b0-5a4dd96aa5b918292b80204227b5bf6760aa04d9ce0002d64afa73e047e4552d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of coco")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235206")[#strong[#text("coco")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("typo: divsibility -> divisibility, in second paragraph.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235214")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("The nonnegativity property I tried to prove in the previous thread (")#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/")[#text("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/")]#text(") is equivalent to")

#mi("\\langle \\alpha_0,\\alpha_0\\rangle_{t_1,\\dots,t_n}\\geq 0")#text(" for any ")#mi("0\\leq t_1,\\dots,t_n<1")#text(".")

#text("Unfortunately, SAGE found the following counterexample for ")#mi("k_0=2")#text(" and ")#mi("n=5")#text(":")

#mi("\\{t_1,t_2,t_3,t_4,t_5\\}=\\{0.20, 0.21, 0.24, 0.25, 0.31\\}")#text(".")

#text("More precisely, with these parameters we have")

#tao-math("\\sum_{\\{1,\\ldots,5\\} = S \\cup T} (-1)^{\\left|S \\cap T\\right|} \\min((1-\\sum_{i\\in S}t_i)_+^2,(1-\\sum_{i\\in T}t_i)_+^2)=-0.0824", block: false)#text(".")

#text("This result is verified by the SAGE commands")

#text("A={20/100, 21/100, 24/100, 25/100, 31/100}")

#text("print sum([((-1)^U.cardinality())*sum([min(max(0,1-sum(S.union(U))),max(0,1-sum(A.difference(S))))^2 for S in Subsets(A.difference(U))]) for U in Subsets(A)])")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235223")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("A minor technical point: there is one tiny way in which ")#mi("x^\\delta")#text("-densely divisible numbers are worse than ")#mi("x^\\delta")#text("-smooth numbers: the behaviour is not quite hereditary with respect to factors. If ")#mi("d=d_1 d_2")#text(" and ")#mi("d")#text(" is ")#mi("x^\\delta")#text("-smooth, then ")#mi("d_1")#text(" is automatically ")#mi("x^\\delta")#text("-smooth as well. On the other hand, if ")#mi("d")#text(" is merely ")#mi("x^\\delta")#text("-densely divisible, then ")#mi("d_1")#text(" is only ")#mi("x^\\delta d_2")#text("-densely divisible, there is a loss of ")#mi("d_2")#text(" (basically because ")#mi("d_2")#text(" could suck up all the useful small primes that are giving the dense divisibility property). This makes the Type III analysis a little more complicated as there is a part in which one forces the frequency parameter ")#mi("h")#text(" to be coprime to the modulus ")#mi("d")#text(" by Mobius inversion, dividing both ")#mi("h")#text(" and ")#mi("d")#text(" by the common factor ")#mi("(h,d)")#text(". However even with the worsening of ")#mi("x^\\delta")#text(" by ")#mi("(h,d)")#text(", one can check that the net power of ")#mi("(h,d)")#text(" remains favorable and the coprime case still dominates, so this is not actually an issue. (But something to look out for when we do the final writing up of the arguments.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235233")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("For reference, I have uploaded (with permission) Pintz’s original notes on this sieve here:")

#link("https://terrytao.files.wordpress.com/2013/06/file-1.pdf")[#text("Section 1")]

#link("https://terrytao.files.wordpress.com/2013/06/file-2.pdf")[#text("Section 2")]

#link("https://terrytao.files.wordpress.com/2013/06/file-3.pdf")[#text("Section 3")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235315")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("OK, I think with ")#mi("A=9500")#text(" and ")#mi("\\omega=1/348-5/2000000")#text(" and ")#mi("\\delta^{\\prime}=1/800")#text(" this now recovers ")#mi("k_0=5453")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235316")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("And ")#mi("\\omega=1/348-4/2000000")#text(" with ")#mi("\\delta^{\\prime}=1/820")#text(" seems to give ")#mi("k_0=5452")#text(" with the same ")#mi("A=9500")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235395")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("I verified that this works with the Maple code below (using crude upper and lower bounds on the Bessel integral after verifying that the Bessel function ")#mi("J_{k_0-2}")#text(" was decreasing from ")#mi("0.998 j_{k_0-2}")#text(" to ")#mi("0.999 j_{k_0-2}")#text(", and was on the other side of the maximum at ")#mi("\\sqrt{\\tilde \\theta} j_{k_0-2}")#text("). By using the ")#mi("\\kappa_3")#text(" bound in the display after Theorem 6 rather than perform any further estimations, there is actually a little bit of margin: ")#mi("2\\kappa_1+2\\kappa_2+2\\kappa_3")#text(" is allowed to be as large as ")#mi("0.100 \\times 10^{-5}")#text(" but is only of size ")#mi("0.269 \\times 10^{-6}")#text(", with ")#mi("\\kappa_1")#text(" dominating, ")#mi("\\kappa_2 \\approx 0.715 \\times 10^{-9}")#text(", and ")#mi("\\kappa_3 \\leq 10^{-2454}")#text(". It seems likely that we could squeeze ")#mi("k_0")#text(" by one or two more by changing the free parameters ")#mi("\\varpi, \\delta^{\\prime}, A")#text(" a bit, but it is very tight and I didn’t try too hard to do so.")

#linebreak()#text(" varpi := 1/348 - 4/2000000;")#linebreak()#text(" k0 := 5452;")#linebreak()#text(" deltap := 1/820;")#linebreak()#text(" A := 9500;")

#text("delta := (1/4 - 87 * varpi) / 17;")#linebreak()#text(" theta := deltap / (1/4 + varpi);")#linebreak()#text(" thetat := (deltap - delta + varpi) / (1/4 + varpi);")#linebreak()#text(" deltat := delta / (1/4 + varpi);")

#text("j := BesselJZeros(k0-2,1);")

#text("eps := 1 - j^2 / (k0 * (k0-1) * (1+4*varpi));")

#text("kappa1 := int( (1-t)^((k0-1)/2)/t, t = theta..1, numeric);")#linebreak()#text(" kappa2 := (k0-1) * int( (1-t)^(k0-1)/t, t=theta..1, numeric);")

#text("e := exp( A + (k0-1) * int( exp(-A*t)/t, t=deltat..theta, numeric ) );")

#text("s1 := BesselJ(k0-2,0.999*j);")#linebreak()#text(" s2 := BesselJ(k0-2,0.998*j);")#linebreak()#text(" s3 := BesselJ(k0-2,0.997*j);")

#text("# check that s3 > s2 > s1 to ensure Bessel function decreases from 0.998 j to 0.999 j")

#text("# crude lower bound on the denominator integral")#linebreak()#text(" gd := s1^2 * 0.001 * j * 0.998 * j;")

#text("# crude upper bound on the numerator integral")#linebreak()#text(" tn := sqrt(thetat)*j;")#linebreak()#text(" s0 := BesselJ(k0-2,tn);")#linebreak()#text(" gn := s0^2 * tn * tn / 2;")

#text("# check that s0 < s3 to ensure that Bessel function decreases up to tn (but this is true with massive amounts of room to spare)")

#text("kappa3 := (gn/gd) * e;")

#text("eps2 := 2*(kappa1+kappa2+kappa3);")

#text("# we win if eps2 < eps")#linebreak()
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91e58d71f0f6fed623003aa05efe0585d16ef93ffa28f35566bfb61f50623ecf-2a8a45a0582c8ce83139ff9a7a2fcc83164146aeb54123a9d43b62b9f617bd50.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of abqmathteacher")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235396")[#strong[#text("abqmathteacher")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("A quick nontechnical question. Any idea of the likelihood of pushing this line of reasoning down to H < 1476, the largest known (I think) \"maximal prime gap\" (see ")#link("http://oeis.org/A005250")[#text("http://oeis.org/A005250")]#text(", ")#link("http://oeis.org/A005250/a005250.txt")[#text("http://oeis.org/A005250/a005250.txt")]#text(")? That would be an exciting landmark.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235406")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("Actually it is known that prime gaps can be arbitrarily large. For instance, if n is a natural number, then ")#mi("n! + 2, n!+3,\\ldots,n!+n")#text(" are all composite, creating a prime gap of length at least ")#mi("n")#text(". I think 1476 may be the smallest H for which the location of the first prime gap of length H is known, though.")

#text("My feeling though is that we are going to run out of improvements before we reach that level; ")#mi("H=10^5")#text(" looks like a more realistic target at this stage.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91e58d71f0f6fed623003aa05efe0585d16ef93ffa28f35566bfb61f50623ecf-2a8a45a0582c8ce83139ff9a7a2fcc83164146aeb54123a9d43b62b9f617bd50.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of abqmathteacher")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235410")[#strong[#text("abqmathteacher")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("Thanks! Indeed the term “maximal prime gap” used in the OEIS entry is confusing, sorry to just quote it. It means “maximal gap for a given size integer”. So 1476 is (according to that table) the *largest* H for which the location of the first prime gap of length H is known.")#linebreak()#text(" Anyway, even H = 10^5 is quite exciting.")#linebreak()#text(" David Metzler")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2380268716865f468a949fe57fbe532e9739173bb8685765e945e8e531963a24-c57dcb97ed453df43d9d399af431c3fe01ed0c5795d7e100e23d0c7be3317f6e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235435")[#strong[#text("Dave")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("If I’m reading the polymath wiki correctly, isn’t the best known H value already below $10^5$?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235436")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("Er, sorry, I meant ")#mi("H = 10^4")#text(" would be a reasonable end target for this project. :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235440")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("1. If ")#mi("j_{k_0-2}^{\\prime}")#text(" denotes the first zero of ")#mi("J_{k_0-2}^{\\prime}(x)")#text(", then it is known that")

#mi("k_0-2<j_{k_0-2}^{\\prime}<j_{k_0-2}<\\sqrt{2}k_0")#text(",")

#text("see Section 15.3 in Watson: A treatise on the theory of Bessel functions (2nd ed., Cambridge University Press, 1944). Hence for ")#mi("\\tilde\\theta<\\frac{1}{3}")#text(" and ")#mi("k_0\\geq 11")#text(" we can bound")

#mi("\\int_0^{\\tilde \\theta^{1/2} j_{k_0-2}} J_{k_0-2}^2(x) \\ x dx<\\frac{1}{2}\\tilde\\theta j_{k_0-2}^2 J_{k_0-2}^2(\\tilde \\theta^{1/2} j_{k_0-2})")#text(".")

#text("On the other hand, by an orthogonality relation of Bessel functions (see ")#link("http://en.wikipedia.org/wiki/Bessel_function")[#text("Wikipedia")]#text(")")

#mi("\\int_0^{j_{k_0-2}} J_{k_0-2}^2(x)\\ x dx = j_{k_0-2}^2\\int_0^1 J_{k_0-2}^2(j_{k_0-2}t)\\ t dt")

#mi("=\\frac{1}{2}j_{k_0-2}^2 J_{k_0-1}^2(j_{k_0-2}).")

#text("It follows that")

#mi("\\frac{\\int_0^{\\tilde \\theta^{1/2} j_{k_0-2}} J_{k_0-2}^2(x) \\ x dx}{\\int_0^{j_{k_0-2}} J_{k_0-2}^2(x)\\ x dx} <\\tilde\\theta \\frac{J_{k_0-2}^2(\\tilde \\theta^{1/2} j_{k_0-2})}{J_{k_0-1}^2(j_{k_0-2})}")#text(".")

#text("SAGE tells me that for ")#mi("k_0=5452")#text(" and ")#mi("\\tilde \\theta = 98909032 / 6133539361")#text(" the right hand side is less than ")#mi("1.3836\\times 10^{-8309}")#text(".")

#text("2. Some misprints: \"analyhsis\", \"systetm\".")

#emph[#text("[Corrected, thanks. These calculations clean up the rather ad hoc Maple code I had previously! -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235442")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("Please note that if ")#mi("k_0")#text(" is even , than by formulas (11.3.33) and (11.3.34) in Abramowitz & Stegun both integrals can be expressed (and thereby precisely computed) as a simple finite linear combinations of squares of Bessel functions! (For odd k, one needs an analogous formula to (11.3.34) in which ")#mi("J_1(t)")#text(" replaces ")#mi("J_0(t)")#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235457")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("Thank you! Actually this works for ")#mi("J_\\nu")#text(" with any ")#mi("\\nu\\geq 0")#text(", see my latest comment below.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235454")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("Actually we can calculate the ratio")

#mi("\\frac{\\int_0^{\\tilde \\theta^{1/2} j_{k_0-2}} J_{k_0-2}^2(x) \\ x dx}{\\int_0^{j_{k_0-2}} J_{k_0-2}^2(x)\\ x dx}")

#text("explicitly in terms of Bessel values. According to Lemma 5.4 in Folland: Fourier analysis and its applications,")

#mi("\\int_0^b J_\\nu^2(x)\\ x dx=\\frac{b^2}{2}J_\\nu^{\\prime 2}(b)+\\frac{b^2-\\nu^2}{2}J_\\nu^2(b)")#text(" for any ")#mi("b>0")#text(" and ")#mi("\\nu\\geq 0")#text(",")

#text("where we can express ")#mi("J_\\nu^{\\prime}(x)")#text(" as ")#mi("J_{\\nu-1}(x)-J_{\\nu+1}(x)")#text(". Using this, SAGE now tells me (for ")#mi("k_0=5452")#text(" and ")#mi("\\tilde \\theta = 98909032 / 6133539361")#text(") that the numerator is ")#mi("\\approx 4.9217\\times 10^{-8311}")#text(", and the denominator is ")#mi("\\approx 1.9231\\times 10^2")#text(", so that")

#mi("\\frac{\\int_0^{\\tilde \\theta^{1/2} j_{k_0-2}} J_{k_0-2}^2(x) \\ x dx}{\\int_0^{j_{k_0-2}} J_{k_0-2}^2(x)\\ x dx}\\approx 2.5592\\times 10^{-8313}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235455")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("Small correction: “")#mi("J_\\nu^{\\prime}(x)")#text(" as ")#mi("J_{\\nu-1}(x)-J_{\\nu+1}(x)")#text("” should be “")#mi("J_\\nu^{\\prime}(b)")#text(" as ")#mi("\\frac{J_{\\nu-1}(b)-J_{\\nu+1}(b)}{2}")#text("“.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235460")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("Nice ! (such simple expression is quite surprising!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235486")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("It seems that there is a slightly simpler expression (for integer order n):")

#mi("\\int_{0}^{x} t J_n^2(t) dt =\\frac{x^2}{2}[J_n^2(x) -J_{n-1}(x)J_{n+1}(x)]")

#text("This is formula (8) in Auluck’s arxiv paper :")

#link("http://arxiv.org/abs/1006.4417")[#text("http://arxiv.org/abs/1006.4417")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235491")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("Very good. Actually this formula holds for all ")#mi("n\\geq 0")#text(" (not only for integers): it can be derived from Folland’s lemma, using ")#mi("2J_\\nu^{\\prime}(x)=J_{\\nu-1}(x)-J_{\\nu+1}(x)")#text(" and ")#mi("2\\nu J_\\nu=x(J_{\\nu-1}(x)+J_{\\nu+1}(x))")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235496")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("I think that it even holds (by analytic continuation) for all complex ")#mi("\\nu")#text(" (since the integrand is entire as a function of ")#mi("\\nu")#text(" for each fixed nonzero ")#mi("t")#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235564")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2013")])]

#text("Eytan: in extending the formula to all complex ")#mi("\\nu")#text(", one needs to be careful, e.g. one needs to check if the integral converges (hopefully locally uniformly, the difficulty coming from ")#mi("t\\approx 0")#text("). Already the extension of ")#mi("J_\\nu(x)")#text(" is tricky to all complex ")#mi("\\nu")#text(". Certainly everything is fine for ")#mi("\\Re(\\nu)>-\\frac{1}{2}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235574")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2013")])]

#text("I agree that the integral can’t be entire in ")#mi("\\nu")#text(", since for any fixed ")#mi("x > 0")#text(", (9.1.10) in A&S implies that the integral diverges as")#linebreak()#text(" ")#mi("\\nu")#text(" tends (from the right) to ")#mi("\\nu = -1")#text(" – which must therefore be a singular point for any analytic continuation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235578")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2013")])]

#text("Eytan: Right. Probably there is no problem for ")#mi("\\Re(\\nu)>-1")#text(", as the integral converges absolutely and locally uniformly there. I sticked to ")#mi("\\Re(\\nu)>-\\frac{1}{2}")#text(" just to be safe, because the definition beyond that range is less straightforward (according to Watson’s book). BTW I am also quite pleased and surprised that so many transparent features of Bessel functions play a role in this project. I come from automorphic forms where this phenomenon is wide-spread, but (I think) it is new for sieve theory where this project belongs.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235585")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2013")])]

#text("There is another interesting “sub-multiplicative” property of ")#mi("f_0")#text(" (shared also by many entire functions of order ")#mi("< 2")#text(") which is very useful for improving the current bounds on the ")#mi("\\kappa")#text("'s. (I'm preparing the details.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235569")[#strong[#text("Exciting real-time developments about prime numbers | Mountain of Math")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2013")]

#text("[…] I asked about this at Terry Tao’s blog, and he indicated that H = 10,000 would be a reasonable target for the polymath8 project. And in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235685")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("In the sum defining ")#mi("\\kappa_3")#text(", the sum variable J is upper bounded by ")#mi("1/ \\delta")#text(", but the original range of J (17 lines above) is")#linebreak()#text(" ")#mi("0 \\le J \\le 1/ \\tilde {\\delta}")#text(" . So it is not clear which upper bound for J is the correct one.")

#emph[#text("[The correct range is ")#mi("J \\leq 1/\\tilde \\delta")#text(". I was not able to locate any instance where ")#mi("1/\\delta")#text(" was used instead, although sometimes the tilde is almost obscured by the dividing bar between the numerator and denominator. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235710")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("1. I have difficulty in deriving the fourth display below (8), i.e. that the left hand side of (5) is up to negligible error")

#mi("\\sum_{d_0 \\in {\\mathcal X}} \\frac{1}{\\Phi(d_0)} f^{\\prime}(\\frac{\\log d_0}{\\log R})^2")#text(".")

#text("This formula should come from")

#mi("\\sum_{d_0 \\in {\\mathcal S}_I} \\Phi(d_0) (\\sum_{d \\in {\\mathcal S}_I: d_0|d} \\frac{\\mu(d)}{\\Phi(d)} \\sum_{q \\in {\\mathcal X}: (q,d) = 1} \\frac{1}{\\Phi(q)} f^{\\prime}( \\frac{\\log dq}{\\log R}))^2")#text(",")

#text("where ")#mi("I = (w,+\\infty)")#text(". Writing ")#mi("d = d_0 d_1")#text(" and ")#mi("m = d_1 q")#text(", the inner sum becomes")

#mi("\\frac{\\mu(d_0)}{\\Phi(d_0)} \\sum_{m \\in {\\mathcal S}_I: (m,d_0)=1} \\frac{f^{\\prime}(\\frac{\\log d_0 m}{\\log R})}{\\Phi(m)} \\sum_{d_1 | m; m/d_1\\in{\\mathcal X}} \\mu(d_1)")#text(".")

#text("Without the condition ")#mi("m/d_1\\in\\mathcal{X}")#text(" in the innermost sum, we would get in the end")

#mi("\\sum_{d_0 \\in {\\mathcal S}_I} \\frac{1}{\\Phi(d_0)} f^{\\prime}(\\frac{\\log d_0}{\\log R})^2")#text(",")

#text("which is admissible. However, I don’t see how to handle the condition ")#mi("m/d_1\\in\\mathcal{X}")#text(" (it was automatic for the earlier choices of ")#mi("\\mathcal{X}")#text(").")

#text("2. I don’t see in (9) the condition ")#mi("md_0\\in\\mathcal{X}")#text(". Certainly ")#mi("md_0=dq")#text(" is the product of ")#mi("d\\in\\mathcal{S}_I")#text(" and ")#mi("q\\in\\mathcal{X}")#text(", but why does it lie in ")#mi("\\mathcal{X}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235731")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("Oops, I think I mis-stated the constraint in (8) which is causing both of these problems: it should be ")#mi("dq")#text(" that lies in ")#mi("{\\mathcal X}")#text(" rather than ")#mi("q")#text(". I’ll edit the post accordingly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235741")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("Thank you, it is all clear now. I just posted a small improvement, I hope it is ok.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235740")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("1. I think the display below (11) can be improved to")

#mi("\\prod_{p|q: p < x^\\delta} p \\geq x^{2\\delta^{\\prime}-2\\delta}")#text(".")

#text("By assumption, ")#mi("q=[d_1,d_2]")#text(" such that ")#mi("d_1r_1,d_2r_2\\in\\mathcal{X}\\cap[1,R]")#text(" for some ")#mi("r_1,r_2\\in\\mathcal{S}_I")#text(".")#linebreak()#text(" It follows that")

#mi("(r_1\\prod_{p|d_1:p < x^\\delta} p)(r_2\\prod_{p|d_2:p < x^\\delta} p) \\geq x^{2\\delta^{\\prime} - 2\\delta + 2\\varpi + \\epsilon}")#text(",")

#text("whence")

#mi("r_1r_2(d_1,d_2)(\\prod_{p|[d_1,d_2]:p < x^\\delta} p) \\geq x^{2\\delta^{\\prime} - 2\\delta + 2\\varpi + \\epsilon}")#text(".")

#text("Multiplying by ")#mi("[d_1,d_2]R^{-2}")#text(" and using ")#mi("(d_1r_1)(d_2r_2)\\leq R^2")#text(" we obtain")

#mi("\\prod_{p|[d_1,d_2]:p < x^\\delta} p\\geq x^{2\\delta^{\\prime} - 2\\delta-1/2+\\epsilon }[d_1,d_2]")#text(".")

#text("Therefore either ")#mi("[d_1,d_2]\\leq x^{1/2-\\epsilon}")#text(" or")

#mi("\\prod_{p|q: p < x^\\delta} p \\geq x^{2\\delta^{\\prime}-2\\delta}")#text(".")

#text("Hopefully this improvement lowers ")#mi("k_0")#text(" somewhat.")

#text("2. \"Section 2 of the previous section\" should be \"Section 2 of this previous blog\".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235747")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("Thanks for the correction and improved argument! I edited the main post accordingly. The net effect is to improve the quantity ")#mi("\\tilde \\theta")#text(" in Theorem 5 from")

#mi("\\displaystyle \\tilde \\theta := \\frac{\\delta^{\\prime}-\\delta + \\varpi}{1/4 + \\varpi}")

#text("to")

#mi("\\displaystyle \\tilde \\theta := \\frac{(\\delta^{\\prime}-\\delta)/2 + \\varpi}{1/4 + \\varpi}")

#text("which should hopefully squeeze a bit more out of ")#mi("k_0")#text(" starting from the current constraint ")#mi("148\\varpi+33\\delta < 1")#text(" since it delays the time when the ")#mi("\\kappa_3")#text(" error starts exploding and so ")#mi("\\delta^{\\prime}")#text(" may be taken a bit larger than previously. Presumably some perturbation of v08ltu's choice of parameters")

#mi("\\displaystyle \\varpi=1/148-24/4000000,\\delta^{\\prime}=1/200,k_0=1467,A=1300")

#text("should work here to nudge ")#mi("k_0")#text(" below 1467…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235759")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("For instance, ")#mi("\\omega=1/148-12/4000000, \\delta^{\\prime}=1/180, k_0=1466, A=1200")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235763")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#strike[#text("Confirmed! H is now 12006.")]#text(" ")#emph[#text("[Retracted, see below. -T]")]

#linebreak()#text(" varpi := 1/148 - 12/4000000;")#linebreak()#text(" k0 := 1466;")#linebreak()#text(" deltap := 1/180;")#linebreak()#text(" A := 1200;")

#text("delta := (1 - 148 * varpi) / 33;")#linebreak()#text(" theta := deltap / (1/4 + varpi);")

#text("# Gergely's improved value for thetat")#linebreak()#text(" thetat := ((deltap - delta)/2 + varpi) / (1/4 + varpi);")#linebreak()#text(" deltat := delta / (1/4 + varpi);")

#text("j := BesselJZeros(k0-2,1);")

#text("eps := 1 - j^2 / (k0 * (k0-1) * (1+4*varpi));")

#text("kappa1 := int( (1-t)^((k0-1)/2)/t, t = theta..1, numeric);")#linebreak()#text(" kappa2 := (k0-1) * int( (1-t)^(k0-1)/t, t=theta..1, numeric);")

#text("e := exp( A + (k0-1) * int( exp(-A*t)/t, t=deltat..theta, numeric ) );")

#text("# using Gergely's exact expression for denominator")#linebreak()#text(" gd := (j^2/2) * BesselJ(k0-3,j)^2;")

#text("# using Eytan's exact expression for numerator")#linebreak()#text(" tn := sqrt(thetat)*j;")#linebreak()#text(" gn := (tn^2/2) * (BesselJ(k0-2,tn)^2 - BesselJ(k0-3,tn)*BesselJ(k0-1,tn));")

#text("kappa3 := (gn/gd) * e;")

#text("eps2 := 2*(kappa1+kappa2+kappa3);")

#text("# we win if eps2 < eps")#linebreak()
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35598924aba40ab439ff5ed4cb5ff894b36068a7207a2d5c6df25c5177e5329b-140b0078e2139ec50e93f18d1fbcc653514264b2e9cdbcc86f776076a297e0c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hannes")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235765")[#strong[#text("Hannes")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("With that script I get eps2-eps=1.268156732*10^251 (not good).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35598924aba40ab439ff5ed4cb5ff894b36068a7207a2d5c6df25c5177e5329b-140b0078e2139ec50e93f18d1fbcc653514264b2e9cdbcc86f776076a297e0c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hannes")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235767")[#strong[#text("Hannes")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("(I used Maple 14)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235768")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("Hmm, you’re right! My version of maple seems to be a bit glitchy, but it is now reporting the same answer as you – once again ")#mi("\\kappa_3")#text(" is blowing up. So I have to retract the confirmation for now…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235787")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("I found my error, that I divided ")#mi("\\omega")#text(" by 2 also in the ")#mi("\\tilde\\theta")#text(" numerator, not only the ")#mi("\\delta")#text(" difference.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235789")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("The main issue that you need to take ")#mi("\\omega = 1/148-12/4000000")#text(" or less to have a hope from Bessel zeroes with ")#mi("k_0=1466")#text(", and this is not able to work, as the ")#mi("\\omega")#text(" part dominates the ")#mi("\\tilde\\theta")#text(" numerator (at least currently).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235751")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("Let ")#mi("q^\\flat:=\\prod_{p|q: p<x^\\delta} p")#text(" and ")#mi("q^\\sharp:=\\prod_{p|q: p\\geq x^\\delta} p")#text(", then the paragraph below (11) seems to work only when ")#mi("q^\\sharp\\geq R")#text(" (e.g. for ")#mi("q^\\sharp=1")#text(" the first step gives nothing). For ")#mi("q^\\sharp < R")#text(" we can do the following. We have ")#mi("{q^\\flat}\\geq R/{q^\\sharp}>1")#text(", hence there is a divisor of ")#mi("q^\\flat")#text(" in the interval ")#mi("[Rx^{-\\delta}/q^\\sharp, R/q^\\sharp]")#text(". Multiplying this divisor by ")#mi("q^\\sharp")#text(" yields a divisor of ")#mi("q")#text(" in the interval ")#mi("[Rx^{-\\delta},R]")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235762")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("1. In the post and in the comments we used the bound (valid for any ")#mi("A>0")#text(")")

#mi("\\int_{\\tilde \\delta \\leq t_1 , \\ldots , t_J \\leq \\theta; \\sum t_j\\leq 1}\\frac{dt_1 \\ldots dt_J}{t_1 \\ldots t_J}< e^A(\\int_{\\tilde \\delta}^\\theta e^{-At} \\frac{dt}{t})^J")#text(".")

#text("Here is an alternate way to bound the left hand side, which probably performs better in practice without any auxiliary parameter:")

#mi("\\int_{\\tilde \\delta \\leq t_1 , \\ldots , t_J \\leq \\theta; \\sum t_j\\leq 1}\\frac{dt_1 \\ldots dt_J}{t_1 \\ldots t_J}")

#mi("= \\int_{1 \\leq \\tau_1 , \\ldots , \\tau_J \\leq \\theta/\\tilde\\delta; \\sum \\tau_j\\leq 1/\\tilde\\delta}\\frac{d\\tau_1 \\ldots d\\tau_J}{\\tau_1 \\ldots \\tau_J}")

#mi("\\leq \\int_{1 \\leq \\tau_1 , \\ldots , \\tau_J; \\sum \\tau_j\\leq 1/\\tilde\\delta}\\ d\\tau_1 \\ldots d\\tau_J")

#mi("= \\int_{0 \\leq x_1 , \\ldots , x_J; \\sum x_j\\leq 1/\\tilde\\delta-J}\\ dx_1 \\ldots dx_J")

#mi("= \\frac{1}{J!}(\\frac{1}{\\tilde\\delta}-J)^J")#text(".")

#text("2. Some typos:")

#text("2a. \"")#mi("d_1")#text(", ")#mi("r_1")#text(" respectively\" should be \"")#mi("d_1")#text(", ")#mi("d_2")#text(" respectively\".")

#text("2b. \"Proposition 7\" should be \"Lemma 7\".")

#text("2c. Exponent ")#mi("k+1")#text(" should be ")#mi("k_0+1")#text(" (at least four occurrences).")

#text("2d. Link is missing under \"In this previous post\".")

#text("2e. \"exceeds ")#mi("R")#text(". or\" should be \"exceeds ")#mi("R")#text(" or\"")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235766")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("Thanks for the corrections!")

#text("The alternate estimate you propose, namely")

#mi("\\displaystyle \\kappa_3 = \\frac{G_{k_0-1,\\tilde \\theta}(0,0)}{G_{k_0-1}(0,0)} \\sum_{0 \\leq J \\leq 1/\\tilde J} \\frac{(k_0-1)^J (\\frac{1}{\\tilde \\delta}-J)^J}{(J!)^2}")

#text("seems to be a bit worse actually than the current estimate")

#mi("\\displaystyle \\kappa_3 = \\frac{G_{k_0-1,\\tilde \\theta}(0,0)}{G_{k_0-1}(0,0)} \\exp( A + (k_0-1) \\int_{\\tilde \\delta}^{\\theta} e^{-At} \\frac{dt}{t} )")

#text("for (say) v08ltu’s most recent values: the latter is about ")#mi("10^{1954}")#text(" times the G-ratio but the former seems to be something like ")#mi("10^{4010}")#text(", peaking at ")#mi("J")#text(" about 4200. Somehow the problem is that ")#mi("\\tilde \\delta")#text(" is so small that the double factorial ")#mi("(J!)^2")#text(" in the denominator has a hard time counteracting the factors of ")#mi("1/\\tilde \\delta")#text(" in the numerator. (The current estimate also blows up as ")#mi("\\tilde \\delta \\to 0")#text(", but the blowup seems to be milder somehow.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235779")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("Thanks for the information! I haven’t experimented with the numerics lately. Another idea is to optimize ")#mi("A")#text(" for each ")#mi("J")#text(" individually, i.e. choose ")#mi("A")#text(" such that ")#mi("A(1-J\\tilde\\delta)=J")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235780")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("Here I meant to use your upper bound for the ")#mi("t")#text("-integral, then optimize in ")#mi("A")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235820")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("From my next message (on a sub multiplicative property of ")#mi("f/f(0)")#text("), it follows that one can take ")#mi("A =  j_{k_0 - 2}^2 /(2 k_0 - 2)")#text(" only in the integral (i.e. without the constant factor ")#mi("\\exp A")#text(")")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235871")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("Actually keeping the ")#mi("t")#text("-integral (i.e. not bounding it) gives much better results. I also experimented with replacing ")#mi("G_{k_0-1,\\tilde \\theta}(0,0)")#linebreak()#text(" by ")#mi("G_{k_0-1,\\tilde \\theta}(J\\tilde\\delta,J\\tilde\\delta)")#text(" in the ")#mi("J")#text("-term. We can gain a factor of ")#mi("\\approx 10^{56}")#text(" this way, but for ")#mi("k_0=1466")#text(" we would need a gain of ")#mi("\\approx 10^{208}")#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235891")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#emph[#text("[Edited, Jun 25, to incorporate corrections by the author – T.]")]

#text("A sub-multiplicative property of f and new bounds for the ")#mi("\\kappa")#text("‘s:")

#text("1. Let ")#mi("g\\in C^1[0, 1]")#text(", be non-vanishing on ")#mi("[0,1)")#text(" (with the possible vanishing at ")#mi("1")#text(".) Consider the following inequality for")#linebreak()#text(" ")#mi("t, \\tau,  t+\\tau \\in [0,1]")#text(":")

#text("(1) ")#tao-math("\\left|g(t + \\tau)\\right| \\le K(\\tau) \\left|g(t)\\right|", block: false)

#text("Where for each fixed ")#mi("\\tau \\in [0, 1)")#linebreak()#text(" ")#tao-math("K(\\tau) := \\sup_{0 \\le t < 1- \\tau} \\left|g(t+\\tau)/ g(t)\\right|", block: false)#text(" is (obviously) the best (uniform) multiplier ")#mi("\\forall t \\in [0, 1 - \\tau]")#text(".")

#text("Clearly, a sufficient condition for ")#tao-math("K(\\tau) = \\left|g(\\tau)/ g(0)\\right|", block: false)#text(" to hold for each fixed ")#mi("\\tau \\in [0, 1)")#text(", is that the function ")#tao-math("\\left|g(t+ \\tau)/g(t)\\right|", block: false)#text(" should be non-increasing (as a function of ")#mi("t")#text(") on ")#mi("[0, 1 - \\tau)")#text(".")#linebreak()#text(" That is, its logarithm (as a function of ")#mi("t")#text(") should be non-increasing on ")#mi("[0, 1-\\tau)")#text(". Or equivalently, the logarithmic derivative of")#linebreak()#text(" ")#mi("|g(t + \\tau)/g(t)")#text(" should be non-positive on ")#mi("[0, 1 - \\tau)")#text(".")

#text("It follows that the above sufficient condition is implied by")

#text("(2) ")#tao-math("\\log \\left|g\\right|", block: false)#text(" is concave on ")#mi("[0, 1)")#text(".")

#text("To prove the implication, observe that for a fixed ")#mi("\\tau \\in [0, 1)")#text(", the derivative of ")#tao-math("\\log \\left|g(t + \\tau)/g(t)\\right|", block: false)#text(" is")#linebreak()#text(" ")#mi("h(t+\\tau) - h(t)")#text(" where ")#tao-math("h := \\left|g\\right|^{\\prime}/\\left|g\\right|", block: false)#text(" is the logarithmic derivative of ")#mi("g")#text(".")#linebreak()#text(" Now (2) implies that ")#mi("h")#text(" (as a non-increasing function on ")#mi("[0, 1])")#text(") satisfies ")#mi("h(t + \\tau) - h(t) \\le 0")#text(" whenever ")#mi("t, \\tau, t+\\tau \\in [0, 1)")#text(", which proves the sufficiency of (2) for (1) with ")#tao-math("K(\\tau) = \\left|g(\\tau)/g(0)\\right|", block: false)#text(".")

#text("This motivates the following")

#emph[#text("[For some reason, LaTeX is not working on the line below, I was unable to fix it – T.]")]

#text("Definition: A function g \\in C^1[0,1] will be called ")#emph[#text("nice")]#text(" ( on [0,1] ) if it is non-vanishing on [0, 1) and satisfy")

#text("(3) ")#mi("g(0) = 1")#text(" and ")#mi("(\\log g)")#text(" is concave")#linebreak()#text(" on ")#mi("[0,1)")

#text("Consequently, any nice function g on [0, 1] satisfies")

#text("(4) ")#mi("g(t + \\tau) \\le g(t) g(\\tau)")#text(" , whenever ")#mi("t, \\tau, t + \\tau \\in [0, 1]")

#text("(4') ")#mi("\\log g(t) \\le g^{\\prime}(0) t")#text(" on ")#mi("[0, 1)")#text(".")

#text("Where (4') follows from the concavity of ")#mi("\\log g")#text(" on ")#mi("[0, 1)")#text(".")

#text("It is easy to verify the following properties")

#text("(i) A finite product of nice functions is nice.")#linebreak()#text(" (ii) If ")#mi("g_n")#text(" is a sequence of nice and analytic functions on")#linebreak()#text(" ")#mi("[0, 1]")#text(", converging locally uniformly on ")#mi("[0,1]")#text(" to a function g, than g is (obviously) analytic and nice on ")#mi("[0, 1]")#text(".")

#text("Examples: If ")#mi("a, \\alpha \\in \\mathbb {R}")#text(" and ")#mi("a \\neq 0")#text(", then the functions")

#mi("E_0(t/a) , E_1(t/a), \\exp(\\alpha t)")#text(" are nice, where")

#mi("E_0(t) := 1 - t , E_1(t) := (1 - t) \\exp (t)")

#text("Theorem: Let ")#mi("g")#text(" be an entire function of order ")#mi("< 2")#text(", having its zeros in ")#mi("\\mathbb{R} \\setminus [0, 1)")#text(" and satisfying ")#mi("g(0) =1")#text(", than ")#mi("g")#text(" is a nice function on ")#mi("[0, 1]")#text(" and, consequently, it satisfies properties (4)-(4').")

#text("Proof: denote by ")#mi("h, \\lambda")#text(" the genus and order of g respectively. Since ")#mi("h \\le \\lambda")#text(" we have two possibilities")#linebreak()#text(" (i) ")#mi("h=0")#text(": implying that the canonical product representation of g")#linebreak()#text(" is given by ")#mi("g(z) = \\prod_n E_0(z /a_n)")#text(" where ")#mi("a_n")#text(" denote")#linebreak()#text(" the zeros of ")#mi("g")#text(", since (by the first example), each canonical factor")#linebreak()#text(" (i.e. ")#mi("E_0(t/a_n)")#text(") is nice and the canonical product converges locally uniformly to ")#mi("g(t)")#text(" on ")#mi("[0, 1]")#text(", it follows (from the above properties) that g is nice on ")#mi("[0, 1]")#text(".")#linebreak()#text(" (ii) ")#mi("h = 1")#text(": implying that the canonical product representation of g is given similarly by ")#mi("g(z) = \\exp (\\alpha z) \\prod_n E_1(z/an)")#text(" with the same proof.")

#text("2. Applications:")

#text("Let ")#mi("f(t) :=  t^{1-k_0 / 2} J_{k_0 - 2} (j_{k_0 - 2} \\sqrt {t})")#text(" for")#linebreak()#text(" ")#mi("t\\in [0, 1]")#text(", then the product representation (9.5.10) in A&S shows that f is an entire function of genus ")#mi("h=0")#text(" having its zeros in ")#mi("[1, +\\infty)")#text(".")#linebreak()#text(" Hence by the above theorem ")#mi("f(t)/f(0)")#text(" is nice on ")#mi("[0,1]")#text(". hence properties (4) and (4') imply")

#text("(5) ")#mi("f(\\sum_j t_j) /f(0) \\le \\prod_j [f(t_j) /f(0)]")#text(" whenever the ")#mi("t_j")#text("'s are non-negative and ")#mi("\\sum_j t_j \\le 1")#text(".")#linebreak()#text(" Remark: the last limitation on the sum is unnecessary if ")#mi("f")#text(" is modified to ")#mi("f = 0")#text(" on ")#mi("[1, \\infty)")#text(".")

#text("(5') ")#mi("f(t)/f(0) \\le \\exp [\\frac {f^{\\prime}0} {f(0)} t ]")#text(" for each ")#mi("t \\in [0,1]")#linebreak()#text(" (with the above modification of ")#mi("f=0")#text(" for ")#mi("t\\ge 1")#text(", (5') holds obviously for each ")#mi("t \\ge 1")#text(".")

#text("Remark: it is easy to verify that ")#mi("f^{\\prime}(0)/f(0) = - J_{k_0 -2}^2/[4 (k_0 - 1)]")#linebreak()#text(" which for large ")#mi("k_0")#text(" is asymptotic to ")#mi("-k_0/4")#text(".")

#text("Using (5), (5') it is easy to verify that for each ")#mi("t \\ge 0")

#mi("G_{k_0 - 1}(0,t) /  G_{k_0 -1}(0,0) \\le f(t)/f(0) \\le \\exp (- \\alpha t)")

#text("Where ")#mi("\\alpha := - f^{\\prime}(0) / f(0) = j_{k_0 - 2}^2 / [4 (k_0 -1)]")

#text("Since ")#mi("\\alpha")#text(" is asymptotic (for large ")#mi("k_0")#text(") to ")#mi("k_0 / 4")#text(", it seems that the last exponential bound is inferior to the current bound")#linebreak()#text(" ")#mi("(1 - t)_{+}^{(k_0-1)/2}")#text(" which determines the upper bound on")#linebreak()#text(" ")#mi("\\kappa_1")#text(", similar situation exists for the new bound")

#mi("G_ {k_0-1}(t,t) / G_{k_0 - 1}(0,0) \\le [f(t)/f(0)]^2 \\le \\exp(-2 \\alpha t)")#linebreak()#text(" relative to the current bound ")#mi("(1 - t)_{+}^{k_0 -1}")#text(" which determines the current upper bound on ")#mi("\\kappa_2")#text(".")

#text("the situation seems better for the new bound on ")#mi("\\kappa_3")#text(":")

#text("Using properties (5)-(5') of ")#mi("f")#text(", it follows that")

#mi("G_{k_0 -1 , \\tilde \\theta}(\\sum t_j, \\sum t_j) /G_{k_0 -1, \\tilde \\theta}(0,0)")

#mi("\\le \\prod_j [f(\\sum t_j) / f(0)]^2 \\le \\prod_j [f(t_j)/f(0)]^2")

#mi("\\le \\prod_j \\exp (- 2 \\alpha t_j)")

#text("It is easy to verify that the last exponential bound implies the current bound with with the parameter ")#mi("A = 2 \\alpha = j_{k_0 - 2}^2 / [2(k_0 - 1)]")#text(" in the integrand, but without the constant multiplier ")#mi("\\exp (A)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235898")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("These are very good ideas. Some thoughts:")

#text("1. Your (4) and (4′) can be proved directly for")

#mi("f_k(t):=t^{-k/2} J_{k} (j\\sqrt {t})")#text(" with ")#mi("j>0")#text(" fixed,")

#text("divided by ")#mi("f_k(0)")#text(" initially to make its value ")#mi("1")#text(" at ")#mi("t=0")#text(". All we need is that ")#mi("(\\log f_k)^{\\prime}")#text(" is decreasing on ")#mi("(0,\\infty)")#text(", i.e. that ")#mi("(f_k^{\\prime})^2-f_kf_k^{\\prime\\prime}\\geq 0")#text(" on ")#mi("(0,\\infty)")#text(". We have that ")#mi("f_k^{\\prime}=(-j/2)f_{k+1}")#text(" and ")#mi("f_k^{\\prime\\prime}=(j^2/4)f_{k+2}")#text(", so we need")

#mi("J_{k+1}^2(x)-J_k(x)J_{k+2}(x)\\geq 0")#text(" for ")#mi("x>0")#text(".")

#text("This in turn follows from Auluck’s formula that you quoted earlier:")

#mi("J_{k+1}^2(x) -J_k(x)J_{k+2}(x) = \\frac{2}{x^2}\\int_0^x J_{k+1}^2(t)\\ tdt")#text(".")

#text("2. So we have now a direct proof that")

#mi("G_{k_0 -1 , \\tilde \\theta}(\\sum t_j, \\sum t_j) /G_{k_0 -1, \\tilde \\theta}(0,0)\\leq \\prod_j \\exp (- 2 \\alpha t_j)")#text(",")

#text("where ")#mi("2 \\alpha = j_{k_0 - 2}^2 /(2(k_0 - 1))")#text(". This means that Terry’s ")#mi("\\kappa_3")#text(" can be improved to")

#mi("\\kappa_3 = \\frac{G_{k_0-1,\\tilde \\theta}(0,0)}{G_{k_0-1}(0,0)} \\exp( A + (k_0-1) \\int_{\\tilde \\delta}^{\\tilde \\theta} e^{-(A+2\\alpha)t} \\frac{dt}{t})")

#text("for any ")#mi("A>0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235906")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("Well, perhaps I should have restricted to ")#mi("k=k_0-2")#text(", ")#mi("j=j_{k_0-2}")#text(", and the interval ")#mi("(0,1)")#text(" instead of ")#mi("(0,\\infty)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235913")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("This is a nice observation! I’m quite surprised to see that the log-concavity holds also for ")#mi("[1, \\infty)")#text(", though at least in a sufficiently small neighborhood of a zero, the dominating logarithmic singularity is concave, the problem is that the logarithmic derivative is positive sufficiently close to the right of each zero, this is exactly the reason why the interval of interest should not have zeros of ")#mi("f")#text(".")#linebreak()#text(" Another well known example is ")#mi("1/ \\Gamma(t)")#text(" known to be entire, log-concave and monotonically decreasing to the right of its maximizer (which is in")#linebreak()#text(" ")#mi("(0, 1)")#text(" ) – in this case the zeros are to the left of the “interesting interval”!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235905")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("The new ")#mi("\\kappa_3")#text(" that arises from Eytan’s ideas seems to allow ")#mi("k_0=1466")#text(". Using ")#mi("\\varpi=1/148-1/318000")#text(", ")#mi("\\delta^{\\prime}=1/200")#text(", ")#mi("A=1360")#text(", I am getting ")#mi("\\epsilon\\approx 8.41\\times 10^{-8}")#text(", ")#mi("2\\kappa_1\\approx 7.15\\times 10^{-8}")#text(", ")#mi("2\\kappa_2\\approx 2.99\\times 10^{-11}")#text(", ")#mi("2\\kappa_3\\approx 3.69\\times 10^{-56}")#text(". These values might not be optimal, and they should be double checked.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235930")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("Maple seems to confirm it. Nice work by both of you!")

#text(".")#linebreak()#text(" ")#linebreak()#text(" varpi := 1/148 - 1/318000;")#linebreak()#text(" k0 := 1466;")#linebreak()#text(" deltap := 1/200;")#linebreak()#text(" A := 1360;")

#text("delta := (1 - 148 * varpi) / 33;")#linebreak()#text(" theta := deltap / (1/4 + varpi);")

#text("# Gergely's improved value for thetat")#linebreak()#text(" thetat := ((deltap - delta)/2 + varpi) / (1/4 + varpi);")#linebreak()#text(" deltat := delta / (1/4 + varpi);")

#text("j := BesselJZeros(k0-2,1);")

#text("eps := 1 - j^2 / (k0 * (k0-1) * (1+4*varpi));")

#text("kappa1 := int( (1-t)^((k0-1)/2)/t, t = theta..1, numeric);")#linebreak()#text(" kappa2 := (k0-1) * int( (1-t)^(k0-1)/t, t=theta..1, numeric);")

#text("# using Gergely and Eytan's improved kappa_3")

#text("alpha := j^2 / (4 * (k0-1));")#linebreak()#text(" e := exp( A + (k0-1) * int( exp(-(A+2*alpha)*t)/t, t=deltat..theta, numeric ) );")

#text("# using Gergely's exact expression for denominator")#linebreak()#text(" gd := (j^2/2) * BesselJ(k0-3,j)^2;")

#text("# using Eytan's exact expression for numerator")#linebreak()#text(" tn := sqrt(thetat)*j;")#linebreak()#text(" gn := (tn^2/2) * (BesselJ(k0-2,tn)^2 - BesselJ(k0-3,tn)*BesselJ(k0-1,tn));")

#text("kappa3 := (gn/gd) * e;")

#text("eps2 := 2*(kappa1+kappa2+kappa3);")

#text("# we win if eps2 < eps")#linebreak()
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235937")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("In your Maple worksheet, you integrate, deltat to theta, but the formula listed by Harcos is ")#mi("\\int_{\\tilde\\delta}^{\\tilde\\theta}")#text(".")

#emph[#text("[Well spotted! But I think Gergely’s formula has a typo, the integral here (which is counting primes up to ")#mi("R^\\theta = x^{\\delta^{\\prime}}")#text(") should go up to ")#mi("\\theta")#text(" rather than ")#mi("\\theta^{\\prime}")#text(". In any case the exponential decay of the integrand renders the upper limit of the integral more or less irrelevant. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235986")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2013")])]

#text("Indeed I had a typo, thanks for pointing it out! It was inherited by copy+paste from Terry’s earlier comment (")#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235766")[#text("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235766")]#text("), but my SAGE worksheet contained the right endpoint ")#mi("\\theta")#text(". Also, as Terry explained, the figures would still be fine with integration up to ")#mi("\\infty")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235992")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2013")])]

#text("I mean that ")#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235986")[#text("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235986")]#text(" was a response to ")#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235937")[#text("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235937")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-236015")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2013")])]

#text("Oops! Sorry about that; too late, now, but I edited the comment to fix it.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-236236")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("By (9.5.4) in A&S, it follows that ")#mi("J_{n -1}(j_n) / J_{n+1}(j_n) = -1")#text(", so this ratio may be used for ")#mi("n = k_0 - 2")#text(" to check the relative numerical error.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The distribution of primes in densely divisible moduli | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235917")[#strong[#text("The distribution of primes in densely divisible moduli | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("[…] The difference between this conjecture and the stronger conjecture is that the modulus is constrained to be -densely divisible rather than -smooth (note that is no longer constrained to lie in ). This relaxation of the smoothness condition improves the Goldston-Pintz-Yildirim type sieving needed to deduce from ; see this previous post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-236284")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("I wrote a wiki page at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Dickson-Hardy-Littlewood_theorems")[#text("http://michaelnielsen.org/polymath1/index.php?title=Dickson-Hardy-Littlewood_theorems")]

#text("recording most of the techniques we have for converting results of the form ")#mi("MPZ[\\varpi,\\delta]")#text(" or ")#mi("MPZ^{\\prime}[\\varpi,\\delta]")#text(" to ")#mi("DHL[k_0,2]")#text(". Nothing new on that page, but it at least collects all the different implications that we have found in a single location (though they are all basically obsolete now that we have Pintz’s sieve).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bounded gaps between primes (Polymath8) – a progress report | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-236880")[#strong[#text("Bounded gaps between primes (Polymath8) – a progress report | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("[…] “dense divisibility”, replacing the conjecture by a variant that we have called ); see this post for details. Finally, by optimising the remaining steps in Zhang’s argument (see below), we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-237561")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2013")])]

#text("The current definition of ")#mi("\\tilde {\\theta}")#text(" ensures (under theorem 5 hypotheses) that ")#mi("\\tilde {\\theta} < 1")#text(", but without the factor ")#mi("1/2")#text(" in its definition, we need to add this constraint to theorem 5 hypotheses.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-237567")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2013")])]

#text("I don’t think we need this constraint. If we replace ")#mi("\\tilde\\theta")#text(" by ")#mi("\\min(\\tilde\\theta,1)")#text(", then the function ")#mi("G_{k_0-1, \\tilde \\theta}(t_1,t_2)")#text(" does not change, hence the condition of Theorem 5 remains the same, while its proof works verbatim, i.e. the original stated conclusion holds.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An improved Type I estimate | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-239914")[#strong[#text("An improved Type I estimate | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2013")])]

#text("[…] We use the Pintz sieve from this post, repeating the proof of Theorem 5 from that post (and using the explicit formulae for and from […]")
]
