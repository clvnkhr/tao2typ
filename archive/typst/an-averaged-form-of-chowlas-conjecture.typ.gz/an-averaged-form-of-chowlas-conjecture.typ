// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T10:24:01.187322+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An averaged form of Chowla’s conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An averaged form of Chowla’s conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 March 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/")[#text("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://users.utu.fi/ksmato/index.html")[#text("Kaisa Matomaki")]#text(", ")#link("http://math.rutgers.edu/~maksym/")[#text("Maksym Radziwill")]#text(", and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1503.05121")[#text("An averaged form of Chowla’s conjecture")]#text("“. This paper concerns a weaker variant of the famous conjecture of Chowla (discussed for instance in ")#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/")[#text("this previous post")]#text(") that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq X} \\lambda(n+h_1) \\dots \\lambda(n+h_k) = o(X)")]]

#text("as ")#mi("{X \\rightarrow \\infty}")#text(" for any distinct natural numbers ")#mi("{h_1,\\dots,h_k}")#text(", where ")#mi("{\\lambda}")#text(" denotes the ")#link("http://en.wikipedia.org/wiki/Liouville_function")[#text("Liouville function")]#text(". (One could also replace the Liouville function here by the ")#link("http://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(" ")#mi("{\\mu}")#text(" and obtain a morally equivalent conjecture.) This conjecture remains open for any ")#mi("{k \\geq 2}")#text("; for instance the assertion")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq X} \\lambda(n) \\lambda(n+2) = o(X)")]]

#text("is a variant of the twin prime conjecture (though possibly a tiny bit easier to prove), and is subject to the notorious parity barrier (as discussed in ")#link("https://terrytao.wordpress.com/2014/11/21/a-general-parity-problem-obstruction/")[#text("this previous post")]#text(").")

#text("Our main result asserts, roughly speaking, that Chowla’s conjecture can be established unconditionally provided one has non-trivial averaging in the ")#mi("{h_1,\\dots,h_k}")#text(" parameters. More precisely, one has")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Chowla on the average)")]#text(" Suppose ")#mi("{H = H(X) \\leq X}")#text(" is a quantity that goes to infinity as ")#mi("{X \\rightarrow \\infty}")#text(" (but it can go to infinity arbitrarily slowly). Then for any fixed ")#mi("{k \\geq 1}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{h_1,\\dots,h_k \\leq H} \\left|\\sum_{n \\leq X} \\lambda(n+h_1) \\dots \\lambda(n+h_k)\\right| = o( H^k X ).", block: true)]]

#text("In fact, we can remove one of the averaging parameters and obtain")

#align(center)[#tao-fit-display[#tao-math("\\sum_{h_2,\\dots,h_k \\leq H} \\left|\\sum_{n \\leq X} \\lambda(n) \\lambda(n+h_2) \\dots \\lambda(n+h_k)\\right| = o( H^{k-1} X ).", block: true)]]
]

#text("Actually we can make the decay rate a bit more quantitative, gaining about ")#mi("{\\frac{\\log\\log H}{\\log H}}")#text(" over the trivial bound. The key case is ")#mi("{k=2}")#text("; while the unaveraged Chowla conjecture becomes more difficult as ")#mi("{k}")#text(" increases, the averaged Chowla conjecture does not increase in difficulty due to the increasing amount of averaging for larger ")#mi("{k}")#text(", and we end up deducing the higher ")#mi("{k}")#text(" case of the conjecture from the ")#mi("{k=2}")#text(" case by an elementary argument.")

#text("The proof of the theorem proceeds as follows. By exploiting the Fourier-analytic identity")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\mathbf T}} (\\int_{\\mathbf R} \\left|\\sum_{x \\leq n \\leq x+H} f(n) e(\\alpha n)\\right|^2 dx)^2\\ d\\alpha", block: true)]]

#align(center)[#tao-fit-display[#tao-math("= \\sum_{\\left|h\\right| \\leq H} (H-\\left|h\\right|)^2 \\left|\\sum_n f(n) \\overline{f}(n+h)\\right|^2", block: true)]]

#text("(related to a standard Fourier-analytic identity for the Gowers ")#mi("{U^2}")#text(" norm) it turns out that the ")#mi("{k=2}")#text(" case of the above theorem can basically be derived from an estimate of the form")

#align(center)[#tao-fit-display[#mitex("\\int_0^X |\\sum_{x \\leq n \\leq x+H} \\lambda(n) e(\\alpha n)|\\ dx = o( H X )")]]

#text("uniformly for all ")#mi("{\\alpha \\in {\\mathbf T}}")#text(". For “major arc” ")#mi("{\\alpha}")#text(", close to a rational ")#mi("{a/q}")#text(" for small ")#mi("{q}")#text(", we can establish this bound from a generalisation of a recent result of Matomaki and Radziwill (discussed in ")#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/")[#text("this previous post")]#text(") on averages of multiplicative functions in short intervals. For “minor arc” ")#mi("{\\alpha}")#text(", we can proceed instead from an argument of Katai and Bourgain-Sarnak-Ziegler (discussed in ")#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/")[#text("this previous post")]#text(").")

#text("The argument also extends to other bounded multiplicative functions than the Liouville function. Chowla’s conjecture was generalised by ")#link("http://www.ams.org/mathscinet-getitem?mr=1292619")[#text("Elliott")]#text(", who roughly speaking conjectured that the ")#mi("{k}")#text(" copies of ")#mi("{\\lambda}")#text(" in Chowla’s conjecture could be replaced by arbitrary bounded multiplicative functions ")#mi("{g_1,\\dots,g_k}")#text(" as long as these functions were far from a twisted Dirichlet character ")#mi("{n \\mapsto \\chi(n) n^{it}}")#text(" in the sense that ")#metadata(none) <tao-cf799c07995fbab0b882>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_p \\frac{1 - \\text{Re} g(p) \\overline{\\chi(p) p^{it}}}{p} = +\\infty.")]]

#text("(This type of distance is incidentally now a fundamental notion in the Granville-Soundararajan “pretentious” approach to multiplicative number theory.) During our work on this project, we found that Elliott’s conjecture is not quite true as stated due to a technicality: one can cook up a bounded multiplicative function ")#mi("{g}")#text(" which behaves like ")#mi("{n^{it_j}}")#text(" on scales ")#mi("{n \\sim N_j}")#text(" for some ")#mi("{N_j}")#text(" going to infinity and some slowly varying ")#mi("{t_j}")#text(", and such a function will be far from any fixed Dirichlet character whilst still having many large correlations (e.g. the pair correlations ")#mi("{\\sum_{n \\leq N_j} g(n+1) \\overline{g(n)}}")#text(" will be large). In our paper we propose a technical “fix” to Elliott’s conjecture (replacing ")#link(<tao-cf799c07995fbab0b882>)[#text("(1)")]#text(" by a truncated variant), and show that this repaired version of Elliott’s conjecture is true on the average in much the same way that Chowla’s conjecture is. (If one restricts attention to real-valued multiplicative functions, then this technical issue does not show up, basically because one can assume without loss of generality that ")#mi("{t=0}")#text(" in this case; we discuss this fact in an appendix to the paper.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (29)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-453192")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2015")])]

#text("Is there any (probabilistic) prediction for the true size of the ")#mi("o(H^k X)")#text(" term in theorem 1 ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-453209")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2015")])]

#text("Standard probabilistic heuristics suggest that this expression should be of size ")#mi("O_\\varepsilon( H^k X^{1/2+\\varepsilon})")#text(" for any ")#mi("\\varepsilon > 0")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8c2016a95d7871dcb511ae984e701ed78c8c69bcbea8aed09b3f13b3dbc827a-acbdc4f59b530120b45a1ec4380cb421d042b21bae300a1a2688683d5cfce060.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joel Moreira")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-453195")[#strong[#text("Joel Moreira")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2015")])]

#text("This looks impressive! I am wondering: does this averaged version imply anything about Sarnak’s conjecture on Mobius orthogonality?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-453210")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2015")])]

#text("Not as far as we can tell – there’s just too much averaging. We had initially hoped that we could say something nontrivial about a weaker version of Sarnak’s conjecture, namely that the Liouville sequence itself had positive entropy (i.e. the word growth is exponential) but even showing it is faster than linear remains a challenge.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a830450fdc42640734c399aefa8d8f69203b5cf003a6fb3d85c05a81a6dcced-6aa92d6fbc6161814fa75065d6b8ebec555852a948f8c3d0155ac32fac6aeb95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-453215")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2015")])]

#text("What is known about the “irreducible polynomial version” of this kind of problem (average of ")#mi("\\lambda(P) \\lambda(P+1)")#text(" for all polynomials of degree ")#mi("N")#text(" on ")#mi("F_2")#text(" for ")#mi("N")#text(" going to infinity, “Hardy-Littlewood conjecture” on the number of irreducibles ")#mi("P")#text(" of degree ")#mi("N")#text(" such that ")#mi("P+X^2 + X")#text(" is also irreducible, etc.)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8c2016a95d7871dcb511ae984e701ed78c8c69bcbea8aed09b3f13b3dbc827a-acbdc4f59b530120b45a1ec4380cb421d042b21bae300a1a2688683d5cfce060.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joel Moreira")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-453222")[#strong[#text("Joel Moreira")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2015")])]

#text("I am not sure if this is what you are looking for, but an analogue of the Chowla conjecture (with the “right” decay) has been proved for polynomials over finite fields by Carmon and Rudnick: ")#link("http://arxiv.org/abs/1205.1599")[#text("http://arxiv.org/abs/1205.1599")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a830450fdc42640734c399aefa8d8f69203b5cf003a6fb3d85c05a81a6dcced-6aa92d6fbc6161814fa75065d6b8ebec555852a948f8c3d0155ac32fac6aeb95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-453239")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2015")])]

#text("Thank you very much for this reference. It gives good estimates for fixed ")#mi("N")#text(" and ")#mi("q")#text(" going to infinity: I am wondering if there are estimates for ")#mi("q")#text(" fixed and ")#mi("N")#text(" going to infinity (which for me seems more similar to the case of the natural numbers).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f026b9d11810dd94a50ccd047993490d842148ba88454fbd446206f18967e28b-2704072eee32906e408b314c7fa3a4b11750419c3db3d93d937c779ba941f873.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brad")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-453244")[#strong[#text("brad")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2015")])]

#text("You’re right that such estimates would be more similar to the natural numbers. Unfortunately, I don’t think there are any such bounds at the moment. Roughly speaking, the paper of Carmon and Rudnick proceeds by reducing Moebius sums to N-fold character sums over ")#mi("\\mathbb{F}_q[T]")#text(", and then uses a Weil bound to estimate 1 part of this sum non-trivially, and the remaining N-1 parts trivially. It seems like it would require a really different idea to non-trivially bound several parts of the sum together. On the other hand, its worth remarking that the Galois-theoretic Pellet formula (1.5) holds true whether q tends to infinity or N does, and is an additional bit of information that has no analogue to be exploited over the integers…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f026b9d11810dd94a50ccd047993490d842148ba88454fbd446206f18967e28b-2704072eee32906e408b314c7fa3a4b11750419c3db3d93d937c779ba941f873.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brad")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-453246")[#strong[#text("brad")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2015")])]

#text("This looks like a nice paper! Is there any hope one could use an extension of these methods to show the existence of some fixed ")#mi("h")#text(" such that ")#mi("\\sum_{n\\leq x} \\lambda(n)\\lambda(n+h) = o(x)")#text("? More loosely, could it be possible to give some control on how the set of ")#mi("h")#text(" in Theorem 1.2 varies with ")#mi("X")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-453250")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2015")])]

#text("Unfortunately we don’t have any mechanism to make these correlations for different x “talk” to each other. Perhaps the best that could be done is to find a sequence of ")#mi("h_j")#text(" going to infinity and a sequence of ")#mi("x_k")#text(" going to infinity such that ")#tao-math("\\limsup_{k \\to \\infty} \\frac{1}{x_k} \\left|\\sum_{n \\leq x_k} \\lambda(n) \\lambda(n+h_j)\\right|", block: false)#text(" goes to zero as ")#mi("j \\to \\infty")#text(", but this is quite a weak statement.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-453251")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2015")])]

#text("Is it possible to generalize theorem 1 by considering powers of the inner sum (i.e. estimating its moments)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-453253")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2015")])]

#text("Yes, but one arrives at an equivalent estimate: for instance, since ")#tao-math("\\left|\\sum_{n \\leq X} \\lambda(n+h_1) \\dots \\lambda(n+h_k)\\right| \\leq X", block: false)#text(", the first estimate in Theorem 1 implies that ")#tao-math("\\sum_{h_1,\\dots,h_k \\leq H} \\left|\\sum_{n \\leq X} \\lambda(n+h_1) \\dots \\lambda(n+h_k)\\right|^m = o( H^k X^m )", block: false)#text(" for any fixed ")#mi("m")#text(". (The converse implication can also be recovered from Holder’s inequality.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-453451")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2015")])]

#text("Are the implied constants in theorem 1.6 (in the arxiv paper) effective?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-453452")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2015")])]

#text("Yes; we make no use of exceptional zeroes or similar repulsion phenomena, which are the main sources of ineffectivity in these arguments.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-453511")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2015")])]

#text("Which (hypothetical) bounds on ")#mi("\\sum_{n \\leq X} \\lambda (n) \\lambda (n+2)")#text(" are known to imply the twin prime conjecture?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-453512")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2015")])]

#text("Roughly speaking one needs bounds on ")#mi("\\sum_{n \\leq X} \\lambda(d_1 n) \\lambda(d_2 n+2)")#text(" for various ")#mi("d_1, d_2")#text(" that gain a couple of powers of ")#mi("\\log X")#text(" over the trivial bound. (See Proposition 3 of ")#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/")[#text("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/")]#text(" for some related computations.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-453538")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2015")])]

#text("Is it possible to improve the estimates in theorem 1 by assuming the general (!) tuple ")#mi("(h_1, ... , h_k)")#text(" to be admissible (or have another “nice” property) ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-453550")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2015")])]

#text("For the method of proof, one needs as much averaging as possible, so restricting the range of possible $h_1,\\dots,h_k$ would lead to inferior estimates. On the other hand, admissibility (or similar conditions) are not expected to help: the Mobius/Liouville randomness heuristic suggests that one should get square root decay uniformly for all choices of ")#mi("h_1,\\dots,h_k")#text(" (assuming they are not too large compared with ")#mi("x")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-458138")[#strong[#text("Updates and plans III. | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2015")]

#text("[…] and Maksym Radziwill. (Here is a link to the paper and to related blog posts by Terry Tao (1), […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sign patterns of the Mobius and Liouville functions | What's new")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-458944")[#strong[#text("Sign patterns of the Mobius and Liouville functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2015")])]

#text("[…] patterns of the Liouville and Möbius functions“. This paper is somewhat similar to our previous paper in that it is using the recent breakthrough of Matomaki and Radziwiłł on mean values of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Erdos discrepancy problem via the Elliott conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-459079")[#strong[#text("The Erdos discrepancy problem via the Elliott conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2015")])]

#text("[…] number . This conjecture remains open, though there are a number of partial results (e.g. these two previous results of Matomaki, Radziwill, and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-459433")[#strong[#text("The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2015")])]

#text("[…] averaged short sums of a modulated Liouville function established in another recent paper by Matomäki, Radziwi{l} and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-459653")[#strong[#text("Frogs and Lily Pads and Discrepancy | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2015")]

#text("[…] Dirichlet characters but used an asymptotic condition that was initially too strong. Building on work earlier this year with Kaisa Matomaki and Maksim Radziwill, Tao first repaired Elliott’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A small remark on the Elliott conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-461151")[#strong[#text("A small remark on the Elliott conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2015")])]

#text("[…] a previous paper with Matomaki and Radziwill, we provided a counterexample to the original formulation of the Elliott conjecture, and proposed […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A conjectural local Fourier-uniformity of the Liouville function | What's new")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-462895")[#strong[#text("A conjectural local Fourier-uniformity of the Liouville function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2015")])]

#text("[…] of course improves the prime number theorem. Recently with Matomaki and Radziwill, we obtained a common generalisation of this estimate with (1), showing […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Equivalence of the logarithmically averaged Chowla and Sarnak conjectures | What's new")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-468687")[#strong[#text("Equivalence of the logarithmically averaged Chowla and Sarnak conjectures | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2016")])]

#text("[…] was a slowly growing function of . This was in turn established in a previous paper of Matomaki, Radziwill, and myself, using the recent breakthrough of Matomaki and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on the Bombieri asymptotic sieve | What's new")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-470707")[#strong[#text("Notes on the Bombieri asymptotic sieve | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2016")])]

#text("[…] conjecture, for which there has been some recent progress (discussed for instance in these recent posts). Informally, the Bombieri asymptotic sieve lets us (on GEH) view the twin prime conjecture as a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-471661")[#strong[#text("Notes on the Bombieri asymptotic sieve - TAREA LISTA")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2016")]

#text("[…] conjecture, for which there has been some recent progress (discussed for instance in these recent posts). Informally, the Bombieri asymptotic sieve lets us (on GEH) view the twin prime conjecture as a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Correlations of the von Mangoldt and higher divisor functions II. Divisor correlations in short ranges | What's new")]], [#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/#comment-490843")[#strong[#text("Correlations of the von Mangoldt and higher divisor functions II. Divisor correlations in short ranges | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2017")])]

#text("[…] the exceptionally large values of then begin to dominate). This can be viewed as an analogue to our previous paper on correlations of bounded multiplicative functions on average, in which the functions are now unbounded, and indeed our proof strategy is based in large part on […]")
]
