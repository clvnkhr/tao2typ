// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/
// Converted to Typst by tao2typ: "2026-10-14T16:38:27.695081+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 1: Local well-posedness of the Navier-Stokes equations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 1: Local well-posedness of the Navier-Stokes equations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 September 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("We now begin the rigorous theory of the incompressible ")#link("https://en.wikipedia.org/wiki/Navier%E2%80%93Stokes_equations")[#text("Navier-Stokes equations")]#text(" ")#metadata(none) <tao-5bda84779c07d3fa658d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\partial_t u + (u \\cdot \\nabla) u = \\nu \\Delta u - \\nabla p")]]



#align(center)[#tao-fit-display[#mitex("\\nabla \\cdot u = 0,")]]

#text("where ")#mi("{\\nu>0}")#text(" is a given constant (the ")#emph[#text("kinematic viscosity")]#text(", or ")#emph[#text("viscosity")]#text(" for short), ")#mi("{u: I \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" is an unknown vector field (the ")#emph[#text("velocity field")]#text("), and ")#mi("{p: I \\times {\\bf R}^d \\rightarrow {\\bf R}}")#text(" is an unknown scalar field (the ")#emph[#text("pressure field")]#text("). Here ")#mi("{I}")#text(" is a time interval, usually of the form ")#mi("{[0,T]}")#text(" or ")#mi("{[0,T)}")#text(". We will either be interested in spatially decaying situations, in which ")#mi("{u(t,x)}")#text(" decays to zero as ")#mi("{x \\rightarrow \\infty}")#text(", or ")#mi("{{\\bf Z}^d}")#text("-periodic (or ")#emph[#text("periodic")]#text(" for short) settings, in which one has ")#mi("{u(t, x+n) = u(t,x)}")#text(" for all ")#mi("{n \\in {\\bf Z}^d}")#text(". (One can also require the pressure ")#mi("{p}")#text(" to be periodic as well; this brings up a small subtlety in the uniqueness theory for these equations, which we will address later in this set of notes.) As is usual, we abuse notation by identifying a ")#mi("{{\\bf Z}^d}")#text("-periodic function on ")#mi("{{\\bf R}^d}")#text(" with a function on the torus ")#mi("{{\\bf R}^d/{\\bf Z}^d}")#text(".")

#text("In order for the system ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" to even make sense, one requires some level of regularity on the unknown fields ")#mi("{u,p}")#text("; this turns out to be a relatively important technical issue that will require some attention later in this set of notes, and we will end up transforming ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" into other forms that are more suitable for lower regularity candidate solution. Our focus here will be on local existence of these solutions in a short time interval ")#mi("{[0,T]}")#text(" or ")#mi("{[0,T)}")#text(", for some ")#mi("{T>0}")#text(". (One could in principle also consider solutions that extend to negative times, but it turns out that the equations are not time-reversible, and the forward evolution is significantly more natural to study than the backwards one.) The study of Euler equations, in which ")#mi("{\\nu=0}")#text(", will be deferred to subsequent lecture notes.")

#text("As the unknown fields involve a time parameter ")#mi("{t}")#text(", and the first equation of ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" involves time derivatives of ")#mi("{u}")#text(", the system ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" should be viewed as describing an evolution for the velocity field ")#mi("{u}")#text(". (As we shall see later, the pressure ")#mi("{p}")#text(" is not really an independent dynamical field, as it can essentially be expressed in terms of the velocity field without requiring any differentiation or integration in time.) As such, the natural question to study for this system is the ")#link("https://en.wikipedia.org/wiki/Initial_value_problem")[#text("initial value problem")]#text(", in which an initial velocity field ")#mi("{u_0: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" is specified, and one wishes to locate a solution ")#mi("{(u,p)}")#text(" to the system ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" with initial condition ")#metadata(none) <tao-ac1b5c0961a7269b6a05>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("u(0,x) = u_0(x)")]]

#text(" ")#text(" for ")#mi("{x \\in {\\bf R}^d}")#text(". Of course, in order for this initial condition to be compatible with the second equation in ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(", we need the compatibility condition")

#metadata(none) <tao-cd35a2426062b7d58fd4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\nabla \\cdot u_0 = 0")]]

#text("and one should also impose some regularity, decay, and/or periodicity hypotheses on ")#mi("{u_0}")#text(" in order to be compatible with corresponding level of regularity etc. on the solution ")#mi("{u}")#text(".")

#text("The fundamental questions in the local theory of an evolution equation are that of ")#emph[#text("existence")]#text(", ")#emph[#text("uniqueness")]#text(", and ")#emph[#text("continuous dependence")]#text(". In the context of the Navier-Stokes equations, these questions can be phrased (somewhat broadly) as follows:")

#list(
[#text("(a) (Local existence) Given suitable initial data ")#mi("{u_0}")#text(", does there exist a solution ")#mi("{(u,p)}")#text(" to the above initial value problem that exists for some time ")#mi("{T>0}")#text("? What can one say about the time ")#mi("{T}")#text(" of existence? How regular is the solution?")],
[#text("(b) (Uniqueness) Is it possible to have two solutions ")#mi("{(u,p), (u^{\\prime},p^{\\prime})}")#text(" of a certain regularity class to the same initial value problem on a common time interval ")#mi("{[0,T)}")#text("? To what extent does the answer to this question depend on the regularity assumed on one or both of the solutions? Does one need to normalise the solutions beforehand in order to obtain uniqueness?")],
[#text("(c) (Continuous dependence on data) If one perturbs the initial conditions ")#mi("{u_0}")#text(" by a small amount, what happens to the solution ")#mi("{(u,p)}")#text(" and on the time of existence ")#mi("{T}")#text("? (This question tends to only be sensible once one has a reasonable uniqueness theory.)")]
)

#text("The answers to these questions tend to be more complicated than a simple “Yes” or “No”, for instance they can depend on the precise regularity hypotheses one wishes to impose on the data and on the solution, and even on exactly how one interprets the concept of a “solution”. However, once one settles on such a set of hypotheses, it generally happens that one either gets a “strong” theory (in which one has existence, uniqueness, and continuous dependence on the data), a “weak” theory (in which one has existence of somewhat low-quality solutions, but with only limited uniqueness results (or even some spectacular failures of uniqueness) and almost no continuous dependence on data), or no satsfactory theory whatsoever. In the former case, we say (roughly speaking) that the initial value problem is ")#emph[#text("locally well-posed")]#text(", and one can then try to build upon the theory to explore more interesting topics such as global existence and asymptotics, classifying potential blowup, rigorous justification of conservation laws, and so forth. With a weak local theory, it becomes much more difficult to address these latter sorts of questions, and there are serious analytic pitfalls that one could fall into if one tries too strenuously to treat weak solutions as if they were strong. (For instance, conservation laws that are rigorously justified for strong, high-regularity solutions may well fail for weak, low-regularity ones.) Also, even if one is primarily interested in solutions at one level of regularity, the well-posedness theory at another level of regularity can be very helpful; for instance, if one is interested in smooth solutions in ")#mi("{{\\bf R}^d}")#text(", it turns out that the well-posedness theory at the critical regularity of ")#mi("{\\dot H^{\\frac{d}{2}-1}({\\bf R}^d)}")#text(" can be used to establish ")#emph[#text("globally")]#text(" smooth solutions from small initial data. As such, it can become quite important to know what kind of local theory one can obtain for a given equation.")

#text("This set of notes will focus on the “strong” theory, in which a substantial amount of regularity is assumed in the initial data and solution, giving a satisfactory (albeit largely local-in-time) well-posedness theory. “Weak” solutions will be considered in later notes.")

#text("The Navier-Stokes equations are not the simplest of partial differential equations to study, in part because they are an amalgam of three more basic equations, which behave rather differently from each other (for instance the first equation is nonlinear, while the latter two are linear):")

#list(
[#text("(a) ")#emph[#text("Transport equations")]#text(" such as ")#mi("{\\partial_t u + (u \\cdot \\nabla) u = 0}")#text(".")],
[#text("(b) ")#emph[#text("Diffusion equations")]#text(" (or ")#emph[#text("heat equations")]#text(") such as ")#mi("{\\partial_t u = \\nu \\Delta u}")#text(".")],
[#text("(c) Systems such as ")#mi("{v = F - \\nabla p}")#text(", ")#mi("{\\nabla \\cdot v = 0}")#text(", which (for want of a better name) we will call ")#emph[#text("Leray systems")]#text(".")]
)

#text("Accordingly, we will devote some time to getting some preliminary understanding of the linear diffusion and Leray systems before returning to the theory for the Navier-Stokes equation. Transport systems will be discussed further in subsequent notes; in this set of notes, we will instead focus on a more basic example of nonlinear equations, namely the first-order ")#emph[#text("ordinary differential equation")]#text(" ")#metadata(none) <tao-87e5ad485acb89c18788>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\partial_t u = F(u)")]]

#text(" ")#text(" where ")#mi("{u: I \\rightarrow V}")#text(" takes values in some finite-dimensional (real or complex) vector space ")#mi("{V}")#text(" on some time interval ")#mi("{I}")#text(", and ")#mi("{F: V \\rightarrow V}")#text(" is a given linear or nonlinear function. (Here, we use “interval” to denote a connected non-empty subset of ")#mi("{{\\bf R}}")#text("; in particular, we allow intervals to be half-infinite or infinite, or to be open, closed, or half-open.) Fundamental results in this area include the ")#link("https://en.wikipedia.org/wiki/Picard%E2%80%93Lindel%C3%B6f_theorem")[#text("Picard existence and uniqueness theorem")]#text(", the ")#link("https://en.wikipedia.org/wiki/Duhamel%27s_principle")[#text("Duhamel formula")]#text(", and ")#link("https://en.wikipedia.org/wiki/Gr%C3%B6nwall%27s_inequality")[#text("Grönwall’s inequality")]#text("; they will serve as motivation for the approach to local well-posedness that we will adopt in this set of notes. (There are other ways to construct strong or weak solutions for Navier-Stokes and Euler equations, which we will discuss in later notes.)")

#text("A key role in our treatment here will be played by the ")#link("https://en.wikipedia.org/wiki/Fundamental_theorem_of_calculus")[#text("fundamental theorem of calculus")]#text(" (in various forms and variations). Roughly speaking, this theorem, and its variants, allow us to recast differential equations (such as ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" or ")#link(<tao-87e5ad485acb89c18788>)[#text("(4)")]#text(") as ")#link("https://en.wikipedia.org/wiki/Integral_equation")[#text("integral equations")]#text(". Such integral equations are less tractable algebraically than their differential counterparts (for instance, they are not ideal for verifying conservation laws), but are significantly more convenient for well-posedness theory, basically because integration tends to increase the regularity of a function, while differentiation reduces it. (Indeed, the problem of “losing derivatives”, or more precisely “losing regularity”, is a key obstacle that one often has to address when trying to establish well-posedness for PDE, particularly those that are quite nonlinear and with rough initial data, though for nonlinear parabolic equations such as Navier-Stokes the obstacle is not as serious as it is for some other PDE, due to the smoothing effects of the heat equation.)")

#text("One weakness of the methods deployed here are that the quantitative bounds produced deteriorate to the point of uselessness in the inviscid limit ")#mi("{\\nu \\rightarrow 0}")#text(", rendering these techniques unsuitable for analysing the Euler equations in which ")#mi("{\\nu=0}")#text(". However, some of the methods developed in later notes have bounds that remain uniform in the ")#mi("{\\nu \\rightarrow 0}")#text(" limit, allowing one to also treat the Euler equations.")

#text("In this and subsequent set of notes, we use the following asymptotic notation (a variant of ")#link("https://en.wikipedia.org/wiki/Big_O_notation#History_(Bachmann%E2%80%93Landau,_Hardy,_and_Vinogradov_notations)")[#text("Vinogradov notation")]#text(" that is commonly used in PDE and harmonic analysis). The statement ")#mi("{X \\lesssim Y}")#text(", ")#mi("{Y \\gtrsim X}")#text(", or ")#mi("{X = O(Y)}")#text(" will be used to denote an estimate of the form ")#tao-math("{\\left|X\\right| \\leq CY}", block: false)#text(" (or equivalently ")#tao-math("{Y \\geq C^{-1} \\left|X\\right|}", block: false)#text(") for some constant ")#mi("{C}")#text(", and ")#mi("{X \\sim Y}")#text(" will be used to denote the estimates ")#mi("{X \\lesssim Y \\lesssim X}")#text(". If the constant ")#mi("{C}")#text(" depends on other parameters (such as the dimension ")#mi("{d}")#text("), this will be indicated by subscripts, thus for instance ")#mi("{X \\lesssim_d Y}")#text(" denotes the estimate ")#tao-math("{\\left|X\\right| \\leq C_d Y}", block: false)#text(" for some ")#mi("{C_d}")#text(" depending on ")#mi("{d}")#text(".")

#metadata(none) <tao-6a5a0c12ef83664f6aee>

#heading(level: 1)[#strong[#text(" — 1. Ordinary differential equations — ")]]

#text("We now study solutions to ordinary differential equations ")#link(<tao-87e5ad485acb89c18788>)[#text("(4)")]#text(", focusing in particular on the initial value problem when the initial state ")#mi("{u(0) = u_0 \\in V}")#text(" is specified. We restrict attention to ")#emph[#text("strong solutions")]#text(" ")#mi("{u: I \\rightarrow V}")#text(", in which ")#mi("{u}")#text(" is continuously differentiable (")#mi("{C^1}")#text(") in the time variable, so that the derivative ")#mi("{\\partial_t}")#text(" in ")#link(<tao-87e5ad485acb89c18788>)[#text("(4)")]#text(" can be interpreted as the classical (strong) derivative, and one has the classical fundamental theorem of calculus ")#metadata(none) <tao-d12991253498ebd95339>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("u(t_2) - u(t_1) = \\int_{t_1}^{t_2} \\partial_t u(t)\\ dt")]]

#text(" ")#text(" whenever ")#mi("{t_1,t_2 \\in I}")#text(" (in this post we use the signed definite integral, thus ")#mi("{\\int_{t_1}^{t_2} = -\\int_{t_2}^{t_1}}")#text(").")

#text("We begin with homogeneous linear equations")

#align(center)[#tao-fit-display[#mitex("\\partial_t u = L u")]]

#text("where ")#mi("{L: V \\rightarrow V}")#text(" is a linear operator. Using the ")#link("https://en.wikipedia.org/wiki/Integrating_factor")[#text("integrating factor")]#text(" ")#mi("{e^{-tL}}")#text(", where ")#mi("{e^{-tL}: V \\rightarrow V}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Matrix_exponential")[#text("matrix exponential")]#text(" of ")#mi("{-tL}")#text(", and noting that ")#mi("{\\frac{d}{dt} e^{-tL} = -L e^{-tL} = -e^{-tL} L}")#text(", we see that this equation is equivalent to")

#align(center)[#tao-fit-display[#mitex("\\partial_t (e^{-tL} u) = 0")]]

#text("and hence from the fundamental theorem of calculus we see that if ")#mi("{u(0) = u_0}")#text(" then we have the unique global solution ")#mi("{e^{-tL} u = u_0}")#text(", or equivalently")

#align(center)[#tao-fit-display[#mitex("u(t) = e^{tL} u_0.")]]

#text("More generally, if one wishes to solve the inhomogeneous linear equation")

#align(center)[#tao-fit-display[#mitex("\\partial_t u = L u + F")]]

#text("for some continuous ")#mi("{F: {\\bf R} \\rightarrow V}")#text(" with initial condition ")#mi("{u(0) = u_0}")#text(", then from the fundamental theorem of calculus we have a unique global solution given by")

#align(center)[#tao-fit-display[#mitex("e^{-tL} u = u_0 + \\int_0^t e^{-sL} F(s)\\ ds")]]

#text("or equivalently one has the ")#link("https://en.wikipedia.org/wiki/Duhamel%27s_principle")[#text("Duhamel’s formula")]

#metadata(none) <tao-ffec15c1ff9b51058930>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("u(t) = e^{tL} u_0 + \\int_0^t e^{(t-s) L} F(s)\\ ds,")]]

#text("which is continuously differentiable in time if ")#mi("{F}")#text(" is continuous. Intuitively, the first term ")#mi("{e^{tL} u_0}")#text(" represents the contribution of the initial data ")#mi("{u_0}")#text(" to the solution ")#mi("{u(t)}")#text(" at time ")#mi("{t}")#text(" (with the ")#mi("{e^{tL}}")#text(" factor representing the evolution from time ")#mi("{0}")#text(" to time ")#mi("{t}")#text("), while the integrand ")#mi("{e^{(t-s)L} F(s)}")#text(" represents the contribution of the forcing term ")#mi("{F(s)}")#text(" at time ")#mi("{s}")#text(" to the solution ")#mi("{u(t)}")#text(" at time ")#mi("{t}")#text(" (with the ")#mi("{e^{(t-s)L}}")#text(" factor representing the evolution from time ")#mi("{s}")#text(" to time ")#mi("{t}")#text(").")

#text("One can apply a similar analysis to the differential inequality ")#metadata(none) <tao-373cb2c6d4fe2778441d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\partial_t u(t) \\leq A(t) u(t) + F(t)")]]

#text(" ")#text(" where ")#mi("{u: I \\rightarrow {\\bf R}}")#text(" is now a scalar continuously differentiable function, ")#mi("{F, A: I \\rightarrow {\\bf R}}")#text(" are continuous functions, and ")#mi("{I}")#text(" is an interval containing ")#mi("{0}")#text(" as its left endpoint; we also assume an initial condition ")#mi("{u(0) = u_0 \\in {\\bf R}}")#text(". Here, the natural integrating factor is ")#mi("{t \\mapsto \\exp( - \\int_0^t A(t^{\\prime})\\ dt^{\\prime} )}")#text(", whose derivative is ")#mi("{t \\mapsto - A(t) \\exp( - \\int_0^t A(t^{\\prime})\\ dt^{\\prime} )}")#text(" by the chain rule and the fundamental theorem of calculus. Applying this integrating factor to ")#link(<tao-373cb2c6d4fe2778441d>)[#text("(7)")]#text(", we may write it as")

#align(center)[#tao-fit-display[#mitex("\\partial_t ( \\exp( - \\int_0^t A(t^{\\prime})\\ ds ) u(t) ) \\leq \\exp( - \\int_0^t A(t^{\\prime})\\ dt^{\\prime} ) F(t)")]]

#text("and hence by the fundamental theorem of calculus we have")

#align(center)[#tao-fit-display[#mitex("\\exp( - \\int_0^t A(t^{\\prime})\\ dt^{\\prime} ) u(t) \\leq u_0 + \\int_0^t \\exp( - \\int_0^{s} A(t^{\\prime})\\ dt^{\\prime} )F(s) \\ ds")]]

#text("or equivalently")

#metadata(none) <tao-fe646824b72c55b16ab1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("u(t) \\leq \\exp( \\int_0^t A(t^{\\prime})\\ dt^{\\prime} ) u_0 + \\int_0^t \\exp( \\int_s^t A(t^{\\prime})\\ dt^{\\prime} ) F(s)\\ ds")]]

#text("for all ")#mi("{t \\in I}")#text(" (compare with ")#link(<tao-ffec15c1ff9b51058930>)[#text("(6)")]#text("). This is the differential form of ")#link("https://en.wikipedia.org/wiki/Gr%C3%B6nwall%27s_inequality")[#text("Grönwall’s inequality")]#text(". In the homogeneous case ")#mi("{F=0}")#text(", the inequality of course simplifies to")

#metadata(none) <tao-6cdf1039bb03586269f3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("u(t) \\leq \\exp( \\int_0^t A(t^{\\prime})\\ dt^{\\prime} ) u_0.")]]

#text("We continue assuming that ")#mi("{F=0}")#text(" for simplicity. From the fundamental theorem of calculus, ")#link(<tao-373cb2c6d4fe2778441d>)[#text("(7)")]#text(" (and the initial condition ")#mi("{u_0}")#text(") implies the integral inequality ")#metadata(none) <tao-762069bc07a6e1b5df12>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("u(t) \\leq u_0 + \\int_0^t A(s) u(s)\\ ds,")]]

#text(" ")#text(" although the converse implication of ")#link(<tao-373cb2c6d4fe2778441d>)[#text("(7)")]#text(" from ")#link(<tao-762069bc07a6e1b5df12>)[#text("(10)")]#text(" is false in general. Nevertheless, there is an analogue of ")#link(<tao-6cdf1039bb03586269f3>)[#text("(9)")]#text(" just assuming the weaker inequality ")#link(<tao-762069bc07a6e1b5df12>)[#text("(10)")]#text(", and not requiring any differentiability on ")#mi("{u}")#text(", at least when all functions involved are non-negative:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Integral form of Grönwall inequality)")]#text(" ")#metadata(none) <tao-7703ee07e2f95491de26>#text(" Let ")#mi("{I}")#text(" be an interval containing ")#mi("{0}")#text(" as left endpoint, let ")#mi("{u_0 \\in {\\bf R}}")#text(", and let ")#mi("{u: I \\rightarrow {\\bf R}}")#text(", ")#mi("{A: I \\rightarrow [0,+\\infty)}")#text(" be continuous functions obeying the inequality ")#link(<tao-762069bc07a6e1b5df12>)[#text("(10)")]#text(" for all ")#mi("{t \\in I}")#text(". Then one has ")#link(<tao-6cdf1039bb03586269f3>)[#text("(9)")]#text(" for all ")#mi("{t \\in I}")#text(".")
]

#emph[#text("Proof:")]#text(" From ")#link(<tao-762069bc07a6e1b5df12>)[#text("(10)")]#text(" and the fundamental theorem of calculus, the function ")#mi("{t \\mapsto u_0 + \\int_0^t A(s) u(s)\\ ds}")#text(" is continuously differentiable and obeys the differential inequality")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt}( u_0 + \\int_0^t A(s) u(s)\\ ds ) = A(t) u(t) \\leq A(t) (u_0 + \\int_0^t A(s) u(s)\\ ds)")]]

#text("(note here that we use the hypothesis that ")#mi("{A(t)}")#text(" is non-negative). Applying the differential form ")#link(<tao-6cdf1039bb03586269f3>)[#text("(9)")]#text(" of Gronwall’s inequality, we conclude that")

#align(center)[#tao-fit-display[#mitex("u_0 + \\int_0^t A(s) u(s)\\ ds \\leq \\exp( \\int_0^t A(t^{\\prime})\\ dt^{\\prime} ) u_0.")]]

#text("The claim now follows from ")#link(<tao-762069bc07a6e1b5df12>)[#text("(10)")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Relax the hypotheses of continuity on ")#mi("{u,A}")#text(" to that of being measurable and bounded on compact intervals. (You will need tools such as the fundamental theorem of calculus for absolutely continuous or Lipschitz functions, covered for instance in ")#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/")[#text("this previous set of notes")]#text(".)")
]

#text("Gronwall’s inequality is an excellent tool for bounding the growth of a solution to an ODE or PDE, or the difference between two such solutions. Here is a basic example, one half of the ")#link("https://en.wikipedia.org/wiki/Picard%E2%80%93Lindel%C3%B6f_theorem")[#text("Picard (or Picard-Lindeöf) theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Picard uniqueness theorem)")]#text(" ")#metadata(none) <tao-499cf3973c308a15fa1f>#text(" Let ")#mi("{I}")#text(" be an interval, let ")#mi("{V}")#text(" be a finite-dimensional vector space, let ")#mi("{F: V \\rightarrow V}")#text(" be a function that is Lipschitz continuous on every bounded subset of ")#mi("{V}")#text(", and let ")#mi("{u, v: I \\rightarrow V}")#text(" be continuously differentiable solutions to the ODE ")#link(<tao-87e5ad485acb89c18788>)[#text("(4)")]#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\partial_t u = F(u); \\quad \\partial_t v = F(v)")]]

#text("on ")#mi("{I}")#text(". If ")#mi("{u(t_0) = v(t_0)}")#text(" for some ")#mi("{t_0 \\in I}")#text(", then ")#mi("{u}")#text(" and ")#mi("{v}")#text(" agree identically on ")#mi("{I}")#text(", thus ")#mi("{u(t)=v(t)}")#text(" for all ")#mi("{t \\in I}")#text(".")
]

#emph[#text("Proof:")]#text(" By translating ")#mi("{I}")#text(" and ")#mi("{t_0}")#text(" we may assume without loss of generality that ")#mi("{t_0=0}")#text(". By splitting ")#mi("{I}")#text(" into at most two intervals, we may assume that ")#mi("{0}")#text(" is either the left or right endpoint of ")#mi("{I}")#text("; by applying the time reversal symmetry of replacing ")#mi("{u,v}")#text(" by ")#mi("{t \\mapsto u(-t), v \\mapsto v(-t)}")#text(" respectively, and also replacing ")#mi("{I, F}")#text(" by ")#mi("{-I}")#text(" and ")#mi("{-F}")#text(", we may assume without loss of generality that ")#mi("{0}")#text(" is the left endpoint of ")#mi("{I}")#text(". Finally, by writing ")#mi("{I}")#text(" as the union of compact intervals with left endpoint ")#mi("{0}")#text(", we may assume without loss of generality that ")#mi("{I}")#text(" is compact. In particular, ")#mi("{u,v}")#text(" are bounded and hence ")#mi("{F}")#text(" is Lipschitz continuous with some finite Lipschitz constant ")#mi("{K}")#text(" on the ranges of ")#mi("{u}")#text(" and ")#mi("{v}")#text(".")

#text("From the fundamental theorem of calculus we have")

#align(center)[#tao-fit-display[#mitex("u(t) = u(0) + \\int_{0}^t F(u(s))\\ ds")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("v(t) = v(0) + \\int_{0}^t F(v(s))\\ ds")]]

#text("for every ")#mi("{t \\in I}")#text("; subtracting, we conclude")

#align(center)[#tao-fit-display[#mitex("u(t) - v(t) = \\int_{0}^t F(u(s)) - F(v(s))\\ ds.")]]

#text("Applying the Lipschitz property of ")#mi("{F}")#text(" and the triangle inequality, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|u(t)-v(t)\\right| \\leq K \\int_{0}^t |u(s)-v(s)|\\ ds.", block: true)]]

#text("By the integral form of Grönwall’s inequality, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|u(t)-v(t)\\right| \\leq \\exp( \\int_{0}^t K\\ ds) 0 = 0", block: true)]]

#text("and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" The same result applies for infinite-dimensional normed vector spaces ")#mi("{V}")#text(", at least if one requires ")#mi("{u,v}")#text(" to be continuously differentiable in the strong (")#link("https://en.wikipedia.org/wiki/F%C3%A9chet_derivative")[#text("Fréchet")]#text(") sense; the proof is identical.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5 (Comparison principle)")]#text(" Let ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a function that is Lipschitz continuous on compact intervals. Let ")#mi("{I}")#text(" be an interval, and let ")#mi("{u,v: I \\rightarrow {\\bf R}}")#text(" be continuously differentiable functions such that")

#align(center)[#tao-fit-display[#mitex("\\partial_t u(t) \\leq F(u(t))")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\partial_t v(t) \\geq F(v(t))")]]

#text("for all ")#mi("{t \\in I}")#text(".")

#list(
[#text("(a) Suppose that ")#mi("{u(t_0) \\leq v(t_0)}")#text(" for some ")#mi("{t_0 \\in I}")#text(". Show that ")#mi("{u(t) \\leq v(t)}")#text(" for all ")#mi("{t \\in I}")#text(" with ")#mi("{t \\geq t_0}")#text(". (")#emph[#text("Hint:")]#text(" there are several ways to proceed here. One is to try to verify the hypotheses of Grönwall’s inequality for the quantity ")#mi("{\\max(u(t)-v(t),0)}")#text(" or ")#mi("{\\max(u(t)-v(t),0)^2}")#text(".)")],
[#text("(b) Suppose that ")#mi("{u(t_0) < v(t_0)}")#text(" for some ")#mi("{t_0 \\in I}")#text(". Show that ")#mi("{u(t) < v(t)}")#text(" for all ")#mi("{t \\in I}")#text(" with ")#mi("{t \\geq t_0}")#text(".")]
)
]

#text("Now we turn to the existence side of the Picard theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Picard existence theorem)")]#text(" ")#metadata(none) <tao-bbba57318f71911354fd>#text(" Let ")#mi("{V}")#text(" be a finite dimensional normed vector space, let ")#mi("{R>0}")#text(", and let ")#mi("{u_0 \\in V}")#text(" lie in the closed ball ")#tao-math("{\\overline{B(0,R)} := \\{ u \\in V: \\left\\|u\\right\\| \\leq R \\}}", block: false)#text(". Let ")#mi("{F: V \\rightarrow V}")#text(" be a function which has a Lipschitz constant of ")#mi("{K}")#text(" on the ball ")#mi("{\\overline{B(0,2R)}}")#text(". If one sets")

#metadata(none) <tao-c46d39c4987abb5fb13b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("T := \\frac{1}{2K + \\left\\|F(0)\\right\\|/R},", block: true)]]

#text("then there exists a continuously differentiable solution ")#mi("{u: [-T,T] \\rightarrow V}")#text(" to the ODE ")#link(<tao-87e5ad485acb89c18788>)[#text("(4)")]#text(" with initial data ")#mi("{u(0) = u_0}")#text(" such that ")#mi("{u(t) \\in \\overline{B(0,2R)}}")#text(" for all ")#mi("{t \\in [0,T]}")#text(".")
]

#text("Note that the solution produced by this theorem is unique on ")#mi("{[-T,T]}")#text(", thanks to Theorem ")#link(<tao-499cf3973c308a15fa1f>)[#text("3")]#text(". We will be primarily concerned with the case ")#mi("{F(0)=0}")#text(", in which case the time of existence ")#mi("{T}")#text(" simplifies to ")#mi("{T = \\frac{1}{2K}}")#text(".")

#emph[#text("Proof:")]#text(" Using the fundamental theorem of calculus, we write ")#link(<tao-87e5ad485acb89c18788>)[#text("(4)")]#text(" (with initial condition ")#mi("{u(0)=u_0}")#text(") in integral form as ")#metadata(none) <tao-1a20f6d5510e063e9244>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("u(t) = u_0 + \\int_0^t F(u(s))\\ ds.")]]

#text(" ")#text(" Indeed, if ")#mi("{u}")#text(" is continuously differentiable and solves ")#link(<tao-87e5ad485acb89c18788>)[#text("(4)")]#text(" with ")#mi("{u(0)=u_0}")#text(" on ")#mi("{[-T,T]}")#text(", then ")#link(<tao-1a20f6d5510e063e9244>)[#text("(12)")]#text(" holds on ")#mi("{[-T,T]}")#text(". Conversely, if ")#mi("{u}")#text(" is continuous and solves ")#link(<tao-1a20f6d5510e063e9244>)[#text("(12)")]#text(" on ")#mi("{[-T,T]}")#text(", then by the fundamental theorem of calculus the right-hand side of ")#link(<tao-1a20f6d5510e063e9244>)[#text("(12)")]#text(" (and hence ")#mi("{u}")#text(") is continuously differentiable and solves ")#link(<tao-87e5ad485acb89c18788>)[#text("(4)")]#text(" with ")#mi("{u(0)=u_0}")#text(". Thus it suffices to solve the integral equation ")#link(<tao-1a20f6d5510e063e9244>)[#text("(12)")]#text(" with a solution taking values in ")#mi("{\\overline{B(0,2R)}}")#text(".")

#text("We can view this as a fixed point problem. Let ")#mi("{X = C([-T,T] \\rightarrow \\overline{B(0,2R)})}")#text(" denote the space of continuous functions from ")#mi("{[-T,T]}")#text(" to ")#mi("{\\overline{B(0,2R)}}")#text(". We give this the uniform metric")

#align(center)[#tao-fit-display[#tao-math("d(u,v) := \\sup_{t \\in [-T,T]} \\left\\| u(t) - v(t) \\right\\|.", block: true)]]

#text("As is well known, ")#mi("{X}")#text(" becomes a complete metric space with this metric. Let ")#mi("{\\Phi: X \\rightarrow X}")#text(" denote the map")

#align(center)[#tao-fit-display[#mitex("\\Phi(u)(t) := u_0 + \\int_0^t F(u(s))\\ ds.")]]

#text("Let us first verify that ")#mi("{\\Phi}")#text(" does map ")#mi("{X}")#text(" to ")#mi("{X}")#text(". If ")#mi("{u \\in X}")#text(", then ")#mi("{\\Phi(u)}")#text(" is clearly continuous. For any ")#mi("{t \\in [-T,T]}")#text(", one has from the triangle inequality that")

#tao-aligned(keep: true)[


#tao-math("\\left\\| \\Phi(u)(t) \\right\\|  & \\leq \\left\\| u_0 \\right\\| + T \\sup_{s \\in [-T,T]} \\left\\| F(u(s)) \\right\\|", block: true)



#tao-math(" & \\leq R + T (\\left\\|F(0)\\right\\| + 2RK)", block: true)



#tao-math(" & \\leq 2R", block: true)
]

#text("by choice of ")#mi("{T}")#text(", hence ")#mi("{\\Phi(u) \\in X}")#text(" as claimed. A similar argument shows that ")#mi("{\\Phi}")#text(" is in fact a contraction on ")#mi("{X}")#text(". Namely, if ")#mi("{u,v \\in X}")#text(", then")

#tao-aligned(keep: true)[


#tao-math("\\left\\|\\Phi(u)(t) - \\Phi(v)(t)\\right\\|  & = \\left\\| \\int_0^t F(u(s)) - F(v(s)) \\ ds \\right\\|", block: true)



#tao-math(" & \\leq T \\sup_{s \\in [-T,T]} K \\left\\|u(s)-v(s)\\right\\|", block: true)



#tao-math(" & \\leq TK d(u,v)", block: true)
]

#text("and hence ")#mi("{d(\\Phi(u),\\Phi(v)) \\leq \\frac{1}{2} d(u,v)}")#text(" by choice of ")#mi("{T}")#text(". Applying the ")#link("https://en.wikipedia.org/wiki/Banach_fixed-point_theorem")[#text("contraction mapping theorem")]#text(", we obtain a fixed point ")#mi("{u \\in X}")#text(" to the equation ")#mi("{u = \\Phi(u)}")#text(", which is precisely ")#link(<tao-1a20f6d5510e063e9244>)[#text("(12)")]#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" The proof extends without difficulty to infinite dimensional Banach spaces ")#mi("{V}")#text(". Up to a multiplicative constant, the result is sharp. For instance, consider the linear ODE ")#mi("{\\partial_t u = Ku}")#text(" for some ")#mi("{K>0}")#text(", with ")#tao-math("{\\left\\|u_0\\right\\|=R}", block: false)#text(". Here, the function ")#mi("{u \\mapsto Ku}")#text(" is of course Lipschitz with constant ")#mi("{K}")#text(" on all of ")#mi("{V}")#text(", and the solution is of the form ")#mi("{u(t) = e^{Kt} u_0}")#text(", hence ")#mi("{u}")#text(" will exit ")#mi("{\\overline{B(0,2R)}}")#text(" in time ")#mi("{\\frac{\\log 2}{K}}")#text(", which is only larger than the time ")#mi("{\\frac{1}{2K}}")#text(" given by the above theorem by a multiplicative constant.")
]

#text("We can iterate the Picard existence theorem (and combine it with the uniqueness theorem) to conclude that there is a ")#emph[#text("maximal Cauchy development")]#text(" ")#mi("{u: (T_-, T_+) \\rightarrow V}")#text(" to the ODE ")#link(<tao-87e5ad485acb89c18788>)[#text("(4)")]#text(" with initial data ")#mi("{u(0)=u_0}")#text(", with the solution diverging to infinity (or “blowing up”) at the endpoint ")#mi("{T_+}")#text(" if this endpoint is finite, and similarly for ")#mi("{T_-}")#text(" (thus one has a dichotomy between global existence and finite time blowup). More precisely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8 (Maximal Cauchy development)")]#text(" ")#metadata(none) <tao-c1f5def06c9c8066f238>#text(" Let ")#mi("{V}")#text(" be a finite dimensional normed vector space, let ")#mi("{u_0 \\in V}")#text(", and let ")#mi("{F: V \\rightarrow V}")#text(" be a function which is Lipschitz on bounded sets. Then there exists ")#mi("{-\\infty \\leq T_- < 0 < T_+ \\leq +\\infty}")#text(" and a continuously differentiable solution ")#mi("{u: (T_-, T_+) \\rightarrow V}")#text(" to ")#link(<tao-87e5ad485acb89c18788>)[#text("(4)")]#text(" with ")#mi("{u(0) = u_0}")#text(", such that ")#tao-math("{\\lim_{t \\rightarrow T_+^-} \\left\\|u(t)\\right\\| = \\infty}", block: false)#text(" if ")#mi("{T_+}")#text(" is finite, and ")#tao-math("{\\lim_{t \\rightarrow T_-^+} \\left\\|u(t)\\right\\| = \\infty}", block: false)#text(" if ")#mi("{T_-}")#text(" is finite. Furthermore, ")#mi("{T_-, T_+}")#text(", and ")#mi("{u}")#text(" are unique.")
]

#emph[#text("Proof:")]#text(" Uniqueness follows easily from Theorem ")#link(<tao-499cf3973c308a15fa1f>)[#text("3")]#text(". For existence, let ")#mi("{I}")#text(" be the union of all the intervals containing ")#mi("{0}")#text(" for which there is a continuously differentiable solution to ")#link(<tao-87e5ad485acb89c18788>)[#text("(4)")]#text(" with ")#mi("{u(0)=u_0}")#text(". From Theorem ")#link(<tao-bbba57318f71911354fd>)[#text("6")]#text(" ")#mi("{I}")#text(" contains a neighbourhood of the origin. From Theorem ")#link(<tao-499cf3973c308a15fa1f>)[#text("3")]#text(" one can glue all the solutions together to obtain a continuously differentiable solution ")#mi("{u: I \\rightarrow V}")#text(" to ")#link(<tao-87e5ad485acb89c18788>)[#text("(4)")]#text(" with ")#mi("{u(0)=u_0}")#text(". If ")#mi("{t_0 \\in I}")#text(" is contained in ")#mi("{I}")#text(", then by Theorem ")#link(<tao-bbba57318f71911354fd>)[#text("6")]#text(" (and time translation) one could find a solution ")#mi("{\\tilde u: (t_0-\\varepsilon,t_0+\\varepsilon) \\rightarrow V}")#text(" to ")#link(<tao-87e5ad485acb89c18788>)[#text("(4)")]#text(" in a neighbourhood of ")#mi("{t_0}")#text(" such that ")#mi("{\\tilde u(t_0) = u(t_0)}")#text("; by Theorem ")#link(<tao-499cf3973c308a15fa1f>)[#text("3")]#text(" we must then have ")#mi("{(t_0-\\varepsilon,t_0+\\varepsilon) \\subset I}")#text(", otherwise we could glue ")#mi("{\\tilde u}")#text(" to ")#mi("{u}")#text(" and obtain a solution on a larger domain than ")#mi("{I}")#text(", contradicting the definition of ")#mi("{I}")#text(". Thus ")#mi("{I}")#text(" is open, and is of the form ")#mi("{I = (T_-, T_+)}")#text(" for some ")#mi("{-\\infty \\leq T_- < 0 < T_+ \\leq +\\infty}")#text(".")

#text("Suppose for contradiction that ")#mi("{T_+}")#text(" is finite and ")#tao-math("{\\left\\|u(t)\\right\\|}", block: false)#text(" does not go to infinity as ")#mi("{T \\rightarrow T_+^-}")#text(". Then there exists a finite ")#mi("{R}")#text(" and a sequence ")#mi("{t_n \\nearrow T_+}")#text(" such that ")#tao-math("{\\left\\|u(t_n)\\right\\| \\leq R}", block: false)#text(". Let ")#mi("{K}")#text(" be the Lipschitz constant of ")#mi("{F}")#text(" on ")#mi("{\\overline{B(0,2R)}}")#text(". By Theorem ")#link(<tao-bbba57318f71911354fd>)[#text("6")]#text(", for each ")#mi("{n}")#text(" one can find a solution ")#mi("{u_n}")#text(" to ")#link(<tao-87e5ad485acb89c18788>)[#text("(4)")]#text(" on ")#mi("{(t_n-T, t_n+T)}")#text(" with ")#mi("{u_n(t_n) = u(t_n)}")#text(", where ")#tao-math("{T := \\frac{1}{2K + \\left\\|F(0)\\right\\|/R}}", block: false)#text(" does not depend on ")#mi("{n}")#text(". For ")#mi("{n}")#text(" large enough, this and Theorem ")#link(<tao-bbba57318f71911354fd>)[#text("6")]#text(" allow us to extend the solution ")#mi("{u}")#text(" outside of ")#mi("{I}")#text(", contradicting the definition of ")#mi("{u}")#text(". Thus we have ")#tao-math("{\\lim_{t \\rightarrow T_+^-} \\left\\|u(t)\\right\\| = \\infty}", block: false)#text(" when ")#mi("{T_+}")#text(" is finite, and a similar argument gives ")#tao-math("{\\lim_{t \\rightarrow T_-^+} \\left\\|u(t)\\right\\| = \\infty}", block: false)#text(" when ")#mi("{T_-}")#text(" is finite. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" Theorem ")#link(<tao-bbba57318f71911354fd>)[#text("6")]#text(" gives a more quantitative description of the blowup: if ")#mi("{T_+}")#text(" is finite, then for any ")#mi("{T_- < t < T_+}")#text(", one must have")

#align(center)[#tao-fit-display[#tao-math("T_+ - t > \\frac{1}{2K_{2\\left\\|u(t)\\right\\|} + \\left\\|F(0)\\right\\|/\\left\\|u(t)\\right\\|}", block: true)]]

#text("where ")#tao-math("{K_{2\\left\\|u(t)\\right\\|}}", block: false)#text(" is the Lipschitz constant of ")#mi("{F}")#text(" on ")#tao-math("{\\overline{B(0,2\\left\\|u(t)\\right\\|)}}", block: false)#text(". This can be used to give some explicit lower bound on blowup rates. For instance, if ")#mi("{F(0)=0}")#text(" and ")#mi("{F(u)}")#text(" behaves like ")#tao-math("{\\left|u\\right|^p}", block: false)#text(" for some ")#mi("{p>1}")#text(" in the sense that the Lipschitz constant of ")#mi("{F}")#text(" on ")#mi("{\\overline{B(0,R)}}")#text(" is ")#mi("{O(R^{p-1})}")#text(" for any ")#mi("{R>0}")#text(", then we obtain a lower bound")

#metadata(none) <tao-f30d3c4042a4d2599f03>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left\\| u(t) \\right\\| \\gtrsim \\frac{1}{(T_+-t)^{1/(p-1)}}", block: true)]]

#text("as ")#mi("{t \\nearrow T_+}")#text(", if ")#mi("{T_+}")#text(" is finite, and similarly when ")#mi("{T_-}")#text(" is finite. This type of blowup rate is sharp. For instance, consider the scalar ODE")

#align(center)[#tao-fit-display[#tao-math("\\partial_t u = \\left|u\\right|^p", block: true)]]

#text("where ")#mi("{u}")#text(" takes values in ")#mi("{{\\bf R}}")#text(" and ")#mi("{p>1}")#text(" is fixed. Then for any ")#mi("{T_+ \\in {\\bf R}}")#text(", one has explicit solutions on ")#mi("{(-\\infty,T_+)}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("u(t) = \\frac{c}{(T_+-t)^{1/(p-1)}}")]]

#text("where ")#mi("{c := \\frac{1}{(p-1)^{1/(p-1)}}}")#text(" is a positive constant depending only on ")#mi("{p}")#text(". The blowup rate at ")#mi("{T_+}")#text(" is consistent with ")#link(<tao-f30d3c4042a4d2599f03>)[#text("(13)")]#text(" and also with ")#link(<tao-c46d39c4987abb5fb13b>)[#text("(11)")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Higher regularity)")]#text(" Let the notation and hypotheses be as in Theorem ")#link(<tao-c1f5def06c9c8066f238>)[#text("8")]#text(". Suppose that ")#mi("{F: V \\rightarrow V}")#text(" is ")#mi("{k}")#text(" times continuously differentiable for some natural number ")#mi("{k}")#text(". Show that the maximal Cauchy development ")#mi("{u}")#text(" is ")#mi("{k+1}")#text(" times continuously differentiable. In particular, if ")#mi("{F}")#text(" is smooth, then so is ")#mi("{u}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11 (Lipschitz continuous dependence on data)")]#text(" Let ")#mi("{V}")#text(" be a finite-dimensional normed vector space.")

#list(
[#text("(a) Let ")#mi("{R>0}")#text(", let ")#mi("{F: V \\rightarrow V}")#text(" be a function which has a Lipschitz constant of ")#mi("{K}")#text(" on the ball ")#mi("{\\overline{B(0,2R)}}")#text(", and let ")#mi("{T}")#text(" be the quantity ")#link(<tao-c46d39c4987abb5fb13b>)[#text("(11)")]#text(". If ")#mi("{u_0, v_0 \\in \\overline{B(0,R)}}")#text(", and ")#mi("{u,v: [-T,T] \\rightarrow V}")#text(" are the solutions to ")#link(<tao-87e5ad485acb89c18788>)[#text("(4)")]#text(" with ")#mi("{u(0)=u_0, v(0)=v_0}")#text(" given by Theorem ")#link(<tao-bbba57318f71911354fd>)[#text("6")]#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\sup_{t \\in [-T,T]} \\left\\|u(t)-v(t)\\right\\| \\leq 2 \\|u_0-v_0\\|.", block: true)]]],
[#text("(b) Let ")#mi("{F: V \\rightarrow V}")#text(" be a function which is Lipschitz on bounded sets, let ")#mi("{u_0 \\in V}")#text(", and let ")#mi("{u: (T_-, T_+) \\rightarrow V}")#text(" be the maximal Cauchy development of ")#link(<tao-87e5ad485acb89c18788>)[#text("(4)")]#text(" with initial data ")#mi("{u(0)=u_0}")#text(" given by Theorem ")#link(<tao-bbba57318f71911354fd>)[#text("6")]#text(". Show that for any compact interval ")#mi("{I \\subset (T_-,T_+)}")#text(" containing ")#mi("{0}")#text(", there exists an open neighbourhood ")#mi("{U}")#text(" of ")#mi("{u_0}")#text(", such that for any ")#mi("{v_0 \\in U}")#text(", there exists a solution ")#mi("{v: I \\rightarrow V}")#text(" of ")#link(<tao-87e5ad485acb89c18788>)[#text("(4)")]#text(" with initial data ")#mi("{v(0)=v_0}")#text(". Furthermore, the map from ")#mi("{v_0}")#text(" to ")#mi("{v}")#text(" is a Lipschitz continuous map from ")#mi("{U}")#text(" to ")#mi("{C(I \\rightarrow V)}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Non-autonomous Picard theorem)")]#text(" Let ")#mi("{V}")#text(" be a finite-dimensional normed vector space, and let ")#mi("{F: {\\bf R} \\times V \\rightarrow V}")#text(" be a function which is Lipschitz on bounded sets. Let ")#mi("{u_0 \\in V}")#text(". Show that there exist ")#mi("{-\\infty \\leq T_- < 0 < T_+ \\leq +\\infty}")#text(" and a continuously differentiable function ")#mi("{u: (T_-,T_+) \\rightarrow V}")#text(" solving the non-")#link("https://en.wikipedia.org/wiki/Autonomous_system_(mathematics)")[#text("autonomous")]#text(" ODE")

#align(center)[#tao-fit-display[#mitex("\\partial_t u(t) = F(t,u(t))")]]

#text("for ")#mi("{t \\in (T_-,T_+)}")#text(" with initial data ")#mi("{u(0) = u_0}")#text("; furthermore one has ")#tao-math("{\\lim_{t \\rightarrow T_+^-} \\left\\|u(t)\\right\\| = \\infty}", block: false)#text(" if ")#mi("{T_+}")#text(" is finite, and ")#tao-math("{\\lim_{t \\rightarrow T_-^+} \\left\\|u(t)\\right\\| = \\infty}", block: false)#text(" if ")#mi("{T_-}")#text(" is finite. Finally, show that ")#mi("{T_-, T_+, u}")#text(" are unique. (")#emph[#text("Hint:")]#text(" this could be done by repeating all of the previous arguments, but there is also a way to deduce this non-autonomous version of the Picard theorem directly from the Picard theorem by adding one extra dimension to the space ")#mi("{V}")#text(".)")
]

#text("The above theory is symmetric with respect to the time reversal of replacing ")#mi("{t \\mapsto u(t)}")#text(" with ")#mi("{t \\mapsto u(-t)}")#text(" and ")#mi("{F}")#text(" with ")#mi("{-F}")#text(". However, one can break this symmetry by introducing a dissipative linear term, in which case one only obtains the forward-in-time portion of the Picard existence theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Let ")#mi("{V}")#text(" be a finite dimensional normed vector space, let ")#mi("{R>0}")#text(", and let ")#mi("{u_0 \\in V}")#text(" lie in the closed ball ")#tao-math("{\\overline{B(0,R)} := \\{ u \\in V: \\left\\|u\\right\\| \\leq R \\}}", block: false)#text(". Let ")#mi("{F: V \\rightarrow V}")#text(" be a function which has a Lipschitz constant of ")#mi("{K}")#text(" on the ball ")#mi("{\\overline{B(0,2R)}}")#text(". Let ")#mi("{T}")#text(" be the quantity in ")#link(<tao-c46d39c4987abb5fb13b>)[#text("(11)")]#text(". Let ")#mi("{L: V \\rightarrow V}")#text(" be a linear operator obeying the dissipative estimates")

#align(center)[#tao-fit-display[#tao-math("\\left\\| e^{tL} u \\right\\| \\leq \\left\\| u \\right\\|", block: true)]]

#text("for all ")#mi("{u \\in V}")#text(" and ")#mi("{t \\geq 0}")#text(". Show that there exists a continuously differentiable solution ")#mi("{u: [0,T] \\rightarrow V}")#text(" to the ODE")

#metadata(none) <tao-39e741eddb03e3118da6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\partial_t u = Lu + F(u)")]]

#text("with initial data ")#mi("{u(0) = u_0}")#text(" such that ")#mi("{u(t) \\in \\overline{B(0,2R)}}")#text(" for all ")#mi("{t \\in [0,T]}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 14")]#text(" With the hypotheses of the above exercise, one can also solve the ODE backwards in time by an amount ")#tao-math("{\\frac{1}{2K + 2 \\left\\|L\\right\\|_{op} + \\left\\|F(0)\\right\\|/R}}", block: false)#text(", where ")#tao-math("{\\left\\|L\\right\\|_{op}}", block: false)#text(" denotes the operator norm of ")#mi("{L}")#text(". However, in the limit as the operator norm of ")#mi("{L}")#text(" goes to infinity, the amount to which one can evolve backwards in time goes to zero, whereas the time in which one can evolve forwards in time remains bounded away from zero, thus breaking the time symmetry.")
]

#heading(level: 1)[#strong[#text(" — 2. Leray systems — ")]]

#metadata(none) <tao-b6dd83c8c15e66d15919>

#text("Now we discuss the Leray system of equations ")#metadata(none) <tao-d1c667af9c5e1c7f6f35>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("v = F - \\nabla p; \\quad \\nabla \\cdot v = 0")]]

#text(" ")#text(" where ")#mi("{F: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" is given, and the vector field ")#mi("{v: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" and the scalar field ")#mi("{p: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" are unknown. In other words, we wish to decompose a specified function ")#mi("{F}")#text(" as the sum of a gradient ")#mi("{\\nabla p}")#text(" and a divergence-free vector field ")#mi("{v}")#text(". We will use the usual Lebesgue spaces ")#mi("{L^q(X \\rightarrow {\\bf R}^m)}")#text(" of measurable functions ")#mi("{f: X \\rightarrow {\\bf R}^m}")#text(" (up to almost everywhere equivalence) defined on some measure space ")#mi("{(X,\\mu)}")#text(" (which in our case will always be either ")#mi("{{\\bf R}^d}")#text(" or ")#mi("{{\\bf R}^d/{\\bf Z}^d}")#text(" with Lebesgue measure) such that the ")#mi("{L^q}")#text(" norm ")#tao-math("{(\\int_X \\left|f\\right|^q\\ d\\mu)^{1/q}}", block: false)#text(" is finite. (For ")#mi("{q=\\infty}")#text(", the ")#mi("{L^\\infty}")#text(" norm is defined instead to be the essential supremum of ")#tao-math("{\\left|f\\right|}", block: false)#text(".)")

#text("Proceeding purely formally, we could solve this system by taking the divergence of the first equation to conclude that")

#align(center)[#tao-fit-display[#mitex("0 = \\nabla \\cdot F - \\Delta p")]]

#text("where ")#mi("{\\Delta p = \\nabla \\cdot (\\nabla p)}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Laplace_operator")[#text("Laplacian")]#text(" of ")#mi("{p}")#text(", and then we could formally solve for ")#mi("{p}")#text(" as")

#metadata(none) <tao-83df400fe4307ef19659>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("p = \\Delta^{-1} (\\nabla \\cdot F)")]]

#text("and then solve for ")#mi("{v}")#text(" as")

#metadata(none) <tao-5e5548e059a49952c012>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("v = F - \\nabla \\Delta^{-1} (\\nabla \\cdot F).")]]

#text("However, if one wishes to justify this rigorously one runs into the issue that the Laplacian ")#mi("{\\Delta}")#text(" is not quite invertible. To sort this out and make this problem well-defined, we need to specify the regularity and decay one wishes to impose on the data ")#mi("{F}")#text(" and on the solution ")#mi("{v, p}")#text(". To begin with, let us suppose that ")#mi("{u,F,p}")#text(" are all smooth.")

#text("We first understand the uniqueness theory for this problem. By linearity, this amounts to solving the homogeneous equation when ")#mi("{F=0}")#text(", thus we wish to classify the smooth fields ")#mi("{v: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" and ")#mi("{p: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" solving the system")

#align(center)[#tao-fit-display[#mitex("v = -\\nabla p; \\quad \\nabla \\cdot v = 0.")]]

#text("Of course, we can eliminate ")#mi("{v}")#text(" and write this a single equation")

#align(center)[#tao-fit-display[#mitex("\\Delta p = 0")]]

#text("That is to say, the solutions to this equation arise by selecting ")#mi("{p}")#text(" to be a (smooth) harmonic function, and ")#mi("{v}")#text(" to be the negative gradient of ")#mi("{p}")#text(". This is consistent with our preceding discussion that identified the potential lack of invertibility of ")#mi("{\\Delta}")#text(" as a key issue.")

#text("By linearity, this implies that (smooth) solutions ")#mi("{(v,p)}")#text(" to the system ")#link(<tao-d1c667af9c5e1c7f6f35>)[#text("(15)")]#text(" are only unique up to the addition of an arbitrary harmonic function to ")#mi("{p}")#text(", and the subtraction of the gradient of that harmonic function from ")#mi("{v}")#text(".")

#text("We can largely eliminate this lack of uniqueness by imposing further requirements on ")#mi("{F,p,v}")#text(". For instance, suppose in addition that we require ")#mi("{F,p,v}")#text(" to all be ")#mi("{{\\bf Z}^d}")#text("-periodic (or ")#emph[#text("periodic")]#text(" for short), thus")

#align(center)[#tao-fit-display[#mitex("F(x+n) = F(x), p(x+n) = p(x), v(x+n) = v(x)")]]

#text("for ")#mi("{x \\in {\\bf R}^d}")#text(" and ")#mi("{n \\in {\\bf Z}^d}")#text(". Then the only freedom we have is to modify ")#mi("{p}")#text(" by an arbitrary periodic harmonic function (and to subtract the gradient of that function from ")#mi("{v}")#text("). However, by ")#link("https://en.wikipedia.org/wiki/Harmonic_function#Liouville's_theorem")[#text("Liouville’s theorem")]#text(", the only periodic harmonic functions are the constants, whose gradient vanishes. Thus the only freedom in this setting is to add a constant to ")#mi("{p}")#text(". This freedom will be almost irrelevant when we consider the Euler and Navier-Stokes equations, since it is only the gradient of the pressure which appears in those equations, rather than the pressure itself. Nevertheless, if one wishes, one could remove this freedom by requiring that ")#mi("{p}")#text(" be of mean zero: ")#mi("{\\int_{{\\bf R}^d/{\\bf Z}^d} p(x)\\ dx = 0}")#text(".")

#text("Now suppose instead that we only require that ")#mi("{F}")#text(" and ")#mi("{v}")#text(" be ")#mi("{{\\bf Z}^d}")#text("-periodic, but do not require ")#mi("{p}")#text(" to be ")#mi("{{\\bf Z}^d}")#text("-periodic. Then we have the freedom to modify ")#mi("{p}")#text(" by a harmonic function ")#mi("{u}")#text(" which need not be ")#mi("{{\\bf Z}^d}")#text("-periodic, but whose gradient ")#mi("{\\nabla u}")#text(" is ")#mi("{{\\bf Z}^d}")#text("-periodic. Since the gradient of a harmonic function is also harmonic, ")#mi("{\\nabla u}")#text(" has to be constant, and so ")#mi("{u}")#text(" is an affine-linear function. Conversely, all affine-linear functions are harmonic, and their gradients are constant and thus also ")#mi("{{\\bf Z}^d}")#text("-periodic. Thus, one has the freedom in this setting to add an arbitrary affine-linear function to ")#mi("{p}")#text(", and subtract the constant gradient of that function from ")#mi("{v}")#text(".")

#text("Instead of periodicity, one can also impose decay conditions on the various functions. Suppose for instance that we require the pressure to lie in an ")#mi("{L^q({\\bf R}^d \\rightarrow {\\bf R})}")#text(" space for some ")#mi("{1 \\leq q < \\infty}")#text("; roughly speaking, this forces the pressure to decay to zero at infinity “on the average”. Then we only have the freedom to modify ")#mi("{p}")#text(" by a harmonic function ")#mi("{u}")#text(" that is also in the ")#mi("{L^q}")#text(" class (and modify ")#mi("{v}")#text(" by the negative gradient of this harmonic function). However, the mean value property of harmonic functions implies that")

#align(center)[#tao-fit-display[#tao-math("u(x) = \\frac{1}{\\left|B(x,R)\\right|} \\int_{B(x,R)} u(y)\\ dy", block: true)]]

#text("for any ball ")#mi("{B(x,R)}")#text(" of some radius ")#mi("{R}")#text(" centred around ")#mi("{x}")#text(", where ")#tao-math("{\\left|B(x,R)\\right|}", block: false)#text(" denotes the measure of the ball. By Hölder’s inequality, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|u(x)\\right| \\leq \\frac{1}{\\left|B(x,R)\\right|} \\left|B(x,R)\\right|^{1-1/q} \\left\\|u\\right\\|_{L^q({\\bf R}^d)}.", block: true)]]

#text("Sending ")#mi("{R \\rightarrow \\infty}")#text(" we conclude that ")#mi("{u}")#text(" vanishes identically; thus there are no non-trivial harmonic functions in ")#mi("{L^q({\\bf R}^d \\rightarrow {\\bf R})}")#text(". Thus there is uniqueness for the problem ")#link(<tao-d1c667af9c5e1c7f6f35>)[#text("(15)")]#text(" if we require the pressure ")#mi("{p}")#text(" to lie in ")#mi("{L^q({\\bf R}^d \\rightarrow {\\bf R})}")#text(". If instead we require the vector field ")#mi("{v}")#text(" to be in ")#mi("{L^q({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(", then we can modify ")#mi("{p}")#text(" by a harmonic function ")#mi("{u}")#text(" with ")#mi("{\\nabla u}")#text(" in ")#mi("{L^q({\\bf R}^d \\rightarrow {\\bf R}^{d^2})}")#text(", thus ")#mi("{\\nabla u}")#text(" vanishes identically and hence ")#mi("{u}")#text(" is constant. So if we require ")#mi("{v \\in L^q({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" then we only have the freedom to adjust ")#mi("{p}")#text(" by arbitrary constants.")

#text("Having discussed uniqueness, we now turn to existence. We begin with the periodic setting in which ")#mi("{F,v,p}")#text(" are required to be ")#mi("{{\\bf Z}^d}")#text("-periodic and smooth, so that they can also be viewed (by slight abuse of notation) as functions on the torus ")#mi("{{\\bf R}^d/{\\bf Z}^d}")#text(". The system ")#link(<tao-d1c667af9c5e1c7f6f35>)[#text("(15)")]#text(" is linear and translation-invariant, which strongly suggests that one solve the system using the Fourier transform (which tends to diagonalise linear translation-invariant equations, because the plane waves ")#mi("{x \\mapsto e^{2\\pi i k \\cdot x}}")#text(" that underlie the Fourier transform are the eigenfunctions of translation.) Indeed, we may expand ")#mi("{F,v,p}")#text(" as Fourier series")

#tao-aligned(keep: true)[


#tao-math("F(x)  & = \\sum_{k \\in {\\bf Z}^d} \\hat F(k) e^{2\\pi i k \\cdot x}", block: true)



#tao-math("v(x)  & = \\sum_{k \\in {\\bf Z}^d} \\hat v(k) e^{2\\pi i k \\cdot x}", block: true)



#tao-math("p(x)  & = \\sum_{k \\in {\\bf Z}^d} \\hat p(k) e^{2\\pi i k \\cdot x}", block: true)
]

#text("where the Fourier coefficients ")#mi("{\\hat F(k) \\in {\\bf R}^d}")#text(", ")#mi("{\\hat v(k) \\in{\\bf R}^d}")#text(", ")#mi("{\\hat p(k) \\in {\\bf R}}")#text(" are given by the formulae")

#tao-aligned(keep: true)[


#tao-math("\\hat F(k)  & = \\int_{{\\bf R}^d/{\\bf Z}^d} F(x) e^{-2\\pi i k \\cdot x}\\ dx", block: true)



#tao-math("\\hat v(k)  & = \\int_{{\\bf R}^d/{\\bf Z}^d} v(x) e^{-2\\pi i k \\cdot x}\\ dx", block: true)



#tao-math("\\hat p(k)  & = \\int_{{\\bf R}^d/{\\bf Z}^d} p(x) e^{-2\\pi i k \\cdot x}\\ dx.", block: true)
]

#text("When ")#mi("{F,v,p}")#text(" are smooth, then ")#mi("{\\hat F(k), \\hat v(k), \\hat p(k)}")#text(" are rapidly decreasing as ")#mi("{k \\rightarrow \\infty}")#text(", which will allow us to justify manipulations such as interchanging summation and derivatives without difficulty. Expanding out ")#link(<tao-d1c667af9c5e1c7f6f35>)[#text("(15)")]#text(" in Fourier series and then comparing Fourier coefficients (which are unique for smooth functions), we obtain the system")

#metadata(none) <tao-b3b84733833237522868>

#tao-aligned(keep: true)[


#tao-math("\\hat v(k)  & = \\hat F(k) - 2\\pi i k \\hat p(k)", block: true, numbering: n => [#text("(18)")])

#metadata(none) <tao-8fd769705377b461d569>

#tao-math("2\\pi i k \\cdot \\hat v(k)  & = 0", block: true, numbering: n => [#text("(19)")])
]

#text("for each ")#mi("{k \\in {\\bf Z}^d}")#text(". As mentioned above, the Fourier transform has ")#emph[#text("diagonalised")]#text(" the system ")#link(<tao-d1c667af9c5e1c7f6f35>)[#text("(15)")]#text(", in that there are no interactions between different frequencies ")#mi("{k \\in {\\bf Z}^d}")#text(", and we now have a decoupled system of vector equations. To solve these equations, we can take the inner product of both sides of ")#link(<tao-b3b84733833237522868>)[#text("(18)")]#text(" with ")#mi("{k}")#text(" and apply ")#link(<tao-8fd769705377b461d569>)[#text("(19)")]#text(" to conclude that")

#align(center)[#tao-fit-display[#tao-math("0 = k \\cdot \\hat F(k) - 2\\pi i \\left|k\\right|^2 \\hat p(k).", block: true)]]

#text("For non-zero ")#mi("{k}")#text(", we can then solve for ")#mi("{\\hat p(k)}")#text(" and hence ")#mi("{\\hat v(k)}")#text(" by the formulae")

#align(center)[#tao-fit-display[#tao-math("\\hat p(k) = \\frac{k}{2\\pi i \\left|k\\right|^2} \\cdot \\hat F(k)", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\hat v(k) = \\hat F(k) - k (\\frac{k}{\\left|k\\right|^2} \\cdot \\hat F(k)).", block: true)]]

#text("For ")#mi("{k = 0}")#text(", these formulae no longer apply; however from ")#link(<tao-b3b84733833237522868>)[#text("(18)")]#text(" we see that ")#mi("{\\hat v(0) = \\hat F(0)}")#text(", while ")#mi("{\\hat p(0)}")#text(" can be arbitrary (which corresponds to the aforementioned freedom to add an arbitrary constant to ")#mi("{p}")#text("). Thus we have the explicit general solution")

#tao-aligned(keep: true)[


#tao-math("p(x)  & = C + \\sum_{k \\in {\\bf Z}^d \\backslash \\{0\\}} \\frac{k}{2\\pi i \\left|k\\right|^2} \\cdot \\hat F(k) e^{2\\pi i k \\cdot x}", block: true)



#tao-math("v(x)  & = \\hat F(0) + \\sum_{k \\in {\\bf Z}^d \\backslash \\{0\\}} (\\hat F(k) - k (\\frac{k}{\\left|k\\right|^2} \\cdot \\hat F(k))) e^{2\\pi i k \\cdot x},", block: true)
]

#text("where ")#mi("{C}")#text(" is an arbitrary constant. Note that if ")#mi("{F}")#text(" is smooth, then ")#mi("{\\hat F(k)}")#text(" is rapidly decreasing and the functions ")#mi("{p,v}")#text(" defined by the above formulae are also smooth.")

#text("We can write the above general solution in a form similar to ")#link(<tao-83df400fe4307ef19659>)[#text("(16)")]#text(", ")#link(<tao-5e5548e059a49952c012>)[#text("(17)")]#text(" as")

#tao-aligned(keep: true)[


#tao-math("p  & = C + \\Delta^{-1} (\\nabla \\cdot F)", block: true)



#tao-math("v  & = F - \\nabla \\Delta^{-1} (\\nabla \\cdot F)", block: true)
]

#text("where, ")#emph[#text("by definition")]#text(", the inverse Laplacian ")#mi("{\\Delta^{-1}}")#text(" of a smooth periodic function ")#mi("{f: {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}}")#text(" of mean zero is given by the Fourier series formula")

#align(center)[#tao-fit-display[#tao-math("\\Delta^{-1} f(x) := \\sum_{k \\in {\\bf Z}^d \\backslash \\{0\\}} \\frac{1}{-4\\pi^2 \\left|k\\right|^2} \\hat f(k) e^{2\\pi i k \\cdot x}.", block: true)]]

#text("(Note that ")#mi("{\\nabla \\cdot F}")#text(" automatically has mean zero.) It is easy to see that ")#mi("{\\Delta \\Delta^{-1} f = f}")#text(" for such functions ")#mi("{f}")#text(", thus justifying the choice of notation. We refer to ")#mi("{F - \\nabla \\Delta^{-1} (\\nabla \\cdot F)}")#text(" as the (periodic) ")#link("https://en.wikipedia.org/wiki/Leray_projection")[#text("Leray projection")]#text(" of ")#mi("{F}")#text(" and denote it ")#mi("{\\mathbb{P}}")#text(", thus in the above solution we have ")#mi("{v = \\mathbb{P}(F)}")#text(". By construction, ")#mi("{\\mathbb{P}(F)}")#text(" is divergence-free, and ")#mi("{\\mathbb{P}(F)}")#text(" vanishes whenever ")#mi("{F}")#text(" is a gradient ")#mi("{F = \\nabla p}")#text(".")

#text("If we require ")#mi("{F,v}")#text(" to be ")#mi("{{\\bf Z}^d}")#text("-periodic, but do not require ")#mi("{p}")#text(" to be ")#mi("{{\\bf Z}^d}")#text("-periodic, then by the previous uniqueness discussion, the general solution is now")

#tao-aligned(keep: true)[


#tao-math("p(x)  & = C + \\Delta^{-1} (\\nabla \\cdot F)(x) + w \\cdot x", block: true)



#tao-math("v(x)  & = F(x) - \\nabla \\Delta^{-1} (\\nabla \\cdot F)(x) - w = \\mathbb{P}(F) - w", block: true)
]

#text("where ")#mi("{C \\in {\\bf R}}")#text(" and ")#mi("{w \\in {\\bf R}^d}")#text(" are arbitrary.")

#text("The above discussion was for smooth periodic functions ")#mi("{F,p,v}")#text(", but one can make the same construction in other function spaces. For instance, recall that for any ")#mi("{s \\geq 0}")#text(", the Sobolev space ")#mi("{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m)}")#text(" consists of those elements ")#mi("{f}")#text(" of ")#mi("{L^2({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m)}")#text(" whose Sobolev norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m)} := (\\sum_{k \\in {\\bf Z}^d} \\langle k \\rangle^{2s} \\left|\\hat f(k)\\right|^2)^{1/2}", block: true)]]

#text("is finite, where we use the “Japanese bracket” convention ")#tao-math("{\\langle k\\rangle := (1 + \\left|k\\right|^2)^{1/2}}", block: false)#text(". (One can also define Sobolev spaces for negative ")#mi("{s}")#text(", but we will not need them here.) Basic properties of these Sobolev spaces can be found in ")#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/")[#text("this previous post")]#text(". From comparing Fourier coefficients we see that the operators ")#mi("{\\Delta^{-1}(\\nabla \\cdot)}")#text(" and ")#mi("{\\nabla \\Delta^{-1} (\\nabla \\cdot)}")#text(" defined for smooth periodic functions can be extended without difficulty to ")#mi("{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}")#text(" (taking values in ")#mi("{H^{s+1}({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}")#text(" and ")#mi("{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow{\\bf R}^d)}")#text(" respectively), with bounds of the form")

#tao-aligned(keep: true)[


#tao-math("\\left\\| \\nabla \\Delta^{-1} (\\nabla \\cdot F)\\right\\|_{H^{s}({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}  & \\lesssim \\left\\| \\Delta^{-1} (\\nabla \\cdot F)\\right\\|_{H^{s+1}({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}", block: true)



#tao-math(" & \\lesssim \\left\\|F\\right\\|_{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}.", block: true)
]

#text("Thus, if ")#mi("{F \\in H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}")#text(", then one can solve ")#link(<tao-d1c667af9c5e1c7f6f35>)[#text("(15)")]#text(" (in the sense of distributions, at least) with some ")#mi("{v \\in H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}")#text(" and ")#mi("{p \\in H^{s+1}({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}")#text(", with bounds")

#align(center)[#tao-fit-display[#tao-math("\\left\\| v \\right\\|_{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}, \\left\\| p \\right\\|_{H^{s+1}({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})} \\lesssim \\left\\|F\\right\\|_{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}.", block: true)]]

#text("In particular, the Leray projection ")#mi("{\\mathbb{P}}")#text(" is bounded on ")#mi("{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}")#text(". (In fact it is a non-expansive map; see Exercise ")#link(<tao-91be4d936426b3b20f1d>)[#text("16")]#text(".)")

#text("One can argue similarly in the non-periodic setting, as long as one avoids the one-dimensional case ")#mi("{d=1}")#text(" which contains some technical divergences. Recall (see e.g., ")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("these previous lecture notes")]#text(" on this blog) that functions ")#mi("{f \\in L^2({\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(" have a Fourier transform ")#mi("{\\hat f \\in L^2({\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(", which for ")#mi("{f}")#text(" in the dense subclass ")#mi("{L^1({\\bf R}^d \\rightarrow {\\bf R}^m) \\cap L^2({\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(" of ")#mi("{L^2({\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(" is defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) := \\int_{{\\bf R}^d} f(x) e^{-2\\pi i x \\cdot \\xi}\\ dx")]]

#text("and then is extended to the rest of ")#mi("{L^2({\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(" by continuous extension in the ")#mi("{L^2}")#text(" topology, taking advantage of the Plancherel identity")

#metadata(none) <tao-ea242a3fb45034524055>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\left\\|\\hat f\\right\\|_{L^2({\\bf R}^d \\rightarrow {\\bf R}^m)} = \\left\\| f \\right\\|_{L^2({\\bf R}^d \\rightarrow {\\bf R}^m)}.", block: true)]]

#text("The Fourier transform is then extended to tempered distributions in the usual fashion (see ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("this previous set of notes")]#text(").")

#text("We then define the Sobolev space ")#mi("{H^s({\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(" for ")#mi("{s \\geq 0}")#text(" to be the collection of those functions ")#mi("{f \\in L^2({\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(" for which the norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^m)} := (\\int_{{\\bf R}^d} \\langle \\xi \\rangle^{2s} \\left|\\hat f(\\xi)\\right|^2\\ d\\xi)^{1/2}", block: true)]]

#text("is finite; equivalently, one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^m)} = \\left\\| \\langle \\nabla \\rangle^s f \\right\\|_{L^2({\\bf R}^d \\rightarrow{\\bf R}^m)}", block: true)]]

#text("where the Fourier multiplier ")#mi("{\\langle \\nabla \\rangle^s}")#text(" is defined by")

#align(center)[#tao-fit-display[#mitex("\\widehat{\\langle \\nabla \\rangle^s f}(\\xi) = \\langle \\xi \\rangle^s \\hat f(\\xi).")]]

#text("For any vector-valued function ")#mi("{F: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" in the Schwartz class, we define ")#mi("{\\Delta^{-1} (\\nabla \\cdot F)}")#text(" to be the scalar tempered distribution whose (distributional) Fourier transform is given by the formula")

#metadata(none) <tao-0549112635482fc7e341>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\widehat{\\Delta^{-1} (\\nabla \\cdot F)}(\\xi) = -\\frac{2\\pi i \\xi \\cdot \\hat F(\\xi)}{4\\pi^2 \\left|\\xi\\right|^2}", block: true)]]

#text("and define the Leray projection ")#mi("{\\mathbb{P} F}")#text(" to be the vector-valued distribution")

#metadata(none) <tao-42db0bfebfce2fece1e7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\mathbb{P} F = F - \\nabla \\Delta^{-1} (\\nabla \\cdot F)")]]

#text("or in terms of the (distributional) Fourier transform")

#align(center)[#tao-fit-display[#tao-math("\\widehat{\\mathbb{P} F}(\\xi) = \\hat F(\\xi) - \\frac{\\xi}{\\left|\\xi\\right|^2} \\xi \\cdot \\hat F(\\xi).", block: true)]]

#text("Then by using the well-known relationship")

#align(center)[#tao-fit-display[#mitex("\\widehat{\\partial_j F}(\\xi) = 2\\pi i \\xi_j \\hat F(\\xi)")]]

#text("between (distributional) derivatives and (distributional) Fourier transforms we see that the tempered distributions")

#align(center)[#tao-fit-display[#mitex("p = \\Delta^{-1} (\\nabla \\cdot F), v = F - \\nabla \\Delta^{-1} (\\nabla \\cdot F)")]]

#text("solve the equation ")#link(<tao-d1c667af9c5e1c7f6f35>)[#text("(15)")]#text(" in the distributional sense, and hence also in the classical sense since ")#mi("{p,v}")#text(" have locally integrable Fourier transforms that are rapidly decreasing away from the origin, and are thus smooth.")

#text("As in the periodic case we see that we have the bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mathbb{P}(F) \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)} \\lesssim \\left\\| F \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)}", block: true)]]

#text("for all Schwartz vector fields ")#mi("{F}")#text(" (in fact ")#mi("{\\mathbb{P}}")#text(" is again a non-expansive map), so we can extend the Leray projection without difficulty to ")#mi("{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" functions. The operator ")#mi("{\\Delta^{-1} (\\nabla \\cdot)}")#text(" can similarly be extended continuously to a map from ")#mi("{H^s({\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(" to the space ")#mi("{\\{ f: \\nabla f \\in H^s({\\bf R}^d \\rightarrow {\\bf R}^d)\\}}")#text(" of scalar tempered distributions with gradient in ")#mi("{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(", although we will not need to work directly with the pressure much in this course. This allows us to solve ")#link(<tao-d1c667af9c5e1c7f6f35>)[#text("(15)")]#text(" in a distributional sense for all ")#mi("{F \\in H^s({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 15")]#text(" (Remark removed due to inaccuracy.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16 (Hodge decomposition)")]#text(" ")#metadata(none) <tao-91be4d936426b3b20f1d>#text(" Define the following three subspaces of the Hilbert space ")#mi("{L^2({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}")#text(":")

#list(
[#mi("{d{\\mathcal E}(\\Omega^0)}")#text(" is the space of all elements of ")#mi("{L^2({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}")#text(" of the form ")#mi("{u = \\nabla f}")#text(" (in the sense of distributions) for some ")#mi("{f \\in H^1({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}")#text(";")],
[#mi("{{\\mathcal H}^1}")#text(" is the space of all elements of ")#mi("{L^2({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}")#text(" that are weakly harmonic in the sense that ")#mi("{\\Delta u = 0}")#text(" (in the sense of distributions).")],
[#mi("{d^*{\\mathcal E}(\\Omega^2)}")#text(" is the space of all elements ")#mi("{u = (u_1,\\dots,u_n)}")#text(" of ")#mi("{L^2({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}")#text(" which take the form")

#align(center)[#tao-fit-display[#mitex("u_i = \\partial_j \\omega_{ij}")]]

#text("(with the usual summation conventions) for some tensor ")#mi("{(\\omega_{ij})_{1 \\leq i,j \\leq d} \\in H^1({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^{d^2})}")#text(" obeying the antisymmetry property ")#mi("{\\omega_{ji} = -\\omega_{ij}}")#text(".")]
)

#list(
[#text("(a) Show that these three spaces are closed subspaces of ")#mi("{L^2({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}")#text(", and one has the orthogonal decomposition")

#align(center)[#tao-fit-display[#mitex("L^2({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d) = d{\\mathcal E}(\\Omega^0) \\oplus {\\mathcal H}^1 \\oplus d^*{\\mathcal E}(\\Omega^2).")]]

#text("This is a simple case of a more general splitting known as the ")#link("https://en.wikipedia.org/wiki/Hodge_theory")[#text("Hodge decomposition")]#text(", which is available for more general differential forms on manifolds.")],
[#text("(b) Show that on ")#mi("{L^2({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}")#text(", the Leray projection ")#mi("{\\mathbb{P}}")#text(" is the orthogonal projection to ")#mi("{{\\mathcal H}^1 \\oplus d^*{\\mathcal E}(\\Omega^2)}")#text(".")],
[#text("(c) Show that the Leray projection is a non-expansive map on ")#mi("{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}")#text(" for all ")#mi("{s \\geq 0}")#text(" (that is to say, its operator norm is at most ")#mi("{1}")#text(").")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Helmholtz decomposition)")]#text(" Define the following two subspaces of the Hilbert space ")#mi("{L^2({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(":")

#list(
[#mi("{H_{\\mathrm{df}}}")#text(" is the space of functions ")#mi("{u \\in L^2({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" which are divergence-free, by which we mean that ")#mi("{\\nabla \\cdot u = 0}")#text(" in the sense of distributions.")],
[#mi("{H_{\\mathrm{cf}}}")#text(" is the space of functions ")#mi("{u \\in L^2({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" which are curl-free, by which we mean that ")#mi("{\\nabla \\wedge u = 0}")#text(" in the sense of distributions, where ")#mi("{\\nabla \\wedge u}")#text(" is the rank two tensor with components ")#mi("{(\\nabla \\wedge u)_{ij} := \\partial_i u_j - \\partial_j u_i}")#text(".")]
)

#list(
[#text("(a) Show that these two spaces are closed subspaces of ")#mi("{L^2({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(", and one has the orthogonal decomposition")

#align(center)[#tao-fit-display[#mitex("L^2({\\bf R}^d \\rightarrow {\\bf R}^d) = H_{\\mathrm{df}} \\oplus H_{\\mathrm{cf}}.")]]

#text("This is known as the ")#link("https://en.wikipedia.org/wiki/Helmholtz_decomposition")[#text("Helmholtz decomposition")]#text(" (particularly in the three-dimensional case ")#mi("{d=3}")#text(", in which one can interpret ")#mi("{\\nabla \\wedge u}")#text(" as the curl of ")#mi("{u}")#text(").")],
[#text("(b) Show that on ")#mi("{L^2({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(", the Leray projection ")#mi("{\\mathbb{P}}")#text(" is the orthogonal projection to ")#mi("{H_{\\mathrm{df}}}")#text(".")],
[#text("(c) Show that the Leray projection is a non-expansive map on ")#mi("{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" for all ")#mi("{s \\geq 0}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18 (Singular integral form of Leray projection)")]#text(" ")#metadata(none) <tao-dbb4e692c9327807fd2d>#text(" Let ")#mi("{d \\geq 3}")#text(". Then the function ")#tao-math("{x \\mapsto \\frac{1}{\\left|x\\right|^{d-2}}}", block: false)#text(" is locally integrable and thus well-defined as a distribution.")

#list(
[#text("(a) For ")#mi("{i,j=1,\\dots,d}")#text(", show that the distribution ")#tao-math("{\\partial_i \\partial_j \\frac{1}{\\left|x\\right|^{d-2}}}", block: false)#text(", defined on test functions ")#mi("{\\phi: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\langle \\partial_i \\partial_j \\frac{1}{\\left|x\\right|^{d-2}}, \\phi \\rangle = \\int_{{\\bf R}^d} \\frac{1}{\\left|x\\right|^{d-2}} \\partial_j \\partial_i \\phi(x)\\ dx,", block: true)]]

#text("can be expressed in principal value form as")

#tao-aligned(keep: true)[


#tao-math("\\langle \\partial_i \\partial_j \\frac{1}{\\left|x\\right|^{d-2}}, \\phi \\rangle  & = (d-2) \\lim_{\\varepsilon \\rightarrow 0} \\int_{\\left|x\\right| > \\varepsilon} (\\frac{d x_i x_j}{\\left|x\\right|^{d+2}}", block: true)



#tao-math(" & - \\frac{\\delta_{ij}}{\\left|x\\right|^d}) \\phi(x)\\ dx - \\frac{d-2}{d} |S^{d-1}|\\delta_{ij} \\phi(0),", block: true)
]

#text("where ")#tao-math("{\\left|S^{d-1}\\right|}", block: false)#text(" denotes the surface area of the unit sphere ")#mi("{S^{d-1}}")#text(" in ")#mi("{{\\bf R}^d}")#text(" and ")#mi("{\\delta_{ij}}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Kronecker_delta")[#text("Kronecker delta")]#text(".")],
[#text("(b) Conclude in particular the ")#link("https://en.wikipedia.org/wiki/Newtonian_potential")[#text("Newtonian potential")]#text(" identity")

#align(center)[#tao-fit-display[#tao-math("\\Delta \\frac{1}{\\left|x\\right|^{d-2}} = - (d-2) |S^{d-1}| \\delta_0", block: true)]]

#text("where (at the risk of a mild notational clash) ")#mi("{\\delta_0}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Dirac_delta")[#text("Dirac delta")]#text(" distribution at ")#mi("{0}")#text(".")],
[#text("(c) For a test vector field ")#mi("{F: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(", establish the explicit form")

#tao-aligned(keep: true)[


#tao-math("(\\mathbb{P} F(x))_i  & = \\frac{d-1}{d} F_i(x)", block: true)



#tao-math(" & + \\lim_{\\varepsilon \\rightarrow 0} \\frac{1}{\\left|S^{d-1}\\right|} \\int_{\\left|y\\right| \\geq \\varepsilon} (\\frac{dy_i y_j F_j(x-y)}{\\left|y\\right|^{d+2}} - \\frac{F_i(x-y)}{\\left|y\\right|^d})\\ dy.", block: true)
]],
[#text("(d) Extend part (c) to the case ")#mi("{d=2}")#text(". (")#emph[#text("Hint:")]#text(" Replace the role of ")#tao-math("{\\frac{1}{d-2} \\frac{1}{\\left|x\\right|^{d-2}}}", block: false)#text(" with ")#tao-math("{\\log \\left|x\\right|}", block: false)#text(", in the spirit of the ")#link("https://en.wikipedia.org/wiki/Replica_trick")[#text("replica trick")]#text(" from physics.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 19")]#text(" One can also solve ")#link(<tao-d1c667af9c5e1c7f6f35>)[#text("(15)")]#text(" in ")#mi("{L^q}")#text("-based Sobolev spaces for exponents ")#mi("{1 < q < \\infty}")#text(" other than ")#mi("{q=2}")#text(" by using Calderón-Zygmund theory and the singular integral form of the Leray projection given in Exercise ")#link(<tao-dbb4e692c9327807fd2d>)[#text("18")]#text(". However, we will try to avoid having to rely on this theory in these notes.")
]

#heading(level: 1)[#strong[#text(" — 3. The heat equation — ")]]

#metadata(none) <tao-d665dc4299392488f716>

#text("We now turn to the study of the heat equation ")#metadata(none) <tao-5a2a0ed9aa3ab7d82b53>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\partial_t u = \\nu \\Delta u")]]

#text(" ")#text(" on a spacetime region ")#mi("{[0,T] \\times {\\bf R}^d}")#text(", with initial data ")#mi("{u(0) = u_0}")#text(", where ")#mi("{\\nu>0}")#text(" is a fixed constant; we also consider the inhomogeneous analog")

#metadata(none) <tao-bf6a766914b296b81a48>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\partial_t u = \\nu \\Delta u + F")]]

#text("with some forcing term ")#mi("{F: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}}")#text(".")

#text("Formally, the solution to the initial value problem for ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(23)")]#text(" should be given by ")#mi("{u(t) = e^{\\nu t \\Delta} u_0}")#text(", and (by the Duhamel formula ")#link(<tao-ffec15c1ff9b51058930>)[#text("(6)")]#text(") the solution to ")#link(<tao-bf6a766914b296b81a48>)[#text("(24)")]#text(" should similarly be")

#align(center)[#tao-fit-display[#mitex("u(t) = e^{\\nu t \\Delta} u_0 + \\int_0^t e^{\\nu (t-s) \\Delta} F(s)\\ ds;")]]

#text("but there are subtleties arising from the unbounded nature of ")#mi("{\\Delta}")#text(".")

#text("The first issue is that even if ")#mi("{u_0}")#text(" vanishes and ")#mi("{u}")#text(" is required to be smooth without any decay hypothesis at infinity, one can have non-uniqueness. The following counterexample is basically ")#link("http://www.mathnet.ru/php/archive.phtml?wshow=paper&jrnid=sm&paperid=6410&option_lang=eng")[#text("due to Tychonoff")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20 (Tychonoff example)")]#text(" Let ")#mi("{1 < \\theta < 2}")#text(" be a real number, and let ")#mi("{\\nu>0}")#text(".")

#list(
[#text("(a) Show that there exists smooth, compactly supported function ")#mi("{\\phi: {\\bf R} \\rightarrow {\\bf R}}")#text(", not identically zero, obeying the derivative bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|\\phi^{(k)}(t)\\right| \\leq (Ck)^{\\theta k}", block: true)]]

#text("for all ")#mi("{k \\geq 0}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(". (")#emph[#text("Hint:")]#text(" one can construct ")#mi("{\\phi = \\psi_1 * \\psi_2 * \\dots}")#text(" as the convolution of an infinite number of approximate identities ")#mi("{\\psi_n}")#text(", where each ")#mi("{\\psi_n}")#text(" is supported on an interval of length ")#mi("{n^{-\\theta}}")#text(", and use the identity ")#mi("{\\frac{d}{dt}(f*g) = (\\frac{d}{dt} f) * g = f * \\frac{d}{dt} g}")#text(" repeatedly. To justify things rigorously, one may need to first work with finite convolutions and take limits.)")],
[#text("(b) With ")#mi("{\\phi}")#text(" as in part (i) show that the function")

#align(center)[#tao-fit-display[#mitex("u(t,x) := \\sum_{k=0}^\\infty \\frac{x^{2k}}{\\nu^k (2k)!} \\phi^{(k)}(t)")]]

#text("is well-defined as a smooth function on ")#mi("{{\\bf R} \\times {\\bf R}}")#text(" that is compactly supported in time, and obeys the heat equation ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(23)")]#text(" for ")#mi("{d=1}")#text(" without being identically zero.")],
[#text("(c) Show that the initial value problem to ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(23)")]#text(" is not unique (for any dimension ")#mi("{d \\geq 1}")#text(") if ")#mi("{u}")#text(" is only required to be smooth, even if ")#mi("{u_0}")#text(" vanishes.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21 (Kowalevski example)")]

#list(
[#text("(a) Let ")#mi("{u_0: {\\bf R} \\rightarrow {\\bf R}}")#text(" be the function ")#mi("{u_0(x) := \\frac{1}{1+x^2}}")#text(". Show that there does not exist any solution ")#mi("{u: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf R}}")#text(" to ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(23)")]#text(" that is jointly real analytic in ")#mi("{t,x}")#text(" at ")#mi("{0}")#text(" (that is to say, it can be expressed as an absolutely convergent power series in ")#mi("{t,x}")#text(" in a neighbourhood of ")#mi("{0}")#text(").")],
[#text("(b) Modify the above example by replacing ")#mi("{\\frac{1}{1+x^2}}")#text(" by a function that extends to an entire function on ")#mi("{{\\bf C}}")#text(" (as opposed to ")#mi("{z \\mapsto \\frac{1}{1+z^2}}")#text(", which has poles at ")#mi("{\\pm i}")#text(").")]
)

#text("This classic example, due to ")#link("https://en.wikipedia.org/wiki/Sofia_Kovalevskaya")[#text("Sofia Kowalevski")]#text(", demonstrates the need for some hypotheses on the PDE in order to invoke the ")#link("https://en.wikipedia.org/wiki/Cauchy%E2%80%93Kowalevski_theorem")[#text("Cauchy-Kowaleski theorem")]#text(".")
]

#text("One can recover uniqueness (forwards in time) by imposing some growth condition at infinity. We give a simple example of this, which illustrates a basic tool in the subject, namely the ")#emph[#text("energy method")]#text(", which is based on understanding the rate of change of various “energy” integrals of integrands which primarily involve quadratic expressions of the solution or its derivatives. The reason for favouring quadratic expressions is that they are more likely to produce integrals with a definite sign (positive definite or negative definite), such as (squares of) ")#mi("{L^2}")#text(" norms or higher Sobolev norms of the solution, particularly after suitable application of integration by parts.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 22 (Uniqueness with energy bounds)")]#text(" ")#metadata(none) <tao-d81b294034bae18f4659>#text(" Let ")#mi("{T>0}")#text(", and let ")#mi("{u, v: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^m}")#text(" be smooth solutions to ")#link(<tao-bf6a766914b296b81a48>)[#text("(24)")]#text(" with common initial data ")#mi("{u(0) = v(0) = u_0}")#text(" and forcing term ")#mi("{F: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^m}")#text(" such that the norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u \\right\\|_{L^\\infty_t L^2_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^m)} := \\sup_{t \\in [0,T]} \\left\\|u(t)\\right\\|_{L^2({\\bf R}^d \\rightarrow {\\bf R}^m)}", block: true)]]

#text("of ")#mi("{u}")#text(" is finite, and similarly for ")#mi("{v}")#text(". Then ")#mi("{u=v}")#text(".")
]

#emph[#text("Proof:")]#text(" As the heat equation ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(23)")]#text(" is linear, we may subtract ")#mi("{v}")#text(" from ")#mi("{u}")#text(" and assume without loss of generality that ")#mi("{v=0}")#text(", ")#mi("{u_0=0}")#text(", and ")#mi("{F=0}")#text(". By working with each component separately we may take ")#mi("{m=1}")#text(".")

#text("Let ")#mi("{\\eta: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" be a non-negative test function supported on ")#mi("{B(0,2)}")#text(" that equals ")#mi("{1}")#text(" on ")#mi("{B(0,1)}")#text(". Let ")#mi("{R>0}")#text(" be a parameter, and consider the “energy” (or more precisely, “local mass”)")

#align(center)[#tao-fit-display[#mitex("E_R(t) := \\int_{{\\bf R}^d} u(t,x)^2 \\eta(x/R)\\ dx")]]

#text("for ")#mi("{t \\in [0,T]}")#text(". As ")#mi("{u(0)=u_0=0}")#text(", we have ")#mi("{E_R(0)=0}")#text(". As ")#mi("{u}")#text(" is smooth and ")#mi("{\\eta}")#text(" is compactly supported, ")#mi("{E_R(t)}")#text(" depends smoothly on ")#mi("{t}")#text(", and we can differentiate under the integral sign to obtain")

#align(center)[#tao-fit-display[#mitex("\\partial_t E_R(t) = 2 \\int_{{\\bf R}^d} u(t,x) \\partial_t u(t,x) \\eta(x/R)\\ dx.")]]

#text("Using ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(23)")]#text(" we thus have")

#align(center)[#tao-fit-display[#mitex("\\partial_t E_R(t) = 2 \\nu \\int_{{\\bf R}^d} u(t,x) \\partial_i \\partial_i u(t,x) \\eta(x/R)\\ dx")]]

#text("using the usual summation conventions.")

#text("A basic rule of thumb in the energy method is this: whenever one is faced with an integral in which one term in the integrand has much lower regularity (or much less control on regularity) than any other, due to a large number of derivatives placed on that term, one should integrate by parts to move one or more derivatives off of that term to other terms in order to make the distribution of derivatives more balanced (which, as we shall see, tends to make the integrals easier to estimate, or to ascribe a definite sign to). Accordingly, we integrate by parts to write")

#tao-aligned(keep: true)[


#tao-math("\\partial_t E_R(t)  & = - 2 \\nu \\int_{{\\bf R}^d} \\partial_i u(t,x) \\partial_i u(t,x) \\eta(x/R)\\ dx", block: true)



#tao-math(" & - 2 \\nu R^{-1} \\int_{{\\bf R}^d} u(t,x) \\partial_i u(t,x) \\partial_i \\eta(x/R)\\ dx.", block: true)
]

#text("The first term is non-positive, thus we may discard it to obtain the inequality")

#align(center)[#tao-fit-display[#mitex("\\partial_t E_R(t) \\leq - 2 \\nu R^{-1} \\int_{{\\bf R}^d} u(t,x) \\partial_i u(t,x) \\partial_i \\eta(x/R)\\ dx.")]]

#text("Another rule of thumb in the energy method is to keep an eye out for opportunities to express some expression appearing in the integrand as a total derivative In this case, we can write")

#align(center)[#tao-fit-display[#mitex("2 u(t,x) \\partial_i u(t,x) = \\partial_i ( u(t,x)^2 )")]]

#text("and then integrate by parts to move the derivative on to the much more slowly varying function ")#mi("{\\eta(x,R)}")#text(" to conclude")

#align(center)[#tao-fit-display[#mitex("\\partial_t E_R(t) \\leq \\nu R^{-2} \\int_{{\\bf R}^d} u(t,x)^2 \\partial_i \\partial_i \\eta(x/R)\\ dx.")]]

#text("In particular we have a bound of the form")

#align(center)[#tao-fit-display[#tao-math("\\partial_t E_R(t) \\lesssim_{\\nu,\\eta} R^{-2} \\left\\| u \\right\\|_{L^\\infty_t L^2_x([0,T] \\times {\\bf R}^d)}^2", block: true)]]

#text("where the subscript indicates that the implied constant can depend on ")#mi("{\\nu}")#text(" and ")#mi("{\\eta}")#text(". Since ")#mi("{E_R(0)=0}")#text(", we conclude from the fundamental theorem of calculus that")

#align(center)[#tao-fit-display[#tao-math("E_R(t) \\lesssim_{\\nu,\\eta,T} R^{-2} \\left\\| u \\right\\|_{L^\\infty_t L^2_x([0,T] \\times {\\bf R}^d)}^2", block: true)]]

#text("for all ")#mi("{t \\in [0,T]}")#text(" (note how it is important here that we evolve forwards in time, rather than backwards). Sending ")#mi("{R \\rightarrow \\infty}")#text(" and using the dominated convergence theorem, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} u(t,x)^2\\ dx \\lesssim_{\\nu,\\eta,T} 0")]]

#text("and thus ")#mi("{u}")#text(" vanishes identically, as required. ")#mi("\\Box")

#text("Now we turn to existence for the heat equation, restricting attention to forward in time solutions. Formally, if one solves the heat equation ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(23)")]#text(", then on taking spatial Fourier transforms")

#align(center)[#tao-fit-display[#mitex("\\hat u(t,\\xi) := \\int_{{\\bf R}^d} u(t,x) e^{-2\\pi i \\xi \\cdot x}\\ dx")]]

#text("the equation transforms to the ODE")

#align(center)[#tao-fit-display[#tao-math("\\partial_t \\hat u(t,\\xi) = - 4\\pi^2 \\nu \\left|\\xi\\right|^2 \\hat u(t,\\xi)", block: true)]]

#text("which when combined with the initial condition ")#mi("{u(0) = u_0}")#text(" gives")

#align(center)[#tao-fit-display[#tao-math("\\hat u(t,\\xi) = e^{- 4\\pi^2 \\nu \\left|\\xi\\right|^2 t} \\hat u_0(\\xi)", block: true)]]

#text("and hence by the Fourier inversion formula we arrive (formally, at least) at the representation")

#metadata(none) <tao-e7e600fb12a8a20d4341>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#tao-math("u(t,x) = \\int_{{\\bf R}^d} e^{- 4\\pi^2 \\nu \\left|\\xi\\right|^2 t} \\hat u_0(\\xi) e^{2\\pi i \\xi \\cdot x}\\ d\\xi.", block: true)]]

#text("As we are assuming forward time evolution ")#mi("{t \\geq 0}")#text(", the exponential factor ")#tao-math("{e^{- 4\\pi^2 \\nu \\left|\\xi\\right|^2 t}}", block: false)#text(" here is bounded. In the case that ")#mi("{u_0:{\\bf R}^d \\rightarrow {\\bf R}^m}")#text(" is a Schwartz function, then ")#mi("{\\hat u_0}")#text(" is also Schwartz, and this formula is certainly well-defined to be smooth in both time and space (and rapidly decreasing in space for any fixed time), and in particular in ")#mi("{L^\\infty_t L^2_x([0,+\\infty) \\times {\\bf R}^d)}")#text("; one can easily justify differentiation under the integral sign to conclude that ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(23)")]#text(" is indeed verified, and the Fourier inversion formula shows that we have the initial data condition ")#mi("{u(0)=u_0}")#text(". So this is the unique solution to the initial value problem ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(23)")]#text(" for the heat equation that lies in ")#mi("{L^\\infty_t L^2_x}")#text(". By definition we declare the right-hand side of ")#link(<tao-e7e600fb12a8a20d4341>)[#text("(25)")]#text(" to be ")#mi("{e^{\\nu t\\Delta} u_0}")#text(", thus")

#metadata(none) <tao-d2320b8c8fba6e5510e2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#tao-math("e^{\\nu t \\Delta} u_0(x) = \\int_{{\\bf R}^d} e^{- 4\\pi^2 \\nu \\left|\\xi\\right|^2 t} \\hat u_0(\\xi) e^{2\\pi i \\xi \\cdot x}\\ d\\xi", block: true)]]

#text("for all ")#mi("{t \\geq 0}")#text(" and all Schwartz functions ")#mi("{u}")#text("; equivalently, one has")

#metadata(none) <tao-7dfd8928a4a3162bbd66>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#tao-math("\\widehat{e^{\\nu t \\Delta} u_0}(\\xi) = e^{- 4\\pi^2 \\nu \\left|\\xi\\right|^2 t} \\hat u_0(\\xi).", block: true)]]

#text("(One can justify this choice of notation using the functional calculus of the self-adjoint operator ")#mi("{\\Delta}")#text(", as discussed for instance in ")#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/")[#text("this previous blog post")]#text(", but we will not do so here since the Fourier transform is available as a substitute.) It is also clear from ")#link(<tao-7dfd8928a4a3162bbd66>)[#text("(27)")]#text(" that ")#mi("{e^{\\nu t\\Delta}}")#text(" commutes with other Fourier multipliers such as ")#mi("{\\langle \\nabla \\rangle^s}")#text(" or constant-coefficient differential operators, on Schwartz functions at least.")

#text("From ")#link(<tao-7dfd8928a4a3162bbd66>)[#text("(27)")]#text(" and Plancherel’s theorem we see that ")#mi("{e^{\\nu t \\Delta}}")#text(" for ")#mi("{t \\geq 0}")#text(" is a non-expansive map in (the Schwartz functions of) ")#mi("{L^2({\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(", and more generally in ")#mi("{H^s({\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(" for any ")#mi("{s \\geq 0}")#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\| e^{\\nu t \\Delta} u_0 \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^m)} \\leq \\left\\| u_0 \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^m)}", block: true)]]

#text("for any Schwartz ")#mi("{u_0: {\\bf R}^d \\rightarrow {\\bf R}^m}")#text(" and any ")#mi("{s, t \\geq 0}")#text(". Thus by density one can extend the heat propagator ")#mi("{e^{\\nu t \\Delta}}")#text(" for ")#mi("{t \\geq 0}")#text(" to all of ")#mi("{L^2({\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(", in a fashion that is a non-expansive map on ")#mi("{L^2({\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(" and more generally on ")#mi("{H^s({\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(". By a limiting argument, ")#link(<tao-7dfd8928a4a3162bbd66>)[#text("(27)")]#text(" holds almost everywhere for all ")#mi("{u_0 \\in L^2({\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(".")

#text("There is also a smoothing effect:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23 (Smoothing effect)")]#text(" ")#metadata(none) <tao-3637a614cb738f813fb7>#text(" Let ")#mi("{s^{\\prime} \\geq s \\geq 0}")#text(". Show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| e^{\\nu t \\Delta} u_0 \\right\\|_{H^{s^{\\prime}}({\\bf R}^d \\rightarrow {\\bf R}^m)} \\lesssim_{s,s^{\\prime}} (1+(\\nu t)^{-\\frac{s^{\\prime}-s}{2}}) \\left\\| u_0 \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^m)}", block: true)]]

#text("for all ")#mi("{u_0 \\in H^s({\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(" and ")#mi("{\\nu, t > 0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24 (Fundamental solution for the heat equation)")]#text(" For ")#mi("{u_0 \\in L^2({\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(" and ")#mi("{t>0}")#text(", establish the identity")

#align(center)[#tao-fit-display[#tao-math("e^{\\nu t \\Delta} u_0(x) = \\frac{1}{(4\\pi \\nu t)^{d/2}} \\int_{{\\bf R}^d} e^{-\\frac{\\left|x-y\\right|^2}{4\\nu t}} u_0(y)\\ dy.", block: true)]]

#text("for almost every ")#mi("{x \\in {\\bf R}^d}")#text(". (")#emph[#text("Hint:")]#text(" first work with Schwartz functions. Either compute the Fourier transform explicitly, or verify directly that the heat equation initial value problem is solved by the right-hand side.) Conclude in particular that (after modification on a measure zero set if necessary) ")#mi("{e^{\\nu t \\Delta} u_0}")#text(" is smooth for any ")#mi("{t>0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25 (Ill-posedness of the backwards heat equation)")]#text(" Show that there exists a Schwartz function ")#mi("{u_0: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" with the property that there is no solution ")#mi("{u \\in L^\\infty_t L^2_x([-T,0] \\times {\\bf R}^d \\rightarrow {\\bf R})}")#text(" to ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(23)")]#text(" with final data ")#mi("{u(0)=u_0}")#text(" for any ")#mi("{-T < 0}")#text(". (")#emph[#text("Hint:")]#text(" choose ")#mi("{u_0}")#text(" so that the Fourier transform ")#mi("{\\hat u_0}")#text(" decays somewhat, but not extremely rapidly. Then argue by contradiction using ")#link(<tao-7dfd8928a4a3162bbd66>)[#text("(27)")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26 (Continuity in the strong operator topology)")]#text(" For any ")#mi("{s \\geq 0}")#text(", let ")#mi("{C^0_t H^s_x([0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(" denote the Banach space of functions ")#mi("{u: [0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^m}")#text(" such that for each ")#mi("{t}")#text(", ")#mi("{u(t)}")#text(" lies in ")#mi("{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(" and varies continuously and boundedly in ")#mi("{t}")#text(" in the strong topology, with norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u \\right\\|_{C^0_t H^s_x([0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^m)} := \\sup_{t \\in [0,+\\infty)} \\left\\| u(t) \\right\\|_{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^m)}.", block: true)]]

#text("Show that if ")#mi("{u_0 \\in H^s_x({\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(" and ")#mi("{u(t) = e^{\\nu t \\Delta} u_0}")#text(" solves the heat equation on ")#mi("{[0,+\\infty) \\times {\\bf R}^d}")#text(", then ")#mi("{u \\in C^0_t H^s_x([0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u \\right\\|_{C^0_t H^s_x([0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^m)} \\leq \\left\\| u_0 \\right\\|_{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^m)}.", block: true)]]
]

#text("Similar considerations apply to the inhomogeneous heat equation ")#link(<tao-bf6a766914b296b81a48>)[#text("(24)")]#text(". If ")#mi("{u_0: {\\bf R}^d \\rightarrow {\\bf R}^m}")#text(" and ")#mi("{F: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^m}")#text(" are Schwartz for some ")#mi("{T>0}")#text(", then the function ")#mi("{u: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^m}")#text(" defined by the Duhamel formula ")#metadata(none) <tao-4cffce0a7ebf3a1cbade>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("u(t) := e^{\\nu t \\Delta} u_0 + \\int_0^t e^{\\nu(t-s) \\Delta} F(s)\\ ds")]]

#text(" ")#text(" can easily be verified to also be Schwartz and solve ")#link(<tao-bf6a766914b296b81a48>)[#text("(24)")]#text(" with initial data ")#mi("{u_0}")#text("; by Proposition ")#link(<tao-d81b294034bae18f4659>)[#text("22")]#text(", this is the only such solution in ")#mi("{L^\\infty_t L^2_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(". It also obeys good estimates:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27 (Energy estimates)")]#text(" Let ")#mi("{u_0: {\\bf R}^d \\rightarrow {\\bf R}}")#text(", ")#mi("{F: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}}")#text(", and ")#mi("{G: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" be Schwartz functions for some ")#mi("{T>0}")#text(", and let ")#mi("{u}")#text(" be the solution to the equation")

#align(center)[#tao-fit-display[#mitex("\\partial_t u = \\nu \\Delta u + F + \\nabla \\cdot G")]]

#text("with initial condition ")#mi("{u(0) = u_0}")#text(" given by the Duhamel formula. For any ")#mi("{s \\geq 0}")#text(", establish the energy estimate")

#metadata(none) <tao-381cfb6e1e428419d5d6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#tao-math("\\left\\| u \\right\\|_{C^0_t H^s_x([0,T] \\times {\\bf R}^d\\rightarrow {\\bf R})} + \\nu^{1/2} \\left\\| \\nabla u \\right\\|_{L^2_t H^s_x([0,T] \\times {\\bf R}^d\\rightarrow {\\bf R})}", block: true)]]

#tao-aligned(keep: true)[


#tao-math(" & \\lesssim \\left\\|u_0\\right\\|_{H^s_x({\\bf R}^d \\rightarrow {\\bf R})} + \\left\\| F \\right\\|_{L^1_t H^s_x([0,T] \\times {\\bf R}^d\\rightarrow {\\bf R})}", block: true)



#tao-math(" & + \\nu^{-1/2} \\left\\| G \\right\\|_{L^2_t H^s_x([0,T] \\times {\\bf R}^d\\rightarrow {\\bf R}^d)}", block: true)
]

#text("in two different ways:")

#list(
[#text("(i) By using the Fourier representation ")#link(<tao-7dfd8928a4a3162bbd66>)[#text("(27)")]#text(" and Plancherel’s formula;")],
[#text("(ii) By using energy methods as in the proof of Proposition ")#link(<tao-d81b294034bae18f4659>)[#text("22")]#text(". (")#emph[#text("Hint:")]#text(" first reduce to the case ")#mi("{s=0}")#text(". You may find the arithmetic mean-geometric mean inequality ")#mi("{ab \\leq \\frac{1}{2} a^2 + \\frac{1}{2} b^2}")#text(" to useful.)")]
)

#text("Here of course we are using the norms")

#align(center)[#tao-fit-display[#tao-math("\\left\\| F \\right\\|_{L^1_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^m)} := \\int_{[0,T]} \\left\\| F(t) \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^m)}\\ dt", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| G \\right\\|_{L^2_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^m)} := (\\int_{[0,T]} \\left\\| G(t) \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^m)}^2\\ dt)^{1/2}", block: true)]]
]

#text("The energy estimate contains some smoothing effects similar (though not identical) to those in Exercise ")#link(<tao-3637a614cb738f813fb7>)[#text("23")]#text(", since it shows that ")#mi("{u}")#text(" can in principle be one degree of regularity smoother than ")#mi("{u_0}")#text(" (if one averages in time in an ")#mi("{L^2}")#text(" sense, and the viscosity ")#mi("{\\nu}")#text(" is not sent to zero), and two degrees of regularity smoother than the forcing term ")#mi("{\\nabla G}")#text(" (with the same caveats). As we shall shortly see, this smoothing effect will allow us to handle the nonlinear terms in the Navier-Stokes equations for the purposes of setting up a local well-posedness theory.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28 (Distributional solution)")]#text(" Let ")#mi("{s \\geq 0}")#text(", let ")#mi("{u_0 \\in H^s({\\bf R}^d \\rightarrow {\\bf R})}")#text(", and let ")#mi("{F \\in C^0_t H^s_x( [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R})}")#text(" for some ")#mi("{T>0}")#text(". Let ")#mi("{u \\in C^0_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R})}")#text(" be given by the Duhamel formula ")#link(<tao-4cffce0a7ebf3a1cbade>)[#text("(28)")]#text(". Show that ")#link(<tao-bf6a766914b296b81a48>)[#text("(24)")]#text(" is true in the spacetime distributional sense, or more precisely that")

#metadata(none) <tao-1a35b4fbb7dd4460bce6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\langle \\partial_t u(t), \\phi \\rangle = \\langle \\nu\\Delta u + F, \\phi \\rangle")]]

#text("in the sense of spacetime distributions for any test function ")#mi("{\\phi: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}}")#text(" supported in the interior of ")#mi("{[0,T] \\times {\\bf R}^d}")#text(".")
]

#text("Pretty much all of the above discussion can be extended to the periodic setting:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" ")#metadata(none) <tao-15f5bbc66cfcfdfb89ba>#text(" Let ")#mi("{d,m \\geq 1}")#text(" and ")#mi("{\\nu > 0}")#text(".")

#list(
[#text("(a) If ")#mi("{u_0: {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m}")#text(" is smooth, define ")#mi("{e^{\\nu t\\Delta} u: {\\bf R}^d/ \t{\\bf Z}^d \\rightarrow {\\bf R}^m}")#text(" by the formula")

#metadata(none) <tao-1b82757a9d6f5159dae2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#tao-math("e^{\\nu t \\Delta} u_0(x) := \\sum_{k \\in {\\bf Z}^d} e^{-4\\pi^2 \\left|k\\right|^2 \\nu t} \\hat u_0(k) e^{2\\pi i k \\cdot x}", block: true)]]

#text("where ")#mi("{\\hat u_0(k) := \\int_{{\\bf R}^d/{\\bf Z}^d} u(x) e^{-2\\pi i k \\cdot x}}")#text(" are the Fourier coefficients of ")#mi("{u_0}")#text(". Show that ")#mi("{e^{\\nu t\\Delta}}")#text(" extends continuously to a non-expansive map on ")#mi("{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m)}")#text(" for every ")#mi("{s \\geq 0}")#text(", and that if ")#mi("{u_0 \\in H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m)}")#text(" then the function ")#mi("{(t,x) \\mapsto e^{\\nu t\\Delta} u_0(x)}")#text(" lies in ")#mi("{C^0_t H^s_x([0,+\\infty) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m)}")#text(".")],
[#text("(b) For ")#mi("{u_0 \\in L^2({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m)}")#text(" and ")#mi("{t>0}")#text(", establish the formula")

#align(center)[#tao-fit-display[#tao-math("e^{\\nu t \\Delta} u_0(x) = \\frac{1}{(4\\pi \\nu t)^{d/2}} \\int_{{\\bf R}^d} e^{-\\frac{\\left|x-y\\right|^2}{4\\nu t}} u_0(y)\\ dy.", block: true)]]

#text("for almost every ")#mi("{x \\in {\\bf R}^d}")#text(", where (by abuse of notation) we identify functions ")#mi("{u: {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m}")#text(" with ")#mi("{{\\bf Z}^d}")#text("-periodic functions ")#mi("{u: {\\bf R}^d \\rightarrow {\\bf R}^m}")#text(" in the usual fashion.")],
[#text("(c) If ")#mi("{T > 0}")#text(", and ")#mi("{u_0: {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m}")#text(" and ")#mi("{F: [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m}")#text(" are smooth, show that the function ")#mi("{u: [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m}")#text(" defined by ")#link(<tao-4cffce0a7ebf3a1cbade>)[#text("(28)")]#text(" is smooth and solves the inhomogeneous equation ")#link(<tao-bf6a766914b296b81a48>)[#text("(24)")]#text(" with initial data ")#mi("{u(0) = u_0}")#text(", and that this is the unique smooth solution to that initial value problem.")],
[#text("(d) If ")#mi("{T > 0}")#text(", ")#mi("{s \\geq 0}")#text(", and ")#mi("{u_0: {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m}")#text(" and ")#mi("{F: [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m}")#text(", ")#mi("{G: [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^{d \\times m}}")#text(" are smooth, and ")#mi("{u}")#text(" is the unique smooth solution to the heat equation ")#mi("{\\partial_t u = \\nu \\Delta u + F + \\nabla \\cdot G}")#text(" with ")#mi("{u(0)=u_0}")#text(", establish the energy estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u \\right\\|_{C^0_t H^s_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m)} + \\nu^{1/2} \\left\\| \\nabla u \\right\\|_{L^2_t H^s_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m)}", block: true)]]

#tao-aligned(keep: true)[


#tao-math(" & \\lesssim \\left\\|u_0 \\right\\|_{H^s_x({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m)} + \\left\\| F \\right\\|_{L^1_t H^s_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m)}", block: true)



#tao-math(" & + \\nu^{-1/2} \\left\\| G \\right\\|_{L^2_t H^{s}_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^{d \\times m})}.", block: true)
]],
[#text("(e) If ")#mi("{T>0}")#text(", ")#mi("{u_0 \\in H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m)}")#text(" and ")#mi("{F \\in C^0_t H^s([0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m)}")#text(", show that the function ")#mi("{u}")#text(" given by ")#link(<tao-4cffce0a7ebf3a1cbade>)[#text("(28)")]#text(" is in ")#mi("{C^0_t H^s_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^m)}")#text(" and obeys ")#link(<tao-bf6a766914b296b81a48>)[#text("(24)")]#text(" in the sense of spacetime distributions ")#link(<tao-1a35b4fbb7dd4460bce6>)[#text("(30)")]#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 30")]#text(" The heat equation for negative viscosities ")#mi("{\\nu < 0}")#text(" can be transformed into a positive viscosity heat equation by time reversal: if ")#mi("{u}")#text(" solves the equation ")#mi("{\\partial_t u = - \\nu \\Delta u}")#text(", then ")#mi("{(t,x) \\mapsto (-t, x)}")#text(" solves the equation ")#mi("{\\partial_t u = \\nu \\Delta u}")#text(". Thus one can solve negative viscosity heat equations (also known as ")#emph[#text("backwards heat equations")]#text(") backwards in time, but one tends not to have well-posedness forwards in time. In a similar spirit, if ")#mi("{\\nu}")#text(" is positive, one can normalise it to (say) ")#mi("{1}")#text(" by an appropriate rescaling of the time variable, ")#mi("{t \\mapsto t/\\nu}")#text(". However, we will generally keep the parameter ")#mi("{\\nu}")#text(" non-normalised in preparation for understanding the limit as ")#mi("{\\nu \\rightarrow 0}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 4. Local well-posedness for Navier-Stokes — ")]]

#text("We now have all the ingredients necessary to create a local well-posedness theory for the Navier-Stokes equations ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(".")

#text("We first dispose of the one-dimensional case ")#mi("{d=1}")#text(", which is rather degenerate as incompressible one-dimensional fluids are somewhat boring. Namely, suppose that one had a smooth solution to the one-dimensional Navier-Stokes equations")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u + u \\partial_x u  & = - \\partial_x p + \\nu \\partial_{xx} u", block: true)



#tao-math("\\partial_x u  & = 0.", block: true)
]

#text("The second equation implies that ")#mi("{u}")#text(" is just a function of time, ")#mi("{u = u(t)}")#text(", and the first equation becomes")

#align(center)[#tao-fit-display[#mitex("u^{\\prime}(t) = - \\partial_x p(t,x).")]]

#text("To solve this equation, one can set ")#mi("{u: {\\bf R} \\rightarrow {\\bf R}}")#text(" to be an arbitrary smooth function of time, and then set")

#align(center)[#tao-fit-display[#mitex("p(t,x) = a(t) - u^{\\prime}(t) x")]]

#text("for an arbitrary smooth function ")#mi("{a: {\\bf R} \\rightarrow {\\bf R}}")#text(". If one requires the pressure to be bounded, then ")#mi("{u^{\\prime}}")#text(" vanishes identically, and then ")#mi("{u}")#text(" is constant in time, which among other things shows that the initial value problem is (rather trivially) well-posed in the category of smooth solutions, up to the ability to alter the pressure by an arbitrary constant ")#mi("{a(t)}")#text(". On the other hand, if one does not require the pressure to stay bounded, then one has a lot less uniqueness, since the function ")#mi("{u(t)}")#text(" is essentially unconstrained.")

#text("Now we work in two or higher dimensions ")#mi("{d \\geq 2}")#text(", and consider solutions to ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" on the spacetime region ")#mi("{[0,T] \\times {\\bf R}^d}")#text(". To begin with, we assume that ")#mi("{u: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" is smooth and periodic in space: ")#mi("{u(t,x+n) = u(t,x)}")#text(" for ")#mi("{n \\in {\\bf Z}^d}")#text("; we assume ")#mi("{p}")#text(" is smooth but do not place any periodicity hypotheses on it. Then, by ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(", ")#mi("{\\nabla p}")#text(" is periodic. In particular, for any ")#mi("{n \\in {\\bf Z}^d}")#text(" and ")#mi("{t}")#text(", the function ")#mi("{x \\mapsto p(t,x+n)-p(t,x)}")#text(" has vanishing gradient and is thus constant in ")#mi("{x}")#text(", so that")

#align(center)[#tao-fit-display[#mitex("p(t,x+n) - p(t,x) = a_n(t)")]]

#text("for all ")#mi("{x \\in {\\bf R}^d}")#text(" and some function ")#mi("{a_n(t)}")#text(" of ")#mi("{t}")#text(". The map ")#mi("{n \\mapsto a_n(t)}")#text(" is a homomorphism for fixed ")#mi("{t}")#text(", so we can write ")#mi("{a_n(t) = n \\cdot a(t)}")#text(" for some ")#mi("{a: [0,T] \\rightarrow {\\bf R}^d}")#text(", which will be smooth since ")#mi("{p}")#text(" is smooth. We thus have ")#mi("{p(t,x) = p_0(t,x) + x \\cdot a(t)}")#text(" for some smooth ")#mi("{{\\bf Z}^d}")#text("-periodic function ")#mi("{p_0}")#text(". By subtracting off the mean, we can further decompose")

#align(center)[#tao-fit-display[#mitex("p(t,x) = p_1(t,x) + x \\cdot a(t) + r(t)")]]

#text("for some smooth function ")#mi("{r: [0,T] \\rightarrow {\\bf R}}")#text(" and some smooth ")#mi("{{\\bf Z}^d}")#text("-periodic function ")#mi("{p_1: [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}}")#text(" which has mean zero at every time.")

#text("Note that one can simply omit the constant term ")#mi("{r(t)}")#text(" from the pressure without affecting the system ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(". One can also eliminate the linear term ")#mi("{x \\cdot a(t)}")#text(" by the following “generalised ")#link("https://en.wikipedia.org/wiki/Galilean_transformation")[#text("Galilean transformation")]#text("“. If ")#mi("{u, p, p_1, a, r}")#text(" are as above, and one lets")

#align(center)[#tao-fit-display[#mitex("v(t) := \\int_0^t a(s)\\ ds")]]

#text("be the primitive of ")#mi("{a}")#text(", and")

#align(center)[#tao-fit-display[#mitex("X(t) := \\int_0^t v(s)\\ ds")]]

#text("be the primitive of ")#mi("{v}")#text(", then a short calculation reveals that the smooth function ")#mi("{u_2: [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("u_2(t, x) := u(t, x - X(t)) + v(t)")]]

#text("and the smooth function ")#mi("{p_2: [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("p_2(t,x) := p_1(t,x - X(t))")]]

#text("solves the Navier-Stokes equations")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u_2 + u_2 \\cdot \\nabla u_2  & = - \\nabla p_2 + \\nu \\Delta u_2", block: true)



#tao-math("\\nabla \\cdot u_2  & = 0", block: true)
]

#text("with ")#mi("{u_2}")#text(" having the same initial data as ")#mi("{u}")#text("; conversely, if ")#mi("{(u_2,p_2)}")#text(" is a solution to Navier-Stokes, then so is ")#mi("{(u,p)}")#text(". In particular this reveals a lack of uniqueness for the periodic Navier-Stokes equations that is essentially the same lack of uniqueness that is present for the Leray system: one can add an arbitrary spatially affine function to the pressure ")#mi("{p}")#text(" by applying a suitable Galilean transform to ")#mi("{u}")#text(". On the other hand, we can eliminate this lack of uniqueness by requiring that the pressure be ")#emph[#text("normalised")]#text(" in the sense that ")#mi("{a(t)=0}")#text(" and ")#mi("{r(t)=0}")#text(", that is to say we require ")#mi("{p}")#text(" to be ")#mi("{{\\bf Z}^d}")#text("-periodic and mean zero. The above discussion shows that any smooth solution to Navier-Stokes with ")#mi("{u}")#text(" periodic can be transformed by a Galilean transformation to one in which the pressure is normalised.")

#text("Once the pressure is normalised, it turns out that one can recover uniqueness (much as was the case with the Leray system):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 31 (Uniqueness with normalised pressure)")]#text(" ")#metadata(none) <tao-f1e185a66379145b883e>#text(" Let ")#mi("{(u_1,p_1), (u_2,p_2)}")#text(" be two smooth periodic solutions to ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" on ")#mi("{[0,T] \\times {\\bf R}^d}")#text(" with normalised pressure such that ")#mi("{u_1(0)=u_2(0)}")#text(". Then ")#mi("{(u_1,p_1)=(u_2,p_2)}")#text(".")
]

#emph[#text("Proof:")]#text(" We use the energy method. Write ")#mi("{w = u_1 - u_2}")#text(", then subtracting ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" for ")#mi("{(u_1,p_1)}")#text(" from ")#mi("{(u_2,p_2)}")#text(" we see that ")#mi("{w: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" is smooth with")

#align(center)[#tao-fit-display[#mitex("\\partial_t w + (u_1 \\cdot \\nabla) w + (w \\cdot \\nabla) u_2 = \\nu \\Delta w - \\nabla (p_1 - p_2)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\nabla \\cdot w = 0.")]]

#text("Now we consider the energy ")#tao-math("{E(t) := \\int_{{\\bf R}^d/{\\bf Z}^d} \\left|w(t,x)\\right|^2\\ dx}", block: false)#text(". This varies smoothly with ")#mi("{t}")#text(", and we can differentiate under the integral sign to obtain")

#tao-aligned(keep: true)[


#tao-math("\\partial_t E(t)  & = 2 \\int_{{\\bf R}^d/{\\bf Z}^d} w(t,x) \\cdot \\partial_t w(t,x)\\ dx", block: true)



#tao-math(" & = A + B + C+ D", block: true)
]

#text("where")

#tao-aligned(keep: true)[


#tao-math("A  & := - 2 \\int_{{\\bf R}^d/{\\bf Z}^d} w \\cdot (u_1 \\cdot \\nabla) w\\ dx", block: true)



#tao-math("B  & := -2 \\int_{{\\bf R}^d/{\\bf Z}^d} w\\cdot (w \\cdot \\nabla) u_2\\ dx", block: true)



#tao-math("C  & := 2\\nu \\int_{{\\bf R}^d/{\\bf Z}^d} w \\partial_i \\partial_i w\\ dx", block: true)



#tao-math("D  & := - 2 \\int_{{\\bf R}^d/{\\bf Z}^d} w \\cdot \\nabla (p_1-p_2)\\ dx", block: true)
]

#text("and we have omitted the explicit dependence on ")#mi("{t}")#text(" and ")#mi("{x}")#text(" for brevity.")

#text("For ")#mi("{A}")#text(", we observe the total derivative ")#tao-math("{2 w \\cdot (u_1 \\cdot \\nabla) w = (u_1 \\cdot \\nabla) \\left|w\\right|^2}", block: false)#text(" and integrate by parts to conclude that")

#align(center)[#tao-fit-display[#tao-math("A = \\int_{{\\bf R}^d/{\\bf Z}^d} (\\nabla \\cdot u_1) \\left|w\\right|^2\\ dx = 0", block: true)]]

#text("since ")#mi("{u_1}")#text(" is divergence-free. Similarly, integration by parts shows that ")#mi("{D}")#text(" vanishes since ")#mi("{w}")#text(" is divergence-free. Another integration by parts gives")

#align(center)[#tao-fit-display[#mitex("C = - 2\\nu \\int_{{\\bf R}^d/{\\bf Z}^d} \\partial_i w \\partial_i w\\ dx")]]

#text("and hence ")#mi("{C \\leq 0}")#text(". Finally, from Hölder’s inequality we have")

#align(center)[#tao-fit-display[#tao-math("B \\leq 2 E(t) \\left\\|\\nabla u_2 \\right\\|_{L^\\infty_t L^\\infty_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d)}", block: true)]]

#text("and hence")

#align(center)[#tao-fit-display[#tao-math("\\partial_t E(t) \\leq 2 E(t) \\left\\|\\nabla u_2 \\right\\|_{L^\\infty_t L^\\infty_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d)}.", block: true)]]

#text("Since ")#mi("{E(0)=0}")#text(", we conclude from Gronwall’s inequality that ")#mi("{E(t) \\leq 0}")#text(" for all ")#mi("{t \\in [0,T]}")#text(", and hence ")#mi("{w}")#text(" is identically zero, thus ")#mi("{u_1=u_2}")#text(". Substituting this into ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" we conclude that ")#mi("{\\nabla p_1 = \\nabla p_2}")#text("; as ")#mi("{p_1,p_2}")#text(" have mean zero, we conclude (e.g., from Fourier inversion) that ")#mi("{p_1=p_2}")#text(", and the claim follows. ")#mi("\\Box")

#text("Now we turn to existence in the periodic setting, assuming normalised pressure. For various technical reasons, it is convenient to reduce to the case when the velocity field ")#mi("{u}")#text(" has zero mean. Observe that the right-hand sides ")#mi("{\\nu \\Delta u}")#text(", ")#mi("{\\nabla p}")#text(" of ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" have zero mean on ")#mi("{{\\bf R}^d/{\\bf Z}^d}")#text(", thanks to integration by parts. A further integration by parts, using the divergence-free condition ")#mi("{\\nabla \\cdot u = 0}")#text(", reveals that the transport term ")#mi("{(u \\cdot \\nabla) u}")#text(" also has zero mean:")

#tao-aligned(keep: true)[


#tao-math("\\int_{{\\bf R}^d/{\\bf Z}^d} ((u \\cdot \\nabla) u)_i\\ dx  & = \\int_{{\\bf R}^d/{\\bf Z}^d} u_j \\partial_j u_i\\ dx", block: true)



#tao-math(" & = - \\int_{{\\bf R}^d/{\\bf Z}^d} (\\partial_j u_j) u_i\\ dx", block: true)



#tao-math(" & = 0.", block: true)
]

#text("Thus, we see that the mean ")#mi("{\\int_{{\\bf R}^d/{\\bf Z}^d} u(t,x)\\ dx}")#text(" is a conserved integral of motion: if ")#mi("{v_0 := \\int_{{\\bf R}^d/{\\bf Z}^d} u_0(x)\\ dx}")#text(" is the mean initial velocity, and ")#mi("{(u,p)}")#text(" is a solution to ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" (obeying some minimal regularity hypothesis), then ")#mi("{u(t)}")#text(" continues to have mean velocity ")#mi("{v_0}")#text(" for all subsequent times. On the other hand, if ")#mi("{(u,p)}")#text(" is a smooth periodic solution to ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" with normalised pressure and initial velocity ")#mi("{u_0}")#text(", then the Galilean transform ")#mi("{(\\tilde u, \\tilde p)}")#text(" defined by")

#tao-aligned(keep: true)[


#tao-math("\\tilde u(t,x)  & := u(t, x + v_0 t) - v_0", block: true)



#tao-math("\\tilde p(t,x)  & := p(t, x + v_0 t)", block: true)
]

#text("can be easily verified to be a smooth periodic solution to ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" with normalised pressure and initial velocity ")#mi("{u_0 - v_0}")#text(". Of course, one can reconstruct ")#mi("{(u,p)}")#text(" from ")#mi("{(\\tilde u,\\tilde p)}")#text(" by the inverse tranformation")

#tao-aligned(keep: true)[


#tao-math("u(t,x)  & = \\tilde u(t, x - v_0 t) + v_0", block: true)



#tao-math("p(t,x)  & = \\tilde p(t, x - v_0 t).", block: true)
]

#text("Thus, up to this simple transformation, solving the initial value problem for ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" for ")#mi("{u_0}")#text(" is equivalent to that of ")#mi("{u_0-v_0}")#text(", so we may assume without loss of generality that the initial velocity (and hence the velocity at all subsequent times) has zero mean.")

#text("A general rule of thumb is that whenever an integral of a solution to a PDE can be proven to vanish (or be equal to boundary terms) by integration by parts, it is because the integrand can be rewritten in “divergence form” – as the divergence of a tensor of one higher rank. (This is because the integration by parts identity ")#mi("{\\int f \\partial_i g = - \\int (\\partial_i f) g}")#text(" arises from the divergence form ")#mi("{\\partial_i(fg)}")#text(" of the expression ")#mi("{f \\partial_i g + (\\partial_i f) g}")#text(".) Thus we expect the transport term ")#mi("{(u \\cdot \\nabla) u}")#text(" to be in divergence form. Indeed, in components we have")

#align(center)[#tao-fit-display[#mitex("((u \\cdot \\nabla) u)_i = u_j \\partial_j u_i;")]]

#text("since we have the divergence-free condition ")#mi("{\\partial_j u_j=0}")#text(", we thus have from the Leibniz rule that")

#align(center)[#tao-fit-display[#mitex("((u \\cdot \\nabla) u)_i = \\partial_j (u_j u_i).")]]

#text("We write this in coordinate-free notation as")

#align(center)[#tao-fit-display[#mitex("(u \\cdot \\nabla) u = \\nabla \\cdot (u \\otimes u)")]]

#text("where ")#mi("{u \\otimes u}")#text(" is the tensor product ")#mi("{(u \\otimes u)_{ji} := u_j u_i}")#text(" and ")#mi("{\\nabla \\cdot (u \\otimes u)}")#text(" denotes the divergence")

#align(center)[#tao-fit-display[#mitex("(\\nabla \\cdot (u \\otimes u))_i = \\partial_j (u \\otimes u)_{ji}.")]]

#text("Thus we can rewrite ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" as the system")

#metadata(none) <tao-1df3da78f6882427fe6e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("\\partial_t u + \\nabla \\cdot (u \\otimes u) = \\nu \\Delta u - \\nabla p")]]

#text("Next, we observe that we can use the Leray projection operator ")#mi("{\\mathbb{P}}")#text(" to eliminate the role of the (normalised) pressure. Namely, if ")#mi("{(u,p)}")#text(" are a smooth periodic solution to ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" with normalised pressure, then on applying ")#mi("{\\mathbb{P}}")#text(" (which preserves divergence-free vector fields such as ")#mi("{\\partial_t u}")#text(" and ")#mi("{\\Delta u}")#text(", but annihilates gradients such as ")#mi("{\\nabla p}")#text(") we conclude an equation that does not involve the pressure at all: ")#metadata(none) <tao-6f035df254ed46ba11c5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("\\partial_t u + \\mathbb{P}( \\nabla \\cdot (u \\otimes u) ) = \\nu \\Delta u.")]]

#text(" ")#text(" Conversely, suppose that one has a smooth periodic solution ")#mi("{u: [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d}")#text(" to ")#link(<tao-6f035df254ed46ba11c5>)[#text("(33)")]#text(" with initial condition ")#mi("{u(0)=u_0}")#text(" for some smooth periodic divergence-free vector field ")#mi("{u_0: {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d}")#text(". Taking divergences of both sides of ")#link(<tao-6f035df254ed46ba11c5>)[#text("(33)")]#text(", we then conclude that")

#align(center)[#tao-fit-display[#mitex("\\partial_t (\\nabla \\cdot u) = \\nu \\Delta (\\nabla \\cdot u),")]]

#text("that is to say ")#mi("{\\nabla \\cdot u}")#text(" obeys the heat equation ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(23)")]#text(". Since ")#mi("{\\nabla \\cdot u}")#text(" is periodic, smooth, and vanishes at ")#mi("{0}")#text(", we see from Exercise ")#link(<tao-15f5bbc66cfcfdfb89ba>)[#text("29")]#text("(c) that ")#mi("{\\nabla \\cdot u}")#text(" vanishes on all of ")#mi("{[0,T] \\times {\\bf R}^d/{\\bf Z}^d}")#text(", thus ")#mi("{u}")#text(" is divergence free on the entire time interval ")#mi("{[0,T]}")#text(". From ")#link(<tao-6f035df254ed46ba11c5>)[#text("(33)")]#text(" and ")#link(<tao-42db0bfebfce2fece1e7>)[#text("(22)")]#text(" we thus see that if one defines ")#mi("{p: [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}}")#text(" to be the function")

#align(center)[#tao-fit-display[#mitex("p := - \\Delta^{-1} (\\nabla \\cdot \\nabla \\cdot (u \\otimes u))")]]

#text("(which can easily be verified to be a smooth function in both space and time) then ")#mi("{(u,p)}")#text(" is a smooth periodic solution to ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" with normalised pressure and initial condition ")#mi("{u(0)=u_0}")#text(" (and is thus the unique solution to this system, thanks to Theorem ")#link(<tao-f1e185a66379145b883e>)[#text("31")]#text("). Thus, the problem of finding a smooth solution to ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" in the smooth periodic setting with normalised pressure and divergence-free initial data ")#mi("{u(0)=u_0}")#text(" is equivalent to that of solving ")#link(<tao-6f035df254ed46ba11c5>)[#text("(33)")]#text(" with the same initial data.")

#text("By Duhamel’s formula (Exercise ")#link(<tao-15f5bbc66cfcfdfb89ba>)[#text("29")]#text("(c)), any smooth solution ")#mi("{u: [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d}")#text(" to the initial value problem ")#link(<tao-6f035df254ed46ba11c5>)[#text("(33)")]#text(" with ")#mi("{u(0)=u_0}")#text(" obeys the Duhamel formula ")#metadata(none) <tao-54330ff21681f8a60f67>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#mitex("u(t) = e^{\\nu t \\Delta} u_0 - \\int_0^t e^{\\nu (t-s) \\Delta} \\mathbb{P}( \\nabla \\cdot (u(s) \\otimes u(s)) )\\ ds.")]]

#text(" ")#text(" (The operator ")#mi("{e^{\\nu (t-s) \\Delta} \\mathbb{P}}")#text(" is sometimes referred to as the ")#emph[#text("Oseen operator")]#text(" in the literature.) Conversely, a smooth solution ")#mi("{u: [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d}")#text(" to ")#link(<tao-54330ff21681f8a60f67>)[#text("(34)")]#text(" will solve the initial value problem ")#link(<tao-6f035df254ed46ba11c5>)[#text("(33)")]#text(" with initial data ")#mi("{u(0)=u_0}")#text(".")

#text("To obtain existence of smooth periodic solutions (with normalised pressure) to the Navier-Stokes equations with given smooth divergence-free periodic initial data ")#mi("{u_0}")#text(", it thus suffices to find a smooth periodic solution to the integral equation ")#link(<tao-54330ff21681f8a60f67>)[#text("(34)")]#text(". We will achieve this by a two-step procedure:")

#list(
[#text("(i) (Existence at finite regularity) Construct a solution ")#mi("{u}")#text(" to ")#link(<tao-54330ff21681f8a60f67>)[#text("(34)")]#text(" in a certain function space with a finite amount of regularity (assuming that the initial data ")#mi("{u_0}")#text(" has a similarly finite amount of regularity); and then")],
[#text("(ii) (Propagation of regularity) show that if ")#mi("{u_0}")#text(" is in fact smooth, then the solution constructed in (i) is also smooth.")]
)

#text("The reason for this two step procedure is that one wishes to solve ")#link(<tao-54330ff21681f8a60f67>)[#text("(34)")]#text(" using iteration-type methods (which for instance power the contraction mapping theorem that was used to prove the Picard existence theorem); however the function space ")#mi("{C^\\infty([0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}")#text(" that one ultimately wishes the solution to lie in is not well adapted for such iteration (for instance, it is not a Banach space, instead being merely a ")#link("https://en.wikipedia.org/wiki/Fr%C3%A9chet_space")[#text("Fréchet space")]#text("). Instead, we iterate in an auxiliary lower regularity space first, and then “bootstrap” the lower regularity to the desired higher regularity. Observe that the same situation occured with the Picard existence theorem, where one performed the iteration in the low regularity space ")#mi("{C([0,T] \\rightarrow \\overline{B(0,2R)})}")#text(", even though ultimately one desired the solution to be continuously differentiable or even smooth.")

#text("Of course, to run this procedure, one actually has to write down an explicit function space in which one will perform the iteration argument. Selection of this space is actually a non-trivial matter and often requires a substantial amount of trial and error, as well as experience with similar iteration arguments for other PDE. Often one is guided by the function space theory for the linearised counterpart of the PDE, which in this case is the heat equation ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(23)")]#text(". As such, the following definition can be at least partially motivated by the energy estimates in Exercise ")#link(<tao-15f5bbc66cfcfdfb89ba>)[#text("29")]#text("(d).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 32 (Mild solution)")]#text(" Let ")#mi("{s \\geq 0}")#text(", ")#mi("{T>0}")#text(", and let ")#mi("{u_0 \\in H^{s}({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0}")#text(" be divergence-free, where ")#mi("{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0}")#text(" denotes the subspace of ")#mi("{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}")#text(" consisting of mean zero functions. An ")#emph[#mi("{H^s}")#text("-mild solution")]#text(" (or ")#emph[#text("Fujita-Kato mild solution")]#text(" to the Navier-Stokes equations with initial data ")#mi("{u_0}")#text(" is a function ")#mi("{u: [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d}")#text(" in the function space")

#align(center)[#tao-fit-display[#mitex("u \\in C^0_t H^s_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0")]]

#align(center)[#tao-fit-display[#mitex("\\cap L^2_t H^{s+1}_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0")]]

#text("that obeys the integral equation ")#link(<tao-54330ff21681f8a60f67>)[#text("(34)")]#text(" (in the sense of distributions) for all ")#mi("{t \\in [0,T]}")#text(". We say that ")#mi("{u}")#text(" is a mild solution on ")#mi("{[0,T_*)}")#text(" if it is a mild solution on ")#mi("{[0,T]}")#text(" for every ")#mi("{0 < T < T_*}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 33")]#text(" The definition of a mild solution could be extended to those choices of initial data ")#mi("{u_0}")#text(" that are not divergence-free, but then this solution concept no longer has any direct connection with the Navier-Stokes equations, so we will not consider such “solutions” here. Similarly, one could also consider mild solutions without the mean zero hypothesis, but the function space estimates are slightly less favourable in this setting and so we shall restrict attention to mean zero solutions only.")
]

#text("Note that the regularity on ")#mi("{u}")#text(" places ")#mi("{u \\otimes u}")#text(" in ")#mi("{L^\\infty_t L^1_x}")#text(" (with plenty of room to spare), which is more than enough regularity to make sense of the right-hand side of ")#link(<tao-54330ff21681f8a60f67>)[#text("(34)")]#text(" in a (spacetime) distributional sense at least. One can also define mild solutions for other function spaces than the one provided here, but we focus on this notion for now, which was introduced in the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=166499")[#text("work of Fujita and Kato")]#text(". We record a simple compatibility property of mild solutions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34 (Splitting)")]#text(" ")#metadata(none) <tao-c93e32efffa296f956f2>#text(" Let ")#mi("{s \\geq 0}")#text(", ")#mi("{T>0}")#text(", let ")#mi("{u_0 \\in H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0}")#text(" be divergence-free, and let")

#align(center)[#tao-fit-display[#mitex("u \\in C^0_t H^s_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0")]]

#align(center)[#tao-fit-display[#mitex("\\cap L^2_t H^{s+1}_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0.")]]

#text("Let ")#mi("{0 < \\tau < T}")#text(". Show that the following are equivalent:")

#list(
[#text("(i) ")#mi("{u: [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d}")#text(" is an ")#mi("{H^s}")#text(" mild solution to the Navier-Stokes equations on ")#mi("{[0,T]}")#text(" with initial data ")#mi("{u_0}")#text(".")],
[#text("(ii) ")#mi("{u: [0,\\tau] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d}")#text(" is an ")#mi("{H^s}")#text(" mild solution to the Navier-Stokes equations on ")#mi("{[0,\\tau]}")#text(" with initial data ")#mi("{u_0}")#text(", and the translated function ")#mi("{u_\\tau: [0,T-\\tau] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d}")#text(" defined by ")#mi("{u_\\tau(t,x) := u(t+\\tau,x)}")#text(" is an ")#mi("{H^s}")#text(" mild solution to the Navier-Stokes equations with initial condition ")#mi("{u(\\tau)}")#text(".")]
)
]

#text("To use this notion of a mild solution, we will need the following harmonic analysis estimate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 35 (Product estimate)")]#text(" ")#metadata(none) <tao-aa77e694ded50339aeb8>#text(" Let ")#mi("{s \\geq 0}")#text(", and let ")#mi("{u,v \\in H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}) \\cap L^\\infty({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}")#text(". Then one has ")#mi("{uv \\in H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}")#text(", with the estimate")

#tao-aligned(keep: true)[


#tao-math("\\left\\| uv \\right\\|_{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}  & \\lesssim_{d,s} \\left\\| u \\right\\|_{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})} \\left\\| v \\right\\|_{L^\\infty({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}", block: true)



#tao-math(" & + \\left\\| u \\right\\|_{L^\\infty({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})} \\left\\| v \\right\\|_{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}.", block: true)
]
]

#text("When ")#mi("{s=0}")#text(" this claim follows immediately from Hölder’s inequality. For ")#mi("{s=1}")#text(" the claim is similarly immediate from the Leibniz rule ")#mi("{\\nabla(uv) = (\\nabla u) v + u (\\nabla v)}")#text(" and the triangle and Hölder inequalities (noting that ")#tao-math("{\\left\\| u \\right\\|_{H^1({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}}", block: false)#text(" is comparable to ")#tao-math("{\\left\\| u \\right\\|_{L^2({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})} + \\left\\| \\nabla u \\right\\|_{L^2({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}}", block: false)#text(". For more general ")#mi("{s}")#text(" the claim is not quite so immediate (for instance, when ")#mi("{s=2}")#text(" one runs into difficulties controlling the intermediate term ")#mi("{2 (\\nabla u) \\otimes (\\nabla v)}")#text(" arising in the Leibniz expansion of ")#mi("{\\nabla^2(uv)}")#text("). Nevertheless the bound is still true. However, to prove it we will need to introduce a tool from harmonic analysis, namely Littlewood-Paley theory, and we defer the proof to the appendix.")

#text("We also need a simple case of Sobolev embedding:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36 (Sobolev embedding)")]#text(" ")#metadata(none) <tao-454bedc703c397ac8232>

#list(
[#text("(a) If ")#mi("{s > \\frac{d}{2}}")#text(", show that for any ")#mi("{u \\in H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}")#text(", one has ")#mi("{u \\in L^\\infty({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u \\right\\|_{L^\\infty({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})} \\lesssim_{d,s} \\left\\| u \\right\\|_{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}.", block: true)]]],
[#text("(b) Show that the inequality fails at ")#mi("{s = \\frac{d}{2}}")#text(".")],
[#text("(c) Establish the same statements with ")#mi("{{\\bf R}^d/{\\bf Z}^d}")#text(" replaced by ")#mi("{{\\bf R}^d}")#text(" throughout.")]
)
]

#text("In particular, combining this exercise with Proposition ")#link(<tao-aa77e694ded50339aeb8>)[#text("35")]#text(" we see that for ")#mi("{s > \\frac{d}{2}}")#text(", ")#mi("{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}")#text(" is a Banach algebra: ")#metadata(none) <tao-ec752d1d10b6d764a0e3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#tao-math("\\left\\| uv \\right\\|_{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})} \\lesssim_{d,s} \\left\\| u \\right\\|_{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})} \\left\\| v \\right\\|_{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}.", block: true)]]



#text("Now we can construct mild solutions at high regularities ")#mi("{s > \\frac{d}{2}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 37 (Local well-posedness of mild solutions at high regularity)")]#text(" ")#metadata(none) <tao-c09e73104942e5734ccc>#text(" Let ")#mi("{s > \\frac{d}{2}}")#text(", and let ")#mi("{u_0 \\in H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0}")#text(" be divergence-free. Then there exists a time")

#align(center)[#tao-fit-display[#tao-math("T \\gg_{d,s} \\frac{\\nu}{\\left\\|u_0\\right\\|_{H^s_x({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}^2},", block: true)]]

#text("and an ")#mi("{H^s}")#text(" mild solution ")#mi("{u: [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d}")#text(" to ")#link(<tao-54330ff21681f8a60f67>)[#text("(34)")]#text(". Furthermore, this mild solution is unique.")
]

#text("The hypothesis ")#mi("{s > \\frac{d}{2}}")#text(" is not optimal; we return to this point later in these notes.")

#emph[#text("Proof:")]#text(" We begin with existence. We can write ")#link(<tao-54330ff21681f8a60f67>)[#text("(34)")]#text(" in the fixed point form")

#align(center)[#tao-fit-display[#mitex("u = \\Phi(u)")]]

#text("where")

#metadata(none) <tao-5781aec985d7f8fb3f90>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#mitex("\\Phi(u)(t) := e^{\\nu t \\Delta} u_0 - \\int_0^t e^{\\nu (t-s) \\Delta} \\mathbb{P}( \\nabla \\cdot (u(s) \\otimes u(s)) )\\ ds.")]]

#text("We remark that this expression automatically has mean zero since ")#mi("{u_0}")#text(" has mean zero. Let ")#mi("{X_T}")#text(" denote the function space")

#align(center)[#tao-fit-display[#mitex("X_T := C^0_t H^s_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0 \\cap L^2_t H^{s+1}_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0")]]

#text("with norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|u\\right\\|_{X_T} := \\left\\| u \\right\\|_{C^0_t H^s_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)} + \\nu^{1/2} \\left\\| u \\right\\|_{L^2_t H^{s+1}_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}.", block: true)]]

#text("This is a Banach space. Because of the mean zero restriction on ")#mi("{X}")#text(", we may estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\|u\\right\\|_{X_T} \\lesssim_{s,d} \\left\\| u \\right\\|_{C^0_t H^s_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)} + \\nu^{1/2} \\left\\| \\nabla u \\right\\|_{L^2_t H^{s}_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^{d^2})}.", block: true)]]

#text("Note that if ")#mi("{u \\in X_T}")#text(", then ")#mi("{u \\otimes u \\in C^t H^s_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^{d^2})}")#text(" by ")#link(<tao-ec752d1d10b6d764a0e3>)[#text("(35)")]#text(", which by Exercise ")#link(<tao-15f5bbc66cfcfdfb89ba>)[#text("29")]#text("(d) (and the fact that ")#mi("{\\mathbb{P}}")#text(" commutes with ")#mi("{\\nabla}")#text(" and is a non-expansive map on ")#mi("{H^s}")#text(") implies that ")#mi("{\\Phi(u) \\in X_T}")#text(". Thus ")#mi("{\\Phi}")#text(" is a map from ")#mi("{X_T}")#text(" to ")#mi("{X_T}")#text(". In fact we can obtain more quantitative control on this map. By using Exercise ")#link(<tao-15f5bbc66cfcfdfb89ba>)[#text("29")]#text("(d), ")#link(<tao-ec752d1d10b6d764a0e3>)[#text("(35)")]#text(", and the Hölder bound ")#metadata(none) <tao-de152fc3bc10a8878677>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#tao-math("\\left\\| F \\right\\|_{L^2_t H^s_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})} \\leq T^{1/2} \\left\\| F \\right\\|_{C^0_t H^s_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}", block: true)]]

#text(" ")#text(" we have")

#tao-aligned(keep: true)[


#tao-math("\\left\\| \\Phi(u) \\right\\|_{X_T}  & \\lesssim \t\\left\\|u_0\\right\\|_{H^s_x({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)} + \\nu^{-1/2} \\left\\| \\mathbb{P} (u \\otimes u) \\right\\|_{L^2_t H^s_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d\\rightarrow {\\bf R}^{d^2})}", block: true)



#tao-math(" & \\lesssim \t\\left\\|u_0\\right\\|_{H^s_x({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)} + \\nu^{-1/2} T^{1/2} \\left\\| u \\otimes u \\right\\|_{C^0_t H^s_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d\\rightarrow {\\bf R}^{d^2})}", block: true)



#tao-math(" & \\lesssim_{d,s} \t\\left\\|u_0\\right\\|_{H^s_x({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)} + \\nu^{-1/2} T^{1/2} \\left\\| u \\right\\|_{C^0_t H^s_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d\\rightarrow {\\bf R}^d)}^2", block: true)



#tao-math(" & \\lesssim \t\\left\\|u_0\\right\\|_{H^s_x({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)} + \\nu^{-1/2} T^{1/2} \\left\\| u \\right\\|_{X_T}^2.", block: true)
]

#text("Thus, if we set ")#tao-math("{R := C_{d,s} \\left\\|u_0\\right\\|_{H^s_x({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}}", block: false)#text(" for a suitably large constant ")#mi("{C_{d,s} > 0}")#text(", and set ")#tao-math("{T := c_{d,s} \\frac{\\nu}{\\left\\|u_0\\right\\|_{H^s_x({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}^2}}", block: false)#text(" for a sufficienly small constant ")#mi("{c_{d,s} > 0}")#text(", then ")#mi("{\\Phi}")#text(" maps the closed ball ")#mi("{\\overline{B_{X_T}(0,R)}}")#text(" in ")#mi("{X_T}")#text(" to itself. Furthermore, for ")#mi("{u,v \\in X_T}")#text(", we have by similar arguments to above")

#tao-aligned(keep: true)[


#tao-math("\\left\\| \\Phi(u) - \\Phi(v) \\right\\|_{X_T}  & \\lesssim \\nu^{-1/2} \\left\\| \\mathbb{P} (u \\otimes u - v \\otimes v) \\right\\|_{L^2_t H^s_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d\\rightarrow {\\bf R}^d)}", block: true)



#tao-math(" & \\lesssim \\nu^{-1/2} T^{1/2} \\left\\| u \\otimes u - v \\otimes v\\right\\|_{C^0_t H^s_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d\\rightarrow {\\bf R}^d)}", block: true)



#tao-math(" & \\lesssim_{d,s} \\nu^{-1/2} T^{1/2} \\left\\| u - v\\right\\|_{C^0_t H^s_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d\\rightarrow {\\bf R}^d)}", block: true)
]

#align(center)[#tao-fit-display[#tao-math("(\\left\\| u \\right\\|_{C^0_t H^s_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d\\rightarrow {\\bf R}^d)} + \\left\\| v\\right\\|_{C^0_t H^s_x([0,T] \\times {\\bf R}^d/{\\bf Z}^d\\rightarrow {\\bf R}^d)})", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\lesssim_{d,s} \\nu^{-1/2} T^{1/2} \\left\\| u - v\\right\\|_{X_T} (\\left\\|u\\right\\|_{X_T} + \\left\\|v\\right\\|_{X_T})", block: true)]]

#text("and hence if the constant ")#mi("{c_{d,s}}")#text(" is chosen small enough, ")#mi("{\\Phi}")#text(" is also a contraction (with constant, say, ")#mi("{\\frac{1}{2}}")#text(") on ")#mi("{\\overline{B(0,R)}}")#text(". Thus there exists ")#mi("{u \\in \\overline{B(0,R)}}")#text(" such that ")#mi("{u=\\Phi(u)}")#text(", thus ")#mi("{u}")#text(" is an ")#mi("{H^s}")#text(" mild solution.")

#text("Now we show that it is the only mild solution. Suppose for contradiction that there is another ")#mi("{H^s}")#text(" mild solution ")#mi("{v}")#text(" with the same initial data ")#mi("{u_0}")#text(". This solution ")#mi("{v}")#text(" might not lie in ")#mi("{\\overline{B_{X_T}(0,R)}}")#text(", but it will lie in ")#mi("{\\overline{B_{X_{T}}(0,R^{\\prime})}}")#text(" for some ")#mi("{R^{\\prime}>R}")#text(". By the same arguments as above, if ")#mi("{0 < T^{\\prime} < T}")#text(" is sufficiently small depending on ")#mi("{d,s,R^{\\prime}}")#text(" then ")#mi("{\\Phi}")#text(" will be a contraction on ")#mi("{\\overline{B_{X_{T^{\\prime}}}(0,R^{\\prime})}}")#text(", which implies that ")#mi("{u}")#text(" and ")#mi("{v}")#text(" agree on ")#mi("{[0,T^{\\prime}]}")#text(". Now we apply Exercise ")#link(<tao-c93e32efffa296f956f2>)[#text("34")]#text(" to advance in time by ")#mi("{T^{\\prime}}")#text(" and iterate this process (noting that ")#mi("{T^{\\prime}}")#text(" depends on ")#mi("{d,s,R^{\\prime}}")#text(" but does not otherwise depend on ")#mi("{u}")#text(" or ")#mi("{v}")#text(") until one concludes that ")#mi("{u=v}")#text(" on all of ")#mi("{[0,T]}")#text(". ")#mi("\\Box")

#text("Iterating this as in the proof of Theorem ")#link(<tao-c1f5def06c9c8066f238>)[#text("8")]#text(", we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 38 (Maximal Cauchy development)")]#text(" ")#metadata(none) <tao-8c2d2b507c5488d60854>#text(" Let ")#mi("{s > \\frac{d}{2}}")#text(", and let ")#mi("{u_0 \\in H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0}")#text(" be divergence-free. Then there exists a time ")#mi("{0 < T_* \\leq \\infty}")#text(" and an ")#mi("{H^s}")#text(" mild solution ")#mi("{u: [0,T_*) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d}")#text(" to ")#link(<tao-54330ff21681f8a60f67>)[#text("(34)")]#text(", such that if ")#mi("{T_* < \\infty}")#text(" then ")#tao-math("{\\left\\|u(t)\\right\\|_{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)} \\rightarrow \\infty}", block: false)#text(" as ")#mi("{t \\rightarrow T_*^-}")#text(". Furthermore, ")#mi("{T_*}")#text(" and ")#mi("{u}")#text(" are unique.")
]

#text("In principle, if the initial data ")#mi("{u_0}")#text(" belongs to multiple Sobolev spaces ")#mi("{u_0 \\in H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0}")#text(" the maximal time of existence ")#mi("{T_*}")#text(" could depend on ")#mi("{s}")#text(" (so that the solution exits different regularity classes ")#mi("{H^s}")#text(" at different times). However, this is not the case, because there is an ")#mi("{s}")#text("-independent blowup criterion:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 39 (Blowup criterion)")]#text(" ")#metadata(none) <tao-7cf6b0597fe4e3cb3559>#text(" Let ")#mi("{s, u_0, T_*, u}")#text(" be as in Theorem ")#link(<tao-8c2d2b507c5488d60854>)[#text("38")]#text(". If ")#mi("{T_* < \\infty}")#text(", then ")#tao-math("{\\left\\| u \\right\\|_{L^\\infty_t L^\\infty_x([0,T_*))} = \\infty}", block: false)#text(".")
]

#text("Note from Exercise ")#link(<tao-454bedc703c397ac8232>)[#text("36")]#text(" that ")#tao-math("{\\left\\| u \\right\\|_{L^\\infty_t L^\\infty_x([0,T])}}", block: false)#text(" is finite for any ")#mi("{0 \\leq T < T_*}")#text(". This shows that ")#mi("{T_*}")#text(" is the unique time at which the ")#mi("{L^\\infty_t L^\\infty_x}")#text(" norm “blows up” (becomes infinite) and thus ")#mi("{T_*}")#text(" is independent of ")#mi("{s}")#text(".")

#emph[#text("Proof:")]#text(" Suppose for contradiction that ")#mi("{T_* < \\infty}")#text(" but that the quantity ")#tao-math("{A := \\left\\| u \\right\\|_{L^\\infty_t L^\\infty_x([0,T_*))}}", block: false)#text(" was finite. Let ")#mi("{0 < \\tau_1 < \\tau_2 < T_*}")#text(" be parameters to be optimised in later. We define the norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|u\\right\\|_{X_{[\\tau_1,\\tau_2]}} := \\left\\| u \\right\\|_{C^0_t H^s_x([\\tau_1,\\tau_2] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)} + \\nu^{1/2} \\left\\| u \\right\\|_{L^2_t H^{s+1}_x([\\tau_1,\\tau_2] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}.", block: true)]]

#text("As ")#mi("{u}")#text(" is a mild solution, this expression is finite.")

#text("We adapt the proof of Theorem ")#link(<tao-c09e73104942e5734ccc>)[#text("37")]#text(". Using Exercise ")#link(<tao-15f5bbc66cfcfdfb89ba>)[#text("29")]#text("(d) (and Exercise ")#link(<tao-c93e32efffa296f956f2>)[#text("34")]#text(") we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|u\\right\\|_{X_{[\\tau_1,\\tau_2]}} \\lesssim_{s,d} \\left\\| u(\\tau_1) \\right\\|_{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)} + \\nu^{-1/2} \\left\\| \\mathbb{P}(u \\otimes u) \\right\\|_{L^2_t H^s_x([\\tau_1,\\tau_2] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}.", block: true)]]

#text("Again we discard ")#mi("{\\mathbb{P}}")#text(" and use (a variant of) ")#link(<tao-de152fc3bc10a8878677>)[#text("(37)")]#text(" to conclude")

#align(center)[#tao-fit-display[#tao-math("\\left\\|u\\right\\|_{X_{[\\tau_1,\\tau_2]}} \\lesssim_{s,d} \\left\\| u(\\tau_1) \\right\\|_{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)} + \\nu^{-1/2} (\\tau_2-\\tau_1)^{1/2} \\left\\| u \\otimes u \\right\\|_{L^\\infty_t H^s_x([\\tau_1,\\tau_2] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}.", block: true)]]

#text("If we now use Proposition ")#link(<tao-aa77e694ded50339aeb8>)[#text("35")]#text(" in place of ")#link(<tao-ec752d1d10b6d764a0e3>)[#text("(35)")]#text(", we conclude that")

#tao-aligned(keep: true)[


#tao-math("\\left\\|u\\right\\|_{X_{[\\tau_1,\\tau_2]}}  & \\lesssim_{s,d} \\left\\| u(\\tau_1) \\right\\|_{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)} + \\nu^{-1/2} (\\tau_2-\\tau_1)^{1/2} A \\left\\| u \\right\\|_{L^\\infty_t H^s_x([\\tau_1,\\tau_2] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}", block: true)



#tao-math(" & \\lesssim_{s,d} \\left\\| u(\\tau_1) \\right\\|_{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)} + \\nu^{-1/2} (T_*-\\tau_1)^{1/2} A \\left\\|u\\right\\|_{X_{[\\tau_1,\\tau_2]}}.", block: true)
]

#text("If we choose ")#mi("{\\tau_1}")#text(" to be sufficiently close to ")#mi("{T_*}")#text(" (depending on ")#mi("{A}")#text(" and ")#mi("{\\nu}")#text("), we can absorb the second term on the RHS into the LHS and conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|u\\right\\|_{X_{[\\tau_1,\\tau_2]}} \\lesssim_{s,d} \\left\\| u(\\tau_1) \\right\\|_{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}.", block: true)]]

#text("In particular, ")#tao-math("{\\left\\|u(\\tau_2)\\right\\|_{H^s_x({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}}", block: false)#text(" stays bounded as ")#mi("{\\tau_2 \\rightarrow T_*}")#text(", contradicting Theorem ")#link(<tao-8c2d2b507c5488d60854>)[#text("38")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 40 (Existence of smooth solutions)")]#text(" ")#metadata(none) <tao-c0a72299f59efbe03558>#text(" If ")#mi("{u_0: {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d}")#text(" is smooth and divergence free then there is a ")#mi("{0 < T_* \\leq \\infty}")#text(" and a smooth periodic solution ")#mi("{(u,p)}")#text(" to the Navier-Stokes equations on ")#mi("{[0,T_*) \\times {\\bf R}^d/{\\bf Z}^d}")#text(" with normalised pressure such that if ")#mi("{T_*<\\infty}")#text(", then ")#tao-math("{\\left\\| u \\right\\|_{L^\\infty_t L^\\infty_x([0,T_*))} = \\infty}", block: false)#text(". Furthermore, ")#mi("{T_*}")#text(" and ")#mi("{(u,p)}")#text(" are unique.")
]

#emph[#text("Proof:")]#text(" As discussed previously, we may assume without loss of generality that ")#mi("{u_0}")#text(" has mean zero. As ")#mi("{u_0}")#text(" is periodic and smooth, it lies in ")#mi("{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0}")#text(" for every ")#mi("{s}")#text(". From the preceding discussion we already have ")#mi("{0 < T_* \\leq \\infty}")#text(" and a function ")#mi("{u: [0,T_*) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d}")#text(" that is an ")#mi("{H^s}")#text(" mild solution for every ")#mi("{s > \\frac{d}{2}}")#text(", and with ")#tao-math("{\\left\\|u\\right\\|_{L^\\infty_t L^\\infty_x([0,T_*))} = \\infty}", block: false)#text(" if ")#mi("{T_*}")#text(" is finite. It will suffice to show that ")#mi("{u}")#text(" is smooth, since we know from preceding discussion that a smooth solution to ")#link(<tao-6f035df254ed46ba11c5>)[#text("(33)")]#text(" can be converted to a smooth solution to ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(".")

#text("By Exercise ")#link(<tao-15f5bbc66cfcfdfb89ba>)[#text("29")]#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\partial_t u = \\nu \\Delta u + \\nabla \\cdot \\mathbb{P} (u \\otimes u)")]]

#text("in the sense of spacetime distributions. The right-hand side lies in ")#mi("{C^0_t H^s_x}")#text(" for every ")#mi("{s}")#text(", hence the left-hand side does also; this makes ")#mi("{u}")#text(" lie in ")#mi("{C^1_t H^s_x}")#text(". It is then easy to see that this implies that the right-hand side of the above equation lies in ")#mi("{C^1_t H^s_x}")#text(" for every ")#mi("{s}")#text(", and so ")#mi("{u}")#text(" now lies in ")#mi("{C^2_t H^s_x}")#text(" for every ")#mi("{s}")#text(". Iterating this (and using Sobolev embedding) we conclude that ")#mi("{u}")#text(" is smooth in space and time, giving the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 41")]#text(" When ")#mi("{d=3}")#text(", it is a ")#link("https://en.wikipedia.org/wiki/Navier%E2%80%93Stokes_existence_and_smoothness")[#text("notorious open problem")]#text(" whether the maximal lifespan ")#mi("{T_*}")#text(" given by the above corollary is always infinite.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42 (Instantaneous smoothing)")]#text(" Let ")#mi("{s > \\frac{d}{2}}")#text(", let ")#mi("{u_0 \\in H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0}")#text(" be divergence-free, and let ")#mi("{u: [0,T_*) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d}")#text(" be the maximal Cauchy development provided by Theorem ")#link(<tao-8c2d2b507c5488d60854>)[#text("38")]#text(". Show that ")#mi("{u}")#text(" is smooth on ")#mi("{(0,T_*) \\times {\\bf R}^d/{\\bf Z}^d}")#text(" (note the omission of the initial time ")#mi("{t=0}")#text("). (")#emph[#text("Hint:")]#text(" first show that ")#mi("{t \\mapsto u(t+\\varepsilon)}")#text(" is a ")#mi("{H^{s+1}}")#text(" mild solution for arbitrarily small ")#mi("{0 < \\varepsilon < T_*}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 43 (Lipschitz continuous dependence on initial data)")]#text(" Let ")#mi("{s > \\frac{d}{2}}")#text(", let ")#mi("{T>0}")#text(", and let ")#mi("{u_0 \\in H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0}")#text(" be divergence-free. Suppose one has an ")#mi("{H^s}")#text(" mild solution ")#mi("{u: [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d}")#text(" to the Navier-Stokes equations with initial data ")#mi("{u_0}")#text(". Show that there in a neighbourhood ")#mi("{U}")#text(" of ")#mi("{u_0}")#text(" in (the divergence-free elements of) in ")#mi("{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0}")#text(", such that for every ")#mi("{v_0 \\in U}")#text(", there exists an ")#mi("{H^s}")#text(" mild solution ")#mi("{v: [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d}")#text(" to the Navier-Stokes equations with initial data ")#mi("{v_0}")#text(" with the map from ")#mi("{v_0}")#text(" to ")#mi("{v}")#text(" Lipschitz continuous (using the ")#mi("{H^s}")#text(" metric for the initial data ")#mi("{v_0}")#text(" and the ")#mi("{C^0_t H^s}")#text(" metric for the solution ")#mi("{v}")#text(").")
]

#text("Now we discuss the issue of relaxing the regularity condition ")#mi("{s > \\frac{d}{2}}")#text(" in the above theory. The main inefficiency in the above arguments is the use of the crude estimate ")#link(<tao-de152fc3bc10a8878677>)[#text("(37)")]#text(", which sacrifices some of the ")#mi("{L^p}")#text(" exponent in time in exchange for extracting a positive power of the lifespan ")#mi("{T}")#text(" that can be used to create a contraction mapping, as long as ")#mi("{T}")#text(" is small enough. It turns out that by using a different energy estimate than Exercise ")#link(<tao-15f5bbc66cfcfdfb89ba>)[#text("29")]#text("(d), one can avoid such an exchange, allowing one to construct solutions at lower regularity, and in particular at the “critical” regularity of ")#mi("{H^{\\frac{d}{2}-1}}")#text(". Furthermore, in the category of smooth solutions, one can even achieve the desirable goal of ensuring that the time of existence ")#mi("{T}")#text(" is infinite – but only provided that the initial data is small. More precisely,")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 44")]#text(" ")#metadata(none) <tao-136c0df4f4faf78145be>#text(" Let ")#mi("{u_0 \\in H^{\\frac{d}{2}-1}({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})^0}")#text(" and let ")#mi("{F \\in L^1_t H^{\\frac{d}{2}-1}_x([0,\\infty) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})^0}")#text(". Then the function ")#mi("{u: [0,+\\infty) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}}")#text(" defined by the Duhamel formula")

#align(center)[#tao-fit-display[#mitex("u(t) = e^{\\nu t\\Delta} u_0 + \\int_0^t e^{\\nu(t-s)\\Delta} F(s)\\ ds")]]

#text("also has mean zero for all ")#mi("{t}")#text(", and obeys the estimates")

#tao-aligned(keep: true)[


#tao-math("\\left\\| u \\right\\|_{C^0_t H^{\\frac{d}{2}-1}([0,+\\infty) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}  & + \t\\nu^{1/2} \\left\\| u \\right\\|_{L^2_t H^{\\frac{d}{2}}_x([0,+\\infty) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}", block: true)



#tao-math(" & + \t\\nu^{1/2} \\left\\| u \\right\\|_{L^2_t L^\\infty_x([0,+\\infty) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}", block: true)
]

#align(center)[#tao-fit-display[#tao-math("\\lesssim_d \\left\\| u_0 \\right\\|_{H^{\\frac{d}{2}-1}({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})} + \\left\\|F \\right\\|_{L^1_t H^{\\frac{d}{2}-1}_x([0,+\\infty) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}.", block: true)]]
]

#emph[#text("Proof:")]#text(" By Minkowski’s integral inequality, it will suffice to establish the bounds in the case ")#mi("{F=0}")#text(". The first two norms of the left-hand side are already established by Exercise ")#link(<tao-15f5bbc66cfcfdfb89ba>)[#text("29")]#text("(d), so it remains to establish the estimate")

#align(center)[#tao-fit-display[#tao-math("\\nu^{1/2} \\left\\| u \\right\\|_{L^2_t L^\\infty_x([0,+\\infty) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})} \t\\lesssim_d \\left\\| u_0 \\right\\|_{H^{\\frac{d}{2}-1}({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}.", block: true)]]

#text("By working with the rescaled function ")#mi("{\\tilde u(t,x) := u(\\nu^{-1} t, x)}")#text(" (and also rescaling ")#mi("{\\tilde F(t,x) = \\nu^{-1} F(\\nu^{-1} t, x)}")#text("), we may normalise ")#mi("{\\nu=1}")#text(". By a limiting argument we may assume without loss of generality that ")#mi("{u_0}")#text(" is Schwarz. We cannot directly apply Exercise ")#link(<tao-454bedc703c397ac8232>)[#text("36")]#text(" here due to the failure of endpoint Sobolev embedding; nevertheless we may argue as follows. For any ")#mi("{t>0}")#text(", we see from ")#link(<tao-1b82757a9d6f5159dae2>)[#text("(31)")]#text(", the mean zero hypothesis, and the triangle inequality that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u(t) \\right\\|_{L^\\infty({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})} \\leq \\sum_{k \\in {\\bf Z}^d \\backslash \\{0\\}} e^{- 4\\pi^2 \\left|k\\right|^2 t} |\\hat u_0(k)|.", block: true)]]

#text("To proceed further, we choose an exponent ")#mi("{\\alpha}")#text(" such that")

#metadata(none) <tao-4805e2f0fa20f3b90b59>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#mitex("d-2 < \\alpha < d")]]

#text("(for instance one can take ")#mi("{\\alpha=d-1}")#text("), and use Cauchy-Schwarz to bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u(t) \\right\\|_{L^\\infty({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})} \\leq (\\sum_{k \\in {\\bf Z}^d \\backslash \\{0\\}} e^{- 4\\pi^2 \\left|k\\right|^2 t} \\left|k\\right|^\\alpha \\left|\\hat u_0(k)\\right|^2)^{1/2}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\times (\\sum_{k \\in {\\bf Z}^d \\backslash \\{0\\}} e^{- 4\\pi^2 \\left|k\\right|^2 t} \\left|k\\right|^{-\\alpha})^{1/2}.", block: true)]]

#text("As ")#mi("{\\alpha < d}")#text(", one has the bound")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k \\in {\\bf Z}^d \\backslash \\{0\\}} e^{- 4\\pi^2 \\left|k\\right|^2 t}\\left|k\\right|^{-\\alpha} \\lesssim_{d,\\alpha} \\left|t\\right|^{-\\frac{d}{2} + \\frac{\\alpha}{2}}", block: true)]]

#text("(which can be verified using the integral test for ")#mi("{t \\geq 1}")#text(", while for ")#mi("{t < 1}")#text(" it is easy to bound the LHS by ")#mi("{O(1)}")#text(") and hence")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u(t) \\right\\|_{L^\\infty({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})} \\lesssim_{d,\\alpha} \\left|t\\right|^{-\\frac{d}{4} + \\frac{\\alpha}{4}} (\\sum_{k \\in {\\bf Z}^d \\backslash \\{0\\}} e^{- 4\\pi^2 \\left|k\\right|^2 t} \\left|k\\right|^\\alpha \\left|\\hat u_0(k)\\right|^2)^{1/2}.", block: true)]]

#text("Taking ")#mi("{L^2_t}")#text(" norms and using Fubini’s theorem, we conclude")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u \\right\\|_{L^2_t L^\\infty_x([0,+\\infty) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}^2", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\lesssim_{d,\\alpha} \\sum_{k \\in {\\bf Z}^d \\backslash \\{0\\}} \\left|k\\right|^\\alpha (\\int_0^\\infty \\left|t\\right|^{-\\frac{d}{2} + \\frac{\\alpha}{2}} e^{-4\\pi^2 \\left|k\\right|^2 t}\\ dt) \\left|\\hat u_0(k)\\right|^2.", block: true)]]

#text("As ")#mi("{\\alpha > d-2}")#text(", the inner integral can be estimated as")

#align(center)[#tao-fit-display[#tao-math("\\int_0^\\infty \\left|t\\right|^{-\\frac{d}{2}+\\frac{\\alpha}{2}} e^{-4\\pi^2 \\left|k\\right|^2 t}\\ dt \\lesssim_{d,\\alpha} \\left|k\\right|^{d - 2 - \\alpha}", block: true)]]

#text("and the claim follows. ")#mi("\\Box")

#text("This gives the following small data global existence result, also due to Fujita and Kato:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 45 (Small data global existence)")]#text(" ")#metadata(none) <tao-50fb28b23c1e32dd0bd4>#text(" Suppose that ")#mi("{u_0 \\in H^{\\frac{d}{2}-1}({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0}")#text(" is divergence-free with norm at most ")#mi("{\\varepsilon_d \\nu}")#text(", where ")#mi("{\\varepsilon_d>0}")#text(" is a sufficiently small constant depending only on ")#mi("{d}")#text(". Then there exists a ")#mi("{H^{\\frac{d}{2}-1}}")#text(" mild solution to the Navier-Stokes equations on ")#mi("{[0,+\\infty)}")#text(". Furthermore, if ")#mi("{u_0}")#text(" is smooth, then this mild solution is also smooth.")
]

#emph[#text("Proof:")]#text(" By working with the rescaled function ")#mi("{\\tilde u(t,x) := \\nu^{-1} u(\\nu^{-1} t, x)}")#text(", we may normalise ")#mi("{\\nu=1}")#text(". Let ")#mi("{X}")#text(" denote the Banach space of functions")

#align(center)[#tao-fit-display[#mitex("X = C^0_t H^{d/2-1}_x( [0,+\\infty) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0")]]

#align(center)[#tao-fit-display[#mitex("\\cap \tL^2_t H^{d/2}_x( [0,+\\infty) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0 \\cap \tL^2_t L^\\infty_x( [0,+\\infty) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0")]]

#text("with the obvious norm")

#tao-aligned(keep: true)[


#tao-math("\\left\\|u\\right\\|_X  & = \\left\\|u\\right\\|_{C^0_t H^{d/2-1}_x( [0,+\\infty) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)} + \\left\\|u\\right\\|_{L^2_t H^{d/2}_x( [0,+\\infty) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}", block: true)



#tao-math(" & + \\left\\|u\\right\\|_{L^2_t L^\\infty_x( [0,+\\infty) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}.", block: true)
]

#text("Let ")#mi("{\\Phi}")#text(" be the Duhamel operator ")#link(<tao-5781aec985d7f8fb3f90>)[#text("(36)")]#text(". If ")#mi("{u \\in X}")#text(", then by Proposition ")#link(<tao-136c0df4f4faf78145be>)[#text("44")]#text(" and Lemma ")#link(<tao-aa77e694ded50339aeb8>)[#text("35")]#text(" one has")

#tao-aligned(keep: true)[


#tao-math("\\left\\| \\Phi(u) \\right\\|_X  & \\lesssim_d \\varepsilon_d + \\left\\| \\mathbb{P}( \\nabla \\cdot (u \\otimes u) ) \\right\\|_{L^1_t H^{\\frac{d}{2}-1}( [0,+\\infty) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}", block: true)



#tao-math(" & \\lesssim_d \\varepsilon_d + \\left\\| u \\otimes u \\right\\|_{L^1_t H^{\\frac{d}{2}}( [0,+\\infty) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^{d^2})}", block: true)



#tao-math(" & \\lesssim_d \\varepsilon_d + \\left\\| u \\right\\|_{L^2_t H^{\\frac{d}{2}}_x( [0,+\\infty) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^{d})} \\left\\| u \\right\\|_{L^2_t L^\\infty_x( [0,+\\infty) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^{d})}", block: true)



#tao-math(" & \\lesssim_d \\varepsilon_d + \\left\\| u \\right\\|_X^2.", block: true)
]

#text("In particular, ")#mi("{\\Phi}")#text(" maps ")#mi("{X}")#text(" to ")#mi("{X}")#text(". A similar argument establishes the bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\Phi(u) - \\Phi(v) \\right\\|_X \\lesssim_d \\left\\| u-v\\right\\|_X ( \\left\\|u\\right\\|_X + \\left\\|v\\right\\|_X )", block: true)]]

#text("for all ")#mi("{u,v \\in X}")#text(". For ")#mi("{\\varepsilon_d}")#text(" small enough, ")#mi("{\\Phi}")#text(" will be a contraction on ")#mi("{\\overline{B(0, C_d \\varepsilon_d)}}")#text(" for some absolute constant ")#mi("{C_d}")#text(" depending only on ")#mi("{d}")#text(", and hence has a fixed point ")#mi("{u = \\Phi(u)}")#text(" which will be the desired ")#mi("{H^{\\frac{d}{2}-1}}")#text(" mild solution.")

#text("Now suppose that ")#mi("{u_0}")#text(" is smooth. Let ")#mi("{s > \\frac{d}{2}}")#text(", and let ")#mi("{u: [0,T_*) \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d}")#text(" be the maximal Cauchy development provided by Theorem ")#link(<tao-8c2d2b507c5488d60854>)[#text("38")]#text(". For any ")#mi("{0 < T < T_*}")#text(", if one defines")

#tao-aligned(keep: true)[


#tao-math("\\left\\|u\\right\\|_{X_T}  & = \\left\\|u\\right\\|_{C^0_t H^{d/2-1}_x( [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)} + \\left\\|u\\right\\|_{L^2_t H^{d/2}_x( [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}", block: true)



#tao-math(" & + \\left\\|u\\right\\|_{L^2_t L^\\infty_x( [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}", block: true)
]

#text("then the preceding arguments give")

#align(center)[#tao-fit-display[#tao-math("\\left\\|u\\right\\|_{X_T} \\lesssim_d \\varepsilon_d + \\left\\| u \\right\\|_{X_T}^2,", block: true)]]

#text("thus either ")#tao-math("{\\left\\|u\\right\\|_{X_T} \\lesssim_d \\varepsilon_d}", block: false)#text(" or ")#tao-math("{\\left\\|u\\right\\|_{X_T} \\gtrsim_d 1}", block: false)#text(". On the other hand, ")#tao-math("{\\left\\|u\\right\\|_{X_T}}", block: false)#text(" depends continuously on ")#mi("{d}")#text(" and converges to ")#tao-math("{\\left\\|u_0\\right\\|_{H^{d/2-1}({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)} \\leq \\varepsilon_d}", block: false)#text(" as ")#mi("{T \\rightarrow 0}")#text(". For ")#mi("{\\varepsilon_d}")#text(" small enough, this implies that ")#tao-math("{\\left\\|u\\right\\|_{X_T} \\lesssim_d \\varepsilon_d}", block: false)#text(" for all ")#mi("{T}")#text(" (this is an example of a “continuity argument”). Next, if we set")

#align(center)[#tao-fit-display[#tao-math("\\left\\|u\\right\\|_{X^s_T} = \\left\\|u\\right\\|_{C^0_t H^{s}_x( [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)} + \\left\\|u\\right\\|_{L^2_t H^{s+1}_x( [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}", block: true)]]

#text("then repeating the previous arguments also gives")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u \\right\\|_{X^s_T} \\lesssim_d \\left\\| u_0 \\right\\|_{H^{s}({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)} + \\left\\| u \\right\\|_{X_T} \\left\\| u \\right\\|_{X^s_T};", block: true)]]

#text("as ")#tao-math("{\\left\\|u\\right\\|_{X^s_T}}", block: false)#text(" is finite and ")#tao-math("{\\left\\|u\\right\\|_{X_T} \\lesssim_d \\varepsilon_d}", block: false)#text(", we conclude (for ")#mi("{\\varepsilon_d}")#text(" small enough) that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u \\right\\|_{X^s_T} \\lesssim_d \\left\\| u_0 \\right\\|_{H^{s}({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}.", block: true)]]

#text("In particular we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u(t) \\right\\|_{H^{s}({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)} \\lesssim_d \\left\\| u_0 \\right\\|_{H^{s}({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}", block: true)]]

#text("for all ")#mi("{0 < t < T_*}")#text(", and hence by Theorem ")#link(<tao-8c2d2b507c5488d60854>)[#text("38")]#text(" we have ")#mi("{T_* = \\infty}")#text(". The argument used to prove Corollary ")#link(<tao-c0a72299f59efbe03558>)[#text("40")]#text(" shows that ")#mi("{u}")#text(" is smooth. From the ")#mi("{X_T}")#text(" bounds on ")#mi("{u}")#text(" we see that, ")#mi("{u}")#text(" lies in ")#mi("{X}")#text(" with norm at most ")#mi("{C_d \\varepsilon_d}")#text(", and so agrees with the fixed point of ")#mi("{\\Phi}")#text(" located previously. The claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 46")]#text(" Modifications of this argument also allow one to establish local existence of ")#mi("{H^{\\frac{d}{2}-1}}")#text(" mild solutions when the initial data ")#mi("{u_0}")#text(" lies in ")#mi("{H^{\\frac{d}{2}-1}({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0}")#text(", but has large norm rather than norm less than ")#mi("{\\varepsilon_d}")#text("; see Exercise ")#link(<tao-d35c416a85b807e9b538>)[#text("47")]#text(" below. However, in this case one does not have a lower bound on the time of existence that depends only on the norm of the data, as was the case with Theorem ")#link(<tao-c09e73104942e5734ccc>)[#text("37")]#text(". Further modification of the argument also allows one to extend Theorem ")#link(<tao-8c2d2b507c5488d60854>)[#text("38")]#text(" to the entire “subcritical” range of regularities ")#mi("{s > \\frac{d}{2}-1}")#text(". See ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=166499")[#text("the paper of Fujita and Kato")]#text(" for details.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 47 (Large data critical local existence)")]#text(" ")#metadata(none) <tao-d35c416a85b807e9b538>#text(" Suppose that ")#mi("{u_0 \\in H^{\\frac{d}{2}-1}({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)^0}")#text(" is divergence-free. Show that there exists ")#mi("{T>0}")#text(" and a ")#mi("{H^{\\frac{d}{2}-1}}")#text(" mild solution to the Navier-Stokes equations on ")#mi("{[0,T]}")#text(". Furthermore, if ")#mi("{u_0}")#text(" is smooth, then this mild solution is also smooth. (")#emph[#text("Hint:")]#text(" By choosing ")#mi("{T}")#text(" small enough, one can ensure that the linear evolution ")#mi("{t \\mapsto e^{t\\nu \\Delta} u_0}")#text(" is small in ")#mi("{L^2_t H^{n/2}_x}")#text(" and ")#mi("{L^2_t L^\\infty_x}")#text(" norms. Now run a contraction mapping argument in a space of functions ")#mi("{u}")#text(" that are small in ")#mi("{L^2_t H^{n/2}_x}")#text(" and ")#mi("{L^2_t L^\\infty_x}")#text(" norm and bounded in ")#mi("{C^0_t H^{n/2}_x}")#text(" norm. One will have to carefully choose all the relevant parameters in the right order, and to choose an appropriate weighted metric on this space of functions, in order to actually obtain a contraction.")
]

#text("We now turn attention to the non-periodic case in two and higher dimensions ")#mi("{d \\geq 2}")#text(". The theory is largely identical, though with some minor technical differences. Unlike the periodic case, we will not attempt to reduce to the case of ")#mi("{u}")#text(" having mean zero (indeed, we will not even assume that ")#mi("{u}")#text(" is absolutely integrable, so that the mean might not even be well defined).")

#text("In the periodic case, we focused initially on smooth solutions. Smoothness is not sufficient by itself in the non-periodic setting to provide a good well-posedness theory, as we already saw in Section ")#link(<tao-d665dc4299392488f716>)[#text("3")]#text(" when discussing the linear heat equation; some additional decay at spatial infinity is needed. There is some flexibility as to how much smoothness to prescribe. Let us say that a solution ")#mi("{(u,p)}")#text(" to Navier-Stokes is ")#emph[#text("classical")]#text(" if ")#mi("{u: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" and ")#mi("{p: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}}")#text(" are smooth, and furthermore ")#mi("{u}")#text(" lies in ")#mi("{C^0_t H^s_x( [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d )}")#text(" for every ")#mi("{s}")#text(".")

#text("Now we work on normalising the pressure. Suppose ")#mi("{(u,p)}")#text(" is a classical solution. As before we may write the Navier-Stokes equation in divergence form as ")#link(<tao-1df3da78f6882427fe6e>)[#text("(32)")]#text(". Taking a further divergence we obtain the equation")

#align(center)[#tao-fit-display[#mitex("\\Delta p = \\nabla \\cdot \\nabla \\cdot (u \\otimes u).")]]

#text("The function ")#mi("{u \\otimes u}")#text(" belongs to ")#mi("{C^t H^s_x}")#text(" for every ")#mi("{s}")#text(", so if we define the normalised pressure")

#align(center)[#tao-fit-display[#mitex("p_0 := \\Delta^{-1} (\\nabla \\cdot \\nabla \\cdot (u \\otimes u))")]]

#text("via the Fourier transform as")

#align(center)[#tao-fit-display[#tao-math("\\widehat{\\Delta p_0}(\\xi) = \\frac{\\xi_i \\xi_j}{\\left|\\xi\\right|^2} \\widehat{u_i u_j}(\\xi)", block: true)]]

#text("then ")#mi("{p_0}")#text(" will also belong to ")#mi("{C^0_t H^s_x}")#text(" for every ")#mi("{s}")#text(". We then have ")#mi("{p = p_0 + h}")#text(" for some harmonic function ")#mi("{h: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}}")#text("that is smooth in space and continuous in time (thus all spatial derivatives exist and are continuous in both space and time). To control this harmonic function, we return to ")#link(<tao-1df3da78f6882427fe6e>)[#text("(32)")]#text(", which we write as")

#align(center)[#tao-fit-display[#mitex("\\nabla h = -\\partial_t u + F")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("F := - \\nabla \\cdot (u \\otimes u) + \\nu \\Delta u - \\nabla p_0")]]

#text("and apply the fundamental theorem of calculus to conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_{t_1}^{t_2} \\nabla h(t)\\ dt = - u(t_2) + u(t_1) + \\int_{t_2}^{t_1} F(t)\\ dt.")]]

#text("The left-hand side is harmonic (thanks to differentiating under the integral sign), and the right-hand side lies in ")#mi("{L^2({\\bf R}^d \\rightarrow {\\bf R})}")#text(" (in fact it is in ")#mi("{H^s}")#text(" for every ")#mi("{s}")#text("), hence both sides vanish. By the fundamental theorem of calculus this implies that ")#mi("{\\nabla h(t)}")#text(" vanishes identically, thus ")#mi("{h(t)}")#text(" is constant in space. One can then subtract it from the pressure without affecting ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text("; also, we now have")

#align(center)[#tao-fit-display[#mitex("\\nabla p = \\nabla p_0 = \\nabla \\Delta^{-1} (\\nabla \\cdot \\nabla \\cdot (u \\otimes u))")]]

#text("which implies that ")#mi("{\\nabla p \\in C^0_t H^s_x}")#text(" for all ")#mi("{s}")#text(", which by the Navier-Stokes equations implies that ")#mi("{u \\in C^1_t H^s_x}")#text(" for all ")#mi("{x}")#text("; iterating this we find eventually that all time derivatives of ")#mi("{p_0}")#text(" exist in ")#mi("{H^s_x}")#text(", and hence ")#mi("{p_0}")#text(" is smooth. Thus, in the category of classical solutions, at least, we may assume without loss of generality that we have ")#emph[#text("normalised pressure")]

#align(center)[#tao-fit-display[#mitex("p_0 := - \\Delta^{-1} (\\nabla \\cdot \\nabla \\cdot (u \\otimes u))")]]

#text("in which case the Navier-Stokes equations may be written as before as ")#link(<tao-6f035df254ed46ba11c5>)[#text("(33)")]#text(". (See also ")#link("https://arxiv.org/abs/1108.1165")[#text("this paper of mine")]#text(" for some variants of this argument.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 48 (Uniqueness with normalised pressure)")]#text(" ")#metadata(none) <tao-b84439240b74c7c08a61>#text(" Let ")#mi("{(u_1,p_1), (u_2,p_2)}")#text(" be two smooth classical solutions to ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" on ")#mi("{[0,T] \\times {\\bf R}^d}")#text(" with normalised pressure such that ")#mi("{u_1(0)=u_2(0)}")#text(". Then ")#mi("{(u_1,p_1)=(u_2,p_2)}")#text(".")
]

#text("We can now define the notion of a Fujita-Kato ")#mi("{H^s}")#text(" mild solution as before, except that we replace all mention of the torus ")#mi("{{\\bf R}^d/{\\bf Z}^d}")#text(" with the Euclidean space ")#mi("{{\\bf R}^d}")#text(", and omit all requirements for the solution to be of mean zero. As stated in the appendix, the product estimate in Proposition ")#link(<tao-aa77e694ded50339aeb8>)[#text("35")]#text(" continues to hold in ")#mi("{{\\bf R}^d}")#text(", so one can obtain the analogue of Theorem ")#link(<tao-c09e73104942e5734ccc>)[#text("37")]#text(", Theorem ")#link(<tao-8c2d2b507c5488d60854>)[#text("38")]#text(", Proposition ")#link(<tao-7cf6b0597fe4e3cb3559>)[#text("39")]#text(", and Corollary ")#link(<tao-c0a72299f59efbe03558>)[#text("40")]#text(" on ")#mi("{{\\bf R}^d}")#text(" by repeating the proofs with the obvious changes; we leave the details as an exercise for the interested reader.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 49")]#text(" Establish an analogue of Proposition ")#link(<tao-136c0df4f4faf78145be>)[#text("44")]#text(" on ")#mi("{{\\bf R}^d}")#text(", using the homogeneous Sobolev space ")#mi("{\\dot H^{\\frac{d}{2}-1}({\\bf R}^d \\rightarrow {\\bf R})}")#text(" defined to be the closure of the Schwartz functions ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" with respect to the norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{\\dot H^{\\frac{d}{2}-1}({\\bf R}^d \\rightarrow {\\bf R})} := (\\int_{{\\bf R}^d} \\left|\\xi\\right|^{d-2} \\left|\\hat f(\\xi)\\right|^2\\ d\\xi)^{1/2},", block: true)]]

#text("and use this to state and prove an analogue of Theorem ")#link(<tao-50fb28b23c1e32dd0bd4>)[#text("45")]#text(".")
]

#heading(level: 1)[#strong[#text(" — 5. Heuristics — ")]]

#text("There are several further extensions of these types of local and global existence results for smooth solutions, in which the role of the Sobolev spaces ")#mi("{H^s}")#text(" here are replaced by other function spaces. For instance, in three dimensions in the non-periodic setting, the role of the critical space ")#mi("{\\dot H^{1/2}({\\bf R}^3 \\rightarrow {\\bf R}^3)}")#text(" was replaced by the larger critical space ")#mi("{L^3({\\bf R}^3 \\rightarrow {\\bf R}^3)}")#text(" by ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=760047")[#text("Kato")]#text(", and to the even larger space ")#mi("{BMO^{-1}({\\bf R}^3 \\rightarrow {\\bf R}^3)}")#text(" by ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1808843")[#text("Koch and Tataru")]#text(", who also gave evidence that the latter space essentially the limit of the method; in even larger spaces such as the Besov space ")#mi("{B^{-1}_{\\infty,\\infty}}")#text(", there are constructions ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2473255")[#text("of Bourgain and Pavlovic")]#text(" that demonstrate ill-posedness in the sense of “norm inflation” – solutions that start from arbitrarily small norm data but end up being arbitrarily large in arbitrarily small amounts of time. (This grossly abbreviated history skips over dozens of other results, both positive and negative, in yet further function spaces, such as Morrey spaces or Besov spaces. See for instance the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3469428")[#text("recent text of Lemarie-Rieusset")]#text(" for a survey.)")

#text("Rather tham detail these other results, let us present instead a ")#emph[#text("scaling heuristic")]#text(" which can be used to interpret these results (and can clarify why all the positive well-posedness results discussed here involve either “subcritical” or “critical” function spaces, rather than “supercritical” ones). For simplicity we restrict our discussion to the non-periodic setting ")#mi("{{\\bf R}^d}")#text(", although the discussion here could also be adapted without much difficulty to the periodic setting (which effectively just imposes an additional constraint ")#mi("{N \\gtrsim 1}")#text(" on the frequency parameter ")#mi("{N}")#text(" to be introduced below).")

#text("In this heuristic discussion, we assume that any given time ")#mi("{t}")#text(", the velocity field ")#mi("{u(t)}")#text(" is primarily located at a certain frequency ")#mi("{N = N(t)}")#text(" (or equivalently, at a certain wavelength ")#mi("{1/N = 1/N(t)}")#text(") in the sense that the spatial Fourier transform ")#mi("{\\hat u(t)}")#text(" is largely concentrated in the region ")#tao-math("{\\left|\\xi\\right| \\sim N}", block: false)#text(". We also assume that at this time, the solution has an amplitude ")#mi("{A(t)}")#text(", in the sense that ")#mi("{u(t,x)}")#text(" tends to be of order ")#mi("{A(t)}")#text(" in magnitude in the region where it is concentrated. (We are deliberately leaving terms such as “concentrated” vague for the purposes of this discussion.) Using this ansatz, one can then heuristically compute the magnitude of various terms in the Navier-Stokes equations ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" or the projected version ")#link(<tao-6f035df254ed46ba11c5>)[#text("(33)")]#text(". For instance, if ")#mi("{u}")#text(" has amplitude ")#mi("{\\sim A}")#text(" and frequency ")#mi("{\\sim N}")#text(", then ")#mi("{\\Delta u}")#text(" should have amplitude ")#mi("{\\sim AN^2}")#text(" (and frequency ")#mi("{\\sim N}")#text("), since the Laplacian operator ")#mi("{\\Delta}")#text(" multiplies the Fourier transform ")#mi("{\\hat u(t,\\xi)}")#text(" by ")#tao-math("{4\\pi^2 \\left|\\xi\\right|^2 \\sim N^2}", block: false)#text("; one can also take a more “physical space” viewpoint and view the second derivatives in ")#mi("{\\Delta}")#text(" as being roughly like dividing out by the wavelength ")#mi("{1/N}")#text(" twice. Thus we see that the viscosity term ")#mi("{\\nu \\Delta u}")#text(" in ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" or ")#link(<tao-6f035df254ed46ba11c5>)[#text("(33)")]#text(" should have size about ")#mi("{\\nu AN^2}")#text(". Similarly, the expression ")#mi("{u \\otimes u}")#text(" in ")#link(<tao-6f035df254ed46ba11c5>)[#text("(33)")]#text(" should have magnitude ")#mi("{\\sim A^2}")#text(" and frequency ")#mi("{\\sim N}")#text(" (or maybe slightly less due to cancellation), so ")#mi("{\\nabla \\cdot (u \\otimes u)}")#text(" and hence ")#mi("{\\mathbb{P} \\nabla \\cdot (u \\otimes u)}")#text(" should have magnitude ")#mi("{\\sim A^2 N}")#text(". The terms ")#mi("{(u \\cdot \\nabla) u}")#text(" and ")#mi("{\\nabla p}")#text(" in ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" can similarly be computed to have magnitude ")#mi("{\\sim A^2 N}")#text(". Finally, if the solution oscillates (or blows up) in time in intervals of length ")#mi("{T}")#text(" (which one can think of as the natural time scale for the solution), then the term ")#mi("{\\partial_t u}")#text(" should have magnitude ")#mi("{\\sim A/T}")#text(".")

#text("This leads to the following heuristics:")

#list(
[#text("If ")#mi("{\\nu A N^2 \\gg A^2 N}")#text(" (or equivalently if ")#mi("{A \\ll \\nu N}")#text("), then the viscosity term ")#mi("{\\nu \\Delta u}")#text(" dominates the nonlinear terms in ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" or ")#link(<tao-6f035df254ed46ba11c5>)[#text("(33)")]#text(", and one should expect the Navier-Stokes equations to behave like the heat equation ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(23)")]#text(" in this regime. In particular solutions should exist and maintain (or even improve) their regularity as long as this regime persists. To balance the equation ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" or ")#link(<tao-6f035df254ed46ba11c5>)[#text("(33)")]#text(", one expects ")#mi("{A/T \\sim \\nu A N^2}")#text(", so the natural time scale here is ")#mi("{T \\sim \\frac{1}{\\nu N^2}}")#text(".")],
[#text("If ")#mi("{\\nu A N^2 \\ll A^2 N}")#text(" (or equivalently if ")#mi("{A \\gg \\nu N}")#text("), then nonlinear effects dominate, and the behaviour is likely to be quite different to that of the heat equation. One now expects ")#mi("{A/T \\sim A^2 N}")#text(", so the natural time scale here is ")#mi("{T \\sim \\frac{1}{AN}}")#text(". In particular, one could theoretically have blowup or other bad behaviour after this time scale.")]
)

#text("As a general rule of thumb, the known well-posedness theory for the Navier-Stokes equation is only applicable when the hypotheses on the initial data (and on the timescale being considered) is compatible either with the viscosity-dominated regime ")#mi("{A \\ll \\nu N}")#text(", or the time-limited regime ")#mi("{T \\ll \\frac{1}{AN}}")#text(". Outside of these regimes, we expect the evolution to be highly nonlinear in nature, and techniques such as the ones in this set of notes, which are primarily based on approximating the evolution by the linear heat flow, are not expected to apply.")

#text("Let’s discuss some of the results in this set of notes using these heuristics. Suppose we are given that the initial data ")#mi("{u_0}")#text(" is bounded in ")#mi("{H^s}")#text(" norm by some bound ")#mi("{B}")#text(":")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u_0 \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)} \\leq B.", block: true)]]

#text("As in the above heuristics, we assume that ")#mi("{u_0}")#text(" exhibits some amplitude ")#mi("{A}")#text(" and frequency ")#mi("{N}")#text(". Heuristically, the ")#mi("{H^s}")#text(" norm of ")#mi("{u_0}")#text(" should resemble ")#mi("{(1+N)^s}")#text(" times the ")#mi("{L^2}")#text(" norm of ")#mi("{u_0}")#text(", which should be roughly ")#mi("{A V^{1/2}}")#text(", where ")#mi("{V}")#text(" is the volume of the region where ")#mi("{u_0}")#text(" is concentrated in. Thus we morally have a bound of the form")

#align(center)[#tao-fit-display[#mitex("(1+N)^s A V^{1/2} \\lesssim B.")]]

#text("To use this bound, we invoke (at a heuristic level) the ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/uncertainty principle")[#text("uncertainty principle")]#text(" ")#mi("{\\Delta x \\Delta \\xi \\gtrsim 1}")#text(", which indicates that the data ")#mi("{u_0}")#text(" should be spatially spread out at a scale of at least the wavelength ")#mi("{1/N}")#text(", which implies that the volume ")#mi("{V}")#text(" should be at least ")#mi("{\\gtrsim 1/N^d}")#text(". Thus we have")

#align(center)[#tao-fit-display[#mitex("(1+N)^s N^{-\\frac{d}{2}} A \\lesssim B.")]]

#text("Suppose we have ")#mi("{s \\geq \\frac{d}{2}}")#text(", then we have the crude bound")

#metadata(none) <tao-c3ccedf562d9529001d8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(39)")])
#mitex("(1+N)^s \\geq N^{\\frac{d}{2}},")]]

#text("so we expect to have an amplitude bound ")#mi("{A \\lesssim B}")#text(". If we are in the nonlinear regime ")#mi("{A \\gg \\nu N}")#text(", this implies that ")#mi("{AN \\lesssim B^2 / \\nu}")#text(", and so the natural time scale ")#mi("{T \\sim \\frac{1}{AN}}")#text(" here is lower bounded by ")#mi("{T \\gtrsim \\frac{\\nu}{B^2}}")#text(". This matches up with the local existence time given in Theorem ")#link(<tao-c09e73104942e5734ccc>)[#text("37")]#text(" (or the non-periodic analogue of this theorem). However, the use of the crude bound ")#link(<tao-c3ccedf562d9529001d8>)[#text("(39)")]#text(" suggests that one can make improvements to this bound when ")#mi("{s}")#text(" is far from ")#mi("{\\frac{d}{2}}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 50")]#text(" ")#metadata(none) <tao-5f44712b7d71ded71ea9>#text(" If ")#mi("{\\frac{d}{2}-1 < s < \\frac{d}{2} + 1}")#text(", make a heuristic argument as to why the optimal lower bound for the time of existence ")#mi("{T}")#text(" for the Navier-Stokes equation in terms of the ")#mi("{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" norm of the initial data ")#mi("{u_0}")#text(" should take the form")

#align(center)[#tao-fit-display[#tao-math("T \\gtrsim \\frac{1}{\\nu (\\left\\| u_0 \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)}/\\nu)^{\\frac{2}{s-\\frac{d}{2}+1}}}.", block: true)]]
]

#text("In a similar spirit, suppose we have the smallness hypothesis")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u_0 \\right\\|_{\\dot H^{\\frac{d}{2}-1}({\\bf R}^d \\rightarrow {\\bf R}^d)} \\leq \\varepsilon_d \\nu", block: true)]]

#text("on the critical norm ")#tao-math("{\\left\\| u_0 \\right\\|_{\\dot H^{\\frac{d}{2}-1}({\\bf R}^d \\rightarrow {\\bf R}^d)}}", block: false)#text(", then a similar analysis to above leads to")

#align(center)[#tao-fit-display[#mitex("N^{\\frac{d}{2}-1} N^{-\\frac{d}{2}} A \\lesssim \\varepsilon_d \\nu")]]

#text("and hence we will be in the viscosity dominated regime ")#mi("{A \\ll \\nu N}")#text(" if ")#mi("{\\varepsilon_d}")#text(" is small enough, regardless of what time scale ")#mi("{T}")#text(" one uses; this is consistent with the global existence result in Theorem ")#link(<tao-50fb28b23c1e32dd0bd4>)[#text("45")]#text(". On the other hand, if the norm ")#tao-math("{\\left\\| u_0 \\right\\|_{\\dot H^{\\frac{d}{2}-1}({\\bf R}^d \\rightarrow {\\bf R}^d)}}", block: false)#text(" is much larger than ")#mi("{\\nu}")#text(", then ")#mi("{A}")#text(" can be larger than ")#mi("{\\nu N}")#text(", and we can fail to be in the viscosity dominated regime at any choice of frequency ")#mi("{N}")#text("; setting ")#mi("{A}")#text(" to be a large multiple of ")#mi("{\\nu N}")#text(" and sending ")#mi("{N}")#text(" to infinity, we see that the natural time scale ")#mi("{T}")#text(" could be arbitrarily small.")

#text("Finally, if one only controls a supercritical norm such as ")#tao-math("{\\left\\| u_0 \\right\\|_{H^{\\frac{d}{2}-1-\\delta}({\\bf R}^d \\rightarrow {\\bf R}^d)}}", block: false)#text(" for some ")#mi("{\\delta > 0}")#text(", this gives a bound on a quantity of the form ")#mi("{A N^{-1-\\delta}}")#text(", which allows one to leave the viscosity dominated regime ")#mi("{A \\ll \\nu N}")#text(" (with plenty of room to spare) when ")#mi("{N}")#text(" is large, creating examples of initial data for which the natural time scale can be made arbitrarily small. As ")#mi("{N}")#text(" increases (restricting to, say, powers of two), the supercritical norm of these examples decays geometrically, so one can superimpose an infinite number of these examples together, leading to a choice of initial data with arbitrarily small supercritical norm for which the natural time scale is in fact zero. This strongly suggests that there is no good local well-posedness theory at such regularities.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 51")]#text(" Discuss the product estimate in Proposition ")#link(<tao-aa77e694ded50339aeb8>)[#text("35")]#text(", the Sobolev estimate in Exercise ")#link(<tao-454bedc703c397ac8232>)[#text("36")]#text(", and the energy estimates in Exercise ")#link(<tao-15f5bbc66cfcfdfb89ba>)[#text("29")]#text("(d) and Proposition ")#link(<tao-136c0df4f4faf78145be>)[#text("44")]#text(" using the above heuristics.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 52")]#text(" These heuristics can also be used to locate errors in many purported solutions to the Navier-Stokes global regularity problem that proceed through a sequence of estimates on a Navier-Stokes solution. At some point, the estimates have to rule out the scenario that the solution ")#mi("{u}")#text(" leaves the viscosity-dominated regime ")#mi("{A \\ll \\nu N}")#text(" at larger and larger frequencies ")#mi("{N}")#text(" (and at smaller and smaller time scales ")#mi("{T}")#text("), with the time scales converging to zero to achieve a finite time blowup. If the estimates in the proposed solution are strong enough to heuristically rule out this scenario by the end of the argument, but not at the beginning of the argument, then there must be some step inside the argument where one moves from “supercritical” estimates that are too weak to rule out this scenario, to “critical” or “subcritical” estimates which are capable of doing so. This step is often where the error in the argument may be found.")
]

#text("The above heuristics are closely tied to the classification of various function space norms as being “subcritical”, “supercritical”, or “critical”. Roughly speaking, a norm is subcritical if bounding that norm heuristically places one in the linear-dominated regime (which, for Navier-Stokes, is the viscosity-dominated regime) at high frequencies; critical if control of the norm very nearly places one in the linear-dominated regime at high frequencies; and supercritical if control of the norm completely fails to place one in the linear-dominated regime at high frequencies. When the equation in question enjoys a scaling symmetry, the distinction between subcritical, supercritical, and critical norms can be made by seeing how the the top-order component of these norms vary with respect to scaling a function to be high frequency. In the case of the Navier-Stokes equations ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(", the scaling ")#mi("{(u,p) \\mapsto (u_\\lambda,p_\\lambda)}")#text(" is given by the formulae ")#metadata(none) <tao-4bc33b57964b7be590d5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(40)")])
#mitex("u_\\lambda(t,x) := \\lambda u( \\lambda^2 t, \\lambda x)")]]



#metadata(none) <tao-9033cec3f2ecb00a41a4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(41)")])
#mitex("p_\\lambda(t,x) := \\lambda^2 p(\\lambda^2 t, \\lambda x)")]]

#text("with the initial data ")#mi("{u_0}")#text(" similarly being scaled to")

#align(center)[#tao-fit-display[#mitex("u_{0,\\lambda}(x) := \\lambda u_0(\\lambda x).")]]

#text("Here ")#mi("{\\lambda > 0}")#text(" is a scaling parameter; as ")#mi("{\\lambda \\rightarrow \\infty}")#text(", the functions ")#mi("{u_\\lambda, p_\\lambda, u_{0,\\lambda}}")#text(" are being sent to increasingly fine scales (i.e., high frequencies). One easily checks that if ")#mi("{(u,p)}")#text(" solves the Navier-Stokes equations ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" with initial data ")#mi("{u_0}")#text(", then ")#mi("{(u_\\lambda,p_\\lambda)}")#text(" solves the same equations with initial data ")#mi("{u_{0,\\lambda}}")#text("; similarly for other formulations of the Navier-Stokes equations such as ")#link(<tao-6f035df254ed46ba11c5>)[#text("(33)")]#text(" or ")#link(<tao-54330ff21681f8a60f67>)[#text("(34)")]#text(". (In terms of the parameters ")#mi("{A,N,T,V}")#text(" from the previous heuristic discussion, this scaling corresponds to the map ")#mi("{(A,N,T,V) \\mapsto (\\lambda A, \\lambda N, \\lambda^{-2} T, \\lambda^{-d} V)}")#text(".)")

#text("Typically, if one considers a function space norm of ")#mi("{u_{0,\\lambda}}")#text(" (or of ")#mi("{u_\\lambda}")#text(" or ")#mi("{p_\\lambda}")#text(") in the limit ")#mi("{\\lambda \\rightarrow \\infty}")#text(", the top order behaviour will be given by some power ")#mi("{\\lambda^\\alpha}")#text(" of ")#mi("{\\lambda}")#text(". A norm is called ")#emph[#text("subcritical")]#text(" if the exponent ")#mi("{\\alpha}")#text(" is positive, ")#emph[#text("supercritical")]#text(" if the exponent is negative, and ")#emph[#text("critical")]#text(" if the exponent is zero. For instance, one can calculate the Fourier transform")

#align(center)[#tao-fit-display[#mitex("\\widehat{u_{0,\\lambda}}(\\xi) = \\lambda^{1-d} \\hat u_0(\\xi/\\lambda)")]]

#text("and hence")

#tao-aligned(keep: true)[


#tao-math("\\left\\| u_{0,\\lambda} \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)}^2  & = \\lambda^{2-2d} \\int_{{\\bf R}^d} \\langle \\xi \\rangle^{2s} \\left|\\hat u_0(\\xi/\\lambda)\\right|^2\\ d\\xi", block: true)



#tao-math(" & = \\lambda^{2-d} \\int_{{\\bf R}^d} \\langle \\lambda \\xi \\rangle^{2s} \\left|\\hat u_0(\\xi)\\right|^2\\ d\\xi.", block: true)
]

#text("As ")#mi("{\\lambda \\rightarrow \\infty}")#text(", this expression behaves like ")#mi("{\\lambda^{2-d+2s}}")#text(" to top order; hence the ")#mi("{H^s}")#text(" norm is subcritical when ")#mi("{s > \\frac{d}{2}-1}")#text(", supercritical when ")#mi("{s < \\frac{d}{2}-1}")#text(", and critical when ")#mi("{s = \\frac{d}{2}-1}")#text(".")

#text("Another way to phrase this classification is to use ")#link("https://en.wikipedia.org/wiki/Dimensional_analysis")[#text("dimensional analysis")]#text(". If we use ")#mi("{L}")#text(" to denote the unit of length, and ")#mi("{T}")#text(" the unit of time, then the velocity field ")#mi("{u}")#text(" should have units ")#mi("{L T^{-1}}")#text(", and the terms ")#mi("{\\partial_t u}")#text(" and ")#mi("{(u \\cdot \\nabla) u}")#text(" in ")#link(<tao-5bda84779c07d3fa658d>)[#text("(1)")]#text(" then have units ")#mi("{L T^{-2}}")#text(". To be dimensionally consistent, the kinematic viscosity ")#mi("{\\nu}")#text(" must then have the units ")#mi("{L^2 T^{-1}}")#text(", and the pressure ")#mi("{p}")#text(" should have units ")#mi("{L^2 T^{-2}}")#text(". (This differs from the usual units given in physics to the pressure, which is ")#mi("{M L^{2-d} T^{-2}}")#text(" where ")#mi("{M}")#text(" is the unit of mass; the discrepancy comes from the choice to normalise the density, which usually has units ")#mi("{M L^{-d}}")#text(", to equal ")#mi("{1}")#text(".) If we fix ")#mi("{\\nu}")#text(" to be a dimensionless constant such as ")#mi("{1}")#text(", this forces a relation ")#mi("{T = L^2}")#text(" between the time and length units, so now ")#mi("{u}")#text(" and ")#mi("{p}")#text(" have the units ")#mi("{L^{-1}}")#text(" and ")#mi("{L^{-2}}")#text(" respectively (compare with ")#link(<tao-4bc33b57964b7be590d5>)[#text("(40)")]#text(" and ")#link(<tao-9033cec3f2ecb00a41a4>)[#text("(41)")]#text("). Of course ")#mi("{u_0}")#text(" will then also have units ")#mi("{L^{-1}}")#text(". One can then declare a function space norm of ")#mi("{u_0}")#text(", ")#mi("{u}")#text(", or ")#mi("{p}")#text(" to be subcritical if its top order term has units of a negative power of ")#mi("{L}")#text(", supercritical if this is a positive power of ")#mi("{L}")#text(", and critical if it is dimensionless. For instance, the top order term in ")#tao-math("{\\left\\| u_{0} \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)}}", block: false)#text(" is the ")#mi("{L^2}")#text(" norm of ")#tao-math("{\\left|\\nabla\\right|^s u_0}", block: false)#text("; as ")#tao-math("{\\left|\\nabla\\right|^s u_0}", block: false)#text(" has the units of ")#mi("{L^{-1-s}}")#text(", and Lebesgue measure ")#mi("{dx}")#text(" has the units of ")#mi("{L^d}")#text(", we see that ")#tao-math("{\\left\\| u_{0} \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)}}", block: false)#text(" has the units of ")#mi("{L^{-1-s} L^{d/2}}")#text(", giving the same division into subcritical, supercritical, and critical spaces as before.")

#heading(level: 1)[#strong[#text(" — 6. Appendix: some Littlewood-Paley theory — ")]]

#text("We now prove Proposition ")#link(<tao-aa77e694ded50339aeb8>)[#text("35")]#text(". By a limiting argument it suffices to establish the claim for smooth ")#mi("{u,v}")#text(". The claim is immediate from Hölder’s inequality when ")#mi("{s=0}")#text(", so we will assume ")#mi("{s>0}")#text(". For brevity we shall abbreviate ")#mi("{L^2({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}")#text(" as ")#mi("{L^2}")#text(", and similarly for ")#mi("{H^s}")#text(", etc..")

#text("We use the technique of Littlewood-Paley projections. Let ")#mi("{\\phi: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" be an even bump function (depending only on ")#mi("{d}")#text(") that equals ")#mi("{1}")#text(" on ")#mi("{B(0,1/2)}")#text(" and is supported on ")#mi("{B(0,1)}")#text("; for the purposes of asymptotic notation, any bound that depends on ")#mi("{\\phi}")#text(" can thus be thought of as depending on ")#mi("{d}")#text(" instead. For any dyadic integer ")#mi("{N}")#text(" (by which we mean an integer that is a power of ")#mi("{2}")#text("), define the ")#emph[#text("Littlewood-Paley projections")]#text(" ")#mi("{P_{\\leq N}, P_N}")#text(" on periodic smooth functions ")#mi("{f: {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}}")#text(" by the formulae")

#align(center)[#tao-fit-display[#mitex("P_{\\leq N} f(x) := \\sum_{k \\in {\\bf Z}^d} \\phi( k/N ) \\hat f(k) e^{2\\pi i k \\cdot x}")]]

#text("and (for ")#mi("{N > 1}")#text(")")

#align(center)[#tao-fit-display[#mitex("P_N := P_{\\leq N} - P_{\\leq N/2}")]]

#text("so one has the ")#emph[#text("Littlewood-Paley decomposition")]

#align(center)[#tao-fit-display[#mitex("f = P_{\\leq 1} f + \\sum_{N>1} P_N f.")]]

#text("Here and in the sequel ")#mi("{N}")#text(" is always understood to be restricted to be a dyadic integer.")

#text("The key point of this decomposition is that the ")#mi("{L^p}")#text(" and Sobolev norms of the individual components of this decomposition are easier to estimate than the original function ")#mi("{f}")#text(". The following estimates in particular will suffice for our applications:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 53 (Basic Littlewood-Paley estimates)")]#text(" ")#metadata(none) <tao-fbb7b5bf4ca348eeeebf>

#list(
[#text("(a) For any dyadic integer ")#mi("{N}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("P_{\\leq N} f(x) = \\int_{{\\bf R}^d} \\check \\phi(y) f(x - \\frac{y}{N})\\ dy")]]

#text("where ")#mi("{\\check \\phi(x) := \\int_{{\\bf R}^d} \\phi(\\xi) e^{2\\pi i \\xi \\cdot x}\\ d\\xi}")#text(" is the inverse Fourier transform of ")#mi("{\\phi}")#text(" on ")#mi("{{\\bf R}^d}")#text(", and the difference ")#mi("{x - \\frac{y}{N} \\in {\\bf R}^d/{\\bf Z}^d}")#text(" between the coset ")#mi("{x \\in {\\bf R}^d/{\\bf Z}^d}")#text(" and the shift ")#mi("{\\frac{y}{N} \\in {\\bf R}^d}")#text(" is defined in the obvious fashion. In particular if ")#mi("{f}")#text(" is real-valued then so is ")#mi("{P_{\\leq N}}")#text(" and ")#mi("{P_N}")#text(". Conclude the ")#emph[#text("Bernstein inequality")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| P_{\\leq N} f \\right\\|_{L^q} \\lesssim_{d} N^{\\frac{d}{p}-\\frac{d}{q}} \\left\\| f \\right\\|_{L^p}", block: true)]]

#text("for all smooth functions ")#mi("{f: {\\bf R}^d/{\\bf Z}^d \\rightarrow{\\bf R}}")#text(", all ")#mi("{N \\geq 1}")#text(" and ")#mi("{1 \\leq p \\leq q \\leq \\infty}")#text("; in particular")

#align(center)[#tao-fit-display[#tao-math("\\left\\| P_{\\leq N} f \\right\\|_{L^p} \\lesssim_{d} \\left\\| f \\right\\|_{L^p}.", block: true)]]

#text("(Recall our convention that constants that depend on ")#mi("{\\phi}")#text(" can also be thought of as depending just on ")#mi("{d}")#text(".) By the triangle inequality, the same estimates also hold for ")#mi("{P_N}")#text(", ")#mi("{N > 1}")#text(".")],
[#text("(b) For any ")#mi("{s \\geq 0}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{H^s} \\sim_{d,s} \\left\\| P_{\\leq 1} f \\right\\|_{L^2} \t+ \\left( \\sum_{N>1} N^{2s} \\left\\| P_N f \\right\\|_{L^2}^2\\right)^{1/2}", block: true)]]]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 54")]#text(" The more advanced ")#link("https://en.wikipedia.org/wiki/Littlewood%E2%80%93Paley_theory")[#text("Littlewood-Paley inequality")]#text(", which is usually proven using the Calderón-Zygmund theory of singular integrals, asserts that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{L^p} \\sim_{d,p} \\left\\| \\left|P_{\\leq 1} f\\right| + (\\sum_{N > 1} \\left|P_N f\\right|^2)^{1/2} \\right\\|_{L^p}", block: true)]]

#text("for any ")#mi("{1 < p < \\infty}")#text(". However, we will not use this estimate here.")
]

#text("We return now to the proof of Proposition ")#link(<tao-aa77e694ded50339aeb8>)[#text("35")]#text(". Let ")#mi("{\\phi}")#text(" be as above. By Exercise ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("53")]#text(", it suffices to establish the bounds ")#metadata(none) <tao-c385425e6e596873aa73>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#tao-math("\\left\\| P_{\\leq 1}( uv) \\right\\|_{L^2} \\lesssim_{d,s} \\left\\| u \\right\\|_{H^s} \\left\\| v \\right\\|_{L^\\infty} \t+ \\left\\| u \\right\\|_{L^\\infty} \\left\\| v \\right\\|_{H^s}", block: true)]]

#text(" ")#text(" and")

#metadata(none) <tao-bdc1ff2604a9891e5ec0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(43)")])
#tao-math("\\sum_{N>1} N^{2s} \\left\\| P_{N}( uv) \\right\\|_{L^2}^2 \\lesssim_{d,s} \\left\\| u \\right\\|_{H^s}^2 \\left\\| v \\right\\|_{L^\\infty}^2 \t+ \\left\\| u \\right\\|_{L^\\infty}^2 \\left\\| v \\right\\|_{H^s}^2.", block: true)]]

#text("The estimate ")#link(<tao-c385425e6e596873aa73>)[#text("(42)")]#text(" follows by dropping ")#mi("{P_{\\leq 1}}")#text(" (using Exercise ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("53")]#text(") and applying Hölder’s inequality, so we turn to ")#link(<tao-bdc1ff2604a9891e5ec0>)[#text("(43)")]#text(". We may restrict attention to those terms where ")#mi("{N>8}")#text(" (say) since the other terms can be treated by the same argument used to prove ")#link(<tao-c385425e6e596873aa73>)[#text("(42)")]#text(".")

#text("The basic strategy here is to split the product ")#mi("{uv}")#text(" (or the component ")#mi("{P_N(uv)}")#text(" of this product) into ")#link("https://en.wikipedia.org/wiki/Paraproduct")[#text("paraproducts")]#text(" in which some constraint is imposed between the frequencies of the ")#mi("{u}")#text(" and ")#mi("{v}")#text(" terms. There are many ways to achieve this splitting; we will use")

#align(center)[#tao-fit-display[#mitex("P_N(uv) = P_N( (P_{\\leq N/8}u) v ) + \\sum_{M>N/8} P_N( (P_M u) v).")]]

#text("By the triangle inequality, it suffices to show the estimates")

#metadata(none) <tao-6d591240777b72c3371f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(44)")])
#tao-math("\\sum_{N>8} N^{2s} \\left\\| P_{N}( (P_{\\leq N/8} u) v) \\right\\|_{L^2}^2 \\lesssim_{d,s} \\left\\| u \\right\\|_{L^\\infty}^2 \\left\\| v \\right\\|_{H^s}^2", block: true)]]

#text("and")

#metadata(none) <tao-db279bc9d5904ef8644a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(45)")])
#tao-math("\\sum_{N>8} N^{2s} (\\sum_{M>N/8} \\left\\| P_{N}( (P_M u) v) \\right\\|_{L^2})^2 \\lesssim_{d,s} \\left\\| u \\right\\|_{H^s}^2 \\left\\| v \\right\\|_{L^\\infty}^2", block: true)]]

#text("We begin with ")#link(<tao-6d591240777b72c3371f>)[#text("(44)")]#text(". We can expand further")

#align(center)[#tao-fit-display[#mitex("P_N( (P_{\\leq N/8} u) v ) = P_N( (P_{\\leq N/8} u) P_{\\leq 1} v ) + \\sum_{M>1} P_N( (P_{\\leq N/8} u) P_M v ).")]]

#text("The key point now is that (by inspecting the Fourier series expansions) the first term on the RHS vanishes, and the summands in the second term also vanish unless ")#mi("{M \\sim N}")#text(". Thus")

#tao-aligned(keep: true)[


#tao-math("N^{2s} \\left\\| P_{N}( (P_{\\leq N/8} u) v) \\right\\|_{L^2}^2  & \\lesssim \\sum_{M \\sim N} N^{2s} \\left\\| P_{N}( (P_{\\leq N/8} u) (P_M v)) \\right\\|_{L^2}^2", block: true)



#tao-math(" & \\lesssim_d \\sum_{M \\sim N} M^{2s} \\left\\| (P_{\\leq N/8} u) (P_M v) \\right\\|_{L^2}^2", block: true)



#tao-math(" & \\lesssim_d \\sum_{M \\sim N} M^{2s} \\left\\| P_{\\leq N/8} u \\right\\|_{L^\\infty}^2 \\left\\| P_M v \\right\\|_{L^2}^2", block: true)



#tao-math(" & \\lesssim_d \\left\\| u \\right\\|_{L^\\infty}^2 \\sum_{M \\sim N} M^{2s} \\left\\| P_M v \\right\\|_{L^2}^2", block: true)
]

#text("and the claim follows by summing in ")#mi("{N}")#text(", interchanging the summations, and using Exercise ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("53")]#text(". Now we prove ")#link(<tao-db279bc9d5904ef8644a>)[#text("(45)")]#text(". We bound")

#tao-aligned(keep: true)[


#tao-math("N^{2s} (\\sum_{M>N/8} \\left\\| P_{N}( (P_M u) v) \\right\\|_{L^2})^2  & \\lesssim_d \tN^{2s} (\\sum_{M>N/8} \\left\\| (P_M u) v \\right\\|_{L^2})^2", block: true)



#tao-math(" & \\lesssim_d N^{2s} (\\sum_{M > N/8} \\left\\| P_M u \\right\\|_{L^2} \\left\\| v \\right\\|_{L^\\infty})^2", block: true)



#tao-math(" & \\lesssim_{d,s} \\left\\| v\\right\\|_{L^\\infty}^2 \\sum_{M > N/8} (N/M)^{s} M^{2s} \\left\\| P_M u \\right\\|_{L^2}^2", block: true)
]

#text("using Cauchy-Schwarz, and the claim again follows by summing in ")#mi("{N}")#text(", interchanging the summations, and using Exercise ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("53")]#text(".")

#text("There is an essentially identical theory in the non-periodic setting, in which the role of smooth periodic functions are now replaced by Schwartz functions, the Littlewood-Paley projections ")#mi("{P_{\\leq N}}")#text(" are now defined as")

#align(center)[#tao-fit-display[#mitex("P_{\\leq N} f(x) := \\int_{{\\bf R}^d} \\phi( \\xi/N ) \\hat f(\\xi) e^{2\\pi i \\xi \\cdot x}\\ d\\xi,")]]

#text("and ")#mi("{P_N}")#text(" is defined as before.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 55 (Non-periodic Littlewood-Paley theory)")]#text(" ")#metadata(none) <tao-defa1ee51c97f87af48f>#text(" With ")#mi("{L^2}")#text(" now denoting ")#mi("{L^2({\\bf R}^d \\rightarrow {\\bf R})}")#text(" instead of ")#mi("{L^2({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}")#text(", and similarly for other function spaces, establish the non-periodic analogue of Exercise ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("53")]#text(" for Schwartz functions ")#mi("{f}")#text(".")
]

#text("In particular, one obtains the non-periodic analogue of Proposition ")#link(<tao-aa77e694ded50339aeb8>)[#text("35")]#text(" by repeating the proof verbatim.")

#heading(level: 1)[#text("Comments (94)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6b375c2b7bf216acdd980108eed6d03d1a720fe95faee715181790274d574ec-ea455139300983443b82df4b4b2c858777dfe4e37a1be96aa98fe5954020f439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-2/#comment-624974")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2021")])]

#text("I think it seems that Lemma 1 does not need to assume u_0 and u is positive?")

#emph[#text("[Fair enough; I’ve adjusted the statement appropriately. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6b375c2b7bf216acdd980108eed6d03d1a720fe95faee715181790274d574ec-ea455139300983443b82df4b4b2c858777dfe4e37a1be96aa98fe5954020f439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ning")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-2/#comment-625124")[#strong[#text("Ning")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2021")])]

#text("Dear Prof. Tao,")#linebreak()#text(" In the Part 2 – Leray system of your notes, you said that Fourier transform tends to diagonalize linear translation-invariant equations, because the plane waves $x \\mapsto e^{2\\pi i k \\cdot x}$ that underlie the Fourier transform are the eigenfunctions of translation.")#linebreak()#text(" I understood the rigorous proof below, but I did not understand this intuitive insights you presented here. I believe I have seen analogous idea in Sturm-Liouville problem. But I’m wondering what you mean by saying that ‘diagonalize linear translation-invariant equation’? I thought you used the fact that since $e^{2\\pi i k \\cdot x}$ are the complete eigenbasis of translation in L^2, so they are also eigenbasis for linear translation-invariant operators?")#linebreak()#text(" But I’m still confused about this. Could you further explain this? Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-2/#comment-625209")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2021")])]

#text("Heuristically speaking, a linear operator should be diagonalised by its eigenvectors (there are subtleties if the operator is not normal, but let us ignore this issue for now). Also heuristically speaking, commuting linear operators should have the same bases of eigenvectors (again, there are subtleties when the eigenvalues have multiplicity, but we will ignore this). Since translation has the plane waves as an eigenbasis, these two heuristics predict that any other translation-invariant operator is diagonalised by the plane wave basis. And indeed on taking Fourier transforms, any (reasonable) translation-invariant operator becomes a multiplier operator, which is the continuous version of the operation of multiplying by a diagonal matrix.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6b375c2b7bf216acdd980108eed6d03d1a720fe95faee715181790274d574ec-ea455139300983443b82df4b4b2c858777dfe4e37a1be96aa98fe5954020f439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ning")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-2/#comment-625308")[#strong[#text("Ning")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2021")])]

#text("Thanks for your reply! It makes sense to me now.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6b375c2b7bf216acdd980108eed6d03d1a720fe95faee715181790274d574ec-ea455139300983443b82df4b4b2c858777dfe4e37a1be96aa98fe5954020f439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ning")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-2/#comment-625156")[#strong[#text("Ning")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2021")])]

#text("Between equation (22) and Remark 15, there is a typo in ‘hence also in the classical sense since {p,F} have rapidly decreasing Fourier transforms and are thus smooth.’")

#text("I think it may be ")#mi("p,v")#text(" instead, and the reason for smoothness may be easier to understand in my view as following:")#linebreak()#text(" ")#mi("\\xi^\\alpha \\hat p")#text(" is in ")#mi("L^1")#text(" for any multi-index ")#mi("\\alpha")#text(" in the setting ")#mi("d>1")#text(", instead of ‘rapidly decreasing’ since I think ")#mi("\\hat p")#text(" is not in ")#mi("L^\\infty")#text(", i.e. ")#mi("\\alpha=0")#text(" case for rapid decreasing. And actually I’m confused about what does it mean by ‘rapid decreasing of a tempered distribution’.")

#text("Maybe my idea is stupid, but I think it is indeed another way to think about this?")

#emph[#text("[Text clarified – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6b375c2b7bf216acdd980108eed6d03d1a720fe95faee715181790274d574ec-ea455139300983443b82df4b4b2c858777dfe4e37a1be96aa98fe5954020f439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ning")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-2/#comment-628930")[#strong[#text("Ning")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2021")])]

#text("The paragraph between Remark 33 and Exercise 34 says that ")#mi("u \\otimes u\\in L^\\infty_t L^1_x")#text(" is more than enough regularity to make sense of the right-hand side of (34) in a distributional sense at least.")#linebreak()#text(" I got stuck here, there are too many operators here. I knew how ")#mi("u \\otimes u\\in L^\\infty_t L^1_x")#text(", but how could I verify that RHS of (34) is indeed a well-defined distribution?")#linebreak()#text(" Thanks!")

#emph[#text("[Verify that the adjoint of the operator ")#mi("F \\mapsto \\int_0^t e^{\\nu(t-s)\\Delta} {\\mathbb P} (\\nabla \\cdot F(s))\\ ds")#text(" maps test functions to bounded functions. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6b375c2b7bf216acdd980108eed6d03d1a720fe95faee715181790274d574ec-ea455139300983443b82df4b4b2c858777dfe4e37a1be96aa98fe5954020f439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ning")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-2/#comment-629034")[#strong[#text("Ning")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2021")])]

#text("Thanks for your reply. I think I have know what is the right way to prove this but I want to make sure this is correct.")#linebreak()#text(" So actually I think we do not need to calculate an explicit formula for the adjoint, but we use the adjoint to define the distribution in the way similar to the definition of the distributional derivative. We pair ")#mi("\\int_0^t e^{\\nu(t-s)\\Delta} {\\mathbb P} (\\nabla \\cdot F(x, s))\\, ds")#text(" with a test function ")#mi("\\phi(x)")#text(", then use the form of heat propagator on torus which analogous to that in exercise 24, which allows us to estimate ")#mi("\\int \\int_0^t e^{\\nu(t-s)\\Delta} {\\mathbb P} (\\nabla \\cdot F(x, s))\\phi(x)\\, ds\\, dx")#text(" by Young’s inequality for convolution, and then use the symmetry and non-expansive property of ")#mi("\\mathbb P")#text(" to conclude that it is bounded by ")#tao-math("\\left\\|F\\right\\|_{L^1} \\sup\\left|\\phi\\right|", block: false)#text(", which verifies that it is a distribution.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6b375c2b7bf216acdd980108eed6d03d1a720fe95faee715181790274d574ec-ea455139300983443b82df4b4b2c858777dfe4e37a1be96aa98fe5954020f439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ning")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-2/#comment-629069")[#strong[#text("Ning")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2021")])]

#text("In exercise 29(d), I think the assumption should be G:[0,T] \\times {\\mathbb R}^d/{\\mathbb Z}^d \\rightarrow {\\mathbb R}^{m^2}, and \\nabla G should be changed to \\nabla\\cdot G. Otherwise, the dimension is not consistent.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6b375c2b7bf216acdd980108eed6d03d1a720fe95faee715181790274d574ec-ea455139300983443b82df4b4b2c858777dfe4e37a1be96aa98fe5954020f439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ning")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-2/#comment-629526")[#strong[#text("Ning")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2021")])]

#text("Some typos and some points that confused me.")

#text("1.In the second line of the proof of Proposition 44, RHS should be LHS.")

#text("2.In the proof of Theorem 45, in first the formula to established the bound for \\Phi u, \\cdot should be \\otimes")

#text("3.In the third line of the proof of the smooth case in Theorem 45, ")#mi("0 < T \\leq T_*")#text(" should be ")#mi("0< T < T_*")

#text("4.Also in the proof of this smooth case, you missed the subsript 0 of ")#mi("u_0")#text(" in the norm below")

#text("` ")#tao-math("\\left\\|u\\right\\|_{X_T}", block: false)#text(" depends continuously on ")#mi("d")#text(" and converges to ")#tao-math("\\left\\|u_0\\right\\|_{H^{d/2-1}({\\mathbb R}^d/{\\mathbb Z}^d \\rightarrow {\\mathbb R}^d)} \\leq \\varepsilon_d", block: false)#text(" as ")#mi("T \\rightarrow 0")#text(".'")

#text("5.And I think the order in this proof for the smooth case should be reversed somehow.")

#text("You may first argue ")#mi("T_*=\\infty")#text(", then conclude that ")#tao-math("\\left\\|u\\right\\|_{X_T} \\lesssim_d \\varepsilon_d", block: false)#text(" for all ")#mi("T <\\infty")#text(", then ")#mi("u\\in X")#text(".")

#text("Instead of putting the argument of ")#mi("T_*=\\infty")#text(" to the last.")

#text("6.In this proof, you use many ")#mi("\\lesssim")#text(" symbols. I think maybe writing these constants explicitly will be more safe for me.You said")

#text("In particular, {u} lies in {X} with norm {O(C_d \\varepsilon_d)}, and so agrees with the fixed point of {\\Phi} located previously.")

#text("I am confused about why only the big O notation could tells us one agrees with another. Instead, I think we should calculate the constants carefully and find that there is a smaller ")#mi("\\widetilde C_d < C_d")#text(" such that ")#tao-math("\\left\\|u\\right\\|_{X_T} \\leq \\widetilde C_d\\varepsilon_d", block: false)#text(".(After writing out the constants carefully, I found this is the case, but I want to know how could you know only from the big O notation here?)")

#text("7.I'm curious what is it mean by having a dot on ")#mi("H^{\\frac{d}2-1}")#text(" in the formulas just below the Exercise 50?")

#text("8.In the last three line of Part 5, the heuristics part, the unit of ")#tao-math("\\left|\\nabla\\right|^s u_0", block: false)#text(" of ")#mi("L^{-1-s}")#text(", not ")#mi("L^{1-s}")

#text("If you could reply when you are free, I will be very happy!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-2/#comment-629577")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2021")])]

#text("Thanks for the corrections. ")#mi("O(C_d \\varepsilon_d)")#text(" was a typo, it should have been “at most ")#mi("C_d \\varepsilon_d")#text(".")

#text("The dot notation was defined in Exercise 49.")

#text("I do not think there is an easy way to jump straight to establishing ")#mi("T_* = +\\infty")#text(" in the small data theory without first obtaining estimates on ")#mi("X_T")#text(" and ")#mi("X^s_T")#text(" norms for various ")#mi("T")#text(". In particular one does not know a priori that the ")#mi("X_{T_*}")#text(" or ")#mi("X^s_{T_*}")#text(" norms are finite.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6b375c2b7bf216acdd980108eed6d03d1a720fe95faee715181790274d574ec-ea455139300983443b82df4b4b2c858777dfe4e37a1be96aa98fe5954020f439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ning")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-2/#comment-629613")[#strong[#text("Ning")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2021")])]

#text("Thanks for your reply!")#linebreak()#text(" For your last comment, I think after you showed that")

#text("For {\\varepsilon_d} small enough, this implies that {\\|u\\|_{X_T} \\lesssim_d \\varepsilon_d} for all {T} (this is an example of a “continuity argument”).")

#text("This did not sufficiently show that $u\\in X$ since `all $T$’ here means that all $T<T_*$. Maybe after this, we first show that $T_*=\\infty$ would be a fair way for us to conclude $u\\in X$.")

#emph[#text("[Fair enough, I’ve rearranged the order of these sentences. -T]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6b375c2b7bf216acdd980108eed6d03d1a720fe95faee715181790274d574ec-ea455139300983443b82df4b4b2c858777dfe4e37a1be96aa98fe5954020f439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ning")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-2/#comment-629614")[#strong[#text("Ning")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2021")])]

#text("Before Exercise 34, you said $u \\otimes u$ is a distribution. Here you mean that it is a space-time distribution or a spatial distribution (when $t$ fixed)?")#linebreak()#text(" I think I have verified both by definition, but you did not use the terminology `space-time distribution’ like elsewhere, so I’m wondering what you mean in this context.")

#emph[#text("[Added a clarification that spacetime distributions are intended here. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6b375c2b7bf216acdd980108eed6d03d1a720fe95faee715181790274d574ec-ea455139300983443b82df4b4b2c858777dfe4e37a1be96aa98fe5954020f439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ning")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-2/#comment-629909")[#strong[#text("Ning")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2021")])]

#text("In the last two equations of Note 1,")#linebreak()#text(" You bound")

#tao-math("\\displaystyle N^{2s} (\\sum_{M>N/8} \\left\\| P_{N}( (P_M u) v) \\right\\|_{L^2})^2 \\lesssim_d \tN^{2s} (\\sum_{M>N/8} \\left\\| (P_M u) v \\right\\|_{L^2})^2", block: false)

#tao-math("\\displaystyle \\lesssim_d N^{2s} (\\sum_{M > N/8} \\left\\| P_M u \\right\\|_{L^2} \\left\\| v \\right\\|_{L^\\infty})^2", block: false)

#tao-math("\\displaystyle  \\lesssim_{d,s} \\left\\| v\\right\\|_{L^\\infty}^2 \\sum_{M > N/8} (N/M)^{s} M^{2s} \\left\\| P_M u \\right\\|_{L^2}^2", block: false)

#text("but I think the last inequality is not correct. Maybe we could just using")#linebreak()#text(" ")#tao-math("\\displaystyle N^{2s} (\\sum_{M>N/8} \\left\\| P_{N}( (P_M u) v) \\right\\|_{L^2})^2  \\lesssim_d N^{2s} (\\sum_{M > N/8} \\left\\| P_M u \\right\\|_{L^2} \\left\\| v \\right\\|_{L^\\infty})^2", block: false)#linebreak()#text(" and then summing in N and interchanging summations by the Minkowski’s inequality to get your result.")

#emph[#text("[Seems fine to me (note that ")#mi("\\sum_{M > N/8} (N/M)^{-s} M^{-2s} \\ll_s N^{-2s}")#text("). -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-2/#comment-643416")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2022")])]

#text("Can one use the ")#link("http://www.tricki.org/article/Use_the_continuity_method")[#text(" continuity method ")]#text(" to prove Lemma 1?")

#text("If one begins with")

#mi("\\displaystyle u(t)\\le (1+\\varepsilon)A\\exp(\\int_0^tB(s)\\;ds)")

#text("then one has, by the assumption,")

#mi("\\displaystyle   u(t)\\le A+(1+\\varepsilon)A\\int_0^tB(s)\\exp(\\int_0^sB(s^{\\prime})\\; ds^{\\prime})\\; ds")

#text("which seems not very helpful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-2/#comment-682310")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2023")])]

#text("Hello. I posted my question on MO ")#link("https://mathoverflow.net/questions/458716/hs-mild-solution-for-navier-stokes-why-do-we-restrict-attention-to-the-func?noredirect=1#comment1188330_458716")[#text("https://mathoverflow.net/questions/458716/hs-mild-solution-for-navier-stokes-why-do-we-restrict-attention-to-the-func?noredirect=1#comment1188330_458716")]

#text("But I guess it is more direct to ask here. In your Remarks 33, what do you mean by estimates being “less favorable” for function spaces with the Fourier zeroth mode included?")

#text("I believe that all results and proofs below Definition 32 + Remark 33 (especially local Lipschitz continuity on the initial data) hold “equally valid” even if we do not exclude the Fourier zeroth mode.")

#text("Could you please confirm for me?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-2/#comment-682311")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2023")])]

#text("Proposition 44 breaks down if the ")#mi("k=0")#text(" mode is included (note for instance the negative power of ")#tao-math("\\left|k\\right|", block: false)#text(" at the end of the proof).")

#text("As a general rule of thumb, for local-in-time theory the zero mode is harmless, but for global-in-time theory the zero mode can cause some minor technical difficulties, due to the heat flow not causing that mode to decay exponentially in time (in contrast to all the other modes).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-2/#comment-682312")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2023")])]

#text("The seroth Fourier mode in the NS problem can be harmlessly set to zero because of the Gallien invariance property. Cheers, Dr Hayes")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-2/#comment-688885")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2025")])]

#text("There are some typos in Proposition 22 and its proof:")#linebreak()#text("1. The dimensions are mixed up, the functions are ")#mi("\\mathbb{R}\\to \\mathbb{R}^m")#text(", unlike the previous discussion where they are ")#mi("R^d\\to R")#text(". In the proof eta is ")#mi("\\mathbb{R}^d\\to \\mathbb{R}")#text(", so the integral of their product now makes no sense. I think it should be ")#mi("\\mathbb{R}^d\\to \\mathbb{R}")#text(" and change ")#mi("m")#text(" to ")#mi("d")#text(" in the proof as well.")

#text("2. In the first sentence of the proof, you wrote ")#mi("E_R(t)=0")#text(" (which is the objective of the whole proof). I think you meant ")#mi("E_R(0)=0")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-2/#comment-689053")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2025")])]

#text("Possible typos:")

#text("Section 4, periodicity of p: “a_n(t) = ncdot q(t) for some a…”")

#text("Above Thm 3.1: “… normalised in the sense that q(t) = 0 …”")

#text("In other places you use a(t) instead.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-504915")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("LaTex equations appear to be stretched horizontally throughout the post. (Latest version of Firefox on Windows 10)")

#emph[#text("[I could not reproduce this issue; it may have been a temporary rendering glitch – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1d0c9b6e3d598fc6819a9be70726912eb2945d73e74e961443995e631e7c3e4-e5a143bae28f525b55b430b325d4eaeb879ffbbbaf6aa4f7025a0bb4879843c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joerg Grande")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-504916")[#strong[#text("Joerg Grande")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("In the paragraph introducing the asymptotic notation, there is a typo in the fourth line. The first inequality should be reversed.")

#text("Kind regards, Joerg")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1d0c9b6e3d598fc6819a9be70726912eb2945d73e74e961443995e631e7c3e4-e5a143bae28f525b55b430b325d4eaeb879ffbbbaf6aa4f7025a0bb4879843c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joerg Grande")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-504952")[#strong[#text("Joerg Grande")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2018")])]

#text("In the third line of section 1, the codomain of u should be V, not the reals.")

#text("In the paragraph between Theorem 6 and its proof, the reference to Theorem 7 is off.")

#text("In the formal discussion of the uniqueness properties of Leray systems, there is the phrase “by imposing further properties on F,p,v”. This sounds odd to me; perhaps “constraints” sounds better? (I am not a native English speaker.)")

#text("In the sentence beginning with “If instead we require the vector field”, the space for the gradient of u has a typo.")

#text("Twelve lines above Remark 15, there is a “distirbutional” among the “distributional”s.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-504917")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("Is there any relationship between the well-posedeness for ")#mi("t > 0")#text(" and the assumption that ")#mi("\\nu > 0")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-504970")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2018")])]

#text("The sign of the viscosity ")#mi("\\nu")#text(" can be viewed as an “arrow of time”; positive values of ")#mi("\\nu")#text(" are consistent with the second law of thermodynamics, but negative values are not, unless one applies the time reversal ")#mi("t \\mapsto -t, \\nu \\mapsto -\\nu")#text(". If ")#mi("\\nu<0")#text(", one would thus have a good local well-posedness theory for backwards time evolution, but not for forwards time evolution. (Physically, a negative viscosity fluid would be rather strange – it would somehow be converting thermal energy into increases in the mean velocity of the fluid as time advances, in a manner inconsistent with the second law of thermodynamics.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-504918")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("In exercise 21, “Kowaleski” should be “Kowalevski”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-504939")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("Typos:")

#text("Exer. 17: sapce -> space")#linebreak()#text(" Thm. 44: jf -> if")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8e2147873ad067b7f96df56d2528ad950fb4c86b7166fb29308bb61486bc061-2e360ba77a14fe55fbd7386691cff8b84a8499b54c493517651ca683cc915aeb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vidyasagar Mysoremath")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-504946")[#strong[#text("Vidyasagar Mysoremath")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("Typo in the 5th line regarding d=1 in the definition of Scalar field.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-504947")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("Typo: thrm 44: jf")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-504955")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2018")])]

#text("it seems in this post (as well as some others) that in order to determine the “real” number of dislikes, one needs to subtract one “automatic” dislike ,,,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-504972")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2018")])]

#text("There are a few typos in the proof of Proposition 43: in the third equation it should be t^{-d/2} and in the fourth equation it should be k^{d-2}. Also, how do you get the third equation from Cauchy-Schwarz?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d124007d2de6148d14903db2bb99935bead41cf80c8cc96b55fc4552f34831c-5eeb3eab01bf20cbdfe67ed70c194fe87536a9fd478b9308b79bb68243654663.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-504985")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2018")])]

#text("In the statement of the blow-up criterion in Corollary 40, I think you meant to say “if $T_*$ is finite”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-505011")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("Dear Pro.Tao,")#linebreak()#text(" May I ask you and Nobel prize committee a question?Once you receive Clay millenium prize for Navier-Stokes problem , I think you will have a Nobel prize at the same time.Because Navier-Stokes itself is a physics matter.Is it right?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-505311")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2018")])]

#text("You need global regularity for that one. This lecture deals with local regularity.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-505149")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2018")])]

#text("In theorem 31, there appears to be a gradient missing in the estimate for B (involving $u_2$).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ee9cd996e9a026199313f197ecc1494d1ff85f69513b6162e84297d7002222a-ca7a02841d7c29efac5913b31cf4e883d9542febdd732eb7fd83be37dd3399df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-505289")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2018")])]

#text("Eq (8) only 1 factor of F(s) on R.H.S. ?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351486a77a52672f599fe8fd642ff7fb23c3e1d2a6581ed8632c58257d6279cb-8309edb3032803c6b36a019de5f0f76746a5a56d8e5978686398e53aa37b55e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adiacheng")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-505297")[#strong[#text("adiacheng")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2018")])]

#text("Reblogged this on ")#link("https://adiacheng.wordpress.com/2018/09/25/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("Daily Discovery")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-505312")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2018")])]

#text("Dr prof Tao, any progress on global regularity of Navier Stokes???")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ee9cd996e9a026199313f197ecc1494d1ff85f69513b6162e84297d7002222a-ca7a02841d7c29efac5913b31cf4e883d9542febdd732eb7fd83be37dd3399df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-505331")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2018")])]

#text("In the proof of theorem 8 uniqueness follows from theorem 7: where is theorem 7 ?")

#emph[#text("[Reference corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: Weak solutions of the Navier-Stokes equations | What's new")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-505507")[#strong[#text("254A, Notes 2: Weak solutions of the Navier-Stokes equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")])]

#text("[…] the previous set of notes we developed a theory of “strong” solutions to the Navier-Stokes equations. This […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b1c0877f8b07bd5ab234616528da0cfc48db5055fdaa794a3f6c9db58a9fe72d-13ce79eb6e52b7960f50c39e0e737eec3f61e9609e7b8f5ff38de63153c3d33a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Heinzl")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-505733")[#strong[#text("Tom Heinzl")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2018")])]

#text("Typo in Exercise 18 (a), second identity: dx_i x_j should be x_i x_j")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b1c0877f8b07bd5ab234616528da0cfc48db5055fdaa794a3f6c9db58a9fe72d-13ce79eb6e52b7960f50c39e0e737eec3f61e9609e7b8f5ff38de63153c3d33a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Heinzl")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-505734")[#strong[#text("Tom Heinzl")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2018")])]

#text("…or is the first “d” the dimension – to render the expression traceless?")

#emph[#text("[This ")#mi("d")#text(" is indeed the dimension. -T]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3: Local well-posedness for the Euler equations | What's new")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-505785")[#strong[#text("254A, Notes 3: Local well-posedness for the Euler equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2018")])]

#text("[…] a solution that is an mild solution for all . From the (non-periodic version of) Corollary 40 of Notes 1, we know that for any divergence-free initial data , there is unique maximal Cauchy development , […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea49f2229abec47963f7ff49e48e26bd61730cb078faf078e850551608edd520-1a223f6e69630dc33e7dc6a4904217659283588e46871a0aa55ff5ebc1b47486.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-505957")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2018")])]

#text("In the proof of Theorem 8, uniqueness should follow from Theorem 5?")

#text("Also, in the proof of Theorem 8, the first instance of Theorem 7 should instead be Theorem 6 and I think the second instance of Theorem 7 should be Theorem 5 and the last instance of Theorem 7 should instead be Theorem 6.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b5e8b767c54854c71db2fcfcc5346fb8cbd066ba4e99aee473f1ef4419a3510-6dc981e01a3082a27ac0d4950e1e8cad3dd0ef0be5259ea79f9df5fb886dff7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-506174")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2018")])]

#text("There seems to be a typo at the beginning of Exercise 20, where you write {1< \\theta 0}")

#emph[#text("[Now fixed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b5e8b767c54854c71db2fcfcc5346fb8cbd066ba4e99aee473f1ef4419a3510-6dc981e01a3082a27ac0d4950e1e8cad3dd0ef0be5259ea79f9df5fb886dff7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-506423")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2018")])]

#text("In Exercise 27, should m=1 throughout?")

#emph[#text("[Now corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea49f2229abec47963f7ff49e48e26bd61730cb078faf078e850551608edd520-1a223f6e69630dc33e7dc6a4904217659283588e46871a0aa55ff5ebc1b47486.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-506473")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2018")])]

#text("In (34) and (36), the ")#mi("u(s) \\cdots u(s)")#text(" should be ")#mi("u(s) \\otimes u(s)")#text(". Also in the two big centered equations after (37), I don’t think you use Exercise 29d correct since we should be estimating ")#mi("\\mathbb{P}(u \\otimes u)")#text(" in ")#mi("L^{1}_{t}H^{s}_{x}")#text(" rather than ")#mi("L^{2}_{t}H^{s}_{x}")#text(".")

#emph[#text("[Thanks for the first correction. Regarding the second: we are using the “G” portion of 29d rather than the “F” portion. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ddfdb66f4a959b8a74e6c9cc558c499ef652ebaf456d60cc4478166433cfd00f-f917906bb5e5c012f2f6a42675d8d41576ff37dc8fc5feb959258524b3f6116a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of terryx6")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-506629")[#strong[#text("terryx6")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2018")])]

#text("I can’t understand what you have said，but I really love math.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea49f2229abec47963f7ff49e48e26bd61730cb078faf078e850551608edd520-1a223f6e69630dc33e7dc6a4904217659283588e46871a0aa55ff5ebc1b47486.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-506640")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2018")])]

#text("There is a typo in Equation (44) (in particular u should be in H^s and v in L^infinty) and the third equation in Exercise 52 shouldn’t have a power of N")

#emph[#text("[Actually I think (44) is correct as stated. Exercise 52 has been fixed. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b5e8b767c54854c71db2fcfcc5346fb8cbd066ba4e99aee473f1ef4419a3510-6dc981e01a3082a27ac0d4950e1e8cad3dd0ef0be5259ea79f9df5fb886dff7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-506661")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2018")])]

#text("For Exercise 52a, I believe the expression you give is meant for the nonperiodic setting (i.e. Exercise 54), while another expression is needed to substitute it.")

#emph[#text("[Expression clarified – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e60dea1a38db610fc76922e1c5d775ff3c699e216913e6a1bbd1c8398b7ea40f-b50315f90e0c2176e8d89026a2395947d07dedabd8f56e7f54c8571439f42e2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of matliu")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-507370")[#strong[#text("matliu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2018")])]

#text("In the last line of Exercise 27, ")#mi("G")#text(" should be ")#mi("F")#text(" or ")#mi("F")#text(" is ")#mi("G")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a6be96d0b33334c6a31c2b3bf2f20ef8ce2f7d97e0c701463b95bf4270e9e25-ce514ac0ea720ed87fa8c8930f4a34ce09507f5e810209a52d960dbea35d2d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Venky")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-514063")[#strong[#text("Venky")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2019")])]

#text("The proof of Proposition 44 starts with assuming Exercise 29(d). That exercise uses the norm ")#tao-math("\\left\\| \\nabla u \\right\\|_{L^2_t H^s}", block: false)#text(", whereas Proposition 44 uses ")#tao-math("\\left\\| u \\right\\|_{L^2_t H^{s+1}}", block: false)#text(". It is not clear to me that we can easily infer that ")#tao-math("\\left\\| u \\right\\|_{L^2_t H^{s+1}} \\leq  \\left\\| \\nabla u \\right\\|_{L^2_t H^s}", block: false)#text(" because of the 1 in the Japanese bracket in ")#tao-math("\\left\\| u \\right\\|_{L^2_t H^{s+1}}", block: false)#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-514082")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2019")])]

#text("The inequality ")#tao-math("\\left\\| u \\right\\|_{L^2_t H^{s+1}_x} \\lesssim \\left\\| \\nabla u \\right\\|_{L^2_t H^s_x}", block: false)#text(" holds in the periodic case when ")#mi("u")#text(" has mean zero, which is the case in this situation, because ")#tao-math("\\langle \\xi \\rangle \\sim \\left|\\xi\\right|", block: false)#text(" when ")#mi("\\xi \\in {\\bf Z}^d")#text(" is non-zero.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Twisted convolution and the sensitivity conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-518972")[#strong[#text("Twisted convolution and the sensitivity conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2019")])]

#text("[…] this bound can be easily established from modern Littlewood-Paley theory (see e.g., Exercise 52 of these lecture notes). Here we use an interlacing argument due to Boas. We first restrict to the case when has real […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/616e9f7dce9c0863ea1ffc820e53e3d9a155b1e30548febdd89fd9fb34b0ce4a-8b815786b03fd4de1092f8e0610aae1d9fbef117bcf3fa8456e29ef2edc3a2f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liam Shakib Llamazares Elías")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-562648")[#strong[#text("Liam Shakib Llamazares Elías")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2020")])]

#text("Hello Professor Tao. I greatly appreciate your generosity in sharing your knowledge through this blog.")#linebreak()#text(" I’m a Spanish student doing an undergraduate thesis on the N.S. equations and I had a couple questions regarding exercise 29(d). Firstly the way this exercise is used throughout the text (e.g. in theorem 37) makes me think that ")#mi("\\nabla G")#text(" should be changed to ")#mi("\\nabla\\cdot G")#text(". In consequence the dimensions would have to be changed to ")#mi("F:\\bf{R}^d\\to\\bf{R}^d")#text(", ")#mi("G:\\bf{R}^d\\to\\bf{R}^{d^2}")#text(". Secondly by applying Hölder’s inequality and integrating the negative exponential ")#tao-math("e^{-8\\pi^2\\left|k\\right|^2\\nu t}", block: false)#linebreak()#text(" ")#tao-math("\\left\\|\\nabla\\int_0^te^{\\nu(t-t^{\\prime})\\Delta}\\nabla\\cdot G(s,x)ds\\right\\|_{L_t^2H_x^s}\\leq\\newline", block: false)#linebreak()#text(" ")#tao-math("(constant)\\sum_{k\\in Z^d}\\left|k\\right|^4\\langle k\\rangle^{2s}\\left|k\\right|^{-2}\\nu^{-1}\\int_0^T\\int_0^t\\left|\\hat{G}(s,k)\\right|^2dsdt.", block: false)#linebreak()#text(" Expression which seems to fit more with the norm ")#tao-math("\\left\\|G\\right\\|_{L_t^2H_x^{s+1}}", block: false)#text(" than with your stronger bound of ")#tao-math("\\left\\|G\\right\\|_{L_t^2H_x^s}", block: false)#text(". Would you be able to offer any suggestions in this regard? Many thanks and sorry again for the previously mistyped comments.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-562758")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2020")])]

#text("The ")#mi("H^s")#text(" norm should indeed be an ")#mi("H^{s+1}")#text(" norm, thanks. The bound for ")#mi("\\nabla G")#text(" implies the bound for ")#mi("\\nabla \\cdot G")#text(" because every component of the latter can be written as a bounded linear combination of the former (with the scalar ")#mi("G")#text(" replaced by various components of the tensor ")#mi("G")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f58512a4bf380b9477dd282f85b3f8dc7bf2af9c7e8d21d881ed0f9c8bce114-01ef04b5ef1b58a71fbe0cc8f3b459639a6650f6e3bd441f92d2281551b7dd30.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liam Shakib Llamazares Elías")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-562975")[#strong[#text("Liam Shakib Llamazares Elías")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2020")])]

#text("Thank you very much for your helpful response. I will review the proof of theorem 37 with the new bounds in light of your response. Thanks again.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/616e9f7dce9c0863ea1ffc820e53e3d9a155b1e30548febdd89fd9fb34b0ce4a-8b815786b03fd4de1092f8e0610aae1d9fbef117bcf3fa8456e29ef2edc3a2f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liam Shakib Llamazares Elías")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-563335")[#strong[#text("Liam Shakib Llamazares Elías")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2020")])]

#text("Dear professor. I have looked over the proof of Theorem 37 and have encountered some difficulties in the inequalities immediately after equation (37). Due to the recent change in exercise 29(d) the term ")#linebreak()#text(" ")#tao-math("\\left\\| \\mathbb{P} (u \\otimes u) \\right\\|_{L^2_t H^s_x }", block: false)#text(" would have to be changed to ")#tao-math("\\left\\| \\mathbb{P} (u \\otimes u) \\right\\|_{L^2_t H^{s+1}_x }", block: false)#text(" . By following the reasoning in your text we would now obtain the term $latex \\| u \\|^2_{C^0_t H^{s+1}_x}$ which we do not know to be finite as we only have ")#mi("u\\in C_t^0H_x^s")#text(".")

#text("Nonetheless I have observed that, if we set ")#mi("F=0")#text(" in exercise 29(d), we have that the bound")#linebreak()#text(" ")#tao-math("\\left\\|u\\right\\|_{C_t^0H_x^s}\\lesssim   \\left\\|u_0\\right\\|_{H^s}+\\nu^{-1/2}\\left\\|G\\right\\|_{L^2_tH_x^s}", block: false)#text(" holds. Hence by changing the definition of the space ")#mi("X_T")#text(" to ")#mi("X_T:=C_t^0H_x^s")#text(" with the norm ")#mi("\\|\\|_{X_T}:=\\|\\|_{C^0_tH_x^s}")#text(" we are able to reason as in Theorem 37 to obtain ")#linebreak()#text(" ")#tao-math("\\left\\|u\\right\\|_{X_T}\\lesssim \\left\\|u_0\\right\\|_{H_s}+\\nu^{-1/2}T^{1/2}\\left\\|u\\right\\|^2_{X_T}", block: false)#text(". I have checked the remaining proofs up to corollary 40 with this change and they all seem to hold. Could such a change work? If not, would you be able to suggest any alterations to the proof of Theorem 37? Many thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-563478")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2020")])]

#text("Actually on closer inspection I see that my original formulation of Exercise 29(d) was the correct one (much as it is with Exercise 27), and have reverted the text. (To establish the gradient estimate you will need to use Young’s inequality (or Minkowski’s inequality) at some point.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f58512a4bf380b9477dd282f85b3f8dc7bf2af9c7e8d21d881ed0f9c8bce114-01ef04b5ef1b58a71fbe0cc8f3b459639a6650f6e3bd441f92d2281551b7dd30.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liam Shakib Llamazares Elías")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-563582")[#strong[#text("Liam Shakib Llamazares Elías")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2020")])]

#text("Dear professor Tao. Thank you so much for your generosity and help. Using your hint I indeed managed to verify your bound. Thank again.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-592441")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2020")])]

#text("Hos is the Gronwall inequality applied in exercise 5(a)? A naive attempt gives")

#mi("\\displaystyle v(t)-u(t)\\ge v(0)-u(0)+\\int_0^tF(v(t))-F(u(t))dt")

#text("I don’t follow why it is useful to see ")#mi("\\max(v-u,0)")#text(". Do you mean ")#mi("\\max(u-v,0)")#text(" or ")#mi("\\min(v-u,0)")#text("?")

#text("If one can show that ")#mi("\\max(u-v,0)=0")#text(", then ")#mi("u-v\\le 0")#text(" which implies ")#mi("u\\le v")#text(". Do I misunderstand the hints?")

#emph[#text("[That was a typo, now corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-592687")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2020")])]

#text("One has")#linebreak()#text(" ")#mi("\\displaystyle \\max(u(t)-v(t),0) \\le \\max(u(0)-v(0),0)+\\max(\\int_0^tF(u(s))-F(v(s))ds,0) \\le 0+K\\max(\\int_0^t|u(s)-v(s)|ds,0)")#linebreak()#text(" But does one have")#linebreak()#text(" ")#mi("\\displaystyle \\max(\\int_0^t|u(s)-v(s)|ds,0)\\lesssim \\int_0^t\\max(u(s)-v(s),0)ds\\quad?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-592720")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2020")])]

#text("Run the fundamental theorem of calculus starting from the last time ")#mi("t_0 \\in [0,t]")#text(" at which ")#mi("u(t_0) \\leq v(t_0)")#text(", or ")#mi("t_0=0")#text(" if no such time exists. (Alternatively, compute the weak derivative of ")#mi("\\max(u(t)-v(t),0)")#text(", or the strong derivative of ")#mi("\\max(u(t)-v(t),0)^2")#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-592928")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2020")])]

#text("I’m not sure if I understand your comment.")

#text("So,")#linebreak()#text(" ")#mi("\\displaystyle  u(t)\\le u(t_0)+\\int_{t_0}^tF(u(s))ds")#linebreak()#text(" and")#linebreak()#text(" ")#mi("\\displaystyle  v(t)\\ge v(t_0)+\\int_{t_0}^tF(v(s))ds")#linebreak()#text(" which implies that")#linebreak()#text(" ")#mi("\\displaystyle  u(t)-v(t)\\le u(t_0)-v(t_0)+\\int_{t_0}^tF(u(s))-F(v(s))ds")#linebreak()#text(" which is essentially the same calculation as in the proof of Theorem 3.")

#text("Now, applying the Lipschitz property of ")#mi("F")#text(", one has")#linebreak()#text(" ")#mi("\\displaystyle  u(t)-v(t)\\le u(t_0)-v(t_0)+K\\int_{t_0}^t|u(s)-v(s)|ds")

#text("But if I introduce the ")#mi("\\max")#text(" function I mess things up.")

#text("So the goal is to verify that")#linebreak()#text(" ")#mi("\\displaystyle  \\max(u(t)-v(t),0)\\le \\max(u(t_0)-v(t_0),) +K\\int_{t_0}^t|\\max(u(s)-v(s),0)|ds")

#text("Maybe one can introduce")#linebreak()#text(" ")#mi("\\displaystyle t_1=\\sup\\{t\\ge t_0: u(t)\\le v(t)\\}.")#linebreak()#text(" Is this what “last time” means in your comment? (I am confused with the way you define ")#mi("t_0")#text(" since it is already used in the statement of the exercise.)")

#text("Then one either has ")#mi("u>v")#text(" on ")#mi("(t_1,t_1+\\delta)")#text(" for some small $\\delta>0$ or no such ")#mi("\\delta")#text(" exists. If it exists, then for ")#mi("t\\in(t_1,t_1+\\delta)")#text(", one has ")#mi("\\max(u(t)-v(t),0)=u(t)-v(t)")#text(" and thus")

#mi("\\displaystyle  \\max(u(t)-v(t),0) \\le \\max(u(t_1)-v(t_1),0) +K\\int_{t_1}^{t_1+\\delta}|\\max(u(s)-v(s),0)|ds")

#text("But ")#mi("\\max(u(t_1)-v(t_1),0)\\ne 0")#text(", so one cannot apply Gronwall to get a contradiction…")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-593497")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2020")])]

#text("In the scenario you outline, one necessarily has ")#mi("u(t_1)-v(t_1)=0")#text(" by continuity (or the intermediate value theorem).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-593450")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2020")])]

#text("In section 3, in the formula below (24), what function space should one have when one writes the operator ")#mi("e^{\\nu t\\Delta}")#text("?")

#text("It is clear in the classical sense what ")#mi("\\Delta")#text(" means, but I’m a bit confused with the “unbounded nature” of ")#mi("\\Delta")#text(" since it is unclear what function space one is working on.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-593502")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2020")])]

#text("At this stage the discussion is only formal in nature. The heat propagator ")#mi("e^{\\nu t \\Delta}")#text(" is formally defined later in (26).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-593453")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2020")])]

#emph[#text("From (33) and (22) we thus see that if one defines ")#mi("{p: [0,T] \\times {\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}}")#text(" to be the function")]

#mi("\\displaystyle p := - \\Delta^{-1} (\\nabla \\cdot \\nabla \\cdot (u \\otimes u))")

#text("(which can easily be verified to be a smooth function in both space and time)…")#linebreak()

#text("(22) is given in the “non-periodic setting” while the definition above is in the periodic setting. Assuming that one should understand (22) as the periodic Leray projection, does one have the “distribution” notion in the periodic setting?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-593503")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2020")])]

#text("Distributions can be defined in the periodic setting without difficulty (they are just linear functionals on the space of smooth periodic functions).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-593658")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("In the “function space” introduced in Definition 32 (mild solution), and many other places in general, what “structures” should one have in mind?")

#text("At the minimum, one has a (real) vector space. Does one endow with it any norms? Or in practice, one only specifies various norms that are compatible with this vector space later?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-593687")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("A Banach space structure is ideal, but Frechet spaces can be used in a pinch. Some spaces of distributions are merely topological vector spaces which is a bare minimum of structure in order to define various notions, but typically one wants more structure than this in order to be able to do analysis effectively (e.g., integration of vector-valued functions).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-594829")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2020")])]

#text("In the proof of Theorem 8, what is ")#mi("t_0")#text("? Do you mean ")#mi("t_0=0")#text(" or some arbitrary fixed number in the interval ")#mi("I")#text("?")

#emph[#text("[The latter. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-594830")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2020")])]

#text("In the proof of Theorem 3, what is the advantage of reducing the theorem to the case where ")#mi("t_0=0")#text("? It seems that in the rest of the proof, this fact is never used again and only ")#mi("t_0")#text(" itself is used.")

#emph[#text("[")#mi("t_0")#text(" changed to ")#mi("0")#text(" in later parts of the argument. The main reason to normalise ")#mi("t_0=0")#text(" is to simplify the time reflection symmetry. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-594833")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2020")])]

#text("Typo in")

#emph[#text("For {n} large enough, this and Theorem 7 allow us to extend the solution {u} outside of {I},")]

#text("I think you mean “Theorem ")#strong[#text("6")]#text("“.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-595044")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("In proof of Theorem 8:")

#emph[#linebreak()#text(" … Thus ")#mi("{I}")#text(" is open, and is of the form ")#mi("{I = (T_-, T_+)}")#text(" for some ")#mi("{-\\infty \\leq T_- < 0 < T_+ \\leq +\\infty}")#text(".")#linebreak()#text(" ")]

#text("Do you need to show somewhere that ")#mi("I")#text(" is connected?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-595048")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("OK… ")#mi("I")#text(" is assumed to be the union of all the intervals containing ")#mi("0")#text(". How can one show from the first principles that ")#mi("I")#text(" must be connected?")

#emph[#text("[Look at the supremum of all the right endpoints of ")#mi("I")#text(", and the infimum of all the left endpoints. Alternatively, show that the union of an arbitrary number of connected sets that all contain a common point is connected. -T]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-595046")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("In the proof of Theorem 8,")

#emph[#linebreak()#text(" … For ")#mi("{n}")#text(" large enough, this and Theorem 7 allow us to extend the solution ")#mi("{u}")#text(" outside of ")#mi("{I}")#text(", contradicting the definition of ")#mi("{u}")#text(". Thus we have ")#tao-math("{\\lim_{t \\rightarrow T_+^-} \\left\\|u(t)\\right\\| = \\infty}", block: false)#text(" when ")#mi("{T_+}")#text(" is finite, and a similar argument gives ")#tao-math("{\\lim_{t \\rightarrow T_-^+} \\left\\|u(t)\\right\\| = \\infty}", block: false)#text(" when ")#mi("{T_-}")#text(" is finite.")#linebreak()#text(" ")]

#text("When clicking on “Theorem 7”, it links to the differential inequality (7). Do you mean something else?")

#emph[#text("[Link corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-595097")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("Minor typo in the proof of Theorem 6:")

#emph[#linebreak()#text(" Let ")#mi("{X = C([T,T] \\rightarrow \\overline{B(0,2R)})}")#text(" denote the space of continuous functions…")#linebreak()#text(" ")]

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-595100")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("In the conclusion of Theorem 6, it is said that ")#mi("{u(t) \\in \\overline{B(0,2R)}} for all {t \\in [0,T]}")#text(". What happens to ")#mi("u")#text(" at the negative time ")#mi("t")#text("?")

#text("Can one use the same argument to show that one has ")#mi("{u(t) \\in \\overline{B(0,2R)}} for all {t \\in [-T,T]}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-595164")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("The argument works for both positive and negative ")#mi("t")#text(" (using the signed definite integral ")#mi("\\int_0^{-t} = -\\int_{-t}^0")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-595383")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2020")])]

#text("So one indeed has ")#mi("{u(t) \\in \\overline{B(0,2R)}}")#text(" for all ")#mi("{t \\in [-T,T]}")#text(".")

#text("Does this imply that (4) is time-reversible under the assumptions of Theorem 6? Is the dimension the reason why the heat equation is not time-reversible? (But Remark 7 says that the proof of Theorem 6 carries over to the infinitely dimensional Banach spaces. I’m a bit lost.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-595905")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2020")])]

#text("In the proof of Theorem 8, do we get ")#mi("u_n")#text(" (in the second paragraph) the same way as we get ")#mi("\\tilde{u}")#text(" (in the first paragraph)? Namely by Theorem 6 and the time translation?")

#text("If yes, then writing ")#mi("{\\tilde u(t_0)=u(t_0)}")#text(", instead of ")#mi("{u(t_0) = \\tilde u(t_0)}")#text(" seems to be more natural, and consistent with ")#mi("{u_n(t_n) = u(t_n)}")#text(".")

#emph[#text("[Changed – T.]")]

#text("Also, in the second paragraph, do we take any limiting process for ")#mi("u_n")#text("? Or use only the fact that ")#mi("t_n+T>T_+")#text(" for large ")#mi("n")#text("??")

#emph[#text("[A single choice of ")#mi("n")#text(" with ")#mi("t_n + T > T_+")#text(" will suffice. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-596772")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2020")])]

#text("How much analysis here carry over into the NSE on a bounded domain with some boundary conditions (say Dirichlet)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-596955")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2020")])]

#text("The functional analytic framework largely carries over, but the Fourier transform (and Littlewood-Paley) is not so convenient to use directly. Instead, one has to come to terms with understanding the heat kernel propagators ")#mi("e^{t\\Delta}")#text(" by other means, such as spectral theory. See for instance the text of Constantain and Foias on the Navier-Stokes equations.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-597166")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2020")])]

#text("In the section on the Leray system, could you elaborate on how the Leray projector is defined in the periodic setting? In particular, in the following excerpt, what do you mean by “comparing Fourier coefficients we see that…”? (How does that lead to the extension of the mentioned operators on ")#mi("H^s")#text("?)")

#emph[#linebreak()#text(" From comparing Fourier coefficients we see that the operators ")#mi("{\\Delta^{-1}(\\nabla \\cdot)}")#text(" and ")#mi("{\\nabla \\Delta^{-1} (\\nabla \\cdot)}")#text(" defined for smooth periodic functions can be extended without difficulty to ")#mi("{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}")#text(" (taking values in ")#mi("{H^{s+1}({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}")#text(" and ")#mi("{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow{\\bf R}^d)}")#text(" respectively), with bounds of the form")]

#tao-math("\\displaystyle \\left\\| \\nabla \\Delta^{-1} (\\nabla \\cdot F)\\right\\|_{H^{s}({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)} \\lesssim \\left\\| \\Delta^{-1} (\\nabla \\cdot F)\\right\\|_{H^{s+1}({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R})}", block: false)#linebreak()#text(" ")#tao-math("\\displaystyle \\lesssim \\left\\|F\\right\\|_{H^s({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}.", block: false)#linebreak()
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-597404")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2020")])]

#text("The Leray projector of ")#mi("F")#text(" was defined two paragraphs previously as ")#mi("F - \\nabla \\Delta^{-1}(\\nabla \\cdot F)")#text(". From the definition of ")#mi("\\Delta^{-1}")#text(" we see that the ")#mi("k^{th}")#text(" Fourier coefficient of ")#mi("\\Delta^{-1}(\\nabla \\cdot F)")#text(" is zero when ")#mi("k=0")#text(", and ")#tao-math("\\frac{2\\pi i k}{-4\\pi^2 \\left|k\\right|^2} \\cdot \\hat F(k)", block: false)#text(" otherwise, and similarly for ")#mi("\\nabla \\Delta^{-1}(\\nabla \\cdot F)")#text(", which when combined with the formula for ")#mi("H^s")#text(" Sobolev norms in terms of Fourier coefficients easily leads to the stated claims.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-597199")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2020")])]

#text("In Exercise 26, the norm")

#tao-math("\\displaystyle \\left\\| u \\right\\|_{C^0_t H^s_x([0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^m)} := \\sup_{t \\in [0,+\\infty)} \\left\\| u(t) \\right\\|_{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^m)}", block: false)

#text("was introduced for the Banach space of functions ")#mi("{u: [0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^m}")#text(" such that for each ")#mi("{t}")#text(", ")#mi("{u(t)}")#text(" lies in ")#mi("{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(" and varies continuously and boundedly in ")#mi("{t}")#text(" in the strong topology. This space is also commonly denoted as")#linebreak()#text(" ")#mi("\\displaystyle C^0([0,+\\infty)\\to H^s({\\bf R}^d \\rightarrow {\\bf R}^m))")

#text("On the other hand, in Exercise 27, and similarly various other places, the norm")#linebreak()#text(" ")#tao-math("\\displaystyle \\left\\| F \\right\\|_{L^1_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^m)} := \\int_{[0,T]} \\left\\| F(t) \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^m)}\\ dt", block: false)#linebreak()#text(" was introduced for the space of Schwartz functions. Unlike the case mention above, the space ")#mi("L^\\infty_t L^2_x([0,T] \\times {\\bf R} \\rightarrow {\\bf R}^m)")#text(" is not defined in the notes.")

#text("In PDE literature, people also use Bochner spaces such as ")#mi("L^1([0,T], H^s({\\bf R}^d \\rightarrow {\\bf R}^m))")#text(", whose norm has the exact same form as ")#tao-math("\\left\\| F \\right\\|_{L^1_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^m)}", block: false)#text(".")

#text("The space ")#mi("L^1([0,T], H^s({\\bf R}^d \\rightarrow {\\bf R}^m))")#text(" consists of all “strongly measurable functions” ")#mi("u:[0,T]\\to H^s({\\bf R}^d \\rightarrow {\\bf R}^m)")#text(" for which the norm above is finite.")

#text("Is the notion of Bochner spaces alluded somewhere in the notes? For instance, if one takes the closure of the Schwartz space with respect to the norm ")#tao-math("\\left\\| F \\right\\|_{L^1_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^m)}", block: false)#text(", does one get the Bochner space ")#mi("L^1([0,T], H^s({\\bf R}^d \\rightarrow {\\bf R}^m))")#text("?")

#text("In the section of Leray-Hopf weak solutions in Notes 2, two function spaces are introduced:")

#mi("\\displaystyle  u \\in L^\\infty_t L^2_x( [0,\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^d ); \\quad \\nabla u \\in L^2_t L^2_x([0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^{d^2}), \\ \\ \\ \\ \\ (16)")

#text("It is clear what the norms are for these two spaces, but how do you define the underlying set of these spaces?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-597406")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2020")])]

#text("Yes, the Bochner space is the closure of the Schwartz functions under such norms. For the purposes of these notes one could take this closure as the *definition* of spaces such as ")#mi("L^1_t H^s_x")#text(", as we do not directly use the other properties of Bochner spaces here. Alternatively one can define these spaces as spaces of tempered distributions for which the ")#mi("L^1_t H^s_x")#text(" norm is finite. (Showing the equivalence of these notions requires a certain amount of effort, but again these equivalences are not strictly necessary for the material presented here. There are additional subtleties in the presence of a boundary, in which case the closure of test functions may lead to a strictly smaller space ")#mi("L^1_t (H^s_0)_x")#text(" than the space arising from arbitrary tempered distributions with finite norm depending on the value of ")#mi("s")#text(" (basically depending on whether the Sobolev trace theorem is applicable at this regularity), but these issues are not covered in these notes.)")

#text("In the case of mixed norm Lebesgue spaces ")#mi("L^q_t L^r_x")#text(", these can be defined precisely as in their pure-norm counterparts, namely as equivalence classes of measurable functions for which the ")#mi("L^q_t L^r_x")#text(" norm (which always exists as an element of ")#mi("[0,+\\infty]")#text(") is finite.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-600000")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2020")])]

#text("In Definition 32, what do you mean by “obeys the integral equation (34) (in the sense of distributions)”? Reading through this set of notes, I can’t find a hint to understand that. (One can talk about distributional derivatives, but does one talk about distributional integrals?)")

#emph[#text("[See ")#link("https://en.wikipedia.org/wiki/Pettis_integral")[#text("https://en.wikipedia.org/wiki/Pettis_integral")]#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-600008")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2020")])]

#text("In the proof Theorem 37, you")

#emph[#linebreak()#text(" set ")#tao-math("{T := c_{d,s} \\frac{\\nu}{\\left\\|u_0\\right\\|_{H^s_x({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}^2}}", block: false)#text(" for a sufficienly small constant ")#mi("{c_{d,s} > 0}")#text(" …")#linebreak()#text(" ")]

#text("Should one has ")#mi("\\ll")#text(" instead of ")#mi("\\gg")#text(" in the statement of the theorem?")

#emph[#linebreak()#text(" …")#linebreak()#text(" ")#tao-math("\\displaystyle T \\gg_{d,s} \\frac{\\nu}{\\left\\|u_0\\right\\|_{H^s_x({\\bf R}^d/{\\bf Z}^d \\rightarrow {\\bf R}^d)}^2},", block: false)#linebreak()#text(" ")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-600524")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2020")])]

#text("It is the lower bound which is important (otherwise one could just set ")#mi("T")#text(" to equal zero or something extremely small, and the local well posedness theorem would either be vacuous or significantly less useful).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-603688")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2020")])]

#text("In proof of proposition 35,you say that it suffices to to establish the claim for smooth $latex $,but how to find a smooth function to approximate $latex $?More generally ,how to approximate$latex $ by smooth function?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-614209")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2020")])]

#text("If one works with the ")#mi("2\\pi")#text("-\\periodic 2D NSE:")#linebreak()#text(" ")#mi("\\frac{du}{dt}+\\nu Au+B(u,u)=f,\\quad u(0)=0")#text(" and performs the following two sets of numerical simulations:")

#text("(1) ")#mi("\\nu=10^{-4}")#text(" and some force ")#mi("f")#text(" with ")#tao-math("\\left|f\\right|=25\\times 10^{-4}", block: false)#text("; simulation time ")#mi("t\\in[0,2000]")#text(";")

#text("(2) ")#mi("\\nu=10^{-2}")#text(" and some force ")#mi("f")#text(" with ")#tao-math("\\left|f\\right|=25", block: false)#text("; simulation time ")#mi("t\\in[0,20]")#text(";")

#text("one finds that the ")#tao-math("\\left|u\\right|", block: false)#text("–")#mi("t")#text(" on (where ")#mi("||=\\|\\|_{L^2}")#text(") plots have the same quality (“shape”) for both (1) on ")#mi("[0,2000]")#text(" and (2) on ")#mi("[0,20]")#text(". But on average, ")#tao-math("\\left|u\\right|\\approx 0.015", block: false)#text(" for (1) and ")#tao-math("\\left|u\\right|\\approx 150", block: false)#text(" for (2).")

#text("Can this be explained by some scaling property of the Navier-Stokes equations?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-614244")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2020")])]

#text("If ")#mi("\\nu, f(x), u(t,x)")#text(" obey the forced NSE on a time interval ")#mi("[0,T]")#text(", then so does ")#mi("\\varepsilon \\nu, \\varepsilon^2 f(x), \\varepsilon u(\\varepsilon t, x)")#text(" on ")#mi("[0,T/\\varepsilon]")#text(" for any ")#mi("\\varepsilon>0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/comment-page-1/#comment-614677")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2021")])]

#text("Thanks. Though I think you mean ")#mi("\\varepsilon \\nu, \\varepsilon^2 f(x), \\varepsilon u(\\varepsilon t, x)")#text(" on ")#mi("[0,T/\\varepsilon ]")#text(" for any ")#mi("\\varepsilon>0")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]
