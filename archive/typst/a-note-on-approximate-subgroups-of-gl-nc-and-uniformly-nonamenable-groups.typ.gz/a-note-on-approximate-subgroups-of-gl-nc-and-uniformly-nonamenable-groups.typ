// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/01/15/a-note-on-approximate-subgroups-of-gl_nc-and-uniformly-nonamenable-groups/
// Converted to Typst by tao2typ: "2026-10-14T09:05:59.952243+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A note on approximate subgroups of GL_n(C) and uniformly nonamenable groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A note on approximate subgroups of GL_n(C) and uniformly nonamenable groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 January 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/01/15/a-note-on-approximate-subgroups-of-gl_nc-and-uniformly-nonamenable-groups/")[#text("https://terrytao.wordpress.com/2011/01/15/a-note-on-approximate-subgroups-of-gl_nc-and-uniformly-nonamenable-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#link("http://www.math.u-psud.fr/~breuilla/indexgb.html")[#text("Emmanuel Breuillard")]#text(", ")#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(", and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1101.2552")[#text("A note on approximate subgroups of ")#mi("{GL_n({\\bf C})}")#text(" and uniformly nonamenable groups")]#text("“. In this short note, we obtain a new proof of a “noncommutative Freiman” type theorem in linear groups ")#mi("{GL_n({\\bf C})}")#text(". As discussed ")#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/")[#text("in")]#text(" ")#link("https://terrytao.wordpress.com/2007/03/02/open-question-noncommutative-freiman-theorem/")[#text("earlier")]#text(" ")#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/")[#text("blog")]#text(" ")#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/")[#text("posts")]#text(", a general question in additive (or multiplicative) combinatorics is to understand the structure of ")#emph[#text("approximate groups")]#text(" – subsets ")#mi("{A}")#text(" of genuine groups ")#mi("{G}")#text(" which are a symmetric neighbourhood the identity (thus ")#mi("{id \\in A}")#text(" and ")#mi("{a^{-1} \\in A}")#text(" whenever ")#mi("{a \\in A}")#text("), and such that the product set ")#mi("{A \\cdot A := \\{ ab: a,b \\in A \\}}")#text(" is covered by ")#mi("{K}")#text(" left (or right) translates of ")#mi("{A}")#text(" for some bounded ")#mi("{K}")#text(". (The case ")#mi("{K=1}")#text(" corresponds to the case of a genuine group.) Most of the focus in multiplicative combinatorics has been on the “discrete” case when ")#mi("{A}")#text(" is a finite set, though continuous cases are also of interest (for instance, small balls around the identity in a Lie group are approximate groups).")

#text("In the discrete case, examples of approximate groups include:")

#list(
[#text("Finite groups;")],
[#text("Balls in a discrete abelian group, or more generally a discrete nilpotent group, with boundedly many generators;")],
[#text("Extensions of the latter type of balls by finite groups;")],
[#text("Approximate groups ")#mi("{A}")#text(" that are ")#emph[#text("controlled")]#text(" by one of the previous examples ")#mi("{B}")#text(", in the sense that ")#mi("{A}")#text(" has comparable cardinality to ")#mi("{B}")#text(", and can be covered by boundedly many translates of ")#mi("{B}")#text(".")]
)

#text("It was conjectured independently by Helfgott and Lindenstrauss (private communication) that these are in fact the ")#emph[#text("only")]#text(" examples of finite approximate groups. This conjecture is not yet settled in general (although we, with Tom Sanders, are making progress on this problem that we hope to be able to report on soon). However, many partial results are known. In particular, as part of the ")#link("http://arxiv.org/abs/0909.2190")[#text("recent paper of Hrushovski")]#text(" in which model-theoretic techniques were introduced to study approximate groups, the following result was established:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" If ")#mi("{n=O(1)}")#text(", then every approximate subgroup of ")#mi("{GL_n({\\bf C})}")#text(" is controlled by a nilpotent approximate subgroup.")
]

#text("This result can be compared with Jordan’s theorem (")#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/")[#text("discussed earlier on this blog")]#text(") that every finite subgroup of ")#mi("{GL_n({\\bf C})}")#text(" is virtually abelian (with a uniform bound on the index of the abelian subgroup), or the special case of ")#link("http://en.wikipedia.org/wiki/Gromov%27s_theorem_on_groups_of_polynomial_growth")[#text("Gromov’s theorem")]#text(" for linear groups (which follows easily from the ")#link("http://www.ams.org/mathscinet-getitem?mr=286898")[#text("Tits alternative")]#text(" and the work ")#link("http://www.ams.org/mathscinet-getitem?mr=232311")[#text("of Milnor")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=248688")[#text("of Wolf")]#text(") that every finitely generated subgroup in ")#mi("{GL_n({\\bf C})}")#text(" of polynomial growth is virtually nilpotent.")

#text("Hrushovski’s proof of the above argument was quite sophisticated; one first transplants the problem using model-theoretic techniques to an infinitary setting, in which the approximate group induces a locally compact topological group structure, which can be played off against the Lie group structure of ")#mi("{GL_n({\\bf C})}")#text(" using the machinery of a paper of Larsen and Pink, as discussed in ")#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/")[#text("this previous blog article")]#text(".")

#text("Two further proofs of this theorem were obtained ")#link("https://terrytao.wordpress.com/2010/05/12/approximate-subgroups-of-linear-subgroups/")[#text("by ourselves")]#text(", as well as in the most recent version of a ")#link("http://arxiv.org/abs/1005.1858")[#text("similar preprint by Pyber and Szabo")]#text(". The arguments used here are variants of those used in earlier papers of Helfgott, and are based on establishing expansion of sets that generated Zariski-dense subgroups of various Lie groups (such as ")#mi("{SL_n({\\bf C})}")#text("). Again, the machinery of Larsen and Pink (which controls how such approximate subgroups intersect with algebraic subgroups) plays a central role.")

#text("In this note we give a new proof of this theorem, based primarily on a different tool, namely the ")#link("http://arxiv.org/abs/0804.1395")[#text("uniform Tits alternative")]#text(" of Breuillard. Recall that the ")#link("http://en.wikipedia.org/wiki/Tits_alternative")[#text("Tits alternative")]#text(" asserts that a finitely generated subgroup of ")#mi("{GL_n({\\bf C})}")#text(" is either virtually solvable, or contains a copy of a free group on two generators. In other words, if ")#mi("{A}")#text(" is a finite symmetric neighbourhood of the identity of ")#mi("{GL_n({\\bf C})}")#text(", then either ")#mi("{A}")#text(" generates a virtually solvable subgroup, or else some power ")#mi("{A^m}")#text(" of ")#mi("{A}")#text(" contains two elements ")#mi("{x,y}")#text(" that generate a free group. As stated, ")#mi("{m}")#text(" may depend on ")#mi("{A}")#text(". However, the uniform Tits alternative makes the stronger assertion that one can take ")#mi("{m=m(n)}")#text(" to be uniform in ")#mi("{A}")#text(", and depend only on the dimension parameter ")#mi("{n}")#text(".")

#text("To use this alternative, we have the following simple observation, that asserts that multiplication by two elements that generate a free group forces a small amount of expansion:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" Let ")#mi("{A, B}")#text(" be finite sets, such that ")#mi("{B}")#text(" is symmetric and contains two elements ")#mi("{x,y}")#text(" that generate a free group ")#mi("{F_2}")#text(". Then ")#tao-math("{\\left|A \\cdot B\\right| \\geq 3 \\left|A\\right|}", block: false)#text(".")
]

#text("We remark that this lemma immediately establishes the classical fact that any group that contains a copy of ")#mi("{F_2}")#text(" is not amenable, an observation initially made by von Neumann.")

#emph[#text("Proof:")]#text(" By foliating ")#mi("{A}")#text(" into cosets of ")#mi("{F_2}")#text(" and translating, we may assume without loss of generality that ")#mi("{A \\subset F_2}")#text(". Observe that for every element ")#mi("{a}")#text(" in ")#mi("{A}")#text(", at least three of the four elements ")#mi("{ax, ay, ax^{-1}, ay^{-1}}")#text(" has a longer word length than ")#mi("{a}")#text(", while lying in ")#mi("{A \\cdot X}")#text(". Furthermore, all such elements generated in this fashion are distinct (as one can recover the initial word ")#mi("{a}")#text(" from the longer word by truncation). The claim follows. ")#mi("\\Box")

#text("This can be combined with a ")#link("http://arxiv.org/abs/0912.0306")[#text("lemma of Sanders")]#text(" (also independently established ")#link("http://arxiv.org/abs/1003.2978")[#text("by Croot and Sisask")]#text("), that asserts that for any approximate group ")#mi("{A}")#text(", and any ")#mi("{r=O(1)}")#text(", one can find a smaller version ")#mi("{S}")#text(" of ")#mi("{A}")#text(" – also a symmetric neighbourhood of the identity – with the property that ")#mi("{S^r \\subset A^4}")#text(", while ")#mi("{S}")#text(" remains of comparable size to ")#mi("{A}")#text(". (One should think of ")#mi("{A}")#text(" as being like a ball of some radius ")#mi("{R}")#text(", in which case ")#mi("{S}")#text(" is analogous to a ball of radius ")#mi("{R/r}")#text("). In particular, ")#mi("{A \\cdot S^r \\subset A^5}")#text(" still has size comparable to ")#mi("{A}")#text(". Inspecting the size of the sets ")#mi("{A, A \\cdot S, A \\cdot S^2, \\ldots, A \\cdot S^r}")#text(", we conclude (if ")#mi("{r}")#text(" is large enough) from the above lemma that ")#mi("{S}")#text(" cannot contain two elements that generate a free group. Indeed, a slight modification of this argument shows that for any ")#mi("{m = O(1)}")#text(", if we take ")#mi("{r}")#text(" sufficiently large depending on ")#mi("{m}")#text(", that ")#mi("{S^m}")#text(" does not contain two elements that generate a free group. Applying the uniform Tits alternative, this shows that ")#mi("{S}")#text(" generates a virtually solvable subgroup of ")#mi("{GL_n({\\bf C})}")#text(". From the known product theory for such groups (due ")#link("http://arxiv.org/abs/0907.0927")[#text("to Breuillard and Green")]#text("), ")#mi("{S}")#text(" (and hence ")#mi("{A}")#text(") is therefore controlled by a virtually nilpotent group, as desired.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b011571820b6718929077961d9488c586a1f0fcae56f5e57a8900df997b2d1e-677bbc2d986f2c57c83d8e9472178e4181e584ac0ea030cb09c125237962d08b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MRF")]], [#link("https://terrytao.wordpress.com/2011/01/15/a-note-on-approximate-subgroups-of-gl_nc-and-uniformly-nonamenable-groups/#comment-53379")[#strong[#text("MRF")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2011")])]

#text("Prof. Tao,")

#text("Is it true that if A is a K-approximate group of fixed density d in a finite abelian group then there is a non-zero r such that the Fourier coefficient of 1_A at r has modulus bounded below in terms of d and K only? This seems to be true for all examples I can think of, including sumsets and Bohr sets, and it seems intuitively clear that if only K shifts of A are needed to cover A+A then A cannot be very randomlike.")

#text("In anticipation, thank you for your time.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/01/15/a-note-on-approximate-subgroups-of-gl_nc-and-uniformly-nonamenable-groups/#comment-53381")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2011")])]

#text("Well, first of all the claim as stated is false for d=1 (take A to be the entire group G). But it is probably false in general also. Consider for instance a random subset A of Z/2NZ formed by selecting one element at random from {2n,2n+1} for each n=1,…,N. Then A and A+1 will cover Z/2NZ and will thus certainly cover A+A, on the other hand A will be very Fourier uniform. (This is not a symmetric set, but it is easy enough to modify this construction to make it symmetric and contain the origin.)")

#text("What is true, though, is that if A is dense and Fourier uniform, then A+A will occupy almost all of the group, and A+A+A will occupy all of the group. This is a standard application of Fourier-analytic methods (covered for instance in my book with Van). So one has a dichotomy for dense sets A; either there is a large Fourier coefficient, or A+A and A+A+A are very large.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9dfd506431bdc82b623f4c4c75df1ca02cac8ffe0b080cdb73b83c6058bb838a-b436cbfacd459fdce34b9ba635d8f458b91eb525ecb76f956d24b02556b5db00.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Tointon")]], [#link("https://terrytao.wordpress.com/2011/01/15/a-note-on-approximate-subgroups-of-gl_nc-and-uniformly-nonamenable-groups/#comment-504606")[#strong[#text("Matthew Tointon")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2018")])]

#text("Dear Terry,")#linebreak()#text(" It looks like the constant is missing from the inequality in Lemma 2.")#linebreak()#text(" Best wishes,")#linebreak()#text(" Matt")

#emph[#text("[Corrected, thanks – T.]")]
]
