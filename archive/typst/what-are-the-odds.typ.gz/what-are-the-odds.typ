// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/
// Converted to Typst by tao2typ: "2026-10-14T16:39:03.630392+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "What are the odds?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("What are the odds?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 October 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/")[#text("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("An unusual lottery result made the news recently: on October 1, 2022, the ")#link("https://en.wikipedia.org/wiki/PCSO_Lottery_Draw#Pari-mutuel_games")[#text("PCSO Grand Lotto")]#text(" in the Philippines, which draws six numbers from ")#mi("{1}")#text(" to ")#mi("{55}")#text(" at random, ")#link("https://philnews.ph/2022/10/01/6-55-lotto-result-today-saturday-october-1-2022/")[#text("managed to draw")]#text(" the numbers ")#mi("{9, 18, 27, 36, 45, 54}")#text(" (though the balls were actually drawn in the order ")#mi("{9, 45,36, 27, 18, 54}")#text("). In other words, they drew exactly six multiples of nine from ")#mi("{1}")#text(" to ")#mi("{55}")#text(". In addition, a total of ")#mi("{433}")#text(" tickets were bought with this winning combination, whose owners then had to split the ")#mi("{236}")#text(" million peso jackpot (about ")#mi("{4}")#text(" million USD) among themselves. This raised enough suspicion that there ")#link("https://www.bloomberg.com/news/articles/2022-10-03/lottery-jackpot-with-433-winners-draws-scrutiny-in-philippines")[#text("were calls for an inquiry into the Philippine lottery system")]#text(", including from the minority leader of the Senate.")

#text("Whenever an event like this happens, journalists often contact mathematicians to ask the question: “What are the odds of this happening?”, and in fact I myself received one such inquiry this time around. This is a number that is not too difficult to compute – in this case, the probability of the lottery producing the six numbers ")#mi("{9, 18, 27, 35, 45, 54}")#text(" in some order turn out to be ")#mi("{1}")#text(" in ")#mi("{\\binom{55}{6} = 28,989,675}")#text(" – and such a number is often dutifully provided to such journalists, who in turn report it as some sort of quantitative demonstration of how remarkable the event was.")

#text("But on the previous draw of the same lottery, on September 28, 2022, the unremarkable sequence of numbers ")#mi("{11, 26, 33, 45, 51, 55}")#text(" were drawn (again in a different order), and no tickets ended up claiming the jackpot. The probability of the lottery producing the six numbers ")#mi("{11, 26, 33, 45, 51, 55}")#text(" is ")#emph[#text("also")]#text(" ")#mi("{1}")#text(" in ")#mi("{\\binom{55}{6} = 28,989,675}")#text(" – just as likely or as unlikely as the October 1 numbers ")#mi("{9, 18, 27, 36, 45, 54}")#text(". Indeed, the whole point of drawing the numbers randomly is to make each of the ")#mi("{28,989,675}")#text(" possible outcomes (whether they be “unusual” or “unremarkable”) equally likely. So why is it that the October 1 lottery attracted so much attention, but the September 28 lottery did not?")

#text("Part of the explanation surely lies in the unusually large number (")#mi("{433}")#text(") of lottery winners on October 1, but I will set that aspect of the story aside until the end of this post. The more general points that I want to make with these sorts of situations are:")

#enum(start: 1, 
[#text("The question “what are the odds of happening” is often easy to answer mathematically, but it is ")#emph[#text("not")]#text(" the correct question to ask.")],
[#text("The question “what is the probability that an ")#link("https://en.wikipedia.org/wiki/Null_hypothesis")[#text("alternative hypothesis")]#text(" is the truth” ")#emph[#text("is")]#text(" (one of) the correct questions to ask, but is ")#emph[#text("very difficult")]#text(" to answer (it involves both mathematical and non-mathematical considerations).")],
[#text("The answer to the first question is one of the quantities needed to calculate the answer to the second, but it is far from the only such quantity. Most of the other quantities involved cannot be calculated exactly.")],
[#text("However, by making some educated guesses, one can still sometimes get a very rough gauge of which events are “more surprising” than others, in that they would lead to relatively higher answers to the second question.")]
)

#text("To explain these points it is convenient to adopt the framework of ")#link("https://en.wikipedia.org/wiki/Bayesian_probability")[#text("Bayesian probability")]#text(". In this framework, one imagines that there are competing hypotheses to explain the world, and that one assigns a probability to each such hypothesis representing one’s belief in the truth of that hypothesis. For simplicity, let us assume that there are just two competing hypotheses to be entertained: the ")#link("https://en.wikipedia.org/wiki/Null_hypothesis")[#text("null hypothesis")]#text(" ")#mi("{H_0}")#text(", and an ")#link("https://en.wikipedia.org/wiki/Null_hypothesis")[#text("alternative hypothesis")]#text(" ")#mi("{H_1}")#text(". For instance, in our lottery example, the two hypotheses might be:")

#list(
[#text("Null hypothesis ")#mi("{H_0}")#text(": The lottery is run in a completely fair and random fashion.")],
[#text("Alternative hypothesis ")#mi("{H_1}")#text(": The lottery is rigged by some corrupt officials for their personal gain.")]
)

#text("At any given point in time, a person would have a probability ")#mi("{{\\bf P}(H_0)}")#text(" assigned to the null hypothesis, and a probability ")#mi("{{\\bf P}(H_1)}")#text(" assigned to the alternative hypothesis; in this simplified model where there are only two hypotheses under consideration, these probabilities must add to one, but of course if there were additional hypotheses beyond these two then this would no longer be the case.")

#text("Bayesian probability does not provide a rule for calculating the initial (or ")#emph[#text("prior")]#text(") probabilities ")#mi("{{\\bf P}(H_0)}")#text(", ")#mi("{{\\bf P}(H_1)}")#text(" that one starts with; these may depend on the subjective experiences and biases of the person considering the hypothesis. For instance, one person might have quite a bit of prior faith in the lottery system, and assign the probabilities ")#mi("{{\\bf P}(H_0) = 0.99}")#text(" and ")#mi("{{\\bf P}(H_1) = 0.01}")#text(". Another person might have quite a bit of prior cynicism, and perhaps assign ")#mi("{{\\bf P}(H_0)=0.5}")#text(" and ")#mi("{{\\bf P}(H_1)=0.5}")#text(". One cannot use purely mathematical arguments to determine which of these two people is “correct” (or whether they are both “wrong”); it depends on subjective factors.")

#text("What Bayesian probability ")#emph[#text("does")]#text(" do, however, is provide a rule to ")#emph[#text("update")]#text(" these probabilities ")#mi("{{\\bf P}(H_0)}")#text(", ")#mi("{{\\bf P}(H_1)}")#text(" in view of new information ")#mi("{E}")#text(" to provide ")#emph[#text("posterior")]#text(" probabilities ")#mi("{{\\bf P}(H_0|E)}")#text(", ")#mi("{{\\bf P}(H_1|E)}")#text(". In our example, the new information ")#mi("{E}")#text(" would be the fact that the October 1 lottery numbers were ")#mi("{9, 18, 27, 36, 45, 54}")#text(" (in some order). The update is given by the famous ")#link("https://en.wikipedia.org/wiki/Bayes%27_theorem")[#text("Bayes theorem")]

#align(center)[#tao-fit-display[#mitex("{\\bf P}(H_0|E) = \\frac{{\\bf P}(E|H_0) {\\bf P}(H_0)}{{\\bf P}(E)}; \\quad {\\bf P}(H_1|E) = \\frac{{\\bf P}(E|H_1) {\\bf P}(H_1)}{{\\bf P}(E)},")]]

#text("where ")#mi("{{\\bf P}(E|H_0)}")#text(" is the probability that the event ")#mi("{E}")#text(" would have occurred under the null hypothesis ")#mi("{H_0}")#text(", and ")#mi("{{\\bf P}(E|H_1)}")#text(" is the probability that the event ")#mi("{E}")#text(" would have occurred under the alternative hypothesis ")#mi("{H_1}")#text(". Let us divide the second equation by the first to cancel the ")#mi("{{\\bf P}(E)}")#text(" denominator, and obtain")

#metadata(none) <tao-ca24b438964942905e50>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{ {\\bf P}(H_1|E) }{ {\\bf P}(H_0|E) } = \\frac{ {\\bf P}(H_1) }{ {\\bf P}(H_0) } \\times \\frac{ {\\bf P}(E | H_1)}{{\\bf P}(E | H_0)}.")]]

#text("One can interpret ")#mi("{\\frac{ {\\bf P}(H_1) }{ {\\bf P}(H_0) }}")#text(" as the prior ")#link("https://en.wikipedia.org/wiki/Odds")[#text("odds")]#text(" of the alternative hypothesis, and ")#mi("{\\frac{ {\\bf P}(H_1|E) }{ {\\bf P}(H_0|E) } }")#text(" as the posterior odds of the alternative hypothesis. The identity ")#link(<tao-ca24b438964942905e50>)[#text("(1)")]#text(" then says that in order to compute the posterior odds ")#mi("{\\frac{ {\\bf P}(H_1|E) }{ {\\bf P}(H_0|E) }}")#text(" of the alternative hypothesis in light of the new information ")#mi("{E}")#text(", one needs to know three things:")

#enum(start: 1, 
[#text("The prior odds ")#mi("{\\frac{ {\\bf P}(H_1) }{ {\\bf P}(H_0) }}")#text(" of the alternative hypothesis;")],
[#text("The probability ")#mi("{\\mathop{\\bf P}(E|H_0)}")#text(" that the event ")#mi("{E}")#text(" occurs under the null hypothesis ")#mi("{H_0}")#text("; ")#emph[#text("and")]],
[#text("The probability ")#mi("{\\mathop{\\bf P}(E|H_1)}")#text(" that the event ")#mi("{E}")#text(" occurs under the alternative hypothesis ")#mi("{H_1}")#text(".")]
)

#text("As previously discussed, the prior odds ")#mi("{\\frac{ {\\bf P}(H_1) }{ {\\bf P}(H_0) }}")#text(" of the alternative hypothesis are subjective and vary from person to person; in the example earlier, the person with substantial faith in the lottery may only give prior odds of ")#mi("{\\frac{0.01}{0.99} \\approx 0.01}")#text(" (99 to 1 against) of the alternative hypothesis, whereas the cynic might give odds of ")#mi("{\\frac{0.5}{0.5}=1}")#text(" (even odds). The probability ")#mi("{{\\bf P}(E|H_0)}")#text(" is the quantity that can often be calculated by straightforward mathematics; as discussed before, in this specific example we have")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf P}(E|H_0) = \\frac{1}{\\binom{55}{6}} = \\frac{1}{28,989,675}.")]]

#text("But this still leaves one crucial quantity that is unknown: the probability ")#mi("{{\\bf P}(E|H_1)}")#text(". This is ")#emph[#text("incredibly difficult")]#text(" to compute, because it requires a precise theory for how events would play out under the alternative hypothesis ")#mi("{H_1}")#text(", and in particular is very sensitive as to what the alternative hypothesis ")#mi("{H_1}")#text(" actually ")#emph[#text("is")]#text(".")

#text("For instance, suppose we replace the alternative hypothesis ")#mi("{H_1}")#text(" by the following very specific (and somewhat bizarre) hypothesis:")

#list(
[#text("Alternative hypothesis ")#mi("{H^{\\prime}_1}")#text(": The lottery is rigged by a cult that worships the multiples of ")#mi("{9}")#text(", and views October 1 as their holiest day. On this day, they will manipulate the lottery to only select those balls that are multiples of ")#mi("{9}")#text(".")]
)

#text("Under this alternative hypothesis ")#mi("{H^{\\prime}_1}")#text(", we have ")#mi("{{\\bf P}(E|H^{\\prime}_1)=1}")#text(". So, when ")#mi("{E}")#text(" happens, the odds of this alternative hypothesis ")#mi("{H^{\\prime}_1}")#text(" will increase by the dramatic factor of ")#mi("{\\frac{{\\bf P}(E|H^{\\prime}_1)}{{\\bf P}(E|H_0)} = 28,989,675}")#text(". So, for instance, someone who already was entertaining odds of ")#mi("{\\frac{0.01}{0.99}}")#text(" of this hypothesis ")#mi("{H^{\\prime}_1}")#text(" would now have these odds multiply dramatically to ")#mi("{\\frac{0.01}{0.99} \\times 28,989,675 \\approx 290,000}")#text(", so that the probability of ")#mi("{H^{\\prime}_1}")#text(" would have jumped from a mere ")#mi("{1\\%}")#text(" to a staggering ")#mi("{99.9997\\%}")#text(". This is about as strong a shift in belief as one could imagine. However, this hypothesis ")#mi("{H^{\\prime}_1}")#text(" is so specific and bizarre that one’s prior odds of this hypothesis would be nowhere near as large as ")#mi("{\\frac{0.01}{0.99}}")#text(" (unless substantial prior evidence of this cult and its hold on the lottery system existed, of course). A more realistic prior odds for ")#mi("{H^{\\prime}_1}")#text(" would be something like ")#mi("{\\frac{10^{-10^{10}}}{1-10^{-10^{10}}}}")#text(" – which is so miniscule that even multiplying it by a factor such as ")#mi("{28,989,675}")#text(" barely moves the needle.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" ")#metadata(none) <tao-71cac08484da8e73dac0>#text(" The contrast between alternative hypothesis ")#mi("{H_1}")#text(" and alternative hypothesis ")#mi("{H^{\\prime}_1}")#text(" illustrates a common demagogical rhetorical technique when an advocate is trying to convince an audience of an alternative hypothesis, namely to use suggestive language (“`I’m just asking questions here”) rather than precise statements in order to leave the alternative hypothesis ")#emph[#text("deliberately vague")]#text(". In particular, the advocate may take advantage of the freedom to use a broad formulation of the hypothesis (such as ")#mi("{H_1}")#text(") in order to maximize the audience’s prior odds of the hypothesis, simultaneously with a very specific formulation of the hypothesis (such as ")#mi("{H^{\\prime}_1}")#text(") in order to maximize the probability of the actual event ")#mi("{E}")#text(" occuring under this hypothesis. (A related technique is to be deliberately vague about the hypothesized competency of some suspicious actor, so that this actor could be portrayed as being extraordinarily competent when convenient to do so, while simultaneously being portrayed as extraordinarily incompetent when that instead is the more useful hypothesis.) This can lead to wildly inaccurate Bayesian updates of this vague alternative hypothesis, and so precise formulation of such hypothesis is important if one is to approach a topic from anything remotely resembling a scientific approach. [EDIT: as pointed out to me by a reader, this technique is a Bayesian analogue of the ")#link("https://en.m.wikipedia.org/wiki/Motte-and-bailey_fallacy")[#text("motte and bailey fallacy")]#text(".]")
]

#text("At the opposite extreme, consider instead the following hypothesis:")

#list(
[#text("Alternative hypothesis ")#mi("{H^{\\prime\\prime}_1}")#text(": The lottery is rigged by some corrupt officials, who on October 1 decide to randomly determine the winning numbers in advance, share these numbers with their collaborators, and then manipulate the lottery to choose those numbers that they selected.")]
)

#text("If these corrupt officials are indeed choosing their predetermined winning numbers randomly, then the probability ")#mi("{{\\bf P}(E|H^{\\prime\\prime}_1)}")#text(" would in fact be just the same probability ")#mi("{\\frac{1}{\\binom{55}{6}} = \\frac{1}{28,989,675}}")#text(" as ")#mi("{{\\bf P}(E|H_0)}")#text(", and in this case the seemingly unusual event ")#mi("{E}")#text(" would in fact have ")#emph[#text("no")]#text(" effect on the odds of the alternative hypothesis, because it was just as unlikely for the alternative hypothesis to generate this multiples-of-nine pattern as for the null hypothesis to. In fact, one would imagine that these corrupt officials would ")#emph[#text("avoid")]#text(" “suspicious” numbers, such as the multiples of ")#mi("{9}")#text(", and only choose numbers that ")#emph[#text("look")]#text(" random, in which case ")#mi("{{\\bf P}(E|H^{\\prime\\prime}_1)}")#text(" would in fact be ")#emph[#text("less")]#text(" than ")#mi("{{\\bf P}(E|H_0)}")#text(" and so the event ")#mi("{E}")#text(" would actually ")#emph[#text("lower")]#text(" the odds of the alternative hypothesis in this case. (In fact, one can sometimes use this tendency of fraudsters to not generate truly random data as a statistical tool to detect such fraud; violations of ")#link("https://en.wikipedia.org/wiki/Benford%27s_law")[#text("Benford’s law")]#text(" for instance ")#link("https://en.wikipedia.org/wiki/Benford%27s_law#Accounting_fraud_detection")[#text("can be used in this fashion")]#text(", though only in situations where the null hypothesis is expected to obey Benford’s law, as discussed in ")#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/")[#text("this previous blog post")]#text(".)")

#text("Now let us consider a third alternative hypothesis:")

#list(
[#text("Alternative hypothesis ")#mi("{H^{\\prime\\prime\\prime}_1}")#text(": On October 1, the lottery machine developed a fault and now only selects numbers that exhibit unusual patterns.")]
)

#text("Setting aside the question of precisely what faulty mechanism could induce this sort of effect, it is not clear at all how to compute ")#mi("{{\\bf P}(E|H^{\\prime\\prime\\prime}_1)}")#text(" in this case. Using the ")#link("https://en.wikipedia.org/wiki/Principle_of_indifference")[#text("principle of indifference")]#text(" as a crude rule of thumb, one might expect")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(E|H^{\\prime\\prime\\prime}_1) \\approx \\frac{1}{\\# \\{ \\text{unusual patterns}\\}}")]]

#text("where the denominator is the number of patterns among the possible ")#mi("{\\binom{55}{6}}")#text(" lottery outcomes that are “unusual”. Among such patterns would presumably be the multiples-of-9 pattern ")#mi("{9,18,27,36,45,54}")#text(", but one could easily come up with other patterns that are equally “unusual”, such as consecutive strings such as ")#mi("{11, 12, 13, 14, 15, 16}")#text(", or the first few primes ")#mi("{2, 3, 5, 7, 11, 13}")#text(", or the first few squares ")#mi("{1, 4, 9, 16, 25, 36}")#text(", and so forth. How many such unusual patterns are there? This is too vague a question to answer with any degree of precision, but as one illustrative statistic, the ")#link("https://oeis.org/")[#text("Online Encyclopedia of Integer Sequences (OEIS)")]#text(" currently hosts about ")#mi("{350,000}")#text(" sequences. Not all of these would begin with six distinct numbers from ")#mi("{1}")#text(" to ")#mi("{55}")#text(", and several of these sequences might generate the same set of six numbers, but this does suggests that patterns that one would deem to be “unusual” could number in the thousands, tens of thousands, or more. Using this guess, we would then expect the event ")#mi("{E}")#text(" to boost the odds of this hypothesis ")#mi("{H^{\\prime\\prime\\prime}_1}")#text(" by perhaps a thousandfold or so, which is moderately impressive. But subsequent information can counteract this effect. For instance, on October 3, the same lottery ")#link("https://philnews.ph/2022/10/03/6-55-lotto-result-today-monday-october-3-2022/")[#text("produced the numbers")]#text(" ")#mi("{8, 10, 12, 14, 26, 51}")#text(", which exhibit no unusual properties (no search results in the OEIS, for instance); if we denote this event by ")#mi("{E^{\\prime}}")#text(", then we have ")#mi("{{\\bf P}(E^{\\prime}|H^{\\prime\\prime\\prime}_1) \\approx 0}")#text(" and so this new information ")#mi("{E^{\\prime}}")#text(" should drive the odds for this alternative hypothesis ")#mi("{H^{\\prime\\prime\\prime}_1}")#text(" way down again.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" This example demonstrates another demagogical rhetorical technique that one sometimes sees (particularly in political or other emotionally charged contexts), which is to cherry-pick the information presented to their audience by informing them of events ")#mi("{E}")#text(" which have a relatively high probability of occurring under their alternative hypothesis, but withholding information about other relevant events ")#mi("{E^{\\prime}}")#text(" that have a relatively low probability of occurring under their alternative hypothesis. When confronted with such new information ")#mi("{E^{\\prime}}")#text(", a common defense of a demogogue is to modify the alternative hypothesis ")#mi("{H_1}")#text(" to a more specific hypothesis ")#mi("{H^{\\prime}_1}")#text(" that can “explain” this information ")#mi("{E^{\\prime}}")#text(" (“Oh, clearly we heard about ")#mi("{E^{\\prime}}")#text(" because the conspiracy in fact extends to the additional organizations ")#mi("{X, Y, Z}")#text(" that reported ")#mi("{E^{\\prime}}")#text("“), taking advantage of the vagueness discussed in Remark ")#link(<tao-71cac08484da8e73dac0>)[#text("1")]#text(".")
]

#text("Let us consider a superficially similar hypothesis:")

#list(
[#text("Alternative hypothesis ")#mi("{H^{\\prime\\prime\\prime\\prime}_1}")#text(": On October 1, a divine being decided to send a sign to humanity by placing an unusual pattern in a lottery.")]
)

#text("Here we (literally) stay agnostic on the prior odds of this hypothesis, and do not address the theological question of why a divine being should choose to use the medium of a lottery to send their signs. At first glance, the probability ")#mi("{{\\bf P}(E|H^{\\prime\\prime\\prime\\prime}_1)}")#text(" here should be similar to the probability ")#mi("{{\\bf P}(E|H^{\\prime\\prime\\prime}_1)}")#text(", and so perhaps one could use this event ")#mi("{E}")#text(" to improve the odds of the existence of a divine being by a factor of a thousand or so. But note carefully that the hypothesis ")#mi("{H^{\\prime\\prime\\prime\\prime}_1}")#text(" did not specify ")#emph[#text("which")]#text(" lottery the divine being chose to use. The PSCO Grand Lotto is just ")#link("https://en.wikipedia.org/wiki/PCSO_Lottery_Draw")[#text("one of a dozen lotteries")]#text(" run by the Philippine Charity Sweepstakes Office (PCSO), and of course there are over a hundred other countries and thousands of states within these countries, each of which often run their own lotteries. Taking into account these thousands or tens of thousands of additional lotteries to choose from, the probability ")#mi("{{\\bf P}(E|H^{\\prime\\prime\\prime\\prime}_1)}")#text(" now drops by several orders of magnitude, and is now basically comparable to the probability ")#mi("{{\\bf P}(E|H_0)}")#text(" coming from the null hypothesis. As such one does not expect the event ")#mi("{E}")#text(" to have a significant impact on the odds of the hypothesis ")#mi("{H^{\\prime\\prime\\prime\\prime}_1}")#text(", despite the small-looking nature ")#mi("{\\frac{1}{28,989,675}}")#text(" of the probability ")#mi("{{\\bf P}(E|H_0)}")#text(".")

#text("In summary, we have failed to locate any alternative hypothesis ")#mi("{H_1}")#text(" which")

#enum(start: 1, 
[#text("Has some non-negligible prior odds of being true (and in particular is not excessively specific, as with hypothesis ")#mi("{H^{\\prime}_1}")#text(");")],
[#text("Has a significantly higher probability of producing the specific event ")#mi("{E}")#text(" than the null hypothesis; AND")],
[#text("Does not struggle to also produce other events ")#mi("{E^{\\prime}}")#text(" that have since been observed.")]
)

#text("One needs all three of these factors to be present in order to significantly weaken the plausibility of the null hypothesis ")#mi("{H_0}")#text("; in the absence of these three factors, a moderately small numerical value of ")#mi("{{\\bf P}(E|H_0)}")#text(", such as ")#mi("{\\frac{1}{28,989,675}}")#text(" does not actually do much to affect this plausibility. In this case one needs to lay out a reasonably precise alternative hypothesis ")#mi("{H_1}")#text(" and make some actual educated guesses towards the competing probability ")#mi("{{\\bf P}(E|H_1)}")#text(" before one can lead to further conclusions. However, if ")#mi("{{\\bf P}(E|H_0)}")#text(" is ")#emph[#text("insanely")]#text(" small, e.g., less than ")#mi("{10^{-1000}}")#text(", then the possibility of a previously overlooked alternative hypothesis ")#mi("{H_1}")#text(" becomes far more plausible; as per the famous quote of Arthur Conan Doyle’s Sherlock Holmes, “When you have eliminated all which is impossible, then whatever remains, however improbable, must be the truth.”")

#text("We now return to the fact that for this specific October 1 lottery, there were ")#mi("{433}")#text(" tickets that managed to select the winning numbers. Let us call this event ")#mi("{F}")#text(". In view of this additional information, we should now consider the ratio of the probabilities ")#mi("{{\\bf P}(E \\& F|H_1)}")#text(" and ")#mi("{{\\bf P}(E \\& F|H_0)}")#text(", rather than the ratio of the probabilities ")#mi("{{\\bf P}(E|H_1)}")#text(" and ")#mi("{{\\bf P}(E|H_0)}")#text(". If we augment the null hypothesis to")

#list(
[#text("Null hypothesis ")#mi("{H^{\\prime}_0}")#text(": The lottery is run in a completely fair and random fashion, and the purchasers of lottery tickets also select their numbers in a completely random fashion.")]
)

#text("Then ")#mi("{{\\bf P}(E \\& F|H^{\\prime}_0)}")#text(" is indeed of the “insanely improbable” category mentioned previously. I was not able to get official numbers on how many tickets are purchased per lottery, but let us say for sake of argument that it is 1 million (the conclusion will not be extremely sensitive to this choice). Then the expected number of tickets that would have the winning numbers would be")

#align(center)[#tao-fit-display[#mitex("\\frac{1 \\text{ million}}{28,989,675} \\approx 0.03")]]

#text("(which is broadly consistent, by the way, with the jackpot being ")#link("https://www.lottopcso.com/6-55-lotto-result-history-and-summary/")[#text("reached every ")#mi("{30}")#text(" draws or so")]#text("), and standard probability theory suggests that the number of winners should now follow a ")#link("https://en.wikipedia.org/wiki/Poisson_distribution")[#text("Poisson distribution")]#text(" with this mean ")#mi("{\\lambda = 0.03}")#text(". The probability of obtaining ")#mi("{433}")#text(" winners would now be")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(F|H^{\\prime}_0) = \\frac{\\lambda^{433} e^{-\\lambda}}{433!} \\approx 10^{-1600}")]]

#text("and of course ")#mi("{{\\bf P}(E \\& F|H^{\\prime}_0)}")#text(" would be even smaller than this. So this clearly demands some sort of explanation. But in actuality, many purchasers of lottery tickets do not select their numbers completely randomly; they often have some “lucky” numbers (e.g., based on birthdays or other personally significant dates) that they prefer to use, or choose numbers according to a simple pattern rather than go to the trouble of trying to make them truly random. So if we modify the null hypothesis to")

#list(
[#text("Null hypothesis ")#mi("{H^{\\prime\\prime}_0}")#text(": The lottery is run in a completely fair and random fashion, but a significant fraction of the purchasers of lottery tickets only select “unusual” numbers.")]
)

#text("then it can now become quite plausible that a highly unusual set of numbers such as ")#mi("{9,18,27,36,45,54}")#text(" could be selected by as many as ")#mi("{433}")#text(" purchasers of tickets; for instance, if ")#mi("{10\\%}")#text(" of the 1 million ticket holders chose to select their numbers according to some sort of pattern, then only ")#mi("{0.4\\%}")#text(" of those holders would have to pick ")#mi("{9,18,27,36,45,54}")#text(" in order for the event ")#mi("{F}")#text(" to hold (given ")#mi("{E}")#text("), and this is not extremely implausible. Given that this reasonable version of the null hypothesis already gives a plausible explanation for ")#mi("{F}")#text(", there does not seem to be a pressing need to locate an alternate hypothesis ")#mi("{H_1}")#text(" that gives some other explanation (cf. ")#link("https://en.wikipedia.org/wiki/Occam%27s_razor")[#text("Occam’s razor")]#text("). [UPDATE: Indeed, given ")#link("https://www.facebook.com/PCSO-GrandLotto-655-1-42-Tickets-1649214508638738/photos/1655400654686790")[#text("the actual layout")]#text(" of the tickets of ths lottery, the numbers ")#mi("{9,18,27,35,45,54}")#text(" form a diagonal, and so all that is needed in order for the modified null hypothesis ")#mi("{H^{\\prime\\prime}_0}")#text(" to explain the event ")#mi("{F}")#text(" is to postulate that a significant fraction of ticket purchasers decided to lay out their numbers in a simple geometric pattern, such as a row or diagonal.]")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" In view of the above discussion, one can propose a systematic way to evaluate (in as objective a fashion as possible) rhetorical claims in which an advocate is presenting evidence to support some alternative hypothesis:")

#enum(start: 1, 
[#text("State the null hypothesis ")#mi("{H_0}")#text(" and the alternative hypothesis ")#mi("{H_1}")#text(" as precisely as possible. In particular, avoid conflating an extremely broad hypothesis (such as the hypothesis ")#mi("{H_1}")#text(" in our running example) with an extremely specific one (such as ")#mi("{H^{\\prime}_1}")#text(" in our example).")],
[#text("With the hypotheses precisely stated, give an honest estimate to the prior odds of this formulation of the alternative hypothesis.")],
[#text("Consider if all the relevant information ")#mi("{E}")#text(" (or at least a representative sample thereof) has been presented to you before proceeding further. If not, consider gathering more information ")#mi("{E^{\\prime}}")#text(" from further sources.")],
[#text("Estimate how likely the information ")#mi("{E}")#text(" was to have occurred under the null hypothesis.")],
[#text("Estimate how likely the information ")#mi("{E}")#text(" was to have occurred under the alternative hypothesis (using exactly the same wording of this hypothesis as you did in previous steps).")],
[#text("If the second estimate is significantly larger than the first, then you have cause to update your prior odds of this hypothesis (though if those prior odds were already vanishingly unlikely, this may not move the needle significantly). If not, the argument is unconvincing and no significant adjustment to the odds (except perhaps in a downwards direction) needs to be made.")]
)
]

#heading(level: 1)[#text("Comments (62)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658390")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2022")])]

#text("yesterday，I have received a paper from a CRRC Lab，the datum on the sheet show a group of number：28，44，46…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43fc9b908ce5068ca05032b931a39e35c364a611c52741b287f2a89aa8c0c3f-e99ac61b40b88e7dff88ff3fc721bd7040f4c729f5e9cb9fa13e731c524126c3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of macbi")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658392")[#strong[#text("macbi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2022")])]

#text("If you wanted to measure how much of an ‘unusual pattern’ a set of number had, one way to do it would be to look at the number of people who bought that ticket. The fact that 433 people bought ‘9, 18, 27, 36, 45, 54’ suggests that it is quite a salient pattern. I bet even more people buy ‘1, 2, 3, 4, 5, 6’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e3e10bf471189e7b9dad6311a00d8fee59d8448088d8a3657a7f76c94b1a631-27f7cd9fcb250764352c0d8d528545e2842fac20761c2b83ede82b451d866cb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bernhard Haak")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658394")[#strong[#text("Bernhard Haak")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("When “strange things” happen I first look for a trivial solution. In particular, the geometry of the lottery tickets seems important. It is plausible that 55 numbers are set up in a 7 x 8 matrix pattern, with one wildcard (to produce 56 objects). Imagine that it is done as such:")

#text("*, 1, 2, .. , 7")#linebreak()#text(" 8, 9, 10, .., 15")#linebreak()#text(" 16, 17, 18, …, 23")#linebreak()#text(" 24, 25, 26, 27,..31")#linebreak()#text(" ..")#linebreak()#text(" then multiples of 9 are the main diagonal. That would explain frequency in an easy way.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658406")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("No need to guess what the tickets look like; you can see one at ")#link("https://lottotips888.blogspot.com/p/grand-lotto-655.html")[#text("https://lottotips888.blogspot.com/p/grand-lotto-655.html")]#text(" . As you can see, the multiples of 9 are on an antidiagonal, although not in the way Bernard guessed.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658395")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("so cool, thanks Terry for a detailed explanation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658492")[#strong[#text("Jeremy")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2022")])]

#text("The assumption that most bettors have “lucky” numbers is correct. Everytime the jackpots reach hundreds of millions, news outlets would interview people on the street. Clips are available in youtube (in Filipino), and almost everyone will say they have favorite numbers that they’re ‘taking care of’ (lit. translation), may it be children’s birthdays, dates of marriages, memorable dreams or whatever eventful numbers. Filipinos are a religious and superstitious bunch, and they will keep betting with these numbers until they win any kind of prize. The lotto ticket isn’t a word search game where people will choose based on patterns they’re seeing.")

#text("Another thing to note is that corrupt officials here aren’t really trying to be subtle. Audits on almost all government agencies (except for the previous Vice Presidential Office) showed blatant corruption such as inflated prices, fake companies, forged signatures and whatnot but almost no one goes to jail as long you have friends who are politicians. Heck, convicted plunderers (pres. Estrada), human rights violators (pres. Duterte), and uneducated tax evaders (pres. Marcos jr.) are super popular! It’s easy to assume that the numbers were rigged without care of being found out.")

#text("Lastly, anyone can claim a ticket even if it isn’t theirs as long as they have an id that matches the signature on the ticket. Anyone can own the tickets. It’s possible a single entity can own them all by proxy. One guy even claimed 2 tickets. The latest winner interview showed a woman who was claiming a ticket for her uncle but can’t show any id. And all of the winning tickets revealed so far were bet either on the same draw date or the day before. Given that you could bet for up to 6 draws in advance, what are the chances that all winners so far only bet on a single draw?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-660156")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2022")])]

#text("Probability is pretty hard. I think we’re pretty lucky we are stupid enough to not tell the future most of the time. After all, what meaning would be left in life, especially if you can’t change the outcome in the end?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luisa")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658396")[#strong[#text("Luisa")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("well，I don’t think the real world is as simple as the pure mathmetic world/the intelligible world/νοητόν…")#linebreak()#text(" Several reasons are as follow：")#linebreak()#text(" 1.The basic philosophic structure of the Occam’s razor is not as firm as we may thought，I have tried to deconstruct it several years ago…")#linebreak()#text(" 2.As we all know，the Conditional Hypothesis，is only a mode of evaluation to the affair or the series，but cannot instead of the affair itself…and from a very basical philosophy principle，we easily know that，")#linebreak()#text(" （a）all the evaluations are unbelievable，from form to content；")#linebreak()#text(" （b）when we make an evaluation to sth. we always have an premise which always contains a Prosets-plane and a value-axis，and from this we can easily derive （a）.")#linebreak()#text(" 3.THE LOGIC FIRST！We should think of the information from all aspects but we cannot， because of the deep paradox of the number of variables and the effectiveness / degree of the complexity. So I think we’d better think of the logic method first，to take a Field Investigation first…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f4668efe0fba6f7f31317358f67a367d30f8eb117d6b50a6e7757d843643d02-a7b3f2838f6ab871c8c95f3de9d1631c3b399ca28105bfdf6404b935d464abfa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan Pang")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658397")[#strong[#text("Ryan Pang")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("One small typo: In view of this additional information, we should now consider the ratio of the probabilities {{\\bf P}(E \\& F|H_1)} and {{\\bf P}(E \\& F|H_0)}, rather than the ratio of {{\\bf P}(E|H_1)} and {{\\bf P}(H_0)} (instead of the expected values)")

#emph[#text("[Corrected, thanks – T.]")]

#text("One way of looking at this is that the sequence 9,18,27,36,45,54 has a higher Kolmogorov complexity than most sequences.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658401")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("This wiining sequence is considered unusual because it seems “highly deterministic” (having a very low algorithmic complexity) – which may explain the large number of winners.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f4668efe0fba6f7f31317358f67a367d30f8eb117d6b50a6e7757d843643d02-a7b3f2838f6ab871c8c95f3de9d1631c3b399ca28105bfdf6404b935d464abfa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan Pang")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658403")[#strong[#text("Ryan Pang")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("Typo: *lower Kolmogorov complexity than most sequences")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658407")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("We can form a pretty decent estimate of the number of tickets sold from publicly available facts. The cost of a 6/55 ticket is 24 PHP (source ")#link("https://www.buylottoticket.com/philippines-grand-lotto-655")[#text("https://www.buylottoticket.com/philippines-grand-lotto-655")]#text(" ). The prize was 236 million PHP. Several sources (eg ")#link("https://www.philstar.com/headlines/2019/07/29/1938904/where-do-pcso-revenues-go")[#text("https://www.philstar.com/headlines/2019/07/29/1938904/where-do-pcso-revenues-go")]#text(" ) state that 55% of revenues are returned in prizes. So, as a rough estimate, the revenue yielding that 236 million jackpot should be about 430 million, which should mean about 18 million tickets sold. I wouldn’t take that too seriously, because (1) I can’t find out if the 55% is from gross receipts or after deducting operating expenses and (2) it might be a rollover jackpot combining several weeks of sales. But I would guess 10 million is closer than 1 million.")

#text("I’ll post my analysis below this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658408")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("The plausible alternate hypothesis seems to me to be “someone rigged the lottery to benefit themselves or a friend, and the beneficiaries preferred numbers were the multiples of 9”. As Bernard Haak says, the most likely reason that this beneficiary liked the multiples of 8 would be that they were arranged in a diagonal on the lotto card, but we know already that multiples of 9 are a highly popular choice (there were 433 winners) so we don’t have to care why they are popular.")

#text("So, the two hypotheses we want to compare are H0: The output is chosen at random and H1 the output is chosen by picking a random lotto player and rigging the lotto to return their favorite numbers.")

#text("The probability of the observed outcome given H0 is about 1/(29 million). The probability of the observed outcome given H1 is 433/(number of players). For reasons I sketched above, I think the number of players is probably closer to 10 million than 1 million. So my estimate for H1 is 400/(10 million), or about 1/(25 thousand). So my odds ratio is (1/29 million)/(1/25 thousand) or about 1/1000. That seems suspicious to me!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658409")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("Arguably, you should condition on the fact that someone won. In that case, the denominator stays the same and the numerator changes to 1/(number of distinct numbers played), which is probably very close to 1/(number of players). Then the odds ratio simplifies to (1/(number of players))/(433/(number of players)) = 1/433 or about 2.5/1000. I still think it is suspicious.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658412")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("This is a fairly reasonable analysis, although I would point out that (a) your proposed alternative hypothesis ")#mi("H_1")#text(" implicitly includes the assumption that the lottery rigger has managed to achieve perfect control on the lottery machine, which would drive down the prior odds of this hypothesis to well under 1 in 433, and (b) if the conspirators here had any sense, then they would avoid rigging the lottery to produce numbers which would immediately arouse suspicion (but this could perhaps be resolved by ")#link("https://en.wikipedia.org/wiki/Hanlon%27s_razor")[#text("Hanlon’s razor")]#text(", i.e., by adding some incompetence to the alternative hypothesis, though this somewhat conflicts with (a)).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658542")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2022")])]

#text("The incompetence would have to be pretty thoroughgoing. They’d have to be clueless not only about the choice of a prominent winning pattern raising the suspicion level (as you point out), but *also* about that choice almost certainly diluting each conspirator’s reward by a significant factor (this dilution could of course be mitigated by each conspirator buying multiple winning tickets, but that would raise the suspicion level even higher).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658717")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2022")])]

#text("I guess I should say that, by suspicious, I don’t mean “definitely happened”, I mean “likely enough that it seems to me worth investigating whether any of the 433 winners has a plausible connection with someone who had the ability to do this.”")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658411")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("I guess 10 million could be plausible. I initially doubted this because one would then naively expect the lottery to be paid out about ")#mi("1 - (1 - 1 / 28,989,765)^{10,000,000} \\approx 42\\%")#text(" of the time, which is significantly higher than empirically observed, but as we have seen, the lottery numbers seem to be rather highly concentrated in “unusual” patterns, thus reducing the probability that the jackpot will actually be claimed (while also increasing the expected number of claimants for that jackpot when it does occur).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658413")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("That’s a good argument against my number. Where did you find the frequency of payouts? That would be useful in estimating the number of distinct numbers sold, which is also useful information.")

#text("As a point in my favor, the population of the Phillipines is 100 million, and a number of websites describe the lottery as very popular, which sounds more like 10% of the population than 1%.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658422")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("I inferred the frequency of payouts from the number of times the jackpot reset in ")#link("https://www.lottopcso.com/6-55-lotto-result-history-and-summary/")[#text("https://www.lottopcso.com/6-55-lotto-result-history-and-summary/")]

#text("While the PSCO lotteries are indeed very popular, the 6/55 Grand lotto described here is just one of about a dozen lotteries that PSCO runs (see ")#link("https://en.wikipedia.org/wiki/PCSO_Lottery_Draw#The_Games")[#text("https://en.wikipedia.org/wiki/PCSO_Lottery_Draw#The_Games")]#text(" for a list), so perhaps what is going on in is that there are roughly 10 million ticket purchasers overall, but for the specific 6/55 lottery the number of tickets may be closer to 1 million.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658426")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("Ah, I think you are right then. That $240 million jackpot built up for a long time.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ba53734eb789e03c804f6c95ba48c1c5cd85dcbc873e59f458c97b20f6acfa52-35d1864444331ffb86730613224976c4c995607fe2bec04b07e0dd6597ffe936.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cjquines")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658500")[#strong[#text("cjquines")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2022")])]

#text("my feeling is that the 6/55 isnt nearly as popular as the other lottery formats, from what ive observed in convenience stores")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/245a27f3a461760e6311211106253be6e0293e534bff6f51f965d3bd3d0637e9-96e99a9fe9f43c8d6e868c6c3123ee36868b355ed796af022da8117a2d1fe1a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658418")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("Binary hypothesis testing, as considered here, is the right approach when one has a good mathematical model for likelihoods of observations under both the null and alternate hypotheses (e.g., detecting a +/- 1 binary signal corrupted by additive noise). This binary testing approach runs into difficulties in situations like the one described, since we have a good model for the null hypothesis (the numbers were drawn uniformly at random), but lack a model for the alternate hypothesis.")

#text("In such situations, it is often preferable to perform null-hypothesis significance testing to compute the “significance” of an observation under the null hypothesis (i.e., a p-value), and then accept or reject the null hypothesis on this basis, without need of an alternate hypothesis. The lotto problem here is arguably a textbook example of the multiple comparisons problem, where we can control things like false discovery rate. Indeed, the lotto agency should have knowledge of the distributions of numbers sold for each game, and can therefore accurately model the number of winners under the null hypothesis (fair drawing of numbers, independent across different drawings). Armed with this, the number of winners for each drawing can be assigned a p-value, and these can be thresholded to accept or reject the null hypothesis for each drawing (subject to control on FDR, FWER, etc.). No formulation of an alternate hypothesis is necessary.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658423")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("I am somewhat wary of excessive reliance on p-values due to the temptation to perform “")#link("https://en.wikipedia.org/wiki/Data_dredging")[#text("p-hacking")]#text("“, but it can be a useful tool in those cases where one can linearly order the observed statistic in some canonical fashion so that one can create a well-defined tail event with which to calculate a p-value. In particular “number of winners” is such a linearly ordered statistic that one can then threshold. On the other hand “unusual nature of winning numbers” does not have an obvious linear ordering with which to perform a p-value: is it the case for instance that the sequence 9, 18, 27, 36, 45, 54 is in the “top 1%” of unusual patterns? “top 0.1%”? etc.. So I don’t see a clear way to use p-values to gain any understanding of these sorts of events – it requires answering the question “what proportion of possible sequences are at least as unusual as 9,18,26,76,45,54?”, which does not seem to have a definitive answer.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/245a27f3a461760e6311211106253be6e0293e534bff6f51f965d3bd3d0637e9-96e99a9fe9f43c8d6e868c6c3123ee36868b355ed796af022da8117a2d1fe1a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658427")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("Of course p-values can be abused, but my point is simply that by focusing on accepting/rejecting the null hypothesis alone (which is straightforward to model in this case), we are relieved of more speculative tasks like quantifying what it means for a winning sequence to be “unusual”, or determining a precise model for corrupt officials. These latter questions are somewhat tangential to the problem of deciding whether the observations are consistent with a fairly-executed lotto (given knowledge of how many tickets were sold for each sequence of numbers in each game).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c178ba988fe8b7652fe2cfa7fb096700dc3d0910064663771996c86eb02c9d3-0b6815b40bdffd5a97b51e7ba037f120758ea9a471a2872687d4c13680f3cfcf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ilya M.")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658430")[#strong[#text("Ilya M.")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("> On the other hand “unusual nature of winning numbers” does not have an obvious linear ordering with which to perform a p-value: is it the case for instance that the sequence 9, 18, 27, 36, 45, 54 is in the “top 1%” of unusual patterns? “top 0.1%”? etc..")

#text("I find the problem of “Philippines lottery” fascinating because, in this instance, we have a good definition of a sequence’s “weirdness” (from a culture-bound perspective). Namely, it is the number of times it was played in one particular round and/or across some period of time. Of course, this information is available only to the PSCO, but they do have the means of estimating the rank of the sequence in the minds of the playing public.")

#text("In contrast, the Kolmogorov complexity that is often brought up in this context suffers from two (fatal) flaws. First, computing the _exact_ Kolmogorov complexity is undecidable, and the notion itself is defined up to a constant (due to arbitrariness of the encoding).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ebbb51a9e7619a73d325d878d35b79fdb271ffd4af2c3579293eead8782f114-03433e0c48ff977b956abf28f98b05bcb64a754b225fbb1c88e36997f99c01d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Wetterau")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658503")[#strong[#text("James Wetterau")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2022")])]

#text("As someone else observed, any combination that is purchased several times is a good candidate for treating as an unusual pattern, and how unusual it is might be based on how many times it was bought. It is possible that numbers that somehow encode significant dates, sports players’ numbers, words, or other real world phenomena might be popular, as well as sequences such as those from OEIS or arithmetic. Perhaps an estimate of how many of these there are and how unusual they are is best addressed as an empirical question: examining all the tickets sold recently (perhaps over years) which are the actually popular number groups, and how unusually popular is 9, 18, 27, 36, 45, 54?")#linebreak()#text(" One piece of evidence would be if 9, 18, 27, 36, 45, 54 only became so popular this time — that would imply the fix was in and the news leaked.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658424")[#strong[#text("Lots of odds – The nth Root")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")]

#text("[…] An unusual lottery result made the news recently: on October 1, 2022, the PCSO Grand Lotto in the Philippines, which draws six numbers from {1} to {55} at random, managed to draw the numbers {9, 18, 27, 36, 45, 54} (though the balls were actually drawn in the order {9, 45,36, 27, 18, 54}). In other words, they drew exactly six multiples of nine from {1} to {55}. In addition, a total of {433} tickets were bought with this winning combination, whose owners then had to split the {236} million peso jackpot (about {4} million USD) among themselves. This raised enough suspicion that there were calls for an inquiry into the Philippine lottery system, including from the minority leader of the Senate…. (Terence Tao) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a3223d5065cc9e0fafdabf91531e3d44b3a0880e75d1b8cbbb6cb2126accaac-b878bf22599f1343c93d68b63b41636fe65a81430f9a6467bdfc12c2eaf430d8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nordin Pumbaya")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658464")[#strong[#text("Nordin Pumbaya")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2022")])]

#text("There is another twist to this lotto story. Some sources mentioned that one winner actually had two tickets both containing the winning combination! Doesn’t that shift the argument in favor of artificial manipulation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658484")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2022")])]

#text("As discussed in the post, in order for a new piece of information ")#mi("F")#text(" to shift one’s belief towards an alternative hypothesis, one needs to propose a plausible and specific alternative hypothesis ")#mi("H_1")#text(" for which the likelihood ")#mi("{\\bf P}(F|H_1)")#text(" of ")#mi("F")#text(" occurring is significantly higher than the likelihood ")#mi("{\\bf P}(F|H_0)")#text(" under the null hypothesis ")#mi("H_0")#text(".")

#text("Under the null hypothesis (in the form ")#mi("H^{\\prime\\prime}_0")#text("), the following two statements are, I think, not controversial: (a) A non-negligible fraction of ticket purchasers will buy two or more tickets. (b) Some fraction of ticket purchasers will not devote significant thought into selecting their numbers, and simply choose numbers according to some pattern (such as the diagonal pattern on the lottery ticket that generated the 9-18-27-36-45-54 sequence). Given (a) and (b), it is not implausible to me that an even smaller but non-zero fraction of ticket purchasers would purchase multiple tickets and mark them all with the same pattern. Mathematically, this is not a good strategy – it increases the chance that any jackpot that you do win would be split among either yourself or other winners – but lottery ticket purchasers, as a group, are not exactly renowned for their mathematically optimal strategizing.")

#text("In contrast, it is not clear what plausible alternative hypothesis ")#mi("H_1")#text(" would make it a good idea to have someone who is “in” on the conspiracy to purchase exactly two tickets with the same, unusually patterned, number. The only thing I can think of is that that person in the conspiracy got greedy and wanted to claim a larger share of the jackpot than originally “planned”, but if that were the case, why stop at two tickets, and instead purchase a much larger quantity? (Admittedly this would attract even more outside attention, but this hypothetical conspiracy was already incredibly inept at avoiding attention. It would make much more sense to rig the lottery to some completely nondescript sequence of numbers that would not arouse undue suspicion, and to designate just one or two members of the conspiracy to purchase a winning ticket, rather than 433.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e6df590c1f5417f96d67b5ca7cd396826511a7e3ce8212db866bae287d0d35d-9ab9da9c9a18fb60a17e6ec7d34d73a0252d6c6c5e87d33811966ff2f4422ed9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abigail")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658466")[#strong[#text("Abigail")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2022")])]

#text("Is it known how often people picked multiples of 9 prior to the Oct 1 drawing? A deviation from that may be an indication something is rigged.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658482")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2022")])]

#text("I think it is better if they looked at the bets of each lottery ticket and see if there is a pattern emerging from this that is quite reminiscent of the winning numbers. If there is, this might indicate a red flag and the lottery might be rigged.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5051f13cae1a5ebe3dbf75363521fcfb9d472f18a40096237bb206ef51bb173-9a1347989168f1f11b73b320d7979ad7781986aee1d632e0209288c3e2146447.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Angelo Galimba")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658481")[#strong[#text("Angelo Galimba")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2022")])]

#text("Awesome technical analysis in this “anomaly”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52ebf7e2839b67361e911579a3f87cf9118d4a6c51e982ea4db50b12b4e2b7e3-1fd0838a824c442a4256f5b2274213b755cfd97c49290777f99b565312397eba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zed")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658486")[#strong[#text("Zed")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2022")])]

#text("Great analysis.")#linebreak()#text(" As there is now a call from a senator to have a formal senate investigation, the PCSO may be forced to divulge some of the data hypothesozed here in the article and in the comments – the number of actual bettors, the prevalence of bettors betting the multiples of nines set in the previous runs, etc.")

#text("I’d also like to add that the way the Philippime lotto ticket is designed, one can bet on a maximum of 7 bets per ticket. The price tag is P20 per bet. Given that our denominations of cash notes come in 20s, 50s, 100s, then 500s, it would be safe to assume that most bettors would be 5 bets (P100) so that there will be no need to get a lot of bills or to wait for change. Given that it’s hard to memorize 5 sets of 6 numbers to always bet on, there is indeed a good probability that people will have one or two of those 5 sets that are easy to remember- the multiples of nine (or any other arithmetic sequence of common difference 9) will actually form a diagonal on the ticket since the numbers are printed out in columns of 10s.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35c17b63fc40928d9f8607c8b3c15bf73ab4b7b93348c35d8827af26432eb134-5f9a079590a8bb7300b06fdeac5c32d8e4885ae44a61da4201b6c9bf3cc6c66d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcos Carreira")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658491")[#strong[#text("Marcos Carreira")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2022")])]

#text("An interesting pattern occurred in Brazil’s Mega Sena in Oct-2001; draw #308 (4, 11, 25, 29, 39, 55) was almost repeated in #309 (4, 11, 25, 39, 50, 55); as one could expect, that led to an outlier of 5 and 4 number winners – who would guess that people bet the previous winners?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658511")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2022")])]

#text("There was a superficially similar story in Ontario, Canada, in which it was believed that people working in convenience stores were winning lotteries at high rates. Jeff Rosenthal of U. Toronto was consulted as an expert by a TV show, and concluded that the data strongly supported the idea that something was amiss. It turned out that customers were buying lottery tickets. The retailers were scanning them so that the retailers could see if the ticket was winning or not(!) Winning tickets were being kept by the retailers and swapped for losing tickets. It was estimated that convenience store owners stole $100M of lottery winnings from their customers. A fuller description is at: ")#link("https://en.wikipedia.org/wiki/Ontario_Lottery_and_Gaming_Corporation#Retailer_fraud")[#text("https://en.wikipedia.org/wiki/Ontario_Lottery_and_Gaming_Corporation#Retailer_fraud")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed57ddb6738d0816cbb41ca9795c259cf0747d998e63973794c4dcbf8d75dff9-2f0e77c37384e762e9d85934817176ba6016a01ba596c91e4dd961264edf43a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stephen Stigler")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658525")[#strong[#text("Stephen Stigler")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2022")])]

#text("For centuries, lotto bettors have favored arithmetic sequences. One source of this is that people bet by marking on a printed ticket. Indeed, the ticket in the Philippines (findable online) was printed with 9 columns so they just bet the right column.")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/PCSO_Lottery_Draw#/media/File:SuperLottoCard.jpg")[#image("../assets/c56a327f1de90ee7ab50db63086b7ca21eb2cc3632e988fc59fb18cf9098b5ed-f1fab31f90926836bcb834eaeee29ecc917bb88fa7db8c8a632199e026b60af7.jpg", width: 90%)]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658533")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2022")])]

#text("Strictly speaking, the 6/55 Lotto discussed here has a slightly different layout ")#link("https://www.facebook.com/PCSO-GrandLotto-655-1-42-Tickets-1649214508638738/photos/1655400654686790")[#text("https://www.facebook.com/PCSO-GrandLotto-655-1-42-Tickets-1649214508638738/photos/1655400654686790")]#text(" as the 6/49 ticket in the Wikipedia image you linked, but the point broadly stands; the winning numbers happen to be in a diagonal pattern on the ticket, and so a plausible null hypothesis is that a non-negligible fraction of bettors chose simple patterns such as diagonals when selecting their numbers (and in at least one case, a bettor selected their favored pattern on multiple purchased tickets).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658534")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2022")])]

#text("I happened across this compilation ")#link("https://www.national-lottery.com/news/what-are-the-most-unusual-lotto-results-ever")[#text("https://www.national-lottery.com/news/what-are-the-most-unusual-lotto-results-ever")]#text(" of other events in lotteries in various countries over the years, in which the winning numbers were again in an arithmetic progression (or something similar to it), and in each case there were an unexpectedly large number of winners. It seems clear to me now that this sort of phenomenon in fact happens almost routinely around the world every few years or so, and is actually not as remarkable as it may first seem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03dff0ce10f39bfd94fdd449bfb1eebf4641e2e4d523cf5ec5ca3fef407f5739-453c402b498665e3caecabd9d454a3371f46704e3d3a8fad083312e5c670a0e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sequence Harry")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658540")[#strong[#text("Sequence Harry")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2022")])]

#text("I’ve always wondered about a concept of “sequence distribution”, e.g. given a certain run of numbers, what is the probability of the next one continuing the sequence; or is it more likely for a certain number to be valid rather than others after you observe a set (or incomplete) sequence. Lack the maths to formulate this all but I guess ultimately it comes back to correlations; conditional distributions. e.g. given you observe 5,10,15; then while all other numbers are equal to be drawn, we feel 20 would be more special to continue the sequence. And then given we observe 5,10,15,20; we feel 25 would be more special, etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A Bayesian probability worksheet | What's new")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658596")[#strong[#text("A Bayesian probability worksheet | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2022")])]

#text("[…] is a spinoff from the previous post. In that post, we remarked that whenever one receives a new piece of information , the prior odds […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658598")[#strong[#text("What are the odds? – Marxist Statistics")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2022")]

#text("[…] What are the odds? […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658601")[#strong[#text("A Bayesian chance worksheet | What's new - Veja Online")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2022")]

#text("[…] is a spinoff from the earlier publish. In that publish, we remarked that each time one receives a brand new piece of knowledge , the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e8ba354408860d8a4ca0ae8876cbc0985f27eaf398d29c43e21204e683a22e1-d4977aa11be9be9ab76c3109a2bdaa15515638b9b0c6337e424a5e50fe638f0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658608")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2022")])]

#text("If there is an agreement what was the event that happened, then the odds can be calculated. If the event was that yet another n numbers was given by a lottery machine, it has essentially the full probability. If the event was that those n numbers form some kind of pattern, that is they belong to particular subset, then the odds are different. If the event was that a particular fixed number was given by the lotto machine then the school answer is correct.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e19c68ac84fb6643c6317acf79ea4e72ae9eb4b00938f2a76bf882cf519de7ba-54728ca9a9f8439a22c02c7e35bc48b6cdf95dde81eb34c50ee861ffe41307b6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dtanman")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658624")[#strong[#text("dtanman")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2022")])]

#text("Hello, you have a small typo in the last paragraph.")

#text("…for instance, **of** {10\\%} of the 1 million ticket holders chose to select their numbers according to some sort of pattern…")

#text("I think it’s meant to be “if?”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bfa55c7cdb3d158d953beee5d1c3f24c2b44a67ff7b24e155cb215eb9ebf3677-af0d73bc9eff37d89417f10b748092e73a9a8043ac5d92a2b9f16408d595318e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 6/55 Magic – Dominic Dayta")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-658640")[#strong[#text("6/55 Magic – Dominic Dayta")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2022")])]

#text("[…] number of tickets that win the jackpot. Fields medalist Terry Tao, a god among mathematical men, has already worked out the math for this. For this let’s assume for the sake of argument that about one million bettors played for the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-659586")[#strong[#text("Reckoning with Bayes – Epicycloid of Cremona")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2022")]

#text("[…] Tao blogged recently about Bayes’ theorem. As always, his exposition was clear and thorough, and he even […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-659632")[#strong[#text("A Bayesian Probability Worksheet - My Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2022")]

#text("[…] is a spinoff from the previous post. In that post, we remarked that whenever one receives a new piece of information , the prior odds […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-659917")[#strong[#text("Știri #64 - BreakingPoint")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2022")]

#text("[…] What are the odds? | What’s new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-659925")[#strong[#text("November Newsletter – Royal Statistical Society Data Science Section")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2022")]

#text("[…] What are the odds?… fun bit of probability […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63217035ac1e74608f68295bb0dce34e02f12e611295d3042442cb8f95e697a8-27b354a4aaf233a3afaa0e351280ca35809f1e2abef25e1cee80a9ec77d6c565.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Perhaps my name is Slartibartfast?")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-682200")[#strong[#text("Perhaps my name is Slartibartfast?")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2023")])]

#text("Please do note that the hypothesis ")#mi("H_1^{\\prime}")#text(" (the one with the cult of multiples of 9) may not give you a 100% chance, because there may be the possibility that the plot fails.")

#text("Then, a lot of your suppositions about “unusual” patterns seem related to the question of which patterns of faulty machines may be modelled by mathematics. Consider for instance a die. A common way for a die to be faulty is that one side is “thicker”, so that the opposite side is more likely to show. Assuming that “mathematical” sequences are equidistributed w.r.t. the likelihood of occurrances of digits, a “mathematical” pattern would be no indication at all for a faulty die.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63217035ac1e74608f68295bb0dce34e02f12e611295d3042442cb8f95e697a8-27b354a4aaf233a3afaa0e351280ca35809f1e2abef25e1cee80a9ec77d6c565.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maybe I'm the Grinch (P(E|H_1) >> 0)!")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-682201")[#strong[#text("Maybe I'm the Grinch (P(E|H_1) >> 0)!")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2023")])]

#text("About the hypothesis ")#mi("H_1^{\\prime\\prime\\prime\\prime}")#text(": If the divine being is expected to perhaps choose a selection of lotteries, then the odds that it chooses the given one are 1/2 under uniform distro.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Santa of the Anti-Earth")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-682202")[#strong[#text("Santa of the Anti-Earth")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2023")])]

#text("I will admit that a lottery-ball producing machine that has a periodic error might give E a bigger chance. The point is that there are counter-examples, ie. where “mathematically interesting” sequences won’t help determine whether or not there is a mechanical flaw.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63217035ac1e74608f68295bb0dce34e02f12e611295d3042442cb8f95e697a8-27b354a4aaf233a3afaa0e351280ca35809f1e2abef25e1cee80a9ec77d6c565.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nonbeliever")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-682203")[#strong[#text("Nonbeliever")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2023")])]

#text("Also, what precisely is the scientific definition of “insanely small”?")

#text("In the end, everything must be weighted against the initial probabilities, and that is precisely the problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-682303")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2023")])]

#text("Concerning the lottery example: You wrote that it was a demagogue’s technique to modify a hypothesis in order to “explain away” the improbability of new information that makes the hypothesis that one argues for less probable. But isn’t this precisely what you do when modifying the null hypothesis to ")#mi("H_0^{\\prime\\prime}")#text("?")

#text("About the remark 3: I think that in most cases (including this one, where there are at least 3 possibilites: Faulty machine, manipulation, nothing) more than two hypotheses have to be considered.")

#text("Finally, in the enumeration after “in summary”, the third point may not always be necessary. There may be hypotheses that an outsider could judge to be probable based on one event alone (an event could also be an intersection of several events).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9640a506bd102ec0357eeb1c4576aca4b0bb04eeb278a415e3708ccf7c92debe-ec0438ce6fef681e66b2421effcbe986f87a39c3a4b0744aad100b84331a5972.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrei")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-685075")[#strong[#text("Andrei")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2024")])]

#text("It’s so hard to win with such odds in Romania… ")#link("https://vreauloto.ro/sanse-castig")[#text("https://vreauloto.ro/sanse-castig")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of What are the odds, II: the Venezuelan presidential election | What's new")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-685461")[#strong[#text("What are the odds, II: the Venezuelan presidential election | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2024")])]

#text("[…] a previous blog post, I discussed how, from a Bayesian perspective, learning about some new information can update […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-685466")[#strong[#text("What are the odds, II: the Venezuelan presidential election – aquamarine-lark-270283.hostingersite.com")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2024")]

#text("[…] a previous blog post, I discussed how, from a Bayesian perspective, learning about some new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-685725")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2024")])]

#text("One instance of the lottery numbers has 35 instead of 36:")

#text("“This is a number that is not too difficult to compute – in this case, the probability of the lottery producing the six numbers 9, 18, 27, ")#strong[#text("35")]#text(", 45, 54 in some order…”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-685812")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2024")])]

#text("(Small Town Lottery) in the Philippines and wanting to provide live updates for the game. If you’re working on a platform where people can check live ")#link("https://stlresult-today.com/")[#text("STL results")]#text(", you could focus on providing:")

#list(
[#strong[#text("Live Draw Updates")]#text(": A section where users can view the real-time STL lotto results for various games like Pares, Swer3, and Swer2.")],
[#strong[#text("Game Instructions")]#text(": A clear and simple guide for users, explaining how each STL game works and how to play.")],
[#strong[#text("Archives")]#text(": Previous draw results in case users want to check older results.")]
)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-685849")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2024")])]

#text("The Philippine Charity Sweepstakes Office (PCSO) plays a vital role in supporting various charitable causes in the country through its lottery and")#link("https://stlresult-today.com/")[#text(" STL")]#text(" (Small Town Lottery) games. These games not only provide entertainment but also serve as a significant source of funding for healthcare services, medical assistance, and other social welfare programs. PCSO’s commitment to transparency and public service is evident in their regular and prompt release of STL results, ensuring fairness and trust among players. It’s great to see an organization using gaming to positively impact the community!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/#comment-687638")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2025")])]

#text("I agree that one needs to consider mathematical and non-mathematical factors to determine the possibility of a rigged lottery or Venezuelan election, but the latter is not as easily quantifiable. Nevertheless, the mathematics involved is fascinating. I first came across Bayes Theorem after reading a friend’s PhD thesis looking into optimising radiotherapy doses to effect higher cure rates and minimise side effects. It opened my eyes to the role of mathematics in the sphere of medicine in which I was trained.")
]
