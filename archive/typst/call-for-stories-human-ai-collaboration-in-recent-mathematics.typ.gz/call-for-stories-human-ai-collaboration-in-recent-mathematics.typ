// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/14/call-for-stories-human-ai-collaboration-in-recent-mathematics/
// Converted to Typst by tao2typ: "2026-10-17T10:59:59.674811+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Call for stories: human–AI collaboration in recent mathematics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Call for stories: human–AI collaboration in recent mathematics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/14/call-for-stories-human-ai-collaboration-in-recent-mathematics/")[#text("https://terrytao.wordpress.com/2026/10/14/call-for-stories-human-ai-collaboration-in-recent-mathematics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-17 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://www.math.ucla.edu/~deanna/")[#text("Deanna Needell")]#text(" and ")#link("https://sites.google.com/view/haydenschaeffer/")[#text("Hayden Schaeffer")]#text(" – T.]")]

#text("[Edit: Oct 16, 2026 : we are in particular interested in ways mathematicians contributed to the results in the wave of recent AI generated preprints, e.g. preliminary results, interactions with AI models, publications, etc.]")

#text("AI systems are playing an important part in mathematical discoveries, and several recent preprints describe results reached with their help. What makes these results possible is often a rich partnership between human insight, expertise, and earlier work combining with new AI capabilities in ways that move the field forward.")

#text("We are interested in documenting and highlighting this collaboration, so the community can better understand how people and AI systems work together most effectively. As a first step, we would love to hear from mathematicians who took part in, or whose work helped make possible, any of these results.")

#text("If that describes you, we would be glad to hear from you at ")#link("mailto:mathematiciancontributions@gmail.com")[#text("mathematiciancontributions@gmail.com")]#text(". We’re interested in all kinds of involvement, such as earlier research or ideas the work built on, related projects in progress, checking and refining arguments, connecting results to the existing literature, or anything else you found relevant or meaningful about the process.")

#text("A short note about your involvement and the work it relates to is a great place to start. All messages will be kept confidential, and nothing you share will be used, quoted, or attributed to you without your explicit consent.")

#text("Thank you, and please feel free to share this with anyone who may have been part of this work.")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/024cb9cda434ba8bdf086f7fadb51eaef75e5b362349a4047e44beb4ced09cad-a0d15a1a44c11ea98c5364849ae620332e0deda4779ff67098eb87db455f6c23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Clemens Cap")]], [#link("https://terrytao.wordpress.com/2026/10/14/call-for-stories-human-ai-collaboration-in-recent-mathematics/comment-page-1/#comment-698075")[#strong[#text("Clemens Cap")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("What is the exact notion of „confidential“ when the email address is on gmail?")

#text("Not trying to be funny and not having something confidential to share. Just stumbled over this paradox.")

#text("Clemens Cap.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/14/call-for-stories-human-ai-collaboration-in-recent-mathematics/comment-page-1/#comment-698081")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("Intended or not, this appears like fishing for “success stories”. What is the reason for UCLA to explicitly collect positive opinions and stories?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/14/call-for-stories-human-ai-collaboration-in-recent-mathematics/comment-page-1/#comment-698095")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("It is written explicitly in the post.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("… so the community can better understand how people and AI systems work together most effectively.")
]

#text("It is not the same only putting the text of a problem into a chatbot and using whatever comes out, than working with an entire architecture that manages the sub-problems that different agents are working on, enforces verification per stage, manages the directed graph of the proof to not repeat work, etc. It is also not the same using it for producing a proof, than using it for proofreading, or for gathering references, or for explaining the steps of proof, or for generating visualizations.")

#text("Obviously successful uses are the more useful, to imitate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eac303e6c7471a79961e0e85fe0b187b690f0613fd57b0a9e1d8f5e48630a7f0-75171483cb34b59a6c8a49e96a19e6ca9e61c6c96b2a000115a4810376359fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kęstutis")]], [#link("https://terrytao.wordpress.com/2026/10/14/call-for-stories-human-ai-collaboration-in-recent-mathematics/comment-page-1/#comment-698135")[#strong[#text("Kęstutis")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("Indeed are we lacking stories of humans using AI in research? AlphaFold? Tristan Buckmaster? Too many submissions to arxiv to count?")

#text("Society loves efficiency and reducing to singular numbers, let us measure the cost of covid in USD. Something like young kids not getting to see people’s mouths, -$")

#text("The concern has never been that highly skilled people will not adapt and find purpsoe with new tools, it’s what we’re sacrificing to construct this braze new world. This blog is already full of ancedotes from student and professor of valuable research questions, dialog and exchanges happening with the machine instead of the student having the change to excersize their own critical thinking. I think Buckmaster has really been trying to draw attention to the chilling effect that as the goalpost of expectations moves towards one having to be a John Henry, a why bother attitude takes hold towards strenenous intellectual excersize. We have the quandary that we systemically penalize the slow careful development of the skills necessary to digest the “progress” in the field generated by productivity maximizing. Celebrating how a generation of deskilled workers can push the frontiers of science is obviously beginning for accident.")

#text("Indeed the ethos of the push to incorporate AI into everything is no vision the future, it’s entire about a present of Execute Execute Execute Kill Kill Kill genai.mil")

#text("As a Gen Z student I really feel much of what we’re doing here is just celebrating the internet and cheap access to abundant information, that goes for the fears about the tech like “oh no the houthis looked up how to make rockets”. What is going on here is a tale of human moral and societal decay. For us Mathematicians and Physicist I guess that means the time is ripe for one to challenge established ideas like Godel is the healthy spin…")

#text("A place where “big data science” makes natural sense is of course climate science so let us check we’re dismantling our research apparatus and defunding it I guess that means we’re hitting the paris goals let us check…")

#text("We need to be a bit more frank that we live in a society that we rewards playing helldivers IRL or running a cryptoscam than a human pouring blood sweat and tears into the most beautiful work proving the riemann hypothesis with tremendous immediate broad application with no AI assistance.")

#text("Geuinely the philosophical life advice for the young aspiring Grothendieck may be to take some LSD and run to the hills far away from lockdowned campuses where protesting killer robotic enhanced genocidal warfare is prohibited")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/14/call-for-stories-human-ai-collaboration-in-recent-mathematics/comment-page-1/#comment-698090")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("Did you get an empty email by Peter Scholze?")
]
