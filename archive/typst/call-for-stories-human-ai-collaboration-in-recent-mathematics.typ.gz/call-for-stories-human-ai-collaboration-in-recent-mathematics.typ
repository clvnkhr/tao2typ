// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/14/call-for-stories-human-ai-collaboration-in-recent-mathematics/
// Converted to Typst by tao2typ: "2026-10-15T11:45:58.041457+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Call for stories: human–AI collaboration in recent mathematics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Call for stories: human–AI collaboration in recent mathematics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/14/call-for-stories-human-ai-collaboration-in-recent-mathematics/")[#text("https://terrytao.wordpress.com/2026/10/14/call-for-stories-human-ai-collaboration-in-recent-mathematics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-15 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://www.math.ucla.edu/~deanna/")[#text("Deanna Needell")]#text(" and ")#link("https://sites.google.com/view/haydenschaeffer/")[#text("Hayden Schaeffer")]#text(" – T.]")]

#text("AI systems are playing an important part in mathematical discoveries, and several recent preprints describe results reached with their help. What makes these results possible is often a rich partnership between human insight, expertise, and earlier work combining with new AI capabilities in ways that move the field forward.")

#text("We are interested in documenting and highlighting this collaboration, so the community can better understand how people and AI systems work together most effectively. As a first step, we would love to hear from mathematicians who took part in, or whose work helped make possible, any of these results.")

#text("If that describes you, we would be glad to hear from you at ")#link("mailto:mathematiciancontributions@gmail.com")[#text("mathematiciancontributions@gmail.com")]#text(". We’re interested in all kinds of involvement, such as earlier research or ideas the work built on, related projects in progress, checking and refining arguments, connecting results to the existing literature, or anything else you found relevant or meaningful about the process.")

#text("A short note about your involvement and the work it relates to is a great place to start. All messages will be kept confidential, and nothing you share will be used, quoted, or attributed to you without your explicit consent.")

#text("Thank you, and please feel free to share this with anyone who may have been part of this work.")
