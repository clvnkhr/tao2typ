// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/
// Converted to Typst by tao2typ: "2026-10-14T15:16:21.640149+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Open question: What is a quantum honeycomb?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Open question: What is a quantum honeycomb?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 April 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/")[#text("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This problem lies in the highly interconnected interface between algebraic combinatorics (esp. the combinatorics of ")#link("http://en.wikipedia.org/wiki/Young_tableau")[#text("Young tableaux")]#text(" and related objects, including ")#link("http://www.math.ucla.edu/~tao/java/Honeycomb.html")[#text("honeycombs")]#text(" and puzzles), algebraic geometry (particularly classical and quantum ")#link("http://en.wikipedia.org/wiki/Intersection_theory")[#text("intersection theory")]#text(" and ")#link("http://en.wikipedia.org/wiki/Geometric_invariant_theory")[#text("geometric invariant theory")]#text("), linear algebra (additive and multiplicative, real and tropical), and the representation theory (classical, quantum, crystal, etc.) of classical groups. (Another open problem in this subject is to find a succinct and descriptive name for the field.) I myself haven’t actively worked in this area for several years, but I still find it a fascinating and beautiful subject. (With respect to the dichotomy between structure and randomness, this subject lies deep within the “structure” end of the spectrum.)")

#text("As mentioned above, the problems in this area can be approached from a variety of quite diverse perspectives, but here I will focus on the linear algebra perspective, which is perhaps the most accessible. About nine years ago, ")#link("http://www.math.ucsd.edu/~allenk/")[#text("Allen Knutson")]#text(" and I ")#link("http://www.ams.org/mathscinet-getitem?mr=1671451")[#text("introduced")]#text(" a combinatorial gadget, called a ")#emph[#text("honeycomb")]#text(", which among other things controlled the relationship between the eigenvalues of two arbitrary Hermitian matrices A, B, and the eigenvalues of their sum A+B; this was not the first such gadget that achieved this purpose, but it was a particularly convenient one for studying this problem, in particular it was used to resolve two conjectures in the subject, the ")#emph[#text("saturation conjecture")]#text(" and the ")#emph[#text("Horn conjecture")]#text(". (These conjectures ")#link("http://math.ucdavis.edu/%7Ekapovich/EPR/alg14.pdf")[#text("have")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=1758750")[#text("since")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2177198")[#text("been")]#text(" ")#link("http://front.math.ucdavis.edu/math.CO/0107011")[#text("proven")]#text(" by a variety of other methods.) There is a natural multiplicative version of these problems, which now relates the eigenvalues of two arbitrary ")#emph[#text("unitary")]#text(" matrices U, V and the eigenvalues of their product UV; this led to the “quantum saturation” and “quantum Horn” conjectures, which were proven ")#link("http://arxiv.org/abs/math/0303013")[#text("a couple years ago")]#text(". However, the quantum analogue of a “honeycomb” remains a mystery; this is the main topic of the current post.")

#metadata(none) <tao-80a35be58adf76416b0e>

#text("Let us first briefly review the additive situation. Consider three ")#mi("n\\times n")#text(" ")#link("http://en.wikipedia.org/wiki/Hermitian_matrix")[#text("Hermitian matrices")]#text(" A,B,C such that A+B=C. Being Hermitian, the matrices A,B,C are all diagonalisable with real eigenvalues. Accordingly, let us arrange the eigenvalues of A (with multiplicity) in decreasing order as")

#align(center)[#tao-fit-display[#mitex("\\lambda_1 \\geq \\lambda_2 \\geq \\ldots \\geq \\lambda_n")]]

#text("the eigenvalues of B as")

#align(center)[#tao-fit-display[#mitex("\\mu_1 \\geq \\mu_2 \\geq \\ldots \\geq \\mu_n")]]

#text("and the eigenvalues of C as")

#align(center)[#mi("\\nu_1 \\geq \\nu_2 \\geq \\ldots \\geq \\nu_n")#text(".")]

#text("Thus for instance ")#mi("\\mu_2")#text(" is the second largest eigenvalue of B, etc.")

#text("An old question (essentially due to Sylvester, though this particular formulation is due to Weyl) was to determine the complete set of relationships between the ")#mi("\\lambda_i")#text(", the ")#mi("\\mu_j")#text(", and the ")#mi("\\nu_k")#text(". There are a number of reasonably obvious equalities and inequalities that one can obtain here. For instance, from the obvious identity tr(A)+tr(B)=tr(C) we conclude the ")#emph[#text("trace identity")]

#align(center)[#mi("\\lambda_1+\\ldots+\\lambda_n+\\mu_1+\\ldots+\\mu_n=\\nu_1+\\ldots+\\nu_n")#text(",")]

#text("while from the minimax characterisation of the largest eigenvalue,")

#align(center)[#mi("\\lambda_1 = \\sup_{\\text{dim}(V)=1} \\text{tr}(A|_V)")#text(", etc.")]

#text("one easily obtains the triangle inequality")

#align(center)[#mi("\\nu_1 \\leq \\lambda_1 + \\mu_1")#text(".")]

#text("And so on and so forth. It turns out that the set of all possible ")#mi("\\lambda_i, \\mu_j, \\nu_k")#text(" form a convex cone, determined by a finite number of linear inequalities; this can be derived from symplectic geometry considerations (the ")#link("http://www.ams.org/mathscinet-getitem?mr=642416")[#text("Atiyah")]#text("/")#link("http://www.ams.org/mathscinet-getitem?mr=664117")[#text("Guillemin-Sternberg")]#text(" convexity theorem, or more precisely a refinement ")#link("http://www.ams.org/mathscinet-getitem?mr=759257")[#text("due to Kirwan")]#text("). A complete (in fact, overcomplete) list of such inequalities, generated by a beautifully recursive formula, was conjectured ")#link("http://http://www.ams.org/mathscinet-getitem?mr=140521")[#text("by Alfred Horn")]#text(" (no relation to Roger Horn, who also works in linear algebra). The Horn conjecture was finally settled in two papers: one ")#link("http://www.ams.org/mathscinet-getitem?mr=1654578")[#text("by Klyachko")]#text(", which used geometric invariant theory to reduce the problem to a simpler problem known as the ")#emph[#text("saturation conjecture")]#text(", and one ")#link("http://www.ams.org/mathscinet-getitem?mr=1671451")[#text("by Allen Knutson and myself")]#text(", which established the saturation conjecture by a combinatorial argument using honeycombs.")

#text("Here is what a honeycomb looks like:")

#image("../assets/cdfdce12ccd6fe8d397f4806291d936fe365bab593d45634d03fe15af25a2265-2499abee937c2ea22949d341c65dd69cd0fbe657ecd5bdebf5bbcfed1144cab3.jpg", width: 90%, alt: "honeycomb")

#text("Note that the lengths of the edges in the honeycomb are variable, but there are only three possible orientations, 120 degree angles apart. This is a honeycomb of order 4, with four half-infinite edges going in a NW direction, four in a NE direction, and four in the S direction; the coordinates of these edges are the ")#emph[#text("boundary data")]#text(" of this honeycomb. [For more precise definitions, see ")#link("http://www.ams.org/mathscinet-getitem?mr=1811121")[#text("our survey paper")]#text(" or ")#link("http://www.ams.org/mathscinet-getitem?mr=1671451")[#text("our original article")]#text(".] One can also play with honeycombs using our ")#link("http://www.math.ucla.edu/~tao/java/Honeycomb.html")[#text("honeycomb applet")]#text(".")

#text("Allen and I observed that honeycombs “solve” Weyl’s problem in the following sense: a collection ")#mi("\\lambda_i, \\mu_j, \\nu_k")#text(" of putative eigenvalues can arise as the eigenvalues of a triplet A+B=C of matrices if and only if they arise as the boundary values of at least one honeycomb. In fact, there is a more quantitative relationship: the “volume” of the set of all A+B=C with the desired eigenvalues is equal (up to some explicit normalising factors) to the “volume” of all the honeycombs with the specified boundary data.")

#text("There is also a discrete or quantized version of the above connection. One can define an ")#emph[#text("integral")]#text(" honeycomb to be one where all lengths and coordinates are integers (in particular, the boundary data will also be integers). It turns out that an integral honeycomb with boundary values ")#mi("\\lambda_i, \\mu_j, \\nu_k")#text(" exists if and only if the irreducible representation of SU(n) with weight vector ")#mi("(\\nu_1,\\ldots,\\nu_n)")#text(" appears at least once in the tensor product of the irreducible representations of weight vectors ")#mi("(\\lambda_1,\\ldots,\\lambda_n)")#text(" and ")#mi("(\\mu_1,\\ldots,\\mu_n)")#text(", and furthermore the number of integral honeycombs counts the multiplicity of this representation. This multiplicity is in fact a ")#emph[#text("Littlewood-Richardson coefficient")]#text(", and appears in a number of other contexts, such as ")#link("http://en.wikipedia.org/wiki/Schubert_calculus")[#text("Schubert calculus")]#text(" (intersection numbers for Schubert classes); see this ")#link("http://www.ams.org/mathscinet-getitem?mr=1754641")[#text("survey of Fulton")]#text(" for details. The precise relationship between the discrete and continuous formulations of this problem is in fact the key to the Horn conjecture (and the closely related saturation conjecture), but I will not discuss this in detail here (it is covered in the above references). Honeycombs can also be linked to several other combinatorial gadgets, such as ")#link("http://www.ams.org/mathscinet-getitem?mr=1997946")[#text("puzzles")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1162639")[#text("Berenstein-Zelevinsky patterns")]#text(", and ")#link("http://en.wikipedia.org/wiki/Young_tableau")[#text("Young tableaux")]#text(": see ")#link("http://www.ams.org/mathscinet-getitem?mr=2143205")[#text("this paper")]#text(" for several of these connections (and ")#link("http://arxiv.org/abs/0704.0817")[#text("this paper")]#text(" for some further recent developments).")

#text("But let us leave this additive setting for now and turn to the analogous multiplicative problem. Here, instead of three Hermitian matrices A+B=C, we now have three ")#emph[#text("unitary")]#text(" matrices UV=W. It is convenient to normalise these matrices to have determinant 1, in which case we can uniquely express the eigenvalues of U as")

#align(center)[#mi("e(\\lambda_1), \\ldots, e(\\lambda_n),")#text(" where ")#mi("\\lambda_1 \\geq \\ldots \\geq \\lambda_n \\geq \\lambda_1-1")#text(" and ")#mi("\\lambda_1+\\ldots+\\lambda_n=0")]

#text("where ")#mi("e(x) := e^{2\\pi i x}")#text(", and similarly express the eigenvalues of V as")

#align(center)[#mi("e(\\mu_1), \\ldots, e(\\mu_n),")#text(" where ")#mi("\\mu_1 \\geq \\ldots \\geq \\mu_n \\geq \\mu_1-1")#text(" and ")#mi("\\mu_1+\\ldots+\\mu_n=0")]

#text("and the eigenvalues of W as")

#align(center)[#mi("e(\\nu_1), \\ldots, e(\\nu_n),")#text(" where ")#mi("\\nu_1 \\geq \\ldots \\geq \\nu_n \\geq \\nu_1-1")#text(" and ")#mi("\\nu_1+\\ldots+\\nu_n=0")#text(".")]

#text("We can now ask the multiplicative version of Weyl’s problem, namely to characterise all the relationships that exist between the ")#mi("\\lambda_i")#text(", the ")#mi("\\mu_j")#text(", and the ")#mi("\\nu_k")#text(". For instance, it is possible to view ")#mi("\\lambda_1")#text(" as the “maximum anti-clockwise angle” that U can rotate a vector, which can eventually lead to the inequality")

#align(center)[#mi("\\nu_1 \\leq \\lambda_1 + \\mu_1")#text(".")]

#text("One can continue creating inequalities of this type, and there will be a strong resemblance of those inequalities with those in the additive problem. This is not so surprising, since the additive problem emerges as a limiting case of the multiplicative one (if ")#mi("U = \\exp( \\epsilon A ), V = \\exp( \\epsilon B), W = \\exp(\\epsilon C)")#text(" and UV=W, then ")#mi("A+B = C + O(\\epsilon)")#text(" when ")#mi("\\epsilon")#text(" is small, by the ")#link("http://en.wikipedia.org/wiki/Baker-Campbell-Hausdorff_formula")[#text("Baker-Campbell-Hausdorff formula")]#text(". What is more surprising is that when the ")#mi("\\lambda_i, \\mu_j, \\nu_k")#text(" are sufficiently small, that the inequalities which describe the multiplicative problem are ")#emph[#text("exactly ")]#text("those that describe the additive problem! In fact, it is known that the space of all possible ")#mi("\\lambda_i, \\mu_j, \\nu_k")#text(" for the multiplicative problem is a convex polytope contained within the convex cone for the additive problem, and in fact a quantum version of the Horn conjecture (i.e. an explicit recursive description of the faces of this polytope) was proven ")#link("http://arxiv.org/abs/math/0303013")[#text("by Belkale")]#text(" (building upon earlier work by ")#link("http://www.ams.org/mathscinet-getitem?mr=1671192")[#text("Agnihotri-Woodward")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1856023")[#text("Belkale")]#text("). For instance, while for the additive problem there is the constraint")

#align(center)[#tao-fit-display[#mitex("\\nu_{i+j-1} \\leq \\lambda_i + \\mu_j")]]

#text("whenever ")#mi("i+j -1 \\leq n")#text(" (the Weyl inequalities), in the multiplicative problem one also has the additional constraint")

#align(center)[#mi("\\lambda_i + \\mu_j \\leq \\nu_{i+j}+1")#text(".")]

#text("As with the additive problem, the complete set of all inequalities of this form turns out to be rather messy to describe and I will not do so here.")

#text("Just as the additive Weyl problem turned out to be linked to Schubert calculus (the intersection numbers of Schubert classes), the multiplicative problem turned out to be linked to quantum Schubert calculus (the ")#link("http://en.wikipedia.org/wiki/Gromov-Witten_invariant")[#text("Gromov-Witten numbers")]#text(" of the same classes), and making this link precise turned out to be the key to the proof of the quantum Horn conjecture.")

#text("This solves the “qualitative” version of the multiplicative Weyl problem, namely whether there exists any triple UV=W with the specified eigenvalues. However, one can still ask “quantitative” versions, namely to compute the volume of the space of all such triples. There is also the discretised quantitative version, which concerns either the Gromov-Witten numbers for Schubert classes, or else the multiplicities of fusion products in the Verlinde algebra of SU(n); these are rather technical and we refer to ")#link("http://www.ams.org/mathscinet-getitem?mr=1671192")[#text("Agnihotri-Woodward")]#text(" for details. There should exist some concept of “quantum honeycomb” which computes all of these numbers, in much the same way that the usual honeycombs computes the volume of the space of solutions to A+B=C with specified eigenvalues, intersection numbers for Schubert classes, or multiplicities of tensor products of SU(n) irreducible representations. Vaguely speaking it seems that one wants to construct an analogue of the planar honeycomb which lives instead on something like a two-dimensional torus, but it is not entirely clear (even when n=2) what the precise definition of this object should be.")

#text("It may seem like one needs to learn a fearsome amount of machinery to attack this problem, but actually I think one can at least ")#emph[#text("guess")]#text(" what the quantum honeycomb should be just by experimentation with small cases n=1,2,3 and by using various sanity checks (this is how Allen and I discovered the additive honeycombs). For instance, the equation UV=W has the cyclic symmetry ")#mi("(U,V,W) \\mapsto (V,W^{-1},U^{-1})")#text(" and so the quantum honeycomb should enjoy a similar symmetry. There is also the translation symmetry ")#mi("(U,V,W) \\mapsto (e(\\alpha)U, e(\\beta)V, e(\\gamma)W)")#text(" whenever ")#mi("\\alpha+\\beta+\\gamma=0")#text(", so quantum honeycombs should be translation invariant. When the honeycomb is small (all vertices close to the origin) there should be a bijective correspondence between the quantum honeycomb and the regular honeycomb. The constraints between all the boundary values are already known due to the resolution of the quantum Horn conjecture. There are some other extreme cases which are also understood quite well, for instance when one of the matrices is very close to the identity but the other two are not.")

#text("My guess is that once a reasonable candidate for a quantum honeycomb is found which passes all the obvious sanity checks, actually verifying that it computes everything that it should will be a relatively routine matter (we have many different combinatorial ways of establishing things like this). This will give a combinatorial tool for computing a number of interesting quantities, and will probably shed some light also as to why these honeycombs appear in the subject in the first place. (It seems to be somehow related to the ")#link("http://en.wikipedia.org/wiki/Dynkin_diagram")[#text("Dynkin diagram")]#text(" ")#mi("A_n")#text(" for the underlying group SU(n); it has proven a little tricky to try to find analogues of these objects for the other Dynkin diagrams.) Certainly they seem to be computing something rather non-trivial; for instance the Littlewood-Richardson numbers that are computed by additive honeycombs have ")#link("http://ramakrishnadas.cs.uchicago.edu/gct6.ps")[#text("even been proposed")]#text(" to play a role in lower bounds in complexity theory, and specifically the ")#mi("P \\neq NP")#text(" problem!")

#text("[Thanks to ")#link("http://math.ucsd.edu/~allenk/")[#text("Allen Knutson")]#text(" for suggestions and encouragement.]")

#heading(level: 1)[#text("Comments (27)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0ba5e9f704716da6c6c03df8a44aa256d0933fa054841feb9deae97e27eeece-cce5119b6810676ce1f73e00e2ecfa911077c241ddb483bf5cc08467cc22927a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kea")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-558")[#strong[#text("Kea")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2007")])]

#emph[#text("Another open problem in this subject is to find a succinct and descriptive name for the field.")]

#text("How about M theory?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-615")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2007")])]

#text("I do not have access to this paper, but look at a 1986 abstract for mathematical modeling of the honeycomb with Fourier Transformation:")

#text("Journal of Mathematical Biology")#linebreak()#text(" ‘Mathematical model of honeycomb construction’ MR Bell et al")

#link("http://www.springerlink.com/content/n3rrj73658488631/")[#text("http://www.springerlink.com/content/n3rrj73658488631/")]

#text("Although this is certainly at a scale different from the quantum, comparison of the Bell paper with your effort may be warranted?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stephen")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-648")[#strong[#text("Stephen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2007")])]

#text("I wonder if ideas related to these Honeycombs could help analyze adiabatic quantum algorithms. Eddie Farhi and collaborators proposed an adiabatic quantum algorithm for solving NP-hard problems. The algorithm provably works in the limit where the runtime is allowed to go to infinity, but it is not known what the minimal runtime is. This hinges on the gap between the smallest and second smallest eigenvalue of the Hamiltonian, which is the sum of two 2^n by 2^n Hermitian matrices, each of which have well understood spectra. (The runtime is upper bounded by something like O(1/gap^3).) Figuring out how this eigenvalue gap scales for large n is a longstanding* open problem. Although some feel it is unlikely that the runtime could be polynomial in the worst case (this would imply that NP is contained in BQP), it seems quite plausible that runtime is polynomial for random instances, and this would still be a very exciting result. Have you ever thought about this?")

#text("*by quantum computation standards!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-651")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2007")])]

#text("Are honeycomb related to amoebas (or non-archimedean amoebas) considered by Kontsevich, Mikhalkin, Shustin and various othres? (this is a “tropical” area, I suppose.) At least the pictures look rather similar.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-657")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2007")])]

#text("Dear Stephen, I know some people are looking at the limiting distribution of “random” honeycombs in the large n limit, which should have connections both with random tilings and to free convolution, but I don’t believe there are published results on this problem yet (though it is an interesting direction to look into). There is also the question of what “random” means; typically for this type of analysis one assumes that the probability distributions of the input matrices are U(n)-invariant, which may be too strong for the quantum computing application.")

#text("Dear Gil, there is indeed a tropical amoeba interpretation of the additive honeycomb, ")#link("http://www.ams.org/mathscinet-getitem?mr=2132865")[#text("due to David Speyer")]#text(". Roughly speaking, one replaces the real line R by the ring of Puiseux series (to get the tropicalisation), and starting from a triple of matrices A+B+C=0 the honeycomb can be recovered by looking at the curve det(xA+yB+zC)=0.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74cb8c8183a06c76e177c0da5183e7618187a4a4368f7f02ac6900e863c16915-e9cdb18e4c7b9ed692e23d25757775c1d7d92f4894ddb936aa87d4bb380177d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Woodward")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-834")[#strong[#text("Chris Woodward")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2007")])]

#text("Hi Terry,")

#text("I once had this crazy dream, that the quantum version of a honeycomb")#linebreak()#text(" should be a honeycomb on a thrice-punctured sphere with hyperbolic")#linebreak()#text(" metric. That is, one has these geodesics coming in from infinity,")#linebreak()#text(" as in the pictures in Thurston’s book, and one can talk about")#linebreak()#text(" honeycombs where each segment is a segment of a geodesic")#linebreak()#text(" of this type. Given data at infinity (namely, distinct")#linebreak()#text(" finite subsets of each circle at infinity) one can try to count honeycombs.")

#text("On the good side, there is an obvious Euclidean limit which gives")#linebreak()#text(" the usual notion of honeycomb. There would also be a strategy")#linebreak()#text(" for proving associativity (degenerate a quadruply punctured")#linebreak()#text(" sphere in two ways ). On the bad side, it wasn’t")#linebreak()#text(" clear to me whether one has the expected cyclic symmetry.")#linebreak()#text(" Or even, how does one choose the base points on the circles")#linebreak()#text(" at infinity?")

#text("I would love it if someone would explain why my crazy dream couldn’t")#linebreak()#text(" work (or could it?)")

#text("Chris")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-836")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2007")])]

#text("Hi Chris! Thanks for posting.")

#text("It’s certainly a very visually appealing idea, and fits of course with the role of the thrice-punctured sphere in the product of unitary matrices problem. One could start with investigating the n=1 case: the space of all “hyperbolic 1-honeycombs” cuts out a two-dimensional subset of the three circles at infinity, which one can view as a group-type operation (mapping the product of two circles to a third); it should then be easy to check whether this operation is isomorphic to the expected one (basically the addition operation on R/Z) by checking that it behaves in a commutative and associative manner.")

#text("The other difficulty I see is that there is no obvious discretisation which would count fusion product multiplicities.")

#text("It may be that we have to somehow abandon the idea of a honeycomb as a 1-D subset of a 2-D space. Take for instance the equivalent “hive” model of the additive honeycomb, which is a piecewise linear concave function with prescribed boundary values. The piecewise linearity is what is causing the honeycomb (which is sort of a dual object to the hive in some ways) to behave one-dimensionally, but one could imagine some sort of “hyperbolic hive” which had the concavity but not the piecewise linearity, and so the corresponding honeycomb becomes “smeared out” somehow. I don’t exactly see what such a hyperbolic hive could be, though; I vaguely want to take some sort of section of a bundle of thrice-punctured spheres over a triangle, or something strange like that.")#linebreak()#text(" But this is just wild speculation, not supported by much hard data :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-842")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2007")])]

#text("p.s. Vaughan Jones pointed me towards the ")#link("http://math.berkeley.edu/~scott/papers/thesis.pdf")[#text("thesis of his student Scott Morrison")]#text(", in which he describes the representation theory of the quantum group ")#mi("U_q(sl_n)")#text(" in terms of spherical categories. One gets a number of topologically planar diagrams involved, related to Kuperberg’s webs and Jones’ planar algebras; they do of course look vaguely honeycomb-ish, but even in the classical additive setting we were never able to figure out what was the connection between these topologically planar objects and the geometrically planar honeycombs. The idea (implicit in your post) of using the uniformisation theorem to connect topology to geometry is very intruiging, though.")

#text("Vaughan ventured the opinion that planarity (or more specifically, a non-crossing condition) should play a much more prominent role in the quantum (multiplicative) setting than in the classical (additive setting), though I don’t know exactly what to make of this “hint”. Certainly the “overlay” operation for additive honeycombs looks like it should extend to multiplicative honeycombs, for instance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9d33b5a8b49301e4ab62bb930e5939e770c4c01ae7975aa899337c4b044801a5-546f553783cfc78e6fcf023d5761b297281ae1f3a6203bf0cb74ab99c1a6464c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sacha")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-849")[#strong[#text("Sacha")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2007")])]

#text("Terry, in using the term “quantum honeycomb”, are you saying that “it” (whatever it is) would be related to quantum algebraic structures (eg quantum algebras)? I’m unfamiliar with the algebraic structures you mention in your post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-853")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2007")])]

#text("Dear Sacha,")

#text("Quantum (or “multiplicative”) honeycombs should relate to two “quantum” objects: firstly, quantum Schubert calculus, i.e. the structure of the quantum cohomology of the Grassmannian, which basically is counting how many holomorphic sections one can find in bundles of Grassmannians over punctured spheres (these counts are known as Gromov-Witten invariants). The other is the fusion product multiplicities of the Verlinde algebra of SU(n). I believe the latter is related to quantum groups, though I do not know the precise relationship. In the classical (or “additive”) honeycomb setting, the analogous objects are classical Schubert calculus (the intersection numbers of Schubert varieties), and tensor product multiplicities of irreducible representations of SU(n) or U(n).")

#text("Incidentally, just to make matters a bit more confusing, there is an unrelated “classical/quantum” distinction in the subject, between the “continuous” setting (which relates to sums of Hermitian matrices or products of unitary matrices) and the “discrete” setting (which is where the Schubert calculus and representation theory is). The continuous/discrete distinction is analogous to the distinction between classical (Hamiltonian) mechanics and quantum (Schrodinger/Heisenberg) mechanics. (I’m actually not entirely clear why quantum cohomology and quantum groups also have the adjective “quantum” attached, but that’s the standard terminology.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9d33b5a8b49301e4ab62bb930e5939e770c4c01ae7975aa899337c4b044801a5-546f553783cfc78e6fcf023d5761b297281ae1f3a6203bf0cb74ab99c1a6464c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sacha")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-869")[#strong[#text("Sacha")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2007")])]

#text("Thanks Terry – I’ll have to read up about these topics. I know a few things about quantum groups (I did my PhD on one family of quantum supergroups) – I think that, essentially, the use of “quantum” as an adjective is by analogy with quantum mechanics in relation to classical mechanics.")

#text("In one version of quantum groups, they can be seen as one-parameter deformations of the universal enveloping algebras of lie algebras or lie superalgebras. The name seems a bit funny to me that it seems to have stuck now. I also call them quantum algebras as they’re not groups (unless you are actually talking about the groups).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frederick")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-962")[#strong[#text("Frederick")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2007")])]

#text("Professor Tao,")#linebreak()#text(" I want to ask a question. Given a sequence B(n), integer n from -infinity to +infinity. I require B(n)=B(-n). Now define a matrix C(p,q)=B(q-p)*q*q (square q). Now I ask under what conditions of B(n), the eigenvalues of matrix C are the eigenvalues of random matrix? The question comes from many fields from physics, such as the Helmholtz equation in a two dimensional billiard.")#linebreak()#text(" This is a very difficult question for me (although it seems easy). I thought it hard, but could not find any answer, even any hints to attack it. I even could not find any references to look at. I even don’t know whether C is some kind of special matrix, on which mathematicians have done a lot of work already.")#linebreak()#text(" Thanks!")#linebreak()#text(" Frederick")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-977")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2007")])]

#text("Dear Frederick,")

#text("The matrix is not self-adjoint or normal, and so it may be that eigenvalues might not be the most relevant feature of this matrix (there is no spectral theorem, for instance). After a Fourier transform, the matrix is equivalent to the operator ")#mi("- b(x) \\frac{d^2}{dx^2}")#text(" acting on periodic functions, where b is the Fourier series with coefficients B. If instead you consider the self-adjoint version ")#mi("- \\frac{d}{dx} b \\frac{d}{dx}")#text(" (this corresponds to replacing q*q by q*p in your matrix), then you can use tools from microlocal analysis, such as Weyl’s law, to obtain some control on the eigenvalues, though to get fine information such as eigenvalue spacing distributions is still well beyond current technology.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frederick")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-1014")[#strong[#text("Frederick")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2007")])]

#text("Dear Professor Tao,")#linebreak()#text(" If b(x) is periodic, then lots of problems are solved by Bloch’s theorem. All the eigenfunctions are extended (no Anderson localization occurs). Actually I was thinking the eigenvalues and wavefunction of a billiard (scar). After making a conformal transformation, the Laplacian will have a factor/coefficient, I thought the factor/coefficient would be periodic. Actually it’s not periodic. So things are more complex than I first thought.")#linebreak()#text(" Lots of physical problems are either solved numerically such as using finite difference method or solved by the spectral method. But the spectral method always brings big infinite matrices. It is a pity there is not very effective to handle these kinds of infinite matrices.")#linebreak()#text(" Thanks very much!")#linebreak()#text(" Frederick")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37ec442307d362db0641c4e90698747e1c9c10c5cde079d5b60ee7b200f3ca54-db273bdb3124ff872087d7f00744b18ada5167bdea3de72dd6586ca366ae288d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of trisetyarso")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-21229")[#strong[#text("trisetyarso")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2007")])]

#text("Dear Prof. Tao,")

#text("It is very helpful for me that I can find this explanation.")

#text("I just start my research in this area.")

#text("I want to see the acts of honeycomb in measurement-based quantum computation. (Adder, Error-Correction etc)")

#text("Best regards,")

#text("Agung Trisetyarso")#linebreak()#text(" ")#link("http://www.agungtrisetyarso.com")[#text("http://www.agungtrisetyarso.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e462e0d25b2299084e2cfd41a62b1463383a36e5d35a1e8edff1754c0ccca8d9-f07aec5c1b8fecd5f87cae7d7d461eb9080a0be9d2906bb21e268ed5f92d6f20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-134180")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2012")])]

#text("Isn’t Littlewood-Richardson number computation in P while Kronecker numbers are in NP-hard (harder)? How can an amateur try to learn about these two numbers?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e462e0d25b2299084e2cfd41a62b1463383a36e5d35a1e8edff1754c0ccca8d9-f07aec5c1b8fecd5f87cae7d7d461eb9080a0be9d2906bb21e268ed5f92d6f20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-134182")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2012")])]

#text("I meant an amateur with a cs theory background trying to find approximation for these numbers!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c44d2ad4caf652b1bbb51051f2c9c7bcf1a5a464729177adb4acb5f9fef7758-562ea39e40e7508487823a6e46bd20fdb361fe72fe1a6357a0703127e949d954.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polytope")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-531913")[#strong[#text("Polytope")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2019")])]

#text("Terry, could you provide an example showing an explicit construction of the extremal rays of the additive and multiplicative polytopes mentioned above")#linebreak()#text(" (say, for n=2)? Or a reference for the same?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-531918")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2019")])]

#text("For ")#mi("n=2")#text(" (and I think also ")#mi("n=3")#text(", though not for all ")#mi("n")#text(") all the extremal rays come from the cases when the matrices in question are simultaneously diagonalisable, and this should be computable by direct calculation (especially if one first normalises the matrices to have trace zero in the additive case, or determinant 1 in the multiplicative case).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c9d0afd7e80741d26c154be7fedf447a7cfac032e95209918c45d1ef5845352d-a7b7c0c3acee4e3027e89a8cb40753685810505c56a7ce9fbe7830ff1f3be127.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Intuition for torus")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-542622")[#strong[#text("Intuition for torus")]]#text(size: 9pt, fill: rgb("596477"), " · 29 February 2020")])]

#text("Terry, what’s the intuition behind why the quantum honeycomb is expected to live on a 2D torus?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a331617a2173f7ea2c61062fef4d0aa1057811cb5ce47017befc22455be024c-a49bb94c75b5a6bfc7b972009302332b5eadfd5807743521dcdc3325a9b055f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Q")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-605647")[#strong[#text("Q")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2020")])]

#text("“Littlewood-Richardson numbers that are computed by additive honeycombs have even been proposed to play a role in lower bounds in complexity theory, and specifically the P \\neq NP problem”. What is the exact role?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-605810")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2020")])]

#text("This is discussed in ")#link("https://arxiv.org/abs/cs/0501076")[#text("https://arxiv.org/abs/cs/0501076")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4cd0017271bbb29ae05f5b5a225f644511ad3edf9a9ebaa35f13283225e9f5c-90556bf81c15b68b76904c436bcab34f854e53c514c00a5ef7fb5583b8bd4019.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arulsaravana Jeyaraj")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-622016")[#strong[#text("Arulsaravana Jeyaraj")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2021")])]

#text("Professor Terence Tao:")

#text("GCT and algebraic complexity works at the non-boolean level.")

#text("Consider the problems:")

#text("1. Given an n x n 0/1 matrix M over integers what is the ith bit of determinant?")

#text("2. Given an n x n 0/1 matrix M over integers what is the ith bit of permanent?")

#text("I understand permanent over integers and determinant over integers have different invariants (permanent is invariant under permutations only) and I think that is what GCT is trying to capitalize on.")

#text("If the intention were to separate their complexities at the boolean level would the invariants be much different?")

#text("In other words if GCT is studying complexity in Boolean world would the objects of interest be any different? How would ‘Boolean GCT’ explain the following phenomenon for Least Significant Bit and Most Significant Bit? So perhaps there are things which should be considered in the program while dealing with Boolean complexity?")

#text("If i is the Least Significant Bit then by mechanics of being in F_2 and by Cook-Levin the boolean complexity is the same (the boolean circuit can be found in P). If i is the Most Significant Bit then by JSV (")#link("https://dl.acm.org/doi/10.1145/1008731.1008738")[#text("https://dl.acm.org/doi/10.1145/1008731.1008738")]#text(") algorithm and randomized algorithms being in P/poly there is a small boolean circuit which can be found in P by Cook-Levin under proper derandomization arguments.")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4cd0017271bbb29ae05f5b5a225f644511ad3edf9a9ebaa35f13283225e9f5c-90556bf81c15b68b76904c436bcab34f854e53c514c00a5ef7fb5583b8bd4019.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arulsaravana Jeyaraj")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-622017")[#strong[#text("Arulsaravana Jeyaraj")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2021")])]

#text("Since MSB position can be any value between 1 and \\lceil\\log_2 n!\\rceil it has to explain why it can extract ith bit bit position only when it is MSB.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4cd0017271bbb29ae05f5b5a225f644511ad3edf9a9ebaa35f13283225e9f5c-90556bf81c15b68b76904c436bcab34f854e53c514c00a5ef7fb5583b8bd4019.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arulsaravana Jeyaraj")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-629147")[#strong[#text("Arulsaravana Jeyaraj")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2021")])]

#text("JSV algorithm ")#link("http://www.cc.gatech.edu/~vigoda/Permanent.pdf")[#text("http://www.cc.gatech.edu/~vigoda/Permanent.pdf")]#text(" alone fails to guarantee BPTIME algorithm for MSB of permanent. However if the following is correct it might provide a BPTIME algorithm for MSB of 0/1 permanent under randomized self reducibility property of PP ")#link("https://lance.fortnow.com/papers/files/rsr.pdf")[#text("https://lance.fortnow.com/papers/files/rsr.pdf")]#text(".")

#text("Fix reals $a,b\\in(1,2)$ satisfying $1<b<a<ab<2$.")

#text("Is the fraction of $0/1$ matrices of dimensions $n\\times n$ have permanents in $[b2^m,a2^m]$ at some $m\\in\\{0,1,2,\\dots,\\lfloor\\log_2n!\\rfloor\\}$ at least $\\frac1{p(n)}$ at a fixed polynomial $p(n)$ whose coefficients and degree are independent of $n$?")

#text("It can validate statements similar to \"the fraction of permanents in (2^m, 2^(m+1)) having values in (b 2^m, a2^m) where b=1.01 and a=1.9 is Omega(2^m/poly(m))\".")

#text("In a sense is permanent of 0/1 matrices distributed approximately uniformly?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4cd0017271bbb29ae05f5b5a225f644511ad3edf9a9ebaa35f13283225e9f5c-90556bf81c15b68b76904c436bcab34f854e53c514c00a5ef7fb5583b8bd4019.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arulsaravana Jeyaraj")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-629166")[#strong[#text("Arulsaravana Jeyaraj")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2021")])]

#text("The consequence of a BPTIME algorithm for MSB would imply any explanation to separation Permanent from FP/poly would need to explain why Permanent does not have PTIME subtractive closure and nothing more while morally LSB and MSB are essentially equivalent in complexity (a pretty tricky and possibly impossible situation to overcome *within* the current consensus of things).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4cd0017271bbb29ae05f5b5a225f644511ad3edf9a9ebaa35f13283225e9f5c-90556bf81c15b68b76904c436bcab34f854e53c514c00a5ef7fb5583b8bd4019.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arulsaravana Jeyaraj")]], [#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/#comment-629282")[#strong[#text("Arulsaravana Jeyaraj")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2021")])]

#text("I think these simple tricks will not work.")
]
]
]
]
]
