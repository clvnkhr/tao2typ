// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/
// Converted to Typst by tao2typ: "2026-10-29T13:26:57.504560+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Joint Statement about Mathathon", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Joint Statement about Mathathon")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/")[#text("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-29 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by a coalition of Caltech mathematicians: the original organizers of Mathathon (Alvan Arulandu, Andrea Li, Avni Garg, Brian Zhao, Caiman Moreno-Earle, Sathvik Redrouthu), two coauthors of the Open Letter about the Mathathon (Dylan King, Tasmin Chu), and other members of the Caltech community (Mayla Ward, Merrick Hua, Robert Joseph George, Sergei Gukov, Shaowu Zhang, Tony Yue Yu, Vihaan Dheer). This blog post was initially written in a different file format and converted using AI. It is also crossposted at ")#link("https://proofsandprompts.com/2026/09/28/joint-statement-about-mathathon/")[#text("Proofs and Prompts")]#text("— T.]")]

#link("https://mathathonchallenge.com/")[#text("Mathathon")]#text(" is centered around one question: how can we use AI to augment human understanding of mathematics?")

#text("This past week, the original organizers of Mathathon, two coauthors of ")#link("https://proofsandprompts.com/2026/09/10/open-letter-about-the-mathathon/")[#text("an open letter about the mathathon")]#text(", and other members of the Caltech community engaged in a conversation to redesign this event. We quickly reached a consensus: problem solving is but one component of mathematics; mathematical understanding and exposition are similarly meaningful. But these components have often been overlooked by grantmakers and hiring committees. We want to celebrate human mathematicians who undertake this work.")

#text("Thus the new theme of Mathathon is ")#strong[#text("Old Problems, New Proofs")]#text(".")

#text("Consider the four color theorem, the ABC conjecture, or the Navier-Stokes problem. Many mathematicians find their proofs—or claimed proofs—difficult to understand or unsatisfying. We invite our participants to pick a problem with an unintuitive solution, learn as much as possible in 40 hours, and present their findings to their peers. Then, they will take two months to develop an alternative proof or exposition. Afterward, they’ll submit an explainer and a GitHub repository. The explainer can take any form: a paper, a blog post, a video, an interactive game, et cetera. The repository will store whatever was used to produce the explainer—LLM chat histories, code used to produce visualizations, and more—so the mathematics community can examine the ideas behind the finished product.")

#text("By shifting the focus from open problems, we want to encourage Mathathon participants to explore everything else we do to make sense of mathematics: generalizations, new notations and techniques, connections to other problems. These innovations can be more exciting than solving individual problems.")

#text("Mathathon treats AI as one of many tools available to mathematicians. We no longer receive sponsorships from developers of proprietary AI models. Participants are given a cash grant to purchase any tool they need, whether that be LLM credits, HPC access, or pen and paper. Proprietary models are allowed, but we encourage the use of open-source tools. Our goal is to empower each participant to make their own decision about the tools used at Mathathon and in their own work.")

#text("The new event will take place on November 13–15. It is co-organized with the ")#link("https://sair.foundation/")[#text("Foundation for Science and AI Research (SAIR)")]#text(", which will provide compute, host workshops, and offer prizes to teams that use open-source models. SAIR is also administering travel grants for participants. Our lead donor is ")#link("https://www.xtxmarkets.com/")[#text("XTX Markets")]#text(", an algorithmic trading firm and a major supporter of academic research, open-source infrastructure, and community-led initiatives in AI-for-math.")

#text("The organizers and advisors of Mathathon range from AI proponents to critics, from undergraduates to well-established mathematicians. Working with this group has been a learning experience for everyone involved. We hope that it will bring together a similarly diverse set of judges and participants.")

#text("If you want to deepen your understanding of math, we hope to see you at Mathathon. Our mission is for you to learn from and teach your peers.")

#text("If you want to have fun, we hope to see you at Mathathon. It’s still a student-led event, run with the same playfulness that first inspired it.")

#text("If you are curious about AI capabilities, we hope to see you at Mathathon. Finding alternative proofs to solved problems and presenting them in human-oriented ways is a novel challenge for LLMs.")

#text("If you are concerned about AI’s impact on mathematics, we hope to see you at Mathathon. It celebrates human-oriented expositions. Mathathon requires participants to fully disclose and justify LLM usage and asks them to consider whether smaller-scale open-source tools would suffice.")

#text("Finally, Mathathon isn’t a conclusive guide to AI in mathematics. The organizers hold different opinions about AI-assisted problem solving, open-source versus proprietary models, and more. But we all believe that mathematicians can use AI to advance human understanding. Mathathon is a first experiment. We want to pave the way for future initiatives that explore AI’s roles in learning, teaching, review, and research, while placing human understanding and community building at the forefront. Mathematics is undergoing its biggest change in decades, and we must work together to adapt.")

#emph[#text("Acknowledgements")]#text(". We are grateful to Terence Tao and Andrew Wu for reviewing this statement and leaving comments, as well as to countless others who offered feedback about Mathathon. All of the views above are solely our own and do not reflect those of Caltech or any other organizations we belong to.")

#heading(level: 1)[#text("Comments (36)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3a67e42ee6dddacfe12657ab6801ed29cd7965344c6646279b187c7b76fefcd-cebbe0226281f777dfd322b06ca6de71b1485abcc4c199db5f5e8d10bdec0816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696540")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("An interesting initiative. If I understand correctly the November event will be the second Mathathon. Where can I find reports on the first one?")

#text("By the way: The tentative initiatives to find out the best ways to use AI tools in math, resemble what happened in the 1990’s when chess programs conquered the world of human chess. One example, after Kasparov lost against Deep Blue II, he initiated an experiment called “Advanced Chess”. An exhibition match was played between Kasparov and strong grandmaster Topalov (in 1998). Each player was given access to one chess program on a fast desktop PC. The match ended 3-3 – and Kasparov’s interest in Advanced Chess vanished after that: He had hoped that also with computer help he would be stronger than Topalov. But it turned out that the computer use helped his weaker opponent at least as much as himself.")

#text("Regards, Ingo Althöfer.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696546")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("I think many people would disagree with the analogy that is being drawn in many online spaces between Chess and Mathematics. ")#linebreak()#text("Chess by itself is a competitive game. Mathematics **in principle** is not competitive. ")#linebreak()#text("Chess by itself is **in principle** finite. Mathematics is definitely not.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696558")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("if the finiteness of chess turned out to be even remotely relevant in any practical consideration (such as hitting the combinatorial limits and making the game an epsilon less challenging), it can be in no time in many natural ways extended to an infinite game (e.g., playing on an nxn grid). Hence, this is ** in principle ** a non-argument. Vice versa, for any practical consideration mathematics could be seen as as finite as the current chess. ")#linebreak()#text("Mathematics is of course highly competitive, it is just done (and “played”) in a very different way than chess")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/372f177f92f7e08fec9a48a6af42573abd0383e45830d7fa452d8e99a2070792-67d486836e16fcdb3639e81e048c521386ea6a1dfd0d5cefd418947f42c3f16b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jibalt")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696787")[#strong[#text("jibalt")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("There are on average 30 legal moves in a chess position. (With no previous promotions it’s at most 144.) There is no such limit in mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3a67e42ee6dddacfe12657ab6801ed29cd7965344c6646279b187c7b76fefcd-cebbe0226281f777dfd322b06ca6de71b1485abcc4c199db5f5e8d10bdec0816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696599")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("I am not proclaiming “full” analogy of the developments in Chess and Mathematics. What I wanted and want to say: In Chess (in the 90’s) suddenly strong computer programs were there and changed almost everything. That also led to an in-between phase where many new approaches were tried.")

#text("And in this year (in particular from July 2026 on) the AI tools (in particular ChatGPT 5.6 and Astra 6.0) are changing almost everything in the math scene. And we already see a phase where many mathematicans try many different ways to handle the new situation.")

#text("One reading hint: “From London to Elista” by chess grandmaster Evgenij Bareev and a co-author (old book from 2007). Bareev was assistant of Vladimir Kramnik in the World Chess Championship match 2000, where Kasparov was dethrowned. Kramnik was not really better in that year, but he used computer help (for preparation) more creatively than the title defender.")

#text("The book described what happened behind the curtains – including the problem with burn-outs because of using computer help too intensively (partly more than 20 hours per day). And then Kramnik motivated his assistants by simply commenting “you could do better”.")

#text("To switch to the math scene. That might be like a prof whose phd students are going for a proof of Riemann’s hypotheses. They report their findings to the boss, but he only says: “You could do better.” That would be terrible!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3a67e42ee6dddacfe12657ab6801ed29cd7965344c6646279b187c7b76fefcd-cebbe0226281f777dfd322b06ca6de71b1485abcc4c199db5f5e8d10bdec0816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696544")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("A second comment already, with a proposal for an ambitious project (perhaps a level too big for Mathathon): Create with AI-help a “nice” version of Mochizuki’s ABC-proof – or show that it has gaps or errors.")

#text("Ingo Althöfer.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696547")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("Since Mochizuki’s paper is wrong, that would be a waste of everyone’s time.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3a67e42ee6dddacfe12657ab6801ed29cd7965344c6646279b187c7b76fefcd-cebbe0226281f777dfd322b06ca6de71b1485abcc4c199db5f5e8d10bdec0816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696561")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("It is not that clear. Mochizuki is unwilling to give a better presentation of his “construction”. But Scholze and Stix are also not too detailed in their criticism. It would help to get better explanations “in between”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696562")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("Mochizuki’s paper is not even wrong. It is incomplete. There appears to be some workable ideas in his paper that should in principle be added to the pantheon of standard techniques in Diophantine geometry, but his cryptic writing has hardly helped his case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696571")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("There is already an ambitious project ongoing with a rather similar goal (writing a formal proof in Lean):")#linebreak()#link("https://zen.ac.jp/news/zmcpostevent0717e")[#text("https://zen.ac.jp/news/zmcpostevent0717e")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3a67e42ee6dddacfe12657ab6801ed29cd7965344c6646279b187c7b76fefcd-cebbe0226281f777dfd322b06ca6de71b1485abcc4c199db5f5e8d10bdec0816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696597")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("Thanks for the very interesting link. In particular the transcontinental character of the project: Utrecht (NL), University of Alberta (Canada) and Zen University (online, but with strong connections to Japan) looks promising. It would be nice to have also a chinese institution envolved, for simpler use of Chinese AI tools.")

#text("Are you in one of the partners involved? Feel free to conatct me via email.")

#text("Ingo Althöfer")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8e99f3194e5914ed3aee458223ea024d5ccb02a5348cb1032e587a9c0b6b532-3e98f05dc3656c82c7ba270e32137e369204af45a99e3d2fde0d811e7415bc56.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paata Ivanishvili")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696545")[#strong[#text("Paata Ivanishvili")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("Very nice. I think there are many ridiculously long proofs where we all had the feeling that there must be a cleaner and much better way to do it, but never had the time to sit down and play with the argument. With the help of AI, this kind of mathematical tinkering is now becoming much easier.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44bf5031049d5192a1b1328dd6966fc2abb2ae9fe787d1df6e13e9146830bd69-4cc48f08f617c08d4a44e28e074dcf63d45ece3bf0e7aed6e464ccdf55d58341.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gershb")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696551")[#strong[#text("gershb")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("Could we ask what proof would be easiest for a particular person to understand given their current knowledge and abilities? Could we ask what proofs might most useful to study to understand a group of theorems for a particular person? Could we ask what proofs would be useful for a particular person to contribute to study to contribute meaningfully to a particular field?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696552")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("I hope, this really helps for Maths community. Its hard to read so many published research papers on open problems by prompters. Proof is a way to reach a goal. If you reached a goal or not, it is not important but how you reached is most important thing. Its like, reaching a moon for the first time. I belive : If you can’t explain your proof or solution to high schoolers then how yourself understand it ? . So in Maths, there are multiple solution/proofs for same problem/theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75466c58a1d44368f62680173e0db2daac71b4602786cab257de2d23ab498b37-88faf38c0286a8da84d461505a72f2f41337b413cb821b50265c4232d0ec2961.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brianbeverly1")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696555")[#strong[#text("brianbeverly1")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("Alright, I will dust off my graph theory books and take a crack at the four color theorem. I’m sure the proof is some simple magic trick that will crack it open. The sixth time is the charm. Right?")

#link("https://giphy.com/gifs/91X2MlgF7dHsA")[#text("https://giphy.com/gifs/91X2MlgF7dHsA")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696590")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("I believe the idea is not that one must pick specifically from the problems described in the post, but rather that one can pick any problem that doesn’t currently have intuitive / easier-to-digest proofs.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696565")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("Hi, it’s right before the CVPR deadline. Do we really want to do this?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696568")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("This looks really exciting! Unfortunately, I’ll be heading to Neuroscience 2026 on the 14th, so the timing overlaps almost exactly. Would have loved to participate—hope there will be another one in the future!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696570")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("So glad to hear about this resolution. Great job guys!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c000c976e9f2517220ea22f1b7201afe5d14760940e77da961c896bfa32251ae-0f532b9815a92a2758d078870903e98ecbe946876ec0fc918ca484ef6a6428da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Asimov")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696572")[#strong[#text("Dan Asimov")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("I wonder whether it is accurate to say that what A.I. can contribute to mathematics can be described as “")#emph[#text("efficiently employing everything currently known to mathematics — but without coming up with any new ideas")]#text("“.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696610")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2026")])]

#text("“New ideas” are nearly all mix and match of old ideas, or old ideas tweaked a bit. It can also be placement, a known lemma or technique, but the newness is to choose to apply it in a particular proof. There is nothing preventing an LLM to produce one, and they do.")

#text("Moreover, there are sizes of ideas. An entire proof can be considered a large complex idea. A new proof is then a new idea.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696589")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("I applied to the Mathathon and I’m very disappointed by this turn of events. I understand some of the concerns in the letter, but one point really bothered me: saying that we cannot imagine a future where every mathematician gets $20,000 in AI credits. For me, this is exactly why the Mathathon was interesting.")

#text("I’m an early-career mathematician and I pay for my own AI subscriptions. I cannot afford to spend thousands of dollars testing these tools seriously on research problems. The Mathathon was a rare chance for people like me to try them at a scale that is normally impossible.")

#text("What is frustrating is that many of the people who signed the letter do have access to $20,000 in AI credits for a research problem. So stopping events like this feels like a way of slowing down other mathematicians from getting access to the same tools they already have. They can keep using these tools at scale, while younger mathematicians lose one of the few chances to do the same.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3a67e42ee6dddacfe12657ab6801ed29cd7965344c6646279b187c7b76fefcd-cebbe0226281f777dfd322b06ca6de71b1485abcc4c199db5f5e8d10bdec0816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696606")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2026")])]

#text("I think many of those who signed the open letter do not use AI-tools at all in their math.")

#text("What about this idea (meant for young people): Solve an interesting problem on small budget, and then find a sponsor who is willing to give you more money for larger problems? I know people who would be willing to become sponsor of this type.")

#text("Ingo Althöfer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696613")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2026")])]

#text("seems like you might have to end up using your brain to do math….")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696594")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("I hope this comment doesn’t make people upset but I think this is important to say.")

#text("Starting with the specifics of the mathathon restructuring and then some more general thoughts. Sharing my perspective as someone who went deep into math in undergrad and graduated recently:")

#text("It would simply be more fun to be going ham with an army of mathematical spidermonkey subagents, people (and machines) will ultimately do this even if it is not at the Caltech mathathon.")

#text("It is reasonable that there is some period of time given for the community to adapt but it must adapt.")

#text("I think a good heuristic is this: If the math community cannot handle/cope with an event, of the original formulation of the mathathon, taking place in one years time, then the human enterprise of mathematics will have proven itself incapable of adapting to our new world.")

#text("Seeing the way the community reacted to the original mathathon proposal showed just how fragile things are.")

#text("The way the math community looks to younger mathematicians (the reaction to the mathathon is a great example of this) is something like a child who’s friends have just eaten some really spicy food and are on the floor in pain and urging their friend to join them in eating the food.")

#text("If we are being honest with ourselves when a young person today decides to pursue mathematics as a profession they are forsaking all worldly concerns and taking a vow of celibacy to join some obscure priesthood.")

#text("I would wager that more than 90% or more of mathematicians today would NOT have gone along with this deal if they were asked to decide BEFORE they started in mathematics.")

#text("Once someone has been doing mathematics for awhile their response to the current situation, in my opinion, does not depend so much on their deep love for the field as it does their sense of sunk cost.")

#text("The unfortunate reality though is that many people will continue with mathematics not because they are genuinely ready to take on this immense burden and sacrifice but because they feel trapped and it is the easiest path in the short term.")

#text("I hate to say it but in aggregate math PhD students will probably net a negative return on their investment into mathematics, whatever that may mean, over the coming years.")

#text("There were already many cases before of people before that had “negative returns” on graduate studies but my guess is that now this will become by far the lion’s share of graduate students in mathematics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696614")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("people (and machines) will ultimately do this even if it is not at the Caltech mathathon.")
]

#text("Some people literally formed the AGMAI to prevent people and machines doing this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696616")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I hate to say it but in aggregate math PhD students will probably net a negative return on their investment into mathematics, whatever that may mean, over the coming years.")
]

#text("It is literally not a well thought out statement. On the average, if you are a talented graduate student e.g. with more than two publications, then there are a lot of companies which will try to hire you. ")#linebreak()#text("Mathematics training is not just learning about say modular forms or algebraic stacks, it’s also training problem solving at a very high level.")

#text("I can see that you don’t have much experience with graduate school in math, so I respectfully implore that you don’t make such blanket statements about people in grad schools. You have to understand that being in graduate school is not just a passage of time, it also trains you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696623")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("This supports the statement that is claimed to be not well thought out: with “problem solving” being delegated to the machines, being in graduate school will not be evaluated so high. It is now more likely to have a negative return on investing in math (except possibly at highly elite places).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696638")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("I think you are highly misinformed about what goes on in graduate school. Grad students don’t mindlessly problem solve say Hartshorne problems. There is a bit more involved in what goes into this.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696662")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("It is about research problems being solved by AI: if digestion/exposition will not be as enriching, then it is natural to expect a loss of interest in hiring math PhD graduates.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696604")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2026")])]

#text("I actually think it’s less good for the participants than the previous mathathon (but I guess it wasn’t changed to protect the participants or with the participants interests highest ….). However, if this is happening, I would personally love a more conceptual proof of Weil conjectures. But sorry to say I don’t believe that it will be produced from such a mathathon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9389b0903baff42e1216caa1cc14238150f0386ca59f70bf63ad04a0ed250311-8e3a338ceb506e63fc49fb49f74bc1a507a86b872de955c24785ce79b85d1eab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sagaistrue")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696620")[#strong[#text("sagaistrue")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2026")])]

#text("I strongly agree with the shift toward “Old Problems, New Proofs.” When single-domain tools approach discrete boundaries, they are often limited by an irremovable Gibbs freezing—this is the fundamental reason many extremal problems remain difficult to break through. Recently we attempted to step beyond single-domain limits and bypass function space search directly via cross-domain structures, obtaining the following numerical results: · Erdos overlap constant (C1b): upper bound 0.380422678, lower bound 0.380422666, interval compressed to the 10^-8 level, precision improved by a factor of 158,000 over existing methods. · Sidon autocorrelation constant (C1a): upper bound 1.502861497, matching the current best upper bound to 6 decimal places; lower bound pushed to 1.497138503, improving the existing lower bound (1.292) by two orders of magnitude. Detailed derivations and structural terminal criteria for five major problems (RH/GRH, generalized abc, P≠NP, BSD, and strong Goldbach) have been published on Zenodo. Link:")

#link("https://doi.org/10.5281/zenodo.22996536")[#text("https://doi.org/10.5281/zenodo.22996536")]

#text("Colleagues are welcome to verify and correct. sagaistrue")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3a67e42ee6dddacfe12657ab6801ed29cd7965344c6646279b187c7b76fefcd-cebbe0226281f777dfd322b06ca6de71b1485abcc4c199db5f5e8d10bdec0816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696645")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("Sounds interesting. Good luck!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9389b0903baff42e1216caa1cc14238150f0386ca59f70bf63ad04a0ed250311-8e3a338ceb506e63fc49fb49f74bc1a507a86b872de955c24785ce79b85d1eab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sagaistrue")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696687")[#strong[#text("sagaistrue")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("With gratitude for the blessing of an elder scholar, and with deep respect for a predecessor steeped in the Erdős tradition — with all reverence, sagaistrue.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9389b0903baff42e1216caa1cc14238150f0386ca59f70bf63ad04a0ed250311-8e3a338ceb506e63fc49fb49f74bc1a507a86b872de955c24785ce79b85d1eab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sagaistrue")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696729")[#strong[#text("sagaistrue")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("On “Old Problems, New Proofs”: I’ve been exploring a framework where 0, 1, 2 are superposition states. In this picture, multiplication has no independent ground — it is a projection of addition, and Euler’s identity e^(i*pi) + 1 = 0 is read as phase cancellation back to the zero-state. Golden iteration then yields a (6,5) integer resonance, with Pascal’s triangle as the shared source of row sums 2^n and diagonal sums G_n. Within this framework, G_1/G_0 = 1/0 is legalized: 0 is a free basis that can be taken as 1 when needed, so 1/0 = 1/1 = 1, serving as the first positioning of the negative probe. This is the structural starting point of the twelve-layer closure.")

#text("For Erdős Problem #1 (distinct subset sums), the known exact values are: 1, 2, 4, 7, 13, 24, 44, 84, 161, 309, 594 (OEIS A276661). The current lower bound is C(n, floor(n/2)), and the upper bound is Conway-Guy / Bohman. Our structure gives the overlay interval [5/16, 6/16] for n=6, with the (6,5) projection; the same nested construction yields n=11 value 594 without search, matching the Conway-Guy upper bound. By this structural criterion, the problem is resolved: the integer-level data are fully accounted for by the Pascal-triangle source and the (6,5) resonance.")

#text("Framework preprint: ")#link("https://doi.org/10.5281/zenodo.23112581")[#text("https://doi.org/10.5281/zenodo.23112581")]

#text("Erdős Problem #1 preprint:")#link("https://doi.org/10.5281/zenodo.21921944")[#text("https://doi.org/10.5281/zenodo.21921944")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/28/joint-statement-about-mathathon/comment-page-1/#comment-696812")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2026")])]

#text("No one ever stated whether one has to re-apply under the new terms. Or does the original application still hold?")
]
