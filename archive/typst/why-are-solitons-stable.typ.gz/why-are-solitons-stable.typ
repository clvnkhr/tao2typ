// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/
// Converted to Typst by tao2typ: "2026-10-14T06:53:17.638086+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Why are solitons stable?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Why are solitons stable?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 February 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/")[#text("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Last month, at the ")#link("http://www.ams.org/amsmtgs/2109_intro.html")[#text("joint AMS/MAA meeting")]#text(" in San Diego, I spoke at the ")#link("http://www.ams.org/amsmtgs/2109_program_tuesday.html#2109:BULLETIN")[#text("AMS “Current Events” Bulletin")]#text(" on the topic “")#link("http://arxiv.org/abs/0802.2408")[#text("Why are solitons stable?")]#text("“. This talk was supposed to be a survey of many of the developments on the rigorous stability theory of solitary waves in dispersive wave models (e.g. the ")#link("http://en.wikipedia.org/wiki/Korteweg%E2%80%93de_Vries_equation")[#text("Kortweg-de Vries equation ")]#text("and its ")#link("http://tosio.math.toronto.edu/wiki/index.php/KdV_equations")[#text("generalisations")]#text(", ")#link("http://tosio.math.toronto.edu/wiki/index.php/NLS_equation")[#text("nonlinear Schrödinger equations")]#text(", etc.), although my actual talk (which was the usual 50 minutes in length) only managed to cover about half of the material I had planned.")

#text("More recently, I completed the ")#link("http://arxiv.org/abs/0802.2408")[#text("article that accompanies the talk")]#text(", and which will be submitted to the Bulletin of the American Mathematical Society. In this paper I describe the key conflict in these wave models between ")#emph[#text("dispersion")]#text(" (the tendency of waves of differing frequency to move at different speeds, thus causing any localised wave to disperse in space over time) and ")#emph[#text("nonlinearity")]#text(" (which can cause any concentrated portion of the wave to self-amplify). Solitons seem to lie at the exact balancing point between these two forces, neither dispersing nor amplifying, but instead simply traveling at a constant velocity or oscillating in phase at a constant rate. In some cases, this balancing point is unstable; remove even a tiny amount of mass from the soliton and it eventually disperses completely into radiation, or one can add a tiny amount and cause the soliton to concentrate into a point and thence exhibit blowup in finite time. In other cases, the balancing point is stable; small perturbations to a soliton may end up changing the amplitude, position, and/or velocity of the soliton slightly, but the bulk of the solution still closely resembles a soliton in size, shape, and behaviour. Stability is sometimes enforced by linear properties, such as dispersive estimates or spectral properties of the linearised dynamics, but is also often enforced by nonlinear properties, such as nonlinear conservation laws, monotonicity formulae, and local propagation estimates for mass and energy (such as those provided by virial identities). The interplay between all these properties can be remarkably subtle, especially in the ")#emph[#text("critical")]#text(" case when a key conserved quantity is scale-invariant (thus leading to an additional degeneracy in the soliton manifold). This is particularly evident in the remarkable series of papers by Martel and Merle establishing various stability and blowup properties near the ground state soliton of the critical generalised KdV equation, which I spend some time discussing (without going into too many of the (quite numerous) technical details). The focus in my paper is primarily on the non-integrable case, in which the techniques are primarily analytic rather than algebraic or geometric.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/#comment-26410")[#strong[#text("This week in the arXivs… « It’s Equal, but It’s Different…")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2008")]

#text("[…] Why are solitons stable? […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e33f0cf3ff2cfacb48518ae3118e0675590728de2374757a47d0cc52a725fd30-3f1634f4a267d36824da021d5f9bb65e5601398c33b794515651a5165cc4235d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Weidig")]], [#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/#comment-26412")[#strong[#text("Tom Weidig")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2008")])]

#text("Hi,")

#text("You might be interested to know that there are also solitons that are stable due to their topology: topological solitons. Examples are the Sine-Gordon solitons, the 2D and 3D Skyrme solitons (Skyrmions), and the 3D Hopf solitons (Hopfions). All 2D and 3D models are non-integrable, and solutions can only be approximated or found by numerical minimization techniques of energy functionals like solving Euler-Lagrange equation or using simulated annealing. All these models are motivated by physics e.g. the 3D Skyrme as a model of the nucleus, and you get really beautiful pictures for the solitons with various topological charges, see for example:")#linebreak()#text(" ")#link("http://www.kent.ac.uk/ims/personal/pms4/ri.html")[#text("http://www.kent.ac.uk/ims/personal/pms4/ri.html")]

#text("And here is an introduction by myself, be warned it’s written by a physicist! :-)")

#link("http://arxiv.org/PS_cache/hep-th/pdf/9911/9911056v1.pdf")[#text("Click to access 9911056v1.pdf")]

#text("Best wishes,")#linebreak()#text(" Tom")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90c02f41607c68dc2bed941e13427d5caa05ebbef2fbcce8749d6ba70055a4a2-ba58d5187ecfe093fa29070570e91eae9d0d8a98aca2cf6ce452f53fa4647938.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/#comment-26417")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2008")])]

#text("Hi Terence,")#linebreak()#text(" The equation directly above (2.1) on page 8 seems to be mislabeled as a first-order equation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/#comment-26445")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2008")])]

#text("Thanks for the corrections and comments!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90c02f41607c68dc2bed941e13427d5caa05ebbef2fbcce8749d6ba70055a4a2-ba58d5187ecfe093fa29070570e91eae9d0d8a98aca2cf6ce452f53fa4647938.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/#comment-26456")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2008")])]

#text("Does anyone have any guesses as to what happens when two solitons of similar speed and width collide?")

#text("I was also intrigued by your mention of ‘excited’ soliton states with changes in sign. Does there exist some kind of spectrum of soliton solutions?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2158d5744d7f14c39f496c6df05751372a04da1eb8814ab2949a3e24171a37c-3d75a7dd66646c827fb34a7b9890d7d87716bbffbe363d8811913351e5396883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Riepe")]], [#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/#comment-26490")[#strong[#text("Thomas Riepe")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2008")])]

#text("Exist analogs in char p or local fields of solitons and their mathematics?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e33f0cf3ff2cfacb48518ae3118e0675590728de2374757a47d0cc52a725fd30-3f1634f4a267d36824da021d5f9bb65e5601398c33b794515651a5165cc4235d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Weidig")]], [#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/#comment-26491")[#strong[#text("Tom Weidig")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2008")])]

#text("Hi David,")

#text("well, I can tell you what happens with many topological solitons like 2D and 3D Skyrmions.")

#text("If they both have a positive topological charge, they scatter at a 90 degree angle: They first merge into an excited bound state and then the bound state splits into two. Though it depends at what speed they hit each other. If it is very slow, then they might stay in the bound state if it is energetically favorable. The same is true for 3D.")

#text("If they have exactly opposite topological charge, they merge and annihilate each other and create a lot of waves with zero topological charge.")

#text("The interesting thing is that 90 degree scattering and annihilation processes are typically quantum phenomena that these topological solitons exhibit, too. Some speculate that quantum mechanics is really just the fact that elementary particles are really solitons and neither waves nor particles. Though interesting, no-one has really written down a convincing and consistent theory. I should also mention that string theorists and quantum field theorists are also dealing with solitons.")

#text("Re 1D solitons, I think they mostly pass through each other.")

#text("Best wishes,")#linebreak()#text(" Tom")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/#comment-26501")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2008")])]

#text("Dear David,")

#text("For solitons in completely integrable models (e.g. KdV, 1D cubic NLS, sine-Gordon, …) what happens is that the solitons pass through each other, but they get shifted in location by the collision (though the velocity remains unchanged). For non-integrable models, the situation seems to be rather complicated; numerics suggest that one gets a wide range of behaviours ranging from integrable-type behaviour (possibly shedding a little bit of mass and energy as radiation) to total disruption into radiation. (Conceivably one can also get some sort of inelastic collision creating a single big soliton, though I don’t know if this has actually been observed numerically.)")

#text("Solitons can often be expressed as critical points of certain Lyapunov functionals (which typically are combinations of such conserved quantities as the mass and energy, the former of which can also be interpreted as a Lagrange multiplier). The ground state soliton tends to be the minimiser of such a functional, which tends to make it stable. But there are also excited states which correspond to non-minimising critical points. Typically there are a discrete set of these (modulo symmetries), and near each such soliton there are a finite number of unstable directions and a cofinite number of stable directions in which the dynamics can evolve. If one inserts a parameter into the nonlinearity and varies that parameter continuously, it is possible for some states to coalesce or branch; there are some interesting mathematical results analysing these sorts of things but I am not really an expert in these topics.")

#text("Dear Thomas,")

#text("That’s an interesting question; I don’t know of any really interesting analogues of nonlinear PDE phenomena in finite characteristic, though given how much algebraic structure there is in completely integrable systems such as KdV I would not be surprised if some version of complete integrability is meaningful in that setting. On the other hand, there are certainly discrete analogues of the KdV or NLS equations in which space (and sometimes time) is replaced with a discrete space such as ")#mi("{\\Bbb Z}")#text(", and then by restricting attention to spatially periodic solutions one can then study such evolutions on ")#mi("{\\Bbb Z}/p{\\Bbb Z}")#text(" for various p. But in all such situations, the solutions remain complex-valued or real-valued, so it is not a true finite characteristic ps ituation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd07d62ad540949ac63637d2625dc17824b4ff932850db5d1974afe371a5daf2-72e59304a8cde8af2b7caa9bd88bccc08b0b8a4f588f63708b2a2ffb96026884.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L")]], [#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/#comment-560016")[#strong[#text("L")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("Dear Professor Tao,")

#text("I ran into this old post and was wandering if you knew of any natural examples of nonlinear PDE’s where the resulting Soliton manifold is not a set of points after identifying gauge orbits (i.e like Galilean/Lorentzian transformations) or perhaps even topologically non-trivial after identification?")

#text("I have only seen this mentioned in passing in a paper by Akhmediev for non-linear optics but haven’t found an example.")

#text("Thank you for your time!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/#comment-560089")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("I would imagine that for a nonlinear Schrodinger or wave equation with a potential ")#mi("F(u)")#text(" that was not of power type (thus breaking scale invariance), one would obtain a one-parameter family of soliton solutions after quotienting out by the remaining symmetries (translation, Galilean, rotation etc.) since the dimension of the soliton manifold should not be expected to change even after breaking one of the symmetries.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2158d5744d7f14c39f496c6df05751372a04da1eb8814ab2949a3e24171a37c-3d75a7dd66646c827fb34a7b9890d7d87716bbffbe363d8811913351e5396883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Riepe")]], [#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/#comment-26645")[#strong[#text("Thomas Riepe")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2008")])]

#text("Dear Terence,")

#text("I just found some links mentioning such analogies of solitons:")#linebreak()#text(" ")#link("http://noncommutativegeometry.blogspot.com/2007/02/physics-in-finite-characteristic.html")[#text("http://noncommutativegeometry.blogspot.com/2007/02/physics-in-finite-characteristic.html")]#linebreak()#text(" Drinfelds construction is explained here:")

#link("http://www.uni-math.gwdg.de/wiedmann/Diss_Englisch/master.pdf")[#text("Click to access master.pdf")]

#text("a short notice:")

#link("http://www.ams.org/notices/200301/what-is.pdf")[#text("Click to access what-is.pdf")]

#text("Unfortunately I found the article by Mumford “An algebrao-geometric construction…” mentioned there not online. Do you know where to find it on the web?")

#text("Best,")#linebreak()#text(" Thomas")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of buffalo bizon")]], [#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/#comment-35791")[#strong[#text("buffalo bizon")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2009")])]

#text("Dear Weidig,")#linebreak()#text(" Are these stable: Gravitational solitons and the squashed 7-sphere,")#linebreak()#text(" Classical Quantum Gravity 24 (2007), no. 18.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dr twotwo")]], [#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/#comment-35808")[#strong[#text("dr twotwo")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("Hi Weidig,")#linebreak()#text(" 4th order KdV has a one-parameter family of solitons with radiating tails. How to choose the stable one?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of howdy serfaus")]], [#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/#comment-35884")[#strong[#text("howdy serfaus")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("Hi Thomas,")#linebreak()#text(" I wonder why physicists name some patterns as soliton-stripes. Probably because interfaces are joined by smooth layers. If you are interested in patterns, some of them are complicated, e.g., Deformations of the gyroid and lidinoid minimal surfaces, Pacific J. Math. 235 (2008), no. 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rational gamma")]], [#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/#comment-35904")[#strong[#text("rational gamma")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("Hi Thomas,")#linebreak()#text(" In char p no, in amonic groups yes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of scoopeer mvngsnds")]], [#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/#comment-35942")[#strong[#text("scoopeer mvngsnds")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2009")])]

#text("Hi Thomas,")#linebreak()#text(" Mumford’s forthcoming article is about sth else: apparently, Fitzhugh-Nagumo pulses have the symbol of a stable rhombic pattern, found recently (published in Phys. Rev. by some Koreans). Thus it is a minimizer of an unknown order variational thermodynamics functional, an extension of the Ginzburg-Landau one. I heard it will be presented in Canberra.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/#comment-459859")[#strong[#text("A sequence not found in the OEIS: part 3 | The indefinite, the definite, and so forth.")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2015")]

#text("[…] Inspired by this posting. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/#comment-489922")[#strong[#text("Everyday entropy: soliton – bonefactory")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2017")]

#text("[…] don’t create an observable interference pattern, they just appear as a larger individual. As Terry Tao describes them, “solitons lie at the exact balancing point between dispersion (the tendency of waves of […]")
]
