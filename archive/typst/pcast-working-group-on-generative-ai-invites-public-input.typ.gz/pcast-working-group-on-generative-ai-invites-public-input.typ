// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/
// Converted to Typst by tao2typ: "2026-10-14T16:39:06.641983+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "PCAST Working Group on Generative AI Invites Public Input", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("PCAST Working Group on Generative AI Invites Public Input")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 May 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/")[#text("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("As part of my duties on the ")#link("https://www.whitehouse.gov/pcast/")[#text("Presidential Council of Advisors on Science and Technology (PCAST)")]#text(", I am co-chairing (with ")#link("https://en.wikipedia.org/wiki/Laura_Greene_(physicist)")[#text("Laura Greene")]#text(") a ")#link("https://www.whitehouse.gov/pcast/briefing-room/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/")[#text("working group")]#text(" studying the impacts of ")#link("https://en.wikipedia.org/wiki/Generative_artificial_intelligence")[#text("generative artificial intelligence")]#text(" technology (which includes popular text-based ")#link("https://en.wikipedia.org/wiki/Large_language_model")[#text("large language models")]#text(" such as ChatGPT or ")#link("https://en.wikipedia.org/wiki/Diffusion_model")[#text("diffusion model")]#text(" image generators such as DALL-E 2 or Midjourney, as well as models for scientific applications such as protein design or weather prediction), both in science and in society more broadly. To this end, we will have public sessions on these topics during our ")#link("https://www.whitehouse.gov/pcast/meetings/2023-meetings/")[#text("PCAST meeting next week")]#text(" on ")#link("https://www.whitehouse.gov/wp-content/uploads/2023/05/PCAST-18-19-May-2023-Public-Agenda-updated-12MAY2023.pdf")[#text("Friday, May 19")]#text(", with presentations by the following speakers, followed by an extensive Q&A session:")

#list(
[#text("AI enabling science:")

#list(
[#link("https://en.wikipedia.org/wiki/Anima_Anandkumar")[#text("Anima Anandkumar")]#text(" (Caltech & NVIDIA)")],
[#link("https://en.wikipedia.org/wiki/Demis_Hassabis")[#text("Demis Hassabis")]#text(" (Deepmind)")],
[#link("https://en.wikipedia.org/wiki/Fei-Fei_Li")[#text("Fei-Fei Li")]#text(" (Stanford)")]
)],
[#text("AI and society:")

#list(
[#link("https://en.wikipedia.org/wiki/Sendhil_Mullainathan")[#text("Sendhil Mullainathan")]#text(" (Chicago)")],
[#link("https://en.wikipedia.org/wiki/Daron_Acemoglu")[#text("Daron Acemoglu")]#text(" (MIT)")],
[#link("https://en.wikipedia.org/wiki/Sarah_Kreps")[#text("Sarah Kreps")]#text(" (Cornell)")]
)]
)

#text("The event will be livestreamed on ")#link("https://www.whitehouse.gov/pcast/meetings/2023-meetings/")[#text("the PCAST meeting page")]#text(". I am personally very much looking forward to these sessions, as I believe they will be of broad public interest.")

#text("In parallel to this, our working group is ")#link("https://www.whitehouse.gov/pcast/briefing-room/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/")[#text("also soliciting public input")]#text(" for submissions from the public on how to identify and promote the beneficial deployment of generative AI, and on how best to mitigate risks. Our initial focus is on the challenging topic of how to detect, counteract, and mitigate AI-generated disinformation and “deepfakes”, without sacrificing the freedom of speech and public engagement with elected officials that is needed for a healthy democracy to function; in the future we may also issue further requests centered around other aspects of generative AI. Further details of our request, and how to prepare a submission, can be found ")#link("https://www.whitehouse.gov/pcast/briefing-room/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/")[#text("at this link")]#text(".")

#text("We also encourage submissions to some additional requests for input on AI-related topics by other agencies:")

#enum(start: 1, 
[#text("The ")#link("https://www.regulations.gov/document/OSTP_FRDOC_0001-0004")[#text("Office of Science Technology and Policy (OSTP) Request for Information")]#text(" on ")#link("https://www.whitehouse.gov/ostp/news-updates/2023/05/01/hearing-from-the-american-people-how-are-automated-tools-being-used-to-surveil-monitor-and-manage-workers/")[#text("how automated tools are being used to surveil, monitor, and manage workers")]#text(".")],
[#text("The ")#link("https://ntia.gov/issues/artificial-intelligence/request-for-comments")[#text("National Telecommunications and Information Administration (NTIA)")]#text(" request for comment on AI accountability policy.")]
)

#text("Readers who wish to know more about existing or ongoing federal AI policy efforts may also be interested in the following resources:")

#list(
[#text("The White House ")#link("https://www.whitehouse.gov/ostp/ai-bill-of-rights/")[#text("Blueprint for an AI Bill of Rights")]#text(" lays out core aspirational principles to guide the responsible design and deployment of AI technologies.")],
[#text("The National Institute of Standards and Technology (NIST) released the ")#link("https://www.nist.gov/itl/ai-risk-management-framework")[#text("AI Risk Management Framework")]#text(" to help organizations and individuals characterize and manage the potential risks of AI technologies.")],
[#text("Congress created the ")#link("https://nscai.gov/")[#text("National Security Commission on AI")]#text(", which studied opportunities and risks ahead and the importance of guiding the development of AI in accordance with American values around democracy and civil liberties.")],
[#text("The ")#link("https://www.ai.gov/")[#text("National Artificial Intelligence Initiative")]#text(" was launched to ensure U.S. leadership in the responsible development and deployment of trustworthy AI and support coordination of U.S. research, development, and demonstration of AI technologies across the Federal government.")],
[#text("In January 2023, the Congressionally mandated ")#link("https://www.nsf.gov/cise/national-ai.jsp")[#text("National AI Research Resource (NAIRR) Task Force")]#text(" released an implementation plan for providing computational, data, testbed, and software resources to AI researchers affiliated with U.S organizations.")]
)

#heading(level: 1)[#text("Comments (31)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-677939")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2023")])]

#text("It seems that AI-generated disinformation should be detected and counterreacted by “deeper AI”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aeb4b719ca739707f08fa774a58278e3f236a57a4b0eef32a2894fefcd41115e-883776a57fa1ebcbc3fb2ff6551fa00aefa38e3c65a9ce1bfe7cff0696a3f2e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sr Sidney Silva.")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-677940")[#strong[#text("Sr Sidney Silva.")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2023")])]

#text("Good evening, first of all thanks for the space: in my concept this Artificial Intelligence, you have to pay attention to the simplest information, such as: what impact will it have on human work? we still don’t have qualified people for this fact, to what extent is it safe? what is the danger of a Hacker entering and making a Tsunami within the information provided? Mr Sidney Silva")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71201f395df7767381e6f128fb702b6b806f8684a24a9f379cba33ba9c365fbe-44615daa6b4ed9c2ef237f863a907f77c1fe89e219bd8133ad8fcd03956ddad3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christopher")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-677942")[#strong[#text("Christopher")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2023")])]

#text("How will the Q&A work? YouTube comments?")

#emph[#text("[PCAST members will ask questions of the speakers. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678014")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2023")])]

#text("Does it mean public can only listen, maybe post comments on youtube, but not directly ask questions during the meeting?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71201f395df7767381e6f128fb702b6b806f8684a24a9f379cba33ba9c365fbe-44615daa6b4ed9c2ef237f863a907f77c1fe89e219bd8133ad8fcd03956ddad3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christopher")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-677943")[#strong[#text("Christopher")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2023")])]

#text("Oh and FYI, I shared this to the community blog LessWrong, where a lot of discussion about AI risk occurs: ")#link("https://www.lesswrong.com/posts/tC9NnWHNMN3wSNuXB/pcast-working-group-on-generative-ai-invites-public-input")[#text("https://www.lesswrong.com/posts/tC9NnWHNMN3wSNuXB/pcast-working-group-on-generative-ai-invites-public-input")]

#text("Note though that they typically discover more disputed forms of AI risk (specifically ")#link("https://en.wikipedia.org/wiki/Existential_risk_from_artificial_general_intelligence")[#text("existential risk")]#text("), so sorry in advance if you get any weird comments!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Crust")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678025")[#strong[#text("Crust")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2023")])]

#text("I didn’t come here via LessWrong, but I am interested to hear if Prof. Tao has any thoughts on extreme risks (up to and including existential risk) from future advanced AI, and how we might align future systems to reduce such risks.")

#text("Are you concerned that capabilities research is proceeding much faster than alignment research? Are there any approaches you think are promising? E.g. mechanistic interpretability (")#link("https://transformer-circuits.pub/2021/framework/index.html")[#text("e.g. work of Olah et al")]#text(")? Or “eliciting latent knowledge” (pursued by ")#link("https://www.alignment.org/theory/")[#text("Christiano et al")]#text(")? Or something else?")

#text("(To be clear, none of this is to deny that deep fakes and misinformation are an important problem that is already with us.)")

#emph[#text("[See ")#link("https://mathstodon.xyz/@tao/109978434783993774")[#text("https://mathstodon.xyz/@tao/109978434783993774")]#text(" for my response to a similar question – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-677945")[#strong[#text("PCAST Working Group Asks For Public Input On The Deployment Of Generative AI - AI Summary")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2023")]

#text("[…] Read the complete article at: terrytao.wordpress.com […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-677964")[#strong[#text("PCAST Working Group on Generative AI Invites Public Input – Full-Stack Feed")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2023")]

#text("[…] As part of my duties on the Presidential Council of Advisors on Science and Technology (PCAST), I am co-chairing (with Laura Greene) a working group studying the impacts of generative artificial in… Read more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b0d2e3d4354210235db09f6bedc9ac2ea8d1f51eb79a093c1ab7a92023165ec6-443f07a2f6c82047ba30b9e6d94149e063954496340dceac4b60d3bea68d0cfa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adannenberg")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678006")[#strong[#text("adannenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2023")])]

#text("What time?")

#emph[#text("[The schedule is available at ")#link("https://www.whitehouse.gov/wp-content/uploads/2023/05/PCAST-18-19-May-2023-Public-Agenda-updated-12MAY2023.pdf")[#text("https://www.whitehouse.gov/wp-content/uploads/2023/05/PCAST-18-19-May-2023-Public-Agenda-updated-12MAY2023.pdf")]#text(" -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678065")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2023")])]

#text("I just want to double check: the session begins 9am San Diego time, right, not Whitehouse time?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b0d2e3d4354210235db09f6bedc9ac2ea8d1f51eb79a093c1ab7a92023165ec6-443f07a2f6c82047ba30b9e6d94149e063954496340dceac4b60d3bea68d0cfa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adannenberg")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678066")[#strong[#text("adannenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2023")])]

#text("Yes, they updated the agenda to say so.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678045")[#strong[#text("PCAST生成AI工作组邀请公众参与！ - 偏执的码农")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2023")]

#text("[…] 详情参考 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678049")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2023")])]

#text("1. You already know the answer to that, don’t be coy.")

#text("2. That is clearly and necessarily only within the capacity of each and every such entity.")

#text("3. It takes one to know one.")

#text("4. That is a cornerstone of a representative democracy.")

#text("5. Make counterclaims.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71201f395df7767381e6f128fb702b6b806f8684a24a9f379cba33ba9c365fbe-44615daa6b4ed9c2ef237f863a907f77c1fe89e219bd8133ad8fcd03956ddad3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christopher")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678050")[#strong[#text("Christopher")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2023")])]

#text("I wonder if a more efficient way to collect input would be via mastodon/fediverse (in addition to email). That way the public input is more of a discussion instead of just throwing things into an inbox!")

#emph[#text("[My understanding is that such a mechanism would most likely not be in compliance with the record-keeping components of the ")#link("https://en.wikipedia.org/wiki/Federal_Advisory_Committee_Act")[#text("Federal Advisory Committee Act")]#text(" (FACA) and the ")#link("https://en.wikipedia.org/wiki/Freedom_of_Information_Act_(United_States)")[#text("Freedom of Information Act")]#text(" (FOIA). -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/570044150d90f16b29a8906a025b503d65d3e14a01875d7060feb010b2389eda-8889ae34c3458b08263a584cc4e3fede321bd8e83a5b6950c428b5dc9f3d5fd8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon Awbrey")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678057")[#strong[#text("Jon Awbrey")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2023")])]

#text("Terry,")

#text("I think a lot of people who’ve been working all along on AI, intelligent systems, and computational extensions of human capacities in general are a little distressed to see the field cornered and re-branded in the short-sighted, market-driven way we currently see.")

#text("The more fundamental problem I see here is the failure to grasp the nature of the task at hand, and this I attribute not to a program but to its developers.")

#text("Journalism, Research, and Scholarship are not matters of generating probable responses to prompts or other stimuli. What matters is producing evidentiary and logical supports for statements. That is the task requirement the developers of recent LLM‑Bots are failing to grasp.")

#text("There is nothing new about that failure. There is a long history of attempts to account for intelligence and indeed the workings of scientific inquiry based on the principles of associationism, behaviorism, connectionism, and theories of that order. But the relationship of empirical evidence, logical inference, and scientific information is more complex and intricate than is dreamt of in those reductive philosophies.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678059")[#strong[#text("Inquiry Into Inquiry • On Initiative 4 | Inquiry Into Inquiry")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2023")]

#text("[…] Re: Terry Tao • PCAST Working Group on Generative AI Invites Public Input […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678069")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2023")])]

#text("There will also be congressional hearings (at 10AM eastern tomorrow (Tuesday)) on related topics:")

#link("https://www.judiciary.senate.gov/committee-activity/hearings/oversight-of-ai-rules-for-artificial-intelligence")[#text("https://www.judiciary.senate.gov/committee-activity/hearings/oversight-of-ai-rules-for-artificial-intelligence")]

#link("https://www.hsgac.senate.gov/hearings/artificial-intelligence-in-government/")[#text("https://www.hsgac.senate.gov/hearings/artificial-intelligence-in-government/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678072")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2023")])]

#text("“disinformation” has been utterly abused by the left to mean anything with which they disagree.")

#text("You’re being used as a patsy in the ongoing war on freedom of speech.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arman")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678076")[#strong[#text("Arman")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2023")])]

#text("I knew U are in many fields i always liked Robotics my English is poor but i tend to get UR points)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678077")[#strong[#text("Terence Tao Leads White House's Generative AI Working Group While Fei-Fei Li Prepares for a Speech - Business Information For All Type Stuff")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2023")]

#text("[…] May 13th, Terence Tao, an award winning Australia-born Chinese mathematician, announced that he and physicist Laura Greene will co-chair a working group studying the impacts of generative […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678111")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2023")])]

#text("I think it’s important to look past ChatGPT/Midjourney and expect actual AI (the kind that solves open math problems, etc.) to appear soon. I hate that Sam Altman and Peter Thiel (I call the latter Lord Thieldemort) will be in charge of it. They were just in front of Congress saying the government should regulate AI to stop bad people from getting hold of it. But of course, they are pretty far up my list of bad people.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf0f4fe3d65881c1ad21d60ba0e774d589f6f787f894ab946103cf10365f226b-34b024389300d1880228e2e2ddde17baee90233e8d99d7bfa9da7957950def26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678227")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2023")])]

#text("Yes, they are bad bad people, unlike Harry Pottermous.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d227c8dbc8e85c5c02aa0438b9ff87ca0627b732756ca313c082af1eb6e149d-3db715ae62f0a02037eff1a19acf25ebacf4205ef88ff8f9517de25411108a49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Saul Youssef")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678146")[#strong[#text("Saul Youssef")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2023")])]

#text("Isn’t it obvious that in a world with AI, we need to cryptographically know where data is coming from? I think that the main solution to the AI problem is not in the field of AI, it is in basic crypto infrastructure. I’m concerned that this isn’t getting recognized and that part of the government has veered into the wrong strategic path for this to work out well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678199")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2023")])]

#text("We will certainly be looking at cryptographic provenance or identity authentication technologies (of which there are already several proposals, such as the ones from ")#link("https://c2pa.org/")[#text("C2PA")]#text(", ")#link("https://www.witness.org/")[#text("Witness")]#text(", ")#link("https://glaze.cs.uchicago.edu/")[#text("Glaze")]#text(", ")#link("https://worldcoin.org/blog/engineering/humanness-in-the-age-of-ai")[#text("Worldcoin")]#text(", and others) as one possible component of our recommendations, though personally I think that no single such technology will be a “silver bullet” solution to this problem, and must be supplemented by non-technological efforts as well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2c79f65f269626f64b7a6e8020f9b87d10938db1265ea5f50296a5a32438d46-8bb4e4e5fa76330835d5f6373bb50f7778ba9201935064e83e3bf11c244fa4e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of saulyoussef")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678212")[#strong[#text("saulyoussef")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2023")])]

#text("Thanks Terrence. I didn’t know about C2PA. It looks just like what I was hoping for. I’m sure that there is no silver bullet, but I do think that this is the #1 most important thing to get right. It’s an area where government can really help and it could IMO have a huge positive impact on society.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678198")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2023")])]

#text("Video of our meeting is now available at ")#link("https://www.youtube.com/watch?v=gZb7Yr4C8po")[#text("https://www.youtube.com/watch?v=gZb7Yr4C8po")]#text(" . The slides will also be made available in a few days. Note that submissions to the working group are independent of this public session, and will continue to be accepted over the next few months at least.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678261")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2023")])]

#text("The White House Office of Science Technology and Policy (OSTP) has issued yesterday a ")#link("https://www.whitehouse.gov/wp-content/uploads/2023/05/OSTP-Request-for-Information-National-Priorities-for-Artificial-Intelligence.pdf")[#text("broader request for information (RFI)")]#text(" for public comments to help update U.S. national priorities and future actions on AI, with submissions accepted until July 7. This is a separate process from PCAST’s ")#link("https://www.whitehouse.gov/pcast/briefing-room/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/")[#text("request for public input")]#text(" (which is not a formal RFI and therefore subject to fewer restrictions).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e69999ad1da0629edabf903e27854fa9e896341fce7a882a18311409c8ff6b32-763fdb2809bb086aeb2834fd59991f22c91303c10701d621ab11d5ab8dc61db3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of BJ")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678338")[#strong[#text("BJ")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2023")])]

#text("Speaking of disinformation, your banner is a case in point. Birx and Fauci have admitted (more like “boasted”) that “two weeks to flatten the curve” was always intended to be the thin end of the wedge for far more draconian lockdowns.")

#text("Lockdowns that quarantined the healthy and intentionally infected the elderly by forcing covid-positive nursing home patients back into their long-term-care facilities.")

#text("Any questioning of such insane policies was labeled “disinformation” or worse.")

#text("“Disinformation” is purely and simply a mechanism for western governments to institute soviet-style speech controls.")

#text("By supporting these efforts, you’re on the side of evil, Terry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/113e68e1b26086e713a32f3b6e12e5c5bb6aefbc5e83b33e844543a692540700-53f8dc03506cd655d2454b0ac53923f5f222165a3299587c47173ec3a8fa4532.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Brav")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678406")[#strong[#text("Chris Brav")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2023")])]

#text("The point has already been made, but worth making again: there is an easy off-the-shelf solution to the problem of deep-fakes, namely cryptographic water-marking.")

#text("As for a healthy democracy, how’s that working out for you?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ad8d2b31129be2d46a49c4d859849816531ab07b34bf5723f53ed41d55cb1c5-9f67c8d9b173176ebea068494bf20d166e94d2019df8212390edcaf1f54dffe3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678442")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2023")])]

#text("“without sacrificing the freedom of speech and public engagement with elected officials that is needed for a healthy democracy to function”")

#text("I am more concerned about the unelected officials. The Deep State that believes they’re the rightful rulers of the country. The Deep State loves their scientific “advisory” boards that serve as rubber-stamps for oppressive policies.")

#text("BTW, I watched the video of the meeting. It would be hilarious and pathetic if it wasn’t so disturbing. A bunch of seriously lame academics — whose only claim to authority is specialization from cradle to now in their esoteric fields — arrogating themselves policy-making credentials over the rest of us.")

#text("More Deep-State trash.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/#comment-678524")[#strong[#text("Some interesting things I’ve read recently (June 2023 Week 1) – Jinjie's Notes")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2023")]

#text("[…] PCAST Working Group on Generative AI Invites Public Input […]")
]
