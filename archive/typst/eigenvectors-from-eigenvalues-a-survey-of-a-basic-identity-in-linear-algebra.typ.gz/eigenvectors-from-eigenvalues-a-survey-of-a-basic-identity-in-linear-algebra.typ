// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/
// Converted to Typst by tao2typ: "2026-10-14T15:20:22.255956+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Eigenvectors from Eigenvalues: a survey of a basic identity in linear algebra", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Eigenvectors from Eigenvalues: a survey of a basic identity in linear algebra")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 December 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/")[#text("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://peterdenton.github.io/")[#text("Peter Denton")]#text(", ")#link("https://home.fnal.gov/~parke/")[#text("Stephen Parke")]#text(", ")#link("https://physics.uchicago.edu/people/profile/xining-zhang/")[#text("Xining Zhang")]#text(", and I have just uploaded to the arXiv a completely rewritten version of ")#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues")[#text("our previous paper")]#text(", now titled “")#link("https://arxiv.org/abs/1908.03795")[#text("Eigenvectors from Eigenvalues: a survey of a basic identity in linear algebra")]#text("“. This paper is now a survey of the various literature surrounding the following basic identity in linear algebra, which we propose to call the ")#emph[#text("eigenvector-eigenvalue identity")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Eigenvector-eigenvalue identity)")]#text(" ")#metadata(none) <tao-69f5e8a085c0a76dac81>#text(" Let ")#mi("{A}")#text(" be an ")#mi("{n \\times n}")#text(" Hermitian matrix, with eigenvalues ")#mi("{\\lambda_1(A),\\dots,\\lambda_n(A)}")#text(". Let ")#mi("{v_i}")#text(" be a unit eigenvector corresponding to the eigenvalue ")#mi("{\\lambda_i(A)}")#text(", and let ")#mi("{v_{i,j}}")#text(" be the ")#mi("{j^{th}}")#text(" component of ")#mi("{v_i}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\left|v_{i,j}\\right|^2 \\prod_{k=1; k \\neq i}^n (\\lambda_i(A) - \\lambda_k(A)) = \\prod_{k=1}^{n-1} (\\lambda_i(A) - \\lambda_k(M_j))", block: true)]]

#text("where ")#mi("{M_j}")#text(" is the ")#mi("{n-1 \\times n-1}")#text(" Hermitian matrix formed by deleting the ")#mi("{j^{th}}")#text(" row and column from ")#mi("{A}")#text(".")
]

#text("When we posted the ")#link("https://arxiv.org/abs/1908.03795v1")[#text("first version of this paper")]#text(", we were unaware of previous appearances of this identity in the literature; a related identity had been used ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2810797")[#text("by Erdos-Schlein-Yau")]#text(" and ")#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/")[#text("by myself and Van Vu")]#text(" for applications to random matrix theory, but to our knowledge this specific identity appeared to be new. Even two months after our preprint first appeared on the arXiv in August, we had only learned of one other place in the literature where the identity showed up (")#link("https://arxiv.org/abs/1905.05314")[#text("by Forrester and Zhang")]#text(", who also cite an earlier ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1818248")[#text("paper of Baryshnikov")]#text(").")

#text("The situation changed rather dramatically with the publication of ")#link("https://www.quantamagazine.org/neutrinos-lead-to-unexpected-discovery-in-basic-math-20191113/")[#text("a popular science article in Quanta")]#text(" on this identity in November, which gave this result significantly more exposure. Within a few weeks we became informed (through private communication, online discussion, and exploration of the citation tree around the references we were alerted to) of over three dozen places where the identity, or some other closely related identity, had previously appeared in the literature, in such areas as numerical linear algebra, various aspects of graph theory (graph reconstruction, chemical graph theory, and walks on graphs), inverse eigenvalue problems, random matrix theory, and neutrino physics. As a consequence, we have decided to completely rewrite our article in order to collate this crowdsourced information, and survey the history of this identity, all the known proofs (we collect seven distinct ways to prove the identity (or generalisations thereof)), and all the applications of it that we are currently aware of. The citation graph of the literature that this ")#emph[#text("ad hoc")]#text(" crowdsourcing effort produced is only very weakly connected, which we found surprising:")

#image("../assets/d1080b22f6a0b4d1848f329166b1c2234fd9e36a3ea4e1714b9ab7f9fed130aa-cd2ff5b139c3e7b9c6c38917930817a1e593dc36c415e4aa170379df7d02f788.png", width: 90%)

#text("The earliest explicit appearance of the eigenvector-eigenvalue identity we are now aware of is in a ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=190151")[#text("1966 paper of Thompson")]#text(", although this paper is only cited (directly or indirectly) by a fraction of the known literature, and also there is a precursor ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1545446")[#text("identity of Löwner")]#text(" from 1934 that can be shown to imply the identity as a limiting case. At the end of the paper we speculate on some possible reasons why this identity only achieved a modest amount of recognition and dissemination prior to the November 2019 Quanta article.")

#heading(level: 1)[#text("Comments (41)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531064")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2019")])]

#text("in page 9, remark 7, the name is Aram not Adam.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d28195df14800315168ea974f4adf888eace7d3a34fc83513af492698793a2c-e2ad3cdfa379c5dcf139408dc5d555ac7c236dfa87abd3799a789b51ef5d74f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kodlu")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531067")[#strong[#text("kodlu")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2019")])]

#text("A commendable effort to bring all these related identities together.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d28195df14800315168ea974f4adf888eace7d3a34fc83513af492698793a2c-e2ad3cdfa379c5dcf139408dc5d555ac7c236dfa87abd3799a789b51ef5d74f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kodlu")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531069")[#strong[#text("kodlu")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2019")])]

#text("Is there supposed to be an image (of a graph) after “The citation graph of the literature that this ad hoc crowdsourcing effort produced is only very weakly connected, which we found surprising:”")

#text("All that is visible in my browser is “???”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531073")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2019")])]

#text("Really cool! Congratulations, I like that you mention chemical GT and the citation graph really rocks. I will consider something like that for my publications in similar cases (minireview by rediscovery) as well!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bd3c8cfa4f6bb8b34059d2fddd33c3319017ad4b38145ee9a23e236780c6092-6723b66ac6782aa36eeefcb3c4886f14146b0a69f69168c8350119d772b8a747.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531099")[#strong[#text("L")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2019")])]

#text("Do $PI$-algebras have application to this and vice versa?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/202ddfca269a36f903ca88cfbce5d66e94df2cf32cd7ecd9f4b6cf4f63df6488-57371a1b9029cf83f03fae14bb0450d41984e043bbe151e6b3b6cfe74c04c3c7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jochen Voss")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531119")[#strong[#text("Jochen Voss")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2019")])]

#text("The Karl Löwner (1934) references in the article on arXiv is shortened to LӞ4, which looks odd. Probably the surname should be spelled L{\\”o}wner instead of L\\”owner in bibtex?")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b1ab7048ee12d8e9baf408fcb4b79428e4eb885ec4e6ef3928b691a09746391-48442f637db4971d3ee8d2173da0bbc67116904b8b850a56c97c2fbd27bbabf3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 3 GiftedNova")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531150")[#strong[#text("3 GiftedNova")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2019")])]

#text("Is this an accidental calculation on how neutrinos change resulting in the formula or theorem describing the relationship between eigenvectors and eigenvalues")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531159")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2019")])]

#text("This is truly a service to the scientific community. Linear algebra, being as it is central to an extremely broad swath of fields of pure and applied mathematics, seems especially prone to this sort of independent rediscovery of useful facts that lie just a bit beyond the level of introductory textbooks. I wasn’t at all surprised by the tree-like nature of the citation graph.")

#text("Although it’s not quite the same phenomenon, I was reminded of a talk I heard Barry Simon give (see e.g. ")#link("https://web.math.princeton.edu/~irod/Simon.html")[#text("here")]#text(") on a widely unnoticed proof of the main result from the same paper of Löwner that you mentioned.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531209")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2019")])]

#text("Another example is Heegner’s solution (from 1952) of the class number 1 problem (which unfortunately remained unnoticed for more a decade)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531162")[#strong[#text("[Terence Tao's blog] Eigenvectors from Eigenvalues: a survey of a basic identity in linear algebra - Nevin Manimala's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2019")]

#text("[…] by /u/Valvino [link] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db070355fdb640ad2c7e83f2901c04633b4e24c7b6e1d2ee2589133350895006-f9da2e26c1544e14f1a4e3e3f414c5d1d407558530a6ed84bd66e870340def56.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Krause")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531168")[#strong[#text("Andrew Krause")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2019")])]

#text("I especially enjoyed the sociology of science of all of this. I constantly feel that there must be better ways to organize the enormous enterprise that is research mathematics, but any such organization will undoubtedly have flaws.")

#text("A few typos involving repeated words in the preprint: “for for” appears at the end of Section 5, and “the the” at the end of Section 4.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63c5e3d164b60dbf2c30b341adc5ad73b787518ecb74470ab6a00431ab9dc71a-de3e719e9960b0a44f0116a1201823a8b5ddfd465aacf6c51ba7363425eb9495.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuyao")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531174")[#strong[#text("liuyao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2019")])]

#text("A small complaint: the formula is only useful when lambda_i is simple (or else both sides vanish, by Cauchy interlacing), so why not just write it in quotient form? (The only argument may be that the identity does not rely on Cauchy interlacing.)")

#text("Also, what is the current state for “fingerprint databases for mathematical theorems”? The paper [BT13] dates from 2013, and one could at least add ")#link("https://www.lmfdb.org/")[#text("https://www.lmfdb.org/")]#text(" to the list.")

#text("Not entirely the same, but getting the *statements* in (one agreed-on) proof assistant could be an important step: ")#link("https://formalabstracts.github.io/")[#text("https://formalabstracts.github.io/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531180")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2019")])]

#text("The non-quotiented form has the advantage of being valid for all diagonalizable matrices taking values in an arbitrary commutative ring (not just real or complex numbers), as it avoids any requirement of invertibility of any of the quantities involved. (For this generalization one needs to distinguish the left eigenvectors from the right eigenvectors, see equation (11) in the new version of the paper.) There are also variants of the identity that are non-degenerate in the case of multiple eigenvalues; see for instance (15) of the new version of the paper.")

#text("The non-quotiented form also has a slightly non-trivial corollary: if ")#mi("\\lambda_i(A)")#text(" lies in the spectrum of ")#mi("M_j")#text(", then either ")#mi("v_{i,j}")#text(" vanishes or ")#mi("\\lambda_i(A)")#text(" is a repeated eigenvalue. I don’t know of a short direct way to see this implication (although the converse implications are not difficult, see consistency checks (iv), (v) in the new version of the paper).")

#text("Unfortunately I do not know of any followup work to [BT13], but perhaps there are other readers of this blog who may be aware of more recent developments in this area.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1317930224c989a36483ebce90860cad96fa152dc396368fee6cb656e9f57062-832304657d5f3e0bf369e8d0d39768d9d490ab6c91f2d110c09b285b068e8b0e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristoffer Varholm")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531222")[#strong[#text("Kristoffer Varholm")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2019")])]

#text("There is a typo on the first line of page 7. Eigenvectors should be eigen_values_.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531234")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2019")])]

#text("Typo, penultimate sentence: “…we are not able to guarantee that there is *not* an even earlier reference in the literature…”")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d5f02c7347a4e573f77b482157b09a9a490cf59f7460d5c188f5fbfa02601a90-2b8fe8e966be9de09f4a2498b6585f2963fbed7ab88cee0a3e660282cdc211ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531237")[#strong[#text("Max")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2019")])]

#text("The meaning of $\\lambda_k(M_j)$ seems quite obscure to me. For a matrix $B = M_j$ different from A, $\\lambda_k(B)$ is just any of the eigenvalues of B (and in addition you have a different B for each j). These are a priori totally unrelated with the { \\lambda_k(A) }, even the range of the indices is not the same since the size of B is not that of A.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d5f02c7347a4e573f77b482157b09a9a490cf59f7460d5c188f5fbfa02601a90-2b8fe8e966be9de09f4a2498b6585f2963fbed7ab88cee0a3e660282cdc211ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531239")[#strong[#text("Max")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2019")])]

#text("Oops, sorry, please ignore the comment, I now understand that the product is taken over all n-1 eigenvalues of M_j, so it does not matter in which order they are taken. (Yet \\lambda_k(M_j) is still ill defined /per se/ and a notation like $\\prod_{\\mu \\in \\spec M_j} …$ would IMHO be less confusing.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531482")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2019")])]

#text("Dear Pro.Tao,")#linebreak()#text(" We always trust your ability in solving a famous problem which was 3 centuries ago. Nearly end the year. Super speed! Come on! Only Sir understands our crazy comments! Sweet fruits are waiting for you after you spend a lot of time care , water, fertilizer your lovely tree.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Jones")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531562")[#strong[#text("Alex Jones")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2019")])]

#text("Terry, with all due respect, may I ask why you were an author on the previous paper? I feel like there is a big “P vs NP” phenomenon going on with this identity. I think the big achievement (I’m tempted to say the “sole achievement”) is *finding* the identity rather than proving it once provided. I think you should have been thanked in the acknowledgments section rather than have been a coauthor.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531686")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2019")])]

#text("There are two previous papers, listed as [DPZ19] and [DPTZ19] in the references to the current version. [DPZ19] is where the identity was (once again) discovered but not proven; I am not an author of that paper. The now-superseded preprint [DPTZ19] consists of little more than two proofs of the identity, which I provided. (One of these proofs we now know to have been discovered multiple times already in the literature, but the other proof appears to be new.)")

#text("The four of us did discuss whether to instead add an appendix to [DPZ19] containing at least one of the proofs, but eventually decided on a standalone preprint to draw attention on the identity outside of the neutrino physics community. Needless to say this goal was achieved to a somewhat greater extent than we expected.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1fd163582463874953a5a0c58cd499767eacc316653e9be898b3cd2dcff5ca7f-713496f4cf9857e0e1e425024df1a6e188ccb748f04e60937dc4a074fe2e7c02.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stephen Parke")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531733")[#strong[#text("Stephen Parke")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2019")])]

#text("As P of [DPZ19] and [DPTZ19], I fully concur with TT response to this comment.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531594")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2019")])]

#text("By n-1 th symmetric function you probably meant the n-1 th elementary symmetric function on page 4.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf439e996e29d20cb552d68ffe9f964d8919f4f9773b9c41c886fb326a5a9695-66573747b7b50dc2532a1c1acd7e23c9482f9aeb4a00f437399c08ade2278ee3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aquazorcarson")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531770")[#strong[#text("aquazorcarson")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2019")])]

#text("Also the summation is perhaps a product on the next line. Nice observation by the way.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/251d74bd08278fbf4f394dfbcfabbf86e4effd495eb043ad0ace5b24bc07b765-27f751079643bf0502b46779750cb5e4843b60f0323db961d7e966a276cb7589.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Darij Grinberg")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531597")[#strong[#text("Darij Grinberg")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2019")])]

#text("Kudos for doing the thankless literature review work everyone has been shying away from. Everyone knows the linear algebra literature is self-similar like a fractal, but actually playing the memory game is not something people usually find the stomach for.")

#text("A trivial typo: “Sbastien” -> “Sébastien” in [GKV]. This is likely a mojibake issue in your bibliography.")

#text("Anyway, here is another proof of the result, which I believe to be more general than the ones in the paper, as it uses neither the base field being a field (let alone the complex numbers), nor diagonalization (only an eigenvector of ")#mi("A")#text(" and one of ")#mi("A^T")#text("), nor any sort of normality. (Feel free to include it!)")

#text("Here is the general form that I’ll be proving:")

#text("=== BEGIN THEOREM ===")

#strong[#text("THEOREM 1")]#text(": Let ")#mi("R")#text(" be a commutative ring. Let ")#mi("A")#text(" be an ")#mi("n")#text("-by-")#mi("n")#text("-matrix over ")#mi("R")#text(". Let ")#mi("\\lambda \\in R")#text(". Let ")#mi("v = (v_1, v_2, \\dots, v_n)^T")#text(" and ")#mi("w = (w_1, w_2, \\dots, w_n)^T")#text(" be two column vectors in ")#mi("R^n")#text(" such that ")#mi("Av = \\lambda v")#text(" and ")#mi("w^T A = \\lambda w^T")#text(". Fix ")#mi("j \\in \\{1, 2, \\dots, n\\}")#text(", and let M_j be the ")#mi("(n-1)")#text("-by-")#mi("(n-1)")#text("-matrix obtained from ")#mi("A")#text(" by removing row ")#mi("j")#text(" and column ")#mi("j")#text(". Then,")

#mi("\\displaystyle v_j w_j p_A^{\\prime}(\\lambda) = (w^T v) p_{M_j}(\\lambda).")

#text("Here, ")#mi("p_S")#text(" denotes the characteristic polynomial of a matrix ")#mi("S")#text(".")

#text("=== END THEOREM ===")

#text("This is probably closest to the equality (4) in arXiv:1908.03795v2, but the use of ")#mi("v")#text(" and ")#mi("w")#text(" (as opposed to a single ")#mi("v")#text(") is from Remark 4. The eigenvectors ")#mi("v")#text(" and ")#mi("w")#text(" are not connected to each other apart from corresponding to the same eigenvalue; but there is a fudge factor ")#mi("w^T v")#text(" on the right hand side that ensures homogeneity of the equality.")

#text("The first step to proving Theorem 1 is to simplify it a lot by replacing ")#mi("A")#text(" by ")#mi("A - \\lambda I")#text(". (Not my idea; you do the same in the last paragraph of §2.5.) Thus, Theorem 1 reduces to the following simpler fact:")

#text("=== BEGIN THEOREM ===")

#strong[#text("THEOREM 2")]#text(": Let ")#mi("R")#text(" be a commutative ring. Let ")#mi("A")#text(" be an ")#mi("n")#text("-by-")#mi("n")#text("-matrix over ")#mi("R")#text(". Let ")#mi("v = (v_1, v_2, \\dots, v_n)^T")#text(" and ")#mi("w = (w_1, w_2, \\dots, w_n)^T")#text(" be two column vectors in ")#mi("R^n")#text(" such that ")#mi("Av = 0")#text(" and ")#mi("w^T A = 0")#text(". Fix ")#mi("j \\in \\{1, 2, \\dots, n\\}")#text(". For each ")#mi("k \\in \\{1, 2, \\dots, n\\}")#text(", let ")#mi("M_k")#text(" be the ")#mi("(n-1)")#text("-by-")#mi("(n-1)")#text("-matrix obtained from ")#mi("A")#text(" by removing row ")#mi("k")#text(" and column ")#mi("k")#text(". Then,")

#mi("\\displaystyle v_j w_j \\sum_{k=1}^n \\det(M_k) = (w^T v) \\det(M_j).")

#text("=== END THEOREM ===")

#text("This is what Theorem 1 boils down to after replacing ")#mi("A")#text(" by ")#mi("A - \\lambda I")#text(", because ")#mi("p_A^{\\prime}(0) = \\sum_{k=1}^n \\det(M_k)")#text(".")

#text("Here is the first lemma that we will use to prove this:")

#text("=== BEGIN LEMMA ===")

#strong[#text("LEMMA 3:")]#text(" Let ")#mi("R")#text(" be a commutative ring. Let ")#mi("A")#text(" be an ")#mi("n")#text("-by-")#mi("n")#text("-matrix over ")#mi("R")#text(". Let ")#mi("w = (w_1, w_2, \\dots, w_n)^T")#text(" be a column vector in ")#mi("R^n")#text(" such that ")#mi("w^T A = 0")#text(". Fix ")#mi("j, k \\in \\{1, 2, \\dots, n\\}")#text(". Then,")

#mi("w_j (\\mathrm{adj} A)_{i, k} = w_k (\\mathrm{adj} A)_{i, j}")

#text("for every ")#mi("i \\in \\left\\{ 1,2,\\ldots,n \\right\\}")#text(".")

#text("=== END LEMMA ===")

#text("Here, ")#mi("U_{i, j}")#text(" denotes the ")#mi("(i, j)")#text("-th entry of a matrix ")#mi("U")#text(".")

#strong[#text("PROOF OF LEMMA 3:")]#text(" Let ")#mi("B")#text(" be the ")#mi("n")#text("-by-")#mi("n")#text(" matrix obtained from ")#mi("A")#text(" by multiplying the ")#mi("j")#text("-th row by ")#mi("w_j")#text(" and multiplying the ")#mi("k")#text("-th row by ")#mi("w_k")#text(". It is thus easy to see that")

#mi("w_j (\\mathrm{adj} A)_{i, k} = (\\mathrm{adj} B)_{i, k}")

#text("and")

#mi("w_k (\\mathrm{adj} A)_{i, j} = (\\mathrm{adj} B)_{i, j}.")

#text("Hence, it remains to prove that ")#mi("(\\mathrm{adj} B)_{i, k} = (\\mathrm{adj} B)_{i, j}")#text(".")

#text("But we assumed ")#mi("w^T A = 0")#text(", so that")

#mi("0 = w^T A = w_1 (\\text{1-st row of } A) + w_2 (\\text{2-nd row of } A) + \\dots + w_n (\\text{n-th row of } A).")

#text("Thus, ")#mi("w_j (\\text{j-th row of }A) + w_k (\\text{k-th row of }A)")#text(" is a linear combination of the remaining rows of ")#mi("A")#text(". In view of how ")#mi("B")#text(" was defined, we can rewrite this as follows: ")#mi("(\\text{j-th row of } B) + (\\text{k-th row of } B)")#text(" is a linear combination of the remaining rows of ")#mi("B")#text(". From this, it is easy to derive that ")#mi("(\\mathrm{adj} B)_{i, k} = (\\mathrm{adj B})_{i, j}")#text(" by simple row operations (indeed, the matrix whose determinant is ")#mi("(\\mathrm{adj} B)_{i, k}")#text(" is obtained from the matrix whose determinant is ")#mi("(\\mathrm{adj} B)_{i, j}")#text(" by some simple row operations). Lemma 3 is proved (not as neatly as I hoped for, but I suspect you can simplify the argument).")

#text("Here is a column analogue of Lemma 3:")

#text("=== BEGIN LEMMA ===")

#strong[#text("LEMMA 4")]#text(": Let ")#mi("R")#text(" be a commutative ring. Let ")#mi("A")#text(" be an ")#mi("n")#text("-by-")#mi("n")#text("-matrix over ")#mi("R")#text(". Let ")#mi("v = (v_1, v_2, \\dots, v_n)^T")#text(" be a column vector in ")#mi("R^n")#text(" such that ")#mi("Av = 0")#text(". Fix ")#mi("j, k \\in \\{1, 2, \\dots, n\\}")#text(". Then,")

#mi("\\displaystyle v_j (\\mathrm{adj} A)_{k, i} = v_k (\\mathrm{adj} A)_{j, i}.")

#text("=== END LEMMA ===")

#strong[#text("PROOF OF LEMMA 4")]#text(": Analogous to Lemma 3. (Or, even easier, just apply Lemma 3 to A^T instead of A.)")

#text("Combining Lemma 3 with Lemma 4 quickly yields the following:")

#text("=== BEGIN COROLLARY ===")

#strong[#text("COROLLARY 5")]#text(": Let ")#mi("R")#text(" be a commutative ring. Let ")#mi("A")#text(" be an ")#mi("n")#text("-by-")#mi("n")#text("-matrix over ")#mi("R")#text(". Let ")#mi("v = (v_1, v_2, \\dots, v_n)^T")#text(" and ")#mi("w = (w_1, w_2, \\dots, w_n)^T")#text(" be two column vectors in ")#mi("R^n")#text(" such that ")#mi("Av = 0")#text(" and ")#mi("w^T A = 0")#text(". Fix ")#mi("j, k \\in {1, 2, \\dots, n}")#text(". Then,")

#mi("\\displaystyle v_j w_j \\mathrm{det}(M_k) = v_k w_k \\mathrm{det}(M_j)")

#text("(with notations ")#mi("M_k")#text(" and ")#mi("M_j")#text(" as in Theorem 2).")

#text("=== END COROLLARY ===")

#strong[#text("PROOF OF COROLLARY 5")]#text(": Lemma 3 (applied to ")#mi("i = k")#text(") yields")

#mi("\\displaystyle w_j (\\mathrm{adj} A)_{k, k} = w_k (\\mathrm{adj} A)_{k, j}.")

#text("Lemma 4 (applied to ")#mi("i = j")#text(") yields")

#mi("\\displaystyle v_j (\\mathrm{adj} A)_{k, j} = v_k (\\mathrm{adj} A)_{j, j}.")

#text("Multiplying the first of these two equalities by ")#mi("v_j")#text(" and the second by ")#mi("w_k")#text(", we obtain")

#mi("\\displaystyle v_j w_j (\\mathrm{adj} A)_{k, k} = v_j w_k (\\mathrm{adj} A)_{k, j} = v_k w_k (\\mathrm{adj} A)_{j, j}.")

#text("In view of ")#mi("(\\mathrm{adj} A)_{k, k} = \\mathrm{det}(M_k)")#text(" and ")#mi("(\\mathrm{adj} A)_{j, j} = \\mathrm{det}(M_j)")#text(", we see that we have obtained precisely the claim of Corollary 5.")

#strong[#text("PROOF OF THEOREM 2")]#text(": We have")

#mi("\\displaystyle v_j w_j \\sum_{k=1}^n \\mathrm{det}(M_k)")

#mi("\\displaystyle = \\sum_{k=1}^n v_j w_j \\mathrm{det}(M_k)")

#mi("\\displaystyle = \\sum_{k=1}^n v_k w_k \\mathrm{det}(M_j)")#text(" (by Corollary 5)")

#mi("\\displaystyle =  (w^T v) \\mathrm{det}(M_j).")

#text("This proves Theorem 2.")

#emph[#text("[Thanks, we will mention this in the next revision of the ms -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/251d74bd08278fbf4f394dfbcfabbf86e4effd495eb043ad0ace5b24bc07b765-27f751079643bf0502b46779750cb5e4843b60f0323db961d7e966a276cb7589.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Darij Grinberg")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-533140")[#strong[#text("Darij Grinberg")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2019")])]

#text("The handwavy nature of my proof of Lemma 3 in the parent comment kept ruffling my feathers, so here is an alternative proof.")

#strong[#text("SECOND PROOF OF LEMMA 3.")]#text(" WLOG assume that ")#mi("j \\neq k")#text(", since otherwise the claim is obvious. Let ")#mi("c")#text(" be the column vector in ")#mi("R^n")#text(" whose ")#mi("j")#text("-th entry is ")#mi("w_k")#text(", whose ")#mi("k")#text("-th entry is ")#mi("-w_j")#text(", and whose all remaining entries are ")#mi("0")#text(". Then, the claim of Lemma 3 is easily seen to be equivalent to the matrix equality ")#mi("w^T \\left( \\mathrm{adj} A \\right) c = 0")#text(".")

#text("At this point, I want to recall a known fact, but as usual the only place where I remember it from is my own writeup (Theorem 5.14 in ")#link("https://www.cip.ifi.lmu.de/~grinberg/algebra/trach.pdf")[#text("https://www.cip.ifi.lmu.de/~grinberg/algebra/trach.pdf")]#text(" ): The adjugate of a square matrix can be written as a polynomial in said matrix. Applying this to ")#mi("A")#text(", we conclude that ")#mi("\\mathrm{adj} A")#text(" can be written as a polynomial in ")#mi("A")#text(". Hence, in order to prove that ")#mi("w^T \\left( \\mathrm{adj} A \\right) c = 0")#text(", it suffices to show that ")#mi("w^T A^i c = 0")#text(" for each nonnegative integer ")#mi("i")#text(". But this is easy: For ")#mi("i > 0")#text(", this follows from ")#mi("w^T A = 0")#text(", but for ")#mi("i = 0")#text(", this follows from ")#mi("w^T c = 0")#text(" (which is checked by direct verification). And Lemma 3 is proved again.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/251d74bd08278fbf4f394dfbcfabbf86e4effd495eb043ad0ace5b24bc07b765-27f751079643bf0502b46779750cb5e4843b60f0323db961d7e966a276cb7589.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Darij Grinberg")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-534212")[#strong[#text("Darij Grinberg")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2019")])]

#text("PS (or PPS). The “known fact” I used in the second proof of Lemma 3 above has a MathOverflow thread devoted to it: ")#link("https://mathoverflow.net/questions/32133/expressing-adja-as-a-polynomial-in-a")[#text("https://mathoverflow.net/questions/32133/expressing-adja-as-a-polynomial-in-a")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/251d74bd08278fbf4f394dfbcfabbf86e4effd495eb043ad0ace5b24bc07b765-27f751079643bf0502b46779750cb5e4843b60f0323db961d7e966a276cb7589.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Darij Grinberg")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-622542")[#strong[#text("Darij Grinberg")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2021")])]

#text("The “second proof of Lemma 3” I gave above is wrong. Sorry! (Thanks Ion Zaballa for spotting the error.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60ae5bd040b932d9b10f2f34c41e27276c9aa7400c9c6b4787c99c062d8b600f-24105b22984a8605ab37b5136e7841aa87ff7154c8597a80dcece7cd7ba357d9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zubereitung Inhalt")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531815")[#strong[#text("Zubereitung Inhalt")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2019")])]

#text("Dear Professor Tao:")

#text("I am the guy who pointed out Löwner’s paper on Quanta. The version as stated by Löwner is very useful — see pp. 224–226 in Demmel’s Applied Numerical Linear Algebra. Your version, on the other hand, is just a consequence of the fact (see Wikipedia) that if an ")#mi("n \\times n")#text(" matrix ")#mi("A")#text(" has rank ")#mi("n-1")#text(", then ")#mi("\\mathrm{adj}(A)")#text(" has rank ")#mi("1")#text(" and ")#mi("\\mathrm{adj}(A) = \\alpha xy^T")#text(" where ")#mi("Ax =0")#text(", ")#mi("A^T y = 0")#text(". Apply this to ")#mi("A - \\lambda I")#text(" for a simple eigenvalue ")#mi("\\lambda")#text(" and left/right eigenvectors ")#mi("y")#text(" and ")#mi("x")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zubereitung Inhalt")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531835")[#strong[#text("Zubereitung Inhalt")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2019")])]

#text("Dear Professor Terry:")

#text("Do you think something like a LaTeX-aware search engine for math papers would be a good idea in these kinds of situations? Also do you think that there should be an effort to revive tricki.org?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-682280")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2023")])]

#text("A physics major mentioned to me a couple of years ago the difficulty of googling math results and equations and asked me how to work around it. I never got back to look at it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b71017f3ba0f543c5044556f27512e72972ffa9e69a8bf9184eadd8f7695b8bf-bea05fabd012afb0eff4e8714fccbbf0a0ed5d4690e1d374727fd01c1f9ac003.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Ruxton")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531847")[#strong[#text("Michael Ruxton")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2019")])]

#link("https://www.irishtimes.com/news/science/particle-physics-gives-maths-potentially-powerful-new-tool-1.4095391")[#text("https://www.irishtimes.com/news/science/particle-physics-gives-maths-potentially-powerful-new-tool-1.4095391")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a24729fe93d9bb501744ba30f36a633b0bc0a3059bdadd8306728745d035e617-e78c897b5216e55a49065a9caf586479c0911391d9b9933e3a6728593f941ec7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Margaret Stawiska-Friedland")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-531916")[#strong[#text("Margaret Stawiska-Friedland")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2019")])]

#text("The argument I posted on November 23, 2019 as a comment under the previous post on eigenvectors from eigenvalues can be made to work for multiple eigenvalues, at least for matrices over the field ")#mi("\\mathbb{K}")#text(" of either real of complex numbers.")#linebreak()#text(" Let ")#mi("A")#text(" be an ")#mi("n \\times n")#text(" matrix over ")#mi("\\mathbb{K}")#text(". Let ")#mi("P(\\lambda)=\\det(A-\\lambda I)")#text(" be the characteristic polynomial of ")#mi("A")#text(".")#linebreak()#text(" For eigenvectors of ")#mi("A \\in M_{n \\times n}(\\mathbb{K})")#text(" corresponding to an eigenvalue ")#mi("\\lambda")#text(" with geometric multiplicity ")#mi("k \\geq 1")#text(" we get the following expressions, provided that the algebraic multiplicity also equals ")#mi("k")#text(": Let ")#mi("\\mathbf{v}_1,..\\mathbf{v}_k")#text(" be a basis of eigenvectors corresponding to ")#mi("\\lambda")#text(". Let ")#mi("\\mathbf{w}_1,...,\\mathbf{w}_k")#text(" be a basis of eigenvectors of ")#mi("A^T")#text(" such that ")#mi("\\mathbf{w}_j^T\\mathbf{v}_i=\\delta_{ij}")#text(" (here we use the assumption on algebraic multiplicity also being ")#mi("k")#text("). Let ")#mi("\\mathbf{v}=\\mathbf{v}_1 \\wedge ...\\wedge \\mathbf{v}_k")#text(" and ")#mi("\\mathbf{w}=\\mathbf{w}_1 \\wedge ...\\wedge \\mathbf{w}_k")#text(". Then ")#mi("\\frac{(-1)^k}{k!}P^{(k)}(\\lambda)\\mathbf{v}\\mathbf{w}^T=\\text{adj }_k(A-\\lambda I)")#text(".")#linebreak()#text(" This is a matrix equality; I do not attempt to rewrite it entrywise.")

#text("Proof:")#linebreak()#text(" For ")#mi("1 \\leq k \\leq n")#text(" the ")#mi("k")#text("-th adjugate of ")#mi("A")#text(", denoted by ")#mi("\\text{adj}_k\\; A\\in \\mathbb{K}^{{n\\choose k}\\times {n\\choose k}}")#text(", is defined as follows:")#linebreak()#text(" The entry ")#mi("(\\{1\\le i_1<\\cdots<i_k\\le n\\}, \\{1\\le j_1<\\cdots<j_k\\le n\\})")#text(" is ")#mi("(-1)^{\\sum_{l=1}^k i_l+j_l}")#text(" times the ")#mi("k \\times k")#text("-minor of ")#mi("A")#text(" obtained by deleting the rows ")#mi("i_1,\\ldots,i_k")#text(" and columns ")#mi("j_1,\\ldots,j_k")#text(". Note that the usual adjugate ")#mi("\\text{adj }A")#text(" is ")#mi("\\text{adj}_1\\; A")#text(". We will also use")#linebreak()#text(" the ")#mi("k")#text("-th compound matrix ")#mi("C_k(A)")#text(", which is the matrix in ")#mi("\\mathbb{K}^{{n\\choose k}\\times {n\\choose k}}")#text(" whose entries are the ")#mi("k\\times k")#text(" minors of ")#mi("A")#text(" arranged in the lexicographical order. (If ")#mi("A")#text(" represents a linear transformation ")#mi("T: V \\to V")#text(", then ")#mi("C_k(A)")#text(" represents ")#mi("\\bigwedge^k T")#text(" in suitable bases.) . It is straightforward to show that that ")#mi("\\textrm{adj}_k\\; A=C_k(\\Delta_n) C_{n-k}(A) C_k(\\Delta_n)^T")#text(", where ")#mi("\\Delta_n\\in\\mathbb{K}^{n\\times n}")#text(" is the matrix whose ")#mi("(i,j)")#text(" entry is ")#mi("(-1)^i \\delta_{i(n-j+1)}")#text(".")

#text("The Laplace expansion along minors implies")#linebreak()#text(" the following identities (")#mi("1 \\leq k \\leq n")#text("):")

#mi("\\displaystyle C_k(A)\\textrm{adj}_k\\; A=(\\textrm{adj}_k\\; A)C_k(A)=(\\det A) I_{n\\choose k}.")

#text("From the identity ")#mi("\\text{adj}_k\\; A=C_k(\\Delta_n) C_{n-k}(A) C_k(\\Delta_n)^T")#text(" it follows that ")#mi("\\text{rank } \\text{adj}_k\\; A=1")#text(" if ")#mi("\\text{rank }A=n-k")#text(". Hence, if the nullity of ")#mi("A-\\lambda I)")#text(" is ")#mi("k")#text(", we can represent ")#mi("\\text{adj}_k(A-\\lambda I)")#text(" as ")#mi("adj_k(A-\\lambda I) = \\mathbf{x}\\mathbf{y}^T")#text(", where ")#mi("\\mathbf{x}")#text(" and ")#mi("\\mathbf{y}")#text(" are vectors in ")#mi("\\mathbb{K}^{\\binom {n}{r}} \\setminus \\{0\\}")#text(". From the relation between the compound and adjugate matrix it follows that ")#mi("C_k(A-\\lambda I)\\mathbf{x} = 0")#text(" and ")#mi("C_k(A-\\lambda I)^T\\mathbf{y} = 0")#text(". Let now ")#mi("\\mathbf{v_1}, ...,\\mathbf{v}_k")#text(" be a basis of eigenvectors for ")#mi("(A-\\lambda I)")#text(". Then ")#mi("\\mathbf{v}_1 \\wedge ...\\wedge \\mathbf{v}_k")#text(" is an eigenvector for ")#mi("C_k(A)")#text(" corresponding to the eigenvalue $\\lambda^k$, which has geometric multiplicity ")#mi("1")#text(".")#linebreak()#text(" We can take ")#mi("\\mathbf{v}=\\mathbf{v}_1 \\wedge ...\\wedge \\mathbf{v}_k")#text(" as a basis for ")#mi("\\text{ker} C_k(A-\\lambda I)")#text(", so ")#mi("\\mathbf{x}=\\alpha \\mathbf{v}, \\ \\alpha  \\ne 0")#text(". Let ")#mi("\\mathbf{u}:=(1/\\alpha)\\mathbf{y}")#text(". Then ")#mi("adj_k(A-\\lambda I) = \\mathbf{v}\\mathbf{u}^T")#text(". If the algebraic multiplicity of $\\lambda$ as the eigenvalue of ")#mi("A")#text(" is also ")#mi("k")#text(", there exist ")#mi("\\mathbf{w}_1,..., \\mathbf{w}_k \\in \\text{ker} (A-\\lambda I)^*")#text(" such that ")#mi("\\mathbf{w}_i(\\mathbf{v}_j) =\\delta_{ij}")#text(" Taking ")#mi("\\mathbf{w}=\\mathbf{w}_1 \\wedge...\\wedge \\mathbf{w}_k")#text(" we get ")#mi("\\mathbf{w} \\in \\mathbb{K}^{\\binom {n}{r}}\\setminus \\{0\\}")#text(" such that ")#mi("C_k(A-\\lambda I)^T\\mathbf{w}=0")#text(", ")#mi("\\mathbf{w}^T\\mathbf{v}=1")#text(". We then have ")#mi("c\\mathbf{w}^T=\\mathbf{u}^T")#linebreak()#text(" with ")#mi("0 \\ne c")#text(" and ")#mi("c = c\\mathbf{w}^T\\mathbf{v}=\\mathbf{u}^T\\mathbf{v}= \\text{tr }\\text{adj}_k(A-\\lambda I)")#text(". Hence ")#mi("\\text{adj}_k(A-\\lambda I)=\\mathbf{v}\\mathbf{u}^T=\\text{tr }\\text{adj}_k(A-\\lambda I)\\mathbf{v}\\mathbf{w}^T")#text(".")

#text("We can replace ")#mi("\\text{tr }\\text{adj}_k(A-\\lambda I)")#text(" by the suitably scaled ")#mi("k")#text("-th derivative of ")#mi("P")#text(" evaluated at ")#mi("\\lambda")#text(" thanks to the following formula: for ")#mi("X,Y")#text(" arbitrary matrices in ")#mi("M_{n \\times n}")#text(", ")#mi("\\det (X+Y) =\\sum_{k=0}^n \\text{tr } (\\text{adj}_k X \\; C_k(Y))")#text(", proved as Theorem 4.1 in: Prells, Uwe; Friswell, Michael I.; Garvey, Seamus D. (2003-02-08). “Use of geometric algebra: compound matrices and the determinant of the sum of two matrices''. Proceedings of the Royal Society of London A: Mathematical, Physical and Engineering Sciences. 459 (2003): 273-285. For the purpose of finding the appropriate differential expression, the formula is applied to the matrices ")#mi("X=(A-\\lambda   I)")#text(" and ")#mi("Y=tI")#text(", and then we take ")#mi("t \\to 0")#text(" in ")#mi("\\mathbb{K}")#text(" (polynomials are identified with polynomial functions, which are smooth).")

#text("The assumption of the algebraic multiplicity of the eigenvalue being equal to its geometric multiplicity can be justified by the following easy result:")

#text("Let ")#mi("V")#text(" be an ")#mi("n")#text("-dimensional vector space over ")#mi("\\mathbb{K}")#text(" and let ")#mi("V^{\\prime}")#text(" be its dual space. Let ")#mi("U \\subset V, \\ W \\subset V^{\\prime}")#text(" be two ")#mi("k")#text("-dimensional subspaces. TFAE: (i) ")#mi("U \\cap W^\\perp =\\{0\\}")#text("; (ii) ")#mi("U^\\perp \\cap W =\\{0\\}")#text("; (iii) There exist bases ")#mi("\\{u_1,...,u_k\\}")#text(", ")#mi("\\{f_1,...,f_k\\}")#text(" in ")#mi("U")#text(" and ")#mi("W")#text(", respectively, such that ")#mi("f_j(u_i)=\\delta_{ij}, \\ i,j=1,...,k")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/717a0de513102aaf5522bd1fe8f22e5efcb208a57c169f7fa3610489c2e043fa-d79ce674d1106ad9cfb5ffe641a523052115f388a03bc0839677080945044b6a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Some Light Winter Break Mathematical Reading – Advice and Resources for Math Graduate Students")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-532200")[#strong[#text("Some Light Winter Break Mathematical Reading – Advice and Resources for Math Graduate Students")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2019")])]

#text("[…] be described by a formula involving only the eigenvalues of the matrix and certain submatrices. Tao’s blog has a concise description of the precise statement. Their preprint is worth a look too: after […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/717a0de513102aaf5522bd1fe8f22e5efcb208a57c169f7fa3610489c2e043fa-d79ce674d1106ad9cfb5ffe641a523052115f388a03bc0839677080945044b6a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Some light winter break math reading – Advice and Resources for Math Graduate Students")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-532202")[#strong[#text("Some light winter break math reading – Advice and Resources for Math Graduate Students")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2019")])]

#text("[…] described by a formula involving only the eigenvalues of the matrix and certain submatrices. See Tao’s blog for a concise description of the precise statement. Their preprint is worth a look too: after […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d56c15c139fba849b6748602cc565f24aa99fcabcff6c18854748b8c966001e-899961247445f3dbd22b85b4aef5be37cf5f6ee8ce90066efce2ffe76ced1388.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edward Zeng")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-532408")[#strong[#text("Edward Zeng")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2019")])]

#text("Dear Professor Tao,")

#text("I’m a sophomore math major at Berkeley. Someone told me about this theorem, and I think I found another proof.")

#text("Set ")#mi("j = 1")#text(". WLOG assume ")#mi("\\lambda_i(A) = 0")#text(". Then the formula to be proved is")#linebreak()#text(" ")#tao-math("\\displaystyle \\left|v_{i,1}\\right|^2 \\prod_{k = 1; k \\neq i}^n \\lambda_k(A) = \\det(M_1).", block: false)

#text("First we note any Hermitian matrix ")#mi("A")#text(" can be diagonalized by a unitary transformation")#linebreak()#text(" ")#mi("T^*AT =  \\begin{pmatrix} \\lambda_1(A) & & \\\\ & \\lambda_2(A) & \\\\ & & \\ddots \\end{pmatrix}")#linebreak()#text(" where the column vectors of ")#mi("T")#text(" form a basis of unit eigenvectors,")#linebreak()#text(" ")#mi("T = (\\vec{v}_1, \\vec{v}_2, \\dots, \\vec{v}_n).")

#text("Now observe the following lemma, which follows directly from how determinants are computed.")

#text("Lemma 1: Let")#linebreak()#text(" ")#mi("A_t = A + \\begin{pmatrix} t  & 0    & \\dots\\\\ 0      & 0    & \\dots\\\\ \\vdots      & \\vdots    & \\ddots \\end{pmatrix} = \\begin{pmatrix} a_{11} + t  & a_{12}    & \\dots\\\\ a_{21}      & a_{22}    & \\dots\\\\ \\vdots      & \\vdots    & \\ddots \\end{pmatrix}.")#text(" Then ")#mi("\\det(A_t) = \\det(A) + t\\det(M_1)")#text(".")

#text("Applying T-transformation to ")#mi("A_t")#text(", we obtain")#linebreak()#text(" ")#mi("T^*A_tT = \\begin{pmatrix} \\lambda_1(A) & & \\\\ & \\lambda_2(A) & \\\\ & & \\ddots \\end{pmatrix} +\\begin{pmatrix} t\\overline{v_{1,1}}v_{1,1}   & t\\overline{v_{1,1}}v_{2,j} & \\dots\\\\ t\\overline{v_{2,1}}v_{1,1}   & t\\overline{v_{2,1}}v_{2,j} & \\dots\\\\ \\vdots                  & \\vdots                & \\ddots \\end{pmatrix}.")

#text("When we take the determinant on both sides (using Lemma 1 on the LHS) and collect the t-linear terms, we obtain the desired formula.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9d8774217484ab2d8a4579e1b0545e7034f43aeee7f410524947d81372456c19-b00c8c36f6695168220798f2aac6913aa535d961411cd54d4a9953c4da764c43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Milad Kiaee Darunkola")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-536117")[#strong[#text("Milad Kiaee Darunkola")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2020")])]

#text("This is related to the problem of Stars and Bars in Combinatorics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e79120dd7df6a12d6bf4a48f2f3b2079f3063f7bc5d6807f1f02f4906a9e0c7-349b44a50d4d38d7ebc0d102b8d36c6890b46aa8ad15a59079679e54b6f8d64e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cole Green")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-541455")[#strong[#text("Cole Green")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2020")])]

#text("Our research group simulates photosynthetic nanotubules in Green Sulphur Bacteria. To study systems comparable in size to those found in nature, we must calculate the eigenvectors of large hamiltonians (up to 10,000×10,000). We do this by using LLAPACK’s DSYEV package, but this takes a long time for large systems. Since we only require the magnitude of the eigenvectors’ components for many of our calculations, we tested whether this new method for finding eigenvectors could be implemented in order to create faster programs. We found that this method was considerably slower than DSYEV, but we would like to improve the program if possible. Has anyone attempted something similar to this?")

#text("If you would like more information about the results of our comparison or have any suggestions, please contact me at ")#link("mailto:cdgreen@my.loyno.edu")[#text("cdgreen@my.loyno.edu")]#text(" or reply to this post")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-542128")[#strong[#text("יומיות 29.12.2019: WT.social, רשת חברתית חדשה למקים ויקיפדיה | ניימן 3.0")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2020")]

#text("[…] זמן קצר הם גילו שהם לא הראשונים שגילו את הזהות, אלא הראשונים שנתנו לה מסגרת וחשיבות משלה. מהר מאד הם […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ca327574bd90c23106f58e54d474c991d4f2e1b86227fa14a40e86afd95423f-5abeaa968aa927addcd8d53d6578c84663798072403dbb1f19bc2c7fe4e5db9e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sylvain Ribault")]], [#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-561367")[#strong[#text("Sylvain Ribault")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2020")])]

#text("One way to avoid having to rediscover the wheel too often: write such results more systematically in Wikipedia.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-564540")[#strong[#text("Server Bug Fix: How do you check that your mathematical research topic is original? - TECHPRPR")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2020")]

#text("[…] is one that is relevant to all mathematicians. An interesting recent example that comes to mind is this story on Terence Tao’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/12/03/eigenvectors-from-eigenvalues-a-survey-of-a-basic-identity-in-linear-algebra/#comment-685261")[#strong[#text("特征向量来自特征值：线性代数中基本身份的调查-2019 - 偏执的码农")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2024")]

#text("[…] 详情参考 […]")
]
