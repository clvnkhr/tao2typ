// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/05/postdoc-position-on-formal-verification-and-algorithm-discovery-for-numerical-analysis/
// Converted to Typst by tao2typ: "2026-10-14T16:39:36.977586+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Postdoc position on formal verification and algorithm discovery for numerical analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Postdoc position on formal verification and algorithm discovery for numerical analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/05/postdoc-position-on-formal-verification-and-algorithm-discovery-for-numerical-analysis/")[#text("https://terrytao.wordpress.com/2026/10/05/postdoc-position-on-formal-verification-and-algorithm-discovery-for-numerical-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://people.epfl.ch/annalisa.buffa")[#text("Annalisa Buffa")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#strong[#text("About us and the position")]

#text("The ")#link("https://www.epfl.ch/labs/mns/")[#text("Chair of Numerical Modelling and Simulation")]#text(" at EPFL is dedicated to the design and analysis of numerical algorithms for partial differential equations. Our research is oriented towards the development of novel and innovative numerical techniques aiming at improving the integration between numerical simulations and geometric modelling and processing.")

#text("Proof assistants such as Lean, together with recent AI tools, are changing how mathematics is done. We are opening a postdoctoral position to explore what formal verification and algorithm discovery can bring to numerical analysis. There is no fixed project. The goal is to find out, through concrete experiments, where these approaches help in the design and analysis of numerical schemes for PDEs, and where they still fall short.")

#metadata(none) <tao-38b5712e7030b2464271>

#strong[#text("What you will do")]

#text("As a postdoc in our group, you will set up and lead this new research line, choosing its directions together with us. Possible starting points are the formalization in Lean of stability and error estimates for finite element methods, or the AI-assisted discovery of new discretization paradigms for classes of PDEs where standard methods struggle, with their properties then verified formally. You will publish and present your work internationally.")

#strong[#text("You are the ideal candidate if")]

#list(
[#text("You hold a PhD in mathematics, computer science or a related field")],
[#text("You have a strong background in formal verification with Lean")],
[#text("You have experience in AI-assisted theorem proving or algorithm discovery is an asset")],
[#text("You have working knowledge of numerical analysis, ideally numerical methods for PDEs")],
[#text("You are independent and comfortable with open-ended research questions")],
[#text("You communicate well in English and enjoy working at the boundary between disciplines")]
)

#strong[#text("We offer")]

#list(
[#text("A stimulating international environment at one of Europe’s leading research institutions")],
[#text("Competitive salary and excellent working conditions")],
[#text("A 1-year contract, renewable")],
[#text("Freedom to shape a new research direction from the start")],
[#text("A friendly team with strong postdoctoral and PhD researcher community")]
)

#strong[#text("If you are interested")]

#text("Submit your application containing CV, motivation letter, and contact details for 2 referees through ")#link("https://careers.epfl.ch/job/Lausanne-Post-doc-on-formal-verification-and-algorithm-discovery-for-numerical-analysis/1165456955/")[#text("this link")]#text(". In the motivation letter, briefly describe one question you would like to work on, linking numerical analysis with formal verification or algorithm discovery. Applications will be reviewed until the position is filled. Start date: as soon as possible (flexible).")

#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/05/postdoc-position-on-formal-verification-and-algorithm-discovery-for-numerical-analysis/#comment-696838")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("The message is clear from the mathematics establishment: adapt to using AIs or you won’t get a postdoc position.")

#text("RIP mathematics. Guess it’s time to find a new career which doesn’t require the use of AIs and let research mathematics just be a hobby.")
]
