// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/
// Converted to Typst by tao2typ: "2026-10-14T16:34:57.703173+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Advice on mathematical careers, and mathematical writing", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Advice on mathematical careers, and mathematical writing")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 June 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/")[#text("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("For the last year or so, I’ve maintained two advice pages on ")#link("http://www.math.ucla.edu/~tao/")[#text("my web site")]#text(": one for ")#link("http://www.math.ucla.edu/~tao/advice.html")[#text("career advice to students in mathematics")]#text(", and another for authors wishing to ")#link("http://www.math.ucla.edu/~tao/submissions_old.html")[#text("write and submit papers")]#text(" (for instance, to one of ")#link("http://www.math.ucla.edu/~tao/submissions.html")[#text("the journals I am editor of")]#text("). It occurred to me, though, that an advice page is particularly well suited to the blog medium, due to the opportunities for feedback that this medium affords (and especially given that many of my readers have more mathematical experience than I do).")

#text("I have thus moved these pages to my blog; my career advice page is ")#link("https://terrytao.wordpress.com/career-advice/")[#text("now here")]#text(", and my advice for writing and submitting papers is ")#link("https://terrytao.wordpress.com/advice-on-writing-papers/")[#text("now here")]#text(". I also took the opportunity to split up these rather lengthy pages into lots of individual subpages, which allowed for easier hyperlinking, and also to expand each separate topic somewhat (for instance, each topic is now framed by an appropriate quotation). Each subpage is also open to comments, as I am hoping to get some feedback to improve each of them.")

#text("[")#emph[#text("Update")]#text(", June 10: Of course, the comments page for this post, and for the pages mentioned above, are also a good place to post your own tips on mathematical writing or careers. :-) ]")

#heading(level: 1)[#text("Comments (59)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-2/#comment-7678")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2007")])]

#text("Dear Andrew,")

#text("It depends on the difficulty of the exercises you are encountering. If it looks like they are easy, you may as well do them now, and pick up some practice and test your strengths. If they look moderately tricky, in that you know how to make some partial progress, but don’t see how to finish off the whole thing, then it is worth doing what you can, so that you know exactly what the gap in your knowledge is, and what to look out for when reading later sections. If the problem looks so difficult that you don’t even know how to begin, then it would be worth skipping it for now and coming back later when you have more of an idea of the big picture.")

#text("Generally, the optimal rate of learning occurs when you are tackling something just barely out of your current range; either a problem which is almost within your ability to solve, or a concept which is only a little more advanced than what you already know. Sometimes it is worth pushing a little bit beyond that, either by reading ahead (or reading around) or by doing more difficult exercises, in order to get more perspective, but it’s not really worth venturing into areas which you do not recognise at all, or problems that you have no idea what to do with.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-2/#comment-7784")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2007")])]

#text("Dear Terry,")

#text("At this stage of your career now, do you think that you could become a physicist? Or would you have to study more physics?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-2/#comment-7977")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2007")])]

#text("Dear Bill,")

#text("Probably not, but I might end up collaborating with a physicist one day, perhaps, if the topic was right. I do intend to work on some questions in ")#emph[#text("mathematical")]#text(" physics, however (such as studying the PDE that arise from the laws of physics), although this is arguably a completely different subject from physics proper.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-2/#comment-7995")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2007")])]

#text("Hi Terence, Bill,")

#text("Paul AM Dirac, Nobel Prize in Physics 1933, did not have a degree in physics. He had a BS in electrical engineering and PhD in mathematics.")#linebreak()#text(" ")#link("http://nobelprize.org/nobel_prizes/physics/laureates/1933/dirac-bio.html")[#text("http://nobelprize.org/nobel_prizes/physics/laureates/1933/dirac-bio.html")]

#text("In 2000, all three recipients were members of IEEE.")#linebreak()#text(" Zhores I. Alferov, Electrotechnical Institute in Leningrad and Physico-Technical Institute.")#linebreak()#text(" Herbert Kroemer, Becker’s Institute for Theoretical Physics, but paper published in Proceedings of the IEEE after rejection by Applied Physics Letters.")#linebreak()#text(" Jack S. Kilby, electrical engineering at the University of Illinois, University of Wisconsin towards a master’s degree in electrical engineering and Distinguished Professor of Electrical Engineering at Texas A&M University.")#linebreak()#text(" Biographies found within:")#linebreak()#text(" ")#link("http://nobelprize.org/nobel_prizes/physics/laureates/2000/index.html")[#text("http://nobelprize.org/nobel_prizes/physics/laureates/2000/index.html")]

#text("“Electrical engineering, originally taught at MIT in the Physics Department, became an independent degree program in 1882. The Department of Electrical Engineering was formed in 1902, …”")#linebreak()#text(" ")#link("http://ocw.mit.edu/OcwWeb/Electrical-Engineering-and-Computer-Science/index.htm")[#text("http://ocw.mit.edu/OcwWeb/Electrical-Engineering-and-Computer-Science/index.htm")]

#text("Electrical engineers have interesting techniques [or tricks?] for dealing with discontuities and oscillating periods.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/19f78d68ca1c7a7f5e6cb4d83083c6680baee4964e5959fe3a84969e72620cab-dd295cba0c8cc4e960c0977a38a8cacd810b0d4ead8d64ae022d8917ce3937b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arulsaravana Jeyaraj")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-2/#comment-633593")[#strong[#text("Arulsaravana Jeyaraj")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2021")])]

#text("Those days EEs probably had to have as much skill as a reasonable mathematician. I doubt if there was a mathematics for engineers coursework. I wish things need not be much different these days (at least for freshmen) given that much of calculus work can be pushed to high school these days and the syllabus uniformized reasonably.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-2/#comment-7996")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2007")])]

#text("I see that I mispelled “discontinuities”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-2/#comment-15241")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2007")])]

#text("Dear Terry,")

#text("Is teaching a subject the best way to learn it even if don’t know it yet? Is this a good practice for undergraduates? How long does it take you to type up your class notes?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-2/#comment-15242")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2007")])]

#text("Also when you teach a subject do you have to study it beforehand yourself? Were you the type of person to do most of the problems in a textbook?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/987c81f7c28f80a9191401ad082bab08f35340e3b68189799821c675751d0095-53cbcf465b67eca695c795fdea8932db506343cd026d8602374a358d0ebe6ed6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergio")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-2/#comment-431428")[#strong[#text("Sergio")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2014")])]

#text("Dear prof. Tao,")

#text("i would like to ask if you use some reference manager software.")

#text("thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-1952")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2007")]

#text("[…] Advice on mathematical careers, and mathematical writing For the last year or so, I’ve maintained two advice pages on my web site: one for career advice to students in […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-1963")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2007")])]

#text("I have just a few opinions and comments reinforcing what Terence has said in his excellent and generous discussion on writing papers.")

#text("I’ve found the use of macros invaluable for notation that I’m initially unsure of. In the current very long document that I’m working on, I’ve changed my mind many times about choice of symbols, and if I’ve used a macro, they are painless to alter. My only regret is that I have not used them to an even greater extent. They can also eliminate the tedium of fine typographical adjustments if you are picky about such things. For example, you may think that a symbol in certain situations needs a tiny bit more space on one or the other side in order to let it breathe:")

#text("\\newcommand{\\set}[2]{ \\{\\mspace{1mu}#1 : \\nolinebreak #2 \\mspace{1mu}\\} }")

#text("Adjustments can be made globally merely by changing a single line. Altering typography or choice of symbol or strings of symbols can be done using regular expressions in a text editor, but these can be quite dangerous to use if you don’t understand them thoroughly and use them frequently. They can have unexpected results, sometimes buried in a few places in your paper, that you may not discover for days or weeks, finally forcing you to check every single case in the paper by hand.")

#text("A good introduction is like a house with good “curb appeal”. If done well, it invites the reader into your thoughts and encourages them to stay a while and at least look around. If the paper is the culmination of months, or perhaps years, of research and writing, then you certainly owe it to yourself and to your ideas to spend a significant amount of time polishing that introduction, writing and rewriting. I’m finding that it is in some ways the most difficult part of the paper to write, and requires a delicate balance of economy and thoroughness. A quick sketch is probably appropriate as the first draft is being written. I think it’s valuable to really seriously attack the introduction before the second pass through the paper, especially if it is along one, because it helps your focus on the global structure of the paper. It should be reconsidered again, and probably needs a few additional tweaks, when you think the body of the paper is more or less complete.")

#text("There are undoubtedly different opinions about the extent to which an introduction should be written to appeal to non-experts. Personally, I don’t believe in only “preaching to the choir”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d3a5481b2dce23f559221115a98d4d16283316e2cbe837021bc66f78a772211-1458b9040bd9a2768f842b42edcd3f062c91a085270fba9a766951943098f3b6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-1965")[#strong[#text("James")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2007")])]

#text("I agree completely about macros. I’ve never regretted using a macro and have often regretted not using one.")

#text("Another benefit is that sometimes you’ll want to change more than just the contents of the macro. For instance, you might realize that all discussion of S should be moved to section 6. If you didn’t use a macro, searching for S in your text editor will turn up much more than what you’re looking for. While searching for something like \\baseSet will turn up only what you want.")

#text("On the other hand, I haven’t yet written a paper where every single symbol name is a macro. In principle, it’s probably possible to overdo it, but I myself am not in much risk of doing that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-2032")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2007")])]

#text("Dear Terry, it is very nice to see comments and advices for graduate students and young mathematicians. (This simultaneous addition of dozens of little “posts” confirms what could be suspected earlier, that “what’s new” requires from the readers at least a two-dimensional time.)")

#text("There is something paradoxical about the advice page because a priori it seems that on this front of trying to explain to graduate students how to overcome difficulties, you would be in some disadvantage.")

#text("One could have expected advices of the form ( :) )")

#text("1) Do not be discouraged if you did not solve the problem that you are working on. Solving it next week will be also OK.")

#text("2) For some famous problems it seems that time is not ripe for solving them completely. Do not be discouraged by partial substantial progress.")

#text("3) Do not hesitate to develop new tools if the tools you are using are not powerful enough.")

#text("4) Sometimes it is better to work in a less well known field that one feels competent and comfortable in, in parallel of working in a more well known field that one feels also competent and comfortable in.")

#text("etc. etc.")

#text("Of course, the actual advices you give are quite reasonable and the approach is thoughtful, and the many links for advices by others are nice and useful. Still the question remains what are the optimal qualifications needed to give good career advice for struggling (ordinary) mathematicians in their early stages.")

#text("There is a larger point here concerning mathematical education, and common mathematical difficulties (even fears) in learning mathematics. Mathematics is a very peculiar human creation and while useful and beautiful it is also very difficult and threatening to many, perhaps most, people.")

#text("We often ask who are those qualified to face the difficulties in mathematical education as a system and for individuals. Is it the mathematicians who may have profound understanding of mathematics but who did not really experience the common difficulties of acquiring mathematics? The alternatives are often people who had never overcome their own basic mathematical difficulties, or people who, while having good mathematical basic skills, have very pale knowledge of modern mathematics. Indeed this is complex problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-2063")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2007")])]

#text("Terry– you’re obviously an exceptional mathematician and I appreciate the opportunity read some of your wisdom on learning and practicing mathematics. However it appears that complementing your extraordinary mathematical talent is a near superhuman level of productivity. I was hoping you could add a few words about time management.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-2066")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2007")])]

#text("Hmm, that’s an interesting suggestion, but I’ll have to think about it. (My advice pages took over a year to reach their current form, with bits and pieces being put in whenever I had the inspiration; I may need a similar amount of time to collect my thoughts on organisation and time management issues.) The “rapid prototype” thing in my writing advice really does help write papers faster, though.")

#text("The other thing, I guess, is to try to direct your energies towards tasks which are suitable the current environment and your mood. If you are lucky enough to have a few hours of uninterrupted time, and you are feeling ready for it, then it’s a good time to write papers or try to do the computations and experiments which may lead to a paper. But if your day is going to be full of scheduled appointments and other distractions, and your brain doesn’t really feel like getting into top gear, then that’s a good day to respond to email, do paperwork or other errands, read some papers, or write a little more on one of your draft blog entries. :-)")

#text("I still feel like there are not enough hours in the day to do everything I want to do, though…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Confused")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-2120")[#strong[#text("Confused")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2007")])]

#text("Dear Terry,")#linebreak()#text(" I will be finishing my PhD over the next months; I would like to ask, if one day you have time, to perhaps also write some piece of advice for new junior faculty members. Thanks.")#linebreak()#text(" A confused PhD to be.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-2350")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2007")])]

#text("Advice is such a big issue – when to give it, and when to refrain from giving it, and how to evaluate an advice – this is difficult even in hindsight. It is very interesting to compare the different approaches expressed and linked in Terry’s posts.")

#text("I remember a very early advice I got regarding the first paper I wrote. I think it was a good advice. The title I gave my paper was “More on ")#mi("A_n(x,y;p,q)")#text(" and ")#mi("F_n(x,y;p,q)")#text(".”")

#text("Now, ")#mi("A_n(x,y;p,q)")#text(" where certain combinatorial sums defined in Riordan’s book “Combinatorial Identities, ” while ")#mi("F_n(x,y;a,b)")#text(" were auxiliary sums that are introduced in the paper itself.")

#text("I send this paper to John Riordan and got a reply back in 1972. Riordan wrote me that I had a splendid idea and said he will be happy to send a satisfactory written version to the Journal of Combinatorial Theory where he was a member of the editorial board. Riordan said, however, that the paper needs a better title. Thinking about it now, I find it hard to imagine a worse title then my original one. Giving some extra thought on the title of a paper may qualify as a good advice in general.")

#text("Riordan proposed an alternative name “A note on evaluation of Abel’s sum” which was the actual name of the published paper (in 1979). (Beside the title Riordan sent me four pages of other remarks. He also send many remarks to the second version in 1974 which he wrote still needed revision. Not to discourage me too much he wrote: “I am sorry to be causing you this additional rewriting; perhaps it may be a little consolation for you to know that I have also asked it of writers who were full professors.”)")

#text("In 1978 I visited for the first time NYC and went to see Riordan who after a long service at Bell Laboratories got a position at Rockefeller University. He told me several nice stories like the one about his first book “An Introduction to Combinatorial Analysis”. After the book appeared Riordan was called to a meeting with his managers at “Bell Labs” and since writing this book was something he did “on the side” he was worried that they are going to be angry about it. Instead he got a salary raise.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-2515")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2007")])]

#text("Dear Gil,")

#text("That is a nice little story. I would add that in addition to having an informative title, it is also good to have an informative abstract that goes beyond the title by revealing the novelty or structure of the paper, especially since most readers will not go beyond the title and abstract of a paper that they are casually skimming. So, if the title is “A proof of Conjecture X”, the abstract should be much more than “We prove Conjecture X.”; it should be more like “We prove Conjecture X using methods from theory Y. The main new ingredients are a generalisation of Lemma Z from the work of W, and a new inequality V which relates A and B. We also speculate as to whether the methods can be used to attack Conjecture X’.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32d20b607dd4a46a31b50b296721fa38971f66b82bd92d1f5d175ddc5ec77357-f8e58c684383cc0d9d017fe9cb7460cd650cf256c49ebdc234eea265f863d13a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rcourant")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-2672")[#strong[#text("rcourant")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2007")])]

#text("Dear Terry")

#text("I am following your advice in writing/TeXing my work. In other words, I am LaTeXing all of my notes and problems on wordpress. It actually is helping me focus and understand the material at a deeper level. Would you say that your advice on writing everything down (TeXing) also applies to undergraduates?")

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-2738")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2007")])]

#text("Dear rcourant,")

#text("I would say that anything which forces you to actively work with the material, rather than just passively absorb it, is a good thing. Plus, investing some time into building up TeX skills will pay off later if you go on into academia. I certainly wish I had written up more of what I had learnt as an undergraduate; every so often I have to go back to textbooks (or nowadays, to wikipedia and other web resources also) to figure out some basic question in, say, Galois theory, because I had forgotten most of my undergraduate education on the topic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-2867")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2007")])]

#text("Dear Terry,")

#text("As a professional mathematician, do you find it easy to learn concepts quickly? For instance, if you needed to study mathematical statistics, information theory, or financial mathematics would you pick up a textbook and do a lot of problems? Or do you not need to do that? I have heard of professors who learn entire fields in one or two weeks. Is it generally the case that math professors can learn any quantitative material very quickly (i.e. new mathematics, physics, chemistry, etc..)?")

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3019")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2007")])]

#text("Dear Tom,")

#text("I think once one learns enough mathematics, other fields with a significant mathematical component can be easier to learn, especially if one can talk to an expert in that field to ask a lot of “dumb” questions to get started. I myself learnt a lot of fields from my co-authors in this way, though in most cases it took significantly longer than two weeks! Working out “trivial” problems in the field helps a lot – many of my “short stories” started this way. And, of course, the best way to learn a subject is to teach a class on it.")

#text("One specific thing that mathematical training can help with though is to understand abstraction, which allows one to learn a field in a nonlinear order. For instance, suppose that a textbook introduces a topic by first establishing concept A, then concept B, then concept C, with B building upon A and C building upon both A and B. If one is learning in a linear order, then if one does not fully comprehend A then one will be totally lost by the time one gets to B and C; however, in such a case, if one can abstract away the key properties of A one needs to understand B and C, then one can obtain a contingent understanding of B and C even without a full comprehension of A, which may give enough of an idea of the “big picture” that one can continue with learning the subject, deferring the complete understanding of A until later when one has more insight and experience (or patience).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3149")[#strong[#text("Robert")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2007")])]

#text("Dear Terry,")

#text("I was just wondering if you know whether there are any math graduate programs that do not require an undergraduate degree? In other words, if someone has self-studied the required undergraduate math courses and does well on the GRE/math GRE, can he still get into a graduate school? Or do all graduate schools in math require a B.S degree?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3159")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2007")])]

#text("Dear Robert,")

#text("I can’t speak for all programs, but I would imagine that any popular graduate program will be highly competitive, and thus an application which is lacking an undergraduate degree (and thus also lacking a GPA or equivalent) would need to compensate for this by being exceptional in some other sense (e.g. having some research achievements or notable awards, outstanding letters of recommendation, etc.) in order to have some chance of admission. In general, the people who look at admissions tend to err on the side of conservatism; any anomaly in a file tends to be regarded as a possible indicator of risk and would need to be compensated for by unusually high quality in some other aspect of the file.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3174")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2007")])]

#text("Dear Terry,")

#text("Do you think that a top-down approach to learning math is effective and efficient. For example, consider someone who wants to learn real analysis or any mathematical subject. He reads through the textbook taking notes, but does NOT do the problems. After covering the entire book, he goes back to the beginning and does all the problems (or selected problems). Do you know anybody who does this? Or would it be better to do problems right after reading a specific section.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3276")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2007")])]

#text("Dear Ben,")

#text("Of course, you are free to study any subject in whatever order you please, and if you are already experienced in similar topics, then it can become efficient to learn things in a nonlinear order, for instance skipping those parts which you think you already know how to do, and focusing on the simplest thing that you currently don’t yet understand. Or perhaps abstracting any particularly difficult topic into a “black box” to be inspected later, and move on to try to grasp the “big picture” first, in order to gain context.")

#text("That being said, the challenge of solving problems (either those provided in the text, or those you make up yourself) provides an excellent objective test to ensure that you actually grasp a topic thoroughly; it also helps purge any accumulated misconceptions or fuzzy thoughts one has acquired about the subject. If one does not put one’s knowledge to the test in such a manner, there is the danger that one may only acquire a superficial (or incorrect) understanding of a subject, the deficiencies of which might not be detected until much later, at which point one may have to do a substantial amount of remediation.")

#text("So one has to find the right balance: it is important to try to understand the big picture, but at the same time one cannot hope to always avoid getting one’s hands dirty with detailed computations and problem solving.")

#text("See also my advice on “asking yourself dumb questions”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3300")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2007")])]

#text("Dear Terry,")

#text("I was just wondering where you do most of your work? In other words, when you are working on a problem, do you use pencil and paper or white boards/chalkboards? Do you espouse the old saying that the tools of a mathematician are pencil, paper, and a waste basket?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3333")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2007")])]

#text("Dear Terry,")

#text("Do you recommend that one learns a subject from different sources? For example, in calculus one can learn from Spivak, Apostol, Courant, Stewart, etc.. I think each of these authors gives a different perspective on the material (i.e. Spivak/Apostol more of a mathematicla view, while Stewart gives more of an engineering perspective).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luther")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3349")[#strong[#text("Luther")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2007")])]

#text("Dear Terry,")

#text("What languages would you recommend one to learn if he wants to become a mathematician. Is German a good language to learn?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3412")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2007")])]

#text("Dear Professor Tao,")

#text("I’m 23 yrs old. I only have basic high school math knowledge.")#linebreak()#text(" I do visit math forums but what puts me off is that there are others who are younger and appear to be better than me, and cleverer.")#linebreak()#text(" This makes me depressed and I stop doing math for about a week then come back to it again.")#linebreak()#text(" My goal is to learn and even contribute some discoveries.")#linebreak()#text(" But I frequently wonder whether I’m simply too slow and not clever enough to contribute or learn higher level math.")

#text("I don’t expect a ready made answer from you but I appreciate any comments.")

#text("thanks,")

#text("Nc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bk")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3421")[#strong[#text("bk")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2007")])]

#text("Dear Terry,")#linebreak()#text(" It will be a nice thing to see your words about time management,maybe later?")

#text("And, any forewalker like Dr. Gil Kalai can also give us some advice on how to schedule things.")

#text("Anyway, I’m grateful to see Terry always give precious advice to us.Thank you for your time,really really appreciate it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3461")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2007")])]

#text("Dear anonymous: I still mostly use pen, paper, and blackboard for initial computations or explorations, and then of course I use LaTeX to write things up once I have a viable sketch of an argument. Of course, I also use a lot of on-line resources, ranging from the ArXiV to Mathscinet to Wikipedia to individual home pages. I occasionally use Maple, the OEIS, or some quick-and-dirty C programming, but for the most part, the maths that I do has not yet been formalised to the point where computer assistance is terribly useful. In other parts of mathematics though, such as algebraic combinatorics or applied mathematics, computer assistance is much more valuable. Closer to my own fields, there has recently been some use of rigorous numerics to obtain enough control on the spectrum of various differential operators to obtain some rigorous qualitative results, such as stability of ground states of some PDE.")

#text("Dear John: It is certainly valuable to understand all the perspectives on a given subject (e.g. algebraic, geometric, intuitive, physical, computational, applied, etc.). (See also my page on “learning and relearning one’s field”.)")

#text("Dear Luther: Nowadays, the majority of maths papers are written in English, with a significant minority in French, so I do recommend learning mathematical French (which is actually very similar to mathematical English). In the older literature there are also Russian and German papers, though I have only had to read one German paper in depth (a paper by Plunnecke) and have always been able to find translations of any Russian paper that I needed (I don’t read Russian). But it depends on your field; if for instance you need to read the original papers of Hilbert frequently, then German is recommended :-) . For some local journals one might see papers in the local language of that country (I once looked through a Portugese paper by Santalo, for instance), but even there English is still widely used. In any case, there are always online translation tools such as babelfish if one needs to read a foreign-language paper.")

#text("Dear Nc: Learning mathematics is not a zero-sum game; it does not detract from your own learning if someone else seems to be faster at it, and mathematical research is actually not primarily determined by speed but rather by patience and experience. With a high-school maths background one can already learn a lot of interesting mathematics of relevance to the real world; to pick some examples at random, one can have a lot of fun with elementary cryptography, voting paradoxes, or elementary probability. For most mathematical research, though, you will need at least an undergraduate maths education.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ron")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3472")[#strong[#text("ron")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2007")])]

#text("Dear Terry,")

#text("Do you backup your LaTeX files onto CD just in case you have to reformat?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ravinder")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3561")[#strong[#text("Ravinder")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2007")])]

#text("Dear Terry,")#linebreak()#text(" How difficult is it to change your research area from the one in which you have obtained your Phd to some unrelated area, say from applied mathematics to number theory ?")#linebreak()#text(" Ravinder.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ravinder")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3573")[#strong[#text("Ravinder")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2007")])]

#text("Sorry not you, for any other average graduate student .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Math Student")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3589")[#strong[#text("Math Student")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2007")])]

#text("Dear Anonymous,")

#text("You are, at 23, still young. You’ll get old no matter what you do, so you might as well do something productive and enjoyable.")

#text("I started my math undergrad at 22. After getting used to being in school again, everything went just fine, and I hardly noticed the fact I was a few years older than the other students. I’ll be entering grad school this year.")

#text("My mom just started and finished her masters degree at age 45. Relative to your entire life, a few years is nothing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35ae0b0f48a9abf455ad50781b982b231957540e14a8dd0833fc5a75694a1ce6-afda852f4621bf76fa465bb2d6270d4851d393e3445710edce0bef579e09b2b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tal")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3611")[#strong[#text("Tal")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2007")])]

#text("Dear Anonymous,")

#text("When I was 24, and it was 6 years after high-school and I forgot almost all the math. I didn’t know what sinx is and what derivative is. I stated studying Industrial Engineering becasue it looked like something practical and I got accepted to it. I thought that I will be much weaker than all my class mates. In my first linear algebra and calculus courses I was surprised to find out that I love math, and only at the end of the first year I changed my major to math – imagine how old I was! Today I am finishing my doctorate, some papers are to appear, it seems that one can make some modest contributions even when being ancient – thirty-something.")

#text("If you like it – go for it! It’s far from being late. But I think that you should start (continue) by going to school, even Prof. Tao did.")

#text("BTW – I know personally many maathematicians who – in contract to common knowledge – started to really flower only after 40.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe02d41f30aea51e1754a0a0f13e4bab939c5acfd2da2916f04348997c5f4aef-b32b8de95c3ef965f5f6599496e1bf21dc4bd8232b0fc7254b03aa1ae2199263.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wilson")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3630")[#strong[#text("Wilson")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2007")])]

#text("Dear Dr. Tao,")

#text("You have a very enlightening blog. I am currently in the 2nd year of my undergraduate studies at the University of Western Australia. I have taken the usual 1st and 2nd year units for majors in mathematics. I am thinking of undertaking some research in pure mathematics at ANU at the end of this year, but I am not sure if I have a broad enough knowledge of any single one area to be able to produce a decent paper. What do you believe is the minimum amount of mathematical knowledge and/or experience required before undertaking a research project with a supervisor? Should I wait until I have completed my 3rd year?")

#text("Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ashwell")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3638")[#strong[#text("Ashwell")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2007")])]

#text("Dear,Terry i (anonymous) am thinking on approaching and coming up with a solution to the Riemann hypothesis and still in high school")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kay")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3641")[#strong[#text("Kay")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2007")])]

#text("For anybody considering a career in mathematics, I credit this book with sharpening my understanding of what I needed to do to get into grad school(one of the top 10 programs in the US):")

#text("A Mathematician’s Survival Guide: Graduate School and Early Career Development by Steven Krantz")

#text("I would also highly recommend:")

#text("Letters to a Young Mathematics by Ian Stewart")#linebreak()#text(" (A lot of the questions people are asking are addressed in this book in particular.)")

#text("The Idea Factory: Learning to think at M.I.T by Pepper White")

#text("ron: backing up is an unequivocally good idea (speaking as someone who lost several years of work when his hard drive failed). You should also consider programs like Active@ UNDELETE … if you can read the drive, then you can probably find old files on there even after you reformat.")

#text("Wilson: I would advise getting an idea of what kind of journal you want to publish in. Perhaps a look at this might help with figuring out how to rank journals: ")#link("http://en.wikipedia.org/wiki/Impact_factor")[#text("http://en.wikipedia.org/wiki/Impact_factor")]#linebreak()#text(" After you have figured out what journal you think you would like to publish in, read some papers in the journal and figure out if you think you can match the same standard. If you can’t do it on your own, then think about whether there is a professor (hopefully in the same university or at a university close by) that is willing to work closely with you and help you get there. You should do your homework and take a look at what the professors you are thinking about working with are working on. It works a lot better if you figure out for yourself what part of their work you think you can make a big contribution to. Depending on your background, something in an applied or computational area might be a more realistic goal than something purely theoretical. Finally, I would say, think about what kind of program you want to get into as a graduate student and find out if the typical student that gets accepted to that program needs to have a research paper already published. If not, then you are potentially wasting energy that could be better spent increasing your knowledge base. The more you know, the easier it is to figure out areas where you can improve on the work of others. You should consider that many math PhDs never publish a single paper. I can not find an appropriate source on math PhDs in general so I will give you the following:")

#text("Patterns of Research in Mathematics by Jerrold W. Grossman")

#text("which details the distribution of people who publish 1 or more papers. You will notice that the majority only publish a single paper. Also alternatives which fall short of a published paper but might still enhance your application are doing an undergraduate thesis at your school and/or developing your research project to the point where it can be discussed at length in your graduate school application essay (perhaps even including a copy of your unpublished paper with your graduate school application.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66466fc5b99ae1626727537b5d45fc74c2a2790a7ed627e672f9461b5bf782a3-38985200a120bfca5f6146968fe5ed4dc97c5df5701e44b09927444dab599d74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zaiaku")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3655")[#strong[#text("Zaiaku")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2007")])]

#text("Unless you can seriously save a company money in most cases or atlesat replace someone in the company its going to be pretty rough atleast for a stable career.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3695")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2007")])]

#text("Dear Professor Tao,")

#text("I am a graduate student in Theoretical Computer Science. First of all, I express my deep and sincere gratitude towards you for writing some wonderful pieces of advice, it really helps to learn how world-class mathematician think about these issues.")

#text("I had a quick question about one of your responses. Please feel free to not answer it if you think it is too personal (and/or not pertinent to this discussion). You mentioned (in one of your responses) that “I still mostly use pen, paper, and blackboard for initial computations or explorations, and then of course I use LaTeX to write things up once I have a viable sketch of an argument.” I would imagine it could take a while before you come up with a viable sketch of the argument, so that it can be put into latex. Until that time, how do you take care of all your notes (which I will imagine could be a good volume of paper)? Do you still organize them on a regular basis (daily/weekly), or you keep shoving them in an untouchable territory (that does not seem to be the case)?")

#text("I am asking this since I have this trouble of how to organize my pencil and paper work and when to put that into computer. Putting the work into computer too early does not seem worth while since latex’ing it takes some time and many times the work is regarding some failed attempts to proving something. I do not want to throw that into waste basket either (too early) since sometimes that contains important formulae and derivations.")

#text("Also, if you take notes in the seminars and colloquia, what do you do with those notes? Do you revise them regularly (again, if you do take notes at all), or refer to them only on demand basis? How do you organize the notes taken during seminars etc. in general?")

#text("I will appreciate if you chose to respond to my query. Thanks you very much for your wonderful advice.")

#text("–Anonymous (for a reason)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3722")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2007")])]

#text("To the guy who asked about the necessity of an undergrad background in math:")

#text("It is not a formal necessity, but getting around it is a challenge.")

#text("There was “a guy” who recently got a double PhD in math and computer science at one of the UCs, and he who did not have a bachelor’s degree (he had only a GED , I think). The way he got into the program was by enrolling as a “special student”, taking the grad math courses and doing well. When they realized that he was For Real (not some crank or dilettante), they let him in. He’s now on research staff at a major lab.")

#text("That being said, the guy had to do a lot of background studying on his own to cover the gaps- an undergrad math education is certainly helpful for passing the qualifying exams and for doing research.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3731")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2007")])]

#text("Dear anonymous: regarding the question of when to transfer from notes to LaTeX, I usually find that at some point any given pen-and-paper computation eventually reaches some natural conclusion – for instance, that a certain method can prove X, but not Y, because of counterexample Z or philosophical objection W. If the conclusion is not so exciting (e.g. if it is mostly negative, or all it does is reprove a well-known lemma), then I sometimes write a short “executive summary” of the argument somewhere on my laptop (or in an email to a co-author) – enough so that I can reconstruct the argument later if needed – but don’t bother recording any details unless they were somehow subtle. Then my notes tend to get discarded, as they have served their purpose. So the point is not to laboriously rewrite all of your paper notes verbatim into a LaTeX file, but instead to take advantage of this conversion phase to distill and summarise what you’ve already accomplished. Sometimes, in the process of doing this, I see a loose end, connection, or other natural direction to pursue that I didn’t see in the original exploration. When that happens, one can either just add an annotation to the LaTeX writeup (e.g. “this may possibly be related to X”, “is this bound Y really best possible?”, “is there an analogue of this for Z?”, etc.) or get out another sheet of paper and pursue that connection right away.")

#text("It can be difficult sometimes to get motivated to write something up as LaTeX, but I find that it helps if you view this exercise as an opportunity to get some closure on the computation, so that you can then safely let it slip from your mind without any trace of guilt. It helps if you have kicked yourself in the past for losing all trace of an interesting computation because you were too lazy to TeX it up. :-)")

#text("Other mathematicians do things differently, of course. I know several who keep very elegant and careful handwritten notes, often on some very nice notepad or notebook paper, and only write things up in LaTeX form when their paper is close to complete. This works well too, though it does require a certain amount of discipline and organisation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1214b0041e80eb02e2601b51b3402b3d8e42b22d345a7a351e2121e0cff52730-fcdc1515888e07a0c5ce45d28b19c36bc47323d69a7fbe3ca2af353b33a9709d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fantasy")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3887")[#strong[#text("Fantasy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2007")])]

#text("Dear Terry:")

#text("I am a senior high school student and I’ll be at college the next year. But a problem has confused me for a long time. I like both physics and mathematics, but I can’t make sure which to learn in the future, can you give me some advice according to you opinion of the two subject?")#linebreak()#text(" I’m sorry that my question seems to have little connection with the theme in this page,but I hope you reply to my question.")#linebreak()#text(" Thank you very much.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kay")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3901")[#strong[#text("Kay")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2007")])]

#text("Fantasy:")

#text("I would recommend the following insightful article in clarifying the differences between physics and mathematics:")

#text("“THEORETICAL MATHEMATICS”: TOWARD A CULTURAL")#linebreak()#text(" SYNTHESIS OF MATHEMATICS AND THEORETICAL PHYSICS")

#text("by Arthur Jaffe and Frank Quinn")

#link("http://arxiv.org/PS_cache/math/pdf/9307/9307227v1.pdf")[#text("Click to access 9307227v1.pdf")]

#text("There are some papers in response to this article which are worth reading:")

#link("http://www.ams.org/bull/pre-1996-data/199430-2/199430-2TOC.html")[#text("http://www.ams.org/bull/pre-1996-data/199430-2/199430-2TOC.html")]

#text("you’ll find them at the top of the page.")

#text("The last thing I would add is that there are many mixes of both mathematics and physics such as: theoretical physics, some branches of applied mathematics and mathematical physics. Also, some parts of math have a more physical flavor than others for reasons related to the history of that branch of math, such as say analysis. So perhaps you do not have to commit to one field or the other quite yet.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ron")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3904")[#strong[#text("Ron")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2007")])]

#text("Dear Terry,")

#text("Do you need an undergrad math degree to get into math grad school? Or can you have a degree in say economics, and self-study the math to get into ath grad school?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3908")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2007")])]

#text("Dear Ravinder, Fantasy, and Ron:")

#text("It is actually rather common to enter graduate school with only a fuzzy idea of what one intends to study, and to switch from one subfield to another (or even from one field to another) during one’s study. For instance, I came into grad school with some vague notions of doing either analysis, topology, number theory, or logic (and even toyed with C^* algebras at one point!). It took me a year or two to settle on harmonic analysis. But there are certainly people who come into grad school from other backgrounds, such as physics, CS, or industry. (As for econ, I see the reverse phenomenon more often – i.e. maths majors go into econ grad school – but I am sure there are some econ majors who go into maths.) For a competitive school, you will of course have to produce some evidence of competence in mathematics (e.g. a maths GRE score) to have a reasonable chance of getting in.")

#text("Graduate school is not just about learning a single subject in depth; it is more generally about learning how to learn – how to ask questions, to think, to listen to talks, to read papers, to understand a topic with only minimal assistance from an advisor or lecturer, that sort of thing. Once one has these sorts of skills, and a bit of experience, it becomes easier to get a handle on adjacent fields of study, and possibly to switch into them if you find those fields interesting. While the new field may look superficially very different from the ones you are more used to, in many cases once one studies things a bit more one will find that there are in fact many similarities and common themes (and also some key differences), which will make it easier to pick up than you might first imagine.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59c57b41bed6af30cc795fa69608f3e4c1b31b07b63386f857401605a1b9e6b4-2a3e527e061688ff79a4d2bbf36dfe20530f39117cdf85fddcdb6e8d9fcfdf23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zaiaku")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3910")[#strong[#text("Zaiaku")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2007")])]

#text("Ron ask the exact same question I was about to ask.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32d20b607dd4a46a31b50b296721fa38971f66b82bd92d1f5d175ddc5ec77357-f8e58c684383cc0d9d017fe9cb7460cd650cf256c49ebdc234eea265f863d13a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rcourant")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3913")[#strong[#text("rcourant")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2007")])]

#text("Dear Terry,")

#text("Does a good score on the Putnam exam guarantee admission to many graduate schools? Or is this just a rumor?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-3988")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2007")])]

#text("Fantasy:")

#text("Physics requires math and any physics prof will tell you to take as much math as your schedule will allow. In the first couple years there are only a couple physics and math courses, so it is definitely possible to study both easily at that level. It is also possible to do a double major or even get two degrees (a fellow student graduated with both a stats and a math degree, though it took her an extra year).")

#text("Basically, don’t worry about it, you can study both and choose later (if you don’t want to do both). Just have fun exploring for the time being and your preference (for one or both) will present itself in time.")

#text("But, if you want to know about your specific options, you should refer to the college’s general calendar. If you have further questions, then you could contact the department head(s) of the college you are planning on attending. Though they may direct you to a campus service that specifically deals with these matters.")

#text("Hope that helps.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carlo")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-4051")[#strong[#text("Carlo")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2007")])]

#text("Dear Terry,")

#text("I’m a CS undergrad with passion for math and problem solving.")#linebreak()#text(" I’m looking for a good strategy-construction approach:")#linebreak()#text(" when I’m working on a problem, I usually try to organize and visualize what I")#linebreak()#text(" know, i.e. Lemmas, Thms, ecc…, in a graph-like structure.")#linebreak()#text(" (Maybe this is due to my CS background :) )")#linebreak()#text(" In particular I usually organize my unformal arguments as a forest,")#linebreak()#text(" and I try to see connections between different trees or nodes in order to find the solution, or the crux move, of the problem.")#linebreak()#text(" This seems to help me on getting the big picture, but I still find it difficult to")#linebreak()#text(" note the right strategy, or the crux move, between a lot of fuzzy ideas…")#linebreak()#text(" I would really like to know if this could be an effective style, and how you usually choose and devise the strategy for solving problems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/881d2d3bc132e334e272ea04f3f04b961ef1fe190ebe02d164ed5c998905c4a5-10dc42bade43acbbf436c4c90e1c177169c52ea7c5ff4ccedb218462fca42746.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kaiming")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-4053")[#strong[#text("kaiming")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2007")])]

#text("Hi Terry,")

#text("Andrew Wiles solved the Fermat’s last problem. Will you also be determined to solve one or more of the long standing famous problems like those announced by Clay’s institute of mathematics?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of usman")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-4059")[#strong[#text("usman")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2007")])]

#text("Dear Kaiming!")

#text("Read these two articles, it will help you understand the approach, Dr Tao has.")

#text("Don’t prematurely obsess on a single “big problem” or “big theory”")

#text("Don’t base career decisions on glamour or fame")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ravinder")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-4060")[#strong[#text("Ravinder")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2007")])]

#text("Dear Terry,")#linebreak()#text(" It was nice to see your reply, actually lately I got interested in number theory. I think collaborations play an important role if one wants to shift from one field of study to another, how should one appraoch in this regard ? One personal question how do you work with your collaborators i mean do you discuss things on mails etc or at some point you all get together at some place for discussion ?")#linebreak()#text(" Ravinder.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-4108")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2007")])]

#text("Carlo:")

#text("Dr. Tao has his method of doing things, so do you, so does everyone. Your method works for you and that’s what counts. In time you’ll refine it and what you’re doing now won’t be recognizable relative from how you’ll be doing things then.")

#text("Those fuzzy ideas and difficulties are there /because you’re still learning/. So, keep solving problems and the fuzziness will tend to be shorter lived and the path to the solution will begin to present itself more readily.")

#text("Basically, the common saying, “The only way to learn math is to do math” applies. There is no silver bullet, and there never was, nor IMO will there ever be.")

#text("Just (at least) attempt every problem that you can get your hands on (that time allows for) and ask people about the problems if you can’t get it. If you can, get a couple people that are interested in working on extra problems, and work them out separately. Then get together and present the solutions to each-other. You might be surprised how many (radically) different approaches there can be to a problem. There should be problem books in the library filled with problems to help you with this.")

#text("Aside from that, going to any workshops that might be at your University (Putnam, etc prep.), is pretty much all you can do.")

#text("Good luck!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-4249")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2007")])]

#text("Dear rcourant,")

#text("The winner of the Putnam competition is awarded a graduate scholarship to Harvard. Other than that, there is no official guarantee of any sort, but this type of thing is noticed when the graduate admissions committee looks at an admissions file.")

#text("Dear Ravinder:")

#text("Collaborations have been critically important for me; most of the fields I work in now, I learnt about primarily through a key collaborator. In many cases we started working together almost by chance, for instance when one of us presented work at a conference or seminar and the other realised the relevance to their own interests. Or sometimes you just get along with another mathematician and feel like there should be something one can work on together.")

#text("Most of my collaborations proceed for 99% of the time by email (and occasionally by phone), both of short informal communications and then also sending big LaTeX files back and forth, especially during the process of actually writing a paper. But there is a crucial 1% of the time when we get together face-to-face and tackle the accumulated problems which were difficult to solve on one’s own, or to plan out the future directions of the project.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wilson")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-4332")[#strong[#text("Wilson")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2007")])]

#text("Dear Kay,")

#text("Thank you for your detailed reply. You bring up some very good points that I had not considered before. I’ve decided that I will be applying for the research opportunity at ANU.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew")]], [#link("https://terrytao.wordpress.com/2007/06/08/advice-on-mathematical-careers-and-mathematical-writing/comment-page-1/#comment-7656")[#strong[#text("Andrew")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2007")])]

#text("Dear Terry,")

#text("You talked earlier about mathematical abstraction (i.e lets say we have A –> B — > C –> D). If you do not understand A then you will not understand B, and then will be totally lost by C. The key idea, as you say, is to abstract out important ideas from A that allow you to understand B, and ultimately you will understand A better.")

#text("So my question is lets say I have a textbook on number theory for example. I read it through word by word first just to get the big picture. After learning all of the concepts, I then do the exercises, starting from the beginning. In other words, I do not do the exercises as I go along.")

#text("Do you think that by, for example, reading the whole textbook on number theory first, and then doing the exercises after reading the entire book would ultimately be more beneficial, because you can get an idea of the purpose of the exercises in a bigger context?")

#text("Thanks")
]
