// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/
// Converted to Typst by tao2typ: "2026-10-14T15:18:20.493996+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Montgomery’s uncertainty principle", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Montgomery’s uncertainty principle")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 31 December 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/")[#text("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the most fundamental principles in Fourier analysis is the ")#link("http://en.wikipedia.org/wiki/Fourier_transform#Uncertainty_principle")[#text("uncertainty principle")]#text(". It does not have a single canonical formulation, but one typical informal description of the principle is that if a function ")#mi("{f}")#text(" is restricted to a narrow region of physical space, then its Fourier transform ")#mi("{\\hat f}")#text(" must be necessarily “smeared out” over a broad region of frequency space. Some versions of the uncertainty principle are discussed in ")#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/")[#text("this previous blog post")]#text(".")

#text("In this post I would like to highlight a useful instance of the uncertainty principle, ")#link("http://www.ams.org/mathscinet-getitem?mr=224585")[#text("due to Hugh Montgomery")]#text(", which is useful in analytic number theory contexts. Specifically, suppose we are given a complex-valued function ")#mi("{f: {\\bf Z} \\rightarrow {\\bf C}}")#text(" on the integers. To avoid irrelevant issues at spatial infinity, we will assume that the support ")#mi("{\\text{supp}(f) := \\{ n \\in {\\bf Z}: f(n) \\neq 0 \\}}")#text(" of this function is finite (in practice, we will only work with functions that are supported in an interval ")#mi("{[M+1,M+N]}")#text(" for some natural numbers ")#mi("{M,N}")#text("). Then we can define the Fourier transform ")#mi("{\\hat f: {\\bf R}/{\\bf Z} \\rightarrow {\\bf C}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) := \\sum_{n \\in {\\bf Z}} f(n) e(-n\\xi)")]]

#text("where ")#mi("{e(x) := e^{2\\pi i x}}")#text(". (In some literature, the sign in the exponential phase is reversed, but this will make no substantial difference to the arguments below.)")

#text("The classical uncertainty principle, in this context, asserts that if ")#mi("{f}")#text(" is localised in an interval of length ")#mi("{N}")#text(", then ")#mi("{\\hat f}")#text(" must be “smeared out” at a scale of at least ")#mi("{1/N}")#text(" (and essentially constant at scales less than ")#mi("{1/N}")#text("). For instance, if ")#mi("{f}")#text(" is supported in ")#mi("{[M+1,M+N]}")#text(", then we have the Plancherel identity ")#metadata(none) <tao-ea242a3fb45034524055>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\int_{{\\bf R}/{\\bf Z}} \\left|\\hat f(\\xi)\\right|^2\\ d\\xi = \\left\\| f \\right\\|_{\\ell^2({\\bf Z})}^2", block: true)]]

#text("while from the Cauchy-Schwarz inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\hat f(\\xi)\\right| \\leq N^{1/2} \\left\\| f \\right\\|_{\\ell^2({\\bf Z})}", block: true)]]

#text("for each frequency ")#mi("{\\xi}")#text(", and in particular that")

#align(center)[#tao-fit-display[#tao-math("\\int_I \\left|\\hat f(\\xi)\\right|^2\\ d\\xi \\leq N \\left|I\\right| \\left\\| f \\right\\|_{\\ell^2({\\bf Z})}^2", block: true)]]

#text("for any arc ")#mi("{I}")#text(" in the unit circle (with ")#tao-math("{\\left|I\\right|}", block: false)#text(" denoting the length of ")#mi("{I}")#text("). In particular, an interval of length significantly less than ")#mi("{1/N}")#text(" can only capture a fraction of the ")#mi("{L^2}")#text(" energy of the Fourier transform of ")#mi("{\\hat f}")#text(", which is consistent with the above informal statement of the uncertainty principle.")

#text("Another manifestation of the classical uncertainty principle is the ")#link("http://en.wikipedia.org/wiki/Large_sieve")[#text("large sieve inequality")]#text(". A particularly nice formulation of this inequality is due independently to ")#link("http://www.ams.org/mathscinet-getitem?mr=374060")[#text("Montgomery and Vaughan")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1295844")[#text("Selberg")]#text(": if ")#mi("{f}")#text(" is supported in ")#mi("{[M+1,M+N]}")#text(", and ")#mi("{\\xi_1,\\ldots,\\xi_J}")#text(" are frequencies in ")#mi("{{\\bf R}/{\\bf Z}}")#text(" that are ")#mi("{\\delta}")#text("-separated for some ")#mi("{\\delta>0}")#text(", thus ")#tao-math("{\\left\\| \\xi_i-\\xi_j\\right\\|_{{\\bf R}/{\\bf Z}} \\geq \\delta}", block: false)#text(" for all ")#mi("{1 \\leq i<j \\leq J}")#text(" (where ")#tao-math("{\\left\\|\\xi\\right\\|_{{\\bf R}/{\\bf Z}}}", block: false)#text(" denotes the distance of ")#mi("{\\xi}")#text(" to the origin in ")#mi("{{\\bf R}/{\\bf Z}}")#text("), then ")#metadata(none) <tao-3e4141e024dfd062b002>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\sum_{j=1}^J \\left|\\hat f(\\xi_j)\\right|^2 \\leq (N + \\frac{1}{\\delta}) \\left\\| f \\right\\|_{\\ell^2({\\bf Z})}^2.", block: true)]]

#text("The reader is encouraged to see how this inequality is consistent with the Plancherel identity ")#link(<tao-ea242a3fb45034524055>)[#text("(1)")]#text(" and the intuition that ")#mi("{\\hat f}")#text(" is essentially constant at scales less than ")#mi("{1/N}")#text(". The factor ")#mi("{N + \\frac{1}{\\delta}}")#text(" can in fact be amplified a little bit to ")#mi("{N + \\frac{1}{\\delta} - 1}")#text(", which is essentially optimal, by using a neat dilation trick of Paul Cohen, in which one dilates ")#mi("{[M+1,M+N]}")#text(" to ")#mi("{[MK+K, MK+NK]}")#text(" (and replaces each frequency ")#mi("{\\xi_j}")#text(" by their ")#mi("{K^{th}}")#text(" roots), and then sending ")#mi("{K \\rightarrow \\infty}")#text(" (cf. the ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("tensor product trick")]#text("); see ")#link("http://www.ams.org/leavingmsn?url=http://dx.doi.org/10.1090/S0002-9904-1978-14497-8")[#text("this survey of Montgomery")]#text(" for details. But we will not need this refinement here.")

#text("In the above instances of the uncertainty principle, the concept of narrow support in physical space was formalised in the ")#link("http://en.wikipedia.org/wiki/Archimedean_absolute_value")[#text("Archimedean")]#text(" sense, using the standard Archimedean metric ")#tao-math("{d_\\infty(n,m) := \\left|n-m\\right|}", block: false)#text(" on the integers ")#mi("{{\\bf Z}}")#text(" (in particular, the parameter ")#mi("{N}")#text(" is essentially the Archimedean diameter of the support of ")#mi("{f}")#text("). However, in number theory, the Archimedean metric is not the only metric of importance on the integers; the ")#mi("{p}")#text("-adic metrics play an equally important role; indeed, it is common to unify the Archimedean and ")#mi("{p}")#text("-adic perspectives together into a unified ")#link("http://en.wikipedia.org/wiki/Adele_ring")[#text("adelic")]#text(" perspective. In the ")#mi("{p}")#text("-adic world, the metric balls are no longer intervals, but are instead residue classes modulo some power of ")#mi("{p}")#text(". Intersecting these balls from different ")#mi("{p}")#text("-adic metrics together, we obtain residue classes with respect to various moduli ")#mi("{q}")#text(" (which may be either prime or composite). As such, another natural manifestation of the concept of “narrow support in physical space” is “vanishes on many residue classes modulo ")#mi("{q}")#text("“. This notion of narrowness is particularly common in sieve theory, when one deals with functions supported on thin sets such as the primes, which naturally tend to avoid many residue classes (particularly if one throws away the first few primes).")

#text("In this context, the uncertainty principle is this: the more residue classes modulo ")#mi("{q}")#text(" that ")#mi("{f}")#text(" avoids, the more the Fourier transform ")#mi("{\\hat f}")#text(" must spread out along multiples of ")#mi("{1/q}")#text(". To illustrate a very simple example of this principle, let us take ")#mi("{q=2}")#text(", and suppose that ")#mi("{f}")#text(" is supported only on odd numbers (thus it completely avoids the residue class ")#mi("{0 \\mod 2}")#text("). We write out the formulae for ")#mi("{\\hat f(\\xi)}")#text(" and ")#mi("{\\hat f(\\xi+1/2)}")#text(":")

#tao-aligned(keep: true)[


#tao-math("\\hat f(\\xi)  & = \\sum_n f(n) e(-n\\xi)", block: true)



#tao-math("\\hat f(\\xi+1/2)  & = \\sum_n f(n) e(-n\\xi) e(-n/2).", block: true)
]

#text("If ")#mi("{f}")#text(" is supported on the odd numbers, then ")#mi("{e(-n/2)}")#text(" is always equal to ")#mi("{-1}")#text(" on the support of ")#mi("{f}")#text(", and so we have ")#mi("{\\hat f(\\xi+1/2)=-\\hat f(\\xi)}")#text(". Thus, whenever ")#mi("{\\hat f}")#text(" has a significant presence at a frequency ")#mi("{\\xi}")#text(", it also must have an equally significant presence at the frequency ")#mi("{\\xi+1/2}")#text("; there is a spreading out across multiples of ")#mi("{1/2}")#text(". Note that one has a similar effect if ")#mi("{f}")#text(" was supported instead on the even integers instead of the odd integers.")

#text("A little more generally, suppose now that ")#mi("{f}")#text(" avoids a single residue class modulo a prime ")#mi("{p}")#text("; for sake of argument let us say that it avoids the zero residue class ")#mi("{0 \\mod p}")#text(", although the situation for the other residue classes is similar. For any frequency ")#mi("{\\xi}")#text(" and any ")#mi("{j=0,\\ldots,p-1}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi+j/p) = \\sum_n f(n) e(-n\\xi) e(-jn/p).")]]

#text("From basic Fourier analysis, we know that the phases ")#mi("{e(-jn/p)}")#text(" sum to zero as ")#mi("{j}")#text(" ranges from ")#mi("{0}")#text(" to ")#mi("{p-1}")#text(" whenever ")#mi("{n}")#text(" is not a multiple of ")#mi("{p}")#text(". We thus have")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=0}^{p-1} \\hat f(\\xi+j/p) = 0.")]]

#text("In particular, if ")#mi("{\\hat f(\\xi)}")#text(" is large, then one of the other ")#mi("{\\hat f(\\xi+j/p)}")#text(" has to be somewhat large as well; using the Cauchy-Schwarz inequality, we can quantify this assertion in an ")#mi("{\\ell^2}")#text(" sense via the inequality ")#metadata(none) <tao-619bc82e0d200e4ad4e6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\sum_{j=1}^{p-1} \\left|\\hat f(\\xi+j/p)\\right|^2 \\geq \\frac{1}{p-1} \\left|\\hat f(\\xi)\\right|^2.", block: true)]]

#text("Let us continue this analysis a bit further. Now suppose that ")#mi("{f}")#text(" avoids ")#mi("{\\omega(p)}")#text(" residue classes modulo a prime ")#mi("{p}")#text(", for some ")#mi("{0 \\leq \\omega(p) < p}")#text(". (We exclude the case ")#mi("{\\omega(p)=p}")#text(" as it is clearly degenerates by forcing ")#mi("{f}")#text(" to be identically zero.) Let ")#mi("{\\nu(n)}")#text(" be the function that equals ")#mi("{1}")#text(" on these residue classes and zero away from these residue classes, then")

#align(center)[#tao-fit-display[#mitex("\\sum_n f(n) e(-n\\xi) \\nu(n) = 0.")]]

#text("Using the periodic Fourier transform, we can write")

#align(center)[#tao-fit-display[#mitex("\\nu(n) = \\sum_{j=0}^{p-1} c(j) e(-jn/p)")]]

#text("for some coefficients ")#mi("{c(j)}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=0}^{p-1} \\hat f(\\xi+j/p) c(j) = 0.")]]

#text("Some Fourier-analytic computations reveal that")

#align(center)[#tao-fit-display[#mitex("c(0) = \\frac{\\omega(p)}{p}")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=0}^{p-1} \\left|c(j)\\right|^2 = \\frac{\\omega(p)}{p}", block: true)]]

#text("and so after some routine algebra and the Cauchy-Schwarz inequality, we obtain a generalisation of ")#link(<tao-619bc82e0d200e4ad4e6>)[#text("(3)")]#text(":")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^{p-1} \\left|\\hat f(\\xi+j/p)\\right|^2 \\geq \\frac{\\omega(p)}{p-\\omega(p)} \\left|\\hat f(\\xi)\\right|^2.", block: true)]]

#text("Thus we see that the more residue classes mod ")#mi("{p}")#text(" we exclude, the more Fourier energy has to disperse along multiples of ")#mi("{1/p}")#text(". It is also instructive to consider the extreme case ")#mi("{\\omega(p)=p-1}")#text(", in which ")#mi("{f}")#text(" is supported on just a single residue class ")#mi("{a \\mod p}")#text("; in this case, one clearly has ")#mi("{\\hat f(\\xi+j/p) = e(-aj/p) \\hat f(\\xi)}")#text(", and so ")#mi("{\\hat f}")#text(" spreads its energy completely evenly along multiples of ")#mi("{1/p}")#text(".")

#text("In 1968, ")#link("http://www.ams.org/mathscinet-getitem?mr=224585")[#text("Montgomery observed")]#text(" the following useful generalisation of the above calculation to arbitrary modulus:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Montgomery’s uncertainty principle)")]#text(" ")#metadata(none) <tao-bb3a99af341e48897552>#text(" Let ")#mi("{f: {\\bf Z} \\rightarrow{\\bf C}}")#text(" be a finitely supported function which, for each prime ")#mi("{p}")#text(", avoids ")#mi("{\\omega(p)}")#text(" residue classes modulo ")#mi("{p}")#text(" for some ")#mi("{0 \\leq \\omega(p) < p}")#text(". Then for each natural number ")#mi("{q}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{1 \\leq a \\leq q: (a,q)=1} \\left|\\hat f(\\xi+\\frac{a}{q})\\right|^2 \\geq h(q) \\left|\\hat f(\\xi)\\right|^2", block: true)]]

#text("where ")#mi("{h(q)}")#text(" is the quantity ")#metadata(none) <tao-4c92664329558154c522>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("h(q) := \\mu(q)^2 \\prod_{p|q} \\frac{\\omega(p)}{p-\\omega(p)}")]]

#text("where ")#mi("{\\mu}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Mobius_function")[#text("Möbius function")]#text(".")
]

#text("We give a proof of this proposition below the fold.")

#text("Following the “adelic” philosophy, it is natural to combine this uncertainty principle with the large sieve inequality to take simultaneous advantage of localisation both in the Archimedean sense and in the ")#mi("{p}")#text("-adic senses. This leads to the following corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2 (Arithmetic large sieve inequality)")]#text(" ")#metadata(none) <tao-1d286cdd6208c38c767f>#text(" Let ")#mi("{f: {\\bf Z} \\rightarrow {\\bf C}}")#text(" be a function supported on an interval ")#mi("{[M+1,M+N]}")#text(" which, for each prime ")#mi("{p}")#text(", avoids ")#mi("{\\omega(p)}")#text(" residue classes modulo ")#mi("{p}")#text(" for some ")#mi("{0 \\leq \\omega(p) < p}")#text(". Let ")#mi("{\\xi_1,\\ldots,\\xi_J \\in {\\bf R}/{\\bf Z}}")#text(", and let ")#mi("{{\\mathcal Q}}")#text(" be a finite set of natural numbers. Suppose that the frequencies ")#mi("{\\xi_j + \\frac{a}{q}}")#text(" with ")#mi("{1 \\leq j \\leq J}")#text(", ")#mi("{q \\in {\\mathcal Q}}")#text(", and ")#mi("{(a,q)=1}")#text(" are ")#mi("{\\delta}")#text("-separated. Then one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^J \\left|\\hat f(\\xi_j)\\right|^2 \\leq \\frac{N + \\frac{1}{\\delta}}{\\sum_{q \\in {\\mathcal Q}} h(q)} \\left\\| f \\right\\|_{\\ell^2({\\bf Z})}^2", block: true)]]

#text("where ")#mi("{h(q)}")#text(" was defined in ")#link(<tao-4c92664329558154c522>)[#text("(4)")]#text(".")
]

#text("Indeed, from the large sieve inequality one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^J \\sum_{q \\in {\\mathcal Q}} \\sum_{1 \\leq a \\leq q: (a,q)=1} \\left|\\hat f(\\xi_j+\\frac{a}{q})\\right|^2 \\leq (N + \\frac{1}{\\delta}) \\left\\| f \\right\\|_{\\ell^2({\\bf Z})}^2", block: true)]]

#text("while from Proposition ")#link(<tao-bb3a99af341e48897552>)[#text("1")]#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\in {\\mathcal Q}} \\sum_{1 \\leq a \\leq q: (a,q)=1} \\left|\\hat f(\\xi_j+\\frac{a}{q})\\right|^2 \\geq (\\sum_{q \\in {\\mathcal Q}} h(q)) \\left|\\hat f(\\xi_j)\\right|^2", block: true)]]

#text("whence the claim.")

#text("There is a great deal of flexibility in the above inequality, due to the ability to select the set ")#mi("{{\\mathcal Q}}")#text(", the frequencies ")#mi("{\\xi_1,\\ldots,\\xi_J}")#text(", the omitted classes ")#mi("{\\omega(p)}")#text(", and the separation parameter ")#mi("{\\delta}")#text(". Here is a typical application concerning the original motivation for the large sieve inequality, namely in bounding the size of sets which avoid many residue classes:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3 (Large sieve)")]#text(" Let ")#mi("{A}")#text(" be a set of integers contained in ")#mi("{[M+1,M+N]}")#text(" which avoids ")#mi("{\\omega(p)}")#text(" residue classes modulo ")#mi("{p}")#text(" for each prime ")#mi("{p}")#text(", and let ")#mi("{R>0}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\left|A\\right| \\leq \\frac{N+R^2}{G(R)}", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("G(R) := \\sum_{q \\leq R} h(q).")]]
]

#emph[#text("Proof:")]#text(" We apply Corollary ")#link(<tao-1d286cdd6208c38c767f>)[#text("2")]#text(" with ")#mi("{f = 1_A}")#text(", ")#mi("{J=1}")#text(", ")#mi("{\\delta=1/R^2}")#text(", ")#mi("{\\xi_1=0}")#text(", and ")#mi("{{\\mathcal Q} := \\{ q: q \\leq R\\}}")#text(". The key point is that the ")#link("http://en.wikipedia.org/wiki/Farey_sequence")[#text("Farey sequence")]#text(" of fractions ")#mi("{a/q}")#text(" with ")#mi("{q \\leq R}")#text(" and ")#mi("{(a,q)=1}")#text(" is ")#mi("{1/R^2}")#text("-separated, since")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\frac{a}{q}-\\frac{a^{\\prime}}{q^{\\prime}} \\right\\|_{{\\bf R}/{\\bf Z}} \\geq \\frac{1}{qq^{\\prime}} \\geq \\frac{1}{R^2}", block: true)]]

#text("whenever ")#mi("{a/q, a^{\\prime}/q^{\\prime}}")#text(" are distinct fractions in this sequence. ")#mi("\\Box")

#text("If, for instance, ")#mi("{A}")#text(" is the set of all primes in ")#mi("{[M+1,M+N]}")#text(" larger than ")#mi("{R}")#text(", then one can set ")#mi("{\\omega(p)=1}")#text(" for all ")#mi("{p \\leq R}")#text(", which makes ")#mi("{h(q) = \\frac{\\mu^2(q)}{\\phi(q)}}")#text(", where ")#mi("{\\phi}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Euler%27s_totient_function")[#text("Euler totient function")]#text(". It is a classical estimate that")

#align(center)[#tao-fit-display[#mitex("G(R) = \\log R + O(1).")]]

#text("Using this fact and optimising in ")#mi("{R}")#text(", we obtain (a special case of) the ")#link("http://en.wikipedia.org/wiki/Brun-Titchmarsh_theorem")[#text("Brun-Titchmarsh inequality")]

#align(center)[#tao-fit-display[#mitex("\\pi(M+N)-\\pi(M) \\leq (2+o_{N \\rightarrow \\infty}(1)) \\frac{N}{\\log N}")]]

#text("where ")#mi("{\\pi(x)}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Prime_counting_function")[#text("prime counting function")]#text("; a variant of the same argument gives the more general Brun-Titchmarsh inequality")

#align(center)[#tao-fit-display[#mitex("\\pi(M+N;a,q)-\\pi(M;a,q) \\leq (2+o_{N \\rightarrow \\infty;q}(1)) \\frac{q}{\\phi(q)} \\frac{N}{\\log N}")]]

#text("for any primitive residue class ")#mi("{a \\mod q}")#text(", where ")#mi("{\\pi(M;a,q)}")#text(" is the number of primes less than or equal to ")#mi("{M}")#text(" that are congruent to ")#mi("{a \\mod q}")#text(". By performing a more careful optimisation using a slightly sharper version of the large sieve inequality ")#link(<tao-3e4141e024dfd062b002>)[#text("(2)")]#text(" that exploits the irregular spacing of the Farey sequence, Montgomery and Vaughan were able to delete the error term in the Brun-Titchmarsh inequality, thus establishing the very nice inequality")

#align(center)[#tao-fit-display[#mitex("\\pi(M+N;a,q)-\\pi(M;a,q) \\leq 2 \\frac{q}{\\phi(q)} \\frac{N}{\\log N}")]]

#text("for any natural numbers ")#mi("{M,N,a,q}")#text(" with ")#mi("{N>1}")#text(". This is a particularly useful inequality in non-asymptotic analytic number theory (when one wishes to study number theory at explicit orders of magnitude, rather than the number theory of sufficiently large numbers), due to the absence of asymptotic notation.")

#text("I recently realised that Corollary ")#link(<tao-1d286cdd6208c38c767f>)[#text("2")]#text(" also establishes a stronger version of the “restriction theorem for the Selberg sieve” that ")#link("http://www.ams.org/mathscinet-getitem?mr=2245880")[#text("Ben Green and I proved some years ago")]#text(" (indeed, one can view Corollary ")#link(<tao-1d286cdd6208c38c767f>)[#text("2")]#text(" as a “restriction theorem for the large sieve”). I’m placing the details below the fold.")

#metadata(none) <tao-90318da146036e698c2c>

#heading(level: 1)[#strong[#text(" — 1. Proof of uncertainty principle — ")]]

#text("We now prove Proposition ")#link(<tao-bb3a99af341e48897552>)[#text("1")]#text(". As with the case when ")#mi("{q}")#text(" is prime, the idea is to work by duality, testing ")#mi("{f}")#text(" against a suitably chosen test function ")#mi("{\\nu}")#text(" and using the Cauchy-Schwarz inequality.")

#text("By replacing ")#mi("{f(n)}")#text(" with the modulated function ")#mi("{f(n) e(n\\xi)}")#text(", we may assume without loss of generality that ")#mi("{\\xi=0}")#text(". We may of course assume that ")#mi("{q}")#text(" is square-free, and that ")#mi("{\\omega(p) > 0}")#text(" for all ")#mi("{p|q}")#text(", since otherwise ")#mi("{h(q)=0}")#text(" and the claim is vacuously true. Let us abbreviate the summation ")#mi("{\\sum_{1 \\leq a \\leq q: (a,q)=1}}")#text(" as ")#mi("{\\sum_{a}^*}")#text(", thus our task is to show that ")#metadata(none) <tao-04a92cab51b3f445453a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\sum_{a}^* \\left|\\hat f(\\frac{a}{q})\\right|^2 \\geq \\left|\\hat f(0)\\right|^2 h(q).", block: true)]]

#text("For each prime ")#mi("{p}")#text(" dividing ")#mi("{q}")#text(", let ")#mi("{S_p}")#text(" be the union of the ")#mi("{\\omega(p)}")#text(" residue classes modulo ")#mi("{p}")#text(" which avoid ")#mi("{A}")#text(". It turns out that the optimal choice for ")#mi("{\\nu}")#text(" is the function")

#align(center)[#tao-fit-display[#mitex("\\nu(n) := \\prod_{p|q} (\\omega(p) - p 1_{S_p}).")]]

#text("On the one hand, we see that ")#mi("{\\nu(n)}")#text(" is equal to ")#mi("{\\omega(q) := \\prod_{p|q} \\omega(p)}")#text(" on the support of ")#mi("{f}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}} \\nu(n) f(n) = \\omega(q) \\hat f(0).")]]

#text("On the other hand, each ")#mi("{\\omega(p)-p 1_{S_p}}")#text(" is mean zero and periodic of period ")#mi("{p}")#text(", and thus a linear combination of phases ")#mi("{e(an/p)}")#text(" with ")#mi("{a}")#text(" coprime to ")#mi("{p}")#text(". Multiplying together, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\nu(n) = \\sum_{a \\in {\\bf Z}/q{\\bf Z}: (a,q)=1} c(a) e(an/q)")]]

#text("for some coefficients ")#mi("{c(n)}")#text(". Taking the inner product against ")#mi("{f}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}} \\nu(n) f(n) = \\sum_{a}^* \\overline{c(a)} \\hat f(a/q).")]]

#text("By Cauchy-Schwarz, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\in {\\bf Z}} \\nu(n) f(n)\\right| \\leq (\\sum_{a}^* \\left|\\hat f(a/q)\\right|^2)^{1/2} (\\sum_{a}^* \\left|c(a)\\right|^2)^{1/2}.", block: true)]]

#text("But by the Plancherel identity we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{a}^* \\left|c(a)\\right|^2 = \\mathop{\\bf E}_{n \\in {\\bf Z}/q{\\bf Z}} \\nu(n)^2.", block: true)]]

#text("Note that ")#mi("{(\\omega(p)-p1_{S_p})^2}")#text(" has mean ")#mi("{(p-\\omega(p)) \\omega(p)}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in {\\bf Z}/q{\\bf Z}} \\nu(n)^2 = \\prod_{p|q} (p-\\omega(p)) \\omega(p).")]]

#text("Putting everything together, we obtain ")#link(<tao-04a92cab51b3f445453a>)[#text("(5)")]#text(" as required.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The factor of ")#mi("{h(q)}")#text(" in the uncertainty principle is sharp, as can be seen by computing what happens when ")#mi("{f := \\prod_{p|q} (1-1_{S_p})}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 2. Restriction theory of the large sieve — ")]]

#text("The hypotheses of Corollary ")#link(<tao-1d286cdd6208c38c767f>)[#text("2")]#text(" are somewhat inconvenient to work with. We can specialise Corollary ")#link(<tao-1d286cdd6208c38c767f>)[#text("2")]#text(" to a more tractable version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Special case of large sieve inequality)")]#text(" ")#metadata(none) <tao-89df50537dd8255045c5>#text(" Let ")#mi("{f: {\\bf Z} \\rightarrow {\\bf C}}")#text(" be a function supported on an interval ")#mi("{[M+1,M+N]}")#text(" which, for each prime ")#mi("{p}")#text(", avoids ")#mi("{\\omega(p)}")#text(" residue classes modulo ")#mi("{p}")#text(" for some ")#mi("{0 \\leq \\omega(p) < p}")#text(". Let ")#mi("{\\xi_1,\\ldots,\\xi_J \\in {\\bf R}/{\\bf Z}}")#text(", and ")#mi("{R := (2\\delta)^{-1/4}}")#text(". Then one has ")#metadata(none) <tao-7e6e9877fff0dbcc576d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\sum_{j=1}^J \\left|\\hat f(\\xi_j)\\right|^2 \\leq (\\prod_{p \\in {\\mathcal P}} (1-\\frac{\\omega(p)}{p}))^{-1} \\frac{N + \\frac{1}{\\delta}}{G(R)} \\left\\| f \\right\\|_{\\ell^2({\\bf Z})}^2,", block: true)]]

#text("where ")#mi("{{\\mathcal P}}")#text(" is a set of at most ")#mi("{\\binom{J}{2}}")#text(" primes.")
]

#emph[#text("Proof:")]#text(" Observe that for each ")#mi("{1 \\leq i < j \\leq J}")#text(", there is at most one fraction ")#mi("{\\frac{a}{q}}")#text(" with ")#mi("{q < R^2}")#text(" such that ")#tao-math("{\\left\\| \\xi_i - \\xi_j - \\frac{a}{q} \\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\delta}", block: false)#text(". Indeed, if there were two such fractions ")#mi("{\\frac{a}{q}, \\frac{a^{\\prime}}{q^{\\prime}}}")#text(", then we would have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\frac{a}{q} - \\frac{a^{\\prime}}{q^{\\prime}} \\right\\| \\leq 2\\delta", block: true)]]

#text("by the triangle inequality. On the other hand, the left-hand side is at least ")#mi("{1/qq^{\\prime} > R^{-4}}")#text(", contradicting the definition of ")#mi("{R}")#text(".")

#text("By selecting at most one prime for each of the ")#mi("{\\binom{J}{2}}")#text(" pairs ")#mi("{(i,j)}")#text(" with ")#mi("{1 \\leq i < j \\leq J}")#text(", we may thus find a natural number ")#mi("{k}")#text(" that is the product of at most ")#mi("{\\binom{J}{2}}")#text(" primes, and with the property that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\xi_i - \\xi_j - \\frac{a}{q} \\right\\| > \\delta", block: true)]]

#text("whenever ")#mi("{q < R^2}")#text(", ")#mi("{1 \\leq i < j \\leq J}")#text(", and ")#mi("{(q,k)=1}")#text(". From this (and ")#link(<tao-3e4141e024dfd062b002>)[#text("(2)")]#text(") we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\xi_i + \\frac{a}{q}) - (\\xi_j + \\frac{a^{\\prime}}{q^{\\prime}}) \\right\\| > \\delta", block: true)]]

#text("whenever ")#mi("{1 \\leq i,j \\leq J}")#text(" and ")#mi("{q, q^{\\prime} \\leq R}")#text(" with ")#mi("{(q,k) = (q^{\\prime},k)=1}")#text(", with either ")#mi("{i \\neq j}")#text(" or ")#mi("{a/q \\neq a^{\\prime}/q^{\\prime}}")#text(". Applying Corollary ")#link(<tao-1d286cdd6208c38c767f>)[#text("2")]#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^J \\left|\\hat f(\\xi_j)\\right|^2 \\leq \\frac{N + \\frac{1}{\\delta}}{\\sum_{q \\leq R; (q,k)=1} h(q)} \\left\\| f \\right\\|_{\\ell^2({\\bf Z})}^2.", block: true)]]

#text("On the other hand, from the multiplicative (and non-negative) nature of ")#mi("{h}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("(\\sum_{q \\leq R; (q,k)=1} h(q)) (\\sum_{q|k} h(q)) \\geq \\sum_{q \\leq R} h(q) = G(R).")]]

#text("Writing ")#mi("{{\\mathcal P}}")#text(" as the primes dividing ")#mi("{k}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_{q|k} h(q) = (\\prod_{p \\in {\\mathcal P}} (1-\\frac{\\omega(p)}{p}))^{-1}.")]]

#text("The claim follows. ")#mi("\\Box")

#text("Suppose that ")#mi("{\\omega(p) \\leq k}")#text(" for all primes ")#mi("{p}")#text(" and some fixed ")#mi("{k}")#text(". Then from Mertens’ theorem, we have")

#align(center)[#tao-fit-display[#tao-math("(\\prod_{p \\in {\\mathcal P}} (1-\\frac{\\omega(p)}{p}))^{-1} \\ll_k \\log^k \\left|{\\mathcal P}\\right| \\ll_k 1+\\log^k J.", block: true)]]

#text("Also, one has the standard sieve theory bound")

#align(center)[#tao-fit-display[#mitex("G(R) \\gg_k \\frac{1}{{\\mathfrak G}} \\log^k R")]]

#text("where ")#mi("{{\\mathfrak G}}")#text(" is the singular series")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak G} = \\prod_{p \\leq R} \\frac{1-\\frac{\\omega}{p}}{(1-\\frac{1}{p})^k}.")]]

#text("This bound can be established by a variety of techniques (e.g. by estimating the Dirichlet series ")#mi("{\\sum_n \\frac{h(n)}{n^\\epsilon}}")#text(" for small values of ")#mi("{\\epsilon}")#text("), and can for instance be found in Lemma 4.1 of ")#link("http://www.ams.org/mathscinet-getitem?mr=424730")[#text("this text of Halberstam and Richert")]#text(". Putting this together, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^J \\left|\\hat f(\\xi_j)\\right|^2 \\ll_k {\\mathfrak G} (1+\\log^k J) \\frac{N + \\frac{1}{\\delta}}{\\log^k R} \\left\\| f \\right\\|_{\\ell^2({\\bf Z})}^2.", block: true)]]

#text("Setting ")#mi("{\\delta := 1/N}")#text(", we can simplify this a bit to")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^J \\left|\\hat f(\\xi_j)\\right|^2 \\ll_k {\\mathfrak G} (1+\\log^k J) \\frac{N}{\\log^k N} \\left\\| f \\right\\|_{\\ell^2({\\bf Z})}^2.", block: true)]]

#text("Note the very slow growth in ")#mi("{J}")#text(". It is not difficult to use this bound to obtain the ")#mi("{\\ell^p}")#text(" variant")

#align(center)[#tao-fit-display[#tao-math("(\\sum_{j=1}^J \\left|\\hat f(\\xi_j)\\right|^p)^{1/p} \\ll_{k,p} {\\mathfrak G}^{1/2} (\\frac{N}{\\log^k N})^{1/2} \\left\\| f \\right\\|_{\\ell^2({\\bf Z})}", block: true)]]

#text("for any ")#mi("{2 < p \\leq \\infty}")#text(" and any ")#mi("{1/N}")#text("-separated ")#mi("{\\xi_1,\\ldots,\\xi_J}")#text(". Averaging, we obtain a restriction theorem")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\hat f \\right\\|_{L^p({\\bf R}/{\\bf Z})} \\ll_{k,p} {\\mathfrak G}^{1/2} \\frac{N^{1/2-1/p}}{\\log^{k/2} N} \\left\\| f \\right\\|_{\\ell^2({\\bf Z})}", block: true)]]

#text("which is essentially Proposition 4.2 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2245880")[#text("my paper with Ben Green")]#text(" (but with the Selberg sieve replaced by the large sieve). As such, it can be used to deduce many of the other results in that paper. For instance, one has the following strengthening of Theorem 1.1 in that paper: if ")#mi("{A}")#text(" is a subset of ")#mi("{[M+1,M+N]}")#text(" that avoids ")#mi("{\\omega(p)}")#text(" residue classes mod ")#mi("{p}")#text(" for each ")#mi("{p}")#text(" and some ")#mi("{0 \\leq \\omega(p) \\leq k}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\hat 1_A \\right\\|_{L^p({\\bf R}/{\\bf Z})} \\ll_{k,p} {\\mathfrak G} N^{1-1/p} \\log^{-k} N", block: true)]]

#text("for all ")#mi("{2 < p \\leq \\infty}")#text(". If ")#tao-math("{\\left|A\\right| \\geq \\delta N / \\log^k N}", block: false)#text(" for some ")#mi("{\\delta>0}")#text(", and ")#mi("{N}")#text(" is sufficiently large depending on ")#mi("{\\delta,k,{\\mathfrak G}}")#text(", one can then show that ")#mi("{A}")#text(" contains arithmetic progressions of length three by repeating the arguments in Section 6 of that paper; among other things, this reproves our result that there are infinitely many progressions of length three among the ")#link("http://en.wikipedia.org/wiki/Chen_prime")[#text("Chen primes")]#text(" (which arises from the two-dimensional case ")#mi("{k=2}")#text(" of the above assertion).")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/#comment-119921")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2012")])]

#text("Very interesting! I’d never thought of the large sieve in these terms… I wonder how far this point of view extends to more general forms of the large sieve, especially involving non-abelian finite groups as quotients. (My current favorite proof of Prop. 1 and Cor. 3 is the amplification-based one in ")#link("http://www.math.ethz.ch/~kowalski/two-remarks-large-sieve.pdf")[#text("this paper")]#text(" of mine.)")

#text("Concerning the relation of the large sieve with the Selberg sieve, I think a number of people have found links in various contexts (one reference I’ve put in the paper I refer to above is to p. 125 of Halberstam and Richert). But I’ve never properly understood these relations.")

#text("P.S. A typo: there’s a missing argument (p) towards the end of section 1, in “note that …. has mean ….”")#linebreak()#text(" Also in the beginning of Section 1, after the definition of nu(n), I’m puzzled by what \\pi_i means?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/#comment-119927")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2012")])]

#text("Thanks for the corrections! (The ")#mi("\\pi_i")#text(" should be ")#mi("\\omega(q) = \\prod_{p|q} \\omega(p)")#text(", but for some reason the LaTeX renderer is giving an incorrect image right now, although the ALT-text is fine.)")

#text("I think the methods in your paper are in some sense complementary to the ones in this post. In your paper you have an amplifier which is large on the sifted set, but small on average outside of it, whereas here I use weights ")#mi("\\nu")#text(" which are small (in fact, constant) on the sifted set but large outside of it. But the numerology and formulae for the weights in the divisor sum seem to be rather similar nonetheless. (Incidentally, I arrived at these weights by performing a Selberg optimisation process similar to the one in your paper, though I didn’t present these rather tedious computations in the actual post.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/#comment-120229")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2012")])]

#text("Emmanuel,")

#text("My experience of statements as to how the Selberg sieve and the large sieve are supposedly ‘dual’ is in general the same as yours. However, there seems to be some material directly relevant to this in Friedlander-Iwaniec’s new book (Opera de Cribro). Tell me if you want to take a look together.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/#comment-120250")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2012")])]

#text("Thanks! Indeed, there is a section 9.5 “Where Linnik meets Selberg: a duet”…. I hadn’t noticed that before so I will have a look…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/#comment-120282")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2012")])]

#text("Hi Professor Tao, from his writings, I realized that the indeterministic has a vision, now I mean, I have carefully read the article on the uncertainty principle, and I realized that she is an indeterminate, but how? I purely mathematical proof of the ‘rise of determinism, indeterminism is the result of our ignorance because as Albert Einstein said God does not play dice, but I do not want this expression affects the interpretation of quantum mechanics as I could to prove mathematically that there is no hidden variable, possibly Einstein meant by this expression not only lack of understanding of quantum mechanics, but also the math!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e387a5766d37f1f84f12db3303cb01014021c9126afe88e8ea22c3cb4a40cd23-e7ba461c3071095adbd60728b447387bd84bd65c70cc8377babc5b74c147b457.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hans")]], [#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/#comment-120819")[#strong[#text("hans")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2012")])]

#text("What space does R/Z denote? An ordinary quotient space with the set of reals and the set of integers?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10535fb698926c89a298224e57dc4aea60efc3a5cb081dfd8bd234b44d3e0d59-9e0b457ed7c27748b5c4166dffbda55d289b150f395174b39b4fb3ee29da2d5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergey")]], [#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/#comment-121051")[#strong[#text("Sergey")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2012")])]

#text("Very interesting, thanks!")#linebreak()#text(" Sergey Novikov")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ghaith Hiary")]], [#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/#comment-121077")[#strong[#text("Ghaith Hiary")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2012")])]

#text("The large sieve makes even more sense now, thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Every odd integer larger than 1 is the sum of at most five primes « What’s new")]], [#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/#comment-125840")[#strong[#text("Every odd integer larger than 1 is the sum of at most five primes « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2012")])]

#text("[…] out that on this particular minor arc one can use tools from the theory of the large sieve (such as Montgomery’s uncertainty principle) to eliminate this logarithmic loss almost completely; it turns out that the most efficient way to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/#comment-126894")[#strong[#text("Fourteenth Linkfest")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2012")]

#text("[…] Tao: Montgomery’s uncertainty principle, Random matrices: Sharp concentration of eigenvalues, Random matrices: The Universality phenomenon […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/#comment-140813")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2012")])]

#text("In the last section, do you need the more strict condition $w(p) = k$, instead of just $0 \\leq w(p) \\leq k$? It seems a lower bound of $k\\leq w(p)$ is needed for estimate of $G(R)$ (while the upper bound of $w(p) \\leq k$ is still needed to derive the $log^k(J)$ bound). Otherwise, it seems the hypothesis of the results get weaker as $k$ increases, while the estimates get stronger.")

#text("Slightly rephrasing the final result, you have obtained a sharp estimate for the $\\Lambda(p)$ constant of the primes (less than $N$). This seems remarkable, considering how poor our knowledge of $\\Lambda(p)$ constants for more sparse arithmetic sets are. For instance, there seems to be no Fourier analytic proof that there exists a $\\Lambda(5)$ subset of $[N]$ of size $N^{1/2+\\epsilon}$. However, when reading the last section it seems natural to hope that one might approach such problems by applying a similar analysis, but sieving out many more residue classes. Is it clear what goes wrong when one tries to do this? (I am aware that the $\\Lambda(p)$ result for the primes was originally proved by Bourgain in connection with his work on $\\Lambda(p)$ sets, so I imagine he would have done this if it did work.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/#comment-140816")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2012")])]

#text("I think the lower bound on ")#mi("{\\mathfrak G}")#text(" continues to work for ")#mi("\\omega(p) \\leq k")#text(" so long as one restricts the product over primes to be less than R. (Note that the factor ")#mi("\\prod_{p \\leq R} (1-\\frac{1}{p})^k")#text(" essentially cancels out the ")#mi("\\log^k R")#text(" term by Mertens’ theorem, so the dependence on ")#mi("k")#text(" is actually somewhat illusory.)")

#text("I’m not sure to what extent the method can be pushed to much sparser sets as you suggest, which would require k to be as large as some power of R. At this point, dependence of constants on k becomes much more important. I haven’t done any computations, but my guess is that one could only go down to sets of size ")#mi("N^{1-\\varepsilon}")#text(" or so for some small ")#mi("\\varepsilon")#text(" (there is ")#link("http://arxiv.org/abs/math/0703749")[#text("some work by Hamel and Laba along such lines")]#text(", for instance; that work uses a sieve majorant analogous to the Selberg sieve rather than the large sieve, but I would imagine the numerology to be roughly comparable. It may be worth checking though whether large sieve ideas could improve any of the Hamel-Laba results.).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heuristic limitations of the circle method « What’s new")]], [#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/#comment-143789")[#strong[#text("Heuristic limitations of the circle method « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2012")])]

#text("[…] order of , which exceeds the major arc contribution of by a logarithmic factor. (One can also use Montgomery’s uncertainty principle to show that the major arc contributions are a fraction of the minor arc ones, for any reasonable […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The prime tuples conjecture, sieve theory, and the work of Goldston-Pintz-Yildirim, Motohashi-Pintz, and Zhang | What's new")]], [#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/#comment-232398")[#strong[#text("The prime tuples conjecture, sieve theory, and the work of Goldston-Pintz-Yildirim, Motohashi-Pintz, and Zhang | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2013")])]

#text("[…] than (and the large sieve inequality shows that this is sharp up to a factor of two, see e.g. this previous post for more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Online reading seminar for Zhang’s “bounded gaps between primes” | What's new")]], [#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/#comment-232621")[#strong[#text("Online reading seminar for Zhang’s “bounded gaps between primes” | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("[…] classical estimate of Montgomery and Vaughan tells us that we cannot make much narrower than , see this previous post for some related […]")
]
