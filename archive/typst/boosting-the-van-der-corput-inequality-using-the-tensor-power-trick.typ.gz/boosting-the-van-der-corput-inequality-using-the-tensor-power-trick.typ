// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/
// Converted to Typst by tao2typ: "2026-10-14T11:02:32.968522+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Boosting the van der Corput inequality using the tensor power trick", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Boosting the van der Corput inequality using the tensor power trick")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 February 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/")[#text("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In ")#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/")[#text("this previous blog post")]#text(" I noted the following easy application of Cauchy-Schwarz:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Van der Corput inequality)")]#text(" Let ")#mi("{v,u_1,\\dots,u_n}")#text(" be unit vectors in a Hilbert space ")#mi("{H}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("(\\sum_{i=1}^n \\left|\\langle v, u_i \\rangle_H\\right|)^2 \\leq \\sum_{1 \\leq i,j \\leq n} |\\langle u_i, u_j \\rangle_H|.", block: true)]]
]

#emph[#text("Proof:")]#text(" The left-hand side may be written as ")#tao-math("{\\left|\\langle v, \\sum_{i=1}^n \\epsilon_i u_i \\rangle_H\\right|^2}", block: false)#text(" for some unit complex numbers ")#mi("{\\epsilon_i}")#text(". By Cauchy-Schwarz we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle v, \\sum_{i=1}^n \\epsilon_i u_i \\rangle_H\\right|^2 \\leq \\langle \\sum_{i=1}^n \\epsilon_i u_i, \\sum_{j=1}^n \\epsilon_j u_j \\rangle_H", block: true)]]

#text("and the claim now follows from the triangle inequality. ")#mi("\\Box")

#text("As a corollary, correlation becomes transitive in a statistical sense (even though it is not transitive in an absolute sense):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2 (Statistical transitivity of correlation)")]#text(" ")#metadata(none) <tao-40460da8c882cdc79183>#text(" Let ")#mi("{v,u_1,\\dots,u_n}")#text(" be unit vectors in a Hilbert space ")#mi("{H}")#text(" such that ")#tao-math("{\\left|\\langle v,u_i \\rangle_H\\right| \\geq \\delta}", block: false)#text(" for all ")#mi("{i=1,\\dots,n}")#text(" and some ")#mi("{0 < \\delta \\leq 1}")#text(". Then we have ")#tao-math("{\\left|\\langle u_i, u_j \\rangle_H\\right| \\geq \\delta^2/2}", block: false)#text(" for at least ")#mi("{\\delta^2 n^2/2}")#text(" of the pairs ")#mi("{(i,j) \\in \\{1,\\dots,n\\}^2}")#text(".")
]

#emph[#text("Proof:")]#text(" From the lemma, we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{1 \\leq i,j \\leq n} \\left|\\langle u_i, u_j \\rangle_H\\right| \\geq \\delta^2 n^2.", block: true)]]

#text("The contribution of those ")#mi("{i,j}")#text(" with ")#tao-math("{\\left|\\langle u_i, u_j \\rangle_H\\right| < \\delta^2/2}", block: false)#text(" is at most ")#mi("{\\delta^2 n^2/2}")#text(", and all the remaining summands are at most ")#mi("{1}")#text(", giving the claim. ")#mi("\\Box")

#text("One drawback with this corollary is that it does not tell us ")#emph[#text("which")]#text(" pairs ")#mi("{u_i,u_j}")#text(" correlate. In particular, if the vector ")#mi("{v}")#text(" also correlates with a separate collection ")#mi("{w_1,\\dots,w_n}")#text(" of unit vectors, the pairs ")#mi("{(i,j)}")#text(" for which ")#mi("{u_i,u_j}")#text(" correlate may have no intersection whatsoever with the pairs in which ")#mi("{w_i,w_j}")#text(" correlate (except of course on the diagonal ")#mi("{i=j}")#text(" where they must correlate).")

#text("While working on an ongoing research project, I recently found that there is a very simple way to get around the latter problem by exploiting the ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("tensor power trick")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3 (Simultaneous statistical transitivity of correlation)")]#text(" Let ")#mi("{v, u^k_i}")#text(" be unit vectors in a Hilbert space for ")#mi("{i=1,\\dots,n}")#text(" and ")#mi("{k=1,\\dots,K}")#text(" such that ")#tao-math("{\\left|\\langle v, u^k_i \\rangle_H\\right| \\geq \\delta_k}", block: false)#text(" for all ")#mi("{i=1,\\dots,n}")#text(", ")#mi("{k=1,\\dots,K}")#text(" and some ")#mi("{0 < \\delta_k \\leq 1}")#text(". Then there are at least ")#mi("{(\\delta_1 \\dots \\delta_K)^2 n^2/2}")#text(" pairs ")#mi("{(i,j) \\in \\{1,\\dots,n\\}^2}")#text(" such that ")#tao-math("{\\prod_{k=1}^K \\left|\\langle u^k_i, u^k_j \\rangle_H\\right| \\geq (\\delta_1 \\dots \\delta_K)^2/2}", block: false)#text(". In particular (by Cauchy-Schwarz) we have ")#tao-math("{\\left|\\langle u^k_i, u^k_j \\rangle_H\\right| \\geq (\\delta_1 \\dots \\delta_K)^2/2}", block: false)#text(" for all ")#mi("{k}")#text(".")
]

#emph[#text("Proof:")]#text(" Apply Corollary ")#link(<tao-40460da8c882cdc79183>)[#text("2")]#text(" to the unit vectors ")#mi("{v^{\\otimes K}}")#text(" and ")#mi("{u^1_i \\otimes \\dots \\otimes u^K_i}")#text(", ")#mi("{i=1,\\dots,n}")#text(" in the tensor power Hilbert space ")#mi("{H^{\\otimes K}}")#text(". ")#mi("\\Box")

#text("It is surprisingly difficult to obtain even a qualitative version of the above conclusion (namely, if ")#mi("{v}")#text(" correlates with all of the ")#mi("{u^k_i}")#text(", then there are many pairs ")#mi("{(i,j)}")#text(" for which ")#mi("{u^k_i}")#text(" correlates with ")#mi("{u^k_j}")#text(" for all ")#mi("{k}")#text(" simultaneously) without some version of the tensor power trick. For instance, even the powerful Szemerédi regularity lemma, when applied to the set of pairs ")#mi("{i,j}")#text(" for which one has correlation of ")#mi("{u^k_i}")#text(", ")#mi("{u^k_j}")#text(" for a single ")#mi("{i,j}")#text(", does not seem to be sufficient. However, there is a reformulation of the argument using the ")#link("https://en.wikipedia.org/wiki/Schur_product_theorem")[#text("Schur product theorem")]#text(" as a substitute for (or really, a disguised version of) the tensor power trick. For simplicity of notation let us just work with real Hilbert spaces to illustrate the argument. We start with the identity")

#align(center)[#tao-fit-display[#mitex("\\langle u^k_i, u^k_j \\rangle_H = \\langle v, u^k_i \\rangle_H \\langle v, u^k_j \\rangle_H + \\langle \\pi(u^k_i), \\pi(u^k_j) \\rangle_H")]]

#text("where ")#mi("{\\pi}")#text(" is the orthogonal projection to the complement of ")#mi("{v}")#text(". This implies a Gram matrix inequality")

#align(center)[#tao-fit-display[#mitex("(\\langle u^k_i, u^k_j \\rangle_H)_{1 \\leq i,j \\leq n} \\succ (\\langle v, u^k_i \\rangle_H \\langle v, u^k_j \\rangle_H)_{1 \\leq i,j \\leq n} \\succ 0")]]

#text("for each ")#mi("{k}")#text(" where ")#mi("{A \\succ B}")#text(" denotes the claim that ")#mi("{A-B}")#text(" is positive semi-definite. By the Schur product theorem, we conclude that")

#align(center)[#tao-fit-display[#mitex("(\\prod_{k=1}^K \\langle u^k_i, u^k_j \\rangle_H)_{1 \\leq i,j \\leq n} \\succ (\\prod_{k=1}^K \\langle v, u^k_i \\rangle_H \\langle v, u^k_j \\rangle_H)_{1 \\leq i,j \\leq n}")]]

#text("and hence for a suitable choice of signs ")#mi("{\\epsilon_1,\\dots,\\epsilon_n}")#text(",")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq i, j \\leq n} \\epsilon_i \\epsilon_j \\prod_{k=1}^K \\langle u^k_i, u^k_j \\rangle_H \\geq \\delta_1^2 \\dots \\delta_K^2 n^2.")]]

#text("One now argues as in the proof of Corollary ")#link(<tao-40460da8c882cdc79183>)[#text("2")]#text(".")

#text("A separate application of tensor powers to amplify correlations was also noted in ")#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/")[#text("this previous blog post")]#text(" giving a cheap version of the Kabatjanskii-Levenstein bound, but this seems to not be directly related to this current application.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (23)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48c035a546c1c11fe3058219823e2fdcc0203e68abe325d503285f95428c7e91-fa1502c627464effefa5caa222b18bb023c4c0f735610232d0140446b32d0dfd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Griesmer")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-622845")[#strong[#text("John Griesmer")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("Starting with collections ")#mi("u_i^1, u_i^2")#text(", ")#mi("i\\leq N")#text(", you could use Ramsey’s theorem together with Corollary 2 to guarantee that for ")#mi("N")#text(" sufficiently large, there is a set ")#mi("I")#text(" of ")#mi("n")#text(" indices with ")#mi("\\langle u_i^1,u_j^1\\rangle > \\delta^2/2")#text(" for every pair ")#mi("(i,j)")#text(" from ")#mi("I")#text(". Then apply Corollary 2 again to the ")#mi("u_i^2")#text(", with ")#mi("i\\in I")#text(".")

#text("This produces a better bound on the correlations, but I don’t know if it can get you a fraction of ")#mi("N^2")#text(" of the pairs of indices satisfying the bound, so maybe it’s not useful for the application you have in mind.")

#text("In any case, I’m naturally very curious about the structure of the set of pairs ")#mi("(i,j)")#text(" for which ")#mi("\\langle u_i, u_j\\rangle >\\delta^2/2")#text(", so it’s interesting to think about how two such sets of pairs must intersect.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-622856")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("Nice – somehow I had not thought to use Ramsey’s theorem instead of the regularity lemma! Once one can guarantee one good pair ")#mi("(i,j)")#text(" with ")#mi("i \\neq j")#text(" whenever ")#mi("N")#text(" exceeds some threshold ")#mi("N_0")#text(" then one gets a positive fraction of pairs by looking at random ")#mi("N_0")#text("-element subsets of indices and averaging. So one gets a better bound on correlation but a much worse bound on density because of the iterated use of Ramsey’s theorem. (Actually now that I see this argument I think something similar is actually used in model theory when using (infinitary versions of) Ramsey’s theorem to create a huge number of indiscernibles.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-622851")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("Terry, since I rely upon you to solve the majority of my most difficult math problems, I can only say that I enjoy attempting to figure yours out. Thanks for the opportunity! David")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/faba56a92c60814a747269c38a99e73a133c9c1ca214d8728c4cf10e8a03ff5b-c7ddb228c746d2745e27a65aa5467553537cee5765765bbef24b0dd904cbaec6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-622857")[#strong[#text("A")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("Are you adapting Walsh’s proof of Fourier Uniformity to the case of nilsequences?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/143c544571e80a3cf438085cc22cdd6ee5f18e956de7a0f03326247396a9c295-1cd0848b805096874077c387ff9b4ebbbdb0dd350cf3e18158aef72a34e6a0b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of duck_master")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-624173")[#strong[#text("duck_master")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2021")])]

#text("Are you referring to ")#link("https://arxiv.org/pdf/2102.05564.pdf")[#text("https://arxiv.org/pdf/2102.05564.pdf")]#text("? I think this might already be done in the case of the Liouville function, c.f. ")#link("https://arxiv.org/pdf/2007.15644.pdf")[#text("https://arxiv.org/pdf/2007.15644.pdf")]#text(" (even though that paper also briefly mentions the general case).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/552758e05dc011a4472f7a95441780f98af7d7d8039475545c5c8f1251b063a5-e51706894cd4d1a916bed88923a8760f41bef0c0377cc6eb12a9189edbe8aae8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oliver Knill")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-622878")[#strong[#text("Oliver Knill")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2021")])]

#text("This is interesting also in the context of Lovasz umbrellas {v,u_1,…,u_n} in graph theory, where the unit vectors u_j attached to the nodes j of the graph satisfy (u_i,u_j)=0 if i,j are not adjacent. The vector v is the `stick’ of the umbrella. Lovasz noted in 1979 that max_j 1/(v,u_j)^2 is an upper bound for the Shannon capacity of the graph (a notoriously difficult number to compute and unknown even for the cyclic graph C_7). A suitable umbrella in R^3 establishes that the capacity is sqrt(5) for C_5. Corollary 2 would give then a lower bound on a fraction of all possible angles. The tensor power trick is the key why Lovasz umbrellas work for the Shannon capacity: the product of graphs produces the tensor product of umbrellas.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4cd0017271bbb29ae05f5b5a225f644511ad3edf9a9ebaa35f13283225e9f5c-90556bf81c15b68b76904c436bcab34f854e53c514c00a5ef7fb5583b8bd4019.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arulsaravana Jeyaraj")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-623121")[#strong[#text("Arulsaravana Jeyaraj")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2021")])]

#text("In this case I think luck was a factor. \\sqrt{5} was a known lower bound. It is not clear semidefinite representations are the right way to go given all semidefinite representations are relaxations and semidefinite representations do not represent the problem exactly (there is a whole theory on it in CS based on UGC) or if these extremal problems require new insight.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4cd0017271bbb29ae05f5b5a225f644511ad3edf9a9ebaa35f13283225e9f5c-90556bf81c15b68b76904c436bcab34f854e53c514c00a5ef7fb5583b8bd4019.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arulsaravana Jeyaraj")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-623122")[#strong[#text("Arulsaravana Jeyaraj")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2021")])]

#text("It would be a miracle if the capacity of strong products of graphs are exactly formulated by the semidefinite relaxations. I think the truth is far lower compared to the semidefinite bounds and for the situation of certain cyclic graphs perhaps exactly portrayable (perhaps providing hints semidefinite relaxation bounds might be improvable in P (at least for certain situations)).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4cd0017271bbb29ae05f5b5a225f644511ad3edf9a9ebaa35f13283225e9f5c-90556bf81c15b68b76904c436bcab34f854e53c514c00a5ef7fb5583b8bd4019.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arulsaravana Jeyaraj")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-628961")[#strong[#text("Arulsaravana Jeyaraj")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2021")])]

#text("I am not certain if following is right approach. The numbers coming through SDP approaches appear trigonometric. As far as I know capacity of ((2^k) +1)-cycle graphs could be bound by ((2^k)+1)^((k-1)/k). For example agrees with 5-cycle and at at 9-cycle agrees to best bounds on independence number at strong product of 9-cycle three times. k need not be integral I think and no computed independence number exceeds above. Is it possible to demonstrate the capacity of cycle graphs have different number theoretic properties compared to what arises naturally in SDP? An UGC connection is possible. Disproving optimality of SDP bound need not be necessarily explicitly computational.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45ea20720e98334adbfaf702f50b533877244d09abbf1f020bb9128321b9fca0-9e1aec68e5c0025b06f6e787d1c5e0a10f0507da57174143b9831733d7479110.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dailyscreenz")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-622880")[#strong[#text("dailyscreenz")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2021")])]

#text("I echo David’s comment from above, really enjoy the blog, and reading about these topics (even if most are well above my level/pay grade).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-622882")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2021")])]

#text("Reblogged this on ")#link("https://scoutmathematics.wordpress.com/2021/02/28/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/")[#text("Aditya Guha Roy's weblog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-622883")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2021")])]

#text("I have known about the fact that the tensor power trick can be used to get powerful results about bounds on sizes of sum sets. Can similar results be derived using this tool?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f3aed195ab92193f6a12bec155c2d861455735b2cc2c378417a4e73dd1670c-482309c7e3415c13305aaa389f10290f1fed44e751228364550fc6fc5b50fbf7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mar")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-623146")[#strong[#text("Mar")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2021")])]

#text("In Corollary 3, \\delta_K should be \\delta_k and k=1,…K is repeated twice")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9d80d5f93e90a0d08290f3bc68630ef75896fbeb8225ded1a23d4edb2887da8e-8036e4e818f72f26d5326a98f6fe237ca177248c9b3ef327975c1ca0552c5469.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M.")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-623202")[#strong[#text("M.")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2021")])]

#text("Typo: In the proof of corollary 3, I believe the u should be a v.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zao")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-623338")[#strong[#text("Zao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2021")])]

#text("Dear Professor,")#linebreak()#text(" You have carefully studied the Sendov conjecture for high degree polynomials in an older post last year.")#linebreak()#text(" I just have founded a preprint of T. Agama uploaded to the ArXiv on 27 august 2020 which could interest you where the author claims to have proved such a famous conjecture in the general case.")#linebreak()#text(" To the best of my knowledge, this paper has not been published in a journal or conference.")#linebreak()#text(" After reading the article, I am not convinced of the completeness and correction of the proof.")#linebreak()#text(" I just wanted to inform you on this contribution.")#linebreak()#text(" Yours sincerely")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-623341")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2021")])]

#text("Following my previous message, you only have to take into account the version 4 of this preprint (55 pages).")#linebreak()#text(" Best")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-623383")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2021")])]

#text("Is it possible to generalize (and possibly improve) these results by using Holder’s inequality (instead of C-S inequality) in lemma 1?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a5cfb58df244822f5d12e3f3e9d646010ea894a46bbf0729660fcd799702bb8-ad09e718a57ab67ef709dd945d8c87195fc982d894fe8b4256e20cbbb7cbb3fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lin Cui")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-623634")[#strong[#text("Lin Cui")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2021")])]

#text("Hello, professor Tao, I’m currently a postgraduate student in a Chinese university. I consulted a study abroad company, and they told me that accord to my grades I can apply to study at UCLA further.")#linebreak()#text(" Professor Tao, if I’m really at the campus of UCLA, can I meet you and ask you some questions about mathematics study?")

#text("Please answer me, thank you very much!")

#text("Best wishes to you!!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-624208")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2021")])]

#text("No! You may not. COVID.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a2aed3f2420c5e68333bba54189b96f68326a66b25d2f160eea6a70198946bd5-3990ea73567e10c54a3642338b891a1c3292cf1ae51f8aa0487370e901d31eaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aegeanwest")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-624202")[#strong[#text("aegeanwest")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2021")])]

#text("professor tao，how can i apply for your graduate student？any matieral should be prepared？and how about recommended books and tools…")#linebreak()#text(" have a nice day～🍭")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf439e996e29d20cb552d68ffe9f964d8919f4f9773b9c41c886fb326a5a9695-66573747b7b50dc2532a1c1acd7e23c9482f9aeb4a00f437399c08ade2278ee3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aquazorcarson")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-624643")[#strong[#text("aquazorcarson")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2021")])]

#text("First sentence missed a square on the rewritten quantity.")

#emph[#text("[I was not able to locate the sentence referred to here. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf439e996e29d20cb552d68ffe9f964d8919f4f9773b9c41c886fb326a5a9695-66573747b7b50dc2532a1c1acd7e23c9482f9aeb4a00f437399c08ade2278ee3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aquazorcarson")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-625259")[#strong[#text("aquazorcarson")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2021")])]

#text("Sorry Terry, I meant the first sentence of the proof of the first result: “The left-hand side may be written as (…)^2”.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf439e996e29d20cb552d68ffe9f964d8919f4f9773b9c41c886fb326a5a9695-66573747b7b50dc2532a1c1acd7e23c9482f9aeb4a00f437399c08ade2278ee3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aquazorcarson")]], [#link("https://terrytao.wordpress.com/2021/02/27/boosting-the-van-der-corput-inequality-using-the-tensor-power-trick/#comment-624644")[#strong[#text("aquazorcarson")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2021")])]

#text("The last sentence of corollary 3 seems too trivial to be what you actually meant?")

#emph[#text("[No, this is in fact the conclusion that ends up being useful in applications – T.]")]
]
