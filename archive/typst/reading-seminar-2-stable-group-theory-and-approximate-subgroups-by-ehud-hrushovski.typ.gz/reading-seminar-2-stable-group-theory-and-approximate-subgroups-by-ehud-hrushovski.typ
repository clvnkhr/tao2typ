// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/
// Converted to Typst by tao2typ: "2026-10-14T16:35:55.102369+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Reading seminar 2: “Stable group theory and approximate subgroups”, by Ehud Hrushovski", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Reading seminar 2: “Stable group theory and approximate subgroups”, by Ehud Hrushovski")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 October 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")[#text("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("At UCLA we just concluded our third seminar in our reading of “")#link("http://arxiv.org/abs/0909.2190")[#text("Stable group theory and approximate subgroups")]#text("” by Ehud Hrushovski. In this seminar, ")#link("http://www.math.ucla.edu/~isaac/")[#text("Isaac Goldbring")]#text(" made some more general remarks about universal saturated models (extending the discussion from ")#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")[#text("the previous seminar")]#text("), and then ")#link("http://www.math.ucla.edu/~hpt/")[#text("Henry Towsner")]#text(" gave some preliminaries on Kiesler measures, in preparation for connecting the main model-theoretic theorem (Theorem 3.4 of Hrushovski) to one of the combinatorial applications (Corollary 1.2 of Hrushovski).")

#text("As with the previous post, commentary on any topic related to Hrushovski’s paper is welcome, even if it is not directly related to what is under discussion by the UCLA group. Also, we have a number of questions below which perhaps some of the readers here may be able to help answer.")

#text("Note: the notes here are quite rough; corrections are very welcome. Henry’s notes on his part of the seminar can be found ")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/10/hrushovskinotes.pdf")[#text("here")]#text(".")

#text("(Thanks to Issac Goldbring for comments.)")

#metadata(none) <tao-9a1c27a93e10693501ea>

#heading(level: 1)[#strong[#text(" — 1. More remarks on universal models — ")]]

#text("Recall from the ")#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")[#text("previous seminar")]#text(" that if we have any structure ")#mi("{M}")#text(" of a language ")#mi("{L}")#text(" (e.g. ")#mi("{M}")#text(" could be a group, and ")#mi("{L}")#text(" the language of groups), then we can (assuming some set-theoretic axioms, such as the existence of inaccessible cardinals) obtain an elementary extension ")#mi("{{\\Bbb U}}")#text(" of ")#mi("{M}")#text(", enjoying the following properties:")

#list(
[#text("(i) (Saturation) If ")#mi("{A \\subset {\\Bbb U}}")#text(" has strictly smaller cardinality than ")#mi("{{\\Bbb U}}")#text(", then every partial type over ")#mi("{A}")#text(" is realisable in ")#mi("{{\\Bbb U}}")#text("; and")],
[#text("(ii) (Homogeneity) If ")#mi("{A}")#text(" is as above and ")#mi("{\\vec a, \\vec b \\in {\\Bbb U}^n}")#text(" are elementarily indistinguishable over ")#mi("{A}")#text(", then there is an automorphism of ")#mi("{{\\Bbb U}}")#text(" that maps ")#mi("{\\vec a}")#text(" to ")#mi("{\\vec b}")#text(".")]
)

#text("Another way of phrasing saturation: if one has a “small” family of formulae ")#mi("{\\phi(x_1,\\ldots,x_n)}")#text(" (where “small” means “having cardinality less than that of ")#mi("{{\\Bbb U}}")#text("“) which is finitely realisable in ")#mi("{{\\Bbb U}^n}")#text(" (i.e. for any finite collection of these formulae, one can find ")#mi("{(a_1,\\ldots,a_n) \\in {\\Bbb U}^n}")#text(" obeying these formulae), then it is realisable (one can find ")#mi("{(a_1,\\ldots,a_n) \\in {\\Bbb U}^n}")#text(" obeying all of the formulae). Equivaqlently the topology on ")#mi("{{\\Bbb U}}")#text(" generated by the definable sets (which form a clopen base) is compact.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" ")#mi("{{\\Bbb U}}")#text(" has the following “universal” property: any small model ")#mi("{N}")#text(" of the theory of ")#mi("{M}")#text(" (i.e. any structure elementarily equivalent to ")#mi("{M}")#text(") can be embedded into ")#mi("{{\\Bbb U}}")#text(". Indeed, if one throws in all the elements of ")#mi("{N}")#text(" as constants, the model ")#mi("{N}")#text(" can be described as a partial type over the small set ")#mi("{N}")#text(", and one simply applies saturation to obtain the embedding.")

#text("(A side remark: in Hrushovski’s paper, it is not completely clear whether one is working with the universal model (in which saturation holds over all small sets ")#mi("{A}")#text(") or merely a countably saturated one. If it is the latter, then the above remark does not quite hold, but it seems that one can get around this by replacing “small model” with “small elementary substructure of ")#mi("{{\\Bbb U}}")#text("” throughout the paper. But this seems to not make a significant difference to the substance of the paper.)")
]

#text("Usually we fix a universal structure ")#mi("{{\\Bbb U}}")#text(", and abbreviate ")#mi("{{\\Bbb U} \\models \\phi(a)}")#text(" as ")#mi("{\\models \\phi(a)}")#text(". (In the combinatorial applications, ")#mi("{{\\Bbb U}}")#text(" will be a group, and we will thus call it ")#mi("{G}")#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" Universal models have the following useful cardinality gap property: if ")#mi("{X \\subset {\\Bbb U}^n}")#text(" is a definable set, then either ")#mi("{X}")#text(" is finite, or ")#tao-math("{\\left|X\\right| = \\left|{\\Bbb U}\\right|}", block: false)#text(" (i.e. ")#mi("{X}")#text(" is large); there are no definable sets of intermediate cardinality. Proof: let ")#mi("{\\phi(\\vec x) = \\phi(x_1,\\ldots,x_n)}")#text(" be a defining formula for ")#mi("{X}")#text(". If ")#mi("{X}")#text(" is infinite, then the formula ")#mi("{\\phi(\\vec x)}")#text(" together with the formulae ")#mi("{\\vec x \\neq \\vec a}")#text(" for every ")#mi("{\\vec a \\in X}")#text(" are finitely realisable, hence realisable by saturation, but this is absurd. Note that this argument in fact shows that any ")#mi("{\\bigwedge}")#text("-definable set (i.e. a partial type) is either finite or large. For ")#mi("{\\bigvee}")#text("-definable sets over some infinite set of constants ")#mi("{A}")#text(", it was claimed that such sets either have cardinality less than or equal to ")#mi("{A}")#text(", or are large, but I didn’t check this.")
]

#text("(Question: if one only assumes countable saturation (which may be the case in Hrushovski’s paper), then one has a smaller cardinality gap: definable sets can be finite or uncountable. It wasn’t clear to us whether the rest of the paper would work if one just had this gap.)")

#text("Now we obtain an analogous cardinality gap for equivalence relations.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(" Suppose the language ")#mi("{L}")#text(" is at most countable. Let ")#mi("{E \\subset {\\Bbb U}^2}")#text(" be a ")#mi("{\\bigwedge}")#text("-definable equivalence relation on ")#mi("{{\\Bbb U}}")#text(" (one could also consider equivalence relations on ")#mi("{{\\Bbb U}^n}")#text("). Then either the cardinality of the classes is at most ")#mi("{2^{\\aleph_0}}")#text(" (the cardinality of the continuum), or is ")#tao-math("{\\left|{\\Bbb U}\\right|}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{\\phi(x,y)}")#text(" be one of the defining relations of the equivalence relation ")#mi("{E}")#text(", which we can assume to be symmetric. By the greedy algorithm, we see that one of the following two statements must be true:")

#list(
[#text("There exists finitely many ")#mi("{x_1, \\ldots, x_n}")#text(" such that for every ")#mi("{y}")#text(", ")#mi("{\\phi(x_i,y)}")#text(" is true for at least one ")#mi("{1 \\leq i \\leq n}")#text(".")],
[#text("There exists a countable sequence ")#mi("{x_1, x_2, \\ldots}")#text(" such that ")#mi("{\\phi(x_i,x_j)}")#text(" fails for all ")#mi("{i \\neq j}")#text(".")]
)

#text("Suppose the latter possibility holds. Then by transfinite induction (using the least ordinal with cardinality ")#tao-math("{\\left|{\\Bbb U}\\right|}", block: false)#text(") and saturation, we can obtain a family ")#mi("{(x_\\alpha)}")#text(" of cardinality ")#tao-math("{\\left|{\\Bbb U}\\right|}", block: false)#text(" such that ")#mi("{\\phi(x_\\alpha,x_\\beta)}")#text(" fails for all ")#mi("{\\alpha \\neq \\beta}")#text(". This implies that ")#mi("{E}")#text(" has ")#tao-math("{\\left|{\\Bbb U}\\right|}", block: false)#text(" equivalence classes, and we are done. Thus the only case remaining is if every defining relation ")#mi("{\\phi}")#text(" enjoys the first property. But then we see that the equivalence class that an element ")#mi("{y}")#text(" belongs to is determined by the precise set of ")#mi("{x_i}")#text(" obeying ")#mi("{\\phi(x_i,y)}")#text(" for each ")#mi("{\\phi}")#text(", and this implies that the number of classes is at most ")#mi("{2^{\\aleph_0}}")#text(". ")#mi("\\Box")

#text("We remark that ")#mi("{2^{\\aleph_0}}")#text(" is best possible. Indeed, consider the integers ")#mi("{{\\Bbb Z}}")#text(" in the language of groups, and take a universal extension ")#mi("{{\\Bbb U}}")#text(" of these integers. Consider the relation ")#mi("{E}")#text(" defined by cosets of the group ")#mi("{\\bigcap_{n=1}^\\infty n {\\Bbb U}}")#text(" (i.e. ")#mi("{x \\equiv y}")#text(" if ")#mi("{x}")#text(" and ")#mi("{y}")#text(" agree modulo ")#mi("{n}")#text(" for every (standard) natural number ")#mi("{n}")#text("). Then this is a ")#mi("{\\bigwedge}")#text("-definable relation, but the set of equivalence classes is equivalent to the profinite integers ")#mi("{\\hat {\\Bbb Z}}")#text(", which have the cardinality of the continuum.")

#text("Equivalence relations whose set of classes have cardinality at most ")#mi("{2^{\\aleph_0}}")#text(" are known as ")#emph[#text("bounded")]#text(" equivalence relations. (It may be that one does not actually need the above dichotomy to establish the results in Hrushovski’s paper, and just take the above statement as the definition of a bounded equivalence relation.)")

#text("Observe that the proof of the above lemma shows that if a bounded equivalence relation is definable rather than merely ")#mi("{\\bigwedge}")#text("-definable, then the number of classes is finite. Thus bounded can be viewed as a generalisation of “finite”.")

#text("The boundedness of a certain equivalence relation (created by a certain stabiliser group) is essential in ensuring that we can define a certain locally compact “logic topology” on the quotient space, which is apparently what allows the Gleason-Yamabe theory of topological groups to kick in; presumably we will see more of this in later seminars. (This idea also appears in previous work, such as ")#link("http://www.ams.org/mathscinet-getitem?mr=2373360")[#text("this paper by Hrushovski, Peterzil, and Pillay")]#text(".)")

#heading(level: 1)[#strong[#text(" — 2. Keisler measures — ")]]

#text("To obtain combinatorial results, Hrushovski applies the contradiction and compactness method: assume that a combinatorial result fails, obtain a sequence of counterexamples to that result, and extract some sort of limiting object to which an infinitary theory (in this case, stability theory) can be applied. In this section we discuss what happens to the combinatorial concept of (normalised) cardinality along such a limit; what one gets at the end is an object known as a ")#emph[#text("Kiesler measure")]#text(".")

#text("Suppose we have a finite set ")#mi("{X}")#text(" in a group ")#mi("{G}")#text(". Then given any other set ")#mi("{A}")#text(" in ")#mi("{G}")#text(", we can define a normalised counting measure ")#mi("{\\mu(A)}")#text(" of ")#mi("{A}")#text(" by the formula ")#tao-math("{\\mu(A)=\\left|A\\right|/\\left|X\\right|}", block: false)#text(" (this measure could be infinite if ")#mi("{A}")#text(" is infinite). More generally, given ")#mi("{A \\subset G^l}")#text(", one can define ")#tao-math("{\\mu^l(A) := \\left|A\\right|/\\left|X\\right|^l}", block: false)#text(". We will often omit the ")#mi("{l}")#text(" superscript and use ")#mi("{\\mu}")#text(" for all the measures on ")#mi("{G^l}")#text(" simultaneously. Thus for instance one has ")#mi("{\\mu(X^l)=1}")#text(", and ")#mi("{\\mu(A \\times B) = \\mu(A) \\mu(B)}")#text(" if ")#mi("{A \\subset G^l}")#text(" and ")#mi("{B \\subset G^m}")#text(".")

#text("Now suppose one has a sequence ")#mi("{G_n}")#text(" of groups, each with a finite set ")#mi("{X_n \\subset G_n}")#text(". Then we have a sequence of normalised counting measures ")#mi("{\\mu_n}")#text(" on ")#mi("{G_n}")#text(" (and on powers ")#mi("{G_n^l}")#text("). We can then take an ultralimit of all of these objects, obtaining a group ")#mi("{G_\\infty}")#text(" (the ultrapower of the ")#mi("{G_n}")#text("), a subset ")#mi("{X_\\infty}")#text(" of ")#mi("{G_\\infty}")#text(" (the ultrapower of the ")#mi("{X_n}")#text("), and a “measure” ")#mi("{\\mu_\\infty}")#text(", which assigns to every subset ")#mi("{A}")#text(" of ")#mi("{G_\\infty}")#text(" a ")#emph[#text("non-standard")]#text(" real number (or ")#mi("{+\\infty}")#text(") ")#mi("{\\mu_\\infty(A)}")#text(". Thus for instance ")#mi("{\\mu_\\infty(X_\\infty)=1}")#text(". In practice we will be working inside ")#mi("{X_\\infty}")#text(" (or small powers of ")#mi("{X_\\infty}")#text(", such as ")#mi("{X_\\infty \\cdot X_\\infty}")#text("), which by hypothesis will have bounded measure, so the ")#mi("{+\\infty}")#text(" case will not be relevant.")

#text("In applications, the ")#mi("{X_n}")#text(" will have bounded doubling, thus ")#mi("{\\mu_n( X_n \\cdot X_n )}")#text(" is bounded in ")#mi("{n}")#text("; taking ultraproducts, we see that ")#mi("{\\mu( X \\cdot X )}")#text(" is bounded also (i.e. less than a standard real number).")

#text("Now we want to extend this ultrapower ")#mi("{G_\\infty}")#text(" to a universal model ")#mi("{G}")#text(". To do this, we have to specify the language ")#mi("{L}")#text(". ")#mi("{L}")#text(" will of course contain the language of groups, but if that is all that the language contains, then one cannot refer to ")#mi("{X}")#text(" or ")#mi("{\\mu}")#text(" in this language. To add in ")#mi("{X}")#text(" is easy: one simply adds a unary predicate for membership in ")#mi("{X}")#text(", so that “")#mi("{x \\in X}")#text("” is now a formula in ")#mi("{x}")#text(". To add ")#mi("{\\mu}")#text(" is a bit trickier: to keep the language ")#mi("{L}")#text(" countable, one is not allowed to measure ")#emph[#text("all")]#text(" sets ")#mi("{A}")#text(" in the model, and also one does not want to work with non-standard real numbers. So instead, what one does is add predicates ")#mi("{\\theta_{A,q}(x_1,\\ldots,x_k)}")#text(" that are interpreted as “")#mi("{\\mu(A(x_1,\\ldots,x_k)) > q}")#text("” for any definable set ")#mi("{A(x_1,\\ldots,x_k)}")#text(" with parameters ")#mi("{x_1,\\ldots,x_k \\in G}")#text(", and any (standard) rational number ")#mi("{q}")#text(". (Note that by adding these predicates, one enlarges the space of possible definable sets; but one can iterate this countably many times to deal with this apparent circularity.) We thus obtain a countable set of predicates (even after iteration). With all these predicates, the language ")#mi("{L}")#text(" is now capable of interpreting ")#mi("{\\mu(A(x_1,\\ldots,x_k))}")#text(" as a standard (extended) real number (the supremum of all rational ")#mi("{q}")#text(" for which ")#mi("{\\mu(A(x_1,\\ldots,x_k)) \\geq q}")#text("); when the model is the ultrapower ")#mi("{G_\\infty}")#text(", this standard real number is simply the standard part of the non-standard real number ")#mi("{\\mu_\\infty(A(x_1,\\ldots,x_k))}")#text(".")

#text("[A slight subtlety: when one collapses ")#mi("{\\mu}")#text(" to the standard real numbers, the predicate ")#mi("{\\theta_{A,q}(x_1,\\ldots,x_k)}")#text(" now deviates very slightly from its original interpretation “")#mi("{\\mu(A(x_1,\\ldots,x_k)) > q}")#text("“. What is now true is that this predicate is ")#emph[#text("implied")]#text(" by ")#mi("{\\mu(A(x_1,\\ldots,x_k)) > q}")#text(", and in turn implies “")#mi("{\\mu(A(x_1,\\ldots,x_k)) \\geq q}")#text("“, just as the assertion that a non-standard number ")#mi("{x}")#text(" is larger than ")#mi("{q}")#text(" is implied by the standard part ")#mi("{st(x)}")#text(" being larger than ")#mi("{q}")#text(", and in turn implies ")#mi("{st(x) \\geq q}")#text(".]")

#text("With this language ")#mi("{L}")#text(", we can now pass to a universal model ")#mi("{G}")#text(". This is a group with a set ")#mi("{X}")#text(", and a real number ")#mi("{\\mu(A(x_1,\\ldots,x_k)) \\in [0,+\\infty]}")#text(" assigned to any set in ")#mi("{G}")#text(" or ")#mi("{G^l}")#text(" definable with parameters. It inherits all the elementary properties of ")#mi("{\\mu_n}")#text(", for instance ")#mi("{\\mu}")#text(" is finitely additive and one has ")#mi("{\\mu(X)=1}")#text(" and ")#mi("{\\mu(A \\times B) = \\mu(A) \\mu(B)}")#text(". (One can use compactness and the Carathéodory extension theorem to extend ")#mi("{\\mu}")#text(" to a ")#mi("{\\sigma}")#text("-additive measure on the “Borel ")#mi("{\\sigma}")#text("-algebra” generated by the definable sets; this is basically the Loeb measure construction, but we will not need it here.)")

#text("By construction, ")#mi("{\\mu}")#text(" is a ")#emph[#text("Keisler measure")]#text(" – a finitely additive measure on the definable sets. By construction, it is also ")#mi("{G_\\infty}")#text("-invariant – i.e. it is invariant under all automorphisms of ")#mi("{G}")#text(" that fix ")#mi("{G_\\infty}")#text(". One consequence of this is that the quantity ")#mi("{\\mu(A(\\vec x))}")#text(" depends only on the type of ")#mi("{\\vec x}")#text(" over ")#mi("{G_\\infty}")#text(". Actually, there is a stronger statement – the quantity ")#mi("{\\mu(A(\\vec x))}")#text(" depends continuously on ")#mi("{\\vec x}")#text(" using the topology generated by the ")#mi("{G_\\infty}")#text("-definable sets (by using the predicates ")#mi("{\\theta_{A,q}(x_1,\\ldots,x_k)}")#text("). Because of this, we call ")#mi("{\\mu}")#text(" an ")#emph[#mi("{G_\\infty}")#text("-definable Keisler measure")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" One does not need to pass through the non-standard real numbers here; instead, one can interpret ")#mi("{\\theta_{A,q}(x_1,\\ldots,x_k)}")#text(" directly as ")#mi("{\\mu_n(A(x_1,\\ldots,x_k)) > q}")#text(" in the finite models ")#mi("{G_n}")#text(", take an ultralimit (or some other theory that contains all the statements that are true in all but finitely many of the ")#mi("{G_n}")#text(") and then take a universal extension, and then reconstruct ")#mi("{\\mu(A(x_1,\\ldots,x_k))}")#text(" as the supremum of all ")#mi("{q}")#text(" for which ")#mi("{\\theta_{A,q}(x_1,\\ldots,x_k)}")#text(" holds. I find the temporary non-standard interpretation of ")#mi("{\\mu}")#text(" to be helpful though in understanding why ")#mi("{\\theta_{A,q}(x_1,\\ldots,x_k)}")#text(" ends up deviating slightly from ")#mi("{\\mu(A(x_1,\\ldots,x_k)) > q}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 3. Wide types — ")]]

#text("Recall that a ")#emph[#text("partial type")]#text(" in ")#mi("{G^l}")#text(" over some set of constants ")#mi("{A}")#text(" is a set of ")#mi("{l}")#text("-ary formulae using ")#mi("{A}")#text(", which then defines a ")#mi("{\\bigwedge}")#text("-definable (over ")#mi("{A}")#text(") subset of ")#mi("{G^l}")#text(", being the set of all ")#mi("{l}")#text("-tuples that realise those formulae. A ")#emph[#text("complete type")]#text(" is a maximal such set of formulae (or a minimal ")#mi("{\\bigwedge}")#text("-definable set, equivalently), or equivalently an orbit of the automorphism group of ")#mi("{G}")#text(".")

#text("Note that given a complete type and a definable set, the type either falls entirely inside the set or is disjoint from it. (Indeed, a complete type can be thought of as an ultrafilter on the algebra of definable sets.) In practice, all the types we will consider will lie inside a definable set such as ")#mi("{X \\cdot X}")#text(", which will have finite measure in applications.")

#text("Now for a key concept. A (partial or complete) type is ")#emph[#text("wide")]#text(" if the set it defines it cannot be contained in a definable set of zero measure. More generally, a type is wide over a set of constants ")#mi("{A}")#text(" if it cannot be contained in an ")#mi("{A}")#text("-definable set of zero measure. Wide sets are thus somewhat “generic” or “Zariski-dense” in some sense.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" Every wide partial type ")#mi("{q}")#text(" over ")#mi("{A}")#text(" can be refined to a wide complete type ")#mi("{p}")#text(" over ")#mi("{A}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{q}")#text(" be a wide partial type over ")#mi("{A}")#text(". By finite additivity of ")#mi("{\\mu}")#text(", ")#mi("{q}")#text(" cannot be covered by finitely many ")#mi("{A}")#text("-definable sets of measure zero, thus by saturation (compactness), ")#mi("{q}")#text(" cannot be covered by all of such sets at once. If we set ")#mi("{q^{\\prime}}")#text(" to be ")#mi("{q}")#text(" with all the ")#mi("{A}")#text("-definable sets of measure zero, ")#mi("{q^{\\prime}}")#text(" is then also a partial type which is wide (since it is disjoint from, and hence not contained in, any ")#mi("{A}")#text("-definable set of measure zero). If we then complete ")#mi("{q^{\\prime}}")#text(" to any complete type ")#mi("{p}")#text(" (e.g. by taking an element of ")#mi("{q^{\\prime}}")#text(" and computing its type), this type is then also wide. ")#mi("\\Box")

#text("A typical application of this lemma will be to start with a wide complete type over some set ")#mi("{A}")#text(" of constants, and then enlarge the set of constants, thus turning the complete type back into a partial type; but if one can show that the partial type remains wide, then one can refine it back to a wide complete type.")

#heading(level: 1)[#strong[#text(" — 4. Types and group operations — ")]]

#text("Types are well behaved with respect to group operations. For instance, if ")#mi("{q}")#text(" is a partial type over ")#mi("{A}")#text(", and ")#mi("{a \\in G}")#text(", then the shift ")#mi("{q \\cdot a}")#text(" of ")#mi("{A}")#text(" (defined by taking the set in ")#mi("{G}")#text(" or ")#mi("{G^l}")#text(" defined by ")#mi("{q}")#text(" and shifting it by ")#mi("{a}")#text(") is a partial type over ")#mi("{A \\cup \\{a\\}}")#text("; if ")#mi("{A}")#text(" contained ")#mi("{a}")#text(" and ")#mi("{q}")#text(" was a complete type, then so is ")#mi("{q \\cdot a}")#text(".")

#text("In a similar vein, if ")#mi("{q}")#text(" is a partial or complete type over ")#mi("{A}")#text(", then ")#mi("{q^{-1}}")#text(" is a partial or complete type over ")#mi("{A}")#text(".")

#text("Slightly less obvious is that if ")#mi("{p, q}")#text(" are partial types over ")#mi("{A}")#text(", then the product set ")#mi("{p \\cdot q}")#text(" is also a partial type over ")#mi("{A}")#text(". Indeed, for any ")#mi("{A}")#text("-definable sets ")#mi("{B, C}")#text(" containing ")#mi("{p, q}")#text(", we see that ")#mi("{p \\cdot q}")#text(" is contained in the set ")#mi("{B \\cdot C}")#text(", which is ")#mi("{A}")#text("-definable (being cut out by the formula “")#mi("{\\exists y \\in B, z \\in C: x = yz}")#text("“). On the other hand, if ")#mi("{x}")#text(" lies in all the ")#mi("{B \\cdot C}")#text(", i.e. for each ")#mi("{B, C}")#text(" one can find realisations ")#mi("{y,z}")#text(" of the formula “")#mi("{y \\in B \\wedge z \\in C \\wedge x=yz}")#text("“, then (as the intersection of definable sets is still definable) this whole family of formulae is finitely realisable, and thus (by saturation) realisable, which means that ")#mi("{x \\in p \\cdot q}")#text(". Thus we have exhibited ")#mi("{p \\cdot q}")#text(" as a finite type.")

#heading(level: 1)[#strong[#text(" — 5. Indiscernibles — ")]]

#text("We already have a notion of elementary indistinguishability: two ")#mi("{l}")#text("-tuples ")#mi("{\\vec a, \\vec b \\in G^l}")#text(" are elementarily indistinguishable (over some set of constants ")#mi("{A}")#text(") if every formula involving ")#mi("{A}")#text(" obeyed by ")#mi("{\\vec a}")#text(" is also obeyed by ")#mi("{\\vec b}")#text(" and vice versa (i.e. ")#mi("{\\vec a, \\vec b}")#text(" have the same type, or equivalently (by homogeneity) there is an automorphism that maps ")#mi("{\\vec a}")#text(" to ")#mi("{\\vec b}")#text(").")

#text("We can build upon this notion: a sequence ")#mi("{b_1, b_2, \\ldots \\in G}")#text(" is ")#emph[#text("indiscernible")]#text(" (over ")#mi("{A}")#text("), if for every ")#mi("{l}")#text(", the ")#mi("{l}")#text("-tuples ")#mi("{(b_{i_1},\\ldots,b_{i_l})}")#text(" for ")#mi("{i_1 < \\ldots < i_l}")#text(" are elementarily indistinguishable; thus the ")#mi("{b_i}")#text(" are indistinguishable, but also every ordered pair ")#mi("{(b_i,b_j)}")#text(" for ")#mi("{i < j}")#text(" are indistinguishable, and so forth. In practice, indiscernibles will be constructed by lots of Ramsey theory, and are sort of a way of pre-emptively doing all the Ramsey theory at once.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" Let ")#mi("{A \\subset G^l \\times G}")#text(" be an ")#mi("{M}")#text("-definable set for some ")#mi("{M}")#text(", and for each ")#mi("{b \\in G}")#text(", let ")#mi("{A_b}")#text(" be the slice ")#mi("{A_b := \\{ a \\in G^l: (a,b) \\in A \\}}")#text(" (note that this is a ")#mi("{M \\cup \\{b\\}}")#text("-definable set). We assume that all the ")#mi("{A_b}")#text(" are contained in an ")#mi("{M}")#text("-definable set ")#mi("{X^{\\prime}}")#text(" of finite measure. Let ")#mi("{b \\in G}")#text(" be such that ")#mi("{\\mu(A_b) > 0}")#text(", and let ")#mi("{b_1, b_2, \\ldots}")#text(" be an indiscernible sequence (over ")#mi("{M}")#text(") with the type of ")#mi("{b}")#text(" (i.e. they are all elementarily indistinguishable from ")#mi("{b}")#text(". Then any finite number of the ")#mi("{A_{b_i}}")#text(" have non-empty intersection (in fact their intersection has positive measure).")
]

#emph[#text("Proof:")]#text(" We establish this by induction. Suppose that we already know that")

#align(center)[#tao-fit-display[#mitex("\\mu( A_{b_{i_1}} \\cap \\ldots \\cap A_{b_{i_k}} ) > 0")]]

#text("for all ")#mi("{i_1 < \\ldots < i_k}")#text(" (note that this is already true for ")#mi("{k=1}")#text(" by hypothesis and indiscernability). We claim that")

#align(center)[#tao-fit-display[#mitex("\\mu( A_{b_{i_1}} \\cap \\ldots \\cap A_{b_{i_{k+1}}} ) > 0")]]

#text("for ")#mi("{i_1 < \\ldots < i_{k+1}}")#text(" also. Note by indiscernability that these measures do not actually depend on the choices of ")#mi("{i_1,\\ldots,i_{k+1}}")#text(". Suppose for contradiction that we had")

#align(center)[#tao-fit-display[#mitex("\\mu( A_{b_{i_1}} \\cap \\ldots \\cap A_{b_{i_{k+1}}} ) = 0")]]

#text("for one, and hence (by indiscernability) for all ")#mi("{i_1 < \\ldots < i_{k+1}}")#text(". In particular, this shows that the sets")

#align(center)[#tao-fit-display[#mitex("A_{b_1} \\cap \\ldots \\cap A_{b_{k-1}} \\cup A_{b_n}")]]

#text("are disjoint modulo null sets for ")#mi("{n= k, k+1, \\ldots}")#text(". On the other hand, these sets have uniformly positive measure by induction hypothesis and indiscernability. Thus their union has unbounded measure, which contradicts the hypothesis that they all lie in a set ")#mi("{X^{\\prime}}")#text(" of finite measure. ")#mi("\\Box")

#text("A remark: the above argument was phrased using the Kiesler measure ")#mi("{\\mu}")#text(", but the same argument also works for a more general structure known as a ")#emph[#mi("{S1}")#text("-ideal")]#text(". We’re not clear yet whether this additional generality will be necessary for the applications at hand.")

#text("Now we combine wide types and indiscernables, showing that wide types can be perturbed to “look the same” with respect to any finite number of indiscernibles:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4")]#text(" Let ")#mi("{b}")#text(" be an element or tuple in ")#mi("{G}")#text(", let ")#mi("{a}")#text(" be a wide type over ")#mi("{M \\cup \\{b\\}}")#text(" for some set of constants ")#mi("{M}")#text(", and let ")#mi("{b_1,b_2,\\ldots}")#text(" be a sequence of indiscernibles (over ")#mi("{M}")#text(") that has the same type as ")#mi("{b}")#text(" (over ")#mi("{M}")#text("). Then for any finite number ")#mi("{b_1,\\ldots,b_n}")#text(" in this sequence, one can find a type ")#mi("{a^{\\prime}}")#text(" such that ")#mi("{a^{\\prime}}")#text(" has the same type over ")#mi("{b_i}")#text(" as ")#mi("{a}")#text(" does over ")#mi("{b}")#text(", for all ")#mi("{1 \\leq i \\leq n}")#text(".")
]

#emph[#text("Proof:")]#text(" To abbreviate notation we suppress “over ")#mi("{M}")#text("” in everything that follows. (We’ll probably use this convention again in later seminars.)")

#text("Let ")#mi("{\\phi(a,b)}")#text(" be a formula obeyed by ")#mi("{a}")#text(" and ")#mi("{b}")#text(", then the definable set ")#mi("{A}")#text(" cut out by ")#mi("{\\phi}")#text(" is such that the slice ")#mi("{A_b}")#text(" has positive measure (since ")#mi("{a}")#text(" is wide). By the previous lemma, ")#mi("{A_{b_1} \\cap \\ldots \\cap A_{b_n}}")#text(" is thus non-empty, so we can find an ")#mi("{a^{\\prime}}")#text(" such that ")#mi("{\\phi(a^{\\prime},b_i)}")#text(" is true for all ")#mi("{1 \\leq i \\leq n}")#text(". At present ")#mi("{a^{\\prime}}")#text(" depends on ")#mi("{\\phi}")#text("; but by using saturation one can make ")#mi("{a^{\\prime}}")#text(" independent of ")#mi("{\\phi}")#text(", and the claim follows. ")#mi("\\Box")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b7ab700e796350ddebdfa8bacb73b8eb00b355248eb55f2c4990be11062ec42-3638053882aa8f4b29bdd6a4f5b04e496113c361cef5cc9541735f14c6bebdab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anand Pillay")]], [#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41986")[#strong[#text("Anand Pillay")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2009")])]

#text("I just saw the informal notes. Quite impressive.")

#text("A quick remark on the question about equivalence relations:")

#text("If the inf.-definable equivalence relation ")#mi("E")#text(" is defined by ")#mi("\\kappa")#text(" many formulas ")#mi("\\phi(x,y)")#text(" and underlying language is of size at most ")#mi("\\kappa")#text(" and one works in a universal model of cardinality much bigger than ")#mi("\\kappa")#text(", then ")#mi("E")#text(" is bounded if the cardinality of set of classes is at most ")#mi("2^{\\kappa}")#text(".")

#text("In fact it is enough to show that if ")#mi("\\phi(x,y)")#text(" is one of the formulas defining E, then there are ")#mi("a_1,\\ldots ,a_n")#text(" such that for any ")#mi("b")#text(", ")#mi("\\phi(a_i,b)")#text(" for some ")#mi("i")#text(". This follows by compactness. For if not we can find as large as one wants set of ")#mi("a_i")#text(" such that ")#mi("\\neg\\phi(a_i,a_j)")#text(" if ")#mi("i\\neq j")#text(". Then E has as many classes as you want, contradicting boundedness.")

#text("In the paper I guess there is always a countable language and by convention the inf. definable equiv. relations are defined by at most countably many formulas. So you get the bound continuuum.")

#text("It is best possible: e.g if G is saturated model of ")#mi("Th({\\Bbb Z},+)")#text(", then smallest bounded index type definable subgroup is ")#mi("\\bigcap_{n} nG")#text(" and the quotient is")#linebreak()#text(" ")#mi("\\hat Z")#text(" (profinite completion).")

#text("Maybe it is said in the paper but another definition of bounded for a inf. definable equiv. relation ")#mi("E")#text(" on definable set ")#mi("X")#text(" is that ")#mi("X/E")#text(" does not get bigger when passing from one saturated model to an elementary extension.")

#text("Also my personal impression is that whenever the paper talks about countable saturated model then one could take it to mean universal (or monster model). But ask the author.")

#text("The main point about bounded (for an equiv. relation) is that it generalizes")#linebreak()#text(" finite (i.e. if ")#mi("E")#text(" is definable then bounded = finite) and in that special case logic topology is the discrete one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41995")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2009")])]

#text("Thanks for the argument! I’ve updated the notes accordingly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b7ab700e796350ddebdfa8bacb73b8eb00b355248eb55f2c4990be11062ec42-3638053882aa8f4b29bdd6a4f5b04e496113c361cef5cc9541735f14c6bebdab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anand Pillay")]], [#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42002")[#strong[#text("Anand Pillay")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2009")])]

#text("Another brief comment, now on Terence’s notes (section 2) on Keisler measures.")

#text("I think the point of adding the predicates ")#mi("\\mu(A(\\bar x)) \\geq q")#text(" is not so much to extend ")#mi("\\mu")#text(" to a Keisler measure on a universal model (in fact Keisler measures on a model ")#mi("M")#text(" or definable set in that model always extend to elementary extensions, just by compactness). But rather to get definability of the measure (over some small set of parameters ")#mi("A")#text(") hence ")#mi("A")#text("-invariance of the measure hence ")#mi("A")#text("-invariance of the corresponding ideal.")

#text("As in 2.6 of the paper it is done in just one step: We have ")#mi("M_i = (G_i,X_i)")#text(" for ")#mi("i<\\omega")#text(", in some language ")#mi("L")#text(", including a common predicate for the ")#mi("X_i")#text(", and common function symbol for the group operation on ")#mi("G_i")#text(", and assume ")#mi("X_i")#text(" finite for all ")#mi("i")#text(". We have normalized counting measure ")#mi("\\mu_i")#text(" for each ")#mi("i")#text(", assigning ")#mi("X_i")#text(" measure 1. For ")#mi("q\\in Q")#text(", and ")#mi("\\phi(x,y)\\in L")#text(", adjoin new formula")#linebreak()#text(" ")#mi("\\theta_{\\phi,q}(y)")#text(" to L to get language ")#mi("L^{\\prime}")#text(".")

#text("Expand each ")#mi("M_i")#text(" to")#linebreak()#text(" ")#mi("L^{\\prime}")#text("-structure ")#mi("M^{\\prime}_i")#text(", defining, for ")#mi("b\\in M_i")#text(", ")#mi("\\theta_{\\phi,q}(b)")#text(" to hold iff ")#mi("\\mu_i(\\phi(x,b))\\geq q")#text(". (Iterate if you feel like it, namely do same thing with the new formulas.. etc to get ctble languages ")#mi("L \\subset L_1 \\subset L_2,\\ldots")#text(", and take ")#mi("L^{\\prime}")#text(" to be the union) Now take any model ")#mi("M^{\\prime} = (G,X,\\ldots)")#text(" of the common ")#mi("L^{\\prime}")#text("-theory of the ")#mi("M^{\\prime}_i")#text(". (e.g. a saturated or universal model..).and by virtue of the formulas ")#mi("\\theta_{\\phi,q}")#text(" we have a ")#mi("\\emptyset")#text("-definable Keisler measure ")#mi("\\mu")#text(" on ")#mi("M^{\\prime}")#text(" giving X measure 1.")

#text("So in fact no need to even mention nonstandard real numbers (sorry if I am mistaken here).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf86ac8ecae9e26bf07c8e66663f0823c01854bb67d4edcb9b3e1679c4ff182d-d586dace0f88eaf8b2db08e6bd57f5b9514bf017ad795affe372f68b23e936de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Usvyatsov")]], [#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42004")[#strong[#text("Alex Usvyatsov")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2009")])]

#text("A quick remark related to Anand’s response concerning Keisler measures and making them definable. In order to get used to this construction, it may be helpful to consider the special case when the measure ")#mi("\\mu")#text(" is a type. So suppose that ")#mi("p")#text(" is a type over a model (for simplicity) ")#mi("M")#text(". Then one can add to the language predicate ")#mi("P_{\\phi(x,y)}(y)")#text(" for every formula ")#mi("\\phi(x,y)")#text(" with the right number of variables, and interpret this predicate as the set ")#mi("\\left\\{b\\in M\\colon \\phi(x,b) \\in p \\right\\}")#text(". In this expansion of the ")#mi("M")#text(", the type ")#mi("p")#text(" is clearly definable.")

#text("Curiously enough, this construction can be used to show the existence of an indiscernible sequence in the type ")#mi("p")#text(" (a fact also mentioned in Terry’s notes above). This can possibly be seen as an easy combinatorial application of this method (normally existence of indiscernible sequences is shown using Ramsey’s Theorem). Let ")#mi("q")#text(" be a global extension of ")#mi("p")#text(" (in the expanded language) definable over ")#mi("M")#text(". So for ")#mi("c")#text(" in the universal domain, ")#mi("\\phi(x,c) \\in q")#text(" if and only if ")#mi("P_{\\phi(x,y)}(c)")#text(" holds. Now construct a “Morley sequence” in ")#mi("q")#text(" over ")#mi("M")#text(", that is, ")#mi("a_i \\models q\\upharpoonright Ma_0\\ldots a_{i-1}")#text(". It is very easy to show that such a sequence is indiscernible over ")#mi("M")#text(" (this would be true for any ")#mi("q")#text(" extending ")#mi("p")#text(", which is invariant over ")#mi("M")#text("). In particular, this sequence is, of course, indiscernible with respect to the original (smaller) language.")

#text("This observation on existence of indiscernibles is not always enough for applications needed in the paper, because sometimes one needs to start with a fixed sequence and in a sense “keep” its finitary type (for this one would use Morley’s Theorem, equivalently, stronger partition results, such as Erdos-Rado Theorem).")

#text("Another small comment: a Keisler measure (by definition) does not need to be invariant over a small set (if it is, it is called an invariant Keisler measure).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42007")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2009")])]

#text("Thanks for the comments! I think I understand Keisler measures a bit better now. I’ve adjusted the text a bit to reflect the above discussion.")

#text("When you interpret types ")#mi("p")#text(" as special kinds of measures, I assume that this is like how points can be interpreted as Dirac mass measures, so that the measure ")#mi("\\mu")#text(" assigns 1 to any definable set that contains p, and 0 to any definable set that is disjoint from p.")

#text("The whole game of making a measure definable by enlarging the language appropriately seems analogous to making a set open (or measurable, etc.) simply by throwing it into the topology (or sigma-algebra, etc.) and seeing what it generates.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf86ac8ecae9e26bf07c8e66663f0823c01854bb67d4edcb9b3e1679c4ff182d-d586dace0f88eaf8b2db08e6bd57f5b9514bf017ad795affe372f68b23e936de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Usvyatsov")]], [#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42015")[#strong[#text("Alex Usvyatsov")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("Dear Terry,")

#text("You are absolutely right in your last observation – after all, all we are doing is making a certain function on the type space continuous by enlarging the topology.")

#text("Indeed, a type ")#mi("p")#text(" is a ")#mi("\\{0,1\\}")#text("-Keisler measure: 1 if the formula is in ")#mi("p")#text(", 0 otherwise. Sorry for leaving this out.")

#text("Another thing I wanted to mention in my comment and forgot is that one can use existence of indiscernible sequences to see that e.g. a type-definable equivalence that has more than continuum many classes is unbounded (so I am assuming that everything is countable). Let ")#mi("E(x,y)")#text(" be such a relation, and ")#mi("\\langle a_i \\colon i<(2^{\\aleph_0})^+ \\rangle")#text(" are pairwise nonequivalent. By ")#link("http://myyn.org/m/article/erdos-rado-theorem/")[#text("Erdős-Rado theorem")]#text(" there is a subsequence of length ")#mi("\\aleph_1")#text(" (all we care is that it is infinite) which is 2-indiscernible. Hence by compactness there is such a sequence of any length – so there are as many ")#mi("E")#text("-classes as we want. The point is that once we have an indiscernible sequence (2-indiscernible is enough in this case), we can apply compactness.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf86ac8ecae9e26bf07c8e66663f0823c01854bb67d4edcb9b3e1679c4ff182d-d586dace0f88eaf8b2db08e6bd57f5b9514bf017ad795affe372f68b23e936de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Usvyatsov")]], [#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42016")[#strong[#text("Alex Usvyatsov")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("My apologies again. I have a silly question: is there a way of previewing comments before posting them? ")#emph[#text("[Unfortunately not; this is perhaps the biggest defect in this installation of wordpress (they cite security concerns). But I can correct the comment manually. -T]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b7ab700e796350ddebdfa8bacb73b8eb00b355248eb55f2c4990be11062ec42-3638053882aa8f4b29bdd6a4f5b04e496113c361cef5cc9541735f14c6bebdab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anand Pillay")]], [#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42065")[#strong[#text("Anand Pillay")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2009")])]

#text("We had our last seminar on the paper proper yesterday, although we will continue to look at related things. We have passed on various comments to Udi. I will give an outline of what we did regarding the proof of Theorem 1.1, with commentary. Hoping it will be helpful. I take responsibilty for any mistakes. We proved an on the face of it weaker version: ")#strong[#text("Theorem 1.1′")]#text(": Let and . Then there is a finite set of pairs of natural numbers, such that for any group and finite subset such that there is and subsets of such that (i) ; (ii) is -comparable to (i.e. -translates of each contains the other); (iii) for all ; (iv) is contained in at most -translates of ; (v) when . In fact we will prove a somewhat stronger version of 1.1'; with a uniform definability condition, which requires some preparation to state. ")#strong[#text("Preparation:")]#text(" Let be the language of groups with an additional unary predicate . Expand to a language as follows: for each -formula and nonneg. rational , add a new relation symbol , to get a language . Do it again on to get . ETC. Let be the union. Now if is a group and a finite subset, we view canonically as the universe of an structure, by interpreting the symbol as , and iteratively, given an -formula whose interpretation we know and , we define to be true of a tuple if , where is the subset of defined by . So now we state: ")#strong[#text("Theorem 1.1”")]#text(". Let and . Then there is a finite set with natural numbers and , such that for any group and finite set such that , there is , and such that (i)-(v) of 1.1' hold and in addition, (vi) is defined in the canonical -structure by for some , (vii) for all . ")#strong[#text("PROOF OF THEOREM 1.1''")]#text(". Suppose not. So for each such finite set of triples there is a counterexample . Let be the common -theory of the canonical -structures (i.e. the set of -sentences true in ALL ). By the compactness theorem there is a model of , say , such that no triple \"works\" (in the obvious sense). We aim for a contradiction by showing that some triple DOES work for . We may assume that is a saturated model (universal model) of its theory. Let be the subgroup of generated by . By a ")#emph[#text("definable subset")]#text(" of we mean a definable subset of some . Also definable means possibly with parameters, unless otherwise stated. I use the expression type-definable for what Udi calls -definable (i.e. defined by a possibly infinite conjunction of formulas, usually countable, but anyway small compared to the saturation..) ")#strong[#text("STEP I.")]#text(" Existence of a -invariant Keisler measure on , such that whenever are definable and is a left or right translate by some element of of , then have same (finite) measure. ")#strong[#text("Comment/proof.")]#text(" So is meant to be defined and finite valued on all definable subsets of . Define as follows: given defined by , let be . Then we check that , , and satisfies all the conditions. is (type)-definable over by definition, so is -invariant. Other properties are by transfer from the counting measures on the as is a model of the common theory of those things.) In particular the ideal of definable subsets of with measure 0 is an -ideal. ")#strong[#text("STEP 2.")]#text(" has a type-definable normal subgroup of bounded index, with contained in . Also is \"generic\" in (any definable subset of is covered by finitely many translates of ). ")#strong[#text("Comment.")]#text(" This is Theorem 3.4, but more precisely using Remark 6 (locality). The existence of in the hypothesis is given by 2.14. The proof is fine. It is worth comparing with the \"classical\" situation of a definable group in simple theory, and the ideal of non -generic formulas (definable subsets of ). Where a formula is -generic if every translate does not fork over . Let be an -generic type say over model . Define . Then is a type-definable normal bounded index subgroup of , in fact the smallest such which is type-def. over , and already normal. Another remark concerning specifically ind-definable (or -definable) groups , is that in the NIP context, is definably amenable (there is a left invariant Keisler measure, finite valued on definable subsets of ) iff there is a complete -generic type in and these conditions imply the exstence of (smallest type-definable bounded index subgroup). ")#strong[#text("COMMENT: LOGIC TOPOLOGY.")]#text(" is a locally compact group under the logic topology: a subset of is closed iff its preimage in has property that the intersection of with any definable subset of (i.e each ) is type-definable. Also is compact iff its preimage in is outright type-definable (in particular contained in a definable subset of ). ")#strong[#text("STEP 3")]#text(". There is relatively definable subgroup of (intersection with any definable subset of is definable) and a normal subgroup , type-definable and containing , such that (i) with the logic topology is a connected Lie group . (ii) the preimage in of some neighbouhood of identity in is contained in a definable subset of (follows from (i) anyway). Moreover any definable subset of (or ) containing is comparable to . ")#strong[#text("Comment.")]#text(" This is a weak version of 4.2. It is just manipulation of logic topology, and using the fact that any locally compact group has an open subgroup which is pro-Lie. Concerning the moreover clause: if are two definable subsets of containing then by compactness finitely many translates of each cover the other, in fact each is generic. Moreover by the argument before 3.2 (Rusza) as is wide, is generic (finitely many translates cover any definable subset of . ")#strong[#text("STEP 4.")]#text(" This is 4.9, and here one gets the contradiction. Nothing really to add. Choose suitable small ball in Lie algebra of , let . Let . Let be a definable subset of lying in between and . Let . Put . For some , at most translates of cover for all . Also, is comparable (so -comparable for some ) with . Also is definable by say . Check other conditions (i) to (vii) hold. So we contradict that does not work for . END. ")#strong[#text("REMARK.")]#text(" I understand that in Theorem 1.1'' one can choose the formulas \"without parameters\" i.e. just . (See proof of 4.11.) This is related to -definability and canonicity demands in 4.2 (which we ignored above), as well as getting -definable which we also ignored above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf86ac8ecae9e26bf07c8e66663f0823c01854bb67d4edcb9b3e1679c4ff182d-d586dace0f88eaf8b2db08e6bd57f5b9514bf017ad795affe372f68b23e936de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Usvyatsov")]], [#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42066")[#strong[#text("Alex Usvyatsov")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2009")])]

#link("http://www.math.ucla.edu/~alexus/papers/talks/udi1.pdf")[#text("Here")]#text(" are some notes that I wrote on the proof of Corollary 1.2 for our seminar. Hope they will be of some help. Corrections are very welcome.")

#text("Let me be the first to (as Ward has put it) share my confusion. I am a bit unclear on the issue of parameters one works over. For example, in the proof of Corollary 1.2 Udi seems to be working over ")#mi("\\emptyset")#text(", whereas the stabilizer is type definable over some model ")#mi("M")#text(", which is obtained in Lemma 2.14. In the proof of Corollary 1.2, for example, it doesn’t seem possible to just throw in constants for a model. In my notes, I dealt with this issue in the following way: take an ultra-product of counterexamples. Since it is ")#mi("\\aleph_1")#text("-saturated, we may assume that ")#mi("M")#text(" lies in it. By working to begin with with formulas with parameters over the finite structures, we can strengthen the demand on ")#mi("X")#text(" in the ultra-product: no subgroup defined with parameters (over ")#mi("M")#text(", say) which lies in ")#mi("X^2")#text(" can finitely cover ")#mi("X")#text(".")

#text("First, I hope I am not making a mistake here. Second, my question is: is there something I am missing? Is there an easier way to avoid this issue?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf86ac8ecae9e26bf07c8e66663f0823c01854bb67d4edcb9b3e1679c4ff182d-d586dace0f88eaf8b2db08e6bd57f5b9514bf017ad795affe372f68b23e936de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Usvyatsov")]], [#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42131")[#strong[#text("Alex Usvyatsov")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2009")])]

#text("Apparently, the parameters issue is clarified in the new version of Udi’s paper. Indeed, in the proof of Corollary 1.2 one can work with parameters (e.g. like in my notes, or in Anand’s comment). On the other hand, using the correspondence with Lie group, one can obtain ")#mi("S")#text(" over the empty set (see Lemma 4.5). So confusion withdrawn.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42068")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2009")])]

#text("Dear Anand and Alex,")

#text("Thank you very much for supplying your own notes on these papers, this will be very useful for our group to “catch up”…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Reading seminar 3: “Stable group theory and approximate subgroups”, by Ehud Hrushovski « What’s new")]], [#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42103")[#strong[#text("Reading seminar 3: “Stable group theory and approximate subgroups”, by Ehud Hrushovski « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2009")])]

#text("[…] types for us will be that they can be used to generate sequences of indiscernibles (as defined in previous notes): Lemma 3 Let be a global invariant type of some arity , and construct recursively a sequence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Reading seminar 4: “Stable group theory and approximate subgroups”, by Ehud Hrushovski « What’s new")]], [#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42267")[#strong[#text("Reading seminar 4: “Stable group theory and approximate subgroups”, by Ehud Hrushovski « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("[…] that the index of in does not exceed in cardinality (i.e. has bounded index, see Lemma 1 of Notes 2). Indeed, if this were not the case, then one could find more than disjoint cosets in , and hence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Reading seminar 5: “Stable group theory and approximate subgroups”, by Ehud Hrushovsk « What’s new")]], [#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42446")[#strong[#text("Reading seminar 5: “Stable group theory and approximate subgroups”, by Ehud Hrushovsk « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2009")])]

#text("[…] Anand Pillay’s sketch of a simplified proof of Theorem 1.1. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2abcbcbb92a5b93cde40dce794410aca0925a10adc3e98ec0b679ccacac85059-da26a8a0e7d8357853f1cd3197c011982c8c32c5e160c2edd13cb519f80aebeb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Lowengrub")]], [#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-141256")[#strong[#text("Daniel Lowengrub")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2012")])]

#text("Hi,")#linebreak()#text(" Thanks for the great notes. I have one small question. In the proof of lemma 2, shouldn’t ")#mi("q^{\\prime}")#text(" be ")#mi("q")#text(" ")#emph[#text("without")]#text(" all of the ")#mi("A")#text("-definable sets of measure zero? Because we want ")#mi("q^{\\prime}")#text(" to be disjoint from all of those sets.")

#emph[#text("[Corrected, thanks – T.]")]
]
