// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/01/11/homogeneous-length-functions-on-groups/
// Converted to Typst by tao2typ: "2026-10-14T16:38:15.582330+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Homogeneous length functions on groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Homogeneous length functions on groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 January 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/01/11/homogeneous-length-functions-on-groups/")[#text("https://terrytao.wordpress.com/2018/01/11/homogeneous-length-functions-on-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("The ")#link("http://michaelnielsen.org/polymath1/index.php?title=Linear_norm")[#text("Polymath14 online collaboration")]#text(" has uploaded to the arXiv its paper “")#link("http://arxiv.org/abs/1801.03908")[#text("Homogeneous length functions on groups")]#text("“, submitted to Algebra & Number Theory. The paper completely classifies ")#emph[#text("homogeneous length functions")]#text(" ")#mi("{\\| \\|: G \\rightarrow {\\bf R}^+}")#text(" on an arbitrary group ")#mi("{G = (G,\\cdot,e,()^{-1})}")#text(", that is to say non-negative functions that obey the symmetry condition ")#tao-math("{\\left\\|x^{-1}\\right\\| = \\left\\|x\\right\\|}", block: false)#text(", the non-degeneracy condition ")#tao-math("{\\left\\|x\\right\\|=0 \\iff x=e}", block: false)#text(", the triangle inequality ")#tao-math("{\\left\\|xy\\right\\| \\leq \\left\\|x\\right\\| + \\left\\|y\\right\\|}", block: false)#text(", and the homogeneity condition ")#tao-math("{\\left\\|x^2\\right\\| = 2\\left\\|x\\right\\|}", block: false)#text(". It turns out that these norms can only arise from pulling back the norm of a Banach space by an isometric embedding of the group. Among other things, this shows that ")#mi("{G}")#text(" can only support a homogeneous length function if and only if it is abelian and torsion free, thus giving a metric description of this property.")

#text("The proof is based on repeated use of the homogeneous length function axioms, combined with elementary identities of commutators, to obtain increasingly good bounds on quantities such as ")#tao-math("{\\left\\|[x,y]\\right\\|}", block: false)#text(", until one can show that such norms have to vanish. See ")#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/")[#text("the previous post")]#text(" for a full proof. The result is robust in that it allows for some loss in the triangle inequality and homogeneity condition, allowing for some new results on “quasinorms” on groups that relate to quasihomomorphisms.")

#text("As there are now a large number of comments on ")#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/")[#text("the previous post")]#text(" on this project, this post will also serve as the new thread for any final discussion of this project as it winds down.")

#heading(level: 1)[#text("Comments (17)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/11/homogeneous-length-functions-on-groups/#comment-491330")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2018")])]

#text("I’ve also submitted the paper to Algebra & Number Theory. Thanks to everyone for their participation in what I found to be an enjoyable and productive project!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2018/01/11/homogeneous-length-functions-on-groups/#comment-491335")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2018")])]

#text("I also want to say thanks to everyone! It has been a lot of fun and also a great learning experience.")

#text("I feel like our problem has been just about right for such a project: not too hard and not too easy, simple to grasp, and approachable from a lot of different angles. Especially concerning the level of difficulty, this problem was more rewarding than Polymath11 on the union-closed sets conjecture, where we had run out of steam after two months. I’m looking forward to possible future Polymath projects, whether that may be as a participant or as a curious spectator.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66f4b2c2c940ea2715fb8e42388470aa28da00d4f38d28ef09b9715eab259a08-84614eb4751eff6f776aace931405cd82643772518c83fe1b781206ebf4adebd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roy Abrams")]], [#link("https://terrytao.wordpress.com/2018/01/11/homogeneous-length-functions-on-groups/#comment-494779")[#strong[#text("Roy Abrams")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("Tobias, apologies for the late follow up, but in regards to Polymath 11, how does this idea sound?")#linebreak()#text(" 1. Frankl’s Conjecture asserts that in any family of sets (1,2,3…) that is union closed, there is a least one element (a,b,c…) found in at least half of all the subsets of the set containing all elements in the family.")#linebreak()#text(" 2. Arrange the sets in ascending order of cardinality, from smallest set to the set containing all elements. Sets of equal cardinality can be put in any order within the overall arrangement.")#linebreak()#text(" 3. The smallest set is “irreducible.” The union of any two sets is either a subset of the larger one, or has cardinality greater than the larger one, or is, in the case of two sets of equal cardinality, a set of greater cardinality.")#linebreak()#text(" 4. Number the sets from 1 to N in ascending order, N being the set of greatest cardinality.")#linebreak()#text(" 5. Create the power set of all sets, 1 to N – 1.")#linebreak()#text(" 6. Because set union is associative and commutative, and because union-closed families include every union, every set represented in the power set is a member of the union closed family, one of the numbered sets used as generators.")#linebreak()#text(" 7. Some of these sets are entirely contained in their set of greatest cardinality. Some include all the sets enumerated, but belong to a set of greater cardinality that is not part of the bracketed sets.")#linebreak()#text(" 8. Because the number of subsets of the power set is strictly larger that the set containing the original elements (and grows exponentially), each element will be represented by multiple subsets of the power set.")#linebreak()#text(" 9. Therefore multiple subsets will be equivalent, representing the same unique generating set.")#linebreak()#text(" 10. Equivalence of these subsets of the original set implies intersections, i.e., element(s) (a,b,c…) appear in more than one generating set.")#linebreak()#text(" 11. Using the ‘irreducibility” of the least set (1), you should be able to establish a chain of subsets in which one is included in more than half the original sets (1,2,3…). Obviously, the power set grows must faster than the number of original sets, so a kind of induction might be possible.")#linebreak()#text(" 12. For example, establish that 1 is a proper subset of 3, establish that 3 is a proper subset of 6, etc.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2018/01/11/homogeneous-length-functions-on-groups/#comment-494812")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2018")])]

#text("I can follow your reasoning up to item 10, but the main problem is how to prove a statement along the lines of your item 11. One issue is that a set of least cardinality does not necessarily have abundance ")#mi("\\geq 1/2")#text("; in fact, it’s easy to construct examples showing that its abundance can be arbitrarily small, even when it’s the unique set of least cardinality.")

#text("My general feeling at the end of Polymath11 has been that we had just scratched the surface of the problem, getting some feel for how difficult it is. The naive hope that I had at the end is that it may be possible to derive a constant lower bound (but smaller than ")#mi("1/2")#text(") by proving a suitable result on approximating every finite lattice by another type of lattice for which FUNC is known to hold, e.g. a geometric lattice. This goes in a vaguely similar direction as what you’re suggesting. But I don’t know how to go about this technically, and it will definitely require an enormous effort.")

#text("In any case, perhaps this discussion would be more appropriate over at the ")#link("https://gowers.wordpress.com/2016/02/22/func4-further-variants/")[#text("last Polymath11 thread")]#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66f4b2c2c940ea2715fb8e42388470aa28da00d4f38d28ef09b9715eab259a08-84614eb4751eff6f776aace931405cd82643772518c83fe1b781206ebf4adebd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roy Abrams")]], [#link("https://terrytao.wordpress.com/2018/01/11/homogeneous-length-functions-on-groups/#comment-494820")[#strong[#text("Roy Abrams")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2018")])]

#text("Thanks, Tobias.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/11/homogeneous-length-functions-on-groups/#comment-491336")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2018")])]

#text("It seems that the numbering of results is not consecutive (e.g. results 1.1 and 1.2 are missing).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2018/01/11/homogeneous-length-functions-on-groups/#comment-491337")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2018")])]

#text("We seem to be using an enumeration style where equations and theorem environments have a shared counter. So (1.1) and (1.3) are equations, and similarly in Section 2.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2018/01/11/homogeneous-length-functions-on-groups/#comment-491339")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2018")])]

#text("Thanks to everyone from me too. It was truly enjoyable and I learnt a lot.")#linebreak()#text(" Mainly as an exercise for my benefit. I have formalized (in the sense of computer verified, but with idiosyncratic foundations) the internal repetition lemma at ")#link("http://siddhartha-gadgil.github.io/ProvingGround/tuts/LengthFunctions.html")[#text("http://siddhartha-gadgil.github.io/ProvingGround/tuts/LengthFunctions.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/15fdd26260b7494ddff8ae819232b8672e2244d264a794710238bd87a2460350-bf33e1a619ddefa0ea9c77e08888cfca229a3c54d92f5aa63c15cd9e70570d84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nicodean")]], [#link("https://terrytao.wordpress.com/2018/01/11/homogeneous-length-functions-on-groups/#comment-491380")[#strong[#text("nicodean")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2018")])]

#text("Terence Tao wrote on 22.Dec 2017: “Secondly, again as with some previous Polymath projects, computer assistance was quite important, even if the final proof is not visibly computer-assisted in any way. […]. We’re still some way off from the dream of computers routinely generating large chunks of proofs and/or conjectures for us, but nevertheless they are playing an increasingly essential role in mathematics.”")

#text("Is there any possibility to summarize in more details of computer-assistance (by any of the participants; and on a more abstract level maybe, i am not an expert in this field)? Also maybe in the other polymath projects? Is there a structure of mathematical problems that are quite good for computer-assisted proofs? What where the insights, has it “just” been the calculation of difficult formulars – i.e. standard Mathematica problems? This is super interesting!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2018/01/11/homogeneous-length-functions-on-groups/#comment-491384")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2018")])]

#text("The role of the computer (used by me) was to find a proof of an (at that time best) concrete bound on the length of the commutator of generators, and output this in a (barely) human readable form as [posted](")#link("https://github.com/siddhartha-gadgil/Superficial/wiki/A-commutator-bound")[#text("https://github.com/siddhartha-gadgil/Superficial/wiki/A-commutator-bound")]#text("). Pace Nielsen read through the proof and saw a pattern, with the “same” conjugacy and the “same” pair of triangle inequalities being repeatedly applied in this proof. This was used by him to get strong bounds, and then he and others refined and abstracted this to get the _splitting lemma_ in the paper.")

#text("There were two limitations of the way the computer proof was done:")

#text("* While the use of conjugacy invariance and triangle inequality was optimal and algorithmic, of which elements to take powers was manually specified by me. This should have been made smart, and would have soon enough except the extreme smartness of the people in this polymath group made this redundant (problem was solved within 24 hours of the first posted computer proof).")#linebreak()#text(" * More importantly, I used [domain specific foundations](")#link("https://github.com/siddhartha-gadgil/Superficial/blob/master/src/main/scala/freegroups/LinNormBound.scala")[#text("https://github.com/siddhartha-gadgil/Superficial/blob/master/src/main/scala/freegroups/LinNormBound.scala")]#text("), which could encode only one kind of proof, that a specific word has length bounded by a specific number. This rules out in particular both firmulas for bounds that are quatified (and so must invlove variables) and recursion/induction. To show that such results can be at least _encoded_ I formalized the [internal repetition trick](")#link("http://siddhartha-gadgil.github.io/ProvingGround/tuts/LengthFunctions.html")[#text("http://siddhartha-gadgil.github.io/ProvingGround/tuts/LengthFunctions.html")]#text(").")

#text("More generally, where a computer helped was in following instructions of the form “try these method in lots of cases in lots of ways and give me the best proof for thess cases (or where we got a strong result)”. It is obvious that the “lots of cases” and “lots of ways” are much bigger numbers for computers than by hand. The question is how general one can be with “these methods”. I do think even in practice a lot of methods can be encoded, and this is underutilized as people underestimate this. In principle, in the era of Homotopy type theory and Deep learning, presumably every method can be encoded.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1838db9b81e7190589d23226251890fc2c360adcdf89368a7c5d4c1bd46c1015-63765fc9cb087c202f6564d48d160a630d36c0c76dd8956d02effbba08c29ff9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J Button")]], [#link("https://terrytao.wordpress.com/2018/01/11/homogeneous-length-functions-on-groups/#comment-491455")[#strong[#text("J Button")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2018")])]

#text("Hi – didn’t see the blog until the arxiv paper was posted and now")#linebreak()#text(" this feels rather late in the day (or sometime the next day) but")#linebreak()#text(" still: why can’t we argue thus….")

#text("Given ")#mi("G")#text(" with homogeneous (pseudo-) length function ")#mi("l")#text(",")#linebreak()#text(" let ")#mi("k>0")#text(" be your favourite upper bound that holds for all")#linebreak()#text(" commutators, thus ")#mi("l([a,b])\\leq k")#text(" for all ")#mi("a,b\\in G")#text(". By")#linebreak()#text(" Culler’s identity ")#mi("[a,b]^3=[aba^{-1},b^{-1}aba^{-2}][b^{-1}ab,b^2]")#linebreak()#text(" (sometimes seen in introductions to stable commutator length)")#linebreak()#text(" we have ")#mi("3l([a,b])\\leq  l([aba^{-1},b^{-1}aba^{-2}])+l([b^{-1}ab,b^2]) \\leq 2k")#text(", thus we now know ")#mi("l([a,b])\\leq 2k/3")#text(" holds for any")#linebreak()#text(" commutator. So now use the argument recursively to get")#linebreak()#text(" ")#mi("l([a,b])\\leq k(2/3)^n")#text(" for all ")#mi("a,b")#text(" and hence ")#mi("l([a,b])=0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2018/01/11/homogeneous-length-functions-on-groups/#comment-491456")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2018")])]

#text("That’s a nice idea, but it doesn’t quite work like that: in any nonzero upper bound, the right-hand side also should be linear in ")#mi("\\ell")#text(", e.g. of the form ")#mi("\\ell([a.b])\\leq k(\\ell(a) + \\ell(b))")#text(". Using conjugation invariance, we can deduce from Culler’s identity that")

#mi("3\\ell([a,b]) \\leq k(\\ell(b) + 2\\ell(b) + \\ell(a)) + k(\\ell(a) + 2\\ell(b)")#text(",")

#text("assuming that ")#mi("\\ell")#text(" satisfies homogeneity and the triangle inequality on the nose. Thus ")#mi("\\ell([a,b]) \\leq k(\\tfrac{2}{3}a + \\tfrac{5}{3}b)")#text(".")

#text("Doing a more refined analysis along the lines of Proposition 1 in the ")#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/")[#text("second blog post")]#text(" could be interesting, but I haven’t done this yet and find it hard to say whether it would have the potential to lead to an alternative proof or not.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1838db9b81e7190589d23226251890fc2c360adcdf89368a7c5d4c1bd46c1015-63765fc9cb087c202f6564d48d160a630d36c0c76dd8956d02effbba08c29ff9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J Button")]], [#link("https://terrytao.wordpress.com/2018/01/11/homogeneous-length-functions-on-groups/#comment-491458")[#strong[#text("J Button")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2018")])]

#text("Ah, yes – thanks! We don’t have a uniform upper bound for commutators (was going between a,b for free basis and for")#linebreak()#text(" arbitrary elements).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2018/01/11/homogeneous-length-functions-on-groups/#comment-491460")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2018")])]

#text("This is to record an erratum pointed out to us by email and its correction.")

#text("Let ")#mi("A")#text(" be a group equipped with a homogeneous norm ")#mi("\\Vert\\cdot\\Vert")#text(" (")#mi("A")#text(" is necessarily abelian and torsion-free). Then this norm extends to a norm on the ")#mi("\\mathbb{Q}")#text("-vectorspace ")#mi("A_\\mathbb{Q} = \\mathbb{Q}\\otimes_\\mathbb{Z} A")#text(". In detail, every element of ")#mi("A_\\mathbb{Q}")#text(" has a representative of the form ")#mi("r\\otimes a")#text(" with ")#mi("r\\in\\mathbb{Q}, a\\in A")#text(" and we set ")#tao-math("\\left\\| r\\otimes a\\right\\| = \\left| r \\right| \\left\\| a\\right\\|", block: false)#text(".")

#text("Now let $\\overline{A_\\mathbb{Q}}$ be the metric completion of ")#mi("A_\\mathbb{Q}")#text(". This is still a normed group into which ")#mi("A")#text(" embeds, and is in fact an ")#mi("\\mathbb{R}")#text("-vectorspace: if ")#mi("\\{r_n\\}_n\\subset \\mathbb{Q}")#text(" and ")#mi("\\{x_n\\}_n\\subset A_\\mathbb{Q}")#text(" are Cauchy sequences and then so is ")#mi("\\{r_n x_n\\}_n")#text(" and it is easy to check that its equivalence class depends only on the equivalence classes on the original sequences. Since also ")#tao-math("\\left\\| r_n x_n \\right\\|  = \\left| r_n\\right| \\left\\| x_n \\right\\|", block: false)#text(" it also follows that the norm is ")#mi("\\mathbb{R}")#text("-homogenous. In summary, ")#mi("\\overline{A_\\mathbb{Q}}")#text(" is naturally a complete normed ")#mi("\\mathbb{R}")#text("-vector space, that is a Banach space.")

#text("Finally, there is a natural map of ")#mi("\\mathbb{Q}")#text("-vectorspaces ")#mi("\\iota\\colon A_\\mathbb{Q} \\to \\overline{A_\\mathbb{Q}}")#text(". This map is injective since our extension of the norm was still a norm. Since the RHS is compatibly an ")#mi("\\mathbb{R}")#text("-vectorspace, this induces a further map of ")#mi("\\mathbb{R}")#text("-vectorspaces")

#mi("\\iota_\\mathbb{R}: A_\\mathbb{R} = \\mathbb{R}\\otimes_\\mathbb{Z} A \\equiv \\mathbb{R}\\otimes_\\mathbb{Q} A_\\mathbb{Q} \\to \\overline{A_\\mathbb{Q}}")#text(".")

#text("However, the latter map need not be injective! In other words, when we pull back the norm from ")#mi("\\overline{A_\\mathbb{Q}}")#text(" to ")#mi("A_\\mathbb{R}")#text(", the result need only be a seminorm.")

#text("For example, if we start with the norm ")#tao-math("\\left\\| (a,b) \\right\\|  = \\left|a+b\\sqrt{2}\\right|", block: false)#text(" on ")#mi("A = \\mathbb{Z}^2")#text(" then the same formula defines a norm on ")#mi("A_\\mathbb{Q} = \\mathbb{Q}^2")#text(" but only a seminorm on ")#mi("A_\\mathbb{R} = \\mathbb{R}^2")#text(". To get a norm we need to divide by the subspace ")#mi("\\mathrm{Span}_\\mathbb{R} (\\sqrt{2},-1)")#text(" which is compatible with everything we’ve said since this subspace is disjoint from the image of ")#mi("A")#text(" here so ")#mi("A")#text(" and ")#mi("A_\\mathbb{Q}")#text(" still inject in the quotient (isometrically, as they must).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2018/01/11/homogeneous-length-functions-on-groups/#comment-491462")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2018")])]

#text("Adding: this is all already in the paper; but we could clarify better the distinction between ")#mi("\\overline{A_\\mathbb{Q}}")#text(" (in the paper called ")#mi("\\mathbb{B}")#text(") and ")#mi("G_\\mathbb{R}")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4ad6c18186ffa1aab4aadbb6437ddfdfd03ffdb28fa7b75fb5a4b74dadd060d-b17876bb6ed44b4eb4e6f409d6e9c2e04bf2fd6789fad7fda897a642de72445e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spontaneous Polymath 14 – A success! | The polymath blog")]], [#link("https://terrytao.wordpress.com/2018/01/11/homogeneous-length-functions-on-groups/#comment-491785")[#strong[#text("Spontaneous Polymath 14 – A success! | The polymath blog")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2018")])]

#text("[…] This post is to report an unplanned polymath project, now called polymath 14 that took place over Terry Tao’s blog. A problem was posed by Apoorva Khare was presented and discussed and openly and collectively solved. (And the paper arxived.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/11/homogeneous-length-functions-on-groups/#comment-592599")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2020")])]

#text("Readers who had followed the Polymath14 project may be interested to know that the discussion for this project was used as a test data set for a collaborative research platform “Sophize”, as presented in ")#text("this video")#text(".")
]
