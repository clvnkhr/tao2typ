// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/
// Converted to Typst by tao2typ: "2026-10-14T16:39:01.105444+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The International Congress of Mathematicians (ICM 2022) will now be fully virtual.  How best to utilise this format?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The International Congress of Mathematicians (ICM 2022) will now be fully virtual.  How best to utilise this format?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 February 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/")[#text("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[Note: while I am ")#link("https://www.mathunion.org/icm/icm-2022")[#text("chair of the ICM Structure Committee")]#text(", this blog post is not an official request from this committee, as events are still moving too rapidly to proceed at present via normal committee deliberations. We are however discussing these matters and may issue a more formal request in due course. -T.]")]

#text("The International Mathematical Union has ")#link("https://www.mathunion.org/")[#text("just made")]#text(" the ")#link("https://www.mathunion.org/fileadmin/IMU/ICM2022/ICM_2022_statement.pdf")[#text("following announcement")]#text(" concerning the International Congress of Mathematicians (ICM) that was previously scheduled to be held in St. Petersburg, Russia in July.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#emph[#strong[#text("Decision of the Executive Committee of the IMU on the upcoming ICM 2022 and IMU General Assembly")]]

#text("On 26 February 2022, the Executive Committee of the International Mathematical Union (IMU) decided that:")

#text("1. The International Congress of Mathematicians (ICM) 2022 will take place as a fully virtual event, hosted outside Russia but following the original time schedule planned for Saint Petersburg.")#linebreak()#text("2. Participation in the virtual ICM event will be free of charge.")#linebreak()#text("3. The IMU General Assembly (GA) will take place as an in-person event outside Russia.")#linebreak()#text("4. A prize ceremony will be held the day after the IMU GA, at the same venue as the IMU GA, for the awarding of the 2022 IMU prizes.")#linebreak()#text("5. The dates for the ICM and the GA will remain unaltered.")#linebreak()#text("6. We will return with further practical information regarding the two events.")
]

#text("An expanded version of the announcement ")#link("https://www.mathunion.org/fileadmin/IMU/ICM2022/ICM_2022_statement.pdf")[#text("can be found here")]#text(". (See also ")#link("https://www.mathunion.org/fileadmin/IMU/Publications/CircularLetters/2022/IMU%20AO%20CL%206_2022.pdf")[#text("this addendum")]#text(".)")

#text("While I am not on the IMU Executive Committee and thus not privy to their deliberations, I have been in contact with several members of this committee and I support their final decision on these matters.")

#text("As we have all experienced during the COVID-19 pandemic, virtual conferences can be rather variable in quality, but there certainly are ways to make the experience more positive for both the speakers and participants. In the interest of maximizing the benefits that this meeting can still produce, I would like to invite readers of this blog to share any experiences they have had with very large virtual conferences, and any opinions on what types of virtual events were effective and engaging.")

#text("One idea that has been suggested to me has been to have (either unofficial, semi-official, or official) regional ICM hosting events at various places worldwide where mathematicians could gather in person to view ICM talks that would be streamed online (and perhaps some ICM speakers from that area could give talks in person in such locations). This would be very nonstandard, of course, but could be one way to salvage some of the physical ICM experience, and perhaps also a way to symbolically support the spirit of the Congress. I would be interested to get some feedback on this proposal.")

#text("Finally, I would like to request that comments to this post remain focused on the upcoming virtual ICM. Broader political issues are very much worth discussing at present, but there are other venues for such discussion, and as per ")#link("https://terrytao.wordpress.com/about/")[#text("my usual blog policy")]#text(" any off-topic comments may be subject to deletion.")

#heading(level: 1)[#text("Comments (68)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640868")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("Dear Terry,")

#text("I’m don’t know how the ICM committee plans to implement this online venue. But given the circumstances behind this change, I would recommend that they carefully consider the possibility of organized Zoom bombing, or something like it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640869")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("Hats off for making it free of charge! I think that this will attract many people to tune in for a few talks, making it the biggest congress ever. In comparison, FOCS cost hundreds of dollars: ")#link("https://focs2021.cs.colorado.edu/registration/")[#text("https://focs2021.cs.colorado.edu/registration/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f563bddef1ea6c900459b818043ae43f59604042e090bc80cd98e994ab2ad2d-855eee57d6ce545af19e1c1d482f30e9f9ca47a674424b7182685751495a71c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of davidmfisher")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640870")[#strong[#text("davidmfisher")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("Thanks Terry. I just wrote to Kenig expressing my disappointment that not only is ICM virtual, but somewhat perplexingly being planned to proceed according to the schedule made for a live event in St. Petersburg. I like your idea of regional ICM events, but think more needs to be done to adapt to the new medium for this to be at all practical. I guess you can hold a watch party with a bunch of different streams of different sessions at UCLA and I might enjoy coming to something like that. But the fact that the talks will essentially happen overnight in your timezone is probably going to crimp attendance quite a bit. As well as comprehension of the mathematics. IMU and ICM organizers really need to think through the shift to virtual in some more serious way or this is going to be a farce not an ICM.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c58d20ac76d30688691ba02cd1ba2090efa08a031aa044e1c84aebfd3e7a2b2-c6238ca5fb438c878029dd135258924aab53e9fd3b29079ad77063ed9f9048bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Noah Snyder")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640872")[#strong[#text("Noah Snyder")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("Another option rather than regional ICM watch parties would be for universities across Europe (and Africa and the Middle East) to host watch parties. It’s very difficult to get a giant conference center and hotel space at the scale of the ICM, but easier if it’s spread across 20 cities and you use university lecture halls. And unlike the regional idea, you’d actually be in the right time zone.")

#text("Time zones are the Achilles heel of virtual events.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f563bddef1ea6c900459b818043ae43f59604042e090bc80cd98e994ab2ad2d-855eee57d6ce545af19e1c1d482f30e9f9ca47a674424b7182685751495a71c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of davidmfisher")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640873")[#strong[#text("davidmfisher")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("That is a great idea. And maybe puts it back in the hands of IMU to organize it somehow rather than just having local folks do it for local people. Maybe even AMS-Simons travel grants could be reactivated to fund participation of younger US folks in these events.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640893")[#strong[#text("Eva Miranda (@evamirandag)")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")]

#text("This is a good idea. Maybe the EMS or ERCOM can help to coordinate efforts.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640871")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("I think the (hopefully) unique circumstance of holding an online ICM would give the perfect opportunity to use this momentum to create and launch permanent IMU chat servers dedicated to each mathematical subarea covered by the ICM.")

#text("During the conference itself, these could serve as “virtual tea rooms” where people can gather and discuss topics amongst themselves and with the speakers. But even more importantly, after the ICM and into the future, these servers could function as a hub for people of all levels of experience to discuss mathematics, in a way that is less episodic than MathOverflow questions, but specialized enough to subareas that there is a good chance they will find an expert able to engage their questions.")

#text("The main example I have in mind is the wonderfully successful Algebraic Topology Discord server run by Charles Rezk and friends:")

#link("https://faculty.math.illinois.edu/~rezk/discord.html")[#text("https://faculty.math.illinois.edu/~rezk/discord.html")]

#text("Just browsing the server, you can see how there is a #basic-questions section where people learning the subject can immediately get helpful answers from experts. You can see that the chat format enables better in-depth live discussion than the ping-pong commenting format of MathOverflow. There are many other channels besides. I have wished on more than one occasion that a server like this existed for harmonic analysis (if it does and I just don’t know about it, please tell me).")

#text("In some other areas, such as number theory, there have been perhaps too many such servers springing up. The problem here is that the community becomes rather dispersed, and these servers don’t seem to picked up a large enough “popular critical mass” individually to be as successful.")

#text("The key advantage of running servers under the ICM and the IMU is that such “official” servers will hopefully attract a very large audience from the beginning and thus avoid the dispersion problems we see with multiple unofficial servers springing up in the same subfield. This is one occasion where some centralization would be quite helpful.")

#text("As for the implementation, I’m not certain what software would be best to use. Discord is of course not specifically designed for mathematics, although it seems to do okay. Zulip is another program I have seen used. Maybe a better idea would be something open-source? The IMU would try creating some experimental servers before the ICM to see which works best.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/951516ab72f8eb7e1f0e5e8704dfba7b644383ab92421ee28d997a0921673a9c-4b054f158dec8d55eb32281674b0ca879dfb2ab9a4d79ab87ace095e613c8875.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dima")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640879")[#strong[#text("Dima")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("zulip is open-source. ")#link("https://zulip.com")[#text("https://zulip.com")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4e11a7d49fdff39d5cc275ab1120954e83a6f7e6b508329161fb80bd0d7c821-ff9c7350b78e85c3ea0df313cedd34930a4b72e1a4f69efd0ecb138984506eb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zhouhang Mᴀᴏ")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640887")[#strong[#text("Zhouhang Mᴀᴏ")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("Yes, being open-source is very important.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/547fac0c397fe33901c42b42bad04ef1b0f6285d8857afc43d7b905e8222483f-e49cedda877b95b030211940d738fdf716b6d1f0055478521a1a170bf18d6a25.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-641022")[#strong[#text("Kevin")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2022")])]

#text("They did this in Strings 2021 (which was virtual) and I thought it worked really well. They used Slack to host the discussions, which I believe supports Latex. There were active discussion sessions in slack on many of the talks, in which several of the speakers engaged.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a04c83e86d769062ef3f777df324f02635f2a99d7c66fac69532f11520f36e3-7401a58e80ec2855688c84b36976b1c0074af1891fec75caa2763143a37c8c6e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mhairer")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-642530")[#strong[#text("mhairer")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2022")])]

#text("Just in case someone stumbles over this post, there is now a Discord server for ICM 2022 at ")#link("https://discord.gg/T72dTkfSzF")[#text("https://discord.gg/T72dTkfSzF")]#text(". Note though that although the IMU is very happy about this, it is not actually run by the IMU.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of obryant")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640876")[#strong[#text("obryant")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("JuliaCon (supporting progress in the Julia math-friendly computing language) the past several years has had a successful Gathertown site.")

#text("Gathertown looks like a 1988 video game, an overhead map with a “character” that can be moved around. The 2022 social wrinkle is that you are automatically put into a video call with all of the nearby characters. I don’t enjoy remote talks at all, but I found the Gathertown experience rewarding at JuliaCon, and for our local math club. We tried it at CANT 2021, but didn’t have enough participation to hit critical mass.")

#text("It might recover some of that “accidentally running into someone you know” atmosphere.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f563bddef1ea6c900459b818043ae43f59604042e090bc80cd98e994ab2ad2d-855eee57d6ce545af19e1c1d482f30e9f9ca47a674424b7182685751495a71c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of davidmfisher")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640878")[#strong[#text("davidmfisher")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("I’ve been to several math events that used gathertown. it seems the best version of this out there, I’ve also been to events that used competing programs. But it never seems to me to have worked very well. Another major issues is: who wants to run around in gathertown instead of going to some other live event. This is why I like the suggestions of Terry and Noah for having some smaller in person events that functionally replace ICM for gathering in person.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d610436fa31a57aebbbba1bed72bf7d09f933f9fb2f9d18bb7ed999a311972-2cb1a896650c47f72bd25f53a26a7779cb7445b3d76dbbf401a05d1371c4d41e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of palais@uci.edu")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640877")[#strong[#text("palais@uci.edu")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("I think Terence Tao’s suggestion to have regional ICM hosting events to replace the originally scheduled meeting in St. Petersburg is eminently sensible. R. Palais")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2a852d4a66731e509aad1305391f4d87afadb0395dc7ea33337c574a5a481ee2-8b761f482c85fd12d9941c14a814a8a4e65b103775b666bd64a56b6e1087030a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor Porton")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640880")[#strong[#text("Victor Porton")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("The site ")#link("https://icm2022.org/")[#text("https://icm2022.org/")]#text(" does not work: I successfully registered through Yandex, but after some time passed, it became unloadable. I deleted site’s cookies and local storage and after some time it started to work again. Apparently, something is wrong with :Yandex passport”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab0342bf4ef98cd507f0f0d9794413baf71ecf63692086a918c723a15533cfc5-3c3882bd4d59f65e68599fcd6bdee0073300e58b765e562ad44064eb6442607e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeanine")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640883")[#strong[#text("Jeanine")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("Might it be possible to host a large handful of simultaneous, smaller-scale, in-person events at various research institutes (e.g. in Paris) to make this a sort of `collective’ hybrid event, perhaps in tandem with some of the satellite conferences that were due to take place in Russia? This would spread out the strain of having to host on short notice, could be organized around the locations of the invited speakers (or the related satellite conferences), and is distinct from the idea of universities running their own “watch parties” (which seems counter to the spirit of meeting/discussing with colleagues from afar).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640884")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("I think this will be a minority view, but my instinct is that if the ICM is going to be virtual, then it should be regarded not as a poor approximation to an in-person conference but as an opportunity to experiment with online formats and try to improve them. In particular, I hope very much that the talks will not be films of mathematicians at blackboards, but will rather be designed as videos (not necessarily of high sophistication, but made with a video audience in mind). I also don’t see why they should stick to any given timetable. Releasing all the videos at once would probably be a mistake and lead to several of them not being watched very much. But they could be released in groups on the day that they are scheduled to be given.")

#text("Of course, what’s missing from that is one of the main reasons people go to ICMs, which is all the conversation and networking that goes on between talks. It will be very hard to reproduce the serendipitous aspects of that — meeting people one was not expecting to see, and the experience of running into people you know are there but at random moments and in randomish clusters. But that might mean that it is a mistake even to try to reproduce it. Instead, one could try to come up with new ideas to foster interaction. For example, and I stress that this is just one idea of many possibilities, maybe established mathematicians could agree to be present at Zoom meetings at certain scheduled times, and younger mathematicians with interests in common who would like to chat to them could sign up for those meetings (with numbers being limited appropriately — quite how that would work would have to be thought about carefully). Or if one wanted to make it more random and ICM-ish, perhaps there could be something where you just check in whenever you want and see if there’s anyone else around you’d like to talk to. I don’t know about Gathertown — see Kevin O’Bryant’s comment above — but maybe that’s something like what it does.")

#text("I feel very strongly that this opportunity should not be wasted, as the more we can learn to interact without emitting tons of carbon in order to do so, the better.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4e11a7d49fdff39d5cc275ab1120954e83a6f7e6b508329161fb80bd0d7c821-ff9c7350b78e85c3ea0df313cedd34930a4b72e1a4f69efd0ecb138984506eb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zhouhang Mᴀᴏ")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640886")[#strong[#text("Zhouhang Mᴀᴏ")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("By the way, it seems better to find an open-source platform instead of Zoom. I think that, it seems bad that our mathematical community relies officially on a proprietary platform which is controlled by a company.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640888")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("This is a great idea in theory, at least if all of the thousands of participants were onboard with the idea. My experience of a platform like Gathertown is that it works well for small workshop groups of participants, where people are more likely to interact as they know each other already, but not as tractable for larger groups of people who are strangers to each other. Your proposal is an interesting challenge to consider in any case!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f0b9a908987dfdfc75dae02356a635e8ff78f8d3d1ca98913514ae4baf88d46-d00c0befd789903b432aea6071945fa92bf8636b4820e83fbd2e6a03dea15f9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640904")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("For established mathematicians agreeing to be present at certain scheduled times, one way to limit the numbers would be to give each younger mathematician a certain number of “tickets” that they could use to sign up with an event with one of a number of established mathematicians, and then events could be scheduled in a different way depending on the number of signups. Those with a smaller number could be an informal conversation style, while those with the largest number could be more of a webinar where people are called on to ask one question.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/acdbedcc2c4c230b77ec8c8f5e96e0ca51435a172cd7be258776ab6e38e9a926-9a6d35bdd0e9900112c11d69d1046e53f26e0351c36066be062dbfc842308c84.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rosskang")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640915")[#strong[#text("rosskang")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("I agree with this view. Moreover I think it applies more generally to nearly all events in the past two years (and, in truth, even longer back). Using a bit of imagination, there remains significant opportunity for meaningful (and sustainable, open, diverse) changes/rethinking about how we meet/collaborate/communicate.")

#text("See also: ")#link("https://euromathsoc.org/magazine/issues/120/mag-23")[#text("https://euromathsoc.org/magazine/issues/120/mag-23")]#linebreak()#text(" (with apologies: this is a shameless plug)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640926")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2022")])]

#text("This would also allow some underrepresented students or other mathematics enthusiasts to enjoy an opportunity for interacting and / or gaining an exposure.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/606c1617bedf38bab9432654b934068338a745f05e49defd8e90ce7eccbb0913-d256aa4be65e54d2bb9571e65a8b9e277f8206e7a6dcbca3d45922505cc342a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frie")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640885")[#strong[#text("Frie")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("“Speakers can choose to submit recorded talks, or give live talks.” I would choose to submit a recorded talk.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640906")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("It would be nice if each time zone will held its own ICM meetings, where each speakers give live talks in their own timezone, and the recordings can be played in a different timezone later, maybe just a a little bit later, depending on the timezone. It would be done if IMU puts sufficient effort into this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640907")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("I mean IMU can record live talks of speakers in different timezones, then have the recordings ready to play when another timezone starts their meeting. Then participants from a different timezone can have both live speakers, and other recorded speakers, and they can then discuss the talks during the meetings in their own timezones. This could be done if IMU puts sufficient effort into it.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c26a9a60e6ee899435f37b8104eb13055d180cefea3db576872cb09ff22a7f49-02ebb79a9270c0b1c314386b421bf405c9f19a915819acb3307bbcee55f43a18.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Toby Gee")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640889")[#strong[#text("Toby Gee")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("I hope that the organisers will also now consider reinviting people who declined the original invitations because they had reasons why they couldn’t travel to Russia (polticial, covid, or other) – I know of several such cases, and presumably there are more.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640892")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("Toby, I presume they already invited someone else in place of those who originally declined.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8c0f7894170c44ae9772029df563d36c32981d878f959ced043afbd1ffeb2d50-f38fe43db5bec4e9936580cd9330b12b9f86c5f6bdaac5f446487251ef7ef348.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pablo Shmerkin")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640900")[#strong[#text("Pablo Shmerkin")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("Yes but the online format should allow for a somewhat larger number of speakers than originally envisioned.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f563bddef1ea6c900459b818043ae43f59604042e090bc80cd98e994ab2ad2d-855eee57d6ce545af19e1c1d482f30e9f9ca47a674424b7182685751495a71c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of davidmfisher")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640901")[#strong[#text("davidmfisher")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("It is one of the more disappointing aspects of the IMU decision so far that they do not seem to have any plan to take advantage of the flexibility allowed by an online event. their detailed statement really seemed to indicate that they planned to stick to literally the same schedule as the in person event. which surely can’t actually happen in the end.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/84fa272da3d4ae9ceb61576692616d868328378e2b1f37aa9744d5125b61fb2e-88bca344ce0c47027cd2b13624f4b9d0e91c845f3a502143574a2bda91052159.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jamie")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640902")[#strong[#text("Jamie")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("That’s probably why the list of speakers looked significantly weaker than usual.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e80802a9b29e2d8afb40091fda40aa8df6b75be0e2001f8f558716e2c51d8b8-24c3dcd28733d7ab24ffdb1dc6a1ca69593666caf05c9d4abf92636d3b202619.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640914")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("I don’t think that an invitation to speak at ICM should be regarded as being such a high honor anyway. It seems that to some people the honor an invitation is the main thing and the actual talk secondary, which results in a rather varying quality of talks.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a36aff54e2e0a56c390058a7fee0df08758bbacc2d40df76f2f8ec3e71095f23-a41a0a22d3ae663f0e0835a9ec1dfb45e97835a308006af1abce572b8b804e92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of GUILHERME ROCHA DE REZENDE")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640891")[#strong[#text("GUILHERME ROCHA DE REZENDE")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640895")[#strong[#text("Is St. Petersburg a good place for the 2022 Int. Congress of Mathematicians – BBSCODE")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")]

#text("[…] Terry Tao, who is the chair of the ICM Structure Committee, is inviting discussion of how to best use the virtual format on his blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Calvin Khor")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640896")[#strong[#text("Calvin Khor")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("I recall that your zoom classes were nearing capacity at the start. I guess this will be more an issue for ICM. Can zoom support thousands of viewers now? At the same time YouTube is blocked in china.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/febb57a3fd1882252eacc15249efbe457ea680d441226ab77490931728233f45-587aa724f40fcaa1b4f64f7a50562d532ee695f42f078fb49702541d55c53505.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Leinster")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640897")[#strong[#text("Tom Leinster")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("The ")#link("https://sites.google.com/view/bmcbamc2021/home")[#text("2021 British Mathematical Colloquium and British Applied Mathematics Colloquium")]#text(", hosted by the University of Glasgow, ran virtually on the platform Sococo. It had about 1000 participants.")

#text("Sococo is a little bit like Gathertown, but it’s much smoother technologically and, crucially, it’s geared up to large events. I like Gathertown and have used it in my teaching, but its limitations can be frustrating and I don’t think it’s suitable for an event at ICM scale.")

#text("An important factor for the BMC/BAMC was that the Sococo space had very good technical support from mathdept.org. That did cost money (as did the use of Sococo), but I believe the charges were quite modest. There’s probably no way for an event the size of the ICM to run online without significant expenditure anyway.")

#text("I attended the BMC/BAMC, and my impression is that many people were initially sceptical about Sococo but quickly took to it. It’s one of those things that sounds complicated when you explain it in the abstract but is easy and intuitive once you start using it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/febb57a3fd1882252eacc15249efbe457ea680d441226ab77490931728233f45-587aa724f40fcaa1b4f64f7a50562d532ee695f42f078fb49702541d55c53505.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Leinster")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640920")[#strong[#text("Tom Leinster")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2022")])]

#text("I should have said: the event was administered by ")#link("https://www.icms.org.uk/")[#text("ICMS")]#text(" in Edinburgh (with mathdept.org supporting). You could contact Dawn Wasley at ICMS if you wanted to find out more about this option and what it took to administer it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b08e0ccacb6069f79063c6e99ff3d3de8d2e444360930ef25619b1b76ba4cd98-7ffcda38b7d95411863481ab1f2366fabd7d9f07b96c89a157ff8f290805d178.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Harris")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-641099")[#strong[#text("Tom Harris")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2022")])]

#text("+1 for the Sococo platform. I have been to quite a few larger virtual meetings over the past two years and the BMC/BAMC was the one where remote interaction felt most spontaneous and genuine, due in large part to Sococo and the smooth technical support. Perhaps the only downside was that Sococo looks a bit less polished than other virtual meeting platforms (or did last summer), which could put people off.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640908")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("Reblogged this on ")#link("https://scoutmathematics.wordpress.com/2022/02/27/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/")[#text("Aditya Guha Roy's weblog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640909")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("There does not seem to be a way to register for the event.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640912")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2022")])]

#text("Short talks (20 minutes long) can be pre-recorded and collected in a forum, instead of very long and tiring Zoom sessions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liewyee")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640918")[#strong[#text("Liewyee")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2022")])]

#text("Tencent meeting，ZOOM，may help～")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1c94850369df9854cee63abffb44ebd61df7d6aa1088328cfd87456281e5729-e283a0c8b4f7d87e3c717eefce77724e22486b00bdef804d7075cec54bf3f720.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of P Sarada")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640924")[#strong[#text("P Sarada")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2022")])]

#text("I’ve registered my self for the conference I just want to know if I can send any research paper as ot is going to be virtual conference.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dcde5cda5741a0cfe99103d144cba877cf52d4a2f28ebd6d06512d1fed83a254-5e297dbac3ea4c065c724313576dc28e894484e218067296239e94d8ef92f60c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yulia Meshkova")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640930")[#strong[#text("Yulia Meshkova")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2022")])]

#text("0) To make the opportunity to provide ideas more official.")#linebreak()#text(" 1) To ban the attendance of politicians at the opening and closing ceremonies.")#linebreak()#text(" 2) Provide organizers the opportunity to send by post web-cameras and microphones free of charge to invited (or to invited and plenary) speakers if the speakers do not have such stuff. [I saw a lot of sad quality Zoom-videos with really famous mathematicians!] Ask the IT-support to help the speakers with usage of such staff before the talk starts. And to make sure that everything is OK with the light at the speakers rooms.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640931")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2022")])]

#text("Thank you all for the constructive suggestions! This should be valuable input for the various IMU committees that will be involved in planning the now-virtual ICM. My informal feeling is that given the very tight schedule we will be unable to implement any complex format innovations that require a lot of technical experimentation, testing, design, or planning for this year’s congress, but there should be many simple things one can do that can improve the experience and avoid the worst shortcomings of a virtual format.")

#text("I have been informed that ")#link("https://nips.cc/virtual/2021/index.html")[#text("NeurIPS 2021")]#text(" was held in a fully online format and was considered to be fairly successful. I wonder if any participants from that conference could share their experiences of this event, and whether there are any practices from that event that might be worth imitating for the ICM. I would also be interested in hearing about other large conferences that have been successfully held online in recent years.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640950")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2022")])]

#text("I might be wrong but I think the 2021 Abel Prize ceremony was held virtually.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dadc36dd80c639b7b1b6f24cc1b6e4bbde399df2214f36fd9a46e21733de41b-2414e8a7a958b1b8ba04cc1cb9abaa672a44837a4218f3ed539c1d78ad7bb585.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cefpisahai")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640933")[#strong[#text("cefpisahai")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2022")])]

#text("I strongly support having regional in-person meetings for recording ICM videos in front of a live audience of mathematicians, and to enable in-person interaction among regional participants.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f563bddef1ea6c900459b818043ae43f59604042e090bc80cd98e994ab2ad2d-855eee57d6ce545af19e1c1d482f30e9f9ca47a674424b7182685751495a71c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of davidmfisher")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640934")[#strong[#text("davidmfisher")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2022")])]

#text("There seems to be some real momentum in a private chat among speakers for in person events that each cover a subject area or three. So far it seems dynamics may be in Budapest, geometry/topology and maybe algebra in Copenhagen and maybe Lie groups and number theory on a Greek Island. All those are very spur of the moment, but the folks talking about organizing them seem quite serious about it. So I suspect this is evolving towards at least partially hybrid and folks should keep that in mind when discussing innovations for the online aspects.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640937")[#strong[#text("What would a good ICM talk look like? | Persiflage")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2022")]

#text("[…] honestly, it took me a lot of time and didn’t turn out that great. But as Tim Gowers says on Terry’s blog, this should at least be an opportunity for speakers to try […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b18e6983434e8d903efc86c0c8d6f7b89152c3eff11adc1cbd0866c967ba4752-13f48faf46b66fa0f46f4673984e837c54a5f17849b831b7b97f014b14833848.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tame Manifold")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640938")[#strong[#text("Tame Manifold")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2022")])]

#text("I would like to make a suggestion-recommendation that the ICM be held in the following locations:")

#text("1)Tel Aviv")

#text("or")

#text("2)London")

#text("3)Washington DC")

#text("Under the circumstances, I see no reason why any of these Cities can’t hold the 2022 ICM.")

#text("Peace")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640949")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2022")])]

#text("Hosting the IMC takes a lot of arrangements to be made. All this while these things were in preparation at St. Petersburg. Certainly the remaining duration is not sufficient to reproduce all the arrangements in these cities.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b192a4690de1a3e7c3a785a32eb6969584cc2e4e0a980b8f5c813072ece404b-97da0c5b462e1e5a01c08fb7d02bcad134557f46234776399c7a31631d39f240.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Melissa Tacy")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640947")[#strong[#text("Melissa Tacy")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2022")])]

#text("More general commentary from the perspective of an unusual timezone (New Zealand). While I realise the decision on time zone has already been made for ICM I would advocate not using a set time zone but spread the sessions (and the pain of inconvenient timing) around.")

#text("Otherwise record sessions and make them available immediately so those who cannot watch the live session can follow as closely as possible. Have discussion boards or some way to ask questions outside of the sessions. Combining these two allows participants who are in bad timezones to gather, say the next day, catch up and interact directly with the speakers. Videos that are available a week or so later break the feeling of being part of the conference and it often feels pointless to email and ask a question after a long period of time.")

#text("I’ve been to some conferences that have used pre-recorded talks to good effect. The live sessions were then more a Q&A. This might be harder to achieve with large scale sessions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b83a5bcd3cfbd3197517da804244ff1c4efe35c179a7afda416081442e5d2973-3d292328ef8dbf5c4dd00be2dc2cb8138d906bf6a45bac2ee55375992bfe5a70.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xi'an")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640953")[#strong[#text("xi'an")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2022")])]

#text("When the ISBA (International Society for Bayesian Analysis) 2021 turned ")#link("https://events.stat.uconn.edu/ISBA2021/")[#text("virtual (and free)")]#text(", I contacted the Centre International de Rencontres Mathématiques (CIRM, Marseille) to hold a ")#link("https://www.cirm-math.fr/Schedule/screen_display.php?id_renc=2701")[#text("mirror meeting")]#text(" there and they agreed to hold it as their first post-lockdown workshop. Under sanitary restrictions on the audience size and distanciation. Between 70 and 80 nearby statisticians (from Austria, Italy, and France) gathered there in a cathartic reunion that made the best of the hybrid format. And of the different time zone. I am thus supporting very much the idea of holding mirror meetings for all large conferences.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640962")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2022")])]

#text("What is a “mirror meeting”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b83a5bcd3cfbd3197517da804244ff1c4efe35c179a7afda416081442e5d2973-3d292328ef8dbf5c4dd00be2dc2cb8138d906bf6a45bac2ee55375992bfe5a70.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xi'an")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640963")[#strong[#text("xi'an")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2022")])]

#text("A mirror meeting is a secondary in-person gathering of participants to a virtual or hybrid or in-person conference towards recreating some of the positive features of in-person meetings. Like discussions of on-going talks, poster presentations, initiating collaborations, mentoring junior participants, &tc. They can be organised very cheaply at the local, regional or national levels. Even outside pandemics or tragedies, they allow a wider audience to take some part in meetings they could not otherwise attend. They should be encouraged by all academic societies.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liewyee")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640955")[#strong[#text("Liewyee")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2022")])]

#text("as something in details，some warm-up musics may be added before every half-day-speeches. and the conference poster with some vital imformation，such as the QR code with the conference address imformation， may become an important item，which I could help to make it cuz I am actually a half-art-designer ：-）")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liewyee")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640972")[#strong[#text("Liewyee")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2022")])]

#text("in addition，the Network Server should be maintained well during the conference- related-software running in the front，in case of accident occuring~")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/654860f7ab3bccdacdd1edf4ed9ca7a452824bc33757d21bd183dd0012aafae1-bef87085757bcf462a3a59c721d677df37b119c3fd1e9113e67b868e9183be0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edgawliet")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640975")[#strong[#text("Edgawliet")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2022")])]

#text("Is still possible to register and attend? If so, where?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-641025")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2022")])]

#text("Further information about the virtual ICM will be released by the IMU in the near future, but several basic logistical details are currently being worked out.")

#text("I am in the process of generating a (currently unofficial) discussion group in which to coordinate proposed satellite events to the virtual congress, such as watch parties, mirror conferences, online chats, or sectional overlay conferences. If you are interested in proposing, hosting, or sponsoring such an event, let me know. (Once the IMU releases more details on the event my committee will be able to make a more official call for such events.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13adaff32d54f3bdf4caf53abe3d7d7661f47307b45be7dfe4a21eeb122bc96c-30478c564e1d0b5eb16035de2a3eae50d90ef7462ef80bb9d6ab9ae482bb19a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Radu Zaharopol")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640984")[#strong[#text("Radu Zaharopol")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2022")])]

#text("Dear Professor Tao,")

#text("Thank you for your “What’s new” post of February 26.")

#text("I would like to participate at ICM 2022.")

#text("How do I register for the ICM?")

#text("Sincerely yours, Radu Zaharopol")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liewyee")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-640987")[#strong[#text("Liewyee")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2022")])]

#text("the same question to the above comment~")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bff3d7fb0c1387cd2764223041b59abcf89d99969fa5f5c8d0632c8d2f0ea68f-58ad703d8daf1c53ffd21ab58da5148d17aebf28b20af0a5048ca711b6515e76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jesus Martinez Garcia")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-641052")[#strong[#text("Jesus Martinez Garcia")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2022")])]

#text("I am a co-organiser of the online Zoom Algebraic Geometry Seminar (ZAG Seminar) which has been running twice a week since March 2020. Our attendance has ranked from 20-400 with over 1500 subscribed to the mailing list. I am not sure how we could be of help, but if we can, please feel free to write to us to zagseminar (AT) gmail.com or jesus.martinez-garcia (AT) essex.ac.uk")

#text("Given the publicity of the event, I can only imagine that a big issue would be to avoid “Zoombombing”. Save for one recent incident we have been spared it. A way to solve this is to run all sessions as webinars (definitely advisable for plenary sessions) where participants cannot intervene. I am not sure if this is such a good idea for the subject-specific sessions as it would difficult discussion (on the other hand with the event being virtual, it is quite likely these sessions are closer to ‘webinar size’ than to face-to-face size).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-641081")[#strong[#text("El ICM 2022 no se celebrará en San Petersburgo – Real Sociedad Matemática Española")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2022")]

#text("[…] El matemático Terence Tao, que es chair del ICM Structure Committee, está recabando de modo oficioso opiniones sobre cómo aprovechar al máximo la celebración del próximo ICM de manera virtual en su blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-641082")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2022")])]

#text("Three suggestions:")

#text("1) A proposal from an earlier thread could be even more relevant now: perhaps we can give speakers of all types (except, of course the prize winners) an opportunity to post a 5-15 minute introductory video that will be posted around May-June 2022 in the ICM site.")

#text("(See ")#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512332")[#text("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512332")]#text(" .)")

#text("As a matter of fact, we can extend this idea to people who present contributed talks/posters and to lecturers in satellite conferences, and to all other participants who may be interested.")

#text("Let me note that the ICM 2022 website (which was excellent but is currently off the air) already had a lot of useful information about speakers, various interviews, and other related matters.")

#text("2) A variant of the proposals made here would be to have regional “ICM” meetings 3-4 weeks before the ICM itself which will allow the speakers to either videotape their lecture in front of a live audience or just practice their lecture. For those who submit a videotaped lecture this would also allow to have the videotaped edited to make the recorded product of better quality. (I must admit though that when I raised this idea here, people were not enthusiastic about it.)")

#text("3) Regarding the talks themselves, probably the preference would be for presentations (beamer, powerpoints) rather than blackboard talks (this was mandatory in ICM 2018) but an exception could be made for good quality videotaped lectures by gifted blackboard speakers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-641097")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2022")])]

#text("Regarding point (2), I know of several efforts underway to create such ICM satellite events, either focused on a single section of the ICM or a single geographical area. If anyone is interested in organizing a further such effort, feel free to ask to join the discussion group on satellite events at ")#link("https://groups.google.com/g/icm-satellite-event-coordination-group")[#text("https://groups.google.com/g/icm-satellite-event-coordination-group")]

#text("For point (1), this is an interesting idea, but given the limited time and resources of the IMU I believe it is extremely unlikely that such a proposal can be added to the “official” ICM in time for the congress. However if some external group is willing to set up an *unofficial* site to host such videos and has the support of a fair number of the invited ICM speakers then I would believe (though I cannot guarantee) that the IMU would be willing to condone this and perhaps even designate this effort as a (highly nonstandard) type of “satellite conference”. Again, if there are people interested in organizing such an effort, please feel free to join the above discussion group.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-641163")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2022")])]

#text("I think the ICM should take advantage of the fact that the virtual world has an infinite amount of lecture hall space. This means that the traditional time constraint imposed on each speaker by the schedule is, in some sense, “just a number”.")

#text("In particular, there seems to be no reason why interested speakers could not schedule extra online sessions (which need not an official part of ICM) after their talk in which they can address extended questions or even continue their lectures if there is popular interest. Such bonus episodes could in principle be done immediately after the official talk, although it seems wiser to schedule it at a different hour to avoid conflicts with other talks the audience may wish to attend.")

#text("On a related note, I have another suggestion about the technical organization. Whatever online software is used for ICM, I would recommend making a separate “zoom room” for each speaker, rather than scheduling multiple talks at different times in the same room. The latter plan would only invite artificial constraints from real life such as speakers being cut off by the schedule before having a chance to finish their remarks or answer questions. There’s no reason we should subject ourselves to these unnecessary logistical issues in the virtual world.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 2022 ICM satellite coordination group | What's new")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-641350")[#strong[#text("2022 ICM satellite coordination group | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2022")])]

#text("[…] The IMU has just released some updates on the status of the 2022 International Congress of Mathematicians, which was discussed in this previous post: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Short communication satellite event for the 2022 virtual ICM | What's new")]], [#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-641726")[#strong[#text("Short communication satellite event for the 2022 virtual ICM | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2022")])]

#text("[…] ICM Discord. Perhaps some of the other proposed online experiments for virtual events discussed in this previous post could also be implemented experimentally on this satellite event to demonstrate […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/#comment-642763")[#strong[#text("Ligação |")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2022")]

#text("[…] Internacional de Matemáticos será totalmente virtual e hospedado fora da Rússia ((mathbb{M}), através da, Veja também), substituindo a reunião presencial agendada para São Petersburgo. Este passo foi […]")
]
