// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/
// Converted to Typst by tao2typ: "2026-10-14T10:22:41.885218+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 2: Complex-analytic multiplicative number theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 2: Complex-analytic multiplicative number theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 December 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(", we approached ")#link("http://en.wikipedia.org/wiki/Multiplicative_number_theory")[#text("multiplicative number theory")]#text(" (the study of multiplicative functions ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" and their relatives) via elementary methods, in which attention was primarily focused on obtaining asymptotic control on summatory functions ")#mi("{\\sum_{n \\leq x} f(n)}")#text(" and logarithmic sums ")#mi("{\\sum_{n \\leq x} \\frac{f(n)}{n}}")#text(". Now we turn to the complex approach to multiplicative number theory, in which the focus is instead on obtaining various types of control on the ")#link("http://en.wikipedia.org/wiki/Dirichlet_series")[#text("Dirichlet series")]#text(" ")#mi("{{\\mathcal D} f}")#text(", defined (at least for ")#mi("{s}")#text(" of sufficiently large real part) by the formula")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D} f(s) := \\sum_n \\frac{f(n)}{n^s}.")]]

#text("These series also made an appearance in the elementary approach to the subject, but only for real ")#mi("{s}")#text(" that were larger than ")#mi("{1}")#text(". But now we will exploit the freedom to extend the variable ")#mi("{s}")#text(" to the complex domain; this gives enough freedom (in principle, at least) to recover control of elementary sums such as ")#mi("{\\sum_{n\\leq x} f(n)}")#text(" or ")#mi("{\\sum_{n\\leq x} \\frac{f(n)}{n}}")#text(" from control on the Dirichlet series. Crucially, for many key functions ")#mi("{f}")#text(" of number-theoretic interest, the Dirichlet series ")#mi("{{\\mathcal D} f}")#text(" can be analytically (or at least meromorphically) continued to the left of the line ")#mi("{\\{ s: \\text{Re}(s) = 1 \\}}")#text(". The zeroes and poles of the resulting meromorphic continuations of ")#mi("{{\\mathcal D} f}")#text(" (and of related functions) then turn out to control the asymptotic behaviour of the elementary sums of ")#mi("{f}")#text("; the more one knows about the former, the more one knows about the latter. In particular, knowledge of where the zeroes of the ")#link("http://en.wikipedia.org/wiki/Riemann_zeta_function")[#text("Riemann zeta function")]#text(" ")#mi("{\\zeta}")#text(" are located can give very precise information about the distribution of the primes, by means of a fundamental relationship known as the ")#link("http://en.wikipedia.org/wiki/Explicit_formulae_(L-function)")[#text("explicit formula")]#text(". There are many ways of phrasing this explicit formula (both in exact and in approximate forms), but they are all trying to formalise an approximation to the von Mangoldt function ")#mi("{\\Lambda}")#text(" (and hence to the primes) of the form ")#metadata(none) <tao-f9815867b5c6572a9404>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\Lambda(n) \\approx 1 - \\sum_\\rho n^{\\rho-1}")]]

#text(" where the sum is over zeroes ")#mi("{\\rho}")#text(" (counting multiplicity) of the Riemann zeta function ")#mi("{\\zeta = {\\mathcal D} 1}")#text(" (with the sum often restricted so that ")#mi("{\\rho}")#text(" has large real part and bounded imaginary part), and the approximation is in a suitable ")#link("http://en.wikipedia.org/wiki/Weak_topology")[#text("weak")]#text(" sense, so that ")#metadata(none) <tao-c9aec453151b23c8fe20>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_n \\Lambda(n) g(n) \\approx \\int_0^\\infty g(y)\\ dy - \\sum_\\rho \\int_0^\\infty g(y) y^{\\rho-1}\\ dy")]]

#text(" for suitable “test functions” ")#mi("{g}")#text(" (which in practice are restricted to be fairly smooth and slowly varying, with the precise amount of restriction dependent on the amount of truncation in the sum over zeroes one wishes to take). Among other things, such approximations can be used to rigorously establish the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(" ")#metadata(none) <tao-a160524700113ddd3205>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{n \\leq x} \\Lambda(n) = x + o(x)")]]

#text(" as ")#mi("{x \\rightarrow \\infty}")#text(", with the size of the error term ")#mi("{o(x)}")#text(" closely tied to the location of the zeroes ")#mi("{\\rho}")#text(" of the Riemann zeta function.")#linebreak()#text(" The explicit formula ")#link(<tao-f9815867b5c6572a9404>)[#text("(1)")]#text(" (or any of its more rigorous forms) is closely tied to the counterpart approximation ")#metadata(none) <tao-ef7ec7068fca7e7e1de8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("-\\frac{\\zeta^{\\prime}}{\\zeta}(s) \\approx \\frac{1}{s-1} - \\sum_\\rho \\frac{1}{s-\\rho}")]]

#linebreak()#text(" for the Dirichlet series ")#mi("{{\\mathcal D} \\Lambda = -\\frac{\\zeta^{\\prime}}{\\zeta}}")#text(" of the von Mangoldt function; note that ")#link(<tao-ef7ec7068fca7e7e1de8>)[#text("(4)")]#text(" is formally the special case of ")#link(<tao-c9aec453151b23c8fe20>)[#text("(2)")]#text(" when ")#mi("{g(n) = n^{-s}}")#text(". Such approximations come from the general theory of local factorisations of meromorphic functions, as discussed in ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text("; the passage from ")#link(<tao-ef7ec7068fca7e7e1de8>)[#text("(4)")]#text(" to ")#link(<tao-c9aec453151b23c8fe20>)[#text("(2)")]#text(" is accomplished by such tools as the residue theorem and the Fourier inversion formula, which were also covered in Supplement 2. The relative ease of uncovering the Fourier-like duality between primes and zeroes (sometimes referred to poetically as the “music of the primes”) is one of the major advantages of the complex-analytic approach to multiplicative number theory; this important duality tends to be rather obscured in the other approaches to the subject, although it can still in principle be discernible with sufficient effort.")#linebreak()#text(" More generally, one has an explicit formula ")#metadata(none) <tao-72554af938a392166526>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\Lambda(n) \\chi(n) \\approx - \\sum_\\rho n^{\\rho-1}")]]

#linebreak()#text(" for any (non-principal) ")#link("http://en.wikipedia.org/wiki/Dirichlet_character")[#text("Dirichlet character")]#text(" ")#mi("{\\chi}")#text(", where ")#mi("{\\rho}")#text(" now ranges over the zeroes of the associated ")#link("http://en.wikipedia.org/wiki/Dirichlet_L-function")[#text("Dirichlet ")#mi("{L}")#text("-function")]#text(" ")#mi("{L(s,\\chi) := {\\mathcal D} \\chi(s)}")#text("; we view this formula as a “twist” of ")#link(<tao-f9815867b5c6572a9404>)[#text("(1)")]#text(" by the Dirichlet character ")#mi("{\\chi}")#text(". The explicit formula ")#link(<tao-72554af938a392166526>)[#text("(5)")]#text(", proven similarly (in any of its rigorous forms) to ")#link(<tao-f9815867b5c6572a9404>)[#text("(1)")]#text(", is important in establishing the prime number theorem in arithmetic progressions, which asserts that ")#metadata(none) <tao-f8aa8da49a63fe52335c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{n \\leq x: n = a\\ (q)} \\Lambda(n) = \\frac{x}{\\phi(q)} + o(x)")]]

#text(" as ")#mi("{x \\rightarrow \\infty}")#text(", whenever ")#mi("{a\\ (q)}")#text(" is a fixed primitive residue class. Again, the size of the error term ")#mi("{o(x)}")#text(" here is closely tied to the location of the zeroes of the Dirichlet ")#mi("{L}")#text("-function, with particular importance given to whether there is a zero very close to ")#mi("{s=1}")#text(" (such a zero is known as an ")#emph[#text("exceptional zero")]#text(" or ")#link("http://en.wikipedia.org/wiki/Siegel_zero")[#text("Siegel zero")]#text(").")#linebreak()#text(" While any information on the behaviour of zeta functions or ")#mi("{L}")#text("-functions is in principle welcome for the purposes of analytic number theory, some regions of the complex plane are more important than others in this regard, due to the differing weights assigned to each zero in the explicit formula. Roughly speaking, in descending order of importance, the most crucial regions on which knowledge of these functions is useful are")

#enum(start: 1, 
[#text("The region on or near the point ")#mi("{s=1}")#text(".")],
[#text("The region on or near the right edge ")#mi("{\\{ 1+it: t \\in {\\bf R} \\}}")#text(" of the ")#emph[#text("critical strip")]#text(" ")#mi("{\\{ s: 0 \\leq \\text{Re}(s) \\leq 1 \\}}")#text(".")],
[#text("The right half ")#mi("{\\{ s: \\frac{1}{2} < \\text{Re}(s) < 1 \\}}")#text(" of the critical strip.")],
[#text("The region on or near the ")#emph[#text("critical line")]#text(" ")#mi("{\\{ \\frac{1}{2} + it: t \\in {\\bf R} \\}}")#text(" that bisects the critical strip.")],
[#text("Everywhere else.")]
)

#text("For instance:")

#enum(start: 1, 
[#text("We will shortly show that the Riemann zeta function ")#mi("{\\zeta}")#text(" has a simple pole at ")#mi("{s=1}")#text(" with residue ")#mi("{1}")#text(", which is already sufficient to recover much of the classical ")#link("http://en.wikipedia.org/wiki/Mertens%27_theorems")[#text("theorems of Mertens")]#text(" discussed in the previous set of notes, as well as results on mean values of multiplicative functions such as the ")#link("http://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]#text(" ")#mi("{\\tau}")#text(". For Dirichlet ")#mi("{L}")#text("-functions, the behaviour is instead controlled by the quantity ")#mi("{L(1,\\chi)}")#text(" discussed in ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(", which is in turn closely tied to the existence and location of a ")#link("http://en.wikipedia.org/wiki/Siegel_zero")[#text("Siegel zero")]#text(".")],
[#text("The zeta function is also known to have no zeroes on the right edge ")#mi("{\\{1+it: t \\in {\\bf R}\\}}")#text(" of the critical strip, which is sufficient to prove (and is in fact equivalent to) the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(". Any enlargement of the zero-free region for ")#mi("{\\zeta}")#text(" into the critical strip leads to improved error terms in that theorem, with larger zero-free regions leading to stronger error estimates. Similarly for ")#mi("{L}")#text("-functions and the prime number theorem in arithmetic progressions.")],
[#text("The (as yet unproven) ")#link("http://en.wikipedia.org/wiki/Riemann_hypothesis")[#text("Riemann hypothesis")]#text(" prohibits ")#mi("{\\zeta}")#text(" from having any zeroes within the right half ")#mi("{\\{ s: \\frac{1}{2} < \\text{Re}(s) < 1 \\}}")#text(" of the critical strip, and gives very good control on the number of primes in intervals, even when the intervals are relatively short compared to the size of the entries. Even without assuming the Riemann hypothesis, ")#emph[#text("zero density estimates")]#text(" in this region are available that give some partial control of this form. Similarly for ")#mi("{L}")#text("-functions, primes in short arithmetic progressions, and the ")#link("http://en.wikipedia.org/wiki/Generalized_Riemann_hypothesis")[#text("generalised Riemann hypothesis")]#text(".")],
[#text("Assuming the Riemann hypothesis, further distributional information about the zeroes on the critical line (such as ")#link("http://en.wikipedia.org/wiki/Montgomery%27s_pair_correlation_conjecture")[#text("Montgomery’s pair correlation conjecture")]#text(", or the more general ")#emph[#text("GUE hypothesis")]#text(") can give finer information about the error terms in the prime number theorem in short intervals, as well as other arithmetic information. Again, one has analogues for ")#mi("{L}")#text("-functions and primes in short arithmetic progressions.")],
[#text("The ")#link("http://en.wikipedia.org/wiki/Riemann_zeta_function#The_functional_equation")[#text("functional equation")]#text(" of the zeta function describes the behaviour of ")#mi("{\\zeta}")#text(" to the left of the critical line, in terms of the behaviour to the right of the critical line. This is useful for building a “global” picture of the structure of the zeta function, and for improving a number of estimates about that function, but (in the absence of unproven conjectures such as the Riemann hypothesis or the pair correlation conjecture) it turns out that many of the basic analytic number theory results using the zeta function can be established without relying on this equation. Similarly for ")#mi("{L}")#text("-functions.")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" ")#metadata(none) <tao-10c2d630409d5a4b8132>#text(" If one takes an “")#link("http://en.wikipedia.org/wiki/Adele_ring")[#text("adelic")]#text("” viewpoint, one can unite the Riemann zeta function ")#mi("{\\zeta(\\sigma+it) = \\sum_n n^{-\\sigma-it}}")#text(" and all of the ")#mi("{L}")#text("-functions ")#mi("{L(\\sigma+it,\\chi) = \\sum_n \\chi(n) n^{-\\sigma-it}}")#text(" for various Dirichlet characters ")#mi("{\\chi}")#text(" into a single object, viewing ")#mi("{n \\mapsto \\chi(n) n^{-it}}")#text(" as a general multiplicative character on the adeles; thus the imaginary coordinate ")#mi("{t}")#text(" and the Dirichlet character ")#mi("{\\chi}")#text(" are really the ")#link("http://en.wikipedia.org/wiki/Archimedean_property")[#text("Archimedean")]#text(" and non-Archimedean components respectively of a single adelic frequency parameter. This viewpoint was famously developed in ")#link("http://en.wikipedia.org/wiki/Tate%27s_thesis")[#text("Tate’s thesis")]#text(", which among other things helps to clarify the nature of the functional equation, as discussed in ")#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/")[#text("this previous post")]#text(". We will not pursue the adelic viewpoint further in these notes, but it does supply a “high-level” explanation for why so much of the theory of the Riemann zeta function extends to the Dirichlet ")#mi("{L}")#text("-functions. (The non-Archimedean character ")#mi("{\\chi(n)}")#text(" and the Archimedean character ")#mi("{n^{it}}")#text(" behave similarly from an algebraic point of view, but not so much from an analytic point of view; as such, the adelic viewpoint is well suited for algebraic tasks (such as establishing the functional equation), but not for analytic tasks (such as establishing a zero-free region).)")
]

#text("Roughly speaking, the elementary multiplicative number theory from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(" corresponds to the information one can extract from the complex-analytic method in region 1 of the above hierarchy, while the more advanced elementary number theory used to prove the prime number theorem (and which we will not cover in full detail in these notes) corresponds to what one can extract from regions 1 and 2.")

#text("As a consequence of this hierarchy of importance, information about the ")#mi("{\\zeta}")#text(" function away from the critical strip, such as Euler’s identity")

#align(center)[#tao-fit-display[#mitex("\\zeta(2) = \\frac{\\pi^2}{6}")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("1 + \\frac{1}{2^2} + \\frac{1}{3^2} + \\dots = \\frac{\\pi^2}{6}")]]

#text("or the infamous identity")

#align(center)[#tao-fit-display[#mitex("\\zeta(-1) = -\\frac{1}{12},")]]

#text("which is often presented (slightly misleadingly, if one’s conventions for divergent summation are not made explicit) as")

#align(center)[#tao-fit-display[#mitex("1 + 2 + 3 + \\dots = -\\frac{1}{12},")]]

#text("are of relatively little direct importance in analytic prime number theory, although they are still of interest for some other, non-number-theoretic, applications. (The quantity ")#mi("{\\zeta(2)}")#text(" does play a minor role as a normalising factor in some asymptotics, see e.g. Exercise 28 from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(", but its precise value is usually not of major importance.) In contrast, the value ")#mi("{L(1,\\chi)}")#text(" of an ")#mi("{L}")#text("-function at ")#mi("{s=1}")#text(" turns out to be extremely important in analytic number theory, with many results in this subject relying ultimately on a non-trivial lower-bound on this quantity coming from ")#link("http://en.wikipedia.org/wiki/Siegel_zero")[#text("Siegel’s theorem")]#text(", discussed below the fold.")#linebreak()#text(" For a more in-depth treatment of the topics in this set of notes, see Davenport’s “")#link("http://www.ams.org/mathscinet-getitem?mr=1790423")[#text("Multiplicative number theory")]#text("“.")

#metadata(none) <tao-63e0d70a533e9620dc22>

#heading(level: 1)[#strong[#text(" — 1. Dirichlet series to the right of the critical strip — ")]]

#text("We begin with the (easy) theory of Dirichlet series to the right of the critical strip ")#mi("{\\{ s: 0 \\leq \\text{Re}(s) \\leq 1 \\}}")#text(", which generalises the theory of Dirichlet series for real ")#mi("{s>1}")#text(" that was used in the ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("previous set of notes")]#text(".")

#text("Given any arithmetic function ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" obeying the crude size bound ")#metadata(none) <tao-462208124b6ea2056647>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("f(n) = O(n^{o(1)}),")]]

#linebreak()#text(" the Dirichlet series ")#metadata(none) <tao-8bd574fdb05c2dc50171>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("{\\mathcal D} f(s) := \\sum_n \\frac{f(n)}{n^s}")]]

#text(" is absolutely convergent in the region ")#mi("{\\{ s: \\text{Re}(s) > 1 \\}}")#text(" to the right of the critical strip. Indeed, if ")#mi("{s = \\sigma+it}")#text(" for some ")#mi("{\\sigma>1}")#text(", then we have")

#align(center)[#tao-fit-display[#mitex("\\frac{f(n)}{n^s} = O_\\varepsilon( \\frac{1}{n^{\\sigma-\\varepsilon}})")]]

#text("for any ")#mi("{\\varepsilon>0}")#text(", and the claim follows by choosing ")#mi("{\\varepsilon}")#text(" so that ")#mi("{\\sigma-\\varepsilon > 1}")#text(". Note that this argument also shows that ")#mi("{{\\mathcal D}f}")#text(" is bounded in any region of the form ")#mi("{\\{ s: \\text{Re}(s) \\ge 1+\\varepsilon \\}}")#text(" for any ")#mi("{\\varepsilon > 0}")#text(".")#linebreak()#text(" The partial sums ")#mi("{\\sum_{n=1}^N \\frac{f(n)}{n^s} = \\sum_{n=1}^N f(n) \\exp( - s \\log n )}")#text(" are clearly holomorphic functions in ")#mi("{s}")#text(" on the entire complex plane ")#mi("{{\\bf C}}")#text(", and they converge locally uniformly to ")#mi("{{\\mathcal D} f(s)}")#text(" on the region ")#mi("{\\{ s: \\text{Re}(s) > 1 \\}}")#text(". Since locally uniform limits of holomorphic functions are holomorphic (Corollary 11 of ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text("), we conclude that ")#mi("{{\\mathcal D} f}")#text(" is holomorphic on ")#mi("{\\{ s: \\text{Re}(s) > 1 \\}}")#text(".")

#text("If ")#mi("{f, g: {\\bf N} \\rightarrow {\\bf C}}")#text(" obey the crude size bound ")#link(<tao-462208124b6ea2056647>)[#text("(7)")]#text(", then so does the Dirichlet convolution ")#mi("{f*g}")#text(" (see Exercise 24 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text("). A simple application of Fubini’s theorem then gives the fundamental identity ")#metadata(none) <tao-16ba121a04d5ad3b885f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("{\\mathcal D}(f*g)(s) = {\\mathcal D} f(s) {\\mathcal D} g(s)")]]

#linebreak()#text(" in the region ")#mi("{\\{s: \\text{Re}(s) > 1 \\}}")#text(". Also, by carefully differentiating ")#link(<tao-8bd574fdb05c2dc50171>)[#text("(8)")]#text(" in ")#mi("{s}")#text(" we obtain the additional identity ")#metadata(none) <tao-0e6ba33f8bc8f41515b9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("{\\mathcal D}(Lf)(s) = -\\frac{d}{ds} {\\mathcal D} f(s)")]]

#text(" in the same region, where ")#mi("{L: {\\bf N} \\rightarrow {\\bf C}}")#text(" is the logarithm function ")#mi("{L(n) = \\log n}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Rigorously establish ")#link(<tao-16ba121a04d5ad3b885f>)[#text("(9)")]#text(" and ")#link(<tao-0e6ba33f8bc8f41515b9>)[#text("(10)")]#text(".")
]

#text("From ")#link(<tao-16ba121a04d5ad3b885f>)[#text("(9)")]#text(", ")#link(<tao-0e6ba33f8bc8f41515b9>)[#text("(10)")]#text(" we can express the Dirichlet series of many basic arithmetic functions of number-theoretic interest in terms of the Riemann zeta function, at least in the region ")#mi("{\\{ s: \\text{Re}(s) > 1\\}}")#text(":")

#list(
[#text("By definition, ")#mi("{{\\mathcal D}(1) = \\zeta}")#text(". Since ")#mi("{1*1 = \\tau}")#text(", we conclude from ")#link(<tao-16ba121a04d5ad3b885f>)[#text("(9)")]#text(" that ")#mi("{{\\mathcal D}(\\tau) = \\zeta^2}")#text(".")],
[#text("Clearly ")#mi("{{\\mathcal D}(\\delta)=1}")#text(". By ")#link(<tao-16ba121a04d5ad3b885f>)[#text("(9)")]#text(" and the Möbius inversion formula ")#mi("{1 * \\mu = \\delta}")#text(", we conclude that ")#mi("{{\\mathcal D}(\\mu) = \\frac{1}{\\zeta}}")#text(". (In particular, ")#mi("{\\zeta}")#text(" has no zeroes in the region ")#mi("{\\{ s: \\text{Re}(s) > 1 \\}}")#text(".)")],
[#text("From ")#link(<tao-0e6ba33f8bc8f41515b9>)[#text("(10)")]#text(", we have ")#mi("{{\\mathcal D}(L) = -\\zeta^{\\prime}}")#text(". By ")#link(<tao-16ba121a04d5ad3b885f>)[#text("(9)")]#text(" and the basic identity ")#mi("{1 * \\Lambda = L}")#text(", we conclude that ")#mi("{{\\mathcal D}(\\Lambda) = -\\frac{\\zeta^{\\prime}}{\\zeta}}")#text(".")],
[#text("From ")#link(<tao-0e6ba33f8bc8f41515b9>)[#text("(10)")]#text(", we see that ")#mi("{{\\mathcal D}(\\frac{\\Lambda}{L})}")#text(" has a derivative of ")#mi("{\\frac{\\zeta^{\\prime}}{\\zeta}}")#text(". For real ")#mi("{s>1}")#text(", we already saw (see equation (21) of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(") that this expression was equal to ")#mi("{\\log \\zeta}")#text(". Thus we see that ")#mi("{{\\mathcal D}(\\frac{\\Lambda}{L})}")#text(" is a branch of the complex logarithm of ")#mi("{\\zeta}")#text(" to the right of the strip, so we write (by slight abuse of notation) ")#mi("{{\\mathcal D}(\\frac{\\Lambda}{L}) = \\log \\zeta}")#text(" in this region.")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]

#list(
[#text("(i) Show that ")#mi("{{\\mathcal D}(\\mu^2)(s) = \\frac{\\zeta(s)}{\\zeta(2s)}}")#text(" in the region ")#mi("{\\{ s: \\text{Re}(s) > 1 \\}}")#text(".")],
[#text("(ii) Define the ")#link("http://en.wikipedia.org/wiki/Liouville_function")[#text("Liouville function")]#text(" ")#mi("{\\lambda: {\\bf N} \\rightarrow {\\bf C}}")#text(" by setting ")#mi("{\\lambda(n) := (-1)^k}")#text(" whenever ")#mi("{n}")#text(" is the product of ")#mi("{k}")#text(" (not necessarily distinct) primes for some ")#mi("{k \\geq 0}")#text(". Show that ")#mi("{{\\mathcal D}(\\lambda) = \\frac{\\zeta(2s)}{\\zeta(s)}}")#text(" in the region ")#mi("{\\{ s: \\text{Re}(s) > 1 \\}}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Let ")#mi("{\\Lambda_k}")#text(" be the higher order von Mangoldt functions (equation (65) from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text("). Show that ")#mi("{{\\mathcal D}(\\Lambda_k) = (-1)^k \\frac{\\zeta^{(k)}}{\\zeta}}")#text(" in the region ")#mi("{\\{ s: \\text{Re}(s) > 1 \\}}")#text(", where ")#mi("{\\zeta^{(k)}}")#text(" is the ")#mi("{k}")#text("-fold derivative of ")#mi("{\\zeta}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5 (Uniqueness for Dirichlet series)")]

#list(
[#text("(i) Let ")#mi("{f, g}")#text(" be two arithmetic functions obeying ")#link(<tao-462208124b6ea2056647>)[#text("(7)")]#text(", such that ")#mi("{{\\mathcal D} f = {\\mathcal D} g}")#text(" on the region ")#mi("{\\{ s: \\text{Re}(s) > 1 \\}}")#text(". Show that ")#mi("{f=g}")#text(". (")#emph[#text("Hint:")]#text(" if ")#mi("{f \\neq g}")#text(", obtain an asymptotic for ")#mi("{{\\mathcal D} f(s) - {\\mathcal D} g(s)}")#text(" as ")#mi("{s \\rightarrow +\\infty}")#text(" along the reals.)")],
[#text("(ii) Use this uniqueness to give an alternate proof of the identity ")#mi("{\\Lambda_{k+1} = L \\Lambda_k + \\Lambda_k * \\Lambda}")#text(" for ")#mi("{k \\geq 1}")#text(" (equation (66) from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(").")],
[#text("(iii) Use this uniqueness to give an alternate proof of the Diamond-Steinig identities (Exercise 64 from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(").")]
)
]

#text("Now we establish some crude bounds on Dirichlet series in the region ")#mi("{\\{ s: \\text{Re}(s) > 1 \\}}")#text(". We will use the following simple application of the triangle inequality: if ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" and ")#mi("{g: {\\bf N} \\rightarrow {\\bf R}^+}")#text(" are arithmetic functions obeying ")#link(<tao-462208124b6ea2056647>)[#text("(7)")]#text(" with ")#tao-math("{\\left|f(n)\\right| \\leq g(n)}", block: false)#text(" for all ")#mi("{n}")#text(", and ")#mi("{s = \\sigma+it}")#text(" for some ")#mi("{\\sigma>1}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left| \\frac{f(n)}{n^s}\\right| \\leq \\frac{g(n)}{n^\\sigma}", block: true)]]

#text("for all ")#mi("{n}")#text(", and hence")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\mathcal D} f(s)\\right| \\leq {\\mathcal D} g(\\sigma).", block: true)]]

#text("In practice, one can use the estimates from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(" to bound ")#mi("{{\\mathcal D} g(\\sigma)}")#text(". For instance, from Exercise 10 of those notes we have")

#align(center)[#tao-fit-display[#mitex("\\zeta(\\sigma), -\\frac{\\zeta^{\\prime}(\\sigma)}{\\zeta(\\sigma)} = \\frac{1}{\\sigma-1} + O(1)")]]

#text("and thus ")#metadata(none) <tao-303580c62f99c48c6140>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left|\\zeta(s)\\right|, \\left|\\frac{1}{\\zeta(s)}\\right|, \\left|\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)}\\right| \\leq \\frac{1}{\\sigma-1} + O(1)", block: true)]]

#text(" for all ")#mi("{s=\\sigma+it}")#text(" with ")#mi("{\\sigma>1}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(" (the second bound arising from the trivial upper bound ")#tao-math("{\\left|\\mu(n)\\right| \\leq 1}", block: false)#text(").")#linebreak()#text(" We can often obtain matching lower bounds to these upper bounds when ")#mi("{s}")#text(" is close to ")#mi("{1}")#text(" by a number of means. For the Riemann zeta function, one can use the bound ")#metadata(none) <tao-2f57d47a3370b4376ace>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\sum_{n \\in {\\bf Z}: y \\leq n \\leq x} f(n) = \\int_y^x f(t)\\ dt + O( \\int_y^x |f^{\\prime}(t)|\\ dt + \\left|f(y)\\right| )", block: true)]]

#linebreak()#text(" for continuously differentiable ")#mi("{f: [y,x] \\rightarrow {\\bf C}}")#text(" (see Exercise 11 from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text("), which after a brief calculation gives")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) = \\frac{1}{s-1} + O(1)")]]

#text("for ")#mi("{\\text{Re}(s) > 1}")#text(" and ")#mi("{s = O(1)}")#text(". A similar calculation also gives")

#align(center)[#tao-fit-display[#mitex("\\zeta^{\\prime}(s) = -\\frac{1}{(s-1)^2} + O(1)")]]

#text("in the same region, and hence ")#metadata(none) <tao-aac42276f4f8225d94b4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("-\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} = \\frac{1}{s-1} + O(1)")]]

#text(" for ")#mi("{\\text{Re}(s)>1}")#text(" and ")#mi("{s}")#text(" sufficiently close to ")#mi("{1}")#text("; note that these three estimates were already established in ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(" under the additional hypothesis that ")#mi("{s}")#text(" was real. One can view ")#link(<tao-aac42276f4f8225d94b4>)[#text("(13)")]#text(" as a crude version of the heuristic ")#link(<tao-ef7ec7068fca7e7e1de8>)[#text("(4)")]#text(", in which the role of the zeroes ")#mi("{\\rho}")#text(" is neglected. When controlling ")#mi("{{\\mathcal D} f(s)}")#text(" for a multiplicative function ")#mi("{f}")#text(" obeying ")#link(<tao-462208124b6ea2056647>)[#text("(7)")]#text(", one can also exploit the Euler product formula")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D} f(s) = \\prod_p (1 + \\frac{f(p)}{p^s} + \\frac{f(p^2)}{p^{2s}} + \\dots)")]]

#text("which remains valid in the domain ")#mi("{\\{ s: \\text{Re}(s) > 1 \\}}")#text(". For instance, under the hypotheses of Theorem 27 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D} f(s) = \\frac{\\mathfrak S}{(s-1)^k} + O_k(\\frac{1}{(s-1)^{k-1}})")]]

#text("for ")#mi("{\\text{Re}(s)>1}")#text(" and ")#mi("{s=O(1)}")#text(", as can be seen by an inspection of the proof of Theorem 27(i).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" By using the Selberg symmetry formula (equation (67) from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text("), show that")

#align(center)[#tao-fit-display[#mitex("\\frac{\\zeta^{\\prime\\prime}(s)}{\\zeta(s)} = \\frac{2}{(s-1)^2} + O(1 + \\frac{1}{\\sigma-1})")]]

#text("whenever ")#mi("{s = \\sigma+it}")#text(" with ")#mi("{\\sigma>1}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(".")
]

#text("We can obtain better estimates for the zeta function and its relatives once we have some analytic continuation of these functions to the critical strip. However, even before we do so, we can still control various weighted sums of arithmetic functions ")#mi("{f(n)}")#text(" in terms of integral combinations of the Dirichlet series ")#mi("{{\\mathcal D} f(s)}")#text(". This can be achieved by the following formula:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7 (Parseval-type formula)")]#text(" ")#metadata(none) <tao-d82618afad4ffaaf54b5>#text(" Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" obey ")#link(<tao-462208124b6ea2056647>)[#text("(7)")]#text(", and let ")#mi("{g: {\\bf R} \\rightarrow {\\bf C}}")#text(" be a twice continuously differentiable, compactly supported function. Then for any ")#mi("{\\sigma>1}")#text(", one has ")#metadata(none) <tao-02b9900d6d1f6c121f6c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\sum_n \\frac{f(n)}{n} g(\\log n) = \\frac{1}{2\\pi} \\int_{\\bf R} {\\mathcal D} f(\\sigma+it) \\hat g(t-i(\\sigma-1))\\ dt")]]

#text(" where ")#mi("{\\hat g:{\\bf C} \\rightarrow {\\bf C}}")#text(" is the Fourier transform of ")#mi("{g}")#text(" extended to the complex plane, defined by the formula ")#metadata(none) <tao-6152d43caa491abea69c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\hat g(t) := \\int_{\\bf R} g(u) e^{itu}\\ du")]]

#text(" for ")#mi("{t \\in {\\bf C}}")#text(". The integral on the right-hand side of ")#link(<tao-02b9900d6d1f6c121f6c>)[#text("(14)")]#text(" is absolutely integrable.")
]

#text("The formula ")#link(<tao-02b9900d6d1f6c121f6c>)[#text("(14)")]#text(" is similar to the Parseval-type identity")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} f(u) g(u)\\ du = \\frac{1}{2\\pi} \\int_{\\bf R} \\hat f(-t) \\hat g(t)\\ dt")]]

#text("for suitably “nice” functions ")#mi("{f, g: {\\bf R} \\rightarrow {\\bf C}}")#text(" (see Corollary 32 from ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text("). Indeed, one could view ")#mi("{{\\mathcal D} f(1-it)}")#text(" as the Fourier transform of the Radon measure ")#mi("{\\sum_n \\frac{f(n)}{n} \\delta_{\\log n}}")#text(", which (formally, at least) yields ")#link(<tao-02b9900d6d1f6c121f6c>)[#text("(14)")]#text(" from the Parseval identity. However we will not adopt this measure-theoretic viewpoint explicitly here.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" From Exercise 28 of ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text(", we have the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|\\hat g(t-i(\\sigma-1))\\right| \\ll_{g,\\sigma} \\min( 1, \\frac{1}{\\left|t\\right|^2} )", block: true)]]

#text("which, together with the boundedness of ")#mi("{{\\mathcal D} f}")#text(" on ")#mi("{\\{ s: \\text{Re}(s) \\geq \\sigma\\}}")#text(", makes the integral in ")#link(<tao-02b9900d6d1f6c121f6c>)[#text("(14)")]#text(" absolutely integrable as claimed. The same bounds allow one to invoke Fubini’s theorem and rewrite the right-hand side of ")#link(<tao-02b9900d6d1f6c121f6c>)[#text("(14)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi} \\sum_n \\int_{\\bf R} \\frac{f(n)}{n^{\\sigma+it}} \\hat g(t-i(\\sigma-1))\\ dt")]]

#text("which we rearrange as")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{f(n)}{n^\\sigma} \\frac{1}{2\\pi} \\int_{\\bf R} \\hat g(t-i(\\sigma-1)) e^{-it \\log n}\\ dt.")]]

#text("By the Fourier inversion formula (Theorem 30 from ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text("), this simplifies to")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{f(n)}{n^\\sigma} e^{(\\sigma-1)\\log n} g(\\log n),")]]

#text("and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" The ")#link("http://en.wikipedia.org/wiki/Uncertainty_principle")[#text("uncertainty principle")]#text(" in Fourier analysis tells us (heuristically, at least) that if we want the function ")#mi("{g}")#text(" to exhibit non-trivial oscillation at the scale ")#mi("{1/T}")#text(", then the Fourier transform ")#mi("{G}")#text(" has to spread out over an interval of size ")#mi("{\\gg T}")#text(". In particular, if we want to use ")#link(<tao-02b9900d6d1f6c121f6c>)[#text("(14)")]#text(" to investigate fine scale structure of ")#mi("{f(n)}")#text(" on intervals such as ")#mi("{\\{ n: \\log n = \\log x + O(1/T) \\}}")#text(", then one expects to need control on the associated Dirichlet series ")#mi("{{\\mathcal D} f(s)}")#text(" in which the imaginary part of ")#mi("{s}")#text(" can be as large as ")#mi("{T}")#text(" in magnitude. Thus, Fourier analysis gives us the insight that the extent to which one can extend control of the Dirichlet series away from the real axis determines the finest scale of ")#mi("{\\log n}")#text(" that one can hope to control. For instance, the prime number theorem allows one to counting primes in regions such as ")#mi("{\\{n: \\log n =\\log x + o(1)\\}}")#text(", and so should need control of ")#mi("{\\zeta}")#text(" on the entire right edge of the critical strip. Conversely, numerical verification of the Riemann hypothesis that establishes zero free regions for ")#mi("{\\zeta}")#text(" for imaginary parts up to some finite threshold ")#mi("{T}")#text(" should yield effective substitutes for the prime number theorem that are able to count primes in intervals such as ")#mi("{\\{ n: \\log n = \\log x + O(1/T) \\}}")#text(".")
]

#text("The most powerful applications of the Parseval-type formula ")#link(<tao-02b9900d6d1f6c121f6c>)[#text("(14)")]#text(" occur when ")#mi("{{\\mathcal D}}")#text(" has a meromorphic continuation into the critical strip (or beyond), allowing one to shift ")#mi("{\\sigma}")#text(" in the right-hand side of ")#link(<tao-02b9900d6d1f6c121f6c>)[#text("(14)")]#text(" to the left of ")#mi("{1}")#text(" (picking up various terms from residue calculus along the way). But one can still obtain some useful estimates on various summatory functions involving ")#mi("{f}")#text(" even without such meromorphic continuations; in particular, just by using asymptotics near (and to the right of) ")#mi("{s=1}")#text(" such as ")#link(<tao-aac42276f4f8225d94b4>)[#text("(13)")]#text(", we can recover estimates of strength comparable to Mertens’ theorems. Here is a basic example, using only the asymptotic ")#link(<tao-aac42276f4f8225d94b4>)[#text("(13)")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9 (Crude Mertens-type theorem)")]#text(" ")#metadata(none) <tao-27722d0084ecc1078baf>#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" be a continuously twice differentiable compactly supported function. Then for ")#mi("{x>10}")#text(", one has ")#metadata(none) <tao-fa9f515065403f474092>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\sum_n \\frac{\\Lambda(n)}{n} f( \\frac{\\log n}{\\log x} ) = (\\int_0^\\infty f(t)\\ dt) \\log x + O_{f}(1).")]]


]

#text("This estimate is weaker than the Mertens’ theorems from Notes 1. However, later in these notes we will be able to improve the error term in this proposition if ")#mi("{f}")#text(" is smoother, by using a more accurate asymptotic expansion than ")#link(<tao-aac42276f4f8225d94b4>)[#text("(13)")]#text(". One should also compare ")#link(<tao-fa9f515065403f474092>)[#text("(16)")]#text(" to the heuristic ")#link(<tao-c9aec453151b23c8fe20>)[#text("(2)")]#text(" (again neglecting the role of the zeroes).")

#emph[#text("Proof:")]#text(" Since ")#mi("{{\\mathcal D} \\Lambda = -\\frac{\\zeta^{\\prime}}{\\zeta}}")#text(" to the right of the critical strip, we can apply Proposition ")#link(<tao-d82618afad4ffaaf54b5>)[#text("7")]#text(" and rewrite the left-hand side of ")#link(<tao-fa9f515065403f474092>)[#text("(16)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("-\\frac{\\log x}{2\\pi} \\int_{\\bf R} \\frac{\\zeta^{\\prime}(\\sigma+it)}{\\zeta(\\sigma+it)} \\hat f( (t-i(\\sigma-1)) \\log x )\\ dt")]]

#text("where ")#mi("{\\sigma > 1}")#text(" is arbitrary.")#linebreak()#text(" A convenient choice of ")#mi("{\\sigma}")#text(" here is ")#mi("{\\sigma = 1 + \\frac{1}{\\log x}}")#text("; this is about as far as one can push ")#mi("{\\sigma}")#text(" to the right (in order to get the best use out of the estimate ")#link(<tao-303580c62f99c48c6140>)[#text("(11)")]#text(") before the ")#mi("{i(\\sigma-1) \\log x}")#text(" shift to ")#mi("{\\hat f}")#text(" becomes problematic. (Compare with ")#emph[#text("Rankin’s trick")]#text(", discussed in ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(".) In view of ")#link(<tao-aac42276f4f8225d94b4>)[#text("(13)")]#text(", it is natural to consider the expression ")#metadata(none) <tao-ba830aa3b6488b483f4d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\frac{\\log x}{2\\pi} \\int_{\\bf R} \\frac{1}{\\sigma+it - 1} \\hat f( (t-i(\\sigma-1)) \\log x )\\ dt.")]]

#linebreak()#text(" To compute this expression, we write")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\sigma+it - 1} = \\int_0^\\infty e^{-(\\sigma+it-1)u}\\ du")]]

#text("and interchange integrals by Fubini’s theorem. From the Fourier inversion formula (Theorem 30 from ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text(") and a change of variables one has")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi} \\int_{\\bf R} e^{-(\\sigma+it-1)u} \\hat f( (t-i(\\sigma-1)) \\log x )\\ dt")]]

#align(center)[#tao-fit-display[#mitex("= \\frac{1}{\\log x} f( \\frac{u}{\\log x} )")]]

#text("so ")#link(<tao-ba830aa3b6488b483f4d>)[#text("(17)")]#text(" simplifies to the expected main term ")#mi("{(\\int_0^\\infty f(t)\\ dt) \\log x}")#text(" in ")#link(<tao-fa9f515065403f474092>)[#text("(16)")]#text(". It thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} [\\frac{\\zeta^{\\prime}(\\sigma+it)}{\\zeta(\\sigma+it)} - \\frac{1}{\\sigma+it-1}] \\hat f( t \\log x - i )\\ dt = O_{f}(\\frac{1}{\\log x}).")]]

#text("By ")#link(<tao-aac42276f4f8225d94b4>)[#text("(13)")]#text(", we can bound ")#mi("{\\frac{\\zeta^{\\prime}(\\sigma+it)}{\\zeta(\\sigma+it)} - \\frac{1}{\\sigma+it-1}}")#text(" in magnitude by ")#mi("{O(1)}")#text(" when ")#tao-math("{\\left|t\\right|}", block: false)#text(" is smaller than some absolute constant ")#mi("{c>0}")#text(". For ")#tao-math("{\\left|t\\right| > c}", block: false)#text(", we instead use ")#link(<tao-303580c62f99c48c6140>)[#text("(11)")]#text(" to bound this quantity by ")#mi("{O( \\frac{1}{\\sigma-1} ) = O( \\log x )}")#text(". Meanwhile, from Exercise 28 of ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text(" we have the bounds")

#align(center)[#tao-fit-display[#tao-math("\\hat f(t-i) = O_{f}( \\min(1, \\frac{1}{\\left|t\\right|^2} ) ).", block: true)]]

#text("Putting these bounds together, we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" In ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("Notes 4")]#text(" we will use a similar method to that used to prove Theorem ")#link(<tao-27722d0084ecc1078baf>)[#text("9")]#text(" to estimate sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2} \\frac{f(\\frac{\\log d_1}{\\log x}, \\frac{\\log d_2}{\\log x})}{[d_1,d_2]},")]]

#text("where ")#mi("{[d_1,d_2]}")#text(" is the least common multiple of ")#mi("{d_1,d_2}")#text(", and ")#mi("{f: {\\bf R}^2 \\rightarrow {\\bf C}}")#text(" is a smooth compactly supported function; such expressions will arise naturally when we turn to the topic of sieve theory.")
]

#text("A classical limiting case of Proposition ")#link(<tao-d82618afad4ffaaf54b5>)[#text("7")]#text(" is ")#link("http://en.wikipedia.org/wiki/Perron%27s_formula")[#text("Perron’s formula")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11 (Perron’s formula)")]#text(" Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" obey ")#link(<tao-462208124b6ea2056647>)[#text("(7)")]#text(". For any non-integer ")#mi("{x>0}")#text(" and any ")#mi("{\\sigma>1}")#text(", show that ")#metadata(none) <tao-5111f93f8a30fe634de9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\sum_{n \\leq x} f(n) = \\frac{1}{2\\pi i} \\lim_{T \\rightarrow \\infty} \\int_{\\sigma-iT}^{\\sigma+iT} {\\mathcal D}f(s) \\frac{x^s}{s}\\ ds,")]]

#text(" where the integral is a contour integral along the line segment ")#mi("{\\{ \\sigma+it: -T \\leq t \\leq T \\}}")#text(". What happens when ")#mi("{x}")#text(" is an integer?")
]

#text("In practice, the presence of the limit in ")#link(<tao-5111f93f8a30fe634de9>)[#text("(18)")]#text(" is inconvenient, and one usually works with smoothed or truncated version of this formula. Proposition ")#link(<tao-d82618afad4ffaaf54b5>)[#text("7")]#text(" can be viewed as a smoothed version of Perron’s formula. Now we establish a truncated version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 12 (Truncated Perron’s formula)")]#text(" ")#metadata(none) <tao-c94d0a1bc5625def12ca>#text(" Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be such that ")#mi("{f(n) = O(\\log(2+n))}")#text(" for all ")#mi("{n}")#text(", and let ")#mi("{x, T \\geq 2}")#text(". Then ")#metadata(none) <tao-c0a388b2be12cca1a303>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\sum_{n \\leq x} f(n) = \\frac{1}{2\\pi i} \\int_{\\sigma-iT}^{\\sigma+iT} {\\mathcal D}f(s) \\frac{x^s}{s}\\ ds + O( (1+\\frac{x}{T}) \\log^2(x) )")]]

#text(" where ")#mi("{\\sigma := 1 + \\frac{1}{\\log x}}")#text(".")
]

#text("One can sharpen the ")#mi("{\\log^2(x)}")#text(" factor here slightly, but we will not need such improvements here. The condition ")#mi("{f(n) = O(\\log(2+n))}")#text(" can also be relaxed (at the cost of worsening the error term accordingly); we leave this as an exercise to the reader.")

#emph[#text("Proof:")]#text(" By perturbing ")#mi("{x}")#text(" we may assume that ")#mi("{x}")#text(" is not an integer. We will assume temporarily that ")#mi("{f}")#text(" vanishes at the nearest integer ")#mi("{[x]}")#text(" to ")#mi("{x}")#text(", and remove this hypothesis later. In view of ")#link(<tao-5111f93f8a30fe634de9>)[#text("(18)")]#text(", it suffices by dyadic decomposition to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{\\sigma \\pm iT}^{\\sigma \\pm 2iT} {\\mathcal D}f(s) \\frac{x^s}{s}\\ ds\\right| \\ll \\frac{x}{T} \\log^2(x).", block: true)]]

#text("for all ")#mi("{T \\geq 2}")#text(" (not necessarily bounded above by ")#mi("{x}")#text("). By Fubini’s theorem, the left-hand side may be written as ")#metadata(none) <tao-8d01331027ac8fe4a37c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\left| \\sum_n f(n) a_n\\right|", block: true)]]

#text(" where")

#align(center)[#tao-fit-display[#mitex("a_n := \\int_{\\sigma \\pm iT}^{\\sigma \\pm 2iT} \\frac{(x/n)^s}{s}\\ ds.")]]

#text("On taking absolute values, we see that")

#align(center)[#tao-fit-display[#mitex("a_n \\ll (x/n)^\\sigma,")]]

#text("and in particular ")#mi("{a_n \\ll 1}")#text(" for ")#mi("{n \\in [x/2,2x]}")#text(". On the other hand, from integration by parts we have")

#align(center)[#tao-fit-display[#mitex("a_n = \\frac{(x/n)^s}{s \\log(x/n)}|^{\\sigma \\pm 2iT}_{\\sigma \\pm iT} + \\int_{\\sigma \\pm iT}^{\\sigma \\pm 2iT} \\frac{(x/n)^s}{s^2 \\log(x/n)}\\ ds")]]

#text("and thus on taking absolute values")

#align(center)[#tao-fit-display[#tao-math("a_n \\ll \\frac{(x/n)^\\sigma}{T \\left|\\log(x/n)\\right|}.", block: true)]]

#text("In particular we have")

#align(center)[#tao-fit-display[#mitex("a_n \\ll \\frac{x}{T} \\frac{1}{n^\\sigma}")]]

#text("for ")#mi("{n \\not \\in [x/2,2x]}")#text(", and")

#align(center)[#tao-fit-display[#tao-math("a_n \\ll\\frac{x}{T \\left|x-n\\right|}", block: true)]]

#text("for ")#mi("{n \\in [x/2,2x]}")#text(". We may thus upper bound ")#link(<tao-8d01331027ac8fe4a37c>)[#text("(20)")]#text(" using the vanishing of ")#mi("{f}")#text(" at ")#mi("{[x]}")#text(" by")

#align(center)[#tao-fit-display[#tao-math("\\ll \\frac{x}{T} \\sum_n \\frac{\\log(2+n)}{n^\\sigma} + \\sum_{x/2 \\leq n \\leq 2x: n \\neq [x]} \\log x \\frac{x}{T\\left|x-n\\right|}", block: true)]]

#text("Note that as ")#mi("{n \\neq [x]}")#text(", we can lower bound ")#tao-math("{\\left|x-n\\right|}", block: false)#text(" by ")#mi("{\\gg 1}")#text(". The claim now follows from Lemma 2 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(".")#linebreak()#text(" We now have to remove the hypothesis that ")#mi("{f}")#text(" vanishes by ")#mi("{[x]}")#text(". By linearity it suffices to address the case where ")#mi("{f}")#text(" is supported equal to ")#mi("{1}")#text(" at ")#mi("{[x]}")#text(" and vanishes elsewhere (with an error bound of ")#mi("{O(\\frac{x}{T} \\log x)}")#text(". But then ")#mi("{\\sum_{n \\leq x} f(n) = O(1)}")#text(", and by the triangle inequality we have ")#mi("{\\int_{\\sigma-iT}^{\\sigma+iT} {\\mathcal D}f(s) \\frac{x^s}{s}\\ ds = O(\\log x)}")#text(", and the claim follows. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 2. Meromorphic continuation into the critical strip, and the (truncated) explicit formula — ")]]

#metadata(none) <tao-37b902a086b2a6a13707>#linebreak()#text(" To get the most use out of Perron-type formulae, we have to extend Dirichlet series such as the Riemann zeta function meromorphically into the critical strip ")#mi("{\\{ s: 0 \\leq \\text{Re}(s) \\leq 1 \\}}")#text(". Not every Dirichlet series with coefficients ")#mi("{f}")#text(" obeying ")#link(<tao-462208124b6ea2056647>)[#text("(7)")]#text(" has such a meromorphic extension; roughly speaking, the existence of such an extension is morally equivalent to having asymptotic formulae for sums such as ")#mi("{\\sum_{n \\leq x} f(n)}")#text(" or ")#mi("{\\sum_{n \\leq x} \\frac{f(n)}{n^s}}")#text(" whose error term is better than what one can obtain just from ")#link(<tao-462208124b6ea2056647>)[#text("(7)")]#text(".")

#text("To extend the zeta function ")#mi("{\\zeta}")#text(" into the critical strip, we will use ")#link(<tao-2f57d47a3370b4376ace>)[#text("(12)")]#text(", which gives the bound")

#align(center)[#tao-fit-display[#tao-math("\\sum_{y \\leq n \\leq x} \\frac{1}{n^s} = \\frac{y^{1-s} - x^{1-s}}{s-1} + O( \\frac{\\left|s\\right|}{\\sigma} y^{-\\sigma} )", block: true)]]

#text("whenever ")#mi("{1 \\leq y \\leq x}")#text(" and ")#mi("{s = \\sigma+it}")#text(" for some ")#mi("{\\sigma > 0}")#text(", ")#mi("{t \\in {\\bf R}}")#text(" with ")#mi("{s \\neq 1}")#text(". (The error term is a bit crude, particularly when ")#mi("{s}")#text(" has large imaginary part; we will obtain better estimates in later notes.) From Lemma 5 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(", this implies that we can find a (unique) complex number ")#mi("{\\zeta(s)}")#text(" such that ")#metadata(none) <tao-0919bc672bbdc06fb07c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\sum_{n \\leq x} \\frac{1}{n^s} = \\zeta(s) - \\frac{x^{1-s}}{s-1} + O( \\frac{\\left|s\\right|}{\\sigma} x^{-\\sigma} )", block: true)]]

#text(" for all ")#mi("{x \\geq 1}")#text(" and ")#mi("{s = \\sigma+it}")#text(" for some ")#mi("{\\sigma>0}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(" with ")#mi("{s \\neq 1}")#text(". For ")#mi("{\\sigma > 1}")#text(", this definition of ")#mi("{\\zeta(s)}")#text(" agrees with the prior definition of the Riemann zeta function in this range; it also is consistent with the quantity ")#mi("{\\zeta(s)}")#text(" defined for ")#mi("{0 < s < 1}")#text(" in Section 1 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/#comment-443398")[#text("Notes 1")]#text(".")#linebreak()#text(" From ")#link(<tao-0919bc672bbdc06fb07c>)[#text("(21)")]#text(" we also observe the conjugation symmetry ")#metadata(none) <tao-cdc29937887188ad3702>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\zeta( \\overline{s} ) = \\overline{\\zeta(s)}")]]

#linebreak()#text(" for any ")#mi("{s}")#text(" in ")#mi("{\\{ s: \\text{Re}(s) > 0 \\}}")#text(". (Indeed, from the unique continuation property for meromorphic functions, this property is automatic for any meromorphic function on a connected domain symmetric around the real axis, which is real on the real axis.)")#linebreak()#text(" Observe that the function ")#mi("{\\frac{x^{1-s}-1}{s-1}}")#text(" has a removable singularity at ")#mi("{s=1}")#text(" (it approaches ")#mi("{\\log x}")#text(" at that value of ")#mi("{s}")#text("). From ")#link(<tao-0919bc672bbdc06fb07c>)[#text("(21)")]#text(", we see that on the region ")#mi("{\\{ s: \\text{Re}(s) > 0 \\}}")#text(", the function ")#mi("{\\zeta(s) - \\frac{1}{s-1}}")#text(" is the locally uniform limit of the functions ")#mi("{\\sum_{n \\leq x} \\frac{1}{n^s} + \\frac{x^{1-s}-1}{s-1}}")#text(", which are holomorphic on this region once the removable singularity at ")#mi("{s=1}")#text(" is removed. We conclude that ")#mi("{\\zeta(s)-\\frac{1}{s-1}}")#text(" is holomorphic in this region (after removing the singularity at ")#mi("{s=1}")#text("), and hence ")#mi("{\\zeta}")#text(" is meromorphic in this region, with a simple pole at ")#mi("{s=1}")#text(" and no other poles. In particular, we have the Laurent expansion")

#align(center)[#tao-fit-display[#tao-math("\\zeta(s) = \\frac{1}{s-1} + c_0 + c_1 (s-1) + \\dots + c_k(s-1)^k + O_k( \\left|s-1\\right|^{k+1} )", block: true)]]

#text("for any natural number ")#mi("{k}")#text(" and all ")#mi("{s}")#text(" sufficiently close to ")#mi("{1}")#text(", where ")#mi("{c_0, c_1, \\dots}")#text(" are complex coefficients. Differentiating, we also see that ")#metadata(none) <tao-8bb0280d8fc3c52ab408>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("-\\frac{\\zeta^{\\prime}}{\\zeta}(s) = \\frac{1}{s-1} + d_0 + d_1 (s-1) + \\dots + d_k(s-1)^k")]]



#align(center)[#tao-fit-display[#tao-math("+ O_k( \\left|s-1\\right|^{k+1} )", block: true)]]

#text("for any natural number ")#mi("{k}")#text(" and all ")#mi("{s}")#text(" sufficiently close to ")#mi("{1}")#text(", where ")#mi("{d_0, d_1, \\dots}")#text(" are further complex coefficients. This refines the bound ")#link(<tao-aac42276f4f8225d94b4>)[#text("(13)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Show that ")#mi("{c_0= \\gamma}")#text(" and ")#mi("{d_0=-\\gamma}")#text(", where ")#mi("{\\gamma}")#text(" is ")#link("http://en.wikipedia.org/wiki/Euler%E2%80%93Mascheroni_constant")[#text("Euler’s constant")]#text(". (This appearance of ")#mi("{\\gamma}")#text(" in analytic number theory is largely unrelated to the appearance of ")#mi("{e^\\gamma}")#text(" type factors in ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Prove the following generalisation of Proposition ")#link(<tao-27722d0084ecc1078baf>)[#text("9")]#text(": if ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" is a continuously ")#mi("{k}")#text("-times differentiable compactly supported function for some ")#mi("{k \\geq 2}")#text(", then for ")#mi("{x>10}")#text(", one has")

#tao-aligned(keep: true)[


#tao-math("\\sum_n \\frac{\\Lambda(n)}{n} f( \\frac{\\log n}{\\log x} )  & = (\\int_0^\\infty f(t)\\ dt) \\log x + a_{0,f} + a_{-1,f} \\log^{-1} x + \\dots", block: true)



#tao-math(" & + a_{3-k,f} \\log^{3-k} x + O_{f}(\\log^{2-k} x)", block: true)
]

#text("for some complex coefficients ")#mi("{a_{0,f}, a_{-1,f}, \\dots, a_{3-k,f}}")#text(" depending on ")#mi("{f}")#text(". (")#emph[#text("Hint:")]#text(" repeat the proof of Proposition ")#link(<tao-27722d0084ecc1078baf>)[#text("9")]#text(", but use ")#link(<tao-8bb0280d8fc3c52ab408>)[#text("(23)")]#text(" in place of ")#link(<tao-aac42276f4f8225d94b4>)[#text("(13)")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 15")]#text(" Note that the error term in the above exercise improves as ")#mi("{f}")#text(" gets smoother, and in fact becomes significantly better than the type of error terms appearing in the elementary approach when ")#mi("{f}")#text(" is smooth enough (a special case of the “")#link("http://www.tricki.org/article/Smoothing_sums")[#text("smoothed sums")]#text("” philosophy in analysis). Thus we see a contrast between the elementary and complex-analytic methods; the latter approach can provide superior error terms, but also has a preference for smoother sums than the roughly truncated sums that are the main focus of the elementary methods.")
]

#text("From ")#link(<tao-0919bc672bbdc06fb07c>)[#text("(21)")]#text(" with ")#mi("{x=1}")#text(", we also have the crude bound ")#metadata(none) <tao-8f763e7fd9431f359dea>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#tao-math("\\left|\\zeta(s) - \\frac{1}{s-1}\\right| \\ll \\frac{\\left|s\\right|}{\\sigma}", block: true)]]

#linebreak()#text(" in the region ")#mi("{\\{ s: \\text{Re}(s) > 0 \\}}")#text(". While this is quite a crude bound, it implies a decent upper bound on the log-magnitude of ")#mi("{\\zeta}")#text(", namely that ")#metadata(none) <tao-8eb664cee9fe6c0360fd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#tao-math("\\log \\left|\\zeta(s)\\right| \\leq O_\\varepsilon( \\log(2+\\left|s\\right|) )", block: true)]]

#text(" whenever ")#mi("{\\text{Re}(s) \\geq \\varepsilon}")#text(" and ")#tao-math("{\\left|s-1\\right| \\geq \\varepsilon}", block: false)#text(". This, combined with Jensen’s formula, gives a useful upper bound on the density of zeroes of ")#mi("{\\zeta}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 16 (Crude upper bound on zeta zeroes)")]#text(" ")#metadata(none) <tao-fea6679fb108f4c55bbb>#text(" For any ")#mi("{\\varepsilon > 0}")#text(" and ")#mi("{t_0 \\in {\\bf R}}")#text(", there are at most ")#tao-math("{O_\\varepsilon( \\log(2+\\left|t_0\\right|) )}", block: false)#text(" zeroes of ")#mi("{\\zeta}")#text(" (counting multiplicity) in the region ")#tao-math("{\\{ \\sigma+it: \\varepsilon \\leq \\sigma \\leq 1; \\left|t-t_0\\right| \\leq 1 \\}}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" We may assume that ")#tao-math("{\\left|t_0\\right| \\geq 10}", block: false)#text(" (say), since for ")#tao-math("{\\left|t_0\\right| < 10}", block: false)#text(" the claim follows from the discrete nature of the zeroes of a meromorphic function. We may also take ")#mi("{\\varepsilon}")#text(" small, say ")#mi("{\\varepsilon < 1/2}")#text(".")

#text("Consider the disk of radius ")#mi("{2-\\varepsilon/2}")#text(" centred at ")#mi("{2 + it_1}")#text(" for some ")#mi("{t_1 \\in [t_0-2, t_0+2]}")#text(". By ")#link(<tao-303580c62f99c48c6140>)[#text("(11)")]#text(", we have ")#tao-math("{\\log \\left|\\zeta(s)\\right| = O(1)}", block: false)#text(" at the centre ")#mi("{2+it_0}")#text(" of the circle, while from ")#link(<tao-8eb664cee9fe6c0360fd>)[#text("(25)")]#text(" one has ")#tao-math("{\\log \\left|\\zeta(s)\\right| \\leq O_\\varepsilon( \\log \\left|t_0\\right| )}", block: false)#text(" on the boundary of the circle. By Jensen’s formula (Theorem 16 from ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("previous notes")]#text("), this implies that there are at most ")#tao-math("{O_\\varepsilon( \\log \\left|t_0\\right| )}", block: false)#text(" zeroes in the disk of radius ")#mi("{2 - 3\\varepsilon/4}")#text(" (say) centred at ")#mi("{2+it_1}")#text(". Since the region ")#tao-math("{\\{ \\sigma+it: \\varepsilon \\leq \\sigma \\leq 1; \\left|t-t_0\\right| \\leq 1 \\}}", block: false)#text(" can be covered by ")#mi("{O_\\varepsilon(1)}")#text(" such disks, the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 17")]#text(" It will be convenient in the following discussion to adopt the convention that all sums over zeroes of ")#mi("{\\zeta}")#text(" (or of other ")#mi("{L}")#text("-functions) are counted with multiplicity; thus for instance a double zero would contribute twice to such a sum. Indeed, one can think of a zero of order ")#mi("{k}")#text(" as being a limiting case of ")#mi("{k}")#text(" simple zeroes that are extremely close together (cf. ")#link("http://en.wikipedia.org/wiki/Rouch%C3%A9%27s_theorem")[#text("Rouché’s theorem")]#text(" or ")#link("http://en.wikipedia.org/wiki/Hurwitz%27s_theorem_(complex_analysis)")[#text("Hurwitz’s theorem")]#text(" in complex analysis), which helps explain why such zeroes are always counted with multiplicity. It is conjectured that the zeroes of the Riemann zeta function (or of any ")#mi("{L}")#text("-function) are all simple, but this claim looks hopeless to prove using current methods; the problem is that it is nearly impossible for analytic methods to distinguish between a repeated zero, and a pair of simple zeroes that are extremely close together, and we currently do not have good methods to exclude the latter from occurring at least once.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 18")]#text(" As a corollary of Proposition ")#link(<tao-fea6679fb108f4c55bbb>)[#text("16")]#text(", we see that the number of zeroes of ")#mi("{\\zeta}")#text(" in the region ")#tao-math("{\\{ \\sigma+it: \\varepsilon \\leq \\sigma \\leq 1; \\left|t\\right| \\leq T \\}}", block: false)#text(" is ")#mi("{O_\\varepsilon( T \\log(2+T) )}")#text(" for any ")#mi("{T > 0}")#text(". Once we establish the functional equation for ")#mi("{\\zeta}")#text(", we will be able to match this upper bound with a comparable lower bound, and also set ")#mi("{\\varepsilon}")#text(" to zero; see ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Supplement 3")]#text(".")
]

#text("This gives an approximate formula for the log-derivative of zeta in terms of the nearby zeroes:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 19 (Approximate formula for log-derivative of zeta)")]#text(" ")#metadata(none) <tao-917adf1964c277211266>#text(" For any ")#mi("{C,\\varepsilon > 0}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("-\\frac{\\zeta^{\\prime}}{\\zeta}(s) = -\\sum_{\\rho: \\left|s-\\rho\\right| \\leq \\varepsilon/2} \\frac{1}{s-\\rho} + \\frac{1}{s-1} + O_{C,\\varepsilon}( \\log(2+\\left|t\\right|) )", block: true)]]

#text("whenever ")#mi("{s = \\sigma+it}")#text(" and ")#mi("{\\varepsilon \\leq \\sigma \\leq C}")#text(".")
]

#text("This proposition should be viewed as a local version of the heuristic ")#link(<tao-ef7ec7068fca7e7e1de8>)[#text("(4)")]#text(".")

#emph[#text("Proof:")]#text(" To eliminate the pole at ")#mi("{s=1}")#text(", it is convenient to work with the modified function ")#mi("{f(s) := (s-1) \\zeta(s)}")#text(", which is holomorphic in ")#mi("{\\{\\text{Re}(s) > 0\\}}")#text(" after removing the singularity at ")#mi("{s=1}")#text(", and our task is now to show that")

#align(center)[#tao-fit-display[#tao-math("\\frac{f^{\\prime}}{f}(s) = \\sum_{\\rho: \\left|s-\\rho\\right| \\leq \\varepsilon/2} \\frac{1}{s-\\rho} + O_{C,\\varepsilon}( \\log(2+\\left|t\\right|) )", block: true)]]

#text("whenever ")#mi("{s = \\sigma+it}")#text(" and ")#mi("{\\varepsilon \\leq \\sigma \\leq C}")#text(".")#linebreak()#text(" As in the previous proposition, consider the disk of radius ")#mi("{2-\\varepsilon/4}")#text(" centred at ")#mi("{2 + it}")#text(". From ")#link(<tao-303580c62f99c48c6140>)[#text("(11)")]#text(" we have ")#tao-math("{\\log \\left|f\\right| = O( \\log(2+\\left|t\\right| ))}", block: false)#text(" in the centre of this disk, and from ")#link(<tao-8eb664cee9fe6c0360fd>)[#text("(25)")]#text(" one has ")#tao-math("{\\log \\left|f\\right| \\leq O( \\log(2+\\left|t\\right| ) )}", block: false)#text(" on the boundary of the disk. The claim now follows from Theorem 21 of ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text(" (using Proposition ")#link(<tao-fea6679fb108f4c55bbb>)[#text("16")]#text(" to remove the contribution of zeroes further than ")#mi("{\\varepsilon/2}")#text(" from ")#mi("{s}")#text("). ")#mi("\\Box")

#text("Among other things, this proposition gives good control on the size of the log-derivative on average, which will be useful in figuring out how to shift a contour without encountering the large values of ")#mi("{\\zeta^{\\prime}/\\zeta}")#text(" too often:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 20 (Local integrability of log-derivative)")]#text(" ")#metadata(none) <tao-1093a0bb57f2f5299d05>#text(" For any ")#mi("{C > \\varepsilon > 0}")#text(" and ")#mi("{t_0 \\in {\\bf R}}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\int_\\varepsilon^C \\int_{t_0-1}^{t_0+1} |\\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma+it)|\\ dt d\\sigma \\ll_{\\varepsilon,C} \\log(2+\\left|t_0\\right|).", block: true)]]
]

#emph[#text("Proof:")]#text(" We apply Proposition ")#link(<tao-917adf1964c277211266>)[#text("19")]#text(". The contribution of the error term ")#tao-math("{O_{C,\\varepsilon}(\\log(2+\\left|t\\right|))}", block: false)#text(" is clearly acceptable. Because ")#mi("{\\frac{1}{s}}")#text(" is a locally integrable function on the complex plane, we see that the ")#mi("{\\frac{1}{s-1}}")#text(" term contributes a factor of ")#mi("{O_{\\varepsilon,C}(1)}")#text(" to the required integral, and every zero within ")#mi("{O_{\\varepsilon,C}(1)}")#text(" of ")#mi("{it_0}")#text(" also contributes ")#mi("{O_{\\varepsilon,C}(1)}")#text(". The claim now follows from Proposition ")#link(<tao-fea6679fb108f4c55bbb>)[#text("16")]#text(". ")#mi("\\Box")

#text("Now we can apply the truncated Perron’s formula with contour shifting to obtain a truncated explicit formula for the von Mangoldt summatory function:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 21 (Truncated von Mangoldt explicit formula)")]#text(" ")#metadata(none) <tao-0717c2db16020159c712>#text(" For any ")#mi("{0 < \\varepsilon < 1}")#text(" and ")#mi("{x, T \\geq 2}")#text(", we have")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\leq x} \\Lambda(n)  & = x -\\sum_{\\rho: \\text{Re}(\\rho) \\geq \\varepsilon; \\left|\\text{Im}(\\rho)\\right| \\leq T} \\frac{x^\\rho}{\\rho}", block: true)



#tao-math(" & + O_\\varepsilon( x^\\varepsilon \\log^2 T + \\frac{x}{T} \\log^2(x) ).", block: true)
]
]

#text("The error terms here can be improved a little, particularly once one uses the functional equation for ")#mi("{\\zeta}")#text("; see ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Supplement 3")]#text(". However, the current form of the formula already suffices for many applications. This theorem should be compared with ")#link(<tao-c9aec453151b23c8fe20>)[#text("(2)")]#text(".")

#emph[#text("Proof:")]#text(" From Corollary ")#link(<tao-1093a0bb57f2f5299d05>)[#text("20")]#text(" and the pigeonhole principle, we may find ")#mi("{T^{\\prime} \\in [T,T+1]}")#text(" such that ")#metadata(none) <tao-d6e21286621a8586f7e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\int_{\\varepsilon/4}^2 |\\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma \\pm iT^{\\prime})|\\ d\\sigma \\ll_\\varepsilon \\log T")]]

#linebreak()#text(" for either choice of sign ")#mi("{\\pm}")#text(" (note that this implies that the horizontal lines ")#mi("{\\{ s: \\text{Im} s = \\pm T^{\\prime}\\}}")#text(" avoid all the poles of ")#mi("{\\zeta^{\\prime}/\\zeta}")#text("). (One could use ")#link(<tao-cdc29937887188ad3702>)[#text("(22)")]#text(" here to eliminate the need to consider a sign ")#mi("{\\pm}")#text(", but it is not necessary to do so here.) On the other hand, from Proposition ")#link(<tao-c94d0a1bc5625def12ca>)[#text("12")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) = -\\frac{1}{2\\pi i} \\int_{1+\\frac{1}{\\log x}-iT^{\\prime}}^{1+\\frac{1}{\\log x}+iT^{\\prime}} \\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} \\frac{x^s}{s}\\ ds + O( (1+\\frac{x}{T}) \\log^2(x) ).")]]

#text("Observe that on the half-space ")#mi("{\\{ \\text{Re}(s) > 0\\}}")#text(", the meromorphic function ")#mi("{\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} \\frac{x^s}{s}}")#text(" has a pole at ")#mi("{s=1}")#text(" with residue ")#mi("{x}")#text(", and poles at every zero ")#mi("{s = \\rho}")#text(" of ")#mi("{\\zeta}")#text(" with residue ")#mi("{-\\frac{x^\\rho}{\\rho}}")#text(" (multiplied by the multiplicity of the zero), with no other poles. By the residue theorem (Exercise 13 of ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text(") applied to the boundary of the rectangle ")#mi("{\\{ s: \\varepsilon^{\\prime} \\leq \\text{Re}(s) \\leq 1+\\frac{1}{\\log x}; -T^{\\prime} \\leq \\text{Im}(s) \\leq T^{\\prime} \\}}")#text(" for some ")#mi("{\\varepsilon^{\\prime} \\in [\\varepsilon/2,\\varepsilon]}")#text(" to be chosen shortly, with ")#mi("{\\{ s: \\text{Re}(s) =\\varepsilon^{\\prime}\\}}")#text(" avoiding the poles of ")#mi("{\\zeta^{\\prime}/\\zeta}")#text(", and using ")#link(<tao-d6e21286621a8586f7e5>)[#text("(26)")]#text(" to bound the upper and lower limits of integration, we thus have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\leq x} \\Lambda(n) = x - \\sum_{\\rho: \\text{Re}(\\rho) \\geq \\varepsilon^{\\prime}; \\left|\\text{Im}(\\rho)\\right| \\leq T^{\\prime}} \\frac{x^\\rho}{\\rho}", block: true)]]

#metadata(none) <tao-15f3b852d2465ae56ff5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("-\\frac{1}{2\\pi i} \\int_{\\varepsilon^{\\prime}-iT^{\\prime}}^{\\varepsilon^{\\prime}+iT^{\\prime}} \\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} \\frac{x^s}{s}\\ ds + O_\\varepsilon( \\frac{x}{T} \\log^2(x) ).")]]

#text(" Now, from Corollary ")#link(<tao-1093a0bb57f2f5299d05>)[#text("20")]#text(", and integrating ")#mi("{t_0}")#text(" from ")#mi("{-T^{\\prime}}")#text(" to ")#mi("{T^{\\prime}}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\varepsilon/2}^{\\varepsilon} \\int_{-T^{\\prime}}^{T^{\\prime}} |\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} \\frac{x^s}{s}|\\ dt d\\sigma \\ll_\\varepsilon x^{\\varepsilon} \\log^2 T")]]

#text("where ")#mi("{s = \\sigma+it}")#text(". Thus by the pigeonhole principle we may find ")#mi("{\\varepsilon^{\\prime} \\in [\\varepsilon/2,\\varepsilon]}")#text(" where")

#align(center)[#tao-fit-display[#mitex("\\int_{-T^{\\prime}}^{T^{\\prime}} |\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} \\frac{x^s}{s}|\\ dt \\ll_\\varepsilon x^{\\varepsilon} \\log^2 T")]]

#text("where ")#mi("{s = \\varepsilon^{\\prime} + it}")#text(", and so the contour integral in ")#link(<tao-15f3b852d2465ae56ff5>)[#text("(27)")]#text(" is ")#mi("{O_\\varepsilon(x^{\\varepsilon} \\log^2 T)}")#text(". Using Proposition ")#link(<tao-fea6679fb108f4c55bbb>)[#text("16")]#text(", the contribution to ")#tao-math("{\\sum_{\\text{Re}(s) \\geq \\varepsilon^{\\prime}; \\left|\\text{Im}(s)\\right| \\leq T^{\\prime}} \\frac{x^\\rho}{\\rho}}", block: false)#text(" of those zeroes ")#mi("{\\rho}")#text(" with ")#tao-math("{\\left|\\text{Im}(s)\\right| \\geq T}", block: false)#text(" is ")#mi("{O( x \\log T / T)}")#text(", and of those zeroes ")#mi("{\\rho}")#text(" with ")#tao-math("{\\left|\\text{Re}(s)\\right| \\leq \\varepsilon}", block: false)#text(" is ")#mi("{O( x^\\varepsilon \\log^2 T )}")#text(". The claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22 (Smoothed explicit formula)")]#text(" ")#metadata(none) <tao-baf97b94534f5197f0ba>#text(" Let ")#mi("{g: {\\bf R} \\rightarrow {\\bf C}}")#text(" be a smooth, compactly supported function. Then for any ")#mi("{\\varepsilon>0}")#text(" and ")#mi("{x \\geq 2}")#text(", show that")

#tao-aligned(keep: true)[


#tao-math("\\sum_n \\Lambda(n) g( \\log n - \\log x)  & = x \\hat g(-i) - \\sum_{\\rho: \\text{Re}(\\rho) > \\varepsilon} x^\\rho \\hat g(-i\\rho)", block: true)



#tao-math(" & + O_{g,\\varepsilon}( x^\\varepsilon ),", block: true)
]

#text("with the sum on the right-hand side being absolutely convergent. (")#emph[#text("Hint:")]#text(" use Proposition ")#link(<tao-d82618afad4ffaaf54b5>)[#text("7")]#text(" and contour shifting.) This exercise should be compared with ")#link(<tao-c9aec453151b23c8fe20>)[#text("(2)")]#text(".")
]

#text("Theorem ")#link(<tao-0717c2db16020159c712>)[#text("21")]#text(" allows one to use zero-free regions of the Riemann zeta function to improve the error term in the prime number theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 23 (Zero-free region controls von Mangoldt summatory function)")]#text(" ")#metadata(none) <tao-21a798570d3dd6a4f913>#text(" Let ")#mi("{x \\geq T \\geq 2}")#text(" and ")#mi("{0 < \\delta \\leq 1/2}")#text(", and suppose that there are no zeroes ")#mi("{\\rho}")#text(" of ")#mi("{\\zeta}")#text(" in the rectangle ")#tao-math("{\\{ s: 1-\\delta < \\left|\\text{Re}(s)\\right| \\leq 1; \\left|\\text{Im}(s)\\right| \\leq T \\}}", block: false)#text(". Then one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) = x + O( x^{1-\\delta} \\log^2 T ) + O( \\frac{x}{T} \\log^2(x) )")]]

#text("for all ")#mi("{x \\geq 2}")#text(".")
]

#emph[#text("Proof:")]#text(" Apply Theorem ")#link(<tao-0717c2db16020159c712>)[#text("21")]#text(" with ")#mi("{\\varepsilon = 1-\\delta}")#text(". (As ")#mi("{\\varepsilon}")#text(" is bounded away from zero, the implied constant is uniformly bounded in ")#mi("{\\varepsilon}")#text(".) ")#mi("\\Box")

#text("In fact, we have a fairly tight relationship between zero-free regions and error terms. Here is one example of this:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 24")]#text(" ")#metadata(none) <tao-0551ffc77d5f3a5d68f2>#text(" Let ")#mi("{0 < \\delta \\leq 1/2}")#text(". Then the following assertions are equivalent:")

#list(
[#text("(i) One has ")#mi("{\\sum_{n \\leq x} \\Lambda(n) = x + O(x^{1-\\delta+o(1)})}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(".")],
[#text("(ii) One has ")#mi("{\\sum_{n \\leq x} \\Lambda(n) = x + O(x^{1-\\delta} \\log^2 x )}")#text(" for all ")#mi("{x \\geq 2}")#text(".")],
[#text("(iii) All the zeroes ")#mi("{\\rho}")#text(" of ")#mi("{\\zeta}")#text(" have real part at most ")#mi("{1-\\delta}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" Clearly (ii) implies (i). If (iii) holds, then by applying Corollary ")#link(<tao-21a798570d3dd6a4f913>)[#text("23")]#text(" with ")#mi("{T := x^\\delta}")#text(", we obtain (ii).")

#text("Finally, suppose that (i) holds. For ")#mi("{\\text{Re}(s) > 1}")#text(", we see from Fubini’s theorem that")

#align(center)[#tao-fit-display[#mitex("\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} = -\\sum_n \\frac{\\Lambda(n)}{n^s} = -\\int_1^\\infty \\frac{s}{x^{s+1}} \\sum_{n \\leq x} \\Lambda(n)\\ dx,")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} = -\\frac{s}{s-1} - \\int_1^\\infty \\frac{s}{x^{s+1}} (\\sum_{n \\leq x} \\Lambda(n)-x)\\ dx.")]]

#text("By (i) and Morera’s theorem, the integral on the right-hand side extends holomorphically to the region ")#mi("{\\{s:\\text{Re}(s) > 1-\\delta\\}}")#text(", and so by unique continuation ")#mi("{\\zeta^{\\prime}/\\zeta}")#text(" cannot have any poles in this region other than at ")#mi("{s=1}")#text(". This implies (iii). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 25")]#text(" Proposition ")#link(<tao-0551ffc77d5f3a5d68f2>)[#text("24")]#text(" illustrates a remarkable “self-improving” property of estimates on the von Mangoldt summatory function: a weak bound of the form ")#mi("{\\sum_{n \\leq x} \\Lambda(n) = x + O(x^{1-\\delta+o(1)})}")#text(", if true in the asymptotic limit ")#mi("{x \\rightarrow \\infty}")#text(", automatically implies the stronger bound ")#mi("{\\sum_{n \\leq x} \\Lambda(n) = x + O(x^{1-\\delta} \\log^2 x)}")#text(" for any given ")#mi("{x \\geq 2}")#text(" (and in fact the implied constant in the conclusion depends only on ")#mi("{\\delta}")#text(", and not on the decay rate in the hypothesis). This is due to the special structure of this summatory function ")#mi("{x \\mapsto \\sum_{n \\leq x} \\Lambda(n)}")#text(", as revealed by the explicit formula, which limits the range of possible asymptotic behaviours of this function, and in particular gives some control on a given value of this function at some choice of ")#mi("{x}")#text(" in terms of its values at much larger choices of ")#mi("{x}")#text(". (Compare with the following easy example of a self-improving property: if ")#mi("{k}")#text(" is a natural number and ")#mi("{P: {\\bf R} \\rightarrow {\\bf C}}")#text(" is a polynomial with ")#mi("{P(x) = o(x^{k+1})}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(", then ")#mi("{P(x) = O_P(x^k)}")#text(" for all ")#mi("{x \\geq 1}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" Give an alternate proof that (i) implies (iii) in Proposition ")#link(<tao-0551ffc77d5f3a5d68f2>)[#text("24")]#text(" that uses Theorem ")#link(<tao-0717c2db16020159c712>)[#text("21")]#text(" (with ")#mi("{T}")#text(" set to a large power of ")#mi("{x}")#text("), as well as an inspection of the asymptotics of the expression")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty \\varphi( y / x ) y^{-\\rho_0} \\sum_{n \\leq y} \\Lambda(n)\\ dy")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(", where ")#mi("{\\rho_0}")#text(" is a zero of ")#mi("{\\zeta}")#text(" and ")#mi("{\\varphi: [0,+\\infty) \\rightarrow {\\bf R}}")#text(" is a smooth compactly supported bump function. (The point is that expression isolates the effect of the single zero ")#mi("{\\rho_0}")#text(" in the von Mangoldt explicit formula.) Give a similar derivation that uses Exercise ")#link(<tao-baf97b94534f5197f0ba>)[#text("22")]#text(" instead of Theorem ")#link(<tao-0717c2db16020159c712>)[#text("21")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27 (Truncated Landau explicit formula)")]#text(" Let ")#mi("{0 < \\varepsilon < c \\leq \\sigma_0 \\leq C}")#text(" and ")#mi("{x \\geq T \\geq 2}")#text(", and let ")#mi("{s_0 = \\sigma_0+it_0}")#text(" for some ")#mi("{t_0 \\in {\\bf R}}")#text(" be such that ")#mi("{s_0}")#text(" is not a zero or pole of ")#mi("{\\zeta}")#text(". Show that")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\leq x} \\frac{\\Lambda(n)}{n^{s_0}}  & = -\\frac{\\zeta^{\\prime}(s_0)}{\\zeta(s_0)} + \\frac{x^{1-{s_0}}}{1-s_0} -\\sum_{\\rho: \\text{Re}(\\rho) \\geq \\varepsilon; \\left|\\text{Im}(\\rho)-t_0\\right| \\leq T} \\frac{x^{\\rho-{s_0}}}{\\rho-{s_0}}", block: true)



#tao-math(" & + O_{\\varepsilon,c,C}( x^{\\varepsilon-\\sigma_0} \\log^2(T(2+\\left|t_0\\right|)) + \\frac{x^{1-\\sigma_0}}{T} \\log^2(x(2+\\left|t_0\\right|)) ).", block: true)
]
]

#text("Unfortunately, none of the statements in Proposition ")#link(<tao-0551ffc77d5f3a5d68f2>)[#text("24")]#text(" are known to hold for any positive ")#mi("{\\delta}")#text(". The infamous ")#link("http://en.wikipedia.org/wiki/Riemann_hypothesis")[#text("Riemann hypothesis")]#text(" asserts that the statements in Proposition ")#link(<tao-0551ffc77d5f3a5d68f2>)[#text("24")]#text(" hold for ")#mi("{\\delta}")#text(" as large as ")#mi("{1/2}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 28 (Riemann hypothesis)")]#text(" All the zeroes of ")#mi("{\\zeta}")#text(" have real part at most ")#mi("{1/2}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 29")]#text(" This is not quite the traditional formulation of the Riemann hypothesis, which asserts instead that all the zeroes of ")#mi("{\\zeta}")#text(" on the critical strip lie on the critical line ")#mi("{\\{ 1/2+it: t \\in {\\bf R}\\}}")#text(". However, the two formulations are logically equivalent, once one possesses the functional equation; see ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Supplement 3")]#text(".")
]

#text("From the above proposition, we see that the Riemann hypothesis is equivalent to the quite strong estimate")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) = x + O( x^{1/2} \\log^2 x )")]]

#text("on the von Mangoldt summatory function for all ")#mi("{x \\geq 2}")#text(". This already gives a “near miss” to ")#link("http://en.wikipedia.org/wiki/Legendre%27s_conjecture")[#text("Legendre’s conjecture")]#text(" that there exists a prime between ")#mi("{n^2}")#text(" and ")#mi("{(n+1)^2}")#text(" for any ")#mi("{n \\geq 1}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30 (Conditional near-miss to Legendre’s conjecture)")]#text(" Assume the Riemann hypothesis. Show that there exists a constant ")#mi("{C>0}")#text(" such that there exists a prime between ")#mi("{n^2}")#text(" and ")#mi("{(n + C \\log^2 n)^2}")#text(" for any ")#mi("{n \\geq 2}")#text(".")
]

#text("We remark that Cramér reduced the ")#mi("{\\log^2 n}")#text(" term here to a ")#mi("{\\log n}")#text(", however no further improvement is known if one “only” assumes the Riemann hypothesis. (But one can shave the ")#mi("{\\log n}")#text(" further to ")#mi("{o(\\sqrt{\\log n})}")#text(" if one additionally assumes a form of the ")#link("http://en.wikipedia.org/wiki/Montgomery%27s_pair_correlation_conjecture")[#text("Montgomery pair correlation conjecture")]#text(", a ")#link("http://www.ams.org/mathscinet-getitem?mr=730173")[#text("result of Goldston and Heath-Brown")]#text(".) In ")#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/")[#text("Notes 6")]#text(" we will discuss some weaker near-misses to Legendre’s conjecture that are not conditional on unproven statements such as the Riemann hypothesis, by replacing the notion of zero-free region with the weaker, but somewhat comparable in power, notion of a ")#emph[#text("zero-density theorem")]#text(".")

#text("There is a limiting case ")#mi("{\\delta=0}")#text(" of Proposition ")#link(<tao-0551ffc77d5f3a5d68f2>)[#text("24")]#text(", due to Wiener:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 31 (Equivalent forms of prime number theorem)")]#text(" ")#metadata(none) <tao-f53af6ab9f633222cb8d>#text(" The following assertions are equivalent:")

#list(
[#text("(i) One has ")#mi("{\\sum_{n \\leq x} \\Lambda(n) = x + o(x)}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(".")],
[#text("(ii) All the zeroes ")#mi("{\\rho}")#text(" of ")#mi("{\\zeta}")#text(" have real part strictly less than one.")]
)
]

#emph[#text("Proof:")]#text(" First suppose that (ii) fails but (i) holds, so ")#mi("{\\zeta}")#text(" has a zero at ")#mi("{1+it}")#text(" for some non-zero ")#mi("{t \\in {\\bf R}}")#text(". Then ")#mi("{\\frac{-\\zeta^{\\prime}}{\\zeta}}")#text(" has a simple pole at ")#mi("{1+it}")#text(" with residue at most ")#mi("{-1}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("-\\text{Re}(\\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma+it)) \\leq \\frac{-1+o(1)}{\\sigma-1}")]]

#text("as ")#mi("{\\sigma \\rightarrow 1^+}")#text(", or in other words")

#align(center)[#tao-fit-display[#mitex("\\text{Re}(\\sum_n \\frac{\\Lambda(n)}{n^{\\sigma+it}}) \\leq \\frac{-1+o(1)}{\\sigma-1}.")]]

#text("However, from Fubini’s theorem we have")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\Lambda(n)}{n^{\\sigma+it}} = (\\sigma+it) \\int_1^\\infty x^{-\\sigma-it-1} \\sum_{n \\leq x} \\Lambda(n)\\ dx.")]]

#text("Applying (i), we soon conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\Lambda(n)}{n^{\\sigma+it}} = o( \\frac{1}{\\sigma-1} )")]]

#text("as ")#mi("{\\sigma \\rightarrow 1^+}")#text(", giving the required contradiction.")#linebreak()#text(" Now suppose that (ii) holds. We apply Exercise ")#link(<tao-baf97b94534f5197f0ba>)[#text("22")]#text(" with ")#mi("{\\varepsilon=1/2}")#text(" (say) to obtain")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\Lambda(n) g( \\log n - \\log x) = x \\hat g(-i) - \\sum_{\\rho: \\text{Re}(\\rho) > 1/2} x^\\rho \\hat g(-i\\rho) + o(x),")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(", for any smooth compactly supported ")#mi("{g}")#text(" independent of ")#mi("{x}")#text(". By (ii), each individual term ")#mi("{x^\\rho \\hat g(-i\\rho)}")#text(" is ")#mi("{o(x)}")#text(". Since the zeroes are discrete, we thus have")

#tao-aligned(keep: true)[


#tao-math("\\sum_n \\Lambda(n) g( \\log n - \\log x)  & = x \\hat g(-i)", block: true)



#tao-math(" & - \\sum_{\\rho: \\text{Re}(\\rho) > 1/2; \\left|\\text{Im}(\\rho)\\right| \\geq T} x^\\rho \\hat g(-i\\rho) + o(x),", block: true)
]

#text("for any ")#mi("{T \\geq 2}")#text(" independent of ")#mi("{x}")#text(". To control the remaining portion of the sum, we crudely bound ")#mi("{x^\\rho = O(x)}")#text(" and ")#tao-math("{\\hat g(-i\\rho) = O_g( 1/\\left|\\rho\\right|^2 )}", block: false)#text(" (using Exercise 28 of ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text(") and use Proposition ")#link(<tao-fea6679fb108f4c55bbb>)[#text("16")]#text(" to conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\Lambda(n) g( \\log n - \\log x) = x \\hat g(-i) + O_g( \\frac{x}{T} ) + o(x),")]]

#text("and thus on sending ")#mi("{T}")#text(" to infinity and expanding out ")#mi("{\\hat g(-i)}")#text(",")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\Lambda(n) g( \\log n - \\log x) = x \\int_{\\bf R} g(u) e^u\\ du + o(x).")]]

#text("Letting ")#mi("{g}")#text(" be an upper or lower approximant to ")#mi("{1_{[-\\log 2,0]}}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{x/2 \\leq n \\leq x} \\Lambda(n) = \\frac{x}{2} + o(x),")]]

#text("and (i) follows by a telescoping argument. ")#mi("\\Box")#linebreak()#text(" Some of the above discussion involving the von Mangoldt function ")#mi("{\\Lambda}")#text(" has an analogue involving the Möbius function, although it is more difficult to use the residue theorem to obtain a useful explicit formula because the residues of ")#mi("{\\frac{1}{\\zeta}}")#text(" are significantly less well understood than that of ")#mi("{-\\frac{\\zeta^{\\prime}}{\\zeta}}")#text(". Nevertheless, one can still use other complex analytic tools, such as Taylor expansion, to get some weaker statements. We give some examples of this in the exercises below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" Suppose that the conclusions of Proposition ")#link(<tao-0551ffc77d5f3a5d68f2>)[#text("24")]#text(" hold for some ")#mi("{0 < \\delta \\leq 1/2}")#text(".")

#list(
[#text("(i) For any ")#mi("{\\varepsilon > 0}")#text(", show the bounds")

#align(center)[#tao-fit-display[#tao-math("\\log\\left|\\zeta(s)\\right| \\ll_\\varepsilon \\log \\left|t\\right|", block: true)]]

#text("if ")#mi("{s=\\sigma+it}")#text(" with ")#mi("{\\sigma > 1-\\delta+\\varepsilon}")#text(" and ")#tao-math("{\\left|t\\right| \\geq 2}", block: false)#text(". If ")#mi("{\\sigma \\geq 3/2}")#text(" (say), improve this to")

#align(center)[#tao-fit-display[#tao-math("\\log\\left|\\zeta(s)\\right| = O(1).", block: true)]]],
[#text("(ii) Show that there is a branch ")#mi("{\\log \\zeta}")#text(" of the logarithm of ")#mi("{\\zeta}")#text(" that is holomorphic in the region ")#mi("{\\{ s: \\text{Re}(s) > 1-\\delta, \\text{Im}(s) > 0 \\}}")#text(", and obeying the bounds")

#align(center)[#tao-fit-display[#tao-math("(\\log \\zeta)^{(k)}( 2+it ) \\ll_\\varepsilon k! (1+\\delta-\\varepsilon)^{-k} \\log \\left|t\\right|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(\\log \\zeta)^{(k)}( 2+it ) \\ll k! 2^k")]]

#text("for all ")#mi("{0 < \\varepsilon < 1+\\delta}")#text(", ")#mi("{k \\geq 0}")#text(" and ")#tao-math("{\\left|t\\right| \\geq 10}", block: false)#text(", where ")#mi("{(\\log \\zeta)^{(k)}}")#text(" denotes the ")#mi("{k}")#text("-fold derivative of ")#mi("{\\log \\zeta}")#text(". (")#emph[#text("Hint:")]#text(" use the generalised Cauchy integral formulae, see Exercise 9 of ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text(". Note that one may have to control the imaginary part of ")#mi("{\\log \\zeta}")#text(" in addition to the real part.)")],
[#text("(iii) Show that for any ")#mi("{\\varepsilon > 0}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\log\\left|\\zeta(s)\\right|\\right| \\leq \\varepsilon \\log \\left|t\\right|", block: true)]]

#text("if ")#mi("{s=\\sigma+it}")#text(" with ")#mi("{\\sigma > 1-\\delta+\\varepsilon}")#text(" and ")#tao-math("{\\left|t\\right|}", block: false)#text(" sufficiently large depending on ")#mi("{\\varepsilon}")#text(". (")#emph[#text("Hint:")]#text(" Taylor expand ")#mi("{\\log \\zeta}")#text(" around ")#mi("{2+it}")#text(" using the bounds from (ii), possibly with a different choice of ")#mi("{\\varepsilon}")#text(".)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" Let ")#mi("{0 < \\delta \\leq 1/2}")#text(". Show that the conclusions (i)-(iii) of Proposition ")#link(<tao-0551ffc77d5f3a5d68f2>)[#text("24")]#text(" are equivalent to the assertion")

#list(
[#text("(iv) ")#mi("{\\sum_{n \\leq x} \\mu(n) = O( x^{1-\\delta+o(1)})}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(".")]
)

#text("(")#emph[#text("Hint:")]#text(" apply the truncated Perron formula to ")#mi("{f(n)=\\mu(n)}")#text(" and shift the contour, using the preceding exercise to control error terms.) In particular, we see that the Riemann hypothesis is equivalent to the assertion that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) = O( x^{1/2+o(1)} )")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34")]#text(" Show that the Riemann hypothesis implies the ")#link("http://en.wikipedia.org/wiki/Lindel%C3%B6f_hypothesis")[#text("Lindelöf hypothesis")]#text(" that ")#mi("{\\zeta(1/2+it) = O( t^{o(1)} )}")#text(" as ")#mi("{t \\rightarrow +\\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35")]#text(" Let ")#mi("{k \\geq 1}")#text(" be a natural number, and let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be a multiplicative function obeying the bounds ")#mi("{f(p) = k + O_k(\\frac{1}{p})}")#text(" for all primes ")#mi("{p}")#text(", and such that ")#mi("{f(p^j) = O_k(j^{O_k(1)})}")#text(" for all primes ")#mi("{p}")#text(" and ")#mi("{j \\geq 2}")#text(".")

#list(
[#text("(i) Show that ")#mi("{{\\mathcal D} f}")#text(" has a meromorphic continuation to the half-space ")#mi("{\\{ s: \\text{Re}(s) > 0 \\}}")#text(", which has a pole of at most order ")#mi("{k}")#text(" at ")#mi("{s=1}")#text(" but no other poles. (")#emph[#text("Hint:")]#text(" use Euler products to factor ")#mi("{{\\mathcal D} f}")#text(" as the product of ")#mi("{\\zeta^k}")#text(" and a function holomorphic in this half-space.) Also show that ")#tao-math("{{\\mathcal D} f(s) = O_{\\varepsilon,k}( \\left|t\\right|^k )}", block: false)#text(" when ")#mi("{s = \\sigma+it}")#text(" with ")#mi("{\\sigma \\geq \\varepsilon}")#text(" and ")#tao-math("{\\left|t\\right| \\geq 2}", block: false)#text(".")],
[#text("(ii) Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} f(n) = x P( \\log x ) + O_k( x^{1-c} )")]]

#text("for all ")#mi("{x \\geq 10}")#text(" and some ")#mi("{c>0}")#text(" depending only ")#mi("{k}")#text(", where ")#mi("{P(t)}")#text(" is a polynomial with leading term ")#mi("{\\frac{1}{(k-1)!} {\\mathfrak S} t^k}")#text(", where the singular series ")#mi("{{\\mathfrak S}}")#text(" was defined in Theorem 27 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(". (")#emph[#text("Hint:")]#text(" modify Proposition ")#link(<tao-c94d0a1bc5625def12ca>)[#text("12")]#text(" to deal with the fact that ")#mi("{f(n)}")#text(" is only bounded by ")#mi("{n^{o(1)}}")#text(" rather than by ")#mi("{O(\\log n)}")#text(", apply it with ")#mi("{T}")#text(" a small power of ")#mi("{x}")#text(", then shift the contour.) Note that this refines Theorem 27(iii) from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(", and also generalises Exercise 32 from those notes.")]
)
]

#heading(level: 1)[#strong[#text(" — 3. The prime number theorem — ")]]

#text("We are now finally ready to prove the prime number theorem ")#link(<tao-a160524700113ddd3205>)[#text("(3)")]#text(", first established by Hadamard and de la Vallée Poussin. In view of Proposition ")#link(<tao-f53af6ab9f633222cb8d>)[#text("31")]#text(", the task comes down to excluding the possibility that a zero")

#align(center)[#tao-fit-display[#mitex("\\zeta(1+it) = 0")]]

#text("occurs on the line ")#mi("{\\{ 1+it: t \\in {\\bf R}\\}}")#text(" for some ")#mi("{t \\in {\\bf R}}")#text(". Note that ")#mi("{t}")#text(" cannot be zero, as ")#mi("{\\zeta}")#text(" has a pole at ")#mi("{s=1}")#text(".")#linebreak()#text(" The basic point here is that such a zero implies a “conspiracy” between the von Mangoldt function ")#mi("{\\Lambda(n)}")#text(" and the multiplicative function ")#mi("{n^{it}}")#text(", in that the two functions correlate or “pretend” to be like each other in a certain sense. Indeed, if ")#mi("{\\zeta}")#text(" has a zero of some positive order ")#mi("{k}")#text(" at ")#mi("{1+it}")#text(", then the log-derivative ")#mi("{-\\frac{\\zeta^{\\prime}}{\\zeta}}")#text(" has a simple pole with residue ")#mi("{-k}")#text(" at ")#mi("{1+it}")#text(", so in particular")

#align(center)[#tao-fit-display[#mitex("-\\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma+it) = -\\frac{k}{\\sigma-1} + O_t(1)")]]

#text("for ")#mi("{\\sigma > 1}")#text(" sufficiently close to ")#mi("{1}")#text(". We rewrite this as ")#metadata(none) <tao-0b94b0cf882a563cd93c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\sum_n \\frac{\\Lambda(n)}{n^\\sigma} n^{-it} = -\\frac{k}{\\sigma-1} + O_t(1).")]]

#text(" On the other hand, from ")#link(<tao-aac42276f4f8225d94b4>)[#text("(13)")]#text(" (and ")#link(<tao-303580c62f99c48c6140>)[#text("(11)")]#text(", when ")#mi("{\\sigma}")#text(" is large) one has ")#metadata(none) <tao-1d5c72881c9295e01158>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("\\sum_n \\frac{\\Lambda(n)}{n^\\sigma} = \\frac{1}{\\sigma-1} + O(1).")]]

#text(" From the triangle inequality ")#metadata(none) <tao-0a3f13c673af2389ecb9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#tao-math("\\left|\\sum_n \\frac{\\Lambda(n)}{n^\\sigma} n^{-it}\\right| \\leq \\sum_n \\frac{\\Lambda(n)}{n^\\sigma}", block: true)]]

#text(" and sending ")#mi("{\\sigma \\rightarrow 1^+}")#text(", we already obtain a contradiction if ")#mi("{k \\geq 2}")#text("; thus we have shown that there are no zeroes of multiplicity two or higher on the line ")#mi("{\\{ 1+it: t \\in {\\bf R}\\}}")#text(". In the case of a simple zero ")#mi("{k=1}")#text(", we have not yet obtained a contradiction; but observe that in this case, the triangle inequality ")#link(<tao-0a3f13c673af2389ecb9>)[#text("(30)")]#text(" is close to being attained with equality. Intuitively, this implies that ")#mi("{n^{-it} \\approx -1}")#text(" on most of the support of ")#mi("{\\Lambda}")#text(", that is to say that ")#mi("{p^{-it} \\approx 1}")#text(" for “most” primes ")#mi("{p}")#text(". To make this precise, we add ")#link(<tao-0b94b0cf882a563cd93c>)[#text("(28)")]#text(" to ")#link(<tao-1d5c72881c9295e01158>)[#text("(29)")]#text(" and then take real parts to conclude that ")#metadata(none) <tao-2ad8a7049d7c5511ac25>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("\\sum_n \\frac{\\Lambda(n)}{n^\\sigma} (1 + \\text{Re}(n^{-it})) = O_t(1)")]]

#text(" so in particular")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\Lambda(n)}{n^\\sigma} (1 + \\text{Re}(n^{-it})) = o( \\sum_n \\frac{\\Lambda(n)}{n^\\sigma} )")]]

#text("as ")#mi("{\\sigma \\rightarrow 1^+}")#text(". In probabilistic terms, if one selects a natural number ")#mi("{n}")#text(" at random using the probability density ")#mi("{\\frac{\\Lambda(n)}{n^\\sigma}}")#text(", divided by the quantity ")#mi("{\\sum_n \\frac{\\Lambda(n)}{n^\\sigma}}")#text(" to normalise the total probability to be one, then the random variable ")#mi("{1 + \\text{Re}(n^{-it})}")#text(" converges in ")#mi("{L^1}")#text(" to zero. (Note that we are implicitly using the non-negative nature of ")#mi("{\\Lambda}")#text(" in order to access this probabilistic interpretation.)")#linebreak()#text(" Following Hadamard, we exploit the following basic observation: if ")#mi("{n^{it} \\approx -1}")#text(", then ")#mi("{n^{2it} \\approx +1}")#text(". To use this observation quantitatively, it is convenient (following Mertens, who simplified the original argument of Hadamard) to exploit the trigonometric inequality ")#metadata(none) <tao-c8e4d6016f4ab159371b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("0 \\leq 1 - \\cos(2\\theta) \\leq 4 (1 + \\cos \\theta )")]]

#linebreak()#text(" for any ")#mi("{\\theta \\in {\\bf R}}")#text(" (which follows from the identity ")#mi("{1 - \\cos(2\\theta) = 4 (1 + \\cos \\theta) - 2(1+\\cos \\theta)^2}")#text("), which implies that ")#metadata(none) <tao-ede331c6992c5dc89d10>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("0 \\leq 1 - \\text{Re}(n^{-2it}) \\leq 4 (1 + \\text{Re}(n^{-it}) ).")]]

#text(" Inserting this inequality into ")#link(<tao-2ad8a7049d7c5511ac25>)[#text("(31)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\Lambda(n)}{n^\\sigma} (1 - \\text{Re}(n^{-2it})) = O_t(1)")]]

#text("and hence by ")#link(<tao-1d5c72881c9295e01158>)[#text("(29)")]

#align(center)[#tao-fit-display[#mitex("\\text{Re} \\sum_n \\frac{\\Lambda(n)}{n^\\sigma} n^{-2it} = \\frac{1}{\\sigma-1} + O_t(1).")]]

#text("This implies that ")#mi("{-\\frac{\\zeta^{\\prime}}{\\zeta}}")#text(" has a pole at ")#mi("{1+2it}")#text(" with residue ")#mi("{1}")#text(", and so ")#mi("{\\zeta}")#text(" must have a simple pole at ")#mi("{1+2it}")#text(". But the only pole of ")#mi("{\\zeta}")#text(" is at ")#mi("{1}")#text(", and ")#mi("{t}")#text(" is non-zero, giving a contradiction. Thus there are no zeroes of ")#mi("{\\zeta}")#text(" on the line ")#mi("{\\{1+it: t \\in {\\bf R}\\}}")#text(", and the prime number theorem follows thanks to Proposition ")#link(<tao-f53af6ab9f633222cb8d>)[#text("31")]#text(".")#linebreak()#text(" The key inequality ")#link(<tao-c8e4d6016f4ab159371b>)[#text("(32)")]#text(" is often written as ")#mi("{3 + 4 \\cos \\theta + \\cos(2\\theta)\\geq 0}")#text(", or ")#mi("{e^{-2i\\theta} + 4e^{-i\\theta} + 6 + 4e^{i\\theta} + e^{2i\\theta} \\geq 0}")#text(". In particular, we have ")#metadata(none) <tao-86e50149658661312a9e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#mitex("3 + 4 \\text{Re} n^{-it} + \\text{Re} n^{-2it} \\geq 0,")]]

#linebreak()#text(" which on multiplying with ")#mi("{\\frac{\\Lambda(n)}{n^\\sigma}}")#text(" and summing gives the useful inequality ")#metadata(none) <tao-50b8d2c3973594d74271>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#mitex("- 3 \\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma) - 4 \\text{Re} \\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma+it) - \\text{Re} \\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma+2it) \\geq 0")]]

#text(" for any ")#mi("{\\sigma > 1}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(". Integrating this in ")#mi("{\\sigma}")#text(" from ")#mi("{\\sigma=+\\infty}")#text(" (noting that ")#mi("{\\zeta(\\sigma+it) \\rightarrow 1}")#text(" as ")#mi("{\\sigma \\rightarrow +\\infty}")#text(" for any fixed ")#mi("{t}")#text(") gives the variant ")#metadata(none) <tao-cb7bf562420b82e97ee1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#tao-math("\\left|\\zeta(\\sigma)\\right|^3 \\left|\\zeta(\\sigma+it)\\right|^4 \\left|\\zeta(\\sigma+2it)\\right| \\geq 1.", block: true)]]

#text(" (One can also obtain this inequality directly from ")#link(<tao-86e50149658661312a9e>)[#text("(34)")]#text(" by multiplying by ")#mi("{\\frac{\\Lambda(n)}{n^\\sigma \\log n}}")#text(", summing, then exponentiating; we leave the details to the interested reader.) This variant gives a slightly different way to interpret the above proof of the prime number theorem: ")#mi("{\\zeta}")#text(" has a simple pole at ")#mi("{s=1}")#text(", and no pole at ")#mi("{1+2it}")#text(", so from ")#link(<tao-cb7bf562420b82e97ee1>)[#text("(36)")]#text(" the maximum order of zero it can have at ")#mi("{1+it}")#text(" is ")#mi("{\\frac{3}{4}}")#text(". But the order must be an integer, and so one cannot have a zero of any positive order.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36")]#text(" Use the Selberg symmetry formula (equation (67) from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(") to obtain the asymptotics")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\Lambda_2(n)}{n^\\sigma \\log n} = (1+o(1)) \\frac{2}{\\sigma-1}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\Lambda_2(n)}{n^\\sigma \\log n} \\text{Re}(n^{-it}) = o(\\frac{2}{\\sigma-1})")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\sum_n \\frac{\\Lambda_2(n)}{n^\\sigma \\log n} \\left|\\text{Re}(n^{-it})\\right| = (\\frac{2}{\\pi}+o(1)) \\frac{2}{\\sigma-1}", block: true)]]

#text("as ")#mi("{\\sigma \\rightarrow 1^+}")#text(", for any fixed ")#mi("{t \\neq 0}")#text(". By using the bound ")#tao-math("{\\left|\\Lambda(n) - \\frac{1}{2 \\log n} \\Lambda_2(n)\\right| \\leq \\frac{1}{2 \\log n} \\Lambda_2(n)}", block: false)#text(", conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\Lambda(n)}{n^\\sigma} (1+\\text{Re}(n^{-it})) \\geq (1 - \\frac{2}{\\pi}+o(1)) \\frac{1}{\\sigma-1},")]]

#text("and use this to give an alternate proof of the prime number theorem. (This argument is related, though not completely identical, to the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem#Elementary_proofs")[#text("Erdös-Selberg elementary proof of the prime number theorem")]#text(", which we will not give here.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 37")]#text(" Another heuristic way to see the lack of zeroes on the line ")#mi("{\\{1+it: t \\in {\\bf R}\\}}")#text(" is to return to the explicit formula ")#link(<tao-f9815867b5c6572a9404>)[#text("(1)")]#text(". If there was a zero at ")#mi("{1+it}")#text(", there would also be a zero at ")#mi("{1-it}")#text(" thanks to the conjugation symmetry ")#link(<tao-cdc29937887188ad3702>)[#text("(22)")]#text(", and hence")

#align(center)[#tao-fit-display[#mitex("\\Lambda \\approx 1 - n^{-it} - n^{it} - \\dots .")]]

#text("In particular, ")#mi("{\\Lambda}")#text(" should behave like ")#mi("{-1}")#text(" or less on the average in the region where ")#mi("{n^{it} \\approx 1}")#text(" (which would imply that other powers ")#mi("{n^{it^{\\prime}}}")#text(" are also comparable to ")#mi("{1}")#text(" if ")#mi("{t^{\\prime}}")#text(" is an integer multiple of ")#mi("{t}")#text(", or else oscillate “orthogonally” to ")#mi("{n^{it}}")#text("). But ")#mi("{\\Lambda}")#text(" is non-negative, which heuristically suggests a contradiction. One can interpret the arguments based on ")#link(<tao-86e50149658661312a9e>)[#text("(34)")]#text(" above as a rigorous implementation of this heuristic argument.")
]

#text("We have now established that the Riemann zeta function has no zeroes on the line ")#mi("{\\{1+it: t \\in {\\bf R} \\}}")#text(". Since the zeroes of ")#mi("{\\zeta}")#text(" are discrete, this implies a ")#emph[#text("qualitative")]#text(" zero-free region to the left of this line, in the sense that there is an open neighbourhood of this line that is free of zeroes of ")#mi("{\\zeta}")#text(". However, for applications (such as Corollary ")#link(<tao-21a798570d3dd6a4f913>)[#text("23")]#text("), we need a more quantitative zero-free region. To do this, we return to the bound in Proposition ")#link(<tao-917adf1964c277211266>)[#text("19")]#text(" as a quantitative substitute for the bound ")#link(<tao-0b94b0cf882a563cd93c>)[#text("(28)")]#text(". We specialise to the case where ")#mi("{s = \\sigma+it}")#text(" with ")#mi("{1 < \\sigma < 2}")#text(" and ")#tao-math("{\\left|t\\right| \\gg 1}", block: false)#text(", and set ")#mi("{\\varepsilon=1/2}")#text(" (say). In this case, the ")#mi("{\\frac{1}{s-1}}")#text(" term is ")#mi("{O(1)}")#text(", and we conclude that ")#metadata(none) <tao-2c371c2ada73a02e26e1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#tao-math("-\\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma+it) = -\\sum_{\\rho: \\left|\\sigma+it-\\rho\\right| \\leq 1/4} \\frac{1}{\\sigma+it-\\rho} + O( \\log(2+\\left|t\\right|) )", block: true)]]

#linebreak()#text(" Observe that as all the zeroes ")#mi("{\\rho}")#text(" have real part at most ")#mi("{1}")#text(", the quantity ")#mi("{\\frac{1}{\\sigma+it-\\rho}}")#text(" has non-negative real part. Thus we have ")#metadata(none) <tao-98fbb7ef60124ed0c3bb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#tao-math("- \\text{Re} \\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma+it) \\leq O( \\log(2+\\left|t\\right|) )", block: true)]]

#text(" whenever ")#mi("{1 < \\sigma < 2}")#text(" and ")#tao-math("{\\left|t\\right| \\gg 1}", block: false)#text(". If there is a zero ")#mi("{\\sigma_0 + it}")#text(" of ")#mi("{\\zeta}")#text(" with the same imaginary part as ")#mi("{\\sigma+it}")#text(", with ")#mi("{\\sigma_0 > 0}")#text(", then we have the improvement ")#metadata(none) <tao-3d96c3915d44b575b508>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(39)")])
#tao-math("- \\text{Re} \\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma+it) \\leq - \\frac{1}{\\sigma-\\sigma_0} + O( \\log(2+\\left|t\\right|) )", block: true)]]

#text(" (note that the term ")#mi("{\\frac{1}{\\sigma-\\sigma_0}}")#text(" is only of size ")#mi("{O(1)}")#text(" and thus negligible if ")#tao-math("{\\left|\\sigma-\\sigma_0\\right| > 1/4}", block: false)#text("). This now gives")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 38 (Classical zero-free region)")]#text(" ")#metadata(none) <tao-9a639003b35ec01545e2>#text(" There exists an absolute constant ")#mi("{c>0}")#text(" such that there are no zeroes of ")#mi("{\\zeta}")#text(" in the region")

#align(center)[#tao-fit-display[#tao-math("\\{ \\beta+it: \\beta > 1 - \\frac{c}{\\log(2+\\left|t\\right|)}\\}.", block: true)]]
]

#emph[#text("Proof:")]#text(" Let ")#mi("{c>0}")#text(" be a small constant to be chosen later. Suppose for contradiction that one has")

#align(center)[#tao-fit-display[#mitex("\\zeta(\\beta + it ) = 0")]]

#text("for some ")#mi("{t \\in {\\bf R}}")#text(" and ")#tao-math("{\\beta > 1 - \\frac{c}{\\log(2+\\left|t\\right|)}}", block: false)#text(". As ")#mi("{\\zeta}")#text(" has a simple pole at ")#mi("{1}")#text(", there are no zeroes in a neighbourhood of ")#mi("{1}")#text(", and so one has ")#tao-math("{\\left|t\\right| \\gg 1}", block: false)#text(" if ")#mi("{c}")#text(" is small enough. For any ")#mi("{1 < \\sigma < 2}")#text(", we conclude from ")#link(<tao-3d96c3915d44b575b508>)[#text("(39)")]#text(" that")

#align(center)[#tao-fit-display[#tao-math("- \\text{Re} \\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma+it) \\leq - \\frac{1}{\\sigma-\\beta} + O( \\log(2+\\left|t\\right|) )", block: true)]]

#text("while from ")#link(<tao-98fbb7ef60124ed0c3bb>)[#text("(38)")]#text(" one has")

#align(center)[#tao-fit-display[#tao-math("- \\text{Re} \\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma+2it) \\leq O( \\log(2+\\left|t\\right|) )", block: true)]]

#text("and from ")#link(<tao-aac42276f4f8225d94b4>)[#text("(13)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("- \\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma) = \\frac{1}{\\sigma - 1} + O(1).")]]

#text("Inserting these bounds into ")#link(<tao-50b8d2c3973594d74271>)[#text("(35)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\frac{3}{\\sigma-1} - \\frac{4}{\\sigma-\\beta} \\geq - O( \\log(2+\\left|t\\right|) )", block: true)]]

#text("for any ")#mi("{1 < \\sigma < 2}")#text(". Setting ")#mi("{\\sigma := 1 + C (1-\\beta)}")#text(" for a sufficiently large absolute constant ")#mi("{C}")#text(" (actually ")#mi("{C=4}")#text(" suffices), we still have ")#mi("{\\sigma < 2}")#text(" if ")#mi("{c}")#text(" is small enough, and the left-hand side is equal to")

#align(center)[#tao-fit-display[#mitex("(\\frac{3}{C} - \\frac{4}{C+1}) \\frac{1}{1-\\beta}.")]]

#text("For ")#mi("{C}")#text(" large enough, ")#mi("{\\frac{3}{C} - \\frac{4}{C+1}}")#text(" is negative, we contradict the hypothesis ")#tao-math("{\\beta > 1 - \\frac{c}{\\log(2+\\left|t\\right|)}}", block: false)#text(" if ")#mi("{c}")#text(" is small enough. ")#mi("\\Box")#linebreak()#text(" We can insert this zero-free region into Corollary ")#link(<tao-21a798570d3dd6a4f913>)[#text("23")]#text(", optimising the choice of parameters, to obtain a quantitative form of the prime number theorem, first obtained by de Vallée Poussin:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 39 (Prime number theorem with classical error term)")]#text(" We have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) = x + O( x \\exp( - c \\sqrt{\\log x} ) )")]]

#text("for all ")#mi("{x \\geq 2}")#text(" and some absolute constant ")#mi("{c>0}")#text(". In particular, one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) = x + O_A( x \\log^{-A} x )")]]

#text("for any ")#mi("{x \\geq 2}")#text(" and ")#mi("{A \\geq 0}")#text(".")
]

#emph[#text("Proof:")]#text(" Apply Corollary ")#link(<tao-21a798570d3dd6a4f913>)[#text("23")]#text(" with ")#mi("{T := \\exp( c_1 \\sqrt{\\log x} )}")#text(" and ")#mi("{\\delta := \\frac{c_1}{\\sqrt{\\log x}}}")#text(" for some small absolute constant ")#mi("{c_1>0}")#text("; this choice of parameters is designed to roughly balance the size of two error terms in that corollary, which is usually a near-optimal way to choose parameters. The required zero-free region follows from Proposition ")#link(<tao-9a639003b35ec01545e2>)[#text("38")]#text(" if ")#mi("{c_1}")#text(" is small enough, and the claim then follows (noting that logarithmic factors ")#mi("{\\log^{O(1)} x}")#text(" can be absorbed into the decay factors ")#mi("{O( \\exp( - c \\sqrt{\\log x} ) )}")#text(" by shrinking ")#mi("{c}")#text(" slightly). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 40 (Alternate form of prime number theorem)")]#text(" ")#metadata(none) <tao-64f46a7526a186d23465>#text(" Show that for any ")#mi("{x \\geq 2}")#text(", the number ")#mi("{\\pi(x)}")#text(" of primes less than or equal to ")#mi("{x}")#text(" obeys the estimate")

#align(center)[#tao-fit-display[#mitex("\\pi(x) = \\text{li}(x) + O( x \\exp( - c \\sqrt{\\log x} ) )")]]

#text("for some absolute constant ")#mi("{c>0}")#text(", where the ")#link("http://en.wikipedia.org/wiki/Logarithmic_integral_function")[#text("logarithmic integral")]#text(" ")#mi("{\\text{li}(x)}")#text(" is defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\text{li}(x) := \\int_0^x \\frac{dt}{\\log t}.")]]

#text("Conclude in particular that")

#align(center)[#tao-fit-display[#mitex("\\pi(x) = \\frac{x}{\\log x} + \\frac{x}{\\log^2 x} + O( \\frac{x}{\\log^3 x} )")]]

#text("for all ")#mi("{x \\geq 2}")#text("; in particular, the simple form ")#mi("{\\pi(x) \\sim x/\\log x}")#text(" of the prime number theorem is not particularly accurate, and one should use the refined version ")#mi("{\\pi(x) \\sim \\text{li}(x)}")#text(" instead (or better yet, work with the von Mangoldt function).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 41 (Prime number theorem for Möbius)")]#text(" Show that there is an absolute constant ")#mi("{c_1>0}")#text(" such that one has the bounds")

#align(center)[#tao-fit-display[#tao-math("-\\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma+it) = O( \\log(2+\\left|t\\right|) )", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\log\\left|\\zeta(\\sigma+it)\\right| = O( \\log \\log(100+\\left|t\\right|) )", block: true)]]

#text("whenever ")#tao-math("{\\left|t\\right| \\gg 1}", block: false)#text(" and ")#tao-math("{\\sigma \\geq 1 - \\frac{c_1}{\\log(2+\\left|t\\right|)}}", block: false)#text(".")

#text("(Hint: first obtain upper bounds on the real part of ")#mi("{-\\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma+it)}")#text(", and then use the Borel-Car\\’atheodory theorem, see Exercise 40 from ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text("}.)")

#text("Conclude the alternate form")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) = O( x \\exp( - c_2 \\sqrt{\\log x} ) )")]]

#text("of the prime number theorem with classical error term for all ")#mi("{x \\geq 2}")#text(" and some ")#mi("{c_2>0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42 (Landau-Beurling prime number theorem)")]#text(" Let")

#align(center)[#tao-fit-display[#mitex("1 < p_1 \\leq p_2 \\leq \\dots")]]

#text("be a set of real numbers, which we refer to as ")#emph[#text("Beurling primes")]#text(". Define a ")#emph[#text("Beurling integer")]#text(" to be a real number of the form")

#align(center)[#tao-fit-display[#mitex("p_{i_1}^{a_1} \\dots p_{i_r}^{a_r}")]]

#text("for some ")#mi("{i_1 < \\dots < i_r}")#text(" and ")#mi("{a_1,\\dots,a_r \\geq 0}")#text("; note that due to potential collisions between different products of Beurling primes, it is possible for a real number to be a Beurling integer in multiple ways. Let ")#mi("{{\\mathcal P}_B}")#text(" and ")#mi("{{\\bf N}_B}")#text(" denote the sets of Beurling primes and Beurling integers respectively. If we have the asymptotic bound ")#metadata(none) <tao-207f5c1d8a3ec09f296b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(40)")])
#mitex("\\sum_{n \\in {\\bf N}_B: n \\leq x} 1 = x + O( x^{1-c_0} )")]]

#text(" for all ")#mi("{x \\geq 1}")#text(" and some absolute constant ")#mi("{c_0>0}")#text(", establish the ")#emph[#text("Landau-Beurling prime number theorem")]#text(" ")#metadata(none) <tao-9a3576ca4a048b010e83>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(41)")])
#mitex("\\sum_{p \\in {\\mathcal P}_B: n \\leq x} 1 = \\frac{x}{\\log x} + O( x \\exp( - c_1 \\sqrt{\\log x} ) )")]]

#text(" for all ")#mi("{x \\geq 2}")#text(" and some absolute constant ")#mi("{c_1>0}")#text("; this generalises Exercise ")#link(<tao-64f46a7526a186d23465>)[#text("40")]#text(". (")#emph[#text("Hint:")]#text(" form the ")#link("http://en.wikipedia.org/wiki/Beurling_zeta_function")[#text("Beurling zeta function")]#text(" ")#mi("{\\zeta_B(s) := \\sum_{n\\in {\\bf N}_B} \\frac{1}{n^s}}")#text(" and show that it has a meromorphic continuation to the region ")#mi("{\\{ s: \\text{Re}(s) > 1-c_0\\}}")#text(", and obeys the bounds ")#tao-math("{\\zeta_B(\\sigma+it) = O_{c_0,\\varepsilon}( \\left|t\\right|^{O_{c_0,\\varepsilon}(1)} )}", block: false)#text(" for ")#mi("{\\varepsilon>0}")#text(", ")#tao-math("{\\left|t\\right| \\gg 1}", block: false)#text(", and ")#mi("{\\sigma > c_0 + \\varepsilon}")#text(". Then repeat the proof of the prime number theorem, all the way down to Exercise ")#link(<tao-64f46a7526a186d23465>)[#text("40")]#text(".) This result is essentially due to Landau; Beurling was able to obtain a variant in which the hypothesis ")#link(<tao-207f5c1d8a3ec09f296b>)[#text("(40)")]#text(" and conclusion ")#link(<tao-9a3576ca4a048b010e83>)[#text("(41)")]#text(" were both weakened. On the other hand, it was ")#link("http://www.ams.org/mathscinet-getitem?mr=2208947")[#text("shown by Diamond, Montgomery, and Vorhauer")]#text(" that without any further axioms on Beurling integers beyond ")#link(<tao-207f5c1d8a3ec09f296b>)[#text("(40)")]#text(", it is not possible to improve upon the estimate ")#link(<tao-9a3576ca4a048b010e83>)[#text("(41)")]#text(" (other than by sharpening the constant ")#mi("{c_1}")#text("). Thus, to go beyond the prime number theorem with classical error term, one needs to know more about the natural numbers than just that they are roughly uniformly distributed on the positive real axis in the sense of ")#link(<tao-207f5c1d8a3ec09f296b>)[#text("(40)")]#text(".")
]

#text("In ")#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/")[#text("Notes 5")]#text(", we will obtain better upper bounds on ")#tao-math("{\\left|\\zeta(s)\\right|}", block: false)#text(" in the critical strip (and particularly near the line ")#mi("{\\{1+it: t \\in {\\bf R}\\}}")#text(") that improve upon ")#link(<tao-8f763e7fd9431f359dea>)[#text("(24)")]#text(". This will allow us to obtain variants of Proposition ")#link(<tao-917adf1964c277211266>)[#text("19")]#text(" near the line ")#mi("{\\{1+it: t \\in {\\bf R}\\}}")#text(" in which the error term ")#tao-math("{O( \\log(2+\\left|t\\right|) )}", block: false)#text(" is replaced with a smaller quantity. The argument based on ")#link(<tao-50b8d2c3973594d74271>)[#text("(35)")]#text(" will then allow us to enlarge the classical zero-free region in Proposition ")#link(<tao-9a639003b35ec01545e2>)[#text("38")]#text(", which in turn leads to an improved error term in the prime number theorem. The asymptotically strongest such result is due to Vinogradov and Korobov, who use new upper bounds on ")#tao-math("{\\left|\\zeta\\right|}", block: false)#text(" to obtain a zero-free region of the form ")#metadata(none) <tao-82475512540baa91122c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#tao-math("\\{ \\beta+it: \\beta > 1 - \\frac{c}{\\log(100+\\left|t\\right|)^{2/3} \\log\\log(100+\\left|t\\right|)^{1/3}} \\}", block: true)]]

#linebreak()#text(" for some ")#mi("{c>0}")#text(", which leads to the prime number theorem ")#metadata(none) <tao-8a2539e2b69d9daf9d58>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(43)")])
#mitex("\\sum_{n \\leq x} \\Lambda(n) = x + O( x \\exp( - c \\log^{3/5} x / (\\log\\log x)^{1/5} ) )")]]

#text(" for some ")#mi("{c>0}")#text(" and all ")#mi("{x\\geq 100}")#text("; see the exercise below. This still falls short of the claims in Proposition ")#link(<tao-0551ffc77d5f3a5d68f2>)[#text("24")]#text(" for any fixed ")#mi("{\\delta>0}")#text(", however it is important for some applications (e.g. finding primes in short intervals) to get some improvement over the classical zero-free region in Proposition ")#link(<tao-9a639003b35ec01545e2>)[#text("38")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 43")]

#list(
[#text("(i) Establish the upper bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(44)")])
#tao-math("\\left|\\zeta(\\sigma+it)\\right| \\ll \\log^{O(1)} \\left|t\\right|", block: true)]]

#metadata(none) <tao-d2afce2f0711890ec752>#text(" whenever ")#tao-math("{\\left|t\\right| \\geq 100}", block: false)#text(" and ")#tao-math("{\\sigma> 1 - c \\frac{\\log\\log \\left|t\\right|}{\\log \\left|t\\right|}}", block: false)#text(" for an absolute constant ")#mi("{c>0}")#text(". (")#emph[#text("Hint:")]#text(" apply ")#link(<tao-0919bc672bbdc06fb07c>)[#text("(21)")]#text(" for a suitable choice of ")#mi("{x}")#text(".)")],
[#text("(ii) Assume that the upper bound ")#link(<tao-d2afce2f0711890ec752>)[#text("(44)")]#text(" in fact holds in the larger region where ")#tao-math("{\\left|t\\right| \\geq 100}", block: false)#text(" and ")#tao-math("{\\sigma> 1 - c \\frac{(\\log\\log \\left|t\\right|)^{2/3}}{\\log^{2/3} \\left|t\\right|}}", block: false)#text(" for some absolute constant ")#mi("{c>0}")#text(". (This bound, essentially due to Vinogradov and Korobov, will be rigorously established in ")#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/")[#text("Notes 5")]#text(".) Conclude the variant")

#tao-aligned(keep: true)[


#tao-math("-\\frac{\\zeta^{\\prime}}{\\zeta}(s)  & = -\\sum_{\\rho: \\left|\\rho - s\\right| \\leq c^{\\prime} \\frac{(\\log \\log \\left|t\\right|)^{2/3}}{\\log^{2/3} \\left|t\\right|}} \\frac{1}{s-\\rho}", block: true)



#tao-math(" & + O( \\log^{2/3} \\left|t\\right| (\\log\\log \\left|t\\right|)^{1/3})", block: true)
]

#text("of ")#link(<tao-2c371c2ada73a02e26e1>)[#text("(37)")]#text(", whenever ")#mi("{s=\\sigma+it}")#text(" with ")#tao-math("{\\left|t\\right| \\geq 200}", block: false)#text(" and ")#mi("{\\sigma > 1}")#text(", and ")#mi("{c^{\\prime}>0}")#text(" is an absolute constant.")],
[#text("(iii) With the assumption in (ii), establish a zero-free region of the form ")#link(<tao-82475512540baa91122c>)[#text("(42)")]#text(".")],
[#text("(iv) Assuming a zero-free region of the form ")#link(<tao-82475512540baa91122c>)[#text("(42)")]#text(", deduce ")#link(<tao-8a2539e2b69d9daf9d58>)[#text("(43)")]#text(".")],
[#text("(v) What happens if one starts only with the bound in (i), rather than in (ii)?")]
)
]

#heading(level: 1)[#strong[#text(" — 4. Dirichlet ")#mi("{L}")#text("-functions, Siegel’s theorem, and the prime number theorem in arithmetic progressions — ")]]

#text("We now extend the above theory of the Riemann zeta function to ")#link("http://en.wikipedia.org/wiki/Dirichlet_L-function")[#text("Dirichlet ")#mi("{L}")#text("-functions")]#text(" ")#mi("{L(s,\\chi)}")#text(", where ")#mi("{\\chi: {\\bf Z} \\rightarrow {\\bf C}}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Dirichlet_character")[#text("Dirichlet character")]#text(" of some period ")#mi("{q}")#text(". As already remarked in Remark ")#link(<tao-10c2d630409d5a4b8132>)[#text("1")]#text(", the theory of such functions is very similar to that of the zeta function, with the character ")#mi("{\\chi(n)}")#text(" being like a “non-Archimedean” counterpart of the “Archimedean” character ")#mi("{n^{it}}")#text(". However, there is one key new feature, which is that the behaviour near ")#mi("{s=1}")#text(" is not completely understood when ")#mi("{\\chi}")#text(" is a real character.")

#text("For ")#mi("{\\text{Re} s > 1}")#text(", the Dirichlet ")#mi("{L}")#text("-functions are defined as ")#mi("{L(s,\\chi) = {\\mathcal D} \\chi(s)}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("L(s,\\chi) := \\sum_n \\frac{\\chi(n)}{n^s}.")]]

#text("By the general theory of Dirichlet series, this is an analytic function on the half-space ")#mi("{\\{ s: \\text{Re}(s) > 1 \\}}")#text(". Since ")#mi("{\\delta = \\chi * (\\mu \\chi)}")#text(" and ")#mi("{L \\chi = \\chi * (\\Lambda \\chi)}")#text(", we then have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{L(s,\\chi)} := \\sum_n \\frac{\\mu(n) \\chi(n)}{n^s}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("-\\frac{L^{\\prime}(s,\\chi)}{L(s,\\chi)} := \\sum_n \\frac{\\Lambda(n) \\chi(n)}{n^s},")]]

#text("where the derivative is always understood to be with respect to the ")#mi("{s}")#text(" variable. In particular, we have the analogue of ")#link(<tao-303580c62f99c48c6140>)[#text("(11)")]#text(": ")#metadata(none) <tao-e1dbd650cbf504c1a56b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(45)")])
#tao-math("\\left|L(s,\\chi)\\right|, \\left|\\frac{1}{L(s,\\chi)}\\right|, \\left|\\frac{L^{\\prime}(s,\\chi)}{L(s,\\chi)}\\right| \\leq \\frac{1}{\\sigma-1} + O(1)", block: true)]]

#text(" whenever ")#mi("{s=\\sigma+it}")#text(" with ")#mi("{\\sigma > 1}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(". In particular, ")#mi("{L(s,\\chi)}")#text(" has no zeroes in the region ")#mi("{\\{ s: \\text{Re}(s) > 1 \\}}")#text(".")#linebreak()#text(" We also have the ")#link("http://en.wikipedia.org/wiki/Euler_product")[#text("Euler product")]

#align(center)[#tao-fit-display[#mitex("L(s,\\chi) = \\prod_p (1 -\\frac{\\chi(p)}{p^s})^{-1}.")]]

#text("If ")#mi("{\\chi}")#text(" is a principal character, thus ")#mi("{\\chi(n) = 1_{(n,q)=1}}")#text(", then we may compare this Euler product with the corresponding Euler product ")#mi("{\\zeta(s) = \\prod_p (1 - \\frac{1}{p^s})^{-1}}")#text(" of the Riemann zeta function, and conclude that ")#metadata(none) <tao-b965ae56a9d00cc7b34d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(46)")])
#mitex("L(s,\\chi) = \\zeta(s) \\prod_{p|q} (1 -\\frac{1}{p^s}).")]]

#text(" The product ")#mi("{\\prod_{p|q} (1 -\\frac{1}{p^s})}")#text(" extends analytically to the entire complex plane, and has no zeroes in the region ")#mi("{\\{\\text{Re}(s) > 0\\}}")#text(", so this ")#mi("{L}")#text("-function has a meromorphic extension to ")#mi("{\\{\\text{Re}(s) > 0 \\}}")#text(" with exactly the same zeroes and poles as ")#mi("{\\zeta}")#text(".")#linebreak()#text(" The more interesting situation occurs when ")#mi("{\\chi}")#text(" is non-principal. In particular, it has mean zero on every interval of length ")#mi("{q}")#text(". This gives a bound on slowly varying sums of ")#mi("{\\chi}")#text(" (cf. Lemma 71 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 44")]#text(" Let ")#mi("{\\chi}")#text(" be a non-principal Dirichlet character of period ")#mi("{q}")#text(", let ")#mi("{1 \\leq x < y}")#text(", and let ")#mi("{f: [x,y] \\rightarrow {\\bf C}}")#text(" be a continuously differentiable function. Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n < y} \\chi(n) f(n) \\ll q \\int_x^y |f^{\\prime}(t)|\\ dt + q |f(y)|.")]]

#text("If ")#mi("{\\chi}")#text(" is principal, show instead that")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n < y} \\chi(n) f(n) - \\frac{\\phi(q)}{q} \\int_x^y f(t)\\ dt \\ll q \\int_x^y |f^{\\prime}(t)|\\ dt + q |f(y)|.")]]
]

#text("Using this exercise, we see that ")#metadata(none) <tao-a4fd75a69c8148243ed0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(47)")])
#tao-math("\\sum_{x \\leq n < y} \\frac{\\chi(n)}{n^s} \\ll q \\frac{\\left|s\\right|}{\\sigma} x^{-\\sigma}", block: true)]]

#linebreak()#text(" whenever ")#mi("{s = \\sigma+it}")#text(" with ")#mi("{\\sigma > 0}")#text(". By Lemma 5 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(", we conclude that for any such ")#mi("{s}")#text(", there is a unique complex number ")#mi("{L(s,\\chi)}")#text(" such that ")#metadata(none) <tao-376bc6693a933b1cda34>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(48)")])
#tao-math("\\sum_{n < x} \\frac{\\chi(n)}{n^s} = L(s,\\chi) + O( q \\frac{\\left|s\\right|}{\\sigma} x^{-\\sigma} )", block: true)]]

#text(" for any ")#mi("{x > 0}")#text(". In particular, the partial sums ")#mi("{\\sum_{n \\leq x} \\frac{\\chi(n)}{n^s}}")#text(" converge locally uniformly to ")#mi("{L(s,\\chi)}")#text(" on the half-space ")#mi("{\\{ s: \\text{Re}(s) > 0 \\}}")#text(", and so ")#mi("{L(s,\\chi)}")#text(" is holomorphic on this region. This is similar to ")#mi("{\\zeta}")#text(", but with the key difference that there is no longer any pole at ")#mi("{s=1}")#text(".")#linebreak()#text(" Setting ")#mi("{x=1}")#text(" in ")#link(<tao-376bc6693a933b1cda34>)[#text("(48)")]#text(", we obtain the crude bound ")#metadata(none) <tao-46ef921f224e814b835d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(49)")])
#tao-math("L(s,\\chi) \\ll_\\varepsilon q (2+\\left|t\\right|)", block: true)]]

#linebreak()#text(" when ")#mi("{s=\\sigma+it}")#text(" with ")#mi("{\\sigma > \\varepsilon > 0}")#text(". Taking logarithms, we have")

#align(center)[#tao-fit-display[#tao-math("\\log \\left|L(s,\\chi)\\right| \\leq O_\\varepsilon( \\log(q (2+\\left|t\\right|)) ).", block: true)]]

#text("One can then repeat much of the arguments in Section ")#link(<tao-37b902a086b2a6a13707>)[#text("2")]#text(" with few changes (other than replacing logarithmic factors such as ")#tao-math("{\\log(2+\\left|t\\right|)}", block: false)#text(" with ")#tao-math("{\\log(q(2+\\left|t\\right|))}", block: false)#text(" instead, and removing the effect of a pole at ")#mi("{s=1}")#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 45")]#text(" ")#metadata(none) <tao-f0b8c9d84dd2b877e0b9>#text(" Let ")#mi("{\\chi}")#text(" be a non-principal character of period ")#mi("{q}")#text(".")

#list(
[#text("(i) (Crude upper bound on ")#mi("{L}")#text("-function zeroes) For any ")#mi("{\\varepsilon > 0}")#text(" and ")#mi("{t_0 \\in {\\bf R}}")#text(", show there are at most ")#tao-math("{O_\\varepsilon( \\log(q(2+\\left|t_0\\right|)) )}", block: false)#text(" zeroes of ")#mi("{L(\\cdot,\\chi)}")#text(" in the region ")#tao-math("{\\{ \\sigma+it: \\varepsilon \\leq \\sigma \\leq 1; \\left|t-t_0\\right| \\leq 1 \\}}", block: false)#text(". (As with ")#mi("{\\zeta}")#text(", zeroes of ")#mi("{L(\\cdot,\\chi)}")#text(" are always understood here to be counted with multiplicity.)")],
[#text("(ii) (Approximate formula for log-derivative of ")#mi("{L}")#text("-function) For any ")#mi("{C,\\varepsilon > 0}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("-\\frac{L^{\\prime}(s,\\chi)}{L(s,\\chi)} = -\\sum_{\\rho: \\left|s-\\rho\\right| \\leq \\varepsilon/2} \\frac{1}{s-\\rho} + O_{C,\\varepsilon}( \\log(q(2+\\left|t\\right|)) ),", block: true)]]

#text("whenever ")#mi("{s = \\sigma+it}")#text(" and ")#mi("{\\varepsilon \\leq \\sigma \\leq C}")#text(". Here and in the rest of this exercise, the sum is over the zeroes ")#mi("{\\rho}")#text(" of ")#mi("{L(s,\\chi)}")#text(".")],
[#text("(iii) (Local integrability of log-derivative) For any ")#mi("{C > \\varepsilon > 0}")#text(" and ")#mi("{t_0 \\in {\\bf R}}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\int_\\varepsilon^C \\int_{t_0-1}^{t_0+1} |\\frac{L^{\\prime}(\\sigma+it,\\chi)}{L(\\sigma+it,\\chi)}|\\ dt d\\sigma \\ll_{\\varepsilon,C} \\log(q(2+\\left|t_0\\right|)).", block: true)]]],
[#text("(iv) (Truncated twisted von Mangoldt explicit formula) For any ")#mi("{0 < \\varepsilon < 1}")#text(" and ")#mi("{x, T \\geq 2}")#text(", show that")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\leq x} \\Lambda(n) \\chi(n)  & = -\\sum_{\\rho: \\text{Re}(\\rho) \\geq \\varepsilon; \\left|\\text{Im}(\\rho)\\right| \\leq T} \\frac{x^\\rho}{\\rho}", block: true)



#tao-math(" & + O_\\varepsilon( x^\\varepsilon \\log^2(qT) + \\frac{x}{T} \\log^2(xqT) ).", block: true)
]

#text("(Compare with ")#link(<tao-72554af938a392166526>)[#text("(5)")]#text(".)")],
[#text("(v) (Smoothed twisted explicit formula) Let ")#mi("{g: {\\bf R} \\rightarrow {\\bf C}}")#text(" be a smooth, compactly supported function. Then for any ")#mi("{\\varepsilon>0}")#text(" and ")#mi("{x \\geq 2}")#text(", show that")

#tao-aligned(keep: true)[


#tao-math("\\sum_n \\Lambda(n) \\chi(n) g( \\log n - \\log x)  & = - \\sum_{\\rho: \\text{Re}(\\rho) > \\varepsilon} x^\\rho \\hat g(-i\\rho)", block: true)



#tao-math(" & + O_{g,\\varepsilon}( x^\\varepsilon \\log(2q) ),", block: true)
]

#text("with the sum on the right-hand side being absolutely convergent. (Again, compare with ")#link(<tao-72554af938a392166526>)[#text("(5)")]#text(".)")],
[#text("(vi) (Zero-free region controls twisted von Mangoldt summatory function) Let ")#mi("{T \\geq 2}")#text(" and ")#mi("{0 < \\delta \\leq 1/2}")#text(", and suppose that there are no zeroes ")#mi("{\\rho}")#text(" of ")#mi("{L(s,\\chi)}")#text(" in the rectangle ")#tao-math("{\\{ s: 1-\\delta < \\left|\\text{Re}(s)\\right| \\leq 1; \\left|\\text{Im}(s)\\right| \\leq T \\}}", block: false)#text(". Then show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) \\chi(n) = O( x^{1-\\delta} \\log^2(qT) ) + O( \\frac{x}{T} \\log^2(xqT) )")]]

#text("for all ")#mi("{x \\geq 2}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 46")]#text(" ")#metadata(none) <tao-1c5905e43a2c2d700497>#text(" Let ")#mi("{\\chi}")#text(" be a non-principal character of period ")#mi("{q}")#text(", and et ")#mi("{0 < \\delta \\leq 1/2}")#text(". Show that the following assertions are equivalent:")

#list(
[#text("(i) One has ")#mi("{\\sum_{n \\leq x} \\Lambda(n) \\chi(n) = O(x^{1-\\delta+o(1)})}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(".")],
[#text("(ii) One has ")#mi("{\\sum_{n \\leq x} \\Lambda(n) \\chi(n) = O(x^{1-\\delta} \\log^2(qx) )}")#text(" for all ")#mi("{x \\geq 2}")#text(".")],
[#text("(iii) All the zeroes ")#mi("{\\rho}")#text(" of ")#mi("{L(\\cdot,\\chi)}")#text(" have real part at most ")#mi("{1-\\delta}")#text(".")]
)
]

#text("Based on this exercise, it is now natural to ")#link("http://en.wikipedia.org/wiki/Generalized_Riemann_hypothesis")[#text("generalise the Riemann hypothesis")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 47 (Generalised Riemann hypothesis)")]#text(" Let ")#mi("{\\chi}")#text(" be a Dirichlet character. Then all the zeroes of ")#mi("{L(\\cdot,\\chi)}")#text(" have real part at most ")#mi("{1/2}")#text(".")
]

#text("Given that the Riemann hypothesis (RH) remains unsolved, the stronger assertion of the generalised Riemann hypothesis (GRH) is also unsolved. (But later on we will establish the ")#link("http://en.wikipedia.org/wiki/Bombieri%E2%80%93Vinogradov_theorem")[#text("Bombieri-Vinogradov theorem")]#text(", of major importance in sieve theory, which can be viewed as a kind of assertion that the generalised Riemann hypothesis holds “on average” in a certain technical sense.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 48")]#text(" ")#metadata(none) <tao-aaace08c7b6d523225fc>#text(" Assume the Generalised Riemann hypothesis. Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x: n = a\\ (q)} \\Lambda(n) = \\frac{x}{\\phi(q)} + O( x^{1/2} \\log^2(qx) )")]]

#text("for all primitive congruence classes ")#mi("{a\\ (q)}")#text(" and all ")#mi("{x \\geq 2}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 49 (Equivalent forms of twisted prime number theorem)")]#text(" ")#metadata(none) <tao-80c6d7616fea6c83d0bf>#text(" Let ")#mi("{\\chi}")#text(" be a non-principal Dirichlet character. Show that the following assertions are equivalent:")

#list(
[#text("(i) One has ")#mi("{\\sum_{n \\leq x} \\Lambda(n) \\chi(n) = o(x)}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(".")],
[#text("(ii) All the zeroes ")#mi("{\\rho}")#text(" of ")#mi("{L(\\cdot,\\chi)}")#text(" have real part strictly less than one.")]
)

#text("This exercise should be compared with the derivation of Dirichlet’s theorem (Theorem 70 from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(") from the non-vanishing of ")#mi("{L(1,\\chi)}")#text(" (Theorem 73 from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(").")
]

#text("Now we obtain zero-free regions for ")#mi("{L(s,\\chi)}")#text(" for a Dirichlet character ")#mi("{\\chi}")#text(" of period ")#mi("{q}")#text(". From the Mertens trigonometric inequality ")#link(<tao-c8e4d6016f4ab159371b>)[#text("(32)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\chi_0(n) - \\text{Re}(\\chi^2(n) n^{-2it}) \\leq 4 (\\chi_0(n) + \\text{Re}(\\chi(n) n^{-it}) ),")]]

#text("where ")#tao-math("{\\chi_0 := \\left|\\chi\\right|}", block: false)#text(" is the principal character of period ")#mi("{q}")#text("; equivalently, we have ")#metadata(none) <tao-c263ca4101c5d1efa048>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(50)")])
#mitex("3 \\chi_0(n) + 4 \\text{Re}(\\chi(n) n^{-it}) + \\text{Re}(\\chi^2(n) n^{-2it}) \\geq 0.")]]

#text(" Multiplying by ")#mi("{\\frac{\\Lambda(n)}{n^\\sigma}}")#text(" for some ")#mi("{\\sigma>1}")#text(" and summing, we obtain a twisted version of ")#link(<tao-50b8d2c3973594d74271>)[#text("(35)")]#text(", ")#metadata(none) <tao-7c7a496e42277562b842>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(51)")])
#mitex("- 3 \\frac{L^{\\prime}(\\sigma,\\chi_0)}{L(\\sigma,\\chi_0)} - 4 \\text{Re} \\frac{L^{\\prime}(\\sigma+it,\\chi)}{L(\\sigma+it,\\chi)} - \\text{Re} \\frac{L^{\\prime}(\\sigma+2it,\\chi^2)}{L(\\sigma+2it,\\chi^2)} \\geq 0")]]

#text(" for any ")#mi("{\\sigma > 1}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(". Integrating this in ")#mi("{t}")#text(" from ")#mi("{t=+\\infty}")#text(" gives a twisted version of ")#link(<tao-cb7bf562420b82e97ee1>)[#text("(36)")]#text(": ")#metadata(none) <tao-b97431eaa63224debeb1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(52)")])
#tao-math("\\left|L(\\sigma,\\chi_0)\\right|^3 \\left|L(\\sigma+it,\\chi)\\right|^4 \\left|L(\\sigma+2it,\\chi^2)\\right|^2 \\geq 1.", block: true)]]

#linebreak()#text(" We can now strengthen Dirichlet’s theorem (Theorem 65 from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 50 (Prime number theorem in arithmetic progressions)")]

#list(
[#text("(i) For any Dirichlet character ")#mi("{\\chi}")#text(", show that ")#mi("{L(\\cdot,\\chi)}")#text(" has no zeroes on the line ")#mi("{\\{1+it: t \\in {\\bf R}\\}}")#text(". (You will need Theorem 73 from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(" to deal with the ")#mi("{t=0}")#text(" case.)")],
[#text("(ii) For any primitive residue class ")#mi("{a\\ (q)}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x: n = a\\ (q)} \\Lambda(n) = \\frac{x}{\\phi(q)} + o(x)")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(" (keeping ")#mi("{a}")#text(" and ")#mi("{q}")#text(" fixed). (The decay rate in the ")#mi("{o()}")#text(" notation may depend on ")#mi("{a}")#text(" and ")#mi("{q}")#text(".)")],
[#text("(iii) For any primitive residue class ")#mi("{a\\ (q)}")#text(", show that the number of primes in ")#mi("{a\\ (q)}")#text(" less than ")#mi("{x}")#text(" is ")#mi("{\\frac{x}{\\phi(q) \\log x} + o(\\frac{x}{\\log x})}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(" (keeping ")#mi("{a}")#text(" and ")#mi("{q}")#text(" fixed).")]
)
]

#text("Next, we obtain the analogue of the classical zero-free region (Proposition ")#link(<tao-9a639003b35ec01545e2>)[#text("38")]#text("), though with an important exception due to the lack of control near ")#mi("{s=1}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 51 (Classical zero-free region for ")#mi("{L}")#text("-functions)")]#text(" ")#metadata(none) <tao-998cf155a250e5c2556b>#text(" There exists an absolute constant ")#mi("{c>0}")#text(" such that, for any Dirichlet character ")#mi("{\\chi}")#text(" of period ")#mi("{q}")#text(", there are no zeroes of ")#mi("{L(\\cdot,\\chi)}")#text(" in the region")

#align(center)[#tao-fit-display[#tao-math("\\{ \\beta+it: \\beta > 1 - \\frac{c}{\\log(q(2+\\left|t\\right|))} \\}", block: true)]]

#text("with the possible exception of a single real zero ")#mi("{1 - \\frac{c}{\\log(2q)} < \\beta < 1}")#text(" (which we refer to as an ")#emph[#text("exceptional zero")]#text(" or ")#emph[#text("Siegel zero")]#text("). The exceptional zero can only occur if ")#mi("{\\chi}")#text(" is a non-principal real character.")
]

#emph[#text("Proof:")]#text(" We may assume that ")#mi("{\\chi}")#text(" is non-principal, since otherwise the claim follows from Proposition ")#link(<tao-9a639003b35ec01545e2>)[#text("38")]#text(". In particular, ")#mi("{q \\geq 2}")#text(".")

#text("Let ")#mi("{c_1>0}")#text(" be a small constant to be chosen later, and let ")#mi("{c>0}")#text(" be sufficiently small depending on ")#mi("{c_1}")#text(".")

#text("First suppose that ")#mi("{\\chi}")#text(" is a complex character, so that ")#mi("{\\chi^2}")#text(" is non-principal. Suppose first that we have ")#mi("{L(\\beta+it,\\chi)=0}")#text(" for some ")#mi("{t \\in {\\bf R}}")#text(" and ")#tao-math("{\\beta > 1 - \\frac{c}{\\log(q(2+\\left|t\\right|)}}", block: false)#text(". From Exercise ")#link(<tao-f0b8c9d84dd2b877e0b9>)[#text("45")]#text("(ii) and taking real parts, we have")

#align(center)[#tao-fit-display[#tao-math("- \\text{Re} \\frac{L^{\\prime}(\\sigma+it,\\chi)}{L(\\sigma+it,\\chi)} \\leq - \\frac{1}{\\sigma-\\beta} + O( \\log(q(2+\\left|t\\right|)) )", block: true)]]

#text("for any ")#mi("{1 < \\sigma < 2}")#text(". Similarly, because ")#mi("{\\chi^2}")#text(" is non-principal, we have")

#align(center)[#tao-fit-display[#tao-math("- \\text{Re} \\frac{L^{\\prime}(\\sigma+2it,\\chi^2)}{L(\\sigma+2it,\\chi^2)} \\leq O( \\log(q(2+\\left|t\\right|)) )", block: true)]]

#text("while from ")#link(<tao-e1dbd650cbf504c1a56b>)[#text("(45)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("- \\text{Re} \\frac{L^{\\prime}(\\sigma,\\chi_0)}{L(\\sigma,\\chi_0)} \\leq \\frac{1}{\\sigma-1} + O( 1 ).")]]

#text("Applying ")#link(<tao-7c7a496e42277562b842>)[#text("(51)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\frac{3}{\\sigma-1} - \\frac{4}{\\sigma-\\beta} \\geq -O( \\log(q(2+\\left|t\\right|) ).", block: true)]]

#text("Setting ")#mi("{\\sigma = 1 + C(1-\\beta)}")#text(" for (say) ")#mi("{C=4}")#text(", we obtain a contradiction with ")#mi("{c}")#text(" small enough. This completes the proof of the proposition when ")#mi("{\\chi}")#text(" is complex.")#linebreak()#text(" Now suppose that ")#mi("{\\chi}")#text(" is a real character, so that ")#mi("{\\chi^2 = \\chi_0}")#text(". We can adapt the previous argument, but need a new tool to estimate ")#mi("{- \\text{Re} \\frac{L^{\\prime}(\\sigma+2it,\\chi^2)}{L(\\sigma+2it,\\chi^2)}}")#text(". By ")#link(<tao-b965ae56a9d00cc7b34d>)[#text("(46)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("- \\text{Re} \\frac{L^{\\prime}(\\sigma+2it,\\chi^2)}{L(\\sigma+2it,\\chi^2)} = -\\text{Re} \\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma+2it) - \\sum_{p|q} \\frac{\\log p}{p^{\\sigma+2it}-1}.")]]

#text("We crudely bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{p|q} \\frac{\\log p}{p^{\\sigma+2it}-1} = O( \\sum_{p|q} \\log p ) = O( \\log q )")]]

#text("and then apply Proposition ")#link(<tao-917adf1964c277211266>)[#text("19")]#text(" and take real parts to conclude that")

#align(center)[#tao-fit-display[#tao-math("- \\text{Re} \\frac{L^{\\prime}(\\sigma+2it,\\chi^2)}{L(\\sigma+2it,\\chi^2)} \\leq \\text{Re} \\frac{1}{\\sigma+2it-1} + O( \\log(q(2+\\left|t\\right|)) ).", block: true)]]

#text("Applying ")#link(<tao-7c7a496e42277562b842>)[#text("(51)")]#text(" as before, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\frac{3}{\\sigma-1} - \\frac{4}{\\sigma-\\beta} + \\text{Re} \\frac{1}{\\sigma+2it-1} \\geq -O( \\log(q(2+\\left|t\\right|) ).", block: true)]]

#text("As before, we set ")#mi("{\\sigma := 1+4(1-\\beta)}")#text(" and conclude that")

#align(center)[#tao-fit-display[#tao-math("-\\frac{1}{20(1-\\beta)} + \\text{Re} \\frac{1}{4(1-\\beta)+2it} \\geq -O( \\log(q(2+\\left|t\\right|) ).", block: true)]]

#text("If ")#tao-math("{\\left|t\\right| \\geq \\frac{c_1}{\\log q}}", block: false)#text(", then ")#tao-math("{\\left|t\\right| \\geq 100(1-\\beta)}", block: false)#text(" (say) if ")#mi("{c}")#text(" is small enough, leading again to a contradiction. Thus the only remaining case is when ")#mi("{\\chi}")#text(" is real and ")#tao-math("{\\left|t\\right| < \\frac{c_1}{\\log q}}", block: false)#text(".")#linebreak()#text(" We now show that there is at most one zero of ")#mi("{L(s,\\chi)}")#text(" in the region ")#tao-math("{\\{ \\beta+it: \\left|t\\right| \\leq \\frac{c_1}{\\log q}; \\beta > 1 - \\frac{c}{\\log(q(2+\\left|t\\right|))} \\}}", block: false)#text(". If there are two such zeroes ")#mi("{\\beta_1+it_1, \\beta_2+it_2}")#text(", then from Exercise ")#link(<tao-f0b8c9d84dd2b877e0b9>)[#text("45")]#text("(ii) and taking real parts we have")

#align(center)[#tao-fit-display[#mitex("- \\text{Re} \\frac{L^{\\prime}(\\sigma,\\chi)}{L(\\sigma,\\chi)} \\leq - \\text{Re} \\frac{1}{\\sigma-\\beta_1-it_1} - \\text{Re} \\frac{1}{\\sigma-\\beta_2-it_2} + O( \\log q );")]]

#text("comparing this with ")#link(<tao-e1dbd650cbf504c1a56b>)[#text("(45)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\text{Re} \\frac{1}{\\sigma-\\beta_1-it_1} + \\text{Re} \\frac{1}{\\sigma-\\beta_2-it_2} \\leq \\frac{1}{\\sigma-1} + O(\\log q).")]]

#text("If we set ")#mi("{\\sigma = 1 + 100 \\frac{c_1}{\\log q}}")#text(" (say), we obtain a contradiction if ")#mi("{c_1}")#text(" is small enough.")#linebreak()#text(" As ")#mi("{\\chi}")#text(" is real, we have the conjugation symmetry")

#align(center)[#tao-fit-display[#mitex("L(\\overline{s},\\chi) = \\overline{L(s,\\chi)},")]]

#text("and so if ")#mi("{\\beta+it}")#text(" is a zero of ")#mi("{L(s,\\chi)}")#text(", then ")#mi("{\\beta-it}")#text(" is one also. Thus there can be no strictly complex zeroes in the region ")#tao-math("{\\{ \\beta+it: \\left|t\\right| \\leq \\frac{c_1}{\\log q}; \\beta > 1 - \\frac{c}{\\log(q(2+\\left|t\\right|))} \\}}", block: false)#text(", and at most one real zero; and the claim follows. (From Theorem 73 from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(", ")#mi("{\\beta}")#text(" cannot equal ")#mi("{1}")#text(", and from ")#link(<tao-e1dbd650cbf504c1a56b>)[#text("(45)")]#text(" there are no zeroes to the right of ")#mi("{1}")#text(".) ")#mi("\\Box")#linebreak()#text(" The exceptional zero ")#mi("{\\beta}")#text(" in the above theorem is quite a nuisance; if one believes in the generalised Riemann hypothesis, it should not exist, but frustratingly, we have not been able to completely exclude this zero from occurring. However, there is an important ")#emph[#text("repulsion phenomenon")]#text(" (known as the ")#link("http://en.wikipedia.org/wiki/Deuring%E2%80%93Heilbronn_phenomenon")[#text("Deuring-Heilbronn repulsion phenomenon")]#text("), that asserts (roughly speaking) that the existence of one exceptional zero tends to repel away other exceptional zeroes. We already saw one instance of this phenomenon when proving Proposition ")#link(<tao-998cf155a250e5c2556b>)[#text("51")]#text(", when we showed that a single character ")#mi("{\\chi}")#text(" could not have two or more exceptional zeroes. Another instance appeared in Proposition 76 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(".")

#text("To state the repulsion phenomenon more precisely, we have to exclude a degenerate case, coming from the fact that if one multiplies a Dirichlet character ")#mi("{\\chi}")#text(" (of some modulus ")#mi("{q}")#text(") by a principal character ")#mi("{\\chi^{\\prime}_0}")#text(" (of some modulus ")#mi("{q^{\\prime}}")#text("), then the resulting Dirichlet character ")#mi("{\\chi \\chi^{\\prime}_0}")#text(" (which has modulus ")#mi("{[q,q^{\\prime}]}")#text(") has essentially the same ")#mi("{L}")#text("-function as ")#mi("{\\chi}")#text(", as ")#mi("{L(s,\\chi\\chi^{\\prime}_0)}")#text(" and ")#mi("{L(s,\\chi)}")#text(" differ by a finite number of Euler factors (as in ")#link(<tao-b965ae56a9d00cc7b34d>)[#text("(46)")]#text("), and so the two ")#mi("{L}")#text("-functions have an identical set of zeroes in the region ")#mi("{\\{ s: \\text{Re}(s) > 0\\}}")#text(". To avoid this problem, let us call a Dirichlet character ")#mi("{\\chi}")#text(" of modulus ")#mi("{q}")#text(" ")#emph[#text("primitive")]#text(" if it cannot be factored as ")#mi("{\\chi = \\chi^{\\prime} \\chi^{\\prime\\prime}_0}")#text(", where ")#mi("{\\chi^{\\prime\\prime}_0}")#text(" is a principal character and ")#mi("{\\chi^{\\prime}}")#text(" is a character of modulus strictly less than ")#mi("{q}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 52")]#text(" ")#metadata(none) <tao-caf4a6af6d6b6773be9e>

#list(
[#text("(i) Show that every Dirichlet character ")#mi("{\\chi}")#text(" of modulus ")#mi("{q}")#text(" can be factored as ")#mi("{\\chi = \\chi^{\\prime} \\chi^{\\prime\\prime}_0}")#text(", where ")#mi("{\\chi^{\\prime}}")#text(" is a primitive character of some modulus ")#mi("{q^{\\prime}}")#text(" (known as the ")#link("http://en.wikipedia.org/wiki/Dirichlet_character#Primitive_characters_and_conductor")[#text("conductor")]#text(" of ")#mi("{\\chi}")#text(") and ")#mi("{\\chi^{\\prime\\prime}_0}")#text(" is a principal character whose modulus ")#mi("{q^{\\prime\\prime}}")#text(" is squarefree and coprime to ")#mi("{q^{\\prime}}")#text(". Furthermore, ")#mi("{q^{\\prime}q^{\\prime\\prime}}")#text(" divides ")#mi("{q}")#text(", and ")#mi("{\\chi}")#text(" is real if and only if ")#mi("{\\chi^{\\prime}}")#text(" is real; and even if one drops the requirements that ")#mi("{q^{\\prime\\prime}}")#text(" is squarefree and coprime to ")#mi("{q^{\\prime}}")#text(" then ")#mi("{\\chi^{\\prime}}")#text(" is still uniquely determined by ")#mi("{\\chi}")#text(". Thus we see that to understand the zeroes of Dirichlet ")#mi("{L}")#text("-functions ")#mi("{L(\\cdot,\\chi)}")#text(", it suffices to do so for the primitive characters.")],
[#text("(ii) Let ")#mi("{\\chi, \\chi^{\\prime}}")#text(" be primitive Dirichlet characters. Show that ")#mi("{\\chi \\overline{\\chi^{\\prime}}}")#text(" is a principal character if and only if ")#mi("{\\chi=\\chi^{\\prime}}")#text(".")]
)
]

#text("Here is one standard manifestation of the repulsion phenomenon:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 53 (Landau’s theorem)")]#text(" ")#metadata(none) <tao-97d9f3fc4250bf823a70>#text(" There is an absolute constant ")#mi("{c>0}")#text(" with the following property: whenever ")#mi("{\\chi,\\chi^{\\prime}}")#text(" are two distinct real primitive characters of conductor ")#mi("{q,q^{\\prime}}")#text(" respectively, there is at most one real zero ")#mi("{\\beta}")#text(" of ")#mi("{L(s,\\chi)}")#text(" or ")#mi("{L(s,\\chi^{\\prime})}")#text(" with ")#mi("{\\beta > 1 - \\frac{c}{\\log(qq^{\\prime})}}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{c>0}")#text(" be sufficiently small. If the claim failed, then (since each ")#mi("{L}")#text("-function has at most one exceptional zero) we can find ")#mi("{\\beta, \\beta^{\\prime} > 1 - \\frac{c}{\\log(qq^{\\prime})}}")#text(" such that ")#mi("{L(\\beta,\\chi)=L(\\beta^{\\prime},\\chi^{\\prime})=0}")#text(".")

#text("In previous arguments, one used the inequality ")#link(<tao-c263ca4101c5d1efa048>)[#text("(50)")]#text(". Here, we will instead use the inequality")

#align(center)[#tao-fit-display[#mitex("(1+\\chi(n)) (1+\\chi^{\\prime}(n)) \\geq 0")]]

#text("which we expand as")

#align(center)[#tao-fit-display[#mitex("1 + \\chi(n) + \\chi^{\\prime}(n) + \\chi(n) \\chi^{\\prime}(n) \\geq 0.")]]

#text("Multiplying by ")#mi("{\\frac{\\Lambda(n)}{n^\\sigma}}")#text(" for some ")#mi("{1 < \\sigma < 2}")#text(" and summing, we conclude that")

#align(center)[#tao-fit-display[#mitex("- \\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma) - \\frac{L^{\\prime}(\\sigma,\\chi)}{L(\\sigma,\\chi)} - \\frac{L^{\\prime}(\\sigma,\\chi^{\\prime})}{L(\\sigma,\\chi^{\\prime})} - \\frac{L^{\\prime}(\\sigma,\\chi\\chi^{\\prime})}{L(\\sigma,\\chi\\chi^{\\prime})} \\geq 0.")]]

#text("(We do not need to take real parts here, as everything in sight is already real.) From ")#link(<tao-aac42276f4f8225d94b4>)[#text("(13)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("- \\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma) = \\frac{1}{\\sigma-1} + O(1),")]]

#text("and from Exercise ")#link(<tao-f0b8c9d84dd2b877e0b9>)[#text("45")]#text("(ii) we have")

#align(center)[#tao-fit-display[#mitex("- \\frac{L^{\\prime}(\\sigma,\\chi)}{L(\\sigma,\\chi)} \\leq - \\frac{1}{\\sigma-\\beta} + O( \\log q )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("- \\frac{L^{\\prime}(\\sigma,\\chi^{\\prime})}{L(\\sigma,\\chi^{\\prime})} \\leq - \\frac{1}{\\sigma-\\beta^{\\prime}} + O( \\log q^{\\prime} ).")]]

#text("By Exercise ")#link(<tao-caf4a6af6d6b6773be9e>)[#text("52")]#text("(ii), ")#mi("{\\chi\\chi^{\\prime}}")#text(" is a non-principal character of modulus at most ")#mi("{qq^{\\prime}}")#text(", and so from Exercise ")#link(<tao-f0b8c9d84dd2b877e0b9>)[#text("45")]#text("(ii) again we have")

#align(center)[#tao-fit-display[#mitex("- \\frac{L^{\\prime}(\\sigma,\\chi\\chi^{\\prime})}{L(\\sigma,\\chi\\chi^{\\prime})} \\leq O( \\log q^{\\prime} ).")]]

#text("Putting all this together, we see that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\sigma-1} - \\frac{1}{\\sigma-\\beta} - \\frac{1}{\\sigma-\\beta^{\\prime}} \\geq -O( \\log(qq^{\\prime}) ).")]]

#text("Setting ")#mi("{\\sigma := 1 + \\frac{100 c}{\\log(qq^{\\prime})}}")#text(", we obtain a contradiction if ")#mi("{c}")#text(" is small enough. ")#mi("\\Box")#linebreak()#text(" This gives a variant of Proposition ")#link(<tao-998cf155a250e5c2556b>)[#text("51")]#text(", in which the zero-free region is reduced slightly, but there is only one primitive character that has an exceptional zero:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 54 (Page’s theorem)")]#text(" Let ")#mi("{Q \\geq 2}")#text(". Show that for each primitive character ")#mi("{\\chi}")#text(" of conductor at most ")#mi("{Q}")#text(", the ")#mi("{L}")#text("-function ")#mi("{L(s,\\chi)}")#text(" has a zero-free region of the form ")#tao-math("{\\{ \\sigma+it: t \\in {\\bf R}, \\sigma \\geq 1 - \\frac{c}{\\log(Q(2+\\left|t\\right|))} \\}}", block: false)#text(" for some absolute constant ")#mi("{c>0}")#text(", with the possible exception of a ")#emph[#text("single")]#text(" real zero ")#mi("{\\beta}")#text(" by a ")#emph[#text("single")]#text(" primitive real character ")#mi("{\\chi_*}")#text(" of modulus at most ")#mi("{Q}")#text(".")
]

#text("We will refer to Landau’s theorem and Page’s theorem collectively as the ")#emph[#text("Landau-Page theorem")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 55 (Prime number theorem in arithmetic progressions with classical error term)")]#text(" ")#metadata(none) <tao-18b1ea4945c713912b23>#text(" Let ")#mi("{c > 0}")#text(" be a sufficiently small quantity, and let ")#mi("{q}")#text(" be a natural number.")

#list(
[#text("(i) If ")#mi("{\\chi_0}")#text(" is the principal Dirichlet character modulo ")#mi("{q}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) \\chi_0(n) = x + O( x \\exp( - c \\sqrt{\\log x} ) )")]]

#text("if ")#mi("{x \\geq 2}")#text(" and ")#mi("{q \\leq \\exp( c \\sqrt{\\log x} )}")#text(".")],
[#text("(ii) If ")#mi("{\\chi}")#text(" is a non-principal Dirichlet character modulo ")#mi("{q}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) \\chi(n) = -\\frac{x^\\beta}{\\beta} + O( x \\exp( - c \\sqrt{\\log x} ) )")]]

#text("if ")#mi("{x \\geq 2}")#text(", ")#mi("{q \\leq \\exp(c \\sqrt{\\log x})}")#text(" and ")#mi("{\\chi}")#text(" has an exceptional zero ")#mi("{\\beta}")#text(" (which, for this current exercise, means a zero of ")#mi("{L(s,\\chi)}")#text(" with ")#mi("{\\beta \\geq 1 - \\frac{c}{\\log q}}")#text("). If ")#mi("{\\chi}")#text(" has no exceptional zero, then the ")#mi("{\\frac{x^\\beta}{\\beta}}")#text(" term should be deleted; this is for instance the case when ")#mi("{\\chi}")#text(" is complex.")],
[#text("(iii) If ")#mi("{a\\ (q)}")#text(" is a primitive residue class modulo ")#mi("{q}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x: n = a\\ (q)} \\Lambda(n) = \\frac{x}{\\phi(q)} - \\frac{\\chi(a)}{\\phi(q)} \\frac{x^\\beta}{\\beta} + O( x \\exp( - c \\sqrt{\\log x} ) )")]]

#text("if ")#mi("{x \\geq 2}")#text(", ")#mi("{q \\leq \\exp(c \\sqrt{\\log x})}")#text(", where ")#mi("{\\chi}")#text(" is a real non-principal character of modulus ")#mi("{q}")#text(" with an exceptional zero ")#mi("{\\beta}")#text(". (Note from Page’s theorem that there is at most one such character for a given ")#mi("{q}")#text(", if ")#mi("{c}")#text(" is small enough.) This character ")#mi("{\\chi}")#text(" will be called the ")#emph[#text("exceptional character")]#text(". If there is no exceptional character, the term ")#mi("{\\frac{\\chi(a)}{\\phi(q)} \\frac{x^\\beta}{\\beta}}")#text(" should be deleted.")]
)

#text("(Note: the constant ")#mi("{c}")#text(" may need to be smaller in (iii) than it needs to be for (i) or (ii).)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 56")]#text(" Informally, the prime number theorem in arithmetic progressions asserts that the primes ")#mi("{p}")#text(" are equidistributed in the primitive residue classes modulo ")#mi("{q}")#text(" for ")#mi("{\\log p \\gg \\log^2 q}")#text(", unless there is an exceptional character ")#mi("{\\chi}")#text(" with exceptional zero ")#mi("{\\beta}")#text(", in which case the primes ")#mi("{p}")#text(" are more or less equidistributed in the primitive residue classes ")#mi("{a\\ (q)}")#text(" with ")#mi("{\\chi(a)=-1}")#text(" if ")#mi("{\\log^2 q \\ll \\log p \\ll \\frac{1}{1-\\beta}}")#text(", and then become equidistributed in all the primitive residue classes modulo ")#mi("{a\\ (q)}")#text(" for ")#mi("{\\log p \\gg \\max( \\log^2 q, \\frac{1}{1-\\beta} )}")#text(".")
]

#text("The Landau-Page theorem is good at eliminating exceptional zeroes in a power range such as ")#mi("{[Q,Q^C]}")#text(" for any fixed ")#mi("{C}")#text(", as it prevents more than a single primitive real character ")#mi("{\\chi}")#text(" of conductor ")#mi("{q}")#text(" in this range having an exceptional zero ")#mi("{\\beta}")#text(" with ")#mi("{\\beta \\geq 1 - \\frac{c}{C \\log q}}")#text(" for an absolute constant ")#mi("{c>0}")#text(". However, it loses control of exceptional zeroes in wider ranges than this. For instance, the Landau-Page theorem does not prevent the existence of an infinite sequence of exceptional real primitive characters ")#mi("{\\chi_n}")#text(" whose conductor ")#mi("{q_n}")#text(" grows very rapidly in ")#mi("{n}")#text(" (e.g. ")#mi("{q_n \\sim \\exp(\\exp(100^n))}")#text("), and with each ")#mi("{\\chi_n}")#text(" having an exceptional zero ")#mi("{\\beta_n}")#text(" that converges very quickly to ")#mi("{1}")#text(", e.g. ")#mi("{1- \\beta_n \\sim q_n^{-10}}")#text(".")

#text("Fortunately we have another way to exploit the repulsion phenomenon even for characters of widely separated modulus. To develop this aspect of the repulsion phenomenon, we first need to establish a link between exceptional zeroes, and exceptionally small values of ")#mi("{L(1,\\chi)}")#text(". We first give one direction of this link:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 57 (Exceptional zero implies small ")#mi("{L(1,\\chi)}")#text(")")]#text(" ")#metadata(none) <tao-784a2ddf5d4d61b6ae15>#text(" Suppose that ")#mi("{\\chi}")#text(" is a real non-principal character of modulus ")#mi("{q}")#text(" whose ")#mi("{L}")#text("-function ")#mi("{L(s,\\chi)}")#text(" has a real zero ")#mi("{\\beta}")#text(" with ")#mi("{\\beta \\geq 1 - O(\\frac{1}{\\log q})}")#text(". Then ")#mi("{L(1,\\chi) \\ll (\\log^2 q) (1-\\beta)}")#text(".")
]

#emph[#text("Proof:")]#text(" From ")#link(<tao-376bc6693a933b1cda34>)[#text("(48)")]#text(" with ")#mi("{x=q}")#text(" and ")#mi("{s = 1 + O(\\frac{1}{\\log q})}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("L(s,\\chi) = \\sum_{n < q} \\frac{\\chi(n)}{n^s} + O( 1 )")]]

#text("which on bounding ")#tao-math("{\\left|\\chi(n)\\right| \\leq 1}", block: false)#text(" and ")#mi("{\\frac{1}{n^s} = O( \\frac{1}{n} )}")#text(" gives ")#metadata(none) <tao-7937c4dc4579bfc7c37b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(53)")])
#mitex("L(s,\\chi) = O( \\log q )")]]

#text(" for ")#mi("{s = 1 + O( \\frac{1}{\\log q} )}")#text(". From the generalised Cauchy integral formula (Exercise 9 of ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text("), we thus have")

#align(center)[#tao-fit-display[#mitex("L^{\\prime}(s,\\chi) = O( \\log^2 q )")]]

#text("for ")#mi("{s = 1 + O( \\frac{1}{\\log q} )}")#text(". Since ")#mi("{L(\\beta,\\chi)=0}")#text(", the claim now follows from the fundamental theorem of calculus. ")#mi("\\Box")#linebreak()#text(" To go in the opposite direction, we will borrow a trick from the proof of the non-vanishing of ")#mi("{L(1,\\chi)}")#text(" (Theorem 73 from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(") and exploit the positivity ")#metadata(none) <tao-7160f8688035138fcbc9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(54)")])
#mitex("1 * \\chi(n) \\geq 1_{n=1}")]]

#linebreak()#text(" to understand the sums")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{1 * \\chi(n)}{n^s}")]]

#text("for various choices of ")#mi("{s}")#text(" and ")#mi("{x}")#text(". The key estimate is the following (compare with ")#link(<tao-0919bc672bbdc06fb07c>)[#text("(21)")]#text(" or ")#link(<tao-376bc6693a933b1cda34>)[#text("(48)")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 58")]#text(" ")#metadata(none) <tao-094a367b026246fb6464>#text(" Let ")#mi("{\\chi}")#text(" be a real non-principal character of modulus ")#mi("{q}")#text(", and let ")#mi("{1/2 \\leq s < 1}")#text(" be a real number. Establish the bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{1*\\chi(n)}{n^s} = \\zeta(s) L(s,\\chi) + \\frac{x^{1-s}}{1-s} L(1,\\chi) + O( \\frac{q}{1-s} x^{1/2-s} )")]]

#text("for any ")#mi("{x \\geq 1}")#text(". (")#emph[#text("Hint:")]#text(" use the Dirichlet hyperbola method and ")#link(<tao-0919bc672bbdc06fb07c>)[#text("(21)")]#text(", ")#link(<tao-376bc6693a933b1cda34>)[#text("(48)")]#text(", ")#link(<tao-8f763e7fd9431f359dea>)[#text("(24)")]#text(".) For an additional challenge, see if you can establish this estimate (possibly with a slightly weaker error term) by using the truncated Perron formula and contour shifting (bearing in mind that ")#mi("{1 * \\chi(n)}")#text(" is only bounded by ")#mi("{O(n^{o(1)})}")#text(" rather than by ")#mi("{O( \\log(2+n))}")#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 59 (Small ")#mi("{L(1,\\chi)}")#text(" implies exceptional zero)")]#text(" ")#metadata(none) <tao-05719c23f281c3f9af4a>#text(" Suppose that ")#mi("{\\chi}")#text(" is a real non-principal character of modulus ")#mi("{q}")#text(" such that ")#mi("{L(1,\\chi) \\leq \\frac{c}{\\log q}}")#text(" for some sufficiently small absolute constant ")#mi("{c}")#text(". Then there is a real zero ")#mi("{\\beta}")#text(" of ")#mi("{L(s,\\chi)}")#text(" with ")#mi("{\\beta \\geq 1 - O( L(1,\\chi) )}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{s := 1 - C L(1,\\chi)}")#text(" for some large absolute constant ")#mi("{C}")#text(", and let ")#mi("{c}")#text(" be sufficiently small depending on ")#mi("{C}")#text(", thus ")#mi("{s = 1 - O(c/\\log q)}")#text(" (recall that ")#mi("{L(1,\\chi)}")#text(" is positive), and so ")#mi("{1/2 \\leq s < 1}")#text(" if ")#mi("{c}")#text(" is small enough. From ")#link(<tao-7160f8688035138fcbc9>)[#text("(54)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{1 * \\chi(n)}{n^s} \\geq 1,")]]

#text("for any ")#mi("{x \\geq 1}")#text(" and so from Exercise ")#link(<tao-094a367b026246fb6464>)[#text("58")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("1 \\leq \\zeta(s) L(s,\\chi) + \\frac{x^{C L(1,\\chi)}}{C} + O( x^{-1/4} q / L(1,\\chi) )")]]

#text("(say). Setting ")#mi("{x = q^{10} / L(1,\\chi)^{10}}")#text(" (say), we conclude that")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) L(s,\\chi) \\geq \\frac{1}{2}")]]

#text("if ")#mi("{C}")#text(" is large enough and ")#mi("{c}")#text(" is small enough. By ")#link(<tao-8f763e7fd9431f359dea>)[#text("(24)")]#text(", ")#mi("{\\zeta(s)}")#text(" is negative. Thus, ")#mi("{L(s,\\chi) < 0}")#text(", and so by the intermediate value theorem there must be a zero ")#mi("{\\beta}")#text(" of ")#mi("{L(\\cdot,\\chi)}")#text(" between ")#mi("{s}")#text(" and ")#mi("{1}")#text(", and the claim follows. ")#mi("\\Box")#linebreak()#text(" Now suppose we have two distinct real primitive characters ")#mi("{\\chi, \\chi^{\\prime}}")#text(" of modulus ")#mi("{q, q^{\\prime}}")#text(" respectively, so that ")#mi("{\\chi\\chi^{\\prime}}")#text(" is also a real non-principal character of modulus at most ")#mi("{qq^{\\prime}}")#text(". As in the proof of the Landau-Page theorem, we have the non-negativity")

#align(center)[#tao-fit-display[#mitex("1 + \\chi(n) + \\chi^{\\prime}(n) + \\chi(n) \\chi^{\\prime}(n) \\geq 0.")]]

#text("We will instead exploit the multiplicative version of this non-negativity:")

#align(center)[#tao-fit-display[#mitex("1 * \\chi * \\chi^{\\prime} * \\chi\\chi^{\\prime}(n) \\geq 1_{n=1}.")]]

#text("The latter bound can be deduced from the former after using the formal identity")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{1 * \\chi * \\chi^{\\prime} * \\chi\\chi^{\\prime}(n)}{n^s} = \\exp( \\sum_n \\frac{\\Lambda(n)}{\\log n} \\frac{1 + \\chi(n) + \\chi^{\\prime}(n) + \\chi(n) \\chi^{\\prime}(n)}{n^s} )")]]

#text("that comes from the identity")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\chi(n)}{n^s} = \\exp( \\sum_n \\frac{\\Lambda(n) \\chi(n)}{n^s \\log n} )")]]

#text("valid for all characters ")#mi("{\\chi}")#text(" (cf. (28) from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text("); it can also be verified directly. In particular, we have ")#metadata(none) <tao-76878f1d2b881ee5cf98>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(55)")])
#mitex("\\sum_{n \\leq x} \\frac{1*\\chi*\\chi^{\\prime}*\\chi\\chi^{\\prime}(n)}{n^s} \\geq 1")]]

#text(" for any ")#mi("{x \\geq 1}")#text(" and ")#mi("{0 < s < 1}")#text(". Meanwhile, one has the following variant of Exercise ")#link(<tao-094a367b026246fb6464>)[#text("58")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 60")]#text(" ")#metadata(none) <tao-3f1bbc8f6d673cb326c9>#text(" Let ")#mi("{\\chi,\\chi^{\\prime}}")#text(" be distinct real primitive characters of modulus ")#mi("{q}")#text(", ")#mi("{q^{\\prime}}")#text(" respectively, and let ")#mi("{1-c < s < 1}")#text(" for some sufficiently small absolute constant ")#mi("{c>0}")#text(". Establish the bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{1*\\chi*\\chi^{\\prime}*\\chi\\chi^{\\prime}(n)}{n^s} = \\zeta(s) L(s,\\chi) L(s,\\chi^{\\prime}) L(s,\\chi\\chi^{\\prime}) +")]]

#align(center)[#tao-fit-display[#mitex("\\frac{x^{1-s}}{1-s} L(1,\\chi) L(1,\\chi^{\\prime}) L(1,\\chi\\chi^{\\prime}) + O( \\frac{(q q^{\\prime})^{O(1)}}{1-s} x^{1-c-s} )")]]

#text("for any ")#mi("{x \\geq 1}")#text(". (")#emph[#text("Hint:")]#text(" either use a higher-dimensional version of the Dirichlet hyperbola method, or the truncated Perron formula and contour shifting.)")
]

#text("This gives a repulsion phenomenon:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 61 (Repulsion phenomenon)")]#text(" ")#metadata(none) <tao-53499abbfdfb4ad6959c>#text(" Let ")#mi("{\\chi}")#text(" be a real primitive character of modulus ")#mi("{q}")#text(". Suppose that ")#mi("{L(\\beta,\\chi)=0}")#text(" for some ")#mi("{1-c \\leq \\beta < 1}")#text(", where ")#mi("{c}")#text(" is a sufficiently small absolute constant. Then one has")

#align(center)[#tao-fit-display[#mitex("L(1,\\chi) L(1,\\chi^{\\prime}) \\gg \\frac{1-\\beta}{(qq^{\\prime})^{O(1-\\beta)} \\log(qq^{\\prime})}")]]

#text("for all real primitive characters ")#mi("{\\chi^{\\prime}}")#text(" distinct from ")#mi("{\\chi}")#text(", with ")#mi("{q^{\\prime}}")#text(" denoting the modulus of ")#mi("{\\chi^{\\prime}}")#text(".")
]

#emph[#text("Proof:")]#text(" From Exercise ")#link(<tao-3f1bbc8f6d673cb326c9>)[#text("60")]#text(" with ")#mi("{s=\\beta}")#text(" and ")#link(<tao-76878f1d2b881ee5cf98>)[#text("(55)")]#text(" (and shrinking ")#mi("{c}")#text(" as needed) one has")

#align(center)[#tao-fit-display[#mitex("\\frac{x^{1-\\beta}}{1-\\beta} L(1,\\chi) L(1,\\chi^{\\prime}) L(1,\\chi\\chi^{\\prime}) + O( \\frac{(q q^{\\prime})^{O(1)}}{1-\\beta} x^{1-2c-\\beta} ) \\geq 1")]]

#text("for any ")#mi("{x \\geq 1}")#text(". If we then set ")#mi("{x := (\\frac{qq^{\\prime}}{1-\\beta})^C}")#text(" for a sufficiently large absolute constant ")#mi("{C}")#text(", the error term is less than ")#mi("{1/2}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("\\frac{x^{1-\\beta}}{1-\\beta} L(1,\\chi) L(1,\\chi^{\\prime}) L(1,\\chi\\chi^{\\prime}) \\gg 1.")]]

#text("From ")#link(<tao-7937c4dc4579bfc7c37b>)[#text("(53)")]#text(" one has ")#mi("{L(1,\\chi\\chi^{\\prime}) \\ll \\log(qq^{\\prime})}")#text(", and from choice of ")#mi("{x}")#text(" we have ")#mi("{x^{1-\\beta} \\ll (qq^{\\prime})^{O(1-\\beta)}}")#text(" with implied constants depending on ")#mi("{C}")#text(". The claim follows. ")#mi("\\Box")#linebreak()#text(" We can now give Siegel’s theorem on exceptional zeroes (or on exceptionally small values of ")#mi("{L(1,\\chi)}")#text("), which will be the first theorem in this set of notes to feature ")#emph[#text("ineffective")]#text(" implied constants – constants which cannot be explicitly computed in terms of the given data, but are merely known to be finite and positive.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 62 (Siegel’s theorem)")]#text(" ")#metadata(none) <tao-1c325aa7008f16adc09a>

#list(
[#text("(i) For any ")#mi("{\\varepsilon > 0}")#text(", one has the bound")

#align(center)[#tao-fit-display[#mitex("L(1,\\chi) \\geq c_\\varepsilon q^{-\\varepsilon}")]]

#text("for all but at most one real primitive character ")#mi("{\\chi}")#text(" of conductor ")#mi("{q}")#text(", and some constant ")#mi("{c_\\varepsilon > 0}")#text(".")],
[#text("(ii) For any ")#mi("{\\varepsilon > 0}")#text(", there are no zeroes of ")#mi("{L(s,\\chi)}")#text(" in the interval ")#mi("{[1-c_\\varepsilon q^{-\\varepsilon}, 1]}")#text(" for all but at most one real primitive character ")#mi("{\\chi}")#text(" of conductor ")#mi("{q}")#text(", and some constant ")#mi("{c_\\varepsilon > 0}")#text(".")]
)

#text("In both (i) and (ii), the constant ")#mi("{c_\\varepsilon}")#text(" is ")#emph[#text("effective")]#text(": it can be computed explicitly in terms of ")#mi("{\\varepsilon}")#text(". However, if one wishes to replace “all but at most one” with “all” in either (i) or (ii), one can do this at the cost of rendering ")#mi("{c_\\varepsilon}")#text(" ")#emph[#text("ineffective")]#text(": this constant is still known to be positive, but we no longer know of a way to compute ")#mi("{c_\\varepsilon}")#text(" explicitly in terms of ")#mi("{\\varepsilon}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 63")]#text(" The observation that Siegel’s theorem may be made effective if one exceptional character is removed is due ")#link("http://www.ams.org/mathscinet-getitem?mr=51262")[#text("to Tatuzawa")]#text(". Combined with the class number formula, this can be used to show that with at most one exception, all but an explicitly computable finite list of quadratic fields of negative discriminant do not have unique factorisation. Indeed, using related methods, Heilbronn and Linfott had previously showed that, apart from the nine discriminants ")#mi("{D = -3,-4,-7,-8,-11,-19,-43,-67,-163}")#text(" (which all give quadratic fields of unique factorisation), there is at most one further negative discriminant giving a quadratic field of unique factorisation. This elusive “tenth discriminant” was finally ruled out ")#link("http://www.ams.org/mathscinet-getitem?mr=53135")[#text("by Heegner")]#text(" by some difficult arguments, which have since been clarified by subsequent work of Stark and many further authors, giving what is now known as the ")#link("http://en.wikipedia.org/wiki/Stark%E2%80%93Heegner_theorem")[#text("Stark-Heegner theorem")]#text(".")
]

#emph[#text("Proof:")]#text(" From Lemmas ")#link(<tao-784a2ddf5d4d61b6ae15>)[#text("57")]#text(", ")#link(<tao-05719c23f281c3f9af4a>)[#text("59")]#text(" we see that (i) and (ii) are equivalent, so we will just prove (i). It suffices to prove the claim with one exceptional character ")#mi("{\\chi}")#text(" deleted and with effective choices of ")#mi("{c_\\varepsilon}")#text(", since one can reinstate the exceptional character (at the cost of making ")#mi("{c_\\varepsilon}")#text(" ineffective) just by using the positivity ")#mi("{L(1,\\chi) > 0}")#text(" for the exceptional character.")

#text("Let ")#mi("{c_\\varepsilon}")#text(" be a small (effective) constant, depending only on ")#mi("{\\varepsilon}")#text(", to be chosen later. We divide into two cases:")

#enum(start: 1, 
[#text("There are no zeroes of ")#mi("{L(s,\\chi)}")#text(" in the interval ")#mi("{[1-c_\\varepsilon q^{-\\varepsilon},1]}")#text(" for ")#emph[#text("any")]#text(" real primitive character ")#mi("{\\chi}")#text(" with a conductor ")#mi("{q}")#text(".")],
[#text("There exists a real primitive character ")#mi("{\\chi}")#text(" of some conductor ")#mi("{q}")#text(" with a zero ")#mi("{\\beta}")#text(" in ")#mi("{[1-c_\\varepsilon q^{-\\varepsilon},1]}")#text(".")]
)

#text("In Case 1, Lemma ")#link(<tao-05719c23f281c3f9af4a>)[#text("59")]#text(" in the contrapositive gives ")#mi("{L(1,\\chi) \\gg c_\\varepsilon q^{-\\varepsilon}}")#text(" for all real primitive characters ")#mi("{\\chi}")#text(" with a conductor ")#mi("{q}")#text(", giving the claim (after adjusting ")#mi("{c_\\varepsilon}")#text(" slightly).")

#text("Now suppose we are in Case 2, so ")#mi("{L(\\beta,\\chi)=0}")#text(" for some real primitive character ")#mi("{\\chi}")#text(" of conductor ")#mi("{q}")#text(" and some ")#mi("{1-c_\\varepsilon q^{-\\varepsilon} \\leq \\beta < 1}")#text(" (recall that ")#mi("{L(1,\\chi)}")#text(" is non-vanishing). We may take ")#mi("{q}")#text(" to be minimal among all such characters. Note that while ")#mi("{q}")#text(" is obviously finite, we do not have any ")#emph[#text("effective")]#text(" bound on ")#mi("{q}")#text(", so we have to proceed a little carefully if one is to avoid the final implied constants from depending on ")#mi("{\\chi}")#text(" or ")#mi("{q}")#text(".")

#text("Let ")#mi("{\\chi^{\\prime}}")#text(" be a real primitive character of conductor ")#mi("{q^{\\prime}}")#text(" that is distinct from the exceptional character ")#mi("{\\chi}")#text(". If ")#mi("{q^{\\prime} < q}")#text(" then by construction, ")#mi("{L(s,\\chi^{\\prime})}")#text(" has no zeroes in ")#mi("{[1-c_\\varepsilon (q^{\\prime})^{-\\varepsilon},1]}")#text(", and the required bound follows again from Lemma ")#link(<tao-05719c23f281c3f9af4a>)[#text("59")]#text(" in the contrapositive. Now suppose that ")#mi("{q^{\\prime} \\geq q}")#text(". From Proposition ")#link(<tao-53499abbfdfb4ad6959c>)[#text("61")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("L(1,\\chi) L(1,\\chi^{\\prime}) \\gg \\frac{1-\\beta}{(qq^{\\prime})^{O(1-\\beta)} \\log(qq^{\\prime})}.")]]

#text("By Lemma ")#link(<tao-15f3b852d2465ae56ff5>)[#text("27")]#text(", we have ")#mi("{L(1,\\chi) \\ll (1-\\beta) \\log^2 q}")#text(". Bounding ")#mi("{q}")#text(" by ")#mi("{q^{\\prime}}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("L(1,\\chi^{\\prime}) \\gg \\frac{1}{(q^{\\prime})^{O(1-\\beta)} \\log^3(q^{\\prime})},")]]

#text("and using the bound ")#mi("{1-\\beta \\leq c_\\varepsilon q^{-\\varepsilon}}")#text(", we obtain the required estimate if ")#mi("{c_\\varepsilon}")#text(" is small enough. ")#mi("\\Box")#linebreak()#text(" The best known ")#emph[#text("effective")]#text(" lower bounds on ")#mi("{L(1,\\chi)}")#text(" for ")#emph[#text("all")]#text(" real primitive characters ")#mi("{\\chi}")#text(" (not excluding an exceptional character) go through the ")#link("http://en.wikipedia.org/wiki/Class_number_formula")[#text("class number formula")]#text(" (as briefly discussed in ")#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/")[#text("Supplement 1")]#text("), and take the shape ")#metadata(none) <tao-6ddf28f040f22b18f962>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(56)")])
#mitex("L(1,\\chi) \\gg q^{-1/2} \\log^{C} q")]]

#linebreak()#text(" for some explicit constant ")#mi("{C}")#text("; this corresponds to a zero-free region of ")#mi("{L(s,\\chi)}")#text(" of size ")#mi("{[1-c q^{-1/2} \\log^{C-2} q, 1]}")#text(" for some effective constants ")#mi("{c, C>0}")#text(". The bound ")#link(<tao-6ddf28f040f22b18f962>)[#text("(56)")]#text(" is trivial for ")#mi("{C=0}")#text(" since the class number is always at least one; it turns out that one can raise ")#mi("{C}")#text(" to be arbitrarily close to ")#mi("{1}")#text(", but this is a difficult result (at least when ")#mi("{\\chi}")#text(" is associated to a quadratic field of negative discriminant), due to Goldfeld and Gross-Zagier; see ")#link("http://www.ams.org/mathscinet-getitem?mr=788386")[#text("this survey of Goldfeld")]#text(" for further discussion. It is of great interest to improve these effective bounds further, but this has not yet been achieved; despite the conjectural non-existence of Siegel zeroes, they seem to live in a stubbornly self-consistent (though somewhat strange) universe that has defied all efforts to eradicate them to date.")#linebreak()#text(" In summary, we can give the following bounds on exceptional zeroes ")#mi("{\\beta}")#text(" of ")#mi("{L}")#text("-functions of real primitive characters ")#mi("{\\chi}")#text(" of conductor ")#mi("{q}")#text(":")

#list(
[#text("(i) (Class number methods) One has ")#mi("{\\beta \\leq 1 - c q^{-1/2} \\log^{C-2} q}")#text(" for some effective ")#mi("{c > 0}")#text(" and ")#mi("{C}")#text(".")],
[#text("(ii) (Siegel) For any ")#mi("{\\varepsilon>0}")#text(", one has ")#mi("{\\beta \\leq 1 - c_\\varepsilon q^{-\\varepsilon}}")#text(" for some ")#emph[#text("ineffective")]#text(" ")#mi("{c_\\varepsilon > 0}")#text(".")],
[#text("(iii) (Tatuzawa) For any ")#mi("{\\varepsilon>0}")#text(", one has ")#mi("{\\beta \\leq 1 - c_\\varepsilon q^{-\\varepsilon}}")#text(" for some ")#emph[#text("effective")]#text(" ")#mi("{c_\\varepsilon > 0}")#text(", except possibly for a single exceptional character ")#mi("{\\chi_\\varepsilon}")#text(".")],
[#text("(iv) (Page) One has ")#mi("{\\beta \\leq 1-\\frac{c}{\\log Q}}")#text(" for some effective ")#mi("{c>0}")#text(" and all real primitive characters ")#mi("{\\chi}")#text(" of conductor at most ")#mi("{Q}")#text(", except possibly for a single exceptional character ")#mi("{\\chi^{\\prime}_Q}")#text(".")]
)

#text("One also obtains analogous lower bounds on ")#mi("{L(1,\\chi)}")#text(" through Lemma ")#link(<tao-05719c23f281c3f9af4a>)[#text("59")]#text(", and lower bounds on class numbers (at least in the case of negative discriminant) using the class number formula.")

#text("All four of the bounds (i), (ii), (iii), (iv) have their advantages and disadvantages, and are all useful in various applications; the choice of which of (i)-(iv) to use depends on whether one has some argument to deal with a potential exceptional character, whether one can tolerate ineffective values of the implied constant, and whether one has a reasonable bound ")#mi("{Q}")#text(" on the conductor of the characters one wishes to use.")

#text("A basic application of Siegel’s theorem is the ")#link("http://en.wikipedia.org/wiki/Siegel%E2%80%93Walfisz_theorem")[#text("Siegel-Walfisz theorem")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 64 (Siegel-Walfisz theorem)")]#text(" For any ")#mi("{A > 0}")#text(", show that there exists an (ineffective) constant ")#mi("{c_A>0}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x:n=a\\ (q)} \\Lambda(n) = \\frac{x}{\\phi(q)} + O( x \\exp( - c_A \\sqrt{\\log x} ) )")]]

#text("for all primitive residue classes ")#mi("{a\\ (q)}")#text(" and all ")#mi("{x \\geq 2}")#text(" with ")#metadata(none) <tao-9bf6cf4c926b38ef61f3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(57)")])
#mitex("q \\leq \\log^A x.")]]

#text(" (")#emph[#text("Hint:")]#text(" use Exercise ")#link(<tao-18b1ea4945c713912b23>)[#text("55")]#text("(iii) together with Siegel’s theorem to handle the exceptional zero.) Conclude in particular that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x:n=a\\ (q)} \\Lambda(n) = \\frac{x}{\\phi(q)} + O_A( x \\log^{-A} x )")]]

#text("for all primitive residue classes ")#mi("{a\\ (q)}")#text(" and all ")#mi("{x \\geq 2}")#text(" (without assuming the size restriction ")#link(<tao-9bf6cf4c926b38ef61f3>)[#text("(57)")]#text("), and with an ineffective constant in the ")#mi("{O_A()}")#text(" notation.")
]

#text("Of course, the error term in the Siegel-Walfisz theorem can be substantially improved if one assumes the generalised Riemann hypothesis: see Exercise ")#link(<tao-aaace08c7b6d523225fc>)[#text("48")]#text(". In ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("Notes 3")]#text(" we will use the Siegel-Walfisz theorem to prove the Bombieri-Vinogradov theorem, which is a theorem of basic importance in sieve theory.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 65 (Least prime in an arithmetic progression)")]#text(" If ")#mi("{a\\ (q)}")#text(" is a primitive residue class, show that ")#mi("{a\\ (q)}")#text(" contains a prime ")#mi("{p}")#text(" with ")#mi("{p \\ll \\exp( q^{o(1)} )}")#text(", with the implied constants ineffective; by using ")#link(<tao-6ddf28f040f22b18f962>)[#text("(56)")]#text(", obtain the alternate bound ")#mi("{p \\ll \\exp(q^{2+o(1)})}")#text(" with effective constants, and obtain the improvement ")#mi("{p \\ll \\exp( O(\\log^2 q) )}")#text(" with effective constants if there is no exceptional character of modulus ")#mi("{q}")#text(". In ")#link("https://terrytao.wordpress.com/2015/02/22/254a-notes-7-linniks-theorem-on-primes-in-arithmetic-progressions/")[#text("Notes 7")]#text(" we will be able to improve all of these bounds to ")#mi("{p \\ll q^{O(1)}}")#text(" with effective constants, a result known as ")#link("http://en.wikipedia.org/wiki/Linnik%27s_theorem")[#text("Linnik’s theorem")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 66 (Siegel-Walfisz for the Möbius function)")]#text(" Show that for any ")#mi("{A>0}")#text(", one has the bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x:n=a\\ (q)} \\mu(n) \\ll_A x \\log^{-A} x")]]

#text("for all residue classes ")#mi("{a\\ (q)}")#text(" (not necessarily primitive) and all ")#mi("{x \\geq 2}")#text(", with an ineffective constant in the ")#mi("{O_A()}")#text(" notation. (")#emph[#text("Hint:")]#text(" reduce to the case in which ")#mi("{q \\leq \\log^A x}")#text(" and ")#mi("{a\\ (q)}")#text(" is primitive. One can either use a truncated Perron’s formula argument using some lower bounds on ")#mi("{L(s,\\chi)}")#text(" for ")#mi("{s}")#text(" slightly to the left of ")#mi("{1}")#text(", or else modify the elementary method from Theorem 58 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(", using an induction on ")#mi("{A}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 67 (Elementary lower bound for ")#mi("{L(1,\\chi)}")#text(")")]#text(" The purpose of this exercise is to give a somewhat reasonable effective lower bound on ")#mi("{L(1,\\chi)}")#text(" by an elementary (but somewhat ")#emph[#text("ad hoc")]#text(") device. Let ")#mi("{\\chi}")#text(" be a real non-principal character of modulus ")#mi("{q}")#text(".")

#list(
[#text("(i) Establish the identity")

#align(center)[#tao-fit-display[#mitex("\\sum_n (1*\\chi)(n) e^{-n/x} = x L(1,\\chi) + \\sum_n \\chi(n) f(\\frac{n}{x})")]]

#text("for any ")#mi("{x>0}")#text(", where ")#mi("{f: (0,+\\infty) \\rightarrow {\\bf R}}")#text(" is the function ")#mi("{f(t) := \\frac{1}{e^t-1}-\\frac{1}{t}}")#text(", and the sum is in the conditionally convergent sense.")],
[#text("(ii) Obtain the bounds")

#align(center)[#tao-fit-display[#mitex("\\sum_n (1*\\chi)(n) e^{-n/x} \\gg \\sqrt{x}")]]

#text("and ")#metadata(none) <tao-df56a7f456855b1e6df6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(58)")])
#mitex("\\sum_n \\chi(n) f(\\frac{n}{x}) \\ll q")]]

#text(" and conclude that ")#metadata(none) <tao-3959bb85476465b58ba6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(59)")])
#mitex("L(1,\\chi) \\gg q^{-1}.")]]

]
)

#text("It is possible to use Fourier analysis to improve the upper bound on ")#link(<tao-df56a7f456855b1e6df6>)[#text("(58)")]#text(" to ")#mi("{O(\\sqrt{q} \\log q)}")#text(", which almost recovers the bound ")#mi("{L(1,\\chi) \\gg q^{-1/2}}")#text(" coming from the class number formula; but we will not do this here.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 68")]#text(" Use ")#link(<tao-3959bb85476465b58ba6>)[#text("(59)")]#text(" and Exercise ")#link(<tao-094a367b026246fb6464>)[#text("58")]#text(" for a suitable choice of ")#mi("{x, s}")#text(" to give an alternate proof of Lemma ")#link(<tao-784a2ddf5d4d61b6ae15>)[#text("57")]#text(".")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (65)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/288e2c8a58a6268a6c8ff5df98ea4d047e748e5401d15fc45a4deaeb19bb4078-828aa9dcba2c09b6126bddb8a926925bf25b82608a8eb26e5a314925f35b286f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicolas Templier")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-444549")[#strong[#text("Nicolas Templier")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2014")])]

#text("Dear Terry,")

#text("I enjoyed your very nice treatment of the Landau-Siegel zeros. There is an important famous result to be mentioned around the display (55) about the best known effective lower bounds on ")#mi("L(1,\\chi)")#text(" for all real primitive characters $\\chi$:")

#text("Briefly the combination of the works of Goldfeld and ")#link("http://www.ams.org/mathscinet-getitem?mr=833192")[#text("Gross-Zagier")]#text(" show unconditionally that (55) holds for any ")#mi("C>-1")#text(".")#linebreak()#text(" Being able to pick a ")#mi("C<0")#text(" is highly significant since it effectively solves the Gauss class number problem.")#linebreak()#text(" An excellent short account appears in this ")#link("http://www.ams.org/journals/bull/1985-13-01/S0273-0979-1985-15352-2/S0273-0979-1985-15352-2.pdf")[#text("Bulletin article")]#text(".")

#text("The original ")#link("http://www.ams.org/mathscinet-getitem?mr=450233")[#text("article")]#text(" treats both real and imaginary quadratic fields and contains precise bounds with the exact dependence on the order of vanishing at 1/2 of the auxiliary elliptic curve L-function.")

#emph[#text("[Fair enough; I’ve reworded that portion of the text accordingly. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-444604")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2014")])]

#text("In the line above corollary 39, “la” is missing in “de la Vallee Poussin”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-444664")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2014")])]

#text("In the line above (32), “identity” may be replaced by “inequality”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-444707")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2014")])]

#text("The derivation of (36) (via integration) from (35) is not sufficiently clear (in particular, the behavior of the LHS of (35) near ")#mi("t= +\\infty")#text(" – because of the essential singularity of ")#mi("\\zeta(s)")#text(" at ")#mi("s=\\infty")#text(").")#linebreak()#text(" BTW, in the wikipedia article on the PNT, (36) is derived directly (i.e. without integration) from the Euler product and the inequality (32).")

#emph[#text("[Oops, that should have been an integration in ")#mi("\\sigma")#text(", not ")#mi("t")#text(". Corrected and clarified, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2108f61ac4b72751222a3ca4c0a3c94cdf7a7a4533ade03a483f2f0830a83f54-736b5d7e61507ab6e071a037b6570fba88784f8f0294a1aa67d272ccd9f87cbb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-444804")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2014")])]

#text("Very nice set of notes. In parts (I) and (ii) of exercise 46, there should not be a main term, right?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-444954")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2014")])]

#text("There may be a problem in the inequality after Exercise 5. As $\\sigma$ is complex, the right-hand side $g(n)/n^\\sigma$ can be negative ($n^\\sigma$ can be real and negative). My apologies if I’m just confused.")#linebreak()#text(" That’s a fantastic set of notes.")

#emph[#text("[")#mi("\\sigma")#text(" is real (which is the convention in analytic number theory, and also implicitly enforced by the hypothesis ")#mi("\\sigma > 1")#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony Quas")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-445732")[#strong[#text("Anthony Quas")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2014")])]

#text("v. interesting again. Under Exercise 2, I think the Dirichlet series of log should be ")#mi("-\\zeta^{\\prime}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony Quas")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-445734")[#strong[#text("Anthony Quas")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2014")])]

#text("In the first line of the proof of Proposition 9, the text refers to Equation (7) rather than Proposition 7 (where the hyperlink redirects).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony Quas")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-445735")[#strong[#text("Anthony Quas")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2014")])]

#text("In Remark 10, the brackets failed to appear in the inline text around ")#mi("[d_1,d_2]")#text(" (in my browser at least).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony Quas")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-445737")[#strong[#text("Anthony Quas")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2014")])]

#text("In my browser, the equation number on equation (23) doesn’t show up, which is slightly disconcerting because it is directly referred to.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony Quas")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-445787")[#strong[#text("Anthony Quas")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2014")])]

#text("The first line of the proof of Theorem 21 refers to (20) when I think it should refer to Corollary 20.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony Quas")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-446190")[#strong[#text("Anthony Quas")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2014")])]

#text("There’s also a reference to Corollary 20 (where the hyperlink points to the wrong place) after equation (27)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-446307")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2014")])]

#text("So I think these corrections have probably been made in the wrong direction! As far as I can tell, both places should refer to Corollary 20, not to equation (20).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 5: The linear sieve and Chen’s theorem (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-451192")[#strong[#text("254A, Supplement 5: The linear sieve and Chen’s theorem (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2015")])]

#text("[…] of . If , then , and then by the prime number theorem for the Liouville function (Exercise 41 from Notes 2, combined with Exercise 18 from Supplement 4) we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-451217")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2015")])]

#text("I think the horizontals lines mentioned in the “(note…” after (26) should +/- T’ not +/- T")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 5: Bounding exponential sums and the zeta function | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-451616")[#strong[#text("254A, Notes 5: Bounding exponential sums and the zeta function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2015")])]

#text("[…] of upper bounding the size of this function within the critical strip; as seen in Exercise 43 of Notes 2, such upper bounds can lead to zero-free regions for , which in turn lead to improved estimates for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-451708")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2015")])]

#text("In the first proof of the PNT, how does (29) imply the given asymptotic of the sum $latex\\sum_{n}\\frac{\\Lambda(n)}{n^{\\sigma}}n^{-2it}$?")

#emph[#text("[Sorry, there was a real part missing on the LHS, now added. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 6: Large values of Dirichlet polynomials, zero density estimates, and primes in short intervals | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-451890")[#strong[#text("254A, Notes 6: Large values of Dirichlet polynomials, zero density estimates, and primes in short intervals | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2015")])]

#text("[…] of the Riemann zeta function (counting multiplicity) with and . Recall from Proposition 16 of Notes 2 that there are at most zeroes in any rectangle of the form with . Combining this with the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 7: Linnik’s theorem on primes in arithmetic progressions | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-452282")[#strong[#text("254A, Notes 7: Linnik’s theorem on primes in arithmetic progressions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2015")])]

#text("[…] from the Landau-Page theorem (Exercise 54 from Notes 2) that at most one exceptional zero exists (if is small enough). A key point here is that the error […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 6: A cheap version of the theorems of Halasz and Matomaki-Radziwill | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-452365")[#strong[#text("254A, Supplement 6: A cheap version of the theorems of Halasz and Matomaki-Radziwill | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2015")])]

#text("[…] summatory function requires the prime number theorem, which is substantially harder to prove (see Notes 2). (From a complex-analytic or Fourier-analytic viewpoint, the problem is that the logarithmic sums […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-453607")[#strong[#text("254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2015")])]

#text("[…] small (of size or so), this estimate will be a consequence of the Siegel-Walfisz theorem ( from Notes 2); it is the application of this theorem that is responsible for the ineffective constants. In the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78b6bb1b526b84f2401b6affa5c7be46eef64b91f3158c598b28de0bdf1ee0ef-5d7fbc184c468ac2b51bf113e3dd31010165e3cfeb41bdf779afeaeef573361d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karaskas")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-454063")[#strong[#text("Karaskas")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2015")])]

#text("Proposition 51: missing ")#mi("\\}")#text(" in the explicit formula for the zero-free region.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-454223")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2015")])]

#text("After equation (5), the Dirichlet character had better be no principal. Otherwise you would have the main term x.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-454224")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2015")])]

#text("Two paragraphs below equation (8), in the second summation in the first line, the n in the upper limit should be N.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-454227")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2015")])]

#text("There is an extra period in equation (12).")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-454663")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2015")])]

#text("The reference to (13) before equation (29) should perhaps be to (11), as (13) is only valid near ")#mi("s=1")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-454693")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2015")])]

#text("In the proof of Proposition 51, in the paragraph dealing with ")#mi("\\chi^2=\\chi_0")#text(" and t large, in the last display, the inequality should be reversed and the RHS be its negative.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-454750")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2015")])]

#text("I’m confused about the paragraph after Remark 56: isn’t the sequence of characters ")#mi("q_n=100^{100^n}")#text(" still of the form ")#mi("q_{n+1}=q_n^C")#text(" with C=100? Also, isn’t ")#mi("1-\\beta_n=q_n^{-10}")#text(" already ruled out by Landau page as ")#mi("\\log(q_nq_{n+1})\\ll 100^{n+1}=o(q_n^{10})")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 4: Probabilistic models and heuristics for the primes (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-456109")[#strong[#text("254A, Supplement 4: Probabilistic models and heuristics for the primes (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2015")])]

#text("[…] now move away from the world of multiplicative prime number theory covered in Notes 1 and Notes 2, and enter the wider, and complementary, world of non-multiplicative prime number theory, in which […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heath-Brown’s theorem on prime twins and Siegel zeroes | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-458476")[#strong[#text("Heath-Brown’s theorem on prime twins and Siegel zeroes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2015")])]

#text("[…] use Siegel’s theorem to obtain the better bound . Standard arguments (see also Lemma 59 of this blog post) then […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab82efe8db2841454b1457793a9953a5a2a37cfd671dc7a9b01203b83c318270-25487a2c0a8940e06137563ee9850144e03d4637018ec997716042f03779ecb3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of XiangYu")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-468665")[#strong[#text("XiangYu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2016")])]

#text("In the proof of proposition 9, should the second last formula be")#linebreak()#text(" ")#mi("\\displaystyle \\int_{\\mathbf{R}} [\\frac{\\zeta^{\\prime}(\\sigma+it)}{\\zeta(\\sigma+it)}-\\frac{1}{\\sigma+it-1}]\\hat{f}(t\\log x-i)\\, dt=O_f(\\frac{1}{\\log x})")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab82efe8db2841454b1457793a9953a5a2a37cfd671dc7a9b01203b83c318270-25487a2c0a8940e06137563ee9850144e03d4637018ec997716042f03779ecb3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiang Yu")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-468910")[#strong[#text("Xiang Yu")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2016")])]

#text("Dear Professor Tao")

#text("I have just finished reading this fantastic set of notes. There is something I cannot understand. My apologies if I am just confused.")

#text("+ Propostion 12: Do we need the assumption that ")#mi("T\\leq x")#text(" ?")

#text("+ Corollary 23: If we apply Theorem 21, it should be")#linebreak()#text(" ")#mi("\\displaystyle \\sum_{n \\leq x} \\Lambda(n) = x + O_{\\delta}( x^{1-\\delta} \\log^2 T ) + O_{\\delta}( \\frac{x}{T} \\log^2(xT) )")#linebreak()#text(" But there is no ")#mi("\\delta")#text(" in the big O, is it because that we can make the implied constant uniformly bounded in ")#mi("\\delta")#text("?")

#text("+ Propostion 31: In the last part of the proof, I think we should let ")#mi("g")#text(" be an upper or lower approximant to ")#mi("1_{[-\\log 2,0]}")#text(".")

#text("+ In parenthesis after formula (35), it should be ")#mi("\\zeta(\\sigma+it)\\to 1")#text(" as ")#mi("\\sigma\\to +\\infty")#text(" for any fixed ")#mi("t")#text(".")

#text("+ Theorem 53: There is a typo in the last sentence of proof, we obtain a contradiction if ")#mi("c")#text(" is small enough, not large enough.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 3: The Gamma function and the functional equation (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-470230")[#strong[#text("254A, Supplement 3: The Gamma function and the functional equation (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2016")])]

#text("[…] Notes 2, the Riemann zeta function (and more generally, the Dirichlet -functions ) were extended […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc04304fcd7ab9122222366cb1b8c4af9b743c1c94f5a0e6c854c799d934f54e-d0852710d9476d3cbfec69e2f79b1bf1beda95e241d3f563059d935bcc8b19ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bernard Victorri")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-478481")[#strong[#text("Bernard Victorri")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2017")])]

#text("In exercise 42 (Beurling primes) the main term in equation 41 should be x/logx, if I am not mistaken ?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-478952")[#strong[#text("Lattice Points in High-Dimensional Spheres | a. w. walker")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2017")]

#text("[…] (Truncated Perron, Prop. 12): Suppose that the Dirichlet series given by satisfies for all . Choose . For we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da87e6971d472723c5320e567915782b17a0a6f3a7b77d257bf00bc0df3d93a7-2d9ebf36b3b42665bb549f067b7e88557c0cb0b1ecbc1c8609a55b4f000307f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Claudeh5")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-479735")[#strong[#text("Claudeh5")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2017")])]

#text("Hello professor Tao,")

#text("I have a problem with this extract:")

#text("“… Thus the only remaining case is when {\\chi} is real and {|t| 1 – \\frac{c}{\\log(q(2+|t|))} \\}}. If there are two such zeroes …")

#text("The formula is incomplete …")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Continuous approximations to arithmetic functions | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-488632")[#strong[#text("Continuous approximations to arithmetic functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2017")])]

#text("[…] Dirichlet series, but we will not pursue these rigorous calculations here. (But see for instance this previous blog post for some […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Math student")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-508766")[#strong[#text("Math student")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2018")])]

#text("Dear Prof. Tao,")

#text("the whole page seems to repeat itself (twice!).")

#emph[#text("[Fixed now – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-508781")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2018")])]

#text("Concerning the remark after exercise 30, is there any sufficiently strong “probabilistically reasonable” conjecture on the (asymptotic) correlation of zeta zeros tuples (not only zero pairs) which is sufficiently strong (stronger than Montgomery pair correlation conjecture) to imply the current conjecture that the gap between any two consecutive primes below ")#mi("x")#text(" is ")#mi("O(\\log ^2 x)")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-508793")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2018")])]

#text("I don’t think there is a clean implication of this type. If one uses the explicit formula to try to work out whether there is a prime in the interval ")#mi("[x, x + \\log^2 x]")#text(", one will find that one needs to understand a highly oscillatory sum that involves all the zeroes up to height about ")#mi("x")#text(" (up to log factors); even assuming the Riemann hypothesis, one would need to understand the cancellation in this sum. One could simply posit that this sum always exhibits the expected amount of cancellation, but this is a rather artificial conjecture which is basically just Cramer’s conjecture expressed in terms of the zeroes, and would be largely orthogonal to the GUE hypothesis which only concerns the local behaviour of zeroes rather than global cancellations.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A announcement: Analytic prime number theory | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-521316")[#strong[#text("254A announcement: Analytic prime number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2019")])]

#text("[…] Complex-analytic multiplicative number theory […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08ae5a70d8b90088660ddc04253b1b214e87eb333534f85448a1206693ce1962-b480703f6ac06d94f3d7e606b82ff203ddcf3b2c457352d4386db8550e36632e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin Ford")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-525270")[#strong[#text("Kevin Ford")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2019")])]

#text("Alternatively, Proposition 9 is valid for any bounded C^1 function on [0,1]. The proof is a couple of lines using partial summation and Mertens.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 10 – mean values of nonpretentious multiplicative functions | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-532953")[#strong[#text("254A, Notes 10 – mean values of nonpretentious multiplicative functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2019")])]

#text("[…] it to for an absolute constant (the bound is more classical, following from Exercise 33 of Notes 2). On the other hand, the randomness heuristics from Supplement 4 suggest that should be able to be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 2: Some connections with the Fourier transform | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-620494")[#strong[#text("246B, Notes 2: Some connections with the Fourier transform | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2021")])]

#text("[…] (The Perron formula and its many variants are of great utility in analytic number theory; see these previous lecture notes for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 4: The Riemann zeta function and the prime number theorem | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-622257")[#strong[#text("246B, Notes 4: The Riemann zeta function and the prime number theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("[…] in this course. For some further discussion see this previous set of lecture notes, particularly Notes 2 and Supplement 3 (with much of the material in this post drawn from the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-629912")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2021")])]

#text("Dear Prof. Tao,")

#text("in proposition 24, one may take the ")#mi("o(1)")#text(" term extremely rapidly decreasing, and then the implication (ii) => (i) becomes false. I would be very grateful if this could be corrected.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-629916")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2021")])]

#text("Or is this supposed to mean “there exists some ")#mi("o(1)")#text("? It could be read either way. Please clarify!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-629917")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2021")])]

#text("Oh, and if you could mention that the ")#mi("o(1)")#text(" can be replaced by “every ")#mi("\\epsilon > 0")#text("“.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-629935")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2021")])]

#text("Dear Prof. Tao,")

#text("if you refuse to make these changes, I’ll be forced to rely on a different reference.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-629947")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2021")])]

#text("There is a German saying that goes “sich keinen Zacken aus der Krone brechen”. You might want to look it up.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-629952")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2021")])]

#text("Spin somewhere else.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-629953")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2021")])]

#text("Dear Anonymous,")

#text("if Prof. Tao doesn’t want me to comment on his blog (which thus far, despite him ignoring my suggestions, has not transpired yet), I’ll respect that. However, I have a strong adversion against bullies trying to exclude me from a group or a conversation. Therefore, I have to strongly condemn your comment.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/182dddb64ad4570b9e54c15852d8221e4e6385bb4969e7abbe2520835c1a7c61-b5c623d217cae4b166aa2626ccd2f3d4801afde5d74358f995daf0185b38efc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-634355")[#strong[#text("James")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2021")])]

#text("Why does one assume ")#mi("f(n) = O(\\log (2+n))")#text(" in Proposition 12, i.e. why “2+” part? I assume it’s because ")#mi("f(n) = O(\\log n)")#text(" would be annoying for ")#mi("n=1")#text(", but wouldn’t that already be solved by ")#mi("f(n) = O(\\log (1+n))")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-634696")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2021")])]

#text("Yes, that would work also. Sometimes ")#mi("\\log(2+n)")#text(" is slightly preferable to ")#mi("\\log(1+n)")#text(" because, when extended to the non-negative real axis ")#mi("[0,+\\infty)")#text(", it stays bounded away from zero all the way up to the endpoint ")#mi("n=0")#text(", whereas ")#mi("\\log(1+n)")#text(" vanishes there, and one doesn’t want to give the impression that this vanishing is in any way relevant.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/182dddb64ad4570b9e54c15852d8221e4e6385bb4969e7abbe2520835c1a7c61-b5c623d217cae4b166aa2626ccd2f3d4801afde5d74358f995daf0185b38efc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-635325")[#strong[#text("James")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2021")])]

#text("I believe one can easily remove constant ")#mi("C")#text(" in Proposition 19. For example, if ")#mi("\\sigma\\geq 2")#text(" then")

#tao-math("\\displaystyle \\left|\\frac{\\zeta^{\\prime}}{\\zeta}(s)\\right|\\leq \\sum_n \\frac{\\log n}{n^2}<\\infty,", block: false)

#text("i.e. ")#mi("\\zeta^{\\prime}(s)/\\zeta(s)=O(1)")#text(". On the other hand, ")#tao-math("\\displaystyle  -\\sum_{\\rho: \\left|s-\\rho\\right| \\leq \\varepsilon/2} \\frac{1}{s-\\rho} + \\frac{1}{s-1}", block: false)#text(" is obviously ")#mi("O(1)")#text(" for ")#mi("\\sigma\\geq 2")#text(".")

#emph[#text("[This seems correct to me, though we rarely need to venture to the right of say ")#mi("{\\bf Re}(s)=10")#text(" in any analytic number theory application anyway, so the dependence on ")#mi("C")#text(" is not terribly important in practice. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d7c1b6cb2355225c4aa81f58c25106da2b399f567af87a7508495d00d6e5f26-19de1650d1de83dd1fdbf582eeadeff0ce510532025de0101576a5993fd23004.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quân Nguyễn")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-641075")[#strong[#text("Quân Nguyễn")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2022")])]

#text("Dear professor Tao,")#linebreak()#text(" In Theorem 21, how can one apply the pigeonhole principle to negate the integral sign and obtain (26) ? The same issue at the end of theorem 21 where there exists \\epsilon’ \\in ")#tao-fit-display[#mitex("\\epsilon/2 , \\epsilon")]#text(". For this approach to work, one condition that I think is that the integrated function should be non-negative. Can one use this approach when one has an improper integral?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-641094")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2022")])]

#text("From Corollary 20, the integral of the left-hand side of (26) (which is non-negative) as ")#mi("T^{\\prime}")#text(" ranges from ")#mi("T")#text(" to ")#mi("T+1")#text(" is ")#mi("O_\\varepsilon(\\log T)")#text(", giving the claim from the pigeonhole principle.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d7c1b6cb2355225c4aa81f58c25106da2b399f567af87a7508495d00d6e5f26-19de1650d1de83dd1fdbf582eeadeff0ce510532025de0101576a5993fd23004.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quân Nguyễn")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-641115")[#strong[#text("Quân Nguyễn")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2022")])]

#text("Thank you professor. May I have one more question? So in the truncated log-derivative formula (proposition 19, can one modify the factor 1/2 in ")#tao-math("\\rho : \\left| s - \\rho \\right| \\leq \\varepsilon/2", block: false)#text(" to a more general domain like ")#tao-math("\\rho: \\left| s - \\rho \\right| \\leq c_1 \\varepsilon", block: false)#text(" with ")#mi("c_1 < 1")#text("? I came up an attempt which results that this might be possible.")

#emph[#text("[Yes – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-682282")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2023")])]

#text("Dear prof. Tao,")#linebreak()#text(" How can one obtain an upper bound of the log derivative of the Dirichlet ")#mi("\\mathcal{L}")#text(" function based on the truncated log derivative formulation above? Since there can be a root ")#mi("\\rho")#text(" that is closed to ")#mi("s")#text(", how can one bound for such roots?")#linebreak()#text(" Latter on, we obtain a zero free region, except for possible one zero, of the ")#mi("\\mathcal{L}")#text(" function. Then is ")#mi("c>0")#text(" works for every modulus ")#mi("q")#text(" or is it dependent on ")#mi("q")#text("? In some talks that you gave, ")#mi("c")#text(" is refer to as the “quality” so to speak, and the smaller the value of ")#mi("c>0")#text(" the better the exceptional zero gets (in some certain sense). Would you like to give more details on this values and how does it improve certain results?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-682290")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2023")])]

#text("The ")#mi("c")#text(" in Proposition 51 is an absolute constant. The exceptional zero ")#mi("\\beta")#text(" can indeed be very close to ")#mi("1")#text(" in applications, which does cause a significant problem; one can use Siegel’s theorem (Theorem 62) to get an ineffective amount of separation, which is good enough in some applications, but if one wants effective bounds then one basically has to live with the contribution of the exceptional zero and try to ensure that one has good bounds for the final result even when ")#mi("\\beta")#text(" is very close to 1.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b134821df55626cfe5cf70200334c62a758e458620c2dc2d9ed73dee50dd080-557cc70b78177ea84cf94b0dee4b299e5ee63df9b3dc06bfc91b8f7ff2952893.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xylophonemindfully59caf3e63a")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-687815")[#strong[#text("xylophonemindfully59caf3e63a")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2025")])]

#text("Dear Professor Tao:")

#text("I am working through the proof of Proposition 16 and am having trouble understanding equation (25). If s is a zero of the zeta function, the left-hand side of (25) appears to diverge, while the right-hand side remains finite, which seems contradictory. Could you let me know if I’ve misunderstood something here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-687818")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2025")])]

#text("At a zero, ")#tao-math("\\log \\left|\\zeta(s)\\right|", block: false)#text(" is ")#mi("-\\infty")#text(", so the inequality holds vacuously in this case. (Think of this bound as an upper bound on ")#tao-math("\\left|\\zeta(s)\\right|", block: false)#text(", but not a lower bound.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-688302")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2025")])]

#text("Is exercise 36 correct as stated? What I am getting instead of the last displayed equation in that exercise:")#linebreak()#text(" ")#tao-math("\\displaystyle \\left|\\sum_n \\frac{\\Lambda(n)}{n^\\sigma} \\mathrm{Re} \\left(n^{- i t}\\right)\\right| \\leq \\left(\\frac{2}{\\pi} + o(1)\\right) \\frac{1}{\\sigma-1},", block: false)

#text("and thus (given what we know given the pole of ")#mi("\\zeta(s)")#text(" at ")#mi("s=1")#text(", namely, (29)), by the triangle inequality,")

#tao-math("\\displaystyle \\left|\\sum_n \\frac{\\Lambda(n)}{n^\\sigma} \\left(1 + \\mathrm{Re} \\left(n^{- i t}\\right)\\right)\\right| \\geq \\left(1 - \\frac{2}{\\pi} + o(1)\\right) \\frac{1}{\\sigma-1},", block: false)

#text("which is enough to give a contradiction with (31).")

#text("(Of course we are still using the fact that there’s no such thing as zeros of fractional order.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-688303")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2025")])]

#text("And I guess the point of exercise 43(i) is to prove that *without* Borel-Carathéodory? (We have just proved something stronger using Borel-Carathéodory.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/#comment-688304")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2025")])]

#text("43(i) works in the larger range ")#mi("\\sigma \\geq 1 - \\frac{c \\log\\log t}{\\log t}")#text(", whereas the Borel-Caratheodory argument only applies in the smaller rnage ")#mi("\\sigma \\geq 1 - \\frac{c}{\\log t}")#text(".")
]
]
