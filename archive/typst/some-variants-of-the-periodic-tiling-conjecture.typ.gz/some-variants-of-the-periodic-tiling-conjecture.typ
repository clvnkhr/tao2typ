// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/05/12/some-variants-of-the-periodic-tiling-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T11:14:01.859383+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Some variants of the periodic tiling conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Some variants of the periodic tiling conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 May 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/05/12/some-variants-of-the-periodic-tiling-conjecture/")[#text("https://terrytao.wordpress.com/2025/05/12/some-variants-of-the-periodic-tiling-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("https://www.math.ias.edu/~rgreenfeld/")[#text("Rachel Greenfeld")]#text(" and I have just uploaded to the arXiv our paper ")#link("https://arxiv.org/abs/2505.06757")[#text("Some variants of the periodic tiling conjecture")]#text(". This paper explores variants of the periodic tiling phenomenon that, in ")#emph[#text("some")]#text(" cases, a tile that can translationally tile a group, must also be able to translationally tile the group periodically. For instance, for a given discrete abelian group ")#mi("{G}")#text(", consider the following question:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Question 1 (Periodic tiling question)")]#text(" Let ")#mi("{F}")#text(" be a finite subset of ")#mi("{G}")#text(". If there is a solution ")#mi("{1_A}")#text(" to the tiling equation ")#mi("{1_F * 1_A = 1}")#text(", must there exist a ")#emph[#text("periodic")]#text(" solution ")#mi("{1_{A_p}}")#text(" to the same equation ")#mi("{1_F * 1_{A_p} = 1}")#text("?")
]

#text("We know that the answer to this question is positive for finite groups ")#mi("{H}")#text(" (trivially, since all sets are periodic in this case), one-dimensional groups ")#mi("{{\\bf Z} \\times H}")#text(" with ")#mi("{H}")#text(" finite, and in ")#mi("{{\\bf Z}^2}")#text(", but it can fail for ")#mi("{{\\bf Z}^2 \\times H}")#text(" for certain finite ")#mi("{H}")#text(", and also for ")#mi("{{\\bf Z}^d}")#text(" for sufficiently large ")#mi("{d}")#text("; see ")#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/")[#text("this previous blog post for more discussion")]#text(". But now one can consider other variants of this question:")

#list(
[#text("Instead of considering level one tilings ")#mi("{1_F * 1_A = 1}")#text(", one can consider level ")#mi("{k}")#text(" tilings ")#mi("{1_F * 1_A = k}")#text(" for a given natural number ")#mi("{k}")#text(" (so that every point in ")#mi("{G}")#text(" is covered by exactly ")#mi("{k}")#text(" translates of ")#mi("{F}")#text("), or more generally ")#mi("{1_F * 1_A = g}")#text(" for some periodic function ")#mi("{g}")#text(".")],
[#text("Instead of requiring ")#mi("{1_F}")#text(" and ")#mi("{1_A}")#text(" to be indicator functions, one can allow these functions to be integer-valued, thus we are now studying convolution equations ")#mi("{f*a=g}")#text(" where ")#mi("{f, g}")#text(" are given integer-valued functions (with ")#mi("{g}")#text(" periodic and ")#mi("{f}")#text(" finitely supported).")]
)

#text("We are able to obtain positive answers to three such analogues of the periodic tiling conjecture for three cases of this question. The first result (which was kindly shared with us by Tim Austin), concerns the homogeneous problem ")#mi("{f*a = 0}")#text(". Here the results are very satisfactory:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (First periodic tiling result)")]#text(" ")#metadata(none) <tao-a7937b64b8caa58f0372>#text(" Let ")#mi("{G}")#text(" be a discrete abelian group, and let ")#mi("{f}")#text(" be integer-valued and finitely supported. Then the following are equivalent.")

#list(
[#text("(i) There exists an integer-valued solution ")#mi("{a}")#text(" to ")#mi("{f*a=0}")#text(" that is not identically zero.")],
[#text("(ii) There exists a periodic integer-valued solution ")#mi("{a_p}")#text(" to ")#mi("{f * a_p = 0}")#text(" that is not identically zero.")],
[#text("(iii) There is a vanishing Fourier coefficient ")#mi("{\\hat f(\\xi)=0}")#text(" for some non-trivial character ")#mi("{\\xi \\in \\hat G}")#text(" of finite order.")]
)
]

#text("By combining this result with an old result ")#link("https://zbmath.org/0138.03102")[#text("of Henry Mann")]#text(" about sums of roots of unity, as well as an even older decidability result ")#link("https://zbmath.org/0064.00803")[#text("of Wanda Szmielew")]#text(", we obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3")]#text(" Any of the statements (i), (ii), (iii) is algorithmically decidable; there is an algorithm that, when given ")#mi("{G}")#text(" and ")#mi("{f}")#text(" as input, determines in finite time whether any of these assertions hold.")
]

#text("Now we turn to the inhomogeneous problem in ")#mi("{{\\bf Z}^2}")#text(", which is the first difficult case (periodic tiling type results are easy to establish in one dimension, and trivial in zero dimensions). Here we have two results:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Second periodic tiling result)")]#text(" ")#metadata(none) <tao-16367aacb67a4a017c8d>#text(" Let ")#mi("{G={\\bf Z}^2}")#text(", let ")#mi("{g}")#text(" be periodic, and let ")#mi("{f}")#text(" be integer-valued and finitely supported. Then the following are equivalent.")

#list(
[#text("(i) There exists an integer-valued solution ")#mi("{a}")#text(" to ")#mi("{f*a=g}")#text(".")],
[#text("(ii) There exists a periodic integer-valued solution ")#mi("{a_p}")#text(" to ")#mi("{f * a_p = g}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Third periodic tiling result)")]#text(" ")#metadata(none) <tao-b1e99324505bd32da0e1>#text(" Let ")#mi("{G={\\bf Z}^2}")#text(", let ")#mi("{g}")#text(" be periodic, and let ")#mi("{f}")#text(" be integer-valued and finitely supported. Then the following are equivalent.")

#list(
[#text("(i) There exists an indicator function solution ")#mi("{1_A}")#text(" to ")#mi("{f*1_A=g}")#text(".")],
[#text("(ii) There exists a periodic indicator function solution ")#mi("{1_{A_p}}")#text(" to ")#mi("{f * 1_{A_p} = g}")#text(".")]
)
]

#text("In particular, the previously established case of periodic tiling conjecture for level one tilings of ")#mi("{{\\bf Z}^2}")#text(", is now extended to higher level. By an ")#link("https://zbmath.org/0137.01001")[#text("old argument of Hao Wang")]#text(", we now know that the statements mentioned in Theorem ")#link(<tao-b1e99324505bd32da0e1>)[#text("5")]#text(" are now also algorithmically decidable, although it remains open whether the same is the case for Theorem ")#link(<tao-16367aacb67a4a017c8d>)[#text("4")]#text(". We know from past results that Theorem ")#link(<tao-b1e99324505bd32da0e1>)[#text("5")]#text(" cannot hold in sufficiently high dimension (even in the classic case ")#mi("{g=1}")#text("), but it also remains open whether Theorem ")#link(<tao-16367aacb67a4a017c8d>)[#text("4")]#text(" fails in that setting.")

#text("Following past literature, we rely heavily on a ")#emph[#text("structure theorem")]#text(" for solutions ")#mi("{a}")#text(" to tiling equations ")#mi("{f*a=g}")#text(", which roughly speaking asserts that such solutions ")#mi("{a}")#text(" must be expressible as a finite sum of functions ")#mi("{\\varphi_w}")#text(" that are one-periodic (periodic in a single direction). This already explains why tiling is easy to understand in one dimension, and why the two-dimensional case is more tractable than the case of general dimension. This structure theorem can be obtained by averaging a ")#emph[#text("dilation lemma")]#text(", which is a somewhat surprising symmetry of tiling equations that basically arises from finite characteristic arguments (viewing the tiling equation modulo ")#mi("{p}")#text(" for various large primes ")#mi("{p}")#text(").")

#text("For Theorem ")#link(<tao-a7937b64b8caa58f0372>)[#text("2")]#text(", one can take advantage of the fact that the homogeneous equation ")#mi("{f*a=0}")#text(" is preserved under finite difference operators ")#mi("{\\partial_h a(x) := a(x+h)-a(x)}")#text(": if ")#mi("{a}")#text(" solves ")#mi("{f*a=0}")#text(", then ")#mi("{\\partial_h a}")#text(" also solves the same equation ")#mi("{f * \\partial_h a = 0}")#text(". This freedom to take finite differences one to selectively eliminate certain one-periodic components ")#mi("{\\varphi_w}")#text(" of a solution ")#mi("{a}")#text(" to the homogeneous equation ")#mi("{f*a=0}")#text(" until the solution is a pure one-periodic function, at which point one can appeal to an induction on dimension, to equate parts (i) and (ii) of the theorem. To link up with part (iii), we also take advantage of the existence of ")#link("https://en.wikipedia.org/wiki/Retract_(group_theory)")[#text("retraction homomorphisms")]#text(" from ")#mi("{{\\bf C}}")#text(" to ")#mi("{{\\bf Q}}")#text(" to convert a vanishing Fourier coefficient ")#mi("{\\hat f(\\xi)= 0}")#text(" into an integer solution to ")#mi("{f*a=0}")#text(".")

#text("The inhomogeneous results are more difficult, and rely on arguments that are specific to two dimensions. For Theorem ")#link(<tao-16367aacb67a4a017c8d>)[#text("4")]#text(", one can also perform finite differences to analyze various components ")#mi("{\\varphi_w}")#text(" of a solution ")#mi("{a}")#text(" to a tiling equation ")#mi("{f*a=g}")#text(", but the conclusion now is that the these components are determined (modulo ")#mi("{1}")#text(") by polynomials of one variable. Applying a retraction homomorphism, one can make the coefficients of these polynomials rational, which makes the polynomials periodic. This turns out to reduce the original tiling equation ")#mi("{f*a=g}")#text(" to a system of essentially local combinatorial equations, which allows one to “periodize” a non-periodic solution by periodically repeating a suitable block of the (retraction homomorphism applied to the) original solution.")

#text("Theorem ")#link(<tao-b1e99324505bd32da0e1>)[#text("5")]#text(" is significantly more difficult to establish than the other two results, because of the need to maintain the solution in the form of an indicator function. There are now ")#emph[#text("two")]#text(" separate sources of aperiodicity to grapple with. One is the fact that the polynomials involved in the components ")#mi("{\\varphi_w}")#text(" may have irrational coefficients (see Theorem 1.3 of ")#link("https://arxiv.org/abs/2010.03254")[#text("our previous paper")]#text(" for an explicit example of this for a level 4 tiling). The other is that in addition to the polynomials (which influence the fractional parts of the components ")#mi("{\\varphi_w}")#text("), there is also “combinatorial” data (roughly speaking, associated to the integer parts of ")#mi("{\\varphi_w}")#text(") which also interact with each other in a slightly non-local way. Once one can make the polynomial coefficients rational, there is enough periodicity that the periodization approach used for the second theorem can be applied to the third theorem; the main remaining challenge is to find a way to make the polynomial coefficients rational, while still maintaining the indicator function property of the solution ")#mi("{a}")#text(".")

#text("It turns out that the restriction homomorphism approach is no longer available here (it makes the components ")#mi("{\\varphi_w}")#text(" unbounded, which makes the combinatorial problem too difficult to solve). Instead, one has to first perform a second moment analysis to discern more structure about the polynomials involved. It turns out that the components ")#mi("{\\varphi_w}")#text(" of an indicator function ")#mi("{1_A}")#text(" can only utilize linear polynomials (as opposed to polynomials of higher degree), and that one can partition ")#mi("{{\\bf Z}^2}")#text(" into a finite number of cosets on which only three of these linear polynomials are “active” on any given coset. The irrational coefficients of these linear polynomials then have to obey some rather complicated, but (locally) finite, sentence in the theory of first-order linear inequalities over the rationals, in order to form an indicator function ")#mi("{1_A}")#text(". One can then use the Weyl equidistribution theorem to replace these irrational coefficients with rational coefficients that obey the same constraints (although one first has to ensure that one does not accidentally fall into the boundary of the constraint set, where things are discontinuous). Then one can apply periodization to the remaining combinatorial data to conclude.")

#text("A key technical problem arises from the discontinuities of the fractional part operator ")#mi("{\\{x\\}}")#text(" at integers, so a certain amount of technical manipulation (in particular, passing at one point to a weak limit of the original tiling) is needed to avoid ever having to encounter this discontinuity.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/12/some-variants-of-the-periodic-tiling-conjecture/#comment-688014")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2025")])]

#text("yay for the periodic tiling conjecture")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/12/some-variants-of-the-periodic-tiling-conjecture/#comment-688017")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2025")])]

#text("The link to retraction homomorphism definition seems to be broken")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/12/some-variants-of-the-periodic-tiling-conjecture/#comment-688037")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2025")])]

#text("“By an ")#link("https://terrytao.wordpress.com/2025/05/12/some-variants-of-the-periodic-tiling-conjecture/???")[#text("old argument of Hao Wang")]#text("” the link seems wrong.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e8b2e751c941899671368185e840a640c16d6548e1a1a2e7cbfa7cc6c543761d-f4999ed38d5dd1f20b6f5e9a7903e9416caba6c25a72bc2cbf308b3fc2abc388.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of runawaysupernaturally2e0836198d")]], [#link("https://terrytao.wordpress.com/2025/05/12/some-variants-of-the-periodic-tiling-conjecture/#comment-688079")[#strong[#text("runawaysupernaturally2e0836198d")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2025")])]

#text("Hi Professor Tao, I have a totally random question. I was reflecting how research mathematics is built upon layer after layer of proof. So I was wondering, if, say, your proofs about the periodic tiling conjecture in your latest paper with Rachel had to start from a suitable set of axioms, proving everything from there until they reached your main theorems, do you have any idea how many pages that would take? Please ignore if you think my question is stupid or frivolous!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/05/12/some-variants-of-the-periodic-tiling-conjecture/#comment-688081")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2025")])]

#text("I would say that a formal proof of this result, if done by standard methods, would be roughly comparable in length to the ")#link("https://github.com/teorth/pfr")[#text("formal proof of the Polynomial Freiman-Ruzsa conjecture")]#text(". This is thousands of lines of code of formal proofs, built on top of Mathlib which has over a million lines of code. However, only a tiny fraction of Mathlib is actually used in PFR, and I would imagine the same would be true here; but there hasn’t really been an attempt to aim for absolute minimality in most of these formalization projects, given that Mathlib already exists as a general purpose library to do most of mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d36763c476b561d1a41bc1b6f7d952ff15e8033376c25da8481a6e9e5d035cb-ad4607aef876d028a5f2929482e96437382cdf56e8d75c84382964286e6f4a8d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stefan Persich")]], [#link("https://terrytao.wordpress.com/2025/05/12/some-variants-of-the-periodic-tiling-conjecture/#comment-688287")[#strong[#text("Stefan Persich")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2025")])]

#text("“Fascinating work! I’ve solved the decidability of f∗a=g on ℤ² via a spectral criterion: solutions exist iff …. see: ")#link("https://doi.org/10.5281/zenodo.15596699")[#text("https://doi.org/10.5281/zenodo.15596699")]

#text("P.S. The core condition is delightfully simple: f̂ ≠ 0 on supp(ĝ)")#linebreak()#text("P.P.S. Python implementation included – handles asymmetric masks with ϵ-precision.”")
]
