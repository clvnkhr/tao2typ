// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/02/21/two-announcements/
// Converted to Typst by tao2typ: "2026-10-14T10:50:58.495386+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Two announcements", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Two announcements")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 February 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/02/21/two-announcements/")[#text("https://terrytao.wordpress.com/2019/02/21/two-announcements/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Now that Google Plus is closing, the brief announcements that I used to post over there will now be migrated over to this blog. (Some people have suggested other platforms for this also, such as Twitter, but I think for now I can use my existing blog to accommodate these sorts of short posts.)")

#enum(start: 1, 
[#text("The ")#link("https://www.cbmsweb.org/regional-conferences/")[#text("NSF-CBMS regional research conferences")]#text(" are now ")#link("https://www.cbmsweb.org/regional-conferences/call-for-proposals/")[#text("requesting proposals")]#text(" for the 2020 conference series. (I was the principal lecturer for one of these conferences back in 2005; it was a very intensive experience, but quite enjoyable, and I am quite pleased with ")#link("https://terrytao.wordpress.com/books/nonlinear-dispersive-equations-local-and-global-analysis/")[#text("the book that resulted from it")]#text(".)")],
[#text("The awardees for the Sloan Fellowships for 2019 ")#link("https://sloan.org/fellowships/2019-Fellows")[#text("have now been announced")]#text(". (I was on the committee for the mathematics awards. For the usual reasons involving the confidentiality of letters of reference and other sensitive information, I will be unfortunately be unable to answer any specific questions about our committee deliberations.)")]
)

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/21/two-announcements/#comment-512973")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2019")])]

#text("No one should be using Google products if had an iota of care regarding privacy issues.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03ecbae8784286921367d68217d35bfe77ebad24a79eb5e11604219f56b55a74-0eb6a25531341fb9165226ec2b7da6288d550fde45aee59e0462ec8dc4857f3b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of peeterjoot")]], [#link("https://terrytao.wordpress.com/2019/02/21/two-announcements/#comment-512986")[#strong[#text("peeterjoot")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2019")])]

#text("WordPress can tweet (and post to linked-in, facebook/… ) your posts automatically at the publish point. That way you can put a notification out on all the possible subscription channels that are available, covering all the possible preferences of the people that are interested in your content.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eae988277ab5af26a6868faf07ff52f678d6d4e55bf19dbae4de9ccc10f05921-36880b05d4b5563fa1a528f8c5decdf570948629ea58099fd0532ef22820807e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sha_bi_a_ti_ya")]], [#link("https://terrytao.wordpress.com/2019/02/21/two-announcements/#comment-512988")[#strong[#text("sha_bi_a_ti_ya")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2019")])]

#text("Very glad facebook is not considered. I prefer twitter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/21/two-announcements/#comment-513832")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2019")])]

#text("Hi, everyone.")#linebreak()#text(" We have more 4 days that our hearts are thumping to know who will win Abel prize. Sometime we wonder ourselves that if there is a Abel laureate who is the youngest man in the history under the age 45 getting this prize.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/21/two-announcements/#comment-513979")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2019")])]

#text("Wow, the first women win abel prize. Half happy, half sad!!!!!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous #2")]], [#link("https://terrytao.wordpress.com/2019/02/21/two-announcements/#comment-513983")[#strong[#text("Anonymous #2")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2019")])]

#text("Congratulations to Karen Uhlenbeck for winning the Abel Prize :).")
]
