// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T16:39:08.457359+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The convergence of an alternating series of Erdős, assuming the Hardy–Littlewood prime tuples conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The convergence of an alternating series of Erdős, assuming the Hardy–Littlewood prime tuples conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 August 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/")[#text("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("I have just uploaded to the arXiv my paper “")#link("https://arxiv.org/abs/2308.07205")[#text("The convergence of an alternating series of Erdős, assuming the Hardy–Littlewood prime tuples conjecture")]#text("“. This paper concerns an old problem of Erdős concerning whether the alternating series ")#mi("{\\sum_{n=1}^\\infty \\frac{(-1)^n n}{p_n}}")#text(" converges, where ")#mi("{p_n}")#text(" denotes the ")#mi("{n^{th}}")#text(" prime. The main result of this paper is that the answer to this question is affirmative assuming a sufficiently strong version of the ")#link("https://mathworld.wolfram.com/k-TupleConjecture.html")[#text("Hardy–Littlewood prime tuples conjecture")]#text(".")

#text("The ")#link("https://en.wikipedia.org/wiki/Alternating_series_test")[#text("alternating series test")]#text(" does not apply here because the ratios ")#mi("{\\frac{n}{p_n}}")#text(" are not monotonically decreasing. The deviations of monotonicity arise from fluctuations in the prime gaps ")#mi("{p_{n+1}-p_n}")#text(", so the enemy arises from biases in the prime gaps for odd and even ")#mi("{n}")#text(". By changing variables from ")#mi("{n}")#text(" to ")#mi("{p_n}")#text(" (or more precisely, to integers in the range between ")#mi("{p_n}")#text(" and ")#mi("{p_{n+1}}")#text("), this is basically equivalent to biases in the parity ")#mi("{(-1)^{\\pi(n)}}")#text(" of the ")#link("https://en.wikipedia.org/wiki/Prime-counting_function")[#text("prime counting function")]#text(". Indeed, it is an ")#link("https://mathoverflow.net/questions/313999/")[#text("unpublished observation of Said")]#text(" that the convergence of ")#mi("{\\sum_{n=1}^\\infty \\frac{(-1)^n n}{p_n}}")#text(" is equivalent to the convergence of ")#mi("{\\sum_{n=10}^\\infty \\frac{(-1)^{\\pi(n)}}{n \\log n}}")#text(". So this question is really about trying to get a sufficiently strong amount of equidistribution for the parity of ")#mi("{\\pi(n)}")#text(".")

#text("The prime tuples conjecture does not directly say much about the value of ")#mi("{\\pi(n)}")#text("; however, it can be used to control differences ")#mi("{\\pi(n+\\lambda \\log x) - \\pi(n)}")#text(" for ")#mi("{n \\sim x}")#text(" and ")#mi("{\\lambda>0}")#text(" not too large. Indeed, it is a famous ")#link("https://zbmath.org/0346.10024")[#text("calculation of Gallagher")]#text(" that for fixed ")#mi("{\\lambda}")#text(", and ")#mi("{n}")#text(" chosen randomly from ")#mi("{1}")#text(" to ")#mi("{x}")#text(", the quantity ")#mi("{\\pi(n+\\lambda \\log x) - \\pi(n)}")#text(" is distributed according to the Poisson distribution of mean ")#mi("{\\lambda}")#text(" asymptotically if the prime tuples conjecture holds. In particular, the parity ")#mi("{(-1)^{\\pi(n+\\lambda \\log x)-\\pi(n)}}")#text(" of this quantity should have mean asymptotic to ")#mi("{e^{-2\\lambda}}")#text(". An application of the ")#link("https://en.wikipedia.org/wiki/Van_der_Corput%27s_method")[#text("van der Corput ")#mi("{A}")#text("-process")]#text(" then gives some decay on the mean of ")#mi("{(-1)^{\\pi(n)}}")#text(" as well. Unfortunately, this decay is a bit too weak for this problem; even if one uses the most quantitative version of Gallagher’s calculation, worked out in a ")#link("https://arxiv.org/abs/2210.09775")[#text("recent paper of (Vivian) Kuperberg")]#text(", the best bound on the mean ")#tao-math("{\\left|\\frac{1}{x} \\sum_{n \\leq x} (-1)^{\\pi(n)}\\right|}", block: false)#text(" is something like ")#mi("{1/(\\log\\log x)^{-1/4+o(1)}}")#text(", which is not quite strong enough to overcome the doubly logarithmic divergence of ")#mi("{\\sum_{n=1}^\\infty \\frac{1}{n \\log n}}")#text(".")

#text("To get around this obstacle, we take advantage of the random sifted model ")#mi("{{\\mathcal S}_z}")#text(" of the primes that was introduced in a ")#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/")[#text("paper of Banks, Ford, and myself")]#text(". To model the primes in an interval such as ")#mi("{[n, n+\\lambda \\log x]}")#text(" with ")#mi("{n}")#text(" drawn randomly from say ")#mi("{[x,2x]}")#text(", we remove one random residue class ")#mi("{a_p \\text{ mod } p}")#text(" from this interval for all primes ")#mi("{p}")#text(" up to ")#link("https://zbmath.org/0092.04901")[#text("Pólya’s “magic cutoff”")]#text(" ")#mi("{z \\approx x^{1/e^\\gamma}}")#text(". The prime tuples conjecture can then be intepreted as the assertion that the random set ")#mi("{{\\mathcal S}_z}")#text(" produced by this sieving process is statistically a good model for the primes in ")#mi("{[n, n+\\lambda \\log x]}")#text(". After some standard manipulations (using a version of the ")#link("https://en.wikipedia.org/wiki/Boole%27s_inequality#Bonferroni_inequalities")[#text("Bonferroni inequalities")]#text(", as well as some upper bounds ")#link("https://arxiv.org/abs/2210.09775")[#text("of Kuperberg")]#text("), the problem then boils down to getting sufficiently strong estimates for the expected parity ")#tao-math("{{\\bf E} (-1)^{\\left|{\\mathcal S}_z\\right|}}", block: false)#text(" of the random sifted set ")#mi("{{\\mathcal S}_z}")#text(".")

#text("For this problem, the main advantage of working with the random sifted model, rather than with the primes or the singular series arising from the prime tuples conjecture, is that the sifted model can be studied iteratively from the partially sifted sets ")#mi("{{\\mathcal S}_w}")#text(" arising from sifting primes ")#mi("{p}")#text(" up to some intermediate threshold ")#mi("{w<z}")#text(", and that the expected parity of the ")#mi("{{\\mathcal S}_w}")#text(" experiences some decay in ")#mi("{w}")#text(". Indeed, once ")#mi("{w}")#text(" exceeds the length ")#mi("{\\lambda \\log x}")#text(" of the interval ")#mi("{[n,n+\\lambda \\log x]}")#text(", sifting ")#mi("{{\\mathcal S}_w}")#text(" by an additional prime ")#mi("{p}")#text(" will cause ")#mi("{{\\mathcal S}_w}")#text(" to lose one element with probability ")#tao-math("{\\left|{\\mathcal S}_w\\right|/p}", block: false)#text(", and remain unchanged with probability ")#tao-math("{1 - \\left|{\\mathcal S}_w\\right|/p}", block: false)#text(". If ")#tao-math("{\\left|{\\mathcal S}_w\\right|}", block: false)#text(" concentrates around some value ")#mi("{\\overline{S}_w}")#text(", this suggests that the expected parity ")#tao-math("{{\\bf E} (-1)^{\\left|{\\mathcal S}_w\\right|}}", block: false)#text(" will decay by a factor of about ")#tao-math("{\\left|1 - 2 \\overline{S}_w/p\\right|}", block: false)#text(" as one increases ")#mi("{w}")#text(" to ")#mi("{p}")#text(", and iterating this should give good bounds on the final expected parity ")#tao-math("{{\\bf E} (-1)^{\\left|{\\mathcal S}_z\\right|}}", block: false)#text(". It turns out that existing second moment calculations ")#link("https://zbmath.org/1124.11048")[#text("of Montgomery and Soundararajan")]#text(" suffice to obtain enough concentration to make this strategy work.")

#heading(level: 1)[#text("Comments (29)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8227f99ec4952fff9a5f3fa21caf4d99bb95fa1f01a956516f2393806ca8de66-311487389dee65622d7b642b4f4a7d348f1cd3f60fb9b7132effa2ab9bd4fac3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Osama Basta")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-680780")[#strong[#text("Osama Basta")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2023")])]

#text("I have employed the z variant of the transform in my paper ")#link("https://vixra.org/pdf/2307.0094v1.pdf")[#text("https://vixra.org/pdf/2307.0094v1.pdf")]#linebreak()#text(" and used pi*nlog(n) which is the original form inside the instead of 1/(6x^2) + 1/(4x) which is an approximation of pi(n) the prime counting function.")#linebreak()#text(" i found analytically that the first question converges to -0.05")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-680792")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2023")])]

#text("Is assumption 1.3 (without knowledge of explicit values of the two absolute constants ")#mi("C, \\epsilon")#text(" sufficient for the sum to be effectively computable?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-680802")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2023")])]

#text("I don’t think I can make the arguments effective without knowing explicit values the constant ")#mi("C")#text(" for Conjecture 1.3, as for any given value of ")#mi("x")#text(", this conjecture will trivially hold for some sufficiently large value of ")#mi("C")#text(" depending on ")#mi("x")#text(", so the conjecture has no content non-asymptotically without specifying the constant.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5fc4fc930916070f40c634c9b1c5092cf7a1b16386b2daa203d404d762a136e3-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Maugham")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-680793")[#strong[#text("William Maugham")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2023")])]

#text("Very.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/acbd30cc44ffa7e48cb00283dcbc110b1e2a6c82ec35a189ffaaaf8fe38b3342-668f9032da9f19dd9b84d0baa9dfd5fd9df05f28f687b7f4c34813aa27dfcaec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Snæ")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-680805")[#strong[#text("Snæ")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2023")])]

#text("Kudos.")

#text("Just found this conjecture (3 weeks ago) from")#linebreak()#text(" Thomas Bloom’s page:")#linebreak()#text(" ")#link("https://www.erdosproblems.com/15")[#text("https://www.erdosproblems.com/15")]#linebreak()#text(" Which only contained the first sentence until your article.")

#text("Tried from a computational point of view.")#linebreak()#text(" Looking at the differences between the even and odd indices of each result. Then try for a curve fit to determine where the difference could be zero.")

#text("Doubt any of my data is of value; at least I improved my programming skills.")

#text("It will take some time to digest your paper.")#linebreak()#text(" Thanks for the read.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-680807")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2023")])]

#text("Prof. Tao:")#linebreak()#text(" The proof is based on a conjecture that hasn’t been proven. Is this a good practice? If the conjecture is wrong, then the work would be void.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-680808")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2023")])]

#text("Conditional results are of course not as strong as unconditional results, but the former often arise as a precursor to the latter; a desired result might first be proven assuming one or more standard conjectures, and later work, inspired by this initial conditional result, removes the dependence on these conjectures.")

#text("In analytic number theory, many sought after results are extremely difficult to prove unconditionally, so conditional proofs are the next best thing, and can supply heuristic confirmation of the result at least, especially given that many of the standard conjectures in analytic number theory, such as the prime tuples conjecture, are quite firmly believed and have a fair amount of numerical, rigorous, or heuristic supporting evidence in their favor.")

#text("Another value of conditional results is that they can highlight the importance of the conjecture being relied upon. Part of the reason that the Riemann hypothesis, for instance, is considered so important is that there is an extremely large number of conditional implications of this hypothesis (and its generalizations) throughout analytic number theory.")

#text("Occasionally, one finds that a conjecture conditionally implies a result that one can demonstrate by other means to be false, in which case this automatically disproves the initial conjecture, which is also a noteworthy accomplishment. One reason to pursue conditional implications of the Siegel zero hypothesis, for instance, is to eventually find a way to disprove this hypothesis (which is widely believed to be false, but has proven extremely stubborn to actually eliminate).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/618cf1f04f8a18eecb1f10f266821e7393feeb97598d32289f48ad8030cb9938-cfc0ce0b3d592e30da34d56ba5b8e4e05f67604304a8cea7731d51a12818b5ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-680810")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2023")])]

#text("Tim Gowers has written a nice essay which touches upon conditional proofs, among other practice of practical mathematics research")

#link("https://mathstodon.xyz/@wtgowers/110639100049503090")[#text("https://mathstodon.xyz/@wtgowers/110639100049503090")]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("From time to time I like to dabble in philosophy, and a little while ago I wrote an article, based on two seminars I had given at the Collège de France, on probabilistic judgments in mathematics. What are they, and how do we make them?")

#text("One might argue that a decidable mathematical statement either has a proof or has a disproof, so either it is definitely true or it is definitely false. And yet mathematicians frequently express degrees of belief in statements for which they lack proofs or disproofs.")
]

#link("https://mxphi.com/wp-content/uploads/2023/04/MxPhi-Gowers2023.pdf")[#text("What Makes Mathematicians Believe Unproved Mathematical Statements?")]

#text("Annals of Mathematics and Philosophy")#linebreak()#text(" vol. 1, no 1, 2023")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d28195df14800315168ea974f4adf888eace7d3a34fc83513af492698793a2c-e2ad3cdfa379c5dcf139408dc5d555ac7c236dfa87abd3799a789b51ef5d74f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kodlu")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-680846")[#strong[#text("kodlu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2023")])]

#text("Possibly naive question: Since the Hardy-Littlewood prime $k-$tuples conjecture and the Second Hardy-Littlewood (2HL) conjecture ($\\pi(x+y)\\leq \\pi(x)+\\pi(y)$) are contradictory (from memory) I wonder if anything useful could be said about the relationship between 2HL and your new result.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-680975")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2023")])]

#text("Unfortunately the implications here flow in the wrong direction to say anything about the second Hardy-Littlewood conjecture, which as you say is known to be false under the assumption of the prime tuples conjecture. Meanwhile, the result in my paper shows that the Erdos sum is convergent under the assumption of the prime tuples conjecture. The basic takeaway here is that the prime tuples conjecture is a powerful conjecture that allows one to settle (either positively or negatively) many other conjectures involving the primes.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-680812")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2023")])]

#text("Sayid observed the sum going from n = 2, not n =10. Is this somehow relevant?")

#emph[#text("[No. I chose to start most series in my paper from 10 rather than 2 to ensure that both ")#mi("\\log n")#text(" and ")#mi("\\log\\log n")#text(" are positive, but it makes little difference to the convergence. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d53e8f616e1cc702ad6ba157664cd356b47102d6038e60cca329d73d4baeb6b3-cda5b9b97f8dae72de29875b9acd434b372753229a5ed320ffc0fb57e029866c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Audigé")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-680813")[#strong[#text("Emmanuel Audigé")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2023")])]

#text("Hi professor Tao. This are good news.")#linebreak()#text(" Finding this question interesting, I think maybe looking the sums over divisors of numbers (-1)^d can help grasping more informations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ac3c76aa80d152ff714ebde7860c6f7faa34ec75003e82518a3612d564cfe22-1ebff00a84a42d109c55c13c09f479a57e6eaee2aac59060c8356b26585ebe2c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-680845")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2023")])]

#text("The name Kuperberg does not uniquely define a mathematician, rather there are at least three generations :-)")

#emph[#text("[First name added to clarify – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-680869")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2023")])]

#text("Is it possible by this method to decide the summability of any similar alternating series where ")#mi("n/p_n")#text(" is replace by any rational function of ")#mi("n, p_n")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-680976")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2023")])]

#text("It’s possible, but (as with many Erdos questions) the particular question involving ")#mi("n/p_n")#text(" is very finely balanced, in the interesting boundary zone between problems that can be resolved by a straightforward application of known methods, and problems which have so many complexities and obstacles that they are significantly more difficult than simpler claims that are still out of reach. The quantity ")#mi("n/p_n")#text(" is of size about ")#mi("1/\\log n")#text(" (which is why, by the way, the series is not absolutely convergent), but the difference between consecutive terms is far smaller:")

#mi("\\frac{n}{p_n} - \\frac{n+1}{p_{n+1}} = n \\frac{p_{n+1}-p_n}{p_n p_{n+1}} - \\frac{1}{p_{n+1}}.")#text("$")

#text("The second term ")#mi("-\\frac{1}{p_{n+1}}")#text(" is monotone decreasing and can be handled by the alternating series test. Heuristically, the prime gap ")#mi("p_{n+1} - p_n")#text(" is of size about ")#mi("\\log n")#text(", and so the first term should be of size about ")#mi("\\frac{1}{n \\log n}")#text(" – just barely short of being summable, so one still has to squeeze a little more cancellation out of the sum (which is where the prime tuples conjecture comes in, as this conjecture is known to control the distribution of the prmie gap).")

#text("If one repeated this sort of calculation with another expression than ")#mi("n/p_n")#text(", most likely one would either get a sum with terms decaying so fast that it was easy to establish convergence, or a sum whose terms diverged so slowly that convergence was either false, or impossible to prove with existing technology.")

#text("Erdos may have made the task of posing productive mathematical questions look effortless, but I believe he must have actually put a lot of prior effort in testing each of his questions against existing methods before releasing them, as the overwhelming majority of them do land in the narrow interesting boundary zone mentioned above.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-681016")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2023")])]

#text("An update: William Banks has informed me that the arguments for ")#mi("\\sum_{n=1}^\\infty \\frac{(-1)^n n}{p_n}")#text(" in my paper can be adapted to the variant sum ")#mi("\\sum_{n=1}^\\infty \\frac{z^n n}{p_n}")#text(" for any ")#mi("z")#text(" on the unit circle other than 1. Thus, assuming a strong version of the prime tupoles conjecture, this power series converges on the boundary of its disk of convergence except at ")#mi("z=1")#text(" where it diverges.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-681034")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2023")])]

#text("Since the Taylor coefficients ")#mi("n/p_n")#text(" of this variant series are quite “noisy”, is it possible that this series has the unit circle as its natural boundary?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-681115")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2023")])]

#text("Nice question! I would also expect the circle to be the natural boundary, in analogy with random power series as you indicate. Proving it rigorously (even with the prime tuples conjecture) could be a challenge though. It morally amounts to getting *lower bounds* on the rate of convergence of (smoothed) partial sums, rather than upper bounds which was the focus of my paper. I’ll add it as an open question in the next revision of the ms.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b79af867da5b26d1e99314d2ada0f8624de4e40523136377a239ec20fec3f4c3-9fc098e083af397379b7a49bc964a02ac1ae358657e24f34aa87342844202003.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ofir G.")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-680871")[#strong[#text("Ofir G.")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2023")])]

#text("I’d like to point out that the computation of ")#mi("\\sum_{1 \\le h_1,h_2\\le H}\\mathfrak{S}(h_1,h_2)")#text(", used in p. 9 of your preprint, has a confusing history. A weak version of it appears in Lemma 2 of Montgomery’s “Primes in arithmetic progressions” (1970), which is also the last chapter of his book “Topics in Multiplicative Number Theory” (1971). It gives ")#mi("2\\sum_{0<h_1<h_2\\lambda H}\\mathfrak{S}(\\{h_1,h_2\\}) = H^2 + O(H \\log H)")#text(". The sharper estimate with ")#mi("H^2 - H\\log H + O(H)")#text(" was known to Montgomery during the same time. In fact, the lower order term ")#mi("-H \\log H")#text(" was central for coming up with his Pair Correlation Conjecture (this is alluded to in his paper introducing the conjecture, and also indicated explicitly in Montgomery and Soundararajan's \"Beyond Pair Correlation\"). A proof of the ")#mi("H^2-H\\log H+O(H)")#text(" estimate is given in Croft's \"Square-free numbers in arithmetic progressions\" (1975). Finally, the estimate ")#mi("H^2 - H \\log H + CH+ O_{\\varepsilon}(H^{1/2+\\varepsilon})")#text(" for an explicit $C$ was given by Goldston's \"Linnik’s theorem on Goldbach numbers in short intervals\" (1990) in equation (33), but without proof. A proof of a more general statement was given in Friedlander and Goldston \"Variance of distribution of primes in residue classes\" (Proposition 3).")

#emph[#text("[Thanks for the references! These will be incorporated into the next version of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-680922")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2023")])]

#text("Is it known whether the non-alternating version – just sum of n/p(n) – converges?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-680971")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2023")])]

#text("Yes one has divergence.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e88190c3a9656c5d444e38198fc1f970903afbc1aed7bad22e8086b235a06ee5-1a808067e899ad202b421116fe9ceabbb890f094f8c2845ca868dea2ad21a269.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Binbin Hu")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-680999")[#strong[#text("Binbin Hu")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2023")])]

#text("Just a simple question about the shift operation in the proof of the equivalence of Q1.1 and Q1.2. From my understanding, the shift operation is ")#mi("\\sum_{1 \\leq n \\leq x} \\frac{(-1)^n n}{p_n}= \\frac{{(-1)}^1 \\cdot 1}{p_1} +\\sum_{1 \\leq n \\leq x} \\frac{(-1)^{n+1}(n+1)}{p_{n+1}}+o(1)")#text(", and the first term on the right-hand side should be ")#mi("- \\frac{1}{2}")#text(". (The constant term has absolutely no influence to the valid proof.)")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Baxter")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-681017")[#strong[#text("Jonathan Baxter")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2023")])]

#text("Don’t keep us in suspense…")

#text("To what does it converge?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Baxter")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-681019")[#strong[#text("Jonathan Baxter")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2023")])]

#text("Nevermind. Now I read the paper, it’s ~ -0.05. Surprising. Almost cancels. I would have expected something a lot larger (in absolute value).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Baxter")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-681020")[#strong[#text("Jonathan Baxter")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2023")])]

#text("This post has Said’s sum starting at 10, whereas the paper has it starting at 2 (obviously both are correct, but the 10 in this version had me scratching my head).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b569ab6e7e3d7906c75b26228bb124f88e299a60f22618bcb8846df553ea7ad-f4d6150803cd83679d270d45b0ebd17630784da51d524022a26e5ab5e18ca754.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Goldston")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-681027")[#strong[#text("Daniel Goldston")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2023")])]

#text("This is an amazing proof, especially using the Banks-Ford-Tao large prime gap probability model as tool in the proof. Not directly related to the paper, I want to mention that for the average of the singular series over two-tuples, which is equivalent to the Cesaro mean of the singular series, the error term ")#mi("H^{1/2+\\epsilon}")#text(" mentioned in the comments above was improved by Vaughan in 2001 using the zero-free region and also assuming RH he obtained the error term ")#mi("H^{5/12+\\epsilon}")#text(". Recently Suriajaya and I proved that this error term is ")#mi("\\Omega_{\\pm}(H^{1/4}")#text(". This is on the Arxiv or JNT 227 (2021) 144-157.")

#emph[#text("[Thanks for the references – these will be added to the next revision of the MS. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/41a5a0b3b7b40f3b3a34d59c1b2741aaa5391bd73354321ca0b2271d0daf6453-3af58e866e713d8735fc731a76486fb160803aa4579677db04dca5fd4e8a96f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Keiju Sono")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-681357")[#strong[#text("Keiju Sono")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2023")])]

#text("Very interesting paper. I found a couple of minor mistakes. I apologize if I am mistaken.")#linebreak()#text(" p2. In the definition of the singular series, \\nu _{H}(p) should be divided by p.")#linebreak()#text(" The last line of p5. The n in the binomial coefficient should be N.")#linebreak()#text(" p5. In the proof of Lemma 3.1, f(r+2)-f(r) changes sign when r=(2N-4)/3.")#linebreak()#text(" p11. line 5. I think “for some absolute constant c>0” is unnecessary.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-681921")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2023")])]

#text("I apologize Pr. This is a series of conjectures of my highschool student (Ousmanou Abdou Mohamadou from Cameroon): ")#link("https://www.researchgate.net/publication/374388548_OUSMANOU's_CONJECTURES_PART_1")[#text("https://www.researchgate.net/publication/374388548_OUSMANOU's_CONJECTURES_PART_1")]#text(" Tthe curious conjecture P10: Let p_n be the n^th prime number after the first 2, and p_m be the m^th prime number ( n,m≥4):")#linebreak()#text(" for all natural numbers k,r one has |〖p_n〗^2k-〖p_m〗^2r | multiple of 24 . Please could any one help us? thanks. Yannick.")

#text("Kouakep’s comment: maybe a quadratic distance between prime numbers, following P10?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/#comment-687542")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2025")])]

#link("https://arxiv.org/abs/2502.03474")[#text("https://arxiv.org/abs/2502.03474")]

#text("The transforming series into Riemann-Stieltjes integrals where one can evaluate the interplay between the integrand and integrator under Hölder continuity can be fundamental in the convergence of special series.Here an example about the Flint-Hills series.")
]
