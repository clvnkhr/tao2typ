// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/
// Converted to Typst by tao2typ: "2026-10-14T16:36:14.795120+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mini-polymath2 discussion thread", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mini-polymath2 discussion thread")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 July 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/")[#text("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’ve just ")#link("http://polymathprojects.org/2010/07/08/minipolymath2-project-imo-2010-q5/")[#text("opened the Mini-polymath2 project")]#text(" over at the ")#link("http://polymathprojects.org/")[#text("polymath blog")]#text(". I decided to use ")#link("http://www.imo-official.org/problems.aspx")[#text("Q5")]#text(" from the ")#link("http://www.imo2010org.kz/")[#text("2010 IMO")]#text(" in the end, rather than Q6, as it seems to be a little bit more challenging and interesting.")

#text("This post will serve as the discussion thread of the project, intended to focus all the non-research aspects of the project such as organisational matters or commentary on the progress of the project. (Is it possible for one blog thread to “live-blog” another?) The third component of the project is the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2010")[#text("wiki page")]#text(", which is intended to summarise the progress made so far on the problem.")

#text("As with ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2009_q6")[#text("mini-polymath1")]#text(", I myself will be serving primarily as a moderator, and hope other participants will take the lead in the research and in keeping the wiki up-to-date. (Ideally, once we get all the kinks in the format ironed out, it should be possible for anyone with a blog and an interested pool of participants to start their own mini-polymath project, without being overly dependent on one key contributor.)")

#heading(level: 1)[#text("Comments (27)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45844")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")])]

#text("So, it’s only been an hour since the project started and there are already 30 comments, with a lot of good initial observations and partial results. (The objective is to create a state with ")#mi("2010^{2010^{2010}}")#text(" coins, and we’ve got as far as ")#mi("7 \\times 2^{27}")#text(" so far.) I have my hands full just updating the wiki to keep up…")

#text("Incidentally, now that there is a substantial body of comments, I would be interested to see how easy it is for casual participants to keep up with what is going on. (This was the biggest concern from mini-polymath1, that there was such a flood of unorganised comments that it was difficult to follow.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cc1550fd626707a8555f381bfa23639e7960de9728f4a9b6377064c44784499d-a5b5ac1e19e1f9cc7f1a2d3c8f9ec71ae1f3b01b522cb12fbf43d2d1c9d61aa0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexandr Kazda")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45847")[#strong[#text("Alexandr Kazda")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")])]

#text("The first hour was quite hectic and I was scooped two or three times. Now, it seems things have calmed down a bit (it helps that the wiki will get more important now). All in all, I can work in this environment but anything that makes comments easier to organize is still welcome.")

#text("Maybe tags would help to keep different lines of thought in order (eg. #invariant, #record, #fiveboxes or some such)?")

#text("If I might have a wish, I would like to have some sort of “preview” function so that I can make sure my posts will look all right.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45849")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")])]

#text("Yes, comment preview is the most commonly requested feature; unfortunately the wordpress hosting site that I use does not allow it. It is certainly on the wish list of any future dedicated platform for this sort of thing, though.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-46073")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2010")])]

#text("Perhaps this is a silly idea of mine. One could create a new WordPress blog only to be used as a comment editor.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45848")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")])]

#text("It appears that we have our first solution, approximately 2 hours and 28 minutes after the project began:")

#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2010#First_solution")[#text("http://michaelnielsen.org/polymath1/index.php?title=Imo_2010#First_solution")]

#text("There are still some interesting questions, though, such as trying to get reasonable bounds on the largest number of coins one can generate with, say, six boxes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45851")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")])]

#text("It looks like there is now a second solution.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f74fdb0dcaa0cd19704c7a2ecd5ca1ce3c536fc69389e58e0904d9077155ca68-40bd8040410cbdbc5674a935f2b8c93254533911e7f6b0f0fe68b5f8871a1b42.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SM")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45853")[#strong[#text("SM")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")])]

#text("Hey, this was fun! You should definitely do it again next year. =)")

#text("The threads were really not clearly laid out at all, though. I could not follow many subdiscussions and I guess this was the same for everyone.")

#text("That also explains that there were clearly some “subgroups” forming around certain threads…")

#text("I have no solution to this problem, and I doubt there is a solution at all. I think that it would increase clarity though, if the “sub-replies” to replies were hidden and you could pop them up, if you wanted to read.")

#text("For example post 27 had all the necessary information for a solution to the problem, but I don’t think anyone had noticed it.")

#text("One might also consider to subdivide the discussion into different “paths” (i.e. investigations into negative/positive solutions).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74f2eb4f4ae429dbd6dbd0399b17d262c3f2ec93ee4d804cfa1125cc6a2af3ba-9788302ae2e0e47605a619f56820160310facb535e777b20d83d4d6ef793fada.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jerzy")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45855")[#strong[#text("Jerzy")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")])]

#text("Thank you for organizing this! I had to leave partway through, but I had a blast!")#linebreak()#text(" I know this one was timed based on when the IMO questions were released, but perhaps a future mini-polymath could happen on a weekend so that it doesn’t conflict with being at work :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45859")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")])]

#text("Some thoughts.")

#text("This has been the shortest polymath project to date – the original aims of the project were basically accomplished in two and a half hours. Given that the format of the Olympiad is three questions of this type to be solved in four and a half hours, this is probably comparable in performance to that of a good Olympiad contestant (I would be interested though to see the statistics for the competition).")

#text("In retrospect, the problem was quite straightforward in nature – there were a half-dozen key observations to be made before the solution became clear, but they all arose naturally (and perhaps more importantly, no significant false leads came up to tie up a lot of time and mental resources). It’s interesting to note that each of the key observations basically came from a different polymath participant, so in that sense the polymath structure worked exactly as intended. One particular strength of the format seems to be that one participant can post a half-finished calculation and another participant can quickly complete it, if the calculation was set up in such a way that it could easily be continued. There were a couple of useful examples of that happening in this mini-polymath.")

#text("Organising the comments continues to be a significant problem. The ability to nest comments seems to have helped a little bit as compared with mini-polymath1, but near the end the discussion was fragmenting into many parallel threads and it was difficult to keep on top of all of them. If the project proceeded at a slower pace then one could conceivably put more effort into summarising the progress so far, for instance at every rollover of the research thread, but the project moved too quickly and finished too soon for this to occur (we didn’t even need to roll over once). The wiki never really got a chance to get going as a consequence, but I still think it was a good thing that it was there right from the start.")

#text("I hope other participants share their impressions of the project while the memory is still fresh!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6283bf39bafac2594aea3625fed70c953488097341517ac20bd2ba0858a4947b-c962d3db0e41129565753700059a8c61be8f55b7d44ebc35f8af86a6b3109078.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron Hill")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45860")[#strong[#text("Aaron Hill")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")])]

#text("This was a lot of fun. Thanks for organizing it.")

#text("A couple of thoughts:")

#text("I wonder how many people would be interested in a regular event like this. It would be easy to set a time each week (maybe Saturday mornings) and do, one at a time, the other 5 IMO problems (and maybe then move to past IMO’s or Putnams, or other problems).")

#text("I wonder if something like this could easily be done at a lower level without getting “spoilers.” For example, I suspect that when I was in high school I would have liked something like this if it were an AIME level question (or easier). In a situation like that, though, you wouldn’t want someone coming in and solving the question so efficiently that others wouldn’t have a chance to struggle with things.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45865")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")])]

#text("I quite like this idea; I had not previously realised that one could use the polymath format for social mathematical purposes.")

#text("One could have an organisation somewhat like the Carnival of Mathematics, in which there is a global organiser to schedule and announce the various mini-polymath projects, but each project is hosted by a local organiser at their own blog (using the wiki as a shared resource). There is no reason to restrict attention to IMO problems; one could use a variety of problem databases (e.g. Putnam problems are another obvious choice), and maybe even some research-level problems if they are feasible and short enough. I doubt I will be able to be a local organiser on a regular basis, but I would be happy to be a global organiser for such an enterprise. This could provide a steady stream of further mini-polymath experiments which one could use to refine the format.")

#text("So far I have not encountered significant problems with spoilers or with people being at the wrong level for the problem at hand – the self-selecting nature of the project, combined with requests to avoid spoilers or individual attempts at a solution, seems to resolve the issue. But it would be good to collect some further data on this.")

#text("I wonder what interest there would be for such a regular activity, both on the participant and the organiser side. (There is not much to do on the organising side beyond what is regularly needed to run a mathematical blog, save perhaps the ability to discern what type of problem might be suitable for a polymath project – it seems that one needs a certain level of difficulty without being so technical that very few participants can actively contribute.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6283bf39bafac2594aea3625fed70c953488097341517ac20bd2ba0858a4947b-c962d3db0e41129565753700059a8c61be8f55b7d44ebc35f8af86a6b3109078.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron Hill")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45925")[#strong[#text("Aaron Hill")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2010")])]

#text("Maybe others could comment of the feasibility of something like this for undergraduate students and beyond, but as far as high school is concerned, I suspect that a typical high school has at least 2-3 students that would be interested in something like this. It could be a sort of virtual math circle. By the way, even if I overestimated and there was only 1 interested high school student per two or three high schools, this would still be thousands of students that would be interested in participating. The issues seem to be:")

#text("1) Global organization (as Terry mentioned).")

#text("2) Local hosting (as Terry mentioned). The local (not geographic) host needs to choose the problem, make sure things are running smoothly, and ideally works to improve the mini-polymath platform.")

#text("3) Recognition. A student can’t participate if they aren’t aware of its existence.")

#text("My impression is that “The art of problem solving” (")#link("http://www.artofproblemsolving.com")[#text("http://www.artofproblemsolving.com")]#text(") has a lot of excellent resources, mostly web based, for high school (and middle school) students. I wonder if they might be interested in something of this sort.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of obryant")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45870")[#strong[#text("obryant")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")])]

#text("Or, the ")#link("http://www.math.u-szeged.hu/~mmaroti/schweitzer/")[#text("Schweitzer competition")]#text(" problems, for something more involved.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cy")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45917")[#strong[#text("cy")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2010")])]

#text("or, the International Mathematics Competition for University Students,")#linebreak()#text(" ")#link("http://www.imc-math.org.uk/")[#text("http://www.imc-math.org.uk/")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45864")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")])]

#text("Dear Professor Tao:")

#text("How about Google Wave? Did you try using it to discuss mathematics?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45866")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")])]

#text("I use Wave for one or two collaborations, though I personally prefer the blog medium (I have a number of private blogs for such purposes). But it would be an interesting experiment to host polymath or mini-polymath projects on other forums than a WordPress blog; I wouldn’t have the time to be a local organiser for such an experiment in the near future, but perhaps someone else here might be willing to try.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45867")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")])]

#text("It seems the fact that the number of participants is very large is also an important elment to the success of such an experiment. But using Wave may be a little difficult to get attention to so many people in the same time. However, Wave maybe better for a few people to engage in serious researches.")

#text("Another thought, I find the most suitable problems for polymath are usually about constructive proofs. This seems easier for all the participants to continue with each other’s partial results. Just like in this project, the Compound moves became crutial in the last a few moments. The process is just like construct a building. Considering the previous polymath projects are mostly dealing with problems of this kind, a question is, can this be improved in the future?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45868")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")])]

#text("The proceeding time of this one is not very good for Chinese mathematicians. It ends at about three o’clock in the morning. I am sorry I didn’t participant. I was gonna. I really hope some similiar project can be organized in the near future.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 关于Mini-polymath2 « Xiaochuan Liu's Weblog")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45869")[#strong[#text("关于Mini-polymath2 « Xiaochuan Liu's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")])]

#text("[…] 关于Mini-polymath2 昨夜Terry Tao组织讨论2010年IMO的第五题。以mini-polymath的形式，整个过程可以说迅雷不及掩耳。我本来在想一些问题，大概仅仅2个半小时左右，这次讨论基本接近了尾声。这个计划结束时差不多已经凌晨三点。这里是这个活动的讨论贴。而这里是整个讨论过程。和去年的情形相比，今年效率大大提高。一方面参与者做好了准备，另一方面Tao的组织更有力。去年时候讨论了差不多三天。而且长时间处于无人组织的状态。另外，尽管有各种方法希望让后参与者更容易加入讨论，但是本次似乎所有主要参与者都是从那个头到尾一直在场的。还有一个问题就是，到目前为止似乎polymath的活动都是构造性的证明。我想，这是因为构造性的证明更容易总结。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45879")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2010")])]

#text("Oops — I missed it! At some point I’ll have a look through the comments though. Is there any evidence that collaboration played a part in the finding of solutions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45888")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2010")])]

#text("The first answer which was the first post of comment thread 34 seemed to follow roughly from the ideas of the first post of comment thread 30 which referred to comment thread 7 and comment thread 13. So it looks to me as if there is evidence of collaboration.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45886")[#strong[#text("Mini-Polymath2 « Euclidean Ramsey Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2010")]

#text("[…] is also a discussion thread and a wiki […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mmailliw/william")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45912")[#strong[#text("mmailliw/william")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2010")])]

#text("Even though I overslept through the first half of this (I have the exact opposite problem from Xiaochun with the time) this was a great experience for me.")

#text("I was expecting there to be more people than there were, and although I always felt a bit behind when trying to work with the problem, I’m surprised I managed to do as much as I did…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-45980")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2010")])]

#text("The problem was a good one, but a little too easy – it was all over too quickly. It was not necessary to understand the shape of the functions involved to solve the problem.")

#text("Collaboration focussed the mind on key questions early on.")

#text("I’ve posted some suggestions on the problem thread which I think will illuminate what is going on with the functions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b19f0989a2533bede23e7f8221f95e26a87f80ab18296f4b2ca084257c411725-b3f71506597860ef7a28b32c92c0c11ff2b44b15db8c1a440dd9ce83b97770e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Evgenij Thorstensen")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-46042")[#strong[#text("Evgenij Thorstensen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2010")])]

#text("I just read through the thread and wiki (unfortunately I could not participate this time). I could follow the threads of thoughts to a large extent, but I have a suggestion for the wiki: Mark observations, solutions, etc. with posts related to them whenever possible (or perhaps whenever clear which posts these are). In particular, several of the observations spawned more discussion, and knowing where in the thread to look would make catching up easier.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-46167")[#strong[#text("IMO 2010 « Absolutely useless")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2010")]

#text("[…] we, together with China and US, was the best country on problem 5 (a problem that Tao thought was more challenging and interesting than problem 6). Denmark is usually in the second half on the country list, and even in a good year […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fab9617feead85791489a2e0e27db3083e1496bf3142530deb16e2ca99ce13e1-87593c0d57df34d8dc86a69d760e6dcdd19c75d41622c585e3099188c6431f18.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stan Wagon")]], [#link("https://terrytao.wordpress.com/2010/07/08/mini-polymath2-discussion-thread/#comment-477538")[#strong[#text("Stan Wagon")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2017")])]

#text("I posted this problem on my Problem of the Week forum, and as a result Richard Stong (San Diego) obtained a remarkable formula for the maximum number of coins one can get IN THE GENERAL CASE! And he has a proof as well. Links to his proof can be found in the solution notes to my post:")

#text("Click “View the solution” here:")

#link("http://mathforum.org/wagon/2017/p1233.html")[#text("http://mathforum.org/wagon/2017/p1233.html")]

#text("Again, his formula is truly beautiful (and shows that the world records on the wiki page for this problem are indeed optimal.")

#text("Stan Wagon")
]
