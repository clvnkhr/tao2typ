// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/
// Converted to Typst by tao2typ: "2026-10-14T15:18:06.834434+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Brouwer’s fixed point and invariance of domain theorems, and Hilbert’s fifth problem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Brouwer’s fixed point and invariance of domain theorems, and Hilbert’s fifth problem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 June 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/")[#text("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("We recall ")#link("http://en.wikipedia.org/wiki/Brouwer_fixed_point_theorem")[#text("Brouwer’s famous fixed point theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Brouwer fixed point theorem)")]#text(" ")#metadata(none) <tao-992a93455c71fedd36ac>#text(" Let ")#mi("{f: B^n \\rightarrow B^n}")#text(" be a continuous function on the unit ball ")#tao-math("{B^n := \\{ x \\in {\\bf R}^n: \\left\\|x\\right\\| \\leq 1 \\}}", block: false)#text(" in a Euclidean space ")#mi("{{\\bf R}^n}")#text(". Then ")#mi("{f}")#text(" has at least one fixed point, thus there exists ")#mi("{x \\in B^n}")#text(" with ")#mi("{f(x)=x}")#text(".")
]

#text("This theorem has many proofs, most of which revolve (either explicitly or implicitly) around the notion of the ")#link("http://en.wikipedia.org/wiki/Degree_of_a_continuous_mapping")[#text("degree")]#text(" of a continuous map ")#mi("{f: S^{n-1} \\rightarrow S^{n-1}}")#text(" of the unit sphere ")#tao-math("{S^{n-1} := \\{ x \\in {\\bf R}^n: \\left\\|x\\right\\|=1\\}}", block: false)#text(" to itself, and more precisely around the ")#emph[#text("stability")]#text(" of degree with respect to homotopy. (Indeed, one can view the Brouwer fixed point theorem as an assertion that some non-trivial degree-like invariant must exist, or more abstractly that the homotopy group ")#mi("{\\pi_{n-1}(S^{n-1})}")#text(" is non-trivial.)")

#text("One of the many applications of this result is to prove ")#link("http://en.wikipedia.org/wiki/Invariance_of_domain")[#text("Brouwer’s invariance of domain theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Brouwer invariance of domain theorem)")]#text(" ")#metadata(none) <tao-e52da16bce3e0b1b8459>#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf R}^n}")#text(", and let ")#mi("{f: U \\rightarrow {\\bf R}^n}")#text(" be a continuous injective map. Then ")#mi("{f(U)}")#text(" is also open.")
]

#text("This theorem in turn has an important corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3 (Topological invariance of dimension)")]#text(" ")#metadata(none) <tao-3f1970acc66289ecfd91>#text(" If ")#mi("{n > m}")#text(", and ")#mi("{U}")#text(" is a non-empty open subset of ")#mi("{{\\bf R}^n}")#text(", then there is no continuous injective mapping from ")#mi("{U}")#text(" to ")#mi("{{\\bf R}^m}")#text(". In particular, ")#mi("{{\\bf R}^n}")#text(" and ")#mi("{{\\bf R}^m}")#text(" are not homeomorphic.")
]

#text("This corollary is intuitively obvious, but note that topological intuition is not always rigorous. For instance, it is intuitively plausible that there should be no continuous surjection from ")#mi("{{\\bf R}^m}")#text(" to ")#mi("{{\\bf R}^n}")#text(" for ")#mi("{n>m}")#text(", but such surjections always exist, thanks to variants of the ")#link("http://en.wikipedia.org/wiki/Space-filling_curve")[#text("Peano curve")]#text(" construction.")

#text("Theorem ")#link(<tao-e52da16bce3e0b1b8459>)[#text("2")]#text(" or Corollary ")#link(<tao-3f1970acc66289ecfd91>)[#text("3")]#text(" can be proven by simple ")#emph[#text("ad hoc")]#text(" means for small values of ")#mi("{n}")#text(" or ")#mi("{m}")#text(" (for instance, by noting that removing a point from ")#mi("{{\\bf R}^n}")#text(" will disconnect ")#mi("{{\\bf R}^n}")#text(" when ")#mi("{n=1}")#text(", but not for ")#mi("{n>1}")#text("), but I do not know of any proof of these results in general dimension that does not require algebraic topology machinery that is at least as sophisticated as the Brouwer fixed point theorem. (Lebesgue, for instance, famously failed to establish the above corollary rigorously, although he did end up discovering the important concept of ")#link("http://en.wikipedia.org/wiki/Lebesgue_covering_dimension")[#text("Lebesgue covering dimension")]#text(" as a result of his efforts.)")

#text("Nowadays, the invariance of domain theorem is usually proven using the machinery of ")#link("http://en.wikipedia.org/wiki/Singular_homology")[#text("singular homology")]#text(". In this post I would like to record a short proof of Theorem ")#link(<tao-e52da16bce3e0b1b8459>)[#text("2")]#text(" using Theorem ")#link(<tao-992a93455c71fedd36ac>)[#text("1")]#text(" that I discovered in a ")#link("http://www.ams.org/mathscinet-getitem?mr=1696596")[#text("paper of Kulpa")]#text(", which avoids any use of algebraic topology tools beyond the fixed point theorem, though it is more ")#emph[#text("ad hoc")]#text(" in its approach than the systematic singular homology approach.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" A heuristic explanation as to why the Brouwer fixed point theorem is more or less a necessary ingredient in the proof of the invariance of domain theorem is that a counterexample to the former result could conceivably be used to create a counterexample to the latter one. Indeed, if the Brouwer fixed point theorem failed, then (as is well known) one would be able to find a continuous function ")#mi("{F: B^n \\rightarrow S^{n-1}}")#text(" that was the identity on ")#mi("{S^{n-1}}")#text(" (indeed, one could take ")#mi("{F(x)}")#text(" to be the first point in which the ray from ")#mi("{f(x)}")#text(" through ")#mi("{x}")#text(" hits ")#mi("{S^{n-1}}")#text("). If one then considered the function ")#mi("{G: B^n \\rightarrow {\\bf R}^n}")#text(" defined by ")#tao-math("{G(x) := (1+\\left\\|x\\right\\|) F(x)}", block: false)#text(", then this would be a continuous function which avoids the interior of ")#mi("{B^n}")#text(", but which maps the origin ")#mi("{0}")#text(" to a point on the sphere ")#mi("{S^{n-1}}")#text(" (and maps ")#mi("{S^{n-1}}")#text(" to the dilate ")#mi("{2 \\cdot S^{n-1}}")#text("). This could conceivably be a counterexample to Theorem ")#link(<tao-e52da16bce3e0b1b8459>)[#text("2")]#text(", except that ")#mi("{G}")#text(" is not necessarily injective. I do not know if there is a more rigorous way to formulate this connection.")
]

#text("The reason I was looking for a proof of the invariance of domain theorem was that it comes up in the very last stage of the solution to ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_fifth_problem")[#text("Hilbert’s fifth problem")]#text(", namely to establish the following fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Hilbert’s fifth problem)")]#text(" ")#metadata(none) <tao-1774b8eebdec58c5f119>#text(" Every locally Euclidean group is isomorphic to a Lie group.")
]

#text("Recall that a ")#emph[#text("locally Euclidean")]#text(" group is a topological group which is locally homeomorphic to an open subset of a Euclidean space ")#mi("{{\\bf R}^n}")#text(", i.e. it is a continuous manifold. Note in contrast that a Lie group is a topological group which is locally ")#emph[#text("diffeomorphic")]#text(" to an open subset of ")#mi("{{\\bf R}^n}")#text(", it is a ")#emph[#text("smooth")]#text(" manifold. Thus, Hilbert’s fifth problem is a manifestation of the “rigidity” of algebraic structure (in this case, group structure), which turns weak regularity (continuity) into strong regularity (smoothness).")

#text("It is plausible that something like Corollary ")#link(<tao-3f1970acc66289ecfd91>)[#text("3")]#text(" would need to be invoked in order to solve Hilbert’s fifth problem. After all, if Euclidean spaces ")#mi("{{\\bf R}^n}")#text(", ")#mi("{{\\bf R}^m}")#text(" of different dimension were homeomorphic to each other, then the property of being locally Euclidean loses a lot of meaning, and would thus not be a particularly powerful hypothesis. Note also that it is clear that two Lie groups can only be isomorphic if they have the same dimension, so in view of Theorem ")#link(<tao-1774b8eebdec58c5f119>)[#text("4")]#text(", it becomes plausible that two Euclidean spaces can only be homeomorphic if they have the same dimension, although I do not know of a way to rigorously deduce this claim from Theorem ")#link(<tao-1774b8eebdec58c5f119>)[#text("4")]#text(".")

#text("Interestingly, Corollary ")#link(<tao-3f1970acc66289ecfd91>)[#text("3")]#text(" is the only place where algebraic topology enters into the solution of Hilbert’s fifth problem (although its cousin, ")#emph[#text("point-set topology")]#text(", is used all over the place). There are results closely related to Theorem ")#link(<tao-1774b8eebdec58c5f119>)[#text("4")]#text(", such as the Gleason-Yamabe theorem mentioned in ")#link("https://terrytao.wordpress.com/2011/05/30/van-dantzigs-theorem/")[#text("a recent post")]#text(", which do not use the notion of being locally Euclidean, and do not require algebraic topological methods in their proof. Indeed, one can deduce Theorem ")#link(<tao-1774b8eebdec58c5f119>)[#text("4")]#text(" from the Gleason-Yamabe theorem and invariance of domain; we sketch a proof of this (following ")#link("http://www.ams.org/mathscinet-getitem?mr=73104")[#text("Montgomery and Zippin")]#text(") below the fold.")

#metadata(none) <tao-2aec18fb3ea320c46867>

#heading(level: 1)[#strong[#text(" — 1. Invariance of domain — ")]]

#text("Now we prove Theorem ")#link(<tao-e52da16bce3e0b1b8459>)[#text("2")]#text(". By rescaling and translation invariance, it will suffice to show the following claim:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Invariance of domain, again)")]#text(" ")#metadata(none) <tao-b4c9e14061c2fd453b36>#text(" Let ")#mi("{f: B^n \\rightarrow {\\bf R}^n}")#text(" be an continuous injective map. Then ")#mi("{f(0)}")#text(" lies in the interior of ")#mi("{f(B^n)}")#text(".")
]

#text("Let ")#mi("{f}")#text(" be as in Theorem ")#link(<tao-b4c9e14061c2fd453b36>)[#text("5")]#text(". The map ")#mi("{f: B^n \\rightarrow f(B^n)}")#text(" is a continuous bijection between compact Hausdorff spaces and is thus a homeomorphism. In particular, the inverse map ")#mi("{f^{-1}: f(B^n) \\rightarrow B^n}")#text(" is continuous. Using the ")#link("http://en.wikipedia.org/wiki/Tietze_extension_theorem")[#text("Tietze extension theorem")]#text(", we can find a continuous function ")#mi("{G: {\\bf R}^n \\rightarrow {\\bf R}^n}")#text(" that extends ")#mi("{f^{-1}}")#text(".")

#text("The function ")#mi("{G}")#text(" has a zero on ")#mi("{f(B^n)}")#text(", namely at ")#mi("{f(0)}")#text(". We can use the Brouwer fixed point theorem to show that this zero is stable:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (Stability of zero)")]#text(" ")#metadata(none) <tao-c6508bd394398ac383f6>#text(" Let ")#mi("{\\tilde G: f(B^n) \\rightarrow {\\bf R}^n}")#text(" be a continuous function such that ")#tao-math("{\\left\\|G(y)-\\tilde G(y)\\right\\| \\leq 1}", block: false)#text(" for all ")#mi("{y \\in f(B^n)}")#text(". Then ")#mi("{\\tilde G}")#text(" has at least one zero (i.e. there is a ")#mi("{y \\in f(B^n)}")#text(" such that ")#mi("{\\tilde G(y)=0}")#text(").")
]

#emph[#text("Proof:")]#text(" Apply Theorem ")#link(<tao-992a93455c71fedd36ac>)[#text("1")]#text(" to the function")

#align(center)[#tao-fit-display[#mitex("x \\mapsto x - \\tilde G(f(x)) = G(f(x)) - \\tilde G(f(x)).")]]

#mi("\\Box")

#text("Now suppose that Theorem ")#link(<tao-b4c9e14061c2fd453b36>)[#text("5")]#text(" failed, so that ")#mi("{f(0)}")#text(" is not an interior point of ")#mi("{f(B^n)}")#text(". We will use this to locate a small perturbation of ")#mi("{G}")#text(" that no longer has a zero on ")#mi("{f(B^n)}")#text(", contradicting Lemma ")#link(<tao-c6508bd394398ac383f6>)[#text("6")]#text(".")

#text("We turn to the details. Let ")#mi("{\\epsilon > 0}")#text(" be a small number. By continuity of ")#mi("{G}")#text(", we see (if ")#mi("{\\epsilon}")#text(" is chosen small enough) that we have ")#tao-math("{\\left\\|G(y)\\right\\| \\leq 0.1}", block: false)#text(" whenever ")#mi("{y \\in {\\bf R}^n}")#text(" and ")#tao-math("{\\left\\|y-f(0)\\right\\| \\leq 2\\epsilon}", block: false)#text(".")

#text("On the other hand, since ")#mi("{f(0)}")#text(" is not an interior point of ")#mi("{f(B^n)}")#text(", there exists a point ")#mi("{c \\in {\\bf R}^n}")#text(" with ")#tao-math("{\\left\\|c-f(0)\\right\\| < \\epsilon}", block: false)#text(" that lies outside ")#mi("{f(B^n)}")#text(". By translating ")#mi("{f}")#text(" if necessary, we may take ")#mi("{c=0}")#text("; thus ")#mi("{f(B^n)}")#text(" avoids zero, ")#tao-math("{\\left\\|f(0)\\right\\| < \\epsilon}", block: false)#text(", and we have ")#metadata(none) <tao-0450a072a036895fa66a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\|G(y)\\right\\| \\leq 0.1 \\text{ whenever } \\left\\|y\\right\\| \\leq \\epsilon.", block: true)]]

#text("Let ")#mi("{\\Sigma}")#text(" denote the set ")#mi("{\\Sigma := \\Sigma_1 \\cup \\Sigma_2}")#text(", where")

#align(center)[#tao-fit-display[#tao-math("\\Sigma_1 := \\{ y \\in f(B^n): \\left\\|y\\right\\| \\geq \\epsilon \\}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\Sigma_2 := \\{ y \\in {\\bf R}^n: \\left\\|y\\right\\| = \\epsilon \\}.", block: true)]]

#text("By construction, ")#mi("{\\Sigma}")#text(" is compact but does not contain ")#mi("{f(0)}")#text(". Crucially, there is a continuous map ")#mi("{\\Phi: f(B^n) \\rightarrow \\Sigma}")#text(" defined by setting ")#metadata(none) <tao-e46fd696bb4d24c149d4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\Phi(y) := \\max( \\frac{\\epsilon}{\\left\\|y\\right\\|}, 1 ) y.", block: true)]]

#text("Note that ")#mi("{\\Phi}")#text(" is continuous and well-defined since ")#mi("{f(B^n)}")#text(" avoids zero. Informally, ")#mi("{\\Sigma}")#text(" is a perturbation of ")#mi("{f(B^n)}")#text(" caused by pushing ")#mi("{f(B^n)}")#text(" out a small distance away from the origin ")#mi("{0}")#text(" (and hence also away from ")#mi("{f(0)}")#text("), with ")#mi("{\\Phi}")#text(" being the “pushing” map.")

#text("By construction, ")#mi("{G}")#text(" is non-zero on ")#mi("{\\Sigma_1}")#text("; since ")#mi("{\\Sigma_1}")#text(" is compact, ")#mi("{G}")#text(" is bounded from below on ")#mi("{\\Sigma_1}")#text(" by some ")#mi("{\\delta > 0}")#text(". By shrinking ")#mi("{\\delta}")#text(" if necessary we may assume that ")#mi("{\\delta < 0.1}")#text(".")

#text("By the ")#link("http://en.wikipedia.org/wiki/Weierstrass_approximation_theorem")[#text("Weierstrass approximation theorem")]#text(", we can find a polynomial ")#mi("{P: {\\bf R}^n \\rightarrow {\\bf R}^n}")#text(" such that ")#metadata(none) <tao-f0b8c9d84dd2b877e0b9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\| P(y) - G(y) \\right\\| < \\delta", block: true)]]

#text("for all ")#mi("{y \\in \\Sigma}")#text("; in particular, ")#mi("{P}")#text(" does not vanish on ")#mi("{\\Sigma_1}")#text(". At present, it is possible that ")#mi("{P}")#text(" vanishes on ")#mi("{\\Sigma_2}")#text(". But as ")#mi("{P}")#text(" is smooth and ")#mi("{\\Sigma_2}")#text(" has measure zero, ")#mi("{P(\\Sigma_2)}")#text(" also has measure zero; so by shifting ")#mi("{P}")#text(" by a small generic constant we may assume without loss of generality that ")#mi("{P}")#text(" also does not vanish on ")#mi("{\\Sigma_2}")#text(". (If one wishes, one can use an algebraic geometry argument here instead of a measure-theoretic one, noting that ")#mi("{P(\\Sigma_2)}")#text(" lies in an algebraic hypersurface and can thus be generically avoided by perturbation. A purely topological way to avoid zeroes in ")#mi("{\\Sigma_2}")#text(" is also given in ")#link("http://www.ams.org/mathscinet-getitem?mr=1696596")[#text("Kulpa’s paper")]#text(".)")

#text("Now consider the function ")#mi("{\\tilde G: f(B^n) \\rightarrow {\\bf R}^n}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("\\tilde G(y) := P( \\Phi( y ) ).")]]

#text("This is a continuous function that is never zero. From ")#link(<tao-f0b8c9d84dd2b877e0b9>)[#text("(3)")]#text(", ")#link(<tao-e46fd696bb4d24c149d4>)[#text("(2)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| G(y) - \\tilde G(y) \\right\\| < \\delta", block: true)]]

#text("whenever ")#mi("{y \\in f(B^n)}")#text(" is such that ")#tao-math("{\\left\\|y\\right\\| > \\epsilon}", block: false)#text(". On the other hand, if ")#tao-math("{\\left\\|y\\right\\| \\leq \\epsilon}", block: false)#text(", then from ")#link(<tao-e46fd696bb4d24c149d4>)[#text("(2)")]#text(", ")#link(<tao-0450a072a036895fa66a>)[#text("(1)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| G(y) \\right\\|, \\left\\| G( \\Phi(y) ) \\right\\| \\leq 0.1", block: true)]]

#text("and hence by ")#link(<tao-f0b8c9d84dd2b877e0b9>)[#text("(3)")]#text(" and the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| G(y) - \\tilde G(y) \\right\\| \\leq 0.2 + \\delta.", block: true)]]

#text("Thus in all cases we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| G(y) - \\tilde G(y) \\right\\| \\leq 0.2 + \\delta \\leq 0.3", block: true)]]

#text("for all ")#mi("{y \\in f(B^n)}")#text(". But this, combined with the non-vanishing nature of ")#mi("{\\tilde G}")#text(", contradicts Lemma ")#link(<tao-c6508bd394398ac383f6>)[#text("6")]#text(".")

#heading(level: 1)[#strong[#text(" — 2. Hilbert’s fifth problem — ")]]

#text("We now sketch how invariance of domain can be used to establish the solution to Hilbert’s fifth problem (as formulated in Theorem ")#link(<tao-1774b8eebdec58c5f119>)[#text("4")]#text("). Our main tool is the Gleason-Yamabe theorem, in the form stated in Theorem 4 of ")#link("https://terrytao.wordpress.com/2011/05/30/van-dantzigs-theorem/")[#text("this previous post")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Gleason-Yamabe theorem)")]#text(" Every locally compact Hausdorff group has an open subgroup that is the projective limit of Lie groups.")
]

#text("A locally Euclidean group is of course locally compact Hausdorff; it is also first countable, and hence (by the ")#link("https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/")[#text("Birkhoff-Kakutani theorem")]#text(", discussed in this post) is also metrisable. Because of this, it is not difficult to show that the open subgroup given by the Gleason-Yamabe theorem in this case can be obtained as a projective limit")

#align(center)[#tao-fit-display[#mitex("G := \\lim_{\\stackrel{\\leftarrow}{n}} G_n")]]

#text("of a ")#emph[#text("countable sequence")]#text(" ")#mi("{(G_n)_{n \\in {\\bf N}}}")#text(" of Lie groups, with continuous homomorphisms from ")#mi("{G_{n+1}}")#text(" to ")#mi("{G_n}")#text(" for each ")#mi("{n}")#text(".")

#text("Using Cartan’s theorem to obtain the smoothness of outer automorphisms on Lie groups as ")#link("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/")[#text("in")]#text(" ")#link("https://terrytao.wordpress.com/2011/05/30/van-dantzigs-theorem/")[#text("previous")]#text(" ")#link("https://terrytao.wordpress.com/2011/07/05/central-extensions-of-lie-groups-and-cocycle-averaging/")[#text("posts")]#text(", we see that to show that a topological group is a Lie group, it suffices to locate an open subgroup that is a Lie group. In view of these reductions, it suffices to show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8")]#text(" Let ")#mi("{G}")#text(" be a locally Euclidean group that is the inverse limit")

#align(center)[#tao-fit-display[#mitex("G := \\lim_{\\stackrel{\\leftarrow}{n}} G_n")]]

#text("of Lie groups. Then ")#mi("{G}")#text(" is itself isomorphic to a Lie group.")
]

#text("We now prove the proposition. We first observe by shrinking the ")#mi("{G_n}")#text(" if necessary (and using Cartan’s theorem that locally compact subgroups of a Lie group are still Lie) we may assume that all the projection maps in the inverse limit are surjective; indeed, by local compactness we may take ")#mi("{G_n = G/H_n}")#text(" where ")#mi("{H_n}")#text(" are a sequence of compact normal subgroups converging to the identity.")

#text("As continuous homomorphisms of Lie groups are automatically smooth (as proven in ")#link("https://terrytao.wordpress.com/wp-admin/post.php?post=4906&action=edit")[#text("this previous post")]#text("), the projection maps from ")#mi("{G_{n+1}}")#text(" to ")#mi("{G_n}")#text(" induce an associated projection map from ")#mi("{{\\mathfrak g}_{n+1}}")#text(" to ")#mi("{{\\mathfrak g}_n}")#text(" at the Lie algebra level. As the former maps are surjective, the latter maps are also. In particular, the dimensions of the finite-dimensional Lie algebras ")#mi("{{\\mathfrak g}_n}")#text(" are non-decreasing in ")#mi("{n}")#text(".")

#text("Another consequence of surjectivity is that every tangent vector in ")#mi("{{\\mathfrak g}_n}")#text(" can be lifted up to ")#mi("{{\\mathfrak g}_{n+1}}")#text(". Continuing this process and passing to the inverse limit, it is possible to show that every one-parameter subgroup in one of the factor groups ")#mi("{G_n}")#text(" can be lifted up (locally, at least) to a one-parameter subgroup of ")#mi("{G}")#text(". In fact, one can show that a neighbourhood of the origin in ")#mi("{{\\mathfrak g}_n}")#text(" can be lifted up into ")#mi("{G}")#text(", to provide a continuous injection of a non-empty open subset of that Lie algebra into ")#mi("{G}")#text(".")

#text("Now we crucially use the invariance of domain (Corollary ")#link(<tao-3f1970acc66289ecfd91>)[#text("3")]#text(") to conclude that the dimensions of the Lie algebras ")#mi("{{\\mathfrak g}_n}")#text(" must be bounded in ")#mi("{n}")#text(" (indeed, they cannot exceed the dimension of the locally Euclidean group ")#mi("{G}")#text("). As these dimensions are non-decreasing, they must therefore be eventually constant; by discarding finitely many of the factor groups, we may thus assume that all the ")#mi("{G_n}")#text(" have the same dimension. In particular, the kernels of the projection maps from ")#mi("{G_{n+1}}")#text(" to ")#mi("{G_n}")#text(" are zero-dimensional Lie groups and are thus discrete. As ")#mi("{G_n = G/H_n}")#text(", this means that the ")#mi("{H_n/H_{n+1}}")#text(" are also discrete, thus ")#mi("{H_{n+1}}")#text(" is an open subgroup of ")#mi("{H_n}")#text(", and so (by compactness of ")#mi("{H_n}")#text(") has finite index. As the ")#mi("{H_n}")#text(" converge to the trivial group as ")#mi("{n \\rightarrow \\infty}")#text(", we conclude that each of the ")#mi("{H_n}")#text(" are ")#link("http://en.wikipedia.org/wiki/Profinite_group")[#text("profinite")]#text(", and in particular are totally disconnected. Thus, for any ")#mi("{n}")#text(", we have a short exact sequence")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow H_n \\rightarrow G \\rightarrow G_n \\rightarrow 0")]]

#text("describing ")#mi("{G}")#text(" as the extension of a Lie group ")#mi("{G_n}")#text(" by a totally disconnected compact group ")#mi("{H_n}")#text(". Furthermore, we can lift a small neighbourhood of the identity of ")#mi("{G_n}")#text(" to ")#mi("{G}")#text(" in a continuously injective manner. This neighbourhood is connected, and acts on the normal subgroup ")#mi("{H_n}")#text(" by conjugation. But ")#mi("{H_n}")#text(" is totally disconnected, and so all orbits of this action must be points; thus, the lift of this neighbourhood commutes with ")#mi("{H_n}")#text(". As a consequence, one can show that ")#mi("{G}")#text(" has the local topological (and group) structure of the direct product ")#mi("{H_n \\times G_n}")#text(". But ")#mi("{G}")#text(" is also locally Euclidean; as ")#mi("{H_n}")#text(" is totally disconnected, these two statements are only compatible if ")#mi("{H_n}")#text(" is discrete. Thus the Lie group ")#mi("{G_n}")#text(" is an open subgroup of ")#mi("{G}")#text(", and we are done.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The above argument shows that any metrisable group which is “finite-dimensional” in the sense that it does not contain continuous injective images of non-trivial open sets of Euclidean spaces ")#mi("{{\\bf R}^n}")#text(" of arbitrarily large dimension, has the local structure (as a topological space) of the product of a Euclidean space and a totally disconnected space. Of course, direct products of Lie groups and totally disconnected groups provide one such example of this claim. A more non-trivial example is given by the ")#link("http://en.wikipedia.org/wiki/Solenoid_(mathematics)")[#text("solenoid groups")]#text(", a simple example of which is the (additive) group")

#align(center)[#tao-fit-display[#mitex("G := ({\\bf Z}_p \\times {\\bf R}) / {\\bf Z}^\\Delta")]]

#text("where ")#mi("{{\\bf Z}^\\Delta := \\{ (n,n): n \\in {\\bf Z} \\}}")#text(" is the diagonally embedded copy of the integers. This is a compact Hausdorff group that has a short exact sequence")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow {\\bf Z}_p \\rightarrow G \\rightarrow {\\bf R}/{\\bf Z} \\rightarrow 0")]]

#text("and has the local structure of ")#mi("{{\\bf Z}_p \\times {\\bf R}/{\\bf Z}}")#text(", although ")#mi("{{\\bf R}/{\\bf Z}}")#text(" does not embed into this group and so this is not a direct or semi-direct product. (Topologically, it can be viewed as the set ")#mi("{{\\bf Z}_p \\times [0,1]}")#text(" after identifying ")#mi("{(x,0)}")#text(" with ")#mi("{(x+1,1)}")#text(" for every ")#mi("{p}")#text("-adic integer ")#mi("{x \\in {\\bf Z}_p}")#text(".) It has topological dimension one, in the sense that it contains continuous injective images of non-empty open subsets of ")#mi("{{\\bf R}^n}")#text(" if and only if ")#mi("{n \\leq 1}")#text(" (Exercise!). It is also the projective limit of the Lie groups")

#align(center)[#tao-fit-display[#mitex("G_n := (({\\bf Z}/p^n{\\bf Z}) \\times {\\bf R})/{\\bf Z}^\\Delta,")]]

#text("each of which is isomorphic to the circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(", but in a manner which becomes increasingly “twisted” as ")#mi("{n}")#text(" increases (which helps explain the terminology “solenoid”). It is an instructive exercise to verify that ")#mi("{G}")#text(" is connected, but not path connected or locally connected. Thus we see that connected locally compact groups can contain some significant non-Lie behaviour, even in the abelian setting.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" Of course, it is possible for locally compact groups to be infinite-dimensional; a simple example is the infinite-dimensional torus ")#mi("{({\\bf R}/{\\bf Z})^{\\bf N}}")#text(", which is compact, abelian, metrisable, and locally connected, but infinite dimensional. (It will still be an inverse limit of Lie groups, though.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" The above analysis also gives another purely topological characterisation of Lie groups; a topological group is Lie if and only if it is locally compact, Hausdorff, first-countable, locally connected, and finite-dimensional. It is interesting to note that this characterisation barely uses the real numbers ")#mi("{{\\bf R}}")#text(", which are of course fundamental in defining the smooth structure of a Lie group; the only remaining reference to ")#mi("{{\\bf R}}")#text(" comes through the notion of finite dimensionality. It is also possible, using ")#link("http://en.wikipedia.org/wiki/Dimension_theory")[#text("dimension theory")]#text(", to obtain alternate characterisations of finite dimensionality (e.g. finite ")#link("http://en.wikipedia.org/wiki/Lebesgue_covering_dimension")[#text("Lebesgue covering dimension")]#text(") that avoid explicit mention of the real line, thus capturing the concept of a Lie group using only the concepts of point-set topology (and the concept of a group, of course).")
]

#heading(level: 1)[#text("Comments (24)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59872241946d6a7c018e64e0a70a24cc0d11c2be35045fe4a65375142e2e3f8a-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alon Amit")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-53857")[#strong[#text("Alon Amit")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2011")])]

#text("On the off chance that you haven’t seen it before, I thought I should mention Milnor’s “strange but quite elementary” proof of the Brouwer fixed-point theorem, one which avoids algebraic topology altogether and relies instead on a volume computation.")

#text("The paper is called “Analytic proofs of the ‘Hairy Ball Theorem’ and the Brouwer Fixed Point Theorem”. A copy is available here: people.ucsc.edu/~lewis/Math208/hairyball.pdf.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0407444868fc42987e0e767c3fa8c7571cd73af435533bcece7a36bd594b0514-2ae27efe97fcf1ece7ea67e36afa94eee62825664716dc4ee7cf030a881d77c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shannon7774")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-54012")[#strong[#text("shannon7774")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2011")])]

#text("I also thought there was a non-topological, analytical proof in Evan’s textbook “PDE’s,” in Chapter 8. Maybe the version in Evans’ is a version of Milnor’s proof.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08de2108b849e3613fc1f6aa7937ff55b7720fe331a9397ab0e8e7eaed9fb861-cf28b702498a979bb4c3b6666cbcf55901a00e7480dca5b0b58b6fd383e040c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-54015")[#strong[#text("Dave")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2011")])]

#text("Of course, there is also the purely combinatorial proof using Sperner’s lemma:")#linebreak()#text(" ")#link("http://en.wikipedia.org/wiki/Sperner's_lemma")[#text("http://en.wikipedia.org/wiki/Sperner's_lemma")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-54086")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2011")])]

#text("That is indeed a strange but lovely proof! (The idea is to deduce the fixed point theorem from the hairy ball theorem, and to prove the latter by observing that a smooth unit vector field on ")#mi("S^{n-1}")#text(" gives rise (for small t) to a diffeomorphism between the unit ball and the ball of radius ")#mi("\\sqrt{1+t^2}")#text(" whose Jacobian depends polynomially on t, implying that ")#mi("(1+t^2)^{n/2}")#text(" is a polynomial, which is absurd for n odd.) It may be that a degree-like invariant is somehow disguised inside the volume computation (it does faintly resemble the analytic representations of degree) but I don’t see exactly how. In any case, this is the first proof I’ve seen that doesn’t obviously involve some sort of degree (or disguised version thereof).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rigidity of algebraic structure: principle of common cause | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-53868")[#strong[#text("Rigidity of algebraic structure: principle of common cause | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2011")])]

#text("[…] In his latest post Tao writes that Thus, Hilbert’s fifth problem is a manifestation of the “rigidity” of algebraic structure (in this case, group structure), which turns weak regularity (continuity) into strong regularity (smoothness). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/19f2fe7b7f034d9d01d35e97bd62d141f6d6f7b2be0ee205896fe4b60644c30f-8099a62c3618dbfb13c35296e6d3b6595d6dfdd53918b78bc84faac0071523cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of eitan bachmat")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-54003")[#strong[#text("eitan bachmat")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2011")])]

#text("The Brouwer fixed point theorem is equivalent via to Sperner’s lemma from combinatorics, using barycentric coordinates to make the reduction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hilbert’s fifth problem and Gleason metrics « What’s new")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-54030")[#strong[#text("Hilbert’s fifth problem and Gleason metrics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2011")])]

#text("[…] and no…Hilbert’s fift… on The Birkhoff-Kakutani the…Dave on Brouwer’s fixed point an…shannon7774 on Brouwer’s fixed point an…Marcelo Cantos on The blue-eyed islanders […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2fbd52fa64c7caa5219f513942a700029f5d89d57ca20f5c9d1317d27cc0c84-826bd5ab8ab114861b4e378d66c87667e47f03587c62745174715f04ae448835.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Noud")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-54058")[#strong[#text("Noud")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2011")])]

#text("Dear Terry Tao,")

#text("Thank you for this post. There is a small typo: in remark 2, the second delta (on line 10) should be in uppercase. ")#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-54260")[#strong[#text("Eighth Linkfest")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2011")]

#text("[…] Tao: Brouwer’s fixed point and invariance of domain theorems, and Hilbert’s fifth problem, Hilbert’s Fifth Problem and Gleason metrics, The C^{1,1} Baker-Campbell-Hausdorff […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/25db112307e61d9728d42311f1ccff35362a4bf602c4d460c13dec610100ef88-a5f6eb3d8c44bd98fd8e9add5fa6962b455260c37c9bc46e27d383edfbe684d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vadim Kulikov")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-54804")[#strong[#text("Vadim Kulikov")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2011")])]

#text("My favourite proof of Brouwer fixed point theorem uses combinatorial game theory. It is funny, because Brouwer f.p.t is in turn used to show the existence of a Nash equilibrium. Also this approach, as is the Sperner’s lemma approach, very elementary and I even presented the proof to a group of high school students last fall. Here is the proof by David Gale:")

#link("http://www.cs.cmu.edu/afs/cs/academic/class/15859-f01/www/notes/brouwer-hex.pdf")[#text("Click to access brouwer-hex.pdf")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 0 – Hilbert’s fifth problem and related topics « What’s new")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-70861")[#strong[#text("254A, Notes 0 – Hilbert’s fifth problem and related topics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2011")])]

#text("[…] We will spend several lectures proving this theorem (due to Gleason and to Yamabe). As stated, may depend on , but one can in fact take the open subgroup to be uniform in the choice of ; we will show this in later notes. Theorem 6 can in fact be deduced from Theorem 7 and some topological arguments involving the invariance of domain theorem; we will see this later in this course (or see this previous blog post). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-71316")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2011")])]

#text("Typo, just after Lemma 6: “is a not an interior point”")#linebreak()#text(" Just before the Weierstrass approximation theorem is mentioned, in “{0 < \\delta < 0.1}\", I thought you were saying {\\delta} was the infimum of {G} on {\\Sigma_1} and necessarily was bounded above by 0.1 for some mysterious but important reason. Maybe changing it to \"for some {\\delta} small enough, {G} is bounded…\" (as a flag that we might need to further decrease the naive bound) would prevent similar misreadings.")

#text("If you know, is it possible to go backwards in a sense and deduce the Brouwer fixed point theorem from the fact that {{\\bf R}^n} and {{\\bf R}^m} are not homeomorphic when the exponents differ, or from the invariance of domain theorem?")

#emph[#text("[Corrected, thanks. As for the last point, see Remark 1. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/85fec62161e04c2ae3b028b5eccf6ff083ede62b26d23968a23e4789869f23bf-0ca208eb6faafa70367604d809ad364a6359d20b904df7c950b7bf3d3c2fa5b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tony Carbery")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-88052")[#strong[#text("Tony Carbery")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2011")])]

#text("There’s a really simple proof of the Brouwer fixed point theorem, along the lines of the one in Evans’ book, but even simpler. It seems to be due to E.Lima.")

#text("As usual it’s enough to show that there is no continuous map ")#mi("g: D^n \\rightarrow S^{n-1}")#text(" which restricts to the identity on the boundary. As usual it’s enough to prove there is no such ")#mi("C^1")#text(" map. Suppose there were such a map. Consider ")#mi("\\int_{D^n} \\det Dg")#text(": on the one hand this is zero as ")#mi("Dg")#text(" has less than full rank, and on the other hand it equals")#linebreak()#text(" ")#mi("\\int_{S^{n-1}} g_1 \\wedge dg_2 \\cdots \\wedge dg_n")#text(" by Stokes’ theorem.")#linebreak()#text(" But as ")#mi("g")#text(" is the identity on the boundary, we can replace ")#mi("g")#text(" by ")#mi("I")#text(" here (pause for thought) and reverse the argument, giving the alternate answer ")#mi("V_n")#text(", the volune of the unit ball in ")#mi("\\mathbb{R}^n")#text(". Hence no such ")#mi("g")#text(" exists. Is there degree theory lurking here?")

#text("A similar argument, combined with some ideas of Shchepin can be used to give a quite easy proof of the Borsuk–Ulam theorem. See ")#link("http://www.maths.ed.ac.uk/~carbery/analysis/notes/bu3_public.pdf")[#text("http://www.maths.ed.ac.uk/~carbery/analysis/notes/bu3_public.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-90807")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2011")])]

#text("Dear Tony,")

#text("I think the connection with degree theory comes in the fact that the degree of a smooth map ")#mi("g: S^{n-1} \\to S^{n-1}")#text(" can be expressed as the integral ")#mi("\\int_{S^{n-1}} \\text{det} Dg")#text(" (normalised by the surface area of the sphere). An application of Stokes’ theorem shows that this quantity is invariant under smooth deformations of g; since the constant map has zero degree and the identity map has non-zero degree, one therefore cannot continuously deform one to the other. If one expresses your map ")#mi("g: D^n \\to S^{n-1}")#text(" in polar coordinates one sees that this argument is basically equivalent to Lima’s argument.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2de6923e2b061a4e78705a3bb2d849506ca9c24a746e8c8ce9f732d2cb7b5a6a-ef1ca4ece4fcc39387b19b892c0fbe277c3319cda2b3788ca85a201dabee0eab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon Sjogren")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-148532")[#strong[#text("Jon Sjogren")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2012")])]

#text("Greetings Terry Tao from af friends esp Robert Bonneau. Also greeting to A. Carberry from Prof. Wm Moran of Melbourne. I would not be hasty about attributing the proof of Brouwer FPT (using differential forms) to “E. Lima”. I know that reference comes from a book of do Carmo. On the other hand, this exact proof is found in Amer Math Monthly article April 1981, 264-268, by Yakar Kannai. He credits discussions with Prof. H.Scarf. First Dr. Kannai goes through the proof from the point of view of classical divergence theorem. However he also covers the proof again, in seven lines, using Stokes’ theorem in its formulation using exterior forms. A refinement that could be suggested to both “differential forms” proofs, is two consider two mappings g, h from the n-ball to (n-1) sphere both fixing every boundary point. In the integral of dg1 ^ dg2 ^ … ^ dgn over the ball, you want to replace each “g” by and “h”. You finally replace the retraction g by the identity h. First apply Stokes’ to equate the first integral with g1 dg2 ^ dg3 ^ … , integrated over the sphere, and note that now g1 may be replaced by h1 . Perform Stokes’ now to the new expression (“in reverse”) to obtain dh1 ^ dg2 ^ dg3 ^ … ^ dgn (over the ball), and now Stokes’ again to get")#linebreak()#text(" dh1 ^ (g2) ^ dg3 ^ … (over the sphere). Now replace g2 by h2 (equal on the domain of integration). Repeat this process to replace all gi by hi, resulting in the volume form for the n-ball, which computes to a non-zero value. As Yakar Kannai points out in the Monthly selection, the same proof also applies to any reasonable n-manifold with boundary, embedded in Euclidean space of the same dimension (attributed to M. Hirsch amongst others). J Sjogren")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The closed graph theorem in various categories « What’s new")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-194654")[#strong[#text("The closed graph theorem in various categories « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2012")])]

#text("[…] theorem can be proven by applying invariance of domain (discussed in this previous post) to the projection of to , to show that it is open if has the same dimension as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1231c616482fea8e43ed45e83778c2b1d7a31167425f7c376a859d830a18d1fa-d45cc05c8e8e0de7c2b26defc116e449bfd39cb777c5b8c4ae4be138b80bf32b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JuhoL")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-247191")[#strong[#text("JuhoL")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2013")])]

#text("Dear Terence.")

#text("Can you please explain, so that a layman can understand, why “invariance of dimension” is non-trivial? If a point separates a line but not a plane, then they are not homeomorphic, but why can’t we use that same argument again and argue that a line separates plane but not 3-dimensional space, and so on and so forth?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-247217")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2013")])]

#text("While a line clearly cannot separate a 3-dimensional space, it is not immediately obvious that every homeomorphic copy of a line (which includes fractals such as the ")#link("http://en.wikipedia.org/wiki/Koch_snowflake")[#text("Koch snowflake")]#text(") also cannot separate a 3-dimensional space, as one can already see from to the existence of ")#link("http://en.wikipedia.org/wiki/Space-filling_curve")[#text("space-filling curves")]#text(". Note that these space-filling curves cross each other and are thus not homeomorphic to a line, but they do indicate that there is something non-trivial to be done in order to rigorously justify the intuition here (much as the ")#link("http://en.wikipedia.org/wiki/Jordan_curve_theorem")[#text("Jordan curve theorem")]#text(", though similarly “obvious”, must also require rigorous proof).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1231c616482fea8e43ed45e83778c2b1d7a31167425f7c376a859d830a18d1fa-d45cc05c8e8e0de7c2b26defc116e449bfd39cb777c5b8c4ae4be138b80bf32b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JuhoL")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-247230")[#strong[#text("JuhoL")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2013")])]

#text("Thanks for your answer!")

#text("So the 1-dimensional case leads layman astray since homeomorphic image of a single point is just a single point, easy case, but homeomorphic image of a line can be pathological and one can’t immediately identify the connected domains?")

#text("A circle separates the plane into two but the homeomorphic image of that is the real question. So does n-dimensional Jordan curve theorem immediately solve dimension invariance, or is there some more pitfalls?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-247231")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2013")])]

#text("Yes, I believe the Jordan-Brouwer separation theorem implies that ")#mi("{\\bf R}^n")#text(" is not homeomorphic to ")#mi("{\\bf R}^m")#text(" for ")#mi("n>m")#text(" (otherwise the image of the ")#mi("{\\bf R}^n")#text(" unit sphere in ")#mi("{\\bf R}^m \\subset {\\bf R}^n")#text(" would be a counterexample to that theorem). But I think the standard proof of that theorem requires at least as much topological machinery as would be needed to establish invariance of domain.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1231c616482fea8e43ed45e83778c2b1d7a31167425f7c376a859d830a18d1fa-d45cc05c8e8e0de7c2b26defc116e449bfd39cb777c5b8c4ae4be138b80bf32b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JuhoL")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-247233")[#strong[#text("JuhoL")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2013")])]

#text("Thank you professor for clarifying this issue.")

#text("I was considerin that counterexample too since the proof of dimension invariance by Borsuk-Ulam theorem uses same contradiction argument when homeomorphism is restricted to unit sphere. Seems to me that domain invariance is much deeper result.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4294b54e396dbfa48e112dc1db704efb122a82f89a2f16f08add9851aad67897-84819578779a9b73450e4652596ba6db5907740a56a60b24ff5dc04d7822b5c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathdude")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-247443")[#strong[#text("mathdude")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2013")])]

#text("When you cut off that alleged lower dimensional “topological sphere” is the remaining part path-connected because R^n is a vector space? Are there any subleties? This can be a silly question, but I haven’t seen that direct & easy proof before…")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-471931")[#strong[#text("Brouwer’s invariance of domain | Bahçemizi Yetiştermeliyiz")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2016")]

#text("[…] this point I refer the interested reader to Terry Tao’s blogpost (where the gist of this proof was also taken from; he was interested in Hilbert’s fifth […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0516b3609be39665082e2370bb6000d4e568c0d1b583f06e3dcd3777a101db9b-79433dc7f5d801df94868a7bda747786a9851829ae1a79905676069bae1d1f83.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brouwer Fixed Point Theorem. Implications, generalisations and more. – Math and Physics")]], [#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/#comment-639633")[#strong[#text("Brouwer Fixed Point Theorem. Implications, generalisations and more. – Math and Physics")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2022")])]

#text("[…] the Remark 1 in Terrence Tao blog [3] for an heuristic explanation, and [8] for the proof of the invariance of domain from […]")
]
