// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/
// Converted to Typst by tao2typ: "2026-10-14T10:23:43.514216+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 5: Bounding exponential sums and the zeta function", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 5: Bounding exponential sums and the zeta function")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 February 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/")[#text("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("We return to the study of the Riemann zeta function ")#mi("{\\zeta(s)}")#text(", focusing now on the task of upper bounding the size of this function within the critical strip; as seen in Exercise 43 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(", such upper bounds can lead to zero-free regions for ")#mi("{\\zeta}")#text(", which in turn lead to improved estimates for the error term in the prime number theorem.")

#text("In equation (21) of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(" we obtained the somewhat crude estimates ")#metadata(none) <tao-95220649f7d73b138d2d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\zeta(s) = \\sum_{n \\leq x} \\frac{1}{n^s} - \\frac{x^{1-s}}{1-s} + O( \\frac{\\left|s\\right|}{\\sigma} \\frac{1}{x^\\sigma} )", block: true)]]

#linebreak()#text(" for any ")#mi("{x > 0}")#text(" and ")#mi("{s = \\sigma+it}")#text(" with ")#mi("{\\sigma>0}")#text(" and ")#mi("{s \\neq 1}")#text(". Setting ")#mi("{x=1}")#text(", we obtained the crude estimate")

#align(center)[#tao-fit-display[#tao-math("\\zeta(s) = \\frac{1}{s-1} + O( \\frac{\\left|s\\right|}{\\sigma} )", block: true)]]

#text("in this region. In particular, if ")#mi("{0 < \\varepsilon \\leq \\sigma \\ll 1}")#text(" and ")#tao-math("{\\left|t\\right| \\gg 1}", block: false)#text(" then we had ")#tao-math("{\\zeta(s) = O_\\varepsilon( \\left|t\\right| )}", block: false)#text(". Using the functional equation and the Hadamard three lines lemma, we can improve this to ")#tao-math("{\\zeta(s) \\ll_\\varepsilon \\left|t\\right|^{\\frac{1-\\sigma}{2}+\\varepsilon}}", block: false)#text("; see ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Supplement 3")]#text(".")#linebreak()#text(" Now we seek better upper bounds on ")#mi("{\\zeta}")#text(". We will reduce the problem to that of bounding certain exponential sums, in the spirit of Exercise 34 of ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Supplement 3")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" ")#metadata(none) <tao-0650df55259438e25f16>#text(" Let ")#mi("{s = \\sigma+it}")#text(" with ")#mi("{0 < \\varepsilon \\leq \\sigma \\ll 1}")#text(" and ")#tao-math("{\\left|t\\right| \\gg 1}", block: false)#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\zeta(s) \\ll_\\varepsilon \\log(2+\\left|t\\right|) \\sup_{1 \\leq M \\leq N \\ll \\left|t\\right|}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("N^{1-\\sigma} \\left|\\frac{1}{N} \\sum_{N \\leq n < N+M} e( -\\frac{t}{2\\pi} \\log n)\\right|", block: true)]]

#text("where ")#mi("{e(x) := e^{2\\pi i x}}")#text(".")
]

#emph[#text("Proof:")]#text(" We fix a smooth function ")#mi("{\\eta: {\\bf R} \\rightarrow {\\bf C}}")#text(" with ")#mi("{\\eta(t)=1}")#text(" for ")#mi("{t \\leq -1}")#text(" and ")#mi("{\\eta(t)=0}")#text(" for ")#mi("{t \\geq 1}")#text(", and allow implied constants to depend on ")#mi("{\\eta}")#text(". Let ")#mi("{s=\\sigma+it}")#text(" with ")#mi("{\\varepsilon \\leq \\sigma \\ll 1}")#text(". From Exercise 34 of ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Supplement 3")]#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\zeta(s) = \\sum_n \\frac{1}{n^s} \\eta( \\log n - \\log C\\left|t\\right| ) + O_\\varepsilon( 1 )", block: true)]]

#text("for some sufficiently large absolute constant ")#mi("{C}")#text(". By dyadic decomposition, we thus have")

#align(center)[#tao-fit-display[#tao-math("\\zeta(s) \\ll_{\\varepsilon} 1 + \\log(2+\\left|t\\right|) \\sup_{1 \\leq N \\ll \\left|t\\right|} \\left|\\sum_{N \\leq n < 2N} \\frac{1}{n^s} \\eta( \\log n - \\log C\\left|t\\right| )\\right|.", block: true)]]

#text("We can absorb the first term in the second using the ")#mi("{N=1}")#text(" case of the supremum. Writing ")#tao-math("{\\frac{1}{n^s} \\eta( \\log n - \\log\\left|C\\right| t ) = N^{-\\sigma} e( - \\frac{t}{2\\pi} \\log n ) F_N(n)}", block: false)#text(", where")

#align(center)[#tao-fit-display[#tao-math("F_N(n) := (N/n)^\\sigma \\eta(\\log n - \\log C\\left|t\\right| ),", block: true)]]

#text("it thus suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{N \\leq n < 2N} e(-\\frac{t}{2\\pi} \\log N) F_N(n) \\ll \\sup_{1 \\leq M \\leq N} \\left|\\sum_{N \\leq n < N+M} e(-\\frac{t}{2\\pi} \\log n)\\right|", block: true)]]

#text("for each ")#mi("{N}")#text(". But from the fundamental theorem of calculus, the left-hand side can be written as")

#align(center)[#tao-fit-display[#mitex("F_N(2N) \\sum_{N \\leq n < 2N} e(-\\frac{t}{2\\pi} \\log n)")]]

#align(center)[#tao-fit-display[#mitex("- \\int_0^{N} (\\sum_{N \\leq n < N+M} e(-\\frac{t}{2\\pi} \\log n)) F^{\\prime}_N(M)\\ dM")]]

#text("and the claim then follows from the triangle inequality and a routine calculation. ")#mi("\\Box")#linebreak()#text(" We are thus interested in getting good bounds on the sum ")#mi("{\\sum_{N \\leq n < N+M} e( -\\frac{t}{2\\pi} \\log n )}")#text(". More generally, we consider normalised exponential sums of the form ")#metadata(none) <tao-01cdfa0371d5f2003343>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\frac{1}{N} \\sum_{n \\in I} e( f(n) )")]]

#linebreak()#text(" where ")#mi("{I \\subset {\\bf R}}")#text(" is an interval of length at most ")#mi("{N}")#text(" for some ")#mi("{N \\geq 1}")#text(", and ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a smooth function. We will assume smoothness estimates of the form ")#metadata(none) <tao-3f744134baea564fc3a2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|f^{(j)}(x)\\right| = \\exp( O(j^2) ) \\frac{T}{N^j}", block: true)]]

#text(" for some ")#mi("{T>0}")#text(", all ")#mi("{x \\in I}")#text(", and all ")#mi("{j \\geq 1}")#text(", where ")#mi("{f^{(j)}}")#text(" is the ")#mi("{j}")#text("-fold derivative of ")#mi("{f}")#text("; in the case ")#mi("{f(x) := -\\frac{t}{2\\pi} \\log x}")#text(", ")#mi("{I \\subset [N,2N]}")#text(" of interest for the Riemann zeta function, we easily verify that these estimates hold with ")#tao-math("{T := \\left|t\\right|}", block: false)#text(". (One can consider exponential sums under more general hypotheses than ")#link(<tao-3f744134baea564fc3a2>)[#text("(3)")]#text(", but the hypotheses here are adequate for our needs.) We do not bound the zeroth derivative ")#mi("{f^{(0)}=f}")#text(" of ")#mi("{f}")#text(" directly, but it would not be natural to do so in any event, since the magnitude of the sum ")#link(<tao-01cdfa0371d5f2003343>)[#text("(2)")]#text(" is unaffected if one adds an arbitrary constant to ")#mi("{f(n)}")#text(".")#linebreak()#text(" The trivial bound for ")#link(<tao-01cdfa0371d5f2003343>)[#text("(2)")]#text(" is ")#metadata(none) <tao-6d4c9cf5e022a07ea801>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\frac{1}{N} \\sum_{n \\in I} e(f(n)) \\ll 1")]]

#linebreak()#text(" and we will seek to obtain significant improvements to this bound. Pseudorandomness heuristics predict a bound of ")#mi("{O_\\varepsilon(N^{-1/2+\\varepsilon})}")#text(" for ")#link(<tao-01cdfa0371d5f2003343>)[#text("(2)")]#text(" for any ")#mi("{\\varepsilon>0}")#text(" if ")#mi("{T = O(N^{O(1)})}")#text("; this assertion (a special case of the ")#emph[#text("exponent pair hypothesis")]#text(") would have many consequences (for instance, inserting it into Proposition ")#link(<tao-0650df55259438e25f16>)[#text("1")]#text(" soon yields the Lindelöf hypothesis), but is unfortunately quite far from resolution with known methods. However, we can obtain weaker gains of the form ")#mi("{O(N^{1-c_K})}")#text(" when ")#mi("{T \\ll N^K}")#text(" and ")#mi("{c_K > 0}")#text(" depends on ")#mi("{K}")#text(". We present two such results here, which perform well for small and large values of ")#mi("{K}")#text(" respectively:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" ")#metadata(none) <tao-b6cf348bc9b1a71d9db0>#text(" Let ")#mi("{2 \\leq N \\ll T}")#text(", let ")#mi("{I}")#text(" be an interval of length at most ")#mi("{N}")#text(", and let ")#mi("{f: I \\rightarrow {\\bf R}}")#text(" be a smooth function obeying ")#link(<tao-3f744134baea564fc3a2>)[#text("(3)")]#text(" for all ")#mi("{j \\geq 1}")#text(" and ")#mi("{x \\in I}")#text(".")

#list(
[#text("(i) (van der Corput estimate) For any natural number ")#mi("{k \\geq 2}")#text(", one has")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\frac{1}{N} \\sum_{n \\in I} e( f(n) ) \\ll (\\frac{T}{N^k})^{\\frac{1}{2^k-2}} \\log^{1/2} (2+T).")]]

#metadata(none) <tao-3bfc269594ef649228e9>],
[#text("(ii) (Vinogradov estimate) If ")#mi("{k}")#text(" is a natural number and ")#mi("{T \\leq N^{k}}")#text(", then")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\frac{1}{N} \\sum_{n \\in I} e( f(n) ) \\ll N^{-c/k^2}")]]

#metadata(none) <tao-fb04dcb6970e4c3d1873>#text(" for some absolute constant ")#mi("{c>0}")#text(".")]
)
]

#text("The factor of ")#mi("{\\log^{1/2} (2+T)}")#text(" can be removed by a more careful argument, but we will not need to do so here as we are willing to lose powers of ")#mi("{\\log T}")#text(". The estimate ")#link(<tao-fb04dcb6970e4c3d1873>)[#text("(6)")]#text(" is superior to ")#link(<tao-3bfc269594ef649228e9>)[#text("(5)")]#text(" when ")#mi("{T \\sim N^K}")#text(" for ")#mi("{K}")#text(" large, since (after optimising in ")#mi("{k}")#text(") ")#link(<tao-3bfc269594ef649228e9>)[#text("(5)")]#text(" gives a gain of the form ")#mi("{N^{-c/2^{cK}}}")#text(" over the trivial bound, while ")#link(<tao-fb04dcb6970e4c3d1873>)[#text("(6)")]#text(" gives ")#mi("{N^{-c/K^2}}")#text(". We have not attempted to obtain completely optimal estimates here, settling for a relatively simple presentation that still gives good bounds on ")#mi("{\\zeta}")#text(", and there are a wide variety of additional exponential sum estimates beyond the ones given here; see Chapter 8 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec-Kowalski")]#text(", or Chapters 3-4 of ")#link("http://www.ams.org/mathscinet-getitem?mr=1297543")[#text("Montgomery")]#text(", for further discussion.")

#text("We now briefly discuss the strategies of proof of Theorem ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("2")]#text(". Both parts of the theorem proceed by treating ")#mi("{f}")#text(" like a polynomial of degree roughly ")#mi("{k}")#text("; in the case of (ii), this is done explicitly via Taylor expansion, whereas for (i) it is only at the level of analogy. Both parts of the theorem then try to “linearise” the phase to make it a linear function of the summands (actually in part (ii), it is necessary to introduce an additional variable and make the phase a ")#emph[#text("bilinear")]#text(" function of the summands). The van der Corput estimate achieves this linearisation by squaring the exponential sum about ")#mi("{k}")#text(" times, which is why the gain is only exponentially small in ")#mi("{k}")#text(". The Vinogradov estimate achieves linearisation by raising the exponential sum to a significantly smaller power – on the order of ")#mi("{k^2}")#text(" – by using Hölder’s inequality in combination with the fact that the discrete curve ")#mi("{\\{ (n,n^2,\\dots,n^k): n \\in \\{1,\\dots,M\\}\\}}")#text(" becomes roughly equidistributed in the box ")#mi("{\\{ (a_1,\\dots,a_k): a_j = O( M^j ) \\}}")#text(" after taking the sumset of about ")#mi("{k^2}")#text(" copies of this curve. This latter fact has a precise formulation, known as the ")#link("http://en.wikipedia.org/wiki/Vinogradov%27s_mean-value_theorem")[#text("Vinogradov mean value theorem")]#text(", and its proof is the most difficult part of the argument, relying on using a “")#mi("{p}")#text("-adic” version of this equidistribution to reduce the claim at a given scale ")#mi("{M}")#text(" to a smaller scale ")#mi("{M/p}")#text(" with ")#mi("{p \\sim M^{1/k}}")#text(", and then proceeding by induction.")

#text("One can combine Theorem ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("2")]#text(" with Proposition ")#link(<tao-0650df55259438e25f16>)[#text("1")]#text(" to obtain various bounds on the Riemann zeta function:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3 (Subconvexity bound)")]

#list(
[#text("(i) Show that ")#tao-math("{\\zeta(\\frac{1}{2}+it) \\ll (1+\\left|t\\right|)^{1/6} \\log^{O(1)}(2+\\left|t\\right|)}", block: false)#text(" for all ")#mi("{t \\in {\\bf R}}")#text(". (")#emph[#text("Hint:")]#text(" use the ")#mi("{k=3}")#text(" case of the Van der Corput estimate.)")],
[#text("(ii) For any ")#mi("{0 < \\sigma < 1}")#text(", show that ")#tao-math("{\\zeta(\\sigma+it) \\ll (1+\\left|t\\right|)^{\\max( \\frac{1-\\sigma}{3}, \\frac{1}{2} - \\frac{2\\sigma}{3}) + o(1)}}", block: false)#text(" as ")#tao-math("{\\left|t\\right| \\rightarrow \\infty}", block: false)#text(" (the decay rate in the ")#mi("{o(1)}")#text(" is allowed to depend on ")#mi("{\\sigma}")#text(").")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Let ")#mi("{t}")#text(" be such that ")#tao-math("{\\left|t\\right| \\geq 100}", block: false)#text(", and let ")#mi("{\\sigma \\geq 1/2}")#text(".")

#list(
[#text("(i) (Littlewood bound) Use the van der Corput estimate to show that ")#tao-math("{\\zeta(\\sigma+it) \\ll \\log^{O(1)} \\left|t\\right|}", block: false)#text(" whenever ")#tao-math("{\\sigma \\geq 1 - O( \\frac{(\\log\\log \\left|t\\right|)^2}{\\log \\left|t\\right|} ))}", block: false)#text(".")],
[#text("(ii) (Vinogradov-Korobov bound) Use the Vinogradov estimate to show that ")#tao-math("{\\zeta(\\sigma+it) \\ll \\log^{O(1)} \\left|t\\right|}", block: false)#text(" whenever ")#tao-math("{\\sigma \\geq 1 - O( \\frac{(\\log\\log \\left|t\\right|)^{2/3}}{\\log^{2/3} \\left|t\\right|} )}", block: false)#text(".")]
)
]

#text("As noted in Exercise 43 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(", the Vinogradov-Korobov bound leads to the zero-free region ")#tao-math("{\\{ \\sigma+it: \\sigma > 1 - c \\frac{1}{(\\log \\left|t\\right|)^{2/3} (\\log\\log \\left|t\\right|)^{1/3}}; \\left|t\\right| \\geq 100 \\}}", block: false)#text(", which in turn leads to the prime number theorem with error term")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) = x + O\\left( x \\exp\\left( - c \\frac{\\log^{3/5} x}{(\\log\\log x)^{1/5}} \\right) \\right)")]]

#text("for ")#mi("{x > 100}")#text(". If one uses the weaker Littlewood bound instead, one obtains the narrower zero-free region")

#align(center)[#tao-fit-display[#tao-math("\\{ \\sigma+it: \\sigma > 1 - c \\frac{\\log\\log\\left|t\\right|}{\\log \\left|t\\right|}; \\left|t\\right| \\geq 100 \\}", block: true)]]

#text("(which is only slightly wider than the classical zero-free region) and an error term")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) = x + O( x \\exp( - c \\sqrt{\\log x \\log\\log x} ) )")]]

#text("in the prime number theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5 (Vinogradov-Korobov in arithmetic progressions)")]#text(" Let ")#mi("{\\chi}")#text(" be a non-principal character of modulus ")#mi("{q}")#text(".")

#list(
[#text("(i) (Vinogradov-Korobov bound) Use the Vinogradov estimate to show that ")#tao-math("{L(\\sigma+it,\\chi) \\ll \\log^{O(1)}(q\\left|t\\right|)}", block: false)#text(" whenever ")#tao-math("{\\left|t\\right| \\geq 100}", block: false)#text(" and")

#align(center)[#tao-fit-display[#tao-math("\\sigma \\geq 1 - O( \\min( \\frac{\\log\\log(q\\left|t\\right|)}{\\log q}, \\frac{(\\log\\log(q\\left|t\\right|))^{2/3}}{\\log^{2/3} \\left|t\\right|} ) ).", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" use the Vinogradov estimate and a change of variables to control ")#mi("{\\sum_{n \\in I: n = a\\ (q)} \\exp( -it \\log n)}")#text(" for various intervals ")#mi("{I}")#text(" of length at most ")#mi("{N}")#text(" and residue classes ")#mi("{a\\ (q)}")#text(", in the regime ")#mi("{N \\geq q^2}")#text(" (say). For ")#mi("{N < q^2}")#text(", do not try to capture any cancellation and just use the triangle inequality instead.)")],
[#text("(ii) Obtain a zero-free region")

#align(center)[#tao-fit-display[#tao-math("\\{ \\sigma+it: \\sigma > 1 - c \\min( \\frac{1}{(\\log \\left|t\\right|)^{2/3} (\\log\\log \\left|t\\right|)^{1/3}}, \\frac{1}{\\log q} );", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\left|t\\right| \\geq 100 \\}", block: true)]]

#text("for ")#mi("{L(s,\\chi)}")#text(", for some (effective) absolute constant ")#mi("{c>0}")#text(".")],
[#text("(iii) Obtain the prime number theorem in arithmetic progressions with error term")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x: n = a\\ (q)} \\Lambda(n) = \\frac{x}{\\phi(q)} + O\\left( x \\exp\\left( - c_A \\frac{\\log^{3/5} x}{(\\log\\log x)^{1/5}} \\right) \\right)")]]

#text("whenever ")#mi("{x > 100}")#text(", ")#mi("{q \\leq \\log^A x}")#text(", ")#mi("{a\\ (q)}")#text(" is primitive, and ")#mi("{c_A>0}")#text(" depends (ineffectively) on ")#mi("{A}")#text(".")]
)
]

#metadata(none) <tao-2b8c72c22d55920f6aac>

#heading(level: 1)[#strong[#text(" — 1. Van der Corput estimates — ")]]

#text("In this section we prove Theorem ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("2")]#text("(i). To motivate the arguments, we will use an analogy between the sums ")#mi("{\\sum_{n \\in I} e(f(n))}")#text(" and the integrals ")#mi("{\\int_I e(f(t))\\ dt}")#text(" (cf. Exercise 11 from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text("). This analogy can be made rigorous by the Poisson summation formula (after applying some smoothing to the integral over ")#mi("{I}")#text(" to truncate the frequency summation), but we will not need to do so here.")

#text("Write ")#mi("{I = [a,b]}")#text(". We can control the integral ")#mi("{\\int_a^b e(f(t))\\ dt}")#text(" by integration by parts:")

#tao-aligned(keep: true)[


#tao-math("\\int_a^b e(f(t))\\ dt  & = \\int_a^b \\frac{1}{2\\pi i f^{\\prime}(t)} \\frac{d}{dt} e(f(t))\\ dt", block: true)



#tao-math(" & = \\frac{1}{2\\pi i f^{\\prime}(t)} e(f(t))|_a^b - \\int_a^b \\frac{d}{dt}( \\frac{1}{2\\pi i f^{\\prime}(t)} ) e(f(t))\\ dt", block: true)



#tao-math(" & \\ll \\frac{1}{\\left|f^{\\prime}(a)\\right|} + \\frac{1}{\\left|f^{\\prime}(b)\\right|} + \\int_a^b \\frac{\\left|f^{\\prime\\prime}(t)\\right|}{\\left|f^{\\prime}(t)\\right|^2}\\ dt.", block: true)
]

#text("If ")#mi("{f}")#text(" obeys ")#link(<tao-3f744134baea564fc3a2>)[#text("(3)")]#text(" for ")#mi("{j=1,2}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\int_a^b e(f(t))\\ dt \\ll \\frac{1}{T}.")]]

#text("An analogous argument, using summation by parts instead of integration by parts, controls the sum ")#mi("{\\sum_I e(f(n))}")#text(", but only in the regime when ")#mi("{T \\ll N}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6")]#text(" ")#metadata(none) <tao-26ec8fd92ba12f8ee80e>#text(" Let ")#mi("{N, A \\geq 1}")#text(" and ")#mi("{T>0}")#text(", let ")#mi("{I}")#text(" be an interval of length at most ")#mi("{N}")#text(", and let ")#mi("{f: I \\rightarrow {\\bf R}}")#text(" be a smooth function obeying the bounds")

#align(center)[#tao-fit-display[#tao-math("\\frac{T}{AN^j} \\leq \\left|f^{(j)}(x)\\right| \\leq A \\frac{T}{N^j}", block: true)]]

#text("for ")#mi("{j=1,2}")#text(" and ")#mi("{x \\in I}")#text(". If ")#mi("{T \\leq \\frac{N}{2A}}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_{n \\in I} e( f(n) ) \\ll A^3 \\frac{1}{T}.")]]
]

#emph[#text("Proof:")]#text(" We may assume that ")#mi("{I = [a,b]}")#text(" for some integers ")#mi("{a \\leq b}")#text(", and after deleting the right endpoint it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{a \\leq n < b} e(f(n)) \\ll \\frac{N}{T}.")]]

#text("From the ")#mi("{j=1}")#text(" case of ")#link(<tao-3f744134baea564fc3a2>)[#text("(3)")]#text(" and the mean value theorem one has ")#mi("{\\frac{T}{AN} \\ll f(n+1)-f(n) \\leq \\frac{AT}{N} \\leq \\frac{1}{2}}")#text(" for all ")#mi("{a \\leq n < b}")#text(". Thus we have")

#align(center)[#tao-fit-display[#tao-math("\\left|e(f(n+1)-f(n))-1\\right| \\gg \\frac{T}{AN}", block: true)]]

#text("and we can write")

#align(center)[#tao-fit-display[#mitex("\\sum_{a \\leq n < b} e(f(n)) = \\sum_{a \\leq n < b} [e(f(n+1)) - e(f(n))] \\frac{1}{e(f(n+1)-f(n))-1}.")]]

#text("From the ")#mi("{j=1,2}")#text(" cases of ")#link(<tao-3f744134baea564fc3a2>)[#text("(3)")]#text(" and the mean value theorem we see that ")#mi("{x \\mapsto \\frac{1}{e(f(x+1)-f(x))-1}}")#text(" has size ")#mi("{O(AN/T)}")#text(" and derivative ")#mi("{O(A^3/T)}")#text(" on ")#mi("{[a,b-1]}")#text(". The claim then follows from a summation by parts. ")#mi("\\Box")#linebreak()#text(" To use this proposition in the regime ")#mi("{T \\gg N}")#text(", we will use the following inequality of van der Corput, which is a basic application of the Cauchy-Schwarz inequality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7 (van der Corput inequality)")]#text(" ")#metadata(none) <tao-e54a5df6ff5bc3208e2c>#text(" Let ")#mi("{N \\geq H \\geq 1}")#text(", let ")#mi("{I}")#text(" be an interval of length ")#mi("{N}")#text(", and let ")#mi("{f: I \\rightarrow {\\bf R}}")#text(" be a function. Then")

#tao-aligned(keep: true)[


#tao-math("\\frac{1}{N} \\sum_{n \\in I} e( f(n) )  & \\ll H^{-1/2}", block: true)



#tao-math(" & + \\left( \\frac{1}{H} \\sum_{1 \\leq h \\leq H} \\left|\\frac{1}{N} \\sum_{n \\in I \\cap I-h} e( f(n+h)-f(n))\\right| \\right)^{1/2}.", block: true)
]
]

#text("The point of this proposition is that it effectively replaces the phase ")#mi("{f(n)}")#text(" by the differenced phase ")#mi("{f_h(n) := f(n+h)-f(n)}")#text(" for some medium-sized ")#mi("{h}")#text("; it is an oscillatory version of the trivial observation that if ")#mi("{f}")#text(" is close to constant, then ")#mi("{f_h}")#text(" is also close to constant. From the fundamental theorem of calculus, we see that if ")#mi("{f}")#text(" obeys the estimates ")#link(<tao-3f744134baea564fc3a2>)[#text("(3)")]#text(", then ")#mi("{f_h}")#text(" obeys a variant of ")#link(<tao-3f744134baea564fc3a2>)[#text("(3)")]#text(" in which ")#mi("{T}")#text(" has been replaced by ")#mi("{\\frac{h}{N} T}")#text(". Since ")#mi("{H \\leq N}")#text(", this reduces ")#mi("{T}")#text(", and so one can hope to then iterate this proposition to the point where one can apply Proposition ")#link(<tao-26ec8fd92ba12f8ee80e>)[#text("6")]#text(".")

#emph[#text("Proof:")]#text(" By rounding down, we may assume that ")#mi("{H}")#text(" is an integer. For any ")#mi("{1 \\leq h \\leq H}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in I} e(f(n)) = \\sum_{n \\in I-h} e(f(n+h))")]]

#text("and thus on averaging in ")#mi("{h}")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in I} e(f(n)) = \\frac{1}{H} \\sum_n \\sum_{1 \\leq h \\leq H} 1_{n \\in I-h} e(f(n+h)).")]]

#text("There are only ")#mi("{O(N)}")#text(" values of ")#mi("{n}")#text(" for which the inner sum is non-vanishing. By the Cauchy-Schwarz inequality, we thus have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\in I} e(f(n)) \\ll \\frac{1}{H} N^{1/2} \\left( \\sum_n \\left|\\sum_{1 \\leq h \\leq H} 1_{n \\in I-h} e(f(n+h))\\right|^2 \\right)^{1/2}", block: true)]]

#text("and so it will suffice to show that")

#tao-aligned(keep: true)[


#tao-math("\\sum_n \\left|\\sum_{1 \\leq h \\leq H} 1_{n \\in I-h} e(f(n+h))\\right|^2  & \\ll H N", block: true)



#tao-math(" & + H \\sum_{1 \\leq h \\leq H} |\\sum_{n \\in I \\cap I-h} e( f(n+h)-f(n))|.", block: true)
]

#text("The left-hand side may be expanded as")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq h_1,h_2 \\leq H} \\sum_{n \\in I-h_1 \\cap I-h_2} e( f(n+h_1) - f(n+h_2) ).")]]

#text("The contribution of the diagonal terms ")#mi("{h_1=h_2}")#text(" is ")#mi("{O( HN )}")#text(" which is acceptable. For the off-diagonal terms, we may use symmetry to restrict to the case ")#mi("{h_2 < h_1}")#text(", picking up a factor of ")#mi("{2}")#text(". After shifting ")#mi("{n}")#text(" by ")#mi("{h_2}")#text(", we may thus bound this contribution by")

#align(center)[#tao-fit-display[#mitex("2\\sum_{1 \\leq h_2 < h_1 \\leq H} |\\sum_{n \\in I-(h_1-h_2) \\cap I} e( f(n+h_1-h_2) - f(n) )|.")]]

#text("Since each ")#mi("{1 \\leq h \\leq H}")#text(" occurs ")#mi("{O(H)}")#text(" times as a difference ")#mi("{h_1-h_2}")#text(", the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8 (Qualitative Weyl exponential sum estimates)")]#text(" Let ")#mi("{P(n) = \\alpha_k n^k + \\dots + \\alpha_0}")#text(" be a polynomial with real coefficients ")#mi("{\\alpha_0,\\dots,\\alpha_k}")#text(".")

#list(
[#text("(i) If ")#mi("{k \\geq 1}")#text(" and ")#mi("{\\alpha_k}")#text(" is irrational, show that ")#mi("{\\frac{1}{x} \\sum_{n \\leq x} e(P(n)) = o(1)}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(". (")#emph[#text("Hint:")]#text(" induct on ")#mi("{k}")#text(", using geometric series for the base case ")#mi("{k=1}")#text(" and Proposition ")#link(<tao-e54a5df6ff5bc3208e2c>)[#text("7")]#text(" for the induction step.)")],
[#text("(ii) If ")#mi("{k \\geq 1}")#text(" and at least one of ")#mi("{\\alpha_1,\\dots,\\alpha_k}")#text(" is irrational, show that ")#mi("{\\frac{1}{x} \\sum_{n \\leq x} e(P(n)) = o(1)}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(".")],
[#text("(iii) If all of the ")#mi("{\\alpha_1,\\dots,\\alpha_k}")#text(" are rational, show that ")#mi("{\\frac{1}{x} \\sum_{n \\leq x} e(P(n))}")#text(" converges as ")#mi("{x \\rightarrow \\infty}")#text(" to a limit that is not necessarily zero.")]
)

#text("One can obtain more quantitative estimates on the decay rate of ")#mi("{\\frac{1}{x} \\sum_{n \\leq x} e(P(n))}")#text(" in terms of how badly approximable by rationals one or more of the coefficients ")#mi("{\\alpha_j}")#text(" are; see for instance Chapter 8 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec-Kowalski")]#text(" for some estimates of this type.")
]

#text("If we combine one application of Proposition ")#link(<tao-e54a5df6ff5bc3208e2c>)[#text("7")]#text(" with Proposition ")#link(<tao-26ec8fd92ba12f8ee80e>)[#text("6")]#text(", we conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9")]#text(" ")#metadata(none) <tao-492bd8f3a14ef41df45b>#text(" Let ")#mi("{N, A \\geq 1}")#text(" and ")#mi("{T>0}")#text(", let ")#mi("{I}")#text(" be an interval of length at most ")#mi("{N}")#text(", and let ")#mi("{f: I \\rightarrow {\\bf R}}")#text(" be a smooth function obeying the bounds")

#align(center)[#tao-fit-display[#tao-math("\\frac{T}{AN^j} \\leq \\left|f^{(j)}(x)\\right| \\leq A \\frac{T}{N^j}", block: true)]]

#text("for ")#mi("{j=1,2,3}")#text(" and ")#mi("{x \\in I}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_{n \\in I} e( f(n) ) \\ll A^2 (\\frac{1}{T^{1/2}} \\log T + \\frac{T^{1/2}}{N} ).")]]
]

#emph[#text("Proof:")]#text(" If ")#mi("{T \\leq \\frac{N}{2A}}")#text(" then the claim follows from Proposition ")#link(<tao-26ec8fd92ba12f8ee80e>)[#text("6")]#text(" (or from ")#link(<tao-6d4c9cf5e022a07ea801>)[#text("(4)")]#text(", if ")#mi("{T<1}")#text("), so we may assume that ")#mi("{T > \\frac{N}{2A}}")#text(". We can also assume that ")#mi("{T \\leq \\frac{N^2}{2A}}")#text(", since otherwise the claim follows from the trivial bound ")#link(<tao-6d4c9cf5e022a07ea801>)[#text("(4)")]#text(".")

#text("Set ")#mi("{H := \\frac{N^2}{2AT}}")#text(", then ")#mi("{1 \\leq H \\leq N}")#text(". By Proposition ")#link(<tao-e54a5df6ff5bc3208e2c>)[#text("7")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{N} \\sum_{n \\in I} e( f(n) ) \\ll H^{-1/2} + \\left(\\frac{1}{H} \\sum_{1 \\leq h \\leq H} \\left|\\frac{1}{N} \\sum_{n \\in I \\cap I-h} e( f_h(n))\\right| \\right)^{1/2}", block: true)]]

#text("where ")#mi("{f_h(n) := f(n+h) - f(n)}")#text(". From the fundamental theorem of calculus we have")

#align(center)[#tao-fit-display[#tao-math("\\frac{h}{N} \\frac{T}{AN^j} \\leq \\left|f_h^{(j)}(x)\\right| \\leq A \\frac{h}{N} \\frac{T}{N^j}", block: true)]]

#text("for ")#mi("{j=1,2}")#text(". By Proposition ")#link(<tao-26ec8fd92ba12f8ee80e>)[#text("6")]#text(" we then have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_{n \\in I \\cap I-h} e( f_h(n)) \\ll A^3 \\frac{N}{Th}")]]

#text("so on summing in ")#mi("{h}")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_{n \\in I} e( f(n) ) \\ll H^{-1/2} + ( A^3 \\frac{N}{TH} \\log T )^{1/2}")]]

#text("and the claim follows from the choice of ")#mi("{H}")#text(". ")#mi("\\Box")#linebreak()#text(" We can iterate this:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10")]#text(" ")#metadata(none) <tao-776283fe954f2e367abb>#text(" Let ")#mi("{C>1}")#text(" be a sufficiently large constant. Then for any ")#mi("{N, A \\geq 1}")#text(", any ")#mi("{T>0}")#text(", any natural number ")#mi("{k \\geq 2}")#text(", any interval ")#mi("{I}")#text(" of length at most ")#mi("{N}")#text(", and any smooth ")#mi("{f: I \\rightarrow {\\bf R}}")#text(" obeying the bounds ")#metadata(none) <tao-101a07e5f182ba079644>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\frac{T}{AN^j} \\leq \\left|f^{(j)}(x)\\right| \\leq A \\frac{T}{N^j}", block: true)]]

#text(" for ")#mi("{j=1,\\dots,k+1}")#text(" and ")#mi("{x \\in I}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{1}{N} \\sum_{n \\in I} e( f(n) )\\right| \\leq C A^{1/2^{k-3}} \\times", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\left( \\frac{1}{N^{1/2^{k-2}}} \\left( \\frac{N^k}{T} \\right)^{\\frac{1}{2^k-2}} \\log^{1/2^{k-2}}(2+T) + \\left( \\frac{T}{N^k} \\right)^{\\frac{1}{2^k-2}} \\right).")]]
]

#text("We have avoided the use of asymptotic notation for this proposition because we need to use induction on ")#mi("{k}")#text(".")

#emph[#text("Proof:")]#text(" We induct on ")#mi("{k}")#text(". The ")#mi("{k=2}")#text(" case follows from Proposition ")#link(<tao-492bd8f3a14ef41df45b>)[#text("9")]#text(". Now suppose that ")#mi("{k \\geq 3}")#text(" and the claim has already been proven for ")#mi("{k-1}")#text(".")

#text("If ")#mi("{T > N^k}")#text(" then the claim follows from ")#link(<tao-6d4c9cf5e022a07ea801>)[#text("(4)")]#text(" (for ")#mi("{C}")#text(" large enough), so suppose that ")#mi("{T \\leq N^k}")#text(". Then the quantity ")#mi("{H := (N^k/T)^{\\frac{1}{2^{k-1}-1}}}")#text(" is such that ")#mi("{1 \\leq H \\leq N}")#text(". By Proposition ")#link(<tao-e54a5df6ff5bc3208e2c>)[#text("7")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{1}{N} \\sum_{n \\in I} e( f(n) )\\right| \\ll H^{-1/2} + \\left(\\frac{1}{H} \\sum_{1 \\leq h \\leq H} \\left|\\frac{1}{N} \\sum_{n \\in I \\cap I-h} e( f_h(n))\\right| \\right)^{1/2}.", block: true)]]

#text("From the fundamental theorem of calculus, ")#mi("{f_h}")#text(" obeys the bounds ")#link(<tao-101a07e5f182ba079644>)[#text("(7)")]#text(" for ")#mi("{j=1,\\dots,k}")#text(" with ")#mi("{T}")#text(" replaced by ")#mi("{hT/N}")#text(". Thus by the induction hypothesis,")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{1}{N} \\sum_{n \\in I \\cap I-h} e( f_h(n))\\right| \\leq C A^{1/2^{k-4}}", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\left( \\frac{1}{N^{1/2^{k-3}}} \\left( \\frac{N^k}{Th} \\right)^{\\frac{1}{2^{k-1}-2}} \\log^{1/2^{k-3}}(2+T) + \\left( \\frac{hT}{N^k} \\right)^{\\frac{1}{2^{k-1}-2}} \\right).")]]

#text("Performing the sum over ")#mi("{h}")#text(", we obtain")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_{n \\in I} e( f(n) ) \\ll H^{-1/2} + C A^{1/2^{k-4}} \\times")]]

#align(center)[#tao-fit-display[#mitex("\\left( \\frac{1}{N^{1/2^{k-3}}} \\left( \\frac{N^k}{TH} \\right)^{\\frac{1}{2^{k-1}-2}} \\log^{1/2^{k-3}}(2+T) + \\left( \\frac{HT}{N^k} \\right)^{\\frac{1}{2^{k-1}-2}} \\right)")]]

#text("which by the choice of ")#mi("{H}")#text(" simplifies to")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_{n \\in I} e( f(n) ) \\ll C^{1/2} A^{1/2^{k-3}}")]]

#align(center)[#tao-fit-display[#mitex("\\left( \\frac{1}{N^{1/2^{k-2}}} \\left( \\frac{N^k}{T} \\right)^{\\frac{1}{2^k-2}} \\log^{1/2^{k-2}}(2+T) + \\left( \\frac{T}{N^k} \\right)^{\\frac{1}{2^k-2}} \\right)^{1/2},")]]

#text("and the claim follows for ")#mi("{C}")#text(" large enough. ")#mi("\\Box")#linebreak()#text(" Now we can prove part (i) of Theorem ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("2")]#text(". We can assume that ")#mi("{T \\leq N^k}")#text(", since the claim follows from ")#link(<tao-6d4c9cf5e022a07ea801>)[#text("(4)")]#text(" otherwise. For any natural number ")#mi("{j \\geq 2}")#text(", we can apply Proposition ")#link(<tao-776283fe954f2e367abb>)[#text("10")]#text(" with ")#mi("{A = \\exp(O(j^2))}")#text(" and conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{1}{N} \\sum_{n \\in I} e( f(n) )\\right| \\ll", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\max\\left( \\frac{1}{N^{1/2^{j-2}}} \\left( \\frac{N^j}{T} \\right)^{\\frac{1}{2^j-2}}, \\left( \\frac{T}{N^j} \\right)^{\\frac{1}{2^j-2}} \\right) \\log^{1/2}(2+T).")]]

#text("Taking infima over ")#mi("{2 \\leq j \\leq k}")#text(", it then suffices to show that ")#metadata(none) <tao-84f6986a1b011def44ac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\inf_{2 \\leq j \\leq k} \\max\\left( \\left( \\frac{1}{N^{1/2^{j-2}}} \\left( \\frac{N^j}{T} \\right)^{\\frac{1}{2^j-2}} , \\left( \\frac{T}{N^j} \\right)^{\\frac{1}{2^j-2}} \\right) \\leq \\left( \\frac{T}{N^k} \\right)^{\\frac{1}{2^k-2}} \\right)")]]

#text(" whenever ")#mi("{N \\leq T \\leq N^k}")#text(". (The case when ")#mi("{N \\ll T \\leq N}")#text(" can be easily derived from the ")#mi("{T=N}")#text(" case, after conceding a multiplicative factor of ")#mi("{O(1)}")#text(".)")#linebreak()#text(" We prove ")#link(<tao-84f6986a1b011def44ac>)[#text("(8)")]#text(" by induction on ")#mi("{k}")#text(". The case ")#mi("{k=2}")#text(" is clear, so suppose ")#mi("{k \\ge 3}")#text(" and that ")#link(<tao-84f6986a1b011def44ac>)[#text("(8)")]#text(" has already been proven for ")#mi("{k-1}")#text(". If")

#align(center)[#tao-fit-display[#mitex("T \\geq N^{k-2 + 1/2^{k-2}}")]]

#text("then")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N^{1/2^{k-2}}} \\left( \\frac{N^k}{T} \\right)^{\\frac{1}{2^k-2}} \\leq \\left( \\frac{T}{N^k} \\right)^{\\frac{1}{2^k-2}}")]]

#text("and the claim follows from the ")#mi("{j=k}")#text(" term of the infimum. If instead")

#align(center)[#tao-fit-display[#mitex("T \\leq N^{k-2 + 1/2^{k-2}}")]]

#text("then")

#align(center)[#tao-fit-display[#mitex("\\left( \\frac{T}{N^{k-1}} \\right)^{\\frac{1}{2^{k-1}-2}} \\leq \\left( \\frac{T}{N^k} \\right)^{\\frac{1}{2^k-2}}")]]

#text("and the claim follows from the induction hypothesis.")

#heading(level: 1)[#strong[#text(" — 2. Vinogradov estimate — ")]]

#text("We now prove Theorem ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("2")]#text("(ii), loosely following the treatment in ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec and Kowalski")]#text(". We first observe that for bounded values of ")#mi("{k}")#text(", part (ii) of this theorem follows from the already proven part (i) (replacing ")#mi("{k}")#text(" by, say, ")#mi("{k+1}")#text("), so we may assume now that ")#mi("{k}")#text(" is larger than any specified absolute constant.")

#text("The first step of Vinogradov’s argument is to use a Taylor expansion and a bilinear averaging to reduce the problem to a bilinear exponential sum estimate involving polynomials with medium-sized coefficients. More precisely, we will derive Theorem ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("2")]#text("(ii) from")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 11 (Bilinear estimate)")]#text(" ")#metadata(none) <tao-c03f6631cf7e0e1bcbd0>#text(" Let ")#mi("{0 < c_0 < 1}")#text(" be a constant, let ")#mi("{k}")#text(" be a sufficiently large natural number, let ")#mi("{M \\geq 1}")#text(", and let ")#mi("{\\alpha_1,\\dots,\\alpha_k}")#text(" be real numbers, with the property that ")#metadata(none) <tao-27475dc24bb4369e58bb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("M^{-(2-c_0)j} \\leq \\left|\\alpha_j\\right| \\leq M^{-c_0 j}", block: true)]]

#text(" for at least ")#mi("{c_0 k}")#text(" values of ")#mi("{j=1,\\dots,k}")#text(". Then ")#metadata(none) <tao-1b5a6f8f2abac45a0e50>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\frac{1}{M^2} \\sum_{1 \\leq a \\leq M} \\sum_{1 \\leq b \\leq M} e( \\sum_{j=1}^k \\alpha_j a^j b^j ) \\ll_{c_0} M^{-c_1 / k^2}")]]

#text(" for some ")#mi("{c_1>0}")#text(" depending only on ")#mi("{c_0}")#text(".")
]

#text("Let us see how Theorem ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("2")]#text("(ii) follows from Theorem ")#link(<tao-c03f6631cf7e0e1bcbd0>)[#text("11")]#text(". By reducing ")#mi("{k}")#text(" as necessary, we may assume that")

#align(center)[#tao-fit-display[#mitex("N^{k-1} \\leq T \\leq N^k.")]]

#text("We may also assume that ")#metadata(none) <tao-7ee3f95b201499689bcd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("N \\geq \\exp( C k^2 )")]]

#text(" for some large constant ")#mi("{C}")#text(", as the claim is trivial otherwise.")#linebreak()#text(" Set ")#mi("{M := \\lfloor N^{1/4}\\rfloor}")#text(". For any ")#mi("{1 \\leq a,b \\leq M}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_{n \\in I} e(f(n)) = \\frac{1}{N} \\sum_{n \\in I} e(f(n+ab)) + O( N^{-1/2} )")]]

#text("and hence on averaging in ")#mi("{a,b}")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_{n \\in I} e(f(n)) = \\frac{1}{N} \\sum_n \\frac{1}{M^2} \\sum_{1 \\leq a,b \\leq M} 1_{n+ab \\in I} e(f(n+ab)) + O( N^{-1/2} ).")]]

#text("The condition ")#mi("{n+ab \\in I}")#text(" can only be satisfied if ")#mi("{n}")#text(" lies within ")#mi("{O(N^{1/2})}")#text(" of ")#mi("{I}")#text(", and if ")#mi("{n}")#text(" lies in ")#mi("{I}")#text(" and is further than ")#mi("{N^{1/2}}")#text(" from the endpoints of ")#mi("{I}")#text(" then the ")#mi("{1_{n+ab \\in I}}")#text(" constraint may be dropped. It thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{M^2} \\sum_{1 \\leq a,b \\leq M} e(f(n+ab)) \\ll N^{-c/k^2}")]]

#text("for all ")#mi("{n}")#text(" in ")#mi("{I}")#text(" that are further than ")#mi("{N^{1/2}}")#text(" from the endpoints of ")#mi("{I}")#text(".")#linebreak()#text(" Fix ")#mi("{n}")#text(". From ")#link(<tao-3f744134baea564fc3a2>)[#text("(3)")]#text(" and Taylor expansion we see that")

#align(center)[#tao-fit-display[#mitex("f(n+ab) = f(n) + \\sum_{j=1}^{3k} \\alpha_j a^j b^j + O\\left( \\exp( O(k^2) ) \\frac{T}{N^{3k+1}} (ab)^{3k+1} \\right)")]]

#text("where ")#mi("{\\alpha_j := \\frac{1}{j!} f^{(j)}(n)}")#text(". Since ")#mi("{ab \\leq \\sqrt{N}}")#text(" and ")#mi("{T \\leq N^k}")#text(", we see from ")#link(<tao-7ee3f95b201499689bcd>)[#text("(11)")]#text(" that the error term is ")#mi("{O( N^{-1} )}")#text(" (say) if ")#mi("{C}")#text(" is large enough, so")

#align(center)[#tao-fit-display[#mitex("e(f(n+ab)) = e(f(n)) e( \\sum_{j=1}^{3k} \\alpha_j a^j b^j ) + O( N^{-1} )")]]

#text("and it thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{M^2} \\sum_{1 \\leq a,b \\leq M} e\\left( \\sum_{j=1}^{3k} \\alpha_j a^j b^j\\right) \\ll N^{-c/k^2}.")]]

#text("From ")#link(<tao-3f744134baea564fc3a2>)[#text("(3)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\alpha_j\\right| = \\exp( O(j^2) ) \\frac{T}{N^j}", block: true)]]

#text("which (since ")#mi("{N^{k-1} \\leq T \\leq N^k}")#text(" and ")#mi("{k}")#text(" is large) implies from ")#link(<tao-7ee3f95b201499689bcd>)[#text("(11)")]#text(" that")

#align(center)[#tao-fit-display[#tao-math("M^{-1.9 j} \\leq \\left|\\alpha_j\\right| \\leq M^{-0.1j}", block: true)]]

#text("if ")#mi("{1.5 k \\leq j \\leq 1.6 k}")#text(" (say). The claim now follows from Theorem ")#link(<tao-c03f6631cf7e0e1bcbd0>)[#text("11")]#text(" (with ")#mi("{k}")#text(" replaced by ")#mi("{3k}")#text(").")#linebreak()#text(" It remains to prove Theorem ")#link(<tao-c03f6631cf7e0e1bcbd0>)[#text("11")]#text(". We fix ")#mi("{c_0}")#text(" and allow all implied constants to depend on ")#mi("{c_0}")#text(". We may assume that ")#metadata(none) <tao-a5a69ff5cbb24cf9481b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("M \\geq \\exp( C k^2 )")]]

#linebreak()#text(" for some large constant ")#mi("{C}")#text(" (depending on ")#mi("{c_0}")#text("), as the claim is trivial otherwise.")#linebreak()#text(" We write the left-hand side of ")#link(<tao-1b5a6f8f2abac45a0e50>)[#text("(10)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("S := \\frac{1}{M^2} \\sum_{1 \\leq a \\leq M} \\sum_{1 \\leq b \\leq M} e( B( \\gamma_k(a), \\gamma_k(b) ) )")]]

#text("where ")#mi("{{\\mathcal B}: {\\bf R}^k \\times {\\bf R}^k \\rightarrow {\\bf R}}")#text(" is the bilinear form")

#align(center)[#tao-fit-display[#mitex("{\\mathcal B}( (x_1,\\dots,x_k), (y_1,\\dots,y_k) ) := \\sum_{j=1}^k \\alpha_j x_j y_j")]]

#text("and ")#mi("{\\gamma_k: {\\bf R} \\rightarrow {\\bf R}^k}")#text(" is the polynomial curve")

#align(center)[#tao-fit-display[#mitex("\\gamma_k(a) := (a, a^2, \\dots, a^k).")]]

#text("The discrete curve ")#metadata(none) <tao-966877d108f945facc0d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\gamma_k(\\{1,\\dots,M\\}) = \\{ \\gamma_k(a): 1 \\leq a \\leq M \\}")]]

#text(" lies in the box ")#mi("{\\{ (x_1,\\dots,x_k) \\in {\\bf Z}^k: 1 \\leq x_j \\leq M^j \\text{ for all } j=1,\\dots,k\\}}")#text(", but occupies only a very sparse subset of this box. However, if one takes iterated sumsets")

#align(center)[#tao-fit-display[#mitex("\\{ \\gamma_k(a_1)+\\dots+\\gamma_k(a_\\ell): 1 \\leq a_1,\\dots,a_\\ell \\leq M \\}")]]

#text("of this curve, one expects (if ")#mi("{\\ell}")#text(" is large compared with ")#mi("{k}")#text(") to fill out a much denser subset of this box (or more precisely, of a slightly larger box in which all sides have been multiplied by ")#mi("{\\ell}")#text("), due to the “curvature” of ")#link(<tao-966877d108f945facc0d>)[#text("(13)")]#text(". By using the device of Hölder’s inequality, we will be able to estimate the sparse sum ")#mi("{S}")#text(" with a sum over such a sumset in a box, which will be significantly easier to estimate, provided one can establish the expected density property of the sumset, or at least something reasonably close to that density property. This latter claim will be accomplished by a deep result known as the ")#link("http://en.wikipedia.org/wiki/Vinogradov%27s_mean-value_theorem")[#text("Vinogradov mean value theorem")]#text(".")#linebreak()#text(" We turn to the details. Let ")#mi("{\\ell}")#text(" be a large natural number (depending on ")#mi("{k}")#text(") to be chosen later; in fact we will eventually take ")#mi("{\\ell = C_0 k^2}")#text(" for a large absolute constant ")#mi("{C_0}")#text(". From Hölder’s inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\left|S\\right|^\\ell \\leq \\frac{1}{M^{\\ell+1}} \\sum_{1 \\leq a \\leq M} \\left|\\sum_{1 \\leq b \\leq M} e( {\\mathcal B}( \\gamma_k(a), \\gamma_k(b) ) )\\right|^\\ell.", block: true)]]

#text("We remove the absolute values to write this as")

#align(center)[#tao-fit-display[#tao-math("\\left|S\\right|^\\ell \\leq \\frac{1}{M^{\\ell+1}} \\sum_{1 \\leq a \\leq M} c_a (\\sum_{1 \\leq b \\leq M} e( {\\mathcal B}( \\gamma_k(a), \\gamma_k(b) ) ))^\\ell", block: true)]]

#text("for some coefficients ")#mi("{c_a}")#text(" of magnitude ")#mi("{1}")#text(". The right-hand side can be rearranged using the bilinearity of ")#mi("{{\\mathcal B}}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{M^{\\ell+1}} \\sum_{1 \\leq b_1,\\dots,b_\\ell \\leq M} \\sum_{1 \\leq a \\leq M} c_a e( {\\mathcal B}( \\gamma_k(a), \\gamma_k(b_1)+\\dots+\\gamma_k(b_\\ell) ) ).")]]

#text("We collect some terms to obtain the inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|S\\right|^\\ell \\leq \\frac{1}{M^{\\ell+1}} \\sum_{y \\in {\\bf Z}^k} \\nu(y) \\left|\\sum_{1 \\leq a \\leq M} c_a e( {\\mathcal B}( \\gamma_k(a), y) )\\right|", block: true)]]

#text("where for each ")#mi("{y \\in {\\bf Z}^k}")#text(", ")#mi("{\\nu(y) = \\nu_{\\ell,k,M}}")#text(" is the number of representations of ")#mi("{y}")#text(" of the form ")#mi("{y = \\gamma_k(b_1)+\\dots+\\gamma_k(b_\\ell)}")#text(" with ")#mi("{1 \\leq b_1,\\dots,b_\\ell \\leq M}")#text(". Note that ")#mi("{\\nu}")#text(" is supported in the box")

#align(center)[#tao-fit-display[#tao-math("B := \\{ (y_1,\\dots,y_k) \\in {\\bf Z}^k: \\left|y_j\\right| \\leq \\ell M^j \\text{ for all } 1 \\leq j \\leq k \\}.", block: true)]]

#text("We now use Hölder’s inequality again to spread out the ")#mi("{\\gamma_k(a)}")#text(" vectors, and also to separate the ")#mi("{\\nu}")#text(" weight from the phase. Specifically, we have")

#align(center)[#tao-fit-display[#tao-math("(\\left|S\\right|^\\ell)^{2\\ell} \\leq \\frac{1}{M^{2\\ell(\\ell+1)}} (\\sum_{y \\in B} \\nu(y))^{2\\ell-2}", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\times \\sum_{y \\in B} \\nu(y)^2")]]

#align(center)[#tao-fit-display[#tao-math("\\times \\sum_{y \\in B} \\left|\\sum_{1 \\leq a \\leq M} c_a e( {\\mathcal B}( \\gamma_k(a), y) )\\right|^{2\\ell}.", block: true)]]

#text("From double counting we have ")#metadata(none) <tao-9a370ebd95136e8b2036>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\sum_{y \\in B} \\nu(y) = M^\\ell")]]

#text(" so if we write ")#metadata(none) <tao-18418c02f8f1d4731025>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("J_{\\ell,k}(M) := \\sum_{y \\in B} \\nu(y)^2")]]

#text(" then we have ")#metadata(none) <tao-69110cefbfea018dfef9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left|S\\right|^{2\\ell^2} \\leq M^{- 4 \\ell} J_{\\ell,k}(M)\\sum_{y \\in B} \\left|\\sum_{1 \\leq a \\leq M} c_a e( {\\mathcal B}( \\gamma_k(a), y) )\\right|^{2\\ell}.", block: true)]]

#text(" The quantity ")#mi("{J_{\\ell,k}(M)}")#text(" has a combinatorial interpretation as the number of solutions to the equation ")#metadata(none) <tao-1ae1dd29593288ec07a1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\gamma_k(x_1)+\\dots+\\gamma_k(x_\\ell) = \\gamma_k(y_1)+\\dots+\\gamma_k(y_\\ell)")]]

#text(" with ")#mi("{x_1,\\dots,x_\\ell,y_1,\\dots,y_\\ell \\in \\{1,\\dots,M\\}}")#text("; its estimation is the deepest and most difficult part of Vinogradov’s argument, and will be discussed presently. Leaving this aside for now, we return to ")#link(<tao-69110cefbfea018dfef9>)[#text("(16)")]#text(" and expand out the right-hand side, using the triangle inequality and bilinearity to bound it by")

#align(center)[#tao-fit-display[#mitex("M^{-4\\ell} J_{\\ell,k}(M) \\sum_{1 \\leq a_1,\\dots,a_{2\\ell} \\leq M}")]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{y \\in B} e( {\\mathcal B}( \\gamma_k(a_1)+\\dots+\\gamma_k(a_\\ell) - \\gamma_k(a_{\\ell+1})-\\dots-\\gamma_k(a_{2\\ell}), y) )\\right|.", block: true)]]

#text("The quantity ")#mi("{\\gamma_k(a_1)+\\dots+\\gamma_k(a_\\ell) - \\gamma_k(a_{\\ell+1})-\\dots-\\gamma_k(a_{2\\ell})}")#text(" lies in the box ")#mi("{B}")#text(". Furthermore, from ")#link(<tao-18418c02f8f1d4731025>)[#text("(15)")]#text(" and the Cauchy-Schwarz inequality, every ")#mi("{x \\in B}")#text(" has at most ")#mi("{J_{\\ell,k}(M)}")#text(" representations of the form")

#align(center)[#tao-fit-display[#mitex("x = \\gamma_k(a_1)+\\dots+\\gamma_k(a_\\ell) - \\gamma_k(a_{\\ell+1})-\\dots-\\gamma_k(a_{2\\ell}).")]]

#text("Thus we arrive at the inequality ")#metadata(none) <tao-a62d234c973ceea23edd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\left| S\\right|^{2\\ell^2} \\leq M^{- 4 \\ell} J_{\\ell,k}(M)^2 \\sum_{x \\in B} |\\sum_{y \\in B} e( {\\mathcal B}( x, y ) )|.", block: true)]]

#text(" The point here is that the phase is now a linear function of the variables ")#mi("{x,y}")#text(", in contrast to the polynomial function of the variables ")#mi("{a,b}")#text(" in the original definition of ")#mi("{S}")#text(". In particular, the exponential sum is now fairly easy to estimate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 12")]#text(" If ")#mi("{\\ell = O( k^2 )}")#text(", then we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in B} \\left|\\sum_{y \\in B} e( {\\mathcal B}( x, y ) )\\right| \\ll M^{-ck^2} \\left|B\\right|^2", block: true)]]

#text("for some ")#mi("{c>0}")#text(" (depending only on ")#mi("{c_0}")#text(").")
]

#emph[#text("Proof:")]#text(" We can factor the left-hand side as")

#align(center)[#tao-fit-display[#tao-math("\\prod_{j=1}^k \\sum_{\\left|x_j\\right| \\leq \\ell M^j} |\\sum_{\\left|y_j\\right| \\leq \\ell M^j} e( \\alpha_j x_j y_j )|.", block: true)]]

#text("Since ")#tao-math("{\\left|B\\right| = \\prod_{j=1}^k (2\\ell M^j+1)}", block: false)#text(" and we have the trivial bound")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\left|x_j\\right| \\leq \\ell M^j} \\left|\\sum_{\\left|y_j\\right| \\leq \\ell M} e( \\alpha_j x_j y_j )\\right| \\leq (2\\ell M^j+1)^2", block: true)]]

#text("it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\left|x_j\\right| \\leq \\ell M^j} \\left|\\sum_{\\left|y_j\\right| \\leq \\ell M} e( \\alpha_j x_j y_j )\\right| \\leq M^{-ck} (2\\ell M^j+1)^2", block: true)]]

#text("for at least ")#mi("{ck}")#text(" choices of ")#mi("{1 \\leq j \\leq k}")#text(", for some ")#mi("{c>0}")#text(".")#linebreak()#text(" By ")#link(<tao-27475dc24bb4369e58bb>)[#text("(9)")]#text(", we can find at least ")#mi("{c_0 k/2}")#text(" choices of ")#mi("{j}")#text(" with ")#mi("{c_0k/2 \\leq j \\leq k}")#text(" and")

#align(center)[#tao-fit-display[#tao-math("M^{-(2-c_0)j} \\leq \\left|\\alpha_j\\right| \\leq M^{-c_0 j}.", block: true)]]

#text("Henceforth we restrict ")#mi("{j}")#text(" to one of these choices. By summing the geometric series, or by using the trivial bound, we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{\\left|y_j\\right| \\leq \\ell M^j} e( \\alpha_j x_j y_j )\\right| \\ll \\min( \\ell M^j, \\frac{1}{\\left\\| \\alpha_j x_j \\right\\|} )", block: true)]]

#text("where ")#tao-math("{\\left\\|x\\right\\|}", block: false)#text(" denotes the distance of ")#mi("{x}")#text(" to the nearest integer. On any interval ")#mi("{I}")#text(" of length ")#tao-math("{1/\\left|\\alpha_j\\right|}", block: false)#text(", we see from the quantitative integral test (Lemma 2 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(") that")

#tao-aligned(keep: true)[


#tao-math("\\sum_{x \\in I} \\min( \\ell M^j, \\frac{1}{\\left\\| \\alpha_j x \\right\\|} )  & \\ll \\ell M^j (1 + \\frac{1}{\\ell M^j \\left|\\alpha_j\\right|}) \\log \\frac{1}{\\left|\\alpha_j\\right|}", block: true)



#tao-math(" & \\ll (\\ell M^j + \\frac{1}{\\left|\\alpha_j\\right|}) k \\log M", block: true)
]

#text("and hence")

#tao-aligned(keep: true)[


#tao-math("\\sum_{\\left|x_j\\right| \\leq \\ell M^j} \\left|\\sum_{\\left|y_j\\right| \\leq \\ell M^j} e( \\alpha_j x_j y_j )\\right|  & \\ll (1 + \\ell M^j \\left|\\alpha_j\\right|) (\\ell M^j + \\frac{1}{\\left|\\alpha_j\\right|}) k \\log M", block: true)



#tao-math(" & \\ll (\\ell M^j + (\\ell M^j)^2 \\left|\\alpha_j\\right| + \\frac{1}{\\left|\\alpha_j\\right|} ) k \\log M", block: true)



#tao-math(" & \\ll k \\ell^2 M^{-c_0 j} M^{2j} \\log M", block: true)
]

#text("for all of the ")#mi("{j}")#text(" under consideration. The claim follows since ")#mi("{\\ell = O(k^2)}")#text(", ")#mi("{j \\geq c_0k/2}")#text(", and ")#mi("{M \\geq \\exp( C k^2 )}")#text(" for some large ")#mi("{C}")#text(" (the latter hypothesis coming from ")#link(<tao-a5a69ff5cbb24cf9481b>)[#text("(12)")]#text("). ")#mi("\\Box")#linebreak()#text(" From this lemma and ")#link(<tao-a62d234c973ceea23edd>)[#text("(18)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|S\\right|^{2\\ell^2} \\leq M^{-c_2 k^2} M^{- 4 \\ell} J_{\\ell,k}(M)^2 \\left|B\\right|^2", block: true)]]

#text("for some ")#mi("{c_2 >0}")#text(" depending only on ")#mi("{c_0}")#text(". To conclude the desired bound ")#mi("{S \\leq M^{-c/k^2}}")#text(", it thus suffices to establish the following result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 13 (Vinogradov mean value theorem)")]#text(" ")#metadata(none) <tao-d4bf696eb64f854fa21c>#text(" Let ")#mi("{k,\\ell}")#text(" be natural numbers such that ")#mi("{\\ell \\geq k^2}")#text(". Then ")#metadata(none) <tao-7e89aadf5e96c325ae6e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("J_{\\ell,k}(M) \\ll \\exp( O(\\ell^2) ) M^{O(k^2 \\exp(-\\ell/k^2))} \\frac{M^{2\\ell}}{\\left|B\\right|}", block: true)]]

#text(" for an absolute constant ")#mi("{c>0}")#text(".")
]

#text("If we apply this theorem with ")#mi("{\\ell}")#text(" equal to a sufficiently large multiple of ")#mi("{k^2}")#text(", we obtain the required bound ")#mi("{S \\ll M^{-c/k^2}}")#text(".")

#text("Actually, Vinogradov proved a slightly weaker estimate than this; the claim above (in a sharper form) was obtained by later refinements of the argument due to Stechkin and Karatsuba. This result has a number of applications beyond that of controlling the Riemann zeta function; for instance it has application to the ")#link("http://en.wikipedia.org/wiki/Waring%27s_problem")[#text("Waring problem")]#text(" of expressing large natural numbers as the sum of ")#mi("{k^{th}}")#text(" powers, which we will not discuss further here. The reason for the name “mean value theorem” is that the quantity ")#mi("{J_{\\ell,k}(M)}")#text(" has a Fourier-analytic interpretation as a mean")

#align(center)[#tao-fit-display[#tao-math("J_{\\ell,k}(M) = \\int_{{\\mathbb T}^k} \\left|S_M(\\alpha)\\right|^{2\\ell}\\ d\\alpha", block: true)]]

#text("of the exponential sum")

#align(center)[#tao-fit-display[#mitex("S_M(\\alpha_1,\\dots,\\alpha_k) := \\sum_{n \\leq M} e( \\alpha_1 n + \\dots + \\alpha_k n^k ).")]]

#text("The estimate ")#link(<tao-7e89aadf5e96c325ae6e>)[#text("(19)")]#text(" should be compared with the lower bound")

#align(center)[#tao-fit-display[#tao-math("J_{\\ell,k}(M) \\gg M^\\ell + \\frac{M^{2\\ell}}{\\left|B\\right|},", block: true)]]

#text("where the ")#mi("{M^\\ell}")#text(" term comes from the diagonal contribution ")#mi("{(x_1,\\dots,x_k) = (y_1,\\dots,y_k)}")#text(" to ")#link(<tao-1ae1dd29593288ec07a1>)[#text("(17)")]#text(", and the ")#tao-math("{\\frac{M^{2\\ell}}{\\left|B\\right|}}", block: false)#text(" term coming from ")#link(<tao-9a370ebd95136e8b2036>)[#text("(14)")]#text(" and the Cauchy-Schwarz inequality. Informally, ")#link(<tao-7e89aadf5e96c325ae6e>)[#text("(19)")]#text(" is an assertion that the ")#mi("{\\ell}")#text("-fold sum of the discrete curve ")#link(<tao-966877d108f945facc0d>)[#text("(13)")]#text(" is somewhat close to being uniformly distributed on ")#mi("{B}")#text(". The ")#emph[#text("main conjecture")]#text(" of Vinogradov asserts the near-optimal bound ")#metadata(none) <tao-0d6e4079e36703ebd37c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("J_{\\ell,k}(M) \\ll_{\\varepsilon,\\ell,k} M^{\\varepsilon} (M^\\ell + \\frac{M^{2\\ell}}{\\left|B\\right|})", block: true)]]

#text(" for any choice of ")#mi("{\\varepsilon>0}")#text(" and ")#mi("{\\ell,k,M}")#text(". In the recent ")#link("http://www.ams.org/mathscinet-getitem?mr=2912712")[#text("work of Wooley")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=3286035")[#text("Ford-Wooley")]#text(", an improved version of the congruencing method given below known as ")#emph[#text("efficient congruencing")]#text(" has been developed and used to establish the main conjecture ")#link(<tao-0d6e4079e36703ebd37c>)[#text("(20)")]#text(" in many cases. See ")#link("http://arxiv.org/abs/1404.3508")[#text("this recent ICM proceedings article of Wooley")]#text(" for a survey of the latest developments in this direction.")#linebreak()#text(" We now turn to the proof of the Vinogradov mean value theorem. Since")

#align(center)[#tao-fit-display[#tao-math("\\left|B\\right| = \\prod_{j=1}^k (2\\ell M^j+1) = \\exp( O( k \\log \\ell) ) M^{\\frac{\\ell(\\ell+1)}{2}}", block: true)]]

#text("and ")#mi("{\\ell \\geq k^2}")#text(", we have ")#mi("{k \\log \\ell = O( \\ell^2 )}")#text(", and so it will suffice to show that ")#metadata(none) <tao-fb9898414ca5ac20c0ae>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("j_{\\ell,k}(M) \\ll \\exp( O(\\ell^2) ) M^{O(k^2 \\exp(-\\ell/k^2))}")]]

#text(" whenever ")#mi("{\\ell \\geq k^2}")#text(" and ")#mi("{j_{\\ell,k}(M)}")#text(" is the normalised quantity ")#metadata(none) <tao-5ca17f9433e3f227c2a7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("j_{\\ell,k}(M) := M^{\\frac{k(k+1)}{2}-2\\ell} J_{\\ell,k}(M),")]]

#text(" which can be viewed as a measure of irregularity of distribution of the quantity ")#mi("{\\gamma_k(x_1)+\\dots+\\gamma_k(x_\\ell)}")#text(" for ")#mi("{x_1,\\dots,x_\\ell \\in \\{1,\\dots,M\\}}")#text(".")#linebreak()#text(" We have the extremely crude bound")

#align(center)[#tao-fit-display[#mitex("J_{\\ell,k}(M) \\leq M^{2\\ell}")]]

#text("coming from the fact that there are ")#mi("{M^{2\\ell}}")#text(" choices of ")#mi("{x_1,\\dots,x_\\ell,y_1,\\dots,y_\\ell \\in \\{1,\\dots,M\\}}")#text(", so that ")#metadata(none) <tao-ff059f1fc565078ac1e2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("j_{\\ell,k}(M) \\leq M^{O(k^2)}.")]]

#linebreak()#text(" This already establishes the claim when ")#mi("{\\ell \\leq 10k^2}")#text(" (say). For ")#mi("{\\ell > 10k^2}")#text(", what we will do is establish the recursive inequality ")#metadata(none) <tao-9d2c65dda8df9efa4769>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("j_{\\ell,k}(M)+1 \\ll \\exp(O(\\ell k)) ( j_{\\ell-k,k}(q) + 1 )")]]

#linebreak()#text(" whenever ")#mi("{\\ell > 10k^2}")#text(" and some ")#mi("{q \\leq M^{1-1/k}}")#text("; iterating this ")#mi("{\\lfloor \\ell/k \\rfloor}")#text(" times and then using ")#link(<tao-ff059f1fc565078ac1e2>)[#text("(23)")]#text(", we will obtain the claim. Note how it is important here that no powers of ")#mi("{M}")#text(" are lost in the estimate ")#link(<tao-9d2c65dda8df9efa4769>)[#text("(24)")]#text(". However, we can be quite generous in losing factors such as ")#mi("{k!}")#text(", ")#mi("{\\ell^k}")#text(", or ")#mi("{k^\\ell}")#text(" as these are easily absorbed in the ")#mi("{\\exp(O(\\ell k))}")#text(" term. To prove ")#link(<tao-9d2c65dda8df9efa4769>)[#text("(24)")]#text(", we begin with a technical reduction. For a prime ")#mi("{p}")#text(", let us first define a restricted version ")#mi("{J^{(p)}_{\\ell,k}(M)}")#text(" of ")#mi("{J_{\\ell,k}(M)}")#text(" to be the number of solutions to")

#align(center)[#tao-fit-display[#mitex("\\gamma_k(x_1)+\\dots+\\gamma_k(x_\\ell) = \\gamma_k(y_1)+\\dots+\\gamma_k(y_\\ell)")]]

#text("with ")#mi("{x_1,\\dots,x_\\ell,y_1,\\dots,y_\\ell \\in \\{1,\\dots,M\\}}")#text(", with ")#mi("{x_1,\\dots,x_k}")#text(" having distinct reductions mod ")#mi("{p}")#text(", and ")#mi("{y_1,\\dots,y_k}")#text(" also having distinct reductions mod ")#mi("{p}")#text(". As we are taking ")#mi("{p}")#text(" to be rather large, one should think of the constraint of having distinct reductions mod ")#mi("{p}")#text(" to be a mild condition, so that ")#mi("{J^{(p)}_{\\ell,k}(M)}")#text(" is morally of the same size as ")#mi("{J_{\\ell,k}(M)}")#text(". This is confirmed by the following proposition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 14")]#text(" ")#metadata(none) <tao-efbaa8cbfffc1af3afcf>#text(" There exists a prime ")#mi("{p}")#text(" with ")#mi("{k M^{1/k} < p \\ll k^4 M^{1/k}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("J_{\\ell,k}(M) \\ll \\exp( O( \\ell k ) ) ( J^{(p)}_{\\ell,k}(M) + M^{\\ell+k-1} ).")]]
]

#text("The reason why we need the prime ")#mi("{p}")#text(" to be somewhat comparable to ")#mi("{M^{1/k}}")#text(" will be clearer later.")

#emph[#text("Proof:")]#text(" By definition, ")#mi("{J_{\\ell,k}(M)}")#text(" is the number of solutions to ")#metadata(none) <tao-769a4e6d0003189c7e96>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\gamma_k(x_1)+\\dots+\\gamma_k(x_\\ell) = \\gamma_k(y_1)+\\dots+\\gamma_k(y_\\ell)")]]

#linebreak()#text(" with ")#mi("{x_1,\\dots,x_\\ell,y_1,\\dots,y_\\ell \\in \\{1,\\dots,M\\}}")#text(". If the set ")#mi("{\\{x_1,\\dots,x_\\ell\\}}")#text(" has cardinality less than ")#mi("{k}")#text(", then there are ")#mi("{O( k^\\ell M^{k-1} )}")#text(" ways to choose the ")#mi("{x_1,\\dots,x_\\ell}")#text(", and ")#mi("{O(M^\\ell)}")#text(" ways to choose ")#mi("{y_1,\\dots,y_\\ell}")#text(", leading to a contribution of at most ")#mi("{\\exp( O( \\ell k ) M^{\\ell+k-1} )}")#text(" to ")#mi("{J_{\\ell,k}(M)}")#text(". Similarly if ")#mi("{\\{y_1,\\dots,y_\\ell\\}}")#text(" has cardinality less than ")#mi("{k}")#text(". Thus we may restrict attention to the case when ")#mi("{\\{x_1,\\dots,x_\\ell\\}}")#text(" and ")#mi("{\\{y_1,\\dots,y_\\ell\\}}")#text(" have cardinality at least ")#mi("{k}")#text(". By paying a factor of ")#mi("{\\binom{\\ell}{k}^2 = \\exp( O(\\ell k) )}")#text(", we may then restrict to the case where ")#mi("{x_1,\\dots,x_k}")#text(" are all distinct, and ")#mi("{y_1,\\dots,y_k}")#text(" are all distinct. In particular, the quantity")

#align(center)[#tao-fit-display[#mitex("\\prod_{1 \\leq i < j \\leq k} (x_i-x_j)(y_i-y_j)")]]

#text("is non-zero and has cardinality at most ")#mi("{M^{k^2-k}}")#text(". In particular, there are at most ")#mi("{k^3-k^2}")#text(" primes larger than ")#mi("{M^{1/k}}")#text(" that define this quantity. On the other hand, from the prime number theorem we can find ")#mi("{k^3}")#text(" distinct primes ")#mi("{p_1,\\dots,p_{k^3}}")#text(" in the range ")#mi("{k M^{1/k} < p_j \\ll k^4 M^{1/k}}")#text(". We thus see that for each solution to ")#link(<tao-769a4e6d0003189c7e96>)[#text("(25)")]#text(" with ")#mi("{x_1,\\dots,x_\\ell,y_1,\\dots,y_\\ell \\in \\{1,\\dots,M\\}}")#text(", ")#mi("{x_1,\\dots,x_k}")#text(" distinct, and ")#mi("{y_1,\\dots,y_k}")#text(" distinct, there is a ")#mi("{1 \\leq j \\leq k^3}")#text(" such that ")#mi("{x_1,\\dots,x_k}")#text(" has distinct reductions mod ")#mi("{p_j}")#text(", and ")#mi("{y_1,\\dots,y_k}")#text(" also has distinct reductions mod ")#mi("{p_j}")#text(", so that this tuple contributes to ")#mi("{J^{(p_j)}_{\\ell,k}(M)}")#text(". Thus we have")

#align(center)[#tao-fit-display[#mitex("J_{\\ell,k}(M) \\ll \\sum_{j=1}^{k^3} J^{(p_j)}_{\\ell,k}(M) + \\exp(O(\\ell k) ) M^{\\ell+k-1}")]]

#text("and the claim follows. ")#mi("\\Box")#linebreak()#text(" Introducing the normalised quantity")

#align(center)[#tao-fit-display[#mitex("j^{(p)}_{\\ell,k}(M) := M^{\\frac{k(k+1)}{2}-2\\ell} J^{(p)}_{\\ell,k}(M),")]]

#text("and recalling that ")#mi("{\\ell > 10k^2}")#text(", we conclude that ")#metadata(none) <tao-7152e6ec048e24fadb10>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("j_{\\ell,k}(M) \\ll \\exp( O( \\ell k ) ) j^{(p)}_{\\ell,k}(M) + 1")]]

#text(" for some prime ")#mi("{k M^{1/k} < p \\ll k^4 M^{1/k}}")#text(".")#linebreak()#text(" The next step is to analyse the multiplicity properties of the ")#mi("{k}")#text("-fold sum ")#mi("{\\gamma_k(y_1)+\\dots+\\gamma_k(y_k)}")#text(". Clearly we have")

#align(center)[#tao-fit-display[#mitex("\\gamma_k(y_1) + \\dots + \\gamma_k(y_k) = (p_1(y_1,\\dots,y_k), \\dots, p_k(y_1,\\dots,y_k))")]]

#text("where the power sums ")#mi("{p_j(y_1,\\dots,y_k)}")#text(" are defined by")

#align(center)[#tao-fit-display[#mitex("p_j(y_1,\\dots,y_k) := y_1^j + \\dots + y_k^j.")]]

#text("We recall a classical relation, known as ")#link("http://en.wikipedia.org/wiki/Newton%27s_identities")[#text("Newton’s identities")]#text(" (or ")#emph[#text("Newton-Girard identities")]#text("), between these power sums and the ")#link("http://en.wikipedia.org/wiki/Elementary_symmetric_polynomial")[#text("elementary symmetric polynomials")]#text(" ")#mi("{e_j(y_1,\\dots,y_k)}")#text(", defined for ")#mi("{j \\geq 0}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("e_j(y_1,\\dots,y_k) := \\sum_{1 \\leq i_1 < \\dots < i_j \\leq k} y_{i_1} \\dots y_{i_j}.")]]

#text("For instance ")#mi("{e_0=1}")#text(", ")#mi("{e_1 = p_1}")#text(", and ")#mi("{e_j=0}")#text(" for all ")#mi("{j>k}")#text(". One can also view the ")#mi("{e_j}")#text(" as essentially being the coefficients of the polynomial ")#mi("{(x-y_1)\\dots(x-y_k)}")#text(": ")#metadata(none) <tao-3608bca1e44ea6c4d268>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("(x-y_1) \\dots (x-y_k) = \\sum_{j=0}^k (-1)^j e_j(y_1,\\dots,y_k) x^{k-j}.")]]



#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 15 (Newton’s identities)")]#text(" For any ")#mi("{1 \\leq j \\leq k}")#text(", one has the polynomial identity")

#align(center)[#tao-fit-display[#mitex("j e_j = \\sum_{i=0}^{j-1} (-1)^i e_{j-i-1} p_{i+1}.")]]
]

#text("Thus for instance")

#tao-aligned(keep: true)[


#tao-math("e_1  & = p_1", block: true)



#tao-math("2e_2  & = e_1 p_1 - p_2", block: true)



#tao-math("3e_3  & = e_2 p_1 - e_1 p_2 + p_3.", block: true)
]

#emph[#text("Proof:")]#text(" We use the method of generating functions. We rewrite the polynomial identity ")#link(<tao-3608bca1e44ea6c4d268>)[#text("(27)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("(1-y_1 x) \\dots (1-y_k x) = \\sum_{j=0}^k (-1)^j e_j(y_1,\\dots,y_k) x^j.")]]

#text("On the other hand, taking logarithmic derivatives we have (as formal power series)")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dx} [(1-y_1 x) \\dots (1-y_k x)] = - (1-y_1 x) \\dots (1-y_k x) \\sum_{a=1}^k \\frac{y_a}{1-y_a x}.")]]

#text("From the geometric series formula we have (as formal power series)")

#align(center)[#tao-fit-display[#mitex("\\sum_{a=1}^k \\frac{y_a}{1-y_a x} = \\sum_{i=0}^\\infty p_{i+1}(y_1,\\dots,y_k) x^j")]]

#text("and the claim then follows by equating coefficients. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 16")]#text(" If ")#mi("{y_1,\\dots,y_k \\in {\\bf Z}}")#text(", then the quantity ")#mi("{\\gamma_k(y_1)+\\dots+\\gamma_k(y_k)}")#text(" determines the multiset ")#mi("{\\{y_1,\\dots,y_k\\}}")#text(" up to permutations. In particular, any element ")#mi("{v}")#text(" of ")#mi("{{\\bf Z}^k}")#text(" has at most ")#mi("{k!}")#text(" representations of the form ")#mi("{v = \\gamma_k(y_1)+\\dots+\\gamma_k(y_k)}")#text(".")
]

#emph[#text("Proof:")]#text(" The quantity ")#mi("{\\gamma_k(y_1)+\\dots+\\gamma_k(y_k)}")#text(" determines the quantities ")#mi("{p_j(y_1,\\dots,y_k)}")#text(" for ")#mi("{j=1,\\dots,k}")#text(". By Newton’s identities and induction, this determines the quantities ")#mi("{e_j(y_1,\\dots,y_k)}")#text(" for ")#mi("{j=1,\\dots,k}")#text(", and thus determines the polynomial ")#mi("{(x-y_1) \\dots (x-y_k)}")#text(". The claim now follows from the unique factorisation of polynomials. ")#mi("\\Box")

#text("This particular result turns out to not give particularly good bounds on ")#mi("{J_{\\ell,k}(M)}")#text("; the sums ")#mi("{\\gamma_k(y_1)+\\dots+\\gamma_k(y_k)}")#text(" are so sparsely distributed that the number of representations of a given ")#mi("{v}")#text(" (in, say, the box ")#mi("{B}")#text(") is typically zero. However, if we localise “")#mi("{p}")#text("-adically”, by replacing the integers ")#mi("{{\\bf Z}}")#text(" with the ring ")#mi("{{\\bf Z}/p^k{\\bf Z}}")#text(", we get a more usable result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 17")]#text(" ")#metadata(none) <tao-4c50d1ff845ad29f110f>#text(" Let ")#mi("{p}")#text(" be a prime with ")#mi("{p>k}")#text(". Then any ")#mi("{v \\in ({\\bf Z}/p^k)^k}")#text(" has at most ")#mi("{k!}")#text(" representations of the form")

#align(center)[#tao-fit-display[#mitex("v = \\gamma_k(y_1) + \\dots + \\gamma_k(y_k)")]]

#text("with ")#mi("{y_1,\\dots,y_k \\in {\\bf Z}/p^k {\\bf Z}}")#text(" having distinct reductions mod ")#mi("{p}")#text(", where by abuse of notation we localise ")#mi("{\\gamma_k: {\\bf Z}/p^k{\\bf Z} \\rightarrow ({\\bf Z}/p^k{\\bf Z})^k}")#text(" to the ring ")#mi("{{\\bf Z}/p{\\bf Z}}")#text(" in the obvious fashion.")
]

#text("To put it another way, this corollary asserts that the map ")#mi("{(y_1,\\dots,y_k) \\rightarrow \\gamma_k(y_1)+\\dots\\gamma_k(y_k)}")#text(" from ")#mi("{({\\bf Z}/p^k)^k}")#text(" to ")#mi("{({\\bf Z}/p^k)^k}")#text(" is at most ")#mi("{k!}")#text("-to-one, if one excludes those ")#mi("{y_1,\\dots,y_k}")#text(" which do not have distinct reductions mod ")#mi("{p}")#text(".")

#emph[#text("Proof:")]#text(" Suppose we have two representations")

#align(center)[#tao-fit-display[#mitex("\\gamma_k(x_1)+\\dots+\\gamma_k(x_k) = \\gamma_k(y_1)+\\dots+\\gamma_k(y_k)")]]

#text("with ")#mi("{y_1,\\dots,y_k \\in {\\bf Z}/p^k{\\bf Z}}")#text(" and ")#mi("{x_1,\\dots,x_k \\in {\\bf Z}/p^k{\\bf Z}}")#text(" each having distinct reductions mod ")#mi("{p}")#text(". By Newton’s identities as before, we have ")#mi("{e_j(x_1,\\dots,x_k) = e_j(y_1,\\dots,y_k)}")#text(" for ")#mi("{j=1,\\dots,k}")#text(" (note that as ")#mi("{p>k}")#text(" there is no difficulty dividing by ")#mi("{j}")#text(" for ")#mi("{j=1,\\dots,k}")#text("). Therefore we have the polynomial identity")

#align(center)[#tao-fit-display[#mitex("(x-x_1) \\dots (x-x_k) = (x-y_1) \\dots (x-y_k)")]]

#text("as polynomials over ")#mi("{{\\bf Z}/p^k {\\bf Z}}")#text(". In particular, each ")#mi("{x_i}")#text(" is a root of ")#mi("{(x-y_1) \\dots (x-y_k)}")#text(" and thus must equal one of the ")#mi("{y_j}")#text(" since the reductions mod ")#mi("{p}")#text(" are all distinct (and so all but one of the factors ")#mi("{(x_i-y_1),\\dots,(x_i-y_k)}")#text(" will be invertible in ")#mi("{{\\bf Z}/p^k{\\bf Z}}")#text("). This implies that ")#mi("{\\{x_1,\\dots,x_k\\}}")#text(" is a permutation of ")#mi("{\\{y_1,\\dots,y_k\\}}")#text(", and the claim follows. ")#mi("\\Box")#linebreak()#text(" Returning to the integers, and specialising to the range of primes ")#mi("{p}")#text(" produced by Lemma ")#link(<tao-efbaa8cbfffc1af3afcf>)[#text("14")]#text(", we conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 18 (Linnik’s lemma)")]#text(" Let ")#mi("{p}")#text(" be a prime with ")#mi("{k M^{1/k} < p \\ll k^4 M^{1/k}}")#text(", and let ")#mi("{v = (v_1,\\dots,v_k) \\in {\\bf Z}^k}")#text(". Then the number of solutions to the system")

#align(center)[#tao-fit-display[#mitex("x_1^j + \\dots + x_k^j = v_j \\text{ mod } p^j")]]

#text("with ")#mi("{j=1,\\dots,k}")#text(" and ")#mi("{x_1,\\dots,x_k \\in \\{1,\\dots,M\\}}")#text(", with ")#mi("{x_1,\\dots,x_k}")#text(" having distinct reductions modulo ")#mi("{p}")#text(", is at most ")#mi("{\\exp( O(\\ell k) ) p^{\\frac{k(k-1)}{2}} }")#text(".")
]

#text("A version of this lemma also applies for primes ")#mi("{p}")#text(" outside of the range ")#mi("{k M^{1/k} < p \\ll k^4 M^{1/k}}")#text(", but this is basically the range where the lemma is the most efficient. Indeed, probabilistic heuristics suggest that the number of solutions here should be approximately ")#mi("{M^k / \\prod_{j=1}^k p^j}")#text(", which equals ")#mi("{\\exp( O(\\ell k) ) p^{\\frac{k(k-1)}{2}} )}")#text(" in the range ")#mi("{k M^{1/k} < p \\ll k^4 M^{1/k}}")#text(".")

#emph[#text("Proof:")]#text(" Each residue class mod ")#mi("{p^j}")#text(" consists of ")#mi("{p^{k-j}}")#text(" residue classes mod ")#mi("{p^k}")#text(". Since")

#align(center)[#tao-fit-display[#mitex("\\prod_{j=1}^k p^{k-j} = p^{k(k-1)/2},")]]

#text("it thus suffices (replacing ")#mi("{v}")#text(" with ")#mi("{p^{k(k-1)/2}}")#text(" different elements of ")#mi("{{\\bf Z}^k}")#text(") to show that for any ")#mi("{v \\in {\\bf Z}^k}")#text(", the number of solutions to the lifted system")

#align(center)[#tao-fit-display[#mitex("x_1^j + \\dots + x_k^j = v_j \\text{ mod } p^k")]]

#text("with ")#mi("{j=1,\\dots,k}")#text(" and ")#mi("{x_1,\\dots,x_k \\in \\{1,\\dots,M\\}}")#text(" is at most ")#mi("{\\exp( O( \\ell k) )}")#text(". But each residue class mod ")#mi("{p^k}")#text(" meets ")#mi("{\\{1,\\dots,M\\}}")#text(" in at most ")#mi("{O(1)}")#text(" representatives, so the claim follows from Corollary ")#link(<tao-4c50d1ff845ad29f110f>)[#text("17")]#text(", crudely bounding ")#mi("{k!}")#text(" by ")#mi("{\\exp( O( \\ell k) )}")#text(". ")#mi("\\Box")#linebreak()#text(" Now we need to consider sums ")#mi("{\\gamma_k(x_1)+\\dots+\\gamma_k(x_\\ell)}")#text(" of ")#mi("{\\ell}")#text(" terms, rather than just ")#mi("{k}")#text(" terms. Recall that ")#mi("{J^{(p)}_{\\ell,k}(M)}")#text(" is the number of solutions to")

#align(center)[#tao-fit-display[#mitex("\\gamma_k(x_1)+\\dots+\\gamma_k(x_\\ell) = \\gamma_k(y_1)+\\dots+\\gamma_k(y_\\ell)")]]

#text("with ")#mi("{x_1,\\dots,x_\\ell,y_1,\\dots,y_\\ell \\in \\{1,\\dots,M\\}}")#text(", with ")#mi("{x_1,\\dots,x_k}")#text(" having distinct reductions mod ")#mi("{p}")#text(", and ")#mi("{y_1,\\dots,y_k}")#text(" also having distinct reductions mod ")#mi("{p}")#text(". We also need an even more restricted version ")#mi("{\\tilde J^{(p)}_{\\ell,k}(M)}")#text(" of ")#mi("{J_{\\ell,k}(M)}")#text(", which is defined similarly to ")#mi("{J^{(p)}_{\\ell,k}(M)}")#text(" but with the additional constraint that")

#align(center)[#tao-fit-display[#mitex("x_{k+1} = \\dots = x_{\\ell} = y_{k+1} = \\dots = y_\\ell \\text{ mod } p.")]]

#text("Probabilistic heuristics suggest that ")#mi("{\\tilde J^{(p)}_{\\ell,k}(M)}")#text(" should be about ")#mi("{p^{1-2(\\ell-k)}}")#text(" as large as ")#mi("{J^{(p)}_{\\ell,k}(M)}")#text(". One side of this prediction is confirmed by the following application of Hölder’s inequality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 19 (Hölder inequality)")]#text(" ")#metadata(none) <tao-e8b22d83b417e85ba4f2>#text(" We have")

#align(center)[#tao-fit-display[#mitex("J^{(p)}_{\\ell,k}(M) \\leq p^{2\\ell - 2k - 1} \\tilde J^{(p)}_{\\ell,k}(M).")]]

#text("In particular, introducing the normalised quantity ")#metadata(none) <tao-897118c6f982513fc2b8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\tilde j^{(p)}_{\\ell,k}(M) := M^{\\frac{k(k+1)}{2}-2\\ell} p^{2\\ell - 2k - 1} \\tilde J^{(p)}_{\\ell,k}(M)")]]

#text(" we have ")#metadata(none) <tao-74fcb92c40783781b365>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("j^{(p)}_{\\ell,k}(M) \\leq \\tilde j^{(p)}_{\\ell,k}(M) .")]]


]

#emph[#text("Proof:")]#text(" It is easiest to prove this by Fourier-analytic means. Observe that we have the Fourier expansion")

#align(center)[#tao-fit-display[#tao-math("J^{(p)}_{\\ell,k}(M) = \\int_{({\\bf R}/{\\bf Z})^k} \\left|S_1(\\alpha)\\right|^2 \\left|S_2(\\alpha)\\right|^{2(\\ell-k)}\\ d\\alpha", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("S_1(\\alpha) := \\sum_{x_1,\\dots,x_k \\in \\{1,\\dots,M\\}}^* e( \\alpha \\cdot ( \\gamma_k(x_1)+\\dots+\\gamma_k(x_k) ) )")]]

#text("where the asterisk denotes the restriction to those ")#mi("{x_1,\\dots,x_k}")#text(" with distinct reductions modulo ")#mi("{p}")#text(" and ")#mi("{(\\alpha_1,\\dots,\\alpha_k) \\cdot (n_1,\\dots,n_k)}")#text(" is the usual dot product ")#mi("{\\alpha_1 n_1 + \\dots + \\alpha_k n_k}")#text(", and")

#align(center)[#tao-fit-display[#mitex("S_2(\\alpha) := \\sum_{x \\in \\{1,\\dots,M\\}} e( \\alpha \\cdot \\gamma_k(x) ).")]]

#text("Similarly, we have")

#align(center)[#tao-fit-display[#tao-math("\\tilde J^{(p)}_{\\ell,k}(M) = \\sum_{u \\in {\\bf Z}/p{\\bf Z}} \\int_{({\\bf R}/{\\bf Z})^k} \\left|S_1(\\alpha)\\right|^2 \\left|S_{2,u}(\\alpha)\\right|^{2(\\ell-k)}\\ d\\alpha", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("S_{2,u}(\\alpha) := \\sum_{x \\in \\{1,\\dots,M\\}: x = u\\text{ mod } p} e( \\alpha \\cdot \\gamma_k(x) ).")]]

#text("Since ")#mi("{S_2(\\alpha) = \\sum_{u \\in {\\bf Z}/p{\\bf Z}} S_{2,u}(\\alpha)}")#text(", the claim now follows from Hölder’s inequality. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Find a non-Fourier-analytic proof of the above lemma, based on the Cauchy-Schwarz inequality, in the case when ")#mi("{\\ell-k}")#text(" is a power of two. (")#emph[#text("Hint:")]#text(" you may wish to generalise the Hölder inequality to one involving the number of solutions ")#mi("{E_\\ell(A_1,\\dots,A_\\ell)}")#text(" to systems ")#mi("{a_1+\\dots+a_\\ell = b_1 + \\dots + b_\\ell}")#text(" where each ")#mi("{a_j,b_j}")#text(" is drawn from a finite multiset ")#mi("{A_j}")#text(" (such quantities are known as ")#emph[#text("additive energies of order ")#mi("{k}")]#text(" in the additive combinatorics literature).) For an additional challenge: find a Cauchy-Schwarz proof that works for arbitrary values of ")#mi("{\\ell-k}")#text(".")
]

#text("Next, we use the Linnik lemma and some elementary arguments to bound ")#mi("{\\tilde J^{(p)}_{\\ell,k}(M)}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 21")]#text(" If ")#mi("{k M^{1/k} < p \\ll k^4 M^{1/k}}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\tilde J^{(p)}_{\\ell,k}(M) \\leq \\exp( O(\\ell k)) M^k p^{\\frac{k(k+1)}{2}} J_{\\ell-k,k}(q)")]]

#text("where ")#mi("{q := \\lfloor M/p\\rfloor+1}")#text(". In particular, from ")#link(<tao-5ca17f9433e3f227c2a7>)[#text("(22)")]#text(" and ")#link(<tao-897118c6f982513fc2b8>)[#text("(28)")]#text(" we have ")#metadata(none) <tao-e10c4e14763654ec79be>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\tilde j^{(p)}_{\\ell,k}(M) \\ll \\exp( O(\\ell k)) J_{\\ell-k,k}(q).")]]


]

#emph[#text("Proof:")]#text(" By definition, ")#mi("{\\tilde J^{(p)}_{\\ell,k}(M)}")#text(" is the number of solutions to the system")

#align(center)[#tao-fit-display[#mitex("\\gamma_k(x_1)+\\dots+\\gamma_k(x_\\ell) = \\gamma_k(y_1)+\\dots+\\gamma_k(y_\\ell)")]]

#text("where ")#mi("{x_1,\\dots,x_\\ell,y_1,\\dots,y_\\ell \\in\\{1,\\dots,M\\}}")#text(", with ")#mi("{x_1,\\dots,x_k}")#text(" and ")#mi("{y_1,\\dots,y_k}")#text(" each having distinct reductions mod ")#mi("{p}")#text(", and also")

#align(center)[#tao-fit-display[#mitex("x_{k+1}=\\dots=x_{\\ell} = y_{k+1} = \\dots = y_{\\ell} = u \\text{ mod } p")]]

#text("for some ")#mi("{u \\in \\{1,\\dots,p\\}}")#text(". From the binomial theorem, ")#mi("{\\gamma_k(\\cdot-u)}")#text(" is a linear transform of ")#mi("{\\gamma_k(\\cdot)}")#text(", so")

#align(center)[#tao-fit-display[#mitex("\\gamma_k(x_1-u)+\\dots+\\gamma_k(x_\\ell-u) = \\gamma_k(y_1-u)+\\dots+\\gamma_k(y_\\ell-u).")]]

#text("Writing ")#mi("{x_j = u + p x^{\\prime}_j}")#text(" and ")#mi("{y_j = u + p y^{\\prime}_j}")#text(" for ")#mi("{k+1 \\leq j \\leq \\ell}")#text(" and some ")#mi("{x^{\\prime}_j,y^{\\prime}_j \\in\\{1,\\dots, q \\}}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\gamma_k(x_1-u)+\\dots+\\gamma_k(x_k-u) + \\gamma_k(p x^{\\prime}_{k+1}) + \\dots + \\gamma_k( p x^{\\prime}_\\ell ) = \\gamma_k(y_1-u)+\\dots+\\gamma_k(y_k-u) + \\gamma_k( p y^{\\prime}_{k+1} ) + \\dots + \\gamma_k( p y^{\\prime}_\\ell ).")]]

#text("In particular, taking the ")#mi("{j^{th}}")#text(" coefficient")

#align(center)[#tao-fit-display[#mitex("(x_1-u)^j + \\dots + (x_k-u)^j = (y_1-u)^j + \\dots + (y_k-u)^j \\text{ mod } p^j.")]]

#text("There are ")#mi("{p M^k}")#text(" choices for ")#mi("{u,y_1,\\dots,y_k}")#text(", and then by Linnik’s lemma once ")#mi("{u,y_1,\\dots,y_k}")#text(" are chosen, there are at most ")#mi("{\\exp(O(\\ell k)) p^{\\frac{k(k-1)}{2}}}")#text(" choices for ")#mi("{x_1,\\dots,x_k}")#text(". Once these are chosen, we still have to select ")#mi("{x^{\\prime}_{k+1},\\dots,x^{\\prime}_\\ell,y^{\\prime}_{k+1},\\dots,y^{\\prime}_\\ell \\in \\{1,\\dots,q\\}}")#text(" subject to a constraint of the form")

#align(center)[#tao-fit-display[#mitex("\\gamma_k( x^{\\prime}_{k+1} ) + \\dots + \\gamma_k(x^{\\prime}_\\ell) = a + \\gamma_k( y^{\\prime}_{k+1} ) + \\dots + \\gamma_k(y^{\\prime}_\\ell)")]]

#text("for some ")#mi("{a}")#text(" depending on ")#mi("{u, x_1,\\dots,x_k,y_1,\\dots,y_k}")#text(". The number of solutions to this system is")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\nu_{\\ell-k,k,q}(n) \\nu_{\\ell-k,k,q}(n+a)")]]

#text("which by the Cauchy-Schwarz inequality is bounded by ")#mi("{J_{\\ell-k,k}(q)}")#text(". The claim follows. ")#mi("\\Box")#linebreak()#text(" Combining ")#link(<tao-7152e6ec048e24fadb10>)[#text("(26)")]#text(", ")#link(<tao-74fcb92c40783781b365>)[#text("(29)")]#text(", and ")#link(<tao-e10c4e14763654ec79be>)[#text("(30)")]#text(" we obtain ")#link(<tao-9d2c65dda8df9efa4769>)[#text("(24)")]#text(" as required.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (54)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/238ee1d9da8ca3ab25eae81d3aa3599068e23fbed8a22a811722fdb0b83a4260-1a9364bf62fba8adbded36a283de2b887c05430a19bd40074afc7d7e23062258.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-451620")[#strong[#text("Anthony")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2015")])]

#text("Under equation (1), should it be ‘setting x = 1’ instead of ‘s = 1’?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-451621")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2015")])]

#text("In the line below (1), it seems that “")#mi("s=1")#text("” should be “")#mi("x=1")#text("“.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/238ee1d9da8ca3ab25eae81d3aa3599068e23fbed8a22a811722fdb0b83a4260-1a9364bf62fba8adbded36a283de2b887c05430a19bd40074afc7d7e23062258.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-451622")[#strong[#text("Anthony")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2015")])]

#text("…although this then gives s/(s-1), not 1/(s-1).")

#emph[#text("[The factor of ")#mi("1")#text(" can be absorbed into the ")#tao-math("O( \\left|s\\right|/\\sigma)", block: false)#text(" error; alternatively, one can take ")#mi("x")#text(" to be slightly less than ")#mi("1")#text(" rather than exactly equal to ")#mi("1")#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/238ee1d9da8ca3ab25eae81d3aa3599068e23fbed8a22a811722fdb0b83a4260-1a9364bf62fba8adbded36a283de2b887c05430a19bd40074afc7d7e23062258.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-451624")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2015")])]

#text("My browser can not parse three formulas: the last line of proof of prop 9, two lines above (21), and two lines before lemma 18.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-451645")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2015")])]

#text("Use “\\colon” instead of “:” for maps. Example: ")#mi("\\eta\\colon\\mathbf{R}\\to\\mathbf{C}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-451653")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2015")])]

#text("In proposition 1, it may be added that ")#mi("\\varepsilon")#text(" is positive.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-451659")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2015")])]

#text("In the line above proposition 1, it should be exercise 33 (instead of exercise 34).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-451667")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2015")])]

#text("In proposition 1, is the implied constant of “")#mi("\\ll t")#text("” (under the supremum) independent of ")#mi("\\varepsilon")#text(" ?")

#emph[#text("[Yes – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-451677")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2015")])]

#text("In the line below (3), it should be “derivative of ")#mi("f")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-451692")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2015")])]

#text("It seems that in proposition 5, the constant ")#mi("100")#text(" can be replaced by any constant ")#mi("> 1")#text(".")

#emph[#text("[Fair enough; I had thought there was possibly a factor of ")#mi("2\\pi")#text(" to take care of, but there isn’t, so I switched the constant to 2 instead. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd83df368f5a465e4458f676823fe63af18caa3828a7c8d866400b549db7ea66-50338db75eee8858da9108c36b9554c86942eff17d4d12f7588cd08b81d90776.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-451721")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2015")])]

#text("I would like to know why the assumptions 3 are reasonable. Proposition 1 seems to say that very far away from the real axis, you can ignore the first ")#tao-math("C\\left|t\\right|", block: false)#text(" terms, and the zeta function is not more oscillatory than the thing you have written down.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd83df368f5a465e4458f676823fe63af18caa3828a7c8d866400b549db7ea66-50338db75eee8858da9108c36b9554c86942eff17d4d12f7588cd08b81d90776.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-451723")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2015")])]

#text("Yeah I am definitely not sure. ")#mi("f \\approx t \\log n")#text(" and yet “")#mi("f")#text(" is a polynomial of degree roughly ")#mi("k")#text("“")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-451727")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2015")])]

#text("The intuition here is that analytic functions behave like polynomials (a similar philosophy was adopted in ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")]#text(" ), particularly if the radius of convergence is larger than the interval on which one is trying to exploit polynomial-type behaviour. In the case of the function ")#mi("x \\mapsto t \\log x")#text(" for ")#mi("x \\approx N")#text(", the radius of convergence is about ")#mi("N")#text(", which is reflected in the increasing powers of N in the denominator of (3). In particular, the error term in a k-term Taylor expansion is about ")#mi("T / N^{k+1}")#text(", which can be significantly less than 1 if ")#mi("N")#text(" is not too small compared with ")#mi("T")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trevor Wooley")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-451753")[#strong[#text("Trevor Wooley")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2015")])]

#text("Great to see Vinogradov’s methods poularised!")

#text("Just a comment that one can make a case now for saying that the main conjecture in Vinogradov’s mean value theorem (your equation (20)) has nearly been proved. By using the multigrade enhancement of my efficient congruencing method, one obtains the main conjecture in the cubic case ")#mi("k=3")#text(" in full, as well as for arbitrary ")#mi("k")#text(" when ")#mi("1\\le l\\le k(k+1)/2-k/3+o(k)")#text(" (and also when ")#mi("l\\ge k(k-1)")#text("). Of course, if one proves (20) for ")#mi("l=k(k+1)/2")#text(", then it follows for all ")#mi("l")#text(", so in a sense we are only ")#mi("k/3")#text(" variables (out of ")#mi("k(k+1)/2")#text(") away from finishing off the conjecture. [There’s an account of this kind of thing in ")#link("http://arxiv.org/pdf/1404.3508v1.pdf")[#text("http://arxiv.org/pdf/1404.3508v1.pdf")]#text(" ]")

#emph[#text("[Reference added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-451793")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2015")])]

#text("It seems that it took more than 20 years to discover the application of Vinogradov mean value theorem (from 1935) to his estimate (theorem 2(ii)).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 6: Large values of Dirichlet polynomials, zero density estimates, and primes in short intervals | What's new")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-451884")[#strong[#text("254A, Notes 6: Large values of Dirichlet polynomials, zero density estimates, and primes in short intervals | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2015")])]

#text("[…] the previous set of notes, we studied upper bounds on sums such as for that were valid for all in a given range, such as ; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-451915")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2015")])]

#text("In exercise 4, it seems that (in order to use proposition 1), the condition ")#mi("\\sigma \\geq \\varepsilon >0")#text(" is also needed.")

#emph[#text("[Fair enough -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21142316488f0c7afddbb243e6a509ef1d1642628a9f5ef6996b764dee5af841-4eed840c674617f4da6095ab1017156c47a2143cc2d663552e30ae8b9c3aa22c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alastair Irving")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-452062")[#strong[#text("Alastair Irving")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2015")])]

#text("I’m slightly confused. IN the Vinogradov estimate theorem 2(ii) you gain by ")#mi("N^{ck^{-2}}")#text(" over the trivial bound (the same as in Iwaniec-Kowalski). However, many papers which consider estimating Weyl sums using the Vinogradov method only gain by ")#mi("N^{\\frac{c}{k^2\\log k}}")#text(". I understood that one of the consequences of Wooley’s efficient congruencing method is that the ")#mi("\\log k")#text(" can be removed. Please can someone explain what I’m missing, in particular why there is no ")#mi("\\log k")#text(" in the above theorem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-452063")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2015")])]

#text("I believe the results you are referring to are for a slightly different exponential sum, namely sums of the form ")#mi("\\sum_{n \\in I} e(P(n))")#text(" where ")#mi("P")#text(" is a polynomial of degree k. The sums here are a little different: ")#mi("\\sum_{n \\in I} e(f(n))")#text(" where ")#mi("f")#text(" is a smooth function (not a polynomial) which obeys the derivative bound (3) for some ")#mi("T \\sim N^k")#text(". In particular the parameter “k” is slightly different in the two contexts. (Both results use Vinogradov’s mean value theorem, but in slightly different ways; in the situation considered in this post, the error exponent ")#mi("O( k^2 \\exp( - \\ell/k^2) )")#text(" in the mean value theorem only needs to be less than a small multiple of ")#mi("k^2")#text(", so one can take ")#mi("\\ell")#text(" to be a large multiple of ")#mi("k^2")#text(", but when dealing with the polynomial sums it seems that the usual methods need this error exponent to be much smaller, like ")#mi("O(1)")#text(", leading to ")#mi("\\ell")#text(" being chosen as large as ")#mi("k^2 \\log k")#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 7: Normalised limit profiles of the log-magnitude of the Riemann zeta function (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-452618")[#strong[#text("254A, Supplement 7: Normalised limit profiles of the log-magnitude of the Riemann zeta function (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2015")])]

#text("[…] limit profiles are known unconditionally, beyond (i)-(iv). For instance, from Exercise 3 of Notes 5 we have as , which implies that any normalised limit profile for is bounded by on the critical […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-452764")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2015")])]

#text("Is it possible to generalize the bilinear estimate (10) to trilinear (or even multilinear) estimates ?")#linebreak()#text(" If so, can Vinogradov estimate (6) be improved ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-452766")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2015")])]

#text("This is theoretically possible, however in practice we have far fewer efficient techniques for dealing with trilinear or higher estimates than for bilinear ones. For instance, bilinear estimates can often be recast as operator norm estimates for a linear operator, for which one can hope to use spectral theory methods to help analyse (e.g. the identity ")#tao-math("\\left\\| T \\right\\|_{op} = \\left\\| (T^* T)^k \\right\\|_{op}^{1/2k}", block: false)#text(" for any natural number ")#mi("k")#text("). Trilinear estimates correspond to bilinear operators, for which we do not have spectral theory methods at our disposal.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-463426")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2015")])]

#text("Is the new decoupling method (used in the proof of Vinogradov main conjecture) seems to have the potential to prove such trilinear (or even higher) estimates?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-463430")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2015")])]

#text("This is potentially possible, and certainly worth exploring. Certainly the Bourgain-Demeter-Guth method relies heavily on multilinear estimates (though not exactly of the type under discussion here).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-453602")[#strong[#text("254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2015")])]

#text("[…] not be discussed further here, save to note that the Vinogradov mean value theorem (Theorem 13 from Notes 5) and its variants are particularly useful for getting good bounds on ; see for instance the ICM […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Erdos discrepancy problem via the Elliott conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-459081")[#strong[#text("The Erdos discrepancy problem via the Elliott conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2015")])]

#text("[…] from the Vinogradov-Korobov zero-free region for (see this previous blog post) it is not difficult to show […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-459992")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2015")])]

#text("Dear Terry,")

#text("The exponent in Exercise 3(ii) is off (obviously a typo).")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-460051")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("The error is still there.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-460054")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("The min-exponent ")#mi("\\min( \\frac{1-\\sigma}{3}, \\frac{1}{2}-\\frac{\\sigma}{3})")#text(" was corrected to a max. Was there another error you were referring to?")

#emph[#text("[Edit: see it now, the second ")#mi("\\sigma")#text(" should be ")#mi("2\\sigma")#text(". -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-463305")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2015")])]

#text("News flash: the Vinogradov main conjecture (estimate (20) in the blog post) has now been proven by Bourgain, Demeter, and Guth, using (a modification of) the decoupling restriction theorem of Bourgain and Demeter! ")#link("http://arxiv.org/abs/1512.01565")[#text("http://arxiv.org/abs/1512.01565")]#text(" Presumably this will impact the best known bounds on the zeta function and the Waring problem, though I don’t know the precise implications in this regard.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-463312")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2015")])]

#text("Is it possible that this has the potential to improve the current (Vinogradov-Korobov) exponent ")#mi("3/5")#text(" in the PNT error term ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-463313")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2015")])]

#text("My initial understanding is that one may need to know how the implied constant in (20) depends on k and epsilon (and maybe also l) in order to get such an improvement. For instance to my knowledge the deep recent results of Wooley have not led to any improvement on Vinogradov-Korobov, in part due to the poor dependence of constants in this regard. But it is plausible that some breakthrough in this direction is now close at hand.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-463541")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2015")])]

#text("In the proof that theorem 11 implies theorem 2(ii), in the sixth line above (12), it is assumed (inside parentheses) that “")#mi("k")#text(" is large” but this assumption is not(!) part of theorem 2(ii) (which allows any natural ")#mi("k")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-463550")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2015")])]

#text("One can use the van der Corput estimates to assume that k is large (see the first paragraph of Section 2).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-463572")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2015")])]

#text("Thanks! (In fact, it seems by first proving (6) for ")#mi("k \\ge k_0")#text(" where ")#mi("k_0")#text(" is sufficiently large, that for the bounded case ")#mi("k \\leq k_0")#text(", (6) follows with some smaller ")#mi("c")#text(" – as the condition ")#mi("T  \\leq N^{k_0}")#text(" is implied by ")#mi("T \\leq N^k")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-463622")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2015")])]

#text("It seems that ")#mi("S")#text(" (defined below (12)) is (in general) a complex number, hence in all the inequalities (below (13)) involving powers of ")#mi("S")#text(" (which are also complex), ")#mi("S")#text(" should be replaced by ")#tao-math("\\left|S\\right|", block: false)#text(".")#linebreak()#text(" (or alternatively, ")#mi("S")#text(" should be defined as the absolute value of the LHS of (10)).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-463803")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2015")])]

#text("It seems that the first and second lines in the RHS of the estimate above (14) are due to bounding ")#tao-math("\\left|\\left|\\nu\\right|\\right|_p", block: false)#text(" with ")#mi("p = 2 l/(2 l -1)")#text(" (due to Holder inequality) by the Riesz-Thorin interpolation bound between ")#mi("L_1")#text(" and ")#mi("L_2")#text(" (in terms of ")#tao-math("\\left|\\left|\\nu\\right|\\right|_1, \\left|\\left|\\nu\\right|\\right|_2", block: false)#text(").")#linebreak()#text(" (i.e. it seems that not only Holder inequality is used in this estimate.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-463806")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2015")])]

#text("I made a mistake (there are no operator norms here), it seems that a generalization of Holder inequality (interpolation between norms) is used.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-463979")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2015")])]

#text("The needed norm interpolation is Littlewood’s inequality (see e.g. in the interpolation section in the Wikipedia article on Holder’s inequality) applied to ")#tao-math("\\left|\\left| \\nu \\right|\\right|_p", block: false)#text(" with ")#mi("p = 2 l / (2 l -1)")#text(" and ")#mi("p_0 =1, p_1 =2")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-464150")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2015")])]

#text("In the third line above (18), ")#mi("J")#text(" should be ")#mi("J_{l, k}(M)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-464288")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2015")])]

#text("It seems that the coefficients ")#mi("c_a")#text(" in (16) are not used in the transition to (18). Hence (for simplicity) they can be eliminated before(16).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-464289")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2015")])]

#text("In fact, it is not clear if these coefficients can be eliminated before (16).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-464374")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2015")])]

#text("It is interesting to observe that the summations in (14)-(15) are not necessarily restricted to the box ")#mi("B")#text(" (because ")#mi("\\nu")#text(" is supported in this box) – this fact is actually used in the application of C-S inequality to get (18).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-464398")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2015")])]

#text("In the proof of lemma 12, it seems clearer to remark that the inequality in the line above “and hence” is valid for the above chosen subset of indices ")#mi("j")#text(" that satisfy (9).")

#emph[#text("[Clarification added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-464400")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2015")])]

#text("In the proof of lemma 12, it is assumed (in the last two lines) that ")#mi("M \\geq \\exp(C k^2)")#text(" for some large ")#mi("C")#text(". But this assumption is not(!) present in the statement of lemma 12.")

#emph[#text("[This bound comes from the ambient hypothesis (12). -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da87e6971d472723c5320e567915782b17a0a6f3a7b77d257bf00bc0df3d93a7-2d9ebf36b3b42665bb549f067b7e88557c0cb0b1ecbc1c8609a55b4f000307f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Claudeh5")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-479417")[#strong[#text("Claudeh5")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2017")])]

#text("Hello professor Tao,")

#text("In “Vinogradov estimate” the first equation (which is on 3 lines) has a small error in the line 3: a square is lost in the integral : |f”(t)/|f'(t)|^2")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-502486")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2018")])]

#text("Dear Prof. Tao,")

#text("I’m confused with the last two sentences of the proof of Prop. 6. The size may be $O(AN/T)$? And the bound in Prop. 6 seems too strong comparing with Cor. 8.13 in Iwaniec–Kowalski’s book. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/796d37e717e39a294e210896f1d88b57d3562bd27ca3d91be080b86f4ac18739-ec5ac211e2f6573a146659dc6ce3f862c45cbf3c07d5e909e6ca5c76f41fb214.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sungjin Kim")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-516956")[#strong[#text("Sungjin Kim")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2019")])]

#text("Dear Professor Tao,")

#text("In the Exercise 5 (iii), shouldn’t there be ")#mi("x/\\phi(q)")#text(" on the right side, not ")#mi("x")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A announcement: Analytic prime number theory | What's new")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-521317")[#strong[#text("254A announcement: Analytic prime number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2019")])]

#text("[…] Bounds for exponential sums […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-681945")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2023")])]

#text("In the second displayed equation after Prop 1, ")#mi("\\ll_\\epsilon")#text(" should be just ")#mi("\\ll")#text(".")

#emph[#text("[The epsilon dependence is needed to absorb the ")#mi("O_\\varepsilon(1)")#text(" term from the previous display. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-681949")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2023")])]

#text("Yes — I missed the condition ")#mi("\\sigma>\\epsilon")#text(" which creates the ")#mi("\\epsilon")#text("-dependence.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-682853")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2024")])]

#text("Dear Terry, you said that pseudorandomness heuristics predict a bound for (2) (which, in particular , implies the Lindelof hypothesis) under the assumption (3) and, if I understand well, also under some more general assumptions. Could you please tell me where I could read more about that and how can one generalize (3) and still expect the bound O(N^{-1/2+epsilon}) to hold? Thank you very much!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-688306")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2025")])]

#text("Again, many years late, but there seems to be a typo here (as in, an error with no further consequence because you were obviously thinking of the right thing and that’s the one you used in the argument):")

#text("“From the")

#link("https://s0.wp.com/latex.php?latex=%7Bj%3D1%2C2%7D&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%7Bj%3D1%2C2%7D&bg=ffffff&fg=000000&s=0&c=20201002")]

#text("cases of ")#link(<tao-3f744134baea564fc3a2>)[#text("(3)")]#text(" and the mean value theorem we see that")

#link("https://s0.wp.com/latex.php?latex=%7Bx+%5Cmapsto+%5Cfrac%7B1%7D%7Be%28f%28x%2B1%29-f%28x%29%29-1%7D%7D&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%7Bx+%5Cmapsto+%5Cfrac%7B1%7D%7Be%28f%28x%2B1%29-f%28x%29%29-1%7D%7D&bg=ffffff&fg=000000&s=0&c=20201002")]

#text("has size")

#link("https://s0.wp.com/latex.php?latex=%7BO%28AT%2FN%29%7D&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%7BO%28AT%2FN%29%7D&bg=ffffff&fg=000000&s=0&c=20201002")]

#text("and derivative")

#link("https://s0.wp.com/latex.php?latex=%7BO%28A%5E3T%2FN%5E2%29%7D&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%7BO%28A%5E3T%2FN%5E2%29%7D&bg=ffffff&fg=000000&s=0&c=20201002")]

#text("…”")

#text("You actually want (and get) O(AN/T) and O(A^3/T). For the former, you don’t need to give a reference, since you’ve just shown the statement.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01f4aab37f5da8b88efe9a69375e749c8d82a87d1e8497b9f847b0444131dc6f-291cbde920906f021dda61657ad7eda40146843270dbe4dd19f991cd0f78bf52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Hayes")]], [#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/#comment-695038")[#strong[#text("Tom Hayes")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I’d like to know whether formal verifications of any of these theorems exist, particularly Theorem 2(ii). Ideally, I’d like a pointer to some Lean code. Please let me know if you have any leads on this!")
]
