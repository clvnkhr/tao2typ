// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/
// Converted to Typst by tao2typ: "2026-10-14T10:28:39.343526+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Chains of large gaps between primes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Chains of large gaps between primes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 November 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/")[#text("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.uiuc.edu/~ford/")[#text("Kevin Ford")]#text(", ")#link("https://en.wikipedia.org/wiki/James_Maynard_(mathematician)")[#text("James Maynard")]#text(", and I have uploaded to the arXiv our preprint “")#link("http://arxiv.org/abs/1511.04468")[#text("Chains of large gaps between primes")]#text("“. This paper was announced in our ")#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/")[#text("previous paper with Konyagin and Green")]#text(", which was concerned with the largest gap")

#align(center)[#tao-fit-display[#mitex("G_1(X) := \\max_{p_n, p_{n+1} \\leq X} (p_{n+1} - p_n)")]]

#text("between consecutive primes up to ")#mi("{X}")#text(", in which we improved the Rankin bound of")

#align(center)[#tao-fit-display[#mitex("G_1(X) \\gg \\log X \\frac{\\log_2 X \\log_4 X}{(\\log_3 X)^2}")]]

#text("to")

#align(center)[#tao-fit-display[#mitex("G_1(X) \\gg \\log X \\frac{\\log_2 X \\log_4 X}{\\log_3 X}")]]

#text("for large ")#mi("{X}")#text(" (where we use the abbreviations ")#mi("{\\log_2 X := \\log\\log X}")#text(", ")#mi("{\\log_3 X := \\log\\log\\log X}")#text(", and ")#mi("{\\log_4 X := \\log\\log\\log\\log X}")#text("). Here, we obtain an analogous result for the quantity")

#align(center)[#tao-fit-display[#mitex("G_k(X) := \\max_{p_n, \\dots, p_{n+k} \\leq X} \\min( p_{n+1} - p_n, p_{n+2}-p_{n+1}, \\dots, p_{n+k} - p_{n+k-1} )")]]

#text("which measures how far apart the gaps between chains of ")#mi("{k}")#text(" consecutive primes can be. Our main result is")

#align(center)[#tao-fit-display[#mitex("G_k(X) \\gg \\frac{1}{k^2} \\log X \\frac{\\log_2 X \\log_4 X}{\\log_3 X}")]]

#text("whenever ")#mi("{X}")#text(" is sufficiently large depending on ")#mi("{k}")#text(", with the implied constant here absolute (and effective). The factor of ")#mi("{1/k^2}")#text(" is inherent to the method, and related to the basic probabilistic fact that if one selects ")#mi("{k}")#text(" numbers at random from the unit interval ")#mi("{[0,1]}")#text(", then one expects the minimum gap between adjacent numbers to be about ")#mi("{1/k^2}")#text(" (i.e. smaller than the mean spacing of ")#mi("{1/k}")#text(" by an additional factor of ")#mi("{1/k}")#text(").")

#text("Our arguments combine those from the previous paper with the ")#link("https://en.wikipedia.org/wiki/Maier%27s_matrix_method")[#text("matrix method")]#text(" of Maier, who (in our notation) ")#link("http://www.ams.org/mathscinet-getitem?mr=614163")[#text("showed that")]

#align(center)[#tao-fit-display[#mitex("G_k(X) \\gg_k  \\log X \\frac{\\log_2 X \\log_4 X}{(\\log_3 X)^2}")]]

#text("for an infinite sequence of ")#mi("{X}")#text(" going to infinity. (Maier needed to restrict to an infinite sequence to avoid Siegel zeroes, but we are able to resolve this issue by the now standard technique of simply eliminating a prime factor of an exceptional conductor from the sieve-theoretic portion of the argument. As a byproduct, this also makes all of the estimates in our paper effective.)")

#text("As its name suggests, the Maier matrix method is usually presented by imagining a matrix of numbers, and using information about the distribution of primes in the columns of this matrix to deduce information about the primes in at least one of the rows of the matrix. We found it convenient to interpret this method in an equivalent probabilistic form as follows. Suppose one wants to find an interval ")#mi("{n+1,\\dots,n+y}")#text(" which contained a block of at least ")#mi("{k}")#text(" primes, each separated from each other by at least ")#mi("{g}")#text(" (ultimately, ")#mi("{y}")#text(" will be something like ")#mi("{\\log X \\frac{\\log_2 X \\log_4 X}{\\log_3 X}}")#text(" and ")#mi("{g}")#text(" something like ")#mi("{y/k^2}")#text("). One can do this by the probabilistic method: pick ")#mi("{n}")#text(" to be a random large natural number ")#mi("{{\\mathbf n}}")#text(" (with the precise distribution to be chosen later), and try to lower bound the probability that the interval ")#mi("{{\\mathbf n}+1,\\dots,{\\mathbf n}+y}")#text(" contains at least ")#mi("{k}")#text(" primes, no two of which are within ")#mi("{g}")#text(" of each other.")

#text("By carefully choosing the residue class of ")#mi("{{\\mathbf n}}")#text(" with respect to small primes, one can eliminate several of the ")#mi("{{\\mathbf n}+j}")#text(" from consideration of being prime immediately. For instance, if ")#mi("{{\\mathbf n}}")#text(" is chosen to be large and even, then the ")#mi("{{\\mathbf n}+j}")#text(" with ")#mi("{j}")#text(" even have no chance of being prime and can thus be eliminated; similarly if ")#mi("{{\\mathbf n}}")#text(" is large and odd, then ")#mi("{{\\mathbf n}+j}")#text(" cannot be prime for any odd ")#mi("{j}")#text(". Using the methods of our previous paper, we can find a residue class ")#mi("{m \\text{ mod } P}")#text(" (where ")#mi("{P}")#text(" is a product of a large number of primes) such that, if one chooses ")#mi("{{\\mathbf n}}")#text(" to be a large random element of ")#mi("{m \\text{ mod } P}")#text(" (that is, ")#mi("{{\\mathbf n} = {\\mathbf z} P + m}")#text(" for some large random integer ")#mi("{{\\mathbf z}}")#text("), then the set ")#mi("{{\\mathcal T}}")#text(" of shifts ")#mi("{j \\in \\{1,\\dots,y\\}}")#text(" for which ")#mi("{{\\mathbf n}+j}")#text(" still has a chance of being prime has size comparable to something like ")#mi("{k \\log X / \\log_2 X}")#text("; furthermore this set ")#mi("{{\\mathcal T}}")#text(" is fairly well distributed in ")#mi("{\\{1,\\dots,y\\}}")#text(" in the sense that it does not concentrate too strongly in any short subinterval of ")#mi("{\\{1,\\dots,y\\}}")#text(". The main new difficulty, not present in the previous paper, is to get ")#emph[#text("lower")]#text(" bounds on the size of ")#mi("{{\\mathcal T}}")#text(" in addition to upper bounds, but this turns out to be achievable by a suitable modification of the arguments.")

#text("Using a version of the prime number theorem in arithmetic progressions ")#link("http://www.ams.org/mathscinet-getitem?mr=279049")[#text("due to Gallagher")]#text(", one can show that for each remaining shift ")#mi("{j \\in {\\mathcal T}}")#text(", ")#mi("{{\\mathbf n}+j}")#text(" is going to be prime with probability comparable to ")#mi("{\\log_2 X / \\log X}")#text(", so one expects about ")#mi("{k}")#text(" primes in the set ")#mi("{\\{{\\mathbf n} + j: j \\in {\\mathcal T}\\}}")#text(". An upper bound sieve (e.g. the Selberg sieve) also shows that for any distinct ")#mi("{j,j^{\\prime} \\in {\\mathcal T}}")#text(", the probability that ")#mi("{{\\mathbf n}+j}")#text(" and ")#mi("{{\\mathbf n}+j^{\\prime}}")#text(" are both prime is ")#mi("{O( (\\log_2 X / \\log X)^2 )}")#text(". Using this and some routine second moment calculations, one can then show that with large probability, the set ")#mi("{\\{{\\mathbf n} + j: j \\in {\\mathcal T}\\}}")#text(" will indeed contain about ")#mi("{k}")#text(" primes, no two of which are closer than ")#mi("{g}")#text(" to each other; with no other numbers in this interval being prime, this gives a lower bound on ")#mi("{G_k(X)}")#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (32)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-461965")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2015")])]

#text("Typo, I think: “inherent for your method”")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-461972")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2015")])]

#text("This typo is in the second line below the main result.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9d6c587f0179a9e9cd79521e2b6e113d0cb1f812e0a24e3149da324234575b5-b393abd8e95f8ff6c0382edd82d629c7d085349005e0c6c3c8751e025646bf26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-461966")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2015")])]

#text("Typos in the last paragraph: some ")#mi("{\\bf n}")#text("s are slashes.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-461970")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2015")])]

#text("In the definition of ")#mi("G_1(X)")#text(", it seems clearer to have ")#mi("p_{n+1} -p_n")#text(" inside parentheses.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-461971")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2015")])]

#text("Can the “sufficiently large” dependence of ")#mi("X")#text(" on ")#mi("k")#text(" be made effective?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-461982")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2015")])]

#text("Yes; we do not rely on ineffective results such as Siegel’s theorem, so all of the assertions in our paper can be made effective (though the lower bound required on ")#mi("X")#text(" is likely to be quite poor, as we did not try to optimise in this direction).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MatjazG")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-461976")[#strong[#text("MatjazG")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2015")])]

#text("A typo in the 3rd paragraph from the bottom up: ")#mi("{\\log X \\frac{\\log_2 X \\log_4 X}{(\\log 3 X)^2}}")#text(" should probably be ")#mi("{\\log X \\frac{\\log_2 X \\log_4 X}{(\\log_3 X)^2}}")#text(" (or even ")#mi("{\\log X \\frac{\\log_2 X \\log_4 X}{\\log_3 X}}")#text(" ?).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-461978")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2015")])]

#text("In the line before the last, it seems that “")#mi("k")#text(" primes” should be “")#mi("k")#text(" consecutive primes”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-462011")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2015")])]

#text("Is it possible (using the above methods) to show (unconditionally) that")#linebreak()#text(" ")#mi("G_k(X) \\gg k^{-2} G_1(X)")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-462025")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2015")])]

#text("I doubt it, because we only control a tiny contribution to ")#mi("G_1(X)")#text(", roughly speaking we only understand those large prime gaps with the property that all the composite numbers within the gap are divisible by small primes. There could be much larger prime gaps (e.g. of the order of the Cramer prediction ")#mi("\\log^2 X")#text(") that are not analysed at all by known methods, and in that case we have essentially no relationship between ")#mi("G_k(X)")#text(" and ")#mi("G_1(X)")#text(" other than the trivial bound ")#mi("G_k(X) \\leq G_1(X)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-462034")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2015")])]

#text("I see. But is it still possible that the transition from a lower bound on ")#mi("G_1(X)")#text(" to a lower bound on ")#mi("G_k(X)")#text(" (via the ")#mi("k^{-2}")#text(" factor may be done by current methods even for “slightly better” lower bounds on ")#mi("G_1(X)")#text(" than currently known?")#linebreak()#text(" (i.e. Is the transition from a lower bound for ")#mi("G_1(X)")#text(" to a lower bound for ")#mi("G_k(X)")#text(" via the ")#mi("k^{-2}")#text(" factor is independent(!) of the exact lower bound on ")#mi("G_1(X)")#text(" as long as it is “sufficiently small”?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-462082")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2015")])]

#text("More precisely, what is the limitation on the growth rate of a function ")#mi("f(X)")#text(" such that ")#mi("G_1(X) \\gg f(X)")#text(" still implies (using current methods) that ")#mi("G_k(X) \\gg k^{-2} f(X)")#text(" ?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-462086")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2015")])]

#text("As I said earlier, there is no direct relationship beyond the trivial inequality; the lower bound on G_1 is not directly used in the arguments establishing a lower bound on G_k. Any new lower bound on G_1 beyond what we currently know could be due to the presence of sporadic large prime gaps that are not adjacent to each other, and so do not serve to increase G_k from beyond the bounds currently available while making G_1 bigger. We have no tool currently to understand these sporadic large gaps, so this new information about G_1 has no direct bearing on G_k. (But it is likely that any new ")#emph[#text("method")]#text(" that is capable of improving the bounds on G_1 will also, after some nontrivial modification, also improve the bounds on G_k, but one actually has to use the method of proof and not simply take the bound on G_1 as a “black box”.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f449649ee72aacb2a1bebb13b00532f0d6edf19f93054a8f037494fefc9365f-e6eabfd6cf52e8405b36520df83897941bd673491e3a3b4800c445f3f22b1b7b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lionel")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-462018")[#strong[#text("Lionel")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2015")])]

#text("Dear Terry, I have just noticed the French flag on the banner. As a Parisian, I am touched by this discreet display of sympathy. I have been reading your blog with great interest for quite a while. Not being a mathematician but with a background on the subject, I would like to praise the way your provide the flavour of the results and the issues at stake. I cannot follow all the developments but I dream about them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-462124")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2015")])]

#text("Professor Tao.")

#text("I guess you already know that: all prime number is in the interval.")

#mi("(30a + (p))")#text(" and ")#mi("(42a +(p_{1}).")#text("latex p = (11,17,23,29) $")

#mi("p_{1}= (13,19,31,37,43)")

#text("as is obvious twin primes are included. But if we want to know only yhe twin primes, the these are defined.")

#mi("\\left[\\frac{5 + 6[7a+(1;2;3;4;5;6)]}{(3;5;7)}\\neq Z \\right] = p_{n}")

#mi("\\left[\\frac{5 + 6[7a+(1;2;3;4;5;6)] + 2}{(3;5;7)}\\neq Z \\right] = p_{n+2}")

#text("when the mathematicians look for something that is already defined, has no sense.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-462184")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2015")])]

#text("Dear Terry and every one,I’m Dr.Tao’s blog’s fan.Maybe I’m the oddest and craziest man in the world.Because I have crazy remark about Terry that related to Riemann problem.Terry never present the result of Riemann unless someone annouce to prove Riemann.But Terry will do a thing(very surprised,very interesting,very quick).He will do a hattrick(Rie-Gold-Twin)at the same time.I predict many things very exactly,from football,economy,rainy, sun to math.Trust me.Please do not vote against.All you never do level to understand anymore")

#text("breakthrough(Riemann,Goldbach,Twin p")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-462217")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2015")])]

#text("I think there is a typo in Maier’s previous result; at least I have no idea what the notation \\gg_k is supposed to mean.")

#text("[")#mi("X \\gg_k Y")#text(" denotes an estimate of the form ")#mi("X \\geq c_k Y")#text(" for some ")#mi("c_k > 0")#text(" that depends only on ")#mi("k")#text(". -T.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-463016")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2015")])]

#text("Is it possible (using current methods) to extend this lower bound for ")#mi("G_k(X)")#text(" to the case where ")#mi("k = k(X)")#text(" is a sufficiently slowly increasing and unbounded function of ")#mi("X")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-463036")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2015")])]

#text("If one is willing to lose a factor of ")#mi("1/k^2")#text(" on the RHS, then our techniques would extend to some sufficiently slowly growing function of ")#mi("k")#text(" (basically because we already demonstrated this for any fixed ")#mi("k")#text(" with ")#mi("X")#text(" sufficiently large depending on ")#mi("k")#text("). But we do not know how to get rid of this ")#mi("1/k^2")#text(" factor (as pointed out in the post, it is related to the fact that given ")#mi("k")#text(" random points in the unit interval, one expects one pair of these to be within about ")#mi("1/k^2")#text(" of each other).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-463065")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2015")])]

#text("Therefore, let (for each fixed ")#mi("k")#text(") ")#mi("X(k)")#text(" be a “sufficiently large” ")#mi("X")#text(" such that for any ")#mi("X \\geq X(k)")#text(" the above lower bound (for ")#mi("G_k(X)")#text(") holds. Clearly, we may assume ")#mi("X(k)")#text(" to be a strictly increasing function of ")#mi("k")#text(", so by taking ")#mi("k = k(X)")#text(" to be the inverse function of ")#mi("X(k)")#text(", the above lower bound for ")#mi("G_k(X)")#text(" holds with ")#mi("k=k(X)")#text(".")#linebreak()#text(" This leads to the question: what is the fastest growth of the function ")#mi("k(X)")#text(" (i.e. the slowest growth of its inverse function ")#mi("X(k)")#text(") available by the current methods?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-463076")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2015")])]

#text("Of course, by taking ")#mi("k(X)")#text(" growing sufficiently fast (e.g. ")#mi("k(X) \\gg (\\log x)^{1/2}")#text("), the resulting lower bound for ")#mi("G_{k(X)}(X)")#text(" can (due to the ")#mi("1/k^2")#text(" factor) be made trivial (e.g. ")#mi("o(1)")#text(", so the above question for the fastest growth of ")#mi("k(X)")#text(" seems interesting only under the additional constraint that the resulting lower bound for ")#mi("G_{k(X)}(X)")#text(" grows no slower than a given increasing unbounded function of ")#mi("X")#text(" (e.g. the Rankin bound).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-463096")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2015")])]

#text("I think the methods in the paper might be pushed to take ")#mi("k")#text(" as large as ")#mi("\\log_3^c X")#text(" for a small absolute constant ")#mi("c>0")#text(", though I haven’t fully checked the details. (In fact one may be able to take ")#mi("c")#text(" arbitrarily close to 1 if one is careful enough. Not coincidentally, ")#mi("\\log_3 X")#text(" is the amount by which our arguments improve over the Erdos-Rankin bound.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c52dcf9dd697f11df6277b8df9b3d1decd789f3d2ae805e253f85ecc8e88065e-2970d349b514ae4a17699568f2044361b5757648d375f06c0df286e650e1546c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of epsilon")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-465223")[#strong[#text("epsilon")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2016")])]

#text("Hello Prof. Tao,")

#text("With the prime number theorem intrinsically tied to the Riemann Hypothesis, what impact to RH would occur if the existence of primes were finite? Would that be possible?")

#text("Assuming RH to be false, what would this imply for prime numbers and their existence?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-484761")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2017")])]

#text("Hello math enthusiast")#linebreak()#text(" Can anyone try to provide a proof for or against the following statement")#linebreak()#text(" “For any subset {1,..,x} of the integer set, if x is even , then the number of prime numbers in the subset {1,..,x} is 1/2x and if x is odd, then the number of prime number numbers in the subset {1,..,x} is 1/2x + 1/2”")

#text("please help an amateur from africa")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-484764")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2017")])]

#text("sorry the claim was false i found the disproof for x = 9")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f24e81e07bb8124bd680d968c93de4368230dba6cac485de2901c49a3c094c69-9490651a2f749e3bc3e386a1210dd1a927ab31a7e913082b7713aff1e9d72d11.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-485793")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2017")])]

#text("Good day. The weakened hypothesis of Grimm’s states ")#mi("\\omega (\\prod_{x< n\\leq x+k}n)\\geq k")#text(". The trivial upper bound for ")#mi("\\omega")#text(" gives a relatively good boundary.")#linebreak()#text(" You can rewrite ")#mi("\\omega (\\prod_{x< n\\leq x+k}n)")#text(" as ")#mi("\\sum_{p\\leq x}f\\left (\\left \\lfloor \\frac{x+k}{p} \\right \\rfloor-\\left \\lfloor \\frac{x}{p} \\right \\rfloor  \\right ) + O(\\frac{\\log x}{\\log \\log x})")#text(",")#linebreak()#text(" where ")#mi("f")#text(" – characteristic function; ")#mi("f(x)-\\begin{cases} 1 & \\text{ if } x\\geq 1 \\\\  0 & \\text{ otherwise } \\end{cases}")

#text("Can this expression be promising?")

#text("On the other hand i used ")#mi("\\sum_{x< n\\leq x+k}\\sum_{p|n; \\pi (k)\\leq p}1 + O(\\pi (k))")#text(" relying on this work ")#link("http://www.iecl.univ-lorraine.fr/~Gerald.Tenenbaum/PUBLIC/PPP/ShortSums.pdf")[#text("http://www.iecl.univ-lorraine.fr/~Gerald.Tenenbaum/PUBLIC/PPP/ShortSums.pdf")]#text(" with no luck")

#text("I will note that by this I try to give an estimate ")#mi("\\omega (\\prod_{x< n\\leq x+k}n)< k")#text(" at least for ")#mi("k=\\frac{x^{1/2}}{\\log^{1/2+\\epsilon }x}")#text(". What would be the improvement of the result obtained by Erdös. ")#link("https://www.renyi.hu/~p_erdos/1971-24.pdf")[#text("https://www.renyi.hu/~p_erdos/1971-24.pdf")]

#text("Unfortunately I did not succeed. Maybe someone will find it useful.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f24e81e07bb8124bd680d968c93de4368230dba6cac485de2901c49a3c094c69-9490651a2f749e3bc3e386a1210dd1a927ab31a7e913082b7713aff1e9d72d11.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-485812")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2017")])]

#mi("\\sum_{p\\leq x}\\left \\lfloor \\frac{x+k}{p} \\right \\rfloor - \\sum_{p\\leq x}\\left \\lfloor \\frac{x}{p} \\right \\rfloor - \\sum_{p\\leq k}\\left \\lfloor \\frac{k}{p} \\right \\rfloor + O(\\pi (k)) + O(\\frac{\\log x}{\\log \\log x})")

#text("It seems that ")#mi("-\\sum_{p\\leq x}\\left \\{ \\frac{x+k}{p} \\right \\} + \\sum_{p\\leq x}\\left \\{ \\frac{x}{p} \\right \\}=O(\\frac{k}{\\log k})")#text(" for ")#mi("x^{1/2-\\epsilon }")#text(".")#linebreak()#text(" Using the method Heat-Brown method, you can reach such a boundary, perhaps , but I do not know how to approach it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f24e81e07bb8124bd680d968c93de4368230dba6cac485de2901c49a3c094c69-9490651a2f749e3bc3e386a1210dd1a927ab31a7e913082b7713aff1e9d72d11.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-485863")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2017")])]

#text("Instead of ")#mi("\\sum_{x< n\\leq x+k}\\sum_{p|n;\\pi (k)\\leq p}1")#text(" should be ")#mi("\\sum_{x< n\\leq x+k}\\sum_{p|n;t_{\\pi (k)}< p}1")#text(", where ")#mi("t_{m}")#text(" – ")#mi("m")#text("-th prime number and ")#mi("\\pi (k)")#text(" – prime-counting function. Sorry for the confusion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/41a5a0b3b7b40f3b3a34d59c1b2741aaa5391bd73354321ca0b2271d0daf6453-3af58e866e713d8735fc731a76486fb160803aa4579677db04dca5fd4e8a96f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Keiju Sono")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-678133")[#strong[#text("Keiju Sono")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2023")])]

#text("Sorry for the question to an old post.")#linebreak()#text(" I am currently reading this paper to obtain some explicit inequality for G_{k}(X), but I can’t understand how the lower bound in (3.10) can be derived. Can this evaluation be obtained from only the lower bound of the order of the expected value of N and the upper bound of the expected value of N^2?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-678157")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2023")])]

#text("Yes. For instance one can use the inequality")

#mi("\\displaystyle {\\bf E} N \\leq \\delta A {\\bf P}(N \\leq \\delta A) + {\\bf E} N 1_{N > \\delta A} \\leq \\delta A + ({\\bf E} N^2)^{1/2} {\\bf P}( N > \\delta A)^{1/2}")

#text("from Cauchy-Schwarz for a suitably small choice of ")#mi("\\delta")#text(" to obtain a lower bound on ")#mi("{\\bf P}( N > \\delta A)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Keiju Sono")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-678196")[#strong[#text("Keiju Sono")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2023")])]

#text("Thank you very much!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/16/chains-of-large-gaps-between-primes/#comment-684713")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2024")])]

#text("Thank you for your previous instructions on how to estimate the probability.")#linebreak()#text("Thanks to your help, I was able to get an explicit lower bound for large gaps between some consecutive primes , and I have summarized it in my paper.")

#link("https://arxiv.org/abs/2404.06951")[#text("https://arxiv.org/abs/2404.06951")]

#text("I would be honored if you would take a moment to read it.")

#text("I don’t have enough ideas yet regarding quantitative improvements, but I’m considering a number of things.")#linebreak()#text("I have generally checked out newly published papers, but would be happy to hear of any developments in this area.")
]
