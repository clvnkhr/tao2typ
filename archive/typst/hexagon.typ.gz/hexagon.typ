// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/06/hexagon/
// Converted to Typst by tao2typ: "2026-10-14T11:21:07.968110+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Hexagon", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Hexagon")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/06/hexagon/")[#text("https://terrytao.wordpress.com/2026/10/06/hexagon/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://antieau.github.io/")[#text("Ben Antieau")]#text(", cross-posted from ")#link("https://antieau.github.io/2026/10/05/hexagon.html")[#text("his blog")]#text(". — T.]")]

#emph[#text("There was no personal problem, no world problem, whose eloquent solution did not exist— somewhere in some hexagon.")]

#text("—Jorge Luis Borges, “The Library of Babel” [1]")

#strong[#text("New repository")]

#text("I am writing to announce ")#link("https://hexagonmath.org")[#text("Hexagon")]#text(", a new repository for research works in the mathematical sciences and theoretical computer science. This has been a joint effort of many people over the last couple of months, starting in early August 2026. We felt that the proliferation of results proved with LLM assistance required a new model for collecting the associated papers. Besides wanting these works to be citable and reliably stored for long periods of time, we wanted to allow lower barriers for authorship and for community interest than the arXiv. We also wanted for these works to have a home besides random GitHub repositories or X/Bluesky/Mathstodon/LinkedIn posts.")

#text("In order to support the development of this project, we founded the Hexagon Mathematics Foundation in the state of Delaware and we intend to apply for recognition of tax-exempt status under section 501(c)(3). The Board of Directors consists of Mohammed Abouzaid, François Charles, Bryna Kra, David Savitt, and Lauren Williams. I serve as the first Executive Director. And, we have a wonderful Advisory Board, where Kevin Buzzard, Akhil Mathew, Johannes Schmitt, Steinn Sigurðsson, Nikhil Srivastava, Ravi Vakil, and Rachel Ward serve. For more details, see our ")#link("https://hexagonmath.org/who")[#text("who we are")]#text(" page.")

#metadata(none) <tao-b7058db15751525435de>

#strong[#text("My personal interest")]

#text("When working with a group of people brought together by an FRG grant, we clicked a button and discovered a new result, namely derived invariance of Hodge numbers of fourfolds in characteristic zero. In the past, this would be a result I would have submitted to an excellent, but not top, journal. In this case, there is no way I would put my name to the result. Instead, I blogged about it ")#link("https://antieau.github.io/2026/07/31/hodge-fourfolds.html")[#text("here")]#text(". This is a brittle way to aggregate mathematics. Now, it is on Hexagon as ")#link("https://hexagonmath.org/2609.00104v1")[#text("hexagon:2609.00104")]#text(".")

#text("The creation of new results happens naturally in working with LLMs. They bubble up, even as side results. My personal hope is that it becomes the community standard to identify these and submit them to Hexagon.")

#strong[#text("The Lifecycle of Hexagon Objects")]

#text("(The title alludes to Ted Chiang’s “The Lifecycle of Software Objects” [2].)")

#text("My ambition is that Hexagon is where mathematical ideas emerge from the water for the first time as they evolve toward community acceptance and understanding. Later, they should be written up in forms suitable for arXiv submission, publication, and canonicalization (Tao [3]).")

#text("Hexagon specifically allows submissions entirely generated by LLMs and even where the submitters claim no human understanding. These results should be available to the general community.")

#strong[#text("Submissions by the big labs")]

#text("Hexagon welcomes submissions by large labs working on language models. These results should be available to the mathematics and TCS communities by default on a platform that the community maintains. We also welcome submissions by large collaborations or other organizations.")

#strong[#text("FAQ")]

#strong[#text("How was Hexagon created?")]#text(" At some point, a group of people convened in early August, brought together by our social networks with the common theme of interest around creating a home for mathematical results which were rapidly being produced with the assistance of LLM tools. This group included most of the current members of the Board and Advisory Board of the Hexagon Mathematics Foundation, as well as several other academic mathematicians who did significant work but preferred not to be named. In August we discussed ideas on a private Zulip channel (thanks ICARM!) as we started building the site itself.")

#text("We talked to a lot of people at that time, including arXiv leadership, and we also examined closely-related AI-era repositories. From the arXiv we learned that they were not going to provide the home for these results we were looking for; instead they are focused on maintaining their project as it is today, and I am happy for that. None of the other repositories had gained sufficient traction or had all of the policies we were hoping for.")

#text("The foundation was incorporated as a nonprofit in Delaware and we intend to apply for recognition of tax-exempt status under section 501(c)(3).")

#text("The entire system was created with the help of OpenAI’s Codex and is hosted on widely available commercial cloud servers. This is rather easy nowadays. What takes time is deciding exactly what features you want and carefully writing the text on the website.")

#strong[#text("How is Hexagon funded?")]#text(" So far, it is entirely funded by the people involved, although we are exploring other funding routes and paths to sustainability. Today, except as customers of cloud infrastructure companies, we have no relationship with any for-profit company or other organization.")

#strong[#text("Why Hexagon?")]#text(" At some point, the group started talking about names involving Babel, which refers to Borges’s story ")#emph[#text("The Library of Babel")]#text(" [1]. But, because it has other connotations as well, we did not go that route. Instead, someone suggested ")#emph[#text("Hexagon")]#text(" in reference to the shape of the halls in Borges’s library.")

#strong[#text("Does Hexagon accept micro-results?")]#text(" Hexagon welcomes small, incremental improvements as long as they are of interest to the mathematics and TCS communities.")

#strong[#text("Is formalization required for a Hexagon submission?")]#text(" No, Hexagon is not primarily a formalization project, but it links to formalization projects, like mathlib, Palomar, prove2.me, and TauCeti.")

#strong[#text("What is the difference between a contributor and a submitter?")]#text(" On Hexagon, Contributors are humans or organizations responsible for the creation of submissions. Submitters are humans with ORCID-validated accounts on Hexagon. In some instances, Hexagon will provide individual account holders the capability to submit on behalf of other humans or organizations.")

#strong[#text("Are there rate limits?")]#text(" Yes, Hexagon limits the rate at which one can submit. It starts at 1/day, and grows at Hexagon’s discretion. This growth is based on previous submissions passing through moderation. (The arXiv recently announced its own repository-wide submission limits [4].)")

#strong[#text("Is there API access?")]#text(" Yes, Hexagon provides both read-access via API (in the style of the arXiv) and submit-access via API tokens available from users’ account pages.")

#strong[#text("Why is Hexagon marked as being in beta?")]#text(" We are still adding features and testing scalability. We welcome any recommendations for how the site can be made more usable.")

#strong[#text("References")]

#text("[1] Jorge Luis Borges, “The Library of Babel,” translated by Andrew Hurley, in ")#emph[#text("Collected Fictions")]#text(", Penguin Books, 1999, ")#link("https://www.penguinrandomhouse.com/books/330909/collected-fictions-by-jorge-luis-borges-translated-by-andrew-hurley/")[#text("publisher page")]#text(".")

#text("[2] Ted Chiang, “The Lifecycle of Software Objects,” in ")#emph[#text("Exhalation")]#text(", Vintage, 2019, ")#link("https://www.penguinrandomhouse.com/books/538034/exhalation-by-ted-chiang/9781101947906/")[#text("publisher page")]#text(".")

#text("[3] Terence Tao, ")#emph[#text("Mathematics in the age of AI")]#text(", 2026, ")#link("https://arxiv.org/abs/2608.16753")[#text("arXiv:2608.16753")]#text(".")

#text("[4] Kat Boboris, ")#emph[#text("Fair Moderation, Equitable Access, and AI: arXiv’s Updated Rate Limit Policy")]#text(", arXiv Blog, 1 October 2026, ")#link("https://blog.arxiv.org/2026/10/01/updated-rate-limit-policy/")[#text("article")]#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (17)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/hexagon/#comment-696849")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("It is hard to understand the purpose of this when alternatives such as ")#link("https://vibemathed.com/")[#text("https://vibemathed.com/")]#text(" already exist and are well established.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/hexagon/#comment-696900")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("Hexagon is for ")#emph[#text("both")]#text(" AI and human-written mathematics. You can label submissions in a variety of ways.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/14ea845f9ca50d83eae6ac1b6c7682a0939271fa9a70dc9e629d203c664367c2-57e444c94f095ed3bfd53f489eafc1ea296257df2d170bc91f5743e563c58211.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ng")]], [#link("https://terrytao.wordpress.com/2026/10/06/hexagon/#comment-697682")[#strong[#text("Ng")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("VibeMathed is moderated, but it’s a tracker, not a repository. It does list some unverified claims, but only with explicit tiers and only when there is checkable independent support — a result found by a model in a single run and read by nobody is rejected. It doesn’t preserve results long-term or assign citable identifiers. Hexagon is meant to be that permanent, community-maintained home.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86cf8e242b153b318c02a7df981adc73582a9e2f8838908175acf8a2d9ce5c7c-2a59886790e32ce207c27edac5980b6f0076723881ea8f693648cd84dd41474f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grigori Avramidi")]], [#link("https://terrytao.wordpress.com/2026/10/06/hexagon/#comment-696851")[#strong[#text("Grigori Avramidi")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("Does that mean we will finally get to see those openai proofs?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/hexagon/#comment-696887")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("Those are already out")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/hexagon/#comment-696899")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("“Supposed proofs”. And not to help the field of mathematics, but for marketing and claiming primacy, resulting in lots of money.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86cf8e242b153b318c02a7df981adc73582a9e2f8838908175acf8a2d9ce5c7c-2a59886790e32ce207c27edac5980b6f0076723881ea8f693648cd84dd41474f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grigori Avramidi")]], [#link("https://terrytao.wordpress.com/2026/10/06/hexagon/#comment-697042")[#strong[#text("Grigori Avramidi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("Was posted before.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/hexagon/#comment-696858")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("repository for research works in the mathematical sciences and theoretical computer science")
]

#text("Basically, “give us your research as training data for free”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/hexagon/#comment-697134")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("It’s already the case with arxiv, or basically anything else that you can use to publis anything…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/hexagon/#comment-696872")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("This looks very similar to this idea ")#link("https://proofsandprompts.com/2026/09/22/proofforum-keeping-ai-generated-mathematics-human/")[#text("here")]#text(" of ")#link("https://www.proofforum.org/")[#text("ProofForum")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/hexagon/#comment-696885")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("That could be sort of useful. It solves the problem of how to indicate to the rest of the world that you’re working on something, which could hopefully help to minimize the amount of stepping on each other’s toes that can result from progress being made faster.")

#text("What I don’t see is how it solves the more crucial problem of theorem-debt as undigested material piles up.")

#text("If the posts on Hexagon also came with a declaration of “I promise to digest this particular piece of slop”, that would help a lot. In its current form, I could fear that it achieves the opposite: that it enables and incentivizes the dumping of slop without digestion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/85a188b385a378b90299ed773ab1af8bd6b68720a58f3c1a01880221a92773ea-0f6bee3bb8f9ca5c929594aa64a739946773ec2f7e24c059441b8fe685297059.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yiftach")]], [#link("https://terrytao.wordpress.com/2026/10/06/hexagon/#comment-696888")[#strong[#text("Yiftach")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("It would be very useful to also publish failures. Currently, it is very hard to understand what AI cannot do, and therefore what is worth the time and efforts of humans. This became more common in experimental sciences following the replication crises, and it would be good for math for somewhat different reasons.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/hexagon/#comment-696889")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("I’m not sure you read Borges carefully…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/hexagon/#comment-696902")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("another day, another tenured prof working to dismantle the system that made them. kudos")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/hexagon/#comment-697039")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("Looking at it right now. that is really cool. thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/hexagon/#comment-697057")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("are version numbers allowed on Hexagon?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/40383f3bd839ade506575f16627012d1968d938f0924d08c7bfafa3671f75414-0dcbe4271bd746fbfda6560d9a3b85b244c806ca6ed9290b762562b4c7779548.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lennart Meier")]], [#link("https://terrytao.wordpress.com/2026/10/06/hexagon/#comment-697443")[#strong[#text("Lennart Meier")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("I really appreciate your work on this, Ben! I think that this was necessary, rather sooner than later (regardless whatever stance one has on AI).")
]
