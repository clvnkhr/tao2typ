// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/
// Converted to Typst by tao2typ: "2026-10-14T16:38:54.422538+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "246B, Notes 2: Some connections with the Fourier transform", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("246B, Notes 2: Some connections with the Fourier transform")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 January 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/")[#text("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Previous set of notes: ")#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/")[#text("Notes 1")]#text(". Next set of notes: ")#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/")[#text("Notes 3")]#text(".")

#text("In Exercise 5 (and Lemma 1) of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("246A Notes 4")]#text(" we already observed some links between complex analysis on the disk (or annulus) and Fourier series on the unit circle:")

#list(
[#text("(i) Functions ")#mi("{f}")#text(" that are holomorphic on a disk ")#tao-math("{\\{ \\left|z\\right| < R \\}}", block: false)#text(" are expressed by a convergent Fourier series (and also Taylor series) ")#mi("{f(re^{i\\theta}) = \\sum_{n=0}^\\infty r^n a_n e^{in\\theta}}")#text(" for ")#mi("{0 \\leq r < R}")#text(" (so in particular ")#mi("{a_n = \\frac{1}{n!} f^{(n)}(0)}")#text("), where")

#metadata(none) <tao-235835d5bc32b359e3c9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\limsup_{n \\rightarrow +\\infty} \\left|a_n\\right|^{1/n} \\leq \\frac{1}{R};", block: true)]]

#text("conversely, every infinite sequence ")#mi("{(a_n)_{n=0}^\\infty}")#text(" of coefficients obeying ")#link(<tao-235835d5bc32b359e3c9>)[#text("(1)")]#text(" arises from such a function ")#mi("{f}")#text(".")],
[#text("(ii) Functions ")#mi("{f}")#text(" that are holomorphic on an annulus ")#tao-math("{\\{ r_- < \\left|z\\right| < r_+ \\}}", block: false)#text(" are expressed by a convergent Fourier series (and also Laurent series) ")#mi("{f(re^{i\\theta}) = \\sum_{n=-\\infty}^\\infty r^n a_n e^{in\\theta}}")#text(", where")

#metadata(none) <tao-c7b68ac37f364473e922>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\limsup_{n \\rightarrow +\\infty} \\left|a_n\\right|^{1/n} \\leq \\frac{1}{r_+}; \\liminf_{n \\rightarrow -\\infty} \\left|a_n\\right|^{1/\\left|n\\right|} \\leq \\frac{1}{r_-};", block: true)]]

#text("conversely, every doubly infinite sequence ")#mi("{(a_n)_{n=-\\infty}^\\infty}")#text(" of coefficients obeying ")#link(<tao-c7b68ac37f364473e922>)[#text("(2)")]#text(" arises from such a function ")#mi("{f}")#text(".")],
[#text("(iii) In the situation of (ii), there is a unique decomposition ")#mi("{f = f_1 + f_2}")#text(" where ")#mi("{f_1}")#text(" extends holomorphically to ")#tao-math("{\\{ z: \\left|z\\right| < r_+\\}}", block: false)#text(", and ")#mi("{f_2}")#text(" extends holomorphically to ")#tao-math("{\\{ z: \\left|z\\right| > r_-\\}}", block: false)#text(" and goes to zero at infinity, and are given by the formulae")

#align(center)[#tao-fit-display[#mitex("f_1(z) = \\sum_{n=0}^\\infty a_n z^n = \\frac{1}{2\\pi i} \\int_\\gamma \\frac{f(w)}{w-z}\\ dw")]]

#text("where ")#mi("{\\gamma}")#text(" is any anticlockwise contour in ")#tao-math("{\\{ z: \\left|z\\right| < r_+\\}}", block: false)#text(" enclosing ")#mi("{z}")#text(", and and")

#align(center)[#tao-fit-display[#mitex("f_2(z) = \\sum_{n=-\\infty}^{-1} a_n z^n = - \\frac{1}{2\\pi i} \\int_\\gamma \\frac{f(w)}{w-z}\\ dw")]]

#text("where ")#mi("{\\gamma}")#text(" is any anticlockwise contour in ")#tao-math("{\\{ z: \\left|z\\right| > r_-\\}}", block: false)#text(" enclosing ")#mi("{0}")#text(" but not ")#mi("{z}")#text(".")]
)

#text("This connection lets us interpret various facts about Fourier series through the lens of complex analysis, at least for some special classes of Fourier series. For instance, the Fourier inversion formula ")#mi("{a_n = \\frac{1}{2\\pi} \\int_0^{2\\pi} f(e^{i\\theta}) e^{-in\\theta}\\ d\\theta}")#text(" becomes the Cauchy-type formula for the Laurent or Taylor coefficients of ")#mi("{f}")#text(", in the event that the coefficients are doubly infinite and obey ")#link(<tao-c7b68ac37f364473e922>)[#text("(2)")]#text(" for some ")#mi("{r_- < 1 < r_+}")#text(", or singly infinite and obey ")#link(<tao-235835d5bc32b359e3c9>)[#text("(1)")]#text(" for some ")#mi("{R > 1}")#text(".")

#text("It turns out that there are similar links between complex analysis on a half-plane (or strip) and Fourier ")#emph[#text("integrals")]#text(" on the real line, which we will explore in these notes.")

#text("We first fix a normalisation for the Fourier transform. If ")#mi("{f \\in L^1({\\bf R})}")#text(" is an absolutely integrable function on the real line, we define its Fourier transform ")#mi("{\\hat f: {\\bf R} \\rightarrow {\\bf C}}")#text(" by the formula ")#metadata(none) <tao-67ec5afd5a72bc56a14b>#mi("\\displaystyle  \\hat f(\\xi) := \\int_{\\bf R} f(x) e^{-2\\pi i x \\xi}\\ dx. \\ \\ \\ \\ \\ (3)")#text(" ")#text(" From the dominated convergence theorem ")#mi("{\\hat f}")#text(" will be a bounded continuous function; from ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93Lebesgue_lemma")[#text("the Riemann-Lebesgue lemma")]#text(" it also decays to zero as ")#mi("{\\xi \\rightarrow \\pm \\infty}")#text(". My choice to place the ")#mi("{2\\pi}")#text(" in the exponent is a personal preference (it is slightly more convenient for some harmonic analysis formulae such as the identities ")#link(<tao-418df28d06f462b0eb70>)[#text("(4)")]#text(", ")#link(<tao-ea242a3fb45034524055>)[#text("(5)")]#text(", ")#link(<tao-c8c3727df724362b5453>)[#text("(6)")]#text(" below), though in the complex analysis and PDE literature there are also some slight advantages in omitting this factor. In any event it is not difficult to adapt the discussion in this notes for other choices of normalisation. It is of interest to extend the Fourier transform beyond the ")#mi("{L^1({\\bf R})}")#text(" class into other function spaces, such as ")#mi("{L^2({\\bf R})}")#text(" or the space of tempered distributions, but we will not pursue this direction here; see for instance ")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("these lecture notes of mine")]#text(" for a treatment.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1 (Fourier transform of Gaussian)")]#text(" ")#metadata(none) <tao-c380779f6175766fdbe9>#text(" If ")#mi("{a}")#text(" is a complex number with ")#mi("{\\mathrm{Re} a>0}")#text(" and ")#mi("{f}")#text(" is the Gaussian function ")#mi("{f(x) := e^{-\\pi a x^2}}")#text(", show that the Fourier transform ")#mi("{\\hat f}")#text(" is given by the Gaussian ")#mi("{\\hat f(\\xi) = a^{-1/2} e^{-\\pi \\xi^2/a}}")#text(", where we use the standard branch for ")#mi("{a^{-1/2}}")#text(".")
]

#text("The Fourier transform has many remarkable properties. On the one hand, as long as the function ")#mi("{f}")#text(" is sufficiently “reasonable”, the Fourier transform enjoys a number of very useful identities, such as the ")#link("https://en.wikipedia.org/wiki/Fourier_inversion_theorem")[#text("Fourier inversion formula")]#text(" ")#metadata(none) <tao-418df28d06f462b0eb70>#mi("\\displaystyle  f(x) = \\int_{\\bf R} \\hat f(\\xi) e^{2\\pi i x \\xi} d\\xi, \\ \\ \\ \\ \\ (4)")#text(" ")#text(" the ")#link("https://en.wikipedia.org/wiki/Plancherel_theorem")[#text("Plancherel identity")]#text(" ")#metadata(none) <tao-ea242a3fb45034524055>#tao-math("\\displaystyle  \\int_{\\bf R} \\left|f(x)\\right|^2\\ dx = \\int_{\\bf R} \\left|\\hat f(\\xi)\\right|^2\\ d\\xi, \\ \\ \\ \\ \\ (5)", block: false)#text(" ")#text(" and the ")#link("https://en.wikipedia.org/wiki/Poisson_summation_formula")[#text("Poisson summation formula")]#text(" ")#metadata(none) <tao-c8c3727df724362b5453>#mi("\\displaystyle  \\sum_{n \\in {\\bf Z}} f(n) = \\sum_{k \\in {\\bf Z}} \\hat f(k). \\ \\ \\ \\ \\ (6)")#text(" ")#text(" On the other hand, the Fourier transform also intertwines various ")#emph[#text("qualitative")]#text(" properties of a function ")#mi("{f}")#text(" with “dual” qualitative properties of its Fourier transform ")#mi("{\\hat f}")#text("; in particular, “decay” properties of ")#mi("{f}")#text(" tend to be associated with “regularity” properties of ")#mi("{\\hat f}")#text(", and vice versa. For instance, the Fourier transform of rapidly decreasing functions tend to be smooth. There are complex analysis counterparts of this Fourier dictionary, in which “decay” properties are described in terms of exponentially decaying pointwise bounds, and “regularity” properties are expressed using holomorphicity on various strips, half-planes, or the entire complex plane. The following exercise gives some examples of this:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2 (Decay of ")#mi("{f}")#text(" implies regularity of ")#mi("{\\hat f}")#text(")")]#text(" ")#metadata(none) <tao-29a071efe595bfa4fb7a>#text(" Let ")#mi("{f \\in L^1({\\bf R})}")#text(" be an absolutely integrable function.")

#list(
[#text("(i) If ")#mi("{f}")#text(" has super-exponential decay in the sense that ")#tao-math("{f(x) \\lesssim_{f,M} e^{-M\\left|x\\right|}}", block: false)#text(" for all ")#mi("{x \\in {\\bf R}}")#text(" and ")#mi("{M>0}")#text(" (that is to say one has ")#tao-math("{\\left|f(x)\\right| \\leq C_{f,M} e^{-M\\left|x\\right|}}", block: false)#text(" for some finite quantity ")#mi("{C_{f,M}}")#text(" depending only on ")#mi("{f,M}")#text("), then ")#mi("{\\hat f}")#text(" extends uniquely to an entire function ")#mi("{\\hat f : {\\bf C} \\rightarrow {\\bf C}}")#text(". Furthermore, this function continues to be defined by ")#link(<tao-67ec5afd5a72bc56a14b>)[#text("(3)")]#text(".")],
[#text("(ii) If ")#mi("{f}")#text(" is supported on a compact interval ")#mi("{[a,b]}")#text(" then the entire function ")#mi("{\\hat f}")#text(" from (i) obeys the bounds ")#mi("{\\hat f(\\xi) \\lesssim_f \\max( e^{2\\pi a \\mathrm{Im} \\xi}, e^{2\\pi b \\mathrm{Im} \\xi} )}")#text(" for ")#mi("{\\xi \\in {\\bf C}}")#text(". In particular, if ")#mi("{f}")#text(" is supported in ")#mi("{[-M,M]}")#text(" then ")#tao-math("{\\hat f(\\xi) \\lesssim_f e^{2\\pi M \\left|\\mathrm{Im}(\\xi)\\right|}}", block: false)#text(".")],
[#text("(iii) If ")#mi("{f}")#text(" obeys the bound ")#tao-math("{f(x) \\lesssim_{f,a} e^{-2\\pi a\\left|x\\right|}}", block: false)#text(" for all ")#mi("{x \\in {\\bf R}}")#text(" and some ")#mi("{a>0}")#text(", then ")#mi("{\\hat f}")#text(" extends uniquely to a holomorphic function ")#mi("{\\hat f}")#text(" on the horizontal strip ")#tao-math("{\\{ \\xi: \\left|\\mathrm{Im} \\xi\\right| < a \\}}", block: false)#text(", and obeys the bound ")#tao-math("{\\hat f(\\xi) \\lesssim_{f,a} \\frac{1}{a - \\left|\\mathrm{Im}(\\xi)\\right|}}", block: false)#text(" in this strip. Furthermore, this function continues to be defined by ")#link(<tao-67ec5afd5a72bc56a14b>)[#text("(3)")]#text(".")],
[#text("(iv) If ")#mi("{f}")#text(" is supported on ")#mi("{[0,+\\infty)}")#text(" (resp. ")#mi("{(-\\infty,0]}")#text("), then there is a unique continuous extension of ")#mi("{\\hat f}")#text(" to the lower half-plane ")#mi("{\\{ \\xi: \\mathrm{Im} \\xi \\leq 0\\}}")#text(" (resp. the upper half-plane ")#mi("{\\{ \\xi: \\mathrm{Im} \\xi \\geq 0 \\}}")#text(") which is holomorphic in the interior of this half-plane, and such that ")#mi("{\\hat f(\\xi) \\rightarrow 0}")#text(" uniformly as ")#mi("{\\mathrm{Im} \\xi \\rightarrow -\\infty}")#text(" (resp. ")#mi("{\\mathrm{Im} \\xi \\rightarrow +\\infty}")#text("). Furthermore, this function continues to be defined by ")#link(<tao-67ec5afd5a72bc56a14b>)[#text("(3)")]#text(".")]
)

#strong[#text("Hint:")]#text(" to establish holomorphicity in each of these cases, use Morera’s theorem and the Fubini-Tonelli theorem. For uniqueness, use analytic continuation, or (for part (iv)) the Schwartz reflection principle.")
]

#text("Later in these notes we will give a partial converse to part (ii) of this exercise, known as the ")#link("https://en.wikipedia.org/wiki/Paley%E2%80%93Wiener_theorem")[#text("Paley-Wiener theorem")]#text("; there are also partial converses to the other parts of this exercise.")

#text("From ")#link(<tao-67ec5afd5a72bc56a14b>)[#text("(3)")]#text(" we observe the following intertwining property between multiplication by an exponential and complex translation: if ")#mi("{\\xi_0}")#text(" is a complex number and ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" is an absolutely integrable function such that the modulated function ")#mi("{f_{\\xi_0}(x) := e^{2\\pi i \\xi_0 x} f(x)}")#text(" is also absolutely integrable, then we have the identity ")#metadata(none) <tao-52ad4eefebc6ffb37f77>#mi("\\displaystyle  \\widehat{f_{\\xi_0}}(\\xi) = \\hat f(\\xi - \\xi_0) \\ \\ \\ \\ \\ (7)")#text(" ")#text(" whenever ")#mi("{\\xi}")#text(" is a complex number such that at least one of the two sides of the equation in ")#link(<tao-52ad4eefebc6ffb37f77>)[#text("(7)")]#text(" is well defined. Thus, multiplication of a function by an exponential weight corresponds (formally, at least) to translation of its Fourier transform. By using contour shifting, we will also obtain a dual relationship: under suitable holomorphicity and decay conditions on ")#mi("{f}")#text(", translation by a complex shift will correspond to multiplication of the Fourier transform by an exponential weight. It turns out to be possible to exploit this property to derive many Fourier-analytic identities, such as the inversion formula ")#link(<tao-418df28d06f462b0eb70>)[#text("(4)")]#text(" and the Poisson summation formula ")#link(<tao-c8c3727df724362b5453>)[#text("(6)")]#text(", which we do later in these notes. (The Plancherel theorem can also be established by complex analytic methods, but this requires a little more effort; see Exercise ")#link(<tao-a679df3a0e9f0840dbfe>)[#text("8")]#text(".)")

#text("The material in these notes is loosely adapted from Chapter 4 of Stein-Shakarchi’s “Complex Analysis”.")

#metadata(none) <tao-822e39c84cd55a5e3352>

#heading(level: 1)[#strong[#text(" — 1. The inversion and Poisson summation formulae — ")]]

#text("We now explore how the Fourier transform ")#mi("{\\hat f}")#text(" of a function ")#mi("{f}")#text(" behaves when ")#mi("{f}")#text(" extends holomorphically to a strip. For technical reasons we will also impose a fairly mild decay condition on ")#mi("{f}")#text(" at infinity to ensure integrability. As we shall shortly see, the method of contour shifting then allows us to insert various exponentially decaying factors into Fourier integrals that make the justification of identities such as the Fourier inversion formula straightforward.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Fourier transform of functions holomorphic in a strip)")]#text(" ")#metadata(none) <tao-a5ab5e743434076c5353>#text(" Let ")#mi("{a > 0}")#text(", and suppose that ")#mi("{f}")#text(" is a holomorphic function on the strip ")#tao-math("{\\{ z: \\left|\\mathrm{Im} z\\right| < a \\}}", block: false)#text(" which obeys a decay bound of the form")

#metadata(none) <tao-0c56ad68cd556d1522e6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left|f(x+iy)\\right| \\leq \\frac{C_b}{1+\\left|x\\right|^\\alpha}", block: true)]]

#text("for all ")#mi("{x \\in {\\bf R}}")#text(", ")#mi("{0 < b < a}")#text(", ")#mi("{y \\in [-b,b]}")#text(", and some ")#mi("{C>0}")#text(" and ")#mi("{\\alpha > 1}")#text(" (or in asymptotic notation, one has ")#tao-math("{f(x+iy) \\lesssim_{b,f} \\frac{1}{1+\\left|x\\right|^\\alpha}}", block: false)#text(" whenever ")#mi("{x \\in {\\bf R}}")#text(" and ")#tao-math("{\\left|y\\right| \\leq b < a}", block: false)#text(").")

#list(
[#text("(i) (Translation intertwines with modulation) For any ")#mi("{w}")#text(" in the strip ")#tao-math("{\\{ z: \\left|\\mathrm{Im}(z)\\right| < a \\}}", block: false)#text(", the Fourier transform of the function ")#mi("{x \\mapsto f(x+w)}")#text(" is ")#mi("{\\xi \\mapsto e^{2\\pi i w \\xi} \\hat f(\\xi)}")#text(".")],
[#text("(ii) (Exponential decay of Fourier transform) For any ")#mi("{0 < b < a}")#text(", there is a quantity ")#mi("{C_{b,\\alpha}}")#text(" such that ")#tao-math("{\\left|\\hat f(\\xi)\\right| \\leq C_{b,\\alpha} e^{-2\\pi b\\left|\\xi\\right|}}", block: false)#text(" for all ")#mi("{\\xi \\in {\\bf R}}")#text(" (or in asymptotic notation, one has ")#tao-math("{\\hat f(\\xi) \\lesssim_{a,b,\\alpha,f} e^{-2\\pi b\\left|\\xi\\right|}}", block: false)#text(" for ")#mi("{0 < b < a}")#text(" and ")#mi("{\\xi \\in {\\bf R}}")#text(").")],
[#text("(iii) (Partial Fourier inversion) For any ")#mi("{0 < \\varepsilon < a}")#text(" and ")#mi("{x \\in {\\bf R}}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi = \\frac{1}{2\\pi i} \\int_{-\\infty}^\\infty \\frac{f(y-i\\varepsilon)}{y-i\\varepsilon - x}\\ dy")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\int_{-\\infty}^0 \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi = -\\frac{1}{2\\pi i} \\int_{-\\infty}^\\infty \\frac{f(y+i\\varepsilon)}{y+i\\varepsilon - x}\\ dy.")]]],
[#text("(iv) (Full Fourier inversion) For any ")#mi("{x \\in {\\bf R}}")#text(", the identity ")#link(<tao-418df28d06f462b0eb70>)[#text("(4)")]#text(" holds for this function ")#mi("{f}")#text(".")],
[#text("(v) (Poisson summation formula) The identity ")#link(<tao-c8c3727df724362b5453>)[#text("(6)")]#text(" holds for this function ")#mi("{f}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" We begin with (i), which is a standard application of contour shifting. Applying the definition ")#link(<tao-67ec5afd5a72bc56a14b>)[#text("(3)")]#text(" of the Fourier transform, our task is to show that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} f(x+w) e^{-2\\pi i x \\xi}\\ dx = e^{2\\pi i w \\xi} \\int_{\\bf R} f(x) e^{-2\\pi i x \\xi}\\ dx")]]

#text("whenever ")#tao-math("{\\left|\\mathrm{Im} w\\right| < a}", block: false)#text(" and ")#mi("{\\xi \\in {\\bf R}}")#text(". Clearly")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} f(x) e^{-2\\pi i x \\xi}\\ d\\xi = \\lim_{R \\rightarrow \\infty} \\int_{\\gamma_{-R \\rightarrow R}} f(z) e^{-2\\pi i z \\xi}\\ dz")]]

#text("where ")#mi("{\\gamma_{z_1 \\rightarrow z_2}}")#text(" is the line segment contour from ")#mi("{z_1}")#text(" to ")#mi("{z_2}")#text(", and similarly after a change of variables")

#align(center)[#tao-fit-display[#mitex("e^{-2\\pi i w \\xi} \\int_{\\bf R} f(x+w) e^{-2\\pi i x \\xi}\\ dx = \\lim_{R \\rightarrow \\infty} \\int_{\\gamma_{-R+w \\rightarrow R+w}} f(z) e^{-2\\pi i z \\xi}\\ dz.")]]

#text("On the other hand, from Cauchy’s theorem we have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_{-R+w \\rightarrow R+w}} = \\int_{\\gamma_{-R \\rightarrow R}} + \\int_{\\gamma_{R \\rightarrow R+w}} - \\int_{\\gamma_{-R \\rightarrow -R+w}}")]]

#text("when applied to the holomorphic integrand ")#mi("{f(z) e^{-2\\pi i z \\xi}}")#text(". So it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_{\\pm R \\rightarrow \\pm R+w}} f(z) e^{-2\\pi i z \\xi}\\ dz \\rightarrow 0")]]

#text("as ")#mi("{R \\rightarrow \\infty}")#text(". But the left hand side can be rewritten as")

#align(center)[#tao-fit-display[#mitex("w e^{\\mp 2\\pi i R \\xi} \\int_0^1 f(\\pm R + tw) e^{-2\\pi i tw \\xi}\\ dt,")]]

#text("and the claim follows from ")#link(<tao-0c56ad68cd556d1522e6>)[#text("(8)")]#text(" and dominated convergence.")

#text("For (ii), we apply (i) with ")#mi("{w = \\pm i b}")#text(" to observe that the Fourier transform of ")#mi("{x \\mapsto f(x \\pm ib)}")#text(" is ")#mi("{\\xi \\mapsto e^{\\mp 2\\pi b \\xi} \\hat f(\\xi)}")#text(". Applying ")#link(<tao-0c56ad68cd556d1522e6>)[#text("(8)")]#text(" and the triangle inequality we conclude that")

#align(center)[#tao-fit-display[#mitex("e^{\\mp 2\\pi b \\xi} \\hat f(\\xi) \\lesssim_{f,b,\\alpha} 1")]]

#text("for both choices of sign ")#mi("{\\mp}")#text(" and all ")#mi("{\\xi \\in {\\bf R}}")#text(", giving the claim.")

#text("For the first part of (iii), we write ")#mi("{f_{-\\varepsilon}(y) := f(y-i\\varepsilon)}")#text(". By part (i), we have ")#mi("{\\hat f_{-\\varepsilon}(\\xi) = e^{2\\pi \\varepsilon \\xi} \\hat f(\\xi)}")#text(", so we can rewrite the desired identity as")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty \\hat f_{-\\varepsilon}(\\xi) e^{-2\\pi \\varepsilon \\xi} e^{2\\pi i x \\xi}\\ d\\xi = \\frac{1}{2\\pi i} \\int_{-\\infty}^\\infty \\frac{f_{-\\varepsilon}(y)}{y-i\\varepsilon-x}\\ dy.")]]

#text("By ")#link(<tao-67ec5afd5a72bc56a14b>)[#text("(3)")]#text(" and Fubini’s theorem (taking advantage of ")#link(<tao-0c56ad68cd556d1522e6>)[#text("(8)")]#text(" and the exponential decay of ")#mi("{e^{-2\\pi \\varepsilon \\xi}}")#text(" as ")#mi("{\\xi\\rightarrow +\\infty}")#text(") the left-hand side can be written as")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} f_{-\\varepsilon}(y) \\int_0^\\infty e^{-2\\pi i y \\xi} e^{-2\\pi \\varepsilon \\xi} e^{2\\pi i x \\xi}\\ dy d\\xi.")]]

#text("But a routine calculation shows that")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty e^{-2\\pi i y \\xi} e^{-2\\pi \\varepsilon \\xi} e^{2\\pi i x \\xi}\\ d\\xi = \\frac{1}{2\\pi i} \\frac{1}{y-i\\varepsilon-x}")]]

#text("giving the claim. The second part of (iii) is proven similarly.")

#text("To prove (iv), it suffices in light of (iii) to show that")

#align(center)[#tao-fit-display[#mitex("\\int_{-\\infty}^\\infty \\frac{f(y-i\\varepsilon)}{y-i\\varepsilon - x}\\ dy - \\int_{-\\infty}^\\infty \\frac{f(y+i\\varepsilon)}{y+i\\varepsilon - x}\\ dy = 2\\pi i f(x)")]]

#text("for any ")#mi("{x \\in {\\bf R}}")#text(". The left-hand side can be written after a change of variables as")

#align(center)[#tao-fit-display[#mitex("\\lim_{R \\rightarrow \\infty} \\int_{\\gamma_{-R-i\\varepsilon \\rightarrow R-i\\varepsilon}} \\frac{f(z)}{z-x}\\ dz - \\int_{\\gamma_{-R+i\\varepsilon \\rightarrow R+i\\varepsilon}} \\frac{f(z)}{z-x}\\ dz.")]]

#text("On the other hand, from dominated convergence as in the proof of (i) we have")

#align(center)[#tao-fit-display[#mitex("\\lim_{R \\rightarrow \\infty} \\int_{\\gamma_{R-i\\varepsilon \\rightarrow R+i\\varepsilon}} \\frac{f(z)}{z-x}\\ dz + \\int_{\\gamma_{-R+i\\varepsilon \\rightarrow -R-i\\varepsilon}} \\frac{f(z)}{z-x}\\ dz = 0")]]

#text("while from the Cauchy integral formula one has")

#align(center)[#tao-fit-display[#mitex("\\lim_{R \\rightarrow \\infty} \\int_{\\gamma_{-R-i\\varepsilon \\rightarrow R-i\\varepsilon \\rightarrow R+i\\varepsilon \\rightarrow -R+i\\varepsilon \\rightarrow -R-i\\varepsilon}} \\frac{f(z)}{z-x}\\ dz = 2\\pi i f(x)")]]

#text("giving the claim.")

#text("Now we prove (v). Let ")#mi("{0 < \\varepsilon < a}")#text(". From (i) we have")

#align(center)[#tao-fit-display[#mitex("\\hat f(k) = \\int_{\\bf R} f(x-i\\varepsilon) e^{-2\\pi \\varepsilon k} e^{-2\\pi i k x}\\ dx")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\hat f(k) = \\int_{\\bf R} f(x+i\\varepsilon) e^{2\\pi \\varepsilon k} e^{-2\\pi i k x}\\ dx")]]

#text("for any ")#mi("{k \\in {\\bf Z}}")#text(". If we sum the first identity for ")#mi("{k=0,1,2,\\dots}")#text(" we see from the geometric series formula and Fubini’s theorem that")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=0}^\\infty \\hat f(k) = \\int_{\\bf R} \\frac{f(x-i\\varepsilon)}{1 - e^{-2\\pi i (x-i\\varepsilon)}}\\ dx")]]

#text("and similarly if we sum the second identity for ")#mi("{k=-1,-2,\\dots}")#text(" we have")

#tao-aligned(keep: true)[


#tao-math("\\sum_{k=-\\infty}^{-1} \\hat f(k)  & = \\int_{\\bf R} \\frac{f(x+i\\varepsilon) e^{2\\pi i (x+i\\varepsilon)}}{1 - e^{2\\pi i (x+i\\varepsilon)}}\\ dx", block: true)



#tao-math(" & = - \\int_{\\bf R} \\frac{f(x+i\\varepsilon)}{1 - e^{-2\\pi i (x+i\\varepsilon)}}\\ dx.", block: true)
]

#text("Adding these two identities and changing variables, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=-\\infty}^\\infty \\hat f(k) = \\lim_{R \\rightarrow \\infty} \\int_{\\gamma_{-R-i\\varepsilon \\rightarrow R-i\\varepsilon}} \\frac{f(z)}{1 - e^{-2\\pi i z}}\\ dz + \\int_{\\gamma_{R+i\\varepsilon \\rightarrow -R+i\\varepsilon}} \\frac{f(z)}{1 - e^{-2\\pi i z}}\\ dz.")]]

#text("We would like to use the residue theorem to evaluate the right-hand side, but we need to take a little care to avoid the poles of the integrand ")#mi("{\\frac{f(z)}{1 - e^{-2\\pi i z}}}")#text(", which are at the integers. Hence we shall restrict ")#mi("{R}")#text(" to be a half-integer ")#mi("{R = N + \\frac{1}{2}}")#text(". In this case, a routine application of the residue theorem shows that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_{-R-i\\varepsilon \\rightarrow R-i\\varepsilon \\rightarrow R+i\\varepsilon \\rightarrow -R+i\\varepsilon \\rightarrow -R-i\\varepsilon}} \\frac{f(z)}{1 - e^{-2\\pi i z}}\\ dz = \\sum_{n=-N}^N f(n).")]]

#text("Noting that ")#mi("{\\frac{1}{1-e^{-2\\pi i z}}}")#text(" stays bounded for ")#mi("{z}")#text(" in ")#mi("{\\gamma_{R-i\\varepsilon \\rightarrow R+i\\varepsilon}}")#text(" or ")#mi("{\\gamma_{-R+i\\varepsilon \\rightarrow -R-i\\varepsilon}}")#text(" when ")#mi("{R}")#text(" is a half-integer, we also see from dominated convergence as before that")

#align(center)[#tao-fit-display[#mitex("\\lim_{R \\rightarrow \\infty} \\int_{\\gamma_{R-i\\varepsilon \\rightarrow R+i\\varepsilon}} \\frac{f(z)}{1 - e^{-2\\pi i z}}\\ dz + \\int_{\\gamma_{-R+i\\varepsilon \\rightarrow -R-i\\varepsilon}} \\frac{f(z)}{1 - e^{-2\\pi i z}} = 0.")]]

#text("The claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4 (Hilbert transform and Plemelj formula)")]#text(" Let ")#mi("{a, \\alpha, f}")#text(" be as in Proposition ")#link(<tao-a5ab5e743434076c5353>)[#text("3")]#text(". Define the ")#link("https://en.wikipedia.org/wiki/Stieltjes_transformation")[#text("Cauchy-Stieltjes transform")]#text(" ")#mi("{{\\mathcal C} f: {\\bf C} \\backslash {\\bf R} \\rightarrow {\\bf C}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("{\\mathcal C} f(z) := \\int_{\\bf R} \\frac{f(x)}{z-x}\\ dx.")]]

#list(
[#text("(i) Show that ")#mi("{{\\mathcal C} f}")#text(" is holomorphic on ")#mi("{{\\bf C} \\backslash {\\bf R}}")#text(" and has the Fourier representation")

#align(center)[#tao-fit-display[#mitex("{\\mathcal C} f(z) = -2\\pi i \\int_0^\\infty \\hat f(\\xi) e^{2\\pi i z \\xi}\\ d\\xi")]]

#text("in the upper half-plane ")#mi("{\\mathrm{Im} z > 0}")#text(" and")

#align(center)[#tao-fit-display[#mitex("{\\mathcal C} f(z) = 2\\pi i \\int_{-\\infty}^0 \\hat f(\\xi) e^{2\\pi i z \\xi}\\ d\\xi")]]

#text("in the lower half-plane ")#mi("{\\mathrm{Im} z < 0}")#text(".")],
[#text("(ii) Establish the ")#link("https://en.wikipedia.org/wiki/Sokhotski%E2%80%93Plemelj_theorem")[#text("Plemelj formulae")]

#align(center)[#tao-fit-display[#mitex("\\lim_{\\varepsilon \\rightarrow 0^+} {\\mathcal C} f(x+i\\varepsilon) = \\pi H f(x) - i \\pi f(x)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\lim_{\\varepsilon \\rightarrow 0^+} {\\mathcal C} f(x-i\\varepsilon) = \\pi H f(x) + i \\pi f(x)")]]

#text("uniformly for any ")#mi("{x \\in {\\bf R}}")#text(", where the ")#link("https://en.wikipedia.org/wiki/Hilbert_transform")[#text("Hilbert transform")]#text(" ")#mi("{Hf}")#text(" of ")#mi("{f}")#text(" is defined by the principal value integral")

#align(center)[#tao-fit-display[#tao-math("Hf(x) := \\lim_{\\varepsilon \\rightarrow 0^+, R \\rightarrow \\infty} \\frac{1}{\\pi} \\int_{\\varepsilon \\leq \\left|y-x\\right| \\leq R} \\frac{f(y)}{x-y}\\ dy.", block: true)]]],
[#text("(iii) Show that ")#mi("{{\\mathcal C} f}")#text(" is the unique holomorphic function ")#mi("{g}")#text(" on ")#mi("{{\\bf C} \\backslash {\\bf R}}")#text(" that obeys the decay bound")

#align(center)[#tao-fit-display[#tao-math("\\sup_{x+iy \\in {\\bf C} \\backslash {\\bf R}} (1+\\left|y\\right|) \\left|g(x+iy)\\right| < \\infty", block: true)]]

#text("and solves the (very simple special case of the) ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93Hilbert_problem")[#text("Riemann-Hilbert problem")]

#align(center)[#tao-fit-display[#mitex("\\lim_{\\varepsilon \\rightarrow 0^+} g(x+i\\varepsilon) - \\lim_{\\varepsilon \\rightarrow 0^+} g(x-i\\varepsilon) = - 2\\pi i f(x)")]]

#text("uniformly for all ")#mi("{x \\in {\\bf R}}")#text(", with both limits existing uniformly in ")#mi("{x}")#text(".")],
[#text("(iv) Establish the identity")

#align(center)[#tao-fit-display[#mitex("Hf(x) = -\\int_{\\bf R} i \\mathrm{sgn}(\\xi) \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi,")]]

#text("where the signum function ")#mi("{\\mathrm{sgn}(\\xi)}")#text(" is defined to equal ")#mi("{+1}")#text(" for ")#mi("{\\xi>0}")#text(", ")#mi("{-1}")#text(" for ")#mi("{\\xi < 0}")#text(", and ")#mi("{0}")#text(" for ")#mi("{\\xi=0}")#text(".")],
[#text("(v) Assume now that ")#mi("{f}")#text(" has mean zero (i.e., ")#mi("{\\int_{\\bf R} f(x)\\ dx = 0}")#text("). Show that ")#mi("{Hf}")#text(" extends holomorphically to the strip ")#tao-math("{\\{ z: \\left|\\mathrm{Im} z\\right| < a \\}}", block: false)#text(" and obeys the bound ")#link(<tao-0c56ad68cd556d1522e6>)[#text("(8)")]#text(" (but possibly with a different constant ")#mi("{C_b}")#text(", and with ")#mi("{\\alpha}")#text(" replaced by a slightly smaller quantity ")#mi("{1 < \\alpha^{\\prime} < \\alpha}")#text("), with the identity")

#metadata(none) <tao-730f7d03509cce2ddaed>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("{\\mathcal C} f(z) = \\pi H f(z) - \\pi i \\mathrm{sgn}(\\mathrm{Im}(z)) f(z)")]]

#text("holding for ")#tao-math("{0 < \\left|\\mathrm{Im} z\\right| < a}", block: false)#text(". ({")#emph[#text("Hint:")]#text(" To exploit the mean value hypothesis to get good decay bounds on ")#mi("{{\\mathcal C} f(z)}")#text(" and hence ")#mi("{Hf(z)}")#text(", write ")#mi("{\\frac{f(x)}{z-x}}")#text(" as the sum of ")#mi("{\\frac{f(x)}{z}}")#text(" and ")#mi("{f(x) (\\frac{1}{z-x}-\\frac{1}{z})}")#text(" and use the mean value hypothesis to manage the first term. For the contribution of the second term, take advantage of contour shifting to avoid the singularity at ")#mi("{z=x}")#text(". One may have to divide the integrals one encounters into a couple of pieces and estimate each piece separately.)")],
[#text("(vi) Continue to assume that ")#mi("{f}")#text(" has mean zero. Establish the identities")

#align(center)[#tao-fit-display[#mitex("H(Hf) = -f")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("H( fHf) = \\frac{(Hf)^2 - f^2}{2}.")]]

#text("(")#emph[#text("Hint:")]#text(" for the latter inequality, square both sides of ")#link(<tao-730f7d03509cce2ddaed>)[#text("(9)")]#text(" and use (iii).)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5 (Kramers-Kronig relations)")]#text(" Let ")#mi("{f}")#text(" be a continuous function on the upper half-plane ")#mi("{\\{ z: \\mathrm{Im} z \\geq 0 \\}}")#text(" which is holomorphic on the interior of this half-plane, and obeys the bound ")#tao-math("{\\left|f(z)\\right| \\leq C/\\left|z\\right|}", block: false)#text(" for all non-zero ")#mi("{z}")#text(" in this half-plane and some ")#mi("{C>0}")#text(". Establish the ")#link("https://en.wikipedia.org/wiki/Kramers%E2%80%93Kronig_relations")[#text("Kramers-Kronig relations")]

#align(center)[#tao-fit-display[#tao-math("\\mathrm{Re} f(x) = \\lim_{\\varepsilon \\rightarrow 0, R \\rightarrow \\infty} \\frac{1}{\\pi} \\int_{\\varepsilon \\leq \\left|y-x\\right| \\leq R} \\frac{\\mathrm{Im} f(y)}{y-x}\\ dy", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{Im} f(x) = -\\lim_{\\varepsilon \\rightarrow 0, R \\rightarrow \\infty} \\frac{1}{\\pi} \\int_{\\varepsilon \\leq \\left|y-x\\right| \\leq R} \\frac{\\mathrm{Re} f(y)}{y-x}\\ dy", block: true)]]

#text("relating the real and imaginary parts of ")#mi("{f}")#text(" to each other.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]

#list(
[#text("(i) By applying the Poisson summation formula to the function ")#mi("{x \\mapsto \\frac{1}{x^2+a^2}}")#text(", establish the identity")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}} \\frac{1}{n^2 + a^2} = \\frac{\\pi}{a} \\frac{e^{2\\pi a}+1}{e^{2\\pi a}-1}")]]

#text("for any positive real number ")#mi("{a}")#text(". Explain why this is consistent with Exercise 24 from ")#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/")[#text("Notes 1")]#text(".")],
[#text("(ii) By carefully taking limits of (i) as ")#mi("{a \\rightarrow 0}")#text(", establish yet another alternate proof of Euler’s identity")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{1}{n^2} = \\frac{\\pi^2}{6}.")]]]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" For ")#mi("{\\tau}")#text(" in the upper half-plane ")#mi("{\\{ \\mathrm{Im} \\tau > 0\\}}")#text(", define the ")#link("https://en.wikipedia.org/wiki/Theta_function")[#text("theta function")]#text(" ")#mi("{\\theta(\\tau) := \\sum_{n \\in {\\bf Z}} e^{\\pi i n^2 \\tau}}")#text(". Use Exercise ")#link(<tao-c380779f6175766fdbe9>)[#text("1")]#text(" and the Poisson summation formula to establish the ")#link("https://en.wikipedia.org/wiki/Modular_form")[#text("modular identity")]

#align(center)[#tao-fit-display[#mitex("\\theta(\\tau) = (-i\\tau)^{-1/2} \\theta(-1/\\tau)")]]

#text("for such ")#mi("{\\tau}")#text(", where one takes the standard branch of the square root.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8 (Fourier proof of Plancherel identity)")]#text(" ")#metadata(none) <tao-a679df3a0e9f0840dbfe>#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" be smooth and compactly supported. For any ")#mi("{\\xi \\in {\\bf C}}")#text(" with ")#mi("{\\mathrm{Im} \\xi \\geq 0}")#text(", define the quantity")

#align(center)[#tao-fit-display[#mitex("A(\\xi) := 2 \\iint_{x>y} e^{2\\pi i \\xi (x-y)} \\overline{f}(x) f(y)\\ dx dy.")]]

#list(
[#text("(i) When ")#mi("{\\xi}")#text(" is real, show that ")#tao-math("{\\mathrm{Re} A(\\xi) = \\left|\\hat f(\\xi)\\right|^2}", block: false)#text(". (")#emph[#text("Hint:")]#text(" find a way to rearrange the expression ")#mi("{\\frac{1}{2}( A(\\xi) + \\overline{A}(\\xi))}")#text(".)")],
[#text("(ii) For ")#mi("{\\xi}")#text(" non-zero (but not necessarily real), show that ")#tao-math("{A(\\xi) = \\frac{-1}{\\pi i \\xi} \\int_{\\bf R} \\left|f(x)\\right|^2\\ dx + O(1/\\left|\\xi\\right|^2)}", block: false)#text(", where the implied constant in the ")#mi("{\\xi}")#text(" notation can depend on ")#mi("{f}")#text(". (")#emph[#text("Hint:")]#text(" integrate by parts several times.)")],
[#text("(iii) Establish the Plancherel identity ")#link(<tao-ea242a3fb45034524055>)[#text("(5)")]#text(" (")#emph[#text("Hint:")]#text(" use contour shifting.).")]
)

#text("Remarkably, this proof of the Plancherel identity generalises to a nonlinear version involving a trace formula for the scattering transform for either Schrödinger or Dirac operators. For Schrödinger operators this was first obtained (implicitly) ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=120417")[#text("by Buslaev and Faddeev")]#text(", and later more explicitly ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1697600")[#text("by Deift and Killip")]#text(". The version for Dirac operators more closely resembles the linear Plancherel identity; see for instance the appendix to ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1950785")[#text("this paper of Muscalu, Thiele, and myself")]#text(". The quantity ")#mi("{A(\\xi)}")#text(" is a component of a nonlinear quantity known as the ")#emph[#text("transmission coefficient")]#text(" ")#mi("{a(\\xi)}")#text(" of a Dirac operator with potential ")#mi("{f}")#text(" and spectral parameter ")#mi("{\\xi}")#text(" (or ")#mi("{2\\pi \\xi}")#text(", depending on normalisations).")
]

#text("The Fourier inversion formula was only established in Proposition ")#link(<tao-a5ab5e743434076c5353>)[#text("3")]#text(" for functions that had a suitable holomorphic extension to a strip, but one can relax the hypotheses by a limiting argument. Here is one such example of this:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9 (More general Fourier inversion formula)")]#text(" ")#metadata(none) <tao-5d9b17b1c95e575a4e09>#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" be continuous and obey the bound ")#tao-math("{\\left|f(x)\\right| \\leq \\frac{C}{1+\\left|x\\right|^2}}", block: false)#text(" for all ")#mi("{x \\in {\\bf R}}")#text(" and some ")#mi("{C>0}")#text(". Suppose that the Fourier transform ")#mi("{\\hat f: {\\bf R} \\rightarrow {\\bf C}}")#text(" is absolutely integrable.")

#list(
[#text("(i) Show that for any ")#mi("{\\varepsilon>0}")#text(", the regularised function")

#align(center)[#tao-fit-display[#mitex("f_\\varepsilon(x) := \\int_{\\bf R} f(x+\\varepsilon y) e^{-\\pi y^2}\\ dy")]]

#text("extends to an entire function obeying the hypotheses of Proposition ")#link(<tao-a5ab5e743434076c5353>)[#text("3")]#text(" for any ")#mi("{0 < a < \\infty}")#text(", with ")#mi("{\\hat f_\\varepsilon(\\xi) = e^{-\\pi \\varepsilon^2 \\xi^2} \\hat f(\\xi)}")#text(" for any ")#mi("{\\xi \\in {\\bf R}}")#text(". (Hint: use Exercise ")#link(<tao-c380779f6175766fdbe9>)[#text("1")]#text(".)")],
[#text("(ii) Show that the Fourier inversion formula ")#link(<tao-418df28d06f462b0eb70>)[#text("(4)")]#text(" holds for this function ")#mi("{f}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Laplace inversion formula)")]#text(" Let ")#mi("{f: [0,+\\infty) \\rightarrow {\\bf C}}")#text(" be a continuously twice differentiable function, obeying the bounds ")#tao-math("{\\left|f(x)\\right|, \\left|f^{\\prime}(x)\\right|, \\left|f^{\\prime\\prime}(x)\\right| \\leq \\frac{C}{1+\\left|x\\right|^2}}", block: false)#text(" for all ")#mi("{x \\geq 0}")#text(" and some ")#mi("{C>0}")#text(".")

#list(
[#text("(i) Show that the Fourier transform ")#mi("{\\hat f}")#text(" obeys the asymptotic")

#align(center)[#tao-fit-display[#tao-math("\\hat f(\\xi) = \\frac{f(0)}{2\\pi i \\xi} + O( \\frac{C}{\\left|\\xi\\right|^2} )", block: true)]]

#text("for any non-zero ")#mi("{\\xi \\in {\\bf R}}")#text(".")],
[#text("(ii) Establish the principal value inversion formula")

#align(center)[#tao-fit-display[#mitex("f(x) = \\lim_{T \\rightarrow +\\infty} \\int_{-T}^T \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi")]]

#text("for any positive real ")#mi("{x}")#text(". (")#emph[#text("Hint:")]#text(" modify the proof of Exercise ")#link(<tao-5d9b17b1c95e575a4e09>)[#text("9")]#text("(ii).) What happens when ")#mi("{x}")#text(" is negative? zero?")],
[#text("(iii) Define the ")#link("https://en.wikipedia.org/wiki/Laplace_transform")[#text("Laplace transform")]#text(" ")#mi("{{\\mathcal L} f(s)}")#text(" of ")#mi("{f}")#text(" for ")#mi("{\\mathrm{Re}(s) \\geq 0}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L} f(s) := \\int_0^\\infty f(t) e^{-st}\\ dt.")]]

#text("Show that ")#mi("{{\\mathcal L} f}")#text(" is continuous on the half-plane ")#mi("{\\{ s: \\mathrm{Re}(s) \\geq 0\\}}")#text(", holomorphic on the interior of this half-plane, and obeys the ")#emph[#text("Laplace-Mellin inversion formula")]

#metadata(none) <tao-dcb7bffa40d781315111>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("f(t) = \\frac{1}{2\\pi i} \\lim_{T \\rightarrow +\\infty} \\int_{\\gamma_{\\sigma-iT \\rightarrow \\sigma+iT}} e^{st} {\\mathcal L} f(s) \\ ds")]]

#text("for any ")#mi("{t>0}")#text(" and ")#mi("{\\sigma \\geq 0}")#text(", where ")#mi("{\\gamma_{\\sigma-iT \\rightarrow \\sigma+iT}}")#text(" is the line segment contour from ")#mi("{\\sigma-iT}")#text(" to ")#mi("{\\sigma+iT}")#text(". Conclude in particular that the Laplace transform ")#mi("{{\\mathcal L}}")#text(" is injective on this class of functions ")#mi("{f}")#text(".")]
)

#text("The Laplace-Mellin inversion formula in fact holds under more relaxed decay and regularity hypotheses than the ones given in this exercise, but we will not pursue these generalisations here. The limiting integral in ")#link(<tao-dcb7bffa40d781315111>)[#text("(10)")]#text(" is also known as the ")#emph[#text("Bromwich integral")]#text(", and often written (with a slight abuse of notation) as ")#mi("{\\frac{1}{2\\pi i} \\int_{\\sigma-i\\infty}^{\\sigma+i\\infty} e^{st} {\\mathcal L} f(s)\\ ds}")#text(". The Laplace transform is a close cousin of the Fourier transform that has many uses; for instance, it is a popular tool for analysing ordinary differential equations on half-lines such as ")#mi("{[0,+\\infty)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11 (Mellin inversion formula)")]#text(" Let ")#mi("{f: (0,+\\infty) \\rightarrow {\\bf C}}")#text(" be a continuous function that is compactly supported in ")#mi("{(0,+\\infty)}")#text(". Define the ")#emph[#text("Mellin transform")]#text(" ")#mi("{{\\mathcal M} f: {\\bf C} \\rightarrow {\\bf C}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("{\\mathcal M} f(s) := \\int_0^\\infty x^s f(x) \\frac{dx}{x}.")]]

#text("Show that ")#mi("{{\\mathcal M} f}")#text(" is entire and one has the ")#emph[#text("Mellin inversion formula")]

#align(center)[#tao-fit-display[#mitex("f(x) = \\frac{1}{2\\pi i} \\lim_{T \\rightarrow +\\infty} \\int_{\\gamma_{\\sigma-iT \\rightarrow \\sigma+iT}} x^{-s} {\\mathcal M} f(s)\\ ds")]]

#text("for any ")#mi("{x \\in {\\bf R}}")#text(" and ")#mi("{\\sigma \\in {\\bf R}}")#text(". The regularity and support hypotheses on ")#mi("{f}")#text(" can be relaxed significantly, but we will not pursue this direction here.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Perron’s formula)")]#text(" Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be a function which is of subpolynomial growth in the sense that ")#tao-math("{\\left|f(n)\\right| \\leq C_\\varepsilon n^\\varepsilon}", block: false)#text(" for all ")#mi("{n \\in {\\bf N}}")#text(" and ")#mi("{\\varepsilon>0}")#text(", where ")#mi("{C_\\varepsilon}")#text(" depends on ")#mi("{\\varepsilon}")#text(" (and ")#mi("{f}")#text("). For ")#mi("{s}")#text(" in the half-plane ")#mi("{\\{ \\mathrm{Re} s > 1 \\}}")#text(", form the ")#link("https://en.wikipedia.org/wiki/Dirichlet_series")[#text("Dirichlet series")]

#align(center)[#tao-fit-display[#mitex("F(s) := \\sum_{n=1}^\\infty \\frac{f(n)}{n^s}.")]]

#text("For any non-integer ")#mi("{x>0}")#text(" and any ")#mi("{\\sigma>1}")#text(", establish ")#link("https://en.wikipedia.org/wiki/Perron%27s_formula")[#text("Perron’s formula")]

#metadata(none) <tao-5111f93f8a30fe634de9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\sum_{n \\leq x} f(n) = \\frac{1}{2\\pi i} \\lim_{T \\rightarrow \\infty} \\int_{\\gamma_{\\sigma-iT \\rightarrow \\sigma+iT}} F(s) \\frac{x^s}{s}\\ ds.")]]

#text("What happens when ")#mi("{x}")#text(" is an integer? (The Perron formula and its many variants are of great utility in analytic number theory; see ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("these previous lecture notes")]#text(" for further discussion.) Note that one can use the special case of this exercise from Exercise 28 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("246A Notes 4")]#text(" to help out here.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Solution to Schrödinger equation)")]#text(" Let ")#mi("{f, a}")#text(" be as in Proposition ")#link(<tao-a5ab5e743434076c5353>)[#text("3")]#text(". Define the function ")#mi("{u: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf C}}")#text(" by the formula \\{ u(t,x) := \\int_")#strong[#text("R")]#text(" \\hat f(\\xi) e^{2\\pi i x \\xi – 4 \\pi^2 i \\xi^2 t} d\\xi.\\}")

#list(
[#text("(i) Show that ")#mi("{f}")#text(" is a smooth function of ")#mi("{t,x}")#text(" that obeys the Schrödinger equation ")#mi("{i \\partial_t u + \\partial_{xx} u = 0}")#text(" with initial condition ")#mi("{u(0,x) = f(x)}")#text(" for ")#mi("{x \\in {\\bf R}}")#text(".")],
[#text("(ii) Establish the formula")

#align(center)[#tao-fit-display[#tao-math("u(t,x) = \\frac{1}{(4\\pi i t)^{1/2}} \\int_{\\bf R} e^{-\\frac{\\left|x-y\\right|^2}{4it}} f(y)\\ dy", block: true)]]

#text("for ")#mi("{x \\in {\\bf R}}")#text(" and ")#mi("{t \\neq 0}")#text(", where we use the standard branch of the square root.")]
)
]

#heading(level: 1)[#strong[#text(" — 2. Phragmén-Lindelöf and Paley-Wiener — ")]]

#text("The ")#link("https://en.wikipedia.org/wiki/Maximum_modulus_principle")[#text("maximum modulus principle")]#text(" (Exercise 26 from ")#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/")[#text("246A Notes 1")]#text(") for holomorphic functions asserts that if a function continuous on a compact subset ")#mi("{K}")#text(" of the plane and holomorphic on the interior of that set is bounded in magnitude by a bound ")#mi("{M}")#text(" on the boundary ")#mi("{\\partial K}")#text(", then it is also bounded by ")#mi("{M}")#text(" on the interior. This principle does not directly apply for noncompact domains ")#mi("{K}")#text(": for instance, on the entire complex plane ")#mi("{{\\bf C}}")#text(", there is no boundary whatsoever and the bound is clearly vacuous. On the half-plane ")#mi("{\\{ \\mathrm{Im} z \\geq 0 \\}}")#text(", the holomorphic function ")#mi("{\\cos z}")#text(" (for instance) is bounded in magnitude by ")#mi("{1}")#text(" on the boundary of the half-plane, but grows exponentially in the interior. Similarly, in the strip ")#mi("{\\{ z: -\\pi/2 \\leq \\mathrm{Re} z \\leq \\pi/2\\}}")#text(", the holomorphic function ")#mi("{\\exp(\\exp(iz))}")#text(" is bounded in magnitude by ")#mi("{1}")#text(" on the boundary of the strip, but is grows double-exponentially in the interior of the strip. However, if one does not have such absurdly high growth, one can recover a form of the maximum principle, known as the ")#link("https://en.wikipedia.org/wiki/Phragm%C3%A9n%E2%80%93Lindel%C3%B6f_principle")[#text("Phragmén-Lindelöf principle")]#text(". Here is one formulation of this principle:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14 (Lindelöf’s theorem)")]#text(" ")#metadata(none) <tao-540cb2d1a1eaef2cd1b6>#text(" Let ")#mi("{f}")#text(" be a continuous function on a strip ")#mi("{S := \\{ \\sigma+it: a \\leq \\sigma \\leq b; t \\in {\\bf R} \\}}")#text(" for some ")#mi("{b>a}")#text(", which is holomorphic in the interior of the strip and obeys the bound")

#metadata(none) <tao-e4ee80cfa07821f0bf44>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\left|f(\\sigma+it)\\right| \\leq A \\exp( B \\exp( (1-\\delta) \\frac{\\pi}{b-a} \\left|t\\right|) )", block: true)]]

#text("for all ")#mi("{\\sigma+it \\in S}")#text(" and some constants ")#mi("{A, \\delta > 0}")#text(". Suppose also that ")#tao-math("{\\left|f(a+it)\\right| \\leq M}", block: false)#text(" and ")#tao-math("{\\left|f(b+it)\\right| \\leq M}", block: false)#text(" for all ")#mi("{t \\in {\\bf R}}")#text(" and some ")#mi("{M>0}")#text(". Then we have ")#tao-math("{\\left|f(\\sigma+it)\\right| \\leq M}", block: false)#text(" for all ")#mi("{a \\leq \\sigma \\leq b}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 15")]#text(" The hypothesis ")#link(<tao-e4ee80cfa07821f0bf44>)[#text("(12)")]#text(" is a qualitative hypothesis rather than a quantitative one, since the exact values of ")#mi("{A, B, \\delta}")#text(" do not show up in the conclusion. It is quite a mild condition; any function of exponential growth in ")#mi("{t}")#text(", or even with such super-exponential growth as ")#tao-math("{O( \\left|t\\right|^{\\left|t\\right|})}", block: false)#text(" or ")#tao-math("{O(e^{\\left|t\\right|^{O(1)}})}", block: false)#text(", will obey ")#link(<tao-e4ee80cfa07821f0bf44>)[#text("(12)")]#text(". The principle however fails without this hypothesis, as discussed previously.")
]

#emph[#text("Proof:")]#text(" By shifting and dilating (adjusting ")#mi("{A,B,\\delta}")#text(" as necessary) we can reduce to the case ")#mi("{a = -\\pi/2}")#text(", ")#mi("{b = \\pi/2}")#text(", and by multiplying ")#mi("{f}")#text(" by a constant we can also normalise ")#mi("{M=1}")#text(".")

#text("Suppose we temporarily assume that ")#mi("{f(\\sigma+it) \\rightarrow 0}")#text(" as ")#tao-math("{\\left|\\sigma+it\\right| \\rightarrow \\infty}", block: false)#text(". Then on a sufficiently large rectangle ")#mi("{\\{ \\sigma+it: -\\pi/2 \\leq \\sigma \\leq \\pi/2; -T \\leq t \\leq T \\}}")#text(", we have ")#tao-math("{\\left|f\\right| \\leq 1}", block: false)#text(" on the boundary of the rectangle, hence on the interior by the maximum modulus principle. Sending ")#mi("{T \\rightarrow \\infty}")#text(", we obtain the claim.")

#text("To remove the assumption that ")#mi("{f}")#text(" goes to zero at infinity, we use the ")#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/")[#text("trick of giving ourselves an epsilon of room")]#text(". Namely, we multiply ")#mi("{f(z)}")#text(" by the holomorphic function ")#mi("{g_\\varepsilon(z) := \\exp( -\\varepsilon \\exp(i(1-\\delta/2) z) )}")#text(" for some ")#mi("{\\varepsilon > 0}")#text(". A little complex arithmetic shows that the function ")#mi("{f(z) g_\\varepsilon(z) g_\\varepsilon(-z)}")#text(" goes to zero at infinity in ")#mi("{S}")#text(". (the ")#mi("{\\delta/2}")#text(" term in ")#mi("{g_\\varepsilon}")#text(" is crucial here to get decay all the way up to the edge of the strip ")#mi("{S}")#text(".) Applying the previous case to this function, then taking limits as ")#mi("{\\varepsilon \\rightarrow 0}")#text(", we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 16 (Phragmén-Lindelöf principle in a sector)")]#text(" ")#metadata(none) <tao-dbc9ff5254cac73e64f5>#text(" Let ")#mi("{f}")#text(" be a continuous function on a sector ")#mi("{S := \\{ re^{i\\theta}: r \\geq 0, \\alpha \\leq \\theta \\leq \\beta \\}}")#text(" for some ")#mi("{\\alpha < \\beta < \\alpha + 2\\pi}")#text(", which is holomorphic on the interior of the sector and obeys the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|f(z)\\right| \\leq A \\exp( B \\left|z\\right|^a )", block: true)]]

#text("for some ")#mi("{A,B > 0}")#text(" and ")#mi("{0 < a < \\frac{\\pi}{\\beta-\\alpha}}")#text(". Suppose also that ")#tao-math("{\\left|f(z)\\right| \\leq M}", block: false)#text(" on the boundary of the sector ")#mi("{S}")#text(" for some ")#mi("{M >0}")#text(". Then one also has ")#tao-math("{\\left|f(z)\\right| \\leq M}", block: false)#text(" in the interior.")
]

#emph[#text("Proof:")]#text(" Apply Theorem ")#link(<tao-540cb2d1a1eaef2cd1b6>)[#text("14")]#text(" to the function ")#mi("{f(\\exp(iz))}")#text(" on the strip ")#mi("{\\{ \\sigma+it: \\alpha \\leq \\sigma \\leq \\beta\\}}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" With the notation and hypotheses of Theorem ")#link(<tao-540cb2d1a1eaef2cd1b6>)[#text("14")]#text(", show that the function ")#tao-math("{\\sigma \\mapsto \\sup_{t \\in {\\bf R}} \\left|f(\\sigma+it)\\right|}", block: false)#text(" is ")#link("https://en.wikipedia.org/wiki/Logarithmically_convex_function")[#text("log-convex")]#text(" on ")#mi("{[a,b]}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18 (Hadamard three-circles theorem)")]#text(" Let ")#mi("{f}")#text(" be a holomorphic function on an annulus ")#tao-math("{\\{ z \\in {\\bf C}: R_1 \\leq \\left|z\\right| \\leq R_2 \\}}", block: false)#text(". Show that the function ")#tao-math("{r \\mapsto \\sup_{\\theta \\in [0,2\\pi]} \\left|f(re^{i\\theta})\\right|}", block: false)#text(" is log-convex on ")#mi("{[R_1,R_2]}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19 (Phragmén-Lindelöf principle)")]#text(" Let ")#mi("{f}")#text(" be as in Theorem ")#link(<tao-540cb2d1a1eaef2cd1b6>)[#text("14")]#text(" with ")#mi("{a=0, b=1}")#text(", but with the hypotheses after “Suppose also” in that theorem replaced instead by the bounds ")#tao-math("{\\left|f(0+it)\\right| \\leq C(1+\\left|t\\right|)^{a_0}}", block: false)#text(" and ")#tao-math("{\\left|f(1+it)\\right| \\leq C(1+\\left|t\\right|)^{a_1}}", block: false)#text(" for all ")#mi("{t \\in {\\bf R}}")#text(" and some exponents ")#mi("{a_0,a_1 \\in {\\bf R}}")#text(" and a constant ")#mi("{C>0}")#text(". Show that one has ")#tao-math("{\\left|f(\\sigma+it)\\right| \\leq C^{\\prime} (1+\\left|t\\right|)^{(1-\\sigma) a_0 + \\sigma a_1}}", block: false)#text(" for all ")#mi("{\\sigma+it \\in S}")#text(" and some constant ")#mi("{C^{\\prime}}")#text(" (which is allowed to depend on the constants ")#mi("{A, \\delta}")#text(" in ")#link(<tao-e4ee80cfa07821f0bf44>)[#text("(12)")]#text(", as well as ")#mi("{C,a_0,a_1}")#text("). (Hint: it is convenient to work first in a half-strip such as ")#mi("{\\{ \\sigma+it \\in S: t \\geq T \\}}")#text(" for some large ")#mi("{T}")#text(". Then multiply ")#mi("{f}")#text(" by something like ")#mi("{\\exp( - ((1-z)a_0+z a_1) \\log(-iz) )}")#text(" for some suitable branch of the logarithm and apply a variant of Theorem ")#link(<tao-540cb2d1a1eaef2cd1b6>)[#text("14")]#text(" for the half-strip. A more refined estimate in this regard is ")#link("http://www.ams.org/mathscinet-getitem?mr=117200")[#text("due to Rademacher")]#text(".) This particular version of the principle gives the ")#emph[#text("convexity bound")]#text(" for Dirichlet series such as the Riemann zeta function. Bounds which exploit the deeper properties of these functions to improve upon the convexity bound are known as ")#emph[#text("subconvexity bounds")]#text(" and are of major importance in analytic number theory, which is of course well outside the scope of this course.")
]

#text("Now we can establish a remarkable converse of sorts to Exercise ")#link(<tao-29a071efe595bfa4fb7a>)[#text("2")]#text("(ii) known as the ")#link("https://en.wikipedia.org/wiki/Paley%E2%80%93Wiener_theorem")[#text("Paley-Wiener theorem")]#text(", that links the exponential growth of (the analytic continuation) of a function with the support of its Fourier transform:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 20 (Paley-Wiener theorem)")]#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" be a continuous function obeying the decay condition")

#metadata(none) <tao-8312c5d48baec3e2cb31>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left|f(x)\\right| \\leq C/(1+\\left|x\\right|^2)", block: true)]]

#text("for all ")#mi("{x \\in {\\bf R}}")#text(" and some ")#mi("{C>0}")#text(". Let ")#mi("{M > 0}")#text(". Then the following are equivalent:")

#list(
[#text("(i) The Fourier transform ")#mi("{\\hat f}")#text(" is supported on ")#mi("{[-M,M]}")#text(".")],
[#text("(ii) ")#mi("{f}")#text(" extends analytically to an entire function that obeys the bound ")#tao-math("{\\left|f(z)\\right| \\leq A e^{2\\pi M \\left|z\\right|}}", block: false)#text(" for some ")#mi("{A>0}")#text(".")],
[#text("(iii) ")#mi("{f}")#text(" extends analytically to an entire function that obeys the bound ")#tao-math("{\\left|f(z)\\right| \\leq A e^{2\\pi M \\left|\\mathrm{Im} z\\right|}}", block: false)#text(" for some ")#mi("{A>0}")#text(".")]
)
]

#text("The continuity and decay hypotheses on ")#mi("{f}")#text(" can be relaxed, but we will not explore such generalisations here.")

#emph[#text("Proof:")]#text(" If (i) holds, then by Exercise ")#link(<tao-5d9b17b1c95e575a4e09>)[#text("9")]#text(", we have the inversion formula ")#link(<tao-418df28d06f462b0eb70>)[#text("(4)")]#text(", and the claim (iii) then holds by a slight modification of Exercise ")#link(<tao-29a071efe595bfa4fb7a>)[#text("2")]#text("(ii). Also, the claim (iii) clearly implies (ii).")

#text("Now we see why (iii) implies (i). We first assume that we have the stronger bound ")#metadata(none) <tao-970f519c2cadbcefb1e8>#tao-math("\\displaystyle  \\left|f(z)\\right| \\leq A e^{2\\pi M \\left|\\mathrm{Im} z\\right|} / (1 + \\left|z\\right|^2) \\ \\ \\ \\ \\ (14)", block: false)#text(" ")#text(" for ")#mi("{z \\in {\\bf C}}")#text(". Then we can apply Proposition ")#link(<tao-a5ab5e743434076c5353>)[#text("3")]#text(" for any ")#mi("{a>0}")#text(", and conclude in particular that")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) = e^{-2\\pi b \\xi} \\int_{\\bf R} f(x-ib) e^{-2\\pi i x \\xi}\\ dx")]]

#text("for any ")#mi("{\\xi \\in {\\bf R}}")#text(" and ")#mi("{b \\in {\\bf R}}")#text(". Applying ")#link(<tao-970f519c2cadbcefb1e8>)[#text("(14)")]#text(" and the triangle inequality, we see that")

#align(center)[#tao-fit-display[#tao-math("\\hat f(\\xi) \\lesssim_A e^{-2\\pi b \\xi} e^{2\\pi M \\left|b\\right|}.", block: true)]]

#text("If ")#mi("{\\xi > M}")#text(", we can then send ")#mi("{b \\rightarrow +\\infty}")#text(" and conclude that ")#mi("{\\hat f(\\xi)=0}")#text("; similarly for ")#mi("{\\xi < -M}")#text(" we can send ")#mi("{b \\rightarrow -\\infty}")#text(" and again conclude ")#mi("{\\hat f(\\xi) = 0}")#text(". This establishes (i) in this case.")

#text("Now suppose we only have the weaker bound on ")#mi("{f}")#text(" assumed in (iii). We again use the epsilon of room trick. For any ")#mi("{\\varepsilon>0}")#text(", we consider the modified function ")#mi("{f_\\varepsilon(z) := f(z) / (1 - i \\varepsilon z)^2}")#text(". This is still holomorphic on the lower half-plane ")#mi("{\\{ z: \\mathrm{Im} z \\leq 0 \\}}")#text(" and obeys a bound of the form ")#link(<tao-970f519c2cadbcefb1e8>)[#text("(14)")]#text(" on this half-plane. An inspection of the previous arguments shows that we can still show that ")#mi("{\\hat f_\\varepsilon(\\xi) = 0}")#text(" for ")#mi("{\\xi > M}")#text(" despite no longer having holomorphicity on the entire upper half-plane; sending ")#mi("{\\varepsilon \\rightarrow 0}")#text(" using dominated convergence we conclude that ")#mi("{\\hat f(\\xi) = 0}")#text(" for ")#mi("{\\xi > M}")#text(". A similar argument (now using ")#mi("{1+i\\varepsilon z}")#text(" in place of ")#mi("{1-i\\varepsilon z}")#text(" shows that ")#mi("{\\hat f(\\xi) = 0}")#text(" for ")#mi("{\\xi < -M}")#text(". This proves (i).")

#text("Finally, we show that (ii) implies (iii). The function ")#mi("{f(z) e^{2\\pi i Mz}}")#text(" is entire, bounded on the real axis by ")#link(<tao-8312c5d48baec3e2cb31>)[#text("(13)")]#text(", bounded on the upper imaginary axis by (iii), and has exponential growth. By Corollary ")#link(<tao-dbc9ff5254cac73e64f5>)[#text("16")]#text(", it is also bounded on the upper half-plane, which gives (iii) in the upper half-plane as well. A similar argument (using ")#mi("{e^{-2\\pi i Mz}}")#text(" in place of ")#mi("{e^{2\\pi i Mz}}")#text(") also yields (iii) in the lower half-plane. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 3. The Hardy uncertainty principle — ")]]

#text("Informally speaking, the ")#link("https://en.wikipedia.org/wiki/Uncertainty_principle")[#text("uncertainty principle")]#text(" for the Fourier transform asserts that a function ")#mi("{f}")#text(" and its Fourier transform cannot simultaneously be strongly localised, except in the degenerate case when ")#mi("{f}")#text(" is identically zero. There are many rigorous formulations of this principle. Perhaps the best known is the ")#emph[#text("Heisenberg uncertainty principle")]

#align(center)[#tao-fit-display[#tao-math("(\\int_{\\bf R} (\\xi-\\xi_0)^2 \\left|\\hat f(\\xi)\\right|^2\\ d\\xi)^{1/2} (\\int_{\\bf R} (x-x_0)^2 \\left|f(x)\\right|^2\\ dx)^{1/2} \\geq \\frac{1}{4\\pi} \\int_{\\bf R} \\left|f(x)\\right|^2\\ dx,", block: true)]]

#text("valid for all ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" and all ")#mi("{x_0,\\xi_0 \\in {\\bf R}}")#text(", which we will not prove here (see for instance Exercise 47 of ")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("this previous set of lecture notes")]#text(").")

#text("Another manifestation of the uncertainty principle is the following simple fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 21")]#text(" ")#metadata(none) <tao-9c3aee7110b787f0fb5f>

#list(
[#text("(i) If ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" is an integrable function that has exponential decay in the sense that one has ")#tao-math("{\\left|f(x)\\right| \\leq C e^{-a\\left|x\\right|}}", block: false)#text(" for all ")#mi("{x \\in {\\bf R}}")#text(" and some ")#mi("{C,a>0}")#text(", then the Fourier transform ")#mi("{\\hat f: {\\bf R} \\rightarrow {\\bf C}}")#text(" is either identically zero, or only has isolated zeroes (that is to say, the set ")#mi("{\\{ \\xi \\in {\\bf R}: \\hat f(\\xi) = 0 \\}}")#text(" is discrete).")],
[#text("(ii) If ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" is a compactly supported continuous function such that ")#mi("{\\hat f}")#text(" is also compactly supported, then ")#mi("{f}")#text(" is identically zero.")]
)
]

#emph[#text("Proof:")]#text(" For (i), we observe from Exercise ")#link(<tao-29a071efe595bfa4fb7a>)[#text("2")]#text("(iii) that ")#mi("{\\hat f}")#text(" extends holomorphically to a strip around the real axis, and the claim follows since non-zero holomorphic functions have isolated zeroes. For (ii), we observe from (i) that ")#mi("{\\hat f}")#text(" must be identically zero, and the claim now follows from the Fourier inversion formula (Exercise ")#link(<tao-5d9b17b1c95e575a4e09>)[#text("9")]#text("). ")#mi("\\Box")

#text("Lemma ")#link(<tao-9c3aee7110b787f0fb5f>)[#text("21")]#text("(ii) rules out the existence of a bump function whose Fourier transform is also a bump function, which would have been a rather useful tool to have in harmonic analysis over the reals. (Such functions do exist however in some non-archimedean domains, such as the ")#mi("{p}")#text("-adics.) On the other hand, from Exercise ")#link(<tao-c380779f6175766fdbe9>)[#text("1")]#text(" we see that we do at least have gaussian functions whose Fourier transform also decays as a gaussian. Unfortunately this is basically the best one can do:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 22 (Hardy uncertainty principle)")]#text(" ")#metadata(none) <tao-79c6702755c69af400ba>#text(" Let ")#mi("{f}")#text(" be a continuous function which obeys the bound ")#tao-math("{\\left|f(x)\\right| \\leq C e^{-\\pi ax^2}}", block: false)#text(" for all ")#mi("{x \\in {\\bf R}}")#text(" and some ")#mi("{C,a>0}")#text(". Suppose also that ")#tao-math("{\\left|\\hat f(\\xi)\\right| \\leq C^{\\prime} e^{-\\pi \\xi^2/a}}", block: false)#text(" for all ")#mi("{\\xi \\in {\\bf R}}")#text(" and some ")#mi("{C^{\\prime}>0}")#text(". Then ")#mi("{f(x)}")#text(" is a scalar multiple of the gaussian ")#mi("{e^{-\\pi ax^2}}")#text(", that is to say one has ")#mi("{f(x) = c e^{-\\pi ax^2}}")#text(" for some ")#mi("{c \\in {\\bf C}}")#text(".")
]

#emph[#text("Proof:")]#text(" By replacing ")#mi("{f}")#text(" with the rescaled version ")#mi("{x \\mapsto f(x/a^{1/2})}")#text(", which replaces ")#mi("{\\hat f}")#text(" with the rescaled version ")#mi("{\\xi \\mapsto a^{1/2} \\hat f(a^{1/2} \\xi)}")#text(", we may normalise ")#mi("{a=1}")#text(". By multiplying ")#mi("{f}")#text(" by a small constant we may also normalise ")#mi("{C=C^{\\prime}=1}")#text(".")

#text("From Exercise ")#link(<tao-29a071efe595bfa4fb7a>)[#text("2")]#text("(i), ")#mi("{\\hat f}")#text(" extends to an entire function. By the triangle inequality, we can bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\hat f(\\xi+i\\eta)\\right| \\leq \\int_{\\bf R} e^{-\\pi x^2} e^{2\\pi x \\eta}\\ dx", block: true)]]

#text("for any ")#mi("{\\xi,\\eta \\in {\\bf R}}")#text(". Completing the square ")#mi("{e^{-\\pi x^2} e^{2\\pi x \\eta} = e^{-\\pi (x-\\eta)^2} e^{\\pi \\eta^2}}")#text(" and using ")#mi("{\\int_{\\bf R} e^{-\\pi (x-\\eta)^2}\\ dx = \\int_{\\bf R} e^{-\\pi x^2}\\ dx = 1}")#text(", we conclude the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\hat f(\\xi+i\\eta)\\right| \\leq e^{\\pi \\eta^2}.", block: true)]]

#text("In particular, if we introduce the normalised function")

#align(center)[#tao-fit-display[#mitex("F(z) := e^{\\pi z^2} \\hat f(z)")]]

#text("then")

#metadata(none) <tao-adfb4dbc1416d2300552>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left|F(\\xi+i\\eta)\\right| \\leq e^{\\pi \\xi^2}.", block: true)]]

#text("In particular, ")#tao-math("{\\left|F\\right|}", block: false)#text(" is bounded by ")#mi("{1}")#text(" on the imaginary axis. On the other hand, from hypothesis ")#mi("{F}")#text(" is also bounded by ")#mi("{1}")#text(" on the real axis. We can now ")#emph[#text("almost")]#text(" invoke the Phragmén-Lindelöf principle (Corollary ")#link(<tao-dbc9ff5254cac73e64f5>)[#text("16")]#text(") to conclude that ")#mi("{F}")#text(" is bounded on all four quadrants, but the growth bound we have ")#link(<tao-adfb4dbc1416d2300552>)[#text("(15)")]#text(" is just barely too weak. To get around this we use the epsilon of room trick. For any ")#mi("{\\varepsilon>0}")#text(", the function ")#mi("{F_\\varepsilon(z) := e^{\\pi i\\varepsilon z^2} F(z)}")#text(" is still entire, and is still bounded by ")#mi("{1}")#text(" in magnitude on the real line. From ")#link(<tao-adfb4dbc1416d2300552>)[#text("(15)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|F_\\varepsilon(\\xi+i\\eta)\\right| \\leq e^{\\pi \\xi^2 - 2\\varepsilon \\pi \\xi \\eta}", block: true)]]

#text("so in particular it is bounded by ")#mi("{1}")#text(" on the slightly tilted imaginary axis ")#mi("{(2\\varepsilon + i) {\\bf R}}")#text(". We can now apply Corollary ")#link(<tao-dbc9ff5254cac73e64f5>)[#text("16")]#text(" in the two acute-angle sectors between ")#mi("{(2\\varepsilon+i) {\\bf R}}")#text(" and ")#mi("{{\\bf R}}")#text(" to conclude that ")#tao-math("{\\left|F_\\varepsilon(z)\\right| \\leq 1}", block: false)#text(" in those two sectors; letting ")#mi("{\\varepsilon \\rightarrow 0}")#text(", we conclude that ")#tao-math("{\\left|F(z)\\right| \\leq 1}", block: false)#text(" in the first and third quadrants. A similar argument (using negative values of ")#mi("{\\varepsilon}")#text(") shows that ")#tao-math("{\\left|F(z)\\right| \\leq 1}", block: false)#text(" in the second and fourth quadrants. By Liouville’s theorem, we conclude that ")#mi("{F}")#text(" is constant, thus we have ")#mi("{\\hat f(z) = c e^{-\\pi z^2}}")#text(" for some complex number ")#mi("{c}")#text(". The claim now follows from the Fourier inversion formula (Proposition ")#link(<tao-a5ab5e743434076c5353>)[#text("3")]#text("(iv)) and Exercise ")#link(<tao-c380779f6175766fdbe9>)[#text("1")]#text(". ")#mi("\\Box")

#text("One corollary of this theorem is that if ")#mi("{f}")#text(" is continuous and decays like ")#mi("{e^{-\\pi ax^2}}")#text(" or better, then ")#mi("{\\hat f}")#text(" cannot decay any faster than ")#mi("{e^{-\\pi \\xi^2/a}}")#text(" without ")#mi("{f}")#text(" vanishing identically. This is a stronger version of Lemma ")#link(<tao-9c3aee7110b787f0fb5f>)[#text("21")]#text("(ii). There is a more general tradeoff known as the Gel’fand-Shilov uncertainty principle, which roughly speaking asserts that if ")#mi("{f(x)}")#text(" decays like ")#tao-math("{e^{-\\pi a \\left|x\\right|^p}}", block: false)#text(" then ")#mi("{\\hat f(\\xi)}")#text(" cannot decay faster than ")#tao-math("{e^{-\\pi b \\left|\\xi\\right|^q}}", block: false)#text(" without ")#mi("{f}")#text(" vanishing identically, whenever ")#mi("{1 < p,q < \\infty}")#text(" are dual exponents in the sense that ")#mi("{\\frac{1}{p}+\\frac{1}{q}=1}")#text(", and ")#mi("{a^{1/p} b^{1/q}}")#text(" is large enough (the precise threshold was established in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1574180")[#text("work of Morgan")]#text("). See for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1246419")[#text("this article of Nazarov")]#text(" for further discussion of these variants.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" ")#metadata(none) <tao-5feba1946996521e30af>#text(" If ")#mi("{f}")#text(" is continuous and obeys the bound ")#tao-math("{\\left|f(x)\\right| \\leq C (1+\\left|x\\right|)^M e^{-\\pi ax^2}}", block: false)#text(" for some ")#mi("{M \\geq 0}")#text(" and ")#mi("{C,a>0}")#text(" and all ")#mi("{x \\in {\\bf R}}")#text(", and ")#mi("{\\hat f}")#text(" obeys the bound ")#tao-math("{\\left|\\hat f(\\xi)\\right| \\leq C^{\\prime} (1+\\left|\\xi\\right|)^M e^{-\\pi \\xi^2/a}}", block: false)#text(" for some ")#mi("{C^{\\prime}>0}")#text(" and all ")#mi("{\\xi \\in {\\bf R}}")#text(", show that ")#mi("{f}")#text(" is of the form ")#mi("{f(x) = P(x) e^{-\\pi ax^2}}")#text(" for some polynomial ")#mi("{P}")#text(" of degree at most ")#mi("{M}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" In this exercise we develop an alternate proof of (a special case of) the Hardy uncertainty principle, which can be found in the original ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1574130")[#text("paper of Hardy")]#text(". Let the hypotheses be as in Theorem ")#link(<tao-79c6702755c69af400ba>)[#text("22")]#text(".")

#list(
[#text("(i) Show that the function ")#mi("{F(s) := (s+a)^{1/2} \\int_{\\bf R} e^{-\\pi s x^2} f(x)\\ dx}")#text(" is holomorphic on the region ")#mi("{\\{ s \\in {\\bf C}: \\mathrm{Re}(s) > -a \\}}")#text(" and obeys the bound ")#tao-math("{\\left|F(s)\\right| \\lesssim C \\frac{\\left|s+a\\right|^{1/2}}{\\left|\\mathrm{Re}(s)+a\\right|^{1/2}}}", block: false)#text(" in this region, where we use the standard branch of the square root.")],
[#text("(ii) Show that the function ")#mi("{\\tilde F(s) := (1 + a/s)^{1/2} \\int_{\\bf R} e^{-\\pi \\xi^2/s} \\hat f(\\xi)\\ d\\xi}")#text(" is holomorphic on the region ")#mi("{\\{ s \\in {\\bf C} \\backslash \\{0\\}: \\mathrm{Re}(1/s) > -1/a \\}}")#text(" and obeys the bound ")#tao-math("{\\left|\\tilde F(s)\\right| \\lesssim C \\frac{\\left|1+a/s\\right|^{1/2}}{\\left|\\mathrm{Re}(1/s)+1/a\\right|^{1/2}}}", block: false)#text(" in this region.")],
[#text("(iii) Show that ")#mi("{F}")#text(" and ")#mi("{\\tilde F}")#text(" agree on their common domain of definition.")],
[#text("(iv) Show that the functions ")#mi("{F,\\tilde F}")#text(" are constant. (You may find Exercise 13 from ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("246A Notes 4")]#text(" to be useful.)")],
[#text("(v) Use the above to give an alternate proof of Theorem ")#link(<tao-79c6702755c69af400ba>)[#text("22")]#text(" in the case when ")#mi("{f}")#text(" is even. (")#emph[#text("Hint:")]#text(" subtract a constant multiple of a gaussian from ")#mi("{f}")#text(" to make ")#mi("{F}")#text(" vanish, and conclude on Taylor expansion around the origin that all the even moments ")#mi("{\\int_{\\bf R} x^{2k} f(x)\\ dx}")#text(" vanish. Conclude that the Taylor series coefficients of ")#mi("{\\hat f}")#text(" around the origin all vanish.)")]
)

#text("It is possible to adapt this argument to also cover the case of general ")#mi("{f}")#text(" that are not required to be even; see the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1574130")[#text("paper of Hardy")]#text(" for details.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" (This problem is due to Tom Liggett; see ")#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/")[#text("this previous post")]#text(".) Let ")#mi("{a_0,a_1,\\dots}")#text(" be a sequence of complex numbers bounded in magnitude by some bound ")#mi("{M}")#text(", and suppose that the power series ")#mi("{f(t) := \\sum_{n=0}^\\infty a_n \\frac{t^n}{n!}}")#text(" obeys the bound ")#tao-math("{\\left|f(t)\\right| \\leq C e^{-t}}", block: false)#text(" for all ")#mi("{t \\geq 0}")#text(" and some ")#mi("{C>0}")#text(".")

#list(
[#text("(i) Show that the Laplace transform ")#mi("{{\\mathcal L} f(s) := \\int_0^\\infty f(t) e^{-st}\\ dt}")#text(" extends holomorphically to the region ")#mi("{\\{ s: \\mathrm{Re}(s) > -1 \\}}")#text(" and obeys the bound ")#tao-math("{\\left|{\\mathcal L} f(s)\\right| \\leq \\frac{C}{1+\\mathrm{Re}(s)}}", block: false)#text(" in this region.")],
[#text("(ii) Show that the function ")#mi("{\\tilde F(s) := \\sum_{n=0}^\\infty \\frac{a_n}{s^{n+1}}}")#text(" is holomorphic in the region ")#tao-math("{\\{ s: \\left|s\\right| > 1\\}}", block: false)#text(", obeys the bound ")#tao-math("{\\left|\\tilde F(s)\\right| \\leq \\frac{M}{\\left|s\\right|-1}}", block: false)#text(" in this region, and agrees with ")#mi("{{\\mathcal L} f(s)}")#text(" on the common domain of definition.")],
[#text("(iii) Show that ")#mi("{{\\mathcal L} f(s)}")#text(" is a constant multiple of ")#mi("{\\frac{1}{1+s}}")#text(".")],
[#text("(iv) Show that the sequence ")#mi("{a_n}")#text(" is a constant multiple of the sequence ")#mi("{(-1)^n}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 26")]#text(" There are many further variants of the Hardy uncertainty principle. For instance we have the following uncertainty principle of Beurling, which we state in a strengthened form due ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1993414")[#text("to Bonami, Demange, and Jaming")]#text(": if ")#mi("{f}")#text(" is a square-integrable function such that ")#tao-math("{\\int_{\\bf R} \\int_{\\bf R} \\frac{\\left|f(x)\\right| \\left|\\hat f(\\xi)\\right|}{(1+\\left|x\\right|+\\left|\\xi\\right|)^N} e^{2\\pi \\left|x\\right| \\left|\\xi\\right|}\\ dx d\\xi < \\infty}", block: false)#text(", then ")#mi("{f}")#text(" is equal (almost everywhere) to a polynomial times a gaussian; it is not difficult to show that this implies Theorem ")#link(<tao-79c6702755c69af400ba>)[#text("22")]#text(" and Exercise ")#link(<tao-5feba1946996521e30af>)[#text("23")]#text(", as well as the Gel’fand-Shilov uncertainty principle. In recent years, PDE-based proofs of the Hardy uncertainty principle have been established, which have then been generalised to establish uncertainty principles for various Schrödinger type equations; see for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2500494")[#text("this review article of Kenig")]#text(". I also have some older notes on the Hardy uncertainty principle in ")#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/")[#text("this blog post")]#text(". Finally, we mention the ")#emph[#text("Beurling-Malliavin theorem")]#text(", which provides a precise description of the possible decay rates of a function whose Fourier transform is compactly supported; see for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2241422")[#text("this paper of Mashregi, Nazarov, and Khavin")]#text(" for a modern treatment.")
]

#heading(level: 1)[#text("Comments (38)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e13182a44f061c8601df5e94f22e72296f833f4520df4541d553abd1d800ae6d-d61f54a7c7316c5d6beeb53fc2349dfd34e87cbd7cb78d48522eb5466abf1291.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michele Nardelli, Antonio Nardelli")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-620201")[#strong[#text("Michele Nardelli, Antonio Nardelli")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2021")])]

#text("Dear Terence,")#linebreak()#text(" The topic of this very interesting post, can be applied also to the some sectors of theoretical physics? Regards")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/94804ce776cb6dfc72b7f0d4c529c12c2983d60aabc9a3e8833a6b77154c116d-8c46e7395d6aedef3f1686928862ebdebfb269e2f15b023c4ec2e413fef28d10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DiscoverReality Clover")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-620910")[#strong[#text("DiscoverReality Clover")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2021")])]

#text("Yes. I think that it is possible. It seems possible to conjecture that, based on this bound, there is a minimum pressure for a de-pressurising thermal system.")#linebreak()#text(" For example, based on this, one can show that if you pop a pressurised balloon (thermal system) in a vacuum then it obeys Newton’s first law – a body stays in motion… – by showing that the pressure inside the balloon does not go to zero. It approaches a minimum, hence the balloon stays in motion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e13182a44f061c8601df5e94f22e72296f833f4520df4541d553abd1d800ae6d-d61f54a7c7316c5d6beeb53fc2349dfd34e87cbd7cb78d48522eb5466abf1291.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-620913")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2021")])]

#text("Thank you very much! Regards")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-620228")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2021")])]

#text("Typos in third bullet point: the integral sign ")#mi("\\int")#text(" in the wrong place.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-620229")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2021")])]

#text("At the beginning for ")#mi("f_1")#text(" and ")#mi("f_2")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-620511")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2021")])]

#text("Typo ")#mi("= - =")#text(" in ")#mi("f_2")

#emph[#text("[Corrected – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-620269")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2021")])]

#text("In the introduction of this notes, I am not sure about the proof of the “conversely” direction in (i),(ii),(iii). It is not intuitive for a sequence to satisfy certain property that it has to arise from a series of a particular form. How do we prove such statement? Say the converse direction in (i)? (Sorry, should have asked about Exe.5 from notes 4 last quarter).")

#emph[#text("[These are immediate from Proposition 7 and Theorem 15 from ")#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/")[#text("Notes 1")]#text(" of the previous quarter’s notes. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-620298")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2021")])]

#text("Hello,")#linebreak()#text(" In the point (iii) there is a typo for defn of f_1 and f_2. 2πi should replace by 1/2πi and unfortunately integral signs are not in right pisition.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e13182a44f061c8601df5e94f22e72296f833f4520df4541d553abd1d800ae6d-d61f54a7c7316c5d6beeb53fc2349dfd34e87cbd7cb78d48522eb5466abf1291.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-620464")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2021")])]

#text("Dear Prof. Tao")#linebreak()#text(" I’ve read this your very interesting Note. What other note or papers of yours can you recommend me to consult in order to delve into these interesting topics? I’m grateful if You can show/suggest me other Your papers regarding this subject, All my best wishes for your works and all my esteem and gratitude,")#linebreak()#text(" All the best")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-620737")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2021")])]

#text("A simple heuristic interpretation of Poisson summation formula (6) is by observing that it can be written as")

#text("(6′) ")#mi("\\int_{\\mathbb R} f d\\mu = \\int_{\\mathbb R} \\hat{f} d\\mu")

#text("where ")#mi("\\mu")#text(" is a nonnegative (singular) measure supported on the integers and has a unit measure on each integer.")

#text("It is not difficult to verify that ")#mi("\\mu")#text(" is invariant under the Fourier transform, so (6′) is equivalent to")

#text("(6”) ")#mi("\\int f d\\mu = \\int \\hat{f} d\\hat{\\mu}")

#text("Which (at least heuristically) follows from Plancherel’s theorem on the invariance of inner products in ")#mi("L^2(\\mathbb R)")#text(" under Fourier transform.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-621961")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2021")])]

#text("This is nice! Thank you.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-620778")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2021")])]

#text("Title of this notes: “factorisation” should be factorization.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-620987")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2021")])]

#text("This is for 246B, Notes 1: —")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/94804ce776cb6dfc72b7f0d4c529c12c2983d60aabc9a3e8833a6b77154c116d-8c46e7395d6aedef3f1686928862ebdebfb269e2f15b023c4ec2e413fef28d10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DiscoverReality Clover")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-620945")[#strong[#text("DiscoverReality Clover")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2021")])]

#text("Dear All,")

#text("I apologise for accidentally rating my own comment – an action which l couldn’t undo.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-621432")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2021")])]

#text("It is interesting to observe that both the Fourier and Hilbert transforms, as linear operators on ")#mi("L^2(\\mathbb R)")#text(", have the property that their fourth power is the identity operator.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-621447")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2021")])]

#text("Hi Terence Tao. I am only 14, but I understand the fundamentals of this maths work. Please can you teach me more about this. Thank you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f33db6ba46dd8093e0e8d2d7190033d0ff680310df51bed189735e7cacc5cd24-bcb0d6d261681b2347f8df2631d1b0529236312dd801712377ed3123f307ca31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jim Hefferon")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-621829")[#strong[#text("Jim Hefferon")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2021")])]

#text("Not about this article. The link to “Cult of Genius” in the sidebar has changed. A litle googling found that it is now ")#link("https://www.discovermagazine.com/mind/the-cult-of-genius")[#text("https://www.discovermagazine.com/mind/the-cult-of-genius")]#text(". Regards.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-621960")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2021")])]

#text("Just some nitpicking: in point ii towards the beginning of the post, one should have ")#mi("r < R")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-621977")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2021")])]

#text("At the end of today’s lecture, you mentioned that Fourier transform is the rotation of the function by 90 degrees in phase space, which gives a good interpretation that take Fourier transform 4 times gets back the original function. Detailed proof involves micro local analysis and something about symplectic structure. Could you provide some reference on this topic? It is a very interesting subject.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-621998")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2021")])]

#text("In the physics literature this is known as the ")#link("https://en.wikipedia.org/wiki/Phase-space_formulation")[#text("phase space formulation")]#text(" of quantum mechanics, and the ")#link("https://en.wikipedia.org/wiki/Wigner_quasiprobability_distribution")[#text("Wigner quasiprobability distribution")]#text(" can be used as a candidate for the “phase space transform” of a function, though it is not the only such choice. A more mathematical treatment of some of these ideas can be found in Folland’s “Harmonic analysis in phase space”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-622118")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2021")])]

#text("Doesn’t the proof of Exercise 2 part i follow directly by putting ")#mi("\\xi")#text(" to be a complex number and then utilising the super-exponential decay of ")#mi("f")#text(" to obtain a bound for the integral displayed on the RHS of equation 3 (for instance by using the dominated convergence theorem), and then conclude that ")#mi("\\hat{f}")#text(" defined in this way will be entire by observing that what we did actually implies that ")#mi("\\hat{f}")#text(" has no poles or other types of singularities.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-622119")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2021")])]

#text("Or once we define ")#mi("\\hat{f}")#text(" in this way, we can also use the second funadamental theorem of calculus to obtain the claim.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-622145")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2021")])]

#text("I think what you wrote above is correct, and then we can use the second fundamental theorem of calculus to conclude that ")#mi("\\hat{f}")#text(" defined in this way will be holomorphic.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-622125")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2021")])]

#text("You mentioned in class yesterday that we use Harr measure for the Mellin transform on the half line because Harr measure is scaling invariant, and Lebesgue measure is translation invariant. Translation invariant property is more useful on the whole real line, and not very useful on the half line. Please elaborate on this. Don’t we define the Laplace transform on the half line using Lebesgure measure?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-622140")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2021")])]

#text("One can still try to exploit translation invariance on the half-line, but one picks up additional terms at the boundary which complicate things a little. Compare for instance the effects of differentiation or translation on the Laplace transform displayed in the table in ")#link("https://en.wikipedia.org/wiki/Laplace_transform#Properties_and_theorems")[#text("https://en.wikipedia.org/wiki/Laplace_transform#Properties_and_theorems")]#text(" with the corresponding properties for the Fourier transform in ")#link("https://en.wikipedia.org/wiki/Fourier_transform#Basic_properties")[#text("https://en.wikipedia.org/wiki/Fourier_transform#Basic_properties")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-622177")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2021")])]

#text("In ii of Exercise 2 shouldn’t we have ")#mi("\\lesssim _{f,M}")#text(" instead of ")#mi("\\lesssim _f")#text(" ?")

#emph[#text("[As it turns out, one does not need a dependence on ")#mi("M")#text(" here. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-622180")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2021")])]

#text("In ii of Exercise 2 I think we should have ")#tao-math("\\left| \\hat{f} ( \\xi ) \\right| \\lesssim", block: false)#text("….. .")

#emph[#text("[Here we use ")#mi("X \\lesssim Y")#text(" to denote the estimate ")#tao-math("\\left|X\\right| \\leq CY", block: false)#text(" (that is, the absolute values are implicit in the notation) -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 4: The Riemann zeta function and the prime number theorem | What's new")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-622258")[#strong[#text("246B, Notes 4: The Riemann zeta function and the prime number theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("[…] function for imaginary values of the argument in the upper half-plane (so ); from Exercise 7 of Notes 2 we have the modularity […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-622312")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2021")])]

#text("In the 4th line of the proof of part (iv.) in Proposition 3, the second integral should be over ")#mi("\\gamma _{-R + i \\varepsilon \\to R + i \\varepsilon}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-622314")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2021")])]

#text("Here we see a proof of the Fourier inversion theorem which becomes easy if one uses the tools from complex analysis as demonstrated above in the proof of Proposition 3.")#linebreak()#text(" We also know that for the discrete setting we can give a proof of the Fourier inversion formula which uses some algebraic manipulations and orthogonality properties.")

#text("In general is there a unified approach to prove Fourier inversion type results?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-622346")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2021")])]

#text("There are various ways to establish Plancherel’s theorem (which includes the Fourier inversion formula as a component) on arbitrary locally compact abelian (LCA) groups; see Section 4 of ")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("these notes")]#text(" for a brief discussion of two approaches, one using Gelfand theory, and another via Bochner’s theorem. For special groups such as the real line or the circle there are shortcuts available that utilise special features of those groups, such as the presence of gaussians or holomorphic extensions to various regions of the complex plane, but these do not seem to generalise well to the LCA setting, which seems to be the most natural framework in which to present Fourier analysis in a unified manner.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-622529")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2021")])]

#text("About the Beurling uncertainty principle [Remark 26], how do you get the hyperbola geometric interpretation phase portrait? Does it follow directly from the square integrability condition? I know ")#mi("f(x)")#text(" and ")#mi("F(\\xi)")#text(" are kind of “inverse” to each other.")

#emph[#text("[It arises from consideration of where the weight ")#tao-math("e^{2\\pi \\left|x\\right| \\left|\\xi\\right|}", block: false)#text(" is exponentially large. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Course announcement: 246B, complex analysis | What's new")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-622824")[#strong[#text("Course announcement: 246B, complex analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("[…] Connections with the Fourier transform on the real line; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 1: Zeroes, poles, and factorisation of meromorphic functions | What's new")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-622828")[#strong[#text("246B, Notes 1: Zeroes, poles, and factorisation of meromorphic functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("[…] Previous set of notes: 246A Notes 5. Next set of notes: Notes 2. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 3: Elliptic functions and modular forms | What's new")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-622830")[#strong[#text("246B, Notes 3: Elliptic functions and modular forms | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("[…] set of notes: Notes 2. Next set of notes: Notes […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d7c1b6cb2355225c4aa81f58c25106da2b399f567af87a7508495d00d6e5f26-19de1650d1de83dd1fdbf582eeadeff0ce510532025de0101576a5993fd23004.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quan")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-639515")[#strong[#text("Quan")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2022")])]

#text("Dear Professor Tao,")#linebreak()#text(" In the Laplace transform problem, one comes up with a different restriction for {f} that {f} is continuously differentiable and {\\vert f(x)e^{-xt}\\vert \\leq \\frac{C_t}{1+x^2}, \\forall t \\in {\\bf R} (1)}. Then, we construct a compactly supported function {h(x)} that agrees with {2\\pi f(2\\pi x)e^{-2\\pi xt}} when {x\\geq 0} for the purpose of applying Fourier transform (modify the proof of excercise 9 for function with contable discontinuities), and one can obtain the Laplace transform for the class of function satisfies (1). Is this approach valid? Thank you for your time, professor.")

#emph[#text("[Large parts of Exercise 10 would still be valid under these more general hypotheses on ")#mi("f")#text(", though perhaps not all. It would be a instructive exercise for you to work out the details. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d7c1b6cb2355225c4aa81f58c25106da2b399f567af87a7508495d00d6e5f26-19de1650d1de83dd1fdbf582eeadeff0ce510532025de0101576a5993fd23004.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quân Nguyễn")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-639663")[#strong[#text("Quân Nguyễn")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2022")])]

#text("I think the proof that Exercise 9 can still be applied for the Laplace inverse transform (exercise 10) if we withdraw the condition of $f$ being differentiable.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18cefad0750f9cee30c24966f2668c3334a909ce302173e43d2aab8320c63b7f-a6e70e9d7df5095256810a0319007c30e49b320db8fadf03f753d6483ff37b52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of khaledalekasir")]], [#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/#comment-687862")[#strong[#text("khaledalekasir")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2025")])]

#text("Equation (2) needs to be corrected to ")#mi("\\liminf_{n \\to- \\infty} . . .")#text(" for the negative part.")

#emph[#text("[Corrected, thanks – T.]")]
]
