// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/27/cognitive-sanctuaries-or-manifesto-of-the-department-chair/
// Converted to Typst by tao2typ: "2026-10-14T16:39:34.924031+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Cognitive Sanctuaries or: Manifesto of the Department Chair", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Cognitive Sanctuaries or: Manifesto of the Department Chair")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/27/cognitive-sanctuaries-or-manifesto-of-the-department-chair/")[#text("https://terrytao.wordpress.com/2026/09/27/cognitive-sanctuaries-or-manifesto-of-the-department-chair/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://astro.washington.edu/people/jessica-werk")[#text("Jess Werk")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("Hello, I am Jess Werk, professor and chair of Astronomy at the University of Washington. Astronomy may interest mathematicians right now because our field has already been reshaped by supercomputers and survived to tell the tale. Our ")#link("https://www.tng-project.org/")[#text("magneto-hydrodynamic simulations")]#text(", built on the Navier-Stokes equations (plus lots of other “subgrid” physics), are run for over a hundred million core-hours, and produce emergent astrophysics that takes us years to understand and verify. They do not replace analytic theory; they complement it. The ")#link("https://rubinobservatory.org/")[#text("Rubin Observatory’s")]#text(" nightly stream of sky survey data, petabytes over the life of the project, would be unusable without advancements in cloud storage and AI algorithms. Astronomers were early adopters of machine-learning techniques because we have a whole Universe’s worth of beautiful data, and our space telescopes are built at the edge of what is technically feasible (e.g. the ")#link("https://www.flickr.com/photos/nasawebbtelescope/albums/72177720331299130/")[#text("James Webb Space Telescope")]#text(", and the ")#link("https://science.nasa.gov/astrophysics/programs/habitable-worlds-observatory/")[#text("Habitable Worlds Observatory")]#text(" now being designed). We are generally a technology-forward field, but a growing number of us see AI-enabled workflows as a risk to the profession. I will tell you what I think that risk is, and then put on my department chair hat and tell you what I am doing about it. My optimism is intact because it has to be.")

#text("As scientists, we design our experiments around an unattainable ideal: an objective and mindless observer from nowhere, studying a reality that exists separately from our subjective understanding of it. As creatures who study the cosmos from a relatively tiny rock, 93 million miles from the nearest star, embedded within the roiling gases of the Galactic interstellar medium produced by hundreds of billions of gasping stars, some fraction of which violently explode, we astronomers appreciate the physical impossibility of the observer from nowhere (and yet we endeavor to achieve it!). Thomas Nagel writes about the paradox of The View from Nowhere and argues later, in Mind and Cosmos, that an intelligible natural order which produces minds capable of understanding it is itself something that requires explanation. Intelligibility is the biological mind’s responsibility; every experiment we design must be understood by someone because that is what gives science its purpose. Generative AI attempts to embody the mindless observer from nowhere. Its achievements in both mathematics and science reveal the incompleteness of this long-held ideal and underscore the importance of human scientists and mathematicians, whose minds make results and proofs meaningful.")

#metadata(none) <tao-98e7f74e6cde092d7845>

#text("The marketing for and media coverage of generative AI invite a belief that the speed and volume of its output render slow human understanding meaningless. Thankfully, ")#link("https://mathandai.org/")[#text("mathematicians have already begun to reject this idea")]#text(". In astronomy, the result plays the role of the theorem: a paper is judged on what it found, how significant it was, and whether it found it first, far more than on what the finding means. The result serves as a ")#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/")[#text("proxy for understanding")]#text(", and that proxy is now a problem (Kra, B., 2026). Across academia, incentive structures have long rewarded productivity over understanding, and generative AI now makes productivity easy to manufacture. Together, the two effects undermine the perceived value of doctoral-level study. Rather than swiftly implementing field-wide changes to our systems, I argue that protecting the Ph.D. requires simple, department-level fortifications that we can all make now. Together, these structural fortifications make up a model I have started calling the cognitive sanctuary.")

#text("Under the current productivity-weighted model, the technical debt that Henry Cohn describes in ")#link("https://terrytao.wordpress.com/2026/09/15/the-technical-debt-of-ai-generated-mathematics/")[#text("his blog post")]#text(" is borne by the most vulnerable members of our community. Ph.D. students compete for postdocs on the number of their publications; postdocs compete for faculty jobs on their h-indices; early-career faculty are judged on the dollar value of their grants (funders, in turn, count our “research products” which are ingested into a database) and the quantity of their scholarly output (including the number of Ph.D. students trained). These metrics do not measure or reward scientific merit. Citations accrue to papers that are already well-cited (e.g. Merton 1968, ")#link("https://www.jstor.org/stable/1723414")[#text("The Matthew Effect in Science")]#text("), so the h-index inherits and magnifies biases present in the field (e.g. ")#link("https://pubmed.ncbi.nlm.nih.gov/16701079/")[#text("Kelly and Jennions 2006")]#text(", ")#link("https://www.nature.com/articles/s41550-017-0141")[#text("Caplar, Tacchella and Birrer 2017")]#text("). In the meantime, the literature keeps growing: astronomy arXiv submissions rose 14% from 2024 to 2025 (")#link("https://arxiv.org/abs/2602.12303")[#text("Lewis, Shah and Alfred 2026")]#text(") and more than half of the papers posted in 2025 are written with language-model assistance (")#link("https://arxiv.org/abs/2609.10664")[#text("Saad and Ting 2026")]#text("). Only about one paper in 66 that uses these AI tools declares it, a gap Saad and Ting attribute to failing disclosure norms and I would also attribute to perceived stigma. The people with the strongest incentive to use these tools and hide that they have done so are the same ones under the most pressure to publish: our students and early-career scientists. Unfortunately, they pay twice. Those who are still building new skills are the ones most likely to suffer “cognitive debt” from an overreliance on an LLM (e.g. ")#link("https://arxiv.org/abs/2506.08872")[#text("Kosmyna et al. 2025")]#text("; ")#link("https://doi.org/10.1073/pnas.2422633122")[#text("Bastani et al. 2025")]#text(") and they will also face the steepest professional consequences for failing to declare its use (e.g., ")#link("https://journals.aas.org/referee-llm-guidelines")[#text("forced retractions and publication bans")]#text(").")

#text("Scientific and mathematical thought relies on our collective judgment being tested, then re-tested and held up continually against alternative explanations. Our workflows, increasingly built on technology, have been streamlined to enable first discoveries and to decorate them with our own names. The slower, iterative processes of refining theories and interpreting data are relegated to methods sections that a few people might read, if they appear at all in the publication. A paper is rarely dedicated to showing how a particular idea turned out to be wrong after a careful analysis. “Nobody has time for that,” we think. The struggle of doing science is the struggle of learning, and it is also where the joy of discovery lives. A cognitive sanctuary, therefore, must reward the effort and celebrate a process that includes failure. It is a space that encourages unhurried thinking with plenty of room for rabbit holes and the occasional mad hatter.")

#text("Unlike a mad hatter, agentic AI creates a chain of probabilistic decisions and steers users away from the improbable. Some of my colleagues have envisioned a future in which student learning centers on individualized, guided conversations with an “Agentic Professor” (")#link("https://er.educause.edu/articles/2026/9/the-agentic-professor-exploring-genai-supported-futures-in-higher-education")[#text("Cornillon and Prochaska 2026")]#text("). In this future, the ability to derive and manipulate equations becomes secondary, and it is assumed that the capacity to interrogate a hypothesis, a necessary Ph.D.-level skill, can be built without the practice of trying and failing and trying and failing and trying and eventually succeeding. Sam Altman envisions a personal AI team for everyone and a virtual tutor for every child (")#link("https://ia.samaltman.com/")[#text("Altman, S 2024")]#text("). Taken to its end, the vision leaves no Ph.D. advisor to serve as a witness to the student’s judgment, and no one to vouch that the student can be trusted to produce and judge knowledge. I reject this future. The Ph.D. student cannot supervise mathematics without being able to produce it themselves through “active shaping of experience performed in the pursuit of knowledge” (Polanyi, M. 1966). Practice builds a tacit element of understanding that my field calls physical intuition. Nothing yet shows that physical intuition can be developed through closed-loop agentic AI conversations, and recent evidence points in the opposite direction (")#link("https://doi.org/10.1073/pnas.2422633122")[#text("Bastani et al. 2025")]#text("). Interrogation is best practiced among other scientists who can offer surprising alternatives and explanations (sometimes incorrect!), while an AI agent’s alternatives are drawn from the distribution of what has already been written. Our system of knowledge depends upon the Ph.D. and the Ph.D. depends upon iterative judgment of people who already have it.")

#text("And the people who have that judgment already work down the hall from you. Academic departments bring together kindred spirits and support many of the structures a cognitive sanctuary needs: we host seminars, discussions, hack-a-thons, and community events designed to honor thinking minds. What I see as a department chair is that the senior faculty with the most recognition are often the ones who use these structures least. Nobody wins an award for being a department chair, as I sadly have discovered, and the work of showing up to preprint discussions carries no service credit. When you are leading national committees and international collaborations, it is easy to justify skipping colloquium or a lunch talk for the hour gained in research productivity. Faculty are expected to do too much, and being overachievers, we do even more. Held against all that external and often unpaid labor, taking time to honor a half-formed thought process looks like an unaffordable luxury. Meanwhile, Ph.D. students are craving opportunities to interact with the senior faculty who are so often absent from department life. A department that works as a cognitive sanctuary gives senior faculty the cover to decline some external work, and it counts showing up for junior colleagues as critical service.")

#text("At our Astronomy faculty retreat on September 17, we discussed a scenario modeled on what is happening in mathematics. Briefly, OpenAI posts a preprint, press release, and public decision log of 40,000 steps reporting a five-sigma detection of an evolving dark energy equation of state, inconsistent with a cosmological constant, with error bars a factor of 2.5 tighter than anything our community could achieve from the same public data, drawn from ")#link("https://rubinobservatory.org/explore/how-rubin-works/lsst")[#text("a future survey")]#text(" in which our department has already invested heavily. None of the faculty were especially fazed and none thought the scenario to be implausible. Although they are all using AI in their research to different degrees, the faculty broadly agreed on four ideas:")

#enum(start: 1, 
[#text("Generative AI is changing who has access to discovery, and early-career scientists face the steepest barriers.")],
[#text("The interpretation of a discovery is more valuable than the discovery itself, and how we figure something out matters more than what we figure out.")],
[#text("Scientific writing is best when it is slow and iterative because the writing refines the science (")#link("https://www.americanscientist.org/blog/the-long-view/the-science-of-scientific-writing")[#text("Gopen and Swan 1990")]#text(").")],
[#text("Verifying someone else’s work is less rewarding than doing your own, so a field that is about to depend on verification more than ever must reward it deliberately.")]
)

#text("A cognitive sanctuary protects the thought process, for everyone in the department, but above all, for Ph.D. students. The ")#link("https://cmsa.fas.harvard.edu/media/2026/09/Summit-on-PhD-Math-Education-in-the-Age-of-AI.pdf")[#text("Harvard Summit on PhD Math Education in the Age of AI")]#text(" met on the same day as our astronomy faculty retreat, and reached many of the same conclusions about assessment and AI use; it does not address faculty incentives, which is where much of the department’s leverage lies. Below are several practical suggestions for how to build a cognitive sanctuary in your own department. They fall into three groups: Ph.D. processes, faculty reward systems, and department community.")

#strong[#text("Ph.D. Processes")]

#enum(start: 1, 
[#text("Develop detailed rubrics for both the dissertation and the defense that distinguish a pass from a conditional pass from a failure. One dimension, for example, is whether the student can state the competing interpretations of the result and say what measurement would distinguish them. Require committee members to score the rubric independently before any closed-door discussion. Following a successful defense, require the committee to sign a short report stating what the student demonstrated. The report can go into recommendation letters, and it gives hiring committees something other than a publication list to read. Post the rubric and the evaluation process on the department website.")],
[#text("Design any evaluation checkpoints (e.g. qualifying exams, required committee meetings) to be conducted live, preferably in person, and unassisted.")],
[#text("Remove any requirement that a student publish a paper to advance to candidacy. Do not push students to submit publications early, before interpretations have been discussed and worked out. Encourage faculty and Ph.D. students to submit short write-ups of ideas that did not pan out.")],
[#text("Ask Ph.D. candidates to explain their work at the board, in group meetings and once a year to the whole department. Explaining an idea to a room of scientists helps refine it, and explaining how an idea turned out to be wrong is part of learning. Ask faculty to provide feedback on the substance of the explanation, not the delivery.")],
[#text("Set clear boundaries on AI use in Ph.D. research to honor the learning process. These boundaries apply to advisors and external collaborators as well as to students. Agree that advisors will not send students feedback that is written with generative AI. Agree that students will not send advisors text or analysis generated by AI.")],
[#text("Teach students to interrogate AI model outputs on well-understood problems and build these skills in coursework, and group and one-on-one meetings.")]
)

#strong[#text("Faculty Reward Systems")]

#enum(start: 1, 
[#text("Define unit-level promotion and tenure criteria that consider Ph.D. student mentoring to be at least as important as a prestigious award or large grant.")],
[#text("Publicly post faculty department service assignments, and weight Ph.D. student advising and committee work more heavily than external service (including university-level service). Provide service credits for faculty who commit to regularly show up to key department events (e.g. chalkboard talks, colloquium).")],
[#text("Develop a teaching policy that includes credit for Ph.D. student advising and committee work. For example, a faculty member who sits on three or more Ph.D. committees in each of two consecutive years is offered a quarter of teaching relief once every 2 years.")],
[#text("Set an expected external service load for faculty that they may cite when they decline invitations. Encourage faculty to report declined external service alongside accepted service in their annual merit reports.")]
)

#strong[#text("Department Community")]

#enum(start: 1, 
[#text("Create opportunities for meaningful connection among senior faculty and students, e.g. department coffee hours, potlucks, celebrations of student milestones.")],
[#text("Thoughtfully design colloquium and seminars with time for discussion, including dedicated time for Ph.D. students to meet with speakers. Commit to showing up yourself, even when speakers are discussing a topic outside of your area of expertise.")],
[#text("Set a department-wide standard that no one uses AI-generated text in research publications, except for disclosed, light use for editing, grammar, or translation.")],
[#text("Develop department-specific policies on generative AI use and have regular discussions with faculty on whether these policies are achieving their stated purpose.")]
)

#text("None of these suggested structural fortifications presents a case against generative AI, a remarkable tool that can improve the practice of science and mathematics and reduce the burden of some administrative tasks. Cognitive sanctuaries encourage its use in the open, especially where nothing the student is supposed to be learning is at stake. The suggestions above do not address structural problems in our fields that will be amplified by AI. They will not themselves generate much-needed funding for basic science and mathematics at the national level. They cannot solve emerging issues in grade-school education that increasingly relies on AI.")

#text("Departments, and the Ph.D. students they educate, sit where all the above challenges meet. They absorb the funding cuts and receive the students that grade-school education produces. As we create microcosms of joy and learning in our departments, I hope that we can gradually steer universities toward rewarding process. Cognitive sanctuaries build the minds that make discoveries mean something, the “")#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/")[#text("deployable intellectual reserve” that Amit Sahai")]#text(" envisions. In an optimistic future where AI-driven discoveries and innovations must be understood and tested, academia is intentionally restructured around process, collaborations that demonstrate understanding win the highest awards, and Ph.D. students find joy as their engaged human professors challenge them over and over again until what they know expands, and they can vouch for all of it.")

#strong[#text("Acknowledgements")]

#text("Thank you to Tatiana Toro for the introduction to Terry, and to Terry for hosting this piece. Thank you also to Terry for pointing me to the report of the Harvard Summit, which I read only after finishing a full draft of this piece. I was genuinely heartened to find how much our two fields had converged on their own. Thank you to the faculty in the UW Department of Astronomy who inspire me with their thoughtfulness, brilliance and ")#link("https://www.youtube.com/watch?v=8bwoPD1A0EU")[#text("musical talent")]#text(". Thank you to Professor Xavier Prochaska, my postdoc mentor who frequently had me go to his chalkboard with my ideas. He came to me over a year ago with a claim that, under his guidance, Claude could write a Ph.D. thesis in a month that would be better than that of an average Ph.D. student in Astronomy. I did not believe him at the time. I do now, but I have decided that the thesis is not the point of the Ph.D. The student is.")

#text("I found a strange comfort in reading philosophy this summer, particularly The View from Nowhere and Mind and Cosmos, both by Thomas Nagel, after my guitar teacher was killed in an accident on June 1st. He taught me how repetition builds skill, always turned on the metronome, and taught me intricate finger patterns. One day I would be all tangled up in a finger pattern, and the next it would fall into place. Our lessons were a microcosm of joy, a cognitive sanctuary, while I was suffering from the burnout of my first years as department chair. Our time together meant more to me than I can say, and what I learned from him will stay with me forever.")

#text("AI disclosure: I drafted every paragraph of this piece by hand, then typed and edited it. I used Claude (Fable 5.1) to check my sentences against Gopen and Swan 1990, to find and verify citations, and to argue with. A handful of sentences began as its suggested wording and were rewritten by me; the arguments are mine, though some were sharpened in the arguing. No text in this piece was generated and pasted.")

#strong[#text("References")]

#text("Altman, S. 2024. “The Intelligence Age.” Blog post, September 23, 2024. ")#link("https://ia.samaltman.com/")[#text("https://ia.samaltman.com/")]

#text("American Astronomical Society. 2026. “Author Guidelines for Use of AI and LLMs in Manuscript Preparation.” AAS Journals, posted September 9, 2026. ")#link("https://journals.aas.org/author-llm-guidelines")[#text("https://journals.aas.org/author-llm-guidelines")]

#text("Avila, A., et al. 2026. “A Severe Misalignment of AI in Mathematics.” Zenodo, September 11, 2026. ")#link("https://doi.org/10.5281/zenodo.22737751")[#text("https://doi.org/10.5281/zenodo.22737751")]

#text("Bastani, H., Bastani, O., Sungu, A., Ge, H., Kabakcı, Ö., and Mariman, R. 2025. “Generative AI without guardrails can harm learning: Evidence from high school mathematics.” Proceedings of the National Academy of Sciences 122 (26): e2422633122. ")#link("https://doi.org/10.1073/pnas.2422633122")[#text("https://doi.org/10.1073/pnas.2422633122")]

#text("Caplar, N., Tacchella, S., and Birrer, S. 2017. “Quantitative evaluation of gender bias in astronomical publications from citation counts.” Nature Astronomy 1: 0141. ")#link("https://doi.org/10.1038/s41550-017-0141")[#text("https://doi.org/10.1038/s41550-017-0141")]

#text("Cohn, H. 2026. “The technical debt of AI-generated mathematics.” Guest post, What’s new (Terence Tao’s blog), September 15, 2026. ")#link("https://terrytao.wordpress.com/2026/09/15/the-technical-debt-of-ai-generated-mathematics/")[#text("https://terrytao.wordpress.com/2026/09/15/the-technical-debt-of-ai-generated-mathematics/")]

#text("Cornillon, P., and Prochaska, J. X. 2026. “The Agentic Professor: Exploring GenAI-Supported Futures in Higher Education.” EDUCAUSE Review, September 14, 2026. ")#link("https://er.educause.edu/articles/2026/9/the-agentic-professor-exploring-genai-supported-futures-in-higher-education")[#text("https://er.educause.edu/articles/2026/9/the-agentic-professor-exploring-genai-supported-futures-in-higher-education")]

#text("Gopen, G. D., and Swan, J. A. 1990. “The Science of Scientific Writing.” American Scientist 78 (6): 550–558.")

#text("Kelly, C. D., and Jennions, M. D. 2006. “The h index and career assessment by numbers.” Trends in Ecology & Evolution 21 (4): 167–170. ")#link("https://doi.org/10.1016/j.tree.2006.01.005")[#text("https://doi.org/10.1016/j.tree.2006.01.005")]

#text("Kosmyna, N., et al. 2025. “Your Brain on ChatGPT: Accumulation of Cognitive Debt when Using an AI Assistant for Essay Writing Task.” arXiv:2506.08872. ")#link("https://arxiv.org/abs/2506.08872")[#text("https://arxiv.org/abs/2506.08872")]

#text("Kra, B. 2026. “Deep theorems were scarce and difficult and so became an effective mechanism to identify deep thought. AI has broken this system.” Guest post, What’s new (Terence Tao’s blog), September 13, 2026. ")#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/")[#text("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/")]

#text("Lewis, R., Shah, H., and Alfred, A. 2026. “Astrophysics Wrapped 2025.” arXiv:2602.12303. ")#link("https://arxiv.org/abs/2602.12303")[#text("https://arxiv.org/abs/2602.12303")]

#text("Merton, R. K. 1968. “The Matthew Effect in Science.” Science 159 (3810): 56–63. ")#link("https://doi.org/10.1126/science.159.3810.56")[#text("https://doi.org/10.1126/science.159.3810.56")]

#text("Nagel, T. 1986. The View from Nowhere. New York: Oxford University Press.")

#text("Nagel, T. 2012. Mind and Cosmos: Why the Materialist Neo-Darwinian Conception of Nature Is Almost Certainly False. New York: Oxford University Press.")

#text("Polanyi, M. 1966. The Tacit Dimension. Garden City, NY: Doubleday. Reissued 2009, Chicago: University of Chicago Press.")

#text("Saad, S. M., and Ting, Y.-S. 2026. “More than half of recent astronomy papers are written with language-model assistance.” arXiv:2609.10664. ")#link("https://arxiv.org/abs/2609.10664")[#text("https://arxiv.org/abs/2609.10664")]

#text("Sahai, A. 2026. “We’re gonna need a lot more mathematicians.” Guest post, What’s new (Terence Tao’s blog), September 24, 2026. ")#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/")[#text("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/")]

#text("Sanderson, G. 2026. “If math is more than proof, we need to better celebrate the rest of it.” Guest post, What’s new (Terence Tao’s blog), September 18, 2026. ")#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/")[#text("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/")]

#text("Summit on PhD Math Education in the Age of AI. 2026. Report of Summit on PhD Math Education in the Age of AI, September 17–18, 2026. Harvard Center of Mathematical Sciences and Applications. ")#link("https://cmsa.fas.harvard.edu/media/2026/09/Summit-on-PhD-Math-Education-in-the-Age-of-AI.pdf")[#text("https://cmsa.fas.harvard.edu/media/2026/09/Summit-on-PhD-Math-Education-in-the-Age-of-AI.pdf")]

#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/27/cognitive-sanctuaries-or-manifesto-of-the-department-chair/#comment-696502")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2026")])]

#text("How can you infer from “AI makes writing and research output easier to produce” that interpretation should therefore become more important than results?")

#text("In the ML community, researchers study how LLM reasoning and planning (a form of human understanding) help models perform complex tasks (e.g., math, coding). That is clearly a victory for a results oriented rubric. If we flip this and claim interpretation matters more than results, evaluation becomes much less objective and breaking down. And as you complain about “universities receiving students produced by grade school”, this is an expected result when we make SAT optional.")

#text("And your logic bets too much on professors. A professor is only an advisor for a short time, and most PhD students will never secure a faculty job anyway. Unlike external peer review, letting department faculty decide whether a student truly understands something is dangerous. It gives professors absolute power as the sole arbiters of a junior researcher’s value and future. It is also inefficient. Even if professors are super smart and completely integrity, considering the speed of AI, the original question might get obsolete quickly.")

#text("CS offers a very different, proven philosophy: rough consensus and running code. You can find a thousand papers trying to explain why the Transformer is successful, but materialize an idea is much harder (and useful). A breakthrough does not need a complete theoretical explanation or flawless writing to be valid, because the jump in results is undeniable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/27/cognitive-sanctuaries-or-manifesto-of-the-department-chair/#comment-696526")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("Thank you for this comment. You are right that the natural outcome of results being easier to produce is more results, and that by itself does not make interpretation more valuable. I argue that we can intentionally place more value on interpretation in the process of educating Ph.D. students as a way to certify their understanding. When results begin to flood the arXiv because they are so easy to produce, and eventually surpass anyone’s ability to check them, the outcome is not great for science. A simple model of the publishing system (e.g. Kwon 2026, ")#link("https://arxiv.org/pdf/2604.05714")[#text("https://arxiv.org/pdf/2604.05714")]#text(") shows that when AI writes faster than scientists can review, verification quality falls faster than throughput rises, and the field ends up publishing more and knowing less.")

#text("On results versus interpretation, I think we are talking about two different things. A result validates a hypothesis. Running code and an undeniable benchmark jump are good evidence that a method works. My piece is more about the human side of education: what a Ph.D. means and what it certifies. Astronomy also lacks the thing that makes running code sufficient in ML. There is no benchmark to rerun. We have one universe and no held-out test set. If OpenAI reports a five-sigma detection of evolving dark energy with a 40,000-step log, following the steps is not verification; understanding the systematics and the physics is. For us interpretation is not a preference over results, it is the only verification available.")

#text("On professors as sole arbiters: they currently are, and yes, we place an enormous amount of trust in their expertise and judgment. What I suggest in this piece, Ph.D. defense and dissertation rubrics scored independently by several faculty with a signed report, is at least more accountable than what we currently have (closed door discussions and a single signed piece of paper with either a pass, conditional pass or fail on it).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/27/cognitive-sanctuaries-or-manifesto-of-the-department-chair/#comment-696515")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("Silicon Valley imagines a lot of futures for students and children of others.")

#text("They put their own children in expensive Montessori schools where the use pen and paper.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f1b1e1d3f3b0c3d50445ba93a445c627d19718f6e289ed17e03a21ed526a294-f8305e6a2879e25547ecb3014745e4d56d1b2d7260d78aac8c842ccf69e03375.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of C.Stefan")]], [#link("https://terrytao.wordpress.com/2026/09/27/cognitive-sanctuaries-or-manifesto-of-the-department-chair/#comment-696517")[#strong[#text("C.Stefan")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("“objective and mindless observer from nowhere, studying a reality that exists separately from our subjective understanding of it” and “an intelligible natural order which produces minds capable of understanding it is itself something that requires explanation”")#linebreak()#text("But that may be the next explanation needed. Yet no one is looking for the meaning of these in the the first place, although issues were formulated by Nagel and many others. What is the “unreasonable effectiveness” of mathematics defined as? Seeing through that answers it can be that different methods can be proposed (with AI too) for Cosmology/Astronomy/SETI programs.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eecd66a337c2a4e86e826a83728d9e8eafa931528e06c8e39a12720fd9c72ab9-a2f288599044367771d0e441dea02b25f62c0a5c58b10e26624a15bcdd990a33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orr Shalit")]], [#link("https://terrytao.wordpress.com/2026/09/27/cognitive-sanctuaries-or-manifesto-of-the-department-chair/#comment-696518")[#strong[#text("Orr Shalit")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("Thank you for this piece, and especially for “…the thesis is not the point of the Ph.D. The student is.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/27/cognitive-sanctuaries-or-manifesto-of-the-department-chair/#comment-696520")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("Sadly, the Yitang Zhang story is no longer possible, because no one will believe it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/27/cognitive-sanctuaries-or-manifesto-of-the-department-chair/#comment-696525")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("For people to believe it, the person would have to explain exactly how they came up with the ideas on their own. Something like: “I started in this direction, got confused, but then, after thinking for some days it was clear it was a bad direction (nonetheless it was not a wasted effort, because I understood some other thing better…), so… Then I explored this other idea… [and so on]”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/27/cognitive-sanctuaries-or-manifesto-of-the-department-chair/#comment-696529")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("This reminds of an experiment Timothy Gowers did on his blog many years ago, where people had to tell their thought process from beginning to end, while solving some problems (also, it seems he recorded his real time rough thinking sometimes). Also, it reminds of this quote:")

#text("“When you are collecting mushrooms, you only see the mushroom itself. But if you are a mycologist, you know that the real mushroom is in the Earth. There’s an enormous thing down there, and you just see the fruit, the body that you eat. In mathematics, the upper part of the mushroom corresponds to the theorems that you see, but you don’t see the things that are below, that is: ")#emph[#text("problems, conjectures, mistakes, ideas")]#text(", etc.”")

#text("Source: V. I. Arnol’d, “From Hilbert’s Superposition Problem to Dynamical Systems”, In ")#emph[#text("The Arnoldfest")]#text(", Fields Institute Communications ")#strong[#text("24")]#text(" (1999) pp. 1–18")

#text("(Arnol’d continues that, talking about how mathematics is like mycology, but I don’t want to quote too much… Anyone can check the rest there!)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/27/cognitive-sanctuaries-or-manifesto-of-the-department-chair/#comment-696528")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("I looked up Yitang Zhang. I agree this is a real loss and my proposals do not make it easier for an outsider to have their arguments heard and understood. The field would need a new route for the next Zhang.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/27/cognitive-sanctuaries-or-manifesto-of-the-department-chair/#comment-696521")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("The suggestion (3) in ")#strong[#text("Department Community")]#text(", is meaningless.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Set a department-wide standard that no one uses AI-generated text in research publications, except for disclosed, light use for editing, grammar, or translation.")
]

#text("There isn’t a benefit in enforcing it. It is likely unenforceable in practice anyway. Who cares if an entire section is generated by an LLM? What is important is the content. If it is valid, valuable, the author(s) have reviewed it and are taking responsibility for it, who cares? Disclosure, sure. But the added qualifiers “light use for editing, grammar, or translation” are an unwarranted burden on whoever gets imposed such requirement by their department.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/27/cognitive-sanctuaries-or-manifesto-of-the-department-chair/#comment-696527")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("Agreed that it is unenforceable, and it is not meant to be enforced. It is a norm a department sets for its own members. We do not need to police it, because we evaluate people in person, not the papers themselves.")

#text("Where I disagree is “who cares if a section is generated.” I do care, because writing is where the interpretation gets worked out (Gopen and Swan’s argument, and my faculty’s third point of agreement). A section you did not draft is an argument you did not make. You can review it and take responsibility for it, but the evidence we have says that is not the same for the person, even when it is fine for the reader. The norm is for our trainees most of all: if PIs use AI to generate their discussion sections, students learn that writing is separate from science, which is the lesson this piece is trying to prevent.")

#text("On the qualifiers, fair: they were meant to say what is allowed, not to police it, and I would restate the item positively: draft your own text, use the tools to polish it, disclose. That is stricter than the the new AAS Journals policy, which permits disclosed drafting, and a department can choose the stricter norm for itself (or not).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/27/cognitive-sanctuaries-or-manifesto-of-the-department-chair/#comment-696538")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("You care because you are still seeing the article (explicitly or implicitly) as a means of evaluating the authors, which is part of what needs to (transition into) stop happening. If the article is to present and evaluate the ideas therein, alone, what matters is the nature of the content, not their provenance.")

#text("You can rethink the “A section you did not draft is an argument you did not make.” in the following way. When you have an article with multiple authors, you also might not know which author contributed some specific idea. So, in the no AI scenario you also have arguments (some of) the authors did no make. Why are we applying a different standard when the list of authors is Person A, Person B, and AI C? In the latter you might even get more detailed information about authorship, because the ethical human authors would declare “this section was written by AI C”.")

#text("A “my department’s papers won’t have a section written by AI”, is an self-inflicted handicap with no gain. What if the artificial contributor actually had some interesting insights? Or it had a witty and delightful tone of the exposition that the human authors don’t happen to posses. So, the human authors either never get the idea, because they avoided using the tool, or they did and need to pretend to draft a text that sounds “in their own words”. They could use that time to interact with students.")

#text("The workflow “draft your own text, use the tools to polish it, disclose” is fine, but I don’t see what is wrong with “the tool drafts, the human refines, the tool polishes, the human polishes and proofreads, and disclose”. After all, the tool is not just an autocorrect. Take also into account that large parts of the overall structure of most papers are more or less the same everywhere, even across different sciences. And within a specific topic, keywords and phraseology repeats a lot. Think of places like near the introduction, where a bit of background, and state of the art is presented. LLM shine at that grasping of the overall tone of a subject. A good place to use them is for a draft, to give you an scaffolding of a paper, and then you fill in the parts that have substance, the delicate points, etc.")

#text("The empowerment of humans, will not come from artificial limits on the AI use. Specially, ones that cause no gain in productivity. Instead, they should consist on providing the humans with the work that we want to be done by humans, and evaluating them on the skills that we need to have.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Satya")]], [#link("https://terrytao.wordpress.com/2026/09/27/cognitive-sanctuaries-or-manifesto-of-the-department-chair/#comment-696535")[#strong[#text("Satya")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("AI is here to stay in mathematics. Faculty evaluation was never perfect, neither within the departments nor in the review process in journals and funding sources (NSF). What did not change is that I continue to enjoy doing mathematics – more so with AI.")
]
