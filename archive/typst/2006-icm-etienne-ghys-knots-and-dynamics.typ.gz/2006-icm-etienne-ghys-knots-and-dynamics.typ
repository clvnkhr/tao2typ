// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/08/03/2006-icm-etienne-ghys-knots-and-dynamics/
// Converted to Typst by tao2typ: "2026-10-14T11:25:48.203053+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "2006 ICM: Étienne Ghys, “Knots and dynamics”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("2006 ICM: Étienne Ghys, “Knots and dynamics”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 August 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/08/03/2006-icm-etienne-ghys-knots-and-dynamics/")[#text("https://terrytao.wordpress.com/2007/08/03/2006-icm-etienne-ghys-knots-and-dynamics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Almost a year ago today, I was in Madrid attending the ")#link("http://www.icm2006.org/")[#text("2006 International Congress of Mathematicians")]#text(" (ICM). One of the many highlights of an ICM meeting are the ")#link("http://icm2006.org/v_f/web_fr.php?PagIni=1pl")[#text("plenary talks")]#text(", which offer an excellent opportunity to hear about current developments in mathematics from leaders in various fields, aimed at a general mathematical audience. All the speakers sweat quite a lot over preparing these high-profile talks; for instance, I rewrote the ")#link("http://www.math.ucla.edu/~tao/preprints/Slides/icmslides2.pdf")[#text("slides for my own talk")]#text(" from scratch after the first version produced bemused reactions from those friends I had shown them to.")

#text("I didn’t write about these talks at the time, since my blog had not started then (and also, things were rather hectic for me in Madrid). During the congress, these talks ")#link("http://www.icm2006.org/onlineevents/")[#text("were webcast live")]#text(", but the video for these talks no longer seems to be available on-line.")

#text("A couple weeks ago, though, I received the first volume of the ICM proceedings, which is the one which among other things contains the articles contributed by the plenary speakers (the other two volumes were available at the congress itself). On reading through this volume, I discovered a pleasant surprise – the publishers had included a CD-ROM on the back page which had all the video and slides of the plenary talks, as well as the opening and closing ceremonies! This was a very nice bonus and I hope that the proceedings of future congresses also include something like this.")

#text("Of course, I won’t be able to put the data on that CD-ROM on-line, for both technical and legal reasons; but I thought I would discuss a particularly beautiful plenary lecture given by ")#link("http://www.umpa.ens-lyon.fr/~ghys/")[#text("Étienne Ghys")]#text(" on “")#link("http://www.umpa.ens-lyon.fr/%7Eghys/articles/icm.pdf")[#text("Knots and dynamics")]#text("“. His talk was not only very clear and fascinating, but he also made a superb use of the computer, in particular using well-timed videos and images (developed in collaboration with ")#link("http://www.josleys.com")[#text("Jos Leys")]#text(") to illustrate key ideas and concepts very effectively. (The video on the CD-ROM unfortunately does not fully capture this, as it only has stills from his computer presentation rather than animations.) To give you some idea of how good the talk was, Étienne ended up running over time by about fifteen minutes or so; and yet, in an audience of over a thousand, only a handful of people actually left before the end.")

#text("The slides for Étienne’s talk ")#link("http://www.umpa.ens-lyon.fr/~ghys/articles/icm.pdf")[#text("can be found here")]#text(", although, being in PDF format, they only have stills rather than full animations. Some of the animations though ")#link("http://www.josleys.com/show_gallery.php?galid=306")[#text("can be found on this page")]#text(". (Étienne’s article for the proceedings ")#link("http://www.umpa.ens-lyon.fr/~ghys/articles/ghys-icm.pdf")[#text("can be found here")]#text(", though like the contributions of most other plenary speakers, the print article is more detailed and technical than the talk.) I of course cannot replicate Étienne’s remarkable lecture style, but I can at least present the beautiful mathematics he discussed.")#linebreak()#text(" ")#metadata(none) <tao-22b6bc0f3acf70dfe4b7>

#text("The main theme of Étienne’s talk was how the topology of a continuous dynamical system (i.e. a vector field on a manifold) could be profitably understood from the perspective of knot theory; in particular, it was useful to think of the vector field which determines the dynamics as being like the tangent field for an infinitely long knot. This philosophy lets one build and understand several important topological or differential invariants of such dynamical systems, such as ")#link("http://en.wikipedia.org/wiki/Helicity_%28fluid_mechanics%29")[#text("helicity")]#text(". Étienne speculated that such invariants would be of use in fluid equations (such as Euler and Navier-Stokes), since the motion of a fluid over long periods of time tends to have no discernible structure other than that of a general diffeomorphism. As I discussed in my own ")#link("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")[#text("post on Navier-Stokes")]#text(", the discovery of a new conserved quantity for fluid equations could potentially be extremely important for the global regularity problem, and would also be of great intrinsic interest in its own right. But Étienne’s talk actually ended up focusing more on applications of topological dynamical systems to number theory, rather than to fluid equations.")

#text("Étienne began by recalling the paradigmatic example of a ")#link("http://en.wikipedia.org/wiki/Strange_attractor#Strange_attractor")[#text("strange attractor")]#text(" from chaos theory, namely the ")#link("http://en.wikipedia.org/wiki/Lorenz_attractor")[#text("Lorenz attractor")]#text(" discovered in 1963. Here is a picture of this attractor from Wikipedia:")

#align(center)[#image("../assets/ee066da603dda6343619a8ff69c7120c59ffe76e1ab84e9aaa66acf011ddc1ff-57dd06f84264f2ff03f95ed6e28407981aeedc1eaa5aa28c9472a06c7b819edc.svg", width: 90%)]

#text("This attractor (also known, for obvious reasons, as the ")#emph[#text("Lorenz butterfly")]#text(") arises from a fairly simple dynamical system in ")#mi("{\\Bbb R}^3")#text(", namely the Lorenz equations, originally introduced as a simplified model for convection in the atmosphere. Here is what these equations look like, for a typical choice of parameters:")

#tao-aligned(keep: true)[


#tao-math("\\frac{dx}{dt}  & = 10(y-x)", block: true)



#tao-math("\\frac{dy}{dt}  & = 28x - y - xz", block: true)
]

#align(center)[#mi("\\frac{dz}{dt} = xy - \\frac{8}{3} z")#text(".")]

#text("It turns out that a typical trajectory in this dynamical system will eventually be attracted to the above fractal set (which has dimension slightly larger than 2). This phenomenon is in fact quite robust; any small perturbation of the above system will also possess a strange attractor with similar features.")

#text("The topology of this attractor was clarified ")#link("http://www.ams.org/mathscinet-getitem?mr=682059")[#text("by Birman and Williams")]#text(", who had the idea of analysing the attractor via its periodic orbits, which they interpreted individually as ")#link("http://en.wikipedia.org/wiki/Knot_%28mathematics%29")[#text("knots")]#text(" (and collectively as ")#link("http://en.wikipedia.org/wiki/Link_%28knot_theory%29")[#text("links")]#text(") in ")#mi("{\\Bbb R}^3")#text("; the philosophy being that the attractor itself was a kind of “infinite limit” of these knots (somewhat analogously to how the unit circle ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(" could be viewed as a limit of its finite subgroups ")#mi("\\frac{1}{N}{\\Bbb Z}/{\\Bbb Z}")#text("). There are many such periodic")#linebreak()#text(" orbits in the Lorenz system, but it turns out that they have substantial combinatorial structure, and so the knot and link types of these orbits are actually very special, and classified by Birman and Williams (together with a more recent ")#link("http://www.ams.org/mathscinet-getitem?mr=1870856")[#text("paper of Tucker")]#text("); the key point being that the Lorenz dynamics is topologically equivalent to that of a simplified model (the “Lorenz template”), which is ultimately driven by the doubling map ")#mi("x \\mapsto 2x \\text{ mod } 1")#text(" on the unit circle ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(").")

#text("Other dynamical systems can have very few or very many periodic orbits. At one extreme is the ")#link("http://www.ams.org/mathscinet-getitem?mr=1307902")[#text("result of Krystyna Kuperberg")]#text(" demonstrating the existence of a smooth (in fact, real-analytic) vector field on the 3-sphere ")#mi("S^3")#text(" with no periodic orbits (thus giving a smooth counterexample to a ")#link("http://en.wikipedia.org/wiki/Seifert_conjecture")[#text("conjecture of Seifert")]#text("); at the other extreme is a ")#link("http://www.ams.org/mathscinet-getitem?mr=1350685")[#text("result of Ghrist")]#text(", giving another real-analytic vector field on ")#mi("S^3")#text(" with so many periodic orbits that ")#emph[#text("every")]#text(" knot type and link type is represented by at least one of these orbits.")

#text("It is thus better to move away from periodic orbits and focus instead on non-periodic orbits. The basic philosophy here, as advocated ")#link("http://www.ams.org/mathscinet-getitem?mr=88720")[#text("by Schwartzman")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=433464")[#text("by Sullivan and Thurston")]#text(", and by others, is to think of the entire flow ")#mi("\\phi")#text(" as one huge knot, or more precisely as a limiting “ergodic average” of knots (ignoring for now the question of what it means to take an average or a limit of knots). Given a random point x in the state space and a long time T, one can flow for time T from x to some other point ")#mi("\\phi^T(x)")#text(", and then artificially connect that point back to x (e.g. by a line segment) to form a knot. “Dividing” this knot by T, “averaging” over all choices of x (over some invariant measure for the system), and taking some sort of “limit” as T goes to infinity should then give some knot-theoretic object that models the flow ")#mi("\\phi")#text(".")

#text("A good example of this philosophy in action is ")#link("http://www.ams.org/mathscinet-getitem?mr=891881")[#text("Arnold’s knot-theoretic interpretation")]#text(" of a invariant of a three-dimensional dynamical system originating from fluid mechanics, namely the ")#link("http://en.wikipedia.org/wiki/Helicity_%28fluid_mechanics%29")[#text("helicity")]#text(". In Arnold’s interpretation, helicity is defined by taking two random points ")#mi("x_1, x_2")#text(" in the system, flowing them both for a long time T and connecting the ends to get two long knots as described above, and then computing the ")#link("http://en.wikipedia.org/wiki/Linking_number")[#text("linking number")]#text(" of these two knots (a certain alternating sum of the crossings between a projection of these two knots, which is invariant under the choice of projection). Dividing this linking number by T and taking the limit as T goes to infinity, turns out to converge to a limit for almost every ")#mi("x_1, x_2")#text(" (this is basically the ")#link("http://en.wikipedia.org/wiki/Ergodic_theorem")[#text("Birkhoff ergodic theorem")]#text("); the average of this limit over all choices of ")#mi("x_1, x_2")#text(" turns out to exactly equal the helicity of the flow.")

#text("Arnold’s construction makes it obvious that the helicity is preserved under changes of variable by (oriented) volume-preserving diffeomorphisms (such as those given by the incompressible ")#link("http://en.wikipedia.org/wiki/Euler_equations")[#text("Euler equations")]#text("). An important open question raised by Arnold is whether it is still preserved by (oriented) volume-preserving ")#emph[#text("homeomorphisms")]#text("; the above definition does not quite yield this automatically, because the line segments used to close up the knots can get non-trivially tangled up after a homeomorphism. This would be of interest in fluid equations, as it would suggest that these quantities remain invariant even after the development of singularities in the flow.")

#text("This problem remains open in general (Étienne remarked that “it has prevented him for sleeping well for the last ten years”), but has been established for a special type of volume-preserving three-dimensional system, namely the ")#emph[#text("suspension")]#text(" of an (oriented) area-preserving diffeomorphism ")#mi("f: D^2 \\to D^2")#text(" of the unit disk which fixes the boundary ")#mi("\\partial D^2 = S^1")#text(". This suspension is formed by taking the solid cylinder ")#mi("D^2 \\times [0,1]")#text(" and identifying ")#mi("(x,0)")#text(" with ")#mi("(f(x),1)")#text(" for all ")#mi("x \\in D^2")#text(" to form a slightly twisted torus, and using the right shift ")#mi("(x,t) \\mapsto (x,t+dt)")#text(" as the dynamics. One key advantage of working in this simplified model is that the space ")#mi("\\text{Diff}(D^2, \\partial D^2, \\text{area})")#text(" of (oriented) area-preserving, boundary-fixing diffeomorphisms of the disk is a group (and is also a contractible topological space).")

#text("To establish Arnold’s conjecture for suspensions, ")#link("http://www.ams.org/mathscinet-getitem?mr=1452855")[#text("Gambaudo and Ghys ")]#text("showed that the helicity in this case is equivalent to the ")#link("http://www.ams.org/mathscinet-getitem?mr=350776")[#text("Calabi invariant")]#text(" ")#mi("\\text{Cal}(f)")#text(" of the diffeomorphism f, which turns out to be a non-trivial homomorphism from the group ")#mi("\\text{Diff}(D^2, \\partial D^2, \\text{area})")#text(" to the real line. (It was shown ")#link("http://www.ams.org/mathscinet-getitem?mr=511781")[#text("by Banyaga ")]#text("that this is essentially the only such homomorphism, or more precisely the kernel of the Calabi invariant is simple and so does not support any further non-trivial homomorphisms.) It was observed by Fathi that ")#mi("\\text{Cal}(f)")#text(" can be interpreted as the “average amount” of rotation inherent in f; more precisely, given two random points ")#mi("x_1, x_2 \\in D^2")#text(", and given a continuous deformation ")#mi("t \\mapsto f_t")#text(" from the identity map to f (which always exists, by contractibility), the average rotation when deforming the line segment ")#mi("(x_1,x_2) = (f_0(x_1),f_0(x_2))")#text(" to its image ")#mi("(f(x_1),f(x_2)) = (f_1(x_1),f_1(x_2))")#text(" using ")#mi("f_t")#text(", when averaged over ")#mi("x_1, x_2")#text(", turns out to be independent of the choice of deformation and equals the Calabi invariant. From this one can show that the Calabi invariant is a topological invariant, and hence the helicity for suspensions is also a topological invariant. (It is however still an open question to see whether the Calabi invariant can be extended to arbitrary homeomorphisms – not just those maps which are homeorphically conjugate to diffeomorphisms.)")

#text("Banyaga’s result says that the Calabi invariant is essentially the only homomorphism invariant on area-preserving diffeomorphisms. But it turns out that one can achieve a far richer set of “quasi-invariants” by passing from homomorphisms to the more general class of ")#emph[#text("homogeneous quasimorphisms")]#text(": a real-valued map ")#mi("\\chi: \\Gamma \\to {\\Bbb R}")#text(" which is almost a homomorphism in the sense that ")#mi("\\chi(\\gamma_1 \\gamma_2) - \\chi(\\gamma_1) - \\chi(\\gamma_2)")#text(" stays bounded (even though it doesn’t vanish entirely), and which is homogeneous in the sense that ")#mi("\\chi(\\gamma^n) = n \\chi(\\gamma)")#text(" for all ")#mi("\\gamma, n")#text(". Quasimorphisms are invariant under conjugation up to bounded errors. This concept (arising from Gromov’s theory of bounded cohomology) turns out to be trivial for groups which are abelian or close to abelian (e.g. solvable or amenable), as in such cases every quasimorphism is just a bounded perturbation of a homomorphism, but is highly non-trivial for very non-abelian groups such as free groups or ")#link("http://en.wikipedia.org/wiki/Hyperbolic_group")[#text("Gromov hyperbolic groups")]#text(". Returning from algebra to dynamical systems, a model example of a quasimorphism is the evaluation map ")#mi("f \\mapsto f(0)")#text(" of the universal cover of the space ")#mi("\\text{Homeo}(S^1)")#text(" of homeomorphisms of the sphere, which we identify with the space of functions ")#mi("f: {\\Bbb R} \\to {\\Bbb R}")#text(" which commute with integer shifts, thus ")#mi("f(x+1) = f(x)+1")#text(". The homogenisation of this quasimorphism is simply the ")#link("http://en.wikipedia.org/wiki/Rotation_number")[#text("Poincaré rotation number")]#text(" of f.")

#link("http://www.ams.org/mathscinet-getitem?mr=2104597")[#text("Gambaudo and Ghys showed")]#text(" that in fact there are an infinite-dimensional vector space of homogeneous quasimorphisms on ")#mi("\\text{Diff}(D^2, \\partial D^2, \\text{area})")#text(". The key idea is to use not the dynamics of two points ")#mi("x_1, x_2")#text(" as was done by Fathi to describe Calabi’s invariant, but instead use the dynamics of ")#emph[#text("many ")]#text("points ")#mi("x_1,\\ldots,x_n")#text(". This dynamics can be described using the ")#link("http://en.wikipedia.org/wiki/Braid_group")[#text("braid group")]#text(" on n strings, which for ")#mi("n > 2")#text(" is sufficiently non-abelian to support a very rich set of quasimorphisms (such as the signature of the braid). Other interesting constructions of quasimorphisms on related groups were also obtained ")#link("http://www.ams.org/mathscinet-getitem?mr=1979584")[#text("by Entov-Polterovich")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2224660")[#text("by Py")]#text(", and others. But the task of extending these quasi-invariants to more general three-dimensional flows, or perhaps to higher-dimensional symplectic flows, in a manner robust enough to provide topological invariants, remains largely open.")

#text("Étienne then turned to a number-theoretic application of these topological and dynamical ideas, to clarify some properties of the classical ")#link("http://en.wikipedia.org/wiki/Dedekind_eta_function")[#text("Dedekind ")#mi("\\eta")#text("-function")]#text(". Consider the space M of two-dimensional lattices ")#mi("\\Lambda")#text(" in ")#mi("{\\Bbb R}^2")#text(" which are unimodular (i.e. their fundamental domain has area 1). This space can be canonically identified with the symmetric space ")#mi("PSL(2,{\\Bbb R})/PSL(2,{\\Bbb Z})")#text(". It is also the ")#link("http://en.wikipedia.org/wiki/Moduli_space")[#text("moduli space")]#text(" of ")#link("http://en.wikipedia.org/wiki/Elliptic_curve")[#text("elliptic curves")]#text(" (as described in ")#link("https://terrytao.wordpress.com/2007/05/03/distinguished-lecture-series-ii-shou-wu-zhang-%e2%80%9cgross-zagier-formula-and-birch-and-swinnerton-dyer-conjecture-%e2%80%9d/")[#text("Zhang’s talk")]#text("); indeed, the ")#link("http://en.wikipedia.org/wiki/Eisenstein_series")[#text("Eisenstein series")]

#tao-aligned(keep: true)[


#tao-math("g_2(\\Lambda)  & := 60 \\sum_{\\omega \\in \\Lambda \\backslash \\{0\\}} \\omega^{-4}", block: true)



#tao-math("g_3(\\Lambda)  & := 140 \\sum_{\\omega \\in \\Lambda \\backslash \\{0\\}} \\omega^{-6}", block: true)
]

#text("describes the coefficients of an elliptic curve ")#mi("y^2 = x^3 - g_2 x - g_3")#text(", whose ")#link("http://en.wikipedia.org/wiki/Discriminant")[#text("discriminant")]#text(" ")#mi("\\Delta = g_2^3 - 27 g_3^2")#text(" is non-zero. (Conversely, the lattice can be reconstructed from the elliptic curve via ")#link("http://en.wikipedia.org/wiki/Period_%28number%29")[#text("periods")]#text(".) Indeed, it is a classical result that the map ")#mi("\\Lambda \\mapsto (g_2,g_3)")#text(" (projectively) identifies M with the 3-sphere ")#mi("S^3 \\subset {\\Bbb C}^2")#text(" with the curve ")#mi("\\{ (g_2,g_3) \\in {\\Bbb C}^2: \\Delta = 0 \\}")#text(" removed. This curve is topologically a ")#link("http://en.wikipedia.org/wiki/Trefoil_knot")[#text("trefoil knot")]#text(" l; thus M is topologically equivalent to the complement ")#mi("S^3 \\backslash l")#text(" of that knot.")

#text("As was (implicitly) observed by Gauss, some very classical objects in number theory (e.g. continued fractions, or ideals in real quadratic fields) can be viewed in terms of a basic flow on M, the ")#emph[#text("modular flow")]#text(" ")#mi("\\phi^t: M \\to M")#text(" defined by area-preserving dilation: ")#mi("\\phi^t := \\begin{pmatrix} e^t & 0 \\\\ 0 & e^{-t} \\end{pmatrix}")#text(". These matrices also describe the hyperbolic elements of ")#mi("PSL(2,{\\Bbb R})")#text(" up to conjugacy, and so a little algebra shows that the periodic orbits of modular flow can be canonically identified with conjugacy classes of hyperbolic elements of ")#mi("PSL(2,{\\Bbb Z})")#text(". Indeed, if A is such a hyperbolic element, then it is conjugate to one of the above dilation matrices, thus the matrix of ")#mi("\\phi^t")#text(" for some t is given by ")#mi("PAP^{-1}")#text(" for some ")#mi("P \\in PSL(2,{\\Bbb R})")#text(", which can be viewed as a point on M, which will be periodic under modular flow with period t.")

#text("Thus, every hyperbolic matrix ")#mi("A \\in PSL(2,{\\Bbb Z})")#text(" defines a periodic orbit, which by the previous discussion can be viewed as a knot ")#mi("k_A")#text(" in the complement of the trefoil knot l. Let’s call such knots ")#emph[#text("modular knots")]#text(".")

#text("Étienne then discussed two remarkable theorems about these modular knots. The first is that the linking number between the modular knot ")#mi("k_A")#text(" and the trefoil knot l is equal to the ")#emph[#text("Radamacher function ")]#text("R(A) of A. The Radamacher function ")#mi("R: PSL(2,{\\Bbb Z}) \\to {\\Bbb Z}")#text(" is a very interesting quasihomomorphism, studied in detail ")#link("http://www.ams.org/mathscinet-getitem?mr=909232")[#text("by Atiyah")]#text(", who gave seven different equivalent definitions of this function; the above fact gives a knot-theoretic proof of several of the equivalences.")

#text("One of the definitions of the Radamacher function is the ")#link("http://en.wikipedia.org/wiki/Monodromy")[#text("monodromy")]#text(" of the logarithm of the ")#link("http://en.wikipedia.org/wiki/Dedekind_eta_function")[#text("Dedekind ")#mi("\\eta")#text("-function")]#text(", which is a non-vanishing function on the upper half-plane; more precisely, one has")

#align(center)[#tao-fit-display[#mitex("24 \\log \\eta(\\frac{a\\tau+b}{c\\tau+d}) = 24 \\log \\eta(\\tau) + 6 \\log( - (c\\tau+d)^2 ) + 2\\pi i R(\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} ),")]]

#text("which is the logarithmic version of the classical modular identity")

#align(center)[#tao-fit-display[#mitex("\\eta^{24}(\\frac{a\\tau+b}{c\\tau+d}) = \\eta^{24}(\\tau) (c\\tau+d)^{12}.")]]

#text("To see why the linking number is at all related to the eta function, one uses Jacobi’s identity ")#mi("\\Delta(\\Gamma) = (2\\pi)^{12} \\omega_1^{-12} \\eta^{24}(\\frac{\\omega_2}{\\omega_1})")#text(" relating the discriminant of a lattice ")#mi("\\Gamma")#text(" with the Dedekind eta function, where ")#mi("\\omega_1, \\omega_2")#text(" are two generators of ")#mi("\\Gamma")#text(". Using this, one can view R(A) in terms of the winding number of ")#mi("\\Delta(k_A)")#text(" around the origin. But if one takes a branch cut of the discriminant, e.g. ")#mi("\\{ \\Gamma: \\Delta(\\Gamma) \\in {\\Bbb R}^+ \\}")#text(", one gets a ")#link("http://en.wikipedia.org/wiki/Seifert_surface")[#text("Seifert surface")]#text(" in M (indeed, the map ")#tao-math("\\Delta/\\left|\\Delta\\right|", block: false)#text(" is a locally trivial fibration whose fibres are punctured tori), and so the winding number is nothing more than the (oriented) number of times ")#mi("k_A")#text(" crosses this surface, which is the linking number between ")#mi("k_A")#text(" and the boundary l of this Seifert surface.")

#text("[Another proof equating the linking number to an alternate, more topological, definition of the Radamacher number is also sketched out in ")#link("http://www.umpa.ens-lyon.fr/~ghys/articles/ghys-icm.pdf")[#text("Étienne’s proceedings article")]#text(".]")

#text("The second remarkable theorem about these modular knots is that the knot types (or more precisely, isotopy classes) of the modular knots coincide exactly with the knot types of the Lorenz attractor periodic orbits! Similarly for the link types between knots. This unexpected connection between dynamics and number theory arises from two key facts. The first, which is relatively easy, is that the modular flow contains inside it an invariant set which is equivalent to the Lorenz template briefly mentioned earlier; this set can be constructed explicitly by flowing out from the regular hexagonal and equilateral lattices in the unstable directions. The second, which is trickier, is to show that any knot in the larger moduli space M can be continuously deformed onto this template (and furthermore, any link of knots can be continuously deformed onto this template). This was not proved in Étienne’s talk, but there were several very nice computer animations which displayed this deformation quite convincingly.")

#text("There appear to be several further connections between the modular flow and the Lorenz flow which is work in progress, but this was not detailed in the talk.")

#text("Étienne closed by commenting on the importance on communicating mathematics effectively not just to other mathematicians in one’s field or on other fields, but also to non-mathematicians; for instance, ")#link("http://www.josleys.com/")[#text("Jos Leys")]#text(", who created all the computer animations for the talk, is a mechanical engineer with a keen interest in mathematics. He ended with two supporting quotes from David Hilbert (at an ICM over a century earlier):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("“")#emph[#text("A mathematical theory is not to be considered complete unless you made it so clear that you can explain it to the man in the street")]#text(".”")

#text("“")#emph[#text("For what is clear and easily comprehended attracts, and the complicated repels us")]#text(".”")
]

#text("Étienne remarked that Hilbert’s second quote is a particularly succinct explanation of why he loves mathematics (and it is why I do too).")

#text("[")#emph[#text("Update")]#text(", Aug 4: link corrected.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bk")]], [#link("https://terrytao.wordpress.com/2007/08/03/2006-icm-etienne-ghys-knots-and-dynamics/#comment-5586")[#strong[#text("bk")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2007")])]

#text("Dr Tao,")#linebreak()#text(" Can you give more talks on PDE?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/03/2006-icm-etienne-ghys-knots-and-dynamics/#comment-5605")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2007")]

#text("[…] 2006 ICM: Étienne Ghys, “Knots and dynamics” Almost a year ago today, I was in Madrid attending the 2006 International Congress of Mathematicians (ICM). One of the […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/03/2006-icm-etienne-ghys-knots-and-dynamics/#comment-5607")[#strong[#text("A couple of links! « Entertaining Research")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2007")]

#text("[…] Terry Tao on a talk that he attended (nearly an year ago) on knots and dynamics. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/08/03/2006-icm-etienne-ghys-knots-and-dynamics/#comment-5624")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2007")])]

#text("Hi Terrence,")

#text("This is a fascinating thread [!] that may relate to other ideas?")

#text("E Ghys slides of “Knots and dynamics” discusses")#linebreak()#text(" – knots with orbit periodicity")#linebreak()#text(" — [nearly circular ellipse if planar?, helix if trajectory curve?],")#linebreak()#text(" – “helicity as asymptotic linking number” or")#linebreak()#text(" — “a topological invariant”,")#linebreak()#text(" – torus — “suspension” related to helicity.")

#text("Perhaps there exists a relation with:")#linebreak()#text(" a – Urs Wiedemann [CERN], ‘Jet quenching in string theory and heavy ion collisions’ emphasizing “our task: find catenary”, slide 38/38, Strings 07.")#linebreak()#text(" — Euler related the catenary to the catenoid,")#linebreak()#text(" — the catenoid is in isometry with the helicoid,")#linebreak()#text(" — the helix is an elliptical and trajectory curve forming a virtual helicoid.")

#text("b – DM Stump, AR Champneys, GHM van der Heijden, ‘The torsional buckling and writhing of a simply supported rod hanging under gravity’, “… outer catenary-like solution … modulated helix-like spiral with period …”.")#linebreak()#text(" International Journal of Solids and Structures")#linebreak()#text(" Volume 38, Issue 5, February 2001, Pages 795-813")

#text("c – David Hestenes, ‘The Kinematic Origin of Complex Wave Functions’, “… wave function describes electron … Zitterwebegung interaction …”.")

#text("d – supercoiling helices of ionic, nucleic and amino acids")#linebreak()#text(" – may help explain bioelectromagnetism.")#linebreak()#text(" [compare Ghys slide 19/40 with images of DNA, RNA, protein helices; rope and cable wiring and images of helices in space by NASA]")

#text("Note:")

#text("The helix appears to be ubiquitous at many different scales.")

#text("The above structures may have similarity with helical wired solenoids.")#linebreak()#text(" – an iron core solenoid may have a magnetic field several hundred times that of an equivalent air solenoid.")#linebreak()#text(" [image in GSU Hyperphysics on google]")

#text("Speculation:")

#text("Pehaps gravity may be a solenoid like force [partial, virtual?] as is electromagnetism in many cases?")#linebreak()#text(" – EM waves (helical) may form vacuum solenoids?")#linebreak()#text(" – Planetary and star orbits are nearly circular ellipses when sun or galactic nucleus held stationary with helical angle equal zero;")#linebreak()#text(" when sun or galactic nucleus in motion, helical angle greater than zero?")#linebreak()#text(" – The weak and strong forces under SU(3) x SU(2) x U(1) are virtually transformed into electromagetism?")

#text("The torus may relate to the Monster symmetry with “folded” [doughnut] possible rather than only “broken” symmetry?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b93c4f704f635870a0c6447b38783dde3f51029c13166930616c70e598e19d32-50d5bd01425c8abdc620f7fdd6f84a72a245b938892ef1797748962ffce1de85.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amazeen")]], [#link("https://terrytao.wordpress.com/2007/08/03/2006-icm-etienne-ghys-knots-and-dynamics/#comment-5652")[#strong[#text("amazeen")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2007")])]

#text("The link to moduli space is wrong. It sends you to the wikipedia page on discriminants.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/03/2006-icm-etienne-ghys-knots-and-dynamics/#comment-5653")[#strong[#text("In case you thought I had given up on knot theory « Mumble Mumble…")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2007")]

#text("[…] blogger Terrance Tao has a really cool post summarizing a talk from the 2006 ICE about the marriage of knot theory and dynamical systems. Specifically, he talks about the use of limits of knots (whatever that means…) as a way of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/03/2006-icm-etienne-ghys-knots-and-dynamics/#comment-5654")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2007")])]

#text("Dear amazeen,")

#text("Thank you for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/03/2006-icm-etienne-ghys-knots-and-dynamics/#comment-5721")[#strong[#text("GVietMath Thế nào là một lý thuyết toán học tốt? «")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2007")]

#text("[…] cho ra Trích từ một bài viết gần đây của Terence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24ec58422b7f5b2d5fed13b5b1c3c402926f3311546c80ddfa2e7e0ad53ca3ac-6fb9637d374939756134e64e9d80fbf7cf30328a7b3294c98bdf43295a679a12.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carnival of Mathematics XIV « Vlorbik on Math Ed")]], [#link("https://terrytao.wordpress.com/2007/08/03/2006-icm-etienne-ghys-knots-and-dynamics/#comment-6145")[#strong[#text("Carnival of Mathematics XIV « Vlorbik on Math Ed")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2007")])]

#text("[…] Category Theory), and Questions About Modules (by John Baez in The n-Category Cafe). Also Terry Tao reports on ICM 2006, where he seems to have won some sort of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/08/03/2006-icm-etienne-ghys-knots-and-dynamics/#comment-41417")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2009")])]

#text("All the videos of the congress, including Étienne Ghys talk, are available at ")#link("http://www.icm2006.org/video/")[#text("http://www.icm2006.org/video/")]#text(" .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/03/2006-icm-etienne-ghys-knots-and-dynamics/#comment-482321")[#strong[#text("Some notes on Lorenz flow – Math for everyone")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2017")]

#text("[…] In 2006 Ghys discovered the extraordinary fact that the set of periodic orbits of the Lorenz equations is identical to that of the geodesic flow on the unit tangent bundle to the modular surface ")#link("http://www.math.tifr.res.in/~tali/research/research_statement.pdf")[#text("http://www.math.tifr.res.in/~tali/research/research_statement.pdf")]#text(" ")#link("https://terrytao.wordpress.com/2007/08/03/2006-icm-etienne-ghys-knots-and-dynamics/")[#text("https://terrytao.wordpress.com/2007/08/03/2006-icm-etienne-ghys-knots-and-dynamics/")]#text(" […]")
]
