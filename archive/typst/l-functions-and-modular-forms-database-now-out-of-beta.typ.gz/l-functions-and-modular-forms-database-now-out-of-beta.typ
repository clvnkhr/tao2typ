// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/05/10/l-functions-and-modular-forms-database-now-out-of-beta/
// Converted to Typst by tao2typ: "2026-10-14T10:30:04.255415+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "L-functions and modular forms database now out of beta", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("L-functions and modular forms database now out of beta")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 May 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/05/10/l-functions-and-modular-forms-database-now-out-of-beta/")[#text("https://terrytao.wordpress.com/2016/05/10/l-functions-and-modular-forms-database-now-out-of-beta/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Over the last few years, a ")#link("http://www.lmfdb.org/acknowledgment")[#text("large group of mathematicians")]#text(" have been developing ")#link("http://lmfdb.org/")[#text("an online database")]#text(" to systematically collect the known facts, numerical data, and algorithms concerning some of the most central types of objects in modern number theory, namely the L-functions associated to various number fields, curves, and modular forms, as well as further data about these modular forms. This of course includes the most famous examples of L-functions and modular forms respectively, namely the ")#link("http://www.lmfdb.org/L/Riemann/")[#text("Riemann zeta function")]#text(" ")#mi("\\zeta(s)")#text(" and the ")#link("http://www.lmfdb.org/ModularForm/GL2/Q/holomorphic/1/12/1/a/")[#text("discriminant modular form")]#text(" ")#mi("\\Delta(q)")#text(", but there are countless other examples of both. The ")#link("http://www.lmfdb.org/universe")[#text("connections between these classes of objects")]#text(" lie at the heart of the ")#link("https://en.wikipedia.org/wiki/Langlands_program")[#text("Langlands programme")]#text(".")

#text("As of today, the “")#link("http://lmfdb.org/")[#text("L-functions and modular forms database")]#text("” is now out of beta, and open to the public; at present the database is mostly geared towards specialists in computational number theory, but will hopefully develop into a more broadly useful resource as time develops. An article by John Cremona summarising the purpose of the database can be found ")#link("http://link.springer.com/article/10.1007/s10208-016-9306-z")[#text("here")]#text(".")

#text("(Thanks to ")#link("https://math.mit.edu/~drew/")[#text("Andrew Sutherland")]#text(" and ")#link("http://www.kskedlaya.org/")[#text("Kiran Kedlaya")]#text(" for the information.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/05/10/l-functions-and-modular-forms-database-now-out-of-beta/#comment-468490")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2016")])]

#text("Can (the numerical part in) Helfgott’s recent proof of the ternary Goldbach conjecture be based only on this database?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/10/l-functions-and-modular-forms-database-now-out-of-beta/#comment-468499")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2016")])]

#text("Not quite yet. There are two significant numerical inputs to Helfgott’s work. One is the verification of ternary Goldbach up to 10^30 or so by Helfgott and Platt, which does not involve L-functions and would be outside of the scope of the database. The other is the verification of GRH by Platt for conductors up to 300000 and height times conductor up to about 10^8. It looks like this is not currently in the database, although there is a ")#link("http://www.lmfdb.org/knowledge/show/zeros.zeta.contents")[#text("related data set of Platt")]#text(" containing the first 10^11 or so zeroes of zeta. Platt is ")#link("http://www.lmfdb.org/acknowledgment")[#text("listed as a contributor to the database")]#text(", so perhaps his data will be uploaded to the lmfdb in the future.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/05/10/l-functions-and-modular-forms-database-now-out-of-beta/#comment-476749")[#strong[#text("Functions Too Cool For Facebook. But Don’t Worry, We’ve Got You Covered – Study Score Calc")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2017")]

#text("[…] objects lie at the heart of the Langlands program,” explained the Fields Medalist Terry Tao in a blog post about the LMFDB today. The LMFDB teases out a lot of surprising relationships between theoretical objects, ones that […]")
]
