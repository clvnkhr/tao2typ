// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/09/11/course-announcement-246a-complex-analysis/
// Converted to Typst by tao2typ: "2026-10-14T10:36:16.746116+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Course announcement: 246A, complex analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Course announcement: 246A, complex analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 September 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/09/11/course-announcement-246a-complex-analysis/")[#text("https://terrytao.wordpress.com/2016/09/11/course-announcement-246a-complex-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Next week, I will be teaching ")#link("https://ccle.ucla.edu/course/view/16F-MATH246A-1")[#text("Math 246A")]#text(", the first course in the three-quarter graduate complex analysis sequence. This first course covers much of the same ground as an honours undergraduate complex analysis course, in particular focusing on the basic properties of holomorphic functions such as the Cauchy and residue theorems, the classification of singularities, and the maximum principle, but there will be more of an emphasis on rigour, generalisation and abstraction, and connections with other parts of mathematics. If time permits I may also cover topics such as factorisation theorems, harmonic functions, conformal mapping, and/or applications to analytic number theory. The main text I will be using for this course is ")#link("http://www.ams.org/mathscinet-getitem?mr=1976398")[#text("Stein-Shakarchi")]#text(" (with ")#link("http://www.ams.org/mathscinet-getitem?mr=510197")[#text("Ahlfors")]#text(" as a secondary text), but as usual I will also be writing notes for the course on this blog.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e822d49659a61efbc514995f9147b7d8d606cb9ad63e838512101ae23dcf07f-6964b7c4f2adaaa4a90c00436abf62076188597c0723c83f9383d8a59fb30b40.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lino Vari")]], [#link("https://terrytao.wordpress.com/2016/09/11/course-announcement-246a-complex-analysis/#comment-472273")[#strong[#text("Lino Vari")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2016")])]

#text("Very much look forward to it Terry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/250ef44e5d9d1498ea529d42aadcaffe2e5b53cc77b294899c5c801f565a46d1-6ecc6a0b1cac73fe5554dc1b87ebbcb29d1c33f3132fd813bcce6c454eaf5b50.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Ericson")]], [#link("https://terrytao.wordpress.com/2016/09/11/course-announcement-246a-complex-analysis/#comment-472277")[#strong[#text("Lars Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2016")])]

#text("When are you going to get that on EdX or Coursera?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e5296b75242012daa1e4d627b7cd5b01010b81d8468fd8fd06c48e351fbb369-b7abc69797d36ef2864be9866590a1d776a5f3c1a4d9dc44a1956eba8d7d4369.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Aldrich")]], [#link("https://terrytao.wordpress.com/2016/09/11/course-announcement-246a-complex-analysis/#comment-472279")[#strong[#text("Chris Aldrich")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2016")])]

#text("It’s not as advanced a treatment, but if you’re looking for a complex analysis MOOC (on Coursera), there’s a class starting shortly: ")#link("https://www.coursera.org/learn/complex-analysis")[#text("https://www.coursera.org/learn/complex-analysis")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/250ef44e5d9d1498ea529d42aadcaffe2e5b53cc77b294899c5c801f565a46d1-6ecc6a0b1cac73fe5554dc1b87ebbcb29d1c33f3132fd813bcce6c454eaf5b50.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Ericson")]], [#link("https://terrytao.wordpress.com/2016/09/11/course-announcement-246a-complex-analysis/#comment-472282")[#strong[#text("Lars Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2016")])]

#text("I know Coursera has Complex Analysis, point of my comment was to encourage Prof. Tao to find a MOOC platform that offers free courses with grading and extend his teaching to the world in that way. Coursera is actually moving towards “monetizing” so they push you towards their for-pay options. Stanford’s Lagunita platform preserves the original ethos of Coursera which is to donate some education to the world.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/25b0a32548ce61de4200d4b34783372d9fcd85041c5adc310f58bb40693716f2-bcc3e6664d13a3a848a86a9c56677f4a52e5e5a66216ecab2fe97d0b1a69fd27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of GAYOUB")]], [#link("https://terrytao.wordpress.com/2016/09/11/course-announcement-246a-complex-analysis/#comment-472280")[#strong[#text("GAYOUB")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2016")])]

#text("Can you please tell me about EdX or Coursera?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/250ef44e5d9d1498ea529d42aadcaffe2e5b53cc77b294899c5c801f565a46d1-6ecc6a0b1cac73fe5554dc1b87ebbcb29d1c33f3132fd813bcce6c454eaf5b50.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Ericson")]], [#link("https://terrytao.wordpress.com/2016/09/11/course-announcement-246a-complex-analysis/#comment-472281")[#strong[#text("Lars Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2016")])]

#text("Coursera has a Complex Analysis course: ")#link("https://www.coursera.org/learn/complex-analysis")[#text("https://www.coursera.org/learn/complex-analysis")]

#text("Stanford has a for-pay EdX platform and a free platform called Lagunita: ")#link("https://lagunita.stanford.edu/courses")[#text("https://lagunita.stanford.edu/courses")]#text(" It is fairly sparse on pure math courses.")

#text("In general the core pure math courses with grading are few and far between in the MOOC world. There are a lot more technical MOOCs in applied math and applied science than in pure math and basic math (undergrad bread-and-butter core math courses). So you’ll get a Data Science with Python in many versions but no Calc 3.")

#text("UCLA is not a leader in MOOCs with very few free MOOCs on any platform.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a206486953aa84d7bfc3dabc824894fb43d36074ccb40945ea33100ba1ed533d-80cf840618106f98108763ea202a0911db3947994f845dbb1510abf59c20daa6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of miklos kontra")]], [#link("https://terrytao.wordpress.com/2016/09/11/course-announcement-246a-complex-analysis/#comment-472278")[#strong[#text("miklos kontra")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2016")])]

#text("Thank s Profesor Tao, I m working on a connection between prime numbers and the Collatz Conjecture, I ve found a way that shows that the conjecture is true for every Natural number, really i found a way mixing graph theory some very basic algebra and logical math ( the idea was to use this mixture, the idea is based on what Paul Erdoss said about the conjecture ‘Mathematics are not ready for this kind of problem’ ‘Paul is a man of the same country as my fathers Hungary’, thats why i tried other things after 3 years of hard working trying out all kinds of things in math (series etc..) and reading many papers from Connway, Feinman even works published in arxiv and other sites, i will be presenting my thesis in computer science in december in Argentina University of UNLAM, if it is of your interest I can send you a copy of about 10 pages of the work on the Conjecture, I know that you re very busy, but just in case it might be of some help in your works.")

#text("The graphs shows the zones where mathematics can t explain the conjecture, but also shows that every number reach 1 having only 1 trivial cycle (4,2,1) and none of the paths diverge! If one takes out the cycle (4,2,1) the graph obeys as a tree structure where each node gets to 1.")

#text("Well I d would be very pleased if i could get somo feedback from you and add your opinion with your authorization to the thesis.")

#text("Thank s for youre time")

#text("Ing. Miklos Kontra")

#text("Buenos Aires, Argentina.")

#text("________________________________ De: Whats new Enviado: lunes, 12 de septiembre de 2016 03:11 a.m. Para: ")#link("mailto:mkontra@hotmail.com")[#text("mkontra@hotmail.com")]#text(" Asunto: [New post] Course announcement: 246A, complex analysis")

#text("Terence Tao posted: “Next week, I will be teaching Math 246A, the first course in the three-quarter graduate complex analysis sequence. This first course covers much of the same ground as an honours undergraduate complex analysis course, in particular focusing on the basic p”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35186b0c9e03516cd6c753630993d6079968fae10524181d5d404140a024ceae-974717ca90d426a994d366d3cfad98df75a8f3478926424d98a74985bed6b80f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JDM")]], [#link("https://terrytao.wordpress.com/2016/09/11/course-announcement-246a-complex-analysis/#comment-472313")[#strong[#text("JDM")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2016")])]

#text("there are new textbooks and newer textbooks on the matter. Certainly:")

#text("Needham “Visual Complex Analysis”")

#text("This might not be at the level of the course. There is a textbook that teaches it via fluid mechanics ( I can’t find it… ) but I found these notes")

#link("http://www.stat.phys.titech.ac.jp/~yokoyama/note4.pdf")[#text("Click to access note4.pdf")]

#text("and these are substantially less visual. “Introduction to Mathematical Fluid Mechanics”")

#link("http://cims.nyu.edu/~tobasco/courses/UofM/Math654.pdf")[#text("Click to access Math654.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ee223a20188fa5c793bc17c08c68a2f943ee60a8744e957c5d89385d895127b-2dd1e709b4b6a4cff8fef0fc5b295d8abf393ff9ed6dd7d234979515767c5c10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jheavner724")]], [#link("https://terrytao.wordpress.com/2016/09/11/course-announcement-246a-complex-analysis/#comment-472366")[#strong[#text("jheavner724")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2016")])]

#text("Neither of these are suitable at the graduate level. Needham’s text is nice, and it can be helpful for beginners who want to have some proficiency with complex variables, but it makes not for a course in rigorous complex analysis. The other texts are even less suitable for this sort of course. They may be excellent resources for scientists interested in fluid mechanics and complex analysis, but they once again lack the rigor demanded of pure mathematics.")

#text("Aflhors’ text is a classic, but one that may disdain; Tao’s choice of Stein is probably a perfect one. It is a very well written text authored by a master of analysis who Tao himself studied under; it retains rigor while also not being horribly terse or boring. Students will probably end up referencing Rudin, Alfhors, and Conway as well, but Stein may be the best leading text choice.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/760ddd8bad27c570c5995a8ca954c5a38fd4fac69f38771b25a6b6db36d6b11e-4ad57592ce78782880a2c818635ada04dd6ba4cba69ace173598d068d4466749.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Romain Viguier")]], [#link("https://terrytao.wordpress.com/2016/09/11/course-announcement-246a-complex-analysis/#comment-472314")[#strong[#text("Romain Viguier")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2016")])]

#text("I would like to find a field where we do not need too many data even if I know we cant replace thousands years of mathematics. I would like to learn few things with big scopes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b5a90bf70e0ec762920225b76895ea4e69d1c5ff4b440877b9766e7a47f8b2f-bcd647a46b328f89f43e814390c3593f16ae4e39e04c7b73813550f066da2fe2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alienbot007")]], [#link("https://terrytao.wordpress.com/2016/09/11/course-announcement-246a-complex-analysis/#comment-472358")[#strong[#text("alienbot007")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2016")])]

#text("I remember when I was a kid I couldn’t solve a math problem, but then when I approached the problem later, I was able to understand it immediately. If I had never approached the problem again, I might have concluded that I was incapable of learning the concept.")

#text("In the interests of helping math become more accessible to those who might be scared away by an initially tough problem, is there a way I can interview you to translate a few of these high-level math concepts into plain language?")

#text("This is a project I’m working to develop a question framework to gain useful insight into a complex field in 20 questions or less to someone who is completely unfamiliar with the field.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://t.co/k9qPnx52jt")[#text("https://t.co/k9qPnx52jt")]#linebreak()#text("Data Structure Standards for Automated Solution Finding")#link("https://twitter.com/pmarca?ref_src=twsrc%5Etfw")[#text("@pmarca")]#text(" ")#link("https://twitter.com/JeffBezos?ref_src=twsrc%5Etfw")[#text("@JeffBezos")]#text(" ")#link("https://twitter.com/theamitsinghal?ref_src=twsrc%5Etfw")[#text("@theamitsinghal")]#text(" ")#link("https://t.co/yMbjcV2Xkz")[#text("pic.twitter.com/yMbjcV2Xkz")]

#text("— Sol Ver (@alienbot123) ")#link("https://twitter.com/alienbot123/status/772286047476736000?ref_src=twsrc%5Etfw")[#text("September 4, 2016")]
]

#text("The initial version of the question framework itself is here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I applied my insight framework to math if anyone wants to answer these:")#link("https://t.co/P5BufJQPoZ")[#text("https://t.co/P5BufJQPoZ")]

#text("— Sol Ver (@alienbot123) ")#link("https://twitter.com/alienbot123/status/775032969882963968?ref_src=twsrc%5Etfw")[#text("September 11, 2016")]
]

#text("I understand you’re extraordinarily busy so I don’t expect you to reply but if you do have a few minutes to look it over, I think it’s a worthwhile endeavor and feedback from you is welcome.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/11/course-announcement-246a-complex-analysis/#comment-689451")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2025")])]

#text("Prof Tao what are the prerequisites for this course？")
]
