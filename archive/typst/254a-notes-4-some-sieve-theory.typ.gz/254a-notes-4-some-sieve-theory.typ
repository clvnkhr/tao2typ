// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/
// Converted to Typst by tao2typ: "2026-10-14T16:37:37.190388+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 4: Some sieve theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 4: Some sieve theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 January 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Many problems in non-multiplicative prime number theory can be recast as ")#emph[#text("sieving")]#text(" problems. Consider for instance the problem of counting the number ")#mi("{N(x)}")#text(" of pairs of twin primes ")#mi("{p,p+2}")#text(" contained in ")#mi("{[x/2,x]}")#text(" for some large ")#mi("{x}")#text("; note that the claim that ")#mi("{N(x) > 0}")#text(" for arbitrarily large ")#mi("{x}")#text(" is equivalent to the twin prime conjecture. One can obtain this count by any of the following variants of the ")#link("http://en.wikipedia.org/wiki/Sieve_of_Eratosthenes")[#text("sieve of Eratosthenes")]#text(":")

#enum(start: 1, 
[#text("Let ")#mi("{A}")#text(" be the set of natural numbers in ")#mi("{[x/2,x-2]}")#text(". For each prime ")#mi("{p \\leq \\sqrt{x}}")#text(", let ")#mi("{E_p}")#text(" be the union of the residue classes ")#mi("{0\\ (p)}")#text(" and ")#mi("{-2\\ (p)}")#text(". Then ")#mi("{N(x)}")#text(" is the cardinality of the ")#emph[#text("sifted set")]#text(" ")#mi("{A \\backslash \\bigcup_{p \\leq \\sqrt{x}} E_p}")#text(".")],
[#text("Let ")#mi("{A}")#text(" be the set of primes in ")#mi("{[x/2,x-2]}")#text(". For each prime ")#mi("{p \\leq \\sqrt{x}}")#text(", let ")#mi("{E_p}")#text(" be the residue class ")#mi("{-2\\ (p)}")#text(". Then ")#mi("{N(x)}")#text(" is the cardinality of the ")#emph[#text("sifted set")]#text(" ")#mi("{A \\backslash \\bigcup_{p \\leq \\sqrt{x}} E_p}")#text(".")],
[#text("Let ")#mi("{A}")#text(" be the set of primes in ")#mi("{[x/2+2,x]}")#text(". For each prime ")#mi("{p \\leq \\sqrt{x}}")#text(", let ")#mi("{E_p}")#text(" be the residue class ")#mi("{2\\ (p)}")#text(". Then ")#mi("{N(x)}")#text(" is the cardinality of the ")#emph[#text("sifted set")]#text(" ")#mi("{A \\backslash \\bigcup_{p \\leq \\sqrt{x}} E_p}")#text(".")],
[#text("Let ")#mi("{A}")#text(" be the set ")#mi("{\\{ n(n+2): x/2 \\leq n \\leq x-2 \\}}")#text(". For each prime ")#mi("{p \\leq \\sqrt{x}}")#text(", let ")#mi("{E_p}")#text(" be the residue class ")#mi("{0\\ (p)}")#text(" Then ")#mi("{N(x)}")#text(" is the cardinality of the ")#emph[#text("sifted set")]#text(" ")#mi("{A \\backslash \\bigcup_{p \\leq \\sqrt{x}} E_p}")#text(".")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Develop similar sifting formulations of the other three ")#link("http://en.wikipedia.org/wiki/Landau%27s_problems")[#text("Landau problems")]#text(".")
]

#text("In view of these sieving interpretations of number-theoretic problems, it becomes natural to try to estimate the size of sifted sets ")#mi("{A \\backslash \\bigcup_{p | P} E_p}")#text(" for various finite sets ")#mi("{A}")#text(" of integers, and subsets ")#mi("{E_p}")#text(" of integers indexed by primes ")#mi("{p}")#text(" dividing some squarefree natural number ")#mi("{P}")#text(" (which, in the above examples, would be the product of all primes up to ")#mi("{\\sqrt{x}}")#text("). As we see in the above examples, the sets ")#mi("{E_p}")#text(" in applications are typically the union of one or more residue classes modulo ")#mi("{p}")#text(", but we will work at a more abstract level of generality here by treating ")#mi("{E_p}")#text(" as more or less arbitrary sets of integers, without caring too much about the arithmetic structure of such sets.")

#text("It turns out to be conceptually more natural to ")#link("http://www.tricki.org/article/Turn_sets_into_functions")[#text("replace sets by functions")]#text(", and to consider the more general the task of estimating sifted ")#emph[#text("sums")]#text(" ")#metadata(none) <tao-9360b9aa48a0507abdfa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{n \\in {\\bf Z}} a_n 1_{n \\not \\in \\bigcup_{p | P} E_p}")]]

#text("for some finitely supported sequence ")#mi("{(a_n)_{n \\in {\\bf Z}}}")#text(" of non-negative numbers; the previous combinatorial sifting problem then corresponds to the indicator function case ")#mi("{a_n=1_{n \\in A}}")#text(". (One could also use other index sets here than the integers ")#mi("{{\\bf Z}}")#text(" if desired; for much of sieve theory the index set and its subsets ")#mi("{E_p}")#text(" are treated as abstract sets, so the exact arithmetic structure of these sets is not of primary importance.)")

#text("Continuing with twin primes as a running example, we thus have the following sample sieving problem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 2 (Sieving problem for twin primes)")]#text(" ")#metadata(none) <tao-72b33a1cb0bfc9cdd3db>#text(" Let ")#mi("{x, z \\geq 1}")#text(", and let ")#mi("{\\pi_2(x,z)}")#text(" denote the number of natural numbers ")#mi("{n \\leq x}")#text(" which avoid the residue classes ")#mi("{0, -2\\ (p)}")#text(" for all primes ")#mi("{p < z}")#text(". In other words, we have")

#align(center)[#tao-fit-display[#mitex("\\pi_2(x,z) := \\sum_{n \\in {\\bf Z}} a_n 1_{n \\not \\in \\bigcup_{p | P(z)} E_p}")]]

#text("where ")#mi("{a_n := 1_{n \\in [1,x]}}")#text(", ")#mi("{P(z) := \\prod_{p < z} p}")#text(" is the product of all the primes strictly less than ")#mi("{z}")#text(" (we omit ")#mi("{z}")#text(" itself for minor technical reasons), and ")#mi("{E_p}")#text(" is the union of the residue classes ")#mi("{0, -2\\ (p)}")#text(". Obtain upper and lower bounds on ")#mi("{\\pi_2(x,z)}")#text(" which are as strong as possible in the asymptotic regime where ")#mi("{x}")#text(" goes to infinity and the ")#emph[#text("sifting level")]#text(" ")#mi("{z}")#text(" grows with ")#mi("{x}")#text(" (ideally we would like ")#mi("{z}")#text(" to grow as fast as ")#mi("{\\sqrt{x}}")#text(").")
]

#text("From the preceding discussion we know that the number of twin prime pairs ")#mi("{p,p+2}")#text(" in ")#mi("{(x/2,x]}")#text(" is equal to ")#mi("{\\pi_2(x-2,\\sqrt{x}) - \\pi_2(x/2,\\sqrt{x})}")#text(", if ")#mi("{x}")#text(" is not a perfect square; one also easily sees that the number of twin prime pairs in ")#mi("{[1,x]}")#text(" is at least ")#mi("{\\pi_2(x-2,\\sqrt{x})}")#text(", again if ")#mi("{x}")#text(" is not a perfect square. Thus we see that a sufficiently good answer to Problem ")#link(<tao-72b33a1cb0bfc9cdd3db>)[#text("2")]#text(" would resolve the twin prime conjecture, particularly if we can get the sifting level ")#mi("{z}")#text(" to be as large as ")#mi("{\\sqrt{x}}")#text(".")

#text("We return now to the general problem of estimating ")#link(<tao-9360b9aa48a0507abdfa>)[#text("(1)")]#text(". We may expand ")#metadata(none) <tao-c1299854f2b209632ab2>

#tao-aligned(keep: true)[


#tao-math("1_{n \\not \\in \\bigcup_{p | P} E_p}  & = \\prod_{p | P} (1 - 1_{E_p}(n))", block: true, numbering: n => [#text("(2)")])



#tao-math(" & = \\sum_{k=0}^\\infty (-1)^k \\sum_{p_1 \\dots p_k|P: p_1 < \\dots < p_k} 1_{E_{p_1}} \\dots 1_{E_{p_k}}(n)", block: true)



#tao-math(" & = \\sum_{d|P} \\mu(d) 1_{E_d}(n)", block: true)
]

#text("where ")#mi("{E_d := \\bigcap_{p|d} E_p}")#text(" (with the convention that ")#mi("{E_1={\\bf Z}}")#text("). We thus arrive at the ")#link("http://en.wikipedia.org/wiki/Legendre_sieve")[#text("Legendre sieve identity")]#text(" ")#metadata(none) <tao-a05f15a8ff8ed7db4ce7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{n \\in {\\bf Z}} a_n 1_{n \\not \\in \\bigcup_{p | P} E_p} = \\sum_{d|P} \\mu(d) \\sum_{n \\in E_d} a_n.")]]

#text("Specialising to the case of an indicator function ")#mi("{a_n=1_{n \\in A}}")#text(", we recover the ")#link("http://en.wikipedia.org/wiki/Inclusion%E2%80%93exclusion_principle")[#text("inclusion-exclusion formula")]

#align(center)[#tao-fit-display[#tao-math("\\left|A \\backslash \\bigcup_{p|P} E_p\\right| = \\sum_{d|P} \\mu(d) |A \\cap E_d|.", block: true)]]

#text("Such exact sieving formulae are already satisfactory for controlling sifted sets or sifted sums when the amount of sieving is relatively small compared to the size of ")#mi("{A}")#text(". For instance, let us return to the running example in Problem ")#link(<tao-72b33a1cb0bfc9cdd3db>)[#text("2")]#text(" for some ")#mi("{x,z \\geq 1}")#text(". Observe that each ")#mi("{E_p}")#text(" in this example consists of ")#mi("{\\omega(p)}")#text(" residue classes modulo ")#mi("{p}")#text(", where ")#mi("{\\omega(p)}")#text(" is defined to equal ")#mi("{1}")#text(" when ")#mi("{p=2}")#text(" and ")#mi("{2}")#text(" when ")#mi("{p}")#text(" is odd. By the Chinese remainder theorem, this implies that for each ")#mi("{d|P(z)}")#text(", ")#mi("{E_d}")#text(" consists of ")#mi("{\\prod_{p|d} \\omega(p)}")#text(" residue classes modulo ")#mi("{d}")#text(". Using the basic bound ")#metadata(none) <tao-c2e247c17cfbff4bdc36>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{n \\leq x: n = a\\ (q)} 1 = \\frac{x}{q} + O(1)")]]

#text("for any ")#mi("{x > 0}")#text(" and any residue class ")#mi("{a\\ (q)}")#text(", we conclude that ")#metadata(none) <tao-e96e02d8e47f2a7c03be>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{n \\in E_d} a_n = g(d) x + O( \\prod_{p|d} \\omega(p) )")]]

#text("for any ")#mi("{d|P(z)}")#text(", where ")#mi("{g}")#text(" is the multiplicative function")

#align(center)[#tao-fit-display[#mitex("g(d) := \\prod_{p|d: p|P(z)} \\frac{\\omega(p)}{p}.")]]

#text("Since ")#mi("{\\omega(p) \\leq 2}")#text(" and there are at most ")#mi("{\\pi(z)}")#text(" primes dividing ")#mi("{P(z)}")#text(", we may crudely bound ")#mi("{\\prod_{p|d} \\omega(p) \\leq 2^{\\pi(z)}}")#text(", thus ")#metadata(none) <tao-d2413b1ea4c7bd8a1046>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{n \\in E_d} a_n = g(d) x + O( 2^{\\pi(z)} ).")]]

#text("Also, the number of divisors of ")#mi("{P(z)}")#text(" is at most ")#mi("{2^{\\pi(z)}}")#text(". From the Legendre sieve ")#link(<tao-a05f15a8ff8ed7db4ce7>)[#text("(3)")]#text(", we thus conclude that")

#align(center)[#tao-fit-display[#mitex("\\pi_2(x,z) = (\\sum_{d|P(z)} \\mu(d) g(d) x) + O( 4^{\\pi(z)} ).")]]

#text("We can factorise the main term to obtain")

#align(center)[#tao-fit-display[#mitex("\\pi_2(x,z) = x \\prod_{p < z} (1-\\frac{\\omega(p)}{p}) + O( 4^{\\pi(z)} ).")]]

#text("This is compatible with the heuristic ")#metadata(none) <tao-bcbb0eeac8d6a4240d57>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\pi_2(x,z) \\approx x \\prod_{p < z} (1-\\frac{\\omega(p)}{p})")]]

#text("coming from the equidistribution of residues principle (Section 3 of ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text("), bearing in mind (from the modified Cramér model, see Section 1 of ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text(") that we expect this heuristic to become inaccurate when ")#mi("{z}")#text(" becomes very large. We can simplify the right-hand side of ")#link(<tao-bcbb0eeac8d6a4240d57>)[#text("(7)")]#text(" by recalling the ")#link("http://mathworld.wolfram.com/TwinPrimesConstant.html")[#text("twin prime constant")]

#align(center)[#tao-fit-display[#mitex("\\Pi_2 := \\prod_{p>2} (1 - \\frac{1}{(p-1)^2}) = 0.6601618\\dots")]]

#text("(see equation (7) from ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text("); note that")

#align(center)[#tao-fit-display[#mitex("\\prod_p (1-\\frac{1}{p})^{-2} (1-\\frac{\\omega(p)}{p}) = 2 \\Pi_2")]]

#text("so from Mertens’ third theorem (Theorem 42 from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(") one has ")#metadata(none) <tao-7f1f073d8bb9b2e3ad6c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\prod_{p < z} (1-\\frac{\\omega(p)}{p}) = (2\\Pi_2+o(1)) \\frac{1}{(e^\\gamma \\log z)^2}")]]

#text("as ")#mi("{z \\rightarrow \\infty}")#text(". Bounding ")#mi("{4^{\\pi(z)}}")#text(" crudely by ")#mi("{\\exp(o(z))}")#text(", we conclude in particular that")

#align(center)[#tao-fit-display[#mitex("\\pi_2(x,z) = (2\\Pi_2 +o(1)) \\frac{x}{(e^\\gamma \\log z)^2}")]]

#text("when ")#mi("{x,z \\rightarrow \\infty}")#text(" with ")#mi("{z = O(\\log x)}")#text(". This is somewhat encouraging for the purposes of getting a sufficiently good answer to Problem ")#link(<tao-72b33a1cb0bfc9cdd3db>)[#text("2")]#text(" to resolve the twin prime conjecture, but note that ")#mi("{z}")#text(" is currently far too small: one needs to get ")#mi("{z}")#text(" as large as ")#mi("{\\sqrt{x}}")#text(" before one is counting twin primes, and currently ")#mi("{z}")#text(" can only get as large as ")#mi("{\\log x}")#text(".")

#text("The problem is that the number of terms in the Legendre sieve ")#link(<tao-a05f15a8ff8ed7db4ce7>)[#text("(3)")]#text(" basically grows exponentially in ")#mi("{z}")#text(", and so the error terms in ")#link(<tao-c2e247c17cfbff4bdc36>)[#text("(4)")]#text(" accumulate to an unacceptable extent once ")#mi("{z}")#text(" is significantly larger than ")#mi("{\\log x}")#text(". An alternative way to phrase this problem is that the estimate ")#link(<tao-c2e247c17cfbff4bdc36>)[#text("(4)")]#text(" is only expected to be truly useful in the regime ")#mi("{q=o(x)}")#text("; on the other hand, the moduli ")#mi("{d}")#text(" appearing in ")#link(<tao-a05f15a8ff8ed7db4ce7>)[#text("(3)")]#text(" can be as large as ")#mi("{P}")#text(", which grows exponentially in ")#mi("{z}")#text(" by the prime number theorem.")

#text("To resolve this problem, it is thus natural to try to ")#emph[#text("truncate")]#text(" the Legendre sieve, in such a way that one only uses information about the sums ")#mi("{\\sum_{n \\in E_d} a_n}")#text(" for a relatively small number of divisors ")#mi("{d}")#text(" of ")#mi("{P}")#text(", such as those ")#mi("{d}")#text(" which are below a certain threshold ")#mi("{D}")#text(". This leads to the following general sieving problem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 3 (General sieving problem)")]#text(" ")#metadata(none) <tao-393b668e2d7b1702441b>#text(" Let ")#mi("{P}")#text(" be a squarefree natural number, and let ")#mi("{{\\mathcal D}}")#text(" be a set of divisors of ")#mi("{P}")#text(". For each prime ")#mi("{p}")#text(" dividing ")#mi("{P}")#text(", let ")#mi("{E_p}")#text(" be a set of integers, and define ")#mi("{E_d := \\bigcap_{p|d} E_p}")#text(" for all ")#mi("{d|P}")#text(" (with the convention that ")#mi("{E_1={\\bf Z}}")#text("). Suppose that ")#mi("{(a_n)_{n \\in {\\bf Z}}}")#text(" is an (unknown) finitely supported sequence of non-negative reals, whose sums ")#metadata(none) <tao-61205ff0d3a9688d0959>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("X_d := \\sum_{n \\in E_d} a_n")]]

#text("are known for all ")#mi("{d \\in {\\mathcal D}}")#text(". What are the best upper and lower bounds one can conclude on the quantity ")#link(<tao-9360b9aa48a0507abdfa>)[#text("(1)")]#text("?")
]

#text("Here is a simple example of this type of problem (corresponding to the case ")#mi("{P = 6}")#text(", ")#mi("{{\\mathcal D} = \\{1, 2, 3\\}}")#text(", ")#mi("{X_1 = 100}")#text(", ")#mi("{X_2 = 60}")#text(", and ")#mi("{X_3 = 10}")#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" ")#metadata(none) <tao-97c10efe01d5c9c88704>#text(" Let ")#mi("{(a_n)_{n \\in {\\bf Z}}}")#text(" be a finitely supported sequence of non-negative reals such that ")#mi("{\\sum_{n \\in {\\bf Z}} a_n = 100}")#text(", ")#mi("{\\sum_{n \\in {\\bf Z}: 2|n} a_n = 60}")#text(", and ")#mi("{\\sum_{n \\in {\\bf Z}: 3|n} a_n = 10}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("30 \\leq \\sum_{n \\in {\\bf Z}: (n,6)=1} a_n \\leq 40")]]

#text("and give counterexamples to show that these bounds cannot be improved in general, even when ")#mi("{a_n}")#text(" is an indicator function sequence.")
]

#text("Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(" is an example of a ")#link("http://en.wikipedia.org/wiki/Linear_programming")[#text("linear programming")]#text(" problem. By using ")#link("http://en.wikipedia.org/wiki/Linear_programming#Duality")[#text("linear programming duality")]#text(" (as encapsulated by results such as the ")#link("http://en.wikipedia.org/wiki/Hahn%E2%80%93Banach_theorem")[#text("Hahn-Banach theorem")]#text(", the ")#link("http://en.wikipedia.org/wiki/Separating_hyperplane_theorem")[#text("separating hyperplane theorem")]#text(", or the ")#link("http://en.wikipedia.org/wiki/Farkas%27_lemma")[#text("Farkas lemma")]#text("), we can rephrase the above problem in terms of ")#emph[#text("upper and lower bound sieves")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Dual sieve problem)")]#text(" ")#metadata(none) <tao-a0d950705fa91bbdd0f2>#text(" Let ")#mi("{P, {\\mathcal D}, E_p, E_d, X_d}")#text(" be as in Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(". We assume that Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(" is ")#emph[#text("feasible")]#text(", in the sense that there exists at least one finitely supported sequence ")#mi("{(a_n)_{n \\in {\\bf Z}}}")#text(" of non-negative reals obeying the constraints in that problem. Define an (normalised) ")#emph[#text("upper bound sieve")]#text(" to be a function ")#mi("{\\nu^+: {\\bf Z} \\rightarrow {\\bf R}}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("\\nu^+ = \\sum_{d \\in {\\mathcal D}} \\lambda^+_d 1_{E_d}")]]

#text("for some coefficients ")#mi("{\\lambda^+_d \\in {\\bf R}}")#text(", and obeying the pointwise lower bound ")#metadata(none) <tao-1e2a7776cbcf61a6ea4d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\nu^+(n) \\geq 1_{n \\not \\in\\bigcup_{p|P} E_p}(n)")]]

#text("for all ")#mi("{n \\in {\\bf Z}}")#text(" (in particular ")#mi("{\\nu^+}")#text(" is non-negative). Similarly, define a (normalised) ")#emph[#text("lower bound sieve")]#text(" to be a function ")#mi("{\\nu^-: {\\bf Z} \\rightarrow {\\bf R}}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("\\nu^-(n) = \\sum_{d \\in {\\mathcal D}} \\lambda^-_d 1_{E_d}")]]

#text("for some coefficients ")#mi("{\\lambda^-_d \\in {\\bf R}}")#text(", and obeying the pointwise upper bound")

#align(center)[#tao-fit-display[#mitex("\\nu^-(n) \\leq 1_{n \\not \\in\\bigcup_{p|P} E_p}(n)")]]

#text("for all ")#mi("{n \\in {\\bf Z}}")#text(". Thus for instance ")#mi("{1}")#text(" and ")#mi("{0}")#text(" are (trivially) upper bound sieves and lower bound sieves respectively.")

#list(
[#text("(i) The supremal value of the quantity ")#link(<tao-9360b9aa48a0507abdfa>)[#text("(1)")]#text(", subject to the constraints in Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(", is equal to the infimal value of the quantity ")#mi("{\\sum_{d \\in {\\mathcal D}} \\lambda^+_d X_d}")#text(", as ")#mi("{\\nu^+ = \\sum_{d \\in {\\mathcal D}} \\lambda^+_d 1_{E_d}}")#text(" ranges over all upper bound sieves.")],
[#text("(ii) The infimal value of the quantity ")#link(<tao-9360b9aa48a0507abdfa>)[#text("(1)")]#text(", subject to the constraints in Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(", is equal to the supremal value of the quantity ")#mi("{\\sum_{d \\in {\\mathcal D}} \\lambda^-_d X_d}")#text(", as ")#mi("{\\nu^- = \\sum_{d \\in {\\mathcal D}} \\lambda^-_d 1_{E_d}}")#text(" ranges over all lower bound sieves.")]
)
]

#emph[#text("Proof:")]#text(" We prove part (i) only, and leave part (ii) as an exercise. Let ")#mi("{A}")#text(" be the supremal value of the quantity ")#link(<tao-9360b9aa48a0507abdfa>)[#text("(1)")]#text(" given the constraints in Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(", and let ")#mi("{B}")#text(" be the infimal value of ")#mi("{\\sum_{d \\in {\\mathcal D}} \\lambda^+_d X_d}")#text(". We need to show that ")#mi("{A=B}")#text(".")

#text("We first establish the easy inequality ")#mi("{A \\leq B}")#text(". If the sequence ")#mi("{a_n}")#text(" obeys the constraints in Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(", and ")#mi("{\\nu^+ = \\sum_{d \\in {\\mathcal D}} \\lambda^+_d 1_{E_d}}")#text(" is an upper bound sieve, then")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\nu^+(n) a_n = \\sum_{d \\in {\\mathcal D}} \\lambda^+_d X_d")]]

#text("and hence (by the non-negativity of ")#mi("{\\nu^+}")#text(" and ")#mi("{a_n}")#text(")")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\not \\in \\bigcup_{p|P} E_p} a_n \\leq \\sum_{d \\in {\\mathcal D}} \\lambda^+_d X_d;")]]

#text("taking suprema in ")#mi("{f}")#text(" and infima in ")#mi("{\\nu^+}")#text(" we conclude that ")#mi("{A \\leq B}")#text(".")

#text("Now suppose for contradiction that ")#mi("{A<B}")#text(", thus ")#mi("{A < C < B}")#text(" for some real number ")#mi("{C}")#text(". We will argue using the ")#link("http://en.wikipedia.org/wiki/Separating_hyperplane_theorem")[#text("hyperplane separation theorem")]#text("; one can also proceed using one of the other duality results mentioned above. (See ")#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/")[#text("this previous blog post")]#text(" for some discussion of the connections between these various forms of linear duality.) Consider the affine functional")

#align(center)[#tao-fit-display[#mitex("\\rho_0: (a_n)_{n \\in{\\bf Z}} \\mapsto C - \\sum_{n \\not \\in \\bigcup_{p|P} E_p} a_n.")]]

#text("on the vector space of finitely supported sequences ")#mi("{(a_n)_{n \\in {\\bf Z}}}")#text(" of reals. On the one hand, since ")#mi("{C > A}")#text(", this functional is positive for every sequence ")#mi("{(a_n)_{n \\in{\\bf Z}}}")#text(" obeying the constraints in Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(". Next, let ")#mi("{K}")#text(" be the space of affine functionals ")#mi("{\\rho}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("\\rho: (a_n)_{n \\in {\\bf Z}} \\mapsto -\\sum_{d \\in {\\mathcal D}} \\lambda^+_d ( \\sum_{n \\in E_d} a_n - X_d ) + \\sum_n a_n \\nu(n) + X")]]

#text("for some real numbers ")#mi("{\\lambda^+_d \\in {\\bf R}}")#text(", some non-negative function ")#mi("{\\nu: {\\bf Z} \\rightarrow {\\bf R}^+}")#text(" which is a finite linear combination of the ")#mi("{1_{E_d}}")#text(" for ")#mi("{d|P}")#text(", and some non-negative ")#mi("{X}")#text(". This is a closed convex cone in a finite-dimensional vector space ")#mi("{V}")#text("; note also that ")#mi("{\\rho_0}")#text(" lies in ")#mi("{V}")#text(". Suppose first that ")#mi("{\\rho_0 \\in K}")#text(", thus we have a representation of the form")

#align(center)[#tao-fit-display[#mitex("C - \\sum_{n \\not \\in \\bigcup_{p|P} E_p} a_n = -\\sum_{d \\in {\\mathcal D}} \\lambda^+_d ( \\sum_{n \\in E_d} a_n - X_d ) + \\sum_n a_n \\nu(n) + X")]]

#text("for any finitely supported sequence ")#mi("{(a_n)_{n \\in {\\bf Z}}}")#text(". Comparing coefficients, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\in {\\mathcal D}} \\lambda^+_d 1_{E_d}(n) \\geq 1_{n \\not \\in \\bigcup_{p|P} E_p}")]]

#text("for any ")#mi("{n}")#text(" (i.e., ")#mi("{\\sum_{d \\in {\\mathcal D}} \\lambda^+_d 1_{E_d}}")#text(" is an upper bound sieve), and also")

#align(center)[#tao-fit-display[#mitex("C \\geq \\sum_{d \\in {\\mathcal D}} \\lambda^+_d X_d,")]]

#text("and thus ")#mi("{C \\geq B}")#text(", a contradiction. Thus ")#mi("{\\rho_0}")#text(" lies outside of ")#mi("{K}")#text(". But then by the hyperplane separation theorem, we can find an affine functional ")#mi("{\\iota: V \\rightarrow {\\bf R}}")#text(" on ")#mi("{V}")#text(" that is non-negative on ")#mi("{K}")#text(" and negative on ")#mi("{\\rho_0}")#text(". By duality, such an affine functional takes the form ")#mi("{\\iota: \\rho \\mapsto \\rho((b_n)_{n \\in {\\bf Z}}) + c}")#text(" for some finitely supported sequence ")#mi("{(b_n)_{n \\in {\\bf Z}}}")#text(" and ")#mi("{c \\in {\\bf R}}")#text(" (indeed, ")#mi("{(b_n)_{n \\in {\\bf Z}}}")#text(" can be supported on a finite set consisting of a single representative for each atom of the finite ")#mi("{\\sigma}")#text("-algebra generated by the ")#mi("{E_p}")#text("). Since ")#mi("{\\iota}")#text(" is non-negative on the cone ")#mi("{K}")#text(", we see (on testing against multiples of the functionals ")#mi("{(a_n)_{n \\in {\\bf Z}} \\mapsto \\sum_{n \\in E_d} a_n - X_d}")#text(" or ")#mi("{(a_n)_{n \\in {\\bf Z}} \\mapsto a_n}")#text(") that the ")#mi("{b_n}")#text(" and ")#mi("{c}")#text(" are non-negative, and that ")#mi("{\\sum_{n \\in E_d} b_n - X_d = 0}")#text(" for all ")#mi("{d \\in {\\mathcal D}}")#text("; thus ")#mi("{(b_n)_{n \\in {\\bf Z}}}")#text(" is feasible for Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(". Since ")#mi("{\\iota}")#text(" is negative on ")#mi("{\\rho_0}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\not \\in \\bigcup_{p|P} E_p} b_n \\geq C")]]

#text("and thus ")#mi("{A \\geq C}")#text(", giving the desired contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Prove part (ii) of the above theorem.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Show that the infima and suprema in the above theorem are actually attained (so one can replace “infimal” and “supremal” by “minimal” and “maximal” if desired).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" ")#metadata(none) <tao-284792493bd06ae32c30>#text(" What are the optimal upper and lower bound sieves for Exercise ")#link(<tao-97c10efe01d5c9c88704>)[#text("4")]#text("?")
]

#text("In the case when ")#mi("{{\\mathcal D}}")#text(" consists of ")#emph[#text("all")]#text(" the divisors of ")#mi("{P}")#text(", we see that the Legendre sieve ")#mi("{\\sum_{d|P} \\mu(d) 1_{E_d}}")#text(" is both the optimal upper bound sieve and the optimal lower bound sieve, regardless of what the quantities ")#mi("{X_d}")#text(" are. However, in most cases of interest, ")#mi("{{\\mathcal D}}")#text(" will only be some strict subset of the divisors of ")#mi("{P}")#text(", and there will be a gap between the optimal upper and lower bounds.")

#text("Observe that a sequence ")#mi("{(\\lambda^+_d)_{d \\in {\\mathcal D}}}")#text(" of real numbers will form an upper bound sieve ")#mi("{\\sum_d \\lambda^+_d 1_{E_d}}")#text(" if one has the inequalities")

#align(center)[#tao-fit-display[#mitex("\\lambda^+_1 \\geq 1")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sum_{d|n} \\lambda^+_d \\geq 0")]]

#text("for all ")#mi("{n|P}")#text("; we will refer to such sequences as ")#emph[#text("upper bound sieve coefficients")]#text(". (Conversely, if the sets ")#mi("{E_p}")#text(" are in “general position” in the sense that every set of the form ")#mi("{\\bigcap_{p|n} E_p \\backslash \\bigcup_{p|P; p\\not | n} E_p}")#text(" for ")#mi("{n|P}")#text(" is non-empty, we see that every upper bound sieve arises from a sequence of upper bound sieve coefficients.) Similarly, a sequence ")#mi("{(\\lambda^-_d)_{d \\in {\\mathcal D}}}")#text(" of real numbers will form a lower bound sieve ")#mi("{\\sum_d \\lambda^-_d 1_{E_d}}")#text(" if one has the inequalities")

#align(center)[#tao-fit-display[#mitex("\\lambda^-_1 \\leq 1")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sum_{d|n} \\lambda^-_d \\leq 0")]]

#text("for all ")#mi("{n|P}")#text(" with ")#mi("{n>1}")#text("; we will refer to such sequences as ")#emph[#text("lower bound sieve coefficients")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9 (Brun pure sieve)")]#text(" ")#metadata(none) <tao-72b90a0d25a6e8f71d5f>#text(" Let ")#mi("{P}")#text(" be a squarefree number, and ")#mi("{k}")#text(" a non-negative integer. Show that the sequence ")#mi("{(\\lambda_d)_{d | P}}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("\\lambda_d := 1_{\\omega(d) \\leq k} \\mu(d),")]]

#text("where (in contrast with the rest of this set of notes) ")#mi("{\\omega(d)}")#text(" denotes the number of prime factors of ")#mi("{d}")#text(", is a sequence of upper bound sieve coefficients for even ")#mi("{k}")#text(", and a sequence of lower bound sieve coefficients for odd ")#mi("{k}")#text(". Deduce the ")#link("http://mathworld.wolfram.com/BonferroniInequalities.html")[#text("Bonferroni inequalities")]#text(" ")#metadata(none) <tao-473772cbd14daeaec014>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\sum_{n \\in {\\bf Z}} a_n 1_{n \\not \\in \\bigcup_{p | P} E_p} \\leq \\sum_{d|P: \\omega(d) \\leq k} \\mu(d) X_d")]]

#text("when ")#mi("{k}")#text(" is even, and ")#metadata(none) <tao-c1cdf5175700b9582645>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\sum_{n \\in {\\bf Z}} a_n 1_{n \\not \\in \\bigcup_{p | P} E_p} \\geq \\sum_{d|P: \\omega(d) \\leq k} \\mu(d) X_d")]]

#text("when ")#mi("{k}")#text(" is odd, whenever one is in the situation of Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(" (and ")#mi("{{\\mathcal D}}")#text(" contains all ")#mi("{d|P}")#text(" with ")#mi("{\\omega(d) \\leq k}")#text("). The resulting upper and lower bound sieves are sometimes known as ")#emph[#text("Brun pure sieves")]#text(". The Legendre sieve can be viewed as the limiting case when ")#mi("{k \\geq \\omega(P)}")#text(".")
]

#text("In many applications the sums ")#mi("{X_d}")#text(" in ")#link(<tao-61205ff0d3a9688d0959>)[#text("(9)")]#text(" take the form ")#metadata(none) <tao-362a284952d3a7250e4b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\sum_{n \\in E_d} a_n = g(d) X + r_d")]]

#text("for some quantity ")#mi("{X}")#text(" independent of ")#mi("{d}")#text(", some multiplicative function ")#mi("{g}")#text(" with ")#mi("{0 \\leq g(p) \\leq 1}")#text(", and some remainder term ")#mi("{r_d}")#text(" whose effect is expected to be negligible on average if ")#mi("{d}")#text(" is restricted to be small, e.g. less than a threshold ")#mi("{D}")#text("; note for instance that ")#link(<tao-e96e02d8e47f2a7c03be>)[#text("(5)")]#text(" is of this form if ")#mi("{D \\leq x^{1-\\varepsilon}}")#text(" for some fixed ")#mi("{\\varepsilon>0}")#text(" (note from the divisor bound, Lemma 23 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(", that ")#mi("{\\prod_{p|d} \\omega(p) \\ll x^{o(1)}}")#text(" if ")#mi("{d \\ll x^{O(1)}}")#text("). We are thus led to the following idealisation of the sieving problem, in which the remainder terms ")#mi("{r_d}")#text(" are ignored:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 10 (Idealised sieving)")]#text(" ")#metadata(none) <tao-cbc8a8ffa86a593fb890>#text(" Let ")#mi("{z, D \\geq 1}")#text(" (we refer to ")#mi("{z}")#text(" as the ")#emph[#text("sifting level")]#text(" and ")#mi("{D}")#text(" as the ")#emph[#text("level of distribution")]#text("), let ")#mi("{g}")#text(" be a multiplicative function with ")#mi("{0 \\leq g(p) \\leq 1}")#text(", and let ")#mi("{{\\mathcal D} := \\{ d|P(z): d \\leq D \\}}")#text(". How small can one make the quantity ")#metadata(none) <tao-b2fec115043348fde0ca>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\sum_{d \\in {\\mathcal D}} \\lambda^+_d g(d)")]]

#text("for a sequence ")#mi("{(\\lambda^+_d)_{d \\in {\\mathcal D}}}")#text(" of upper bound sieve coefficients, and how large can one make the quantity ")#metadata(none) <tao-e32c325b4bb236b62f58>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\sum_{d \\in {\\mathcal D}} \\lambda^-_d g(d)")]]

#text("for a sequence ")#mi("{(\\lambda^-_d)_{d \\in {\\mathcal D}}}")#text(" of lower bound sieve coefficients?")
]

#text("Thus, for instance, the trivial upper bound sieve ")#mi("{\\lambda^+_d := 1_{d=1}}")#text(" and the trivial lower bound sieve ")#mi("{\\lambda^-_d := 0}")#text(" show that ")#link(<tao-b2fec115043348fde0ca>)[#text("(14)")]#text(" can equal ")#mi("{1}")#text(" and ")#link(<tao-e32c325b4bb236b62f58>)[#text("(15)")]#text(" can equal ")#mi("{0}")#text(". Of course, one hopes to do better than these trivial bounds in many situations; usually one can improve the upper bound quite substantially, but improving the lower bound is significantly more difficult, particularly when ")#mi("{z}")#text(" is large compared with ")#mi("{D}")#text(".")

#text("If the remainder terms ")#mi("{r_d}")#text(" in ")#link(<tao-362a284952d3a7250e4b>)[#text("(13)")]#text(" are indeed negligible on average for ")#mi("{d \\leq D}")#text(", then one expects the upper and lower bounds in Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(" to essentially be the optimal bounds in ")#link(<tao-b2fec115043348fde0ca>)[#text("(14)")]#text(" and ")#link(<tao-e32c325b4bb236b62f58>)[#text("(15)")]#text(" respectively, multiplied by the normalisation factor ")#mi("{X}")#text(". Thus Problem ")#link(<tao-cbc8a8ffa86a593fb890>)[#text("10")]#text(" serves as a good model problem for Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(", in which all the arithmetic content of the original sieving problem has been abstracted into two parameters ")#mi("{z,D}")#text(" and a multiplicative function ")#mi("{g}")#text(". In many applications, ")#mi("{g(p)}")#text(" will be approximately ")#mi("{\\kappa/p}")#text(" on the average for some fixed ")#mi("{\\kappa>0}")#text(", known as the ")#emph[#text("sieve dimension")]#text("; for instance, in the twin prime sieving problem discussed above, the sieve dimension is ")#mi("{2}")#text(". The larger one makes the level of distribution ")#mi("{D}")#text(" compared to ")#mi("{z}")#text(", the more choices one has for the upper and lower bound sieves; it is thus of interest to obtain equidistribution estimates such as ")#link(<tao-362a284952d3a7250e4b>)[#text("(13)")]#text(" for ")#mi("{d}")#text(" as large as possible. When the sequence ")#mi("{a_d}")#text(" is of arithmetic origin (for instance, if it is the von Mangoldt function ")#mi("{\\Lambda}")#text("), then estimates such as the Bombieri-Vinogradov theorem, Theorem 17 from ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("Notes 3")]#text(", turn out to be particularly useful in this regard; in other contexts, the required equidistribution estimates might come from other sources, such as homogeneous dynamics, or the theory of expander graphs (the latter arises in the recent theory of the ")#emph[#text("affine sieve")]#text(", discussed in ")#link("https://terrytao.wordpress.com/2012/03/01/254b-notes-7-sieving-and-expanders/")[#text("this previous blog post")]#text("). However, the sieve-theoretic tools developed in this post are not particularly sensitive to ")#emph[#text("how")]#text(" a certain level of distribution is attained, and are generally content to use sieve axioms such as ")#link(<tao-362a284952d3a7250e4b>)[#text("(13)")]#text(" as “black boxes”.")

#text("In some applications one needs to modify Problem ")#link(<tao-cbc8a8ffa86a593fb890>)[#text("10")]#text(" in various technical ways (e.g. in altering the product ")#mi("{P(z)}")#text(", the set ")#mi("{{\\mathcal D}}")#text(", or the definition of an upper or lower sieve coefficient sequence), but to simplify the exposition we will focus on the above problem without such alterations.")

#text("As the exercise below (or the heuristic ")#link(<tao-bcbb0eeac8d6a4240d57>)[#text("(7)")]#text(") suggests, the “natural” size of ")#link(<tao-b2fec115043348fde0ca>)[#text("(14)")]#text(" and ")#link(<tao-e32c325b4bb236b62f58>)[#text("(15)")]#text(" is given by the quantity ")#mi("{V(z) := \\prod_{p < z} (1 - g(p))}")#text(" (so that the natural size for Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(" is ")#mi("{V(z) X}")#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Let ")#mi("{z,D,g}")#text(" be as in Problem ")#link(<tao-cbc8a8ffa86a593fb890>)[#text("10")]#text(", and set ")#mi("{V(z) := \\prod_{p \\leq z} (1 - g(p))}")#text(".")

#list(
[#text("(i) Show that the quantity ")#link(<tao-b2fec115043348fde0ca>)[#text("(14)")]#text(" is always at least ")#mi("{V(z)}")#text(" when ")#mi("{(\\lambda^+_d)_{d \\in {\\mathcal D}}}")#text(" is a sequence of upper bound sieve coefficients. Similarly, show that the quantity ")#link(<tao-e32c325b4bb236b62f58>)[#text("(15)")]#text(" is always at most ")#mi("{V(z)}")#text(" when ")#mi("{(\\lambda^-_d)_{d \\in {\\mathcal D}}}")#text(" is a sequence of lower bound sieve coefficients. (")#emph[#text("Hint:")]#text(" compute the expected value of ")#mi("{\\sum_{d|n} \\lambda^\\pm_d}")#text(" when ")#mi("{n}")#text(" is a random factor of ")#mi("{P(z)}")#text(" chosen according to a certain probability distribution depending on ")#mi("{g}")#text(".)")],
[#text("(ii) Show that ")#link(<tao-b2fec115043348fde0ca>)[#text("(14)")]#text(" and ")#link(<tao-e32c325b4bb236b62f58>)[#text("(15)")]#text(" can both attain the value of ")#mi("{V(z)}")#text(" when ")#mi("{D \\geq P(z)}")#text(". (")#emph[#text("Hint:")]#text(" translate the Legendre sieve to this setting.)")]
)
]

#text("The problem of finding good sequences of upper and lower bound sieve coefficients in order to solve problems such as Problem ")#link(<tao-cbc8a8ffa86a593fb890>)[#text("10")]#text(" is one of the core objectives of sieve theory, and has been intensively studied. This is more of an optimisation problem rather than a genuinely number theoretic problem; however, the optimisation problem is sufficiently complicated that it has not been solved exactly or even asymptotically, except in a few special cases. (It can be reduced to a optimisation problem involving multilinear integrals of certain unknown functions of several variables, but this problem is rather difficult to analyse further; see ")#link("http://www.ams.org/mathscinet-getitem?mr=1295844")[#text("these lecture notes of Selberg")]#text(" for further discussion.) But while we do not yet have a definitive solution to this problem in general, we do have a number of good general-purpose upper and lower bound sieve coefficients that give fairly good values for ")#link(<tao-b2fec115043348fde0ca>)[#text("(14)")]#text(", ")#link(<tao-e32c325b4bb236b62f58>)[#text("(15)")]#text(", often coming within a constant factor of the idealised value ")#mi("{V(z)}")#text(", and which work well for sifting levels ")#mi("{z}")#text(" as large as a small power of the level of distribution ")#mi("{D}")#text(". Unfortunately, we also know of an important limitation to the sieve, known as the ")#emph[#text("parity problem")]#text(", that prevents one from taking ")#mi("{z}")#text(" as large as ")#mi("{D^{1/2}}")#text(" while still obtaining non-trivial lower bounds; as a consequence, sieve theory is not able, on its own, to sift out primes for such purposes as establishing the twin prime conjecture. However, it is still possible to use these sieves, in conjunction with additional tools, to produce various types of primes or prime patterns in some cases; examples of this include ")#link("http://en.wikipedia.org/wiki/Green%E2%80%93Tao_theorem")[#text("the theorem of Ben Green and myself")]#text(" in which an upper bound sieve is used to demonstrate the existence of primes in arbitrarily long arithmetic progressions, or the more recent ")#link("http://www.ams.org/mathscinet-getitem?mr=2552109")[#text("theorem of Zhang")]#text(" in which an upper bound sieve (among other things) was used to demonstrate the existence of infinitely many pairs of primes whose difference was bounded. In such arguments, the upper bound sieve was used not so much to count the primes or prime patterns directly, but to serve instead as a sort of “container” to efficiently envelop such prime patterns; when used in such a manner, the upper bound sieves are sometimes known as ")#emph[#text("enveloping sieves")]#text(". If the original sequence was supported on primes, then the enveloping sieve can be viewed as a “smoothed out indicator function” that is concentrated on ")#emph[#text("almost primes")]#text(", which in this context refers to numbers with no small prime factors.")

#text("In a somewhat different direction, it can be possible in some cases to break the parity barrier by assuming additional equidistribution axioms on the sequence ")#mi("{a_n}")#text(" than just ")#link(<tao-362a284952d3a7250e4b>)[#text("(13)")]#text(", in particular controlling certain ")#emph[#text("bilinear")]#text(" sums involving ")#mi("{a_{nm}}")#text(" rather than just ")#emph[#text("linear")]#text(" sums of the ")#mi("{a_n}")#text(". This approach was in particular pursued by Friedlander and Iwaniec, leading to ")#link("http://en.wikipedia.org/wiki/Friedlander%E2%80%93Iwaniec_theorem")[#text("their theorem")]#text(" that there are infinitely many primes of the form ")#mi("{n^2+m^4}")#text(".")

#text("The study of sieves is an immense topic; see for instance the ")#link("http://www.ams.org/mathscinet-getitem?mr=2647984")[#text("recent 527-page text by Friedlander and Iwaniec")]#text(". We will limit attention to two sieves which give good general-purpose results, if not necessarily the most optimal ones:")

#list(
[#text("(i) The ")#emph[#text("beta sieve")]#text(" (or ")#emph[#text("Rosser-Iwaniec sieve")]#text("), which is a modification of the classical combinatorial sieve of Brun. (A collection of sieve coefficients ")#mi("{\\lambda_d^{\\pm}}")#text(" is called ")#emph[#text("combinatorial")]#text(" if its coefficients lie in ")#mi("{\\{-1,0,+1\\}}")#text(".) The beta sieve is a family of upper and lower bound combinatorial sieves, and are particularly useful for efficiently sieving out all primes up to a parameter ")#mi("{z = x^{1/u}}")#text(" from a set of integers of size ")#mi("{x}")#text(", in the regime where ")#mi("{u}")#text(" is moderately large, leading to what is sometimes known as the ")#link("http://en.wikipedia.org/wiki/Fundamental_lemma_of_sieve_theory")[#text("fundamental lemma of sieve theory")]#text(".")],
[#text("(ii) The ")#emph[#text("Selberg upper bound sieve")]#text(", which is a general-purpose sieve that can serve both as an upper bound sieve for classical sieving problems, as well as an enveloping sieve for sets such as the primes. (One can also convert the Selberg upper bound sieve into a lower bound sieve in a number of ways, but we will only touch upon this briefly.) A key advantage of the Selberg sieve is that, due to the “quadratic” nature of the sieve, the difficult optimisation problem in Problem ")#link(<tao-cbc8a8ffa86a593fb890>)[#text("10")]#text(" is replaced with a much more tractable quadratic optimisation problem, which can often be solved for exactly.")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 12")]#text(" It is possible to compose two sieves together, for instance by using the observation that the product of two upper bound sieves is again an upper bound sieve, or that the product of an upper bound sieve and a lower bound sieve is a lower bound sieve. Such a composition of sieves is useful in some applications, for instance if one wants to apply the fundamental lemma as a “preliminary sieve” to sieve out small primes, but then use a more precise sieve like the Selberg sieve to sieve out medium primes. We will see an example of this in later notes, when we discuss the linear beta-sieve.")
]

#text("We will also briefly present the (arithmetic) ")#emph[#text("large sieve")]#text(", which gives a rather different approach to Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(" in the case that each ")#mi("{E_p}")#text(" consists of some number (typically a large number) of residue classes modulo ")#mi("{p}")#text(", and is powered by the (analytic) large sieve inequality of the preceding section. As an application of these methods, we will utilise the Selberg upper bound sieve as an enveloping sieve to establish Zhang’s theorem on bounded gaps between primes. Finally, we give an informal discussion of the ")#emph[#text("parity barrier")]#text(" which gives some heuristic limitations on what sieve theory is able to accomplish with regards to counting prime patters such as twin primes.")

#text("These notes are only an introduction to the vast topic of sieve theory; more detailed discussion can be found in the ")#link("http://www.ams.org/mathscinet-getitem?mr=2647984")[#text("Friedlander-Iwaniec text")]#text(", in ")#link("http://www.ams.org/mathscinet-getitem?mr=1295844")[#text("these lecture notes of Selberg")]#text(", and in many further texts.")

#metadata(none) <tao-2c73d9fc8203f1120141>

#heading(level: 1)[#strong[#text(" — 1. Combinatorial sieving and the fundamental lemma of sieve theory — ")]]

#text("We begin with a discusion of ")#emph[#text("combinatorial upper and lower bound sieves")]#text(", in which the sieve coefficients ")#mi("{\\lambda^\\pm_d}")#text(" take values in ")#mi("{\\{-1,0,+1\\}}")#text(". These sieves, first introduced by Brun, can be viewed as truncations of the Legendre sieve (which corresponds to the choice of coefficients ")#mi("{\\lambda^\\pm_d = \\mu(d)}")#text(" for all ")#mi("{d|P(z)}")#text("). The Legendre sieve, and more generally the Brun pure sieves in Exercise ")#link(<tao-72b90a0d25a6e8f71d5f>)[#text("9")]#text(", give basic examples of combinatorial sieves.")

#text("We loosely follow the ")#link("http://www.ams.org/mathscinet-getitem?mr=2647984")[#text("discussion of Friedlander and Iwaniec")]#text(". The combinatorial sieves may be motivated by observing the ")#emph[#text("Buchstab identity")]#text(" ")#metadata(none) <tao-e81935fb86434cdaaeee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("1_{n \\not \\in \\bigcup_{p < z} E_p} = 1 - \\sum_{p_1 < z} 1_{E_{p_1}}(n) 1_{n \\not \\in \\bigcup_{p < p_1} E_p}")]]

#text("for any ")#mi("{n \\in {\\bf Z}}")#text(" and any collection of sets ")#mi("{E_p \\subset {\\bf Z}}")#text(" for ")#mi("{p < z}")#text(". This identity reflects the basic fact that if ")#mi("{n}")#text(" does lie in ")#mi("{\\bigcup_{p < z} E_p}")#text(", then there is a unique prime ")#mi("{p_1 < z}")#text(" such that ")#mi("{n}")#text(" lies in ")#mi("{E_{p_1}}")#text(", but does not lie in ")#mi("{E_p}")#text(" for any ")#mi("{p < p_1}")#text(".")

#text("There is an analogous identity for the function ")#mi("{g}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" For any arithmetic function ")#mi("{g}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\prod_{p<z} (1-g(p)) = 1 - \\sum_{p_1 < z} g(p_1) \\prod_{p<p_1} (1-g(p)).")]]

#text("How is this identity related to ")#link(<tao-e81935fb86434cdaaeee>)[#text("(16)")]#text("?")
]

#text("The Buchstab identity ")#link(<tao-e81935fb86434cdaaeee>)[#text("(16)")]#text(" allows one to convert upper bound sieves into lower bound sieves and vice versa. Indeed, if ")#mi("{\\sum_{d|P(p_1)} \\lambda^{-,p_1}_d 1_{E_d}}")#text(" is a family of lower bound sieves for each ")#mi("{p_1 < z}")#text(", then ")#link(<tao-e81935fb86434cdaaeee>)[#text("(16)")]#text(" tells us that")

#align(center)[#tao-fit-display[#mitex("1 - \\sum_{p_1 < z} \\sum_{d|P(p_1)} \\lambda^{-,p_1}_d 1_{E_{p_1 d}}")]]

#text("is an upper bound sieve; similarly, if ")#mi("{\\sum_{d|P(p_1)} \\lambda^{+,p_1}_d 1_{E_d}}")#text(" is a family of upper bound sieves for each ")#mi("{p_1 < z}")#text(", then")

#align(center)[#tao-fit-display[#mitex("1 - \\sum_{p_1 < z} \\sum_{d|P(p_1)} \\lambda^{+,p_1}_d 1_{E_{p_1 d}}")]]

#text("is a lower bound sieve. In terms of sieve coefficients, we see that if ")#mi("{(\\lambda^{-,p_1}_d)_{d | P(p_1)}}")#text(" are lower bound sieve coefficients for each ")#mi("{p_1 < z}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\left( 1_{d=1} - 1_{d > 1} \\lambda^{-,p^*(d)}_{d/p^*(d)} \\right)_{d|P(z)}")]]

#text("is a sequence of upper bound sieve coefficients (where ")#mi("{p^*(d)}")#text(" denotes the largest prime factor of ")#mi("{d}")#text("). Similarly, if ")#mi("{(\\lambda^{+,p_1}_d)_{d | P(p_1)}}")#text(" are upper bound sieve coefficients for each ")#mi("{p_1 < z}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\left( 1_{d=1} - 1_{d > 1} \\lambda^{+,p^*(d)}_{d/p^*(d)} \\right)_{d|P(z)}")]]

#text("is a sequence of lower bound sieve coefficients.")

#text("One can iterate this procedure to produce an alternating sequence of upper and lower bound sieves. If one iterates out the Buchstab formula completely, one ends up back at the Legendre sieve. However, one can truncate this iteration by using the trivial lower bound sieve of ")#mi("{0}")#text(" for some of the primes ")#mi("{p_1}")#text(". For instance, suppose one seeks an upper bound for ")#mi("{1_{n \\not \\in \\bigcup_{p < z} E_p}}")#text(". Applying ")#link(<tao-e81935fb86434cdaaeee>)[#text("(16)")]#text(", we only save some of the summands, say those ")#mi("{p_1}")#text(" which obey some predicate ")#mi("{A_1(p_1)}")#text(" to be chosen later. For the remaining summands, we use the trivial lower bound sieve of ")#mi("{0}")#text(", giving")

#align(center)[#tao-fit-display[#mitex("1_{n \\not \\in \\bigcup_{p < z} E_p} \\leq 1 - \\sum_{p_1 < z: A_1(p_1)} 1_{E_{p_1}}(n) 1_{n \\not \\in \\bigcup_{p < p_1} E_p}.")]]

#text("For the surviving summands, we apply ")#link(<tao-e81935fb86434cdaaeee>)[#text("(16)")]#text(" again. With the sign change, the trivial lower bound sieve is not applicable, so we do not discard any further summands and arrive at")

#tao-aligned(keep: true)[


#tao-math("1_{n \\not \\in \\bigcup_{p < z} E_p}  & \\leq 1 - \\sum_{p_1 < z: A_1(p_1)} 1_{E_{p_1}}(n)", block: true)



#tao-math(" & + \\sum_{p_2 < p_1 < z: A_1(p_1)} 1_{E_{p_1 p_2}}(n) 1_{n \\not \\in \\bigcup_{p < p_2} E_p}.", block: true)
]

#text("For the summands in the second sum on the right, we apply ")#link(<tao-e81935fb86434cdaaeee>)[#text("(16)")]#text(" once again. We once again have a favourable sign and can use the trivial lower bound sieve of ")#mi("{0}")#text(" to discard some of the resulting summands, keeping only those triples ")#mi("{p_1,p_2,p_3}")#text(" that obey some predicate ")#mi("{A_3(p_1,p_2,p_3)}")#text(", giving")

#tao-aligned(keep: true)[


#tao-math("1_{n \\not \\in \\bigcup_{p < z} E_p}  & \\leq 1 - \\sum_{p_1 < z: A_1(p_1)} 1_{E_{p_1}}(n)", block: true)



#tao-math(" & + \\sum_{p_2 < p_1 < z: A_1(p_1)} 1_{E_{p_1 p_2}}(n)", block: true)



#tao-math(" & - \\sum_{p_3 < p_2 < p_1 < z: A_1(p_1) \\wedge A_3(p_1,p_2,p_3)} 1_{E_{p_1 p_2 p_3}}(n) 1_{n \\not \\in \\bigcup_{p < p_3} E_p}.", block: true)
]

#text("Since one cannot have an infinite descent of primes, this process will eventually terminate to produce an upper bound sieve. A similar argument (but with the signs reversed) gives a lower bound sieve. We formalise this discussion as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 14 (General combinatorial sieve)")]#text(" ")#metadata(none) <tao-46c252d291a567838780>#text(" Let ")#mi("{z > 0}")#text(". For each natural number ")#mi("{r}")#text(", let ")#mi("{A_r(p_1,\\dots,p_r)}")#text(" be a predicate pertaining to a sequence ")#mi("{z > p_1 > \\dots > p_r}")#text(" of ")#mi("{r}")#text(" decreasing primes, thus ")#mi("{A_r(p_1,\\dots,p_r)}")#text(" is either true or false for a given choice of such primes. Let ")#mi("{{\\mathcal D}_+}")#text(" (resp. ")#mi("{{\\mathcal D}_-}")#text(") denote the set of ")#mi("{d|P(z)}")#text(" which, when factored as ")#mi("{d = p_1 \\dots p_m}")#text(" for ")#mi("{z > p_1 > \\dots > p_m}")#text(", are such that ")#mi("{A_r(p_1,\\dots,p_r)}")#text(" holds for all odd (resp. even) ")#mi("{1 \\leq r \\leq m}")#text(". Thus")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D}_+ := \\{ p_1 < z: A_1(p_1) \\} \\cup \\{ p_1 p_2: p_2 < p_1 < z; A_1(p_1)\\}")]]

#align(center)[#tao-fit-display[#mitex("\\cup \\{p_1 p_2 p_3: p_3 < p_2 < p_1 < z; A_1(p_1) \\wedge A_3(p_1,p_2,p_3) \\}")]]

#align(center)[#tao-fit-display[#mitex("\\cup \\{p_1 p_2 p_3 p_4: p_4 < p_3 < p_2 < p_1 < z; A_1(p_1) \\wedge A_3(p_1,p_2,p_3) \\}")]]

#align(center)[#tao-fit-display[#mitex("\\cup \\dots")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D}_- := \\{ p_1 < z \\} \\cup \\{ p_1 p_2: p_2 < p_1 < z; A_2(p_1,p_2)\\}")]]

#align(center)[#tao-fit-display[#mitex("\\cup \\{p_1 p_2 p_3: p_3 < p_2 < p_1 < z; A_2(p_1,p_2) \\}")]]

#align(center)[#tao-fit-display[#mitex("\\cup \\{p_1 p_2 p_3 p_4: p_4 < p_3 < p_2 < p_1 < z; A_2(p_1,p_2) \\wedge A_4(p_1,p_2,p_3,p_4) \\}")]]

#align(center)[#tao-fit-display[#mitex("\\cup \\dots.")]]

#list(
[#text("(i) For any sets ")#mi("{E_d \\subset {\\bf Z}}")#text(", ")#mi("{\\sum_{d \\in {\\mathcal D}_+} \\mu(d) 1_{E_d}}")#text(" is an upper bound sieve, and ")#mi("{\\sum_{d \\in {\\mathcal D}_-} \\mu(d) 1_{E_d}}")#text(" is a lower bound sieve. In fact, we have the more precise identities")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\in {\\mathcal D}_+} \\mu(d) 1_{E_d}(n) = 1_{n \\not \\in \\bigcup_{p<z} E_p} + \\sum_{r \\text{ odd}} \\sum_{d \\in {\\mathcal E}_r} 1_{n \\in E_d} 1_{n \\not \\in \\bigcup_{p<p_*(d)} E_p}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\in {\\mathcal D}_-} \\mu(d) 1_{E_d}(n) = 1_{n \\not \\in \\bigcup_{p<z} E_p} - \\sum_{r \\text{ even}} \\sum_{d \\in {\\mathcal E}_r} 1_{n \\in E_d} 1_{n \\not \\in \\bigcup_{p<p_*(d)} E_p}")]]

#text("where ")#mi("{p_*(d)}")#text(" denotes the least prime factor of ")#mi("{d}")#text(" and, for each natural number ")#mi("{r}")#text(", ")#mi("{{\\mathcal E}_r}")#text(" is the collection of products ")#mi("{p_1 \\dots p_r}")#text(" with ")#mi("{z > p_1 > \\dots > p_r}")#text(" such that ")#mi("{A_{r^{\\prime}}(p_1,\\dots,p_{r^{\\prime}})}")#text(" holds for all ")#mi("{r^{\\prime} < r}")#text(" with the same parity as ")#mi("{r}")#text(", but fails for ")#mi("{r^{\\prime}=r}")#text(". Thus for instance")

#align(center)[#tao-fit-display[#mitex("{\\mathcal E}_3 = \\{ p_1 p_2 p_3: z > p_1 > p_2 > p_3; A_1(p_1) \\wedge \\neg A_3(p_1,p_2,p_3) \\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("{\\mathcal E}_4 = \\{ p_1 p_2 p_3 p_4: z > p_1 > p_2 > p_3 > p_4;")]]

#align(center)[#tao-fit-display[#mitex("A_2(p_1,p_2) \\wedge \\neg A_4(p_1,p_2,p_3,p_4) \\}.")]]],
[#text("(ii) The sequences ")#mi("{(\\mu(d) 1_{{\\mathcal D}_+}(d))_{d|P(z)}}")#text(" and ")#mi("{(\\mu(d) 1_{{\\mathcal D}_-}(d))_{d|P(z)}}")#text(" are upper and lower sieve coefficient sequences respectively.")],
[#text("(iii) For any multiplicative function ")#mi("{g}")#text(", one has the identities")

#metadata(none) <tao-7f1b55b860590406f84f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\sum_{d \\in {\\mathcal D}_+} \\mu(d) g(d) = V(z) + \\sum_{r \\text{ odd}} \\sum_{d \\in {\\mathcal E}_r} g(d) V( p_*(d) )")]]

#text("and")

#metadata(none) <tao-490f7737f5d3cd9b758a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\sum_{d \\in {\\mathcal D}_-} \\mu(d) g(d) = V(z) - \\sum_{r \\text{ even}} \\sum_{d \\in {\\mathcal E}_r} g(d) V( p_*(d) )")]]

#text("where ")#mi("{V(w) := \\prod_{p<w} (1-g(p))}")#text(".")]
)
]

#text("Note that the Legendre sieve is the special case of the combinatorial sieve when all the predicates ")#mi("{A_r(p_1,\\dots,p_r)}")#text(" are true for all choices of inputs ")#mi("{p_1,\\dots,p_r}")#text(" (i.e. one does not ever utilise the trivial lower bound sieve); more generally, the Brun pure sieve with parameter ")#mi("{k}")#text("corresponds to the case when ")#mi("{A_r(p_1,\\dots,p_r)}")#text(" is always true for ")#mi("{r \\leq k}")#text(" and always false for ")#mi("{r>k}")#text(". The predicates ")#mi("{A_r}")#text(" for odd ")#mi("{r}")#text(" are only used for the upper bound sieve and not the lower bound sieve; conversely, the predicates ")#mi("{A_r}")#text(" for even ")#mi("{r}")#text(" are only used for the lower bound sieve and not the upper bound sieve.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" Prove Proposition ")#link(<tao-46c252d291a567838780>)[#text("14")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Interpret the sieves in Exercise ")#link(<tao-284792493bd06ae32c30>)[#text("8")]#text(" as combinatorial sieves. What are the predicates ")#mi("{A_1, A_2}")#text(" in this case?")
]

#text("We now use the above proposition to attack Problem ")#link(<tao-cbc8a8ffa86a593fb890>)[#text("10")]#text(" for a given choice of parameters ")#mi("{z}")#text(" and ")#mi("{D}")#text("; we will focus on the regime when ")#metadata(none) <tao-d5787cd36cdf96b5ff9e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("z = D^{1/s}")]]

#text("for some ")#mi("{s,z \\geq 1}")#text(", thus we are sifting out primes up to a small power of the sieve level ")#mi("{D}")#text(". To do this, one needs to select the predicates ")#mi("{A_r(p_1,\\dots,p_r)}")#text(" in such a fashion that the sets ")#mi("{{\\mathcal D}_\\pm}")#text(" only consist of divisors ")#mi("{d|P(z)}")#text(" that are less than or equal to ")#mi("{D}")#text(". There are a number of ways to achieve this, but experience has shown that a good general-purpose choice in this regard is to define ")#mi("{A_r(p_1,\\dots,p_r)}")#text(" to be the predicate ")#metadata(none) <tao-cf835fc094349f22c221>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("p_1 \\dots p_{r-1} p_r^{\\beta+1} \\leq D")]]

#text("for some parameter ")#metadata(none) <tao-f44e64e75f3948e9f73f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("1 \\leq \\beta \\leq s")]]

#text("to be chosen later. The combinatorial sieve with this choice of predicate is known as the ")#emph[#text("beta sieve")]#text(" or ")#emph[#text("Rosser-Iwaniec sieve")]#text(" at sieve level ")#mi("{D}")#text(". Observe that if ")#mi("{p_1 \\dots p_r}")#text(" lies in ")#mi("{{\\mathcal D}_\\pm}")#text(" for some ")#mi("{r \\geq 2}")#text(" and ")#mi("{z > p_1 > \\dots > p_r}")#text(", then at least one of ")#mi("{p_1 \\dots p_{r-1} p_r^{\\beta+1} \\leq D}")#text(" or ")#mi("{p_1 \\dots p_{r-2} p_{r-1}^{\\beta+1} \\leq D}")#text(" will hold, and hence ")#mi("{p_1 \\dots p_r \\leq D}")#text(" since ")#mi("{\\beta \\geq 1}")#text(". If ")#mi("{r \\leq 1}")#text(", we have the same conclusion thanks to ")#link(<tao-d5787cd36cdf96b5ff9e>)[#text("(19)")]#text(" since ")#mi("{s \\geq 1}")#text(". Thus under the hypotheses ")#link(<tao-f44e64e75f3948e9f73f>)[#text("(21)")]#text(", ")#link(<tao-d5787cd36cdf96b5ff9e>)[#text("(19)")]#text(", the beta sieves are indeed upper and lower bound sieves at level ")#mi("{D}")#text(".")

#text("Now we estimate the quantities ")#link(<tao-b2fec115043348fde0ca>)[#text("(14)")]#text(", ")#link(<tao-e32c325b4bb236b62f58>)[#text("(15)")]#text(" for the beta sieve coefficients ")#mi("{\\lambda^\\pm_d := \\mu(d) 1_{{\\mathcal D}_\\pm}(d)}")#text(" for some multiplicative function ")#mi("{g}")#text(" with ")#mi("{0 \\leq g(p) \\leq 1}")#text(" for all ")#mi("{p}")#text(". In order to actually compute asymptotics, we assume the Mertens-like axiom ")#metadata(none) <tao-c7c25cf63498ff73b179>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("V(w) \\ll_\\kappa \\left(\\frac{\\log z}{\\log w}\\right)^\\kappa V(z)")]]

#text("whenever ")#mi("{2 \\leq w \\leq z}")#text(", where ")#mi("{V(z) := \\prod_{p < z} (1 - g(p))}")#text(" and some fixed ")#mi("{\\kappa>0}")#text(", which we refer to as the ")#emph[#text("sieve dimension")]#text(". From Mertens’ theorems, we see that these axioms will in particular be obeyed if")

#align(center)[#tao-fit-display[#mitex("g(p) \\leq \\frac{\\kappa}{p} + O_\\kappa(\\frac{1}{p^2})")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("g(p) \\leq 1-c")]]

#text("for all primes ")#mi("{p}")#text(" and some fixed ")#mi("{c>0}")#text(" depending only on ")#mi("{\\kappa}")#text(".")

#text("Let ")#mi("{g}")#text(" be as above. From ")#link(<tao-7f1b55b860590406f84f>)[#text("(17)")]#text(", ")#link(<tao-490f7737f5d3cd9b758a>)[#text("(18)")]#text(", ")#link(<tao-c7c25cf63498ff73b179>)[#text("(22)")]#text(" we see that the quantities ")#link(<tao-b2fec115043348fde0ca>)[#text("(14)")]#text(", ")#link(<tao-e32c325b4bb236b62f58>)[#text("(15)")]#text(" are both of the form ")#metadata(none) <tao-3171fd7f525d47830c7a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("V(z) \\left( 1 + O_\\kappa \\left( \\sum_r \\sum_{d \\in {\\mathcal E}_r} g(d) \\left( \\frac{\\log z}{\\log p_*(d)} \\right)^\\kappa \\right)\\right).")]]

#text("We now estimate the error term; our estimates will be somewhat crude in order to simplify the calculations, but this will already suffice for many applications. First observe that if ")#mi("{z > p_1 > \\dots > p_r}")#text(" then")

#align(center)[#tao-fit-display[#mitex("p_1 \\dots p_{r-1} p_r^{\\beta+1} \\leq z^{r+\\beta} = D^{(r+\\beta)/s}.")]]

#text("We conclude that the condition ")#mi("{A_r(p_1,\\dots,p_r)}")#text(" is automatically satisfied when ")#mi("{r+\\beta \\leq s}")#text(", and so the ")#mi("{r}")#text(" summand in ")#link(<tao-3171fd7f525d47830c7a>)[#text("(23)")]#text(" can be restricted to the range ")#mi("{r > s - \\beta}")#text(".")

#text("Next, note that if ")#mi("{d = p_1 \\dots p_r \\in {\\mathcal E}_r}")#text(" for some ")#mi("{z > p_1 > \\dots > p_r}")#text(", then from ")#link(<tao-cf835fc094349f22c221>)[#text("(20)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("p_1 \\dots p_{r^{\\prime}-1} p_{r^{\\prime}}^{\\beta+1} \\leq D")]]

#text("for all ")#mi("{1 \\leq r^{\\prime} < r}")#text(" with the same parity as ")#mi("{r}")#text(", which implies (somewhat crudely) that")

#align(center)[#tao-fit-display[#mitex("p_1 \\dots p_{r^{\\prime}-1} p_{r^{\\prime}}^{\\beta} \\leq D")]]

#text("for all ")#mi("{1 \\leq r^{\\prime} < r}")#text(", regardless of parity (note that the ")#mi("{r^{\\prime}=1}")#text(" case follows since ")#mi("{p_1^{\\beta} \\leq z^{\\beta} = D^{\\beta / s} \\leq D}")#text("). We rearrange this inequality as")

#align(center)[#tao-fit-display[#mitex("\\frac{D}{p_1 \\dots p_{r^{\\prime}}} \\geq \\left( \\frac{D}{p_1 \\dots p_{r^{\\prime}-1}}\\right)^{\\frac{\\beta-1}{\\beta}}")]]

#text("which iterates to give")

#align(center)[#tao-fit-display[#mitex("\\frac{D}{p_1 \\dots p_{r-1}} \\geq D^{(\\frac{\\beta-1}{\\beta})^{r-1}}.")]]

#text("On the other hand, from the definition of ")#mi("{{\\mathcal E}_r}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("p_1 \\dots p_{r-1} p_r^{\\beta+1} > D")]]

#text("which leads to a lower bound on ")#mi("{p_r = p_*(d)}")#text(":")

#tao-aligned(keep: true)[


#tao-math("p_r  & > D^{(\\frac{\\beta-1}{\\beta})^{r-1} / (\\beta+1)}", block: true)



#tao-math(" & > D^{(\\frac{\\beta-1}{\\beta})^{r} / \\beta}", block: true)



#tao-math(" & > z^{(\\frac{\\beta-1}{\\beta})^{r}}", block: true)
]

#text("so in particular")

#align(center)[#tao-fit-display[#mitex("\\frac{\\log z}{\\log p_*(d)} < \\left(\\frac{\\beta}{\\beta-1}\\right)^r.")]]

#text("We can thus estimate ")#link(<tao-3171fd7f525d47830c7a>)[#text("(23)")]#text(" somewhat crudely as")

#align(center)[#tao-fit-display[#mitex("V(z) \\left( 1 + O_\\kappa \\left( \\sum_{r \\geq s-\\beta} \\sum_{z > p_1 > \\dots > p_r > z^{(\\frac{\\beta-1}{\\beta})^{r\\kappa}}} g(p_1) \\dots g(p_r) \\left(\\frac{\\beta}{\\beta-1}\\right)^r \\right)\\right).")]]

#text("We can estimate")

#tao-aligned(keep: true)[


#tao-math("\\sum_{z > p_1 > \\dots > p_r > z^{(\\frac{\\beta-1}{\\beta})^{r}}} g(p_1) \\dots g(p_r)  & \\leq \\frac{1}{r!} (\\sum_{z > p \\geq z^{(\\frac{\\beta-1}{\\beta})^{r}}} g(p))^r", block: true)



#tao-math(" & \\leq \\frac{1}{r!} (\\log \\prod_{z > p \\geq z^{(\\frac{\\beta-1}{\\beta})^{r}}} (1-g(p))^{-1})^r", block: true)



#tao-math(" & = \\frac{1}{r!} ( \\log( V(z^{(\\frac{\\beta-1}{\\beta})^{r}}) / V(z) ) )^r", block: true)



#tao-math(" & \\ll \\frac{1}{r!} ( \\kappa r \\log \\frac{\\beta}{\\beta-1} + O(1) )^r", block: true)



#tao-math(" & \\ll ( \\kappa e \\log \\frac{\\beta}{\\beta-1} + O(1/r) )^r", block: true)
]

#text("thanks to ")#link(<tao-c7c25cf63498ff73b179>)[#text("(22)")]#text(" and the crude bound ")#mi("{\\frac{r^r}{r!} \\leq e^r}")#text(" coming from the Taylor expansion of ")#mi("{e^r}")#text(". If we choose ")#mi("{\\beta}")#text(" large enough so that ")#metadata(none) <tao-de04c42b8f31c8ceaea3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\kappa e (\\log \\frac{\\beta}{\\beta-1}) (\\frac{\\beta}{\\beta-1})^\\kappa \\leq \\frac{1}{e}")]]

#text("(note the left-hand side decays like ")#mi("{\\kappa/\\beta}")#text(" as ")#mi("{\\beta \\rightarrow \\infty}")#text("), we thus can estimate ")#link(<tao-3171fd7f525d47830c7a>)[#text("(23)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("V(z) \\left( 1 + O_\\kappa \\left( \\sum_{r \\geq s-\\beta} (\\frac{1}{e} + O(1/r))^r \\right)\\right)")]]

#text("which sums to")

#align(center)[#tao-fit-display[#mitex("V(z) ( 1 + O_{\\kappa,\\beta}( e^{-s} ) ).")]]

#text("We conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 17 (Fundamental lemma of sieve theory)")]#text(" Let ")#mi("{\\kappa > 0}")#text(". If ")#mi("{z = D^{1/s}}")#text(" for some ")#mi("{D,s \\geq 1}")#text(", then there exist combinatorial upper and lower sieve coefficients ")#mi("{(\\lambda^\\pm_d)_{d \\in {\\mathcal D}}}")#text(" supported in ")#mi("{{\\mathcal D} := \\{ d | P(z): d \\leq D \\}}")#text(" such that ")#metadata(none) <tao-736bc2d4e0945110e88f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\sum_{d \\in {\\mathcal D}} \\lambda^\\pm_d g(d) = V(z) ( 1 + O_{\\kappa}( e^{-s} ) )")]]

#text("for any multiplicative function ")#mi("{g}")#text(" with ")#mi("{0 \\leq g(p) < 1}")#text(" for all primes ")#mi("{p}")#text(", obeying the bounds ")#link(<tao-c7c25cf63498ff73b179>)[#text("(22)")]#text(".")
]

#text("Informally, the fundamental lemma shows that one can get exponentially close to the Legendre sieve limit of ")#mi("{V(z)}")#text(" as long as the sieve level ")#mi("{D}")#text(" is a large power of the sifting range ")#mi("{z}")#text(".")

#emph[#text("Proof:")]#text(" Without loss of generality we may assume that ")#mi("{s}")#text(" is sufficiently large depending on ")#mi("{\\kappa}")#text(", since for small ")#mi("{s}")#text(" we may simply reduce ")#mi("{z}")#text(" (for the purposes of the upper bound sieve) or use the trivial lower bound sieve ")#mi("{0}")#text(". But then we may find ")#mi("{\\beta = \\beta(\\kappa)}")#text(" obeying ")#link(<tao-de04c42b8f31c8ceaea3>)[#text("(24)")]#text(" and less than ")#mi("{s}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" Improve the ")#mi("{O_\\kappa( e^{-s} )}")#text(" error in ")#link(<tao-736bc2d4e0945110e88f>)[#text("(25)")]#text(" to ")#mi("{O_{\\kappa,\\varepsilon}( e^{-(1-\\varepsilon) s \\log s} )}")#text(" for any ")#mi("{\\varepsilon>0}")#text(". (It is possible to show that this error term is essentially best possible, at least in the linear dimension case ")#mi("{\\kappa = 1}")#text(", by using asymptotics for rough numbers (Exercise 28 of ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text("), but we will not do so here.)")
]

#text("The fundamental lemma is often used as a preliminary sifting device to remove small primes, in preparation for a more sophisticated sieve to deal with medium primes. But one can of course use it directly. Indeed, thanks to Theorem ")#link(<tao-a0d950705fa91bbdd0f2>)[#text("5")]#text(", we now have an adequate answer to Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(" in the regime where the sieve dimension ")#mi("{\\kappa}")#text(" is fixed and the sifting level is small compared to the level of distribution:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 19 (Fundamental lemma, applied directly)")]#text(" ")#metadata(none) <tao-1e5677b32282ff4ec5ce>#text(" Let ")#mi("{z = D^{1/s}}")#text(" for some ")#mi("{\\kappa, s, D \\geq 1}")#text(", and suppose that ")#mi("{g}")#text(" is a multiplicative function obeying the bounds ")#link(<tao-c7c25cf63498ff73b179>)[#text("(22)")]#text(" for all ")#mi("{2 \\leq w \\leq z}")#text(", where ")#mi("{V(w) := \\prod_{p<w} (1-g(p))}")#text(". For each ")#mi("{p \\leq z}")#text(", let ")#mi("{E_p}")#text(" be a set of integers, and let ")#mi("{(a_n)_{n \\in {\\bf Z}}}")#text(" is a finitely supported sequence of non-negative reals such that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in E_d} a_n = X g(d) + r_d")]]

#text("for all square-free ")#mi("{d \\leq D}")#text(", where ")#mi("{X > 0}")#text(" and ")#mi("{r_d \\in {\\bf R}}")#text(", and ")#mi("{E_d := \\bigcap_{p|d} E_p}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\not \\in \\bigcup_{p \\leq z} E_p} a_n = (1 + O_\\kappa(e^{-s})) X V(z) + O( \\sum_{d\\leq D: \\mu^2(d)=1} \\left|r_d\\right| ).", block: true)]]
]

#text("We now specialise to the twin prime problem in Problem ")#link(<tao-72b33a1cb0bfc9cdd3db>)[#text("2")]#text(". Here, ")#mi("{X = x}")#text(", and ")#mi("{g(p)=\\omega(p)/p}")#text(" where ")#mi("{\\omega(p)=2}")#text(" for odd ")#mi("{p}")#text(", with ")#mi("{\\omega(2)=1}")#text(". In particular we may take ")#mi("{\\kappa = 2}")#text(". We set ")#mi("{z := x^{1/u}}")#text(" for some fixed ")#mi("{u > 1}")#text(", and ")#mi("{D = x^{1-o(1)}}")#text(" for some quantity ")#mi("{o(1)}")#text(" going sufficiently slowly to infinity, so ")#mi("{s := u + o(1)}")#text(". From ")#link(<tao-7f1f073d8bb9b2e3ad6c>)[#text("(8)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("V(z) = (1+o(1)) \\frac{u^2}{e^{2\\gamma}} \\frac{2\\Pi_2}{\\log^2 x}")]]

#text("and from ")#link(<tao-e96e02d8e47f2a7c03be>)[#text("(5)")]#text(" and the divisor bound we have")

#align(center)[#tao-fit-display[#mitex("r_d \\leq \\tau(d) \\ll x^{o(1)}")]]

#text("for any ")#mi("{d \\leq D}")#text(", as ")#mi("{x \\rightarrow \\infty}")#text(". From the fundamental lemma, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\pi_2(x, x^{1/u}) = \\frac{u^2}{e^{2\\gamma}} (1 + O( e^{-u} ) + o(1)) \\frac{2\\Pi_2 x}{\\log^2 x} + O( x^{o(1)} D ).")]]

#text("If we let the ")#mi("{o(1)}")#text(" term in ")#mi("{D = x^{1-o(1)}}")#text(" decay sufficiently slowly, then the final error term in the above expression can be absorbed into the second error term, and so ")#metadata(none) <tao-9c2f138690fca4890c3c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\pi_2(x, x^{1/u}) = \\frac{u^2}{e^{2\\gamma}} (1 + O( e^{-u} ) + o(1)) \\frac{2\\Pi_2 x}{\\log^2 x}.")]]

#text("Setting ")#mi("{u=2}")#text(", we conclude in particular that")

#align(center)[#tao-fit-display[#mitex("\\pi_2(x, x^{1/2}) \\ll \\frac{x}{\\log^2 x}")]]

#text("which implies from the sieve of Eratosthenes that there are ")#mi("{O( \\frac{x}{\\log^2 x} )}")#text(" pairs of twin primes in ")#mi("{[x/2,x]}")#text(". This implies a famous ")#link("http://en.wikipedia.org/wiki/Brun%27s_theorem")[#text("theorem of Brun")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20 (Brun’s theorem)")]#text(" Show that the sum ")#mi("{\\sum_{p: p+2 \\in {\\mathcal P}} \\frac{1}{p}}")#text(" is convergent.")
]

#text("Alternatively, if one applies ")#link(<tao-9c2f138690fca4890c3c>)[#text("(26)")]#text(" with ")#mi("{u}")#text(" a sufficiently large natural number, we see that")

#align(center)[#tao-fit-display[#mitex("\\pi_2(x,x^{1/u}) \\gg \\frac{x}{\\log^2 x}")]]

#text("for all sufficiently large ")#mi("{x}")#text(". This implies that there are ")#mi("{\\gg \\frac{x}{\\log^2 x}}")#text(" numbers ")#mi("{n}")#text(" in ")#mi("{[1,x]}")#text(" with the property that ")#mi("{n, n+2}")#text(" are both not divisible by any prime less than or equal to ")#mi("{x^{1/u}}")#text(". In particular (if ")#mi("{n \\leq x-2}")#text("), ")#mi("{n}")#text(" and ")#mi("{n+2}")#text(" both have at most ")#mi("{u}")#text(" prime factors. We conclude a version of the twin prime conjecture for almost primes:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 21")]#text(" ")#metadata(none) <tao-04695fa805d662a7ca81>#text(" There is an absolute constant ")#mi("{u}")#text(" such that there are infinitely many natural numbers ")#mi("{n}")#text(" such that ")#mi("{n, n+2}")#text(" are each the product of at most ")#mi("{u}")#text(" primes.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" By going through the beta sieve estimates carefully, show that one can take ")#mi("{u=20}")#text(" in the above corollary. (One can do substantially better if one uses more sophisticated sieve estimates, and of course ")#link("http://en.wikipedia.org/wiki/Chen%27s_theorem")[#text("Chen’s theorem")]#text(" tells us that ")#mi("{u}")#text(" can be taken as low as ")#mi("{2}")#text("; we will review the proof of Chen’s theorem in subsequent notes.)")
]

#text("In the above corollary, both elements of the pair ")#mi("{n,n+2}")#text(" are permitted to be almost prime rather than prime. It is possible to use the fundamental lemma to improve upon this by forcing ")#mi("{n}")#text(" (for instance) to be prime. To do this, we run the twin prime sieve differently; rather than start with all integers and sieve out two residue classes modulo each prime ")#mi("{p}")#text(", we instead start with the primes and sieve out one residue class modulo ")#mi("{p}")#text(". More precisely, we consider the quantity")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\not \\in \\bigcup_{p \\leq z} E_p} f(n)")]]

#text("where ")#mi("{E_p}")#text(" is the residue class ")#mi("{-2\\ (p)}")#text(" and")

#align(center)[#tao-fit-display[#mitex("f(n) := \\Lambda(n) 1_{[x/2,x-2]}(n)")]]

#text("(say). Observe that the sum ")#mi("{\\sum_{n \\in E_d} f(n)}")#text(" is only as large as ")#mi("{O( \\log^{O(1)} x)}")#text(" at worst for even ")#mi("{d}")#text(". For odd ")#mi("{d}")#text(", we expect from the prime number theorem in arithmetic progressions that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in E_d} f(n) = \\frac{1}{\\phi(d)} \\frac{x}{2} + r_d")]]

#text("for some small ")#mi("{r_d}")#text(". Thus it is natural to apply Corollary ")#link(<tao-1e5677b32282ff4ec5ce>)[#text("19")]#text(" with ")#mi("{X := \\frac{x}{2}}")#text(" and ")#mi("{g(d) := 1_{(d,2)=1} \\frac{1}{\\phi(d)}}")#text(", so that ")#mi("{\\kappa = 1}")#text(". From the Bombieri-Vinogradov theorem (see Theorem 17 of ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("Notes 3")]#text("), we see that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d \\leq x^{1/2-\\varepsilon}} \\left|r_d\\right| \\ll_{A,\\varepsilon} x \\log^{-A} x", block: true)]]

#text("for any fixed ")#mi("{\\varepsilon, A> 0}")#text(". We thus take ")#mi("{D := x^{1/2-\\varepsilon}}")#text(" for some small fixed ")#mi("{\\varepsilon>0}")#text(" and ")#mi("{z := x^{1/u}}")#text(", and apply Corollary ")#link(<tao-1e5677b32282ff4ec5ce>)[#text("19")]#text(" to conclude that")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\not \\in \\bigcup_{p \\leq z} E_p} f(n)  & = (1 + O( e^{-u/(1/2-\\varepsilon)})) \\frac{x}{2} \\prod_{2 < p < z}( 1 - \\frac{1}{\\phi(p)})", block: true)



#tao-math(" & + O_{A,\\varepsilon}( x \\log^{-A} x ).", block: true)
]

#text("For ")#mi("{u}")#text(" a sufficiently large fixed constant, we conclude from Mertens’ theorem that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\not \\in \\bigcup_{p \\leq z} E_p} f(n) \\gg \\frac{x}{\\log x}")]]

#text("for ")#mi("{x}")#text(" large enough. The contribution for those ")#mi("{n}")#text(" for which ")#mi("{n}")#text(" is a power of a prime, rather than a prime, is easily seen to be negligible, and we conclude that there are ")#mi("{\\gg \\frac{x}{\\log^2 x}}")#text(" primes ")#mi("{p}")#text(" less than ")#mi("{x-2}")#text(" such that ")#mi("{p+2}")#text(" has no factors less than ")#mi("{x^{1/u}}")#text(", and thus is the product of at most ")#mi("{u}")#text(" primes. We thus have the following improvement of Corollary ")#link(<tao-04695fa805d662a7ca81>)[#text("21")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 23")]#text(" There is an absolute constant ")#mi("{u}")#text(" such that there are infinitely many primes ")#mi("{p}")#text(" such that ")#mi("{p+2}")#text(" is the product of at most ")#mi("{u}")#text(" primes.")
]

#text("More generally, the fundamental lemma (combined with equidistribution results such as the Bombieri-Vinogradov theorem) lets one prove analogues of various unsolved conjectures about primes, in which one either (a) is content with upper bounds of the right order of magnitude, or (b) is willing to replace primes with a suitable notion of almost prime. We give some examples in the exercises below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24 (Approximations to the prime ")#mi("{k}")#text("-tuples conjecture)")]#text(" ")#metadata(none) <tao-6a5b32b39ff583bc5f86>#text(" Let ")#mi("{(h_1,\\dots,h_k)}")#text(" be an admissible ")#mi("{k}")#text("-tuple of integers for some ")#mi("{k \\geq 1}")#text(", thus the ")#mi("{h_i}")#text(" are all distinct, and for any ")#mi("{p}")#text(", the number ")#mi("{\\omega(p)}")#text(" of residue classes occupied by ")#mi("{h_1,\\dots,h_k\\ (p)}")#text(" is never equal to ")#mi("{p}")#text(". Let ")#mi("{{\\mathfrak S}}")#text(" denote the singular series ")#metadata(none) <tao-094a367b026246fb6464>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("{\\mathfrak S} := \\prod_p (1-\\frac{1}{p})^{-k} (1-\\frac{\\omega(p)}{p}).")]]

#list(
[#text("(i) Show that ")#mi("{\\sum_{n \\leq x: n+h_1,\\dots,n+h_k \\in {\\mathcal P}} 1 \\ll_k {\\mathfrak S} \\frac{x}{\\log^k x}}")#text(" for all sufficiently large ")#mi("{x}")#text(". (This should be compared with the Hardy-Littlewood prime tuples conjecture ")#mi("{\\sum_{n \\leq x: n+h_1,\\dots,n+h_k \\in {\\mathcal P}} 1 = (1+o(1)) {\\mathfrak S} \\frac{x}{\\log^k x}}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(", see Exercise 13 of ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text(".) Thus the fundamental lemma tells us that the prime tuples conjecture is only off from the truth by a multiplicative factor of ")#mi("{O_k(1)}")#text(", at least as far as upper bounds are concerned.")],
[#text("(ii) Show that if ")#mi("{u}")#text(" is sufficiently large depending on ")#mi("{k}")#text(", then there are infinitely many ")#mi("{n}")#text(" such that ")#mi("{n+h_1,\\dots,n+h_k}")#text(" are each the product of at most ")#mi("{u}")#text(" prime factors.")],
[#text("(iii) Strengthen (ii) to include the requirement that ")#mi("{n+h_1}")#text(" (say) is prime.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25 (Approximations to the even Goldbach conjecture)")]#text(" If ")#mi("{N}")#text(" is an even natural number, define the singular series")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak S}(N) := 2 \\Pi_2 \\prod_{p>2: p|N} \\frac{p-1}{p-2}.")]]

#list(
[#text("(i) Show that the number of ways to write ")#mi("{N}")#text(" as the sum of two primes ")#mi("{N=p_1+p_2}")#text(" is ")#mi("{O( {\\mathfrak S}(N) \\frac{N}{\\log^2 N} )}")#text(" if ")#mi("{N}")#text(" is sufficiently large. (This should be compared with the prediction of ")#mi("{(1+o(1)) {\\mathfrak S}(N) \\frac{N}{\\log^2 N}}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(", see Exercise 12 of ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text(".)")],
[#text("(ii) Show that if ")#mi("{u}")#text(" is a sufficiently large natural number, then every sufficiently large even number ")#mi("{N}")#text(" is expressible as the sum of two natural numbers ")#mi("{n_1,n_2}")#text(", each of which are the product of at most ")#mi("{u}")#text(" prime factors.")],
[#text("(iii) Strengthen (ii) to include the requirement that ")#mi("{n_1}")#text(" is prime.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26 (Approximations to Legendre’s conjecture)")]

#list(
[#text("(i) Show that for any ")#mi("{x,y \\geq 2}")#text(", the number of primes in the interval ")#mi("{[x,x+y]}")#text(" is at most ")#mi("{O( \\frac{y}{\\log y} )}")#text(".")],
[#text("(ii) Show that if ")#mi("{u}")#text(" is a sufficiently large natural number, then for all sufficiently large ")#mi("{x}")#text(", there is at least one natural number ")#mi("{n}")#text(" between ")#mi("{x^2}")#text(" and ")#mi("{(x+1)^2}")#text(" that is the product of at most ")#mi("{u}")#text(" primes.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27 (Approximations to Landau’s fourth problem)")]#text(" Define the singular series")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak S} := \\prod_p \\frac{1-\\omega(p)/p}{1-1/p}")]]

#text("where ")#mi("{\\omega(p)}")#text(" is the number of residue classes ")#mi("{a\\ (p)}")#text(" such that ")#mi("{a^2 + 1 =0\\ (p)}")#text(".")

#list(
[#text("(i) Show that the number of primes of the form ")#mi("{n^2+1}")#text(" with ")#mi("{n \\leq x}")#text(" is ")#mi("{O( {\\mathfrak S} \\frac{x}{\\log x} )}")#text(" for sufficiently large ")#mi("{x}")#text(". (This should be compared with the prediction ")#mi("{(1+o(1)) {\\mathfrak S} \\frac{x}{\\log x}}")#text(", see Exercise 15 of ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text(".)")],
[#text("(ii) Show that if ")#mi("{u}")#text(" is a sufficiently large natural number, then there are an infinite number of numbers of the form ")#mi("{n^2+1}")#text(" that are the product of at most ")#mi("{u}")#text(" primes.")]
)
]

#heading(level: 1)[#strong[#text(" — 2. The Selberg upper bound sieve — ")]]

#text("We now turn to the ")#emph[#text("Selberg upper bound sieve")]#text(", which is a simple but remarkably useful general-purpose upper bound sieve. We again follow the ")#link("http://www.ams.org/mathscinet-getitem?mr=2647984")[#text("discussion of Friedlander and Iwaniec")]#text(".")

#text("The idea of the sieve comes from the following trivial observation: if ")#mi("{P}")#text(" is a squarefree number, ")#mi("{E_p}")#text(" is a set of integers for each ")#mi("{p|P}")#text(", and ")#mi("{(\\rho_d)_{d|P}}")#text(" are arbitrary real numbers with ")#mi("{\\rho_1 = 1}")#text(", then the function")

#align(center)[#tao-fit-display[#mitex("\\left( \\sum_{d|P} \\rho_d 1_{E_d} \\right)^2")]]

#text("is an upper bound sieve, since it is clearly non-negative and equals ")#mi("{1}")#text(" outside of ")#mi("{\\bigcup_{p|P} E_p}")#text(". Equivalently, the sequence ")#metadata(none) <tao-7c84ce75d92e62ebdbe7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\lambda^+_d := \\sum_{d_1,d_2: [d_1,d_2] = d} \\rho_{d_1} \\rho_{d_2}")]]

#text("for ")#mi("{d|P}")#text(" is a sequence of upper bound sieve coefficients, where ")#mi("{[d_1,d_2]}")#text(" is the least common multiple of ")#mi("{d_1,d_2}")#text(". If we set ")#mi("{D=R^2}")#text(" and assume that the ")#mi("{\\rho_d}")#text(" are only non-zero for ")#mi("{d \\leq R}")#text(", then this sequence of sieve coefficients will only be non-zero on ")#mi("{{\\mathcal D} := \\{ d|P: d \\leq D \\}}")#text(". We will refer to sieves (and sieve coefficients) constructed by this method as ")#emph[#text("Selberg upper bound sieves")]#text(" (or ")#emph[#text("Selberg upper bound sieve coefficients")]#text("); they are also referred to as ")#mi("{\\rho^2}")#text(" sieves in the literature.")

#text("A key advantage of the Selberg sieve is that the coefficients ")#mi("{\\rho_d}")#text(" for ")#mi("{1 < d \\leq R}")#text(" are completely unconstrained within the real numbers, and the sieve depends in a quadratic fashion on these coefficients, so the problem of optimising the Selberg sieve for a given application usually reduces to an unconstrained quadratic optimisation problem, which can often be solved exactly in many cases. Of course, the optimal Selberg sieve need not be the globally optimal sieve amongst ")#emph[#text("all")]#text(" upper bound sieves; but in practice the Selberg sieve tends to give quite good results even if it might not be the globally optimal choice.")

#text("Selberg sieves can be used for many purposes, but we begin with the classical sieve problem posed in Problem ")#link(<tao-cbc8a8ffa86a593fb890>)[#text("10")]#text(". To avoid some degeneracies we will assume that ")#metadata(none) <tao-2a1d60299ac1428b9086>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("0 < g(p) < 1")]]

#text("for all ")#mi("{p|P}")#text(". Restricting to upper bound sieve coefficients of the Selberg form, the quantity ")#link(<tao-b2fec115043348fde0ca>)[#text("(14)")]#text(" becomes ")#metadata(none) <tao-f3cf3f52140e146702cb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\sum_{d_1,d_2|P} \\rho_{d_1} \\rho_{d_2} g( [d_1,d_2] ).")]]

#text("This is a quadratic form in the coefficients ")#mi("{\\rho_d}")#text("; our task is to minimise this amongst all choices of coefficients with ")#mi("{\\rho_1=1}")#text(", with ")#mi("{\\rho_d}")#text(" vanishing for ")#mi("{d>R}")#text(".")

#text("Observe that any ")#mi("{d_1,d_2|P}")#text(" can be expressed as ")#mi("{d_1 = a_1 b}")#text(", ")#mi("{d_2 = a_2 b}")#text(" with ")#mi("{a_1 a_2 b | P}")#text(", in which case ")#mi("{[d_1,d_2] = a_1 a_2 b}")#text(". By multiplicativity, we may thus write ")#link(<tao-f3cf3f52140e146702cb>)[#text("(30)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{a_1 a_2 b|P} \\rho_{a_1 b} \\rho_{a_2 b} g(b) g(a_1) g(a_2)")]]

#text("which we can rearrange as as")

#align(center)[#tao-fit-display[#mitex("\\sum_{b|P} g(b) \\sum_{a_1,a_2 | P/b: (a_1,a_2)=1} \\rho_{a_1b} g(a_1) \\rho_{a_2 b} g(a_2).")]]

#text("The inner sum almost factorises as a square, but we have the coprimality constraint ")#mi("{(a_1,a_2)=1}")#text(" to deal with. The standard trick for dealing with this constraint is Möbius inversion:")

#tao-aligned(keep: true)[


#tao-math("1_{(a_1,a_2)=1}  & = \\sum_{d |(a_1,a_2)} \\mu(d)", block: true)



#tao-math(" & = \\sum_{d|a_1,a_2} \\mu(d);", block: true)
]

#text("inserting this and writing ")#mi("{a_1 = d c_1}")#text(", ")#mi("{a_2 = d c_2}")#text(", we can now write ")#link(<tao-f3cf3f52140e146702cb>)[#text("(30)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{b|P} g(b) \\sum_{d|P/b} \\mu(d) g(d)^2 \\sum_{c_1,c_2 | P/db} \\rho_{dbc_1} g(c_1) \\rho_{dbc_2} g(c_1)")]]

#text("which now does factor as a sum of squares:")

#align(center)[#tao-fit-display[#mitex("\\sum_{b|P} g(b) \\sum_{d|P/b} \\mu(d) g(d)^2 \\left( \\sum_{c | P/db} \\rho_{dbc} g(c)\\right)^2.")]]

#text("Writing ")#mi("{e = bcd}")#text(", this becomes")

#align(center)[#tao-fit-display[#mitex("\\sum_{bd|P} \\frac{\\mu(d)}{g(b)} \\left( \\sum_{bd | e | P} \\rho_e g(e)\\right)^2.")]]

#text("Writing ")#mi("{bd = m}")#text(", this becomes ")#metadata(none) <tao-68dbf73d03d3a5107eda>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("\\sum_{m|P} h(m) y_m^2")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("y_m := \\frac{\\mu(m)}{h(m)} \\sum_{m | e | P} \\rho_e g(e)")]]

#text("and ")#mi("{h}")#text(" is defined on factors of ")#mi("{P}")#text(" by the Dirichlet convolution")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{h} = \\mu * \\frac{1}{g}.")]]

#text("Thus ")#mi("{h}")#text(" is the multiplicative function with ")#metadata(none) <tao-93969d193161ae6fbd17>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("h(p) := \\frac{g(p)}{1-g(p)}")]]

#text("for all ")#mi("{p|P}")#text("; we extend ")#mi("{h}")#text(" by zero outside of the factors of ")#mi("{P}")#text(". In particular ")#mi("{h}")#text(" is non-negative.")

#text("The coefficients ")#mi("{(y_m)_{m|P}}")#text(" are a transform of the original coefficients ")#mi("{(\\rho_e)_{e|P}}")#text(". For instance, if ")#mi("{P}")#text(" was replaced by a single prime ")#mi("{p}")#text(", then the coefficients ")#mi("{(y_1,y_p)}")#text(" would be related to the coefficients ")#mi("{(\\rho_1,\\rho_p)}")#text(" by the transform")

#align(center)[#tao-fit-display[#mitex("y_1 = \\rho_1 + g(p) \\rho_p; \\quad y_p = -\\frac{g(p)}{h(p)} \\rho_p")]]

#text("which is inverted as")

#align(center)[#tao-fit-display[#mitex("\\rho_1 = y_1 + h(p) y_p; \\quad \\rho_p = - \\frac{1}{g(p)} h(p) y_p.")]]

#text("More generally, we have the following inversion formula:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28 (Möbius-type inversion formula)")]#text(" Verify that ")#metadata(none) <tao-7a7b9f165c6525f14114>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("\\rho_e = \\frac{\\mu(e)}{g(e)} \\sum_{e|m|P} h(m) y_m")]]

#text("for any ")#mi("{e|P}")#text(".")
]

#text("From this formula, we see in particular that ")#mi("{y_m}")#text(" is supported on ")#mi("{m \\leq R}")#text(" if and only if ")#mi("{\\rho_e}")#text(" is supported on ")#mi("{e \\leq R}")#text(". The constraint ")#mi("{\\rho_1=1}")#text(" can now be written in terms of the ")#mi("{y_m}")#text(" coefficients as ")#metadata(none) <tao-7f2fe580edb35154041f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#mitex("\\sum_{m|P} h(m) y_m = 1.")]]

#text("Our task is now to minimise the quadratic form ")#link(<tao-68dbf73d03d3a5107eda>)[#text("(31)")]#text(" amongst all coefficients ")#mi("{y_m}")#text(" supported on ")#mi("{m \\leq R}")#text(" obeying ")#link(<tao-7f2fe580edb35154041f>)[#text("(34)")]#text(". The Cauchy-Schwarz inequality gives the lower bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{m|P} h(m) y_m^2 \\geq J^{-1}")]]

#text("where ")#mi("{J := \\sum_{m|P: m \\leq R} h(m)}")#text(", with equality precisely when ")#mi("{y_m = 1/J}")#text(" for ")#mi("{m \\leq R}")#text(". Inserting this back into ")#link(<tao-7a7b9f165c6525f14114>)[#text("(33)")]#text(", we arrive at the optimised Selberg sieve coefficients ")#metadata(none) <tao-e0901b044970ff1ba3a0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#mitex("\\rho_e = \\frac{1}{J} \\frac{\\mu(e)}{g(e)} \\sum_{e|m|P: m \\leq R} h(m)")]]

#text("and the quantity ")#link(<tao-b2fec115043348fde0ca>)[#text("(14)")]#text(" is equal to ")#mi("{\\frac{1}{J}}")#text(".")

#text("We have a pleasant size bound on the coefficients ")#mi("{\\rho_e}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 29")]#text(" We have ")#tao-math("{\\left|\\rho_e\\right| \\leq 1}", block: false)#text(" for all ")#mi("{e|P}")#text(".")
]

#emph[#text("Proof:")]#text(" Writing ")#mi("{m = ek}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\rho_e\\right| = \\frac{1}{Jg(e)} \\sum_{k| P/e: k \\leq R/e} h(e) h(k)", block: true)]]

#text("but")

#tao-aligned(keep: true)[


#tao-math("J  & \\geq \\sum_{k \\leq R/e} \\sum_{d|e} h(d) h(k)", block: true)



#tao-math(" & = \\sum_{k \\leq R/e} h(k) \\frac{h(e)}{g(e)}", block: true)
]

#text("since one can compute that ")#mi("{\\frac{h}{g} = h * 1}")#text(". The claim follows. ")#mi("\\Box")

#text("The upper bound sieve coefficients ")#mi("{\\lambda^+_d}")#text(" in ")#link(<tao-7c84ce75d92e62ebdbe7>)[#text("(28)")]#text(" is then bounded by")

#align(center)[#tao-fit-display[#tao-math("\\left|\\lambda^+_d\\right| \\leq \\sum_{[d_1,d_2]=d} 1 = \\tau_3(d)", block: true)]]

#text("where ")#mi("{\\tau_3(d) = \\sum_{d_1 d_2 d_3 = d} 1}")#text(" is the third divisor function. Applying Theorem ")#link(<tao-a0d950705fa91bbdd0f2>)[#text("5")]#text(", we thus have a general upper bound for Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 30 (Selberg sieve upper bound)")]#text(" ")#metadata(none) <tao-19147f7d7f268da443a0>#text(" Let ")#mi("{P}")#text(" be a squarefree natural number. For each prime ")#mi("{p}")#text(" dividing ")#mi("{P}")#text(", let ")#mi("{E_p}")#text(" be a set of integers. Let ")#mi("{g}")#text(" be a multiplicative function with ")#mi("{0 < g(p) < 1}")#text(" for all ")#mi("{p}")#text(", and define the multiplicative function ")#mi("{h}")#text(" by ")#link(<tao-93969d193161ae6fbd17>)[#text("(32)")]#text(", extending ")#mi("{h}")#text(" by zero outside of the factors of ")#mi("{P}")#text(". Let ")#mi("{D = R^2}")#text(" for some ")#mi("{R \\geq 1}")#text(". Suppose that ")#mi("{(a_n)_{n \\in {\\bf Z}}}")#text(" is a finitely supported sequence of non-negative reals, such that ")#metadata(none) <tao-6fe8ecbc1deafa51c2ec>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#mitex("\\sum_{n \\in E_d} a_n = g(d) X + r_d")]]

#text("for all ")#mi("{d \\leq D}")#text(" and some reals ")#mi("{X, r_d}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\not \\in\\bigcup_{p|P} E_p} a_n \\leq \\frac{X}{\\sum_{d \\leq R} h(d)} + \\sum_{d \\leq D} \\tau_3(d) |r_d|.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 31")]#text(" To compare this bound against the “expected” value of ")#mi("{X \\prod_{p|P} (1-g(p))}")#text(", observe from Euler products that")

#align(center)[#tao-fit-display[#mitex("\\prod_{p|P} (1-g(p)) = \\frac{1}{\\sum_d h(d)}.")]]
]

#text("The quantity ")#mi("{\\sum_{d \\leq R} h(d)}")#text(" can often be computed in practice using standard methods for controlling sums of multiplicative functions, such as Theorem 27 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(". We illustrate this with the following sample application of the Selberg sieve:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 32 (Sieving an interval)")]#text(" ")#metadata(none) <tao-cb46c56f0f6ec1fcfe92>#text(" Let ")#mi("{k, C}")#text(" be fixed natural numbers, and let ")#mi("{x \\geq 2}")#text(". For each prime number ")#mi("{p \\leq \\sqrt{x}}")#text(", let ")#mi("{E_p}")#text(" be the union of ")#mi("{\\omega(p)}")#text(" residue classes modulo ")#mi("{p}")#text(", where ")#mi("{\\omega(p) = k}")#text(" for all ")#mi("{p \\geq C}")#text(", and ")#mi("{\\omega(p) < p}")#text(" for all ")#mi("{p}")#text(". Then for any ")#mi("{\\varepsilon > 0}")#text(", one has ")#metadata(none) <tao-b652ea885f7a74758cd5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#tao-math("\\left|\\{ n: n \\leq x \\} \\backslash \\bigcup_{p \\leq \\sqrt{x}} E_p\\right| \\leq (2^k k! + \\varepsilon) {\\mathfrak S} \\frac{x}{\\log^k x}", block: true)]]

#text("whenever ")#mi("{x}")#text(" is sufficiently large depending on ")#mi("{k,C,\\varepsilon}")#text(", where ")#mi("{{\\mathfrak S}}")#text(" is the singular series ")#metadata(none) <tao-cc9448917f4a0f9ae748>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#mitex("{\\mathfrak S} := \\prod_p (1-\\frac{1}{p})^{-k} (1 - \\frac{\\omega(p)}{p}).")]]
]

#emph[#text("Proof:")]#text(" We apply Theorem ")#link(<tao-19147f7d7f268da443a0>)[#text("30")]#text(" with ")#mi("{a_n := 1_{1 \\leq n \\leq x}}")#text(", ")#mi("{X := x}")#text(", ")#mi("{P := \\prod_{p \\leq \\sqrt{x}} p}")#text(", and ")#mi("{g(p) := \\frac{\\omega(p)}{p}}")#text(". We set ")#mi("{D := x^{1-\\varepsilon}}")#text(" and ")#mi("{R := D^{1/2}}")#text(". For any ")#mi("{d|P}")#text(", ")#mi("{E_d}")#text(" is the union of ")#mi("{\\prod_{p|d} \\omega(p)}")#text(" residue classes modulo ")#mi("{d}")#text(", and thus by ")#link(<tao-6fe8ecbc1deafa51c2ec>)[#text("(36)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|r_d\\right| \\leq \\prod_{p|d} \\omega(p)", block: true)]]

#text("and in particular")

#align(center)[#tao-fit-display[#tao-math("\\left|r_d\\right| \\ll_{k,C} \\tau_k(d).", block: true)]]

#text("From Theorem ")#link(<tao-19147f7d7f268da443a0>)[#text("30")]#text(", we thus can upper bound the left-hand side of ")#link(<tao-b652ea885f7a74758cd5>)[#text("(37)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\frac{x}{\\sum_{d \\leq R} h(d)} + O_{k,C}( \\sum_{d \\leq D} \\tau_3(d) \\tau_k(d) ).")]]

#text("By the divisor bound and the choice of ")#mi("{D}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq D} \\tau_3(d) \\tau_k(d) \\ll_{k,C,\\varepsilon} \\frac{x}{\\log^{k+1} x}")]]

#text("so it will suffice to show (after adjusting ")#mi("{\\varepsilon}")#text(") that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq R} h(d) = \\frac{1}{(2 + O(\\varepsilon))^k k! {\\mathfrak S}} \\log^k x + O_{k,C,\\varepsilon}( \\log^{k-1} x ).")]]

#text("But from Theorem 27(ii) of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(" (with ")#mi("{g(n)}")#text(" replaced by ")#mi("{n h(n)}")#text("), the left-hand side is")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{k!} {\\mathfrak H} \\log^k R + O_{k,C,\\varepsilon}( \\log^{k-1} R )")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak H} = \\prod_p (1 - \\frac{1}{p})^k (1 + h(p)).")]]

#text("Since ")#mi("{h(p) = \\frac{g(p)}{1-g(p)} = \\frac{\\omega(p)}{p-\\omega(p)}}")#text(", we see that ")#mi("{{\\mathfrak H} = {\\mathfrak S}^{-1}}")#text(", and the claim follows (after adjusting ")#mi("{\\varepsilon}")#text(" appropriately). ")#mi("\\Box")

#text("The upper bound in ")#link(<tao-b652ea885f7a74758cd5>)[#text("(37)")]#text(" is off by a factor of about ")#mi("{2^k k!}")#text(" from what one expects to be the truth. The following exercises give some quick applications of Theorem ")#link(<tao-cb46c56f0f6ec1fcfe92>)[#text("32")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33 (Brun-Titchmarsh inequality)")]#text(" ")#metadata(none) <tao-45d3346fa1b23665571f>#text(" If ")#mi("{\\varepsilon > 0}")#text(", and ")#mi("{y}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon}")#text(", establish the ")#link("http://en.wikipedia.org/wiki/Brun%E2%80%93Titchmarsh_theorem")[#text("Brun-Titchmarsh inequality")]

#align(center)[#tao-fit-display[#mitex("\\pi(x+y) - \\pi(x) \\leq \\frac{(2+\\varepsilon)y}{\\log y}")]]

#text("for all ")#mi("{x > 1}")#text(", where ")#mi("{\\pi(x)}")#text(" is the number of primes less than ")#mi("{x}")#text(". More generally, if ")#mi("{\\varepsilon > 0}")#text(", ")#mi("{a\\ (q)}")#text(" is a primitive residue class, and ")#mi("{y}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon,q}")#text(", establish the Brun-Titchmarsh inequality")

#align(center)[#tao-fit-display[#mitex("\\pi(x+y; a\\ (q)) - \\pi(x; a\\ (q)) \\leq \\frac{(2+\\varepsilon)y}{\\phi(q) \\log(y/q)}")]]

#text("for all ")#mi("{x>1}")#text(", where ")#mi("{\\pi(x; a\\ (q))}")#text(" is the number of primes less than ")#mi("{x}")#text(" that lie in ")#mi("{a\\ (q)}")#text(". Comparing this with the prime number theorem in arithmetic progressions, we see that the Brun-Titchmarsh inequality is off from the truth by a factor of two when ")#mi("{x = O(y)}")#text("; however, the Brun-Titchmarsh inequality is applicable even when ")#mi("{x}")#text(" is extremely large compared with ")#mi("{y}")#text(", whereas the prime number theorem gives no non-trivial bound in this regime. The ")#mi("{\\varepsilon}")#text(" can in fact be deleted in these inequalities, a ")#link("http://www.ams.org/mathscinet-getitem?mr=374060")[#text("result of Montgomery and Vaughan")]#text(" (using a refinement of the large sieve, discussed below).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34 (Upper bound for ")#mi("{k}")#text("-tuple conjecture)")]#text(" If ")#mi("{(h_1,\\dots,h_k)}")#text(" is an admissible ")#mi("{k}")#text("-tuple (as in Exercise ")#link(<tao-6a5b32b39ff583bc5f86>)[#text("24")]#text("), and let ")#mi("{{\\mathfrak S}}")#text(" be the singular series ")#link(<tao-094a367b026246fb6464>)[#text("(27)")]#text(". Show that ")#metadata(none) <tao-bcee72e6df5d56319125>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(39)")])
#tao-math("\\left|\\{ n \\leq x: n+h_1,\\dots,n+h_k \\in {\\mathcal P}\\}\\right| \\leq (2^k k! + o(1)) {\\mathfrak S} \\frac{x}{\\log^k x}", block: true)]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(". (This should be compared with the prime tuples conjecture, which predicts")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ n \\leq x: n+h_1,\\dots,n+h_k \\in {\\mathcal P}\\}\\right| = (1 + o(1)) {\\mathfrak S} \\frac{x}{\\log^k x}", block: true)]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(".)")
]

#text("As with the fundamental lemma, one can use the Selberg sieve together with the Bombieri-Vinogradov theorem to sift out a set of primes, rather than a set of intervals:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35 (Sieving primes)")]#text(" ")#metadata(none) <tao-8efdd041f86d689a9464>#text(" Let ")#mi("{k, C}")#text(" be fixed natural numbers, and let ")#mi("{x \\geq 2}")#text(". For each prime number ")#mi("{p \\leq \\sqrt{x}}")#text(", let ")#mi("{E_p}")#text(" be the union of ")#mi("{\\omega(p)}")#text(" primitive residue classes modulo ")#mi("{p}")#text(", where ")#mi("{\\omega(p) = k-1}")#text(" for all ")#mi("{p \\geq C}")#text(", and ")#mi("{\\omega(p) < p-1}")#text(" for all ")#mi("{p}")#text(". Then for any ")#mi("{\\varepsilon > 0}")#text(", one has ")#metadata(none) <tao-f546deca2a11f72f68bc>

#tao-aligned(keep: true)[


#tao-math("\\left|\\{ p \\in {\\mathcal P}: p \\leq x \\} \\backslash \\bigcup_{p \\leq \\sqrt{x}} E_p\\right|  & \\leq (4^{k-1} (k-1)! + \\varepsilon", block: true, numbering: n => [#text("(40)")])



#tao-math(" & + O_{k,C,\\varepsilon}( \\frac{1}{\\log x} )) {\\mathfrak S} \\frac{x}{\\log^k x}", block: true)
]

#text("where ")#mi("{{\\mathfrak S}}")#text(" is the singular series")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak S} := \\prod_p (1-\\frac{1}{p})^{1-k} (1 - \\frac{\\omega(p)}{p-1}).")]]

#text("(You will need Exercise 23 of ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("Notes 3")]#text(" to control the ")#mi("{\\tau_3}")#text(" terms arising from the remainder term.) If one assumes the ")#link("http://en.wikipedia.org/wiki/Elliott%E2%80%93Halberstam_conjecture")[#text("Elliott-Halberstam conjecture")]#text(" (see Exercise 22 of ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("Notes 3")]#text("), show that the factor of ")#mi("{4^{k-1}}")#text(" here can be lowered to ")#mi("{2^{k-1}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36")]#text(" Show that the quantity ")#mi("{2^k k!}")#text(" in ")#link(<tao-bcee72e6df5d56319125>)[#text("(39)")]#text(" may be replaced by ")#mi("{4^{k-1} (k-1)!}")#text(", which is a superior bound for ")#mi("{k \\leq 3}")#text(". (It remains an open question to improve upon the bound ")#mi("{\\min( 2^k k!, 4^{k-1} (k-1)! )}")#text(" without assuming any further unproven conjectures.) Assuming the Elliott-Halberstam conjecture, show that one can replace ")#mi("{2^k k!}")#text(" instead by ")#mi("{2^{k-1} (k-1)!}")#text(".")
]

#text("We have approached the analysis of the Selberg sieve as a “discrete” optimisation problem, in which one is trying to optimise the parameters ")#mi("{(\\rho_d)_{d|P; d \\leq R}}")#text(" or ")#mi("{(y_m)_{m|P; m \\leq R}}")#text(" that are indexed by the discrete set ")#mi("{\\{ d|P: d \\leq R \\}}")#text(". It is however also instructive to consider a “continuous” version of the optimisation problem, in which the coefficients ")#mi("{\\rho_d}")#text(" or ")#mi("{y_m}")#text(" are described by a continuous function of ")#mi("{d}")#text(" or ")#mi("{m}")#text("; this is a slightly more restrictive class of sieves, but turns out to lead to numerical bounds that come very close to the discrete optimum, and allow for the use of methods from calculus of variations to come into play when using the Selberg sieve in more sophisticated ways. (See ")#link("http://www.ams.org/mathscinet-getitem?mr=1295844")[#text("these lecture notes of Selberg")]#text(" for further discussion of how the continuous problem serves as a good approximation of the discrete one.) We give a basic illustration of this by presenting an alternate proof of (a very slightly weaker form of) Theorem ")#link(<tao-cb46c56f0f6ec1fcfe92>)[#text("32")]#text(" in which we do not use the choice ")#link(<tao-e0901b044970ff1ba3a0>)[#text("(35)")]#text(" for the sieve weights ")#mi("{\\rho_e}")#text(", but instead choose weights of the form ")#metadata(none) <tao-badbe2bc65856bf35ed4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(41)")])
#mitex("\\rho_d := \\mu(d) f( \\frac{\\log d}{\\log R} )")]]

#text("for some smooth compactly supported function ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" that vanishes on ")#mi("{[1,+\\infty)}")#text(", and which equals ")#mi("{1}")#text(" at the origin; compare this smoothly truncated version of the Möbius function with the more abrupt truncations of the Möbius function that arise in combinatorial sieving. Such cases of the Selberg sieve were studied by several authors, most notably ")#link("http://www.ams.org/mathscinet-getitem?mr=2552109")[#text("Goldston, Pintz, and Yildirim")]#text(" (although they made ")#mi("{F}")#text(" a polynomial on ")#mi("{[0,1]}")#text(", rather than a smooth function). As in the previous proof of Theorem ")#link(<tao-cb46c56f0f6ec1fcfe92>)[#text("32")]#text(", we take ")#mi("{g(p) := \\frac{\\omega(p)}{p}}")#text(", ")#mi("{D := x^{1-\\varepsilon}}")#text(", ")#mi("{R := D^{1/2}}")#text(", ")#mi("{P := \\prod_{p \\leq \\sqrt{x}} p}")#text(", ")#mi("{X=x}")#text(", and ")#mi("{a_n := 1_{1 \\leq n \\leq x}}")#text(". The quantity ")#link(<tao-f3cf3f52140e146702cb>)[#text("(30)")]#text(" (or ")#link(<tao-b2fec115043348fde0ca>)[#text("(14)")]#text(") is then equal to")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2|P} f( \\frac{\\log d_1}{\\log R} ) f( \\frac{\\log d_2}{\\log R} ) \\mu(d_1) \\mu(d_2) g( [d_1,d_2] ).")]]

#text("We can remove the constraints ")#mi("{d_1, d_2|P}")#text(", since the summands vanish outside of this range. To estimate this sum we use an argument related to that used to prove Proposition 9 from ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(". We first use Fourier inversion, applied to the function ")#mi("{u \\mapsto e^u f(u)}")#text(", to obtain a representation of the form ")#metadata(none) <tao-1deb861e670432b25732>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#mitex("e^u f(u) = \\int_{\\bf R} F(t) e^{-itu}\\ dt")]]

#text("for some smooth, rapidly decreasing function ")#mi("{F: {\\bf R} \\rightarrow {\\bf C}}")#text(", thus ")#metadata(none) <tao-9789dae9e8de2d0c79d3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(43)")])
#tao-math("\\left|F(t)\\right| \\ll_{f,A} (1+\\left|t\\right|)^{-A}", block: true)]]

#text("for any ")#mi("{A>0}")#text(". We then have")

#align(center)[#tao-fit-display[#mitex("f( \\frac{\\log d_1}{\\log R} ) = \\int_{\\bf R} \\frac{F(t_1)}{d_1^{\\frac{1+it_1}{\\log R}}} dt_1")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("f( \\frac{\\log d_2}{\\log R} ) = \\int_{\\bf R} \\frac{F(t_2)}{d_2^{\\frac{1+it_2}{\\log R}}} dt_2")]]

#text("and so by Fubini’s theorem (using the divisor bound ")#mi("{g(d) = O( d^{-1+o(1)} )}")#text(") we may write ")#link(<tao-f3cf3f52140e146702cb>)[#text("(30)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{\\bf R} F(t_1) F(t_2) \\sum_{d_1,d_2} \\frac{\\mu(d_1) \\mu(d_2) g([d_1,d_2])}{d_1^{\\frac{1+it_1}{\\log R}} d_2^{\\frac{1+it_2}{\\log R}}}\\ dt_1 dt_2,")]]

#text("and then by Euler products and the definition of ")#mi("{g}")#text(" we may factorise this as ")#metadata(none) <tao-ab88ea80fdee69b28b0f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(44)")])
#mitex("\\int_{\\bf R} \\int_{\\bf R} F(t_1) F(t_2) G( t_1, t_2)\\ dt_1 dt_2")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("G(t_1,t_2) := \\prod_{p} ( 1 - \\frac{\\omega(p)}{p^{1+\\frac{1+it_1}{\\log R}}} - \\frac{\\omega(p)}{p^{1+\\frac{1+it_2}{\\log R}}} + \\frac{\\omega(p)}{p^{1+\\frac{1+it_1+1+it_2}{\\log R}}} ).")]]

#text("We have the crude upper bound")

#align(center)[#tao-fit-display[#tao-math("\\left|G(t_1,t_2)\\right| \\ll_{k,C} \\prod_p \\exp( O_k( \\frac{1}{p^{1+1/\\log R}} ) )", block: true)]]

#text("which by the asymptotic ")#mi("{\\sum_p \\frac{1}{p^s} = -\\log(s-1) + O(1)}")#text(" for ")#mi("{s > 1}")#text(" (see equation (22) of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(") implies that")

#align(center)[#tao-fit-display[#tao-math("\\left|G(t_1,t_2)\\right| \\ll_{k,C} \\log^{O_k(1)} R.", block: true)]]

#text("From this and the rapid decrease of ")#mi("{f}")#text(", we see that the contribution of the cases ")#tao-math("{\\left|t_1\\right| \\geq \\sqrt{\\log R}}", block: false)#text(" or ")#tao-math("{\\left|t_2\\right| \\geq \\sqrt{\\log R}}", block: false)#text(" (say) to ")#link(<tao-ab88ea80fdee69b28b0f>)[#text("(44)")]#text(" is ")#mi("{O_{k,C,f,A}( \\log^{-A} R )}")#text(" for any ")#mi("{A>0}")#text(". Thus we can write ")#link(<tao-ab88ea80fdee69b28b0f>)[#text("(44)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|t_1\\right|, \\left|t_2\\right| \\leq \\sqrt{\\log R}} F(t_1) F(t_2) G( t_1, t_2)\\ dt_1 dt_2 + O_{k,C,f,A}(\\log^{-A} R).", block: true)]]

#text("Since ")#mi("{\\zeta(s) = \\prod_p (1 - \\frac{1}{p^s})^{-1}}")#text(", we can factor")

#align(center)[#tao-fit-display[#mitex("G(t_1,t_2) = \\frac{\\zeta(1 + \\frac{1+it_1+1+it_2}{\\log R})^k}{\\zeta(1+\\frac{1+it_1}{\\log R})^k \\zeta(1+\\frac{1+it_2}{\\log R})^k} \\prod_p E_p(t_1,t_2)")]]

#text("where ")#mi("{E_p(t_1,t_2)}")#text(" is the local Euler factor")

#align(center)[#tao-fit-display[#mitex("\\frac{( 1 - \\frac{\\omega(p)}{p^{1+\\frac{1+it_1}{\\log R}}} - \\frac{\\omega(p)}{1+p^{\\frac{1+it_2}{\\log R}}} + \\frac{\\omega(p)}{p^{1+\\frac{1+it_1+1+it_2}{\\log R}}} ) (1 - \\frac{1}{p^{1+\\frac{1+it_1+1+it_2}{\\log R}}})^k}{(1-\\frac{1}{p^{1+\\frac{1+it_1}{\\log R}}})^k (1-\\frac{1}{p^{1+\\frac{1+it_2}{\\log R}}})^k}.")]]

#text("The point of this factorisation is that, thanks to a routine but somewhat tedious Taylor expansion, one has the asymptotics")

#align(center)[#tao-fit-display[#mitex("E_p(t_1,t_2) = 1 + O_{k,C}(\\frac{1}{p^{3/2}})")]]

#text("for any complex ")#mi("{t_1,t_2}")#text(" with imaginary part less than ")#mi("{\\frac{1}{2} \\log R}")#text(" in magnitude, and hence (by the Cauchy integral formula)")

#align(center)[#tao-fit-display[#mitex("\\partial_{t_1} E_p(t_1,t_2), \\partial_{t_2} E_p(t_1,t_2) = O_{k,C}( \\frac{1}{\\log R} \\frac{1}{p^{3/2}})")]]

#text("for any complex ")#mi("{t_1,t_2}")#text(" with imaginary part less than ")#mi("{\\frac{1}{4} \\log R}")#text(" in magnitude. By the fundamental theorem of calculus, we thus have")

#align(center)[#tao-fit-display[#mitex("E_p(t_1,t_2) = E_p(i,i) + O_{k,C}( \\frac{1}{\\sqrt{\\log R}} \\frac{1}{p^{3/2}} )")]]

#text("when ")#tao-math("{\\left|t_1\\right|, \\left|t_2\\right| \\leq \\sqrt{\\log R}}", block: false)#text(" are real. Also, observe from ")#link(<tao-cc9448917f4a0f9ae748>)[#text("(38)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\prod_p E_p(i,i) = {\\mathfrak S}")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\prod_p E_p(t_1,t_2) = {\\mathfrak S} + O_{k,C}( \\frac{1}{\\sqrt{\\log R}} ).")]]

#text("From this and the standard asymptotic ")#mi("{\\zeta(s) = \\frac{1}{s-1} + O(1)}")#text(" for ")#mi("{s}")#text(" close to ")#mi("{1}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("G(t_1,t_2) = {\\mathfrak S} \\log^{-k} R \\frac{(1+it_1)^k (1+it_2)^k}{(1+it_1+1+it_2)^k} + O_{k,C}( (1+\\left|t_1\\right|+\\left|t_2\\right|)^{O(1)} \\log^{-k-1/2} R )", block: true)]]

#text("and thus we can write ")#link(<tao-ab88ea80fdee69b28b0f>)[#text("(44)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("{\\mathfrak S} \\log^{-k} R \\int_{\\left|t_1\\right|, \\left|t_2\\right| \\leq \\sqrt{\\log R}} F(t_1) F(t_2) \\frac{(1+it_1)^k (1+it_2)^k}{(1+it_1+1+it_2)^k} \\ dt_1 dt_2", block: true)]]

#align(center)[#tao-fit-display[#mitex("+ O_{k,C,f}( \\log^{-k-1/2} R ).")]]

#text("From the rapid decrease of ")#mi("{F}")#text(", we may now remove the constraints on ")#mi("{t_1,t_2}")#text(" and write this as")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak S} \\log^{-k} R \\int_{\\bf R} \\int_{\\bf R} F(t_1) F(t_2) \\frac{(1+it_1)^k (1+it_2)^k}{(1+it_1+1+it_2)^k} \\ dt_1 dt_2")]]

#align(center)[#tao-fit-display[#mitex("+ O_{k,C,f}( \\log^{-k-1/2} R ).")]]

#text("To handle the weight ")#mi("{\\frac{(1+it_1)^k (1+it_2)^k}{(1+it_1+1+it_2)^k}}")#text(", we observe from dividing ")#link(<tao-1deb861e670432b25732>)[#text("(42)")]#text(" by ")#mi("{e^u}")#text(" and then differentiating ")#mi("{k}")#text(" times that")

#align(center)[#tao-fit-display[#mitex("f^{(k)}(u) = (-1)^k \\int_{\\bf R} (1+it)^k F(t) e^{-(1+it)u}\\ dt")]]

#text("and hence by Fubini’s theorem")

#align(center)[#tao-fit-display[#mitex("f^{(k)}(u)^2 = \\int_{\\bf R} \\int_{\\bf R} (1+it_1)^k (1+it_2)^k F(t_1) F(t_2) e^{-(1+it_1+1+it_2)u}\\ dt_1 dt_2.")]]

#text("Using the Gamma function identity ")#mi("{\\int_0^\\infty e^{-su} u^{k-1}\\ du = \\frac{(k-1)!}{s^k}}")#text(" for any ")#mi("{s}")#text(" with ")#mi("{\\text{Re}(s)>0}")#text(", we conclude from another application of Fubini’s theorem that")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty f^{(k)}(u)^2 u^{k-1}\\ du")]]

#align(center)[#tao-fit-display[#mitex("= (k-1)! \\int_{\\bf R} \\int_{\\bf R} \\frac{(1+it_1)^k (1+it_2)^k}{(1+it_1+1+it_2)^k} F(t_1) F(t_2)\\ dt_1 dt_2.")]]

#text("Note from the support of ")#mi("{f}")#text(" that we can restrict the ")#mi("{u}")#text(" integral to ")#mi("{1}")#text(". Putting this all together, we see that with the choice of weights ")#link(<tao-badbe2bc65856bf35ed4>)[#text("(41)")]#text(", the expression ")#link(<tao-b2fec115043348fde0ca>)[#text("(14)")]#text(" takes the form")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{(k-1)!} {\\mathfrak S} \\log^{-k} R \\int_0^1 f^{(k)}(u)^2 u^{k-1}\\ du + O_{k,C,f}( \\log^{-k-1/2} R ).")]]

#text("Recall that we are requiring ")#mi("{f(0)}")#text(" to equal ")#mi("{1}")#text(", which after ")#mi("{k}")#text(" applications of the fundamental theorem of calculus (or integration by parts) is equivalent to the constraint")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 f^{(k)}(u) \\frac{u^{k-1}}{(k-1)!}\\ du = 1.")]]

#text("Since ")#mi("{\\int_0^1 u^{k-1}\\ du = \\frac{1}{k}}")#text(", we conclude from Cauchy-Schwarz that")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 f^{(k)}(u)^2 u^{k-1}\\ du \\geq k ((k-1)!)^2,")]]

#text("with equality occurring when ")#mi("{f^{(k)}(u) = k!}")#text(". Equality is not quite attainable with ")#mi("{f}")#text(" smooth, but by a mollification one can select an ")#mi("{f}")#text(" smoothly supported on (say) ")#mi("{[-1,1]}")#text(" with ")#mi("{f(0)=0}")#text(" and")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 f^{(k)}(u)^2 u^{k-1}\\ du \\leq (1+\\varepsilon) k ((k-1)!)^2")]]

#text("for any ")#mi("{\\varepsilon > 0}")#text(". The expression ")#link(<tao-b2fec115043348fde0ca>)[#text("(14)")]#text(" now takes the form")

#align(center)[#tao-fit-display[#mitex("(1+\\varepsilon) k! {\\mathfrak S} \\log^{-k} R + O_{k,C,f}( \\log^{-k-1/2} R ).")]]

#text("Meanwhile, from ")#link(<tao-badbe2bc65856bf35ed4>)[#text("(41)")]#text(" we have ")#mi("{\\rho_d = O_f(1)}")#text(" and thus ")#mi("{\\lambda^+_d \\ll_f \\tau_3(d)}")#text(" much as before. We can then apply Theorem ")#link(<tao-a0d950705fa91bbdd0f2>)[#text("5")]#text(" as before to recover Theorem ")#link(<tao-cb46c56f0f6ec1fcfe92>)[#text("32")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 37")]#text(" The Selberg sieve is most naturally used as an upper bound sieve. However, it is possible to modify the Selberg sieve to produce a lower bound sieve in a number of ways. One way is to simply insert the Selberg sieve into the Buchstab identity ")#link(<tao-e81935fb86434cdaaeee>)[#text("(16)")]#text("; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=167467")[#text("this paper of Ankeny and Onishi")]#text(" for an investigation of this approach. Another method is to multiply the Selberg upper bound sieve by a lower bound sieve ")#mi("{\\Lambda_-}")#text("; somewhat surprisingly, even a very crude lower bound sieve such as the ")#mi("{k=1}")#text(" Bonferroni sieve ")#mi("{\\Lambda_- = 1 - \\sum_{p|P} 1_{E_p}}")#text(" can give reasonably good results for this purpose. See ")#link("http://www.ams.org/mathscinet-getitem?mr=2647984")[#text("Friedlander and Iwaniec")]#text(" for further analysis of this lower bound sieve (sometimes known as the ")#mi("{\\Lambda^2 \\Lambda_-}")#text(" sieve).")
]

#heading(level: 1)[#strong[#text(" — 3. A multidimensional Selberg sieve, and bounded gaps between primes — ")]]

#text("We now discuss a multidimensional variant of the Selberg sieve that establishes a ")#link("http://www.ams.org/mathscinet-getitem?mr=3272929")[#text("recent result of Maynard")]#text(" (and independently by myself), giving further partial progress towards the Hardy-Littlewood prime tuples conjecture. For sake of exposition we shall omit some details; see ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/")[#text("this previous blog post")]#text(" for a more careful treatment; see also ")#link("http://arxiv.org/abs/1410.8400")[#text("this survey of Granville")]#text(".")

#text("More precisely, we sketch the proof of")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 38 (Maynard’s theorem)")]#text(" ")#metadata(none) <tao-ee4d988c65de860fabbf>#text(" Let ")#mi("{m}")#text(" be a natural number, and let ")#mi("{k}")#text(" be sufficiently large depending on ")#mi("{m}")#text(". Then for any admissible ")#mi("{k}")#text("-tuple ")#mi("{(h_1,\\dots,h_k)}")#text(", there exist infinitely many natural numbers ")#mi("{n}")#text(" such that at least ")#mi("{m+1}")#text(" of the numbers ")#mi("{n+h_1,\\dots,n+h_k}")#text(" are prime.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39")]#text(" Show that Maynard’s theorem implies that the quantity ")#mi("{H_{m} = \\lim \\inf_{n \\rightarrow \\infty} p_{n+m}-p_n}")#text(" is finite for each natural number ")#mi("{m}")#text(", where ")#mi("{p_n}")#text(" is the ")#mi("{n^{th}}")#text(" prime, is finite. (For the most recent bounds on ")#mi("{H_m}")#text(", see ")#link("http://www.resmathsci.com/content/1/1/12")[#text("this Polymath paper")]#text(".) In particular, the ")#mi("{m=1}")#text(" case of Theorem ")#link(<tao-ee4d988c65de860fabbf>)[#text("38")]#text(" yields “bounded gaps between primes”, in that there is a finite ")#mi("{H}")#text(" for which ")#mi("{p_{n+1}-p_n \\leq H}")#text(" for infinitely many ")#mi("{n}")#text(".")
]

#text("Even the ")#mi("{m=1}")#text(" case of this theorem was only proven in 2013 ")#link("http://www.ams.org/mathscinet-getitem?mr=3171761")[#text("by Zhang")]#text(", building upon ")#link("http://www.ams.org/mathscinet-getitem?mr=2552109")[#text("earlier work of Goldston, Pintz, and Yildirim")]#text(". Zhang’s original value of ")#mi("{H}")#text(" in the “bounded gaps” application was ")#mi("{H = 7 \\times 10^7}")#text("; this has since been lowered several times, with the current record being ")#mi("{H=246}")#text(", ")#link("http://www.resmathsci.com/content/1/1/12")[#text("due to the Polymath project")]#text(". The original arguments of Zhang and Goldston-Pintz-Yildirim used a “one-dimensional” Selberg sieve, with coefficients given by ")#link(<tao-badbe2bc65856bf35ed4>)[#text("(41)")]#text(", and required quite strong equidistribution hypotheses on the primes (stronger than what the Bombieri-Vinogradov theorem provides). However, the argument of Maynard relies on a more general and flexible “multi-dimensional” Selberg sieve, which has better numerical performance, and as such does not need any equidistribution result beyond the Bombieri-Vinogradov theorem. This sieve has since been used for a number of further applications in analytic number theory; see ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("this web page")]#text(" for a list of papers in this direction.")

#text("Let ")#mi("{m, k, h_1,\\dots,h_k}")#text(" be as in Theorem ")#link(<tao-ee4d988c65de860fabbf>)[#text("38")]#text(". Suppose that, for sufficiently large ")#mi("{x}")#text(", we can find a non-negative function ")#mi("{\\nu: {\\bf N} \\rightarrow {\\bf R}^+}")#text(" supported on ")#mi("{[x/2,x]}")#text(" with the property that ")#metadata(none) <tao-8eba22e77bc660f69301>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(45)")])
#mitex("\\sum_{i=1}^k \\sum_n \\nu(n) 1_{n+h_i \\in {\\mathcal P}} > m \\sum_n \\nu(n).")]]

#text("Then by the pigeonhole principle, there exists at least one ")#mi("{n \\in [x/2,x]}")#text(" such that ")#mi("{\\sum_{i=1}^k 1_{n+h_i \\in {\\mathcal P}} > m}")#text(", that is to say at least ")#mi("{m+1}")#text(" of the numbers ")#mi("{n+h_1,\\dots,n+h_k}")#text(" are prime. Letting ")#mi("{x}")#text(" go to infinity (keeping ")#mi("{m,k,h_1,\\dots,h_k}")#text(" fixed), we will obtain Theorem ")#link(<tao-ee4d988c65de860fabbf>)[#text("38")]#text(".")

#text("It remains to establish the existence of a function ")#mi("{\\nu}")#text(" with the required properties. Prior to the work of Goldston, Pintz, and Yildirim, it was only known (using tools such as the fundamental lemma of sieve theory, or off-the-shelf Selberg sieves) how to construct sieve weights ")#mi("{\\nu}")#text(" obeying ")#link(<tao-8eba22e77bc660f69301>)[#text("(45)")]#text(" with ")#mi("{m}")#text(" replaced by a small constant less than ")#mi("{1}")#text(". The earlier arguments of Zhang and Goldston-Pintz-Yildirim chose a weight ")#mi("{\\nu}")#text(" which was essentially of the Selberg sieve form")

#align(center)[#tao-fit-display[#mitex("\\nu(n) := 1_{[x/2,x]}(n) \\left( \\sum_{d | (n+h_1) \\dots (n+h_k)} \\mu(d) f( \\frac{\\log d}{\\log R} ) \\right)^2")]]

#text("(compare with ")#link(<tao-badbe2bc65856bf35ed4>)[#text("(41)")]#text("), where ")#mi("{R = x^{\\theta/2}}")#text(" for some fixed ")#mi("{0 < \\theta < 1}")#text(", and ")#mi("{f}")#text(" was a smooth fixed compactly supported function. Omitting many calculations, their conclusion was that one could prove the ")#mi("{m=1}")#text(" case of Theorem ")#link(<tao-ee4d988c65de860fabbf>)[#text("38")]#text(" once one had some sort of distribution result on the primes at level ")#mi("{\\theta}")#text(" (as defined in Exercise 22 of ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("Notes 3")]#text(") with ")#mi("{1/2 < \\theta < 1}")#text(". Unfortunately, this just falls short of what the Bombieri-Vinogradov theorem provides, which is a level of distribution ")#mi("{\\theta}")#text(" for any ")#mi("{0 < \\theta < 1/2}")#text(". One of the key contributions of Zhang was to obtain a partial distribution result at a value of ")#mi("{\\theta}")#text(" slightly above ")#mi("{1/2}")#text(", which when combined with (a modification of) the previous work of Goldston, Pintz, and Yildirim, was able to yield the ")#mi("{m=1}")#text(" case of Theorem ")#link(<tao-ee4d988c65de860fabbf>)[#text("38")]#text(".")

#text("The approach of Maynard and myself was a little different, based on multidimensional Selberg sieves such as")

#align(center)[#tao-fit-display[#mitex("\\nu(n) := 1_{[x/2,x]}(n) \\times")]]

#align(center)[#tao-fit-display[#mitex("\\left( \\sum_{d_i | n+h_i \\forall i=1,\\dots,k} \\mu(d_1) \\dots \\mu(d_k) f( \\frac{\\log d_1}{\\log R}, \\dots, \\frac{\\log d_k}{\\log R} ) \\right)^2")]]

#text("for some multidimensional smooth function ")#mi("{f: [0,+\\infty)^k \\rightarrow {\\bf R}}")#text(" supported on the simplex ")#mi("{\\{ (t_1,\\dots,t_k): t_1+\\dots +t_k \\leq 1 \\}}")#text("; the one-dimensional sieve considered by Zhang and Goldston-Pintz-Yildirim is then essentially the case when ")#mi("{f(t_1,\\dots,t_k)}")#text(" is a function just of ")#mi("{t_1+\\dots+t_k}")#text(" on this simplex. Actually, to avoid some (very minor) issues concerning common factors between the ")#mi("{n+h_i}")#text(", and also to essentially eliminate the role of the singular series, it is convenient to work with a slight modification ")#metadata(none) <tao-317cea04b3172ab7f18b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(46)")])
#mitex("\\nu(n) := 1_{n=b\\ (W)} 1_{[x/2,x]}(n) \\times")]]

#align(center)[#tao-fit-display[#mitex("\\left( \\sum_{d_i | n+h_i \\forall i=1,\\dots,k} \\mu(d_1) \\dots \\mu(d_k) f( \\frac{\\log d_1}{\\log R}, \\dots, \\frac{\\log d_k}{\\log R} ) \\right)^2")]]

#text("of the above sieve, where ")#mi("{W = \\prod_{p \\leq w} p}")#text(" for some ")#mi("{w}")#text(" slowly growing to infinity with ")#mi("{x}")#text(" (e.g. ")#mi("{w = \\log\\log\\log x}")#text(" will do), and ")#mi("{b\\ (W)}")#text(" is a residue class such that ")#mi("{b+h_i\\ (W)}")#text(" is primitive for all ")#mi("{i=1,\\dots,k}")#text(" (such a ")#mi("{b}")#text(" exists thanks to the admissibility of ")#mi("{(h_1,\\dots,h_k)}")#text(" and the Chinese remainder theorem). Note that for ")#mi("{w}")#text(" large enough, the ")#mi("{n+h_i}")#text(" have no common factors, and so the ")#mi("{d_1,\\dots,d_k}")#text(" are automatically coprime to each other and to ")#mi("{W}")#text(". (In Maynard’s paper, the coefficients ")#mi("{f( \\frac{\\log d_1}{\\log R}, \\dots, \\frac{\\log d_k}{\\log R} )}")#text(" were replaced by a sequence ")#mi("{\\rho_{d_1,\\dots,d_k}}")#text(" which was not directly arising from a smooth function ")#mi("{f}")#text(", but instead the analogue of the ")#mi("{y_{m_1,\\dots,m_k}}")#text(" coefficients from the preceding section were chosen to be of the form ")#mi("{F( \\frac{\\log d_1}{\\log R}, \\dots, \\frac{\\log d_k}{\\log R} )}")#text(" for some suitable function ")#mi("{F}")#text(". However, the differences between the two approaches are fairly minor.)")

#text("It is possible to estimate the right-hand side of ")#link(<tao-8eba22e77bc660f69301>)[#text("(45)")]#text(" using a modification of the arguments of the previous section:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 40")]#text(" ")#metadata(none) <tao-f71854425943c68be20e>#text(" Let ")#mi("{k, h_1,\\dots,h_k, b, W, \\theta, R, f, \\nu}")#text(" be as in the above discussion. Assume that ")#mi("{0 < \\theta < 1}")#text(". If ")#mi("{w}")#text(" goes to infinity at a sufficiently slow rate at ")#mi("{x \\rightarrow \\infty}")#text(", establish the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\nu(n) = \\left( \\frac{W}{\\phi(W)} \\right)^k \\frac{x}{2W\\log^k R} (I(f) + o(1))")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(", where")

#align(center)[#tao-fit-display[#mitex("I(f) := \\int_{[0,+\\infty)^k} f_{1,\\dots,k}(t_1,\\dots,t_k)^2\\ dt_1 \\dots dt_k")]]

#text("and ")#mi("{f_{1,\\dots,k}}")#text(" denotes the mixed partial derivative ")#mi("{\\frac{\\partial^k f}{\\partial t_1 \\dots \\partial t_k}}")#text(" in each of the ")#mi("{k}")#text(" variables ")#mi("{t_1,\\dots,t_k}")#text(".")
]

#text("Now we consider a term on the left-hand side, say ")#mi("{\\sum_n \\nu(n) 1_{n+h_k \\text{ prime}}}")#text(". When ")#mi("{n+h_k}")#text(" is prime, the quantity ")#mi("{d_k}")#text(" in ")#link(<tao-317cea04b3172ab7f18b>)[#text("(46)")]#text(" is necessarily ")#mi("{1}")#text(", so ")#link(<tao-317cea04b3172ab7f18b>)[#text("(46)")]#text(" simplifies to a ")#mi("{k-1}")#text("-dimensional version of itself:")

#align(center)[#tao-fit-display[#mitex("\\nu(n) = 1_{n=b\\ (W)} 1_{[x/2,x]}(n) \\times")]]

#align(center)[#tao-fit-display[#mitex("\\left( \\sum_{d_i | n+h_i \\forall i=1,\\dots,k-1} \\mu(d_1) \\dots \\mu(d_{k-1}) f( \\frac{\\log d_1}{\\log R}, \\dots, \\frac{\\log d_{k-1}}{\\log R}, 0 ) \\right)^2.")]]

#text("If ")#mi("{\\theta < \\frac{1}{2}}")#text(", one can control the effect of the weight ")#mi("{1_{n+h_k \\text{ prime}}}")#text(" using the Bombieri-Vinogradov theorem, and after some moderately complicated calculations one obtains")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 41")]#text(" ")#metadata(none) <tao-3f1b82e16a820ed80c98>#text(" Let ")#mi("{k, h_1,\\dots,h_k, b, W, \\theta, R, f, \\nu}")#text(" be as in the above discussion. Assume that ")#mi("{0 < \\theta < 1/2}")#text(". If ")#mi("{w}")#text(" goes to infinity at a sufficiently slow rate at ")#mi("{x \\rightarrow \\infty}")#text(", establish the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\nu(n) 1_{n+h_k \\in {\\mathcal P}} = \\left( \\frac{W}{\\phi(W)} \\right)^k \\frac{x}{2W\\log^{k-1} R \\log x} (J_k(f) + o(1))")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(", where")

#align(center)[#tao-fit-display[#mitex("J_k(f) := \\int_{[0,+\\infty)^{k-1}} f_{1,\\dots,k-1}(t_1,\\dots,t_{k-1},0)^2\\ dt_1 \\dots dt_{k-1}")]]

#text("and ")#mi("{f_{1,\\dots,k-1}}")#text(" denotes the mixed partial derivative ")#mi("{\\frac{\\partial^{k-1} f}{\\partial t_1 \\dots \\partial t_{k-1}}}")#text(" in the ")#mi("{k-1}")#text(" variables ")#mi("{t_1,\\dots,t_{k-1}}")#text(". Similarly for permutations of the ")#mi("{1,\\dots,k}")#text(" indices.")
]

#text("In view of these two calculations, one can establish Maynard’s theorem as soon as one can find ")#mi("{k}")#text(" and ")#mi("{f}")#text(" for which")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^k J_i(f) > \\frac{m}{\\theta/2} I(f)")]]

#text("where ")#mi("{J_i}")#text(" is defined similarly to ")#mi("{J_k}")#text(" but with the role of the ")#mi("{i}")#text(" and ")#mi("{k}")#text(" indices swapped. This is now a problem purely in calculus of variations rather than number theory. It is thus natural to take ")#mi("{\\theta}")#text(" close to ")#mi("{1/2}")#text(" (though, for the qualitative analysis performed here, actually any non-zero choice of ")#mi("{\\theta}")#text(" independent of ")#mi("{k}")#text(" will suffice). Our task is now to find ")#mi("{k,f}")#text(" with")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^k J_i(f) > 4 m I(f).")]]

#text("The optimal choice of ")#mi("{f}")#text(" for a given ")#mi("{k}")#text(" is not known for any ")#mi("{k>2}")#text(", but one can generate a “good enough” choice of ")#mi("{f}")#text(" by the following set of calculations. Firstly, we restrict to the case when ")#mi("{f(t_1,\\dots,t_k)}")#text(" is symmetric in the ")#mi("{t_1,\\dots,t_k}")#text(", so that all the ")#mi("{J_i}")#text(" are equal and our objective is now to satisfy the inequality")

#align(center)[#tao-fit-display[#mitex("kJ_k(f) > 4 m I(f).")]]

#text("Next, we make the change of variables ")#mi("{F := f_{1,\\dots,k}}")#text(", thus ")#mi("{F}")#text(" is smooth on ")#mi("{[0,+\\infty)^k}")#text(" and supported on the simplex ")#mi("{\\{t_1+\\dots+t_k \\leq 1\\}}")#text(" but is otherwise arbitrary on this simplex. From the fundamental theorem of calculus, the desired inequality now becomes")

#align(center)[#tao-fit-display[#mitex("k \\int_{[0,+\\infty)^{k-1}} (\\int_0^\\infty F(t_1,\\dots,t_k)\\ dt_k)^2 dt_1 \\dots dt_{k-1}")]]

#align(center)[#tao-fit-display[#mitex("> 4m \\int_{[0,+\\infty)^k} F(t_1,\\dots,t_k)^2\\ dt_1 \\dots t_k.")]]

#text("We select a function ")#mi("{F}")#text(" of the truncated product form")

#align(center)[#tao-fit-display[#mitex("F(t_1,\\dots,t_k) = k^{1/2} g(k t_1) \\dots k^{1/2} g(k t_k) 1_{t_1 + \\dots +t_k < 1}")]]

#text("where ")#mi("{g: [0,+\\infty) \\rightarrow {\\bf R}^+}")#text(" is a smooth non-negative function normalised so that ")#metadata(none) <tao-d137d43ec26cc59943b3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(47)")])
#mitex("\\int_0^\\infty g(t)^2\\ dt = 1")]]

#text("so that")

#align(center)[#tao-fit-display[#mitex("\\int_{[0,+\\infty)^k} F(t_1,\\dots,t_k)^2\\ dt_1 \\dots t_k \\leq 1")]]

#text("and our objective (after a rescaling) is now to get")

#align(center)[#tao-fit-display[#mitex("\\int_{[0,+\\infty)^{k-1}} \\left(\\int_0^\\infty g(t_k) 1_{t_1+\\dots+t_k \\leq k}\\ dt_k\\right)^2 g(t_1)^2 dt_1 \\dots g(t_{k-1})^2 dt_{k-1}")]]

#align(center)[#tao-fit-display[#mitex("> 4m.")]]

#text("The emergence of the function ")#mi("{g}")#text(" as a parameter in the multidimensional sieve is a feature that is not present in previous sieves (at least not without sharply curtailing the support of ")#mi("{g}")#text("), and is the main reason why this sieve performs better than previous sieves for this problem.")

#text("We interpret the above optimisation problem probabilistically. Let ")#mi("{X_1,X_2,\\dots}")#text(" be independent real values in ")#mi("{[0,+\\infty)}")#text(" with probability density function ")#mi("{g(t)^2\\ dt}")#text(". Our task is now to obtain the inequality")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\left(\\int_0^{\\min(k-X_1-\\dots-X_k),0} g(t_k)\\ dt_k\\right)^2 > 4m.")]]

#text("Suppose that we can locate a fixed function ")#mi("{g}")#text(" (independent of ")#mi("{k}")#text(") obeying ")#link(<tao-d137d43ec26cc59943b3>)[#text("(47)")]#text(" with ")#metadata(none) <tao-5787e14b58a2a229b1b6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(48)")])
#mitex("\\mathop{\\bf E} X_i = \\int_0^\\infty t g(t)^2\\ dt < 1")]]

#text("and ")#metadata(none) <tao-ff482e15f3661af2ae27>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(49)")])
#mitex("\\int_0^\\infty g(t)\\ dt = \\infty")]]

#text("Then from the law of large numbers, ")#mi("{k-X_1-\\dots-X_k}")#text(" goes to infinity almost surely as ")#mi("{k}")#text(" to ")#mi("{\\infty}")#text(", and so from dominated convergence one has")

#align(center)[#tao-fit-display[#mitex("\\lim_{k \\rightarrow \\infty} \\mathop{\\bf E} (\\int_0^{\\min(k-X_1-\\dots-X_k),0} g(t_k)\\ dt_k)^2 = \\infty")]]

#text("and the claim follows from ")#link(<tao-ff482e15f3661af2ae27>)[#text("(49)")]#text(" if ")#mi("{k}")#text(" is sufficiently large depending on ")#mi("{m}")#text(".")

#text("We are thus reduced to the easy one-dimensional problem of producing a smooth function ")#mi("{g: [0,+\\infty) \\rightarrow {\\bf R}}")#text(" obeying the constraints ")#link(<tao-d137d43ec26cc59943b3>)[#text("(47)")]#text(", ")#link(<tao-5787e14b58a2a229b1b6>)[#text("(48)")]#text(", ")#link(<tao-ff482e15f3661af2ae27>)[#text("(49)")]#text(". However, one can verify that the choice")

#align(center)[#tao-fit-display[#mitex("g(t) := \\frac{1}{(1+t) \\log(2+t)}")]]

#text("(barely) obeys ")#link(<tao-ff482e15f3661af2ae27>)[#text("(49)")]#text(" with ")#mi("{\\int_0^\\infty g(t)^2\\ dt}")#text(" and ")#mi("{\\int_0^\\infty t g(t)^2\\ dt}")#text(" both finite, and the claim follows by a routine rescaling.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42")]#text(" By working through a more quantitative version of the above argument, establish Theorem ")#link(<tao-ee4d988c65de860fabbf>)[#text("38")]#text(" with ")#mi("{m \\gg \\log k}")#text(" as ")#mi("{k \\rightarrow \\infty}")#text(". (")#emph[#text("Hint:")]#text(" One can replace the use of the law of large numbers with Chebyshev’s inequality.) It is not currently known how to obtain this theorem with any choice of ")#mi("{m}")#text(" that grows faster than logarithmically in ")#mi("{k}")#text("; the current record is ")#mi("{m = (\\frac{1}{4} + \\frac{7}{600}) \\log k + O(1)}")#text(", ")#link("http://www.resmathsci.com/content/1/1/12")[#text("due to the Polymath project")]#text(". It is known, though, that bounds on the order of ")#mi("{\\log k}")#text(" are the limit of the Selberg sieve method, and one either needs new sieves, or new techniques beyond sieve theory, to increase ")#mi("{m}")#text(" beyond this rate; see ")#link("http://www.resmathsci.com/content/1/1/12")[#text("the Polymath paper")]#text(" for further discussion.")
]

#text("One can use the multidimensional sieve to study the classical sieving problem of counting prime ")#mi("{k}")#text("-tuples, but unfortunately the numerology it gives is precisely the same as the numerology given by previous sieves:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 43")]#text(" Let ")#mi("{(h_1,\\dots,h_k)}")#text(" be an admissible tuple, and let ")#mi("{w}")#text(" go to infinity sufficiently slowly as ")#mi("{x \\rightarrow \\infty}")#text(".")

#list(
[#text("(i) Use Exercise ")#link(<tao-f71854425943c68be20e>)[#text("40")]#text(", followed by an optimisation of the function ")#mi("{f}")#text(" (or ")#mi("{F}")#text(") to establish the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{x/2 \\leq n \\leq x: n = b\\ (W); n+h_1,\\dots,n+h_k \\in {\\mathcal P}\\}\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\leq (2^k k! + o(1)) \\left( \\frac{W}{\\phi(W)}\\right)^k \\frac{x}{2W\\log^k x}")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(", uniformly for all ")#mi("{b\\ (W)}")#text(" with ")#mi("{b+h_1, \\dots, b+h_k\\ (W)}")#text(" primitive. Use this to give an alternate proof of ")#link(<tao-bcee72e6df5d56319125>)[#text("(39)")]#text(".")],
[#text("(ii) By using Exercise ")#link(<tao-3f1b82e16a820ed80c98>)[#text("41")]#text(" instead of Exercise ")#link(<tao-f71854425943c68be20e>)[#text("40")]#text(", repeat (i) but with ")#mi("{2^k k!}")#text(" replaced by ")#mi("{4^{k-1} (k-1)!}")#text(".")]
)
]

#heading(level: 1)[#strong[#text(" — 4. The large sieve — ")]]

#text("In the general discussion of sieving problems such as Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(" in previous sections, there was no structure imposed on the sets ")#mi("{E_p}")#text(" beyond the fact that one could control the sums ")#link(<tao-61205ff0d3a9688d0959>)[#text("(9)")]#text(". However, as we have seen in practice, ")#mi("{E_p}")#text(" is typically the union of some number ")#mi("{\\omega(p)}")#text(" of residue classes modulo ")#mi("{p}")#text(". It is possible to exploit this structure using Fourier analysis, leading to an approach to sieving known as the ")#emph[#text("large sieve")]#text(", and relying crucially on the analytic large sieve inequality from ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("Notes 3")]#text(". The large sieve tends to give results similar to that of the Selberg sieve; indeed, the two sieves are in some sense “dual” to each other and are powered by the same sort of ")#mi("{L^2}")#text("-based techniques (such as the Cauchy-Schwarz inequality). However, the large sieve methods can offer sharper control on error terms than the Selberg sieve if carried out carefully. As the name suggests, the large sieve is particularly useful in the regime when the number of residue classes modulo ")#mi("{p}")#text(" being sieved out is large, for instance as large as a constant multiple of ")#mi("{p}")#text(". (When ")#mi("{\\omega(p)}")#text(" is ")#emph[#text("very large")]#text(" – close to ")#mi("{p}")#text(", then there is another sieve that gives even sharper results, namely the ")#link("http://www.ams.org/mathscinet-getitem?mr=291120")[#text("larger sieve")]#text(" of Gallagher, which we do not discuss further here.)")

#text("To apply the analytic large sieve to sieving problems, we need to exploit an “uncertainty principle” ")#link("http://www.ams.org/mathscinet-getitem?mr=224585")[#text("of Montgomery")]#text(" (discussed further in ")#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/")[#text("this previous blog post")]#text("), that shows that functions which avoid certain residue classes in the physical domain are necessarily spread out in the frequency domain. More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 44 (Montgomery uncertainty principle)")]#text(" ")#metadata(none) <tao-73f269601fe15bc39760>#text(" Let ")#mi("{f: {\\bf Z} \\rightarrow {\\bf C}}")#text(" be a finitely supported function, and let ")#mi("{\\hat f: {\\bf R}/{\\bf Z} \\rightarrow {\\bf C}}")#text(" be the Fourier transform ")#mi("{\\hat f(\\theta) := \\sum_n f(n) e(n\\theta)}")#text(", where ")#mi("{e(x) := e^{2\\pi i x}}")#text(". Suppose that for each prime ")#mi("{p}")#text(", there are ")#mi("{\\omega(p)}")#text(" residue classes modulo ")#mi("{p}")#text(" on which ")#mi("{f}")#text(" vanishes identically for some ")#mi("{\\omega(p) < p}")#text(". Then for any ")#mi("{\\theta \\in {\\bf R}/{\\bf Z}}")#text(" and any natural number ")#mi("{q}")#text(", one has ")#metadata(none) <tao-a95bc16631ae2b6fadb4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(50)")])
#tao-math("\\sum_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\hat f(\\theta + \\frac{a}{q})\\right|^2 \\geq h(q) \\left|\\hat f(\\theta)\\right|^2,", block: true)]]

#text("where ")#mi("{h}")#text(" is the multiplicative function ")#metadata(none) <tao-374d1e75d9b32114b582>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(51)")])
#mitex("h(q) := \\mu^2(q) \\prod_{p|q} \\frac{\\omega(p)}{p-\\omega(p)}.")]]
]

#emph[#text("Proof:")]#text(" We may assume that ")#mi("{q}")#text(" is squarefree, since otherwise we have ")#mi("{h(q)=0}")#text(" and the claim ")#link(<tao-a95bc16631ae2b6fadb4>)[#text("(50)")]#text(" is trivial. Observe from the Chinese remainder theorem that if the inequality ")#link(<tao-a95bc16631ae2b6fadb4>)[#text("(50)")]#text(" holds for two coprime values ")#mi("{q=q_1, q=q_2}")#text(" of ")#mi("{q}")#text(", then it also holds for ")#mi("{q=q_1q_2}")#text(" (as every fraction ")#mi("{\\frac{a}{q_1 q_2}}")#text(" in ")#mi("{{\\bf R}/{\\bf Z}}")#text(" with ")#mi("{(a,q_1q_2)=1}")#text(" can be uniquely written as ")#mi("{\\frac{a_1}{q_1} + \\frac{a_2}{q_2}}")#text(" with ")#mi("{(a_1,q_1)=(a_2,q_2)=1}")#text("). Thus it suffices to verify the claim when ")#mi("{q}")#text(" is prime. By multiplying ")#mi("{f(n)}")#text(" by ")#mi("{e(-n\\theta)}")#text(" we can also reduce to the case ")#mi("{\\theta=0}")#text(", thus our task is now to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{a \\in ({\\bf Z}/p{\\bf Z}) \\backslash \\{0\\}} \\left|\\hat f(\\frac{a}{p})\\right|^2 \\geq \\frac{\\omega(p)}{p-\\omega(p)} \\left|\\hat f(0)\\right|^2", block: true)]]

#text("or equivalently")

#align(center)[#tao-fit-display[#tao-math("\\sum_{a \\in {\\bf Z}/p{\\bf Z}} \\left|\\hat f(\\frac{a}{p})\\right|^2 \\geq \\frac{p}{p-\\omega(p)} \\left|\\hat f(0)\\right|^2.", block: true)]]

#text("By the Plancherel identity in ")#mi("{{\\bf Z}/p{\\bf Z}}")#text(", the left-hand side can be written as")

#align(center)[#tao-fit-display[#tao-math("p \\sum_{b \\in {\\bf Z}/p{\\bf Z}} \\left|\\sum_{n = b\\ (p)} f(n)\\right|^2", block: true)]]

#text("and the right-hand side is")

#align(center)[#tao-fit-display[#tao-math("\\frac{p}{p-\\omega(p)} \\left|\\sum_{b \\in {\\bf Z}/p{\\bf Z}} \\sum_{n = b\\ (p)} f(n)\\right|^2.", block: true)]]

#text("Since the sum ")#mi("{\\sum_{n = b\\ (p)} f(n)}")#text(" is only non-vanishing for at most ")#mi("{p-\\omega(p)}")#text(" choices of ")#mi("{b}")#text(", the claim follows from the Cauchy-Schwarz inequality. ")#mi("\\Box")

#text("We then obtain the following variant of Theorem ")#link(<tao-cb46c56f0f6ec1fcfe92>)[#text("32")]#text(" or Theorem ")#link(<tao-19147f7d7f268da443a0>)[#text("30")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 45 (Arithmetic large sieve)")]#text(" ")#metadata(none) <tao-f5e50a9291efaed32843>#text(" Let ")#mi("{Q \\geq 1}")#text(". For each prime number ")#mi("{p \\leq Q}")#text(", let ")#mi("{E_p}")#text(" be the union of ")#mi("{\\omega(p)}")#text(" residue classes modulo ")#mi("{p}")#text(", where ")#mi("{\\omega(p) < p}")#text(" for all ")#mi("{p}")#text(". Then for any ")#mi("{M \\in {\\bf Z}}")#text(" and natural number ")#mi("{N \\geq 1}")#text(", we have ")#metadata(none) <tao-35124fc4a6606af46bd5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(52)")])
#tao-math("\\left|\\{ n \\in {\\bf Z}: M < n \\leq M+N\\} \\backslash \\bigcup_{p \\leq Q} E_p\\right| \\ll \\frac{N+Q^2}{J}", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("J := \\sum_{q \\leq Q} h(q)")]]

#text("and ")#mi("{h}")#text(" is given by ")#link(<tao-374d1e75d9b32114b582>)[#text("(51)")]#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{f}")#text(" be the indicator function of the set in ")#link(<tao-35124fc4a6606af46bd5>)[#text("(52)")]#text(". From Theorem ")#link(<tao-73f269601fe15bc39760>)[#text("44")]#text(" with ")#mi("{\\theta=0}")#text(", and ")#mi("{q}")#text(" summed up to ")#mi("{Q}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\leq Q} \\sum_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\hat f(\\frac{a}{q})\\right|^2 \\geq J \\left|\\hat f(0)\\right|^2.", block: true)]]

#text("Now observe from the basic identity")

#align(center)[#tao-fit-display[#mitex("\\frac{a_1}{q_1} - \\frac{a_2}{q_2} = \\frac{a_1 q_2 - a_2 q_1}{q_1 q_2}")]]

#text("that the ")#link("http://en.wikipedia.org/wiki/Farey_sequence")[#text("Farey sequence")]#text(" ")#mi("{\\{ \\frac{a}{q}: q \\leq Q; a \\in ({\\bf Z}/q{\\bf Z})^\\times\\}}")#text(" is ")#mi("{\\frac{1}{Q^2}}")#text("-separated in ")#mi("{{\\bf R}/{\\bf Z}}")#text(". We may thus invoke the analytic large sieve inequality (see Proposition 6 of ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("Notes 3")]#text(") to conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\leq Q} \\sum_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\hat f(\\frac{a}{q})\\right|^2 \\ll (N + Q^2) \\sum_n \\left|f(n)\\right|^2.", block: true)]]

#text("But from construction of ")#mi("{n}")#text(", the left-hand side of ")#link(<tao-35124fc4a6606af46bd5>)[#text("(52)")]#text(" is equal to both ")#tao-math("{\\sum_n \\left|f(n)\\right|^2}", block: false)#text(" and ")#mi("{\\hat f(0)}")#text(", and the claim follows. ")#mi("\\Box")

#text("Note that if one uses the sharp form of the large sieve inequality (Remark 7 from ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("Notes 3")]#text(") then one can sharpen ")#link(<tao-35124fc4a6606af46bd5>)[#text("(52)")]#text(" to")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ n \\in {\\bf Z}: M < n \\leq M+N\\} \\backslash \\bigcup_{p \\leq Q} E_p\\right| \\leq \\frac{N+Q^2}{J}.", block: true)]]

#text("Setting ")#mi("{Q = N^{1/2-\\varepsilon}}")#text(", one can then recover sharper versions of Theorem ")#link(<tao-cb46c56f0f6ec1fcfe92>)[#text("32")]#text(" and its consequences, for instance by working along these lines (and using a very sharp version of the analytic large sieve inequality that exploits the variable spacing of the set of fractions ")#mi("{\\frac{a}{q}}")#text("), ")#link("http://www.ams.org/mathscinet-getitem?mr=374060")[#text("result of Montgomery and Vaughan")]#text(" were able to completely delete the error term in the Brun-Titchmarsh inequality (Exercise ")#link(<tao-45d3346fa1b23665571f>)[#text("33")]#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 46")]#text(" It is a general phenomenon that large sieve methods tend to give the same main term as the Selberg sieve; see ")#link("http://www.ams.org/mathscinet-getitem?mr=2647984")[#text("Section 9.5 of Friedlander-Iwaniec")]#text(" for further discussion.")
]

#heading(level: 1)[#strong[#text(" — 5. The parity problem — ")]]

#text("We have seen that sieve theoretic techniques are reasonably good at obtaining upper bounds to various sieving problems, and can also provide lower bounds if the sifting limit is low. However, these methods have proven to be frustratingly ineffective at providing non-trivial lower bounds for the original problems that motivated the development of sieve theory in the first place, namely counting patterns of primes such as twin primes. While we do not fully understand the exact limitations of what sieve theory can and cannot do, we do have a convincing heuristic barrier, known as the ")#link("http://en.wikipedia.org/wiki/Parity_problem_%28sieve_theory%29")[#text("parity barrier")]#text(" or ")#emph[#text("parity problem")]#text(" and first raised explicitly ")#link("http://www.ams.org/mathscinet-getitem?mr=53147")[#text("by Selberg")]#text(", which explains why sieves have so much difficulty in lower bounding (or efficiently upper bounding) counts involving primes; in particular they explain why sieve-theoretic methods have thus far been unable to fully resolve any of the four Landau problems. The barrier is not completely rigorous, as it relies on the ")#emph[#text("Möbius pseudorandomness principle")]#text(" (or ")#emph[#text("Liouville pseudorandomness principle")]#text(") discussed in Section 2 of ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text(". As such, our discussion in this section will be somewhat informal in nature; for instance, we will use vague symbols such as ")#mi("{\\approx}")#text(" without defining their meaning precisely.")

#text("Consider the general sieving problem in Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(", in which one tries to control the quantity ")#mi("{\\sum_{n \\not \\in \\bigcup_{p|P} E_p} a_n}")#text(" via knowledge of the sums ")#mi("{\\sum_{n \\in E_d} a_n}")#text(", together with the hypothesis that the ")#mi("{a_n}")#text(" are non-negative. In most situations, one expects this problem to be ")#emph[#text("underdetermined")]#text("; in particular, there will probably exist two different finitely supported sequences ")#mi("{(a_n)_{n \\in {\\bf Z}}}")#text(", ")#mi("{(b_n)_{n \\in {\\bf Z}}}")#text(" of non-negative reals which are essentially indistinguishable with regards to the inputs of this sieve problem, in the sense that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in E_d} a_n \\approx \\sum_{n \\in E_d} b_n \\approx X_d")]]

#text("for all ")#mi("{d \\in {\\mathcal D}}")#text(", but which have very different outputs for this sieve problem, in that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\not \\in \\bigcup_{p|P} E_p} a_n \\not \\approx \\sum_{n \\not \\in \\bigcup_{p|P} E_p} b_n .")]]

#text("Then any upper bound for Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(" with this choice of ")#mi("{E_d, X_d, {\\mathcal D}, P}")#text(" must exceed (at least approximately) the greater of ")#mi("{\\sum_{n \\not \\in \\bigcup_{p|P} E_p} a_n}")#text(" and ")#mi("{\\sum_{n \\not \\in \\bigcup_{p|P} E_p} b_n}")#text("; similarly, any lower bound for this problem must be (approximately) less than the lesser of ")#mi("{\\sum_{n \\not \\in \\bigcup_{p|P} E_p} a_n}")#text(" and ")#mi("{\\sum_{n \\not \\in \\bigcup_{p|P} E_p} b_n}")#text(".")

#text("As a special case of this observation, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 47 (Abstract parity barrier)")]#text(" ")#metadata(none) <tao-a6ee84408708e51150a6>#text(" (Informal) Let ")#mi("{E_d, X_d, {\\mathcal D}, P}")#text(" be as in Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(". Let ")#mi("{(a_n)_{n \\in {\\bf Z}}}")#text(" be a finitely supported sequence of non-negative reals such that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in E_d} a_n \\approx X_d")]]

#text("for all ")#mi("{d \\in {\\mathcal D}}")#text(". Suppose that we have an additional “parity function” ")#mi("{\\omega: {\\bf Z} \\rightarrow \\{-1,0,+1\\}}")#text(" with the property that")

#align(center)[#tao-fit-display[#mitex("\\omega(n) = -1")]]

#text("for all ")#mi("{n \\not \\in \\bigcup_{p|P} E_p}")#text(" in the support of ")#mi("{a_n}")#text(", but such that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\in E_d} a_n \\omega(n) \\approx 0")]]

#text("for all ")#mi("{d \\in {\\mathcal D}}")#text(". Then any upper bound for Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(" cannot be significantly smaller than ")#mi("{2 \\sum_{n \\not \\in \\bigcup_{p|P} E_p} a_n}")#text(", and any lower bound for Problem ")#link(<tao-393b668e2d7b1702441b>)[#text("3")]#text(" cannot be significantly larger than zero. In particular, one does not expect to be able to show using such sieve methods that the support of ")#mi("{a_n}")#text(" contains any appreciable number of elements outside of ")#mi("{\\bigcup_{p|P} E_p}")#text(".")
]

#emph[#text("Proof:")]#text(" (Non-rigorous!) For the statement about the upper bound, apply the previous discussion to the sequence ")#mi("{b_n := a_n (1 - \\omega(n))}")#text(". For the statement about the lower bound, apply the previous discussion to the sequence ")#mi("{b(n) := a_n (1+\\omega(n))}")#text(". ")#mi("\\Box")

#text("Informally, the proposition asserts that if the sifted set ")#mi("{{\\bf Z} \\backslash \\bigcup_{p|P} E_p}")#text(" is sensitive to the parity function ")#mi("{\\omega}")#text(", but original pre-sifted sequence ")#mi("{a_n}")#text(" and the sets ")#mi("{E_d}")#text(" are not, then traditional sieve methods cannot give any non-trivial lower bounds, and any upper bounds must be off from the truth by a factor of at least two.")

#text("In practice, one can heuristically obey the hypotheses of this proposition if one takes ")#mi("{\\omega(n)}")#text(" to be some variant of the ")#link("http://en.wikipedia.org/wiki/Liouville_function")[#text("Liouville function")]#text(" ")#mi("{\\lambda(n)}")#text(", which counts the parity of the number of prime factors of ")#mi("{n}")#text(", in which case the parity problem asserts (roughly speaking) that the sifting problem must allow both numbers with an even number of prime factors and numbers with an odd number of prime factors to survive if one is to have any hope of good lower bounds. For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 48 (Parity barrier for twin primes)")]#text(" (Very informal) One cannot use traditional sieve methods to resolve the twin prime conjecture.")
]

#emph[#text("Proof:")]#text(" (Very non-rigorous! Also assumes Liouville pseudorandomness) As mentioned in the introduction, there are a number of different ways to try to approach the twin prime conjecture by sieve methods. Consider for instance the approach in which one starts with the primes ")#mi("{A}")#text(" in ")#mi("{[x/2+2,x]}")#text(" and removes the residue class ")#mi("{E_p = 2\\ (p)}")#text(" for each ")#mi("{p \\leq \\sqrt{x}}")#text(". The quantity ")#mi("{\\lambda(n+2)}")#text(" will then be ")#mi("{-1}")#text(" on the sifted set ")#mi("{A \\backslash \\bigcup_{p|P} E_p}")#text(" (since ")#mi("{n+2}")#text(" will be prime on that set), while the Liouville pseudorandomness heuristic predicts that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in E_d} 1_A(n) \\lambda(n+2) = \\sum_{x/2+2 \\leq n \\leq x: n = 2\\ (d)} 1_{\\mathcal P}(n) \\lambda(n+2)")]]

#text("is negligible for all ")#mi("{d \\leq x}")#text(" (say). The claim then follows from Proposition ")#link(<tao-a6ee84408708e51150a6>)[#text("47")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 49")]#text(" (Informal) Develop similar parity obstructions for the other sieve-theoretic approaches to the twin prime conjecture. In the case when one is sieving out the integers by two residue classes ")#mi("{0, -2\\ (p)}")#text(" for each prime ")#mi("{p}")#text(", argue that any sieve-theoretic bound must in fact be off from the truth by a factor of at least ")#emph[#text("four")]#text(". (")#emph[#text("Hint:")]#text(" experiment with weights such as ")#mi("{(1 - \\lambda(n)) (1-\\lambda(n+2))}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 50")]#text(" (Informal) Argue why any sieve-theoretic upper bound on prime ")#mi("{k}")#text("-tuples that is based on equidistribution estimates for the natural numbers and primes must be off from the truth by a factor of at least ")#mi("{2^{k-1}}")#text(". (This should be compared with the known upper bounds of ")#mi("{2^k k!}")#text(" and ")#mi("{4^{k-1} (k-1)!}")#text(" discussed in previous sections. It is not clear at present which of these bounds is closest to the true limit of sieve theory.)")
]

#text("The above argument is far from watertight, and there have been successful attempts to circumvent the parity barrier. For instance:")

#list(
[#text("(i) The parity barrier does not prohibit the possibility of producing a very small number of prime (or near-prime) patterns, even if one cannot hope to get lower bounds that are of the “right” order of magnitude. For instance, it was shown unconditionally ")#link("http://www.ams.org/mathscinet-getitem?mr=2806510")[#text("by Goldston, Graham, Pintz, and Yildirim")]#text(" that there exist infinitely many pairs of consecutive numbers ")#mi("{n,n+1}")#text(", each of which are the product of exactly four primes. Cramér type random models (see ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text(") predict the number of such pairs up to ")#mi("{x}")#text(" to be approximately ")#mi("{\\frac{x}{\\log^2 x}}")#text(" (ignoring some factors of ")#mi("{\\log\\log x}")#text("), and the parity barrier prevents one from getting lower bounds of this magnitude; but the construction of Goldston, Graham, Pintz, and Yildirim only produces a quite sparse set of pairs (about ")#mi("{\\frac{x}{\\log^3 x}}")#text(" or so) and so evades the parity barrier. Using a very different class of arguments, it is also possible to produce analogues of patterns like twin primes in the function field setting (in which the role of primes are replaced by irreducible polynomials over a finite field) by using very sparse sequences of polynomials for which irreducibility can be tested easily; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=2228953")[#text("this paper of Hall")]#text(" for the case of twin irreducible polynomials.")],
[#text("(ii) The parity barrier may disappear if one is somehow in a situation in which the Möbius or Liouville pseudorandomness principles break down. An extreme example of this is when one assumes the existence of one (or many) ")#emph[#text("Siegel zeroes")]#text(", which imply extremely high correlation between the Möbius or Liouville functions and a Dirichlet character, in strong violation of the pseudorandomness principle. A striking example of this case occurs in ")#link("http://www.ams.org/mathscinet-getitem?mr=703977")[#text("this paper of Heath-Brown")]#text(", which demonstrates the truth of the twin prime conjecture if one assumes the existence of an infinite sequence of Siegel zeroes.")],
[#text("(iii) Traditional sieve theoretic methods only assume that one can control “linear” or “Type I” sums of the form ")#mi("{\\sum_{n \\in E_d} a_n}")#text(". However, in some cases it is also possible to control “bilinear” or “Type II” sums such as ")#mi("{\\sum_n \\sum_m \\alpha_n \\beta_m a_{nm}}")#text(" for various coefficients ")#mi("{\\alpha_n, \\beta_m}")#text(" of controlled size and support but uncontrolled phase. Note that multiplicative parity functions such as ")#mi("{\\lambda}")#text(" will be distinguishable with such sums, since ")#mi("{\\sum_n \\sum_m \\alpha_n \\beta_m \\lambda(nm)}")#text(" will not exhibit any cancellation if ")#mi("{\\alpha_n, \\beta_m}")#text(" both oscillate with the sign of ")#mi("{\\lambda(n), \\lambda(m)}")#text(" respectively; as such, the parity barrier is no longer in effect. In such situations it can be possible to go beyond the limits of traditional sieve theory, for instance by using decompositions similar to the Vaughan identity employed in ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("Notes 3")]#text(". Of course, one still has to actually establish the required bilinear sum asymptotics, and this typically requires some deep and non-trivial input outside of sieve theory. A model example here is ")#link("http://www.ams.org/mathscinet-getitem?mr=1432648")[#text("the work of Friedlander and Iwaniec")]#text(" establishing the infinitude of primes of the form ")#mi("{a^2+b^4}")#text(". Here, the relevant bilinear input is obtained using the algebraic structure of the Gaussian integers and some non-trivial results on lattice counting problems.")],
[#text("(iv) Sieve theory is focused on “one-dimensional” sums, such as ")#mi("{\\sum_{n \\not \\in \\bigcup_{p|P} E_p} a_n}")#text(", or perhaps ")#mi("{\\sum_{n \\leq x} \\Lambda(n) \\Lambda(n+2)}")#text(". The presence of the parity problem relies on the ability to modify weights such as ")#mi("{a_n}")#text(" or ")#mi("{\\Lambda(n)}")#text(" in such sums in such a fashion that the value of the sum dramatically changes. If one instead is trying to control a ")#emph[#text("multi-dimensional")]#text(" sum, such as ")#mi("{\\sum_{n,r \\leq x} \\Lambda(n) \\Lambda(n+r) \\Lambda(n+2r) \\Lambda(n+3r)}")#text(" (which roughly speaking counts arithmetic progressions of primes of length four), then there is no easy way to modify any of the factors of such a sum in the fashion required for the parity barrier to be in effect. For such multi-dimensional sums one can then hope to use additional estimates to produce non-trivial lower bounds. For instance, ")#link("http://www.ams.org/mathscinet-getitem?mr=2415379")[#text("with Ben Green, we used")]#text(" Selberg sieves combined with the additional tool of ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("Szemerédi’s theorem")]#text(" to obtain lower bounds for multi-dimensional sums similar to the one above, proving in particular that the primes contained arbitrarily long arithmetic progressions.")]
)

#text("It is one of the major problems in analytic prime number theory to continue to find more ways to defeat the parity barrier, so that we can produce prime patterns in many more situations than what is currently possible. However, this has proven to be a surprisingly challenging task, and one which typically requires the injection of new ideas and methods external to sieve theory.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 51")]#text(" As mentioned previously, it is not known in general if the parity problem represents the ")#emph[#text("only")]#text(" obstruction to sieve methods. However, under the additional hypothesis of the Elliott-Halberstam conjecture, and when focusing on “binary” problems such as the twin prime conjecture, there is a more detailed analysis of the parity problem ")#link("http://www.ams.org/mathscinet-getitem?mr=491570")[#text("due to Bombieri")]#text(" which indicates that, in some sense, the parity problem ")#emph[#text("is")]#text(" indeed the only information not captured by sieve-theoretic methods, in that the asymptotic distribution of primes or almost primes in pairs ")#mi("{n,n+2}")#text(" is completely determined by a single parameter ")#mi("{0 \\leq \\delta \\leq 2}")#text(" that represents the ratio between the actual number of twin primes and the expected number of twin primes; the parity problem prevents us from obtaining any further information about ")#mi("{\\delta}")#text(" other than that it lies between ")#mi("{0}")#text(" and ")#mi("{2}")#text(", but once ")#mi("{\\delta}")#text(" is known, essentially all other asymptotics regarding the prime factorisation of ")#mi("{n}")#text(" and ")#mi("{n+2}")#text(" will also be known. See Chapter 16 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2647984")[#text("Friedlander-Iwaniec")]#text(" for further discussion.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 52")]#text(" For a slightly different way to formalise the parity problem, see ")#link("https://terrytao.wordpress.com/2014/11/21/a-general-parity-problem-obstruction/")[#text("this previous blog post")]#text(". Among other things, it is shown in that post that the parity problem prevents one from proving Theorem ")#link(<tao-ee4d988c65de860fabbf>)[#text("38")]#text(" with any choice of ")#mi("{m,k}")#text(" with ")#mi("{m > \\lceil \\frac{k}{2} \\rceil}")#text(" using purely sieve-theoretic methods, in particular ruling out a solution to the twin prime conjecture by sieve methods.")
]

#heading(level: 1)[#text("Comments (41)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-450573")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2015")])]

#text("Remark 46 — missing reference?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbc18fa1121b8fa9882913bae34c8ee95f5625eeca6286b1a2ad23ba28677eac-4b48c0ccfb856201ce86b093cbda2eddf8c25a173a1979df1f1fa74ff2800c19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of observer")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-450611")[#strong[#text("observer")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2015")])]

#text("Remark 46: sieve sieve.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-450614")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2015")])]

#text("Thank you. When I read from the email all formulas appear superscripted like exponents. When I read from ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comments")[#text("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comments")]#text(" it looks all right. Can I do something to make the email look all right?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-450619")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2015")])]

#text("In Problem 2, it seems (in line 3) that “")#mi("p \\leq x")#text("” should be “")#mi("p \\leq z")#text("“.")#linebreak()#text(" Also, it seems that ")#mi("\\pi_2(x, z)")#text(" should appear as the LHS of the displayed formula.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c935d3e0b69c3fe73a864a2de52513750618e1267ad7f7e5046377635d58c4ca-ae25666e2277e547f496e73140b31709b4b8ce234d70b62cbc1c158f9aea36c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomcircle")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-450625")[#strong[#text("tomcircle")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2015")])]

#text("Reblogged this on ")#link("https://tomcircle.wordpress.com/2015/01/22/254a-notes-4-some-sieve-theory/")[#text("Math Online Tom Circle")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-450626")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2015")])]

#text("In Problem 2, if we omit z itself in the product defining P(z), how does this avoid the residue classes 0, -2 (p) when p=z?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-450638")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2015")])]

#text("In (6), you need to incorporate the immediately preceding crude bound.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-450648")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2015")])]

#text("Proposition 14(i): The superscripts in ")#mi("{\\mathcal E}^3")#text(" and ")#mi("{\\mathcal E}^4")#text(" should instead be subscripts.")

#text("Proposition 23: n+2 -> p+2")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-450741")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2015")])]

#text("In the 1st sentence after (3), should ")#mi("{f=1_A}")#text(" instead be ")#mi("{a_n=1_A}")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d28195df14800315168ea974f4adf888eace7d3a34fc83513af492698793a2c-e2ad3cdfa379c5dcf139408dc5d555ac7c236dfa87abd3799a789b51ef5d74f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kodlu")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-450762")[#strong[#text("kodlu")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2015")])]

#text("“… theorem of Zhang which (among other things) used an upper bound sieve was used to demonstrate the existence of infinitely many pairs of primes whose difference was bounded.”")

#text("could be rewritten")

#text("“…theorem of Zhang in which (among other things) an upper bound sieve was used to demonstrate the existence of infinitely many pairs of primes whose difference was bounded.”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1@gmail.com")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-451003")[#strong[#text("arch1@gmail.com")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2015")])]

#text("As a beginner it took me a while to see that the terms in the expansion of (2)’s RHS correspond to the subsets of P’s prime factors, which in turn correspond to the divisors d of P on the following line.")

#emph[#text("[Additional step added to clarify – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-451070")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2015")])]

#text("In exercise 13 should’t it be ")#mi("p")#text(" in the last productory, instead of ")#mi("p_1")#text("? Very nice notes, by the way, hope I get some time to look at them carefully.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-451177")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2015")])]

#text("Maybe overkill, but it would have helped me if (4) had started with")#linebreak()#text(" ")#mi("\\sum_{1 \\leq n \\leq x: n=a(q)} 1 = ...,")#text(" and (5) with ")#mi("\\sum_{n \\in E_d} a_n = \\sum_{1 \\leq n \\leq x: n \\in E_d} 1 = ...")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 5: The linear sieve and Chen’s theorem (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-451191")[#strong[#text("254A, Supplement 5: The linear sieve and Chen’s theorem (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2015")])]

#text("[…] continue the discussion of sieve theory from Notes 4, but now specialise to the case of the linear sieve in which the sieve dimension is equal to , […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 7: Linnik’s theorem on primes in arithmetic progressions | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-452284")[#strong[#text("254A, Notes 7: Linnik’s theorem on primes in arithmetic progressions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2015")])]

#text("[…] options here; we will use a variant of the “continuous Selberg sieve” from Section 2 of Notes 4. Fix a smooth function that equals on and is supported on ; we allow implied constants to depend […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-452416")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2015")])]

#text("In the first sentence after Problem 2, should ")#mi("\\pi_2(x/2, \\sqrt{x})")#text(" instead be ")#mi("\\pi_2((x-1)/2, \\sqrt{x})")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-453606")[#strong[#text("254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2015")])]

#text("[…] function is somewhat similar to the continuous Selberg sieve weights studied in Notes 4, with the main difference being that we did not square the divisor sum as we will not need to take […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78b6bb1b526b84f2401b6affa5c7be46eef64b91f3158c598b28de0bdf1ee0ef-5d7fbc184c468ac2b51bf113e3dd31010165e3cfeb41bdf779afeaeef573361d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karaskas")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-454546")[#strong[#text("Karaskas")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2015")])]

#text("Theorem 44: The condition about q being squre-free looks unnecessary thanks to the definition of h(q), doesn’t it?")

#text("In the definition of Fourier transform shouldn’t it be ")#mi("e(-n \\theta )")#text(" instead of ")#mi("e(n \\theta )")#text("? It seems that if we define the transform without minus sign, then we will have to multiply the function f by ")#mi("e(-n \\theta )")#text(" during the reducing to the ")#mi("\\theta = 0")#text(" case.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d0f07a6b25b398f79766d935099dece0df94dae484a0c0adc2823c895f01232-61e318392d0d98168dab83f5b6531ccad3df4dcb0a3f560fb9d06a7b9d6bf139.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-457953")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2015")])]

#text("Are these notes available as pdf? I want to take a printout.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-459427")[#strong[#text("The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2015")])]

#text("[…] such as (2) or (3) are known to be subject to the “parity problem” (discussed numerous times previously on this blog), which roughly speaking means that they cannot be proven solely using […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A cheap version of Halasz’s inequality | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-462305")[#strong[#text("A cheap version of Halasz’s inequality | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2015")])]

#text("[…] This follows for instance from the fundamental lemma of sieve theory (see e.g. Corollary 19 of this blog post). (One can also use the Selberg sieve or the large […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on the Bombieri asymptotic sieve | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-470708")[#strong[#text("Notes on the Bombieri asymptotic sieve | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2016")])]

#text("[…] where denotes the derivative of . Note the loss of that had previously been pointed out. In the arguments that follows I will be a little brief with the details, as they are standard (see e.g. this previous post). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8276f0954b97549ceff275f57c29082e0589d500a659640812d803d6fbd0c170-0ea9f76c3e76b42cf50f9c9e28b096afd33cf0cef6e93d3b23a1c0acc573910a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of manhtuankhtn")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-472574")[#strong[#text("manhtuankhtn")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2016")])]

#text("In the definition of $G(t_1,t_2)$ after equation (44): should the term $dt_1dt_2$ removed?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8276f0954b97549ceff275f57c29082e0589d500a659640812d803d6fbd0c170-0ea9f76c3e76b42cf50f9c9e28b096afd33cf0cef6e93d3b23a1c0acc573910a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-472578")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2016")])]

#text("In the definition of $G(t_1,t_2)$ (after (44)) and $E_p(t_1,t_2)$: $1+p^{\\frac{1+it_2}{\\log R}}$ should be $p^{1+\\frac{1+it_2}{\\log R}}$.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8276f0954b97549ceff275f57c29082e0589d500a659640812d803d6fbd0c170-0ea9f76c3e76b42cf50f9c9e28b096afd33cf0cef6e93d3b23a1c0acc573910a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-472579")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2016")])]

#text("”which by the asymptotic $\\sum_p \\frac{1}{p^s} = \\log(s-1) + O(1)$ for $s > 1$” should be ”…. $-\\log(s-1)$…” (missing minus sign).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8276f0954b97549ceff275f57c29082e0589d500a659640812d803d6fbd0c170-0ea9f76c3e76b42cf50f9c9e28b096afd33cf0cef6e93d3b23a1c0acc573910a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-472664")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2016")])]

#text("I have a question which is somewhat related to the Brun-Titchmarsh inequality. It would be great if you can give me a reference. Does the following statement hold: Almost all natural numbers ")#mi("n")#text(" in the interval ")#mi("[x,x+y]")#text(" has the property that all prime factors of ")#mi("n")#text(" are at most ")#mi("x^{o(1)}")#text(", where ")#mi("y")#text(" grows slowly to infinity with ")#mi("x")#text(". Please ignore (delete) my question if you think it is inappropriate for this post. Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-472684")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2016")])]

#text("There has been a lot of work on counting smooth numbers in short intervals, see e.g. this paper of Croot ")#link("http://people.math.gatech.edu/~ecroot/smooth6.pdf")[#text("http://people.math.gatech.edu/~ecroot/smooth6.pdf")]#text(" for some results and references.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-508973")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2018")])]

#text("Exercise 26 (Approximations to Legendre’s conjecture):")

#text("I guess it should be O(y/logx) instead of O(y/logy), shouldn’t it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-508999")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2018")])]

#text("No, one can only hope to get ")#mi("y/\\log y")#text(" here (one can only make good use of the portion of the sieve of Eratosthenes up to primes of size about ")#mi("\\sqrt{y}")#text("). Note for instance that the number of primes in ")#mi("[x,x+2]")#text(" does not go to zero in the limit ")#mi("x \\to\\infty")#text(" (indeed, we believe it equal to 2 infinitely often!)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: Complex-analytic multiplicative number theory | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-528002")[#strong[#text("254A, Notes 2: Complex-analytic multiplicative number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2019")])]

#text("[…] 10 In Notes 4 we will use a similar method to that used to prove Theorem 9 to estimate sums such […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-629954")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2021")])]

#text("Dear Prof. Tao,")

#text("if you Ctrl+F for “taking s”, you’ll find a stray ")#mi("f")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-629955")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2021")])]

#text("Also, for the proof of Brun’s theorem, one can’t just set ")#mi("u = 2")#text(", because the ")#mi("O")#text("-notation does not yield a bound on the entire real line, but only a complement-bounded segment of it. One instead needs the containment of prime numbers within the set of (suitably) rough numbers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-629956")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2021")])]

#text("Finally, right after eqn. (19), ")#mi("D")#text(" is probably meant to be the level of distribution, and not the sieve level.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-629957")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2021")])]

#text("Oh, and regarding social matters: Perhaps my comment about the German saying has been percieved as somewhat grumpy. Yet, I observed that you, Prof. Tao, usually implement suggestions within the day, and I was put off by the fact that for my suggestions, that hasn’t happened yet.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-630022")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2021")])]

#text("Regarding lemma 17, I wonder whether the formulation might be optimised. Right now there is some class of functions obeying (22), and for this class one has the dependency on the sieve dimension. However, in the subsequent exercises one does not use the class of functions and the dependency on ")#mi("\\kappa")#text(" at all. As it stands, it might be misunderstood to state that the bound depends on ")#mi("\\kappa")#text(" and nothing else, which may be true but is not proven here, because (22) is assumed as an axiom.")

#text("Also, I’d be happy to get some kind of feedback from you whether my comments are welcome here or whether I’m just wasting my time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-630024")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2021")])]

#text("Also, in the paragraph after (22), I’m not sure at all whether the inequality is sufficient for the desired bound, which in ")#mi("w")#text(" needs to hold even for the small primes, if I’m not mistaken. I worry that a weird fluctuation in the beginning might throw the bound off. Also, I’m not quite sure whether the inequality is enough, because one bound is from above and the other from below.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-630026")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2021")])]

#text("Just to be clear: I mean fluctuations in ")#mi("g")#text(", not ")#mi("p")#text(" (even though it best not be zero for small primes).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-630031")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2021")])]

#text("In the proof of lemma 17, for the lower bound of ")#mi("p_*(p)")#text(", the third equation should probably not be strict, because the case ")#mi("\\beta = s")#text(" is not yet ruled out. Two equations later, there is a ")#mi("\\kappa")#text(" missing in the exponent of ")#mi("\\beta/(\\beta - 1)")#text(".")

#text("Dude, I’m not trying to piss anyone off. But it would just be nice to have a freely available reference, and with a bit of collaboration, we can make it happen!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-630648")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2021")])]

#text("Hello there,")

#text("this is a gentle reminder kindly asking you to implement the above suggestions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-632171")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2021")])]

#text("I give up. I’ve made some good faith suggestions, and all I got was an estranging remark by a certain “Anonymous” that said “Spin somewhere else” (see the comment section to chapter 2 of this lecture). I’m going to take the advice of this “Anonymous” seriously. Farewell.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/#comment-632172")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2021")])]

#text("I should add that this comment has not been removed yet, as of today.")
]
]
]
