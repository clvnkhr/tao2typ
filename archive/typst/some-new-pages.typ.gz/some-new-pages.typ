// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/07/16/some-new-pages/
// Converted to Typst by tao2typ: "2026-10-14T16:34:59.054785+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Some new pages", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Some new pages")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 July 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/07/16/some-new-pages/")[#text("https://terrytao.wordpress.com/2007/07/16/some-new-pages/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’ve added some new pages to this blog. Firstly, I’ve moved my ")#link("http://www.math.ucla.edu/~tao/preprints/books.html")[#text("old page on my books")]#text(" to a new ")#link("https://terrytao.wordpress.com/books/")[#text("page on this blog")]#text(", so that each book now has its own page for publication information, errata, etc., as well as its own comments section for feedback (including the inevitable reports of future errata).")

#text("I also added a new page to ")#link("https://terrytao.wordpress.com/advice-on-writing-papers/")[#text("my advice page on writing and submitting papers")]#text(", on “")#link("https://terrytao.wordpress.com/advice-on-writing-papers/take-advantage-of-the-english-language/")[#text("taking advantage of the English language")]#text("“.")

#text("Finally, I added some links on the sidebar of this blog to some of the more popular of my older posts and articles, and reorganised the categories slightly. In particular, my expository articles were moved out of the “short story” category (they didn’t fit particularly well with the ")#link("http://wordpress.com/tag/short-story/")[#text("other wordpress articles in this category")]#text(") and into the “expository” category. (Now that there are a number of wordpress blogs in research mathematics, it might eventually be worth trying to establish some standards for use of mathematical tags, but this is hardly an urgent concern.)")

#text("[")#emph[#text("Update")]#text(", July 18: Added the ")#link("http://www.arxiv.org/new/math.html")[#text("arXiv math categories")]#text(", as well as a parent ")#link("https://terrytao.wordpress.com/tag/mathematics/")[#text("Mathematics category")]#text(".]")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f033e7308b4cf1267f303af87f5bc0a962861d193ad03e688227541c53cbe8ff-05c0a4b086d8c6dbe145d080ad79a1b521e2cb05747030e901311750b51833c7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikael Johansson")]], [#link("https://terrytao.wordpress.com/2007/07/16/some-new-pages/#comment-4478")[#strong[#text("Mikael Johansson")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2007")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("(Now that there are a number of wordpress blogs in research mathematics, it might eventually be worth trying to establish some standards for use of mathematical tags, but this is hardly an urgent concern.)")
]

#text("I suspect that a highly relevant first step toward such a standard is for someone to simply step up and propose a system – much reminiscent of the RFC system for by and by establishment of other networking standards.")

#text("Thus – why don’t you simply state what system you’d like to use, and the rest of us’ll surely step into the discussion gladly!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf09cf30636779f507ac7bb7605f1fa930eb0fd5cf47853823ea8305c6708b7b-57bac54d2fefac22b892cb860f89f82132d79fea9b659911b396aa58fcf1f65b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aravind")]], [#link("https://terrytao.wordpress.com/2007/07/16/some-new-pages/#comment-4481")[#strong[#text("aravind")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2007")])]

#text("Happy Birthday Terry, and I wish you many more such power-of-two birthdays!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8fbd42a34ce005cbb548a0f847d21d168a0dbce41865cfa6acff735cd7e7dd0a-071af3853a0d8de7a1c7aebf632350b4aa3707d3fab8f653120477353e4ae2e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valentin10")]], [#link("https://terrytao.wordpress.com/2007/07/16/some-new-pages/#comment-4487")[#strong[#text("valentin10")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2007")])]

#text("Very good blog, very rich nice pictures and articles, congratulations !!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/16/some-new-pages/#comment-4493")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2007")])]

#text("Dear Mikael,")

#text("I haven’t given the matter a lot of thought, other than a vague feeling that tags could be more useful than they currently are. They seem to serve two purposes: a “local” purpose, allowing one to extract useful subsets of any given blog (e.g. all the non-technical posts in my blog), and a “global” purpose, allowing one to find other blogs with content similar to a given blog. For the local purpose, there is of course no need for a standard, but for the global purpose there might be.")

#text("Here’s a sample suggestion: would it be worthwhile for us to all slap a “mathematics” tag on all our maths posts (which, for me at least, would be about 90% of all my posts)? Richard Borcherds already does this. The global benefits of doing so are admittedly somewhat minor, though. (The same is even more so for trying to agree upon a uniform set of tags for, say, algebra, analysis, geometry, topology, etc.)")

#text("Dear Aravind – thanks! A friend pointed out to me that while I can hopefully expect one more power-of-two birthday, this is the last fifth-power birthday I am likely to have :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0370d1a896797a6c35d6dcfd44d6754e09ccd8bbc0700b42d12133888202801f-a1c7c2ca13b5ac992b05a7c9dda2638098396ea50fd31bf4c95069b66ad37a4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thomas1111")]], [#link("https://terrytao.wordpress.com/2007/07/16/some-new-pages/#comment-4499")[#strong[#text("thomas1111")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2007")])]

#text("Dear Terry,")#linebreak()#text(" what about the arxiv tags (‘math.NT’, etc.)? They are well-known to all (and even if they don’t appear in the identifiers of preprints anymore the corresponding categories still exist on the arxiv website). This would have the advantage of extracting “serious” mathematics-related posts from those by laymen who tagged theirs with ‘mathematics’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/16/some-new-pages/#comment-4505")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2007")])]

#text("Dear Thomas1111,")

#text("I like that solution; one can then search for math.* to get all research mathematics topics with essentially no false positives. It also helps solves the (still rather distant) problem of what to do once the number of research maths blogs out there exceeds the size of any reasonable blogroll; one can scan one’s favourite math.* categories in order to keep abreast.")

#text("I’ve decided to just go ahead and tag all my posts with these categories, to illustrate how they would work. (The exercise also illuminated, for me, how my interests are distributed across mathematics.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d58677b4023c07b9b61cf0df9fef1bc113847e309100e069a0553cbecbd3aa2-30758f8d1f45cd3689e45046e6532a6d5e9799c1bc00d595c3d66f9be73b61c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PinJun")]], [#link("https://terrytao.wordpress.com/2007/07/16/some-new-pages/#comment-4560")[#strong[#text("PinJun")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2007")])]

#text("Dear Terry")

#text("Can you put your tags in the form of “clouds”, just like that of del.icio.us? It would be more convenient for appearance.")
]
