// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/
// Converted to Typst by tao2typ: "2026-10-14T15:17:26.994682+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A speech for the American Academy of Arts and Sciences", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A speech for the American Academy of Arts and Sciences")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 September 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/")[#text("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Next month, I am scheduled to give a short speech (three to five minutes in length) at the annual induction ceremony of the American Academy of Arts and Sciences in Boston. This is a bit different from the usual scientific talks that I am used to giving; there are no projectors, blackboards, or other visual aids available, and the audience of Academy members is split evenly between the humanities and the sciences (as well as people in industry and politics), so this will be an interesting new experience for me. (The last time I gave a speech ")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/12/terrys-my-recollections.doc")[#text("was in 1985")]#text(".)")

#text("My chosen topic is on the future impact of internet-based technologies on academia (somewhat similar in theme to ")#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/")[#text("my recent talk on this topic")]#text("). I have a draft text below the fold, though it is currently too long and my actual speech is likely to be a significantly abridged version of the one below [")#emph[#text("Update")]#text(", Oct 12: The abridged speech is now at the bottom of the post.] In the spirit of the theme of the talk, I would of course welcome any comments and suggestions.")

#text("For comparison, the talks from last year’s ceremony, by ")#link("http://en.wikipedia.org/wiki/James_Harris_Simons")[#text("Jim Simons")]#text(", ")#link("http://en.wikipedia.org/wiki/Peter_S._Kim")[#text("Peter Kim")]#text(", ")#link("http://en.wikipedia.org/wiki/Susan_Athey")[#text("Susan Athey")]#text(", ")#link("http://en.wikipedia.org/wiki/Earl_Lewis")[#text("Earl Lewis")]#text(", and ")#link("http://en.wikipedia.org/wiki/Indra_Nooyi")[#text("Indra Nooyi")]#text(", can be ")#link("http://www.amacad.org/publications/bulletin/winter2009/ceremony.pdf")[#text("found here")]#text(". Jim’s chosen topic, incidentally, was what mathematics is, and why mathematicians do it.")

#text("[Update, Nov 3: Video of the various talks by myself and the other speakers (Emmylou Harris, James Earl Jones, Elizabeth Nabel, Ronald Marc George, and Edward Villela) is now available on the Academy web site ")#link("http://www.amacad.org/audio/induction09/saturday09.aspx")[#text("here")]#text(".]")

#metadata(none) <tao-f8899f5adc9b68e1c91c>

#heading(level: 1)[#text("— Introduction —")]

#text("If I had to name the most significant technological development in recent decades, I would have to say it would be the internet. By this, I mean not just the physical architecture of the internet ")#emph[#text("per se")]#text(", which was already available to academics and government agencies since the 1960s, but also all the innovative technologies that flourished once the internet matured, from tools as humble as the email mailing list to such unreasonably effective services as modern search engines or Wikipedia.")

#text("As the internet has become more integrated into the mainstream of modern life, it has disrupted and revolutionised one sphere of human activity after another. We read in the news about how online media is thriving as “old” media stumbles; how online medical information is transforming patient-doctor relationships; how blogs, tweets, and online videos are tipping the balance in closely fought elections; and so forth.")

#text("But to most of us in academia, there is a temptation to view these changes with a certain detachment: sure, established for-profit companies may well face competition (as they ought to) from lower-cost internet-based rivals, and it is only reasonable in a democracy that politics should be influenced by popular debate, both offline and online, but we, by contrast, should be secure in our ivory towers from any internet revolution, with our tenure, our unique expertise, and our time-tested academic traditions.")

#text("Even when new technologies do hit close to home – by threatening the profit model of the academic journal system, say, or by greatly facilitating the ability for students to cheat on their homework (and also for professors to detect such cheating!) – we can still rationalise away these developments as requiring only superficial changes to adapt to – switching from physical journals to online journals, perhaps, or placing more safeguards on our homework formats. We still perform our “core” academic activities – teaching, advising, research – much as we have for over a century: classroom by classroom, student by student, and paper by paper. We may do more of these things online now rather than offline, but it is still the academic who is at the center of things, not the internet. After all, it is not as if our classes can be replaced by a Wikipedia entry, or our research by a search engine query, right? Right?")

#text("Well, yes and no. It’s true that even the most advanced online resources available today are not nearly “smart” or sophisticated enough to render our academic services obsolete; not yet, at least. Unlike many other industries, academia does not currently face any real threat from a cheap internet-based competitor.")

#text("But I believe a “hybrid” form of academic activity is beginning to emerge – one in which internet-savvy academics and their institutions harness the full power of online tools to initiate and organise large research collaborations, and to disseminate and share their results at far more rapid and effective rates than were previously possible. In my discipline – mathematics – this type of net-centric activity is still in its infancy, but it shows signs of potentially being substantially more efficient (and perhaps more importantly, ")#emph[#text("open, cumulative")]#text(" and ")#emph[#text("responsive")]#text(") than traditional collaboration and dissemination, and is likely to become increasingly mainstream in the years ahead. It may not totally revolutionise the way we work, the ambition of what we hope to achieve, and the academic culture we work in, but it is likely to transform them significantly.")

#heading(level: 1)[#text("— Teaching —")]

#text("Consider teaching, for instance. Year after year, day after day, and in universities across the world, we stand in lecture halls and present the foundations of our subject to classrooms consisting of hundreds, or even just dozens, of students at a time. This keeps us engaged with our students, hones our skills, and makes us feel useful, but is it the most efficient way to do things?")

#text("There is a mathematical topic – Mobius transformations – which is taught routinely in complex analysis classes in a thousand mathematics departments across the world, to classes of perhaps thirty or fifty students in size; I have done so myself several times. On Youtube, there is ")#link("http://www.youtube.com/watch?v=JX3VmDgiFnY")[#text("a beautiful video")]#text(" explaining the geometric interpretation of these transformations which has been viewed ")#emph[#text("one million, six hundred thousand times")]#text(" so far – more people than can be reached than by even ten thousand mathematics lecturers. It can be accessed by just about anyone on the internet through a simple web search on the topic (it is in the top three hits currently on all major search engines).")

#text("Now, clearly, one cannot hope to replicate the entire classroom experience as a sequence of Youtube videos – the quality of interactivity, depth of material, and availability of expert attention, in particular, is much poorer. Even more professional organised efforts, such as the online videotaped lectures offered by institutions such as MIT, are an imperfect substitute for physically being present at these lectures. But the sheer numbers of people one can reach by the internet shows the potential of tapping this medium to teach in the future.")

#text("Already, hundreds of academics (including myself) use a blog to post their course notes and encourage online discussion (in all directions) between the teacher and students in the classroom, as well as visitors from around the world; I have had classes with perhaps thirty local students but up to a hundred other participants from a variety of backgrounds following (and commenting!) using the blog. There is a much higher quantity and level of questions asked, and the material in my notes is much improved, because of this; and I have learned more about the subject than if I had taught it in a traditional way, both from preparing the blog material, and from obtaining feedback from students and participating colleagues.")

#text("Even after the physical class ends, the online class goes on; I have often had people wanting to learn a subject stumble onto one of my online lecture notes on my blog from a year ago through a search engine, and continue the discussion afresh. Within a few years, there may well be valuable online content like this for virtually every commonly taught academic topic, just one search query away from anyone with internet access.")

#text("The technological level of online interactivity is certain to increase in the future; one can well imagine it becoming routine in classes to (for instance) field questions by text message from students overseas who are watching the lecture in real time through video, with the discussion continuing online long after the class has ended. Not all experiments in online teaching will achieve their intended objectives, but it only takes one clear success to provide a model that can then be rapidly emulated by institutions and lecturers worldwide.")

#text("In my view, the traditional classroom lecture will still play an indispensable role in the future, but in a rather different format than it is today, with its effects being vastly amplified and prolonged through its integration with the internet.")

#heading(level: 1)[#text("— Collaboration —")]

#text("Another major area where profound changes are happening is that of collaboration in research.")

#text("It was only four decades ago that the primary mode of communication among academics in distant institutions was by physical mail. This was inconveniently slow, and it discouraged collaboration with anyone who was not in the same physical location. With modern communication tools such as email, the situation today is vastly different; it is completely routine now in mathematics to collaborate over long distances, with months of online communication punctuated by only a few (but crucial!) days of physical contact each year. Perhaps as a consequence, there has been a huge increase in the proportion of papers in mathematics that are jointly authored, rather than singly authored. As a related phenomenon, an increasing fraction of papers are also interdisciplinary rather than specialised to a single subfield.")

#text("Very recently, software tools have become available to allow easier collaboration by large numbers of authors from across the world. Unlike the sciences, pure mathematics in academia has never really had the large laboratories in which armies of graduate students, postdocs, and senior researchers work on a single goal; but the technology is just becoming available for such large-scale projects to be possible.")

#text("This year, for instance, by ")#emph[#text("ad hoc")]#text(" usage of existing tools such as blogs and wikis, the first “polymath” projects were launched – massively collaborative mathematical research projects, completely open for any interested mathematician to drop in, make some observations on the problem at hand, and discuss them with the other participants.")

#text("The very first such project solved a significant problem in combinatorics after almost six weeks of effort, with almost a thousand small but non-trivial contributions from dozens of participants. It was a novel way to do mathematics, but also a novel way to locate the collaborators with the right expertise and interest to solve the problem, perhaps serving as a model to begin collaborations through online networking rather than physical networking.")

#text("And there were other unexpected benefits too; the projects have retained a fully available online record of all the discussion, including false starts, dead ends, and incremental progress, that took place while the problem was not yet solved, giving a much richer, more dynamic, and more accurate picture of how mathematical research really takes place than the cut-and-dried presentations one sees in finished products such as papers and textbooks.")

#text("By taking research online, it comes to life; one participant compared his anticipation to seeing the latest developments on a polymath project to the suspense one might feel while watching a TV or movie drama. Veteran researchers are familiar with these tensions, frustrations, and joys, but it used to be quite difficult to convey these experiences to the graduate students entering the field; perhaps these open internet projects, with their “show, don’t tell” nature, may succeed in doing so in the future.")

#heading(level: 1)[#text("— Academic culture —")]

#text("As we adopt new technology, our culture of doing things subtly changes. In mathematics, for instance, research used to be a secretive activity; one would often not discuss what one was working on before it was ready for submission to a journal, and would only give out preprints to a select few colleagues before the publication process was complete (which takes months or even years). With the rise of preprint servers and search engines, it is nowadays quite customary to put a preprint online as soon as it is submission-ready (or sometimes even sooner!); experience has shown that doing so greatly increases the visibility, impact, and influence of one’s work, and (perhaps counterintuitively) discourages excessively competitive behaviour and even plagiarism, as the timestamps given by preprint servers can help defuse arguments over precedence.")

#text("Indeed, in many parts of mathematics there is now a ")#emph[#text("social expectation")]#text(" that one’s work should be readily available online, and journals have largely abandoned attempts to enforce a (counterproductive) monopoly on the dissemination of their authors’ work. As a result, research developments propagate at a significantly faster speed than in previous decades.")

#text("In the future, I can imagine further cultural shifts of this type. Currently, the actual problem-solving process in mathematical research is usually obscured from view until the problem has been solved and a polished, publication-quality draft is available; with the rise of open collaborative projects such as polymath, this culture may begin to change in the future. (For instance, I circulated a draft of this talk on my blog weeks in advance, both to obtain valuable feedback and to encourage me to continue working on the text. A few years ago, I might only have shown a draft to one or two trusted friends, with perhaps a single round of revisions.)")

#text("Similarly, the advent of mathematical blogs and other semi-formal outlets for discussion is reinforcing an existing trend in mathematics in which the intuition and motivation behind a mathematical topic is emphasised as much as the definitions, theorems, and proofs; some of the more technical and specialised subfields of mathematics may well encounter increasing societal pressure in the future from their peers to make their work more accessible and transparent to wider audiences.")

#text("In teaching mathematics, the current model is that of a nearly one-way street; the lecturer does almost all of the talking. Apart from a few questions from the more bold students, one only receives feedback days or weeks after the class has ended, from the assignments, evaluations and exams the students turn in.")

#text("With improvements in technology, there may be a greater expectation in the future for such classes to be significantly more interactive, both during the “actual” class, as well as the online discussions before and afterwards, and with near-instant feedback becoming the norm.")

#text("Such changes will certainly encounter resistance; consider for instance the ongoing debate on whether to allow laptops in classrooms. Many such initiatives will not be fully successful; we still have a very partial understanding of what makes one online experiment flourish and another one fail. Nevertheless, I doubt that we will keep the ")#emph[#text("status quo")]#text(" indefinitely in the presence of such technological and social changes.")

#heading(level: 1)[#text("— Conclusion —")]

#text("One can draw an analogy between pre-internet academia and pre-industrial manufacturing. Before the industrial revolution, manufacturing was the province of individual craftsmen or of secretive guilds, working painstakingly on each individual piece of work, with each master passing down their carefully hoarded insights and tricks to just a handful of disciples. It is not hard to find parallels to each of these phenomena in academia.")

#text("But after the industrial revolution, specialisation and mass production became the paradigm in manufacturing; less intimate, surely, but also vastly more efficient and reliable. One might bemoan the loss of creativity and individuality that each craftsman exhibited, but eventually, as the industrial revolution matured into the modern era, the outlets for creativity became dispersed to a wider group of people. Thanks to division of labour, design, invention, entrepreneurship, manufacturing, marketing, training, or management could now be performed by whoever was best qualified to do each, rather than by the same individual; and the best practices in each of these areas could be adopted widely, rather than being confined to their originator and a select number of followers.")

#text("Academia has not experienced change on the scale of the industrial revolution since the invention of the printing press. With the advent of the internet – the modern day analogue of the printing press, among other things – could it be revolutionised once again?")

#heading(level: 1)[#text("— Abridged version of speech —")]

#text("It’s a great honour, both to be inducted to the Academy and to address you all today. I must confess that while I have given over a hundred scientific talks, this is only my second speech; and the first one was when I was nine. So I please bear with me; I’ll try not to sound like a nine-year-old.")

#text("I would like to talk about the impact of the internet, and all the unreasonably effective services it has spawned, from modern search engines to Wikipedia.")

#text("We know that the internet has revolutionised area after area: entertainment, journalism, politics will never be the same again. But those of us in academia like to feel protected in our ivory towers from the internet revolution, with our tenure, our expertise, and our academic traditions. After all, our classes can’t be replaced by a Wikipedia entry, and our research can’t be replaced by a search engine – not yet, anyway.")

#text("Nevertheless, I believe major change is already underway.")

#text("Consider teaching, for instance. There is a mathematical topic – Mobius transformations – which is taught in a thousand mathematics departments across the world, to perhaps thirty or fifty students at a time. I’ve done so myself many times.")

#text("But if you do a web search for Mobius transformations, you’ll find a beautiful video on Youtube explaining this concept clearly, which has been viewed one million, six hundred thousand times – more people than can be reached by ten thousand mathematics classes.")

#text("On a smaller scale, hundreds of academics (including myself) have actively pushed their classes onto the internet, using such tools as blogs. I have had classes with perhaps thirty local students but up to a hundred online participants. Even after the physical class ends, the online class goes on, with new visitors stumbling onto the class via a search engine and continuing the conversation.")

#text("These tools can have unexpected uses; for instance, I posted a draft of this talk online a few weeks ago, and got a tremendous amount of valuable feedback in return.")

#text("Or consider research. This year, for instance, by ad hoc usage of existing tools such as blogs and wikis, the first “polymath” projects were launched – massively collaborative mathematical research projects, completely open for any interested mathematician to drop in.")

#text("The very first such project solved a significant problem in combinatorics after almost six weeks of effort, with almost a thousand small but non-trivial contributions from dozens of participants. It was a novel, transparent, and lively way to initiate and then do mathematics. One participant even compared his anticipation to seeing the latest developments on a polymath project to the suspense one might feel while watching a TV or movie drama. (You had to be there, I guess.)")

#text("Academia has not experienced massive change – on the scale of the industrial revolution – since the invention of the printing press. With the advent of the internet – the modern day analogue of the printing press, among other things – could it be revolutionised once again?")

#metadata(none) <tao-f057d9ad07a460347579>

#text("It’s a great honour, both to be inducted to the Academy and to address you all today. I must confess that while I have given over a hundred scientific talks, this is only my second speech; and the first one was when I was nine. So I please bear with me; I’ll try not to sound like a nine-year-old.")



#text("I would like to talk about the impact of the internet, and all the unreasonably effective services it has spawned, from modern search engines to Wikipedia.")



#text("We know that the internet has revolutionised area after area: entertainment, journalism, politics will never be the same again. But those of us in academia like to feel protected in our ivory towers from the internet revolution, with our tenure, our expertise, and our academic traditions. After all, our classes can’t be replaced by a Wikipedia entry, and our research can’t be replaced by a search engine – not yet, anyway.")



#text("Nevertheless, I believe major change is already underway.")



#text("Consider teaching, for instance. There is a mathematical topic – Mobius transformations – which is taught in a thousand mathematics departments across the world, to perhaps thirty or fifty students at a time. I’ve done so myself many times.")



#text("But if you do a web search for Mobius transformations, you’ll find a beautiful video on Youtube explaining this concept clearly, which has been viewed one million, six hundred thousand times – more people than can be reached by ten thousand mathematics classes.")



#text("On a smaller scale, hundreds of academics (including myself) have actively pushed their classes onto the internet, using such tools as blogs. I have had classes with perhaps thirty local students but up to a hundred online participants. Even after the physical class ends, the online class goes on, with new visitors stumbling onto the class via a search engine and continuing the conversation.")



#text("These tools can have unexpected uses; for instance, I posted a draft of this talk online a few weeks ago, and got a tremendous amount of valuable feedback in return.")



#text("Or consider research. This year, for instance, by ad hoc usage of existing tools such as blogs and wikis, the first “polymath” projects were launched – massively collaborative mathematical research projects, completely open for any interested mathematician to drop in.")



#text("The very first such project solved a significant problem in combinatorics after almost six weeks of effort, with almost a thousand small but non-trivial contributions from dozens of participants. It was a novel, transparent, and lively way to initiate and then do mathematics. One participant even compared his anticipation to seeing the latest developments on a polymath project to the suspense one might feel while watching a TV or movie drama. (You had to be there, I guess.)")



#text("Academia has not experienced massive change – on the scale of the industrial revolution – since the invention of the printing press. With the advent of the internet – the modern day analogue of the printing press, among other things – could it be revolutionised once again?")

#heading(level: 1)[#text("Comments (57)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3396e5d821acf05130e0dd66a808e5a9b747f400bb4c8ec1e095e16f3d5863cd-8dc080f324aaf85dbf23766c178d9f111de3ca6f2343b550efff03667c70681f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bertram K.C. Chan, PhD")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41455")[#strong[#text("Bertram K.C. Chan, PhD")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2009")])]

#text("While it may be efficient in disseminating lecture materials via the Internet, experience has found that the tried-&-true method of chalk-&-talk has its advantages, including:")#linebreak()#text(" 1. The process of hand-copying the notes from the black/white board, & from the words of the lecturer, actually demands the brain of the students to process (at least some of) the content of the materials, & hence starts the learning process.")#linebreak()#text(" 2. Some lecturers chose to up-load their lecture notes on to his/her personal website, or to some other sites, with the good intention of saving the students from the tedious process of copying. This may be an unintended disservice, owing to one or more of the following factors:")#linebreak()#text(" (a) Depriving the students from the learning process described in #1 above.")#linebreak()#text(" (b) Some students, having down-loaded the lecture notes, will end up")#linebreak()#text(" (i) Missing the classes (by not attending)")#linebreak()#text(" (ii) Spending the class time doing something else, & not")#linebreak()#text(" listening/learning the lecture materials")#linebreak()#text(" – ALL BECAUSE THESE STUDENTS WERE GIVEN THE LECTURE NOTES")#linebreak()#text(" THROUGH THE INTERNET.")#linebreak()#text(" 3. Admittedly, some conscientious students WILL benefit from down-loading the lecture note prior to the class!")

#text("Do you agree?")

#text("Bert")

#text("(Bertram Chan)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fffb309a46e6c520798b804dbc143f07b9bb084eb2c3938e762d8bafc3ade406-5b5234ec978a8e85814fc052a115b74455d5c6b52553a2c6ad85fd7d7ea3a9ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Beetle B.")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41469")[#strong[#text("Beetle B.")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2009")])]

#text("Just as there are good and bad ways to teach using the chalkboard, there are good and bad ways to teach with giving the students lecture notes in advance.")

#text("In particular, instructors who simply follow their lecture notes to the letter are not doing it well.")

#text("As for the benefit of staying engaged with the professor and transcribing the notes by hand, it often has a bunch of drawbacks:")

#text("1) As one commenter noted, all too often it denigrates to the student switching to the “madly-copy-stuff-so-that-I-don’t-miss-anything”. Usually, the student will follow the professor up to half the lecture, and then either through fatigue or because it may just take him/her some time (and side calculations) to justify what the professor just said, he/she will not try to understand and simply copy everything down in the hope of understanding later.")

#text("Sure, he/she could query the instructor, but most students will not query more than a few times in one lecture. Additionally, it’s often the case that the student (perhaps being slow that day) will really require up to, say, 10 minutes of deep thought to figure it out.")

#text("2) Handwritten notes are bad for both studying and reference. Don’t underestimate well typed up notes for both.")

#text("3) If the students have read the notes in advance, then they’re more likely to ponder over deeper questions related to the material while the instructor is teaching. The first time most students encounter the material, their thought processes are at the very basic level, and they don’t tend to ponder over “what if’s”. They’re more likely to do so when they’re encountering the material the second time.")

#text("My two bytes…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b869235808b2230c870170197dbf3dfc89de74b25e842f695db21a5cc7c0874-97d118c6d3647236c9ddba823fe4a743b3cd63ede25fb2c021fce205b74a9b13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jair")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41484")[#strong[#text("Jair")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2009")])]

#text("Others might derive some benefit from the act of copying detailed notes, but I almost always find it a distraction. If I’m copying down information from the blackboard, chances are I’m not thinking about what I’m writing. Since there is a delay between the spoken lecture and my copying notes, I will often end up not listening to what is being said in a frantic effort to keep up with what was written. This is especially frustrating in a math class, where rapt attention is necessary.")

#text("On the other hand, note-taking can be very constructive for me if my notes are loose and abbreviated. I can afford to do this if I know there are reference materials online to refer to. If I have printed notes in front of me, I can underline sentences and write questions in the margins, which is even better.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41489")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2009")])]

#text("Bert,")

#text("I think Terry is arguing for something quite a bit larger scale than a single lecturer and a single class. However, I think you strike on something interesting which is the internet lacks an element of motivation/coercion that seems present in traditional academic settings. Providing information on the internet empowers the student but does more personal power mean a better outcome? In the example you cite, some students use the power of having more than one source of information to skip classes, presumably to their detriment. (These are in some sense political issues which would have political answers and I will avoid trying to address them as my personal politics can only bias my answers.)")

#text("I can’t help but consider the issue of content providers and content because the concern about notes revolves around users(students) using content(lectures and notes) not as intended by the content provider(lecturer). This also relates to what Terry mentioned about cheating. There seems to be an issue of models that rely on control of information (Encyclopedias, Journals, Movies, Music, Books) breaking down in the face of ever increasing availability of information and the choices previously less powerful people (at least in the sphere of information) make.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41632")[#strong[#text("Dave")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2009")])]

#text("Some empirical investigations show that about 20% of people cannot grasp or understand classroom lectures. That is, they cannot understand by hearing, rather by reading. Also, it is known that female students are better at both keeping notes and thinking– while males have difficulty at this.")

#text("Therefore, there is no method that is good for everyone, and the internet and on-line lectures give more options for students. This will certainly increase effective learning, not decrease it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41462")[#strong[#text("Mathematician Terence Tao on the influence of the Web on academia « Economics and Mechanisms")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2009")]

#text("[…] Tao has a prominent blog on mathematics. Today’s post encapsulates his observations on the influence of internet-based technology on all aspects of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41463")[#strong[#text("S")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2009")])]

#text("Section -Teaching-, last paragraph:")#linebreak()#text(" Maybe “to fielding” should be “to be fielding” or “to field”.")#linebreak()#text(" In the same sentence, the “and” after the comma may not be needed.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd83ab57967ccfe2fec3a7390f8ee470a99d34703c8a83778c9a2dff057d0298-fd0b212ab9166c7049cdb64effce4a7b0cb415ba88a6226266fd2fd598d74fd0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of davetweed")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41464")[#strong[#text("davetweed")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2009")])]

#text("In reply to Bertram Chan, I think your way to look at it isn’t quite right. Even pre-internet, in subjects like undergraduate mathematics where almost everything taught is at least 100 years old, the only thing that having the bouind-to-exist textbook with the same approach as the lecturer would miss from lecture notes is the precise boundary of what’s on the syllabus. So this isn’t a technology only problem. The issue is that you’re right that students need to be actively engaged during lectures, the question is whether the engagement engendered by copying out primarily what the lecturer has written on the blackboard is the best way to achieve this?")

#text("I know that 15 years ago when I was an undergrad, taking notes did keep you engaged but I also remember far too many occasions when I was frantically trying to copy stuff down, aware that I’d stopped actually following what the lecturer was saying. Hopefully there’ll be some approaches using new technology that capture the best of both worlds. For instance, it’s culturally frowned upon (as well as rendering it un-resllable) to scribble personal notes in a textbook, but maybe with e-book style technology it will become standard that the raw textural material is there but there are bits missing every so often that the students have to fill in, so there’s an incentive not to drift off. (I know a lecturer who already does this with printed handouts.) Similarly maybe with wireless links the lecturer can stop every so often and pose a “mildly-sophisticated” question (eg, write an equation relating these two quantities I’ve been talking about) of the audience and tally votes to promote the audience thinking about what they’re listening to. (The problem with this at the moment is that you either need multiple choice questions or you can only ask one audience member, so that everyone else doesn’t get involved.)")

#text("So I don’t think it’s a battle between blackboard OR printed notes but “What can we do with new technology that’s neither approach that works for students?”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/397530fd2887f612fba57abd32459442958e156e9a8d23305eb271a9f74ca393-fab68614ef7c5f8b6cbacb2fd16cb80a62d3801234d373e83bcfdb326cc5e905.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of oz")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41465")[#strong[#text("oz")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2009")])]

#text("Will you give any scientific talks while in Boston?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6374b4ec8949937d7250d1bebe2533f042bc477abca90f843302a7a24303fb5-8429e23abc3b6b7b5b24b08d388dd38cabb5e73ff1054f5c638b0b9bf2634b22.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41466")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2009")])]

#text("You may want to trim the content about online teaching, leaving just a short remark in the collaboration section, since the same broad issues apply to both: mathematicians often find it necessary to learn about fields of mathematics other than their own in order to understand some newly-published result.")

#text("Add a paragraph about proof assistants, such as Mizar, HOL, Isabelle, etc. Formal proof has recently been covered by ")#emph[#text("Notices of the AMS")]#text(" with a ")#link("http://www.ams.org/notices/200811/")[#text("special issue")]#text(". While it suffers from a number of problems (chiefly the low usability of current tools and the amount of effort needed to “sequence the mathematical genome”) it could well become a transformative tool in mathematical research and teaching. The current draft places too much emphasis on “semi-formal” outlets which, while clearly important, have limited potential in opening up mathematical research to a broader audience.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of weiyu")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41468")[#strong[#text("weiyu")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2009")])]

#text("There should be a good balance of “individuality” and “internetism”. It might be helpful to talk a little bit more about the limitations of excessive use of computer technology or internet for mathematics teaching and research. I often find a hard time listening to mathematical courses taught only through slides.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41471")[#strong[#text("Speech about mathemtatics and the internet « Euclidean Ramsey Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2009")]

#text("[…] ")#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/")[#text("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41472")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2009")])]

#text("I am by no means very well informed on the industrial revolution. Nevertheless, I found the analogy with the industrial revolution and the resulting conclusion that there might be a similar reduction in personal craftsmanship, the most intriguing part of the speech.")

#text("My thinking on the industrial revolution is that some of the more important elements which seem of relevance to me are mechanization, organization and cheap, minimally-skilled, driven labor. I see the parallel between using heavy machinery and using computers and between more complex organizations of the workforce and something like the polymath project. However, I think the massive availability of cheap workers might be missing here. There also seems to be no parallel with the dumbing down of the process. While a factory might be a complex object to design, each process in the factory is often so simple that quite literally anybody can do it with minimal training. Finally, the labour force was driven to migrate hundreds of miles and live in very unhealthy and dangerous situations because the pay provided a way for them to better themselves.")

#text("Something like the polymath is resting on unpaid, voluntary, formally uncommitted workers. Many of these are highly skilled with skills that only a few people might have. The psychology of this kind of worker seems to me to have the potential to be radically different from those that make up much of the factory-based workforce. Thus a movement composed of these workers seems like it would be radically different.")

#text("“One might bemoan the loss of creativity and individuality that each craftsman exhibited, but in truth, the outlets for creativity simply became dispersed to a wider group of people. ”")

#text("I found myself differing with this line of thought. Software and the internet in general seems to be empowering more individuality. The difference between a good blog and a newspaper, for me, is personality and craftsmanship. I think that innovations like compilers, computational algebra systems, office software, cheap electronics and so on means that regular people can do more than hundreds of people could do 100 years ago. This facilitates the creation of highly individual productions by democratizing the means of production.")

#text("My final thought is on the nature of the reward system. My experience with online communities is that they often have some powerful centralizing force such as a single person, a piece of software which organizes most of the group activity or a community with an attractive culture; and participants are rewarded either with credit for their efforts or access to resources of the group not available to everyone.")

#text("I think it might be interesting (if possible) to hear your thoughts on what the reward systems are for participants.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41473")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2009")])]

#text("Magnificent!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef3ae79bd944137a0ccf68ddfb4ed9dfeeb13f961a9a3b4d2ab56fa684b5a23a-2affba240ffd94ccd755a866d2425adef2dc8d0dcaadef7222e988fcfcbf79a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41475")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2009")])]

#text("The first two paragraphs of the Conclusion section seem to also apply to the pre-printing-press era. Using the analogy with the transmission of knowledge instead of the implementation of labor.")#linebreak()#text(" We could also say that, before the invention of the mechanical printing press “the transmission of knowledge was the province of individual craftsmen or of secretive guilds, working painstakingly on each individual piece of work, with each master passing down their carefully hoarded insights and tricks to just a handful of disciples.”")#linebreak()#text(" Some time after the invention of the printing press people could read Plato’s books, making the attendance to Plato’s lectures essentially irrelevant.")#linebreak()#text(" Along these lines, the internet (always in terms of the transmission of knowledge, rather than the creation thereof) is just amazing. If I can’t attend one of Tao’s lectures, I can visit his website/blog or, even better, watch one of his math videos (now making books essentially irrelevant!).")#linebreak()#text(" Even more amazing, I have access to Tao’s speeches weeks before he delivers them!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5f34d5ab8f2011590e40a3e10a75c7f3a86a65cff37ec135cae7414f2e5434a-e0a8bf59221cc6f53bc7f6307cf5125c52de6c3e9366c1889d0e430954fd4dcd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Mietchen")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41479")[#strong[#text("Daniel Mietchen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2009")])]

#text("– Wikis provide ample opportunities to address the aspects of online syllabus, teaching tool and collaborative platform that places a topic in context (e.g. as at")#linebreak()#text(" ")#link("http://en.citizendium.org/wiki/Associated_Legendre_function/Related_Articles")[#text("http://en.citizendium.org/wiki/Associated_Legendre_function/Related_Articles")]#text(" )")

#text("– New dimensions of collaboration: Efforts are spreading to harvest database contents into wikis, as in ")#link("http://biogps.blogspot.com/2009/09/gene-wiki-update-paper.html")[#text("http://biogps.blogspot.com/2009/09/gene-wiki-update-paper.html")]#text(" and ")#link("http://www.biomedcentral.com/1471-2105/10/291")[#text("http://www.biomedcentral.com/1471-2105/10/291")]#text(" . Related efforts are on the way in the opposite direction, from wiki-based Open Lab Notebooks into databases ( ")#link("http://friendfeed.com/oww/6dec4105/do-you-know-of-any-examples-open-notebook-data")[#text("http://friendfeed.com/oww/6dec4105/do-you-know-of-any-examples-open-notebook-data")]#text(" )")

#text("– One important aspect of current academic culture is summarized at")#linebreak()#text(" ")#link("http://www.plosbiology.org/article/info%3Adoi%2F10.1371%2Fjournal.pbio.1000197")[#text("http://www.plosbiology.org/article/info%3Adoi%2F10.1371%2Fjournal.pbio.1000197")]#text(" which states “I was also advised not to put our very best ideas into the application as it would be seen by competitors—it would be safer to keep those ideas secret.”")#linebreak()#text(" I would think that academia as a whole would be better off if it were to put the best ideas into a public space (much like in the Polymath project), and discuss and decide in public what would be the best methods and required qualifications to address them, and to assemble the teams based on these criteria, rather regardless of physical location or nominal degree (cf. ")#link("http://dmm.biologists.org/content/2/5-6/201")[#text("http://dmm.biologists.org/content/2/5-6/201")]#text(" ) – all of this highly unusual for most fields, but fully compatible with the spirit of doing research funding in public, as described at ")#link("http://ways.org/en/blogs/2009/may/24/implementing_fantasy_science_funding")[#text("http://ways.org/en/blogs/2009/may/24/implementing_fantasy_science_funding")]#text(" .")#linebreak()#text(" A related quote (found via ")#link("http://mixedink.com/Eups20/Manifesto")[#text("http://mixedink.com/Eups20/Manifesto")]#text(" – an example of how collaborative drafting of texts, e.g. for speeches, could work; another such example is at ")#link("http://etherpad.com/SxYOAaQDUd")[#text("http://etherpad.com/SxYOAaQDUd")]#text(" ): “For the first time in modern industrial society, governments have the chance to realise the potential embodied in Bill Joy’s observation that there will always be more smart people outside government than within it. And, in view of the scale and complexity of the challenges faced in the early 21st century, there has never been a more urgent time to realise this latent, distributed potential. ”")#linebreak()#text(" I think this fully applies to research too, and we should consider ways to facilitate the harvesting of this potential there.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41482")[#strong[#text("Tales from the Tubes — 19/​09/​09 | Young Australian Skeptics")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2009")]

#text("[…] Terence Tao speech about the internet. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43c6e8a8da64cd8d8330e0a17b568edb712ad8e78efffeac790325f83615fb0a-4dfb49c86896fc83cb3dd6340ed6fef67136274d82d04398453780f35237e326.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jonathanfine")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41485")[#strong[#text("jonathanfine")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2009")])]

#text("Not exactly a comment, but Elizabeth Eisenstein’s book “The Printing Revolution in Early Modern Europe” provides an excellent description and analysis of the changes made in religion and science as a result of the rise of print. This is something that might interest the humanists in the audience.")

#text("For example, it has chapters “Some features of print culture”, “Western christendom disrupted” and “The book of nature transformed”. The rise of the internet has analogies both with the industrial revolution and the rise of print. (The early printers were pioneers in large-scale manufacturing, with standardised components, and so were forerunners of the industrial revolution).")

#text("Here’s a URL for the book:")#linebreak()#text(" ")#link("http://www3.cambridge.org/us/catalogue/catalogue.asp?isbn=0521607744")[#text("http://www3.cambridge.org/us/catalogue/catalogue.asp?isbn=0521607744")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c99cfa2c4a0dabf1cdba7663990d1e85fc8c0959c0742629cc45314d5f861444-d9d6fd2ec518579e21ab66a663de5603ccbe3d69256f5c82f06ffc6c57740dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gry")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41487")[#strong[#text("gry")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2009")])]

#text("fantastic blog:)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/826a2728424b30ad8cc83000d2bfd8744edcd1bafba060e1c70b63281a0934f6-5e3de4a3d5bde314bee2c1b42ac7f851cee463773970099eaeb046cc61a7dd19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harrison")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41491")[#strong[#text("Harrison")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2009")])]

#text("Just a minor usage nitpick:")

#text("“With modern communication tools such as email, the situation today is vastly different; it is completely routine now in mathematics to collaborate over long distances, with perhaps only a few (but crucial!) days of physical contact per year, punctuated by months of online communication.”")

#text("Wouldn’t it be more accurate to have “months of online communication punctuated by a few days of physical contact?” ")#emph[#text("[Corrected, thanks – T.]")]

#text("Apart from that, fantastic speech!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41492")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2009")])]

#text("Thanks for all the feedback! I have already revised my speech (and more subtly, revised my perspective on some of the topics in the speech) in response to the comments (which, incidentally, seems to demonstrate in a small way the thesis of the talk…).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41493")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2009")])]

#text("Video lectures have great advantages.")

#text("It is invaluable for a student to be able to pause to think a point over, or to rewind to hear a difficult idea explained again.")

#text("Most teachers are average. It is preferable to hear an explanation by a world-class teacher.")

#text("With video lectures, each student may progress at his own rate. Fast students may zip ahead and slower students may take their time.")

#text("By spending less time on preparation and delivery of lectures, teachers have more time for answering questions, mentoring, and providing feedback, which is their irreplaceable contribution.")

#text("Teachers have little motivation to perfect a lecture which will be seen by few students and then gone forever. It is worthwhile to perfect a video lecture because it can become a permanent contribution to civilization, like a great book.")

#text("I imagine a classroom in which each student watches video lectures on his or her own laptop, pausing at times to ask questions of the teacher or their classmates. Perhaps students in this class will post questions on a shared online document and the questions may be answered or discussed spontaneously.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41494")[#strong[#text("Auf die Augen « Auf die Augen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2009")]

#text("[…] ")#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/")[#text("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd4bfb06bd050a989093ed573685723febc2f7fbc97be93869ddd8bab3257fc9-7fe956b9f8b7dae1686b686a0691c02b9667dd8802e8de59c9cf328efac02d71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A semana nos arXivs… « Ars Physica")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41496")[#strong[#text("A semana nos arXivs… « Ars Physica")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2009")])]

#text("[…] A speech for the American Academy of Arts and Sciences […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41498")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2009")])]

#text("Most of the teaching-related comments take lectures, more-or-less, as a given. My experience is that lectures are superior to a text because (and only because) the lecturer can adjust the pace and level of detail to the audience, using not only questions but facial expressions and body language as cues. This is true in research seminars as well as undergrad classes.")

#text("In a computerized world, however, texts can also be adaptive. Read one of Terry’s posts, and you find hyperlinks to quotes of theorems, to more detailed discussions of side issues, to other work and workers.")

#text("The Calculus & Mathematica(TM) texts, by Uhl, et al, are Mathematica notebooks. They have thousands of small questions for the reader, with the answers (and related graphics) in “grouped” cells, so that the reader can think about it without seeing the answer, and either skip or go into the details as appropriate. A Calculus & Mathematica class proceeds without lectures; the students read the book, argue with each other (or the instructor) about the answers, solve problems, and do substantive homework. It’s great fun to teach this way (for me, at least), and the students love it, too.")

#text("Also, WeBWorK (NSF funded and Free) can have an impact. One can assign “routine” homework that is randomized, and the grading happens by computer. One role of lecturing is to keep everyone on the same topic, so that homework and exams can be graded in a practical manner. That’s no longer needed.")

#text("The great coming education revolution will be through individualization, not mass production. My two bytes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41501")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2009")])]

#text("I agree with many of the advantages of on-line instruction and slick lecture videos as noted above, and particularly so for people who otherwise do not have access to a university. However, if education is strictly limited to this experience, as some people and commercial enterprises advocate, the student will miss the experience of intimately observing the professor think, and sometimes stumble on a proof, at the blackboard in front of them. Moreover, the student is missing the reactions of students next to them. That physical and real-time presence of others and their thoughts makes learning a shared and human experience, as it should be.")

#text("I’m also afraid that diversity of thought and viewpoint could suffer as certain on-line courses and videos become dominate in the marketplace, or some are suppressed by administrators or bureaucrats bending to the pressure of political crackpots. Anything in electronic form is easier to market, control, manipulate, and censor. Humanities would suffer even more than mathematics and science under this senario.")

#text("Another thought: how on earth do you do physics, chemistry, and biology labs for an on-line course?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41502")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2009")])]

#text("After reflection (and reading Richard’s comment) I want to soften my post. Another thing lectures *are* good for is the shared experience of the audience. It’s more fun to hear a good joke at the same time as friends. Laughter is contagious, and I recall being in a couple of Joe Gallian’s talks that were entertaining and memorable because his humor, the surprisingness of the math, and the thrill of learning something together brought us all along together.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ca56e46c8742ff0a086d1d6aedfbb4d4d0855a51c295525fac4807042eceed7-d6dad7070d925156dcf5c4a38010c9717072d95a73147876a450157e079ac847.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A T")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41525")[#strong[#text("A T")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2009")])]

#text("The “shared experience” can perhaps be simulated by adding a laughter track. (Sorry, couldn’t resist the joke.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b936027b16d564ae3bce702ec552aa6f4a3e691b31290889bad8f9a782252787-cd9c9a03ea60126224fd195c4660bf737d509f34928b1ec7f5a7eb17fd180cbf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vrigg")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41503")[#strong[#text("Vrigg")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2009")])]

#text("There’s an additional way to relate this to the career paths that many in the audience are embarking on. Two forces conspire to make future careers more multi-disciplinary:")

#text("* There are more researchers in a given discipline than in decades past. To succeed you either have to be brilliant and/or very hard working or you set yourself apart by having a skill-set few others in your field has. Traditional education focus on giving those in the field a shared foundation through a standard curriculum, but the student find that he/she has to break away from this to set oneself apart from the competition")

#text("* The internet has of course made it much easier to find new topics and study between fields. A search engine throws up related topics that browsing a library catalogue or reading the standard textbooks won’t show you. I think the rapid dissemination of compressive sensing to many fields is one example, but I think we’re seeing more multidisciplinary work everywhere.")

#text("This can further be related to Hilbert’s concluding remarks in his 23-problems speech from 1900, where he argue against the fear that mathematics will disintegrate into disjoint fields:")

#link("http://aleph0.clarku.edu/~djoyce/hilbert/problems.html#final")[#text("http://aleph0.clarku.edu/~djoyce/hilbert/problems.html#final")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9040bac26d9a740f9318df61e97779ca8729000df38e4d9aed7ead17b4525756-d4b843ec87daf04a3f02fc66e356632cef15aa27155f9df47406b0c63a31109f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt Daws")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41504")[#strong[#text("Matt Daws")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2009")])]

#text("Well, these comments are essentially “academic”, as Terry won’t possibly have time to mention them in his actual short talk. But anyway… It would be interesting to address how some of the “politics” of academia are taking time to catch up with some of these new ideas. For example:")

#text("i) I love the arXiv, and post all my papers there, usually a week or so before sending them off to a journal: I often get one or two comments from people around the world, which helps to improve the final version. I have some papers that still haven’t been published (due to journal backlogs) but which have inspired other people: that’s exactly how the arXiv is meant to work! However, I find it odd that many colleagues (both locally, and people who work in my research area who I meet at conferences) do not use the arXiv. Often these are people are of my generation, or only a little older, so I don’t think this can be dismissed as ludditism. It would be interesting to know why the arXiv isn’t standard practise by now.")

#text("ii) Daniel Mietchen above writes “academia as a whole would be better off if it were to put the best ideas into a public space”. In many ways I agree, but at the same time, I also completely sympathise with the view: “I was also advised not to put our very best ideas into the application as it would be seen by competitors—it would be safer to keep those ideas secret.” There is huge pressure, here in the UK, to get research grants: these now pay “overheads” which go to the university (to cover things like my salary, office space, and so forth) and so are an important source of extra funding. So it’s vital to be able to get funding, which is based upon specific projects (and so, I think, differs from NSF grants). I can see why you wouldn’t want to put your best ideas into a proposal: if you get the money, you want the best “bang for your buck”; if you don’t get the money, you’ll still be able to do the research, and getting good publications will help get a grant next time. In short, what recognition would you get for merely having had the idea?")

#text("iii) Here in the UK, the government (or a government body, technically) periodically assesses our research output, and this directly affects the funding our department will receive (this is entirely separate to the grants described above). How, I wonder, would this process (the RAE) handle a polymath project? To be a little controversial, I doubt this is a worry Tim Gowers and Cambridge have, but as an average young academic, it does worry me!")

#text("These points all address issues of academic culture and politics: I don’t see why, in an alternative universe, with a different way of structuring academia, these couldn’t all be dealt with. But in this world, they do seem important.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41506")[#strong[#text("Stones Cry Out - If they keep silent… » Monday Highlights")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2009")]

#text("[…] math, I haven’t looked into it yet, but it sounds like a great idea. Not unrelated, a talk on the Internet and maths by Terry […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f24a97b13a38989afb1d97d4058775a34d5ebb4f4b680491fba9f0daaaf6cc1-8c4202cd59223e301f43977249a21d6879dc14e7056d91c2d65f2fb9d5309f6f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Batson")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41508")[#strong[#text("Joshua Batson")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2009")])]

#text("A related, practical question: what is the best way to enable collaborative note-taking in a mathematics class? In many of my seminars, the professor requests that one student act as the scribe in each session, with the collection of notes by different students to be collated and made available to all later. Since 1h30 chunks are not a natural mathematical unit and occasional mistakes are made (by the scribe and the lecturer), the disjoint union of the notes is far less valuable than an integrated version. It would be great to have students able to correct one-another’s mistakes, flesh out ‘by the way, this is related to ____” comments, provide alternative proofs, include examples, etc. It would be a good learning/writing opportunity for everyone in the class, and at the end, there would be a useful (maybe even reusable) document. Has anyone tried this? Options seem to include a subversion repository, an online host ScribTeX, a wiki…. I’m hoping to find a balance ease of use, LaTeX convenience, and version control. Any suggestions would be much appreciated.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/390517060033239b9bf4fdf38be68020e8c3713bc59523c096d8f998664e0bbe-8a87dc77dc8f1db8ed403dfd640cfca3565b7b89c4f53fa7c5cbd2c0bed27bd8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41510")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2009")])]

#text("This is exactly the kind of thing Google Wave could easily accomplish. One could imagine a professor sharing a Wave with his students before each class with a bare-bones outline of his lecture. Students would then collaboratively edit this Wave either by fleshing out the outline or by asking questions, which could be answered both in the Wave and in person depending on whether you want this process to occur before, during, or after the lecture. There are of course many possible variations on this theme.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ca56e46c8742ff0a086d1d6aedfbb4d4d0855a51c295525fac4807042eceed7-d6dad7070d925156dcf5c4a38010c9717072d95a73147876a450157e079ac847.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A T")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41526")[#strong[#text("A T")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2009")])]

#text("Unrelated question: Is there a “WordPress Groups” (similar to “Google Groups” but supporting mathematical typesetting)?")

#text("I set up a Google Group for all my classes and students tend to find it very useful for discussing homeworks and such.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e6069f1706108a9fe37ccf480e472fbbe41938b3d58cce935eeacfe361ea9e4-8e21c22006ed0e7b6d77ccfeb4c41e26bd85333500bfc50f9246ad8910afc4fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Beetle B.")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41552")[#strong[#text("Beetle B.")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2009")])]

#text("That would actually be an awesome use of Google Wave.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41511")[#strong[#text("The Twofold Gaze")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2009")]

#text("[…] have been thinking about the nature of knowledge work due to an recent draft of a speech by Terry Tao where he discusses the idea of the polymath […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df88c82a0c6ca60749bde63169ae2c1a10887470fb305be1ac30901d9d26e643-738f0fc464705f031f93b8ebe4bdcd7c3f18bdbd27a382bbbdd325758468e3f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hmmm")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41513")[#strong[#text("hmmm")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2009")])]

#text("That 1985 speech is so cute! I assume you were 9 at the time?")

#text("It does, however, raise important questions.")

#text("Do you still have nightmares about the London Underground?")

#text("Do you still throw away pens, tear up your papers, go to your bed and sulk?")

#text("Do you still play teach your brother music and play duets?")

#text("Most important of all, do you still jump on your trampoline to relieve frustration?")

#text("Your answers to these questions will be of far greater value than the speech to the AAAS, no matter how many dignitaries attend.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41514")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2009")])]

#text("It is indeed a shame that I couldn’t possibly cover all the topics debated here in my talk, but I think I will mention the existence of this thread, at least.")

#text("Two small observations. Firstly, regarding the potential future tension between individuality and mass production in academia, I think this is a false dichotomy; one can (in principle, at least) have the best of both worlds thanks to modern technology, much has happened in industry with the advent of ")#link("http://en.wikipedia.org/wiki/Mass_customization")[#text("mass customisation")]#text(". I think I may have given the wrong impression in the original draft of my talk that I thought one would achieve an exact repetition of the industrial revolution; it won’t quite be the same, but is instead would merely be analogous in many respects. I’ve changed the conclusion a little to reflect this.")

#text("Secondly, there is a paradoxical phenomenon that even as technology allows for many more activities to be done over long distances, the “hub” of these activities often become ")#emph[#text("more")]#text(" concentrated in space, rather than less, because the network effect of physically concentrating expertise in one location becomes amplified. (Note for instance how industries such as finance, movie-making, fashion, etc. are concentrated in just a handful of cities worldwide, despite (or because of?) the ability to perform these tasks anywhere.) So I don’t think the physical classroom is going to go away any time soon… but it will probably look and function quite differently in 2029 than it does in 2009.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41542")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2009")])]

#text("I think I see now that the element of the industrial revolution that Terry is emphasizing is mass production. So extending to mathematics, any revolution ought to mean something about the mass production of mathematics.")

#text("Thurston wrote in ‘On Proof and Progress in Mathematics’ that in doing mathematics “what we are doing is finding ways for people to understand and think about mathematics”. He emphasized the notion of increasing the understanding of people in contrast to the production large masses of undigested data or computations.")

#text("This perspective on mathematics is close to my own but I’m not sure if it’s what most other people would consider mathematics so my conclusions might not be universal. It seems to me that mass production of mathematics then means mass increases in the understanding of mathematics by humans. A goal like this appears to require the implementation of a process which merges the changes which attended both the invention of the printing press and the industrial revolution. This makes this line of thought especially intriguing.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41520")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2009")])]

#text("Thanks Terry, for a very insightful and beautifully written article.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of math_in_uk")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41524")[#strong[#text("math_in_uk")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2009")])]

#text("In the UK many universities have gathered forces to produce graduate courses in maths online via Grid Technology. It is located here: ")#link("http://maths.dept.shef.ac.uk/magic/index.php")[#text("http://maths.dept.shef.ac.uk/magic/index.php")]

#text("As you can see, for each course it allows students from very different locations to attend, plus lecturers can manage a forum and post lecture notes. I don’t know how smooth it runs in practise, but the concept is great. The lecture notes seem to be freely available, while the videos are reserved for fully registered students apparently (given university fees it’s understandable I guess).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a82acfa3edff407f8c5d813817db713c34413d77b69d9357d0c78acdb150f2d1-344a5eccba98f1d26b258f1ce01a23a351f459ab838f41a863000682d8dc0f10.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josh")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41547")[#strong[#text("Josh")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2009")])]

#text("“On Youtube, there is a beautiful video explaining the geometric interpretation of these transformations which has been viewed one million, six hundred thousand times so far – more people than can be reached than by even ten thousand mathematics lecturers”")

#text("I’m sorry, but the view count does not equal the number of people who have seen the video. One person could have viewed it 100 times, some other opened and closed without watching. It may account for various scrapers and spiders. So the view count is not a definite measure for number of people who have seen it!!!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/53cae6195c493f52ba3ccd3e7fec51d055a0868ee73605d2945b6f8549cca6a2-01dee5326189353f8f5092d20dc5e9acd71464934d8557371089e94f95b039d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Anderson")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41623")[#strong[#text("Tom Anderson")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2009")])]

#text("I disagree that the view count is not a definite measure for the number of people who have seen it. Although YouTube counters are not as accurate as they could be, in fact if a person opens and closes a video without watching it, the counter does not register a view. The standard for web video is three seconds of watching time before it can be counted as a “view”. And in the unlikely scenario where a single person watches a video 100 times, it means they really really like it. Therefore, the view count is a strong indicator of the interest in a particular video.")

#text("Here’s the link to the video: ")#link("http://www.youtube.com/watch?v=JX3VmDgiFnY")[#text("http://www.youtube.com/watch?v=JX3VmDgiFnY")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41558")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2009")])]

#text("In a sense, if the PURPOSE of Mathematics is INSIGHT, about an application, a structure, a sequence, a function, a theorem, an operator, a pattern, a symmetry, a clever trick, a fruitful discovery from an apparent dead end, an analogy, an analogy between analogies, or even self-insight into the nature of one’s cognition and sense of beauty. In which case the analogy with mass production and mass customisation is mass insight and mass-self-insight. To the extent that the computer and its network of networks bring that, it is of immense human value.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0aa74e93d23af6d611299ff8d71ca6b9223d38d5dc6147cac295f1cc321ff247-1fbb0751e5cd17c62f9c19ef4fcf46c047fb9988615bce1eb78148141b5c9972.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Lund")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41559")[#strong[#text("Peter Lund")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2009")])]

#text("“Unlike the sciences, pure mathematics has never really had the large laboratories in which armies of graduate students, postdocs, and senior researchers work on a single goal;”")

#text("What about the NSA? GCHQ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41560")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2009")])]

#text("Peter, you think NSA and GCHQ do “pure” mathematics? Try getting a job there without an applied background.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/573d2542ab1f1dbc3aa25ef136ef711e6751ba35c1b4c15c36cc4b068a8c5dfd-811059f52c94f0492664ad3b7849f5bdce509d50393a8abe6b70a2eb60c38940.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy P.")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41561")[#strong[#text("Andy P.")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2009")])]

#text("I know of a number of pure mathematicians who now work at the NSA. My impression is that they like it if you also know how to program a computer, but they definitely hire people with PhD’s in pure mathematics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41562")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2009")])]

#text("But do they ")#emph[#text("do")]#text(" pure mathematics, Andy? I’m pretty certain that all their mathematics has some application or another in mind.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41569")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2009")])]

#text("I don’t know NSA, but given that Microsoft Research does some pure math…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/573d2542ab1f1dbc3aa25ef136ef711e6751ba35c1b4c15c36cc4b068a8c5dfd-811059f52c94f0492664ad3b7849f5bdce509d50393a8abe6b70a2eb60c38940.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy P.")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41570")[#strong[#text("Andy P.")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2009")])]

#text("They are not allowed to talk about their work, so who knows? It probably depends on what you mean by “pure math” — I get the impression that a lot of their work deals with cryptography, and thus that they end up doing some pretty serious number theory.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41573")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2009")])]

#text("I suppose the line between pure and applied mathematics can get somewhat blurry, but for the purposes of my talk I had intended to focus on academic pure mathematics, as opposed to industrial or security organisation mathematics, and have amended the talk accordingly.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41605")[#strong[#text("Tweetlinks, 9-26-09 [A Blog Around The Clock] « Technology Blogs")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2009")]

#text("[…] Tao: A speech for the American Academy of Arts and Sciences (on how the internet is changing science, especially […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41629")[#strong[#text("גיקדום 30.9.2009 « ניימן 3.0")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2009")]

#text("[…] בחסד ואדם ששמו חוזר בבלוג בתכיפות נדירה, מדבר על חשיבות האינטרנט למתמטיקה. קראתי פוסטים מוצלחים יותר שלו, אבל גם זה ספציפית לא […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41838")[#strong[#text("Seb Paquet (sebpaquet) 's status on Thursday, 15-Oct-09 11:16:29 UTC - Identi.ca")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2009")]

#text("[…] A speech for the American Academy of Arts and Sciences « What’s new a few seconds ago from seesmic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-41855")[#strong[#text("Harold Jarche » Friday’s Finds #22")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2009")]

#text("[…] medalist Terry Tao has seen the future of academic work, and it is networked and collaborative: via […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4da9015591fa1b5728116bbb8d844e11f5c44030778498aace88de667285c72-aeb86f10576beed57f1ae674e5ddadb62778952354eed066cc5e44026f93d7b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of toni")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-42440")[#strong[#text("toni")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2009")])]

#text("NSA and GCHQ do “pure” mathematics? No, they hire proffessionals to do mathematic jobs only")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/760ddd8bad27c570c5995a8ca954c5a38fd4fac69f38771b25a6b6db36d6b11e-4ad57592ce78782880a2c818635ada04dd6ba4cba69ace173598d068d4466749.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Romain Viguier")]], [#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/#comment-477785")[#strong[#text("Romain Viguier")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2017")])]

#text("I entirely agree with this text and I recognize myself in it. I am not in mathematics but in an other scientific formation. But the mathematics approach grow in me and internet, through podcast blogs (Thanks Prof Tao for your blog) online course website etc, allow me to be trained and to be stimulate. It does not take much to change a career and internet help me to change my way of doing science.")
]
