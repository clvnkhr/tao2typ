// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/
// Converted to Typst by tao2typ: "2026-10-14T07:11:35.360678+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Proposed stimulus amendment eliminates $1.4 billion in NSF funding", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Proposed stimulus amendment eliminates $1.4 billion in NSF funding")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 February 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/")[#text("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I came across the following news item today which might be of interest to many of the readers of this blog: as part of ")#link("http://www.nytimes.com/2009/02/06/us/politics/06stimulus.html")[#text("a bipartisan effort")]#text(" (headed by Sen. ")#link("http://en.wikipedia.org/wiki/Susan_Collins")[#text("Susan Collins")]#text(" (R-ME) and Sen. ")#link("http://en.wikipedia.org/wiki/Ben_Nelson")[#text("Ben Nelson")]#text(" (D-NE)) to reduce the size of the U.S. federal government stimulus package (currently at over $900 billion) by about $77 billion, the entire appropriation for the ")#link("http://www.nsf.gov/")[#text("National Science Foundation")]#text(" (NSF) in the package ($1.4 billion – about 0.15% of the entire stimulus package) ")#link("http://www.talkingpointsmemo.com/docs/Collins-Nelson-Cuts/?resultpage=2&")[#text("is being proposed to be eliminated")]#text(", with significant cuts in related agencies (NASA, DOE office of science, NOAA, etc.). The $1.4 billion for the NSF in the Senate version of the package is already a reduction from the $2.5 billion allocated in ")#link("http://appropriations.house.gov/pdf/RecoveryBill01-15-09.pdf")[#text("the House version")]#text(".")

#text("For comparison, the entire 2009FY budget for the NSF is $6.9 billion, or about 0.5% of the ")#link("http://en.wikipedia.org/wiki/2009_United_States_federal_budget")[#text("discretionary federal budget ")]#text("of $1.21 trillion.")

#text("[Full disclosure: a majority of my own research funding comes from the NSF.]")

#text("[")#emph[#text("Update")]#text(", Feb 8: It now appears that $1.2 billion of the funding for the NSF ")#link("http://www.sciencedebate2008.com/www/index.php?id=60")[#text("has been restored")]#text(" in a Senate compromise.]")

#text("[")#emph[#text("Update")]#text(", Feb 12: After the House/Senate reconciliation process, the amount allocated to the NSF has ")#link("http://www.buffalonews.com/nationalworld/national/story/576760.html")[#text("been increased to $3 billion")]#text(". Thanks to Alex Iosevich for the link. See also ")#link("http://www.sciencedebate2008.com/www/index.php?id=62")[#text("this Sciencedebate update")]#text(".]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (34)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35512")[#strong[#text("Have I mentioned that I hate the Senate? « Secret Blogging Seminar")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")]

#text("[…] Have I mentioned that I hate the Senate? February 6, 2009 Posted by Ben Webster in Off Topic, math life. trackback Before, it was just for their inability to do anything; now, it’s personal. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c396b5630eb16772d67195f3748aa9487d7c592d5e020d0fa957a817a0815d51-923336261856245560a3ee88f9a89ce0a5d1f5edac1c8529e3ff616f3c37f829.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zach")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35514")[#strong[#text("Zach")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("Note that the $1.4B amount currently in the bill is already less than half the amount approved by the House.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/663a319d112e69e9ebe5a1b81f16f1ca183e5d127ae5c1b2eb1aa87baa96d805-9c2595793d0d8578034c0ba335aafa11d92c659623bbeba487d9b6abfbd10acd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jatkesha")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35516")[#strong[#text("Jatkesha")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("Dear Prof. Tao,")

#text("It is indeed sad to get to know this. Just because of an excessive greed to hoard money (how else can you explain the fall of Wall street, poor regulations in the banking sector and recession thereby?) science and research funding has to suffer. Eliminating $1.4 billion in NSF funding is going to affect the progress of science.")

#text("What else can explain it better apart from this small note on PhD comics?")

#text("“It’s official – Times are tough. Actual excerpt from the Dean’s newsletter, Stanford University: “The new policy suspends provision of food and beverages from School funds for meetings and other events… Some events will be rescheduled, where feasible, so that they don’t coincide with meal times.”")#linebreak()#text(" And this is from the School of Medicine. Yikes!”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zygmund")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35519")[#strong[#text("Zygmund")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("It is disappointing to see the widespread hostility to science that seems to infect both ends of the political spectrum. I don’t know how effective this stimulus will be, but it is clear that science is a valuable investment that deserves large amounts of federal money, especially in areas such as energy research. Climate change and renewable energy–in my opinion, the most important long-term issue of our time—has been ignored under eight years of a profoundly anti-science administration; they cannot afford to wait.")

#text("Alas, if only there were more lobbyists for science…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35520")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("Question: is it 1.4 billion from the NSF budget or 1.4 extra from the stimulus package that is in addition to the normal budget? The two things are very different.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ed591a8639a79145739e121eec53a04725c9a44105341e622a33542fd9c7c7b-06eca9adb9f8e353aa0e8cf42153be05002641b523696ef850f8fbacce644b8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Watson")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35522")[#strong[#text("George Watson")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("If the stimulus package is designed to stimulate4 gorwth and jobs in areas that will help the US have a larger economic base in the future then science and discoveries which could lead to new industries and efficiencies should definitely be funded.")

#text("In fact It’s mor eimportant to fund those things which pay off forever and add real productivity gains than it is to repair old roads.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35523")[#strong[#text("Mortgaging the future : Core Economics")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")]

#text("[…] Apparently some US politicians want to cut the size the stimulus by cutting $1.4b in NSF funding. Now that is what I call mortgaging the future. From Terry Tao: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aca453954697305e76c6379314a1048c45ec31be10491409bb6e47ab15b5b6c3-7058258cc1ee2cc089b342c45cc56cee8861dffa22fe21b686b6aadcb74e6529.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LwoodPDowd")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35525")[#strong[#text("LwoodPDowd")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("This is not as bad as people make it, it actually might be a good thing. Adding 1.4 or 2.5 to the budget as part of the stimulus would make it harder to get an increase in funding in the final budget when it comes time. The science budget would be better served with a year in year out increase than a one time expenditure. Large one time outputs would likely get allocated to large expensive (and often overpriced due to lack of competition) equipment, rather than increase numbers of cheap (grad students and postdocs) and not so cheap (technicians and research associates) employees.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4489b710d4ad7582bfcb7612b09a200694886caf9a737283ce707cae21d27ff1-fda1d09402381232d34e50de4ceaf2a21e324d08b0492dad70ef7ae093c63f43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Patrick")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35527")[#strong[#text("Patrick")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("This is idiotic. Most of the things that I saw in the list of cuts seemed like either (1) good ideas or (2) things that I don’t see as particular useful, but that I can see being very important to others.")

#text("Mainly though, they managed to cut the price of the Bill by cutting funding to federal agencies that do research(not just NSF at all). How can they possibly think that this is a good way to save money? Why are they even concerned with cutting the cost?")

#text("This is a bunch of politicians sacrificing our future so that they can claim they won a concession when they return to their districts. Idiotic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35533")[#strong[#text("Science in the recent stimulus « Shell Beach")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")]

#text("[…] a comment » Prodded by prof Tao’s post, I spent a little too much time sifting through official documents on the congressional budget as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf6123cf3bf3561e11f1ca0cbca58ba8ed8c8d917ecede1d547749198e6feb41-071cf3a8f664e450e67ee93785383ba1e364e6e40e108f8bd1adf02519911458.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of llabesab")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35544")[#strong[#text("llabesab")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("All Liberals constantly harp on those poor ratings of Pres. Bush. Congress, especially the Senate, wishes their ratings were as high. But, of course, the “…grass always looks greener…”. Pres. Obama’s ratings are in free-fall. Wait a few more month’s and even the most leftist of Liberals will be complaining,”…wow, 4 more years of Bush.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/924e4e6df6e997eb48b19feac272c60d828397e0007268ac2b5cb4094be7204a-aa8bf4b28b674cc2771a0dbb520e5130c143afb8f26598d2918751a42ce6af7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Concerned Researcher")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35553")[#strong[#text("Concerned Researcher")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("For what it is worth, everyone should submit their comment to the whitehouse website and on the senators websites, asking that the funding not be cut.")

#link("http://www.whitehouse.gov/contact/")[#text("http://www.whitehouse.gov/contact/")]

#link("http://collins.senate.gov/public/continue.cfm?FuseAction=ContactSenatorCollins.EmailIssue&CFID=5412275&CFTOKEN=36415723")[#text("http://collins.senate.gov/public/continue.cfm?FuseAction=ContactSenatorCollins.EmailIssue&CFID=5412275&CFTOKEN=36415723")]

#link("http://bennelson.senate.gov/contact/email.cfm")[#text("http://bennelson.senate.gov/contact/email.cfm")]

#text("Here’s what I wrote on whitehouse form. Please write your own.")

#text("“Kindly DO NOT eliminate additional funding for National Science Foundation from the stimulus bill. NSF is critical in funding most of high quality science and engineering research across the country. NSF has suffered tremendously under Bush due to lack of budget increase. We spend more in Iraq in 3 weeks than we fund NSF in the entire year. Bright students no longer find graduate studies in US as attractive, and bright researchers increasingly go abroad. Please DO NOT CUT NSF FUNDING. Thanks.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab16edac0e5c9cfd1b9b7fe24a39a921fab0961fdeb1339a4d0b004194906774-a97ed6e9a6aec06fbbd8ec5fe1d55a6cfd06a959362356c42320869110f5e406.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Savitt")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35560")[#strong[#text("David Savitt")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("I gather that $1.2B for NSF made it back into last night’s compromise. See ")#link("http://www.politico.com/blogs/glennthrush/0209/List_of_spending_cuts_in_Senate_bill.html")[#text("here")]#text(" for more details. Assuming that this version of the bill passes the Senate, one can also hope that the NSF amount might grow in conference, since this is less than half of the amount in the House version of the bill.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35565")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("A history of NSF budgets: (")#link("http://dellweb.bfa.nsf.gov/NSFHist_constant.htm")[#text("http://dellweb.bfa.nsf.gov/NSFHist_constant.htm")]#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35566")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("Sorry, but I disagree. NSF grants are based on high quality, peer-reviewed research. A sudden infusion of funds that are to be spent by NSF in 120 days indicates that there will be no time for the full peer-review process. In other words, the funding will be given to proposals that did not make the cut in recent panel reviews, or as add ons to existing grants. This is not the way to fund research. Also, for the next fiscal year, when NSF comes to Congress with a request for increased funding, Congress will say “Well we just gave you x billions”.")#linebreak()#text(" The right way to do it is to consistently increase NSF funding so that the success rate increases. But everything should be based on a full peer reviewed process. I would much prefer that the current stimulus be spent on roads and bridges.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35567")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("Let me be the one who disagrees with the prevailing sentiment in this thread. First, of course I agree that the funding for science agencies should be increased, in particular for NSF, which also happens to be my own main funding source.")

#text("But I am not sure that a stimulus bill is the right place to do so. My understanding is that the point of this bill is the ")#strong[#text("immediate")]#text(" creation of jobs and consumer spending. While a higher NSF budget will also have an effect in this realm, by creating more RA, lab technician, etc. positions, it seems like that effect would be much smaller than for other types of spending. So I can see why an increase in science funding would not fit the “stimulus” part.")

#text("But of course, we need to increase science funding for the medium and long term development of the country and world. I think the right place to put the increase would be the next federal budget. If it doesn’t happen there, then I will join the chorus of this thread.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e3346e58ada8c56ed0777da8d2f1799db4d4067d3d4ce7b5275e969513dc309-4f56ccd300442e395594bf7ba9f6df05fff080792c398b992b5a6230140827f5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35575")[#strong[#text("Max")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("Losses in university endowments mean hiring freezes and other cuts. If this contraction continues for a bit it will be hard to recover robust development in the “medium and long term”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0cf49708872e932bfb728cf0dd2856349243608e414feea6eb3a6487ba6cf0e2-37a4f2b8ee19ad1e526227fe242f60c989b5dfc49bb33831337c9f26e3856fb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Votive Candles")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35576")[#strong[#text("Votive Candles")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("The thing that urks me about this whole bill passing event are the words partisan and bipartisan. These words shouldn’t exist in the politic realm.")#linebreak()#text(" These senators no longer represent the people who voted for them. They don’t cast there vote based on what the people who voted them in want anymore. They cast there votes based on what there party lines and what there special interest groups want them to vote on.")

#text("I don’t think thats what America is suppose to be.")

#text("P.S. Ask what you can do for your country not what your country can do for you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a04279598bd3c60aef14590d27dd6e987d2f79bc6fa376751d1342628c8756ef-6a958dcc4c01046ae875f74516ab1c05b70ad7320a7fcf25166e7d8751ace274.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wilsonrofishing")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35579")[#strong[#text("wilsonrofishing")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("OK, so they cut 1.4 billion out, now for the other 999 billion. . .")

#text("There may be many laudable things in this bill, but if the purpose of the legislation was to stimulate the economy, not invest in science, medicine, etc.")

#text("Ensuring everyone could buy a brand new ")#link("http://acreofindependence.com/2009/02/07/the-vanishing-point-stimulus/")[#text("Dodge Challenger")]#text("is an example of a way to stimulate the economy fast, by the way. . .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35582")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("Many scientists/programmers/etc. are hired by universities (and other institutions) on short-term renewable contracts. These people are essential to the operation of large scale projects in many fields, but in the current economic climate such contracts are not being renewed, many people are being laid off etc. A supplement to the NSF budget (even a temporary one) will mean in the first place that many of these people will not lose their jobs, and in the second place will mitigate the costs of rebuilding research groups and restarting large projects when and if conditions eventually improve. The “stimulus” bill has at least two functions: one is the creation of jobs and a stimulus to consumer spending; another is to prevent the deterioration of infrastructure (including intellectual infrastructure) while the economy as a whole contracts. I suspect much of this funding increase would go to supplement shortfalls in current (excellent) projects which are funded by multiple sources; I very much doubt there would be a drop in the quality of projects funded.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf6123cf3bf3561e11f1ca0cbca58ba8ed8c8d917ecede1d547749198e6feb41-071cf3a8f664e450e67ee93785383ba1e364e6e40e108f8bd1adf02519911458.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of llabesab")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35598")[#strong[#text("llabesab")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("It’s a “Stimulus Package”, stupid. Unless it can be shown to create new jobs, it doesn’t belong in a stimulus package. In any event, those hot-beds of liberal hogwash, sometimes referred to as “universities, should have most of their funding cut to zero. Maybe these “universities” should stop paying football coaches $2-3 million and divert that amount to research. The University of Chicago, not a bad academic institution, has no interscholastic sports. Doesn’t seem to have hurt their standing. As an example, let anyone name one important research project conducted by Notre Dame. Very few, if any, can. But mention some football stats–and you can’t stop them from talking. But what does anyone care that every university in the US with interscholastic sports pays their football/basketball coaches 5x what they pay their presidents. You give these univesities research grants and they’ll only divert the dollars to turf fields, etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35605")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("Politicians speak a very simple language: jobs and votes.")

#text("So how do mathematicians, scientists, and engineers work well with politicians?")

#text("There’s only one way: create jobs, and explain this process to the voters and the politicians.")

#text("Working alone, mathematicians can do rather little to create jobs. Ditto for scientists. Ditto even for engineers. By working together, however, mathematicians, scientists and engineers can accomplish a great deal … historically, many of humanity’s greatest enterprises have been founded upon this three-way partnership.")

#text("My enormous respect and liking for the “TerryTao” blog, comes largely from the fact that it is a wonderfully effect conduit from the mathematics community, to the broader community of engineers and scientists.")

#text("This technological community-building conduit could usefully have a far broader bandwidth, even than it does at present. Theorem-proving is good, but it is *not* enough.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/776b2c6964b91709ed51dee6e8d6d65cfc71cee5a2023fc97c9a5626d45032cf-05c4c68b25fad1c2c126d338686c9563ce686f3087feef96970b50b8a89740f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jerry")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35609")[#strong[#text("jerry")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("To llabesab above,")

#text("By stating that “you give these univesities research grants and they’ll only divert the dollars to turf fields, etc.,” you obviously don’t know how your federal and university funding works. Well, that the universities pay more to the football coaches than their own presidents is a sign of a large “ill” in this American society, the same that a “sport jock” gets more respect than a “science nerd” in US high schools. I grew up in an Asian country where education is far more valued (and we didn’t words like “jocks” and “nerds”, in fact most so-called “jocks” would get no respect if they are dumb, and can’t get a good grade), and now I am a professor in a US university, I am worried about the future of these college kids in my university — some are brilliant, many are hard-working, but some have no clues that they now need to compete with all the other hard-working and brilliant kids in the world to compete for jobs.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3135b1138db7ec661916cf78a71d775695a97c12eb624b98cfb78d09388ee020-2f7fcf5d81cecef5dbc829dfdf7206bb155e2ca2ccaa152b7d3fbc1863ec3074.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ilya")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35610")[#strong[#text("ilya")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("I agree with the Tom’s reasoning that NSF shouldn’t get money in the stimulus bill simply because the stimulus is supposed to be quick and the NSF process operates slowly.")

#text("Now if we apply this one step further, ideally we’d want to spend money on bridges and roads that we need and that passed public review and cost-benefit analysis of the same quality of NSF’s peer review. Which, of course, is opposite of how the distribution of public money works.")

#text("The funniest and saddest thing simultaneously about this is how politicians are ready to shower lots of money on, e.g. “bringing the internet to every home”, but none on the people who might invent next internet.")

#text("The scientists will still have more clout in 2009 than in 2007 so I won’t worry much about this particular bill though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35611")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("The post of llabesab (“baseball”) raises an important topic—the economics of math, science and engineering education—but goes on to say almost nothing sensible about it.")

#text("(1) State university budgets are shrinking (for reasons everyone understands).")

#text("(2) Our medical school—like most medical schools—derives only a miniscule fraction of its budget from the state … but we are hurting too (for reasons everybody understands).")

#text("(3) Top-tier private universities depend neither on state budgets nor on patient care revenues … but they are hurting too (for reasons everybody understands).")

#text("To state the obvious, there are severe structural problems with the way math, science and engineering education is funded, both in the USA and worldwide.")

#text("There is very little that politicians can do—in the USA or in any other nation—to fix these structural problems (aside from popular, but ineffectual short-term stimulus packages).")

#text("During the twenty-first century, the future of mathematics, science and education is going to be all about jobs. Because planet has literally one billion people who need good, family-supporting jobs, ")#emph[#text("immediately")]#text(".")

#text("So maybe we had all better start thinking a little bit harder—systematically, creatively, and in-detail—about how mathematics, science, and engineering can contribute (on a massive, global scale) to creating these jobs.")

#text("The day we can provide good answers, is the day the politicians (and the entrepreneurs too) will start listening more thoughtfully to what we have to say.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of supper+")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35612")[#strong[#text("supper+")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("Hi Zygmund,")#linebreak()#text(" Renewable energy is not compatible with sprawls. It is puzzling why government scientific advisers are not taking their cue from models of visible matter. E.g., in 1910 van der Waals explained in his Nobel lecture, that particles form pseudoassociations not of chemical origin. How much energy would it take to sustain clusters of high rises? It is not clear if Obama’s government is unified enough to redesign the harmony we have, so for now it is an academic discussion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e50edccfbab96e51759c58b1b20331f22812c6929d427bdd096e64d4bc20b829-f53723222d4c67d3f262db3af68501fc018eb7c9a5f6c8ae029f6b567bdfad77.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rajan")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35626")[#strong[#text("Rajan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("@llabesab, maybe you should try reading for a while instead of talking. Generally I don’t respond to people that misspell “universities” but this one is just too stupid to ignore. Start your reading with this web site:")

#link("http://athletics.uchicago.edu/")[#text("http://athletics.uchicago.edu/")]

#text("and then read the research that this guy does (if you don’t understand how excellent it is, none of us will be surprised):")

#link("http://www.nd.edu/~pkamat/")[#text("http://www.nd.edu/~pkamat/")]

#text("As said before, none of the NSF funding goes to sports, but of course you would have known that if you spent a bit more time reading.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35646")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("Unfortunately, the cut can partly be blamed for terrible timing and terrible PR. Here’s an article about NSF porn surfing that came out exactly when the Senate bill was being debated:")#linebreak()#text(" ")#link("http://tinyurl.com/cfm7dv")[#text("http://tinyurl.com/cfm7dv")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/79a190795d80e8c530d4a698e6be06bac867e32eed945b944b9cc603f8f83754-717d77f039a97e939bab0746ac8ac93e3d6f29dd80ba56d28d6bf76de4a9939f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of none")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35658")[#strong[#text("none")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2009")])]

#text("Scott Aaronson has also blogged about this[1], giving a link to an American Physical Society sample letter:")

#text("Speaking of Public Understanding of Science: as you may have heard, much of the future of American science now hinges on whether the Senate, as it haggles over the $800B stimulus, decides to sprinkle a breadcrumb or two off the table for us. If there was ever a time to email your Senator’s office, and have a staff person check a box marked “constituent complaining about science funding” in your name, it’s probably this week. The APS has drafted a letter[2] for you.")

#text("[1] ")#link("http://scottaaronson.com/blog/?p=385")[#text("http://scottaaronson.com/blog/?p=385")]#linebreak()#text(" [2] ")#link("http://www.congressweb.com/cweb4/index.cfm?orgcode=apspa&hotissue=81")[#text("http://www.congressweb.com/cweb4/index.cfm?orgcode=apspa&hotissue=81")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35722")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("It appears that the House version of the NSF funding has prevailed:")

#link("http://www.sciencedebate2008.com/www/index.php?id=62")[#text("http://www.sciencedebate2008.com/www/index.php?id=62")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5650b942fbc8479d53950a3ff4cc60804d8a8da1ae7e15aac1526445b0d0730-28fbc98b0d395fa11071b7f908d6e39ca4e82070d2e34216d3b702914b5272f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roger")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35792")[#strong[#text("Roger")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2009")])]

#text("So the NSF is getting $3B in the stimulus bill, in addition to the annual $6B that it already gets. So it was a false alarm. The NSF will be swimming in so much cash that it won’t know what to do with it all.")#linebreak()#text(" ")#link("http://www.math.columbia.edu/~woit/wordpress/?p=1601")[#text("http://www.math.columbia.edu/~woit/wordpress/?p=1601")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zygmund")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35872")[#strong[#text("Zygmund")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2009")])]

#text("Renewable energy will only become competitive if more research is done, and incentives are introduced to raise the price of CO2 emissions, e.g. through a Pigovian carbon tax or a cap-and-trade mechanism.* Nuclear energy is also worth expanding.")

#text("Anyway, it is good to hear that the money is back and has actually increased.")

#text("*Which, of course, Obama has promised. That’s a vow we can’t afford to let him break.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bipartisan ford")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-35909")[#strong[#text("bipartisan ford")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("Hi Zygmund,")#linebreak()#text(" Nuclear devices are quite dangerous. E.g., what do you think about earlier this month affair in the middle of heavy seas Atlantic incident: nuclears HMS Vanguard and Le Triomphant were badly damaged in a slow speed collision, the MoD has confirmed. First Sea Lord Admiral Sir Jonathon Band said no injuries were reported. Both the UK and France insist nuclear security had not ben compromised. Ps HMS Vanguard, with “very visible dents and scrapes”, was towed back to its home base at Faslane on the Firth of Clyde. Le Triomphant is based at L’Ile Longue near Brest.")#linebreak()#text(" ")#link("http://news.bbc.co.uk/2/hi/uk_news/7892294.stm")[#text("http://news.bbc.co.uk/2/hi/uk_news/7892294.stm")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Presidential address at the National Academy of Sciences « What’s new")]], [#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/#comment-38396")[#strong[#text("Presidential address at the National Academy of Sciences « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("[…] yet implemented; this is distinct from the one-time funding from the stimulus package discussed in this previous post), leading in particular to a tripling in the number of NSF graduate research fellowships; and a […]")
]
