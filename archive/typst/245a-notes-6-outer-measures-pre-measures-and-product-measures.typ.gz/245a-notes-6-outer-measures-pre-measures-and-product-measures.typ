// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/
// Converted to Typst by tao2typ: "2026-10-30T13:14:59.993638+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245A, Notes 6: Outer measures, pre-measures, and product measures", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245A, Notes 6: Outer measures, pre-measures, and product measures")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 October 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/")[#text("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-30 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In this course so far, we have focused primarily on one specific example of a countably additive measure, namely ")#link("http://en.wikipedia.org/wiki/Lebesgue_measure")[#text("Lebesgue measure")]#text(". This measure was constructed from a more primitive concept of ")#emph[#text("Lebesgue outer measure")]#text(", which in turn was constructed from the even more primitive concept of ")#emph[#text("elementary measure")]#text(".a")#linebreak()#text(" It turns out that both of these constructions can be abstracted. In this set of notes, we will give the ")#link("http://en.wikipedia.org/wiki/Carath%C3%A9odory's_theorem_(measure_theory)")[#text("Carathéodory lemma")]#text(", which constructs a countably additive measure from any abstract outer measure; this generalises the construction of Lebesgue measure from Lebesgue outer measure. One can in turn construct outer measures from another concept known as a ")#link("http://en.wikipedia.org/wiki/Premeasure")[#text("pre-measure")]#text(", of which elementary measure is a typical example.")#linebreak()#text(" With these tools, one can start constructing many more measures, such as ")#link("http://en.wikipedia.org/wiki/Lebesgue%E2%80%93Stieltjes_integration")[#text("Lebesgue-Stieltjes measures")]#text(", ")#link("http://en.wikipedia.org/wiki/Product_measure")[#text("product measures")]#text(", and ")#link("http://en.wikipedia.org/wiki/Hausdorff_measure")[#text("Hausdorff measures")]#text(". With a little more effort, one can also establish the ")#link("http://en.wikipedia.org/wiki/Kolmogorov_extension_theorem")[#text("Kolmogorov extension theorem")]#text(", which allows one to construct a variety of measures on infinite-dimensional spaces, and is of particular importance in the foundations of probability theory, as it allows one to set up probability spaces associated to both discrete and continuous random processes, even if they have infinite length.")#linebreak()#text(" The most important result about product measure, beyond the fact that it exists, is that one can use it to evaluate iterated integrals, and to interchange their order, provided that the integrand is either unsigned or absolutely integrable. This fact is known as the ")#link("http://en.wikipedia.org/wiki/Fubini's_theorem")[#text("Fubini-Tonelli theorem")]#text(", and is an absolutely indispensable tool for computing integrals, and for deducing higher-dimensional results from lower-dimensional ones.")#linebreak()#text(" We remark that these notes omit a very important way to construct measures, namely the ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem")]#text(", but we will defer discussion of this theorem ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("to 245B")]#text(".")#linebreak()#text(" This is the final set of notes in this sequence. If time permits, the course will then begin covering the ")#link("https://terrytao.wordpress.com/category/teaching/245b-real-analysis/")[#text("245B notes")]#text(", starting with the material on ")#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/")[#text("signed measures and the Radon-Nikodym-Lebesgue theorem")]#text(".")

#heading(level: 1)[#strong[#text(" — 1. Outer measures and the Carathéodory extension theorem — ")]]

#text("We begin with the abstract concept of an outer measure.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Abstract outer measure)")]#text(" Let ")#mi("{X}")#text(" be a set. An ")#emph[#text("abstract outer measure")]#text(" (or ")#emph[#text("outer measure")]#text(" for short) is a map ")#mi("{\\mu^*: 2^X \\rightarrow [0,+\\infty]}")#text(" that assigns an unsigned extended real number ")#mi("{\\mu^*(E) \\in [0,+\\infty]}")#text(" to ")#emph[#text("every")]#text(" set ")#mi("{E \\subset X}")#text(" which obeys the following axioms:")

#list(
[#text("(Empty set) ")#mi("{\\mu^*(\\emptyset)=0}")#text(".")],
[#text("(Monotonicity) If ")#mi("{E \\subset F}")#text(", then ")#mi("{\\mu^*(E) \\leq \\mu^*(F)}")#text(".")],
[#text("(Countable subadditivity) If ")#mi("{E_1, E_2, \\ldots \\subset X}")#text(" is a countable sequence of subsets of ")#mi("{X}")#text(", then ")#mi("{\\mu^* (\\bigcup_{n=1}^\\infty E_n) \\leq \\sum_{n=1}^\\infty \\mu^*(E_n)}")#text(".")]
)
]

#text("Outer measures are also known as ")#emph[#text("exterior measures")]#text(".")#linebreak()#text(" Thus, for instance, Lebesgue outer measure ")#mi("{m^*}")#text(" is an outer measure (see Exercise 4 of ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(") is an outer measure. On the other hand, Jordan outer measure ")#mi("{m^{*,(J)}}")#text(" is only finitely subadditive rather than countably subadditive and thus is not, strictly speaking, an outer measure; for this reason this concept is often referred to as ")#emph[#text("Jordan outer content")]#text(" rather than ")#emph[#text("Jordan outer measure")]#text(".")#linebreak()#text(" Note that outer measures are weaker than measures in that they are merely countably subadditive, rather than countably additive. On the other hand, they are able to measure ")#emph[#text("all")]#text(" subsets of ")#mi("{X}")#text(", whereas measures can only measure a ")#mi("{\\sigma}")#text("-algebra of measurable sets.")#linebreak()#text(" In Definition 1 of ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(", we used Lebesgue outer measure together with the notion of an open set to define the concept of Lebesgue measurability. This definition is not available in our more abstract setting, as we do not necessarily have the notion of an open set. An alternative definition of measurability was put forth in Exercise 17 of ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(", but this still required the notion of a box or an elementary set, which is still not available in this setting. Nevertheless, we can modify that definition to give an abstract definition of measurability:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2 (Carathéodory measurability)")]#text(" Let ")#mi("{\\mu^*}")#text(" be an outer measure on a set ")#mi("{X}")#text(". A set ")#mi("{E \\subset X}")#text(" is said to be ")#emph[#text("Carathéodory measurable")]#text(" with respect to ")#mi("{\\mu^*}")#text(" if one has")

#align(center)[#tao-fit-display[#mitex("\\mu^*(A) = \\mu^*(A \\cap E) + \\mu^*(A \\backslash E)")]]

#text("for ")#emph[#text("every")]#text(" set ")#mi("{A \\subset X}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3 (Null sets are Carathéodory measurable)")]#text(" ")#metadata(none) <tao-be76034d428de14b447c>#text(" Suppose that ")#mi("{E}")#text(" is a null set for an outer measure ")#mi("{\\mu^*}")#text(" (i.e. ")#mi("{\\mu^*(E) = 0}")#text("). Show that ")#mi("{E}")#text(" is Carathéodory measurable with respect to ")#mi("{\\mu^*}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4 (Compatibility with Lebesgue measurability)")]#text(" ")#metadata(none) <tao-60205d1d0633a41686db>#text(" Show that a set ")#mi("{E \\subset {\\bf R}^d}")#text(" is Carathéodory measurable with respect to Lebesgue outer measure if and only if it is Lebesgue measurable. (")#emph[#text("Hint:")]#text(" one direction follows from Exercise 17 of ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(". For the other direction, first verify simple cases, such as when ")#mi("{E}")#text(" is a box, or when ")#mi("{E}")#text(" or ")#mi("{A}")#text(" are bounded.)")
]

#text("The construction of Lebesgue measure can then be abstracted as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Carathéodory lemma)")]#text(" Let ")#mi("{\\mu^*: 2^X \\rightarrow [0,+\\infty]}")#text(" be an outer measure on a set ")#mi("{X}")#text(", let ")#mi("{{\\mathcal B}}")#text(" be the collection of all subsets of ")#mi("{X}")#text(" that are Carathéodory measurable with respect to ")#mi("{\\mu^*}")#text(", and let ")#mi("{\\mu: {\\mathcal B} \\rightarrow [0,+\\infty]}")#text(" be the restriction of ")#mi("{\\mu^*}")#text(" to ")#mi("{{\\mathcal B}}")#text(" (thus ")#mi("{\\mu(E) := \\mu^*(E)}")#text(" whenever ")#mi("{E \\in {\\mathcal B}}")#text("). Then ")#mi("{{\\mathcal B}}")#text(" is a ")#mi("{\\sigma}")#text("-algebra, and ")#mi("{\\mu}")#text(" is a measure.")
]

#emph[#text("Proof:")]#text(" We begin with the ")#mi("{\\sigma}")#text("-algebra property. It is easy to see that the empty set lies in ")#mi("{{\\mathcal B}}")#text(", and that the complement of a set in ")#mi("{{\\mathcal B}}")#text(" lies in ")#mi("{{\\mathcal B}}")#text(" also. Next, we verify that ")#mi("{{\\mathcal B}}")#text(" is closed under finite unions (which will make ")#mi("{{\\mathcal B}}")#text(" a Boolean algebra). Let ")#mi("{E, F \\in {\\mathcal B}}")#text(", and let ")#mi("{A \\subset X}")#text(" be arbitrary. By definition, it suffices to show that ")#metadata(none) <tao-ba3d4b19f4deaa8fb663>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\mu^*(A) = \\mu^*( A \\cap (E \\cup F) ) + \\mu^*( A \\backslash (E \\cup F) ).")]]

#text("To simplify the notation, we partition ")#mi("{A}")#text(" into the four disjoint sets")

#tao-aligned(keep: true)[


#tao-math("A_{00}  & := A \\backslash (E \\cup F); \\quad A_{10} := (A \\backslash F) \\cap E;", block: true)



#tao-math("A_{01}  & := (A \\backslash E) \\cap F; \\quad A_{11} := A \\cap E \\cap F", block: true)
]

#text("(the reader may wish to draw a Venn diagram here to understand the nature of these sets). Thus ")#link(<tao-ba3d4b19f4deaa8fb663>)[#text("(1)")]#text(" becomes ")#metadata(none) <tao-27a179a88f7d9b6f887c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\mu^*(A_{00} \\cup A_{01} \\cup A_{10} \\cup A_{11}) = \\mu^*(A_{01} \\cup A_{10} \\cup A_{11}) + \\mu^*(A_{00}).")]]

#text("On the other hand, from the Carathéodory measurability of ")#mi("{E}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\mu^*(A_{00} \\cup A_{01} \\cup A_{10} \\cup A_{11}) = \\mu^*(A_{00} \\cup A_{01}) + \\mu^*(A_{10} \\cup A_{11})")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\mu^*(A_{01} \\cup A_{10} \\cup A_{11}) = \\mu^*(A_{01}) + \\mu^*(A_{10} \\cup A_{11})")]]

#text("while from the Carathéodory measurability of ")#mi("{F}")#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\mu^*(A_{00} \\cup A_{01}) = \\mu^*(A_{00}) + \\mu^*(A_{01});")]]

#text("putting these identities together we obtain ")#link(<tao-27a179a88f7d9b6f887c>)[#text("(2)")]#text(". (Note that no subtraction is employed here, and so the arguments still work when some sets have infinite outer measure.)")#linebreak()#text(" Now we verify that ")#mi("{{\\mathcal B}}")#text(" is a ")#mi("{\\sigma}")#text("-algebra. As it is already a Boolean algebra, it suffices (see Exercise ")#link(<tao-4ad58e4451be79c7ace6>)[#text("6")]#text(" below) to verify that ")#mi("{{\\mathcal B}}")#text(" is closed with respect to countable disjoint unions. Thus, let ")#mi("{E_1, E_2, \\ldots}")#text(" be a sequence of disjoint Carathéodory-measurable sets, and let ")#mi("{A}")#text(" be arbitrary. We wish to show that")

#align(center)[#tao-fit-display[#mitex("\\mu^*(A) = \\mu^*(A \\cap \\bigcup_{n=1}^\\infty E_n) + \\mu^*(A \\backslash \\bigcup_{n=1}^\\infty E_n).")]]

#text("In view of subadditivity, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\mu^*(A) \\geq \\mu^*(A \\cap \\bigcup_{n=1}^\\infty E_n) + \\mu^*(A \\backslash \\bigcup_{n=1}^\\infty E_n).")]]

#text("For any ")#mi("{N \\geq 1}")#text(", ")#mi("{\\bigcup_{n=1}^N E_n}")#text(" is Carathéodory measurable (as ")#mi("{{\\mathcal B}}")#text(" is a Boolean algebra), and so")

#align(center)[#tao-fit-display[#mitex("\\mu^*(A) \\geq \\mu^*(A \\cap \\bigcup_{n=1}^N E_n) + \\mu^*(A \\backslash \\bigcup_{n=1}^N E_n).")]]

#text("By monotonicity, ")#mi("{\\mu^*(A \\backslash \\bigcup_{n=1}^N E_n) \\geq \\mu^*(A \\backslash \\bigcup_{n=1}^\\infty E_n)}")#text(". Taking limits as ")#mi("{N \\rightarrow \\infty}")#text(", it thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\mu^*(A \\cap \\bigcup_{n=1}^\\infty E_n) \\leq \\lim_{N \\rightarrow \\infty} \\mu^*(A \\cap \\bigcup_{n=1}^N E_n).")]]

#text("But by the Carathéodory measurability of ")#mi("{\\bigcup_{n=1}^N E_n}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\mu^*(A \\cap \\bigcup_{n=1}^{N+1} E_n) = \\mu^*(A \\cap \\bigcup_{n=1}^N E_n) + \\mu^*( A \\cap E_{N+1})")]]

#text("for any ")#mi("{N \\geq 0}")#text(", and thus on iteration")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty} \\mu^*(A \\cap \\bigcup_{n=1}^N E_n) = \\sum_{N=0}^\\infty \\mu^*( A \\cap E_{N+1})")]]

#text("On the other hand, from countable subadditivity one has")

#align(center)[#tao-fit-display[#mitex("\\mu^*(A \\cap \\bigcup_{n=1}^\\infty E_n) \\leq \\sum_{N=0}^\\infty \\mu^*( A \\cap E_{N+1})")]]

#text("and the claim follows.")#linebreak()#text(" Finally, we show that ")#mi("{\\mu}")#text(" is a measure. It is clear that ")#mi("{\\mu(\\emptyset)=0}")#text(", so it suffices to establish countable additivity, thus we need to show that")

#align(center)[#tao-fit-display[#mitex("\\mu^*( \\bigcup_{n=1}^\\infty E_n ) = \\sum_{n=1}^\\infty \\mu^*(E_n)")]]

#text("whenever ")#mi("{E_1,E_2,\\ldots}")#text(" are Carathéodory-measurable and disjoint. By subadditivity it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\mu^*( \\bigcup_{n=1}^\\infty E_n ) \\geq \\sum_{n=1}^\\infty \\mu^*(E_n).")]]

#text("By monotonicity it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\mu^*( \\bigcup_{n=1}^N E_n ) = \\sum_{n=1}^N \\mu^*(E_n)")]]

#text("for any finite ")#mi("{N}")#text(". But from the Carathéodory measurability of ")#mi("{\\bigcup_{n=1}^N E_n}")#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\mu^*( \\bigcup_{n=1}^{N+1} E_n ) = \\mu^*( \\bigcup_{n=1}^N E_n ) +\\mu^*(E_{N+1})")]]

#text("for any ")#mi("{N \\geq 0}")#text(", and the claim follows from induction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" ")#metadata(none) <tao-4ad58e4451be79c7ace6>#text(" Let ")#mi("{{\\mathcal B}}")#text(" be a Boolean algebra on a set ")#mi("{X}")#text(". Show that ")#mi("{{\\mathcal B}}")#text(" is a ")#mi("{\\sigma}")#text("-algebra if and only if it is closed under countable ")#emph[#text("disjoint")]#text(" unions, which means that ")#mi("{\\bigcup_{n=1}^\\infty E_n \\in {\\mathcal B}}")#text(" whenever ")#mi("{E_1, E_2, E_3, \\ldots \\in {\\mathcal B}}")#text(" are a countable sequence of ")#emph[#text("disjoint")]#text(" sets in ")#mi("{{\\mathcal B}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" Note that the above theorem, combined with Exercise ")#link(<tao-60205d1d0633a41686db>)[#text("4")]#text(" gives a slightly alternate way to construct Lebesgue measure from Lebesgue outer measure than the construction given in ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(". This is arguably a more efficient way to proceed, but is also less geometrically intuitive than the approach taken in ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" From Exercise ")#link(<tao-be76034d428de14b447c>)[#text("3")]#text(" we see that the measure ")#mi("{\\mu}")#text(" constructed by the Carathéodory lemma is automatically ")#link("http://en.wikipedia.org/wiki/Complete_measure")[#text("complete")]#text(", in the sense that any sub-null set for ")#mi("{\\mu}")#text(" (a subset of a null set for ")#mi("{\\mu}")#text(") is also a null set.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" In 245C we will give an important example of a measure constructed by Carathéodory’s lemma, namely the ")#mi("{d}")#text("-dimensional ")#emph[#text("Hausdorff measure")]#text(" ")#mi("{{\\mathcal H}^d}")#text(" on ")#mi("{{\\bf R}^n}")#text(" that is good for measuring the size of ")#mi("{d}")#text("-dimensional subsets of ")#mi("{{\\bf R}^n}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 2. Pre-measures — ")]]

#text("In previous notes, we saw that finitely additive measures, such as elementary measure or Jordan measure, could be extended to a countably additive measure, namely Lebesgue measure. It is natural to ask whether this property is true in general. In other words, given a finitely additive measure ")#mi("{\\mu_0: {\\mathcal B}_0 \\rightarrow [0,+\\infty]}")#text(" on a Boolean algebra ")#mi("{{\\mathcal B}_0}")#text(", is it possible to find a ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}}")#text(" refining ")#mi("{{\\mathcal B}_0}")#text(", and a countably additive measure ")#mi("{\\mu: {\\mathcal B} \\rightarrow [0,+\\infty]}")#text(" that extends ")#mi("{\\mu_0}")#text("?")#linebreak()#text(" There is an obvious necessary condition in order for ")#mi("{\\mu_0}")#text(" to have a countably additive extension, namely that ")#mi("{\\mu_0}")#text(" already has to be countably additive ")#emph[#text("within ")#mi("{{\\mathcal B}_0}")]#text(". More precisely, suppose that ")#mi("{E_1, E_2, E_3, \\ldots \\in {\\mathcal B}_0}")#text(" were disjoint sets such that their union ")#mi("{\\bigcup_{n=1}^\\infty E_n}")#text(" was also in ")#mi("{{\\mathcal B}_0}")#text(". (Note that this latter property is not automatic as ")#mi("{{\\mathcal B}_0}")#text(" is merely a Boolean algebra rather than a ")#mi("{\\sigma}")#text("-algebra.) Then, in order for ")#mi("{\\mu_0}")#text(" to be extendible to a countably additive measure, it is clearly necessary that")

#align(center)[#tao-fit-display[#mitex("\\mu_0( \\bigcup_{n=1}^\\infty E_n ) = \\sum_{n=1}^\\infty \\mu_0(E_n).")]]

#text("Using the Carathéodory lemma, we can show that this necessary condition is also sufficient. More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 10 (Pre-measure)")]#text(" A ")#emph[#text("pre-measure")]#text(" on a Boolean algebra ")#mi("{{\\mathcal B}_0}")#text(" is a finitely additive measure ")#mi("{\\mu_0: {\\mathcal B}_0 \\rightarrow [0,+\\infty]}")#text(" with the property that ")#mi("{\\mu_0( \\bigcup_{n=1}^\\infty E_n ) = \\sum_{n=1}^\\infty \\mu_0(E_n)}")#text(" whenever ")#mi("{E_1,E_2,E_3,\\ldots \\in {\\mathcal B}_0}")#text(" are disjoint sets such that ")#mi("{\\bigcup_{n=1}^\\infty E_n}")#text(" is in ")#mi("{{\\mathcal B}_0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]

#enum(start: 1, 
[#text("Show that the requirement that ")#mi("{\\mu_0}")#text(" is finitely additive could be relaxed to the condition that ")#mi("{\\mu_0(\\emptyset)=0}")#text(" without affecting the definition of a pre-measure.")],
[#text("Show that the condition ")#mi("{\\mu_0( \\bigcup_{n=1}^\\infty E_n ) = \\sum_{n=1}^\\infty \\mu_0(E_n)}")#text(" could be relaxed to ")#mi("{\\mu_0( \\bigcup_{n=1}^\\infty E_n ) \\leq \\sum_{n=1}^\\infty \\mu_0(E_n)}")#text(" without affecting the definition of a pre-measure.")],
[#text("On the other hand, give an example to show that if one performs both of the above two relaxations at once, one starts admitting objects ")#mi("{\\mu_0}")#text(" that are not pre-measures.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" Without using the theory of Lebesgue measure, show that elementary measure (on the elementary Boolean algebra) is a pre-measure. (Hint: use }{Lemma 6} from Notes 1. Note that one has to also deal with co-elementary sets as well as elementary sets in the elementary Boolean algebra.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Construct a finitely additive measure ")#mi("{\\mu_0: {\\mathcal B}_0 \\rightarrow [0,+\\infty]}")#text(" that is not a pre-measure. (")#emph[#text("Hint:")]#text(" take ")#mi("{X}")#text(" to be the natural numbers, take ")#mi("{{\\mathcal B}_0 = 2^{\\bf N}}")#text(" to be the discrete algebra, and define ")#mi("{\\mu_0}")#text(" separately for finite and infinite sets.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14 (Hahn-Kolmogorov theorem)")]#text(" ")#metadata(none) <tao-66b3b534b5a851cc90da>#text(" Every pre-measure ")#mi("{\\mu_0: {\\mathcal B}_0 \\rightarrow [0,+\\infty]}")#text(" on a Boolean algebra ")#mi("{{\\mathcal B}_0}")#text(" in ")#mi("{X}")#text(" can be extended to a countably additive measure ")#mi("{\\mu: {\\mathcal B} \\rightarrow [0,+\\infty]}")#text(".")
]

#emph[#text("Proof:")]#text(" We mimic the construction of Lebesgue measure from elementary measure. Namely, for any set ")#mi("{E \\subset X}")#text(", define the ")#emph[#text("outer measure")]#text(" ")#mi("{\\mu^*(E)}")#text(" of ")#mi("{E}")#text(" to be the quantity")

#align(center)[#tao-fit-display[#mitex("\\mu^*(E) := \\inf \\{ \\sum_{n=1}^\\infty \\mu_0(E_n): E \\subset \\bigcup_{n=1}^\\infty E_n; E_n \\in {\\mathcal B}_0 \\text{ for all } n \\}.")]]

#text("It is easy to verify (cf. Exercise 4 of ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(") that ")#mi("{\\mu^*}")#text(" is indeed an outer measure. Let ")#mi("{{\\mathcal B}}")#text(" be the collection of all sets ")#mi("{E \\subset X}")#text(" that are Carathéodory measurable with respect to ")#mi("{\\mu^*}")#text(", and let ")#mi("{\\mu}")#text(" be the restriction of ")#mi("{\\mu^*}")#text(" to ")#mi("{{\\mathcal B}}")#text(". By the Carathéodory lemma, ")#mi("{{\\mathcal B}}")#text(" is a ")#mi("{\\sigma}")#text("-algebra and ")#mi("{\\mu}")#text(" is a countably additive measure.")#linebreak()#text(" It remains to show that ")#mi("{{\\mathcal B}}")#text(" contains ")#mi("{{\\mathcal B}_0}")#text(" and that ")#mi("{\\mu}")#text(" extends ")#mi("{\\mu_0}")#text(". Thus, let ")#mi("{E \\in {\\mathcal B}_0}")#text("; we need to show that ")#mi("{E}")#text(" is Carathéodory measurable with respect to ")#mi("{\\mu^*}")#text(" and that ")#mi("{\\mu^*(E) = \\mu_0(E)}")#text(". To prove the first claim, let ")#mi("{A \\subset X}")#text(" be arbitrary. We need to show that")

#align(center)[#tao-fit-display[#mitex("\\mu^*(A) = \\mu^*(A \\cap E) + \\mu^*(A \\backslash E);")]]

#text("by subadditivity, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\mu^*(A) \\geq \\mu^*(A \\cap E) + \\mu^*(A \\backslash E).")]]

#text("We may assume that ")#mi("{\\mu^*(A)}")#text(" is finite, since the claim is trivial otherwise.")#linebreak()#text(" Fix ")#mi("{\\varepsilon > 0}")#text(". By definition of ")#mi("{\\mu^*}")#text(", one can find ")#mi("{E_1,E_2,\\ldots \\in {\\mathcal B}_0}")#text(" covering ")#mi("{A}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\mu_0(E_n) \\leq \\mu^*(A)+\\varepsilon.")]]

#text("The sets ")#mi("{E_n \\cap E}")#text(" lie in ")#mi("{{\\mathcal B_0}}")#text(" and cover ")#mi("{A \\cap E}")#text(" and thus")

#align(center)[#tao-fit-display[#mitex("\\mu^*(A \\cap E) \\leq \\sum_{n=1}^\\infty \\mu_0(E_n \\cap E).")]]

#text("Similarly we have")

#align(center)[#tao-fit-display[#mitex("\\mu^*(A \\backslash E) \\leq \\sum_{n=1}^\\infty \\mu_0(E_n \\backslash E).")]]

#text("Meanwhile, from finite additivity we have")

#align(center)[#tao-fit-display[#mitex("\\mu_0(E_n \\cap E) + \\mu_0(E_n \\backslash E) = \\mu_0(E_n).")]]

#text("Combining all of these estimates, we obtain")

#align(center)[#tao-fit-display[#mitex("\\mu^*(A \\cap E) + \\mu^*(A \\backslash E) \\leq \\mu^*(A) + \\varepsilon;")]]

#text("since ")#mi("{\\varepsilon > 0}")#text(" was arbitrary, the claim follows.")#linebreak()#text(" Finally, we have to show that ")#mi("{\\mu^*(E) = \\mu_0(E)}")#text(". Since ")#mi("{E}")#text(" covers itself, we certainly have ")#mi("{\\mu^*(E) \\leq \\mu_0(E)}")#text(". To show the converse inequality, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\mu_0(E_n) \\geq \\mu_0(E)")]]

#text("whenever ")#mi("{E_1,E_2,\\ldots \\in {\\mathcal B}_0}")#text(" cover ")#mi("{E}")#text(". By replacing each ")#mi("{E_n}")#text(" with the smaller set ")#mi("{E_n \\backslash \\bigcup_{m=1}^{n-1} E_m}")#text(" (which still lies in ")#mi("{{\\mathcal B_0}}")#text(", and still covers ")#mi("{E}")#text("), we may assume without loss of generality (thanks to the monotonicity of ")#mi("{\\mu_0}")#text(") that the ")#mi("{E_n}")#text(" are disjoint. Similarly, by replacing each ")#mi("{E_n}")#text(" with the smaller set ")#mi("{E_n \\cap E}")#text(" we may assume without loss of generality that the union of the ")#mi("{E_n}")#text(" is exactly equal to ")#mi("{E}")#text(". But then the claim follows from the hypothesis that ")#mi("{\\mu_0}")#text(" is a pre-measure (and not merely a finitely additive measure). ")#mi("\\Box")#linebreak()#text(" Let us call the measure ")#mi("{\\mu}")#text(" constructed in the above proof the ")#emph[#text("Hahn-Kolmogorov extension")]#text(" of the pre-measure ")#mi("{\\mu_0}")#text(". Thus, for instance, from Exercise ")#link(<tao-60205d1d0633a41686db>)[#text("4")]#text(", the Hahn-Kolmogorov extension of elementary measure (with the convention that co-elementary sets have infinite elementary measure) is Lebesgue measure. This is not quite the unique extension of ")#mi("{\\mu_0}")#text(" to a countably additive measure, though. For instance, one could restrict Lebesgue measure to the Borel ")#mi("{\\sigma}")#text("-algebra, and this would still be a countably additive extension of elementary measure. However, the extension is unique within its own ")#mi("{\\sigma}")#text("-algebra:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" ")#metadata(none) <tao-234225f66642ae73f16f>#text(" Let ")#mi("{\\mu_0: {\\mathcal B}_0 \\rightarrow [0,+\\infty]}")#text(" be a pre-measure, let ")#mi("{\\mu: {\\mathcal B} \\rightarrow [0,+\\infty]}")#text(" be the Hahn-Kolmogorov extension of ")#mi("{\\mu_0}")#text(", and let ")#mi("{\\mu^{\\prime}: {\\mathcal B}^{\\prime} \\rightarrow [0,+\\infty]}")#text(" be another countably additive extension of ")#mi("{\\mu_0}")#text(". Suppose also that ")#mi("{\\mu_0}")#text(" is ")#emph[#mi("{\\sigma}")#text("-finite")]#text(", which means that one can express the whole space ")#mi("{X}")#text(" as the countable union of sets ")#mi("{E_1,E_2,\\ldots \\in {\\mathcal B}_0}")#text(" for which ")#mi("{\\mu_0(E_n) < \\infty}")#text(" for all ")#mi("{n}")#text(". Show that ")#mi("{\\mu}")#text(" and ")#mi("{\\mu^{\\prime}}")#text(" agree on their common domain of definition. In other words, show that ")#mi("{\\mu(E) = \\mu^{\\prime}(E)}")#text(" for all ")#mi("{E \\in {\\mathcal B} \\cap {\\mathcal B}^{\\prime}}")#text(". (Hint: first show that ")#mi("{\\mu^{\\prime}(E) \\leq \\mu^*(E)}")#text(" for all ")#mi("{E \\in {\\mathcal B}^{\\prime}}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" The purpose of this exercise is to show that the ")#mi("{\\sigma}")#text("-finite hypothesis in Exercise ")#link(<tao-234225f66642ae73f16f>)[#text("15")]#text(" cannot be removed. Let ")#mi("{{\\mathcal A}}")#text(" be the collection of all subsets in ")#mi("{{\\bf R}}")#text(" that can be expressed as finite boolean combinations of half-open intervals ")#mi("{[a,b)}")#text(". Let ")#mi("{\\mu_0: {\\mathcal A} \\rightarrow [0,+\\infty]}")#text(" be the function such that ")#mi("{\\mu_0(E)=+\\infty}")#text(" for non-empty ")#mi("{E}")#text(" and ")#mi("{\\mu_0(\\emptyset)=0}")#text(".")

#enum(start: 1, 
[#text("Show that ")#mi("{\\mu_0}")#text(" is a pre-measure.")],
[#text("Show that ")#mi("{\\langle {\\mathcal A} \\rangle}")#text(" is the Borel ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}[{\\bf R}]}")#text(".")],
[#text("Show that the Hahn-Kolmogorov extension ")#mi("{\\mu: {\\mathcal B}[{\\bf R}] \\rightarrow [0,+\\infty]}")#text(" of ")#mi("{\\mu_0}")#text(" assigns an infinite measure to any non-empty Borel set.")],
[#text("Show that counting measure ")#mi("{\\#}")#text(" (or more generally, ")#mi("{c\\#}")#text(" for any ")#mi("{c \\in (0,+\\infty]}")#text(") is another extension of ")#mi("{\\mu_0}")#text(" on ")#mi("{{\\mathcal B}[{\\bf R}]}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" ")#metadata(none) <tao-8e6a0ab2937027144d3c>#text(" Let ")#mi("{\\mu_0: {\\mathcal B}_0 \\rightarrow [0,+\\infty]}")#text(" be a pre-measure which is ")#mi("{\\sigma}")#text("-finite (thus ")#mi("{X}")#text(" is the countable union of sets in ")#mi("{{\\mathcal B_0}}")#text(" of finite ")#mi("{\\mu_0}")#text("-measure), and let ")#mi("{\\mu: {\\mathcal B} \\rightarrow [0,+\\infty]}")#text(" be the Hahn-Kolmogorov extension of ")#mi("{\\mu_0}")#text(".")

#list(
[#text("Show that if ")#mi("{E \\in {\\mathcal B}}")#text(", then there exists ")#mi("{F \\in \\langle {\\mathcal B}_0 \\rangle}")#text(" containing ")#mi("{E}")#text(" such that ")#mi("{\\mu(F \\backslash E) = 0}")#text(" (thus ")#mi("{F}")#text(" consists of the union of ")#mi("{E}")#text(" and a null set). Furthermore, show that ")#mi("{F}")#text(" can be chosen to be a countable intersection ")#mi("{F = \\bigcap_{n=1}^\\infty F_n}")#text(" of sets ")#mi("{F_n}")#text(", each of which is a countable union ")#mi("{F_n = \\bigcup_{m=1}^\\infty F_{n,m}}")#text(" of sets ")#mi("{F_{n,m}}")#text(" in ")#mi("{{\\mathcal B}_0}")#text(".")],
[#text("If ")#mi("{E \\in {\\mathcal B}}")#text(" has finite measure (i.e. ")#mi("{\\mu(E) < \\infty}")#text("), and ")#mi("{\\varepsilon > 0}")#text(", show that there exists ")#mi("{F \\in {\\mathcal B}_0}")#text(" such that ")#mi("{\\mu(E \\Delta F) \\leq \\varepsilon}")#text(".")],
[#text("Conversely, if ")#mi("{E}")#text(" is a set such that for every ")#mi("{\\varepsilon > 0}")#text(" there exists ")#mi("{F \\in {\\mathcal B}_0}")#text(" such that ")#mi("{\\mu^*(E \\Delta F) \\leq \\varepsilon}")#text(", show that ")#mi("{E \\in {\\mathcal B}}")#text(".")]
)
]

#heading(level: 1)[#strong[#text(" — 3. Lebesgue-Stieltjes measure — ")]]

#text("Now we use the Hahn-Kolmogorov extension theorem to construct a variety of measures. We begin with Lebesgue-Stieltjes measure.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 18 (Existence of Lebesgue-Stieltjes measure)")]#text(" Let ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a monotone non-decreasing function, and define the left and right limits")

#align(center)[#tao-fit-display[#mitex("F_-(x) := \\sup_{y<x} F(y); \\quad F_+(x) := \\inf_{y>x} F(y),")]]

#text("thus one has ")#mi("{F_-(x) \\leq F(x) \\leq F_+(x)}")#text(" for all ")#mi("{x}")#text(". Let ")#mi("{{\\mathcal B}[{\\bf R}]}")#text(" be the Borel ")#mi("{\\sigma}")#text("-algebra on ")#mi("{{\\bf R}}")#text(". Then there exists a unique Borel measure ")#mi("{\\mu_F: {\\mathcal B}[{\\bf R}] \\rightarrow [0,+\\infty]}")#text(" such that ")#metadata(none) <tao-3edbf2860e9e8eece078>

#tao-aligned(keep: true)[


#tao-math("\\mu_F( [a,b] )  & = F_+(b)-F_-(a), \\mu_F( [a,b) ) = F_-(b)-F_-(a),", block: true, numbering: n => [#text("(3)")])



#tao-math("\\mu_F( (a,b] )  & = F_+(b)-F_+(a), \\mu_F( (a,b) ) = F_-(b) - F_+(a)", block: true)
]

#text("for all ")#mi("{-\\infty < a < b < \\infty}")#text(", and ")#metadata(none) <tao-04ffaa535b35c6e5d020>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\mu_F( \\{a\\} ) = F_+(a) - F_-(a)")]]

#text("for all ")#mi("{a \\in {\\bf R}}")#text(".")
]

#emph[#text("Proof:")]#text(" (Sketch) For this proof, we will deviate from our previous notational conventions, and allow intervals to be unbounded, thus in particular including the half-infinite intervals ")#mi("{[a,+\\infty)}")#text(", ")#mi("{(a,+\\infty)}")#text(", ")#mi("{(-\\infty,a]}")#text(", ")#mi("{(-\\infty,a)}")#text(" and the doubly infinite interval ")#mi("{(-\\infty,+\\infty)}")#text(" as intervals.")#linebreak()#text(" Define the ")#mi("{F}")#text("-volume ")#tao-math("{\\left|I\\right|_F \\in [0,+\\infty]}", block: false)#text(" of any interval ")#mi("{I}")#text(" to be the required value of ")#mi("{\\mu_F(I)}")#text(" given by ")#link(<tao-3edbf2860e9e8eece078>)[#text("(3)")]#text(" (e.g., ")#tao-math("{\\left|[a,b]\\right|_F = F_+(b)-F_-(a)}", block: false)#text("), adopting the obvious conventions that ")#mi("{F_-(+\\infty) = \\sup_{y \\in {\\bf R}} F(y)}")#text(" and ")#mi("{F_+(-\\infty) = \\inf_{y \\in {\\bf R}} F(y)}")#text(", and also adopting the convention that the empty interval ")#mi("{\\emptyset}")#text(" has zero ")#mi("{F}")#text("-volume, ")#tao-math("{\\left|\\emptyset\\right|_F = 0}", block: false)#text(". Note that ")#mi("{F_-(+\\infty)}")#text(" could equal ")#mi("{+\\infty}")#text(" and ")#mi("{F_+(-\\infty)}")#text(" could equal ")#mi("{-\\infty}")#text(", but in all circumstances the ")#mi("{F}")#text("-volume ")#tao-math("{\\left|I\\right|_F}", block: false)#text(" is well-defined and takes values in ")#mi("{[0,+\\infty]}")#text(", after adopting the obvious conventions to evaluate expressions such as ")#mi("{+\\infty - (-\\infty)}")#text(".")#linebreak()#text(" A somewhat tedious case check (Exercise!) gives the additivity property")

#align(center)[#tao-fit-display[#tao-math("\\left|I \\cup J\\right|_F = \\left|I\\right|_F + \\left|J\\right|_F", block: true)]]

#text("whenever ")#mi("{I}")#text(", ")#mi("{J}")#text(" are disjoint intervals that share a common endpoint, in such a fashion that their union is also an interval. As a corollary, we see that if a interval ")#mi("{I}")#text(" is partitioned into finitely many disjoint sub-intervals ")#mi("{I_1,\\ldots,I_k}")#text(", we have ")#tao-math("{\\left|I\\right| = \\left|I_1\\right|+\\ldots+\\left|I_k\\right|}", block: false)#text(".")#linebreak()#text(" Let ")#mi("{{\\mathcal B}_0}")#text(" be the Boolean algebra generated by the (possibly infinite) intervals, then ")#mi("{{\\mathcal B}_0}")#text(" consists of those sets that can be expressed as a finite union of intervals. (This is slightly larger than the elementary algebra, as it allows for half-infinite intervals such as ")#mi("{[0,+\\infty)}")#text(", whereas the elementary algebra does not.) We can define a measure ")#mi("{\\mu_0}")#text(" on this algebra by declaring")

#align(center)[#tao-fit-display[#tao-math("\\mu_0( E ) = \\left|I_1\\right|_F + \\ldots + \\left|I_k\\right|_F", block: true)]]

#text("whenever ")#mi("{E=I_1 \\cup \\ldots \\cup I_k}")#text(" is the disjoint union of finitely many intervals. One can check (Exercise!) that this measure is well-defined (in the sense that it gives a unique value to ")#mi("{\\mu_0(E)}")#text(" for each ")#mi("{E \\in {\\mathcal B}_0}")#text(") and is finitely additive. We now claim that ")#mi("{\\mu_0}")#text(" is a pre-measure: thus we suppose that ")#mi("{E = {\\mathcal B}_0}")#text(" is the disjoint union of countably many sets ")#mi("{E_1, E_2, \\ldots \\in {\\mathcal B}_0}")#text(", and wish to show that")

#align(center)[#tao-fit-display[#mitex("\\mu_0(E) = \\sum_{n=1}^\\infty \\mu_0(E_n).")]]

#text("By splitting up ")#mi("{E}")#text(" into intervals and then intersecting each of the ")#mi("{E_n}")#text(" with these intervals and using finite additivity, we may assume that ")#mi("{E}")#text(" is a single interval. By splitting up the ")#mi("{E_n}")#text(" into their component intervals and using finite additivity, we may assume that the ")#mi("{E_n}")#text(" are also individual intervals. By finite additivity, we have ")#mi("{ \\mu_0(E) \\geq \\sum_{n=1}^N \\mu_0(E_n)}")#text(" for every ")#mi("{N}")#text(", so it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\mu_0(E) \\leq \\sum_{n=1}^\\infty \\mu_0(E_n).")]]

#text("By the definition of ")#mi("{\\mu_0(E)}")#text(", one can check that ")#metadata(none) <tao-d92f43dbe69f86f7a5d8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\mu_0(E) = \\sup_{K \\subset E} \\mu_0(K)")]]

#text("where ")#mi("{K}")#text(" ranges over all compact intervals contained in ")#mi("{E}")#text(" (Exercise!). Thus, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\mu_0(K) \\leq \\sum_{n=1}^\\infty \\mu_0(E_n)")]]

#text("for each compact sub-interval ")#mi("{K}")#text(" of ")#mi("{E}")#text(". In a similar spirit, one can show that")

#align(center)[#tao-fit-display[#mitex("\\mu_0(E_n) = \\inf_{U \\supset E_n} \\mu_0(U)")]]

#text("where ")#mi("{U}")#text(" ranges over all open intervals containing ")#mi("{E_n}")#text(" (Exercise!). Using the ")#mi("{\\varepsilon/2^n}")#text(" trick, it thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\mu_0(K) \\leq \\sum_{n=1}^\\infty \\mu_0(U_n)")]]

#text("whenever ")#mi("{U_n}")#text(" is an open interval containing ")#mi("{E_n}")#text(". But by the Heine-Borel theorem, one can cover ")#mi("{K}")#text(" by a finite number ")#mi("{\\bigcup_{n=1}^N U_n}")#text(" of the ")#mi("{U_n}")#text(", hence by finite subadditivity")

#align(center)[#tao-fit-display[#mitex("\\mu_0(K) \\leq\\sum_{n=1}^N \\mu_0(U_n)")]]

#text("and the claim follows.")#linebreak()#text(" As ")#mi("{\\mu_0}")#text(" is now verified to be a pre-measure, we may use the Hahn-Kolmogorov extension theorem to extend it to a countably additive measure ")#mi("{\\mu}")#text(" on a ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}}")#text(" that contains ")#mi("{{\\mathcal B}_0}")#text(". In particular, ")#mi("{{\\mathcal B}}")#text(" contains all the elementary sets and hence (by Exercise 14 of ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/")[#text("Notes 3")]#text(") contains the Borel ")#mi("{\\sigma}")#text("-algebra. Restricting ")#mi("{\\mu}")#text(" to the Borel ")#mi("{\\sigma}")#text("-algebra we obtain the existence claim.")#linebreak()#text(" Finally, we establish uniqueness. If ")#mi("{\\mu^{\\prime}}")#text(" is another Borel measure with the stated properties, then ")#tao-math("{\\mu^{\\prime}(K) = \\left|K\\right|_F}", block: false)#text(" for every compact interval ")#mi("{K}")#text(", and hence by ")#link(<tao-d92f43dbe69f86f7a5d8>)[#text("(5)")]#text(" and upward monotone convergence, one has ")#tao-math("{\\mu^{\\prime}(I) = \\left|I\\right|_F}", block: false)#text(" for every interval (including the unbounded ones). This implies that ")#mi("{\\mu^{\\prime}}")#text(" agrees with ")#mi("{\\mu_0}")#text(" on ")#mi("{{\\mathcal B}_0}")#text(", and thus (by Exercise ")#link(<tao-234225f66642ae73f16f>)[#text("15")]#text(", noting that ")#mi("{\\mu_0}")#text(" is ")#mi("{\\sigma}")#text("-finite) agrees with ")#mi("{\\mu}")#text(" on Borel measurable sets. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Verify the claims marked “Exercise!” in the above proof.")
]

#text("The measure ")#mi("{\\mu_F}")#text(" given by the above theorem is known as the ")#link("http://en.wikipedia.org/wiki/Lebesgue-Stieltjes_integration")[#text("Lebesgue-Stieltjes measure")]#text(" ")#mi("{\\mu_F}")#text(" of ")#mi("{F}")#text(". (In some texts, this measure is only defined when ")#mi("{F}")#text(" is right-continuous, or equivalently if ")#mi("{F=F_+}")#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Define a ")#link("http://en.wikipedia.org/wiki/Radon_measure")[#text("Radon measure")]#text(" on ")#mi("{{\\bf R}}")#text(" to be a Borel measure ")#mi("{\\mu}")#text(" obeying the following additional properties:")

#list(
[#text("(Local finiteness) ")#mi("{\\mu(K) < \\infty}")#text(" for every compact ")#mi("{K}")#text(".")],
[#text("(Inner regularity) One has ")#mi("{\\mu(E) = \\sup_{K \\subset E, K \\text{ compact}} \\mu(K)}")#text(" for every Borel set ")#mi("{E}")#text(".")],
[#text("(Outer regularity) One has ")#mi("{\\mu(E) = \\inf_{U \\supset E, U \\text{ open}} \\mu(U)}")#text(" for every Borel set ")#mi("{E}")#text(".")]
)

#text("Show that for every monotone function ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(", the Lebesgue-Stieltjes measure ")#mi("{\\mu_F}")#text(" is a Radon measure on ")#mi("{{\\bf R}}")#text("; conversely, if ")#mi("{\\mu}")#text(" is a Radon measure on ")#mi("{{\\bf R}}")#text(", show that there exists a monotone function ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" such that ")#mi("{\\mu= \\mu_F}")#text(".")
]

#text("Radon measures will be studied in more detail ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("in 245B")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21 (Near uniqueness)")]#text(" If ")#mi("{F, F^{\\prime}:{\\bf R} \\rightarrow {\\bf R}}")#text(" are monotone non-decreasing functions, show that ")#mi("{\\mu_F = \\mu_{F^{\\prime}}}")#text(" if and only if there exists a constant ")#mi("{C \\in {\\bf R}}")#text(" such that ")#mi("{F_+(x) = F^{\\prime}_+(x) + C}")#text(" and ")#mi("{F_-(x) = F^{\\prime}_-(x) + C}")#text(" for all ")#mi("{x \\in {\\bf R}}")#text(". Note that this implies that the value of ")#mi("{F}")#text(" at its points of discontinuity are irrelevant for the purposes of determining the Lebesgue-Stieltjes measure ")#mi("{\\mu_F}")#text("; in particular, ")#mi("{\\mu_F = \\mu_{F_+} = \\mu_{F_-}}")#text(".")
]

#text("In the special case when ")#mi("{F_+(-\\infty)=0}")#text(" and ")#mi("{F_-(+\\infty)=1}")#text(", then ")#mi("{\\mu_F}")#text(" is a probability measure, and ")#mi("{F_+(x) = \\mu_F((-\\infty,x])}")#text(" is known as the ")#link("http://en.wikipedia.org/wiki/Cumulative_distribution_function")[#text("cumulative distribution function")]#text(" of ")#mi("{\\mu_F}")#text(".")#linebreak()#text(" Now we give some examples of Lebesgue-Stieltjes measure.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22 (Lebesgue-Stieltjes measure, absolutely continuous case)")]

#enum(start: 1, 
[#text("If ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" is the identity function ")#mi("{F(x)=x}")#text(", show that ")#mi("{\\mu_F}")#text(" is equal to Lebesgue measure ")#mi("{m}")#text(".")],
[#text("If ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" is monotone non-decreasing and absolutely continuous (which in particular implies that ")#mi("{F^{\\prime}}")#text(" exists and is absolutely integrable, show that ")#mi("{\\mu_F = m_{F^{\\prime}}}")#text(" in the sense of Exercise 47 of ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/")[#text("Notes 3")]#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\mu_F(E) = \\int_E F^{\\prime}(x)\\ dx")]]

#text("for any Borel measurable ")#mi("{E}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} f(x)\\ d\\mu_F(x) = \\int_{\\bf R} f(x) F^{\\prime}(x)\\ dx")]]

#text("for any unsigned Borel measurable ")#mi("{f: {\\bf R} \\rightarrow [0,+\\infty]}")#text(".")]
)
]

#text("In view of the above exercise, the integral ")#mi("{\\int_{\\bf R} f\\ d\\mu_F}")#text(" is often abbreviated ")#mi("{\\int_{\\bf R} f\\ dF}")#text(", and referred to as the ")#link("http://en.wikipedia.org/wiki/Lebesgue-Stieltjes_integration")[#text("Lebesgue-Stieltjes integral")]#text(" of ")#mi("{f}")#text(" with respect to ")#mi("{F}")#text(". In particular, observe the identity")

#align(center)[#tao-fit-display[#mitex("\\int_{[a,b]}\\ dF = F_+(b) - F_-(a)")]]

#text("for any monotone non-decreasing ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" and any ")#mi("{-\\infty < a < b < +\\infty}")#text(", which can be viewed as yet another formulation of the fundamental theorem of calculus.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23 (Lebesgue-Stieltjes measure, pure point case)")]

#enum(start: 1, 
[#text("If ")#mi("{H: {\\bf R} \\rightarrow {\\bf R}}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Heaviside_step_function")[#text("Heaviside function")]#text(" ")#mi("{H := 1_{[0,+\\infty)}}")#text(", show that ")#mi("{\\mu_H}")#text(" is equal to the Dirac measure ")#mi("{\\delta_0}")#text(" at the origin (defined in Example 9 of ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/")[#text("Notes 3")]#text(").")],
[#text("If ")#mi("{F = \\sum_n c_n J_n}")#text(" is a jump function (as defined in Definition 17 of ")#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems")[#text("Notes 5")]#text("), show that ")#mi("{\\mu_F}")#text(" is equal to the linear combination ")#mi("{\\sum c_n \\delta_{x_n}}")#text(" of delta functions (as defined in Exercise 22 of ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/")[#text("Notes 3")]#text("), where ")#mi("{x_n}")#text(" is the point of discontinuity for the basic jump function ")#mi("{J_n}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24 (Lebesgue-Stieltjes measure, singular continuous case)")]

#enum(start: 1, 
[#text("If ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a monotone non-decreasing function, show that ")#mi("{F}")#text(" is continuous if and only if ")#mi("{\\mu_F(\\{x\\})=0}")#text(" for all ")#mi("{x \\in {\\bf R}}")#text(".")],
[#text("If ")#mi("{F}")#text(" is the Cantor function (defined in Exercise 84 of ")#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/")[#text("Notes 5")]#text("), show that ")#mi("{\\mu_F}")#text(" is a probability measure supported on the middle-thirds ")#link("http://en.wikipedia.org/wiki/Cantor_function")[#text("Cantor set")]#text(" (Exercise 10 from ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(") in the sense that ")#mi("{\\mu_F({\\bf R} \\backslash C) = 0}")#text(". The measure ")#mi("{\\mu_F}")#text(" is known as ")#link("http://en.wikipedia.org/wiki/Cantor_measure")[#text("Cantor measure")]#text(".")],
[#text("If ")#mi("{\\mu_F}")#text(" is Cantor measure, establish the self-similarity properties ")#mi("{\\mu( \\frac{1}{3} \\cdot E ) = \\frac{1}{2} \\mu(E)}")#text(" and ")#mi("{\\mu( \\frac{1}{3} \\cdot E + \\frac{2}{3} ) = \\frac{1}{2} \\mu(E)}")#text(" for every Borel-measurable ")#mi("{E \\subset [0,1]}")#text(", where ")#mi("{\\frac{1}{3} \\cdot E := \\{ \\frac{1}{3} x: x \\in E \\}}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25 (Connection with Riemann-Stieltjes integral)")]#text(" ")#metadata(none) <tao-b4c194b68572fb47bee6>#text(" Let ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" be monotone non-decreasing, let ")#mi("{[a,b]}")#text(" be a compact interval, and let ")#mi("{f: [a,b] \\rightarrow {\\bf R}}")#text(" be continuous. Suppose that ")#mi("{F}")#text(" is continuous at the endpoints ")#mi("{a, b}")#text(" of the interval. Show that for every ")#mi("{\\varepsilon > 0}")#text(" there exists ")#mi("{\\delta > 0}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{i=1}^n f(t^*_i) (F(t_i) - F(t_{i-1})) - \\int_{[a,b]} f\\ dF\\right| \\leq \\varepsilon", block: true)]]

#text("whenever ")#mi("{a = t_0 < t_1 < \\ldots < t_n = b}")#text(" and ")#mi("{t^*_i \\in [t_{i-1},t_i]}")#text(" for ")#mi("{1 \\leq i \\leq n}")#text(" are such that ")#tao-math("{\\sup_{1 \\leq i \\leq n} \\left|t_i - t_{i-1}\\right| \\leq \\delta}", block: false)#text(". In the language of the ")#link("http://en.wikipedia.org/wiki/Riemann%E2%80%93Stieltjes_integral")[#text("Riemann-Stieltjes integral")]#text(", this result asserts that the Lebesgue-Stieltjes integral extends the Riemann-Stieltjes integral.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26 (Integration by parts formula)")]#text(" Let ")#mi("{F, G: {\\bf R} \\rightarrow {\\bf R}}")#text(" be monotone non-decreasing and continuous. Show that")

#align(center)[#tao-fit-display[#mitex("\\int_{[a,b]} F\\ dG = - \\int_{[a,b]} G\\ dF + F(b) G(b) - F(a) G(a)")]]

#text("for any compact interval ")#mi("{[a,b]}")#text(". (")#emph[#text("Hint:")]#text(" use Exercise \\ref}{riemstil}.) This formula can be partially extended to the case when one or both of ")#mi("{F, G}")#text(" have discontinuities, but care must be taken when ")#mi("{F}")#text(" and ")#mi("{G}")#text(" are simultaneously discontinuous at the same location.")
]

#heading(level: 1)[#strong[#text(" — 4. Product measure — ")]]

#metadata(none) <tao-345a28a6901ff4628a34>#linebreak()#text(" Given two sets ")#mi("{X}")#text(" and ")#mi("{Y}")#text(", one can form their Cartesian product ")#mi("{X \\times Y = \\{ (x,y): x \\in X, y \\in Y \\}}")#text(". This set is naturally equipped with the coordinate projection maps ")#mi("{\\pi_X: X \\times Y \\rightarrow X}")#text(" and ")#mi("{\\pi_Y: X \\times Y \\rightarrow Y}")#text(" defined by setting ")#mi("{\\pi_X(x,y) := x}")#text(" and ")#mi("{\\pi_Y(x,y) := y}")#text(". One can certainly take Cartesian products ")#mi("{X_1 \\times \\ldots \\times X_d}")#text(" of more than two sets, or even take an infinite product ")#mi("{\\prod_{\\alpha \\in A} X_\\alpha}")#text(", but for simplicity we will only discuss the theory for products of two sets for now.")#linebreak()#text(" Now suppose that ")#mi("{(X,{\\mathcal B}_X)}")#text(" and ")#mi("{(Y,{\\mathcal B}_Y)}")#text(" are measurable spaces. Then we can still form the Cartesian product ")#mi("{X \\times Y}")#text(" and the projection maps ")#mi("{\\pi_X: X \\times Y \\rightarrow X}")#text(" and ")#mi("{\\pi_Y: X \\times Y \\rightarrow Y}")#text(". But now we can also form the ")#link("http://en.wikipedia.org/wiki/Pullback")[#text("pullback")]#text(" ")#mi("{\\sigma}")#text("-algebras")

#align(center)[#tao-fit-display[#mitex("\\pi_X^*({\\mathcal B}_X) := \\{ \\pi_X^{-1}(E): E \\in {\\mathcal B}_X \\} = \\{ E \\times Y: E \\in {\\mathcal B}_X \\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\pi_Y^*({\\mathcal B}_Y) := \\{ \\pi_Y^{-1}(E): E \\in {\\mathcal B}_Y \\} = \\{ X \\times F: F \\in {\\mathcal B}_Y \\}.")]]

#text("We then define the ")#emph[#text("product ")#mi("{\\sigma}")#text("-algebra")]#text(" ")#mi("{{\\mathcal B}_X \\times {\\mathcal B}_Y}")#text(" to be the ")#mi("{\\sigma}")#text("-algebra generated by the union of these two ")#mi("{\\sigma}")#text("-algebras:")

#align(center)[#tao-fit-display[#mitex("{\\mathcal B}_X \\times {\\mathcal B}_Y := \\langle \\pi_X^*({\\mathcal B}_X) \\cup \\pi_Y^*({\\mathcal B}_Y) \\rangle.")]]

#text("This definition has several equivalent formulations:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" ")#metadata(none) <tao-227ad062d6deda524b0a>#text(" Let ")#mi("{(X,{\\mathcal B}_X)}")#text(" and ")#mi("{(Y,{\\mathcal B}_Y)}")#text(" be measurable spaces.")

#enum(start: 1, 
[#text("Show that ")#mi("{{\\mathcal B}_X \\times {\\mathcal B}_Y}")#text(" is the ")#mi("{\\sigma}")#text("-algebra generated by the sets ")#mi("{E \\times F}")#text(" with ")#mi("{E \\in {\\mathcal B}_X}")#text(", ")#mi("{Y \\in {\\mathcal B}_Y}")#text(". In other words, ")#mi("{{\\mathcal B}_X \\times {\\mathcal B}_Y}")#text(" is the coarsest ")#mi("{\\sigma}")#text("-algebra on ")#mi("{X \\times Y}")#text(" with the property that the product of a ")#mi("{{\\mathcal B}_X}")#text("-measurable set and a ")#mi("{{\\mathcal B}_Y}")#text("-measurable set is always ")#mi("{{\\mathcal B}_X \\times {\\mathcal B}_Y}")#text(" measurable.")],
[#text("Show that ")#mi("{{\\mathcal B}_X \\times {\\mathcal B}_Y}")#text(" is the coarsest ")#mi("{\\sigma}")#text("-algebra on ")#mi("{X \\times Y}")#text(" that makes the projection maps ")#mi("{\\pi_X, \\pi_Y}")#text(" both measurable morphisms (see Remark 8 from ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems")[#text("Notes 3")]#text(").")],
[#text("If ")#mi("{E \\in {\\mathcal B}_X \\times {\\mathcal B}_Y}")#text(", show that the sets ")#mi("{E_x := \\{ y \\in Y: (x,y) \\in E \\}}")#text(" lie in ")#mi("{{\\mathcal B}_Y}")#text(" for every ")#mi("{x \\in X}")#text(", and similarly that the sets ")#mi("{E^y := \\{ x \\in X: (x,y) \\in E \\}}")#text(" lie in ")#mi("{{\\mathcal B}_X}")#text(" for every ")#mi("{y \\in Y}")#text(".")],
[#text("If ")#mi("{f: X \\times Y \\rightarrow [0,+\\infty]}")#text(" is measurable (with respect to ")#mi("{{\\mathcal B}_X \\times {\\mathcal B}_Y}")#text("), show that the function ")#mi("{f_x: y \\mapsto f(x,y)}")#text(" is ")#mi("{{\\mathcal B}_Y}")#text("-measurable for every ")#mi("{x \\in X}")#text(", and similarly that the function ")#mi("{f^y: x \\mapsto f(x,y)}")#text(" is ")#mi("{{\\mathcal B}_X}")#text("-measurable for every ")#mi("{y \\in Y}")#text(".")],
[#text("If ")#mi("{E \\in {\\mathcal B}_X \\times {\\mathcal B}_Y}")#text(", show that the slices ")#mi("{E_x := \\{ y \\in Y: (x,y) \\in E \\}}")#text(" lie in a countably generated ")#mi("{\\sigma}")#text("-algebra. In other words, show that there exists an at most countable collection ")#mi("{{\\mathcal A} = {\\mathcal A}_E}")#text(" of sets (which can depend on ")#mi("{E}")#text(") such that ")#mi("{\\{ E_x: x \\in X \\} \\subset \\langle {\\mathcal A} \\rangle}")#text(". Conclude in particular that the number of distinct slices ")#mi("{E_x}")#text(" is at most ")#mi("{c}")#text(", the cardinality of the continuum. (The last part of this exercise is only suitable for students who are comfortable with cardinal arithmetic.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" ")#metadata(none) <tao-eac1ebf358c57028f5c5>

#enum(start: 1, 
[#text("Show that the product of two trivial ")#mi("{\\sigma}")#text("-algebras (on two different spaces ")#mi("{X,Y}")#text(") is again trivial.")],
[#text("(Exercise removed)")],
[#text("Show that the product of two finite ")#mi("{\\sigma}")#text("-algebras is again finite.")],
[#text("Show that the product of two Borel ")#mi("{\\sigma}")#text("-algebras (on two Euclidean spaces ")#mi("{{\\bf R}^d, {\\bf R}^{d^{\\prime}}}")#text(" with ")#mi("{d,d^{\\prime} \\geq 1}")#text(") is again the Borel ")#mi("{\\sigma}")#text("-algebra (on ")#mi("{{\\bf R}^d \\times {\\bf R}^{d^{\\prime}} \\equiv {\\bf R}^{d+d^{\\prime}}}")#text(").")],
[#text("Show that the product of two Lebesgue ")#mi("{\\sigma}")#text("-algebras (on two Euclidean spaces ")#mi("{{\\bf R}^d, {\\bf R}^{d^{\\prime}}}")#text(" with ")#mi("{d,d^{\\prime} \\geq 1}")#text(") is ")#emph[#text("not")]#text(" the Lebesgue ")#mi("{\\sigma}")#text("-algebra. (")#emph[#text("Hint:")]#text(" argue by contradiction and use Exercise ")#link(<tao-227ad062d6deda524b0a>)[#text("27")]#text("(3).)")],
[#text("However, show that the Lebesgue ")#mi("{\\sigma}")#text("-algebra on ")#mi("{{\\bf R}^{d+d^{\\prime}}}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Complete_measure")[#text("completion")]#text(" of the product of the Lebesgue ")#mi("{\\sigma}")#text("-algebras of ")#mi("{{\\bf R}^d}")#text(" and ")#mi("{{\\bf R}^{d^{\\prime}}}")#text(" with respect to ")#mi("{d+d^{\\prime}}")#text("-dimensional Lebesgue measure (see Exercise 26 of ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems")[#text("Notes 3")]#text(" for the definition of completion of a measure space).")],
[#text("This part of the exercise is only for students who are comfortable with cardinal arithmetic. Give an example to show that the product of two discrete ")#mi("{\\sigma}")#text("-algebras is not necessarily discrete.")],
[#text("On the other hand, show that the product of two discrete ")#mi("{\\sigma}")#text("-algebras ")#mi("{2^X, 2^Y}")#text(" is again a discrete ")#mi("{\\sigma}")#text("-algebra if at least one of the domains ")#mi("{X, Y}")#text(" is at most countably infinite.")]
)
]

#text("Now suppose we have two measure spaces ")#mi("{(X,{\\mathcal B}_X,\\mu_X)}")#text(" and ")#mi("{(Y,{\\mathcal B}_Y,\\mu_Y)}")#text(". Given that we can multiply together the sets ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" to form a product set ")#mi("{X \\times Y}")#text(", and can multiply the ")#mi("{\\sigma}")#text("-algebras ")#mi("{{\\mathcal B}_X}")#text(" and ")#mi("{{\\mathcal B}_Y}")#text(" together to form a product ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}_X \\times {\\mathcal B}_Y}")#text(", it is natural to expect that we can multiply the two measures ")#mi("{\\mu_X: {\\mathcal B}_X \\rightarrow [0,+\\infty]}")#text(" and ")#mi("{\\mu_Y: {\\mathcal B}_Y \\rightarrow [0,+\\infty]}")#text(" to form a product measure ")#mi("{\\mu_X \\times \\mu_Y: {\\mathcal B}_X \\times {\\mathcal B}_Y \\rightarrow [0,+\\infty]}")#text(". In view of the “base times height formula” that one learns in elementary school, one expects to have ")#metadata(none) <tao-77f2f036726eaa17f75c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\mu_X \\times \\mu_Y( E \\times F ) = \\mu_X(E) \\mu_Y(F)")]]

#text("whenever ")#mi("{E \\in {\\mathcal B}_X}")#text(" and ")#mi("{F \\in {\\mathcal B}_Y}")#text(".")#linebreak()#text(" To construct this measure, it is convenient to make the assumption that both spaces are ")#link("http://en.wikipedia.org/wiki/%CE%A3-finite_measure")[#mi("{\\sigma}")#text("-finite")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 29 (")#mi("{\\sigma}")#text("-finite)")]#text(" A measure space ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" is ")#emph[#mi("{\\sigma}")#text("-finite")]#text(" if ")#mi("{X}")#text(" can be expressed as the countable union of sets of finite measure.")
]

#text("Thus, for instance, ")#mi("{{\\bf R}^d}")#text(" with Lebesgue measure is ")#mi("{\\sigma}")#text("-finite, as ")#mi("{{\\bf R}^d}")#text(" can be expressed as the union of (for instance) the balls ")#mi("{B(0,n)}")#text(" for ")#mi("{n=1,2,3,\\ldots}")#text(", each of which has finite measure. On the other hand, ")#mi("{{\\bf R}^d}")#text(" with counting measure is not ")#mi("{\\sigma}")#text("-finite (why?). But most measure spaces that one actually encounters in analysis (including, clearly, all probability spaces) are ")#mi("{\\sigma}")#text("-finite. It is possible to partially extend the theory of product spaces to the non-")#mi("{\\sigma}")#text("-finite setting, but there are a number of very delicate technical issues that arise and so we will not discuss them here.")#linebreak()#text(" As long as we restrict attention to the ")#mi("{\\sigma}")#text("-finite case, product measure always exists and is unique:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 30 (Existence and uniqueness of product measure)")]#text(" ")#metadata(none) <tao-ec46cdac772ad9544660>#text(" Let ")#mi("{(X,{\\mathcal B}_X,\\mu_X)}")#text(" and ")#mi("{(Y,{\\mathcal B}_Y,\\mu_Y)}")#text(" be ")#mi("{\\sigma}")#text("-finite measure spaces. Then there exists a unique measure ")#mi("{\\mu_X \\times \\mu_Y}")#text(" on ")#mi("{{\\mathcal B}_X \\times {\\mathcal B}_Y}")#text(" that obeys ")#mi("{\\mu_X \\times \\mu_Y( E \\times F ) = \\mu_X(E) \\mu_Y(F)}")#text(" whenever ")#mi("{E \\in {\\mathcal B}_X}")#text(" and ")#mi("{F \\in {\\mathcal B}_Y}")#text(".")
]

#emph[#text("Proof:")]#text(" We first show existence. Inspired by the fact that Lebesgue measure is the Hahn-Kolmogorov completion of elementary (pre-)measure, we shall first construct an “elementary product pre-measure” that we will then apply Theorem ")#link(<tao-66b3b534b5a851cc90da>)[#text("14")]#text(" to.")#linebreak()#text(" Let ")#mi("{{\\mathcal B}_0}")#text(" be the collection of all finite unions")

#align(center)[#tao-fit-display[#mitex("S := (E_1 \\times F_1) \\cup \\ldots \\cup (E_k \\times F_k)")]]

#text("of Cartesian products of ")#mi("{{\\mathcal B}_X}")#text("-measurable sets ")#mi("{E_1,\\ldots,E_k}")#text(" and ")#mi("{{\\mathcal B}_Y}")#text("-measurable sets ")#mi("{F_1,\\ldots,F_k}")#text(". (One can think of such sets as being somewhat analogous to elementary sets in Euclidean space, although the analogy is not perfectly exact.) It is not difficult to verify that this is a Boolean algebra (though it is not, in general, a ")#mi("{\\sigma}")#text("-algebra). Also, any set in ")#mi("{{\\mathcal B}_0}")#text(" can be easily decomposed into a ")#emph[#text("disjoint")]#text(" union of product sets ")#mi("{E_1 \\times F_1, \\ldots, E_k \\times F_k}")#text(" of ")#mi("{{\\mathcal B}_X}")#text("-measurable sets and ")#mi("{{\\mathcal B}_Y}")#text("-measurable sets (cf. Lemma 2 (and Exercise 2) from ")#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/")[#text("the prologue")]#text("). We then define the quantity ")#mi("{\\mu_0(S)}")#text(" associated such a disjoint union ")#mi("{S}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\mu_0(S) := \\sum_{j=1}^k \\mu_X(E_j) \\mu_Y(F_j)")]]

#text("whenever ")#mi("{S}")#text(" is the disjoint union of products ")#mi("{E_1 \\times F_1,\\ldots,E_k \\times F_k}")#text(" of ")#mi("{{\\mathcal B}_X}")#text("-measurable sets and ")#mi("{{\\mathcal B}_Y}")#text("-measurable sets. One can show that this definition does not depend on exactly how ")#mi("{S}")#text(" is decomposed, and gives a finitely additive measure ")#mi("{\\mu_0: {\\mathcal B}_0 \\rightarrow [0,+\\infty]}")#text(" (cf. Exercise 2 from ")#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/")[#text("the prologue")]#text(", and also Exercise 31 from ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems")[#text("Notes 3")]#text(").")#linebreak()#text(" Now we show that ")#mi("{\\mu_0}")#text(" is a pre-measure. It suffices to show that if ")#mi("{S \\in {\\mathcal B}_0}")#text(" is the countable disjoint union of sets ")#mi("{S_1, S_2, \\ldots \\in {\\mathcal B}_0}")#text(", then ")#mi("{\\mu_0(S) = \\sum_{n=1}^\\infty \\mu_0(S_n)}")#text(".")#linebreak()#text(" Splitting ")#mi("{S}")#text(" up into disjoint product sets, and restricting the ")#mi("{S_n}")#text(" to each of these product sets in turn, we may assume without loss of generality (using the finite additivity of ")#mi("{\\mu_0}")#text(") that ")#mi("{S = E \\times F}")#text(" for some ")#mi("{E \\in {\\mathcal B}_X}")#text(" and ")#mi("{F \\in {\\mathcal B}_Y}")#text(". In a similar spirit, by breaking each ")#mi("{S_n}")#text(" up into component product sets and using finite additivity again, we may assume without loss of generality that each ")#mi("{S_n}")#text(" takes the form ")#mi("{S_n = E_n \\times F_n}")#text(" for some ")#mi("{E_n \\in {\\mathcal B}_X}")#text(" and ")#mi("{F_n \\in {\\mathcal B}_Y}")#text(". By definition of ")#mi("{\\mu_0}")#text(", our objective is now to show that")

#align(center)[#tao-fit-display[#mitex("\\mu_X(E) \\mu_Y(F) = \\sum_{n=1}^\\infty \\mu_X(E_n) \\mu_Y(F_n).")]]

#text("To do this, first observe from construction that we have the pointwise identity")

#align(center)[#tao-fit-display[#mitex("1_E(x) 1_F(y) = \\sum_{n=1}^\\infty 1_{E_n}(x) 1_{F_n}(y)")]]

#text("for all ")#mi("{x \\in X}")#text(" and ")#mi("{y \\in Y}")#text(". We fix ")#mi("{x \\in X}")#text(", and integrate this identity in ")#mi("{y}")#text(" (noting that both sides are measurable and unsigned) to conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_Y 1_E(x) 1_F(y)\\ d\\mu_Y(y) = \\int_Y \\sum_{n=1}^\\infty 1_{E_n}(x) 1_{F_n}(y)\\ d\\mu_Y(y).")]]

#text("The left-hand side simplifies to ")#mi("{1_E(x) \\mu_Y(F)}")#text(". To compute the right-hand side, we use the monotone convergence theorem to interchange the summation and integration, and soon see that the right-hand side is ")#mi("{\\sum_{n=1}^\\infty 1_{E_n}(x) \\mu_Y(F_n)}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("1_E(x) \\mu_Y(F) = \\sum_{n=1}^\\infty 1_{E_n}(x) \\mu_Y(F_n)")]]

#text("for all ")#mi("{x}")#text(". Both sides are measurable and unsigned in ")#mi("{x}")#text(", so we may integrate in ")#mi("{X}")#text(" and conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_X 1_E(x) \\mu_Y(F)\\ d\\mu_X = \\int_X \\sum_{n=1}^\\infty 1_{E_n}(x) \\mu_Y(F_n)\\ d\\mu_X(x).")]]

#text("The left-hand side here is ")#mi("{\\mu_X(E) \\mu_Y(F)}")#text(". Using monotone convergence as before, the right-hand side simplifies to ")#mi("{\\sum_{n=1}^\\infty \\mu_X(E_n) \\mu_Y(F_n)}")#text(", and the claim follows.")#linebreak()#text(" Now that we have established that ")#mi("{\\mu_0}")#text(" is a pre-measure, we may apply Theorem ")#link(<tao-66b3b534b5a851cc90da>)[#text("14")]#text(" to extend this measure to a countably additive measure ")#mi("{\\mu_X \\times \\mu_Y}")#text(" on a ")#mi("{\\sigma}")#text("-algebra containing ")#mi("{{\\mathcal B}_0}")#text(". By Exercise ")#link(<tao-227ad062d6deda524b0a>)[#text("27")]#text("(2), ")#mi("{\\mu_X \\times \\mu_Y}")#text(" is a countably additive measure on ")#mi("{{\\mathcal B}_X \\times {\\mathcal B}_Y}")#text(", and as it extends ")#mi("{\\mu_0}")#text(", it will obey ")#link(<tao-77f2f036726eaa17f75c>)[#text("(6)")]#text(". Finally, to show uniqueness, observe from finite additivity that any measure ")#mi("{\\mu_X \\times \\mu_Y}")#text(" on ")#mi("{{\\mathcal B}_X \\times {\\mathcal B}_Y}")#text(" that obeys ")#link(<tao-77f2f036726eaa17f75c>)[#text("(6)")]#text(" must extend ")#mi("{\\mu_0}")#text(", and so uniqueness follows from Exercise ")#link(<tao-234225f66642ae73f16f>)[#text("15")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 31")]#text(" When ")#mi("{X}")#text(", ")#mi("{Y}")#text(" are not both ")#mi("{\\sigma}")#text("-finite, then one can still construct at least one product measure, but it will, in general, not be unique. This makes the theory much more subtle, and we will not discuss it in these notes.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 32")]#text(" From Exercise 22 of ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(", we see that the product ")#mi("{m^d \\times m^{d^{\\prime}}}")#text(" of the Lebesgue measures ")#mi("{m^d, m^{d^{\\prime}}}")#text(" on ")#mi("{({\\bf R}^d,{\\mathcal L}[{\\bf R}^d])}")#text(" and ")#mi("{({\\bf R}^d,{\\mathcal L}[{\\bf R}^{d^{\\prime}}])}")#text(" respectively will agree with Lebesgue measure ")#mi("{m^{d+d^{\\prime}}}")#text(" on the product space ")#mi("{{\\mathcal L}[{\\bf R}^d] \\times {\\mathcal L}[{\\bf R}^{d^{\\prime}}]}")#text(", which as noted in Exercise ")#link(<tao-eac1ebf358c57028f5c5>)[#text("28")]#text(" is a subalgebra of ")#mi("{{\\mathcal L}[{\\bf R}^{d+d^{\\prime}}]}")#text(". After taking the completion ")#mi("{\\overline{m^d \\times m^{d^{\\prime}}}}")#text(" of this product measure, one obtains the full Lebesgue measure ")#mi("{m^{d+d^{\\prime}}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" Let ")#mi("{(X,{\\mathcal B}_X)}")#text(", ")#mi("{(Y,{\\mathcal B}_Y)}")#text(" be measurable spaces.")

#enum(start: 1, 
[#text("Show that the product of two Dirac measures on ")#mi("{(X,{\\mathcal B}_X)}")#text(", ")#mi("{(Y,{\\mathcal B}_Y)}")#text(" is a Dirac measure on ")#mi("{(X \\times Y, {\\mathcal B}_X \\times {\\mathcal B}_Y)}")#text(".")],
[#text("If ")#mi("{X, Y}")#text(" are at most countable, show that the product of the two counting measures on ")#mi("{(X,{\\mathcal B}_X)}")#text(", ")#mi("{(Y,{\\mathcal B}_Y)}")#text(" is the counting measure on ")#mi("{(X \\times Y, {\\mathcal B}_X \\times {\\mathcal B}_Y)}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34 (Associativity of product)")]#text(" Let ")#mi("{(X,{\\mathcal B}_X,\\mu_X)}")#text(", ")#mi("{(Y,{\\mathcal B}_Y,\\mu_Y)}")#text(", ")#mi("{(Z,{\\mathcal B}_Z,\\mu_Z)}")#text(" be ")#mi("{\\sigma}")#text("-finite sets. We may identify the Cartesian products ")#mi("{(X \\times Y) \\times Z}")#text(" and ")#mi("{X \\times (Y \\times Z)}")#text(" with each other in the obvious manner. If we do so, show that ")#mi("{({\\mathcal B}_X \\times {\\mathcal B}_Y) \\times {\\mathcal B}_Z = {\\mathcal B}_X \\times ({\\mathcal B}_Y \\times {\\mathcal B}_Z)}")#text(" and ")#mi("{(\\mu_X \\times \\mu_Y) \\times \\mu_Z = \\mu_X \\times (\\mu_Y \\times \\mu_Z)}")#text(".")
]

#text("Now we integrate using this product measure. We will need the following technical lemma. Define a ")#emph[#text("monotone class")]#text(" in ")#mi("{X}")#text(" is a collection ")#mi("{{\\mathcal B}}")#text(" of subsets of ")#mi("{X}")#text(" with the following two closure properties:")

#list(
[#text("If ")#mi("{E_1 \\subset E_2 \\subset \\ldots}")#text(" are a countable increasing sequence of sets in ")#mi("{{\\mathcal B}}")#text(", then ")#mi("{\\bigcup_{n=1}^\\infty E_n \\in {\\mathcal B}}")#text(".")],
[#text("If ")#mi("{E_1 \\supset E_2 \\supset \\ldots}")#text(" are a countable decreasing sequence of sets in ")#mi("{{\\mathcal B}}")#text(", then ")#mi("{\\bigcap_{n=1}^\\infty E_n \\in {\\mathcal B}}")#text(".")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 35 (Monotone class lemma)")]#text(" Let ")#mi("{{\\mathcal A}}")#text(" be a Boolean algebra on ")#mi("{X}")#text(". Then ")#mi("{\\langle {\\mathcal A} \\rangle}")#text(" is the smallest monotone class that contains ")#mi("{{\\mathcal A}}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{{\\mathcal B}}")#text(" be the intersection of all the monotone classes that contain ")#mi("{{\\mathcal A}}")#text(". Since ")#mi("{\\langle {\\mathcal A} \\rangle}")#text(" is clearly one such class, ")#mi("{{\\mathcal B}}")#text(" is a subset of ")#mi("{\\langle {\\mathcal A} \\rangle}")#text(". Our task is then to show that ")#mi("{{\\mathcal B}}")#text(" contains ")#mi("{\\langle {\\mathcal A} \\rangle}")#text(".")#linebreak()#text(" It is also clear that ")#mi("{{\\mathcal B}}")#text(" is a monotone class that contains ")#mi("{{\\mathcal A}}")#text(". By replacing all the elements of ")#mi("{{\\mathcal B}}")#text(" with their complements, we see that ")#mi("{{\\mathcal B}}")#text(" is necessarily closed under complements.")#linebreak()#text(" For any ")#mi("{E \\in {\\mathcal A}}")#text(", consider the set ")#mi("{{\\mathcal C}_E}")#text(" of all sets ")#mi("{F \\in {\\mathcal B}}")#text(" such that ")#mi("{F \\backslash E}")#text(", ")#mi("{E \\backslash F}")#text(", ")#mi("{F \\cap E}")#text(", and ")#mi("{X \\backslash (E \\cup F)}")#text(" all lie in ")#mi("{{\\mathcal B}}")#text(". It is clear that ")#mi("{{\\mathcal C}_E}")#text(" contains ")#mi("{{\\mathcal A}}")#text("; since ")#mi("{{\\mathcal B}}")#text(" is a monotone class, we see that ")#mi("{{\\mathcal C}_E}")#text(" is also. By definition of ")#mi("{{\\mathcal B}}")#text(", we conclude that ")#mi("{{\\mathcal C}_E = {\\mathcal B}}")#text(" for all ")#mi("{E \\in {\\mathcal A}}")#text(".")#linebreak()#text(" Next, let ")#mi("{{\\mathcal D}}")#text(" be the set of all ")#mi("{E \\in {\\mathcal B}}")#text(" such that ")#mi("{F \\backslash E}")#text(", ")#mi("{E \\backslash F}")#text(", ")#mi("{F \\cap E}")#text(", and ")#mi("{X \\backslash (E \\cup F)}")#text(" all lie in ")#mi("{{\\mathcal B}}")#text(" for all ")#mi("{F \\in {\\mathcal B}}")#text(". By the previous discussion, we see that ")#mi("{{\\mathcal D}}")#text(" contains ")#mi("{{\\mathcal A}}")#text(". One also easily verifies that ")#mi("{{\\mathcal D}}")#text(" is a monotone class. By definition of ")#mi("{{\\mathcal B}}")#text(", we conclude that ")#mi("{{\\mathcal D} = {\\mathcal B}}")#text(". Since ")#mi("{{\\mathcal B}}")#text(" is also closed under complements, this implies that ")#mi("{{\\mathcal B}}")#text(" is closed with respect to finite unions. Since this class also contains ")#mi("{{\\mathcal A}}")#text(", which contains ")#mi("{\\emptyset}")#text(", we conclude that ")#mi("{{\\mathcal B}}")#text(" is a Boolean algebra. Since ")#mi("{{\\mathcal B}}")#text(" is also closed under increasing countable unions, we conclude that it is closed under arbitrary countable unions, and is thus a ")#mi("{\\sigma}")#text("-algebra. As it contains ")#mi("{{\\mathcal A}}")#text(", it must also contain ")#mi("{\\langle {\\mathcal A} \\rangle}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 36 (Tonelli’s theorem, incomplete version)")]#text(" Let ")#mi("{(X,{\\mathcal B}_X,\\mu_X)}")#text(" and ")#mi("{(Y,{\\mathcal B}_Y,\\mu_Y)}")#text(" be ")#mi("{\\sigma}")#text("-finite measure spaces, and let ")#mi("{f: X \\times Y \\rightarrow [0,+\\infty]}")#text(" be measurable with respect to ")#mi("{{\\mathcal B}_X \\times {\\mathcal B}_Y}")#text(". Then:")

#enum(start: 1, 
[#text("The functions ")#mi("{x \\mapsto \\int_Y f(x,y)\\ d\\mu_Y(y)}")#text(" and ")#mi("{y \\mapsto \\int_X f(x,y)\\ d\\mu_X(x)}")#text(" (which are well-defined, thanks to Exercise ")#link(<tao-227ad062d6deda524b0a>)[#text("27")]#text(") are measurable with respect to ")#mi("{{\\mathcal B}_X}")#text(" and ")#mi("{{\\mathcal B}_Y}")#text(" respectively.")],
[#text("We have")

#align(center)[#tao-fit-display[#mitex("\\int_{X \\times Y} f(x,y)\\ d\\mu_X \\times \\mu_Y(x,y)")]]

#tao-aligned(keep: true)[


#tao-math(" & = \\int_X (\\int_Y f(x,y)\\ d\\mu_Y(y))\\ d\\mu_X(x)", block: true)



#tao-math(" & = \\int_Y (\\int_X f(x,y)\\ d\\mu_X(x))\\ d\\mu_Y(y).", block: true)
]]
)
]

#emph[#text("Proof:")]#text(" By writing the ")#mi("{\\sigma}")#text("-finite space ")#mi("{X}")#text(" as an increasing union ")#mi("{X = \\bigcup_{n=1}^\\infty X_n}")#text(" of finite measure sets, we see from several applications of the monotone convergence theorem that it suffices to prove the claims with ")#mi("{X}")#text(" replaced by ")#mi("{X_n}")#text(". Thus we may assume without loss of generality that ")#mi("{X}")#text(" has finite measure. Similarly we may assume ")#mi("{Y}")#text(" has finite measure. Note from ")#link(<tao-77f2f036726eaa17f75c>)[#text("(6)")]#text(" that this implies that ")#mi("{X \\times Y}")#text(" has finite measure also.")#linebreak()#text(" Every unsigned measurable function is the increasing limit of unsigned simple functions. By several applications of the monotone convergence theorem, we thus see that it suffices to verify the claim when ")#mi("{f}")#text(" is a simple function. By linearity, it then suffices to verify the claim when ")#mi("{f}")#text(" is an indicator function, thus ")#mi("{f=1_S}")#text(" for some ")#mi("{S \\in {\\mathcal B}_X \\times {\\mathcal B}_Y}")#text(".")#linebreak()#text(" Let ")#mi("{{\\mathcal C}}")#text(" be the set of all ")#mi("{S \\in {\\mathcal B}_X \\times {\\mathcal B}_Y}")#text(" for which the claims hold. From the repeated applications of the monotone convergence theorem and the downward monotone convergence theorem (which is available in this finite measure setting) we see that ")#mi("{{\\mathcal C}}")#text(" is a monotone class.")#linebreak()#text(" By direct computation (using ")#link(<tao-77f2f036726eaa17f75c>)[#text("(6)")]#text("), we see that ")#mi("{{\\mathcal C}}")#text(" contains as an element any product ")#mi("{S = E \\times F}")#text(" with ")#mi("{E \\in {\\mathcal B}_X}")#text(" and ")#mi("{F \\in {\\mathcal B}_Y}")#text(". By finite additivity, we conclude that ")#mi("{{\\mathcal C}}")#text(" also contains as an element any a disjoint finite union ")#mi("{S = E_1 \\times F_1 \\cup \\ldots \\cup E_k \\times F_k}")#text(" of such products. This implies that ")#mi("{{\\mathcal C}}")#text(" also contains the Boolean algebra ")#mi("{{\\mathcal B}_0}")#text(" in the proof of Proposition ")#link(<tao-ec46cdac772ad9544660>)[#text("30")]#text(", as such sets can always be expressed as the disjoint finite union of Cartesian products of measurable sets. Applying the monotone class lemma, we conclude that ")#mi("{{\\mathcal C}}")#text(" contains ")#mi("{\\langle {\\mathcal B}_0 \\rangle = {\\mathcal B}_X \\times {\\mathcal B}_Y}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 37")]#text(" Note that Tonelli’s theorem for sums (Theorem 2 from ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(") is a special case of the above result when ")#mi("{\\mu_X, \\mu_Y}")#text(" are counting measure. In a similar spirit, Corollary 15 from ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems")[#text("Notes 3")]#text(" is the special case when just one of ")#mi("{\\mu_X, \\mu_Y}")#text(" is counting measure.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 38")]#text(" ")#metadata(none) <tao-3608bca1e44ea6c4d268>#text(" Let ")#mi("{(X,{\\mathcal B}_X,\\mu_X)}")#text(" and ")#mi("{(Y,{\\mathcal B}_Y,\\mu_Y)}")#text(" be ")#mi("{\\sigma}")#text("-finite measure spaces, and let ")#mi("{E \\in {\\mathcal B}_X \\times {\\mathcal B}_Y}")#text(" be a null set with respect to ")#mi("{\\mu_X \\times \\mu_Y}")#text(". Then for ")#mi("{\\mu_X}")#text("-almost every ")#mi("{x \\in X}")#text(", the set ")#mi("{E_x := \\{ y \\in Y: (x,y) \\in E \\}}")#text(" is a ")#mi("{\\mu_Y}")#text("-null set; and similarly, for ")#mi("{\\mu_Y}")#text("-almost every ")#mi("{y \\in Y}")#text(", the set ")#mi("{E^y := \\{ x \\in X: (x,y) \\in E \\}}")#text(" is a ")#mi("{\\mu_X}")#text("-null set.")
]

#emph[#text("Proof:")]#text(" Applying the Tonelli theorem to the indicator function ")#mi("{1_E}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("0 = \\int_X (\\int_Y 1_E(x,y)\\ d\\mu_Y(y))\\ d\\mu_X(x) = \\int_Y (\\int_X 1_E(x,y)\\ d\\mu_X(x))\\ d\\mu_Y(y)")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("0 = \\int_X \\mu_Y(E_x)\\ d\\mu_X(x) = \\int_Y \\mu_X(E^y)\\ d\\mu_Y(y),")]]

#text("and the claim follows. ")#mi("\\Box")#linebreak()#text(" With this corollary, we can extend Tonelli’s theorem to the ")#link("http://en.wikipedia.org/wiki/Complete_measure")[#text("completion")]#text(" ")#mi("{(X \\times Y, \\overline{{\\mathcal B}_X \\times {\\mathcal B}_Y}, \\overline{\\mu_X \\times \\mu_Y})}")#text(" of the product space ")#mi("{(X \\times Y, {\\mathcal B}_X \\times {\\mathcal B}_Y, \\mu_X \\times \\mu_Y)}")#text(": (see Exercise 26 of ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems")[#text("Notes 3")]#text(" for the definition of completion). But we can easily extend the Tonelli theorem to this context:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 39 (Tonelli’s theorem, complete version)")]#text(" Let ")#mi("{(X,{\\mathcal B}_X,\\mu_X)}")#text(" and ")#mi("{(Y,{\\mathcal B}_Y,\\mu_Y)}")#text(" be complete ")#mi("{\\sigma}")#text("-finite measure spaces, and let ")#mi("{f: X \\times Y \\rightarrow [0,+\\infty]}")#text(" be measurable with respect to ")#mi("{\\overline{{\\mathcal B}_X \\times {\\mathcal B}_Y}}")#text(". Then:")

#enum(start: 1, 
[#text("For ")#mi("{\\mu_X}")#text("-almost every ")#mi("{x \\in X}")#text(", the function ")#mi("{y \\mapsto f(x,y)}")#text(" is ")#mi("{{\\mathcal B}_Y}")#text("-measurable, and in particular ")#mi("{\\int_Y f(x,y)\\ d\\mu_Y(y)}")#text(" exists. Furthermore, the (")#mi("{\\mu_X}")#text("-almost everywhere defined) map ")#mi("{x \\mapsto \\int_Y f(x,y)\\ d\\mu_Y}")#text(" is ")#mi("{{\\mathcal B}_X}")#text("-measurable.")],
[#text("For ")#mi("{\\mu_Y}")#text("-almost every ")#mi("{y \\in Y}")#text(", the function ")#mi("{x \\mapsto f(x,y)}")#text(" is ")#mi("{{\\mathcal B}_X}")#text("-measurable, and in particular ")#mi("{\\int_X f(x,y)\\ d\\mu_X(x)}")#text(" exists. Furthermore, the (")#mi("{\\mu_Y}")#text("-almost everywhere defined) map ")#mi("{y \\mapsto \\int_X f(x,y)\\ d\\mu_X}")#text(" is ")#mi("{{\\mathcal B}_Y}")#text("-measurable.")],
[#text("We have")

#align(center)[#tao-fit-display[#mitex("\\int_{X \\times Y} f(x,y)\\ d\\overline{\\mu_X \\times \\mu_Y}(x,y)")]]

#metadata(none) <tao-d3d7b0b1568ab8a7f8c3>

#tao-aligned(keep: true)[


#tao-math(" & = \\int_X (\\int_Y f(x,y)\\ d\\mu_Y(y))\\ d\\mu_X(x)", block: true, numbering: n => [#text("(7)")])



#tao-math(" & = \\int_Y (\\int_X f(x,y)\\ d\\mu_X(x))\\ d\\mu_Y(y).", block: true)
]]
)
]

#emph[#text("Proof:")]#text(" From Exercise 26 of ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems")[#text("Notes 3")]#text(", every measurable set in ")#mi("{\\overline{{\\mathcal B}_X \\times {\\mathcal B}_Y}}")#text(" is equal to a measurable set in ")#mi("{{\\mathcal B}_X \\times {\\mathcal B}_Y}")#text(" outside of a ")#mi("{\\mu_X \\times \\mu_Y}")#text("-null set. This implies that the ")#mi("{\\overline{{\\mathcal B}_X \\times {\\mathcal B}_Y}}")#text("-measurable function ")#mi("{f}")#text(" agrees with a ")#mi("{{\\mathcal B}_X \\times {\\mathcal B}_Y}")#text("-measurable function ")#mi("{\\tilde f}")#text(" outside of a ")#mi("{\\mu_X \\times \\mu_Y}")#text("-null set ")#mi("{E}")#text(" (as can be seen by expressing ")#mi("{f}")#text(" as the limit of simple functions). From Corollary ")#link(<tao-3608bca1e44ea6c4d268>)[#text("38")]#text(", we see that for ")#mi("{\\mu_X}")#text("-almost every ")#mi("{x \\in X}")#text(", the function ")#mi("{y \\mapsto f(x,y)}")#text(" agrees with ")#mi("{y \\mapsto \\tilde f(x,y)}")#text(" outside of a ")#mi("{\\mu_Y}")#text("-null set (and is in particular measurable, as ")#mi("{(Y,{\\mathcal B}_Y,\\mu_Y)}")#text(" is complete); and similarly for ")#mi("{\\mu_Y}")#text("-almost every ")#mi("{y \\in Y}")#text(", the function ")#mi("{x \\mapsto f(x,y)}")#text(" agrees with ")#mi("{x \\mapsto \\tilde f(x,y)}")#text(" outside of a ")#mi("{\\mu_X}")#text("-null set and is measurable, and the claim follows. ")#mi("\\Box")#linebreak()#text(" Specialising to the case when ")#mi("{f}")#text(" is an indicator function ")#mi("{f=1_E}")#text(", we conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 40 (Tonelli’s theorem for sets)")]#text(" ")#metadata(none) <tao-018d7f61c7b4616b2a0a>#text(" Let ")#mi("{(X,{\\mathcal B}_X,\\mu_X)}")#text(" and ")#mi("{(Y,{\\mathcal B}_Y,\\mu_Y)}")#text(" be complete ")#mi("{\\sigma}")#text("-finite measure spaces, and let ")#mi("{E \\in \\overline{{\\mathcal B}_X \\times {\\mathcal B}_Y}}")#text(". Then:")

#enum(start: 1, 
[#text("For ")#mi("{\\mu_X}")#text("-almost every ")#mi("{x \\in X}")#text(", the set ")#mi("{E_x := \\{ y \\in Y: (x,y) \\in E \\}}")#text(" lies in ")#mi("{{\\mathcal B}_Y}")#text(", and the (")#mi("{\\mu_X}")#text("-almost everywhere defined) map ")#mi("{x \\mapsto \\mu_Y(E_x)}")#text(" is ")#mi("{{\\mathcal B}_X}")#text("-measurable.")],
[#text("For ")#mi("{\\mu_Y}")#text("-almost every ")#mi("{y \\in Y}")#text(", the set ")#mi("{E^y := \\{ x \\in X: (x,y) \\in E \\}}")#text(" lies in ")#mi("{{\\mathcal B}_X}")#text(", and the (")#mi("{\\mu_Y}")#text("-almost everywhere defined) map ")#mi("{y \\mapsto \\mu_X(E^y)}")#text(" is ")#mi("{{\\mathcal B}_Y}")#text("-measurable.")],
[#text("We have")

#tao-aligned(keep: true)[


#tao-math("\\overline{\\mu_X \\times \\mu_Y}(E)  & = \\int_X \\mu_Y(E_x)\\ d\\mu_X(x)", block: true, numbering: n => [#text("(8)")])



#tao-math(" & = \\int_Y \\mu_X(E^y)\\ d\\mu_Y(y).", block: true)
]]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 41")]#text(" ")#metadata(none) <tao-fc90a69f33f798f936f4>#text(" The purpose of this exercise is to demonstrate that Tonelli’s theorem can fail if the ")#mi("{\\sigma}")#text("-finite hypothesis is removed, and also that product measure need not be unique. Let ")#mi("{X}")#text(" is the unit interval ")#mi("{[0,1]}")#text(" with Lebesgue measure ")#mi("{m}")#text(" (and the Lebesgue ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal L}([0,1])}")#text(") and ")#mi("{Y}")#text(" is the unit interval ")#mi("{[0,1]}")#text(" with counting measure (and the discrete ")#mi("{\\sigma}")#text("-algebra ")#mi("{2^{[0,1]}}")#text(") ")#mi("{\\#}")#text(". Let ")#mi("{f := 1_E}")#text(" be the indicator function of the diagonal ")#mi("{E := \\{(x,x): x \\in [0,1]\\}}")#text(".")

#enum(start: 1, 
[#text("Show that ")#mi("{f}")#text(" is measurable in the product ")#mi("{\\sigma}")#text("-algebra.")],
[#text("Show that ")#mi("{\\int_X (\\int_Y f(x,y)\\ d\\#(y)) dm(x) = 1}")#text(".")],
[#text("Show that ")#mi("{\\int_Y (\\int_X f(x,y)\\ dm(x)) d\\#(y) = 0}")#text(".")],
[#text("Show that there is more than one measure ")#mi("{\\mu}")#text(" on ")#mi("{{\\mathcal L}([0,1]) \\times 2^{[0,1]}}")#text(" with the property that ")#mi("{\\mu(E \\times F) = m(E) \\#(F)}")#text(" for all ")#mi("{E \\in {\\mathcal L}([0,1])}")#text(" and ")#mi("{F \\in 2^{[0,1]}}")#text(". (Hint: use the two different ways to perform a double integral to create two different measures.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 42")]#text(" If ")#mi("{f}")#text(" is not assumed to be measurable in the product space (or its completion), then of course the expression ")#mi("{\\int_{X \\times Y} f(x,y)\\ d\\overline{\\mu_X \\times \\mu_Y}(x,y)}")#text(" does not make sense. Furthermore, in this case the remaining two expressions in ")#link(<tao-d3d7b0b1568ab8a7f8c3>)[#text("(7)")]#text(" may become different as well (in some models of set theory, at least), even when ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are finite measure. For instance, let us assume the ")#link("http://en.wikipedia.org/wiki/Continuum_hypothesis")[#text("continuum hypothesis")]#text(", which implies that the unit interval ")#mi("{[0,1]}")#text(" can be placed in one-to-one correspondence with the ")#link("http://en.wikipedia.org/wiki/First_uncountable_ordinal")[#text("first uncountable ordinal")]#text(" ")#mi("{\\omega_1}")#text(". Let ")#mi("{\\prec}")#text(" be the ordering of ")#mi("{[0,1]}")#text(" that is associated to this ordinal, let ")#mi("{E := \\{ (x,y) \\in [0,1]^2: x \\prec y \\}}")#text(", and let ")#mi("{f := 1_E}")#text(". Then, for any ")#mi("{y \\in [0,1]}")#text(", there are at most countably many ")#mi("{x}")#text(" such that ")#mi("{x \\prec y}")#text(", and so ")#mi("{\\int_{[0,1]} f(x,y)\\ dx}")#text(" exists and is equal to zero for every ")#mi("{y}")#text(". On the other hand, for every ")#mi("{x \\in [0,1]}")#text(", one has ")#mi("{x \\prec y}")#text(" for all but countably many ")#mi("{y \\in [0,1]}")#text(", and so ")#mi("{\\int_{[0,1]} f(x,y)\\ dy}")#text(" exists and is equal to one for every ")#mi("{y}")#text(", and so the last two expressions in ")#link(<tao-d3d7b0b1568ab8a7f8c3>)[#text("(7)")]#text(" exist but are unequal. (In particular, Tonelli’s theorem implies that ")#mi("{E}")#text(" cannot be a Lebesgue measurable subset of ")#mi("{[0,1]^2}")#text(".) Thus we see that measurability in the product space is an important hypothesis. (There do however exist models of set theory (with the axiom of choice) in which such counterexamples cannot be constructed, at least in the case when ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are the unit interval with Lebesgue measure.)")
]

#text("Tonelli’s theorem is for the unsigned integral, but it leads to an important analogue for the absolutely convergent integral, known as ")#link("http://en.wikipedia.org/wiki/Fubini's_theorem")[#text("Fubini’s theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 43 (Fubini’s theorem)")]#text(" Let ")#mi("{(X,{\\mathcal B}_X,\\mu_X)}")#text(" and ")#mi("{(Y,{\\mathcal B}_Y,\\mu_Y)}")#text(" be complete ")#mi("{\\sigma}")#text("-finite measure spaces, and let ")#mi("{f: X \\times Y \\rightarrow {\\bf C}}")#text(" be absolutely integrable with respect to ")#mi("{\\overline{{\\mathcal B}_X \\times {\\mathcal B}_Y}}")#text(". Then:")

#enum(start: 1, 
[#text("For ")#mi("{\\mu_X}")#text("-almost every ")#mi("{x \\in X}")#text(", the function ")#mi("{y \\mapsto f(x,y)}")#text(" is absolutely integrable with respect to ")#mi("{\\mu_Y}")#text(", and in particular ")#mi("{\\int_Y f(x,y)\\ d\\mu_Y(y)}")#text(" exists. Furthermore, the (")#mi("{\\mu_X}")#text("-almost everywhere defined) map ")#mi("{x \\mapsto \\int_Y f(x,y)\\ d\\mu_Y(y)}")#text(" is absolutely integrable with respect to ")#mi("{\\mu_X}")#text(".")],
[#text("For ")#mi("{\\mu_Y}")#text("-almost every ")#mi("{y \\in Y}")#text(", the function ")#mi("{x \\mapsto f(x,y)}")#text(" is absolutely integrable with respect to ")#mi("{\\mu_X}")#text(", and in particular ")#mi("{\\int_X f(x,y)\\ d\\mu_X(x)}")#text(" exists. Furthermore, the (")#mi("{\\mu_Y}")#text("-almost everywhere defined) map ")#mi("{y \\mapsto \\int_X f(x,y)\\ d\\mu_X(x)}")#text(" is absolutely integrable with respect to ")#mi("{\\mu_Y}")#text(".")],
[#text("We have")

#align(center)[#tao-fit-display[#mitex("\\int_{X \\times Y} f(x,y)\\ d\\overline{\\mu_X \\times \\mu_Y}(x,y)")]]

#tao-aligned(keep: true)[


#tao-math(" & = \\int_X (\\int_Y f(x,y)\\ d\\mu_Y(y))\\ d\\mu_X(x)", block: true)



#tao-math(" & = \\int_Y (\\int_X f(x,y)\\ d\\mu_X(x))\\ d\\mu_Y(y).", block: true)
]]
)
]

#emph[#text("Proof:")]#text(" By taking real and imaginary parts we may assume that ")#mi("{f}")#text(" is real; by taking positive and negative parts we may assume that ")#mi("{f}")#text(" is unsigned. But then the claim follows from Tonelli’s theorem; note from ")#link(<tao-d3d7b0b1568ab8a7f8c3>)[#text("(7)")]#text(" that ")#mi("{\\int_X (\\int_Y f(x,y)\\ d\\mu_Y(y))\\ d\\mu_X(x)}")#text(" is finite, and so ")#mi("{\\int_Y f(x,y)\\ d\\mu_Y(y) < \\infty}")#text(" for ")#mi("{\\mu_X}")#text("-almost every ")#mi("{x \\in X}")#text(", and similarly ")#mi("{\\int_X f(x,y)\\ d\\mu_X(x) < \\infty}")#text(" for ")#mi("{\\mu_Y}")#text("-almost every ")#mi("{y \\in Y}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 44")]#text(" Give an example of a Borel measurable function ")#mi("{f: [0,1]^2 \\rightarrow {\\bf R}}")#text(" such that the integrals ")#mi("{\\int_{[0,1]} f(x,y)\\ dy}")#text(" and ")#mi("{\\int_{[0,1]} f(x,y)\\ dx}")#text(" exist and are absolutely integrable for all ")#mi("{x \\in [0,1]}")#text(" and ")#mi("{y \\in [0,1]}")#text(" respectively, and that ")#mi("{\\int_{[0,1]} (\\int_{[0,1]} f(x,y)\\ dy)\\ dx}")#text(" and ")#mi("{\\int_{[0,1]} (\\int_{[0,1]} f(x,y)\\ dx)\\ dy}")#text(" exist and are absolutely integrable, but such that")

#align(center)[#tao-fit-display[#mitex("\\int_{[0,1]} (\\int_{[0,1]} f(x,y)\\ dy)\\ dx \\neq \\int_{[0,1]} (\\int_{[0,1]} f(x,y)\\ dx)\\ dy")]]

#text("are unequal. (")#emph[#text("Hint:")]#text(" adapt the example from Remark 2 of ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(".) Thus we see that Fubini’s theorem fails when one drops the hypothesis that ")#mi("{f}")#text(" is absolutely integrable with respect to the product space.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 45")]#text(" Despite the failure of Tonelli’s theorem in the non-")#mi("{\\sigma}")#text("-finite setting, it is possible to (carefully) extend Fubini’s theorem to the non-")#mi("{\\sigma}")#text("-finite setting, as the absolute integrability hypotheses, when combined with Markov’s inequality, can provide a substitute for the ")#mi("{\\sigma}")#text("-finite property. However, we will not do so here, and indeed I would recommend proceeding with extreme caution when performing any sort of interchange of integrals or invoking of product measure when one is not in the ")#mi("{\\sigma}")#text("-finite setting.")
]

#text("Informally, Fubini’s theorem allows one to always interchange the order of two integrals, as long as the integrand is absolutely integrable in the product space (or its completion). In particular, specialising to Lebesgue measure, we have")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^{d+d^{\\prime}}} f(x,y)\\ d(x,y) = \\int_{{\\bf R}^d} (\\int_{{\\bf R}^{d^{\\prime}}} f(x,y)\\ dy)\\ dx = \\int_{{\\bf R}^{d^{\\prime}}} (\\int_{{\\bf R}^d} f(x,y)\\ dx)\\ dy")]]

#text("whenever ")#mi("{f: {\\bf R}^{d+d^{\\prime}} \\rightarrow {\\bf C}}")#text(" is absolutely integrable. In view of this, we often write ")#mi("{dx dy}")#text(" (or ")#mi("{dy dx}")#text(") for ")#mi("{d(x,y)}")#text(".")#linebreak()#text(" By combining Fubini’s theorem with Tonelli’s theorem, we can recast the absolute integrability hypothesis:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 46 (Fubini-Tonelli theorem)")]#text(" Let ")#mi("{(X,{\\mathcal B}_X,\\mu_X)}")#text(" and ")#mi("{(Y,{\\mathcal B}_Y,\\mu_Y)}")#text(" be complete ")#mi("{\\sigma}")#text("-finite measure spaces, and let ")#mi("{f: X \\times Y \\rightarrow {\\bf C}}")#text(" be measurable with respect to ")#mi("{\\overline{{\\mathcal B}_X \\times {\\mathcal B}_Y}}")#text(". If")

#align(center)[#tao-fit-display[#mitex("\\int_X (\\int_Y |f(x,y)|\\ d\\mu_Y(y))\\ d\\mu_X(x) < \\infty")]]

#text("(note the left-hand side always exists, by Tonelli’s theorem) then ")#mi("{f}")#text(" is absolutely integrable with respect to ")#mi("{\\overline{{\\mathcal B}_X \\times {\\mathcal B}_Y}}")#text(", and in particular the conclusions of Fubini’s theorem hold. Similarly if we use ")#mi("{\\int_Y (\\int_X |f(x,y)|\\ d\\mu_X(x))\\ d\\mu_Y(y)}")#text(" instead of ")#mi("{\\int_X (\\int_Y |f(x,y)|\\ d\\mu_Y)\\ d\\mu_X}")#text(".")
]

#text("The Fubini-Tonelli theorem is an indispensable tool for computing integrals. We give some basic examples below:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 47 (Area interpretation of integral)")]#text(" Let ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" be a ")#mi("{\\sigma}")#text("-finite measure space, and let ")#mi("{{\\bf R}}")#text(" be equipped with Lebesgue measure ")#mi("{m}")#text(" and the Borel ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}[{\\bf R}]}")#text(". Show that if ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(" is measurable, then the set ")#mi("{ \\{ (x,t) \\in X \\times {\\bf R}: 0 \\leq t \\leq f(x) \\}}")#text(" is measurable in ")#mi("{{\\mathcal B} \\times {\\mathcal B}[{\\bf R}]}")#text(", and")

#align(center)[#tao-fit-display[#mitex("(\\mu \\times m)( \\{ (x,t) \\in X \\times {\\bf R}: 0 \\leq t \\leq f(x) \\} ) = \\int_X f(x)\\ d\\mu(x).")]]

#text("Similarly if we replace ")#mi("{\\{ (x,t) \\in X \\times {\\bf R}: 0 \\leq t \\leq f(x) \\}}")#text(" by ")#mi("{ \\{ (x,t) \\in X \\times {\\bf R}: 0 \\leq t < f(x) \\}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 48 (Distribution formula)")]#text(" Let ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" be a ")#mi("{\\sigma}")#text("-finite measure space, and let ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(" be measurable. Show that")

#align(center)[#tao-fit-display[#mitex("\\int_X f(x)\\ d\\mu(x) = \\int_{[0,+\\infty]} \\mu( \\{ x \\in X: f(x) \\geq \\lambda \\} )\\ d\\lambda.")]]

#text("(Note that the integrand on the right-hand side is monotone and thus Lebesgue measurable.) Similarly if we replace ")#mi("{\\{ x \\in X: f(x) \\geq \\lambda \\}}")#text(" by ")#mi("{\\{ x \\in X: f(x) > \\lambda \\}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 49 (Approximations to the identity)")]#text(" Let ")#mi("{P: {\\bf R}^d \\rightarrow {\\bf R}^+}")#text(" be a good kernel (see Exercise 51 from ")#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/")[#text("Notes 5")]#text("), and let ")#mi("{P_t}")#text(" be the associated rescaled functions. Show that if ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is absolutely integrable, that ")#mi("{f*P_t}")#text(" converges in ")#mi("{L^1}")#text(" norm to ")#mi("{f}")#text(" as ")#mi("{t \\rightarrow 0}")#text(". (")#emph[#text("Hint:")]#text(" use the density argument. You will need an upper bound on ")#tao-math("{\\left\\|f*P_t\\right\\|_{L^1({\\bf R}^d)}}", block: false)#text(" which can be obtained using Tonelli’s theorem.)")
]

#heading(level: 1)[#strong[#text(" — 5. Application: the Radamacher differentiation theorem (Optional) — ")]]

#text("The Fubini-Tonelli theorem is often used in extending lower-dimensional results to higher-dimensional ones. We illustrate this by extending the one-dimensional Lipschitz differentiation theorem (Exercise 40 from ")#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/")[#text("Notes 5")]#text(") to higher dimensions. We first recall some higher-dimensional definitions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 50 (Lipschitz continuity)")]#text(" A function ")#mi("{f: X \\rightarrow Y}")#text(" from one metric space ")#mi("{(X,d_X)}")#text(" to another ")#mi("{(Y,d_Y)}")#text(" is said to be ")#link("http://en.wikipedia.org/wiki/Lipschitz_continuity")[#text("Lipschitz continuous")]#text(" if there exists a constant ")#mi("{C>0}")#text(" such that ")#mi("{d_Y(f(x),f(x^{\\prime})) \\leq C d_X(x,x^{\\prime})}")#text(" for all ")#mi("{x,x^{\\prime} \\in X}")#text(". (In our current application, ")#mi("{X}")#text(" will be ")#mi("{{\\bf R}^d}")#text(" and ")#mi("{Y}")#text(" will be ")#mi("{{\\bf R}}")#text(", with the usual metrics.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 51")]#text(" Show that Lipschitz continuous functions are ")#link("http://en.wikipedia.org/wiki/Uniform_continuity")[#text("uniformly continuous")]#text(", and hence continuous. Then give an example of a uniformly continuous function ")#mi("{f: [0,1] \\rightarrow [0,1]}")#text(" that is not Lipschitz continuous.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 52 (Differentiability)")]#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" be a function, and let ")#mi("{x_0 \\in {\\bf R}^d}")#text(". For any ")#mi("{v \\in {\\bf R}^d}")#text(", we say that ")#mi("{f}")#text(" is ")#link("http://en.wikipedia.org/wiki/Directional_derivative")[#text("directionally differentiable")]#text(" at ")#mi("{x_0}")#text(" in the direction ")#mi("{v}")#text(" if the limit")

#align(center)[#tao-fit-display[#mitex("D_v f(x_0) := \\lim_{h \\rightarrow 0; h \\in {\\bf R} \\backslash \\{0\\}} \\frac{f(x_0+hv) - f(x_0)}{h}")]]

#text("exists, in which case we call ")#mi("{D_v f(x_0)}")#text(" the ")#emph[#text("directional derivative")]#text(" of ")#mi("{f}")#text(" at ")#mi("{x_0}")#text(" in this direction. If ")#mi("{v=e_i}")#text(" is one of the standard basis vectors ")#mi("{e_1,\\ldots,e_d}")#text(" of ")#mi("{{\\bf R}^d}")#text(", we write ")#mi("{D_v f(x_0)}")#text(" as ")#mi("{\\frac{\\partial f}{\\partial x_i}(x_0)}")#text(", and refer to this as the ")#emph[#text("partial derivative")]#text(" of ")#mi("{f}")#text(" at ")#mi("{x_0}")#text(" in the ")#mi("{e_i}")#text(" direction.")#linebreak()#text(" We say that ")#mi("{f}")#text(" is ")#link("http://en.wikipedia.org/wiki/Total_derivative")[#text("totally differentiable")]#text(" at ")#mi("{x_0}")#text(" if there exists a vector ")#mi("{\\nabla f(x_0) \\in {\\bf R}^d}")#text(" with the property that")

#align(center)[#tao-fit-display[#tao-math("\\lim_{h \\rightarrow 0; h \\in {\\bf R}^d \\backslash \\{0\\}} \\frac{f(x_0+h) - f(x_0) - h \\cdot \\nabla f(x_0)}{\\left|h\\right|} = 0,", block: true)]]

#text("where ")#mi("{v \\cdot w}")#text(" is the usual ")#link("http://en.wikipedia.org/wiki/Dot_product")[#text("dot product")]#text(" on ")#mi("{{\\bf R}^d}")#text(". We refer to ")#mi("{\\nabla f(x_0)}")#text(" (if it exists) as the ")#emph[#text("gradient")]#text(" of ")#mi("{f}")#text(" at ")#mi("{x_0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 53")]#text(" From the viewpoint of differential geometry, it is better to work not with the gradient vector ")#mi("{\\nabla f(x_0) \\in {\\bf R}^d}")#text(", but rather with the derivative covector ")#mi("{df(x_0): {\\bf R}^d \\rightarrow {\\bf R}}")#text(" given by ")#mi("{df(x_0): v \\mapsto \\nabla f(x_0) \\cdot v}")#text(". This is because one can then define the notion of total differentiability without any mention of the Euclidean dot product, which allows one to extend this notion to other manifolds in which there is no Euclidean (or more generally, Riemannian) structure. However, as we are working exclusively in Euclidean space for this application, this distinction will not be important for us.")
]

#text("Total differentiability implies directional and partial differentiability, but not conversely, as the following three exercises demonstrate.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 54 (Total differentiability implies directional and partial differentiability)")]#text(" Show that if ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" is totally differentiable at ")#mi("{x_0}")#text(", then it is directionally differentiable at ")#mi("{x_0}")#text(" in each direction ")#mi("{v \\in {\\bf R}^d}")#text(", and one has the formula ")#metadata(none) <tao-d8e96eda68ed3b7b7b1f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("D_v f(x_0) = v \\cdot \\nabla f(x_0).")]]

#text("In particular, the partial derivatives ")#mi("{\\frac{\\partial f}{\\partial x_i} f(x_0)}")#text(" exist for ")#mi("{i=1,\\ldots,d}")#text(" and ")#metadata(none) <tao-ca65f90d09c34d8a1da1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\nabla f(x_0) = (\\frac{\\partial f}{\\partial x_1}(x_0), \\ldots, \\frac{\\partial f}{\\partial x_d}(x_0)).")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 55 (Continuous partial differentiability implies total differentiability)")]#text(" ")#metadata(none) <tao-653e813098a28ccdf23d>#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" be such that the partial derivatives ")#mi("{\\frac{\\partial f}{\\partial x_i}: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" exist everywhere and are continuous. Then show that ")#mi("{f}")#text(" is totally differentiable everywhere, which in particular implies that the gradient is given by the formula ")#link(<tao-ca65f90d09c34d8a1da1>)[#text("(10)")]#text(" and the directional derivatives are given by ")#link(<tao-d8e96eda68ed3b7b7b1f>)[#text("(9)")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 56 (Directional differentiability does not imply total differentiability)")]#text(" Let ")#mi("{f: {\\bf R}^2 \\rightarrow {\\bf R}}")#text(" be defined by setting ")#mi("{f(0,0) := 0}")#text(" and ")#mi("{f(x_1,x_2) := \\frac{x_1 x_2^2}{x_1^2+x_2^2}}")#text(" for ")#mi("{(x_1,x_2) \\in {\\bf R}^2 \\backslash \\{(0,0)\\}}")#text(". Show that the directional derivatives ")#mi("{D_v f(x)}")#text(" exist for all ")#mi("{x,v \\in {\\bf R}^2}")#text(" (so in particular, the partial derivatives exist), but that ")#mi("{f}")#text(" is not totally differentiable at the origin ")#mi("{(0,0)}")#text(".")
]

#text("Now we can state the ")#link("http://en.wikipedia.org/wiki/Rademacher's_theorem")[#text("Rademacher differentiation theorem")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 57 (Rademacher differentiation theorem)")]#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" be Lipschitz continuous. Then ")#mi("{f}")#text(" is totally differentiable at ")#mi("{x_0}")#text(" for almost every ")#mi("{x_0 \\in {\\bf R}^d}")#text(".")
]

#text("Note that the ")#mi("{d=1}")#text(" case of this theorem is Exercise 76 from ")#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/")[#text("Notes 5")]#text(", and indeed we will use the one-dimensional theorem to imply the higher-dimensional one, though there will be some technical issues due to the gap between directional and total differentiability.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" The strategy here is to first aim for the more modest goal of directional differentiability, and then find a way to link the directional derivatives together to get total differentiability.")#linebreak()#text(" Let ")#mi("{v, x_0 \\in {\\bf R}^d}")#text(". As ")#mi("{f}")#text(" is continuous, we see that in order for the directional derivative")

#align(center)[#tao-fit-display[#mitex("D_v f(x_0) := \\lim_{h \\rightarrow 0; h \\in {\\bf R} \\backslash \\{0\\}} \\frac{f(x_0+hv) - f(x_0)}{h}")]]

#text("to exist, it suffices to let ")#mi("{h}")#text(" range in the dense subset ")#mi("{{\\bf Q} \\backslash \\{0\\}}")#text(" of ")#mi("{{\\bf R} \\backslash \\{0\\}}")#text(" for the purposes of determing whether the limit exists. In particular, ")#mi("{D_v f(x_0)}")#text(" exists if and only if")

#align(center)[#tao-fit-display[#mitex("\\limsup_{h \\rightarrow 0; h \\in {\\bf Q} \\backslash \\{0\\}} \\frac{f(x_0+hv) - f(x_0)}{h} = \\liminf_{h \\rightarrow 0; h \\in {\\bf Q} \\backslash \\{0\\}} \\frac{f(x_0+hv) - f(x_0)}{h}.")]]

#text("From this we easily conclude that for each direction ")#mi("{v \\in {\\bf R}^d}")#text(", the set")

#align(center)[#tao-fit-display[#mitex("E_v := \\{ x_0 \\in {\\bf R}^d: D_v f(x_0) \\text{ does not exist} \\}")]]

#text("is Lebesgue measurable in ")#mi("{{\\bf R}^d}")#text(" (indeed, it is even Borel measurable). A similar argument reveals that ")#mi("{D_v f}")#text(" is a measurable function outside of ")#mi("{E_v}")#text(". From the Lipschitz nature of ")#mi("{f}")#text(", we see that ")#mi("{D_v f}")#text(" is also a bounded function.")#linebreak()#text(" Now we claim that ")#mi("{E_v}")#text(" is a null set for each ")#mi("{v}")#text(". For ")#mi("{v=0}")#text(" ")#mi("{E_v}")#text(" is clearly empty, so we may assume ")#mi("{v \\neq 0}")#text(". Applying an invertible linear transformation to map ")#mi("{v}")#text(" to ")#mi("{e_1}")#text(" (noting that such transformations will map Lipschitz functions to Lispchitz functions, and null sets to null sets) we may assume without loss of generality that ")#mi("{v}")#text(" is the basis vector ")#mi("{e_1}")#text(". Thus our task is now to show that ")#mi("{\\frac{\\partial f}{\\partial x_1}(x)}")#text(" exists for almost every ")#mi("{x \\in {\\bf R}^d}")#text(".")#linebreak()#text(" We now split ")#mi("{{\\bf R}^d}")#text(" as ")#mi("{{\\bf R} \\times {\\bf R}^{d-1}}")#text(". For each ")#mi("{x_0 \\in {\\bf R}}")#text(" and ")#mi("{y_0 \\in {\\bf R}^{d-1}}")#text(", we see from the definitions that ")#mi("{\\frac{\\partial f}{\\partial x_1}(x_0,y_0)}")#text(" exists if and only if the one-dimensional function ")#mi("{x \\mapsto f(x,y_0)}")#text(" is differentiable at ")#mi("{x_0}")#text(". But this function is Lipschitz continuous (this is inherited from the Lipschitz continuity of ")#mi("{f}")#text("), and so we see that for each fixed ")#mi("{y_0 \\in {\\bf R}^{d-1}}")#text(", the set ")#mi("{E^{y_0} := \\{ x_0 \\in {\\bf R}: (x_0,y_0) \\in E_{e_1} \\}}")#text(" is a null set in ")#mi("{{\\bf R}}")#text(". Applying Tonelli’s theorem for sets (Corollary ")#link(<tao-018d7f61c7b4616b2a0a>)[#text("40")]#text("), we conclude that ")#mi("{E_{e_1}}")#text(" is a null set as required.")#linebreak()#text(" We would like to now conclude that ")#mi("{\\bigcup_{v \\in {\\bf R}^d} E_v}")#text(" is a null set, but there are uncountably many ")#mi("{v}")#text("‘s, so this is not directly possible. However, as ")#mi("{{\\bf Q}^d}")#text(" is countable, we can at least assert that ")#mi("{E := \\bigcup_{v \\in {\\bf Q}^d} E_v}")#text(" is a null set. In particular, for almost every ")#mi("{x_0 \\in {\\bf R}^d}")#text(", ")#mi("{f}")#text(" is directionally differentiable in every rational direction ")#mi("{v \\in {\\bf Q}^d}")#text(".")#linebreak()#text(" Now we perform an important trick, in which we interpret the directional derivative ")#mi("{D_v f}")#text(" as a ")#link("http://en.wikipedia.org/wiki/Weak_derivative")[#text("weak derivative")]#text(". We already know that ")#mi("{D_v f}")#text(" is almost everywhere defined, bounded and measurable. Now let ")#mi("{g: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" be any function that is compactly supported and Lipschitz continuous. We investigate the integral")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} D_v f(x) g(x)\\ dx.")]]

#text("This integral is absolutely convergent since ")#mi("{D_v f(x)}")#text(" is bounded and measurable, and ")#mi("{g(x)}")#text(" is continuous and compactly supported, hence bounded. We expand this out as")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} \\lim_{h \\rightarrow 0; h \\in {\\bf R} \\backslash \\{0\\}} \\frac{f(x+hv)-f(x)}{h} g(x)\\ dx.")]]

#text("Note (from the Lipschitz nature of ")#mi("{f}")#text(") that the expression ")#mi("{\\frac{f(x+hv)-f(x)}{h} g(x)}")#text(" is bounded uniformly in ")#mi("{h}")#text(" and ")#mi("{x}")#text(", and is also uniformly compactly supported in ")#mi("{x}")#text(" for ")#mi("{h}")#text(" in a bounded set. We may thus apply the Lebesgue dominated convergence theorem to pull the limit out of the integral to obtain")

#align(center)[#tao-fit-display[#mitex("\\lim_{h \\rightarrow 0; h \\in {\\bf R} \\backslash \\{0\\}} \\int_{{\\bf R}^d} \\frac{f(x+hv)-f(x)}{h} g(x)\\ dx.")]]

#text("Now, from translation invariance of the Lebesgue integral (Exercise 15 of Notes 2) we have")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} f(x+hv) g(x)\\ dx = \\int_{{\\bf R}^d} f(x) g(x-hv)\\ dx")]]

#text("and so (by the lienarity of the Lebesgue integral) we may rearrange the previous expression as")

#align(center)[#tao-fit-display[#mitex("\\lim_{h \\rightarrow 0; h \\in {\\bf R} \\backslash \\{0\\}} \\int_{{\\bf R}^d} f(x) \\frac{g(x-hv)-g(x)}{h}\\ dx.")]]

#text("Now, as ")#mi("{g}")#text(" is Lipschitz, we know that ")#mi("{\\frac{g(x-hv)-g(x)}{h}}")#text(" is uniformly bounded and converges pointwise almost everywhere to ")#mi("{D_{-v} g(x)}")#text(" as ")#mi("{h \\rightarrow 0}")#text(". We may thus apply the dominated convergence theorem again and end up with the ")#emph[#text("integration by parts formula")]#text(" ")#metadata(none) <tao-f7c3684c915e478b24de>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\int_{{\\bf R}^d} D_v f(x) g(x)\\ dx = \\int_{{\\bf R}^d} f(x) D_{-v} g(x)\\ dx.")]]

#text("This formula moves the directional derivative operator ")#mi("{D_v}")#text(" from ")#mi("{f}")#text(" over to ")#mi("{g}")#text(". At present, this does not look like much of an advantage, because ")#mi("{g}")#text(" is the same sort of function that ")#mi("{f}")#text(" is. However, the key point is that we can choose ")#mi("{g}")#text(" to be whatever we please, whereas ")#mi("{f}")#text(" is fixed. In particular, we can choose ")#mi("{g}")#text(" to be a compactly supported, ")#emph[#text("continuously differentiable")]#text(" function (such functions are Lipschitz from the fundamental theorem of calculus, as their derivatives are bounded). By Exercise 54, one has ")#mi("{D_{-v} g = - v \\cdot \\nabla g}")#text(" for such functions, and so")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} D_v f(x) g(x)\\ dx = - \\int_{{\\bf R}^d} f(x) (v \\cdot \\nabla g)(x)\\ dx.")]]

#text("The right-hand side is linear in ")#mi("{v}")#text(", and so the left-hand side must be linear in ")#mi("{v}")#text(" also. In particular, if ")#mi("{v = (v_1,\\ldots,v_d)}")#text(", then we have")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} D_v f(x) g(x)\\ dx = \\sum_{j=1}^d v_j \\int_{{\\bf R}^d} D_{e_j} f(x) g(x)\\ dx.")]]

#text("If we define the gradient candidate function")

#align(center)[#tao-fit-display[#mitex("\\nabla f(x) := (D_{e_1} f(x), \\ldots, D_{e_d} f(x)) = (\\frac{\\partial f}{\\partial x_1}(x), \\ldots, \\frac{\\partial f}{\\partial x_d}(x))")]]

#text("(note that this function is well-defined almost everywhere, even though we don’t know yet whether ")#mi("{f}")#text(" is totally differentiable almost everywhere), we thus have")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} (D_v f - v \\cdot \\nabla f)(x) g(x)\\ dx = 0")]]

#text("for all compactly supported, continuously differentiable ")#mi("{g}")#text(". This implies (see Exercise ")#link(<tao-9be7b8a33de00c62605c>)[#text("58")]#text(" below) that ")#mi("{F_v := D_v f - v \\cdot \\nabla f}")#text(" vanishes almost everywhere, thus (by countable subadditivity) we have ")#metadata(none) <tao-055b511edb9748e24c39>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("D_v f(x_0) = v \\cdot \\nabla f(x_0)")]]

#text("for almost every ")#mi("{x_0 \\in {\\bf R}^d}")#text(" and every ")#mi("{v \\in {\\bf Q}^d}")#text(".")#linebreak()#text(" Let ")#mi("{x_0}")#text(" be such that ")#link(<tao-055b511edb9748e24c39>)[#text("(12)")]#text(" holds for all ")#mi("{v \\in {\\bf Q}^d}")#text(". We claim that this forces ")#mi("{f}")#text(" to be totally differentiable at ")#mi("{x_0}")#text(", which would give the claim. Let ")#mi("{F: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" be the modified function")

#align(center)[#tao-fit-display[#mitex("F(h) := f(x_0+h) - f(x_0) - h \\cdot \\nabla f(x_0).")]]

#text("Our objective is to show that")

#align(center)[#tao-fit-display[#tao-math("\\lim_{h \\rightarrow 0; h \\in {\\bf R}^d \\backslash \\{0\\}} \\left|F(h)\\right| / \\left|h\\right| = 0.", block: true)]]

#text("On the other hand, we have ")#mi("{F(0)=0}")#text(", ")#mi("{F}")#text(" is Lipschitz, and from ")#link(<tao-055b511edb9748e24c39>)[#text("(12)")]#text(" we see that ")#mi("{D_v F(0) = 0}")#text(" for every ")#mi("{v \\in {\\bf Q}^d}")#text(".")#linebreak()#text(" Let ")#mi("{\\varepsilon > 0}")#text(", and suppose that ")#mi("{h \\in {\\bf R}^d \\backslash \\{0\\}}")#text(". Then we can write ")#mi("{h = r u}")#text(" where ")#tao-math("{r := \\left|h\\right|}", block: false)#text(" and ")#tao-math("{u := h/\\left|h\\right|}", block: false)#text(" lies on the unit sphere. This ")#mi("{u}")#text(" need not lie in ")#mi("{{\\bf Q}^d}")#text(", but we can approximate it by some vector ")#mi("{v \\in {\\bf Q}^d}")#text(" with ")#tao-math("{\\left|u-v\\right| \\leq \\varepsilon}", block: false)#text(". Furthermore, by the total boundedness of the unit sphere, we can make ")#mi("{v}")#text(" lie in a finite subset ")#mi("{V_\\varepsilon}")#text(" of ")#mi("{{\\bf Q}^d}")#text(" that only depends on ")#mi("{\\varepsilon}")#text(" (and on ")#mi("{d}")#text(").")#linebreak()#text(" Since ")#mi("{D_v F(0) = 0}")#text(" for all ")#mi("{v \\in V_\\varepsilon}")#text(", we see (by making ")#tao-math("{\\left|h\\right|}", block: false)#text(" small enough depending on ")#mi("{V_\\varepsilon}")#text(") that we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{F(rv)-F(0)}{r}\\right| \\leq \\varepsilon", block: true)]]

#text("for all ")#mi("{v \\in V_\\varepsilon}")#text(", and thus")

#align(center)[#tao-fit-display[#tao-math("\\left|F(rv)\\right| \\leq \\varepsilon r.", block: true)]]

#text("On the other hand, from the Lipschitz nature of ")#mi("{F}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|F(ru) - F(rv)\\right| \\leq C r \\left|u-v\\right| \\leq C r \\varepsilon", block: true)]]

#text("where ")#mi("{C}")#text(" is the Lipschitz constant of ")#mi("{F}")#text(". As ")#mi("{h=ru}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|F(h)\\right| \\leq (C+1) r \\varepsilon.", block: true)]]

#text("In other words, we have shown that")

#align(center)[#tao-fit-display[#tao-math("\\left|F(h)\\right|/\\left|h\\right| \\leq (C+1)\\varepsilon", block: true)]]

#text("whenever ")#tao-math("{\\left|h\\right|}", block: false)#text(" is sufficiently small depending on ")#mi("{\\varepsilon}")#text(". Letting ")#mi("{\\varepsilon \\rightarrow 0}")#text(", we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 58")]#text(" ")#metadata(none) <tao-9be7b8a33de00c62605c>#text(" Let ")#mi("{F: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" be a locally integrable function with the property that ")#mi("{\\int_{{\\bf R}^d} F(x) g(x)\\ dx=0}")#text(" whenever ")#mi("{g}")#text(" is a compactly supported, continuously differentiable function. Show that ")#mi("{F}")#text(" is zero almost everywhere. (")#emph[#text("Hint:")]#text(" if not, use the Lebesgue differentiation theorem to find a Lebesgue point ")#mi("{x_0}")#text(" of ")#mi("{F}")#text(" for which ")#mi("{F(x_0) \\neq 0}")#text(", then pick a ")#mi("{g}")#text(" which is supported in a sufficiently small neighbourhood of ")#mi("{x_0}")#text(".)")
]

#heading(level: 1)[#strong[#text(" — 6. Infinite product spaces and the Kolmogorov extension theorem (optional) — ")]]

#text("In Section ")#link(<tao-345a28a6901ff4628a34>)[#text("4")]#text(" we considered the product of two sets, measurable spaces, or (")#mi("{\\sigma}")#text("-finite) measure spaces. We now consider how to generalise this concept to products of more than two such spaces. The axioms of set theory allow us to form a Cartesian product ")#mi("{X_A := \\prod_{\\alpha \\in A} X_\\alpha}")#text(" of any family ")#mi("{(X_\\alpha)_{\\alpha \\in A}}")#text(" of sets indexed by another set ")#mi("{A}")#text(", which consists of the space of all tuples ")#mi("{x_A = (x_\\alpha)_{\\alpha \\in A}}")#text(" indexed by ")#mi("{A}")#text(", for which ")#mi("{x_\\alpha \\in X_\\alpha}")#text(" for all ")#mi("{\\alpha \\in A}")#text(". This concept allows for a succinct formulation of the ")#link("http://en.wikipedia.org/wiki/Axiom_of_choice")[#text("axiom of choice")]#text(" (Axiom 3 from ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text("), namely that an arbitrary Cartesian product of non-empty sets remains non-empty.")#linebreak()#text(" For any ")#mi("{\\beta \\in A}")#text(", we have the coordinate projection maps ")#mi("{\\pi_\\beta: X_A \\rightarrow X_\\beta}")#text(" defined by ")#mi("{\\pi_\\beta( (x_\\alpha)_{\\alpha \\in A} ) := x_\\beta}")#text(". More generally, given any ")#mi("{B \\subset A}")#text(", we define the partial projections ")#mi("{\\pi_B: X_A \\rightarrow X_B}")#text(" to the partial product space ")#mi("{X_B := \\prod_{\\alpha \\in B} X_\\alpha}")#text(" by ")#mi("{\\pi_B( (x_\\alpha)_{\\alpha \\in A} ) := (x_\\alpha)_{\\alpha \\in B}}")#text(". More generally still, given two subsets ")#mi("{C \\subset B \\subset A}")#text(", we have the partial subprojections ")#mi("{\\pi_{C \\leftarrow B}: X_B \\rightarrow X_C}")#text(" defined by ")#mi("{\\pi_{C \\leftarrow B}( (x_\\alpha)_{\\alpha\\in B} ) := (x_\\alpha)_{\\alpha \\in C}}")#text(". These partial subprojections obey the composition law ")#mi("{\\pi_{D \\leftarrow C} \\circ \\pi_{C \\leftarrow B} := \\pi_{D \\leftarrow B}}")#text(" for all ")#mi("{D \\subset C \\subset B \\subset A}")#text(" (and thus form a very simple example of a ")#link("http://en.wikipedia.org/wiki/Category_(mathematics)")[#text("category")]#text(").")#linebreak()#text(" As before, given any ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}_\\beta}")#text(" on ")#mi("{X_\\beta}")#text(", we can pull it back by ")#mi("{\\pi_\\beta}")#text(" to create a ")#mi("{\\sigma}")#text("-algebra")

#align(center)[#tao-fit-display[#mitex("\\pi_\\beta^{*}({\\mathcal B}_\\beta) := \\{ \\pi_\\beta^{-1}(E_\\beta): E_\\beta \\in {\\mathcal B}_\\beta \\}")]]

#text("on ")#mi("{X_A}")#text(". One easily verifies that this is indeed a ")#mi("{\\sigma}")#text("-algebra. Informally, ")#mi("{\\pi_\\beta^{*}({\\mathcal B}_\\beta)}")#text(" describes those sets (or “events”, if one is thinking in probabilistic terms) that depend only on the ")#mi("{x_\\beta}")#text(" coordinate of the state ")#mi("{x_A = (x_\\alpha)_{\\alpha \\in A}}")#text(", and whose dependence on ")#mi("{x_\\beta}")#text(" is ")#mi("{{\\mathcal B}_\\beta}")#text("-measurable. We can then define the product ")#mi("{\\sigma}")#text("-algebra")

#align(center)[#tao-fit-display[#mitex("\\prod_{\\beta \\in A} {\\mathcal B}_\\beta := \\langle \\bigcup_{\\beta \\in A} \\pi_\\beta^{*}({\\mathcal B}_\\beta) \\rangle.")]]

#text("We have a generalisation of Exercise ")#link(<tao-227ad062d6deda524b0a>)[#text("27")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 59")]#text(" ")#metadata(none) <tao-69d8a5965f9ddb29426b>#text(" Let ")#mi("{((X_\\alpha,{\\mathcal B}_\\alpha))_{\\alpha \\in A}}")#text(" be a family of measurable spaces. For any ")#mi("{B \\subset A}")#text(", write ")#mi("{{\\mathcal B}_B := \\prod_{\\beta \\in B} {\\mathcal B}_\\beta}")#text(".")

#enum(start: 1, 
[#text("Show that ")#mi("{{\\mathcal B}_A}")#text(" is the coarsest ")#mi("{\\sigma}")#text("-algebra on ")#mi("{X_A}")#text(" that makes the projection maps ")#mi("{\\pi_\\beta}")#text(" measurable morphisms for all ")#mi("{\\beta \\in A}")#text(".")],
[#text("Show that for each ")#mi("{B \\subset A}")#text(", that ")#mi("{\\pi_B}")#text(" is a measurable morphism from ")#mi("{(X_A,{\\mathcal B}_A)}")#text(" to ")#mi("{(X_B, {\\mathcal B}_B)}")#text(".")],
[#text("If ")#mi("{E_A}")#text(" in ")#mi("{{\\mathcal B}_A}")#text(", show that there exists an at most countable set ")#mi("{B \\subset A}")#text(" and a set ")#mi("{E_B \\in {\\mathcal B}_B}")#text(" such that ")#mi("{E_A = \\pi_B^{-1}(E_B)}")#text(". Informally, this asserts that a measurable event can only depend on at most countably many of the coefficients.")],
[#text("If ")#mi("{f: X_A \\rightarrow [0,+\\infty]}")#text(" is ")#mi("{{\\mathcal B}_A}")#text("-measurable, show that there exists an at most countable set ")#mi("{B \\subset A}")#text(" and a ")#mi("{{\\mathcal B}_B}")#text("-measurable function ")#mi("{f_B: X_B \\rightarrow [0,+\\infty]}")#text(" such that ")#mi("{f = f_B \\circ \\pi_B}")#text(".")],
[#text("If ")#mi("{A}")#text(" is at most countable, show that ")#mi("{{\\mathcal B}_A}")#text(" is the ")#mi("{\\sigma}")#text("-algebra generated by the sets ")#mi("{\\prod_{\\beta\\in A} E_\\beta}")#text(" with ")#mi("{E_\\beta \\in {\\mathcal B}_\\beta}")#text(" for all ")#mi("{\\beta \\in A}")#text(".")],
[#text("On the other hand, show that if ")#mi("{A}")#text(" is uncountable and the ")#mi("{{\\mathcal B}_\\alpha}")#text(" are all non-trivial, show that ")#mi("{{\\mathcal B}_A}")#text(" is ")#emph[#text("not")]#text(" the ")#mi("{\\sigma}")#text("-algebra generated by sets ")#mi("{\\prod_{\\beta\\in A} E_\\beta}")#text(" with ")#mi("{E_\\beta \\in {\\mathcal B}_\\beta}")#text(" for all ")#mi("{\\beta \\in A}")#text(".")],
[#text("If ")#mi("{B \\subset A}")#text(", ")#mi("{E \\in {\\mathcal B}_A}")#text(", and ")#mi("{x_{A\\backslash B} \\in X_{A \\backslash B}}")#text(", show that the set ")#mi("{E_{x_{A\\backslash B},B} := \\{ x_B \\in X_B: (x_B, x_{A \\backslash B}) \\in E \\}}")#text(" lies in ")#mi("{{\\mathcal B}_B}")#text(", where we identify ")#mi("{X_B \\times X_{A \\backslash B}}")#text(" with ")#mi("{X_A}")#text(" in the obvious manner.")],
[#text("If ")#mi("{B \\subset A}")#text(", ")#mi("{f: X_A \\rightarrow [0,+\\infty]}")#text(" is ")#mi("{{\\mathcal B}_A}")#text("-measurable, and ")#mi("{x_{A\\backslash B} \\in X_{A \\backslash B}}")#text(", show that the function ")#mi("{f_{x_{A\\backslash B},B}: x_B \\rightarrow f(x_B, x_{A \\backslash B})}")#text(" is ")#mi("{{\\mathcal B}_B}")#text("-measurable.")]
)
]

#text("Now we consider the problem of constructing a measure ")#mi("{\\mu_A}")#text(" on the product space ")#mi("{X_A}")#text(". Any such measure ")#mi("{\\mu_A}")#text(" will induce ")#emph[#text("pushforward measures")]#text(" ")#mi("{\\mu_B := (\\pi_B)_* \\mu_A}")#text(" on ")#mi("{X_B}")#text(" (introduced in Exercise 36 of ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems")[#text("Notes 3")]#text("), thus")

#align(center)[#tao-fit-display[#mitex("\\mu_B(E_B) := \\mu_A( \\pi_B^{-1}(E_B) )")]]

#text("for all ")#mi("{E_B\\in {\\mathcal B}_B}")#text(". These measures obey the compatibility relation ")#metadata(none) <tao-9ea2483b344bb5c59f34>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("(\\pi_{C \\leftarrow B})_* \\mu_B = \\mu_C")]]

#text("whenever ")#mi("{C \\subset B \\subset A}")#text(", as can be easily seen by chasing the definitions.")#linebreak()#text(" One can then ask whether one can reconstruct ")#mi("{\\mu_A}")#text(" from just from the projections ")#mi("{\\mu_B}")#text(" to ")#emph[#text("finite")]#text(" subsets ")#mi("{B}")#text(". This is possible in the important special case when the ")#mi("{\\mu_B}")#text(" (and hence ")#mi("{\\mu_A}")#text(") are probability measures, provided one imposes an additional ")#link("http://en.wikipedia.org/wiki/Inner_regular_measure")[#text("inner regularity")]#text(" hypothesis on the measures ")#mi("{\\mu_B}")#text(". More precisely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 60 (Inner regularity)")]#text(" A (metrisable) inner regular measure space ")#mi("{(X, {\\mathcal B},\\mu,d)}")#text(" is a measure space ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" equipped with a metric ")#mi("{d}")#text(" such that")

#enum(start: 1, 
[#text("Every compact set is measurable; and")],
[#text("One has ")#mi("{\\mu(E) = \\sup_{K \\subset E, K \\text{ compact}} \\mu(K)}")#text(" for all measurable ")#mi("{E}")#text(".")]
)

#text("We say that ")#mi("{\\mu}")#text(" is ")#emph[#text("inner regular")]#text(" if it is associated to an inner regular measure space.")
]

#text("Thus for instance Lebesgue measure is inner regular, as are Dirac measures and counting measures. Indeed, most measures that one actually encounters in applications will be inner regular. For instance, any finite Borel measure on ")#mi("{{\\bf R}^d}")#text(" (or more generally, on a locally compact, ")#mi("{\\sigma}")#text("-compact space) is inner regular (see Exercise 12 of ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("245B Notes 12")]#text("). Inner regularity is one of the axioms of a ")#link("http://en.wikipedia.org/wiki/Radon_measure")[#text("Radon measure")]#text(", which we will discuss in more detail ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("in 245B")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 61")]#text(" One can generalise the concept of an inner regular measure space to one which is given by a topology rather than a metric; Kolmogorov’s extension theorem still holds in this more general setting, but requires ")#link("http://en.wikipedia.org/wiki/Tychonoff's_theorem")[#text("Tychonoff’s theorem")]#text(", which we will cover in ")#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/")[#text("245B Notes 10")]#text(". However, some minimal regularity hypotheses of a topological nature are needed to make the Kolmogorov extension theorem work, although this is usually not a severe restriction in practice.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 62 (Kolmogorov extension theorem)")]#text(" Let ")#mi("{((X_\\alpha,{\\mathcal B}_\\alpha),{\\mathcal F}_\\alpha)_{\\alpha \\in A}}")#text(" be a family of measurable spaces ")#mi("{(X_\\alpha,{\\mathcal B}_\\alpha)}")#text(", equipped with a topology ")#mi("{{\\mathcal F}_\\alpha}")#text(". For each finite ")#mi("{B \\subset A}")#text(", let ")#mi("{\\mu_B}")#text(" be an inner regular probability measure on ")#mi("{{\\mathcal B}_B := \\prod_{\\alpha \\in B} {\\mathcal B}_\\alpha}")#text(" with the product topology ")#mi("{{\\mathcal F}_B := \\prod_{\\alpha \\in B} {\\mathcal F}_\\alpha}")#text(", obeying the compatibility condition ")#link(<tao-9ea2483b344bb5c59f34>)[#text("(13)")]#text(" whenever ")#mi("{C \\subset B \\subset A}")#text(" are two nested finite subsets of ")#mi("{A}")#text(". Then there exists a unique probability measure ")#mi("{\\mu_A}")#text(" on ")#mi("{{\\mathcal B}_A}")#text(" with the property that ")#mi("{(\\pi_B)_* \\mu_A = \\mu_B}")#text(" for all finite ")#mi("{B \\subset A}")#text(".")
]

#emph[#text("Proof:")]#text(" Our main tool here will be the Hahn-Kolmogorov extension theorem for pre-measures (Theorem ")#link(<tao-66b3b534b5a851cc90da>)[#text("14")]#text("), combined with the Heine-Borel theorem.")#linebreak()#text(" Let ")#mi("{{\\mathcal B}_0}")#text(" be the set of all subsets of ")#mi("{X_A}")#text(" that are of the form ")#mi("{\\pi_B^{-1}( E_B )}")#text(" for some finite ")#mi("{B \\subset A}")#text(" and some ")#mi("{E_B \\in {\\mathcal B}_B}")#text(". One easily verifies that this is a Boolean algebra that is contained in ")#mi("{{\\mathcal B}_A}")#text(". We define a function ")#mi("{\\mu_0: {\\mathcal B}_0 \\rightarrow [0,+\\infty]}")#text(" by setting")

#align(center)[#tao-fit-display[#mitex("\\mu_0( E ) := \\mu_B( E_B )")]]

#text("whenever ")#mi("{E}")#text(" takes the form ")#mi("{\\pi_B^{-1}(E_B)}")#text(" for some finite ")#mi("{B \\subset A}")#text(" and ")#mi("{E_B \\in {\\mathcal B}_B}")#text(". Note that a set ")#mi("{E \\in {\\mathcal B}_0}")#text(" may have two different representations ")#mi("{E = \\pi_B^{-1}(E_B) = \\pi_{B^{\\prime}}^{-1}(E_{B^{\\prime}})}")#text(" for some finite ")#mi("{B,B^{\\prime} \\subset A}")#text(", but then one must have ")#mi("{E_B = \\pi_{B \\leftarrow B \\cup B^{\\prime}}(E_{B \\cup B^{\\prime}})}")#text(" and ")#mi("{E_{B^{\\prime}} = \\pi_{B^{\\prime} \\leftarrow B \\cup B^{\\prime}}(E_{B \\cup B^{\\prime}})}")#text(", where ")#mi("{E_{B \\cup B^{\\prime}} := \\pi_{B \\cup B^{\\prime}}(E)}")#text(". Applying ")#link(<tao-9ea2483b344bb5c59f34>)[#text("(13)")]#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\mu_B(E_B) = \\mu_{B \\cup B^{\\prime}}(E_{B \\cup B^{\\prime}})")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\mu_{B^{\\prime}}(E_{B^{\\prime}}) = \\mu_{B \\cup B^{\\prime}}(E_{B \\cup B^{\\prime}})")]]

#text("and thus ")#mi("{\\mu_B(E_B) = \\mu_{B^{\\prime}}(E_{B^{\\prime}})}")#text(". This shows that ")#mi("{\\mu_0(E)}")#text(" is well defined. As the ")#mi("{\\mu_B}")#text(" are probability measures, we see that ")#mi("{\\mu_0(X_A)=1}")#text(".")#linebreak()#text(" It is not difficult to see that ")#mi("{\\mu_0}")#text(" is finitely additive. We now claim that ")#mi("{\\mu_0}")#text(" is a pre-measure. In other words, we claim that if ")#mi("{E \\in {\\mathcal B}_0}")#text(" is the disjoint countable union ")#mi("{E = \\bigcup_{n=1}^\\infty E_n}")#text(" of sets ")#mi("{E_n \\in {\\mathcal B}_0}")#text(", then ")#mi("{\\mu_0(E) = \\sum_{n=1}^\\infty \\mu_0(E_n)}")#text(".")#linebreak()#text(" For each ")#mi("{N \\geq 1}")#text(", let ")#mi("{F_N := E \\backslash \\bigcup_{n=1}^N E_N}")#text(". Then the ")#mi("{F_N}")#text(" lie in ")#mi("{{\\mathcal B}_0}")#text(", are decreasing, and are such that ")#mi("{\\bigcap_{N=1}^\\infty F_N = \\emptyset}")#text(". By finite additivity (and the finiteness of ")#mi("{\\mu_0}")#text("), we see that it suffices to show that ")#mi("{\\lim_{N \\rightarrow \\infty} \\mu_0(F_N) = 0}")#text(".")#linebreak()#text(" Suppose this is not the case, then there exists ")#mi("{\\varepsilon > 0}")#text(" such that ")#mi("{\\mu_0(F_N) > \\varepsilon}")#text(" for all ")#mi("{N}")#text(". As each ")#mi("{F_N}")#text(" lies in ")#mi("{{\\mathcal B}_0}")#text(", we have ")#mi("{F_N = \\pi_{B_N}^{-1}(G_N)}")#text(" for some finite sets ")#mi("{B_N \\subset A}")#text(" and some ")#mi("{{\\mathcal B}_{B_N}}")#text("-measurable sets ")#mi("{G_N}")#text(". By enlarging each ")#mi("{B_N}")#text(" as necessary we may assume that the ")#mi("{B_N}")#text(" are increasing in ")#mi("{N}")#text(". The decreasing nature of the ")#mi("{F_N}")#text(" then gives the inclusions")

#align(center)[#tao-fit-display[#mitex("G_{N+1} \\subset \\pi_{B_N \\leftarrow B_{N+1}}^{-1}(G_N).")]]

#text("By inner regularity, one can find a compact subset ")#mi("{K_N}")#text(" of each ")#mi("{G_N}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\mu_{B_N}(K_N) \\geq \\mu_{B_N}(G_N) - \\varepsilon/2^{N+1}.")]]

#text("If we then set")

#align(center)[#tao-fit-display[#mitex("K^{\\prime}_N := \\bigcap_{N^{\\prime}=1}^N \\pi_{B_{N^{\\prime}} \\leftarrow B_N}^{-1}( K_{N^{\\prime}} )")]]

#text("then we see that each ")#mi("{K^{\\prime}_N}")#text(" is compact and")

#align(center)[#tao-fit-display[#mitex("\\mu_{B_N}(K^{\\prime}_N) \\geq \\mu_{B_N}(G_N) - \\sum_{N^{\\prime}=1}^N \\varepsilon/2^{N^{\\prime}+1} \\geq \\varepsilon - \\varepsilon/2.")]]

#text("In particular, the sets ")#mi("{K^{\\prime}_N}")#text(" are non-empty. By construction, we also have the inclusions")

#align(center)[#tao-fit-display[#mitex("K^{\\prime}_{N+1} \\subset \\pi_{B_N \\leftarrow B_{N+1}}^{-1}(K^{\\prime}_N)")]]

#text("and thus the sets ")#mi("{H_N := \\pi_{B_N}^{-1}(K^{\\prime}_N)}")#text(" are decreasing in ")#mi("{N}")#text(". On the other hand, since these sets are contained in ")#mi("{F_N}")#text(", we have ")#mi("{\\bigcap_{N=1}^\\infty H_N = \\emptyset}")#text(".")#linebreak()#text(" By the axiom of choice, we can select an element ")#mi("{x_N \\in H_N}")#text(" from ")#mi("{H_N}")#text(" for each ")#mi("{N}")#text(". Observe that for any ")#mi("{N_0}")#text(", that ")#mi("{\\pi_{B_{N_0}}(x_N)}")#text(" will lie in the compact set ")#mi("{K^{\\prime}_{N_0}}")#text(" whenever ")#mi("{N \\geq N_0}")#text(". Applying the Heine-Borel theorem repeatedly, we may thus find a subsequence ")#mi("{x_{N_{1,m}}}")#text(" of the ")#mi("{x_N}")#text(" for ")#mi("{m=1,2,\\ldots}")#text(" such that ")#mi("{\\pi_{B_1}(x_{N_{1,m}})}")#text(" converges; then we can find a further subsequence ")#mi("{x_{N_{2,m}}}")#text(" of that subsequence such that ")#mi("{\\pi_{B_2}(x_{N_{2,m}})}")#text(", and more generally obtain nested subsequences ")#mi("{x_{N_{j,m}}}")#text(" for ")#mi("{m=1,2,\\ldots}")#text(" and ")#mi("{j=1,2,\\ldots}")#text(" such that for each ")#mi("{j=1,2,\\ldots}")#text(", the sequence ")#mi("{m \\mapsto \\pi_{B_j}(x_{N_{j,m}})}")#text(" converges.")#linebreak()#text(" Now we use the diagonalisation trick. Consier the sequence ")#mi("{x_{N_{m,m}} =: (y_{m,\\alpha})_{\\alpha \\in A}}")#text(" for ")#mi("{m=1,2,\\ldots}")#text(". By construction, we see that for each ")#mi("{j}")#text(", ")#mi("{\\pi_{B_j}(x_{N_{m,m}})}")#text(" converges to a limit as ")#mi("{m \\rightarrow \\infty}")#text(". This implies that for each ")#mi("{\\alpha \\in \\bigcup_{j=1}^\\infty B_j}")#text(", ")#mi("{y_{m,\\alpha}}")#text(" converges to a limit ")#mi("{y_\\alpha}")#text(" as ")#mi("{m \\rightarrow \\infty}")#text(". As ")#mi("{K^{\\prime}_j}")#text(" is closed, we see that ")#mi("{(y_\\alpha)_{\\alpha \\in B_j} \\in K^{\\prime}_j}")#text(" for each ")#mi("{j}")#text(". If we then extend ")#mi("{y_\\alpha}")#text(" arbitrarily from ")#mi("{\\alpha \\in \\bigcup_{j=1}^\\infty B_j}")#text(" to ")#mi("{\\alpha \\in A}")#text(", then the point ")#mi("{y := (y_\\alpha)_{\\alpha \\in A}}")#text(" lies in ")#mi("{H_j}")#text(" for each ")#mi("{j}")#text(". But this contradicts the fact that ")#mi("{\\bigcap_{N=1}^\\infty H_N=\\emptyset}")#text(". This contradiction completes the proof that ")#mi("{\\mu_0}")#text(" is a pre-measure.")#linebreak()#text(" If we then let ")#mi("{\\mu}")#text(" be the Hahn-Kolmogorov extension of ")#mi("{\\mu_0}")#text(", one easily verifies that ")#mi("{\\mu}")#text(" obeys all the required properties, and the uniqueness follows from Exercise ")#link(<tao-234225f66642ae73f16f>)[#text("15")]#text(". ")#mi("\\Box")#linebreak()#text(" The Kolmogorov extension theorem is a fundamental tool in the foundations of probability theory, as it allows one to construct a probability space to hold a variety of random processes ")#mi("{(X_t)_{t \\in T}}")#text(", both in the discrete case (when the set of times ")#mi("{T}")#text(" is something like the integers ")#mi("{{\\bf Z}}")#text(") and in the continuous case (when the set of times ")#mi("{T}")#text(" is something like ")#mi("{{\\bf R}}")#text("). In particular, it can be used to rigorously construct a process for ")#link("http://en.wikipedia.org/wiki/Brownian_motion")[#text("Brownian motion")]#text(", known as the ")#link("http://en.wikipedia.org/wiki/Wiener_process")[#text("Wiener process")]#text(". We will however not focus on this topic, which can be found in many graduate probability texts. But we will give one common special case of the Kolmogorov extension theorem, which is to construct product probability measures:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 63 (Existence of product measures)")]#text(" ")#metadata(none) <tao-a8792157cb4f27fb949c>#text(" Let ")#mi("{A}")#text(" be an arbitrary set. For each ")#mi("{\\alpha \\in A}")#text(", let ")#mi("{(X_\\alpha,{\\mathcal B}_\\alpha,\\mu_\\alpha)}")#text(" be a probability space in which ")#mi("{X_\\alpha}")#text(" is a locally compact, ")#link("http://en.wikipedia.org/wiki/%CE%A3-compact_space")[#mi("{\\sigma}")#text("-compact")]#text(" metric space, with ")#mi("{{\\mathcal B}_\\alpha}")#text(" being its Borel ")#mi("{\\sigma}")#text("-algebra (i.e. the ")#mi("{\\sigma}")#text("-algebra generated by the open sets). Then there exists a unique probability measure ")#mi("{\\mu_A = \\prod_{\\alpha \\in A} \\mu_\\alpha}")#text(" on ")#mi("{(X_A,{\\mathcal B}_A) := (\\prod_{\\alpha \\in A} X_\\alpha, \\prod_{\\alpha \\in A} {\\mathcal B}_\\alpha)}")#text(" with the property that")

#align(center)[#tao-fit-display[#mitex("\\mu_A( \\prod_{\\alpha \\in A} E_\\alpha ) = \\prod_{\\alpha \\in A} \\mu_\\alpha(E_\\alpha)")]]

#text("whenever ")#mi("{E_\\alpha \\in {\\mathcal B}_\\alpha}")#text(" for each ")#mi("{\\alpha \\in A}")#text(", and one has ")#mi("{E_\\alpha=X_\\alpha}")#text(" for all but finitely many of the ")#mi("{\\alpha}")#text(".")
]

#emph[#text("Proof:")]#text(" We apply the Kolmogorov extension theorem to the finite product measures ")#mi("{\\mu_B := \\prod_{\\alpha \\in B} \\mu_\\alpha}")#text(" for finite ")#mi("{B \\subset A}")#text(", which can be constructed using the machinery in Section ")#link(<tao-345a28a6901ff4628a34>)[#text("4")]#text(". These are Borel probability measures on a locally compact, ")#mi("{\\sigma}")#text("-compact space and are thus inner regular by Exercise 12 of ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("245B Notes 12")]#text(". The compatibility condition ")#link(<tao-9ea2483b344bb5c59f34>)[#text("(13)")]#text(" can be verified from the uniqueness properties of finite product measures. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 64")]#text(" This result can also be obtained from the }{Riesz representation theorem}, which we will cover in ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("245B Notes 12")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 65 (Bernoulli cube)")]#text(" Let ")#mi("{A := {\\bf N}}")#text(", and for each ")#mi("{\\alpha \\in A}")#text(", let ")#mi("{(X_\\alpha,{\\mathcal B}_\\alpha,\\mu_\\alpha)}")#text(" be the two-element set ")#mi("{X_\\alpha = \\{0,1\\}}")#text(" with the discrete metric (and thus discrete ")#mi("{\\sigma}")#text("-algebra) and the uniform probability measure ")#mi("{\\mu_\\alpha}")#text(". Then Theorem ")#link(<tao-a8792157cb4f27fb949c>)[#text("63")]#text(" gives a probability measure ")#mi("{\\mu}")#text(" on the infinite discrete cube ")#mi("{X_A := \\{0,1\\}^{\\bf N}}")#text(", known as the (uniform) ")#emph[#text("Bernoulli measure")]#text(" on this cube. The coordinate functions ")#mi("{\\pi_\\alpha: X_A \\rightarrow \\{0,1\\}}")#text(" can then be interpreted as a countable sequence of random variables taking values in ")#mi("{\\{0,1\\}}")#text(". From the properties of product measure one can easily check that these random variables are uniformly distributed on ")#mi("{\\{0,1\\}}")#text(" and are jointly ")#link("http://en.wikipedia.org/wiki/Independence_(probability_theory)")[#text("independent")]#text(". Informally, Bernoulli measure allows one to model an infinite number of “coin flips”. One can replace the natural numbers here by any other index set, and have a similar construction.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 66 (Continuous cube)")]#text(" We repeat the previous example, but replace ")#mi("{\\{0,1\\}}")#text(" with the unit interval ")#mi("{[0,1]}")#text(" (with the usual metric, the Borel ")#mi("{\\sigma}")#text("-algebra, and the uniform probability measure). This gives a probability measure on the infinite continuous cube ")#mi("{[0,1]^{\\bf N}}")#text(", and the coordinate functions ")#mi("{\\pi_\\alpha: X_A \\rightarrow [0,1]}")#text(" can now be interpreted as jointly independent random variables, each having the uniform distribution on ")#mi("{[0,1]}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 67 (Independent gaussians)")]#text(" We repeat the previous example, but now replace ")#mi("{[0,1]}")#text(" with ")#mi("{{\\bf R}}")#text(" (with the usual metric, and the Borel ")#mi("{\\sigma}")#text("-algebra), and the normal probability distribution ")#mi("{d\\mu_\\alpha = \\frac{1}{\\sqrt{2\\pi}} e^{-x^2/2}\\ dx}")#text(" (thus ")#mi("{\\mu_\\alpha(E) = \\int_E \\frac{1}{\\sqrt{2\\pi}} e^{-x^2/2}\\ dx}")#text(" for every Borel set ")#mi("{E}")#text("). This gives a probability space that supports a countable sequence of jointly independent gaussian random variables ")#mi("{\\pi_\\alpha}")#text(".")
]

#heading(level: 1)[#text("Comments (146)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-47937")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2010")])]

#text("Which course are you going to teach next semester, Prof. Tao?")#linebreak()#text(" if you will teach 245B, are you going to post new notes or just use previous’ year notes?")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-47951")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2010")])]

#text("I will be on sabbatical next quarter.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Asymptotic decay for a one-dimensional nonlinear wave equation « What’s new")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-47973")[#strong[#text("Asymptotic decay for a one-dimensional nonlinear wave equation « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2010")])]

#text("[…] this theorem in my current course, both in one dimension (which is the case of interest here) and in higher dimensions.) A compactness argument allows one to extract a quantitative estimate from this theorem (cf. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-48064")[#strong[#text("Real Analysis (=Measure Theory) by Terence Tao « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2010")]

#text("[…] Prolog: Grundfragen und Jordansche Maß Lecture 1: Das Lebesguesche Maß. Lecture 2: Das Lebesguesche Integral Lecture 3: Maße und Maßräume Lecture 4: Konvergenzbegriffe Lecture 5: Differentiation Lecture 6: Konstruktion von Maßen (Neu) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-48132")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2010")])]

#text("Typo: Ex. 11, “sup” should be “inf” in (Outer regularity).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-48627")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2010")])]

#text("It seems that exercise 9 part 1 requires sigma-finiteness? A counterexample in the non-sigma finite case could be given by the pre-measure from the previous problem by just looking at a non-borel set which is measurable by the hahn-kolmogorov extension (they exist if you just use the definition of caratheodory measurable?). ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e900aec663891280aae43a7f20f70e5cd13605589a6a988059957a169a8caa5-5ff6c42c4cd23fc4dd358a2eb98e6dae4d990c73b5c9518d8571fca5a12e3bfd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jackie")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-48682")[#strong[#text("Jackie")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2010")])]

#text("I think there is a typo in the first part of exercise 9. Namely, the words say that F is a countable intersection of the F_n, but the symbols say that F is a countable union of the F_n.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-48769")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2010")])]

#text("In Exercise 18, I wonder if you need Y to be second countable (i.e. to have a countable base)?")

#emph[#text("[No – this is only required if one wants ")#mi("{\\mathcal A}")#text(" to be independent of ")#mi("E")#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-48825")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2010")])]

#text("Hi Prof. Tao,")

#text("I have a question about the first part of exercise 9. I can show that when E is finite measure, we can find a F which is the intersection and union of some sets in B0. Next step is when E is not finite measure, we can express E as countable union of finite measure sets, for each set we can find a F_i which is the intersection and union of some sets in B0. But now, the F is the union of all these F_i, which will be union and intersection and union of some sets of B0. This is different from the require F in the problem.")

#text("Please give me some hint on this. (I have tried to compare this with R_d case.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-48826")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2010")])]

#text("Try rearranging the argument a bit. The way one constructs the set F in the finite measure case is as the intersection of sets F_n, which are countable unions of sets in B_0. It turns out that one can also construct F_n without difficulty in the sigma-finite case too, by the usual trick of working locally. Once the F_n are constructed in the sigma finite case, intersect them to get F.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-48864")[#strong[#text("Is the product of measurable spaces the categorical product? « Graduated Understanding")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2010")]

#text("[…] the following definition: A -algebra on a set is said to be coarser than a -algebra on if . In exercise 18 of Terry Tao’s notes on product measures, it is shown that is the coarsest -algebra on such that the projection maps and are both […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c621842fcf9d51f26e7ec3217721862d97a46c44e106b6eb9dc42cfbb9100dfe-f2773ca7ad7c707ec1af20c4eeb099e86710505825ad252b7877ec814377c0b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-48993")[#strong[#text("Lior")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2010")])]

#text("The hyperlink to wikipedia after Ex. 13 is mistyped. ")#emph[#text("[Corrected, thanks -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2992df609be7243e0653732f5e4400aae5f33a22ea423246ccd936395fdeb1cd-83f01d841771cf436eb3b326a35740a99276eca034165ad37247882706e9826a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ñie")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-48995")[#strong[#text("Ñie")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2010")])]

#text("I think there is a typo following the phrase “By monotonicity it suffices to show that..”, it should be an inequality not an equality.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2992df609be7243e0653732f5e4400aae5f33a22ea423246ccd936395fdeb1cd-83f01d841771cf436eb3b326a35740a99276eca034165ad37247882706e9826a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felipe Olmos")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-48996")[#strong[#text("Felipe Olmos")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2010")])]

#text("Actually, there is no mistake.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-50716")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2011")])]

#text("When doing Lebesgue integral, how can one deal with the integral of “composite function”:")#linebreak()#text(" ")#mi("\\int_{X} f\\circ g dx")#text("” where ")#mi("f\\circ g(x):=f(g(x))")#text("? It seems that one needs to generalize “integration by substitution” in the Riemann world. Is this possible?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-50717")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2011")])]

#text("Formally, one can achieve this by pushing forward Lebesgue measure by g, see Exercise 36 of ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/")[#text("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/")]#text(" .")

#text("Of course, for computational purposes one would actually like to compute this pushforward, rather than merely defining it abstractly. If g is smooth and non-singular, this can be done by using the change of variables formula from Riemann integration, and then extending from Riemann to Lebesgue by some standard method (e.g. Riesz representation theorem will suffice). Alternatively one can push around infinitesimal parallelopipeds using the inverse function theorem. Singularities of g (where the derivative fails to have full rank) do present a non-trivial problem, though (their pushforwards will be supported on a set of measure zero, by Sard’s theorem, and thus singular). One can handle these by being careful, but the theory is somewhat non-trivial.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-50921")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2011")])]

#text("Professor,")

#text("Will you be teaching this course again in the Fall?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ce33daf0ad5f933a9315b10d7dcf90b8250c5b09fa34b57290fbd778e988c6f-53dc7bf0353d634b383b48177a68becfe553fcc517a44cdcef0bc5eec2c52bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Epstein")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-126423")[#strong[#text("Paul Epstein")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2012")])]

#text("Is there a flaw in your proof of lemma 1.1.2 (ii)? Earlier, it is stated that the product function is not continuous on [0, inf] x [0, inf]. This would seem to mean that, without further justification, one can’t pass from the product of the limits to the limit of the products.")

#text("If I were writing the proof, I would restrict N to being a power of 2 to make the discretisation an increasing function of N and then use upward continuity.")

#text("Your book on measure theory seems delightful and I look forward to learning more.")

#text("Paul Epstein")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-126481")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2012")])]

#text("The product function is not continuous on ")#mi("[0,+\\infty] \\times [0,+\\infty]")#text(", but it is continuous on ")#mi("[0,+\\infty) \\times [0,+\\infty)")#text(", which suffices for the purposes of proving Lemma 1.1.2(ii) of my book. (Incidentally, the web page for that book is not this one, but rather ")#link("https://terrytao.wordpress.com/books/an-introduction-to-measure-theory/")[#text("https://terrytao.wordpress.com/books/an-introduction-to-measure-theory/")]#text(" ).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9544230e43d0df1c3ff7d00970402083d0c84d2a1b817d00403ce7929615b3e7-c58fca882b54f4eac5c8b44f684a307f7b56716cc6bb73a2af39e644dbe1b54f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-139297")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2012")])]

#text("Is the following true for outer measure?")

#mi("\\forall j\\in\\mathbb{N},A_j\\subset \\mathbb{R}^n")#text(".Then")#linebreak()#text(" ")#mi("m^*(\\bigcup_{j\\in \\mathbb{N}}A_j)=\\lim_{N\\to\\infty}m^*(\\bigcup_{j=0}^{N}A_j)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9544230e43d0df1c3ff7d00970402083d0c84d2a1b817d00403ce7929615b3e7-c58fca882b54f4eac5c8b44f684a307f7b56716cc6bb73a2af39e644dbe1b54f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-139492")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2012")])]

#text("Now I think it is obviously true.")

#text("Because there is no distinction between ")#mi("\\displaystyle \\sum_{i=0}^{\\infty}\\frac{1}{2^i}")#text(" and ")#mi("\\displaystyle \\sum_{i\\in\\mathbb{N}}\\frac{1}{2^i}")#text(".")

#text("The two phenomenons are quite similar.Or maybe same.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Isaac Solomon")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-197091")[#strong[#text("Isaac Solomon")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2012")])]

#text("For Theorem 6 (Existence of Lebesgue-Stieltjes measure), when you prove that \\mu_0 is a pre-measure, you claim “by subadditivity, it suffices to show that…”, and then you have a statement asserting subadditivity. Did you mean “by superadditvity”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f06e61006fc21cad74e4b8eea44a5419e35b4ee2838aebec6757cdfeb13d49fd-de944e5d96796e6b5e374bdb39a90bb92dc114dce1e5c40a19925bd892d8ea68.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-210761")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2012")])]

#text("The pre-measure in the wiki article linked is defined on “ring of sets” (coincident with ring theory? The article only says “Not to be confused with Ring (mathematics).”). In Definition 4, it is defined on a “Boolean algebra”. Are they the same objects in algebra? The wikipedia articles for these two concepts seem to be slightly different.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-210925")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2012")])]

#text("A Boolean algebra is a special type of ring of sets, namely a ring of sets that contains the whole set ")#mi("X")#text(" as a member. It is possible to extend much of the theory of premeasures in these notes from Boolean algebras to more general rings of sets (for instance, the ring of elementary sets), but this level of generality is usually not needed in applications.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-216818")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2013")])]

#text("Dear Professor Tao,")#linebreak()#text(" In the proof of Monotone Class Lemma, I think you didn’t use Axiom of Choice. But for example, in Paul A. Meyer (1966), probability and potentials, p10, in order to prove that the smallest monotone class is also an algebra, he uses Zorn’s lemma:")#linebreak()#text(" The maximal algebra containing A and is contained in B is B itself.")

#text("I am really curious that is AC implicitly used in your proof, or Meyer’s use of AC is really unnecessary (Although it seems strange that a good mathematician would invoke AC unnecessarily)?")

#text("Regards,")#linebreak()#text(" Ming")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-216856")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2013")])]

#text("I don’t think that the axiom of choice is needed for the monotone class lemma. For instance, one can construct the smallest monotone class containing a given set without choice, simply by intersecting together all monotone classes that contain that set. I am not familiar with Meyer’s book and cannot offer any opinion on his approach, but given that many other parts of measure theory require (or are at least simplified with the presence of) the axiom of choice, it seems fairly harmless to use it without hesitation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f06e61006fc21cad74e4b8eea44a5419e35b4ee2838aebec6757cdfeb13d49fd-de944e5d96796e6b5e374bdb39a90bb92dc114dce1e5c40a19925bd892d8ea68.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-220604")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2013")])]

#text("In the undergraduate real analysis course, we have a theorem about “Integration by substitution”:")

#text("Let ")#mi("I\\subset{\\Bbb R}")#text(" be an interval and ")#mi("g:[a,b]\\to I")#text(" be a continuously differentiable function. Suppose that ")#mi("f:I\\to{\\Bbb R}")#text(" is a continuous function. Then")

#mi("\\int_{g(a)}^{g(b)}f(x)\\ dx=\\int_{a}^bf\\circ g(t)g^{\\prime}(t)\\ dt.")

#text("In Exercise 36 of 245A Note 3, you gives the “change of variables formula” which looks very similar to each other. But I failed to justify if there is indeed a relationship between these two.")

#text("In this Note 6, Exercise 13, you gives")

#mi("\\int_{\\bf R}f(x)\\ d\\mu_F(x)=\\int_{\\bf R}f(x)F^{\\prime}(x)\\ dx")

#text("Is there any relationship among these three theorems? (I thought the ")#mi("F")#text(" in Ex.13 Note 6 as the counterpart of ")#mi("g")#text(" in the first theorem, but the formula does not completely match…) The “absolutely continuous” notion only appears in the third one but not in the first one. Does it implicitly hide somewhere in the first one?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-227518")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2013")])]

#text("Theorem 14 (3.): the order does not change. I guess you used Ctrl+C for the last line:-)")

#text("[")#emph[#text("Corrected, thanks – T.")]#text("]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f06e61006fc21cad74e4b8eea44a5419e35b4ee2838aebec6757cdfeb13d49fd-de944e5d96796e6b5e374bdb39a90bb92dc114dce1e5c40a19925bd892d8ea68.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-227520")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2013")])]

#text("One version of the Fubini’s theorem in this Wikipedia article( ")#link("http://en.wikipedia.org/wiki/Fubini's_theorem#Theorem_statement")[#text("http://en.wikipedia.org/wiki/Fubini's_theorem#Theorem_statement")]#text(") has no ")#mi("\\sigma")#text("-finite assumption. Would it be correct if one drops it in Theorem 14?")

#emph[#text("[Yes; see Remark 7. However, I recommend against omitting the ")#mi("\\sigma")#text("-finite hypothesis for Fubini’s theorem as it can cause one to recall an incorrect version of the theorem if one is not careful. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9841c2a20db701c8cef0326b346c137cd39048b80f75dd3ba0688b59417a600c-54db6723862008fb8c9764fb5a26f2cf69773d9cc30532c9b7186abf53db3b00.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ivan Dario Peñaloza Rojas")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-243647")[#strong[#text("Ivan Dario Peñaloza Rojas")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2013")])]

#text("Dear Professor Tao")

#text("In the proof of the Hahn-Kolmogorov theorem I think that you can use a weaker hyphotesis about $\\beta_{0}$, namely you can say that $\\beta_{0}$ is a ring instead boolean algera, because you have the same conclusion if you consider $\\beta_{0}$ as a ring, because if you have a pre-measure $\\mu: \\beta_{0} \\to [0, \\infty]$ you can find an outer measure as ")#tao-fit-display[#mitex("\\mu^{*}(E)=inf \\left\\lbrace \\sum_{n \\geqslant 1} \\mu(A_{n}) : A_{n} \\in \\beta_{0} \\ \\ \\text{and} \\ \\  E\\subseteq \\bigcup A_{n} \\right\\rbrace")]

#text("If we let the sigma algebra $M(\\mu^{*})$ be the set of all Carathéodory measurable sets with respect to $\\mu^{*}$ we have that $\\beta_{0} \\subseteq M(\\mu^{*}) $ and moreover $\\mu^{*}$ is an measure on $M(\\mu^{*})$ and the a measure on then $\\sigma$-algebra generated by the ring $\\beta_{0}$")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9841c2a20db701c8cef0326b346c137cd39048b80f75dd3ba0688b59417a600c-54db6723862008fb8c9764fb5a26f2cf69773d9cc30532c9b7186abf53db3b00.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ivan Dario Peñaloza Rojas")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-243649")[#strong[#text("Ivan Dario Peñaloza Rojas")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2013")])]

#text("Dear Professor Tao")

#text("Can I ask you about the following thing, please?:")

#text("if you consider $\\mu: S \\to [0, \\infty]$ a pre-measure with $S$ the Boolean algebra generated by a ring $\\beta$ of subsets of a set $X$,")

#text("the outer measures ")#tao-fit-display[#mitex("\\mu_{\\beta}^{*}(E)=inf \\left\\lbrace \\sum_{n \\geqslant 1} \\mu(A_{n}) : A_{n} \\in \\beta \\ \\ \\text{and} \\ \\  E\\subseteq \\bigcup A_{n} \\right\\rbrace")]#text(" with $\\beta$ a ring of subsets of the set $X$ (that idea follows of the book of real analysis and probability of RM DUBLEY page 89),")

#text("and the outer measure")

#tao-fit-display[#mitex("\\mu_{S}^{*}(E)=inf \\left\\lbrace \\sum_{n \\geqslant 1} \\mu(A_{n}) : A_{n} \\in S \\ \\ \\text{and} \\ \\  E\\subseteq \\bigcup A_{n} \\right\\rbrace")]#text(" with $S$ the Boolean algebra generated by the ring $\\beta$,")

#text("are the same?")

#text("I only know that $\\mu_{S}^{*}(E) \\leqslant \\mu_{\\beta}^{*}(E)$ for all $E \\subseteq X$")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-404827")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2014")])]

#text("There is a proposition in Folland’s book in the section of outer measure:")

#text("Let ")#mi("E\\subset P(X)")#text(" and ")#mi("f:E\\to [0,\\infty]")#text(" be such that ")#mi("\\emptyset\\in E")#text(", ")#mi("X\\in E")#text(", and ")#mi("f(\\emptyset)=0")#text(". For any ")#mi("A\\subset X")#text(", define")

#mi("\\displaystyle \\mu^*(A)=\\inf\\big{\\left\\{\\sum_{1}^\\infty f(E_j):E_j\\in E\\ \\  and\\ \\  A\\subset \\bigcup_1^\\infty E_j\\right\\}}")#text(".")

#text("Then ")#mi("\\mu^*")#text(" is an outer measure.")

#text("The Wikipedia article (")#link("http://en.wikipedia.org/wiki/Outer_measure#Method_I")[#text("http://en.wikipedia.org/wiki/Outer_measure#Method_I")]#text(") calls this a method of construction of outer measure.")

#text("I tried to find the counterpart in your note but failed to do so: the only place I found is the proof of Theorem 5. Does the family ")#mi("E")#text(" have to be a algebra in application or it can be any set as indicated in the proposition I quoted?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-404830")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2014")])]

#text("If all one wants is for ")#mi("\\mu^*")#text(" to be an outer measure, then no further hypotheses on the collection ")#mi("E")#text(" are required (this is a good exercise for you to verify). However, if one wants to upgrade ")#mi("\\mu^*")#text(" to an actual measure rather than just an outer measure (restricting to suitable classes of “measurable” sets, of course), then the additional hypothesis of ")#mi("E")#text(" being a Boolean algebra will be very helpful (as one can see in the proof of Theorem 5 above).")

#text("EDIT: It’s also worth pointing out that a surprising amount of measure theory can actually be carried out with outer measures in place of measures; see ")#link("http://arxiv.org/abs/1309.0945")[#text("this recent paper of Do and Thiele")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-405366")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2014")])]

#text("Theorem 3 is more about “restriction” than “extension”. Why is it called “extension theorem”?")

#text("The link you gave about Carathéodory’s extension theorem(")#link("http://en.wikipedia.org/wiki/Carath%C3%A9odory%27s_extension_theorem")[#text("http://en.wikipedia.org/wiki/Carath%C3%A9odory%27s_extension_theorem")]#text(") seems to be more similar to Theorem 5.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-405389")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2014")])]

#text("Hmm, on looking it up it appears that Theorem 3 is more commonly called “Caratheodory’s lemma”, which is a key component of the proof of the Caratheodory extension theorem, but the latter usually refers to a slightly different claim. I’ll change the wording.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-406422")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2014")])]

#text("In the proof of Theorem 3:")

#text("“On the other hand, from countable subadditivity one has")

#mi("\\displaystyle \\mu^*(A \\cap \\bigcup_{n=1}^\\infty E_n) \\leq \\sum_{N=0}^\\infty \\mu^*( A \\cap E_{N+1} \\backslash\\bigcup_{n=1}^N E_n)")

#text("Rewriting the set on the left hand side, one gets")

#mi("\\displaystyle \\bigcup_{n=1}^\\infty (A\\cap E_n)")#text(".")

#text("Would you elaborate how the “countable subadditivity” is used to get the right hand side?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-406466")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2014")])]

#text("Every element ")#mi("x")#text(" of ")#mi("\\bigcup_{n=1}^\\infty A \\cap E_n")#text(" lies in one of the ")#mi("A \\cap E_{N+1} \\backslash \\bigcup_{n=1}^N E_n")#text(" (take ")#mi("N")#text(" to be the least natural number such that ")#mi("x \\in E_{N+1}")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-406876")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2014")])]

#text("Fair enough. It seems that one could have used")

#mi("\\displaystyle \\mu^*(A \\cap \\bigcup_{n=1}^{N} E_n) = \\mu^*(A \\cap \\bigcup_{n=1}^N E_n\\cap E_N) + \\mu^*( A \\cap \\bigcup_{n=1}^N E_n\\setminus E_N)")

#text("instead in the beginning of verifying ")#mi("{\\mathcal B}")#text(" is a sigma algebra.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-407780")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2014")])]

#text("In Exercise 11, when defining regularity of the measure, is there a particular reason that we use a compact (resp. open) set to approximate a set from “inside (resp. outside)” instead of the other way around:")

#mi("\\displaystyle {\\mu(E) = \\sup_{K \\subset E, K \\text{ open}} \\mu(K)}")

#text("and")

#mi("\\displaystyle {\\mu(E) = \\inf_{U \\supset E, U \\text{ compact}} \\mu(U)}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-407796")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2014")])]

#text("If one reversed the axioms, for regularity, then Lebesgue measure would no longer be regular (consider for instance the case when ")#mi("E")#text(" is the set of rationals or irrationals in the interval [0,1]). See also the notes on Radon measures at ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-428797")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2014")])]

#text("Can one say that a complete measure space is always preferable to a non-complete one? Why do we need the non-complete version of Fubini’s theorem than? Is the non-complete version just a intermediate step for proving the complete one?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-428821")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2014")])]

#text("The non-complete version of Fubini (or Tonelli) is not completely superseded by the complete version. For instance, when working with the incomplete product sigma-algebra, one gets measurability for ")#emph[#text("all")]#text(" of the slices ")#mi("x \\mapsto f(x,y)")#text(" and ")#mi("y \\mapsto f(x,y)")#text(" of a jointly measurable function, whereas when working with the complete product sigma-algebra one only gets measurability for ")#emph[#text("almost all")]#text(" of the slices (because the requirement of joint measurability is weaker). The differences between the two theorems are fairly minor, though.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-429456")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2014")])]

#text("I don’t quite understand the proof of Monotone Class Lemma. How can we see that ")#mi("{{\\mathcal B}}")#text(" is necessarily closed under complements “by replacing all the elements of ")#mi("{{\\mathcal B}}")#text(" with their complements”?")

#text("Let ")#mi("{\\mathcal B}^{\\prime}:=\\{E\\mid E^c\\in {\\mathcal B}\\}")#text(". Then ")#mi("{\\mathcal B}^{\\prime}")#text(" is a monotone class containing ")#mi("{\\mathcal A}")#text(" and thus containing ")#mi("{\\mathcal B}")#text(". Suppose ")#mi("E\\in{\\mathcal B}")#text(". Then ")#mi("E\\in{\\mathcal B}^{\\prime}")#text(" must be true by definition. How can one get ")#mi("E^c \\in{\\mathcal B}^{\\prime}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-429542")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2014")])]

#text("If ")#mi("E \\in {\\mathcal B}")#text(", then ")#mi("E \\in {\\mathcal B}^{\\prime}")#text(", which is equivalent to ")#mi("E^c \\in {\\mathcal B}")#text(" by the definition of ")#mi("{\\mathcal B}^{\\prime}")#text(", and hence ")#mi("{\\mathcal B}")#text(" is closed under complements.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-473157")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2016")])]

#text("It is obvious that ")#mi("\\mathcal{B}^{\\prime}")#text(" is a monotone class. Why does it contain ")#mi("\\mathcal{A}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-473158")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2016")])]

#text("Ah, OK, ")#mi("\\mathcal{A}")#text(" is a field. This is a stupid question.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-433427")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2014")])]

#text("I’m confused about the difference between “(Lebesgue) measurable functions” and Borel measurable functions. Let ")#mi("({\\bf R}, {\\mathcal B}_{\\bf R}, \\mu)")#text(" be the measure space where ")#mi("{\\mathcal B}_{\\bf R}")#text(" is the Borel ")#mi("\\sigma")#text("-algebra of ")#mi("{\\bf R}")#text(" and ")#mi("\\mu")#text(" is the Lebesgue measure, which can be constructed by extension of the pre-measure on the algebra of half intervals, which generates ")#mi("{\\mathcal B}_{\\bf R}")#text(". So “measurable (real-valued) functions” defined on this measure space are called “Borel measurable functions”?")

#text("But we also constructed the Lebesgue measure ")#mi("\\mu")#text(" in a different way in the previous notes and have a measure space ")#mi("({\\bf R}, \\Sigma,\\mu)")#text(" where ")#mi("\\Sigma")#text(" is the set of all the Lebesgue measurable sets. Are measurable functions on this space what people call “Lebesgue measurable functions”?")

#text("I have the similar confusion in the probability theory. It is told that in probability theory, people usually work on ")#mi("({\\bf R}, {\\mathcal B}_{\\bf R}, \\mu)")#text(" instead of ")#mi("({\\bf R}, \\Sigma,\\mu)")#text(". Why is it not the space ")#mi("({\\bf R}, {\\mathcal B}_{\\bf R}, \\mu_F)")#text(" where ")#mi("\\mu_F")#text(" is the Borel measure with ")#mi("F(x)=x")#text("? (If we don’t use the completion of ")#mi("{\\mathcal B}_{\\bf R}")#text(", why don’t we just use ")#mi("\\mu_F")#text(" which is incomplete but use ")#mi("\\mu")#text("?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-433443")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2014")])]

#text("Yes, Borel measurable functions are measurable functions from ")#mi("({\\bf R}, {\\mathcal B}_R)")#text(" to ")#mi("({\\bf R}, {\\mathcal B}_{\\bf R})")#text(", and Lebesgue measurable functions are measurable functions from ")#mi("({\\bf R}, \\Sigma)")#text(" to ")#mi("({\\bf R}, {\\mathcal B}_{\\bf R})")#text(". (Note that the measure ")#mi("\\mu")#text(" is irrelevant for the purposes of defining the concept of a measurable function).")

#text("I am not sure what you mean by ")#mi("\\mu_F")#text(", but when people refer to Lebesgue measure ")#mi("\\mu")#text(" on the Borel ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal B}_{\\bf R}")#text(", they are likely referring (by mild abuse of notation) to the restriction ")#mi("\\mu \\downharpoonright_{{\\mathcal B}_{\\bf R}}")#text(" of Lebesgue measure to the Borel ")#mi("\\sigma")#text("-algebra, which is a Borel measure.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-433453")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2014")])]

#text("Ah, I’m using the notations ")#mi("\\mu_F")#text(" in Theorem 6. I thought it is the same thing as ")#mi("\\mu \\downharpoonright_{{\\mathcal B}_{\\bf R}}")#text(" in your comment.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-433462")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2014")])]

#text("Ah, I see. When ")#mi("F(x)=x")#text(" then the Lebesgue-Stieltjes measure ")#mi("\\mu_F")#text(" is indeed the restriction of Lebesgue measure ")#mi("\\mu")#text(" to the Borel ")#mi("\\sigma")#text("-algebra (or equivalently, Lebesgue measure is the completion of ")#mi("\\mu_F")#text(").")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-456563")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2015")])]

#text("In the proof of Theorem 3, we verify that ")#mi("\\mathcal{B}")#text(" is closed with respect to countable disjoint unions. But I don’t see where the assumption that ")#mi("E_1, E_2, ...")#text(" are disjoint was used.")

#emph[#text("[The disjointness is not needed in this part of the argument; basically, the fact that one has already established the Boolean algebra property renders it unnecessary. Of course, it is still quite harmless to impose this condition. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-456673")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2015")])]

#text("I know you are already aware of this mistake, but in the proof of the Kolmogorov extension theorem, it should say $\\bigcap_{N’=1}^N \\pi_{B_{N’} \\leftarrow B_N}^{-1}(K_{N’})$.")

#emph[#text("[Corrected, thanks -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-456674")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2015")])]

#text("Sorry, I don’t know how to insert Latex here. Anyways, I was talking about the last correction on your errata page for the book “An introduction to measure theory,” the one on page 197 : ")#link("https://terrytao.wordpress.com/books/an-introduction-to-measure-theory/")[#text("https://terrytao.wordpress.com/books/an-introduction-to-measure-theory/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 2: Product measures and independence | What's new")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-460456")[#strong[#text("275A, Notes 2: Product measures and independence | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2015")])]

#text("[…] measure. There are analogues of the Fubini and Tonelli theorems for such complete -algebras; see this previous lecture notes for details. However one should be cautioned that the product of Lebesgue -algebras is not the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-466599")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2016")])]

#text("In the notation section of your paper “Localisation and compactness properties of the Navier-Stokes global regularity problem”, you give the following descriptions:")

#text("Given any spatial norm ")#mi("\\|\\ \\|_{X_x(\\Omega)}")#text(" associated to a function space ")#mi("X_x")#text(" defined on a spatial domain ")#mi("\\Omega")#text(", and a time interval ")#mi("I")#text(", we can define mixed-norms ")#tao-math("\\left\\|u\\right\\|_{L^p_tX_x(I\\times\\Omega)}", block: false)#text(" on functions ")#mi("u:I\\times\\Omega\\to\\mathbb{R}")#text(" by the formula")#linebreak()#text(" define")

#tao-math("\\displaystyle \\left\\|u\\right\\|_{L^p_tX_x(I\\times\\Omega)}:=\\left(\\left\\|u(t)\\right\\|_{X_x(\\Omega)}^p\\right)^{1/p}", block: false)

#text("I’ve seen in literature that people call this Bochner integral (")#link("https://en.wikipedia.org/wiki/Bochner_integral")[#text("https://en.wikipedia.org/wiki/Bochner_integral")]#text("). Is it essentially the same as the Lebesgue integrals in this set of notes? When ")#mi("X_x=L^p_x")#text(", is true that")

#tao-math("\\displaystyle \\left\\|u\\right\\|_{L^p_tX_x(I\\times\\Omega)}=\\left\\|u\\right\\|_{L^p(I\\times\\Omega)}", block: false)#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-466603")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2016")])]

#text("There is a time integral missing in your first display. The integral here is just the ordinary Lebesgue integral of scalar-valued functions (in this case, of ")#tao-math("t \\mapsto \\left\\|u(t)\\right\\|_{X_x(\\Omega)}^p", block: false)#text("); one does not need the Bochner integral (which is for vector-valued functions here). The equivalence in your final display follows from the Fubini-Tonelli theorem (assuming of course that ")#mi("u")#text(" is measurable).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/42fa6c29a56da6e32376db624695163c27aaaa1ab6ccaf780062a21df09cc721-bb954ba5173a10ef4b5e03c10706fc34bd07274292b741b0e02fdb2d0cf01881.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-468998")[#strong[#text("Nick")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2016")])]

#text("The statement in Exercise 19.2 appears to be false. If not, then the product of two discrete $\\sigma$-algebras would be discrete, contradicting Ex.19.7.")

#emph[#text("[Oops, that part of the exercuse should have been removed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-469762")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2016")])]

#text("The complete and incomplete versions of Tonelli’s theorem are given in Theorem 10 and Theorem 12. But there is only one version of the Fubini theorem. Do we also also have an incomplete version of Fubini?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-473046")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2016")])]

#text("Can one relax the condition in the Fubini-Tonelli to")#linebreak()#text(" ")#tao-math("\\displaystyle \\int_X\\left|\\int_Y f(x,y)\\,dy\\right|\\,dx<\\infty?", block: false)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-473163")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2016")])]

#text("In the proof of the Lemma 9, if one lets ")#mi("\\mathcal{M}")#text(" be the smallest monotone class over ")#mi("\\mathcal{A}")#text(" then it suffices to show that ")#mi("\\mathcal{M}")#text(" is a field. Would that be little faster/neater I think?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b0a2a5bf1a3b38bdad3521393afac85698eea858bc2b77fa10e8b5c4d1002174-a76438fb1badf71d24c90390f3879faa8fbfe2a7506f2450735b7c7529a48027.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YijunYuan")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-474111")[#strong[#text("YijunYuan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2016")])]

#text("Let ")#mi("A\\subset\\mathbb{R}^p")#text(" and ")#mi("B\\subset\\mathbb{R}^q")#text(", it’s not difficult to show that")

#mi("m^*(A\\times B)\\leq m^*(A)\\cdot m^*(B),")

#text("where ")#mi("m^*()")#text(" stands for the outter measure in Lebesgue meaning.")

#text("If A and B are measurable, then “=” holds. My question is whether “=” holds for all of/ none of/ some of the non-measurable A and B?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-475222")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2016")])]

#text("In the proof of the monotone class lemma, can one replace the requirement that ")#mi("F \\backslash E, E \\backslash F, \\dots")#text(" by just ")#mi("F \\cup E")#text("? I worked through but didn’t find where to use these, did I just miss something? Thanks!")

#emph[#text("[Yes, this seems to work. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59e1d17563448927ffd8eed9423be29be71d97ddf2fe0f404bed3a20a7ac696c-2e3cc73e8b991296259916c2b75112dcca4ab5619e581a170735a64d61be78c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of coupon_clipper")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-477262")[#strong[#text("coupon_clipper")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2017")])]

#text("In exercise 18 part 3, you ask to show that if ")#mi("E")#text(" is measurable wrt the product measure, then every “slice” ")#mi("E_x")#text(" is also measurable (wrt to the measure on ")#mi("Y")#text(").")

#text("Here’s as far as I got: The product space is generated by sets of the form ")#mi("A \\times Y")#text(" and ")#mi("X \\times B")#text(" (where ")#mi("A \\in X")#text(" and ")#mi("B \\in Y")#text(", and the claim is certainly true about those sets. Also the property is preserved under union and complementation, so therefore it should be true about the entire sigma algebra.")

#text("Two questions:")#linebreak()#text(" 1. Is my reasoning correct?")#linebreak()#text(" 2. Isn’t there a snappier way to show this claim? It seems like I’m working way too hard for such a simple exercise.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-477282")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2017")])]

#text("This works. One could also use the monotone class lemma, though this doesn’t shorten the proof all that much.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59e1d17563448927ffd8eed9423be29be71d97ddf2fe0f404bed3a20a7ac696c-2e3cc73e8b991296259916c2b75112dcca4ab5619e581a170735a64d61be78c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of coupon_clipper")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-477285")[#strong[#text("coupon_clipper")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2017")])]

#text("Thanks, Terry. The monotone class lemma comes later, which is why I didn’t think to use it (and I hadn’t heard of it until I read your comment).")

#text("I’m curious as to whether you were expecting students to come up with my solution or something else.")

#text("Also, my solution doesn’t get me any closer to figuring out part 5 where we have to show the the set of slices of a given measurable set are contained in a countably generated sigma algebra. Can you give a hint for that one?")

#text("As always, I appreciate your help!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-477317")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2017")])]

#text("For most of these types of questions involving proving statements valid for all sets in a sigma algebra, Remark 4 from ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/")[#text("Notes 3")]#text(" is the usual method, though as I said previously, the monotone class lemma (and variants such as the ")#link("https://en.wikipedia.org/wiki/Dynkin_system#Dynkin.27s_.CF.80-.CE.BB_theorem")[#text("lambda-pi theorem")]#text(") can be more convenient technically in some cases.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59e1d17563448927ffd8eed9423be29be71d97ddf2fe0f404bed3a20a7ac696c-2e3cc73e8b991296259916c2b75112dcca4ab5619e581a170735a64d61be78c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of coupon_clipper")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-477461")[#strong[#text("coupon_clipper")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("Yup, remark 4 was exactly what I needed and now that I’ve worked through the MCL I can see how to use that instead.")

#text("What about showing that the set of slices (for a particular element of the product space) is countably generated? I can’t imagine where to begin; I don’t even know what I could use as the generators.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59e1d17563448927ffd8eed9423be29be71d97ddf2fe0f404bed3a20a7ac696c-2e3cc73e8b991296259916c2b75112dcca4ab5619e581a170735a64d61be78c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of coupon_clipper")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-477585")[#strong[#text("coupon_clipper")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2017")])]

#text("Theorem 12 (Tonelli’s Thm, complete) last line looks like a copy & paste error. It’s the same as the previous line. I think you meant to switch the order of integration.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b6e95a56c17ebfa5aed6fc952a08bfb0a44d8cf53c2925f63cbcfa7c4623989-da79ae37d9d1f5d861d6a16e5ed3ccde002c73166ff808cc4d5b54a6a07a4c3b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Li")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-485648")[#strong[#text("Joe Li")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2017")])]

#text("Dear Prof. Tao,")

#text("In the proof of Carathéodory extension theorem, when showing ")#mi("\\mathcal{B}")#text(" is a ")#mi("\\sigma")#text("-algebra, you assumed that ")#mi("E_1,E_2,\\ldots")#text(" is disjoint. But it seems that this assumption is not used, is it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-485672")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2017")])]

#text("Yes, the way it was written it was not used. I’ve now rewritten the argument to take advantage of the disjointness to simplify the argument slightly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a1eee564adb905c9ce9f9c36f5df15b1d725feacc10e6a229a6bd4188b1b467e-2afa0fa34935967598dce73dffd9484b0cf1342aa26799a4e0262d28aadde64c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MatjazG")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-485706")[#strong[#text("MatjazG")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2017")])]

#text("In Exercise 4, “with respect to Lebesgue outer measurable” should be: “with respect to the Lebesgue outer measure”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b6e95a56c17ebfa5aed6fc952a08bfb0a44d8cf53c2925f63cbcfa7c4623989-da79ae37d9d1f5d861d6a16e5ed3ccde002c73166ff808cc4d5b54a6a07a4c3b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Li")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-485727")[#strong[#text("Joe Li")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2017")])]

#text("Dear Prof Tao,")

#text("In the proof of Theorem 18 (Existence of Lebesgue-Stieltjes measure), did you forget to define ")#mi("F")#text("-volume ")#tao-math("\\left|I\\right|_F", block: false)#text("?")

#emph[#text("[Correction added, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b6e95a56c17ebfa5aed6fc952a08bfb0a44d8cf53c2925f63cbcfa7c4623989-da79ae37d9d1f5d861d6a16e5ed3ccde002c73166ff808cc4d5b54a6a07a4c3b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Li")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-485936")[#strong[#text("Joe Li")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2017")])]

#text("The reference to equation is not parsed. (It shows ‘\\eqref{mas-1}’).")#linebreak()#text(" I guess you mean equation (3).")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b6e95a56c17ebfa5aed6fc952a08bfb0a44d8cf53c2925f63cbcfa7c4623989-da79ae37d9d1f5d861d6a16e5ed3ccde002c73166ff808cc4d5b54a6a07a4c3b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Li")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-485935")[#strong[#text("Joe Li")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2017")])]

#text("Small typos:")

#text("In the proof of Proposition 30 (Existence and uniqueness of product measure),")

#text("In the end of the line starting with “Now we show that”, it should be")#linebreak()#text(" ")#mi("\\mu_0(S) = \\sum_{n=1}^\\infty \\mu_0(S_n)")

#text("In Corollary 40 (Tonelli’s theorem for sets), the RHS of last equality should be")#linebreak()#text(" ")#mi("\\int_Y \\mu_X(E^y)\\ d\\mu_Y(y)")

#text("In Exercise 44, the line below “such that”, the LHS and RHS of the inequality is the same. (One of them should be dxdy)")#linebreak()#text(" Same for the integrals after “respectively, and that” in the same exercise.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b6e95a56c17ebfa5aed6fc952a08bfb0a44d8cf53c2925f63cbcfa7c4623989-da79ae37d9d1f5d861d6a16e5ed3ccde002c73166ff808cc4d5b54a6a07a4c3b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Li")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-485979")[#strong[#text("Joe Li")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2017")])]

#text("Small typo:")

#text("The line above Exercise 23 (Lebesgue-Stieltjes measure, pure point case)")

#mi("-\\infty < b < a < +\\infty")#text(" should be ")#mi("-\\infty < a < b < +\\infty")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-486249")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2017")])]

#text("In Exercise 44, does an example exist if we require further that ")#mi("f")#text(" is nonnegative?")

#emph[#text("[No: see Theorem 36. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-1/#comment-488013")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2017")])]

#text("In Remark 45,")

#text("Despite the failure of Tonelli’s theorem in the {\\sigma}-finite setting…")

#text("Do you mean that Tonell fails in the non-sigma-finite setting instead?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f186d5c1e23a59007311650d43a2c96fcf009ef8787c86d8e418ad07a5d1f174-94c213eb3eb93d5e2d768cb63939fa5330e63156f09627d83e6324c1c9bf1fc7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-496822")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2018")])]

#text("For lemma 35,")

#text("Correct me if I am wrong, but is the second paragraph necessary: “It is also clear… closed under complements. ” As ")#mi("X \\in A")#text(", the proof already shows ")#mi("D")#text(" is closed under complements, ")#mi("X\\backslash B=B^c")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-496845")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2018")])]

#text("Yes, one could arrange the argument in this fashion instead if one wished.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e9002742a17f237017dd4d29d967308883992a3473ac0f5f470fc5d4649935b-60fceb51d5eb3c8e5b8cdeff15e225df6a42971ec1f3945059aaad35c5f47c97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nathanael Schilling")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-505574")[#strong[#text("Nathanael Schilling")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2018")])]

#text("I think there is a small mistake in the proof of the Kolomogorov Extension Theorem (Theorem 62) Here you write:")

#mi("\\displaystyle \\mu_{B_N}(K^{\\prime}_N) \\geq \\mu_{B_N}(G_N) - \\varepsilon/2^N \\geq \\varepsilon - \\varepsilon/2^N")#text(".")

#text("As ")#mi("K_1")#text(" potentially only has measure ")#mi("\\varepsilon/2")#text(", and hence ")#mi("K^{\\prime}_N")#text(" (which is contained in the inverse image under a projection of ")#mi("K_1")#text(") cannot have a larger measure.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-619796")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2021")])]

#text("Dear Professor Tao")

#text("Can I ask you about the following thing, please?:In (4) of Exercise 59. How can we get the at most countable set {B} and get the function {f_B}?")#linebreak()#text(" Now I just know that if want that {f = f_B \\circ \\pi_B},we will have that")#linebreak()#text(" { (x_\\alpha)_{\\alpha \\in A}} and { (x^’_\\alpha)_{\\alpha \\in A}}are equal under the given function {f} if {x_\\alpha = x^’_\\alpha} for all {\\alpha belong B}.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-619894")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2021")])]

#text("In theorem 18, it seems that there is a typo in the definition of left and right limits of ")#mi("F")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 4: Probabilistic models and heuristics for the primes (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-635695")[#strong[#text("254A, Supplement 4: Probabilistic models and heuristics for the primes (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2021")])]

#text("[…] of random variables, as this set of notes is not focused on rigorous formalism. (See for instance this previous post for the relevant theory […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-643290")[#strong[#text("Outer Measures – deep mind")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2022")]

#text("[…] Apart from the literature [1] to [6] listed at the end of this post, we also refer to the lecture 245A notes of T. Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-685350")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2024")])]

#text("When introducing the Lebesgue measure in ")#mi("{\\mathbf R}^n")#text(", boxes or an elementary sets are used, which are much more intuitive. Do you have any conceptual intuition/motivation of why the Carathéodory measurability (Definition 2) would be effective?")

#text("This condition is also mentioned in Exercise 17 of Notes 1. Apart from memorizing it, I don’t see how one could naturally arrive at this concept.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-685424")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2024")])]

#text("I don’t know the precise history of the subject, but once the concepts of outer measure and Lebesgue measure are introduced, it is natural to ask when outer measure is actually additive, namely to figure out conditions on disjoint sets ")#mi("A, B")#text(" such that ")#mi("\\mu^*(A \\cup B) = \\mu^*(A) + \\mu^*(B)")#text(". Presumably at some point Caratheodory noticed that one condition under which this occurs is if ")#mi("A, B")#text(" can be obtained from ")#mi("A \\cup B")#text(" by intersecting with a box (or more generally, a measurable set) and its complement. The clever bit was then to ask if this property actually characterized Lebesgue measurability (i.e., Exercise 17 of Notes 1), and whether this could be abstracted to provide a more general construction of measurable sets.")

#text("In general, elegant mathematical axiomatizations of key concepts can be hard to motivate; they have to be searched for and discovered by a lengthy research process. They also tend to be somewhat artificial: see my MathOverflow answer ")#link("https://mathoverflow.net/a/30231/766")[#text("https://mathoverflow.net/a/30231/766")]#text(" for some further discussion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-687671")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2025")])]

#text("Something that occurred to me while reading your proof of Theorem 18: I think that if you just use F_+​, and the algebra, A, of finite disjoint unions of left-open/right-closed intervals, (a,b], you can prove the sigma-additivity of F+​ on A very neatly using trans-finite induction, since if (a,b] is a union of other such intervals, the intervals are (backwards) well-ordered.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688451")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2025")])]

#text("Dear professor Tao:")

#text("Can you hint a little further on how to approximate the relevant sets in Exercise 4, once the case when ")#mi("E")#text(" is a box is obtained?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688452")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2025")])]

#text("I assume the Caratheodory measurability for general Lebesgue measurable ")#mi("E")#text(" follows from outer regularity and subadditivity, so we need to establish Caratheodory measurability for open ")#mi("E")#text(", yet I’m unsure of how this follows in turn from the box case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688455")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2025")])]

#text("Dear professor Tao:")

#text("For Exercise 4, It just occur to me that by outer regularity, there exists an open set ")#mi("U \\supset A")#text(" such that ")#mi("m^*(U) \\leq m^*(A) + \\varepsilon")#text(". Then by additivity of Lebesgue measure one simply has ")#mi("m^*(A) + \\varepsilon \\geq m^*(U) = m^*(U \\backslash E) + m^*(U \\cap E) \\geq m^*(A \\backslash A) + m^*(A \\cap E)")#text(". Combining with subadditivity of outer measure we get the other direction. I have yet to see how the box case readily lends itself to a proof of the general case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688464")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2025")])]

#text("Dear professor Tao:")

#text("To clarify the hint of Exercise 4, are we using Caratheodory lemma in advance to get from the case where ")#mi("E")#text(" is a box to the general case where ")#mi("E")#text(" is Lebesgue measurable?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688483")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2025")])]

#text("Dear professor Tao:")

#text("Since the proof of the Caratheodory lemma proceeds Exercise 4, may I ask how do we get from Lebesgue measurability to Caratheodory measurability from the case when ")#mi("E")#text(" is a box?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688486")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2025")])]

#text("Dear professor Tao:")

#text("Other than my question on the hint for Exercise 4, in the proof of the Carathéodory lemma, the statement “But by the Carathéodory measurability of ")#mi("E_{N+1}")#text("” should be “But by the Carathéodory measurability of ")#mi("\\bigcup_{n=1}^N E_n")#text("“, as in the book.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688498")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2025")])]

#text("Dear professor Tao:")

#text("By the definition in previous notes, the elementary measure can only measure elementary sets, but not co-elementary ones. In Exercise 4 however, we define it on the entire elementary Borel algebra. Are we considering a generalization here?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688502")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2025")])]

#text("The Wiki page on pre-measure defines it on a ring of subsets, a weaker structure than a Boolean algebra. This is consistent with say Exercise 16, but inconsistent with Definition 10. May I ask which convention are we adopting in this set of notes?")

#emph[#text("[“finite unions” corrected to “finite boolean combinations” in Exercise 16. In this text I do not aim for maximal generality, and so the definitions here may be more restrictive than what can be found in some other sources. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688511")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2025")])]

#text("Dear professor Tao:")

#text("In part (1) of Exercise 17, should we add that ")#mi("F")#text(" can be written as such, when ")#mi("E")#text(" has finite measure?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688518")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2025")])]

#text("Dear professor Tao:")

#text("In theorem 18 the ")#mi("F")#text("-volume is defined for intervals, should we state explicitly that the same definition extends to the union of two disjoint intervals, for the sake of Exercise 19?")

#emph[#text("[Added clarification that the union of the disjoint intervals is assumed to also be an interval. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688540")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2025")])]

#text("Dear professor Tao:")

#text("In correspondence to Theorem 18, shouldn’t “monotone function” be “monotone non-decreasing function” in Exercise 20?")

#emph[#text("[Clarified, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688567")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2025")])]

#text("Dear professor Tao:")

#text("Small issue with regard to the index: “Exercise 46” in part (2) of Exercise 24 should be changed to “Exercise 84”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688568")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2025")])]

#text("Also, since theorem 18 defines the Lebesgue-Stieltjes measure ")#mi("\\mu_F")#text(" for ")#mi("F")#text(" defined on ")#mi("{\\bf R}")#text(", how do we interpret ")#mi("\\mu_F")#text(" for the Cantor function ")#mi("F")#text(", which is only defined on ")#mi("[0,1]")#text("?")

#emph[#text("[Extend the Cantor function by constants outside of this interval. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688726")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2025")])]

#text("Dear professor Tao:")

#mi("Y \\in {\\mathcal B}_Y")#text(" should be changed to ")#mi("F \\in {\\mathcal B}_Y")#text(". Also, can you give a little hint on the first half of part (5) (show that the slices lie in a countably generated ")#mi("\\sigma")#text("-algebra)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688732")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2025")])]

#text("Dear professor Tao:")

#text("For part (5) of Exercise 27, I argued by two steps. One, show that the sets in the product algebra generated by countably many generators of (1) is a ")#mi("\\sigma")#text("-algebra, and in fact is the product algebra itself. Two, for a set ")#mi("E")#text(" in the product algebra, and the corresponding family of generators ")#mi("A_n \\times B_n")#text(", show that the sets in the product space with their vertical slices lie in the generation of the ")#mi("B_n")#text(" again forms a ")#mi("\\sigma")#text("-algebra. The issue with this type of argument though, is that it has a somewhat inductive flavor, in that it assumes what claim to prove to arrive at the conclusion in a backward fashion. I wonder if there is a more constructive way of approaching this problem, which (a) shows why the result holds and (b) gives some insight as to how the result is conjectured in the first place.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688748")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2025")])]

#text("Dear professor Tao:")

#text("For Exercise 28(6), we have not defined a suitable measure on the product algebra yet, which is needed for the notion of completion of a measure space.")

#emph[#text("[As stated in the exercise, we use Lebesgue measure here. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688751")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2025")])]

#text("Dear professor Tao:")

#text("In Exercise 15 the notion of ")#mi("\\sigma")#text("-finiteness is defined for the pre-measure ")#mi("\\mu_0")#text(", whereas in Definition 29 it is defined for the measure space ")#mi("(X, {\\mathcal B}, \\mu)")#text(". Is there a common framework for both of these conventions?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688778")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2025")])]

#text("Dear professor Tao:")

#text("Did the proof of Theorem 36 missed the part for the measurability of the inner integral?")

#emph[#text("[This measurability would be part of the definition of the monotone class ")#mi("{\\mathcal C}")#text(" – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688790")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2025")])]

#text("Dear professor Tao:")

#text("Can you give a little hint on how to show that the function ")#mi("f")#text(" of Exercise 41 is measurable in the product algebra?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688792")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2025")])]

#text("Dear professor Tao:")

#text("Below Remark 42, “absolutely integral” should be “absolutely convergent integral”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688793")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2025")])]

#text("Dear professor Tao:")

#text("I think I got part (1) of Exercise 41. For part (4) though, if one defines the two measures by the two ways to compute the double integral of the indicator function, how should one show that the inner integral corresponding to the counting measure is measurable?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688804")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2025")])]

#text("To be precise, since the inner integral w.r.t the counting measure might not be a measurable map w.r.t the Lebesgue measure, the outer integral can not be properly defined, how could we get around this issue?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688813")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2025")])]

#text("Dear Professor Tao:")

#text("Since the inner integral w.r.t the counting measure might not be measurable w.r.t the Lebesgue ")#mi("sigma")#text("-algebra on the unit interval, can you give a little hint on how to define the measure that corresponds to this double integral?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688819")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2025")])]

#text("Hmm, you’re right, measurability is an issue. One can construct a candidate product measure instead using Caratheodory’s theorem, mimicking the construction of product measure in the sigma-finite case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688918")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2025")])]

#text("Dear professor Tao:")

#text("For Exercise 44, if one partitions the unit interval into sub-intervals of length ")#mi("2^{-k}")#text(" and defines ")#mi("f(x,y) :=\\sum_{n,m} x_{n,m} 1_{I_n \\times J_m}(x,y)")#text(". Then it seems that the two iterated integrals differs (latex 1/2 and 0). But then how does it not contradicting the Fubini’s theorem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688928")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2025")])]

#text("Dear professor Tao:")

#text("In Exercise 49, the reference to Exercise 26 in Note 5 should be changed to Exercise 51.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688931")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2025")])]

#text("Dear professor Tao:")

#text("In the section of the Rademacher differentiation theorem, the reference to Exercise 40 from Note 5 should be changed to Exercise 76.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-688941")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2025")])]

#text("Dear professor Tao:")

#text("In the second display of Definition 52, ")#mi("h \\rightarrow {\\bf R}^d \\backslash \\{0\\}")#text(" should be changed to ")#mi("h \\in {\\bf R}^d \\backslash \\{0\\}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689018")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2025")])]

#text("Dear professor Tao:")

#text("In the proof of Theorem 57, why do we have that ")#mi("E_v")#text(" is Borel measurable? ")#mi("E_v")#text(" is the set where the difference between the lim sup and the lim inf are non-zero, but the lim sup and lim inf are taken on the difference quotient, which is not unsigned, in previous notes we have only measurability for lim sup and lim inf taken on the unsigned functions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689019")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2025")])]

#text("It is not difficult to adapt the measurability results for unsigned limsup/liminf to signed limsup/liminf. (One could also use exp and log to move between the unsigned and signed cases, although this is a somewhat strange way to proceed.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689024")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2025")])]

#text("Dear professor Tao:")

#text("Thanks for the explanation. Now that ")#mi("E_v")#text(" as the pre-image of ")#mi("{\\bf R} \\backslash {0}")#text(" under the difference of two measurable functions, is Lebesgue measurable. But how about Borel-measurability? May I ask which result are we relying on here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689027")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2025")])]

#mi("f")#text(" is continuous, as are all of the difference quotients ")#mi("D_v f")#text(", so their level sets will be Borel measurable.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689030")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2025")])]

#text("Dear professor Tao:")

#text("In the proof of Theorem 57, the set ")#mi("E^{y_0}")#text(" should be ")#mi("E^{y_0}_v")#text(", and similarly ")#mi("E")#text(" should be changed to ")#mi("E_v")#text(" in the next sentence.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689032")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2025")])]

#text("For this portion of the proof we have already specialized to the case ")#mi("v = e_1")#text(" (so I have replaced ")#mi("E")#text(" with ")#mi("E_{e_1}")#text(" here).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689033")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2025")])]

#text("Thank you professor. Also, where we use the translation invariance of the Lebesgue integral, the reference to Exercise 15 in the parenthesis should be changed to Exercise 15 of Note 2.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689034")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2025")])]

#text("Dear professor Tao:")

#text("When we let ")#mi("g: {\\bf R}^d \\rightarrow {\\bf R}")#text(" to be compactly supported and continuously differentiable, can you elaborate why such functions are Lipschitz from the fundamental theorem of calculus, as their derivatives are bounded? The FTC in previous notes are for functions defined on ")#mi("{bf R}")#text(" rather than ")#mi("{\\bf R}^d")#text(".")

#emph[#text("[Specialize the d-dimensional function to one-dimensional lines, and then apply the one-dimensional FTC on each such line. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689036")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2025")])]

#text("Dear professor Tao: As the definition of total derivative is not given in Definition 52, we don’t have a proper definition for continuous differentiability for ")#mi("g")#text(" either. Can you be a bit more specific on this method of specializing ")#mi("g")#text(" to each dimension separately?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689037")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2025")])]

#text("See ")#link("https://en.wikipedia.org/wiki/Total_derivative")[#text("https://en.wikipedia.org/wiki/Total_derivative")]#text(" . One can specialize ")#mi("g")#text(" to any line ")#mi("\\{ x+tv: t \\in {\\bf R} \\}")#text(" by considering the one-dimensional function ")#mi("t \\mapsto g(x+tv)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689049")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2025")])]

#text("Dear professor Tao: Follow your hint, we get the bound ")#tao-math("\\left|g(x+h) - g(x)\\right|  \\leq \\int_{[0,1]} |\\nabla g(x+ht) \\cdot h| dt", block: false)#text(" from the chain rule and FTC, and then the claim follows, is this correct? Why then do we need to specialize to each one of the d dimensions then?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689050")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2025")])]

#text("I said to specialize to one-dimensional lines, not to one of the d coordinate dimensions.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689058")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2025")])]

#text("Dear professor Tao:")

#text("Again on Theorem 57, the reference to Exercise 55 should be changed to Exercise 54, and the modified function ")#mi("F")#text(" should takes values in ")#mi("{\\bf R}")#text(" rather than in ")#mi("{\\bf R}^d")#text(".")

#emph[#text("[Corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689062")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2025")])]

#text("Dear professor Tao: “as ")#mi("{\\bf Q}^d")#text(" is rational” should be “as ")#mi("{\\bf Q}^d")#text(" is countable” in Theorem 57. Lastly, to clarify, the reason why we restrict the choices of approximating vector ")#mi("v")#text(" to ")#mi("V_\\varepsilon")#text(" is so that ")#mi("h")#text(" will only depends on ")#mi("\\varepsilon")#text(" instead of on both ")#mi("v")#text(" and ")#mi("\\varepsilon")#text(", is this precise?")

#emph[#text("[Typo corrected. Yes, the discretization here is needed to obtain uniformity in ")#mi("v")#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689075")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2025")])]

#text("Dear professor Tao:")

#text("What is the intended definition of ")#mi("E_A")#text(" in (3) of Exercise 59?")

#emph[#text("[I have corrected the previous ")#mi("E")#text(" to ")#mi("E_A")#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689082")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2025")])]

#text("Dear professor Tao:")

#text("To get (3) of Exercise 59, my idea is to show that every set ")#mi("E_A \\in {\\mathcal B}_A")#text(" is generated by countably many pre-images ")#mi("\\pi{\\beta}^{-1}(E_{\\beta})")#text(", indexed by some countable subset ")#mi("B \\subset A")#text(". We then use the composition law to pull the pre-images back to ")#mi("X_B")#text(", and show that every element in the algebra generated by this family has this property of expressible as the pre-image under ")#mi("\\pi_B")#text(" of some ")#mi("E \\in {\\mathcal B}_B")#text(", since ")#mi("E_A")#text(" is in this algebra, the claim follows. Is this the standard proof? Are there any explanation on the source of idea?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689086")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2025")])]

#text("Dear professor Tao:")

#text("Can you hint a little on how can we use (3) to deduce (4) in Exercise 59?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689087")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2025")])]

#text("Dear professor Tao: To locate the single countable set ")#mi("B")#text(" in (4) of Exercise 59, we consider the rational intervals of ")#mi("[0,+\\infty]")#text(" and use the fact that countable unions of countable sets remain countable, is this correct? But then how do we explicitly define the function ")#mi("f_B")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689093")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2025")])]

#text("Dear professor Tao:")

#text("I figured that ")#mi("f")#text(" is constant on each fiber of ")#mi("\\pi_B")#text(", hence the function ")#mi("f_B")#text(" is well-defined. Is this right?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689097")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2025")])]

#text("Dear professor Tao:")

#text("To clarify two points about the proof of Theorem 62: 1. The set ")#mi("K^{\\prime}_N")#text(" is compact since ")#mi("K^{\\prime}_N = \\prod{j=1}^N (\\bigcap_{i=j}^N \\pi_{B_j \\backslash B_{j-1}}(K_i))")#text(", and continuous maps preserve compactness. Is this correct? 2. If so, how do we deduce the following lower bound on the measure of ")#mi("K^{\\prime}_N")#text("? (push the measure forward inside the intersection only shows that its’ measure is no greater that the measure of ")#mi("K_{N^{\\prime}}")#text(" for all ")#mi("N^{\\prime} \\leq N")#text(")")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689098")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2025")])]

#text("Dear professor Tao:")

#text("Can you give a little hint on how one obtains the lower bound on the measure of ")#mi("K^{\\prime}_N")#text(" in Theorem 62?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689099")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2025")])]

#text("Dear professor Tao:")

#text("I think my previous expression for ")#mi("K^{\\prime}_N")#text(" is incorrect, why then do we have that $K’_N$ is compact?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-689490")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2025")])]

#text("Dear Dr Tao,")

#text("Could we intuitively think of all types of “measure”, like Lebesgue measure, outer measure, product measure etc, as the “mass” of a set or object? But if we could do so, what’s the difference between distinct measures?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-2/#comment-691613")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2026")])]

#text("Dear professor Tao:")

#text("Does Kolmogorov extension theorem have any intuitive way to understand better?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-3/#comment-692298")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2026")])]

#text("Dear professor Tao:")

#text("Based on this post, it seems that the Lebesgue-Stieltjes measure is just a variety of measure constructed by the Hahn-Kolmogorov extension theorem. I would like to ask: what is the motivation for introducing this concept?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-3/#comment-692304")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2026")])]

#text("I am ")#link("https://claude.ai/share/90b4fcb6-849e-4bc5-bd7c-6757a1e249a4")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-3/#comment-692534")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2026")])]

#text("In the proof of Kolmogorov extension theorem, why would you choose to prove it proof by contradiction? Is it because a direct proof is too difficult?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-3/#comment-692538")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2026")])]

#text("Interesting question; there may be some reverse mathematics or constructive mathematics issues in play here that make proof by contradiction (or by contrapositive) more natural, though I am not an expert on these matters. I played a little with an AI and ")#link("https://claude.ai/share/ded0a28e-1a04-48cc-b41a-d3e36a07cced")[#text("eventually got it to create a direct proof")]#text(" relying on Tychonoff’s theorem rather than the finite intersection property or the Bolzano-Weierstrass theorem, though the proof by contradiction is still present through the application of Tychonoff’s theorem. But certainly this style of proof encounters more “resistance” than working with the contrapositive statement.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-3/#comment-693869")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2026")])]

#text("Dear Prof. Tao:")

#text("I’m a bit puzzled by Exercises 22, 23, and 24: why do we need to separately focus on the absolutely continuous case, the pure point case, and the singular continuous case of Lebesgue-Stieltjes measures?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-3/#comment-693875")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2026")])]

#text("This is a pedagogical choice, to allow readers to compare and contrast three key special cases of Lebesgue-Stieltjes measure.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/comment-page-3/#comment-693877")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2026")])]

#text("Dear Prof. Tao,")

#text("Some typos:")

#text("i) In Theorem 18, “b < a” should be “a < b”;")

#text("ii) The Carathéodory extension theorem, which appears in the title of the section 1 and the tags of the post, becomes the Carathéodory lemma in the main text, so perhaps one of them needs to be changed.")

#text("I would like to ask: Are the techniques used to prove the various extension theorems in measure theory—namely the Carathéodory lemma/Carathéodory extension theorem, the Hahn–Kolmogorov extension theorem, and the Kolmogorov extension theorem in this post—general? What ideas or techniques can we learn from the proofs of these distinct extension theorems?")
]
