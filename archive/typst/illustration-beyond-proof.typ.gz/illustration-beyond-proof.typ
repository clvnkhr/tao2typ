// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/11/illustration-beyond-proof/
// Converted to Typst by tao2typ: "2026-10-14T15:21:27.790960+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Illustration beyond Proof", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Illustration beyond Proof")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/11/illustration-beyond-proof/")[#text("https://terrytao.wordpress.com/2026/10/11/illustration-beyond-proof/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://math.katestange.net/")[#text("Kate Stange")]#text(" and ")#link("https://maxwelldemon.com/")[#text("Edmund Harriss")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("In January a group of mathematicians, historians, artists and educators gathered at the Institut Henri Poincaré (IHP) for a very unusual workshop on mathematical meaning. Our focus for that week, as part of a special trimester on the use of illustration in mathematical research, was to ask: what would it mean for an illustration to be rigorous [1]? We did not anticipate how urgent the surrounding cluster of questions, about the very definitions of human mathematical practice, would seem, just six months later. Our discussions led to an article, written over the summer in the context of the ")#link("https://leidendeclaration.ai/")[#text("Leiden Declaration")]#text(" [2], and now accepted in the ")#emph[#text("Notices")]#text(" [3]. The past month or two have seen a heartfelt outpouring of viewpoints on what it means to do mathematics as a human being, and what it will mean in the near future. It is evident from the impassioned discussions that being a mathematician has many and varied important meanings. Mathematical illustration, which includes computer graphics and other media that speak to our senses beyond symbolic communication, is one of the activities of a human mathematician that goes beyond proof-writing. Its own struggles as a discipline can perhaps provide some insight into where mathematics can go from here.")

#metadata(none) <tao-cc1afe14c3b9311b92b0>

#text("We begin with a recap of where we are. ")#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/")[#text("Bryna Kra")]#text(" [4] describes the heart of the current problem. Over many years, theorem production has become the most important measure of success. Positions and prizes rest upon it. But it has always been a proxy for something harder to measure: understanding. Deep theorems were scarce and difficult, so they reliably identified deep thought. AI has broken that scarcity. For her, a proof is “a story, a picture, an insight, an explanation.” ")#link("https://terrytao.wordpress.com/2026/09/12/after-math/")[#text("Silvia De Toffoli and Eamon Duede")]#text(" [5] sharpen this perspective, rejecting the idea that mathematics is a game that machines can now win. The goal of mathematics is not simply a verifiable solution. Mathematics is “a body of knowledge engaged with, interpreted, and digested by a scholarly community,” not a registry of results. ")#link("https://www.its.caltech.edu/~matilde/AImathNew.pdf")[#text("Matilde Marcolli")]#text(" [6] goes further: the big theorems were never the point, only a value system the community chose, and choices can be made again. ")#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/")[#text("Grant Sanderson")]#text(" [7] asks what that means in practice: how do we give real credit to the other forms that mathematical work and understanding take?")

#text("Other forms of knowing have been given credit in the past. Our paper begins with the hand-drawing required in mathematical training at Gaspard Monge’s École Polytechnique in the nineteenth century. At the January workshop, historian Frédéric Brechenmacher made this explicit: “Drawing was knowing.” [8] We trace how that tradition was set aside in the twentieth century, but nevertheless persisted, emerging in part in a more recent debate over the relationship of proof and meaning in mathematics in the 1990s. At that time, in response to an influential paper by Arthur Jaffe and Frank Quinn [9], many mathematicians expressed their thoughts, most famously Bill Thurston. In his now much quoted “On Proof and Progress in Mathematics” [10], he defended his work against Jaffe and Quinn’s criticism. Many of the other responses are also worth reading [11]. The Philosophy of Mathematical Practice [12], the field of De Toffoli and Duede, studies these questions systematically across the community.")

#image("../assets/0b73f3b0e39933098d756324754666bb38f943825e3898e8beb03648e52f1e8b-a4e9806a635a37ed3867f475f4445dd637de9a6b0fa2373f7abb51e5f096c054.png", width: 90%)

#image("../assets/eab776fc893af9d7bb163be9d5c0f214d6d4e8b1c4db934ef5f0aaf88f3970d5-b825514848e419ae5091ec5bfd5da4f52d894bdf06a66c3060a75a74c9ea7915.png", width: 90%)

#emph[#text("Algebraic number starscapes: the complex roots of rational cubic polynomials. The right-hand image is a shader by Steve Trettel; code at ")#link("https://www.shadertoy.com/view/sfjGWw")[#text("shadertoy")]#text(".")]

#text("The Illustrating Mathematics community developed from this tradition of drawing and making mathematical objects. It took shape during a semester at ICERM in 2019 and went on to organise the IHP trimester this year [13]. It brings together mathematicians who actively develop images, models, software and experiences of mathematics. A particular focus has been the role illustration plays as a method of research: exploring, not just explaining, mathematics. In the same way that a good proof shows more than just its result, a good illustration does much more than demonstrate a form or pattern.")

#text("Our own work in algebraic starscapes [14], including the images above is a modest example (with Steve Trettel, and with Jayadev Athreya, Gabriel Dorfsman-Hopkins and Claudio Gonzalez joining in). The pictures show elaborate structure in the complex roots of rational cubic polynomials. When we moved to using shaders to draw the image (on the right), a naive first draft of the code turned circles into ellipses. But we realized that the unintended distortion revealed an extra dimension of meaningful structure. These pictures show mathematics that has not been explored, rather than explaining what is already known.")

#text("Of course, both proof and illustration can mislead, especially in research. The capabilities of LLMs come at a cost. In the case of illustration, their ability to produce code makes illustration more accessible than ever before. Yet by vibecoding, we are now two steps from knowledge: even the creation algorithm itself may not be understood.")

#text("In the case of proof, this problem of “digestion” is now centre-stage. ")#link("https://www.quantamagazine.org/update/167384/")[#text("This month")]#text(" [15], prompted by Ioannis Tsiokos, GPT-6 Astra found Chair44, the first three-dimensional aperiodic monotile. Tsiokos shared a 61-page paper [16]. He says he understood the intuitive geometric argument but not the mathematics. Chaim Goodman-Strauss then distilled the argument into eight pages [17] built around a diagram of matching arrows that makes the supertile structure visible, giving a classical hierarchical proof of aperiodicity. The illustration of the shape itself (in Tsiokos’ paper) was a critical clue in revealing the key idea.")

#text("So returning to our original question, in the face of these problems, how can an illustration be rigorous? In the paper we draw on Valeria Giardino’s account of representations as tools for thought (")#emph[#text("Endeavour")]#text(" 42, 2018) [18], which considers an illustration’s affordances: the readings, manipulations and inferences the figure invites. We might choose a stronger definition of affordances: the properties of the illustration that a proof certifies as accurate. Conversely, proofs can show that an apparent property is not an affordance. For example, early images of the Mandelbrot set seemed to show it was disconnected [19], but in a pixelated image a feature thinner than the step between pixels can be missed [20]. Properties such as the number of bulbs of a given size off the main cardioid, on the other hand, can be proved correct, provided the pixel size is small in comparison.")

#text("If this addresses the accuracy of an image, what about its engagement or ability to reveal? These are questions without clear answers, but they are not unimportant. They are also the questions that academic art asks of the work of its students, and art has a long-tested method: the “crit”. At the workshop, Jean Schmitt, a professor of art foundations, helped us set up a crit framework we used through the trimester. The crit is a discussion of a work, often presented with minimal introduction, to reveal how it is received by the audience. What are the similarities and differences between that reception and the creator’s intent? This gave a more formal structure to the sort of informal conversations we were already having, and placed the discussions in a communal space. The crit shares something with the style of Gelfand’s Moscow seminar.")

#text("Schmitt’s workshop talk [21] drew on Tim Ingold’s idea of thinking through making (")#emph[#text("Making")]#text(", Routledge, 2013) [22], in which form and understanding emerge through the process and in collaboration with the tools and materials available. In the same way Monge’s students were expected to learn through the process of drawing, not by observing the drawings of others. Value and understanding often come as much from the effort of creation, be it illustration or proof, as from viewing that created by others.")

#text("These ideas from art make explicit and visible something that has always been implicit in the mathematics community. Being a mathematician is as much about being an excited audience for the work of others as it is about presenting or creating our own research. As a community, we value aesthetics, elegance, and insight, and we have developed these shared values through our interactions. The oversized importance of publication and previously unproven results merely overshadowed these broader values, but people have always been working to find ways to ensure we give credit for them.")

#text("Infrastructure to support these broader values has also been growing. The Geometry Labs United network [23] brings together groups in many universities where undergraduates and graduates work with postdocs and faculty, exploring math as research, experimentation and visualisation. This gives a natural space for learning through making proofs, experiments, exposition and illustrations. In many cases the proof can be more contextual, proving the affordances of a specific experiment or illustration. Learning through making also aligns with work in mathematics education. In the final talk of our workshop, Hortensia Soto showed how working with physical materials supports learners’ actions, perceptions and sensations on the way to understanding [24].")

#text("Answering Sanderson’s call to credit things beyond proof can consists of, as much as anything, recognising and growing the work that has already been done. This work is happening in the community of Illustrating Mathematics, but also in the Philosophy of Mathematical Practice, in Geometry Labs, and many other places. Insights are found by connecting to mathematics education, outreach and even art. The work is happening: what it needs, as Sanderson argues, is support. With that we can achieve what Bryna Kra describes: a mathematics that continues to")

#text("“enlarge our capacity to reason and open our minds to new ways of understanding.” [4]")

#strong[#text("References")]

#text("[1] ")#emph[#text("Rigorous Illustrations: Their Creation and Evaluation for Mathematical Research")]#text(", workshop (2026 T1 WS1), Institut Henri Poincaré, January 2026. Programme and talks: ")#link("https://indico.math.cnrs.fr/event/13124/")[#text("https://indico.math.cnrs.fr/event/13124/")]

#text("[2] Jarod Alper, Michael Barany, Alain Chavarri Villarello, Sander Dahmen, Walter Dean, Karthik Ganapathy, Michael Harris, David Holmes, Mateja Jamnik, Steven Kelk, Bryna Kra, Ursula Martin, Bartosz Naskręcki, Rodrigo Ochigame, Jim Portegies, and Johannes Schmitt, ")#emph[#text("Leiden Declaration on Artificial Intelligence and Mathematics")]#text(", 2026. ")#link("https://doi.org/10.5281/zenodo.20302944")[#text("https://doi.org/10.5281/zenodo.20302944")]

#text("[3] Edmund Harriss and Katherine E. Stange, Mathematical Illustration: Proof, Intuition and AI, ")#emph[#text("Notices of the American Mathematical Society")]#text(", to appear. ")#link("https://arxiv.org/abs/2610.02655")[#text("https://arxiv.org/abs/2610.02655")]

#text("[4] Bryna Kra, “Deep theorems were scarce and difficult and so became an effective mechanism to identify deep thought. AI has broken this system.”, guest post, ")#emph[#text("What’s new")]#text(", 13 September 2026. ")#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/")[#text("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/")]

#text("[5] Silvia De Toffoli and Eamon Duede, After Math, guest post, ")#emph[#text("What’s new")]#text(", 12 September 2026. ")#link("https://terrytao.wordpress.com/2026/09/12/after-math/")[#text("https://terrytao.wordpress.com/2026/09/12/after-math/")]

#text("[6] Matilde Marcolli, essay on AI and mathematics, 2026. ")#link("https://www.its.caltech.edu/~matilde/AImathNew.pdf")[#text("https://www.its.caltech.edu/~matilde/AImathNew.pdf")]

#text("[7] Grant Sanderson, If math is more than proof, we need to better celebrate the rest of it, guest post, ")#emph[#text("What’s new")]#text(", 18 September 2026. ")#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/")[#text("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/")]

#text("[8] Frédéric Brechenmacher, The flat and the relief: Geometric material models in 19th century France, talk at [1], 2026. ")#link("https://dx.doi.org/10.57987/IHP.2026.T1.WS1.007")[#text("https://dx.doi.org/10.57987/IHP.2026.T1.WS1.007")]

#text("[9] Arthur Jaffe and Frank Quinn, ‘Theoretical mathematics’: Toward a cultural synthesis of mathematics and theoretical physics, ")#emph[#text("Bulletin of the American Mathematical Society")]#text(" 29 (1993), 1–13.")

#text("[10] William P. Thurston, On proof and progress in mathematics, ")#emph[#text("Bulletin of the American Mathematical Society")]#text(" 30 (1994), 161–177.")

#text("[11] Michael Atiyah, Armand Borel, Shiing-Shen Chern, et al., Responses to ‘Theoretical Mathematics: Toward a cultural synthesis of mathematics and theoretical physics,’ by A. Jaffe and F. Quinn, ")#emph[#text("Bulletin of the American Mathematical Society")]#text(" 30 (1994), 178–207.")

#text("[12] Silvia De Toffoli and Paolo Mancosu, The philosophy of mathematical practice, ")#emph[#text("The Stanford Encyclopedia of Philosophy")]#text(", 2026.")

#text("[13] Rémi Coulon, Gabriel Dorfsman-Hopkins, Edmund Harriss, Martin Skrodzki, Katherine E. Stange, and Glen Whitney, On the importance of illustration for mathematical research, ")#emph[#text("Notices of the American Mathematical Society")]#text(" 71 (2024), no. 1, 105–115.")

#text("[14] Edmund Harriss, Katherine E. Stange, and Steve Trettel, Algebraic number starscapes, ")#emph[#text("Experimental Mathematics")]#text(" (2022).")

#text("[15] Konstantin Kakaes, Software developer finds first 3D “einstein” tile, ")#emph[#text("Quanta Magazine")]#text(", 23 September 2026. ")#link("https://www.quantamagazine.org/update/167384/")[#text("https://www.quantamagazine.org/update/167384/")]

#text("[16] Ioannis Tsiokos, Chair44 paper, arXiv:2609.19214, 2026. ")#link("https://arxiv.org/abs/2609.19214")[#text("https://arxiv.org/abs/2609.19214")]

#text("[17] Chaim Goodman-Strauss, paper on the Chair44 tile, arXiv:2609.24779, 2026. ")#link("https://arxiv.org/abs/2609.24779")[#text("https://arxiv.org/abs/2609.24779")]

#text("[18] Valeria Giardino, Tools for thought: The case of mathematics, ")#emph[#text("Endeavour")]#text(" 42 (2018), no. 2–3, 172–179.")

#text("[19] Benoit B. Mandelbrot, Fractal aspects of the iteration of z ↦ λz(1 – z) for complex λ and z, ")#emph[#text("Annals of the New York Academy of Sciences")]#text(" 357 (1980), no. 1, 249–259.")

#text("[20] Adrien Douady and John H. Hubbard, Itération des polynômes quadratiques complexes, ")#emph[#text("Comptes Rendus de l’Académie des Sciences, Série I Mathématique")]#text(" 294 (1982), 123–126.")

#text("[21] Jean Schmitt, talk at [1], 2026. ")#link("https://indico.math.cnrs.fr/event/13124/contributions/14965/")[#text("https://indico.math.cnrs.fr/event/13124/contributions/14965/")]

#text("[22] Tim Ingold, ")#emph[#text("Making: Anthropology, Archaeology, Art and Architecture")]#text(", Routledge, 2013.")

#text("[23] Jayadev Athreya, Emily Dumas, William Goldman, Sergey Grigorian, Rosemary Guzman, Philipp Hieronymi, Sean Lawton, Anton Lukyanenko, Jeremy Tyson, and Aaron Wilson, Geometry labs united: An invitation, ")#emph[#text("Notices of the American Mathematical Society")]#text(" 65 (2018), no. 9, 1088–1093.")

#text("[24] Hortensia Soto, Rigorous and flexible illustrations: Inviting realms of possibilities, talk at [1], 2026. ")#link("https://dx.doi.org/10.57987/IHP.2026.T1.WS1.017")[#text("https://dx.doi.org/10.57987/IHP.2026.T1.WS1.017")]

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed0e33c0c2cae68926c9965877193cb5b50d88e4fa3c9dd54fa8b1365b5b45c7-02a30b3afad7f3b5530817339a95487d28e12644af249ca826bc5f3eab29c513.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of satyrchary")]], [#link("https://terrytao.wordpress.com/2026/10/11/illustration-beyond-proof/#comment-697753")[#strong[#text("satyrchary")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("Ooh, George Francis’ ‘A Topological Picturebook’ comes to mind… geometric intuition via lovely and clear blackboard drawings that utilize artistic expression techniques (shading, cross hatching, silhouette depiction etc). And of course, Escher’s work, and Fomenko’s as well!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/054ea8f558ef738affa76b1ee5e862774be3b3d40159a55bd4f86702e5b1dd5d-8671a3a63f724ebc289b58480761d48799387133c25b5a009ca1aa35165c3a83.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A P")]], [#link("https://terrytao.wordpress.com/2026/10/11/illustration-beyond-proof/#comment-697768")[#strong[#text("A P")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("that’s all not wrong, and well written and important. But it is still such a hypocrisy to pretend that switching to illustration and “digestion” (what a horrible word) without having come up with your own calculations and ideas can replace research. If this is what will become of research it just way less appealing or maybe appealing to different people.")

#text("In other words, AI made some of the work of designers and illustrators redundant much earlier than mathematicians, so illustrators are not really people to take inspiration from.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/494df6d6a0c1f66a7c37c90f07c0170a976e18d7685e3f3655823a77ad367d19-15b9e865ba19e63a177222a16fbe652f863c942035df375cc63b0d9ca7fa4aaf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gelada")]], [#link("https://terrytao.wordpress.com/2026/10/11/illustration-beyond-proof/#comment-697813")[#strong[#text("gelada")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("We broadly agree. This is about doing the work and having ideas (which both mathematical illustration and transforming established results require). This is not about a switch but recognising the range of work the community has been doing that has always helped create ideas and will continue to do so.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/11/illustration-beyond-proof/#comment-697906")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I think the issue is financial: Artists and designers can still do wonderful work, but AI has made it much harder for them to turn their creativity into an income. Mathematicians can still come up with wonderful theorems and mathematical ideas, but turning this into a career that earns you a living will be much more difficult than before.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b4f5d99aac7261cf146c2fcfb9ee07e0df920243e6d9e27792b42b42b3834b74-3fffaeab9d64d163a1127d51be5f95f65af3c1e654dded4e00556a857488fbd8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bevan")]], [#link("https://terrytao.wordpress.com/2026/10/11/illustration-beyond-proof/#comment-697777")[#strong[#text("David Bevan")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Elias Wegert’s ")#emph[#text("Visual Complex Functions")]#text(" is another beautiful example of pedagogy through illustration.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f31f0c11c1e58f3a9ebad4d8cf4654cbbc291b28a1279962afea745a3089ddd-794dfb8e4226422af322781f410d21540ec6ef952fefde4edf287302126cb7fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Homeward")]], [#link("https://terrytao.wordpress.com/2026/10/11/illustration-beyond-proof/#comment-697788")[#strong[#text("Homeward")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("As a non-mathematician with an interest in mathematics, I find it puzzling as to why mathematicians are worried. Most solutions or proofs that are being claimed are yet to be verified formally and, nevertheless, do build on decades of mathematical research and ideas. The latter part is almost always going to be human-generated.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69d2940a5978fcd4b2989f2c95f9145325e0b47af1105c0b319956c27f9e517e-006405f489d1b081bb43347dff7d7fb8b96d331a11d5ac17090f6baa78dbe1d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2026/10/11/illustration-beyond-proof/#comment-697791")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("What happens when AI also becomes better than humans at explaining, visualising, teaching, and interpreting mathematics?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/11/illustration-beyond-proof/#comment-697903")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("Same thing as when AI became better at chess than humans: We still watch human chess players, admire them, and enjoy the wonderful entertainment they provide to us, even if they are not the source of the best chess moves anymore.")
]
]
