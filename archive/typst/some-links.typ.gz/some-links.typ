// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/05/01/some-links/
// Converted to Typst by tao2typ: "2026-10-14T08:58:52.621713+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Some links", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Some links")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 May 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/05/01/some-links/")[#text("https://terrytao.wordpress.com/2010/05/01/some-links/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Michael Nielsen has posted a draft of his article “")#link("http://michaelnielsen.org/blog/introduction-to-the-polymath-project-and-density-hales-jewett-and-moser-numbers/")[#text("Introduction to the Polymath Project and “Density Hales-Jewett and Moser Numbers”")]#text("” for comments, which will precede our ")#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/")[#text("own polymath article")]#text(" in the Szemerédi birthday conference proceedings.")

#text("As an unrelated link, ")#link("http://quomodocumque.wordpress.com/2010/04/30/the-census-will-be-wrong-we-could-fix-it/")[#text("Jordan Ellenberg")]#text(" has just written a ")#link("http://www.washingtonpost.com/wp-dyn/content/article/2010/04/30/AR2010043001862.html")[#text("piece for the Washington Post")]#text(" on statistical sampling and how it could make the US census more accurate. (Whether this is politically viable is, of course, a different matter.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2010/05/01/some-links/#comment-44557")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2010")])]

#text("Great newspaper article! “… The skepticism that people like Gregg apply to statistics, if applied to other sciences, would get them lumped with the anti-vaccinationists and the homeopaths. The difference? Everyone knows that physics, chemistry and biology have changed radically in the past hundred years; the tools available are fantastically more powerful and reliable than those of the past. Math, by contrast, is taught as if Isaac Newton supplied the final word on the subject….”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kelly Johnson")]], [#link("https://terrytao.wordpress.com/2010/05/01/some-links/#comment-44559")[#strong[#text("Kelly Johnson")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2010")])]

#text("I also enjoyed the Washington Post article by Jordan Ellenberg. I found the following sentence particularly incisive, “To choose the raw [census] count is to be wrong on purpose in order to avoid being wrong by accident.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/05/01/some-links/#comment-44644")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2010")])]

#text("In case there is anyone to whom it wasn’t known or obvious, there was a big political battle in the 1990’s (leading to the Supreme Court case with the opinion written by Justice Scalia) about whether to allow statistical sampling in the census. The political reason to oppose sampling was that the census is more likely to miss (undercount) people in lower income and minority ethnic groups, that were disfavored by sampling opponents, than it is to miss members of the groups the opponents favored. Undercounting these people diminishes the congressional apportionment given to the regions where they live, which is the outcome the opponents were seeking. For the side that prevailed, undercounting was not an unfortunate side effect of anything. It was the goal.")
]
