// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/
// Converted to Typst by tao2typ: "2026-10-14T16:36:13.717730+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Euler-Arnold equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Euler-Arnold equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 June 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/")[#text("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A (smooth) ")#link("http://en.wikipedia.org/wiki/Riemannian_manifold")[#text("Riemannian manifold")]#text(" is a smooth manifold ")#mi("{M}")#text(" without boundary, equipped with a Riemannian metric ")#mi("{{\\rm g}}")#text(", which assigns a length ")#tao-math("{\\left|v\\right|_{{\\rm g}(x)} \\in {\\bf R}^+}", block: false)#text(" to every tangent vector ")#mi("{v \\in T_x M}")#text(" at a point ")#mi("{x \\in M}")#text(", and more generally assigns an inner product")

#align(center)[#tao-fit-display[#mitex("\\langle v, w \\rangle_{{\\rm g}(x)} \\in {\\bf R}")]]

#text("to every pair of tangent vectors ")#mi("{v, w \\in T_x M}")#text(" at a point ")#mi("{x \\in M}")#text(". (We use Roman font for ")#mi("{g}")#text(" here, as we will need to use ")#mi("{g}")#text(" to denote group elements later in this post.) This inner product is assumed to symmetric, positive definite, and smoothly varying in ")#mi("{x}")#text(", and the length is then given in terms of the inner product by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left|v\\right|_{{\\rm g}(x)}^2 := \\langle v, v \\rangle_{{\\rm g}(x)}.", block: true)]]

#text("In coordinates (and also using ")#link("http://en.wikipedia.org/wiki/Abstract_index_notation")[#text("abstract index notation")]#text("), the metric ")#mi("{{\\rm g}}")#text(" can be viewed as an invertible symmetric rank ")#mi("{(0,2)}")#text(" tensor ")#mi("{{\\rm g}_{ij}(x)}")#text(", with")

#align(center)[#tao-fit-display[#mitex("\\langle v, w \\rangle_{{\\rm g}(x)} = {\\rm g}_{ij}(x) v^i w^j.")]]

#text("One can also view the Riemannian metric as providing a (self-adjoint) identification between the ")#link("http://en.wikipedia.org/wiki/Tangent_bundle")[#text("tangent bundle")]#text(" ")#mi("{TM}")#text(" of the manifold and the ")#link("http://en.wikipedia.org/wiki/Cotangent_bundle")[#text("cotangent bundle")]#text(" ")#mi("{T^* M}")#text("; indeed, every tangent vector ")#mi("{v \\in T_x M}")#text(" is then identified with the cotangent vector ")#mi("{\\iota_{TM \\rightarrow T^* M}(v) \\in T_x^* M}")#text(", defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\iota_{TM \\rightarrow T^* M}(v)(w) := \\langle v, w \\rangle_{{\\rm g}(x)}.")]]

#text("In coordinates, ")#mi("{\\iota_{TM \\rightarrow T^* M}(v)_i = {\\rm g}_{ij} v^j}")#text(".")

#text("A fundamental dynamical system on the tangent bundle (or equivalently, the cotangent bundle, using the above identification) of a Riemannian manifold is that of ")#link("http://en.wikipedia.org/wiki/Geodesic_flow")[#text("geodesic flow")]#text(". Recall that geodesics are smooth curves ")#mi("{\\gamma: [a,b] \\rightarrow M}")#text(" that minimise the length")

#align(center)[#tao-fit-display[#tao-math("\\left|\\gamma\\right| := \\int_a^b \\left|\\gamma^{\\prime}(t)\\right|_{{\\rm g}(\\gamma(t))}\\ dt.", block: true)]]

#text("There is some degeneracy in this definition, because one can reparameterise the curve ")#mi("{\\gamma}")#text(" without affecting the length. In order to fix this degeneracy (and also because the square of the speed is a more tractable quantity analytically than the speed itself), it is better if one replaces the length with the ")#emph[#text("energy")]

#align(center)[#tao-fit-display[#tao-math("E(\\gamma) := \\frac{1}{2} \\int_a^b \\left|\\gamma^{\\prime}(t)\\right|_{{\\rm g}(\\gamma(t))}^2\\ dt.", block: true)]]

#text("Minimising the energy of a parameterised curve ")#mi("{\\gamma}")#text(" turns out to be the same as minimising the length, together with an additional requirement that the speed ")#tao-math("{\\left|\\gamma^{\\prime}(t)\\right|_{{\\rm g}(\\gamma(t))}}", block: false)#text(" stay constant in time. Minimisers (and more generally, critical points) of the energy functional (holding the endpoints fixed) are known as ")#emph[#text("geodesic flows")]#text(". From a physical perspective, geodesic flow governs the motion of a particle that is subject to no external forces and thus moves freely, save for the constraint that it must always lie on the manifold ")#mi("{M}")#text(".")

#text("One can also view geodesic flows as a dynamical system on the tangent bundle (with the state at any time ")#mi("{t}")#text(" given by the position ")#mi("{\\gamma(t) \\in M}")#text(" and the velocity ")#mi("{\\gamma^{\\prime}(t) \\in T_{\\gamma(t)} M}")#text(") or on the cotangent bundle (with the state then given by the position ")#mi("{\\gamma(t) \\in M}")#text(" and the ")#emph[#text("momentum")]#text(" ")#mi("{\\iota_{TM \\rightarrow T^* M}( \\gamma^{\\prime}(t) ) \\in T_{\\gamma(t)}^* M}")#text("). With the latter perspective (sometimes referred to as ")#emph[#text("cogeodesic flow")]#text("), geodesic flow becomes a Hamiltonian flow, with Hamiltonian ")#mi("{H: T^* M \\rightarrow {\\bf R}}")#text(" given as")

#align(center)[#tao-fit-display[#mitex("H( x, p ) := \\frac{1}{2} \\langle p, p \\rangle_{{\\rm g}(x)^{-1}} = \\frac{1}{2} {\\rm g}^{ij}(x) p_i p_j")]]

#text("where ")#mi("{\\langle ,\\rangle_{{\\rm g}(x)^{-1}}: T^*_x M \\times T^*_x M \\rightarrow {\\bf R}}")#text(" is the inverse inner product to ")#mi("{\\langle, \\rangle_{{\\rm g}(x)}: T_x M \\times T_x M \\rightarrow {\\bf R}}")#text(", which can be defined for instance by the formula")

#align(center)[#tao-fit-display[#mitex("\\langle p_1, p_2 \\rangle_{{\\rm g}(x)^{-1}} = \\langle \\iota_{TM \\rightarrow T^* M}^{-1}(p_1), \\iota_{TM \\rightarrow T^* M}^{-1}(p_2)\\rangle_{{\\rm g}(x)}.")]]

#text("In coordinates, geodesic flow is given by Hamilton’s equations of motion")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} x^i = {\\rm g}^{ij} p_j; \\quad \\frac{d}{dt} p_i = - \\frac{1}{2} (\\partial_i {\\rm g}^{jk}(x)) p_j p_k.")]]

#text("In terms of the velocity ")#mi("{v^i := \\frac{d}{dt} x^i = {\\rm g}^{ij} p_j}")#text(", we can rewrite these equations as the geodesic equation")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} v^i = - \\Gamma^i_{jk} v^j v^k")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\Gamma^i_{jk} = \\frac{1}{2} {\\rm g}^{im} (\\partial_k {\\rm g}_{mj} + \\partial_j {\\rm g}_{mk} - \\partial_m {\\rm g}_{jk} )")]]

#text("are the ")#link("http://en.wikipedia.org/wiki/Christoffel_symbol")[#text("Christoffel symbols")]#text("; using ")#link("http://en.wikipedia.org/wiki/Levi-Civita_connection")[#text("the Levi-Civita connection")]#text(" ")#mi("{\\nabla}")#text(", this can be written more succinctly as")

#align(center)[#tao-fit-display[#mitex("(\\gamma^* \\nabla)_t v = 0.")]]

#text("If the manifold ")#mi("{M}")#text(" is an embedded submanifold of a larger Euclidean space ")#mi("{R^n}")#text(", with the metric ")#mi("{{\\rm g}}")#text(" on ")#mi("{M}")#text(" being induced from the standard metric on ")#mi("{{\\bf R}^n}")#text(", then the geodesic flow equation can be rewritten in the equivalent form")

#align(center)[#tao-fit-display[#mitex("\\gamma^{\\prime\\prime}(t) \\perp T_{\\gamma(t)} M,")]]

#text("where ")#mi("{\\gamma}")#text(" is now viewed as taking values in ")#mi("{{\\bf R}^n}")#text(", and ")#mi("{T_{\\gamma(t)} M}")#text(" is similarly viewed as a subspace of ")#mi("{{\\bf R}^n}")#text(". This is intuitively obvious from the geometric interpretation of geodesics: if the curvature of a curve ")#mi("{\\gamma}")#text(" contains components that are transverse to the manifold rather than normal to it, then it is geometrically clear that one should be able to shorten the curve by shifting it along the indicated transverse direction. It is an instructive exercise to rigorously formulate the above intuitive argument. This fact also conforms well with one’s physical intuition of geodesic flow as the motion of a free particle constrained to be in ")#mi("{M}")#text("; the normal quantity ")#mi("{\\gamma^{\\prime\\prime}(t)}")#text(" then corresponds to the ")#emph[#text("centripetal force")]#text(" necessary to keep the particle lying in ")#mi("{M}")#text(" (otherwise it would fly off along a tangent line to ")#mi("{M}")#text(", as per Newton’s first law). The precise value of the normal vector ")#mi("{\\gamma^{\\prime\\prime}(t)}")#text(" can be computed via the ")#link("http://en.wikipedia.org/wiki/Second_fundamental_form")[#text("second fundamental form")]#text(" as ")#mi("{\\gamma^{\\prime\\prime}(t) = \\Pi_{\\gamma(t)}( \\gamma^{\\prime}(t), \\gamma^{\\prime}(t) )}")#text(", but we will not need this formula here.")

#text("In ")#link("http://www.ams.org/mathscinet-getitem?mr=202082")[#text("a beautiful paper from 1966")]#text(", Vladimir Arnold (who, sadly, passed away last week), observed that many basic equations in physics, including the Euler equations of motion of a rigid body, and also (by which is ")#emph[#text("a priori")]#text(" a remarkable coincidence) the Euler equations of fluid dynamics of an inviscid incompressible fluid, can be viewed (formally, at least) as geodesic flows on a (finite or infinite dimensional) Riemannian manifold. And not just any Riemannian manifold: the manifold is a Lie group (or, to be truly pedantic, a ")#link("http://en.wikipedia.org/wiki/Torsor")[#text("torsor")]#text(" of that group), equipped with a right-invariant (or left-invariant, depending on one’s conventions) metric. In the context of rigid bodies, the Lie group is the group ")#mi("{SE(3) = {\\bf R}^3 \\rtimes SO(3)}")#text(" of rigid motions; in the context of incompressible fluids, it is the group ")#mi("{Sdiff({\\bf R}^3}")#text(") of measure-preserving diffeomorphisms. The right-invariance makes the Hamiltonian mechanics of geodesic flow in this context (where it is sometimes known as the ")#emph[#text("Euler-Arnold equation")]#text(" or the ")#emph[#text("Euler-Poisson equation")]#text(") quite special; it becomes (formally, at least) completely integrable, and also indicates (in principle, at least) a way to reformulate these equations in a Lax pair formulation. And indeed, many further completely integrable equations, such as the Korteweg-de Vries equation, have since been reinterpreted as Euler-Arnold flows.")

#text("From a physical perspective, this all fits well with the interpretation of geodesic flow as the free motion of a system subject only to a physical constraint, such as rigidity or incompressibility. (I do not know, though, of a similarly intuitive explanation as to why the Korteweg de Vries equation is a geodesic flow.)")

#text("One consequence of being a completely integrable system is that one has a large number of conserved quantities. In the case of the Euler equations of motion of a rigid body, the conserved quantities are the linear and angular momentum (as observed in an external reference frame, rather than the frame of the object). In the case of the two-dimensional Euler equations, the conserved quantities are the pointwise values of the vorticity (as viewed in ")#link("http://en.wikipedia.org/wiki/Lagrangian_and_Eulerian_specification_of_the_flow_field")[#text("Lagrangian coordinates, rather than Eulerian coordinates")]#text("). In higher dimensions, the conserved quantity is now the (Hodge star of) the vorticity, again viewed in Lagrangian coordinates. The vorticity itself then evolves by the ")#emph[#text("vorticity equation")]#text(", and is subject to ")#link("http://en.wikipedia.org/wiki/Vortex_stretching")[#text("vortex stretching")]#text(" as the diffeomorphism between the initial and final state becomes increasingly sheared.")

#text("The elegant Euler-Arnold formalism is reasonably well-known in some circles (particularly in Lagrangian and symplectic dynamics, where it can be viewed as a special case of the ")#emph[#text("Euler-Poincaré formalism")]#text(" or ")#emph[#text("Lie-Poisson formalism")]#text(" respectively), but not in others; I for instance was only vaguely aware of it until recently, and I think that even in fluid mechanics this perspective to the subject is not always emphasised. Given the circumstances, I thought it would therefore be appropriate to present Arnold’s original 1966 paper here. (For a more modern treatment of these topics, see the books of ")#link("http://www.ams.org/mathscinet-getitem?mr=1612569")[#text("Arnold-Khesin")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1723696")[#text("Marsden-Ratiu")]#text(".)")

#text("In order to avoid technical issues, I will work formally, ignoring questions of regularity or integrability, and pretending that infinite-dimensional manifolds behave in exactly the same way as their finite-dimensional counterparts. In the finite-dimensional setting, it is not difficult to make all of the formal discussion below rigorous; but the situation in infinite dimensions is substantially more delicate. (Indeed, it is a notorious open problem whether the Euler equations for incompressible fluids even forms a global continuous flow in a reasonable topology in the first place!) However, I do not want to discuss these analytic issues here; see ")#link("http://www.ams.org/mathscinet-getitem?mr=271984")[#text("this paper of Ebin and Marsden")]#text(" for a treatment of these topics.")

#metadata(none) <tao-1182a49197c2b9bf6e52>

#heading(level: 1)[#strong[#text(" — 1. Geodesic flow using a right-invariant metric — ")]]

#text("Let ")#mi("{G}")#text(" be a Lie group. From a physical perspective, one should think of a group element ")#mi("{g}")#text(" as describing the relationship between a fixed reference observer ")#mi("{O}")#text(", and a moving object ")#mi("{A = gO}")#text("; mathematically, one could think of ")#mi("{A}")#text(" and ")#mi("{O}")#text(" as belonging to a (left) ")#link("http://en.wikipedia.org/wiki/Torsor")[#text("torsor")]#text(" ")#mi("{M}")#text(" of ")#mi("{G}")#text(". (One could also work with right torsors; this would require a number of sign conventions below to be altered.) For instance, in the case of rigid motions, ")#mi("{O}")#text(" would be the reference state of a rigid body, ")#mi("{A}")#text(" would be the current state, and ")#mi("{g = A/O}")#text(" would be the element of the rigid motion group ")#mi("{SE(3) = {\\bf R}^3 \\rtimes SO(3)}")#text(" that moves ")#mi("{O}")#text(" to ")#mi("{A}")#text("; ")#mi("{M}")#text(" is then the ")#link("http://en.wikipedia.org/wiki/Configuration_space")[#text("configuration space")]#text(" of the rigid body. Similarly, in the case of incompressible fluids, ")#mi("{O}")#text(" would be a reference state of the fluid (e.g. the initial state at time ")#mi("{t=0}")#text("), ")#mi("{A}")#text(" would be the current state, and ")#mi("{g \\in SDiff({\\bf R}^3)}")#text(" would be the measure-preserving diffeomorphism required to map the location each particle of the fluid at ")#mi("{O}")#text(" to the corresponding location of the same particle at ")#mi("{A}")#text(". Again, ")#mi("{M}")#text(" would be the configuration space of the fluid.")

#text("Once one fixes the reference observer ")#mi("{O}")#text(", one can set up a bijection between the torsor ")#mi("{M}")#text(" and the group ")#mi("{G}")#text("; but one can also adopt a “coordinate-free” perspective in which the observer ")#mi("{O}")#text(" is not present, in which case one should keep ")#mi("{M}")#text(" and ")#mi("{G}")#text(" distinct. Strictly speaking, the geodesic flow we will introduce will be on ")#mi("{M}")#text(" rather than on ")#mi("{G}")#text(", but for some minor notational reasons it is convenient to fix a reference observer ")#mi("{O}")#text(" in order to identify the two objects.")

#text("Let ")#mi("{{\\mathfrak g} := T_{id} G}")#text(" denote the Lie algebra of ")#mi("{G}")#text(", i.e. the tangent space of ")#mi("{G}")#text(" at the identity. This Lie algebra can be identified with the tangent space ")#mi("{T_A M}")#text(" of a state ")#mi("{A}")#text(" in ")#mi("{M}")#text(" in two different ways: an intrinsic one that does not use a reference observer ")#mi("{O}")#text(", and an extrinsic one which does rely on this observer.")

#list(
[#text("(Intrinsic identification) If ")#mi("{V \\in T_A M}")#text(" is a tangent vector to ")#mi("{A}")#text(", we let ")#mi("{V/A \\in {\\mathfrak g}}")#text(" be the associated element of the Lie algebra defined infinitesimally as")

#align(center)[#tao-fit-display[#mitex("A + \\epsilon V = (1 + \\epsilon V/A) A")]]

#text("modulo higher order terms for infinitesimal ")#mi("{\\epsilon}")#text(", or more traditionally by requiring ")#mi("{\\gamma^{\\prime}(0)/\\gamma(0) = g^{\\prime}(0)}")#text(" whenever ")#mi("{\\gamma: {\\bf R} \\rightarrow M}")#text(", ")#mi("{g: {\\bf R} \\rightarrow G}")#text(" are smooth curves such that ")#mi("{\\gamma(t) = g(t) \\gamma(0)}")#text(". Conversely, if ")#mi("{X \\in {\\mathfrak g}}")#text(", we let ")#mi("{XA \\in T_A M}")#text(" be the tangent vector at ")#mi("{A}")#text(" defined infinitesimally as")

#align(center)[#tao-fit-display[#mitex("A + \\epsilon X A = (1 + \\epsilon X) A")]]

#text("modulo higher order terms for infinitesimal ")#mi("{\\epsilon}")#text(", or more traditionally by requiring ")#mi("{\\gamma^{\\prime}(0) = g^{\\prime}(0) \\gamma(0)}")#text(" whenever ")#mi("{\\gamma: {\\bf R} \\rightarrow M}")#text(", ")#mi("{g: {\\bf R} \\rightarrow G}")#text(" are smooth curves such that ")#mi("{\\gamma(t) = g(t) \\gamma(0)}")#text(" (so ")#mi("{g(0) = id}")#text("). Clearly, these two operations invert each other.")],
[#text("(Extrinsic identification) If ")#mi("{V \\in T_A M}")#text(" is a tangent vector to ")#mi("{A}")#text(", and ")#mi("{A=gO}")#text(" for some fixed reference ")#mi("{O}")#text(", we let ")#mi("{g^{-1} V/O \\in {\\mathfrak g}}")#text(" be the element of the Lie algebra defined infinitesimally as")

#align(center)[#tao-fit-display[#mitex("A + \\epsilon V = g( (1 + \\epsilon g^{-1} V/O) O )")]]

#text("or more traditionally by requiring ")#mi("{g^{-1} \\gamma^{\\prime}(0)/O = h^{\\prime}(0)}")#text(" whenever ")#mi("{\\gamma: {\\bf R} \\rightarrow M}")#text(", ")#mi("{h: {\\bf R} \\rightarrow G}")#text(" are such that ")#mi("{\\gamma(t) = g h(t) O}")#text(" and ")#mi("{h(0)=id}")#text(".")]
)

#text("The distinction between intrinsic and extrinsic identifications is closely related to the distinction between ")#link("http://en.wikipedia.org/wiki/Active_and_passive_transformation")[#text("active and passive transformations")]#text(": ")#mi("{V/A}")#text(" denotes the direction in which ")#mi("{A}")#text(" must move in order to effect a change of ")#mi("{V}")#text(" in the apparent position of ")#mi("{A}")#text(" relative to any observer ")#mi("{O}")#text(", whereas ")#mi("{g^{-1} V/O}")#text(" is the (inverse of the) direction in which the ")#emph[#text("reference")]#text(" ")#mi("{O}")#text(" would move to effect the same change in the apparent position. The two quantities are related to each other by conjugation:")

#align(center)[#tao-fit-display[#mitex("g^{-1} V/O = g^{-1} ( V/A ) g; \\quad V/A = g (g^{-1} V/O) g^{-1}")]]

#text("where we define conjugation ")#mi("{X \\mapsto g X g^{-1}}")#text(" of a Lie algebra element ")#mi("{X}")#text(" by a Lie group element ")#mi("{g}")#text(" in the usual manner.")

#text("If ")#mi("{A(t) \\in M}")#text(" is the state of a rigid body at time ")#mi("{t}")#text(", then ")#mi("{A^{\\prime}(t)/A(t)}")#text(" is the linear and angular velocity of ")#mi("{A(t)}")#text(" as measured in ")#mi("{A(t)}")#text("‘s current spatial reference frame, while if ")#mi("{A(t) = g(t) O}")#text(", then ")#mi("{g(t)^{-1} A^{\\prime}(t) / O}")#text(" is the linear and angular velocity of ")#mi("{A(t)}")#text(" as measured in the frame of ")#mi("{O}")#text(". Similarly, if ")#mi("{A(t) \\in M}")#text(" is the state of an incompressible fluid at time ")#mi("{t}")#text(", then ")#mi("{A^{\\prime}(t)/A(t)}")#text(" is the velocity field ")#mi("{u(t)}")#text(" in ")#link("http://en.wikipedia.org/wiki/Lagrangian_and_Eulerian_specification_of_the_flow_field")[#text("Eulerian coordinates")]#text(", while ")#mi("{g(t)^{-1} A^{\\prime}(t) / O}")#text(" is the velocity field ")#mi("{u \\circ g(t)}")#text(" in ")#link("http://en.wikipedia.org/wiki/Lagrangian_and_Eulerian_specification_of_the_flow_field")[#text("Lagrangian coordinates")]#text(".")

#text("The left action of ")#mi("{G}")#text(" ")#mi("{g: A \\mapsto gA}")#text(" on the torsor ")#mi("{M}")#text(" induces a corresponding action ")#mi("{g: V \\rightarrow gV}")#text(" on the tangent bundle ")#mi("{TM}")#text(". Indeed, this action was implicitly present in the notation ")#mi("{g^{-1} V/O}")#text(" used earlier.")

#text("Now suppose we choose a non-degenerate inner product ")#mi("{\\langle,\\rangle_{{\\mathfrak g}}}")#text(" on the Lie algebra ")#mi("{{\\mathfrak g}}")#text(". We do ")#emph[#text("not")]#text(" assume any symmetries or invariances of this inner product with respect to the group structure, such as conjugation invariance; in particular, this inner product will usually ")#emph[#text("not")]#text(" be the ")#link("http://en.wikipedia.org/wiki/Killing_form")[#text("Cartan-Killing form")]#text(". At any rate, once we select an inner product, we can construct a right-invariant Riemannian metric ")#mi("{{\\rm g}}")#text(" on ")#mi("{M}")#text(" by the formula ")#metadata(none) <tao-eac42ad34c8f70c750fe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\langle V, W \\rangle_{{\\rm g}(A)} := \\langle V/A, W/A \\rangle_{{\\mathfrak g}}.")]]

#text("Because we do not require the inner product to be conjugation invariant, this metric will usually not be bi-invariant, instead being merely right-invariant.")

#text("The quantity ")#mi("{H(V) := \\frac{1}{2} \\langle V, V \\rangle_{{\\rm g}(A)}}")#text(" is the ")#emph[#text("Hamiltonian")]#text(" associated to this metric. For rigid bodies, this Hamiltonian is the total kinetic energy of the body, which is the sum of the kinetic energy ")#tao-math("{\\frac{1}{2} m \\left|v\\right|^2}", block: false)#text(" of the centre of mass, plus the rotational kinetic energy ")#mi("{\\frac{1}{2} I( \\omega, \\omega)}")#text(" which is determined by the ")#link("http://en.wikipedia.org/wiki/Moment_of_inertia")[#text("moments of inertia")]#text(" ")#mi("{I}")#text(". For incompressible fluids, the Hamiltonian is (up to a normalising constant) the energy ")#tao-math("{\\frac{1}{2} \\int_{{\\bf R}^3} \\left|u\\right|^2 = \\frac{1}{2} \\int_{{\\bf R}^3} \\left|u \\circ A\\right|^2}", block: false)#text(" of the fluid, which can be computed either in Eulerian coordinates or in Lagrangian coordinates (there are no Jacobian factors here thanks to incompressibility).")

#text("Another important object in the Euler-Arnold formalism is the bilinear form ")#mi("{B: {\\mathfrak g} \\times {\\mathfrak g} \\rightarrow {\\mathfrak g}}")#text(" associated to the inner product ")#mi("{\\langle, \\rangle}")#text(", defined via the Lie bracket and duality using the formula ")#metadata(none) <tao-3e744b9dc39389baf0c5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\langle [X,Y], Z \\rangle = \\langle B(Z,Y), X \\rangle,")]]

#text("thus ")#mi("{B}")#text(" is a partial adjoint of the Lie bracket operator. (The conventions here differ slightly from those in Arnold’s paper.) Note that this form need not be symmetric. The importance of this form comes from the fact that it describes the geodesic flow:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Euler-Arnold equation)")]#text(" Let ")#mi("{\\gamma: {\\bf R} \\rightarrow M}")#text(" be a geodesic flow on ")#mi("{M}")#text(" using the right-invariant metric ")#mi("{{\\rm g}}")#text(" defined above, and let ")#mi("{X(t) := \\gamma^{\\prime}(t) / \\gamma(t) \\in {\\mathfrak g}}")#text(" be the intrinsic velocity vector. Then ")#mi("{X}")#text(" obeys the equation ")#metadata(none) <tao-d7939186d51d823b7c9c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\frac{d}{dt} X(t) = B(X(t), X(t)).")]]
]

#text("The Euler-Arnold equation is also known as the ")#emph[#text("Euler-Poincaré equation")]#text("; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=2078563")[#text("this paper of Cendra, Marsden, Pekarsky, and Ratiu")]#text(" for further discussion.")

#emph[#text("Proof:")]#text(" For notational reasons, we will prove this in the model case when ")#mi("{G}")#text(" is a matrix group (so that we can place ")#mi("{G}")#text(", ")#mi("{M}")#text(", and ")#mi("{{\\mathfrak g}}")#text(" in a common vector space, or more precisely a common matrix space); the general case is similar but requires more abstract notation. We consider a variation ")#mi("{\\gamma(s,t)}")#text(" of the original curve ")#mi("{\\gamma(t)=\\gamma(s,t)}")#text(", and consider the first variation of the energy")

#align(center)[#tao-fit-display[#mitex("\\partial_s \\frac{1}{2} \\int_a^b \\langle \\partial_t \\gamma(s,t), \\partial_t \\gamma(s,t) \\rangle_{{\\rm g}(\\gamma(s,t))}\\ dt")]]

#text("which we write using ")#link(<tao-eac42ad34c8f70c750fe>)[#text("(1)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\partial_s \\frac{1}{2} \\int_a^b \\langle \\gamma_t \\gamma^{-1}, \\gamma_t \\gamma^{-1} \\rangle\\ dt.")]]

#text("We move the derivative inside and use symmetry to write this as")

#align(center)[#tao-fit-display[#mitex("\\int_a^b \\langle \\partial_s(\\gamma_t \\gamma^{-1}), \\gamma_t \\gamma^{-1} \\rangle\\ dt")]]

#text("or")

#align(center)[#tao-fit-display[#mitex("\\int_a^b \\langle \\partial_s(\\gamma_t \\gamma^{-1}), X \\rangle\\ dt")]]

#text("We expand")

#align(center)[#tao-fit-display[#mitex("\\partial_s(\\gamma_t \\gamma^{-1}) = \\gamma_{ts} \\gamma^{-1} - \\gamma_t \\gamma^{-1} \\gamma_s \\gamma^{-1}.")]]

#text("Similarly")

#align(center)[#tao-fit-display[#mitex("\\partial_t(\\gamma_s \\gamma^{-1}) = \\gamma_{ts} \\gamma^{-1} - \\gamma_s \\gamma^{-1} \\gamma_t \\gamma^{-1}")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\partial_s(\\gamma_t \\gamma^{-1}) = \\partial_t(\\gamma_s \\gamma^{-1}) + [\\gamma_s \\gamma^{-1}, X ].")]]

#text("Inserting this into the first variation and integrating by parts, we obtain")

#align(center)[#tao-fit-display[#mitex("\\int_a^b \\langle [\\gamma_s \\gamma^{-1}, X], X \\rangle - \\langle \\gamma_s \\gamma^{-1}, \\partial_t X \\rangle\\ dt;")]]

#text("using ")#link(<tao-3e744b9dc39389baf0c5>)[#text("(2)")]#text(", this is")

#align(center)[#tao-fit-display[#mitex("\\int_a^b \\langle \\gamma_s \\gamma^{-1}, B(X,X) \\rangle - \\langle \\gamma_s \\gamma^{-1}, \\partial_t X \\rangle\\ dt")]]

#text("and so the first variation vanishes for arbitrary choices of perturbation ")#mi("{\\gamma_s}")#text(" precisely when ")#mi("{\\partial_t X = B(X,X)}")#text(", as required. ")#mi("\\Box")

#text("It is instructive to verify that the Hamiltonian ")#mi("{H = \\frac{1}{2} \\langle X, X \\rangle}")#text(" is preserved by this equation, as it should be. In the case of rigid motions, ")#link(<tao-d7939186d51d823b7c9c>)[#text("(3)")]#text(" is essentially ")#link("http://en.wikipedia.org/wiki/Euler's_equations_(rigid_body_dynamics)")[#text("Euler’s equations of motion")]#text(".")

#text("The right-invariance of the Riemannian manifold implies that the geodesic flow is similarly right-invariant. And this is reflected by the fact that the Euler-Arnold equation ")#link(<tao-d7939186d51d823b7c9c>)[#text("(3)")]#text(" does not involve the position ")#mi("{\\gamma(t)}")#text(". This position of course evolves by the equation ")#metadata(none) <tao-c6fbdfb5cf38d9096c79>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\frac{d}{dt} \\gamma = X \\gamma")]]

#text("which is just the definition of ")#mi("{X}")#text(".")

#text("Note that while the velocity ")#mi("{X}")#text(" influences the evolution of the position ")#mi("{\\gamma}")#text(", the position ")#mi("{\\gamma}")#text(" does not influence the evolution of the velocity ")#mi("{X}")#text(". This is of course a manifestation of the right-invariance of the problem. This reduction of the flow is known as ")#emph[#text("Euler-Poincaré reduction")]#text(", and is essentially a basic example of both ")#emph[#text("Lagrangian reduction")]#text(" and ")#emph[#text("symplectic reduction")]#text(", in which the symmetries of a Lagrangian or Hamiltonian evolution are used to reduce the dimension of the dynamics while preserving the Lagrangian or Hamiltonian structure.")

#text("We can rephrase the Euler equation in a ")#link("http://en.wikipedia.org/wiki/Lax_pair")[#text("Lax pair")]#text(" formulation by introducing the ")#link("http://en.wikipedia.org/wiki/Cartan-Killing_form")[#text("Cartan-Killing form")]

#align(center)[#tao-fit-display[#mitex("(X, Y) := \\text{tr}( \\text{ad}(X) \\text{ad}(Y) ).")]]

#text("Like ")#mi("{\\langle, \\rangle}")#text(", the Cartan-Killing form ")#mi("{(,)}")#text(" is a symmetric bilinear form on the Lie algebra ")#mi("{{\\mathfrak g}}")#text(". If we assume that the group ")#mi("{G}")#text(" is ")#link("http://en.wikipedia.org/wiki/Semisimple_Lie_group")[#text("semisimple")]#text(" (and finite-dimensional), then this form will be non-degenerate. It obeys the identity ")#metadata(none) <tao-fd1478e5fc36bfcf9d0e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("([X,Y],Z) = -(Y,[X,Z]),")]]

#text("thus adjoints are automatically skew-adjoint in the Cartan-Killing form.")

#text("If the Cartan-Killing form is non-degenerate, it can be used to express the inner product ")#mi("{\\langle, \\rangle}")#text(" via a formula of the form ")#metadata(none) <tao-ca5941f91508c0d16fc4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\langle X, Y \\rangle := ( X, \\Lambda^{-1} Y )")]]

#text("where ")#mi("{\\Lambda: {\\mathfrak g} \\rightarrow {\\mathfrak g}}")#text(" is an invertible linear transformation which is self-adjoint with respect to both ")#mi("{\\langle,\\rangle}")#text(" and ")#mi("{(,)}")#text(". We then define the ")#emph[#text("intrinsic momentum")]#text(" ")#mi("{{\\bf M}(t)}")#text(" of the Euler-Arnold flow ")#mi("{\\gamma(t)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("{\\bf M}(t) := \\Lambda^{-1} X(t).")]]

#text("From ")#link(<tao-d7939186d51d823b7c9c>)[#text("(3)")]#text(", we see that ")#mi("{{\\bf M}}")#text(" evolves by the equation")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} {\\bf M} := \\Lambda^{-1} B( \\Lambda {\\bf M}, \\Lambda {\\bf M} ).")]]

#text("But observe from ")#link(<tao-ca5941f91508c0d16fc4>)[#text("(6)")]#text(", ")#link(<tao-3e744b9dc39389baf0c5>)[#text("(2)")]#text(", ")#link(<tao-ca5941f91508c0d16fc4>)[#text("(6)")]#text(", ")#link(<tao-fd1478e5fc36bfcf9d0e>)[#text("(5)")]#text(" that")

#tao-aligned(keep: true)[


#tao-math("( \\Lambda^{-1} B( \\Lambda {\\bf M}, \\Lambda {\\bf M} ), Y )  & = \\langle B( \\Lambda {\\bf M}, \\Lambda {\\bf M} ), Y \\rangle", block: true)



#tao-math(" & = \\langle [Y, \\Lambda {\\bf M}], \\Lambda {\\bf M} \\rangle", block: true)



#tao-math(" & = ([Y,\\Lambda {\\bf M}], {\\bf M} )", block: true)



#tao-math(" & = ([\\Lambda {\\bf M},{\\bf M}],Y)", block: true)
]

#text("for any test vector ")#mi("{Y \\in {\\mathfrak g}}")#text(", which by nondegeneracy implies that")

#align(center)[#tao-fit-display[#mitex("\\Lambda^{-1} B( \\Lambda {\\bf M}, \\Lambda {\\bf M} ) = [\\Lambda {\\bf M},{\\bf M}]")]]

#text("leading to the Lax pair form")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} {\\bf M} = [\\Lambda {\\bf M},{\\bf M}]")]]

#text("of the Euler-Arnold equation, known as the ")#emph[#text("Lie-Poisson equation")]#text(". (The sign conventions here are the opposite of those in Arnold’s paper, I think ultimately because I am assuming right-invariance instead of left-invariance.) In particular, the spectrum of ")#mi("{{\\bf M}}")#text(" is invariant, or equivalently ")#mi("{{\\bf M}}")#text(" evolves along a single ")#emph[#text("coadjoint orbit")]#text(" in ")#mi("{{\\mathfrak g} \\equiv {\\mathfrak g}^*}")#text(".")

#text("By ")#link("http://en.wikipedia.org/wiki/Noether's_theorem")[#text("Noether’s theorem")]#text(", the right-invariance of the geodesic flow should create a conserved quantity (or ")#link("http://en.wikipedia.org/wiki/Moment_map")[#text("moment map")]#text("); as the right-invariance is an action of the group ")#mi("{G}")#text(", the conserved quantity should take place in the adjoint ")#mi("{{\\mathfrak g}^*}")#text(". If we write ")#mi("{\\gamma(t) = g(t) O}")#text(" for some fixed observer ")#mi("{O}")#text(", then this conserved quantity can be computed as the ")#emph[#text("extrinsic momentum")]#text(" ")#metadata(none) <tao-304b4a90a76a1cbe4c11>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("P: Y \\mapsto \\langle X, g Y g^{-1} \\rangle,")]]

#text("thus ")#mi("{\\omega}")#text(" is the ")#mi("{1}")#text("-form associated to ")#mi("{X}")#text(", pulled back to extrinsic coordinates. Indeed, from ")#link(<tao-c6fbdfb5cf38d9096c79>)[#text("(4)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\partial_t g = X g")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\partial_t g^{-1} = - g^{-1} X")]]

#text("and hence for any test vector ")#mi("{Y}")

#tao-aligned(keep: true)[


#tao-math("\\partial_t P(Y)  & = \\langle X_t, g Y g^{-1} \\rangle + \\langle X, [X, gYg^{-1}] \\rangle", block: true)



#tao-math(" & = \\langle B(X,X), g Y g^{-1}\\rangle - \\langle B(X,X), g Y g^{-1}\\rangle", block: true)



#tao-math(" & = 0", block: true)
]

#text("thanks to ")#link(<tao-3e744b9dc39389baf0c5>)[#text("(2)")]#text(", and the claim follows. Using the Cartan-Killing form, the extrinsic momentum can also be identified with ")#mi("{g^{-1} {\\bf M} g}")#text(", thus linking the extrinsic and intrinsic momenta to each other.")

#heading(level: 1)[#strong[#text(" — 2. Incompressible fluids — ")]]

#text("Now consider an incompressible fluid in ")#mi("{{\\bf R}^3}")#text(", whose initial state is ")#mi("{O}")#text(" and whose state at any time ")#mi("{t}")#text(" is given as ")#mi("{\\gamma(t)}")#text(". One can express ")#mi("{\\gamma(t) = g(t) O}")#text(", where ")#mi("{g(t) \\in \\text{Sdiff}({\\bf R}^3)}")#text(" is the diffeomorphism from ")#mi("{{\\bf R}^3}")#text(" to itself that maps the location of each particle at ")#mi("{O}")#text(" to the location of the same particle at ")#mi("{\\gamma(t)}")#text(". As the fluid is assumed incompressible, the diffeomorphism must be measure-preserving (and orientation preserving); we denote the group of such special diffeomorphisms as ")#mi("{\\text{Sdiff}({\\bf R}^3)}")#text(".")

#text("The Lie algebra to the group ")#mi("{\\text{Diff}({\\bf R}^3)}")#text(" of all diffeomorphisms, is the space of all (smooth) vector fields ")#mi("{X: {\\bf R}^3 \\rightarrow {\\bf R}^3}")#text(". The Lie algebra of the subgroup ")#mi("{\\text{Sdiff}({\\bf R}^3)}")#text(" of measure-preserving diffeomorphisms is the space of all ")#emph[#text("divergence-free")]#text(" vector fields; indeed, this is one of the primary motivations of introducing the concept of ")#link("http://en.wikipedia.org/wiki/Divergence")[#text("divergence")]#text(" of a vector field. We give both Lie algebras the usual ")#mi("{L^2}")#text(" inner product:")

#align(center)[#tao-fit-display[#mitex("\\langle u, v\\rangle := \\int_{{\\bf R}^3} u \\cdot v.")]]

#text("The Lie bracket on ")#mi("{\\text{Sdiff}({\\bf R}^3)}")#text(" or ")#mi("{\\text{Diff}({\\bf R}^3)}")#text(" is the same as the usual Lie bracket of vector fields.")

#text("Let ")#mi("{u(t) := \\gamma^{\\prime}(t)/\\gamma(t) = g^{\\prime} \\circ g^{-1}}")#text(" be the intrinsic velocity vector; then this is a divergence-free vector field, which physically represents the velocity field in Eulerian coordinates. The extrinsic velocity vector ")#mi("{g(t)^{-1} u(t) g(t) = u \\circ g(t)}")#text(" is then the velocity field in Lagrangian coordinates; it is also divergence-free.")

#text("If there were no constraint of incompressibility (i.e. if one were working in ")#mi("{\\text{Diff}({\\bf R}^3)}")#text(" rather than ")#mi("{\\text{Sdiff}({\\bf R}^3)}")#text("), then the metric is flat, and the geodesic equation of motion is simply given by Newton’s first law")

#align(center)[#tao-fit-display[#mitex("\\frac{d^2}{dt^2} g(t) = 0")]]

#text("or in terms of the intrinsic velocity field ")#mi("{u}")#text(",")

#align(center)[#tao-fit-display[#mitex("\\partial_t u(t) + (u \\cdot \\nabla) u = 0.")]]

#text("Once we restrict to incompressible fluids, this becomes")

#align(center)[#tao-fit-display[#mitex("\\frac{d^2}{dt^2} g(t) \\perp T_{g(t)} \\text{Sdiff}({\\bf R}^3)")]]

#text("or, in terms of the intrinsic velocity field,")

#align(center)[#tao-fit-display[#mitex("\\partial_t u(t) + (u \\cdot \\nabla) u \\perp \\text{ divergence free fields}")]]

#text("or equivalently (by Hodge theory)")

#align(center)[#tao-fit-display[#mitex("\\partial_t u(t) + (u \\cdot \\nabla) u = \\nabla p")]]

#text("for some ")#mi("{p}")#text("; this is precisely the ")#link("http://en.wikipedia.org/wiki/Euler_equations_(fluid_dynamics)")[#text("Euler equations of incompressible fluids")]#text(". This equation can also be deduced from ")#link(<tao-d7939186d51d823b7c9c>)[#text("(3)")]#text(", after first calculating using ")#link(<tao-3e744b9dc39389baf0c5>)[#text("(2)")]#text(" and the formula for Lie bracket of vector fields that ")#mi("{B(X,Y)}")#text(" is the divergence-free component of ")#mi("{X \\neg dY}")#text("; we omit the details (which are in Arnold’s paper).")

#text("Let us now compute the extrinsic momentum ")#mi("{P}")#text(", which is conserved by the Euler equations. Given any divergence-free vector field ")#mi("{v}")#text(" (in Lagrangian coordinates), we see from ")#link(<tao-304b4a90a76a1cbe4c11>)[#text("(7)")]#text(" that ")#mi("{P}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("P(v) := \\int_{{\\bf R}^3} u \\cdot (g_* v),")]]

#text("thus the form ")#mi("{P(v)}")#text(" is computed by pushing ")#mi("{v}")#text(" over to Eulerian coordinates to get ")#mi("{g_* v := (Dg \\circ g^{-1}) (v \\circ g^{-1})}")#text(" and then taking the inner product with ")#mi("{u}")#text(". Let us check that this is indeed conserved. Since")

#align(center)[#tao-fit-display[#mitex("u_t = - (u \\cdot \\nabla) u + \\nabla p")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\partial_t (g_* v) = - {\\mathcal L}_u (g_* v),")]]

#text("where ")#mi("{{\\mathcal L}}")#text(" denotes the Lie derivative along the vector field ")#mi("{u}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\partial_t P(v) = \\int_{{\\bf R}^3} (- (u \\cdot \\nabla) u + \\nabla p) \\cdot w - u \\cdot {\\mathcal L}_u w,")]]

#text("where ")#mi("{w := g_* v}")#text(" is ")#mi("{v}")#text(" in Eulerian coordinates. The ")#mi("{\\nabla p}")#text(" term vanishes by integration by parts, since ")#mi("{v}")#text(" (and hence ")#mi("{w}")#text(") is divergence-free. The Lie derivative is computed by the formula")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L}_u w = (u \\cdot \\nabla) w - (w \\cdot \\nabla) u.")]]

#text("As ")#tao-math("{u \\cdot (w \\cdot \\nabla) u = \\frac{1}{2} (w \\cdot \\nabla) \\left|u\\right|^2}", block: false)#text(" is a total derivative (recall here that ")#mi("{w}")#text(" is divergence-free), this term vanishes. The other two terms combine to form a total derivative ")#mi("{-(u \\cdot \\nabla)(u \\cdot w)}")#text(", which also vanishes, and so the claim follows.")

#text("The external momentum is closely related to the ")#link("http://en.wikipedia.org/wiki/Vorticity")[#text("vorticity")]#text(" ")#mi("{\\omega := \\text{curl} u}")#text(". This is because a divergence-free vector field ")#mi("{v}")#text(" can (in principle, at least) be written as the divergence ")#mi("{v = \\text{div} \\alpha}")#text(" of a ")#mi("{2}")#text("-vector field ")#mi("{\\alpha}")#text(". As divergence is diffeomorphism invariant, it commutes with pushforward:")

#align(center)[#tao-fit-display[#mitex("g_*( \\text{div} \\alpha ) = \\text{div} (g_* \\alpha)")]]

#text("and thus")

#tao-aligned(keep: true)[


#tao-math("P(\\text{div} \\alpha)  & = \\int_{{\\bf R}^3} u \\cdot \\text{div}( g_* \\alpha )", block: true)



#tao-math(" & = \\int_{{\\bf R}^3} \\omega \\cdot g_* \\alpha", block: true)



#tao-math(" & = \\int_{{\\bf R}^3} (*\\omega) \\wedge g_* \\alpha", block: true)
]

#text("where ")#mi("{*}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Hodge_star")[#text("Hodge star")]#text(". We can pull this back to Lagrangian coordinates to obtain")

#align(center)[#tao-fit-display[#mitex("P(\\text{div} \\alpha) = \\int_{{\\bf R}^3} g^{-1}_*(*\\omega) \\wedge \\alpha.")]]

#text("As ")#mi("{\\alpha}")#text(" was an arbitrary ")#mi("{2}")#text("-form, we thus see that the pullback ")#mi("{g^{-1}_*(*\\omega)}")#text(" of the Hodge star of the vorticity in Lagrangian coordinates is preserved by the flow, or equivalently that ")#mi("{*\\omega}")#text(" is transported by the velocity field ")#mi("{u}")#text(". In the two-dimensional case, this is well known (")#mi("{*\\omega}")#text(" is a scalar in this case); in higher dimensions, this is fact is implicit in the ")#link("http://en.wikipedia.org/wiki/Vorticity_equation")[#text("vorticity equation")]

#align(center)[#tao-fit-display[#mitex("\\partial_t \\omega_{ij} + u_k \\partial_k \\omega_{ij} + \\omega_{ik} \\partial_k u_j = 0")]]

#text("which can be rewritten as")

#align(center)[#tao-fit-display[#mitex("\\partial_t(*\\omega) + {\\mathcal L}_u (*\\omega) = 0.")]]

#text("In principle, the Euler-Arnold formalism allows one to write the Euler equations for incompressible fluids into a Lax pair form. To properly carry this out by the machinery above, though, would require calculating the Cartan-Killing form for the infinite-dimensional Lie group ")#mi("{\\text{Sdiff}({\\bf R}^3)}")#text(", which looked quite tricky to me, and I was not able to complete the calculation. However, a Lax pair formulation for this system was found ")#link("http://www.ams.org/mathscinet-getitem?mr=1069495")[#text("by Friedlander and Vishik")]#text(", and it is likely that that formulation is essentially equivalent to the Lax pair that one could construct from the Euler-Arnold formalism. In the simpler two-dimensional case, it was observed ")#link("http://www.ams.org/mathscinet-getitem?mr=1845205")[#text("by Li")]#text(" that the vorticity equation can also be recast into a slightly different Lax pair form. While this formalism does allow for some of the inverse scattering machinery to be brought to bear on the initial value problem for the Euler equations, it does not as yet seem that this machinery can be successfully used for the global regularity problem.")

#text("It would, of course, also be very interesting to see what aspects of this formalism carry over to the Navier-Stokes equation. The first naive guess would be to add a friction term, but this seems to basically correspond to adding a damping factor of ")#mi("{-cu}")#text(" (rather than a viscosity factor of ")#mi("{\\nu \\Delta u}")#text(") to the Euler equations and ends up being rather uninteresting (it basically slows down the time variable but otherwise does not affect the dynamics). More generally, it would be of interest to see how the Hamiltonian formalism can be generalised to incorporate dissipation or viscosity.")

#text("{\\emph Update}, June 15: Some references added. Thanks to Jerry Marsden for comments.")

#heading(level: 1)[#text("Comments (32)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d673d9b3e9ff664b048a243397f1756f4cfaee98f073b4186a1396d6da741ac-38cab0c5d213f9c1aa1f47d8a8c3a19490ed36bd7997a03dda17e6c9535e88b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Carron")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-45385")[#strong[#text("Igor Carron")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2010")])]

#text("Terry,")

#text("Typo in LaTeX ?")

#text("“..we let [Formula does not parse] be the tangent vector at A defined infinitesimally…”")

#text("Igor.")

#emph[#text("[This seemed to be a transient problem with WordPress’s LaTeX image rendering server; it disappeared by the time I got around to looking at it. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b80ed17b0a9ca583b1105e476b6af80dd8f244fcc9a23ade804810bf73d37f0b-01a28f9cc6b908126320c63a0dcd0e26b95be19c987a15b8c7f6a7991f3abce6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Corfield")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-45387")[#strong[#text("David Corfield")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2010")])]

#text("Extra ‘to’ in “…a system subject to only to a physical constraint…”.")

#text("Section 3 of ")#link("http://www.srcf.ucam.org/~jde27/fluids.pdf")[#text("Hydrodynamics and Infinite-Dimensional Riemannian Geometry")]#text(" gives some insight as to the KdV equation as geodesic flow, but not so straightforwardly as the free motion of a system subject only to a physical constraint.")

#emph[#text("[Corrected, and thanks for the link! – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-45393")[#strong[#text("Christian")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2010")])]

#text("There is some interesting recent work by Holm on co-workers on dissipative systems which are still co-adjoint, see for example ")#link("http://rspa.royalsocietypublishing.org/content/early/2010/04/21/rspa.2010.0043.abstract")[#text("http://rspa.royalsocietypublishing.org/content/early/2010/04/21/rspa.2010.0043.abstract")]#text(". They consider kinetic theory, and hence $Diff_{can}$, but the approach using double Poisson brackets is also applicable to fluid systems, see the earlier article by Bloch et al; ")#link("http://infoscience.epfl.ch/record/129486")[#text("http://infoscience.epfl.ch/record/129486")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of HB")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-45398")[#strong[#text("HB")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2010")])]

#text("Minor typo (second equation):")#linebreak()#text(" “… the length is then given in terms of the inner product by the formula”")#linebreak()#text(" |v|^2:=")#linebreak()#text(" ^2 is missing.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-45400")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2010")])]

#text("Thank you for this fine post, and especially for its tribute to Vladimir Arnold. I am hoping that someday you may write a post that discusses the extension of these geometric/dynamical ideas to the quantum domain, where many of them carry-over without change … and some of them become simpler. Arnold discusses these quantum extensions in (too brief!) Appendix 3 of his ")#emph[#text("Mathematical Methods of Classical Mechanics")]#text(", but nowadays we appreciate that there is much more to be said.")

#text("Nowadays, in quantum systems engineering, the natural pullback is not from (say) classical Cartesian space onto the manifold of rigid body rotations and translations, but from Hilbert space onto the manifold of tensor network states. Just as dissipation and viscosity play central roles in classical systems, Lindbladian dynamics plays a key role in quantum dynamics. And in all of the preceding, the natural pullback of dynamics onto reduced-dimension manifolds is central to achieving a satisfactory mathematical, physical, and engineering understanding.")

#text("One challenge that the mathematical, physical science, and engineering communities are all facing is that (typically) our students do not acquire (as undergraduates at least) a mathematically natural toolset for appreciating these ubiquitous “Arnoldian” ideas.")

#text("Learning these ideas at the graduate level is not particularly satisfactory either, in that specialization sets-in to a degree that inhibits graduate students in math, physics, chemistry, biology, mechatronics, materials science (etc.) from appreciating that they are all embracing the same “Arnoldian” ideas, but speaking very different languages. Too often, moreover, these languages are not mathematically natural in the sense that Arnold so scrupulously respect.")

#text("It is easy to write a long wish-list of “Arnoldian” topics that mathematicians might beneficially explain in ways that are accessible to engineers and scientists. To name two, I wish someone would explain Ran Raz’ STOC2010 presentation ")#emph[#text("Tensor-Rank and Lower Bounds for Arithmetic Formulas")]#text(", which appears to lie at the boundary of complexity theory, algebraic geometry, and quantum simulation theory … but I have to confess to being (so far) unable to decode Raz’ article itself. And I wish someone would tackle the “Arnoldian” analysis of Lindblad processes. The standard textbooks analyze these processes using vector-space proof technology, but we engineers ")#emph[#text("use")]#text(" these processes in an “Arnoldian” pullback context (for which much of the vector-space toolset is inapplicable); this leaves us engineers with sadly little geometric and/or informatic insight into our own simulation codes.")

#text("That being said, I am *very* grateful for the existence of this fine weblog—and for many other outstanding math weblogs too—which so greatly encourage us engineers and scientists, by allowing us to glimpse the many wonderful “Arnoldian” opportunities, both creative and practical, that are open to us all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/297ba35fceba57126d9613193c7cd9b835407adfe13d536390a27ced310e32e2-a380eea33e7db527042e9dcd6848d8e1ec0adf2e9b8d886dab8b90081140dfe3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-45403")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2010")])]

#text("It looks like there’s a typo in the definition of the Christoffel symbol – the first two terms in the parenthesis are the same.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-45405")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2010")])]

#text("A connection I’m very fond of is between quantum computing and minimal geodesic paths on right-invariant manifolds. It can be shown that the minimal quantum circuit size for solving a particular problem is equal (modulo polynomial factors and some technical caveats) to the minimal geodesic length between two points on a particular right-invariant manifold.")

#text("This seems to me a potentially very useful observation for understanding minimal circuit sizes. Pretty much everything we teach students about minimizing functions relies on working in a smooth space, where the tools of calculus can be used. Unfortunately, the way we ordinarily think about circuits (quantum and non-quantum) that way of thinking can’t be applied to understand minimal circuit size. But by relating circuit size to geometry it becomes possible to use the tools of calculus to think about minimal circuit complexity. Roughly, there’s a correspondence optimal quantum circuit to solve a particular problem and some solution of the Euler-Arnold equation. This seems like a potentially powerful observation, although I was never able to get bounds on circuit size this way. I wrote up some of these ideas in ")#link("http://arxiv.org/abs/quant-ph/0701004")[#text("http://arxiv.org/abs/quant-ph/0701004")]#text(" (joint with Mark Dowling), if anyone’s interested.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9074ff19ebb3d02de7b4be34bc7cfad6a1f74713ac02cbe35c2f0e77d8ca4bd9-01aa355ffd75878977a0ce62cefd7ed1b0660a38d9199a228259951fce50ff43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chirag Lakhani")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-45654")[#strong[#text("Chirag Lakhani")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2010")])]

#text("Dear Michael,")

#text("I know I have come to this post late, but I was wondering if you think there is any advantage if formulating your ideas in terms of this symplectic geometry setting rather than Riemannian geometry. Do things like Euler-Poison reduction work out when it comes to the metric you use for SU(2^n)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-45656")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2010")])]

#text("I didn’t consider this at all – it certainly seems an interesting question. My background in symplectic geometry is minimal.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/175532ecc8833230f93efa13a3bab4280bed7637409fde712b96e19b8e67e20f-08d5278cf17f685e3dec7dee0d49b29e21978d990e1685597c7d092470b16bc4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anosh Joseph")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-45417")[#strong[#text("Anosh Joseph")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2010")])]

#text("Great post, Terry. Here is a recent review on this in a recent arXiv paper :")#linebreak()#text(" ")#link("http://arxiv.org/abs/0906.0184")[#text("http://arxiv.org/abs/0906.0184")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-45422")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2010")])]

#text("Anosh, thank you for that arXiv reference … which was new to me and fun. Perhaps you might similarly enjoy astronaut Michael Foale’s keynote address “")#link("http://www.mathematica-journal.com/issue/v7i3/special/transcript/html/")[#text("Navigating on Mir")]#text("” (which was published in ")#emph[#text("Mathematica Journal")]#text(") in which the negative sectional curvature of rigid-body state-space generates high adventure in low Earth orbit.")

#text("The fraction of the Earth’s global computing power that is devoted to numerically integrating rigid-body rotational dynamics is surprising large … plausibly as large as 10^(-4)—10(^-3) … for the reason that tumbling water molecules are ubiquitously present in molecular dynamical simulations.")

#text("Moreover, for reasons of numerical efficiency, water-molecule dynamical trajectories typically are integrated on quaternionic state-spaces; thus yet another of this blog’s perennial mathematical themes appears naturally … gauge invariance!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-45527")[#strong[#text("Vladimir Arnold (1937-2010). R.I.P. « Successful Researcher")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2010")]

#text("[…] Vladimir Arnold (1937-2010). R.I.P. One of the world’s greatest and most influential mathematicians, Vladimir Arnold, passed away today in Paris, France. He made major contributions, inter alia, to the fields of dynamical systems (the famous KAM (Kolmogorov-Arnold-Moser) theory) and topology (he is one of the founding fathers of symplectic topology). I hope that the prominent mathematicians like Terence Tao or Timothy Gowers will say more on their blogs about Arnold’s scientific legacy as they did for Israel Gelfand (update: Terence Tao has a recent post on the Euler–Arnold equation). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0256afbde4a3aae59801169ea10c1af52396c390811f26b65693dda171c0e8d9-8a69847d5b00855ac15c355b2eb2bd1d9982735da31979347fc69efdcd5fcccf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Artem")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-45530")[#strong[#text("Artem")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2010")])]

#text("When in the beginning you give geodesic flow in coordinates by Hamilton’s equations you say: «In terms of the velocity…» and write the formula with g that is typeseted not in Roman font — possible typo.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a2bc2db2645f89bf0491e9a2969b99fe11f155238a15c8024a7b442a86f20adb-56bfcc2235d0812c76607eaa3940899eda18b63bdecfacb7612b144fdff2dd81.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Geisler")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-47336")[#strong[#text("Daniel Geisler")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2010")])]

#text("For years I’ve come across meager references that there was another mathematical formalism besides PDE’s that was appropriate for modeling physics, that of continuously iterated functions. But Aldrovandi and Freitas’ article ")#link("http://arxiv.org/abs/physics/9712026")[#text("Continuous iteration of dynamical maps")]#text(" is the only relevant work I’ve been able to find. Could you please tell me if Arnold’s 1966 paper is the source or is relevant to using continuously iterated functions to model physics?")

#text("Dynamics")#linebreak()#text(" In 1986 I had a couple of conversations with Stephen Wolfram regarding dynamical systems. Wolfram was interested in my work in defining ")#link("http://www.tetration.org")[#text("tetration")]#text(" for complex numbers. Tetration is iterated exponentiation and the standard notation is ")#mi("^1 a=a, ^2 a=a^a, ^3a=a^{a^a}")#text(", and so on. Wolfram pointed out that the problem of extending tetration to the complex numbers was actually part of the much larger and more important problem of unifying the discreet representation of chaotic systems in mathematics with the continuous representation of chaotic systems in physics, of unifying maps from iterated functions and flows from PDEs. He maintained that the duality prevented the derivation of mathematical solutions for continuous chaotic systems as are found in physics. My understanding of Wolfram’s position is that he was interested in the possibility that there might be a principle at play even deeper than his Principle of Equivalence and that it might be possible to formulate a single mathematical approach to dynamics encompassing iterated functions, cellular automata, PDEs, and recurrence equations. Wolfram suggested at if tetration could be defined for complex numbers then those results might be generalized to unify discrete maps and continuous flows.")#linebreak()#text(" Bell Polynomials")#linebreak()#text(" Let ")#mi("f(x)")#text(" and ")#mi("g(x)")#text(" be differentiable functions, then the ")#link("http://en.wikipedia.org/wiki/Bell_polynomials")[#text("Bell polynomials")]#text(" can be constructed using ")#link("http://en.wikipedia.org/wiki/Fa%C3%A0_di_Bruno%27s_formula")[#text("Faa Di Bruno’s formula")]#text(".")

#mi("D^nf(g(x))=\\sum_{\\pi(n)} \\frac{n!}{k_1! \\cdots k_n!} (D^kf)(g(x)) \\left(\\frac{Dg(x)}{1!}\\right)^{k_1} \\cdots \\left(\\frac{D^ng(x)}{n!}\\right)^{k_n}")

#text("A partition of ")#mi("n")#text(" is ")#mi("\\pi(n)")#text(", usually denoted by ")#mi("1^{k_1}2^{k_2}\\cdots n^{k_n}")#text(" with ")#mi("k_1+2k_2+ \\cdots nk_n=k")#text("; where ")#mi("k_i")#text(" is the number of parts of size ")#mi("i")#text(". The partition function ")#mi("p(n)")#text(" is a decategorized version of ")#mi("\\pi(n)")#text(", the function ")#mi("\\pi(n)")#text(" enumerates the integer partitions of ")#mi("n")#text(", while ")#mi("p(n)")#text(" is the cardinality of the enumeration of ")#mi("\\pi(n)")#text(".")

#text("Setting ")#mi("g(x) = f^{t-1}(x)")#text(" results in")

#mi("D^n f^t(x)=\\sum_{\\pi(n)} \\frac{n!}{k_1! \\cdots k_n!} (D^k f)(f^{t-1}(x)) \\left(\\frac{Df^{t-1}(x)}{1!}\\right)^{k_1} \\cdots \\left(\\frac{D^n f^{t-1}(x)}{n!}\\right)^{k_n}")

#text("The Taylors series of ")#mi("f^t(x)")#text(" is derived by evaluating the derivatives of the iterated function at a fixed point ")#mi("f^t(0)")#text(" by setting ")#mi("x=0")#text(" and separating out the ")#mi("k_n")#text(" term of the summation that is dependent on ")#mi("D^n f^{t-1}(0)")#text(".")

#mi("D^n f^t(0)=\\sum \\frac{n!(D^k f)(0)}{k_1! \\cdots k_{n-1}!} \\left(\\frac{Df^{t-1}(0)}{1!}\\right)^{k_1} \\cdots \\left(\\frac{D^n f^{t-1}(0)}{(n-1)!}\\right)^{k_{n-1}} + (D f)(0) D^n f^{t-1}(0)")

#text("and rewriting ")#mi("(D^k f)(0)")#text(" as ")#mi("f_k")#text(" where ")#mi("f_1")#text(" is the Lyapunov multiplier.")

#mi("D^n f^t(0)=\\sum \\frac{n! f_k}{k_1! \\cdots k_{n-1}!} \\left(\\frac{Df^{t-1}(0)}{1!}\\right)^{k_1} \\cdots\\left(\\frac{D^{n-1} f^{t-1}(0)}{(n-1)!}\\right)^{k_{n-1}} + f_1 D^n f^{t-1}(0)")

#text("The remaining ")#mi("p(n)-1")#text(" terms of the summation are only dependent on ")#mi("D^k f^{t-1}(0)")#text(", where ")#mi("0<k<n")#text(".")

#text("Flows")

#text("Putting the pieces together gives the Taylors series for a dynamical system. Still assuming a fixed point at ")#mi("x=0")#text(" such that ")#mi("f(0)=0")#text(" results in,")

#mi("f^t(x)=f_1^t x+\\frac{1}{2!}(f_2 \\sum_{k_1=0}^{t-1}f_1^{2 t-k_1-2})x^2+\\frac{1}{3!}(f_3 \\sum_{k_1=0}^{t-1}f_1^{3 t-2 k_1-3}+3 f_2^2 \\sum_{k_1=0}^{t-1}\\sum_{k_2=0}^{t-k_1-2}f_1^{3 t-2k_1-k_2-5})x^3 + \\cdots")

#text("As a check, a great deal is known about dynamical systems, so if there is a fundamental flaw in the derivation of Taylors series for ")#mi("f^t(x)")#text(", then it should appear as it is scrutinized in light of the theorems of dynamics. Note the presence of nested summations of ")#mi("f_1")#text(", the Lyapunov multiplier. They occur in the quadratic and all higher terms as the only time dependent components. This demonstrates the dominance of the Lyapunov multiplier in the global dynamics of ")#mi("f^t(x)")#text(", an important theorem in dynamics.")

#text("Consider that the nested summations are unevaluated. Simplifying the sums of geometric progressions depends on whether the multiplier is a root of unity and then which root. For the iteration of complex functions, ")#mi("f: \\mathbb{C} \\rightarrow \\mathbb{C}")#text(", the classification of types of solutions for simplifying the sums of geometric progressions is consistent with the classification of fixed points, issues of topological conjugacy and the use of Schroeder’s and Abel’s functional equations.")

#text("A final reason for studying the nested summations in unevaluated form is it leaves the underlying combinatorial structure of ")#mi("f^t(x)")#text(" exposed. My unpublished paper ")#link("http://tetration.org/BPIF.pdf")[#text("Bell Polynomials of Iterated Functions")]#text(" covers much of the proceeding material in greater detail as well as exploring the combinatorial structure of ")#mi("f^t(x)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-47669")[#strong[#text("Tetration Blog · The Euler-Arnold equation")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2010")]

#text("[…] The following was posted as a question to Terry Tao’s posting on The Euler-Arnold equation. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-49224")[#strong[#text("The Euler-Arnold Equation « Sergeysk's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2010")]

#text("[…] nice post by wonderful Terry Tao about the Arnold formalism. Sums it up in a concise way, where everything in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-142582")[#strong[#text("Fluid Flows and Infinite-Dimensional Manifolds (Part 2) « Azimuth")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2012")]

#text("[…] ours, but—as could be expected—assuming a little bit more of a mathematical background: The Euler-Arnold equation. If you are into math, you might like to take a look at […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Conserved quantities for the Euler equations | What's new")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-272839")[#strong[#text("Conserved quantities for the Euler equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2014")])]

#text("[…] fact was also interpreted as conservation of exterior momentum in this previous blog post.) This fact also follows from Kelvin’s circulation theorem, after first applying […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Noether’s theorem, and the conservation laws for the Euler equations | What's new")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-273680")[#strong[#text("Noether’s theorem, and the conservation laws for the Euler equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2014")])]

#text("[…] discussed in this previous post, both the Euler equations for rigid body motion, and the Euler equations for incompressible […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a89b2c708861d5ae7ca234d1967aced1a4a9e7a310e7adf194c7c1e62bdf67a0-8b950fdc9219cc8bc9bd1ce70250c96dcbbb52c6b319eb1e63f31c33fb8a510a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrei Ludu")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-298223")[#strong[#text("Andrei Ludu")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2014")])]

#text("All these are beautiful and a great exercise. However, nature is very far away from these crystal clean mathematical approaches. Euler equation is a very limited situation which rather doesn’t happen in reality. Moreover, there are showers of articles on geometrical aspects of fluids in n-dimensions (R^n manifolds) using concepts like centrifugal force and surface tension. I wonder what is a centrifugal force in more than 3 dimensions? What is the meaning of law of inertia in more than 3 (3+1) dimensions.? There is not knowledge of such a thing. I don’t know of Newton’s laws in more than 3+1 dimensions. But nevertheless, all these are splendid exercises helping the understanding of some phenomena in 3 dimensions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/85e2defcb0328211df24d69ae6e3bcb095feeb6aa2aef380f10e296273c281f1-7b48051525fde7ee5a448ee6f2de195729c3332d2af3506691222310f647b818.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Honeybul")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-407635")[#strong[#text("Robert Honeybul")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2014")])]

#text("Excellent post. Just wondering, should the map Gamma map to the dual of the lie algebra? I’m assuming in this case that Gamma represents The inertia operator")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/721fdda1a92b24271943a1786cf6eee99606d2730a11693e2d6f4c206ee2472d-d5ba4c2db9af6d84851025b16c20da1ef342345c96d4c98fbc77c08c57d72498.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kosta")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-452641")[#strong[#text("kosta")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2015")])]

#text("Interesting post!")#linebreak()#text(" I think there is a typo here:")

#text("* (Intrinsic identification) If V \\in T_M A")#linebreak()#text(" I think should be")#linebreak()#text(" * (Intrinsic identification) If V \\in T_A M")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Finite time blowup for Lagrangian modifications of the three-dimensional Euler equation | What's new")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-470147")[#strong[#text("Finite time blowup for Lagrangian modifications of the three-dimensional Euler equation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2016")])]

#text("[…] an infinite dimensional Riemannian manifold of volume preserving diffeomorphisms (as discussed in this previous post) extends to the generalised Euler equations (with the operator determining the new Riemannian […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-481253")[#strong[#text("Geodesics of left invariant metrics on matrix Lie groups – Part 2 Conservation laws | Open System - Ark's blog")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2017")]

#text("[…] his blog post “The Euler-Arnold equation” Terrence Tao mentions that some people call this equation the “Euler-Arnold” equation, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On the universality of the incompressible Euler equation on compact manifolds | What's new")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-484242")[#strong[#text("On the universality of the incompressible Euler equation on compact manifolds | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2017")])]

#text("[…] flow equation on the infinite-dimensional manifold of volume-preserving diffeomorphisms on (see this previous post for a discussion of this in the flat space […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Embedding the Boussinesq equations in the incompressible Euler equations on a manifold | What's new")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-489903")[#strong[#text("Embedding the Boussinesq equations in the incompressible Euler equations on a manifold | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2017")])]

#text("[…] flow equation on the infinite-dimensional manifold of volume-preserving diffeomorphisms on (see this previous post for a discussion of this in the flat space […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-503080")[#strong[#text("CLASSICAL LAGRANGIAN MECHANICS | zulfahmed")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2018")]

#text("[…] the localized waves. By classical trajectory we will mean the precise definition given above. Terry Tao’s discussion here veers toward the generalization of the Euler-Lagrange equations toward homogeneous descriptions for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/608fa4d9046b62b11facd3c0d1b044cd6d283b08d7d211465c652f4711538435-e32054dcc6fb18203ccda7f18d11ab0344805f0f4e7da9d1000b1efe647e108e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pablo Basteiro")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-603749")[#strong[#text("Pablo Basteiro")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2020")])]

#text("Hi! Thank you very much for this amazing article! I am a little bit late to the party, but I would have a question on the defining equation for the bilinear form B in the Lie algebra. I have encountered many different definitions for this, even in Arnold’s paper and his book on topological methods in hydrodynamics the definition is slightly different. We do not assume this form to be symmetric, but we do assume symmetry of the inner product, correct?")

#text("Can we then write =")#strong[#text(" equivalently to =? This simplifies the explicit computation of the B form when using a non-trivial inner-product. ")]

#text("Thanks to anyone that can help me with this little detail!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/608fa4d9046b62b11facd3c0d1b044cd6d283b08d7d211465c652f4711538435-e32054dcc6fb18203ccda7f18d11ab0344805f0f4e7da9d1000b1efe647e108e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pablo Basteiro")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-603758")[#strong[#text("Pablo Basteiro")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2020")])]

#mi("([X,Y],Z)_{inner}=(B(Y,Z),X)_{inner}")#text(" equivalently to ")#mi("(Z,[X,Y])_{inner}=(X,B(Y,Z)_{inner}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-643625")[#strong[#text("Variational form of Euler’s incompressible fluid equations? – GrindSkills")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2022")]

#text("[…] Tao, The Euler-Arnold equation, blogpost […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-684733")[#strong[#text("Vladimir Arnold – featurefreaks")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2024")]

#text("[…] The Euler-Arnold equation […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/#comment-688297")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2025")])]

#text("Great post! Today Arnold would have turned 88. He is still influencing many students with his writings.")
]
