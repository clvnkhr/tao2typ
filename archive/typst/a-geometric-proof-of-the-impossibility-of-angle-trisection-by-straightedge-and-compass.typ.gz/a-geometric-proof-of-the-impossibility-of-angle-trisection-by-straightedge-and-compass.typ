// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/
// Converted to Typst by tao2typ: "2026-10-14T16:36:36.576452+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A geometric proof of the impossibility of angle trisection by straightedge and compass", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A geometric proof of the impossibility of angle trisection by straightedge and compass")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 August 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/")[#text("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the most well known problems from ancient Greek mathematics was that of ")#link("http://en.wikipedia.org/wiki/Angle_trisection")[#text("trisecting an angle by straightedge and compass")]#text(", which was eventually proven impossible in 1837 by Pierre Wantzel, using methods from Galois theory.")

#text("Formally, one can set up the problem as follows. Define a ")#emph[#text("configuration")]#text(" to be a finite collection ")#mi("{{\\mathcal C}}")#text(" of points, lines, and circles in the Euclidean plane. Define a ")#emph[#text("construction step")]#text(" to be one of the following operations to enlarge the collection ")#mi("{{\\mathcal C}}")#text(":")

#list(
[#text("(Straightedge) Given two distinct points ")#mi("{A, B}")#text(" in ")#mi("{{\\mathcal C}}")#text(", form the line ")#mi("{\\overline{AB}}")#text(" that connects ")#mi("{A}")#text(" and ")#mi("{B}")#text(", and add it to ")#mi("{{\\mathcal C}}")#text(".")],
[#text("(Compass) Given two distinct points ")#mi("{A, B}")#text(" in ")#mi("{{\\mathcal C}}")#text(", and given a third point ")#mi("{O}")#text(" in ")#mi("{{\\mathcal C}}")#text(" (which may or may not equal ")#mi("{A}")#text(" or ")#mi("{B}")#text("), form the circle with centre ")#mi("{O}")#text(" and radius equal to the length ")#tao-math("{\\left|AB\\right|}", block: false)#text(" of the line segment joining ")#mi("{A}")#text(" and ")#mi("{B}")#text(", and add it to ")#mi("{{\\mathcal C}}")#text(".")],
[#text("(Intersection) Given two distinct curves ")#mi("{\\gamma, \\gamma^{\\prime}}")#text(" in ")#mi("{{\\mathcal C}}")#text(" (thus ")#mi("{\\gamma}")#text(" is either a line or a circle in ")#mi("{{\\mathcal C}}")#text(", and similarly for ")#mi("{\\gamma^{\\prime}}")#text("), select a point ")#mi("{P}")#text(" that is common to both ")#mi("{\\gamma}")#text(" and ")#mi("{\\gamma^{\\prime}}")#text(" (there are at most two such points), and add it to ")#mi("{{\\mathcal C}}")#text(".")]
)

#text("We say that a point, line, or circle is ")#emph[#text("constructible by straightedge and compass")]#text(" from a configuration ")#mi("{{\\mathcal C}}")#text(" if it can be obtained from ")#mi("{{\\mathcal C}}")#text(" after applying a finite number of construction steps.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 1 (Angle trisection)")]#text(" Let ")#mi("{A, B, C}")#text(" be distinct points in the plane. Is it always possible to construct by straightedge and compass from ")#mi("{A,B,C}")#text(" a line ")#mi("{\\ell}")#text(" through ")#mi("{A}")#text(" that ")#emph[#text("trisects")]#text(" the angle ")#mi("{\\angle BAC}")#text(", in the sense that the angle between ")#mi("{\\ell}")#text(" and ")#mi("{BA}")#text(" is one third of the angle of ")#mi("{\\angle BAC}")#text("?")
]

#text("Thanks to Wantzel’s result, the answer to this problem is known to be “no” in general; a ")#emph[#text("generic")]#text(" angle ")#mi("{\\angle BAC}")#text(" cannot be trisected by straightedge and compass. (On the other hand, some ")#emph[#text("special")]#text(" angles can certainly be trisected by straightedge and compass, such as a right angle. Also, one can certainly trisect generic angles using other methods than straightedge and compass; see the ")#link("http://en.wikipedia.org/wiki/Angle_trisection")[#text("Wikipedia page on angle trisection")]#text(" for some examples of this.)")

#text("The impossibility of angle trisection stands in sharp contrast to the easy construction of angle ")#emph[#text("bisection")]#text(" via straightedge and compass, which we briefly review as follows:")

#enum(start: 1, 
[#text("Start with three points ")#mi("{A, B, C}")#text(".")],
[#text("Form the circle ")#mi("{c_0}")#text(" with centre ")#mi("{A}")#text(" and radius ")#mi("{AB}")#text(", and intersect it with the line ")#mi("{\\overline{AC}}")#text(". Let ")#mi("{D}")#text(" be the point in this intersection that lies on the same side of ")#mi("{A}")#text(" as ")#mi("{C}")#text(". (")#mi("{D}")#text(" may well be equal to ")#mi("{C}")#text(").")],
[#text("Form the circle ")#mi("{c_1}")#text(" with centre ")#mi("{B}")#text(" and radius ")#mi("{AB}")#text(", and the circle ")#mi("{c_2}")#text(" with centre ")#mi("{D}")#text(" and radius ")#mi("{AB}")#text(". Let ")#mi("{E}")#text(" be the point of intersection of ")#mi("{c_1}")#text(" and ")#mi("{c_2}")#text(" that is not ")#mi("{A}")#text(".")],
[#text("The line ")#mi("{\\ell := \\overline{AE}}")#text(" will then bisect the angle ")#mi("{\\angle BAC}")#text(".")]
)

#link("https://terrytao.wordpress.com/wp-content/uploads/2011/08/trisect1.png")[#image("../assets/2e20da98ae3929a34a86f5f2f30e2c644f5c3faac3d567f342d832457e5e1437-fdf7006d3716d6d254633ea7d83b0a49fe2225d8972e50af12969bdb1206cc69.png", width: 90%)]

#text("The key difference between angle trisection and angle bisection ultimately boils down to the following trivial number-theoretic fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" ")#metadata(none) <tao-2c392ddd140b692c3c6e>#text(" There is no power of ")#mi("{2}")#text(" that is evenly divisible by ")#mi("{3}")#text(".")
]

#emph[#text("Proof:")]#text(" Obvious by modular arithmetic, by induction, or by the fundamental theorem of arithmetic. ")#mi("\\Box")

#text("In contrast, there are of course plenty of powers of ")#mi("{2}")#text(" that are evenly divisible by ")#mi("{2}")#text(", and this is ultimately why angle bisection is easy while angle trisection is hard.")

#text("The standard way in which Lemma ")#link(<tao-2c392ddd140b692c3c6e>)[#text("2")]#text(" is used to demonstrate the impossibility of angle trisection is via ")#link("http://en.wikipedia.org/wiki/Galois_theory")[#text("Galois theory")]#text(". The implication is quite short if one knows this theory, but quite opaque otherwise. We briefly sketch the proof of this implication here, though we will not need it in the rest of the discussion. Firstly, Lemma ")#link(<tao-2c392ddd140b692c3c6e>)[#text("2")]#text(" implies the following fact about ")#link("http://en.wikipedia.org/wiki/Algebraic_field_extension")[#text("field extensions")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3")]#text(" Let ")#mi("{F}")#text(" be a field, and let ")#mi("{E}")#text(" be an extension of ")#mi("{F}")#text(" that can be constructed out of ")#mi("{F}")#text(" by a finite sequence of ")#link("http://en.wikipedia.org/wiki/Quadratic_extension")[#text("quadratic extensions")]#text(". Then ")#mi("{E}")#text(" does not contain any cubic extensions ")#mi("{K}")#text(" of ")#mi("{F}")#text(".")
]

#emph[#text("Proof:")]#text(" If ")#mi("E")#text(" contained a cubic extension ")#mi("K")#text(" of ")#mi("F")#text(", then the dimension of ")#mi("E")#text(" over ")#mi("F")#text(" would be a multiple of three. On the other hand, if ")#mi("E")#text(" is obtained from ")#mi("F")#text(" by a tower of quadratic extensions, then the dimension of ")#mi("E")#text(" over ")#mi("F")#text(" is a power of two. The claim then follows from Lemma ")#link(<tao-2c392ddd140b692c3c6e>)[#text("2")]#text(". ")#mi("\\Box")

#text("To conclude the proof, one then notes that any point, line, or circle that can be constructed from a configuration ")#mi("{{\\mathcal C}}")#text(" is definable in a field obtained from the coefficients of all the objects in ")#mi("{{\\mathcal C}}")#text(" after taking a finite number of quadratic extensions, whereas a trisection of an angle ")#mi("{\\angle ABC}")#text(" will generically only be definable in a cubic extension of the field generated by the coordinates of ")#mi("{A,B,C}")#text(".")

#text("The Galois theory method also allows one to obtain many other impossibility results of this type, most famously the ")#link("http://en.wikipedia.org/wiki/Abel%E2%80%93Ruffini_theorem")[#text("Abel-Ruffini theorem")]#text(" on the insolvability of the quintic equation by radicals. For this reason (and also because of the many applications of Galois theory to number theory and other branches of mathematics), the Galois theory argument is the “right” way to prove the impossibility of angle trisection within the broader framework of modern mathematics. However, this argument has the drawback that it requires one to first understand Galois theory (or at least field theory), which is usually not presented until an advanced undergraduate algebra or number theory course, whilst the angle trisection problem requires only high-school level mathematics to formulate. Even if one is allowed to “cheat” and sweep several technicalities under the rug, one still needs to possess a fair amount of solid intuition about advanced algebra in order to appreciate the proof. (This was undoubtedly one reason why, even after Wantzel’s impossibility result was published, a large amount of effort was still expended by amateur mathematicians to try to trisect a general angle.)")

#text("In this post I would therefore like to present a different proof (or perhaps more accurately, a disguised version of the standard proof) of the impossibility of angle trisection by straightedge and compass, that avoids explicit mention of Galois theory (though it is never far beneath the surface). With “cheats”, the proof is actually quite simple and geometric (except for Lemma ")#link(<tao-2c392ddd140b692c3c6e>)[#text("2")]#text(", which is still used at a crucial juncture), based on the basic geometric concept of ")#link("http://en.wikipedia.org/wiki/Monodromy")[#text("monodromy")]#text("; unfortunately, some technical work is needed however to remove these cheats.")

#text("To describe the intuitive idea of the proof, let us return to the angle bisection construction, that takes a triple ")#mi("{A, B, C}")#text(" of points as input and returns a bisecting line ")#mi("{\\ell}")#text(" as output. We iterate the construction to create a quadrisecting line ")#mi("{m}")#text(", via the following sequence of steps that extend the original bisection construction:")

#enum(start: 1, 
[#text("Start with three points ")#mi("{A, B, C}")#text(".")],
[#text("Form the circle ")#mi("{c_0}")#text(" with centre ")#mi("{A}")#text(" and radius ")#mi("{AB}")#text(", and intersect it with the line ")#mi("{\\overline{AC}}")#text(". Let ")#mi("{D}")#text(" be the point in this intersection that lies on the same side of ")#mi("{A}")#text(" as ")#mi("{C}")#text(". (")#mi("{D}")#text(" may well be equal to ")#mi("{C}")#text(").")],
[#text("Form the circle ")#mi("{c_1}")#text(" with centre ")#mi("{B}")#text(" and radius ")#mi("{AB}")#text(", and the circle ")#mi("{c_2}")#text(" with centre ")#mi("{D}")#text(" and radius ")#mi("{AB}")#text(". Let ")#mi("{E}")#text(" be the point of intersection of ")#mi("{c_1}")#text(" and ")#mi("{c_2}")#text(" that is not ")#mi("{A}")#text(".")],
[#text("Let ")#mi("{F}")#text(" be the point on the line ")#mi("{\\ell := \\overline{AE}}")#text(" which lies on ")#mi("{c_0}")#text(", and is on the same side of ")#mi("{A}")#text(" as ")#mi("{E}")#text(".")],
[#text("Form the circle ")#mi("{c_3}")#text(" with centre ")#mi("{F}")#text(" and radius ")#mi("{AB}")#text(". Let ")#mi("{G}")#text(" be the point of intersection of ")#mi("{c_1}")#text(" and ")#mi("{c_3}")#text(" that is not ")#mi("{A}")#text(".")],
[#text("The line ")#mi("{m := \\overline{AG}}")#text(" will then quadrisect the angle ")#mi("{\\angle BAC}")#text(".")]
)

#link("https://terrytao.wordpress.com/wp-content/uploads/2011/08/trisect2.png")[#image("../assets/8629040b98503bff17eae2c8c61b105d852b55cb7faec39dea64366a65e5fd64-81420a124460ec04fe00652ac0b20a193fcbaf91bacec08f479b5f5d605e293c.png", width: 90%)]

#text("Let us fix the points ")#mi("{A}")#text(" and ")#mi("{B}")#text(", but not ")#mi("{C}")#text(", and view ")#mi("{m}")#text(" (as well as intermediate objects such as ")#mi("{D}")#text(", ")#mi("{c_2}")#text(", ")#mi("{E}")#text(", ")#mi("{\\ell}")#text(", ")#mi("{F}")#text(", ")#mi("{c_3}")#text(", ")#mi("{G}")#text(") as a function of ")#mi("{C}")#text(".")

#text("Let us now do the following: we begin rotating ")#mi("{C}")#text(" counterclockwise around ")#mi("{A}")#text(", which drags around the other objects ")#mi("{D}")#text(", ")#mi("{c_2}")#text(", ")#mi("{E}")#text(", ")#mi("{\\ell}")#text(", ")#mi("{F}")#text(", ")#mi("{c_3}")#text(", ")#mi("{G}")#text(" that were constructed by ")#mi("{C}")#text(" accordingly. For instance, here is an early stage of this rotation process, when the angle ")#mi("{\\angle BAC}")#text(" has become obtuse:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2011/08/trisect3.png")[#image("../assets/63ca2f65ad87bc4fc1e90d4e8d26b8e91a8bf8739a75de8acc7961fea3fe0d67-b622a84b086048c87bdc583acfc6a89d588d5cfb90232403bbb9254191b4af7d.png", width: 90%)]

#text("Now for the slightly tricky bit. We are going to keep rotating ")#mi("{C}")#text(" beyond a half-rotation of ")#mi("{180^\\circ}")#text(", so that ")#mi("{\\angle BAC}")#text(" now becomes a ")#emph[#text("reflex angle")]#text(". At this point, a singularity occurs; the point ")#mi("{E}")#text(" collides into ")#mi("{A}")#text(", and so there is an instant in which the line ")#mi("{\\ell = \\overline{AE}}")#text(" is not well-defined. However, this turns out to be a ")#emph[#text("removable singularity")]#text(" (and the easiest way to demonstrate this will be to tap the power of complex analysis, as complex numbers can easily route around such a singularity), and we can blast through it to the other side, giving a picture like this:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2011/08/trisect4.png")[#image("../assets/fd3fcd6d4720b3fe0a235a2425cc3f67190f87bd23e7021777505d653fe2d036-bc24017f540fd55d8a7208303b854bcd931293fa4e81a373418143a0ed0dad05.png", width: 90%)]

#text("Note that we have now deviated from the original construction in that ")#mi("{F}")#text(" and ")#mi("{E}")#text(" are no longer on the same side of ")#mi("{A}")#text("; we are thus now working in a ")#emph[#text("continuation")]#text(" of that construction rather than with the construction itself. Nevertheless, we can still work with this continuation (much as, say, one works with ")#link("http://en.wikipedia.org/wiki/Analytic_continuation")[#text("analytic continuations")]#text(" of infinite series such as ")#mi("{\\sum_{n=1}^\\infty \\frac{1}{n^s}}")#text(" beyond their original domain of definition).")

#text("We now keep rotating ")#mi("{C}")#text(" around ")#mi("{A}")#text(". Here, ")#mi("{\\angle BAC}")#text(" is approaching a full rotation of ")#mi("{360^\\circ}")#text(":")

#link("https://terrytao.wordpress.com/wp-content/uploads/2011/08/trisect5.png")[#image("../assets/f75aa083016940419616b3b0a70c38440547d62f9f32dc48dde3b88cad79b438-c92c71653fa3b8e6c73b14a8a8647ef231a795d86bed13e40f5c933ddc9f8412.png", width: 90%)]

#text("When ")#mi("{\\angle BAC}")#text(" reaches a full rotation, a different singularity occurs: ")#mi("{c_1}")#text(" and ")#mi("{c_2}")#text(" coincide. Nevertheless, this is also a removable singularity, and we blast through to beyond a full rotation:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2011/08/trisect6.png")[#image("../assets/9310453fffb35893ef19d2b769818b16bae9f5a1150444f2bef31b9c98a4bc5c-4e7d172d1f3d3d2db904eb2e120232d61f67f6410b4c8f3aa4df7d1ed338d5db.png", width: 90%)]

#text("And now ")#mi("{C}")#text(" is back where it started, as are ")#mi("{D}")#text(", ")#mi("{c_2}")#text(", ")#mi("{E}")#text(", and ")#mi("{\\ell}")#text("… but the point ")#mi("{F}")#text(" has moved, from one intersection point of ")#mi("{\\ell \\cap c_3}")#text(" to the other. As a consequence, ")#mi("{c_3}")#text(", ")#mi("{G}")#text(", and ")#mi("{m}")#text(" have also changed, with ")#mi("{m}")#text(" being at right angles to where it was before. (In the jargon of modern mathematics, the quadrisection construction has a non-trivial ")#link("http://en.wikipedia.org/wiki/Monodromy")[#text("monodromy")]#text(".)")

#text("But nothing stops us from rotating ")#mi("{C}")#text(" some more. If we continue this procedure, we see that after two full rotations of ")#mi("{C}")#text(" around ")#mi("{A}")#text(", all points, lines, and circles constructed from ")#mi("{A, B, C}")#text(" have returned to their original positions. Because of this, we shall say that the quadrisection construction described above is ")#emph[#text("periodic with period ")#mi("{2}")]#text(".")

#text("Similarly, if one performs an octisection of the angle ")#mi("{\\angle BAC}")#text(" by bisecting the quadrisection, one can verify that this octisection is periodic with period ")#mi("{4}")#text("; it takes four full rotations of ")#mi("{C}")#text(" around ")#mi("{A}")#text(" before the configuration returns to where it started. More generally, one can show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" ")#metadata(none) <tao-f98407019f8c4af6fbb6>#text(" Any construction of straightedge and compass from the points ")#mi("{A,B,C}")#text(" is periodic with period equal to a power of ")#mi("{2}")#text(".")
]

#text("The reason for this, ultimately, is because any two circles or lines will intersect each other in at most two points, and so at each step of a straightedge-and-compass construction there is an ambiguity of at most ")#mi("{2! = 2}")#text(". Each rotation of ")#mi("{C}")#text(" around ")#mi("{A}")#text(" can potentially flip one of these points to the other, but then if one rotates again, the point returns to its original position, and then one can analyse the next point in the construction in the same fashion until one obtains the proposition.")

#text("But now consider a putative trisection operation, that starts with an arbitrary angle ")#mi("{\\angle BAC}")#text(" and somehow uses some sequence of straightedge and compass constructions to end up with a trisecting line ")#mi("{\\ell}")#text(":")

#link("https://terrytao.wordpress.com/wp-content/uploads/2011/08/trisect7.png")[#image("../assets/10154c4b28998cc1eaaea0492a95fae0833bdd56eaa4af1809119ef26caf7ea0-64a81c64318ee4b8d8de485ad4b124c168228e9142ff39204cc028b07f2e06d2.png", width: 90%)]

#text("What is the period of this construction? If we continuously rotate ")#mi("{C}")#text(" around ")#mi("{A}")#text(", we observe that a full rotations of ")#mi("{C}")#text(" only causes the trisecting line ")#mi("{\\ell}")#text(" to rotate by a third of a full rotation (i.e. by ")#mi("{120^\\circ}")#text("):")

#link("https://terrytao.wordpress.com/wp-content/uploads/2011/08/trisect8.png")[#image("../assets/bfecf6ace8f159ab81c01f0ff74c5579268e7473c9457df961f95c6cdf89dd37-103587cbeb4ff8df3c25c06fa2a6811f31aeec9cea6d2f625a81e4e81c991cb4.png", width: 90%)]

#link("https://terrytao.wordpress.com/wp-content/uploads/2011/08/trisect9.png")[#image("../assets/ad34d501c11d21f916540150981105a34493b1784095c6f747a0103b88e31f0c-5603ce192602f8342e133ca7d4ee87d27b61463e32e2f2e4c6c881637bcd4949.png", width: 90%)]

#link("https://terrytao.wordpress.com/wp-content/uploads/2011/08/trisect101.png")[#image("../assets/3ad404ce4907eb6d7517604b96e923d77aadbcef9161800540c4fdd0cababc98-0981ec5c439a2eff46a1e6495b686eaf5a2ddaf73a772550bf2ad53cc55f0f8c.png", width: 90%)]

#text("Because of this, we see that the period of any construction that contains ")#mi("{\\ell}")#text(" must be a multiple of ")#mi("{3}")#text(". But this contradicts Proposition ")#link(<tao-f98407019f8c4af6fbb6>)[#text("4")]#text(" and Lemma ")#link(<tao-2c392ddd140b692c3c6e>)[#text("2")]#text(".")

#text("Below the fold, I will make the above proof rigorous. Unfortunately, in doing so, I had to again leave the world of high-school mathematics, as one needs a little bit of algebraic geometry and complex analysis to resolve the issues with singularities that we saw in the above sketch. Still, I feel that at an intuitive level at least, this argument is more geometric and accessible than the Galois-theoretic argument (though anyone familiar with Galois theory will note that there is really not that much difference between the proofs, ultimately, as one has simply replaced the Galois group with a closely related monodromy group instead).")

#metadata(none) <tao-1c6d7f02da82c51184a6>

#heading(level: 1)[#strong[#text(" — 1. Details — ")]]

#text("We now make the argument more rigorous. We will assume for sake of contradiction that for every triple ")#mi("{A,B,C}")#text(" of distinct points, we can find a construction by straightedge and compass that trisects the angle ")#mi("{\\angle BAC}")#text(", and eventually deduce a contradiction out of this.")

#text("We remark that we do not initially assume any uniformity in this construction; for instance, it could be possible that the trisection procedure for obtuse angles is completely different from that of acute angles, using a totally different set of constructions, while some exceptional angles (e.g. right angles or degenerate angles) might use yet another construction. We will address these issues later.")

#text("The first step is to get rid of some possible degeneracies in one’s construction. At present, nothing in our definition of a construction prevents us from adding a point, line, or circle to the construction that was already present in the existing collection ")#mi("{{\\mathcal C}}")#text(" of points, lines, and circles. However, it is clear that any such step in the construction is redundant, and can be omitted. Thus, we may assume without loss of generality that for each ")#mi("{A,B,C}")#text(", the construction used to trisect the angle contains no such redundant steps. (This may make the construction even less uniform than it was previously, but we will address this issue later.)")

#text("Another form of degeneracy that we will need to eliminate for technical reasons is that of ")#emph[#text("tangency")]#text(". At present, we allow in our construction the ability to take two tangent circles, or a circle and a tangent line, and add the tangent point to the collection (if it was not already present in the construction). This would ordinarily be a harmless thing to do, but it complicates our strategy of perturbing the configuration, so we now act to eliminate it. Suppose first that one had two circles ")#mi("{c_1,c_2}")#text(" already constructed in the configuration ")#mi("{{\\mathcal C}}")#text(" and tangent to each other, and one wanted to add the tangent point ")#mi("{T}")#text(" to the configuration. But note that in order to have added ")#mi("{c_1}")#text(" and ")#mi("{c_2}")#text(" to ")#mi("{{\\mathcal C}}")#text(", one must previously have added the centres ")#mi("{A_1}")#text(" and ")#mi("{A_2}")#text(" of these circles to ")#mi("{{\\mathcal C}}")#text(" also. One can then add ")#mi("{T}")#text(" to ")#mi("{{\\mathcal C}}")#text(" by intersecting the line ")#mi("{\\overline{A_1 A_2}}")#text(" with ")#mi("{c_1}")#text(" and picking the point that lies on ")#mi("{c_2}")#text("; this way, one does not need to intersect two tangent curves together.")

#link("https://terrytao.wordpress.com/wp-content/uploads/2011/08/trisect11.png")[#image("../assets/5b07d8d89fcd16539f6b4401bf03b7b39e89a1a183b07de4092fbea3c5850044-d5f50442eed658410841747491065d6cdc9ae1e9d022cb80bd0eebde196f8f60.png", width: 90%)]

#text("Similarly, suppose that we already had a circle ")#mi("{c}")#text(" and a tangent line ")#mi("{\\ell}")#text(" already constructed in the configuration, but with the tangent point ")#mi("{T}")#text(" absent. The centre ")#mi("{A}")#text(" of ")#mi("{c}")#text(", and at least two points ")#mi("{B, C}")#text(" on ")#mi("{\\ell}")#text(", must previously have also been constructed in order to have ")#mi("{c}")#text(" and ")#mi("{\\ell}")#text(" present; note that ")#mi("{B, C}")#text(" are not equal to ")#mi("{T}")#text(" by hypothesis. One can then obtain ")#mi("{T}")#text(" by dropping a perpendicular from ")#mi("{A}")#text(" to ")#mi("{\\ell}")#text(" by the usual construction (i.e. drawing a circle centred at ")#mi("{A}")#text(" with radius ")#tao-math("{\\left|AB\\right|}", block: false)#text(" to hit ")#mi("{\\ell}")#text(" again at ")#mi("{D}")#text(", then drawing circles from ")#mi("{B}")#text(" and ")#mi("{D}")#text(" with the same radius ")#tao-math("{\\left|AB\\right|}", block: false)#text(" to meet at a point ")#mi("{E}")#text(" distinct from ")#mi("{A}")#text(", then intersecting ")#mi("{AE}")#text(" with ")#mi("{\\ell}")#text(" to obtain ")#mi("{T}")#text("), thus avoiding tangencies again. (This construction may happen to use lines or circles that had already appeared in the construction, but in those cases one can simply skip those steps.)")

#link("https://terrytao.wordpress.com/wp-content/uploads/2011/08/trisect12.png")[#image("../assets/4b607ffc4d4917b863b0e2edf2c16d0c7a77145c422a0f5995fdde25c3181f8b-cfa499b4bf0547b8130de47599735378355c9f073558df0b4ed6c7ceedcaf764.png", width: 90%)]

#text("As a consequence of these reductions, we may now assume that our construction is ")#emph[#text("nondegenerate")]#text(" in the sense that")

#list(
[#text("Any point, line, or circle added at a step in the construction, does not previously appear in that construction.")],
[#text("Whenever one intersects two circles in a construction together to add another point to the construction, the circles are non-tangent (and thus meet in exactly two points).")],
[#text("Whenever one intersects a circle and a line in a construction together to add another point to the construction, the circle and line are non-tangent (and thus meet in exactly two points).")]
)

#text("The reason why we restrict attention to nondegenerate constructions is that they are ")#emph[#text("stable with respect to perturbations")]#text(". Note for instance that if one has two circles ")#mi("{c_1, c_2}")#text(" that intersect in two different points, and one of them is labeled ")#mi("{P}")#text(", then we may perturb ")#mi("{c_1}")#text(" and ")#mi("{c_2}")#text(" by a small amount, and still have an intersection point close to ")#mi("{P}")#text(" (with the other intersection point far away from ")#mi("{P}")#text("). Thus, ")#mi("{P}")#text(" is locally a continuous function of ")#mi("{c_1}")#text(" and ")#mi("{c_2}")#text(". Similarly if one forms the intersection of a circle and a secant (a line which intersects non-tangentially). In a similar vein, given two points ")#mi("{A}")#text(" and ")#mi("{B}")#text(" that are distinct, the line between them ")#mi("{\\overline{AB}}")#text(" varies continuously with ")#mi("{A}")#text(" and ")#mi("{B}")#text(" as long as one does not move ")#mi("{A}")#text(" and ")#mi("{B}")#text(" so far that they collide; and given two lines ")#mi("{\\ell_1}")#text(" and ")#mi("{\\ell_2}")#text(" that intersect at a point ")#mi("{C}")#text(" (and in particular are non-parallel), then ")#mi("{C}")#text(" also depends continuously on ")#mi("{\\ell_1}")#text(" and ")#mi("{\\ell_2}")#text(". Thus, in a nondegenerate construction starting from the original three points ")#mi("{A,B,C}")#text(", every point, line, or circle created by the construction can be viewed as a continuous function of ")#mi("{A,B,C}")#text(", as long as one only works in a sufficiently small neighbourhood of the original configuration ")#mi("{(A,B,C)}")#text(". In particular, the final line ")#mi("{\\ell}")#text(" varies continuously in this fashion. Note however that the trisection property may be lost by this perturbation; just because ")#mi("{\\ell}")#text(" happens to trisect ")#mi("{\\angle BAC}")#text(" when ")#mi("{A,B,C}")#text(" are in the original positions, this does not necessarily imply that after one perturbs ")#mi("{A,B,C}")#text(", that the resulting perturbed line ")#mi("{\\ell}")#text(" still trisects the angle. (For instance, there are a number of ways to trisect a right angle (e.g. by bisecting an angle of an equilateral triangle), but if one perturbs the angle to be slightly acute or slightly obtuse, the line created by this procedure would not be expected to continue to trisect that angle.)")

#text("The next step is to allow ")#link("http://en.wikipedia.org/wiki/Analytic_geometry")[#text("analytic geometry")]#text(" (and thence ")#link("http://en.wikipedia.org/wiki/Algebraic_geometry")[#text("algebraic geometry")]#text(") to enter the picture, by using ")#link("http://en.wikipedia.org/wiki/Cartesian_coordinate_system")[#text("Cartesian coordinates")]#text(". We may identify the Euclidean plane with the analytic plane ")#mi("{{\\bf R}^2 := \\{ (x,y): x,y \\in {\\bf R}\\}}")#text("; we may also normalise ")#mi("{A, B}")#text(" to be the points ")#mi("{A = (0,0)}")#text(", ")#mi("{B = (1,0)}")#text(" by this identification. We will also restrict ")#mi("{C}")#text(" to lie on the unit circle ")#mi("{S^1 := \\{ (x,y) \\in {\\bf R}^2: x^2+y^2 = 1 \\}}")#text(", so that there is now just one degree of freedom in the configuration ")#mi("{(A,B,C)}")#text(". One can describe a line in ")#mi("{{\\bf R}^2}")#text(" by an equation of the form")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y) \\in {\\bf R}^2: ax+by+c = 0 \\}")]]

#text("(with ")#mi("{a,b}")#text(" not both zero), and describe a circle in ")#mi("{{\\bf R}^2}")#text(" by an equation of the form")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y) \\in {\\bf R}^2: (x-x_0)^2 + (y-y_0)^2 = r^2 \\}")]]

#text("with ")#mi("{r}")#text(" non-zero. There is some non-uniqueness in these representations: for the line, one can multiply ")#mi("{a,b,c}")#text(" by the same constant without altering the line, and for the circle, one can replace ")#mi("{r}")#text(" by ")#mi("{-r}")#text(". However, this will not be a serious concern for us. Note that any two distinct points ")#mi("{P = (x_1,y_1)}")#text(", ")#mi("{Q = (x_2,y_2)}")#text(" determine a line")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y) \\in {\\bf R}^2: x y_1 - xy_2 - y x_1 + y x_2 + x_1 y_2 - x_2 y_1 = 0 \\}")]]

#text("and given three points ")#mi("{O = (x_0,y_0)}")#text(", ")#mi("{A = (x_1,y_1)}")#text(", ")#mi("{B = (x_2,y_2)}")#text(", one can form a circle")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y) \\in {\\bf R}^2: (x-x_0)^2 + (y-y_0)^2 = (x_1-x_2)^2 + (y_1-y_2)^2\\}")]]

#text("with centre ")#mi("{O}")#text(" and radius ")#tao-math("{\\left|AB\\right|}", block: false)#text(". Given two distinct non-parallel lines")

#align(center)[#tao-fit-display[#mitex("\\ell = \\{ (x,y) \\in {\\bf R}^2: ax+by+c=0\\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\ell^{\\prime} = \\{ (x,y) \\in {\\bf R}^2: a^{\\prime}x+b^{\\prime}y+c^{\\prime}=0\\},")]]

#text("their unique intersection point is given as")

#align(center)[#tao-fit-display[#mitex("( \\frac{bc^{\\prime}-b^{\\prime}c}{ab^{\\prime}-ba^{\\prime}}, \\frac{a^{\\prime}c-c^{\\prime}a}{ab^{\\prime}-ba^{\\prime}} );")]]

#text("similarly, given two circles")

#align(center)[#tao-fit-display[#mitex("c_1 = \\{ (x,y) \\in {\\bf R}^2: (x-x_1)^2 + (y-y_1)^2 = r_1^2 \\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("c_2 = \\{ (x,y) \\in {\\bf R}^2: (x-x_2)^2 + (y-y_2)^2 = r_2^2 \\},")]]

#text("their points of intersection (if they exist in ")#mi("{{\\bf R}^2}")#text(") are given as ")#metadata(none) <tao-862615375d041fad0647>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("(x_1,y_1) + t (x_2-x_1,y_2-y_1) \\pm (\\frac{r^2 - t^2 d^2}{d^2})^{1/2} (y_1-y_2,x_2-x_1)")]]



#text(" where")

#align(center)[#tao-fit-display[#mitex("t := \\frac{1}{2} - \\frac{r_2^2-r_1^2}{2d^2}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("d^2 := (x_1-x_2)^2+(y_1-y_2)^2,")]]

#text("and the points of intersection between ")#mi("{\\ell}")#text(" and ")#mi("{c_1}")#text(" (if they exist in ")#mi("{{\\bf R}^2}")#text(") are given as ")#metadata(none) <tao-944e2b14e52e2d9d5db8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("(x_1,y_1) - \\frac{ax_1+by_1+c}{a^2+b^2}(a,b) \\pm \\sqrt{r^2 - (\\frac{ax_1+by_1+c}{a^2+b^2})^2} (b,-a).")]]



#text(" The precise expressions given above are not particularly important for our argument, save to note that these expressions are always ")#link("http://en.wikipedia.org/wiki/Algebraic_function")[#text("algebraic functions")]#text(" of the input coordinates such as ")#mi("{x_0,x_1,x_2,y_0,y_1,y_2,a,b,c,a^{\\prime},b^{\\prime},c^{\\prime},r_1,r_2}")#text(", defined over the reals ")#mi("{{\\bf R}}")#text(", and that the only algebraic operations needed here besides the arithmetic operations of addition, subtraction, multiplication, and division is the square root operation. Thus, we see that any particular construction of, say, a line ")#mi("{\\ell}")#text(" from a configuration ")#mi("{(A,B,C)}")#text(" will locally be an algebraic function of ")#mi("{C}")#text(" (recall that we have already fixed ")#mi("{A,B}")#text("), and this definition can be extended until one reaches a degeneracy (two points, lines, or circles collide, two curves become tangent, or two lines become parallel); however, this degeneracy only occurs in an proper real algebraic set of configurations, and in particular for ")#mi("{C}")#text(" in a dimension zero subset of the circle ")#mi("{S^1}")#text(".")

#text("These degeneracies are annoying because they disconnect the circle ")#mi("{S^1}")#text(", and can potentially block off large regions of that circle for which the construction is not even defined (because two circles stop intersecting, or a circle and line stop intersecting, in ")#mi("{{\\bf R}^2}")#text(", due to the lack of a real square root for negative numbers). To fix this, we move now from the real plane ")#mi("{{\\bf R}^2}")#text(" to the complex plane ")#mi("{{\\bf C}^2}")#text(". Note that the algebraic definitions of a line and a circle continue to make perfect sense in ")#mi("{{\\bf C}^2}")#text(" (with coefficients such as ")#mi("{a,b,c,x_0,y_0,r}")#text(" now allowed to be complex numbers instead of real numbers), and the algebraic intersection formulae given previously continue to make sense in the complex setting. The point ")#mi("{C}")#text(" now is allowed to range in the complex circle ")#mi("{S^1_{\\bf C} = \\{ (x,y) \\in {\\bf C}: x^2+y^2 = 1 \\}}")#text(", which is a Riemann surface (conformal to the ")#link("http://en.wikipedia.org/wiki/Riemann_sphere")[#text("Riemann sphere")]#text(" ")#mi("{{\\bf C} \\cup \\infty}")#text(" after stereogrpahic projection). Furthermore, because all non-zero complex numbers have square roots, any given construction that was valid for at least one configuration is now valid (though possibly multi-valued) as an algebraic function on ")#mi("{S^1_{\\bf C}}")#text(" outside of a dimension zero set of singularities, i.e. outside of a finite number of exceptional values of ")#mi("{C}")#text(". But note now that these singularities do not disconnect the complex circle ")#mi("{S^1_{\\bf C}}")#text(", which has topological dimension two instead of one.")

#text("As mentioned earlier, a line ")#mi("{\\ell}")#text(" given by such a construction may or may not trisect the original angle ")#mi("{\\angle BAC}")#text(". But this trisection property can be expressed algebraically (e.g. using the triple angle formulae from trigonometry, or by building rotation matrices), and in particular makes sense over ")#mi("{{\\bf C}}")#text(". Thus, for any given construction of a line ")#mi("{\\ell}")#text(", the set of ")#mi("{C}")#text(" in ")#mi("{S^1_{\\bf C}}")#text(" for which the construction is non-degenerate and trisects ")#mi("{\\angle BAC}")#text(" is a ")#emph[#text("constructible set")]#text(" (a boolean combination of algebraic sets). But ")#mi("{S^1_{\\bf C}}")#text(" is an irreducible one-dimensional complex variety. As such, the aforementioned set of ")#mi("{C}")#text(" is either ")#emph[#text("generic")]#text(" (the complement of a dimension one algebraic set), or has dimension at most one. (Here we are implicitly using the fundamental theorem of algebra, because the basic dimension theory of algebraic geometry only works properly over algebraically closed fields.)")

#text("On the other hand, there are at most countably many constructions, and by hypothesis, for each choice of ")#mi("{C}")#text(" in ")#mi("{S^1_{\\bf C}}")#text(", at least one of these constructions has to trisect the angle. Applying the ")#link("http://en.wikipedia.org/wiki/Baire_category_theorem")[#text("Baire category theorem")]#text(" (or countable additivity of Lebesgue measure, or using the algebraic geometry fact that an algebraic variety over an uncountable field cannot be covered by the union of countably many algebraic sets of smaller dimension), we conclude that there is a single construction which trisects the angle ")#mi("{\\angle BAC}")#text(" for a generic choice of ")#mi("{C}")#text(", i.e. for all ")#mi("{C}")#text(" in ")#mi("{S^1_{\\bf C}}")#text(" outside of a finite set of points, there is a construction, which amongst its multiple possible values, is able to output at least one line ")#mi("{\\ell}")#text(" that trisects ")#mi("{\\angle BAC}")#text(".")

#text("Now one performs monodromy. Suppose we move ")#mi("{C}")#text(" around a closed loop in ")#mi("{S^1_{\\bf C}}")#text(" that avoids all points of degeneracy. Then all the other points, lines, and circles constructed from ")#mi("{A, B, C}")#text(" can be continuously extended from an initial configuration as discussed earlier, with each such object tracing out its own path in its own configuration space. Because of the presence of square roots in constructions such as the intersection ")#link(<tao-862615375d041fad0647>)[#text("(1)")]#text(" between two circles, or the intersection ")#link(<tao-944e2b14e52e2d9d5db8>)[#text("(2)")]#text(" between a circle and a line, these constructions may map a closed loop to an open loop; but because the square root function forms a double cover of ")#mi("{{\\bf C} \\backslash 0}")#text(", we see that any closed loop in ")#mi("{{\\bf C} \\backslash 0}")#text(", if doubled, will continue to be a closed loop upon taking a square root. (Alternatively, one can argue geometrically rather than algebraically, noting that in the intersection of (say) two non-degenerate circles ")#mi("{c_1, c_2}")#text(", there are only two possible choices for the intersection point of these two circles, and so if one performs monodromy along a loop of possible pairs ")#mi("{(c_1,c_2)}")#text(" of circles, either these two choices return to where they initially started, or are swapped; so if one doubles the loop, one must necessarily leave the intersection points unchanged.) Iterating this, we see that any object constructed by straightedge and compass from ")#mi("{A,B,C}")#text(" must have period ")#mi("{2^k}")#text(" for some power of two ")#mi("{2^k}")#text(", in the sense that if one iterates a loop of ")#mi("{C}")#text(" in ")#mi("{S^1_{\\bf C}}")#text(" avoiding degenerate points ")#mi("{2^k}")#text(" times, the object must return to where it started. (In more algebraic terminology: the monodromy group must be a ")#mi("{2}")#text("-group.)")

#text("Now, one traverses ")#mi("{C}")#text(" along a slight perturbation of a single rotation of the real unit circle ")#mi("{S^1}")#text(", taking a slight detour around the finite number of degeneracy points one encounters along the way. Since ")#mi("{\\ell}")#text(" has to trisect the angle ")#mi("{\\angle ABC}")#text(" at each of these points, while varying continuously with ")#mi("{C}")#text(", we see that when ")#mi("{C}")#text(" traverses a full rotation, ")#mi("{\\ell}")#text(" has only traversed one third of a rotation (or two thirds, depending on which trisection one obtained), and so the period of ")#mi("{\\ell}")#text(" must be a multiple of three; but this contradicts Lemma ")#link(<tao-2c392ddd140b692c3c6e>)[#text("2")]#text(", and the claim follows.")

#heading(level: 1)[#text("Comments (146)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23f1eccfe747e324133164ca5db3cbf3e9e68eda70519705615f4ad95ccc8364-090bd23601e873e4972d4a12f473caf135f4ec75ce5ad420c1edcf0272887dce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-479795")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2017")])]

#text("Hi every one. Very interesting comments in here. I however strongly disagree with the statement that it is geometrically impossible to trisect any angle defined between two rays, uniting at a common end point. Looking at the angle trisection impossibility proof, Wantzel gave just a statement that it is impossible to classically trisect an angle, and to support his statement, he used a 60 degree angle as an example that no one can construct a 20 degree angle. I think this was a very wrong approach of the case. First, the algebraic proof turned the problem from geometrical into a purely algebraic one. That violates the governing rigor in verifying geometrical logic. It it is important we look at what is possible and what is impossible reasonably. The first drawback in the impossibility proof is that, i would kind of, accept the statement of angle trisection impossibility only if wantzel gave a geometrical approach, for trisecting an angle such as 72 degrees, that cannot trisect the 60 degree angle. I have done some work in geometry. In my first publication, i aimed at generating an algorithm to help that would help construct all whole number angles, their multiples and sub-multiple angles. In this my approach, though the work did not have a geometric proof, i realized that this did not solve the angle trisection problem. I later Generated an simple proof, close to the Archimedes theorem of angle trisection using a marked straightedge, to support my theorem, but too aiming at solving the angle trisection problem.")

#text("I later realized that did not solve the problem, though using the proposed method, one is logically able to construct all whole number angles starting from 1 degree. In this paper i also have shown how to trisect angles of 48 and 60, as a general proof for construction of all whole number angles. I moreover, have made another algorithm for trisection of an arbitrary angle. In this theorem, i discovered it is possible to trisect all angles, within a certain range of angle. I chose this set to represent a subset of all the angles. From this link: ")#link("https://www.academia.edu/32310946/trisection.docx")[#text("https://www.academia.edu/32310946/trisection.docx")]#text(", one is able to see some of the results i generated using my algorithm, which i will be posting soon after the proof is published. These results represent two aspects; as any reader would like to know from a construction, that, does the method work for all angles or for a specific angle?. How accurate are the results?. Find out from the docx file.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/967fba9fb8002c9ee65c3a890ce25542bea98f453059cb79b6da4c2818d9ebc3-06ff8c9b33ae893f1368e08a86c2ead58f5969145436bd63ae5f2a3655d364ae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harold Florentino Latortue, PhD")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-479950")[#strong[#text("Harold Florentino Latortue, PhD")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2017")])]

#text("I completely agree with you on Wantzel proof. His approach just did replace x=2cos(20) in the equation. There is no graphic reasons for it. The same equation can be use to show that the solutions can be obtained from x=Rsin(a/6) and Y=R[cos(a/6)-cos(a/2). Once you move the origin of the coordinate system to O(0, cos(a/2) the problem is moved from a cubic root to a square root.")

#strong[#text(" ")#link("https://www.slideshare.net/HAROLDFLORENTINOLATO/graphic-trisection-of-an-arbitrary-angle")[#text("Graphic Trisection of an Arbitrary Angle")]#text(" ")]#text(" from ")#strong[#link("https://www.slideshare.net/HAROLDFLORENTINOLATO")[#text("HAROLD FLORENTINO LATORTUE PhD")]]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23f1eccfe747e324133164ca5db3cbf3e9e68eda70519705615f4ad95ccc8364-090bd23601e873e4972d4a12f473caf135f4ec75ce5ad420c1edcf0272887dce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-479956")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2017")])]

#text("Dear Prof. HAROLD FLORENTINO LATORTUE. Am glad that you accept there is messy in the angle trisection proof. Thanks for your comment. I also like your algebraic approach. I have tried to follow your slides but got lost at around slide 21. The construction is getting tiresome from this point because of the many steps to be followed. I think it really would have been good to have a more shorter method. At this point i am not able to decisively say your construction is exact because i have not gotten the results. I will try it again and get back to you later. I invite you to view the results i got from this link; ")#link("https://www.academia.edu/32310946/trisection.docx")[#text("https://www.academia.edu/32310946/trisection.docx")]#text(". I have managed to generate a 7 steps algorithm for trisecting an arbitrary angle. In this draft, i have presented the results based on accuracy. My algorithm is purely compass-straightedge construction, no arithmetics nor measurements involved. It works for all angles, whole number angles and non-whole number angles trisection.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/967fba9fb8002c9ee65c3a890ce25542bea98f453059cb79b6da4c2818d9ebc3-06ff8c9b33ae893f1368e08a86c2ead58f5969145436bd63ae5f2a3655d364ae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harold Florentino Latortue, PhD")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-479964")[#strong[#text("Harold Florentino Latortue, PhD")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2017")])]

#text("Alex, I understand that it appears tiresome. The slides are parts of the complete book that I publish on Amazon: ‘Graphic trisection of an arbitrary angle’. ")#link("https://www.amazon.com/Graphic-Trisection-arbitrary-angle-impossible/dp/0692870121/ref=pd_sbs_14_1?_encoding=UTF8&pd_rd_i=0692870121&pd_rd_r=WM69FD6TZBW9MFS5F509&pd_rd_w=21g8T&pd_rd_wg=gvqZu&psc=1&refRID=WM69FD6TZBW9MFS5F509")[#text("https://www.amazon.com/Graphic-Trisection-arbitrary-angle-impossible/dp/0692870121/ref=pd_sbs_14_1?_encoding=UTF8&pd_rd_i=0692870121&pd_rd_r=WM69FD6TZBW9MFS5F509&pd_rd_w=21g8T&pd_rd_wg=gvqZu&psc=1&refRID=WM69FD6TZBW9MFS5F509")]#text(" In this book, there is an explanation of ‘what you are doing’ in each step. Plus the algebraic proof of why this work. Slide 26 presents the results when the graphic method is compared to the algebraic method for various values of the angle.")#linebreak()#text(" I do abide to the rules of straightedge and compass")#linebreak()#text(" I you can provide an email address I will be glad to send you a PDF copy of the book.")#linebreak()#text(" Thanks for your interest")#linebreak()#text(" Florentino")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23f1eccfe747e324133164ca5db3cbf3e9e68eda70519705615f4ad95ccc8364-090bd23601e873e4972d4a12f473caf135f4ec75ce5ad420c1edcf0272887dce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-479831")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2017")])]

#text("Hello!! I got something else on cube duplication. I got a very interesting approach of constructing a line of magnitude 1.2599… given a cube of a unit length. In the work i have rounded up this factor to 1.26, that i could proof its exactness. I do not believe it is good we confuse an inability with impossibility. I think the most difficult thing under the sun is to proof something to be impossible. As a physicist, i understand what it means by something being impossible. For one to proof an impossibility, we have to take into consideration all the laws of nature. Not just acceptance of statements that something is impossible. Any way, in this article, i have addressed my solution as an approximate construction because of the proof i employed. But, i think if one is able to provably construct the third root of 2, what importantly matters is the logic followed towards the solution, and not much of the generated value, though the results should agree with the set claim. The method works for both the compass-straightedge construction and the CAD methods. I used GeiGebra in generating the results. Here is the link “https://www.academia.edu/32406599/Geometrical_Duplication_of_a_Cube_An_Approximate_Solution_”. Any feedback is highly welcome. Correspond through the provided e-mail in the paper.")#linebreak()#text(" Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23f1eccfe747e324133164ca5db3cbf3e9e68eda70519705615f4ad95ccc8364-090bd23601e873e4972d4a12f473caf135f4ec75ce5ad420c1edcf0272887dce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-479832")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2017")])]

#link("https://www.academia.edu/32406599/Geometrical_Duplication_of_a_Cube_An_Approximate_Solution_")[#text("https://www.academia.edu/32406599/Geometrical_Duplication_of_a_Cube_An_Approximate_Solution_")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/967fba9fb8002c9ee65c3a890ce25542bea98f453059cb79b6da4c2818d9ebc3-06ff8c9b33ae893f1368e08a86c2ead58f5969145436bd63ae5f2a3655d364ae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harold Florentino Latortue, PhD")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-479949")[#strong[#text("Harold Florentino Latortue, PhD")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2017")])]

#text("With humility, I am convince that many problem may have undiscovered solutions. By freeing one of the algebraic constraints of the trisection of an arbitrary angle, one can reduce it from a cubic root to a square root approach. I invite you to look this following approach that has great possibilities: ")#link("https://www.slideshare.net/HAROLDFLORENTINOLATO/graphic-trisection-of-an-arbitrary-angle?qid=760850f0-17cf-42f8-b747-01bfbd225113&v=&b=&from_search=1")[#text("https://www.slideshare.net/HAROLDFLORENTINOLATO/graphic-trisection-of-an-arbitrary-angle?qid=760850f0-17cf-42f8-b747-01bfbd225113&v=&b=&from_search=1")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23f1eccfe747e324133164ca5db3cbf3e9e68eda70519705615f4ad95ccc8364-090bd23601e873e4972d4a12f473caf135f4ec75ce5ad420c1edcf0272887dce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-479957")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2017")])]

#text("Hi HAROLD FLORENTINO LATORTUE. I do not think it will be a good thing to bend any algebraic condition, based on the classical geometric view of things. No one can deny that; Euclidean geometry has its initial shape in nature and sharply shine than any other new development in academia. It will remain in existence. However, i believe, we need to appreciate the fact that, the traditional geometers solely worked out their findings using only compass and straightedge. The analytical interpretation of geometrical findings came later, due to interest by humans to work with specific quantities. Number systems was created. I deeper look at the ancient times work would reveal that, Euclid did not work with numbers, and instead, he used the term magnitude. He did not have nationalities such as root 2. Instead, he worked with incomparable. But he was able to construct a line of magnitude root of 2. I think, the most important consideration in today’s research is to have a methods, that precisely give clear results, when performed using both the traditional approaches, and in using the CAD approaches. I Do agree with you that the most difficult thing in the universe for humans is to proof something to be completely impossible. No matter the set conditions for a particular problem, we need to be sure and clear that impossibility does not mean the inability to solve a particular problem. For example, if we consider a quantity power, in mechanics, power is defined by energy per unit time. When someone say; it is not possible to create not destroy power, i think it is quite sensible. The nature agree with such a claim. It is possible, physically, to have almost two identical people competing to run up and down a system of stair cases, and to have one of them wining the race. Empirically, it can be proven from any good physics lab that, the equation V=IR is correct. Therefore agreeing with the statement that it is impossible to create power. What importantly the matter should be is the analogs employed in disproving something. Statements based on incomprehensible algebraic proofs make no sense.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/967fba9fb8002c9ee65c3a890ce25542bea98f453059cb79b6da4c2818d9ebc3-06ff8c9b33ae893f1368e08a86c2ead58f5969145436bd63ae5f2a3655d364ae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harold Florentino Latortue, PhD")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-479965")[#strong[#text("Harold Florentino Latortue, PhD")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2017")])]

#text("I too use the CAD for precision in the graphic method for precision. I tested it using really arbitrary angle value, like 23.27 degree (possible with autocad). i do not bend any of the rules. Just straightedge and compass. The algebraic analysis using cos(3a) showed that the solutions for the trisections are at the intersects of arc circle when you consider an axe translation for your coordinates systems. (No rule broken).")#linebreak()#text(" Please provide an email address so I can forward you a PDF file.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23f1eccfe747e324133164ca5db3cbf3e9e68eda70519705615f4ad95ccc8364-090bd23601e873e4972d4a12f473caf135f4ec75ce5ad420c1edcf0272887dce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-479969")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2017")])]

#link("mailto:alexkimuya23@gmail.com")[#text("alexkimuya23@gmail.com")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23f1eccfe747e324133164ca5db3cbf3e9e68eda70519705615f4ad95ccc8364-090bd23601e873e4972d4a12f473caf135f4ec75ce5ad420c1edcf0272887dce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-479971")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2017")])]

#text("Dear Prof. HAROLD FLORENTINO LATORTUE. Please use the email above. Got issues with my network connection.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/967fba9fb8002c9ee65c3a890ce25542bea98f453059cb79b6da4c2818d9ebc3-06ff8c9b33ae893f1368e08a86c2ead58f5969145436bd63ae5f2a3655d364ae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harold Florentino Latortue, PhD")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-479973")[#strong[#text("Harold Florentino Latortue, PhD")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2017")])]

#text("sent")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23f1eccfe747e324133164ca5db3cbf3e9e68eda70519705615f4ad95ccc8364-090bd23601e873e4972d4a12f473caf135f4ec75ce5ad420c1edcf0272887dce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-479974")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2017")])]

#text("Thanks. Will have a serious look at the proofs.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5a5eb61cdcb16af02eb94b2973643a1f20eeb0e147d5e54413dc448d0fae1b5-1ee7c8b03ebd4f42fea791fe113383cb7209cfb36210dd9c202a37fffd63ffd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charles Bennett")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-480282")[#strong[#text("Charles Bennett")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2017")])]

#text("As a practical matter, you can do it to within your protractor’s precision by noting that")#linebreak()#text(" 1/3 = 1/2 – 1/4 + 1/8 – 1/16 ……")#linebreak()#text(" and then patiently doing enough alternating bisections to get within the desired tolerance.")#linebreak()#text(" Although algebra class taught me to not waste time on this, I confess that I do think about Morley’s triangles on occasion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-480283")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2017")])]

#text("Charles,")#linebreak()#text(" Actually you can do it with a compass and a straightedge for any arbitrary angle without any iteration with the same precision ad PI = 3.1416 ie with results to 1/1000 (using autocad for measuring the angles) of a degree using the Flatortue Method. ")#link("https://www.slideshare.net/HAROLDFLORENTINOLATO/graphic-trisection-of-an-arbitrary-angle?qid=760850f0-17cf-42f8-b747-01bfbd225113&v=&b=&from_search=1")[#text("https://www.slideshare.net/HAROLDFLORENTINOLATO/graphic-trisection-of-an-arbitrary-angle?qid=760850f0-17cf-42f8-b747-01bfbd225113&v=&b=&from_search=1")]#linebreak()#text(" The acuracy for trisecting the arc is 1/10000 ie. to the 4th decimal point.")#linebreak()#text(" Try it, you will be amazed. Dont get stuck to the idea that it was proven to be impossible to achieve.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23f1eccfe747e324133164ca5db3cbf3e9e68eda70519705615f4ad95ccc8364-090bd23601e873e4972d4a12f473caf135f4ec75ce5ad420c1edcf0272887dce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-480578")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2017")])]

#text("Hi. I invite you all to find out how one can construct all the whole number angles, their multiples and sub-multiples from the link: ")#link("http://homeworkhelpguru.com/mathematics-solutions")[#text("http://homeworkhelpguru.com/mathematics-solutions")]#text(". In this site, the provided tutorials would help one learn not only the classical construction of all whole number angles, but also the construction of the infinitely the many regular polygons, the geometric trisection of all whole number trisectible angles, and much more.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9857f662faaa3eda0061818730257c9ad9171157f73efb33f4311986f5937585-2c74dc1585bf080993aa2eabd5ee7abede77f82ecff554e965dfe3d79f6e9736.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elephant Rock")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-482852")[#strong[#text("Elephant Rock")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2017")])]

#text("Okay, so as embarrassing as it is to be among the cranks submitting yet another solution to a problem shown not to have one, I can’t think of why this very simple seeming proof is not valid, so I’ll post it here. Maybe someone can explain…")

#text("Trisecting a *line segment* is easy. Make two line segments equidistant from and perpendicular to the angle’s vertex by striking an arc from the vertex and joining the intersections. Trisect both line segments on either side of the angle’s vertex. Now draw two lines connecting each third of the opposite trisected line segments such that both lines pass through the vertex.")

#link("https://drive.google.com/a/bookplates.com/file/d/0B0fQ0MCqU054NzJMQWFpRGRUZWM/view?usp=sharing")[#text("https://drive.google.com/a/bookplates.com/file/d/0B0fQ0MCqU054NzJMQWFpRGRUZWM/view?usp=sharing")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9857f662faaa3eda0061818730257c9ad9171157f73efb33f4311986f5937585-2c74dc1585bf080993aa2eabd5ee7abede77f82ecff554e965dfe3d79f6e9736.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elephant Rock")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-482856")[#strong[#text("Elephant Rock")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2017")])]

#text("Oops. I just realized why this ‘proof’ is invalid. The problem with using the trisected line is that it doesn’t project onto the arc without distortion. The center angle will be different than the two sides. Repeating the mistake on the opposite side and connecting through the vertex doesn’t buy anything either. I guess I won’t quit my day job. LOL")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23f1eccfe747e324133164ca5db3cbf3e9e68eda70519705615f4ad95ccc8364-090bd23601e873e4972d4a12f473caf135f4ec75ce5ad420c1edcf0272887dce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-482916")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2017")])]

#text("Hi Elephant Rock")#linebreak()#text(" I looked at your construction results and i could not connect the figures well. However, i must say that, the angle trisection problem is still an open challenge. What importantly people need to put into consideration is the conditions governing the solutions to the problem. Many people (since Wantzel’s time) seemingly overlook the most serious restriction that all classical geometric problems should be solely sought using only two tools: an unmarked straightedge and a compass.")

#text("The compass straightedge construction is such a serious restriction, and from this stem other constraints that: no measurements are allowed, and any geometric procedure should not involve arithmetic. In other words, to proof any geometric problem, one needs to consider that, the solution is deeply inherent from the construction. It has to be geometrical. The angle trisection solution is possible. I cannot, though not a mathematician, call myself a crank. Any one with passion in geometry can solve this problem provided he has the basic classical geometric knowledge. This is the only weapon. I would invite you to have a look at the article: “https://www.academia.edu/33497904/Short_Review_on_Classical_Construction_of_Whole_Number_Angles_and_The_Angle_Trisection_Problem_A_Compass-Straightedge_Construction_”. In this paper, i have discussed much on classical geometric constructions, the construction of all whole number angles, and the relationship between the classical construction of whole number angles and the angle trisection problem. I also have, in brief, shown the relation between classical geometry and the analytical geometry. There are also many other sources containing such information, from research articles to the Euclid’s elements. We have to understand why one has to be careful in saying it is generally impossible to solve a certain problem. How? This is the most difficult task to do on earth. we only can demonstrate, and in any case, we have to illustrate the impossibility to a problem based on the required framework of the solution. For instance, the wantzel’s proof involved both quadratic and cubic equations. This among other problems in the proof make it geometrically invalid.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23f1eccfe747e324133164ca5db3cbf3e9e68eda70519705615f4ad95ccc8364-090bd23601e873e4972d4a12f473caf135f4ec75ce5ad420c1edcf0272887dce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-485216")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2017")])]

#text("Here are some more youtube links: ")#link("https://www.youtube.com/watch?v=JNmlPqmuVIo")[#text("https://www.youtube.com/watch?v=JNmlPqmuVIo")]#linebreak()
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23f1eccfe747e324133164ca5db3cbf3e9e68eda70519705615f4ad95ccc8364-090bd23601e873e4972d4a12f473caf135f4ec75ce5ad420c1edcf0272887dce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-485217")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2017")])]

#text("Please open the videos on youtube for clearity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23f1eccfe747e324133164ca5db3cbf3e9e68eda70519705615f4ad95ccc8364-090bd23601e873e4972d4a12f473caf135f4ec75ce5ad420c1edcf0272887dce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-485834")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2017")])]

#text("Hi guys! Here is my angle trisection solution. In my view, the angle trisection problem is solvable. In-fact in a very simple way. But, before i provide the solution, i think it is good scientists, consider the conditions governing the angle trisection problem. In classical geometry, the use of trigonometry has no space. This only make sense in analytical geometry. Therefore, any solution involving the use of trigonometry, and the other mechanical methods aimed at solving the angle trisection problem are generally wrong. In my view, what maters as Euclid did in his works, is the analogs followed towards the solution. Here, any solution should reasonably agree with the set conventions. i.e, for example, the value of the factor PI is mostly used up to 3.142 accuracy. Having this consideration, i would like to share my paper addressing on the angle trisection problem via the link; ")#link("https://cirworld.com/index.php/jam/article/view/6175")[#text("https://cirworld.com/index.php/jam/article/view/6175")]#text(". Your comments and constructive views are welcomed. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23f1eccfe747e324133164ca5db3cbf3e9e68eda70519705615f4ad95ccc8364-090bd23601e873e4972d4a12f473caf135f4ec75ce5ad420c1edcf0272887dce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-486429")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2017")])]

#text("Hi")#linebreak()#text(" I would like to point out some few things about some of my earlier posts on this blog as follows:")

#text("The above posted video links are specifically based in the construction of all whole number angles, and the trisection of the infinitely many trisectible angles. They are not meant for the angle trisection solution.")

#text("I have made some basic corrections made during the production of the paper available through the link: ")#link("https://www.academia.edu/34455820/The_Angle_Trisection_Solution_A_Compass-Straightedge_Ruler_Construction_")[#text("https://www.academia.edu/34455820/The_Angle_Trisection_Solution_A_Compass-Straightedge_Ruler_Construction_")]#text(",")#linebreak()#text(" which present the angle trisection solution. It the earlier post, on page 6 of the paper, figures 3 and 4 were interchanged during the copy-editing process, which we did not get off during the proofreading stage. In annex-1, the line trisection procedure was misleading and a very important correction has been made. Thank you for those who contacted me on these corrections. Any academician would acknowledge that, paper production comes after the review process. And that, a paper going though a peer-review process does not make it a perfect one. So such basic errors are common. Please download the corrected version of the publication from:")#linebreak()#text(" ")#link("https://www.academia.edu/34455820/The_Angle_Trisection_Solution_A_Compass-Straightedge_Ruler_Construction_")[#text("https://www.academia.edu/34455820/The_Angle_Trisection_Solution_A_Compass-Straightedge_Ruler_Construction_")]#linebreak()#text(" Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23f1eccfe747e324133164ca5db3cbf3e9e68eda70519705615f4ad95ccc8364-090bd23601e873e4972d4a12f473caf135f4ec75ce5ad420c1edcf0272887dce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-489869")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2017")])]

#text("My New solution on Cube Duplication:")#linebreak()#text(" ")#link("https://www.academia.edu/32406599/The_Cube_Duplication_Solution_A_Compass-straightedge_Ruler_Construction_")[#text("https://www.academia.edu/32406599/The_Cube_Duplication_Solution_A_Compass-straightedge_Ruler_Construction_")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/758a93a538abe56cfbde00e95409dac6e3a491f3d125ba2346e3c9f08c34156c-eacab0cee8bbd98506f5af00053377cf1f0c0dc6773d4950b8e69e530782bab3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gary E. Schultz")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-491171")[#strong[#text("Gary E. Schultz")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2018")])]

#text("TRISECTING THE ANGLE")

#text("A call to all geometers of the 3,500 year, Trisect the Angle grand challenge. The dogma of this ages old, false impossibility, is greatly exaggerated. N.B., interested geometers, your impossibility emperor has no clothes, and hasn’t had any for about fifty-two years. And it does not dignify one’s misinformation to demur to the higher and foggier ground of the Galois ethers, as, for example, Pierre Wantzel was want to do in his obviously flawed paper of 1837. We’re in serious need of an update here. And the lowly sixty degree triangle . . . seriously? Read ’em and weep . . .")

#text("Accordingly, it is my great pleasure to introduce to you and the world (and hidden in plain sight all this time since 1966) a man worthy of surely nothing less than the Fields Medal, Mr. Harry Cohen:")

#link("http://www.softouch.on.ca/kb/data/Scan-130117-0005.pdf")[#text("Click to access Scan-130117-0005.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/758a93a538abe56cfbde00e95409dac6e3a491f3d125ba2346e3c9f08c34156c-eacab0cee8bbd98506f5af00053377cf1f0c0dc6773d4950b8e69e530782bab3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gary E. Schultz")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-491173")[#strong[#text("Gary E. Schultz")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2018")])]

#text("Erratum, “And the lowly sixty degree angle . . .”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/758a93a538abe56cfbde00e95409dac6e3a491f3d125ba2346e3c9f08c34156c-eacab0cee8bbd98506f5af00053377cf1f0c0dc6773d4950b8e69e530782bab3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gary E. Schultz")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-491776")[#strong[#text("Gary E. Schultz")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2018")])]

#text("So we have five thumbs-down pinheads, huh? Look, pinheads, I can only give you the information (the link), I can’t give you the brains to understand it. — GES")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c7fd4a36ebf000a3007f2603fa242ce8ba11b91fbc1388b9493f1f7a9abc8c8-368be7813cec06d0a5db2b4b3ae447c7ec188185099c4e8ec834e29627eb1ec8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rainer aus dem Spring")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-491199")[#strong[#text("Rainer aus dem Spring")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2018")])]

#text("Dear Professoer Tao,")

#text("I have not read the whole thread and therefore I am not sure if somebody already mentioned:")

#text("Wantzel did not use Galois theory. Galois’ paper was first published in 1846 – nine years after Wantzel’s paper.")

#text("For a detailed history and elementary proofs of non-constructibility theorems (apart form the transcendence of pi) I recommend:")

#text("Craig Smorynski, “History of Mathematics – A Supplement”")#linebreak()#text(" Springer, 2000")

#text("A really nice book.")

#text("Best regards,")

#text("Rainer aus dem Spring")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28057b336e90ecc17e140df8626265448bd80529b0854a39e2973465d5ff7355-dc048f82d07d9ca6263f3abffab42fcd284ec6444a6c9fc141c7a41e593d682b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Push")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-491457")[#strong[#text("Push")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2018")])]

#text("I can think of an iterative approach to trisect an angle. It is as follows. 1/3 = 1/(1+2)=1/(2 (1+1/2))=(1/2) (1-1/2+1/4-1/8+..) is an infinite series =1/2-1/4+1/8-1/16+…. This implies first bisect the angle. Then bisect the bisected angle. Then bisect the first bisected angle and the second bisected angle. Repeat the process few times till required accuracy based on the series and we can trisect the given angle. One can repeat the same procedure for the other half of the angle.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d67391cf735fa8157e60d955f3d008f006ffa94d587eb36e7b7c35aaed98bcf-cd3dab9084f58c5355ad461a84b0c38df6a4eb440a1575afde97461f0c4a8d36.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nebojsa Mitic")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-492330")[#strong[#text("Nebojsa Mitic")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2018")])]

#text("Attachments")#linebreak()#text(" ")#link("https://www.geogebra.org/m/HQm7WwFk")[#text("https://www.geogebra.org/m/HQm7WwFk")]

#text("on the ruler $AB\\infty{_1}\\infty{_2}$ , raises divider ADC where AB + AB = AC, ruler sets the angle $\\alpha$")#linebreak()#text(" semi-line ruler $B\\infty{_1}$ sliding on point E , the point A of ruler slides semi-line l , when point C is on the line n , we get the radius of the circle , we get the angle $\\beta$")#linebreak()#text(" we have solved the tricection of any angle")

#text("Look at the construction protocol , or find the error if there is ….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb4e34d2cc8c9f25118fbe237d8f41f1c410482630fdc5463a10d18d56d626b2-015365be36cfe5915ff6aec227c5a4217bf81174f62a8813518db0bcde8883c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joc")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-494184")[#strong[#text("Joc")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2018")])]

#text("Dear Terence, why are you not deleting all the useless crank comments? They are just fodder for future cranks to come here and ‘observe’ that no mathematician has ever refuted their ‘terrific’ (more like terrible) claim to fame. Sometimes, freedom of speech gets us nowhere… Besides, they could freely post their junk on their own blog.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-496546")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("Dear Joc")#linebreak()#text(" With the highest degree of respect, allow me to respond to this your post. I am glad to have read your thinking. I understand it is not wise to hijack someones blog, and above all, a respectful blog like this of Prof. Terence.")

#text("I am wondering of few things:")#linebreak()#text(" “why are you not deleting all the useless crank comments?” Why would you advice one on how to manage his blog?")

#text("” They are just fodder for future cranks to come here and ‘observe’ that no mathematician has ever refuted their ‘terrific’ (more like terrible) claim to fame.” Why have you not these terrific claim of fame? Why let someone else do it for you?")

#text("“Sometimes, freedom of speech gets us nowhere” If it was not for freedom of speech, would you have posted on this blog freely as you did? I think there is nothing wrong with freedom of speech.")

#text("“Besides, they could freely post their junk on their own blog.” How would you define your contents in the post. Any information of help? So between the other posts and the contents of your comment, which one is junk? Is this your blog so as to post your feelings and not information in here?")

#text("Please Note:")#linebreak()#text(" I got nothing personal with you. I only have problem with how you cannot control your emotions. I find it healthy when one develops the courage to share a concept in a forum as this.If there is any junk that should never cross the eyes and in the minds of the future generations, through this blog, is your post. You just discourage others without any constructive contribution! How would you feel if you were told you cannot do anything from the capacity of your thinking?")

#text("This is the harm you are causing the future generations. You are among those robbing them the freedom to think. You are among those who just read and believe, and this is destructive i suppose! Your thinking is self defeating in simple terms. If you had good interest on the generations to come, you would have expressed your reasoning in a more academic rigorous manner.")

#text("I do not think anyone is looking for fame in this forum. Those after fame are acting movies.")

#text("So please let people express their thinking. Share their ideas. I would be happy to have my posts as crank. But one thing i am certain of, they are miles smarter than what you post.")

#text("The future generations may be smarter than we are today. They would ponder much about what you write. They will come across your comment and wonder what problems you observed, and what solution you offered. It is just poor one would express emotions that reasoning. I was glad to read your comment.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-496547")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("Hi. I am posting the latest copy of my paper on the angle trisection solution, as published by Journal of Advances in Mathematics. I will soon upload a video on the YouTube exposing the developed algorithms. This paper presents the most accurate, and the most elegant solution on Angle trisection In Universe (The limit of human knowledge) today. I hope it is of much help to those doing their research in the related areas:")

#link("https://www.academia.edu/34455820/The_Angle_Trisection_Solution_A_Compass-Straightedge_Ruler_Construction_")[#text("https://www.academia.edu/34455820/The_Angle_Trisection_Solution_A_Compass-Straightedge_Ruler_Construction_")]

#link("https://cirworld.com/index.php/jam/article/view/6175")[#text("https://cirworld.com/index.php/jam/article/view/6175")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23f1eccfe747e324133164ca5db3cbf3e9e68eda70519705615f4ad95ccc8364-090bd23601e873e4972d4a12f473caf135f4ec75ce5ad420c1edcf0272887dce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex M Kimuya")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-503079")[#strong[#text("Alex M Kimuya")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2018")])]

#text("Hi, with all respect, i hope to present my classical geometric solution to this old ages problem to those who love mathematics, and with good understanding of the subject in here too.")

#text("I have been following the discussion on the trisection of an arbitrary angle problem.In summary:")

#text("A proof to the impossibility is wrong from the beginning to the end. This is my philosophical thinking. To prove an impossibility, one is required to demonstrate at least two thing:")#linebreak()#text(" 1. We need to show that the particular problem does not exist, and so too is its solution.")#linebreak()#text(" 2. We need to show that no human can resolve the problem if it does exist, and that would imply the limitations of our tools, from the classical tools of geometry in the case of the angle trisection, to use of technology.")

#text("First, an attempt to justify these things will just be self defeating. To prove the non-existence of a problem that is already defined in humans knowledge simply show the first mistake in thinking. Second, to prove that a particular problem got no solution and that no human can resolve it is also self defeating. One would should have an infinite capacity of knowledge to justify these claims too. Infact, one is required to have total understanding of the entire universe. This is the initial point of the messy in any proof of impossibility, and so is the Angle Trisection Impossibility proof.")

#text("Almost every scientific concept has some governing conditions. There are those restrictions governing the angle trisection problem, and many other problems in classical geometry:")

#text("That the problems should solely be sought using the classical tools of geometry; compass and unmarked straightedge.")

#text("Other restrictions in way, stem from this condition:")#linebreak()#text(" a. The proposed solution should have a finite number of construction steps.")#linebreak()#text(" b. The construction procedure should not have arithmetic.")#linebreak()#text(" c. There should be no measurements in the described procedure.")

#text("Importantly to observe is that, the construction algorithm should be contained in the confines of the first three postulates of Euclid’s Elements. The solution should have a proof of the concept or the logic employed generating the proposed procedure. This proof should however, be inherent from the construction either. This was the ways of Geometry by the early Greek’s mathematicians.")

#text("Note: A proof should not involve complex trigonometry or any other form of algebra for it to be correct.")

#text("Looking at the proposed geometric impossibility proof in here, is just wrong. It is really not geometrical. Any other form of proof, whether from Galois theory or from whichever area that does not begin from plane geometry is incorrect. We can use the modern speak to describe the problems but one has to be careful that our definitive descriptions of the subject is not aimed at tweaking people into the wrong understanding of the concept.")

#text("Any one who understand Euclidean geometry would agree with me. However, use of algebra is simply analysis.It is healthy. Having said the impossibility proof to the angle trisection solution is wrong and not valid to hold allegiance in stating the angle trisection problem as impossible, we now have to look at the other side of the coin. The problem require a solution and not just any solution. Since we are in a practical universe, we have to consider the accuracy of the work to hit meaningful degree. For example, 1/1000. In this, we would avoid what the skepticals call an eyeballing construction.")

#text("Exactness is just theoretical. No one would show exactness. Those immune to this reality can give an explanation of what they mean by exactness in practical geometry.")

#text("The solution: Having written this little i share to you some few video clips showing my shortest and most elegant general solution to the angle trisection puzzle. It obeys all the classical geometric conditions. No measurements not any adjustments. The solution too has two important conditions, that when understood one would accept the facts.")

#text("Follow the following YouTube Links to access the videos:")

#text("Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe0ef876daa22fb724efbaa7c962b52d6334dec420920635dd68181527d2d492-9cd33212bfc809c0c4dd901da1651b7446a896e94ae70c7ae696149a8b6f2587.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-503083")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2018")])]

#text("Reading your “Note: A proof should not involve complex trigonometry or any other form of algebra for it to be correct.” it reminds me this video:")

#text("Pity, you should have seen this when you were much younger or long time ago, you would have been somewhere else by now.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23f1eccfe747e324133164ca5db3cbf3e9e68eda70519705615f4ad95ccc8364-090bd23601e873e4972d4a12f473caf135f4ec75ce5ad420c1edcf0272887dce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex M Kimuya")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-503092")[#strong[#text("Alex M Kimuya")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2018")])]

#text("HI,")#linebreak()#text(" I think something is not clear here. And this could be the reason for the misunderstanding if am correct. First, this video clip is immaterial in this context. And if it makes some sense, it only depicts your understanding of my post, and the entire problem of the angle trisection.")

#text("Before i respond to you, let me point something out here:")

#text("My posts are not meant to harm anyone, but ti convey a concept. So no need to act emotionally. Your pity cannot work against a reality. If i am wrong, correct my contents.About where i am, or what i am, it is not at all important here too. As a fact, i am not that young and nor am i that old. I am comfortable with what i do too so let this not bother anyone like you. Let us speak and write science.")

#text("Back To Your Video")

#text("Analyzing what the physicist is saying, the general thing is understanding what problem in particular one is working on. But, this make no sense because it has no connection to:")#linebreak()#text(" “Note: A proof should not involve complex trigonometry or any other form of algebra for it to be correct.”")

#text("If it makes meaning here, it simply means the person not understanding the thing is you. Remember i have not created any rules and my argument is based on rules established may years possibly before even you, came to exist In simple terms, i meant that a proof does not have to be complex for it to be credited correct.In the case of Angle Trisection, it has to be inherent from the construction, and well geometrically founded before we introduce any other form of analysis. I am not against use of Algebra, but, if it is applied in a misleading manner that has to be refuted.")

#text("I got much understanding of Algebra too but what is the sense of using complex mathematics unnecessarily? The solution require to be proven geometrically. I also understand the angle trisection problem well so if there is someone lost in this context it probably could be you and any other person, with no proper reasons, is believing the impossibility proofs.")

#text("The fact that something is said by a renowned person, it does not mean it is final and no other human can talk about it. Some of the things from these people are not proven. When you post a video clip with just non-scientific statements and expect people to fear thinking is just waste of time and energy. People see the problems in the angle trisection impossibility proof. To justify this i refer you to this very blog: Why did Prof Terence Tao attempt a geometrical approach to justify the impossibility proof?")

#text("I acknowledge his approach and it simply shows Wantzel’s proof is not geometrical in the first place.")

#text("I hope you get sense as to why you need to redeem back your freedom of thinking and stop believing we possibly can proof impossibilities. We got much to do in science to change this planet for and make it better for the coming generations. Otherwise with people of your type, we wont progress. I could much appreciate if you posted your own video clip countering my arguments. Else, it just shows how poor some people are. A statement that can not be supported make no sense at all. Stop thinking you can create fear to the young researchers.")

#text("Thanks.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23f1eccfe747e324133164ca5db3cbf3e9e68eda70519705615f4ad95ccc8364-090bd23601e873e4972d4a12f473caf135f4ec75ce5ad420c1edcf0272887dce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex M Kimuya")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-503283")[#strong[#text("Alex M Kimuya")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2018")])]

#text("The Cube Duplication Solution")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-505948")[#strong[#text("Miller’s Quadsector Theorem – Glimpses of Infinity, Reminders of Reality")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2018")]

#text("[…] went for quadsectors instead – bisect and bisect again. (fascinating and unknowing nod to the futile attempts to trisect an angle using straight-edge and compass). Excitement fizzed around the room at the new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f53df5c4c335f39865749c7a274a7b7f4ad3c0fdf42ab4feebbfbc5ffbaafbb-7a985783f1d3808a67f06fadf6e7aa525083b17d8fde516e9e75e77a3b90a2f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nest")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-509541")[#strong[#text("Nest")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2018")])]

#text("What if the exception trisection of a straight angle could be used as a benchmark to trisect any angle?")#linebreak()#text(" In your Gallois-Wantzel demonstration you did not explain the nature of exceptional angles.")

#text("Is it possible to demonstrate that using a pi/2 angle as trisection benchmark is not a door to trisecting any angle?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-509576")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2018")])]

#text("Actually, the set of “trisectable angles” (i.e. that can be trisected by straightedge and compass – which is equivalent to be constructible from the integers using only finitely many four basic arithmetical operations and square root extractions) contains (but not limited to) all the angles of the form ")#mi("(3 m/2^n) \\pi")#text(" where ")#mi("m, n")#text(" are positive integers.")#linebreak()#text(" Which implies that this set of “trisectable angles” is dense in ")#mi("[0, \\pi]")#text(".")#linebreak()#text(" It would be interesting to give a more explicit characterization for this exceptional set of “trisectable angles” .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66313b46d573daf541af63e7dcf5be5f84b9b29e473f97c17ba1830c199e76f9-44906ace71b97b56f82a3ccc54d22ced02a790a0f717115e7b70a0b48d6f19dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Mangel")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-512940")[#strong[#text("Richard Mangel")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2019")])]

#text("Start by constructing a circle, then construct a circle atop the first circle, construct one vertical line through the center’s of the circles, then draw horizontal lines through the circles. Connect the south point of the bottom circle with the west point of the top circle. The left radius of the circle is cut in one-third and two-thirds, respectively.")#linebreak()#text(" To trisect an angle, increase the circles up, as many as you want, then above for odd reciprocals, fill circles with additional circles with horizonal tangents where circles meet. (All circles have radius of one.). Angles are addition of angles. Only need. . . . Proportional sides, take square root. Get trigometric answer to lower angle of right triangle by looking up in trig table, or do the division. Add this to simple angle such as seven and one-half, twelve and one-half,etc. This sum of angles is the unknown angle. To then trisect the known angle, cut pieces of pie into fractional parts need not be degrees. Add parts as needed. he.1 2 1/2 + 7 1/2 equals 20 parts. 33 1/3 + 33 1/3 + 33 1/3 equals 100 percent of the 360 degree pie.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-517104")[#strong[#text("Fermat Primes and the Gauss-Wantzel Theorem - AMSI Vacation Research Scholarships 2018/19")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2019")]

#text("[…] ")#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection&#8230")[#text("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/508d48ab60a85f3c1ff059bdb0213beb4224cf6ff68c7452088320768a1ddd90-7828f21534444e286aa5af0a26c336966c77b36191ec217de8d16ac9fadc1156.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Robinson")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-517375")[#strong[#text("Joshua Robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2019")])]

#text("I Trisected any angle and it looks like ur proofs")

#link("https://www.youtube.com/channel/UC0pmyIMkgexU3vtvTFUSMfw")[#text("https://www.youtube.com/channel/UC0pmyIMkgexU3vtvTFUSMfw")]

#text("Please look.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d90807d654eea401771b24596c3a34d8879c60169791aee402b134cfd2ea79e-8581814a352cc80914ff5161328fdd0c37474bdaf5d6a189dcfa1617f8aa4ff8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of paulsancheski")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-517392")[#strong[#text("paulsancheski")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2019")])]

#text("By Jove, I think you’ve got it! But will have to review further …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d90807d654eea401771b24596c3a34d8879c60169791aee402b134cfd2ea79e-8581814a352cc80914ff5161328fdd0c37474bdaf5d6a189dcfa1617f8aa4ff8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of paulsancheski")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-517448")[#strong[#text("paulsancheski")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2019")])]

#text("Sorry, Joshua, but we have to call off the parade. A trigonometric analysis applying your method to a sixty-degree angle indicates your trisectors are around 20.104-degrees from the angle arms, off by a little over a tenth of a degree. Good try. Have a cigar anyway.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/014d7135a664ed1de4c395113a9a5ba0d7e057f16225087cf08f0cdd6a114cd7-021040a8bd0c5b2c2e3366a44451d18d9831f8287fdb91e83900bc55152859ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Foundations of Arithmetic")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-522331")[#strong[#text("Foundations of Arithmetic")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2019")])]

#text("Is it possible any modern tools in arithmetic can say anything about ‘Suppose that a linear time Turing Machine computes the first {n} digits of the real number {r} in base ten. Then, the number is either a rational number or a transcendental number’ mentioned in ")#link("https://rjlipton.wordpress.com/2012/06/15/why-the-hartmanis-stearns-conjecture-is-still-open/")[#text("https://rjlipton.wordpress.com/2012/06/15/why-the-hartmanis-stearns-conjecture-is-still-open/")]#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ae8c8cb7f60f2b3cb2c29e6544f25e8031aae026990660dd9236f5c40ac0f66-bdb7f12e8e4fb17087d5bf185bdd42d3760c1e3f7888f6a0116df46196e92717.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Foundations of Arithmetic")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-522348")[#strong[#text("Foundations of Arithmetic")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2019")])]

#text("Also ")#link("https://rjlipton.wordpress.com/2009/02/24/a-conjecture-of-hartmanis/")[#text("https://rjlipton.wordpress.com/2009/02/24/a-conjecture-of-hartmanis/")]#text(" and ")#link("https://rjlipton.wordpress.com/2012/06/04/transcendental-aspects-of-turing-machines/")[#text("https://rjlipton.wordpress.com/2012/06/04/transcendental-aspects-of-turing-machines/")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7076d830831bf0484f4c5f9d66bad6232b033c7c589ea72da68736b119577956-35e2a144f275d321794e11c4a366e5cc093d79e85d80c116c9d8e1d658c43336.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Foundations of Arithmetic")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-522407")[#strong[#text("Foundations of Arithmetic")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2019")])]

#text("This also appears interesting ")#link("https://mathoverflow.net/questions/288911/any-proved-connection-between-roth-theorem-and-hartmanis-stearns-conjecture")[#text("https://mathoverflow.net/questions/288911/any-proved-connection-between-roth-theorem-and-hartmanis-stearns-conjecture")]#text(". This is the fundamental reference ")#link("https://fi.ort.edu.uy/innovaportal/file/20124/1/60-hartmanis_stearns_complexity_of_algorithms.pdf")[#text("https://fi.ort.edu.uy/innovaportal/file/20124/1/60-hartmanis_stearns_complexity_of_algorithms.pdf")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7076d830831bf0484f4c5f9d66bad6232b033c7c589ea72da68736b119577956-35e2a144f275d321794e11c4a366e5cc093d79e85d80c116c9d8e1d658c43336.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Foundations of Arithmetic")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-522411")[#strong[#text("Foundations of Arithmetic")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2019")])]

#text("Summary ")#link("https://www.cs.auckland.ac.nz/research/conferences/wtcs2012/resources/Freivalds-Rusins.pdf")[#text("https://www.cs.auckland.ac.nz/research/conferences/wtcs2012/resources/Freivalds-Rusins.pdf")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of real analytic")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-522389")[#strong[#text("real analytic")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2019")])]

#text("The simplest application of this method, which was also done to avoid field theory, is JH Conway’s meta-proof that there is no “direct” solution of the Steiner-Lehmus problem (to show that equal angle bisectors imply equal sides in a triangle).")

#text("The S-L theorem is false over general fields, which is a field theoretic argument that there is no proof by equality chasing. Indeed the usual proofs rely on order properties of the positive reals; they proceed by case analysis to rule out a > b and a < b, rather than proving a=b directly.")

#text("Conway replaced field theory by R-to-R analytic continuation, passing points through each other, again with complexification as the tacit justification. The continuation allows some of the side lengths to flip sign and exchanges interior and exterior angle bisectors, resulting in a configuration where the analytically continued interpretation of the statement becomes false.")

#text("On the other hand the inequality arguments do work in intuitionistic logic, without having to do case analysis based on Excluded Middle, so this still leaves the problem of rigorously specifying what constitutes a \"direct proof\".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0fa130dcf5ca1f8b44d83f1054a47f92ba324a8322bd36b182199eebf6094134-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ronald Davis")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-525739")[#strong[#text("Ronald Davis")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2019")])]

#text("With ten nickels, make an equilateral triangle. From the center point of a corner nickel imagine two radiated lines from there, radiating out through the two points where the row of three, touch, and beyond… add the two triangle lines, on the outside headed in the same direction and Wallah, you just trisected your first triangle. To trisect other angles send me an email and I will send you… How To trisect.. Or just think about the geometry of when lines radiate to a point, and radii is doubled as perpendicular lines one, to two, to four… (and clear to six and nine, which divide by threes nicely); it make radiated lines spread outward… but there is also a 3 in-between 2 and 4, when radiating… I really can trisect an angle! …Look at your four finger with one eye, and imagine three lines from your eye out through the cracks between your fingers… “read between the lines as they say, four fingers, but three lines! I am almost 81 years… So I’m giving this Info., away to all… [However I do have my date for creativity covered, for how I trisect] I have other stuff if you like Physics and Geometry, that got lost, or too quickly passed in Classical Physics… Ron Davis ")#link("mailto:radpressure@gmail.com")[#text("radpressure@gmail.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-534253")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2019")])]

#text("Ive solved it, but not for all angles,, any one interested, ill send it to you .The question is what can u use it for. ")#link("mailto:markusbolin@gmail.com")[#text("markusbolin@gmail.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/665ffb6667f1160eebd0204c87dd675799c8396e9bf0bada5354e04c790483d0-846bdcf581a4a17164c3dcdd41114b335d23d96cd173b01327e8f1adafab5f6e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fernando mancebo")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-564214")[#strong[#text("fernando mancebo")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2020")])]

#text("I think angle trisection is very easy and fast only with compass.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab89c794112eb17e27ea31bb778defe72cb439d4450c31cfc3dd54f124a373b1-a40abfb775d8a56af6fb85236a23c629dc9a842015c8c5d5ea3e935fed7eb38a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Taha M. Muhammad")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-582834")[#strong[#text("Taha M. Muhammad")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2020")])]

#text("I trisected angles. Please look at you tube.")#linebreak()#text(" I’m using the same method which is 1, 2, 3 and Trisecting angles of 0 to 360 degrees.")#linebreak()#text(" I am not deviding 2 by 3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-610581")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2020")])]

#link("https://www.facebook.com/photo?fbid=1803820016439648&set=a.397252653763065")[#text("https://www.facebook.com/photo?fbid=1803820016439648&set=a.397252653763065")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a474a2954360efecb5ae4ffca9f1da1667332bba7d2fd0de36a34a646a7d1096-59a12bc0abd4a2eac43ac9b84015872da39a13aa6e84b9332c4d065c9c6148d8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luis Martinez")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-640085")[#strong[#text("Luis Martinez")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2022")])]

#text("GEOMETRIC PROOF of the 60º angle trisection with ruler and compass.")

#text("The trigonometric expression is determined in the form:")

#mi("cos \\frac{\\theta}{3} = \\frac{a^{2} + b^{2} - \\left(\\frac{c}{3}\\right)^{2}}{2ab}")

#mi("cos \\theta = \\frac{2a^{2} - \\left[3\\left(\\frac{c}{3}\\right)\\right]^{2}}{2a^{2}}")

#text("With c opposite side to the angle to be trisected.")

#text("It includes:")

#text("Method to split any segment into three ( with compass).")#linebreak()#text(" Method to multiply any angle (with compas)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5922b3facde3193fc1a9e13128799080680445aa5c225ccd2bb133424ca39b80-78ded3cb73b31a6d853771b42c3981300acedc487109271c6f8b8b0c1e102244.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mahesh R Bubna")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-658607")[#strong[#text("Mahesh R Bubna")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2022")])]

#text("After putting 40-42 years efforts I have been to trisect an arbitrary angle to an unprecedent/ miraculous approximation, that too, using only a compass and an unmarked straight edge with 9-10 finite easy steps, for example")#linebreak()#text(" 30° to 10.000000°")#linebreak()#text(" 36° to 12.000000°")#linebreak()#text(" 40° to 13.333333°")#linebreak()#text(" 45° to 14.999999° and so on…..")#linebreak()#text(" The images of the above are ready for uploading…..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a474a2954360efecb5ae4ffca9f1da1667332bba7d2fd0de36a34a646a7d1096-59a12bc0abd4a2eac43ac9b84015872da39a13aa6e84b9332c4d065c9c6148d8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luis Martinez")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-672471")[#strong[#text("Luis Martinez")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2023")])]

#text("The Trisection method for the rule and the compass, the 20º angles is defined in the triangle of sides (")#mi("k_{1}p; k_{1}m; mp)")#text(".")

#text("By trigonometry:")

#block(width: 100%, above: 12pt, below: 14pt)[#set par(justify: false)
#text(size: 7pt, fill: rgb("596477"))[#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/#comment-672471")[Source formula could not be rendered.] ] #text(font: "DejaVu Sans Mono", size: 7.5pt, "cos\\frac{60}{3} = \\frac{(\\frac{k_{1}p)^{2} + (mp)^{2} - (\\frac{k_{1}m}{3})^{2}}{2[k_{1}p * mp]}")]

#mi("cos\\frac{60}{3} = \\frac{(frac{1665}{1728})^{2} + (\\frac{17}{18})^{2} - (\\frac{1}{3})^{2}}{2[\\frac{1665}{1728} * \\frac{17}{18}]} = 0,93915....")

#text("The greater the value of (x) in ")#mi("k_{1}p")#text(" the greater the number of decimal places with its absolute value (see youtube vedeo).")

#text("And")

#mi("cos\\frac{90}{3} = \\frac{(\\frac{801}{864})^{2} + (\\frac{8}{9})^{2} - (\\frac{\\sqrt{2}}{3})^{2}}{2[\\frac{801}{864} * \\frac{8}{9}]} = 0,8660536.....")

#text("The greater the value of (x) in ")#mi("k_{1}p")#text(" the greater the number of decimal places with its absolute value.")

#text("Professor Tao: As a math genious, I hope the you so proceed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5922b3facde3193fc1a9e13128799080680445aa5c225ccd2bb133424ca39b80-78ded3cb73b31a6d853771b42c3981300acedc487109271c6f8b8b0c1e102244.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mahesh Bubna")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-672476")[#strong[#text("Mahesh Bubna")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2023")])]

#text("The new is that 99.99â approximation that too by using only a compass and an unmarked straightedge with 5-6 ascertain steps is first time in last 2250 years and that has become possible by only and anly one method invented by me.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-672482")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2023")])]

#text("This comment could be written only by a very modest person!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luis martinez")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-673737")[#strong[#text("luis martinez")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2023")])]

#mi("cos\\frac{60}{3} = \\frac{(k_{1})^{2} +(mp)^{2} - (frac{k_{1 }m)}{3})^{2}}{2[k_{1}*mp]}")

#text("where: ")#mi("a=1; x= \\neq 2")

#mi("k_{1}p = a-k + \\frac{k}{3} +\\frac{\\frac{k}{2}- \\frac{k}{3}}{4^{x}}")

#text("With a = 1 and x = 2 we have:")

#mi("cos\\frac{60}{3} = \\frac{(\\frac{1665}{1728})^{2} + (\\frac{17}{18})^{2} - (\\frac{1}{3})^{2}}{2[\\frac{1665}{1728} * \\frac{17}{18}]} = 0.93915....")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5922b3facde3193fc1a9e13128799080680445aa5c225ccd2bb133424ca39b80-78ded3cb73b31a6d853771b42c3981300acedc487109271c6f8b8b0c1e102244.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mahesh Bubna")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-673771")[#strong[#text("Mahesh Bubna")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2023")])]

#text("Yes, I know that exact trisection of a given angle is impossible. But what about the MRB method, invented by me, which (using only a compass -straightedge) gives 99.99+â approximation.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luis Martinez")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-674661")[#strong[#text("Luis Martinez")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2023")])]

#text("The root of ")#mi("\\sqrt{pi}")#text(" with ruler and compas by (ENFER DIEZ).")#linebreak()#text(" Today sunday one day amomg many open minds.")

#text("With the segment ")#mi("\\sqrt{2}")#text(" and unit; the root of ")#mi("\\sqrt{pi}")#text(" is determine in the form:")

#text("$latex\\sqrt{\\pi} = 6 – 3\\sqrt{2} + \\frac{6 – 4\\sqrt{2}}{3^{3}} + 2\\left[\\frac{6 – 4\\sqrt{2}}{3^{5}}\\right]$ –")

#mi("\\frac{6 - 4\\sqrt{2}}{3^{5}*2^{2}} - \\frac{6 - 4\\sqrt{2}}{3^{6}*2^{2}} + \\frac{6 - 4\\sqrt{2}}{3^{7}*2^{2}}")#text(" –")#linebreak()#text(" $\\latex\\sqrt{\\pi} = 6 – 3\\sqrt{2} + \\frac{6 – 4\\sqrt{2}}{3^{3}} + 2\\left[\\frac{6 – 4\\sqrt{2}}{3^{5}}\\right] – \\frac{6 – 4\\sqrt{2}}{3^{5}*2^{2}}$ – ")#mi("\\frac{6 - 4\\sqrt{2}}{3^{6}*2^{2}} + \\frac{6 - 4\\sqrt{2}}{3^{7}*2^{2}} - \\frac{6 - 4\\sqrt{2}}{3^{8}*2^{3}}")#text(" –")#linebreak()#text(" ")#block(width: 100%, above: 12pt, below: 14pt)[#set par(justify: false)
#text(size: 7pt, fill: rgb("596477"))[#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/#comment-674661")[Source formula could not be rendered.] ] #text(font: "DejaVu Sans Mono", size: 7.5pt, "\\frac{6 - 4\\sqrt{2}}{3^{8}*2^{6}} + \\frac{6 - 4\\sqrt{2}}{3^{8}*2^{11}} + \\frac{6 - 4\\sqrt{2}}")]#linebreak()#text(" {3^{8}*2^{13}}$ +")#linebreak()#text(" ")#mi("\\frac{6 - 4\\sqrt{2}}{3^{8}*2^{16}} + \\frac{6 - 4\\sqrt{2}}{3^{8}*2^{18}} + \\frac{6 - 4\\sqrt{2}}{3^{8}*2^{22}} - \\frac{6 - 4\\sqrt{2}}{3^{9}*2^{22}}")#text(" –")#linebreak()#text(" ")#mi("\\frac{6 - 4\\sqrt{2}}{3^{9}*2^{26}} - \\frac{6 - 4\\sqrt{2}}{3^{9}*2^{30}} - \\frac{6 - 4\\sqrt{2}}{3^{12}*2^{30}} + .... = 1,77245385090551557....")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-675044")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2023")])]

#text("I recommend the book:Solving problem in Number Theory and Geometry.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luis Martinez")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-675088")[#strong[#text("Luis Martinez")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2023")])]

#text("As last information; the third problem.")

#text("The ")#mi("\\sqrt[3]{2}")#text(" with ruler and compas:")

#mi("\\sqrt[3]{2} = \\sqrt{2} - \\left[\\frac{8\\sqrt{2} - 11}{2} - \\frac{17-12\\sqrt{2}}{12*3^{n}}\\right]")

#text("With n = 2")

#mi("\\left[\\sqrt{2} - \\left[\\frac{8\\sqrt{2} - 11}{2} - \\frac{17-12\\sqrt{2}}{12*3^{2}}\\right]\\right]^{3} = 2,000535....")

#text("The greater n is, the greater the number of zeros.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Md Mahabub Alam")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-675614")[#strong[#text("Md Mahabub Alam")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2023")])]

#text("It is possible trisection any angle by compass. It’s possible for me.plesse help me for published it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-2/#comment-682794")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2024")])]

#text("I, Mahesh R Bubna, has been successful in trisecting an arbitrary angle by using only a compass and straightedge to the approximation correct up to 6+ decimals.")#linebreak()#text(" One can refer Angle Trisection by Mahesh R Bubna on LinkedIn.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-65774")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2011")])]

#text("Nice argument! I’m just a little confused about how you’re stating Corollary 3. As far as I know, this is true in all characteristics and follows directly from the fact that dimension is multiplicative in towers, with no need to appeal to Galois theory.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-65794")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2011")])]

#text("Hmm, you’re right. (I thought one needed to ensure the big field was Galois in order for it to contain the full splitting field of the cubic extension, but now that I think about it, this is unnecessary for the argument.) I’ve reworded the text accordingly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22b170fc060b3b1318da816c8eb6476d1ba934217e2d5b3b0e140a7f88ad1e57-f58fdaed3d78a76af96dfd8f41cd15c1ffe59bb456c4a339521ff20c9303627c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Murat Emiroglu")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-474358")[#strong[#text("Murat Emiroglu")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("Mr. Tao, my father has worked on this problem – trisection of an angle with straightedge and compass – on and off almost all his life, he is 85 years old. I have been reviewing his different approaches and solution proposals to this problem for over 25 years, and I have always been able to find some inconsistency or something that cannot be proven after thoroughly reviewing his solution proposals until recently. Currently he has a solution proposal that I could NOT find anything wrong, no matter how hard I tried. I wanted to present this to a mathematician such as yourself who will not dismiss a solution without even reviewing it and simply by referring us to the Galois theorem having proven that it is impossible to trisect and angle. You seem to have taken on this issue and attempted to prove the impossibility of trisecting an angle with straightedge and compass using geometry, not trigonometry. Seeing your proof above made me hopeful that you might be one of the very few mathematicians who wouldn’t mind – (perhaps even show interest in) spending a few minutes on my father’s pure geometric solution proposal. It is a 10-11 step simple solution. If you read this and you have a few minutes to review the solution please email me. Best Regards.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22b170fc060b3b1318da816c8eb6476d1ba934217e2d5b3b0e140a7f88ad1e57-f58fdaed3d78a76af96dfd8f41cd15c1ffe59bb456c4a339521ff20c9303627c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Murat Emiroglu")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-474359")[#strong[#text("Murat Emiroglu")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("By the way I must add the proposed solution is for trisecting a 60 degree-angle with straightedge and compass. regards,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-475954")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2016")])]

#text("60 degrees is no problem. It’s trisecting a general angle that’s the impossible one.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22b170fc060b3b1318da816c8eb6476d1ba934217e2d5b3b0e140a7f88ad1e57-f58fdaed3d78a76af96dfd8f41cd15c1ffe59bb456c4a339521ff20c9303627c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Murat Emiroglu")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-475958")[#strong[#text("Murat Emiroglu")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2016")])]

#text("No, trisecting a 60-degree angle is the problem. If one can achieve that then there is a problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-475989")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2017")])]

#text("IIRC, Courant and Robbins’ wonderful book “What Is Mathematics?” has an elementary proof that a 60 degree angle can’t be trisected. It uses simple algebra to show that the tangent (or maybe it was sin or cos) of a 20 degree angle involves the cube root of something. I read the book in high school and don’t remember how or whether it proved that cube roots weren’t constructable but just showing its presence was convincing to me at the time. (I didn’t know any Galois theory then, but it’s in some way obvious that compass constructions only give quadratic extensions and you can’t get a cube root that way).")

#text("There’s a famous article by Underwood Dudley called “What to do when the trisector comes”:")

#link("http://web.mst.edu/~lmhall/WhatToDoWhenTrisectorComes.pdf")[#text("Click to access WhatToDoWhenTrisectorComes.pdf")]

#text("It describes communications from people who say they’ve found trisection constructions, and mentions they are almost all quite elderly. Murat Emiroglu’s father fits this pattern, I guess.")

#text("Per the article and per the biography ")#link("https://en.wikipedia.org/wiki/Underwood_Dudley")[#text("https://en.wikipedia.org/wiki/Underwood_Dudley")]#text(" , Dudley has written a book about trisectors, and had been collecting examples of trisections for a long time when the article was published in the 1980s. He’s apparently still around, but quite old and probably retired.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-476001")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2017")])]

#text("It is not difficult to show that ")#mi("2 \\cos 20")#text(" degrees is a root of the cubic equation ")#mi("x^3 -3 x -1 =0")#text(" (the remaining conjugate roots are ")#mi("-2 \\cos 40")#text(" degrees and ")#mi("-2 \\cos 80")#text(" degrees).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92de18753b09812cfe78cbce04b76697dc7573ea3c4722016f2b8a9b4502f3a4-5e12eff0f87d0e218c957596559df00bf9c36b15eba61d0bb1667c6f3b57e4e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit Nair")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-65779")[#strong[#text("Sujit Nair")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2011")])]

#text("You might also be interested in the following book.")

#link("http://www.springer.com/mathematics/algebra/book/978-1-4020-2186-2")[#text("http://www.springer.com/mathematics/algebra/book/978-1-4020-2186-2")]

#text("V. I. Arnold uses monodromy of curves on Riemann surfaces of functions representable by radicals to prove the Abel–Ruffini theorem. It is a very “beautiful” argument :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-65800")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2011")])]

#text("Thanks for the reference, which I was not aware of! From a cursory inspection it does indeed seem that the argument here (based on replacing Galois groups by monodromy groups) is essentially the same as Arnold’s, though in a slightly different context.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f28d5d37b3a0f3fe81d5f01b1c2d6f3f9f707172720c901de22d46e10af9527c-472c85474a41f9b4626e6c74432d521a2a1f66955a0936ef5b4f9be017e35110.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron Sheldon")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-65804")[#strong[#text("Aaron Sheldon")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2011")])]

#text("Does the initial assumed contradiction need to be: there exists an angle that can be trisected?")#linebreak()#text(" This is the logical negation of: no angle can be trisected")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c3a772c747b02c97fe77e7fba737276af356d9f58c890701bc4c1aa6063bee8a-6f4cd9492084508d3b176c729cfca93bb4776dda629f0d16c3393ae99f008aae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Franciscus Rebro")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-65813")[#strong[#text("Franciscus Rebro")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2011")])]

#text("Seems to me the assumption up for contradiction is that ANY angle can be trisected, i.e. there exists some construction which will trisect angle CAB as C sweeps around A in a circle (except for possibly some of those points leading to removable singularities).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-65854")[#strong[#text("The only post whose title I understand… « Definitely Maybe")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2011")]

#text("[…] time, but awkwardly, today is the ONLY blog post whose title I understand…Here is the blog on angle trisection by straightedge and compass, a primary-school geometry theorem for Chinese […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2b61804d937f822fcbbc774f9d79658fb5e075d3fb9c12ff2edb60fed59f9d2-1337f42511aa25b086459fe2ea7f1a2706fc6533b54d978373c714bcecce799a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of paramanands")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-65865")[#strong[#text("paramanands")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2011")])]

#text("Very wonderful proof indeed. Even if we leave the “details” part the proof is very convincing to a reader who is at high-school level. I wonder if many other advanced theorems of mathematics in general could be proved using ideas within the realm of high-school mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec7c6b0e3060e1c806f619bf4b492030a739cda006aaf0a178402739ff75194-2c3659f7497f4bb1cf1e6e85fafd68a9d10b53737c2f3b03f29c35b080ae39ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-65866")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2011")])]

#text("Of course some angles can be trisected — 180 degree angles, for example. Or 0. The traditional one to prove impossible is 60 degrees.")

#text("Just to be an ungrateful jerk, Terry, I want to suggest that the right way to encompass (ha!) the first half of that exposition is with a _movie_ of the monodromy. Of course, there should be scary music as you pass through the removable singularity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-65867")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2011")])]

#text("Yes, 60 degrees is indeed the traditional example of a non-trisectable angle, though I don’t see a way to adapt the monodromy argument to show that this specific angle cannot be trisected, so I decided to omit this example from the discussion.")

#text("A movie (or at least an animated image) would indeed be the best way to illustrate the process, but I don’t have the experience to make such a thing. Of course, if another reader would volunteer to make such an image (with or without scary music), that would be much appreciated :-) ")#emph[#text("[Edit: it also occurs to me that an applet would also do the job nicely. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of math_reader")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-66365")[#strong[#text("math_reader")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2011")])]

#text("I’d like to recommend the excellent free program called geogebra ")#link("http://www.geogebra.org/cms/en")[#text("http://www.geogebra.org/cms/en")]#text(" which allows to create easily so-called dynamic worksheets which are simply animated applets. It is used by many high school teachers worldwide and should be well-suited to your needs here. In particular the page of their wiki contains lots of examples ")#link("http://www.geogebra.org/en/wiki/index.php/English")[#text("http://www.geogebra.org/en/wiki/index.php/English")]#text(" Finally their forum is very active (e.g. to provide help with installation on linux).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of math_reader")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-66428")[#strong[#text("math_reader")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2011")])]

#text("Addendum: of course there’s also a nice youtube channel with lots of advanced tutorials ")#link("http://www.youtube.com/geogebrachannel")[#text("http://www.youtube.com/geogebrachannel")]#text(" and I’ve just found this other nice video tutorial to get started and save as a java applet ")#link("http://www.youtube.com/watch?v=SVSNHhCeukw")[#text("http://www.youtube.com/watch?v=SVSNHhCeukw")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a1ceca4ab0b1fcbf27a16f4ea6c66c5807d84453cc115edafb4a63701d61d716-510eddb40e31ec7a3a2aaac440c90ea9dd260a17dabc205fb126e7c5853ecb1e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of azjps")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-66477")[#strong[#text("azjps")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2011")])]

#text("I took the liberty of creating such an animation in GeoGebra, minus the music: ")#link("http://imgur.com/a/N3pvo")[#text("http://imgur.com/a/N3pvo")]#text(" (the red figures being those of period 2).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-66484")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2011")])]

#text("Thanks! (it seems that it is the green figures that are of period 2, rather than the red ones, though. In any event, colouring objects by their period is a neat idea.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bddd181c7452ccf8409ff77f22949c43b1a485779f75a3e8efe0b148508168dc-af78555bc712cb6764f9ef7d116868691c2451a4599c66021031af7814047f8b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of WAYNE")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-206512")[#strong[#text("WAYNE")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2012")])]

#text("check out: ")#link("http://www.math.umbc.edu/~rouben/Geometry/trisect-baker.html")[#text("http://www.math.umbc.edu/~rouben/Geometry/trisect-baker.html")]#linebreak()#text(" Rouben may help with your applet")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b1af1467332c044b32fef284f74a15e5e0b92a5ab33bd6559de953169e35dba6-7016c2facdd4edbda653da370c7176b83d8130e5c4de046415caa5df1c3f6c84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Zelinsky")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-65919")[#strong[#text("Joshua Zelinsky")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2011")])]

#emph[#text(" (This was undoubtedly be one reason why, even after Wantzel’s impossibility result was published, a large amount of effort was still expended by amateur mathematicians to try to trisect a general angle.)")]

#text("I think there’s a typo here- “be” seems to be unnecessary. Also I suspect that this is not the major reason for why amateurs expended and still expend some work trying to trisect. This is not the only example where crankish or simply very amateur individuals try to do something that has been proven to be impossible. The most obvious such example is those who want to get a 1-1 correspondence between the integers and the reals. There are a lot of them. And yes, Cantor’s proof that you can’t is really quite straightforward.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6dec8f58344fa3fe134ef4213036fcaf9afae0971122e1c47aee4a9b906906ed-b110cf76e37b1925ab6768195638d885706979ea75ee642b15732bfdd3c72294.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian Tobasco")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-65922")[#strong[#text("Ian Tobasco")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2011")])]

#text("Richard Courant also discusses the topic of constructable numbers in “What is Mathematics?”")

#text("There he demonstrates that the angle 60 deg cannot be trisected. The main idea is Corollary 3, but this is proved without appealing to Galois theory or a dimension argument.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d08234f97311997ba051bcc1e08e7aef9a7eea7f69a2900d33e6e0a9804e23c-fdb632cf7d7d17b8fcd4d48cded88e8274f7bd70015530c870a11be50cf91bde.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Cohen")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-67053")[#strong[#text("Martin Cohen")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2011")])]

#text("Poor Herbert Robbins – ignored again!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f04931d56a33bb1cce093eca5d16bb551e28e3116974a5c58403f6fde9b7daa9-29257ec6a6dd594f9c3a3a83b5e6f356256e21ec969c673b0d9e87ed5fe33d7e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ghulam Sarwar")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-400218")[#strong[#text("Ghulam Sarwar")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2014")])]

#text("Trisection is a matter of construction, not calculation.You can trisect a line but numbers fail to calculate it, and the same case is with trisection of angle.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab21c02cd34bb05e37e96c2bf17b43bfd41cb94f9b34c2b7230a119b2e7587df-94c888d4f4175b805e94d713efb9a3aa33edd029689d6be9d358d462c7585707.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-65930")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2011")])]

#text("What software did you use to draw the diagrams?")

#emph[#text("[Inkscape – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e93f9dc07f75cedd8e720078553215326946db058a739d5e834b99c52b4ce677-f78eee69ac0adf472ac64bc97aec049fa77a28ec3f689a723fc1df540e71d862.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Slipper.Mystery")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-66469")[#strong[#text("Slipper.Mystery")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2011")])]

#text("It looks like same argument works to show not only impossibility of trisection but impossibility of splitting by anything other than a power of 2, since only powers of 2 divide powers of 2?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-66474")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2011")])]

#text("Yes, that is correct. (This is one small advantage of this argument over the standard field-theoretic argument, which can reach the same conclusion but only after a bit of fiddling around with minimal polynomials.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dfefed9d0023dce56a34632d43550a77e761f88545cab5c0bb3b7b1317ea607e-66fceddcc50c8d81a17a952a311bc4ff5c3a2149d63984c0b54d4004cbccf93c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ImNotSure")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-66495")[#strong[#text("ImNotSure")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2011")])]

#text("Hi Tao,")

#text("A question, do you have any references? a book o somewhere to read more about this proof")

#text("bye")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Linda Janourova")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-66509")[#strong[#text("Linda Janourova")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2011")])]

#text("Neat — and I’m sure I’m missing something obvious, but the “intuitive” version of the proof doesn’t seem quite “complete” to me (if that even means anything!). I’m happy to accept everything up to the last step — but once we get to that step, is it really so clear that because the trisecting line {\\ell} only makes a one-third (120 degree) rotation for every full rotation of {C}, the whole construction must have a period that is a multiple of 3?")

#text("Couldn’t the original construction have contained another line {\\ell_1} that is coincides with {\\ell} (rotated through 120 degrees) — so that a full rotation of {C} just brings {\\ell} to {\\ell_1}?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-66512")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2011")])]

#text("One should view the construction as a ")#emph[#text("labeled")]#text(" construction, with each point, line, or circle in the construction given a label such as ")#mi("\\ell")#text(" or ")#mi("\\ell_1")#text(". If one arrives at a construction with the same set of lines and circles, but for which the labels have been swapped, this is not considered the same construction as the original construction for the purposes of determining periodicity. So even if the construction contains the 120-degree rotated lines ")#mi("\\ell_1, \\ell_2")#text(" to ")#mi("\\ell")#text(", it will only return to the original construction after a number of rotations equal to a multiple of 3.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a28f5bd1ac2331e426da5bd322dfe1f24b57ff624ca5574906e99aa104c2a0bc-b14a8c4d0e9d659f5934a0318e58a9500bccecdc0a4766bf708f799775a325c6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A SERIOUS geek out on mathmatics (via What’s new) « Normanomicon")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-66514")[#strong[#text("A SERIOUS geek out on mathmatics (via What’s new) « Normanomicon")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2011")])]

#text("[…] One of the most well known problems from ancient Greek mathematics was that of trisecting an angle by straightedge and compass, which was eventually proven impossible in 1837 by Pierre Wantzel, using methods from Galois theory. Formally, one can set up the problem as follows. Define a configuration to be a finite collection of points, lines, and circles in the Euclidean plane. Define a construction step to be … Read More […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-66616")[#strong[#text("A geometric proof of the impossibility of angle trisection by straightedge and compass « What’s new « kronikoles")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2011")]

#text("[…] A geometric proof of the impossibility of angle trisection by straightedge and compass « What’s n…. Like this:LikeBe the first to like this post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-66711")[#strong[#text("Walking Randomly » 80th Carnival of Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2011")]

#text("[…] Tao gives us a geometric proof of the impossibility of angle trisection by straightedge and compass while the Geometry and the imagination blog discusses Rotation numbers and the Jankins-Neumann […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83d96e7c8c96d50373c16adc05ffdc481068318f19d01c35f33dbf86af20cc59-49eb4a9ab4a203065f352353af9896244ac4db2c7bdcf7e3cc5be30ab6ba8c3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fedja")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-66989")[#strong[#text("fedja")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2011")])]

#text("I was once challenged with presenting the proof of the impossibility of the angle trisection to undergraduates. It took me a while to figure out how to do it but I finally got away without Galois though I needed the notion of the quadratic field extension. Here is what I did:")

#text("1) Introduce complex numbers as points on the plane")#linebreak()#text(" 2) Define constructible numbers for an initial configuration of points")#linebreak()#text(" 3) Show that any constructible number belongs to some quadratic extension of a quadratic extension of … the field generated by the original points.")#linebreak()#text(" 4) Now, suppose that ")#mi("z^3")#text(" is in the original field and the last extension was obtained by joining ")#mi("w")#text(" with ")#mi("w^2=u")#text(". Then ")#mi("z=aw+b")#text(", ")#mi("z^3=(3ab^2+a^3u)w+(3a^2bu+b^3)")#text(". If ")#mi("3ab^2+a^3u\\ne 0")#text(", ")#mi("w")#text(" lies in the previous extension, so the last extension was vacuous. If ")#mi("a=0")#text(", ")#mi("z")#text(" was in the previous extension already. If ")#mi("a\\ne 0")#text(", then ")#mi("3b^2+a^2u=")#text(", so if ")#mi("i\\sqrt {3}")#text(" was in the original field, we can take the square root of ")#mi("u")#text(" there and the last extension was vacuous again. Thus, if ")#mi("i\\sqrt {3}")#text(" is in the first field in the chain, the whole chain is unnecessary and we should have ")#mi("z")#text(" in the original field.")#linebreak()#text(" 5) Take the 120 degrees angle with ")#mi("Z^3=1")#text(" (so you get that ")#mi("i\\sqrt {3}")#text(" there at once). If ")#mi("(aZ+b)^3=Z")#text(" for ")#mi("a,b\\i\\mathbb Q")#text(", then, since ")#mi("Z^2=-Z-1")#text(", we must have ")#mi("a^3+b^3-3a^2b=0")#text(" but the equation ")#mi("x^3-3x+1")#text(" has no rational roots, so ")#mi("a=b=0")#text(", which is absurd.")

#text("To be honest, this still takes a lot of time (three 50 minute lectures, to be exact), but it appeals only to the elementary algebra.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/704b81e58ca29743b47850bb62f82d988587af8aa950d2d86ccec5d2d2505f3a-ae78c7c51eb8b92e65e74b0790dfb510525c2923707a533c2fcc07a150e39602.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of plm")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-67496")[#strong[#text("plm")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2011")])]

#text("I have not read it but this article posted today may be relevant:")

#link("http://arxiv.org/abs/1108.2793")[#text("http://arxiv.org/abs/1108.2793")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Menelaus theorem by way of Reidemeister move 3 | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-68659")[#strong[#text("Menelaus theorem by way of Reidemeister move 3 | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2011")])]

#text("[…] I was in fact motivated to draw the figures and explain all this after seeing this very nice post of Tao, where an elementary proof of a famous result is given, by using “elementary” graphical […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/809af7cb888c0da2ef22cfe34c3839f7ea2a89e73898923f2b672e77a536401a-2f255c5afec6347f352c08747c10fe294817c3b65614c60de69ca9d5d3eb625b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A geometric proof of the impossibility of angle trisection by straightedge and compass « Nico For Math")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-69124")[#strong[#text("A geometric proof of the impossibility of angle trisection by straightedge and compass « Nico For Math")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2011")])]

#text("[…] standard way in which Lemma 2 is used to demonstrate the impossibility of angle trisection is via Galois theory. The implication […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-70905")[#strong[#text("Absolute Value (mathematics) « Jeinrev")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2011")]

#text("[…] Geometric proof that angle trisection by straightedge and compass is impossible (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-72777")[#strong[#text("Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2011")]

#strong[#text("Has a negative result ever published in a high-profile academic journal (i.e. Nature, or Science)?…")]

#text("In the field of mathematics, negative results are treated probably with the same regard as positive results. After all, if a proof has been determined to be impossible to solve either at all or in a certain way, it does help scope the problem in a non-…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e6917b74a6a87144da76dc68615bedb96b74f638b054b43ca1260729586acea1-44b0f626c79acdc5dfa8fd876b1fad43fe1749d0cfdb359671fec8e157bc0d46.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-92895")[#strong[#text("Joe")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2011")])]

#text("Totally new to this site. Interested in, not obsessed by, the trisection problem.")#linebreak()#text(" Could I have your permission to email, in a ACDC attachment, a model of a proposed trisection construction for comment?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-101532")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2011")])]

#text("Read my method of this problem at ")#link("http://www.scribd.com/doc/62318863/Trisection-of-an-Angle-English")[#text("http://www.scribd.com/doc/62318863/Trisection-of-an-Angle-English")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fca160afb7da2c87b2507275284ce367b9a86277554bd31eb9aa11c8ab58285b-9cca69aacae0304fbcf8ee5fa725e19dcdf39ef0b9a1f5642e27a815518bf90f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mohammed nowairan")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-139414")[#strong[#text("mohammed nowairan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2012")])]

#text("announcement : my father found out a method with prove to trisect any angle no matter what’s the degree !! i know it looks like a joke but for who interested i mean official centers or official Representatives of math , please contact me on my father’s email !! The research consists of 46 pages written by hand in the Arabic language only unfortunately , including 16 explanatory figures, but does not include a preface or an epilogue.")

#link("mailto:m.nowairan@gmail.com")[#text("m.nowairan@gmail.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f51e660ac196c4eeaf90aa6018106fb1e4151c0ed6acb54e38883045d935afe9-8390035311011cda07fb6097383177e167593b30e8c6ad23edeba5ed9f998b08.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sunwukong")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-231064")[#strong[#text("sunwukong")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2013")])]

#text("Trisection of an angle.")#linebreak()#text(" (20130523, pak)")

#text("(graphic did not paste)")

#text("Consider an arbitrary angle (say for instance 32 degrees)")#linebreak()#text(" If you draw two lines thru a point (a1) at this angle for 50 cm or so.")#linebreak()#text(" If you then draw a circle around the point (p) at some arbitrary distance (say r=10 cm)")#linebreak()#text(" If you then mark out points along both of the lines at r distance (10 cm)")#linebreak()#text(" Then swing arcs from the point thru each of these “r” distance points")#linebreak()#text(" The distances between the points where each “r” distance crosses the two lines (32 degrees) apart will be sin(32)*r.")

#text("Then where the base is 3*r the small base of the triangle will be three times the base of the smallest triangle. Simply mark r distance from each of the sides and you have trisected the angle between the two long sides of the triangle.")

#text("how is this not a trisection?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-231068")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2013")])]

#text("Trisecting a chord is not quite the same thing as trisecting an angle, though it gives a reasonably good approximation. Equating the two happens to be a rather commonly made error in first attempts to trisect an angle: see e.g. ")#link("http://mathworld.wolfram.com/AngleTrisection.html")[#text("http://mathworld.wolfram.com/AngleTrisection.html")]

#text("It is instructive to work through the trigonometry (using the sine rule) for an explicit example (e.g. the 32 degree angle you mention) to see that the angles constructed by trisecting the chord are not quite a perfect trisection (the angles will be close to, but not exactly, 32/3 = 10.666… degrees).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-246190")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2013")])]

#text("Angle trisection is possible by Euclidean methods in 3 dimensional space.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d0bc30e455da893fb7fb808958d5375e343c67d1dfabfb9d67ce969b5deba41-a1c0c21baff6ab12ebd3d58f3aab53ad5079ea24909ffd937f83f6ff6bf7f702.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manthos Monogios")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-326991")[#strong[#text("Manthos Monogios")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2014")])]

#text("A solution to the geometric trisection of any angle may have been found.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-434620")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2014")])]

#text("It has. IOSR JOURNAL OF MATHEMATICS volume 10, issue 5, version 6, pages 48 – 51")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/654df0925f1fc2bd8d8be0c65d5697fa8f5cc2acba08d6978a67d2ceb65bedf0-438698e83609446bc78fd3e87b24fb33164835fc5cdbe58043f77c0021d7fd7b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Danish Rugjee")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-453959")[#strong[#text("Danish Rugjee")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2015")])]

#text("Hello there,")

#text("If you’re proof is correct, so how did i trisect an angle???")

#text("Please have a look at the website i posted")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8157ad43d4c7a09a5ea747120ed89d192c1db379fa8b7749a7ae9c973b98ebc6-d97e8d96e4d195fe18a8efe94cc7588bbc26a5501c274572f4f11edd2cec7c8b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chenjia Lin")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-456110")[#strong[#text("Chenjia Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2015")])]

#text("I was trying out this problem two days ago with only a straight edge and compass, and for some reason, I was able to trisect a 60 and 45 degree angle. Any attempt afterwards didn’t work for some reason.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/035027f6d093db637f7c1e82f5ee2d78aca82eeaaf6dc8fb6c7a94564dc722cc-8cf059efa6ada90059efde0403d41e8e8275d84124c3ad24e29d7752c22e7b91.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William (Bill) Greig. Bsc(St And., PGCE,")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-457766")[#strong[#text("William (Bill) Greig. Bsc(St And., PGCE,")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2015")])]

#text("Sorry y’all, but I have done it. My method depends on an extension of the series of circle equalitiy theorems: In any given circlle, equal chords, Implies equal arcs, implies equal angles at the centre, implies equal half size angles at the circumference ( subtended bu the same of equal arcs) which extends to equal angles at any point on the plane: The proof hangs on triangle congruences: It is then used back track from : ning the angle into an isosoceles triangle. Drawing a semicircle with the third side as diameter. Cutting three 60degree arcs on this semicircle, and joining the ends to the original vertex. Detailed proof supplied to any who have the grace to ask")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f51e660ac196c4eeaf90aa6018106fb1e4151c0ed6acb54e38883045d935afe9-8390035311011cda07fb6097383177e167593b30e8c6ad23edeba5ed9f998b08.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sunwukong")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-464628")[#strong[#text("sunwukong")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2016")])]

#text("I have a method that seems to work")#linebreak()#text(" I have a .jpg slide that shows the method how do I u/load a .jpg?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d81323b27438fddf8b6dcf628865d0796277ef6c997cc698c84aa4cebb2d1fe6-93fa31f19cf6775eca185dbb2ee175fbaefd4d1c15727c6dacb8a73b2e8705bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AjAy")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-470399")[#strong[#text("AjAy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2016")])]

#text("but I can prove that we can easily trisect an angle!")#linebreak()#text(" I have developed a New approach to trisect an angle!")#linebreak()#text(" :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9921949323b1ab74eec237d49d4c3c203f1b5153c1fc992cff63b13f23d23016-5a8384609362dbeae8065a0fb3c16c9aa9627e797b20cd27870145ea53ea416b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Crabtree")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-470412")[#strong[#text("Jonathan Crabtree")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2016")])]

#text("Dear Dr. Tao,")

#text("Thank you for your wonderful website. How privileged we are that you care to share so much!")

#text("Have you seen the published proof of angle trisection via origami? (Not by compass and straightedge!)")

#text("Trisecting an angle, Karim Noura, Vinculum, Vol. 51, No. 4, pp. 8-10, 2014. ")#link("http://search.informit.com.au.ezproxy.slv.vic.gov.au/documentSummary;dn=633791700982280;res=IELAPA")[#text("http://search.informit.com.au.ezproxy.slv.vic.gov.au/documentSummary;dn=633791700982280;res=IELAPA")]

#text("Slides for the above can be seen at")

#strong[#text(" ")#link("https://www.slideshare.net/KarimNoura/angle-trisection-aamt-kn-2015")[#text("Angle Trisection (AAMT KN 2015)")]#text(" ")]#text(" from ")#strong[#link("https://www.slideshare.net/KarimNoura")[#text("Karim Noura")]]

#text("Thanks again!")

#text("Best wishes,")#linebreak()#text(" Jonathan Crabtree")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d81323b27438fddf8b6dcf628865d0796277ef6c997cc698c84aa4cebb2d1fe6-93fa31f19cf6775eca185dbb2ee175fbaefd4d1c15727c6dacb8a73b2e8705bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AjAy")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-470413")[#strong[#text("AjAy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2016")])]

#text("but i have my own way to prove about trisection of an angle…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nk C")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-471892")[#strong[#text("Nk C")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2016")])]

#text("Thanks a lot I like this posts")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/afd4719c11314da281cbdf6ef9da6901597b851621810d9c4a6e71d7ce6f5e6a-60e3cea27b22b0eb449c2bd5b0c413fe847bd60f6ff0dbce9bdcc1278e315f0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-472296")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2016")])]

#text("I could be wrong, but could someone please explain to me why this linked method doesn’t accomplish the goal?")#linebreak()#text(" ")#linebreak()#text(" I believe it follows the rules of compass and straight edge. It could only be an approximation, but if so, please explain why.")#linebreak()#text(" Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/afd4719c11314da281cbdf6ef9da6901597b851621810d9c4a6e71d7ce6f5e6a-60e3cea27b22b0eb449c2bd5b0c413fe847bd60f6ff0dbce9bdcc1278e315f0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-472298")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2016")])]

#text("And to extrapolate, if this is a correct method, you can use it to divide an angle n-times. And if you can do that, you can construct an n-gon. Which i believe is also currently considered to be impossible. I think the whole impossibility factor is when cubes and cube roots are involved. But this method takes a completely different approach I think. But again, I could be wrong and probably am.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-472302")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2016")])]

#text("The problem starts at 4:46 (the process of creating 3 equal circles which divide the arc DE into 3 equal arcs can’t be done in finitely many steps!)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/afd4719c11314da281cbdf6ef9da6901597b851621810d9c4a6e71d7ce6f5e6a-60e3cea27b22b0eb449c2bd5b0c413fe847bd60f6ff0dbce9bdcc1278e315f0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-472303")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2016")])]

#text("Thank you for the reply. But I’m not sure what you mean. The division of arc DE is marked by the compass radius. Can you please elaborate about the “finitely many steps”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-472304")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2016")])]

#text("The problem is how to determine (in finitely many steps) the exact(!) compass radius needed for the division of the arc DE into 3 equal arcs (which is equivalent to trisecting a corresponding angle).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/afd4719c11314da281cbdf6ef9da6901597b851621810d9c4a6e71d7ce6f5e6a-60e3cea27b22b0eb449c2bd5b0c413fe847bd60f6ff0dbce9bdcc1278e315f0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-472316")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2016")])]

#text("The radius that I constructed at KJ is exactly 1/6 the length of arc DE, so that is able to divide the arc into 6 equal parts. If it can divide by 6, then it can be divided by 3, which is how the arc can be divided into 3 equal parts by my method. What am I missing?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/afd4719c11314da281cbdf6ef9da6901597b851621810d9c4a6e71d7ce6f5e6a-60e3cea27b22b0eb449c2bd5b0c413fe847bd60f6ff0dbce9bdcc1278e315f0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-472317")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2016")])]

#text("I realize the logic in my proof at the end of the video is incorrect. In the first, I calculate the length of a straight line, in the next I calculate the length of the arc, so naturally they will not match exactly. Here is another try:")

#text("We know that AK is equal to AJ, and the angle KAJ is ½ the total angle BAC. And we know the length of AK 1/3 of AD.")#linebreak()#text(" We can express: circumference with radius KJ = AD/3 x 2pi")#linebreak()#text(" If we plug in an arbitrary angle for BAC, say 30, the angle for KAJ is half, or 15 degrees. The arc is 1/24 the circumference of the entire circle with radius KJ.")#linebreak()#text(" So the length of KJ = AD x .0872")#linebreak()#text(" Does this match up to the length of LG?")

#text("If we say that our angle BAC is 30 degrees, we know that the arc DE = 1/12 the total circumference of the circle with radius AD. And we know that KJ is 1/6 of arc DE.")

#text("From our previous argument, we know KJ = AD x .0872")#linebreak()#text(" We can express:LG = 2pi x AD / 12 / 6 = AD x .0872")#linebreak()#text(" What about the angle DAL? It should equal 10 degrees if it’s 1/3 of the 30 degree angle BAC. Is it?")

#text("Since AD and AL are equal length, they form an isosceles triangle DAL. We know KJ is ½ the length of DL. We can also bisect line DL to divide DAL into 2 right triangles with hypotenuse of length AD.")#linebreak()#text(" sin(5) = KJ /AD = .0871557 so DAL has an angle of 10 degrees and is 1/3 the angle BAC!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-472323")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2016")])]

#text("As a simple check of your last construction, your construction should give sin(5 degrees) in terms of rational numbers and square roots only.")#linebreak()#text(" This expression can be computed to sufficiently many significant digits in order to see its deviation from the exact value of sin(5 degrees) (which can’t be expressed using only rational numbers and square roots!)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d416f5927596debf18841a88ad56030bbd3b4742ac4fd29de2b90ca31f4b71d0-3793b5ea5bc549a25f8a9646914ee298b9185989c72bce6c43f8bf1105ae8a43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous2")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-472340")[#strong[#text("anonymous2")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2016")])]

#text("Your construction would work if: 2 sin (A/4) = 6 sin (A/12) where A is the angle in radians. In other words, the corresponding implied polygons’ sides’ lengths are not integer multiples of each other. It is remarkably close, but not close enough for mathematicians. Looks like the error is less than half a percent. Probably why you didn’t notice it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/afd4719c11314da281cbdf6ef9da6901597b851621810d9c4a6e71d7ce6f5e6a-60e3cea27b22b0eb449c2bd5b0c413fe847bd60f6ff0dbce9bdcc1278e315f0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-472345")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2016")])]

#text("Thank you for the explanation. I will check it out.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-472361")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2016")])]

#text("Let ")#mi("x = \\cos \\alpha")#text(". Given ")#mi("y= \\cos (3 \\alpha) = 4 x^3 - 3 x")#text(" and a sufficiently good (initial) approximation of ")#mi("x")#text(", it is possible by (a geometric version of) the Newton-Raphson iteration to generate (geometrically!) a quadratically(!) convergent sequence of approximations to ")#mi("x")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/afd4719c11314da281cbdf6ef9da6901597b851621810d9c4a6e71d7ce6f5e6a-60e3cea27b22b0eb449c2bd5b0c413fe847bd60f6ff0dbce9bdcc1278e315f0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-472359")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2016")])]

#text("Why does the method of trisecting an angle (using a marked ruler) break the rules when you can construct the same thing using a compass and straightedge that is “unmarked”?")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/Angle_trisection")[#text("https://en.wikipedia.org/wiki/Angle_trisection")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/afd4719c11314da281cbdf6ef9da6901597b851621810d9c4a6e71d7ce6f5e6a-60e3cea27b22b0eb449c2bd5b0c413fe847bd60f6ff0dbce9bdcc1278e315f0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-472360")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2016")])]

#text("Nevermind. Getting late and I made an incorrect assumption.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/94de2db3fc35af378106b54d9f6eb220f0d3c6c0ad79a45a084d0bc8501462a4-aee4e1cc340bc04df8bcc48b6fb8617794e97b09f2a0625e459681a8187e5a0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Petrus3743")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-473551")[#strong[#text("Petrus3743")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2016")])]

#text("A design proposal.")#linebreak()#text(" Perhaps the accuracy is enough.")#linebreak()#text(" See ")#link("https://upload.wikimedia.org/wikipedia/commons/8/80/01-Trisection_of_angle_E-10_Animation.gif")[#text("https://upload.wikimedia.org/wikipedia/commons/8/80/01-Trisection_of_angle_E-10_Animation.gif")]#linebreak()#text(" Petrus3743")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d53a15e44ce117433263421fa95aabb84b58e43fddb389253f92261b027c47a5-169bbaf7edef2ee8276be913524065d39111fd60a3861e3eb6db73ddc6c58c8f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Misom Bilić")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-476768")[#strong[#text("Misom Bilić")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2017")])]

#text("There proportions angles, it solves trisection angle and regular polygon")

#text("look ")#link("http://mathhelpforum.com/peer-math-review/272327-misli.html#post912740")[#text("http://mathhelpforum.com/peer-math-review/272327-misli.html#post912740")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3170687540c66dc22acac3ff153a5f7b25b10303e42e1144b148a6cfe32bff3d-0c12835ec5ba8882b4301c470ff7175f999ad4539c3167aabdb48ab191ff6473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eulogio Garcia")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-476797")[#strong[#text("Eulogio Garcia")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2017")])]

#text("The trisection of evey angle has its own algebraic expresión. Have his origin in the cosine theorem. ie")

#mi("x(b^{2} - 2a^{2}) + 2a^{2} = 0")

#text("the arithmetical sum of the angle is equivalent to the arithmetical sum of the side opposite to the given angle.")

#text("see: ")#link("http://www.hrpub.org/journals/jour_info.php?id=26")[#text("http://www.hrpub.org/journals/jour_info.php?id=26")]#text(" Vol 1 (2) 2013")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-477272")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2017")])]

#text("DOI 10.9790/5728-10564851")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22b170fc060b3b1318da816c8eb6476d1ba934217e2d5b3b0e140a7f88ad1e57-f58fdaed3d78a76af96dfd8f41cd15c1ffe59bb456c4a339521ff20c9303627c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Murat Emiroglu")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-477284")[#strong[#text("Murat Emiroglu")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2017")])]

#text("Dudley’s effort is a bit odd. I think if he were to compile the records of people who ever discovered / invented anything in history he would have seen many similarities with the cranks he calls as trisectors. It is all good.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-478368")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2017")])]

#text("Random angle trisection")#linebreak()#text(" Example 1. Suppose I have the circle x2+z2=1252. Above in the circle, if get the points E=(-117,-44) , Z=(117,-44) , M=(-75,100) and N=(75,100) , then we have the isosceles trapezoid MNZE with MN//EZ and with paper and pencil we find EM=MN=NZ=150. We know that at equal chords we have equal arcs and so the angle ETZ=110,61o divided in three equal angles You make the shape")#linebreak()#text(" ")#link("mailto:halatsisg@yahoo.com")[#text("halatsisg@yahoo.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-478391")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2017")])]

#text("Example 3. Suppose I have the circle x2+z2=49132. Above in the circle, if get the points E=(-4888,-495) , Z=(4888,-495) , H=(-2312,-4335) and K=(2312,-4335) , then we have the isosceles trapezoid EZHK with EZ//HK and with paper and pencil we find EH=HK=KZ=4624. We know that at equal chords we have equal arcs and so the angle ETZ=84,22o divided in three equal angles.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-478392")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2017")])]

#text("Example 4. Suppose I have the circle x2+z2=1488772. Above in the circle, if get the points E=(-148148,-14715) , Z=(148148,-14715) , M=(-78625,126405) and N=(78625,126405) , then we have the isosceles trapezoid MNZE with MN//EZ and with paper and pencil we find EM=MN=NZ=157304. We know that at equal chords we have equal arcs and so the angle ETZ=95,67o divided in three equal angles.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-478393")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2017")])]

#text("Example 5. Suppose I have the circle x2+z2=33079492. Above in the circle, if get the points E=(-2866149,-1651580) , Z=(2866149,-1651580) , H=(-1132251,-3108140) and K=(1132251,-3108140) , then we have the isosceles trapezoid EZHK with EZ//HK and with paper and pencil we find EH=HK=KZ=2264502. We know that at equal chords we have equal arcs and so the angle ETZ=60,05o divided in three equal angles")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/comment-page-1/#comment-478433")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2017")])]

#text("Example 18. Suppose I have the circle x2+z2=6584892. Above in the circle, if get the points E=(-550836,-360815) , Z=(550836,-360815) , H=(-213564,-622895) and K=(213564,-622895) , then we have the isosceles trapezoid EZHK with EZ//HK and with paper and pencil we find EH=HK=KZ=427128. We know that at equal chords we have equal arcs and so the angle EPZ=56,77o divided in three equal angles.")
]
