// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/02/01/a-massively-collaborative-mathematical-project/
// Converted to Typst by tao2typ: "2026-10-14T07:10:53.903351+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A massively collaborative mathematical project", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A massively collaborative mathematical project")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 February 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/02/01/a-massively-collaborative-mathematical-project/")[#text("https://terrytao.wordpress.com/2009/02/01/a-massively-collaborative-mathematical-project/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("My good friend ")#link("http://en.wikipedia.org/wiki/Timothy_Gowers")[#text("Tim Gowers")]#text(" has just started an experimental “")#link("http://gowers.wordpress.com/2009/01/27/is-massively-collaborative-mathematics-possible/")[#text("massively collaborative mathematical project")]#text("” over at ")#link("http://gowers.wordpress.com/")[#text("his blog")]#text(". The project is entitled “")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/")[#text("A combinatorial approach to density Hales-Jewett")]#text("“, and the aim is to see if progress can be made on this problem by many small contributions by a large number of people, as opposed to the traditional model of a few very large contributions by a small number of people (see ")#link("http://gowers.wordpress.com/2009/02/01/questions-of-procedure/")[#text("this article")]#text(" for more on the “rules of the game”, and ")#link("http://gowers.wordpress.com/2009/02/01/why-this-particular-problem/")[#text("this article")]#text(" for why this particular project was picked as a test project). I think this is an interesting experiment, and hopefully a successful one, though it is far too early to tell as yet.")

#text("I can describe the problem here. Let n be a large integer, and let ")#mi("{}[3]^n")#text(" be the set of all strings of length n using the alphabet ")#mi("\\{1,2,3\\}")#text(", thus for instance ")#mi("13323 \\in [3]^5")#text(". A ")#emph[#text("combinatorial line")]#text(" in ")#mi("{}[3]^n")#text(" is a triple of points in ")#mi("{}[3]^n")#text(" that can be formed by taking a string of length n using the alphabet ")#mi("\\{1,2,3,x\\}")#text(" with at least one occurrence of the “wildcard” x, and then substituting the values of 1, 2, 3 for the wildcard. For instance, the string ")#mi("1xx2x")#text(" would lead to the combinatorial line ")#mi("\\{11121, 12222, 13323\\}")#text(" in ")#mi("{}[3]^5")#text(". The (k=3) case of the ")#emph[#text("density Hales-Jewett theorem")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=1001397")[#text("of Furstenberg and Katznelson")]#text(" asserts:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Density Hales-Jewett theorem.")]#text(" Let ")#mi("0 < \\delta < 1")#text(". Then if n is sufficiently large depending on ")#mi("\\delta")#text(", every subset of ")#mi("{}[3]^n")#text(" of density at least ")#mi("\\delta")#text(" contains a combinatorial line.")
]

#text("[Furstenberg and Katznelson handled the case of general k ")#link("http://www.ams.org/mathscinet-getitem?mr=1191743")[#text("in a subsequent paper")]#text(". The k=1 case is trivial, and as pointed out in ")#link("http://gilkalai.wordpress.com/2009/01/28/mathematics-science-and-blogs/")[#text("this post by Gil Kalai")]#text(", the k=2 case follows from ")#link("http://en.wikipedia.org/wiki/Sperner%27s_theorem")[#text("Sperner’s theorem")]#text(".]")

#text("Furstenberg and Katznelson’s proof uses ergodic theory, and in particular does not obviously give any bound as to how large n has to be depending on ")#mi("\\delta")#text(" before the theorem takes effect. No other proofs of this theorem are currently known. So it would be desirable to have a combinatorial proof of the k=3 density Hales-Jewett theorem. Since this theorem implies ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("Roth’s theorem")]#text(", and Roth’s theorem has a combinatorial proof based on the triangle removal lemma (see e.g. my ")#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/")[#text("Simons lecture on the subject")]#text(", or Tim Gowers’ ")#link("http://gowers.wordpress.com/2009/01/30/background-to-a-polymath-project/")[#text("background article")]#text(" for the project), it is thus natural to ask whether the density Hales-Jewett theorem has a proof based on something similar to the triangle removal lemma. This is basically the question being explored in ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/")[#text("the above project")]#text(". (Some further motivation for this problem can be ")#link("http://gowers.wordpress.com/2009/02/01/why-this-particular-problem/")[#text("found here")]#text(".)")

#text("Further articles on ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/")[#text("this project")]#text(" are collected at ")#link("http://wordpress.com/tag/polymath1/")[#text("this page")]#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Upper and lower bounds for the density Hales-Jewett problem « What’s new")]], [#link("https://terrytao.wordpress.com/2009/02/01/a-massively-collaborative-mathematical-project/#comment-35559")[#strong[#text("Upper and lower bounds for the density Hales-Jewett problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("[…] 5 February, 2009 in math.CO | Tags: polymath1 | by Terence Tao This is a continuation of several threads from Tim Gowers’ massively collaborative mathematics project, “A combinatorial approach to density Hales-Jewett“, which I discussed in my previous post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/01/a-massively-collaborative-mathematical-project/#comment-35570")[#strong[#text("Mathematics, Science, and Blogs « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")]

#text("[…] blog describing the project, its rules and motivation, and interesting discussions also over What’s new and in In theory. The project itself is fairly focused; Let me mention another connection which is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/01/a-massively-collaborative-mathematical-project/#comment-36014")[#strong[#text("A quick review of the polymath project « What Is Research?")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2009")]

#text("[…] from distinguished mathematicians such as Terence Tao. Tao has his own blog, and he published a post giving the background of the Hales-Jewett theorem and a later post with some of his own ideas about the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/01/a-massively-collaborative-mathematical-project/#comment-38432")[#strong[#text("Un blog concentra a cientos de matemáticos en la demostración conjunta de un teorema « Francis (th)E mule Science’s News")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2009")]

#text("[…] idea del proyecto era obtener una nueva demostración del teorema de la densidad de Hales-Jewett (muy bien descrito por Terence aquí), que no hiciera uso de la teoría ergódica, necesaria en la única demostración conocida hasta […]")
]
