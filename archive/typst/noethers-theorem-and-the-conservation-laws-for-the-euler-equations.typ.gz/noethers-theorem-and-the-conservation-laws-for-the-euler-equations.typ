// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/
// Converted to Typst by tao2typ: "2026-10-14T16:37:22.308320+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Noether’s theorem, and the conservation laws for the Euler equations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Noether’s theorem, and the conservation laws for the Euler equations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 March 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/")[#text("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Throughout this post, we will work only at the ")#emph[#text("formal")]#text(" level of analysis, ignoring issues of convergence of integrals, justifying differentiation under the integral sign, and so forth. (Rigorous justification of the conservation laws and other identities arising from the formal manipulations below can usually be established in an ")#emph[#text("a posteriori")]#text(" fashion once the identities are in hand, without the need to rigorously justify the manipulations used to come up with these identities).")

#text("It is a remarkable fact in the theory of differential equations that many of the ordinary and partial differential equations that are of interest (particularly in geometric PDE, or PDE arising from mathematical physics) admit a ")#link("http://en.wikipedia.org/wiki/Calculus_of_variations")[#text("variational")]#text(" formulation; thus, a collection ")#mi("{\\Phi: \\Omega \\rightarrow M}")#text(" of one or more fields on a domain ")#mi("{\\Omega}")#text(" taking values in a space ")#mi("{M}")#text(" will solve the differential equation of interest if and only if ")#mi("{\\Phi}")#text(" is a critical point to the functional ")#metadata(none) <tao-ec1a6ccd1c61fab13342>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("J[\\Phi] := \\int_\\Omega L( x, \\Phi(x), D\\Phi(x) )\\ dx")]]

#text("involving the fields ")#mi("{\\Phi}")#text(" and their first derivatives ")#mi("{D\\Phi}")#text(", where the ")#link("http://en.wikipedia.org/wiki/Lagrangian")[#text("Lagrangian")]#text(" ")#mi("{L: \\Sigma \\rightarrow {\\bf R}}")#text(" is a function on the vector bundle ")#mi("{\\Sigma}")#text(" over ")#mi("{\\Omega \\times M}")#text(" consisting of triples ")#mi("{(x, q, \\dot q)}")#text(" with ")#mi("{x \\in \\Omega}")#text(", ")#mi("{q \\in M}")#text(", and ")#mi("{\\dot q: T_x \\Omega \\rightarrow T_q M}")#text(" a linear transformation; we also usually keep the boundary data of ")#mi("{\\Phi}")#text(" fixed in case ")#mi("{\\Omega}")#text(" has a non-trivial boundary, although we will ignore these issues here. (We also ignore the possibility of having additional constraints imposed on ")#mi("{\\Phi}")#text(" and ")#mi("{D\\Phi}")#text(", which require the machinery of Lagrange multipliers to deal with, but which will only serve as a distraction for the current discussion.) It is common to use local coordinates to parameterise ")#mi("{\\Omega}")#text(" as ")#mi("{{\\bf R}^d}")#text(" and ")#mi("{M}")#text(" as ")#mi("{{\\bf R}^n}")#text(", in which case ")#mi("{\\Sigma}")#text(" can be viewed locally as a function on ")#mi("{{\\bf R}^d \\times {\\bf R}^n \\times {\\bf R}^{dn}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1 (Geodesic flow)")]#text(" Take ")#mi("{\\Omega = [0,1]}")#text(" and ")#mi("{M = (M,g)}")#text(" to be a Riemannian manifold, which we will write locally in coordinates as ")#mi("{{\\bf R}^n}")#text(" with metric ")#mi("{g_{ij}(q)}")#text(" for ")#mi("{i,j=1,\\dots,n}")#text(". A ")#link("http://en.wikipedia.org/wiki/Geodesic")[#text("geodesic")]#text(" ")#mi("{\\gamma: [0,1] \\rightarrow M}")#text(" is then a critical point (keeping ")#mi("{\\gamma(0),\\gamma(1)}")#text(" fixed) of the energy functional")

#align(center)[#tao-fit-display[#mitex("J[\\gamma] := \\frac{1}{2} \\int_0^1 g_{\\gamma(t)}( D\\gamma(t), D\\gamma(t) )\\ dt")]]

#text("or in coordinates (ignoring coordinate patch issues, and using the usual summation conventions)")

#align(center)[#tao-fit-display[#mitex("J[\\gamma] = \\frac{1}{2} \\int_0^1 g_{ij}(\\gamma(t)) \\dot \\gamma^i(t) \\dot \\gamma^j(t)\\ dt.")]]

#text("As discussed in ")#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/")[#text("this previous post")]#text(", both the ")#link("http://en.wikipedia.org/wiki/Euler_equations_of_motion")[#text("Euler equations for rigid body motion")]#text(", and the ")#link("http://en.wikipedia.org/wiki/Euler_equations_(fluid_dynamics)")[#text("Euler equations for incompressible inviscid flow")]#text(", can be interpreted as geodesic flow (though in the latter case, one has to work ")#emph[#text("really")]#text(" formally, as the manifold ")#mi("{M}")#text(" is now infinite dimensional).")

#text("More generally, if ")#mi("{\\Omega = (\\Omega,h)}")#text(" is itself a Riemannian manifold, which we write locally in coordinates as ")#mi("{{\\bf R}^d}")#text(" with metric ")#mi("{h_{ab}(x)}")#text(" for ")#mi("{a,b=1,\\dots,d}")#text(", then a ")#link("http://en.wikipedia.org/wiki/Harmonic_map")[#text("harmonic map")]#text(" ")#mi("{\\Phi: \\Omega \\rightarrow M}")#text(" is a critical point of the energy functional")

#align(center)[#tao-fit-display[#mitex("J[\\Phi] := \\frac{1}{2} \\int_\\Omega h(x) \\otimes g_{\\gamma(x)}( D\\gamma(x), D\\gamma(x) )\\ dh(x)")]]

#text("or in coordinates (again ignoring coordinate patch issues)")

#align(center)[#tao-fit-display[#mitex("J[\\Phi] = \\frac{1}{2} \\int_{{\\bf R}^d} h_{ab}(x) g_{ij}(\\Phi(x)) (\\partial_a \\Phi^i(x)) (\\partial_b \\Phi^j(x))\\ \\sqrt{\\det(h(x))}\\ dx.")]]

#text("If we replace the Riemannian manifold ")#mi("{\\Omega}")#text(" by a ")#link("http://en.wikipedia.org/wiki/Lorentzian_manifold#Lorentzian_manifold")[#text("Lorentzian manifold")]#text(", such as ")#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/Minkowski_space")[#text("Minkowski space")]#text(" ")#mi("{{\\bf R}^{1+3}}")#text(", then the notion of a harmonic map is replaced by that of a ")#link("http://en.wikipedia.org/wiki/Wave_maps_equation")[#text("wave map")]#text(", which generalises the scalar wave equation (which corresponds to the case ")#mi("{M={\\bf R}}")#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2 (")#mi("{N}")#text("-particle interactions)")]#text(" ")#metadata(none) <tao-e883a76a30b245c29f32>#text(" Take ")#mi("{\\Omega = {\\bf R}}")#text(" and ")#mi("{M = {\\bf R}^3 \\otimes {\\bf R}^N}")#text("; then a function ")#mi("{\\Phi: \\Omega \\rightarrow M}")#text(" can be interpreted as a collection of ")#mi("{N}")#text(" trajectories ")#mi("{q_1,\\dots,q_N: {\\bf R} \\rightarrow {\\bf R}^3}")#text(" in space, which we give a physical interpretation as the trajectories of ")#mi("{N}")#text(" particles. If we assign each particle a positive mass ")#mi("{m_1,\\dots,m_N > 0}")#text(", and also introduce a potential energy function ")#mi("{V: M \\rightarrow {\\bf R}}")#text(", then it turns out that Newton’s laws of motion ")#mi("{F=ma}")#text(" in this context (with the force ")#mi("{F_i}")#text(" on the ")#mi("{i^{th}}")#text(" particle being given by the conservative force ")#mi("{-\\nabla_{q_i} V}")#text(") are equivalent to the trajectories ")#mi("{q_1,\\dots,q_N}")#text(" being a critical point of the action functional")

#align(center)[#tao-fit-display[#tao-math("J[\\Phi] := \\int_{\\bf R} \\sum_{i=1}^N \\frac{1}{2} m_i \\left|\\dot q_i(t)\\right|^2 - V( q_1(t),\\dots,q_N(t) )\\ dt.", block: true)]]
]

#text("Formally, if ")#mi("{\\Phi = \\Phi_0}")#text(" is a critical point of a functional ")#mi("{J[\\Phi]}")#text(", this means that")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{ds} J[ \\Phi[s] ]|_{s=0} = 0")]]

#text("whenever ")#mi("{s \\mapsto \\Phi[s]}")#text(" is a (smooth) deformation with ")#mi("{\\Phi[0]=\\Phi_0}")#text(" (and with ")#mi("{\\Phi[s]}")#text(" respecting whatever boundary conditions are appropriate). Interchanging the derivative and integral, we (formally, at least) arrive at ")#metadata(none) <tao-3f7bbd502154653602d8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\int_\\Omega \\frac{d}{ds} L( x, \\Phi[s](x), D\\Phi[s](x) )|_{s=0}\\ dx = 0.")]]

#text("Write ")#mi("{\\delta \\Phi := \\frac{d}{ds} \\Phi[s]|_{s=0}}")#text(" for the infinitesimal deformation of ")#mi("{\\Phi_0}")#text(". By the chain rule, ")#mi("{\\frac{d}{ds} L( x, \\Phi[s](x), D\\Phi[s](x) )|_{s=0}}")#text(" can be expressed in terms of ")#mi("{x, \\Phi_0(x), \\delta \\Phi(x), D\\Phi_0(x), D \\delta \\Phi(x)}")#text(". In coordinates, we have ")#metadata(none) <tao-19b25856e1c150ca834c>

#tao-aligned(keep: true)[


#tao-math("\\frac{d}{ds} L( x, \\Phi[s](x), D\\Phi[s](x) )|_{s=0}  & = \\delta \\Phi^i(x) L_{q^i}(x,\\Phi_0(x), D\\Phi_0(x))", block: true, numbering: n => [#text("(3)")])



#tao-math(" & + \\partial_{x^a} \\delta \\Phi^i(x) L_{\\partial_{x^a} q^i} (x,\\Phi_0(x), D\\Phi_0(x)),", block: true)
]

#text("where we parameterise ")#mi("{\\Sigma}")#text(" by ")#mi("{x, (q^i)_{i=1,\\dots,n}, (\\partial_{x^a} q^i)_{a=1,\\dots,d; i=1,\\dots,n}}")#text(", and we use subscripts on ")#mi("{L}")#text(" to denote partial derivatives in the various coefficients. (One can of course work in a coordinate-free manner here if one really wants to, but the notation becomes a little cumbersome due to the need to carefully split up the tangent space of ")#mi("{\\Sigma}")#text(", and we will not do so here.) Thus we can view ")#link(<tao-3f7bbd502154653602d8>)[#text("(2)")]#text(" as an integral identity that asserts the vanishing of a certain integral, whose integrand involves ")#mi("{x, \\Phi_0(x), \\delta \\Phi(x), D\\Phi_0(x), D \\delta \\Phi(x)}")#text(", where ")#mi("{\\delta \\Phi}")#text(" vanishes at the boundary but is otherwise unconstrained.")

#text("A general rule of thumb in PDE and calculus of variations is that whenever one has an integral identity of the form ")#mi("{\\int_\\Omega F(x)\\ dx = 0}")#text(" for some class of functions ")#mi("{F}")#text(" that vanishes on the boundary, then there must be an associated differential identity ")#mi("{F = \\text{div} X}")#text(" that justifies this integral identity through Stokes’ theorem. This rule of thumb helps explain why integration by parts is used so frequently in PDE to justify integral identities. The rule of thumb can fail when one is dealing with “global” or “cohomologically non-trivial” integral identities of a topological nature, such as the ")#link("http://en.wikipedia.org/wiki/Gauss%E2%80%93Bonnet_theorem")[#text("Gauss-Bonnet")]#text(" or ")#link("https://terrytao.wordpress.com/2008/05/30/285g-lecture-16-classification-of-asymptotic-gradient-shrinking-solitons/")[#text("Kazhdan-Warner identities")]#text(", but is quite reliable for “local” or “cohomologically trivial” identities, such as those arising from calculus of variations.")

#text("In any case, if we apply this rule to ")#link(<tao-3f7bbd502154653602d8>)[#text("(2)")]#text(", we expect that the integrand ")#mi("{\\frac{d}{ds} L( x, \\Phi[s](x), D\\Phi[s](x) )|_{s=0}}")#text(" should be expressible as a spatial divergence. This is indeed the case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" (Formal) Let ")#mi("{\\Phi = \\Phi_0}")#text(" be a critical point of the functional ")#mi("{J[\\Phi]}")#text(" defined in ")#link(<tao-ec1a6ccd1c61fab13342>)[#text("(1)")]#text(". Then for any deformation ")#mi("{s \\mapsto \\Phi[s]}")#text(" with ")#mi("{\\Phi[0] = \\Phi_0}")#text(", we have ")#metadata(none) <tao-dead17353d9cbb514e3d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\frac{d}{ds} L( x, \\Phi[s](x), D\\Phi[s](x) )|_{s=0} = \\text{div} X")]]

#text("where ")#mi("{X}")#text(" is the vector field that is expressible in coordinates as ")#metadata(none) <tao-b212a7d6bd7701d4804f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("X^a := \\delta \\Phi^i(x) L_{\\partial_{x^a} q^i}(x,\\Phi_0(x), D\\Phi_0(x)).")]]
]

#emph[#text("Proof:")]#text(" Comparing ")#link(<tao-dead17353d9cbb514e3d>)[#text("(4)")]#text(" with ")#link(<tao-19b25856e1c150ca834c>)[#text("(3)")]#text(", we see that the claim is equivalent to the ")#link("http://en.wikipedia.org/wiki/Euler%E2%80%93Lagrange_equation")[#text("Euler-Lagrange equation")]#text(" ")#metadata(none) <tao-d65c3e892354b17a4c03>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("L_{q^i}(x,\\Phi_0(x), D\\Phi_0(x)) - \\partial_{x^a} L_{\\partial_{x^a} q^i}(x,\\Phi_0(x), D\\Phi_0(x)) = 0.")]]

#text("The same computation, together with an integration by parts, shows that ")#link(<tao-3f7bbd502154653602d8>)[#text("(2)")]#text(" may be rewritten as")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega ( L_{q^i}(x,\\Phi_0(x), D\\Phi_0(x)) - \\partial_{x^a} L_{\\partial_{x^a} q^i}(x,\\Phi_0(x), D\\Phi_0(x)) ) \\delta \\Phi^i(x)\\ dx = 0.")]]

#text("Since ")#mi("{\\delta \\Phi^i(x)}")#text(" is unconstrained on the interior of ")#mi("{\\Omega}")#text(", the claim ")#link(<tao-d65c3e892354b17a4c03>)[#text("(6)")]#text(" follows (at a formal level, at least). ")#mi("\\Box")

#text("Many variational problems also enjoy one-parameter continuous ")#emph[#text("symmetries")]#text(": given any field ")#mi("{\\Phi_0}")#text(" (not necessarily a critical point), one can place that field in a one-parameter family ")#mi("{s \\mapsto \\Phi[s]}")#text(" with ")#mi("{\\Phi[0] = \\Phi_0}")#text(", such that")

#align(center)[#tao-fit-display[#mitex("J[ \\Phi[s] ] = J[ \\Phi[0] ]")]]

#text("for all ")#mi("{s}")#text("; in particular,")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{ds} J[ \\Phi[s] ]|_{s=0} = 0,")]]

#text("which can be written as ")#link(<tao-3f7bbd502154653602d8>)[#text("(2)")]#text(" as before. Applying the previous rule of thumb, we thus expect another divergence identity ")#metadata(none) <tao-b779f99856d67b26ef48>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\frac{d}{ds} L( x, \\Phi[s](x), D\\Phi[s](x) )|_{s=0} = \\text{div} Y")]]

#text("whenever ")#mi("{s \\mapsto \\Phi[s]}")#text(" arises from a continuous one-parameter symmetry. This expectation is indeed the case in many examples. For instance, if the spatial domain ")#mi("{\\Omega}")#text(" is the Euclidean space ")#mi("{{\\bf R}^d}")#text(", and the Lagrangian (when expressed in coordinates) has no direct dependence on the spatial variable ")#mi("{x}")#text(", thus ")#metadata(none) <tao-867ed5f235d5d7d2db4a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("L( x, \\Phi(x), D\\Phi(x) ) = L( \\Phi(x), D\\Phi(x) ),")]]

#text("then we obtain ")#mi("{d}")#text(" translation symmetries")

#align(center)[#tao-fit-display[#mitex("\\Phi[s](x) := \\Phi(x - s e^a )")]]

#text("for ")#mi("{a=1,\\dots,d}")#text(", where ")#mi("{e^1,\\dots,e^d}")#text(" is the standard basis for ")#mi("{{\\bf R}^d}")#text(". For a fixed ")#mi("{a}")#text(", the left-hand side of ")#link(<tao-b779f99856d67b26ef48>)[#text("(7)")]#text(" then becomes")

#tao-aligned(keep: true)[


#tao-math("\\frac{d}{ds} L( \\Phi(x-se^a), D\\Phi(x-se^a) )|_{s=0}  & = -\\partial_{x^a} [ L( \\Phi(x), D\\Phi(x) ) ]", block: true)



#tao-math(" & = \\text{div} Y", block: true)
]

#text("where ")#mi("{Y(x) = - L(\\Phi(x), D\\Phi(x)) e^a}")#text(". Another common type of symmetry is a ")#emph[#text("pointwise")]#text(" symmetry, in which ")#metadata(none) <tao-3086ec194efcd8433d2c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("L( x, \\Phi[s](x), D\\Phi[s](x) ) = L( x, \\Phi[0](x), D\\Phi[0](x) )")]]

#text("for all ")#mi("{x}")#text(", in which case ")#link(<tao-b779f99856d67b26ef48>)[#text("(7)")]#text(" clearly holds with ")#mi("{Y=0}")#text(".")

#text("If we subtract ")#link(<tao-dead17353d9cbb514e3d>)[#text("(4)")]#text(" from ")#link(<tao-b779f99856d67b26ef48>)[#text("(7)")]#text(", we obtain the celebrated ")#link("http://en.wikipedia.org/wiki/Noether's_theorem")[#text("theorem of Noether")]#text(" linking symmetries with conservation laws:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Noether’s theorem)")]#text(" Suppose that ")#mi("{\\Phi_0}")#text(" is a critical point of the functional ")#link(<tao-ec1a6ccd1c61fab13342>)[#text("(1)")]#text(", and let ")#mi("{\\Phi[s]}")#text(" be a one-parameter continuous symmetry with ")#mi("{\\Phi[0] = \\Phi_0}")#text(". Let ")#mi("{X}")#text(" be the vector field in ")#link(<tao-b212a7d6bd7701d4804f>)[#text("(5)")]#text(", and let ")#mi("{Y}")#text(" be the vector field in ")#link(<tao-b779f99856d67b26ef48>)[#text("(7)")]#text(". Then we have the pointwise conservation law")

#align(center)[#tao-fit-display[#mitex("\\text{div}(X-Y) = 0.")]]
]

#text("In particular, for one-dimensional variational problems, in which ")#mi("{\\Omega \\subset {\\bf R}}")#text(", we have the conservation law ")#mi("{(X-Y)(t) = (X-Y)(0)}")#text(" for all ")#mi("{t \\in \\Omega}")#text(" (assuming of course that ")#mi("{\\Omega}")#text(" is connected and contains ")#mi("{0}")#text(").")

#text("Noether’s theorem gives a systematic way to locate conservation laws for solutions to variational problems. For instance, if ")#mi("{\\Omega \\subset {\\bf R}}")#text(" and the Lagrangian has no explicit time dependence, thus")

#align(center)[#tao-fit-display[#mitex("L(t, \\Phi(t), \\dot \\Phi(t)) = L(\\Phi(t), \\dot \\Phi(t)),")]]

#text("then by using the time translation symmetry ")#mi("{\\Phi[s](t) := \\Phi(t-s)}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("Y(t) = - L( \\Phi(t), \\dot\\Phi(t) )")]]

#text("as discussed previously, whereas we have ")#mi("{\\delta \\Phi(t) = - \\dot \\Phi(t)}")#text(", and hence by ")#link(<tao-b212a7d6bd7701d4804f>)[#text("(5)")]

#align(center)[#tao-fit-display[#mitex("X(t) := - \\dot \\Phi^i(x) L_{\\dot q^i}(\\Phi(t), \\dot \\Phi(t)),")]]

#text("and so Noether’s theorem gives conservation of the ")#emph[#text("Hamiltonian")]#text(" ")#metadata(none) <tao-0c0452c0ba8bed70d49c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("H(t) := \\dot \\Phi^i(x) L_{\\dot q^i}(\\Phi(t), \\dot \\Phi(t))- L(\\Phi(t), \\dot \\Phi(t)).")]]

#text("For instance, for geodesic flow, the Hamiltonian works out to be")

#align(center)[#tao-fit-display[#mitex("H(t) = \\frac{1}{2} g_{ij}(\\gamma(t)) \\dot \\gamma^i(t) \\dot \\gamma^j(t),")]]

#text("so we see that the speed of the geodesic is conserved over time.")

#text("For pointwise symmetries ")#link(<tao-3086ec194efcd8433d2c>)[#text("(9)")]#text(", ")#mi("{Y}")#text(" vanishes, and so Noether’s theorem simplifies to ")#mi("{\\text{div} X = 0}")#text("; in the one-dimensional case ")#mi("{\\Omega \\subset {\\bf R}}")#text(", we thus see from ")#link(<tao-b212a7d6bd7701d4804f>)[#text("(5)")]#text(" that the quantity ")#metadata(none) <tao-736bc2d4e0945110e88f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\delta \\Phi^i(t) L_{\\dot q^i}(t,\\Phi_0(t), \\dot \\Phi_0(t))")]]

#text("is conserved in time. For instance, for the ")#mi("{N}")#text("-particle system in Example ")#link(<tao-e883a76a30b245c29f32>)[#text("2")]#text(", if we have the translation invariance")

#align(center)[#tao-fit-display[#mitex("V( q_1 + h, \\dots, q_N + h ) = V( q_1, \\dots, q_N )")]]

#text("for all ")#mi("{q_1,\\dots,q_N,h \\in {\\bf R}^3}")#text(", then we have the pointwise translation symmetry")

#align(center)[#tao-fit-display[#mitex("q_i[s](t) := q_i(t) + s e^j")]]

#text("for all ")#mi("{i=1,\\dots,N}")#text(", ")#mi("{s \\in{\\bf R}}")#text(" and some ")#mi("{j=1,\\dots,3}")#text(", in which case ")#mi("{\\dot q_i(t) = e^j}")#text(", and the conserved quantity ")#link(<tao-736bc2d4e0945110e88f>)[#text("(11)")]#text(" becomes")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^n m_i \\dot q_i^j(t);")]]

#text("as ")#mi("{j=1,\\dots,3}")#text(" was arbitrary, this establishes conservation of the ")#emph[#text("total momentum")]

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^n m_i \\dot q_i(t).")]]

#text("Similarly, if we have the rotation invariance")

#align(center)[#tao-fit-display[#mitex("V( R q_1, \\dots, Rq_N ) = V( q_1, \\dots, q_N )")]]

#text("for any ")#mi("{q_1,\\dots,q_N \\in {\\bf R}^3}")#text(" and ")#mi("{R \\in SO(3)}")#text(", then we have the pointwise rotation symmetry")

#align(center)[#tao-fit-display[#mitex("q_i[s](t) := \\exp( s A ) q_i(t)")]]

#text("for any skew-symmetric real ")#mi("{3 \\times 3}")#text(" matrix ")#mi("{A}")#text(", in which case ")#mi("{\\dot q_i(t) = A q_i(t)}")#text(", and the conserved quantity ")#link(<tao-736bc2d4e0945110e88f>)[#text("(11)")]#text(" becomes")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^n m_i \\langle A q_i(t), \\dot q_i(t) \\rangle;")]]

#text("since ")#mi("{A}")#text(" is an arbitrary skew-symmetric matrix, this establishes conservation of the ")#emph[#text("total angular momentum")]

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^n m_i q_i(t) \\wedge \\dot q_i(t).")]]

#text("Below the fold, I will describe how Noether’s theorem can be used to locate all of the conserved quantities for the Euler equations of inviscid fluid flow, discussed in ")#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/")[#text("this previous post")]#text(", by interpreting that flow as geodesic flow in an infinite dimensional manifold.")

#metadata(none) <tao-ace9a616d51d86a33207>

#heading(level: 1)[#strong[#text(" — 1. Euler’s equations — ")]]

#text("The geometric setup for the geodesic interpretation of Euler’s equations of fluid flow is as follows. We will need two copies ")#mi("{{\\cal L}}")#text(" and ")#mi("{{\\cal E}}")#text(" of Euclidean space ")#mi("{{\\bf R}^n}")#text(", with two different structures. Firstly, we will have ")#link("http://en.wikipedia.org/wiki/Lagrangian_and_Eulerian_specification_of_the_flow_field")[#text("Lagrangian space")]

#align(center)[#tao-fit-display[#mitex("{\\cal L} = ({\\bf R}^n, \\text{vol}),")]]

#text("which is ")#mi("{{\\bf R}^n}")#text(" (viewed as a smooth manifold), together with the standard volume form ")#mi("{\\text{vol}}")#text(". This space should be thought of as the space of “labels” of the particles of the fluid, and its coordinates are known as ")#emph[#text("Lagrangian coordinates")]#text(". The symmetry group of this space is the space ")#mi("{\\text{Sdiff}({\\bf R}^n)}")#text(" of orientation-preserving and volume-preserving diffeomorphisms.")

#text("Secondly, we will need the ")#emph[#text("Eulerian space")]

#align(center)[#tao-fit-display[#mitex("{\\cal E} = ({\\bf R}^n, \\eta, \\text{vol})")]]

#text("which is the smooth manifold ")#mi("{{\\bf R}^n}")#text(" together with the Euclidean metric ")#mi("{\\eta}")#text(" and the standard volume form ")#mi("{\\text{vol}}")#text(". This space is the physical space of “positions” of the particles of the fluid. The symmetry space of this space is the space ")#mi("{SE(n) = SO(n) \\ltimes {\\bf R}^n}")#text(" of orientation-preserving rigid motions of Euclidean space.")

#text("Let ")#mi("{M}")#text(" be the space of diffeomorphisms ")#mi("{\\Phi: {\\cal L} \\rightarrow {\\cal E}}")#text(" from Lagrangian space to Eulerian space that preserve volume and orientation; this can be viewed as an infinite-dimensional manifold. A single element of ")#mi("{M}")#text(" describes the positions of an incompressible fluid at a snapshot in time; an incompressible fluid flow is then described by a curve ")#mi("{\\Phi: {\\bf R} \\rightarrow M}")#text(". The time derivative ")#mi("{\\dot \\Phi(t): {\\cal L} \\rightarrow T{\\cal E}}")#text(" of such a curve can be viewed in Eulerian coordinates as the ")#emph[#text("velocity field")]#text(" ")#metadata(none) <tao-84bae4db933bb6e48e3d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("u(t) := \\dot \\Phi(t) \\circ \\Phi^{-1}(t).")]]

#text("If one then defines the Lagrangian")

#align(center)[#tao-fit-display[#tao-math("J[\\Phi] := \\int_{\\bf R} (\\int_{\\cal E} \\frac{1}{2} \\left|u(t,x)\\right|^2\\ dx)\\ dt", block: true)]]

#text("then one can show that the critical points ")#mi("{\\Phi}")#text(" of this Lagrangian (formally) correspond to solutions ")#mi("{u}")#text(" to the Euler equations using the correspondence ")#link(<tao-84bae4db933bb6e48e3d>)[#text("(12)")]#text(": see ")#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/")[#text("this previous blog post")]#text(" for details.")

#text("Applying a volume-preserving change of coordinates, the Lagrangian can also be expressed as")

#align(center)[#tao-fit-display[#tao-math("J[\\Phi] := \\int_{\\bf R} (\\int_{\\cal L} \\frac{1}{2} \\left|\\dot \\Phi(t,x)\\right|^2\\ dx)\\ dt.", block: true)]]

#text("There are then three types of symmetries that are evident for this Lagrangian: time symmetry; symmetry on the Eulerian space; and symmetry on the Lagrangian space.")

#text("We begin with time symmetry, ")#mi("{\\Phi[s](t) := \\Phi(t-s)}")#text(", which comes from the fact that the Lagrangian does not depend explicitly on the time variable ")#mi("{t}")#text(". As discussed before, this gives conservation of the Hamiltonian ")#link(<tao-0c0452c0ba8bed70d49c>)[#text("(10)")]#text(", which (formally, at least) becomes")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\cal L} \\frac{1}{2} \\left|\\dot \\Phi(t,x)\\right|^2\\ dx = \\int_{\\cal E} \\frac{1}{2} \\left|u(t,x)\\right|^2\\ dx", block: true)]]

#text("thus giving the familiar energy conservation law for the Euler equations.")

#text("Now we use the symmetry group ")#mi("{SE(n) = SO(n) \\ltimes {\\bf R}^n}")#text(" that acts on the Eulerian space ")#mi("{{\\cal E}}")#text(", and hence on fluid flows ")#mi("{\\Phi(t): {\\cal L} \\rightarrow {\\cal E}}")#text(". This is a pointwise symmetry of the Lagrangian, and formally gives conservation of total momentum")

#align(center)[#tao-fit-display[#mitex("\\int_{\\cal L} \\dot \\Phi(t,x)\\ dx= \\int_{\\cal E} u(t,x)\\ dx")]]

#text("and total angular momentum")

#align(center)[#tao-fit-display[#mitex("\\int_{\\cal L} \\Phi(t,x) \\wedge \\dot \\Phi(t,x)\\ dx= \\int_{\\cal E} x \\wedge u(t,x)\\ dx")]]

#text("in exact analogy with the situation with the ")#mi("{N}")#text("-body system. (Indeed, one can formally view the Euler equations as an ")#mi("{N \\rightarrow \\infty}")#text(" limit of a certain family of ")#mi("{N}")#text("-body systems, which is indeed how these equations are physically derived.)")

#text("Finally, we consider symmetries on the Lagrangian space ")#mi("{{\\cal L}}")#text(". Any divergence-free vector field ")#mi("{Z}")#text(" on ")#mi("{{\\cal L}}")#text(" gives a one-parameter group ")#mi("{\\exp(sZ)}")#text(" of volume-preserving, orientation-preserving diffeomorphisms on ")#mi("{{\\cal L}}")#text(", which then act on fluid flows ")#mi("{\\Phi(t)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\Phi[s](t) := \\Phi(t) \\cdot \\exp(-sX).")]]

#text("This is a pointwise symmetry of the Lagrangian, with infinitesimal derivative")

#align(center)[#tao-fit-display[#mitex("\\delta \\Phi(t) = - \\nabla_Z \\Phi(t).")]]

#text("Applying ")#link(<tao-736bc2d4e0945110e88f>)[#text("(11)")]#text(", we thus (formally) conclude that the quantity ")#metadata(none) <tao-37aa022583059b190b36>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\int_{{\\cal L}} \\nabla_Z \\Phi(t,x) \\cdot \\dot \\Phi(t,x)\\ dx")]]

#text("is conserved. We can write this in coordinates as")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\cal L}} Z^i(x) (\\partial_{x^i} \\Phi^j(t,x)) \\dot \\Phi^j(t,x)\\ dx")]]

#text("We can specialise this conservation law by working with specific choices of divergence-free vector field ")#mi("{Z}")#text(". For instance, suppose we have a closed loop ")#mi("{\\gamma: S^1 \\rightarrow {\\cal L}}")#text(", which we parameterise by unit speed: ")#tao-math("{\\left|\\dot \\gamma\\right| = 1}", block: false)#text(". For an infinitesimal ")#mi("{\\epsilon > 0}")#text(", we can then create a divergence-free vector field by setting ")#mi("{Z(x) = \\dot \\gamma(s)}")#text(" when ")#mi("{x}")#text(" lies in the (transverse) ")#mi("{\\epsilon}")#text("-neighbourhood of ")#mi("{\\gamma(s)}")#text(", and zero otherwise. It is geometrically obvious that this field is divergence-free (up to errors of ")#mi("{O(\\epsilon)}")#text("). The conserved quantity ")#link(<tao-37aa022583059b190b36>)[#text("(13)")]#text(" is then equal to")

#align(center)[#tao-fit-display[#mitex("\\pi \\epsilon^2 \\int_{S^1} (\\nabla_{\\dot \\gamma(s)} \\Phi(t,\\gamma(s))) \\cdot \\dot \\Phi(t,\\gamma(s))\\ ds")]]

#text("up to lower order terms, so that the quantity")

#align(center)[#tao-fit-display[#mitex("\\int_{S^1} (\\nabla_{\\dot \\gamma(s)} \\Phi(t,\\gamma(s))) \\cdot \\dot \\Phi(t,\\gamma(s))\\ ds")]]

#text("is conserved. Writing ")#mi("{\\tilde \\gamma = \\tilde \\gamma_t}")#text(" for the curve ")#mi("{s \\mapsto \\Phi(t,\\gamma(s))}")#text(", we see from the chain rule that this is equal to")

#align(center)[#tao-fit-display[#mitex("\\int_{S^1} \\partial_s \\tilde \\gamma(s) \\cdot u( t, \\tilde \\gamma(s) )\\ ds,")]]

#text("giving ")#link("http://en.wikipedia.org/wiki/Kelvin's_circulation_theorem")[#text("Kelvin’s circulation theorem")]#text(".")

#text("More generally, we can generate a divergence-free vector field ")#mi("{Z^i}")#text(" from an alternating ")#mi("{2}")#text("-vector ")#mi("{W^{ij}}")#text(" by taking a further divergence:")

#align(center)[#tao-fit-display[#mitex("Z^i = \\partial_{x^k} W^{ik}.")]]

#text("Integrating by parts, we can then write ")#link(<tao-37aa022583059b190b36>)[#text("(13)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("- \\int_{{\\cal L}} W^{ik}(x) (\\partial_{x^i} \\Phi^j(t,x)) (\\partial_{x^k} \\dot \\Phi^j(t,x))\\ dx;")]]

#text("since ")#mi("{W^{ik}}")#text(" is an arbitrary alternating ")#mi("{2}")#text("-tensor, we conclude that for each ")#mi("{x}")#text(" and ")#mi("{i,k}")#text(", the quantity")

#align(center)[#tao-fit-display[#mitex("(\\partial_{x^i} \\Phi^j(t,x)) (\\partial_{x^k} \\dot \\Phi^j(t,x)) - (\\partial_{x^k} \\Phi^j(t,x)) (\\partial_{x^i} \\dot \\Phi^j(t,x))")]]

#text("is conserved in time. Writing ")#mi("{\\dot \\Phi = u( \\Phi )}")#text(" and using the chain rule, this becomes")

#align(center)[#tao-fit-display[#mitex("(\\partial_{x^i} \\Phi^j(t,x)) (\\partial_{x^k} \\Phi^l(t,x)) (\\partial_l u^j)(t,x)")]]

#align(center)[#tao-fit-display[#mitex("- (\\partial_{x^k} \\Phi^j(t,x)) (\\partial_{x^i} \\Phi^l(t,x)) (\\partial_l u^j)(t,x)")]]

#text("which after interchange of the ")#mi("{j,l}")#text(" indices may be rewritten in terms of the vorticity ")#mi("{\\omega_{lj} = \\partial_l u_j - \\partial_j u_l}")#text(" as")

#align(center)[#tao-fit-display[#mitex("(\\partial_{x^i} \\Phi^j(t,x)) (\\partial_{x^k} \\Phi^l(t,x)) \\omega_{lj}(t,x),")]]

#text("giving the pointwise conservation of the pullback ")#mi("{\\Phi^* \\omega}")#text(" of the vorticity in Lagrangian coordinates. (Of course, this is just the differential form of Kelvin’s circulation theorem; it also implies conservation of the vortex stream lines in Lagrangian coordinates.)")

#text("Finally, as the vorticity is divergence-free (when viewed as a polar vector field), the pullback ")#mi("{\\Phi^* \\omega}")#text(" is also. If we then set ")#mi("{Z}")#text(" to be the vector field associated to the conserved quantity ")#mi("{\\Phi^* \\omega}")#text(", the quantity ")#link(<tao-37aa022583059b190b36>)[#text("(13)")]#text(" can then be rewritten as the ")#link("http://en.wikipedia.org/wiki/Helicity_(fluid_mechanics)")[#text("helicity")]

#align(center)[#tao-fit-display[#mitex("\\int_{{\\cal E}} \\omega \\cdot u\\ dx,")]]

#text("which is then also conserved; a similar argument gives conservation of the helicity on any set that is the union of stream lines.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The above Lagrangian mechanics calculations can also be ")#link("http://en.wikipedia.org/wiki/Hamiltonian_mechanics#As_a_reformulation_of_Lagrangian_mechanics")[#text("recast into a Hamiltonian mechanics formalism")]#text("; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=672198")[#text("this paper of Olver")]#text(" for a Hamiltonian perspective on the conservation laws for the Euler equations.")
]

#heading(level: 1)[#text("Comments (24)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-273698")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2014")])]

#text("Just below (6): “that the left-hand side of (2) is equal to” –> “that (2) is equivalent to” (if I’m not mistaken).")

#text("Also, for maps, correct horizontal spacing is achieved by using “\\colon” instead of “:”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-273771")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2014")])]

#text("The reason for my comment is that I don’t see how the left-hand side of an equation can be equal to an equation. (I hope I haven’t missed something obvious.)")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-273776")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2014")])]

#text("I’m puzzled by Example 2. I just dropped my pen and the actual pen/Earth trajectory combo didn’t seem to be a critical point of the given J over the next second (since a faster drop would have increased the KE and decreased the PE, thus increasing the integrand, for each t; whereas a hover would have *decreased* the integrand for each t). Is V here actually the *negative* of the PE, or (much likelier) am I misinterpreting/misapplying the example?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-273777")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2014")])]

#text("One has to respect the boundary conditions, i.e. the pen has to start and end at fixed locations. If one tries to make the pen hover for a long period of time, then to compensate it must suddenly burst downwards at great speed to reach its designated location at the end of the time interval, resulting in a large surge in kinetic energy which ends up making the functional J larger than if it had just dropped straight down. (It is true, though, that it is variationally advantageous for the pen to be somewhat slower initially than at later times (though not to hover at a standstill) to take some advantage of the higher potential energy there to minimise the action; of course, this behaviour is what one actually sees in real life.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-273780")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2014")])]

#text("Ah. So wherever the pencil ends up at t=1 (or at any t>0), it had to have gotten there via a J-minimizing trajectory. Thanks for clearing up my confusion!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-273786")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2014")])]

#text("Yes, this is how the principle of least action works, although (a) the minimum may only be a local minimum rather than a global minimum (in much the same fashion that geodesics may minimise length locally, but not necessarily globally), and (b) in fact one may only have a critical point rather than a local minimum (this is particularly the case when performing multidimensional variational problems, in which the domain is not just the time axis).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-273800")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2014")])]

#text("Thanks again. I’m now curious how the critical point is chosen, but it’s time for me to do some reading on my own (the fact that this stuff is already very pretty when only dimly understood will I hope be sufficient motivation).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03c7dffeb32b481ee0f417e5d29ec4c1f4fb7235fd40259a596399e4611946d2-8443daf68253693c201742daf7dc854a3e0872d5069abb4f53b3b25e6e5b201b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Denis")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-273972")[#strong[#text("Denis")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("Very interesting and useful post. By the occasion, may I ask you about your opinion on the related topic. What do you think about the geometric theory of nonlinear PDE a.k.a. secondary calculus and diffiety theory being developed by these people: ")#link("http://www.levi-civita.org")[#text("http://www.levi-civita.org")]#text(" Can this marginal science be perspective for further development and applications?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ad5c42fe82487230a30392028f42e1abcd73bac1b1c3107d1200eb40362f487-86a1b68e1026b92ecc5257605c1ef2a1241297705954af099ce19c1008247a01.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jussilindgren")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-273997")[#strong[#text("jussilindgren")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("Dear Terry, do you think there is an analogy between the Euler equations and Einstein field equations? In GR I understand that the field equation is an Euler-Lagrange equation for the Hilbert action, whereas the actual path can be obtained by plugging the metric in the geodesic equation (Euler-Lagrange equations as well) ? As the Hilbert action is basically a minimization scheme for “average curvature”, could there be an interesting variational formulation based on e.g. minimizing some integrals of Frobenius norms of the gradient tensors or something along these lines? Best,")#linebreak()#text(" Jussi")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Conserved quantities for the surface quasi-geostrophic equation | What's new")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-274335")[#strong[#text("Conserved quantities for the surface quasi-geostrophic equation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2014")])]

#text("[…] the previous blog post, the Euler equations for inviscid incompressible fluid flow were interpreted in a Lagrangian […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-274498")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2014")])]

#text("Is equation (12) a sort of logarithmic derivative?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-274513")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2014")])]

#text("Yes, in the infinite-dimensional Lie group of diffeomorphisms on ")#mi("{\\bf R}^n")#text(". For instance, if ")#mi("\\Phi(0)")#text(" is the identity map (identifying both ")#mi("{\\cal L}")#text(" and ")#mi("{\\cal E}")#text(" with ")#mi("{\\bf R}^n")#text("), and ")#mi("u(t) = X")#text(" is a fixed vector field, then the integrated flow map ")#mi("\\Phi(t)")#text(" is often denoted ")#mi("\\exp(tX)")#text(", which is consistent with the interpretation of ")#mi("u")#text(" as a logarithmic derivative of ")#mi("\\Phi")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-274785")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2014")])]

#text("Your Lagrangian J(\\phi) is just an L^2 norm whether you integrate in the Lagrangian or Euler space, right? So we expecte a large number of symmetries, like some sort of infinite rotation group?")

#text("When I was a freshman, we set the derivative to zero.")#linebreak()#text(" And we drew elaborate charts keeping track of the sign of the second derivative.")#linebreak()#text(" All discussions I seen using calculus of variations fall into extremes. Either they justifying the critical points or omitting those details entirely.")

#text("Also, I highly recommend using Einstein summation convention — if you wish.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/491865fa8b9ead62e7d655630de8f6285dcb47fac81123a16c81b95d4724ee34-f0d62494e4296a670c9aaa414df7758dfce1b7a04681219e02041d308e1dbabe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of damtson")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-274927")[#strong[#text("damtson")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2014")])]

#text("Thank you for a very interesting posting. A few remarks of historical character, with potential bias toward physics literature: the first paper on the Lagrangian formulation of (relativistic) fluid dynamics seems to be by Taub in 1954 (")#link("http://journals.aps.org/pr/abstract/10.1103/PhysRev.94.1468")[#text("http://journals.aps.org/pr/abstract/10.1103/PhysRev.94.1468")]#text("), and the first paper mentioning a Hamiltonian structure of the (compressible) Euler equations was written by the great Lev Landau in 1941 (J. Phys. USSR 5, 71 (1941), reprinted in the book by Khalatnikov “An introduction to the theory of superfluidity”). Kelvin’s circulation theorem was derived from Noether’s theorem in ")#link("http://arxiv.org/abs/hep-th/0101029")[#text("http://arxiv.org/abs/hep-th/0101029")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b16b57b2061018808964e85b00b84d898a2186a561a818f9482831648fbf5a1-e17d544f392b6bfd0cc692da244bea947ad4973eb1a964f22aae0e67f2cfe30b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matrix Elements of Lorentzian Hamiltonian Constraint in LQG by Alesci,Liegener and Zipfel | quantumtetrahedron")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-291184")[#strong[#text("Matrix Elements of Lorentzian Hamiltonian Constraint in LQG by Alesci,Liegener and Zipfel | quantumtetrahedron")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2014")])]

#text("[…] Noether’s theorem, and the conservation laws for the Euler equations (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b16b57b2061018808964e85b00b84d898a2186a561a818f9482831648fbf5a1-e17d544f392b6bfd0cc692da244bea947ad4973eb1a964f22aae0e67f2cfe30b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sagemath 18: Calculation of the Matrix Elements of Thiemann’s Hamiltonian Constraint in Loop Quantum Gravity | quantumtetrahedron")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-299116")[#strong[#text("Sagemath 18: Calculation of the Matrix Elements of Thiemann’s Hamiltonian Constraint in Loop Quantum Gravity | quantumtetrahedron")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2014")])]

#text("[…] Noether’s theorem, and the conservation laws for the Euler equations (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-379464")[#strong[#text("Navier-Stokes Fluid Computers | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2014")]

#text("[…] here is a follow up post on Tao’s blog (and a few more II, III), and a post on Shtetl […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b526dbf887c0fdf9c8f07fab57d86a3b61fad497cd67390d6c2a0f24773a565-be2bcea39e4d7ba3d95a05e3bf839ca4b7f499abed28a3021f5f1b6cf95acbd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-470217")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2016")])]

#text("I am posting the following papers in case you haven’t seen them before.")

#text("It seems like X. He found another conserved integral for Euler (the “alignment”):")

#link("http://www.sciencedirect.com/science/article/pii/S0893965999000348")[#text("http://www.sciencedirect.com/science/article/pii/S0893965999000348")]

#text("It appears the same author later found a sufficient condition for ")#mi("L^2")#text(" blowup, using an unrelated technique.")

#link("http://arxiv.org/pdf/math/0209323.pdf")[#text("Click to access 0209323.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-570480")[#strong[#text("تقارن،قوانین پایستگی و اِمی نٌودِر - سیتپـــــور")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2020")]

#text("[…] Noether’s theorem, and the conservation laws for the Euler equations […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-694081")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2026")])]

#text("Prof. Tao:")

#emph[#text("The rule of thumb can fail when one is dealing with “global” or “cohomologically non-trivial” integral identities of a topological nature.")]

#text("Please forgive my naive thinking- I originally thought this could be solved by integration by parts. Could you elaborate on what the strategy is for proving “global” or “cohomologically non-trival” identities (such as Gauss-Bonnet Theorem)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-694082")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2026")])]

#text("At the same time, I don’t quite understand why this rule of thumb fails when dealing with this type of identity?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-694090")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2026")])]

#text("What is perhaps worth mentioning is that this describes only half of Noether’s seminal work, what is known as Noether’s first theorem. Noether’s second theorem is equally important and beautiful, and is closely related to what physicists call “gauge symmetries.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-694137")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2026")])]

#text("In Example 1, why is a harmonic map defined in terms of critical points of the energy functional rather than the L¹ type functional? For instance, for the geodesics and minimal surfaces mentioned here, I think it would be more intuitive to define them using critical points of length and area.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/#comment-694145")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2026")])]

#text("I am ")#link("https://claude.ai/share/dc4497e8-a429-4c3f-8ada-1016c3813a1a")[#text("outsourcing this question to an AI")]#text(". Roughly speaking, when dealing with ")#emph[#text("parameterized")]#text(" curves and surfaces, as opposed to their ")#emph[#text("unparameterized")]#text(" counterparts, energy is a more natural thing to minimize (or criticalize) than length or area, as it detects the parameterization as well as the geometric shape. Also, experience has shown that quadratic (L^2) type quantities have better variational behavior than L^1 type quantities (ultimately because ")#tao-math("x \\mapsto \\left|x\\right|^2", block: false)#text(" is a nice polynomial, whereas ")#tao-math("x \\mapsto \\left|x\\right|", block: false)#text(" is not even differentiable at the origin).")
]
]
