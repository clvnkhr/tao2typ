// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T15:19:32.703284+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Erdos discrepancy problem via the Elliott conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Erdos discrepancy problem via the Elliott conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 September 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/")[#text("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://www.ams.org/mathscinet-getitem?mr=177943")[#text("Chowla conjecture")]#text(" asserts that all non-trivial correlations of ")#link("https://en.wikipedia.org/wiki/Liouville_function")[#text("the Liouville function")]#text(" are asymptotically negligible; for instance, it asserts that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq X} \\lambda(n) \\lambda(n+h) = o(X)")]]

#text("as ")#mi("{X \\rightarrow \\infty}")#text(" for any fixed natural number ")#mi("{h}")#text(". This conjecture remains open, though there are a number of partial results (e.g. these ")#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/")[#text("two")]#text(" ")#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/")[#text("previous results")]#text(" of Matomaki, Radziwill, and myself).")

#text("A natural generalisation of Chowla’s conjecture was proposed ")#link("http://www.ams.org/mathscinet-getitem?mr=1292619")[#text("by Elliott")]#text(". For simplicity we will only consider Elliott’s conjecture for the pair correlations")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq X} g(n) \\overline{g}(n+h).")]]

#text("For such correlations, the conjecture was that one had ")#metadata(none) <tao-ba08a661b09e23d06c15>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{n \\leq X} g(n) \\overline{g}(n+h) = o(X)")]]

#text("as ")#mi("{X \\rightarrow \\infty}")#text(" for any natural number ")#mi("{h}")#text(", as long as ")#mi("{g}")#text(" was a completely multiplicative function with magnitude bounded by ")#mi("{1}")#text(", and such that ")#metadata(none) <tao-3298c63581b4eba57380>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_p \\text{Re} \\frac{1 - g(p) \\overline{\\chi(p)} p^{-it}}{p} = +\\infty")]]

#text("for any Dirichlet character ")#mi("{\\chi}")#text(" and any real number ")#mi("{t}")#text(". In the language of “pretentious number theory”, as developed by Granville and Soundararajan, the hypothesis ")#link(<tao-3298c63581b4eba57380>)[#text("(2)")]#text(" asserts that the completely multiplicative function ")#mi("{g}")#text(" does not “pretend” to be like the completely multiplicative function ")#mi("{n \\mapsto \\chi(n) n^{it}}")#text(" for any character ")#mi("{\\chi}")#text(" and real number ")#mi("{t}")#text(". A condition of this form is necessary; for instance, if ")#mi("{g(n)}")#text(" is precisely equal to ")#mi("{\\chi(n) n^{it}}")#text(" and ")#mi("{\\chi}")#text(" has period ")#mi("{q}")#text(", then ")#mi("{g(n) \\overline{g}(n+q)}")#text(" is equal to ")#mi("{1_{(n,q)=1} + o(1)}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(" and ")#link(<tao-ba08a661b09e23d06c15>)[#text("(1)")]#text(" clearly fails. The prime number theorem in arithmetic progressions implies that the Liouville function obeys ")#link(<tao-3298c63581b4eba57380>)[#text("(2)")]#text(", and so the Elliott conjecture contains the Chowla conjecture as a special case.")

#text("As it turns out, Elliott’s conjecture is false as stated, with the counterexample ")#mi("{g}")#text(" having the property that ")#mi("{g}")#text(" “pretends” ")#emph[#text("locally")]#text(" to be the function ")#mi("{n \\mapsto n^{it_j}}")#text(" for ")#mi("{n}")#text(" in various intervals ")#mi("{[1, X_j]}")#text(", where ")#mi("{X_j}")#text(" and ")#mi("{t_j}")#text(" go to infinity in a certain prescribed sense. See ")#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/")[#text("this paper of Matomaki, Radziwill, and myself")]#text(" for details. However, we view this as a technicality, and continue to believe that certain “repaired” versions of Elliott’s conjecture still hold. For instance, our counterexample does not apply when ")#mi("{g}")#text(" is restricted to be real-valued rather than complex, and we believe that Elliott’s conjecture is valid in this setting. Returning to the complex-valued case, we still expect the asymptotic ")#link(<tao-ba08a661b09e23d06c15>)[#text("(1)")]#text(" provided that the condition ")#link(<tao-3298c63581b4eba57380>)[#text("(2)")]#text(" is replaced by the stronger condition")

#align(center)[#tao-fit-display[#tao-math("\\sup_{\\left|t\\right| \\leq X} \\left|\\sum_{p \\leq X} \\text{Re} \\frac{1 - g(p) \\overline{\\chi(p)} p^{-it}}{p}\\right| \\rightarrow +\\infty", block: true)]]

#text("as ")#mi("{X \\rightarrow +\\infty}")#text(" for all fixed Dirichlet characters ")#mi("{\\chi}")#text(". In our paper we supported this claim by establishing a certain “averaged” version of this conjecture; see that paper for further details. (See also ")#link("http://arxiv.org/abs/1502.02646")[#text("this recent paper of Frantzikinakis and Host")]#text(" which establishes a different averaged version of this conjecture.)")

#text("One can make a stronger “non-asymptotic” version of this corrected Elliott conjecture, in which the ")#mi("{X}")#text(" parameter does not go to infinity, or equivalently that the function ")#mi("{g}")#text(" is permitted to depend on ")#mi("{X}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Non-asymptotic Elliott conjecture)")]#text(" ")#metadata(none) <tao-0f9c00b3f38f964ee172>#text(" Let ")#mi("{\\varepsilon > 0}")#text(", let ")#mi("{A \\geq 1}")#text(" be sufficiently large depending on ")#mi("{\\varepsilon}")#text(", and let ")#mi("{X}")#text(" be sufficiently large depending on ")#mi("{A,\\varepsilon}")#text(". Suppose that ")#mi("{g}")#text(" is a completely multiplicative function with magnitude bounded by ")#mi("{1}")#text(", such that")

#align(center)[#tao-fit-display[#tao-math("\\inf_{\\left|t\\right| \\leq AX} \\left|\\sum_{p \\leq X} \\text{Re} \\frac{1 - g(p) \\overline{\\chi(p)} p^{-it}}{p}\\right| \\geq A", block: true)]]

#text("for all Dirichlet characters ")#mi("{\\chi}")#text(" of period at most ")#mi("{A}")#text(". Then one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\leq X} g(n) \\overline{g(n+h)}\\right| \\leq \\varepsilon X", block: true)]]

#text("for all natural numbers ")#mi("{1 \\leq h \\leq 1/\\varepsilon}")#text(".")
]

#text("The ")#mi("{\\varepsilon}")#text("-dependent factor ")#mi("{A}")#text(" in the constraint ")#tao-math("{\\left|t\\right| \\leq AX}", block: false)#text(" is necessary, as can be seen by considering the completely multiplicative function ")#mi("{g(n) := n^{2iX}}")#text(" (for instance). Again, the results in ")#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/")[#text("my previous paper with Matomaki and Radziwill")]#text(" can be viewed as establishing an averaged version of this conjecture.")

#text("Meanwhile, we have the following conjecture that is the focus of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=The_Erd%C5%91s_discrepancy_problem")[#text("Polymath5 project")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2 (Erdös discrepancy conjecture)")]#text(" ")#metadata(none) <tao-6bf99799d0ef91be6c25>#text(" For any function ")#mi("{f: {\\bf N} \\rightarrow \\{-1,+1\\}}")#text(", the discrepancy")

#align(center)[#tao-fit-display[#tao-math("\\sup_{n,d \\in {\\bf N}} \\left|\\sum_{j=1}^n f(jd)\\right|", block: true)]]

#text("is infinite.")
]

#text("It is instructive to compute some near-counterexamples to Conjecture ")#link(<tao-6bf99799d0ef91be6c25>)[#text("2")]#text(" that illustrate the difficulty of the Erdös discrepancy problem. The first near-counterexample is that of a non-principal ")#link("https://en.wikipedia.org/wiki/Dirichlet_character")[#text("Dirichlet character")]#text(" ")#mi("{f(n) = \\chi(n)}")#text(" that takes values in ")#mi("{\\{-1,0,+1\\}}")#text(" rather than ")#mi("{\\{-1,+1\\}}")#text(". For this function, one has from the complete multiplicativity of ")#mi("{\\chi}")#text(" that")

#tao-aligned(keep: true)[


#tao-math("\\left|\\sum_{j=1}^n f(jd)\\right|  & = \\left|\\sum_{j=1}^n \\chi(j) \\chi(d)\\right|", block: true)



#tao-math(" & \\leq \\left|\\sum_{j=1}^n \\chi(j)\\right|.", block: true)
]

#text("If ")#mi("{q}")#text(" denotes the period of ")#mi("{\\chi}")#text(", then ")#mi("{\\chi}")#text(" has mean zero on every interval of length ")#mi("{q}")#text(", and thus")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{j=1}^n f(jd)\\right| \\leq \\left|\\sum_{j=1}^n \\chi(j)\\right| \\leq q.", block: true)]]

#text("Thus ")#mi("{\\chi}")#text(" has bounded discrepancy.")

#text("Of course, this is not a true counterexample to Conjecture ")#link(<tao-6bf99799d0ef91be6c25>)[#text("2")]#text(" because ")#mi("{\\chi}")#text(" can take the value ")#mi("{0}")#text(". Let us now consider the following variant example, which is the simplest member of a family of examples studied ")#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/z")[#text("by Borwein, Choi, and Coons")]#text(". Let ")#mi("{\\chi = \\chi_3}")#text(" be the non-principal Dirichlet character of period ")#mi("{3}")#text(" (thus ")#mi("{\\chi(n)}")#text(" equals ")#mi("{+1}")#text(" when ")#mi("{n=1 \\text{ mod } 3}")#text(", ")#mi("{-1}")#text(" when ")#mi("{n = 2 \\text{ mod } 3}")#text(", and ")#mi("{0}")#text(" when ")#mi("{n = 0 \\text{ mod } 3}")#text("), and define the completely multiplicative function ")#mi("{f = \\tilde \\chi: {\\bf N} \\rightarrow \\{-1,+1\\}}")#text(" by setting ")#mi("{\\tilde \\chi(p) := \\chi(p)}")#text(" when ")#mi("{p \\neq 3}")#text(" and ")#mi("{\\tilde \\chi(3) = +1}")#text(". This is about the simplest modification one can make to the previous near-counterexample to eliminate the zeroes. Now consider the sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^n \\tilde \\chi(j)")]]

#text("with ")#mi("{n := 1 + 3 + 3^2 + \\dots + 3^k}")#text(" for some large ")#mi("{k}")#text(". Writing ")#mi("{j = 3^a m}")#text(" with ")#mi("{m}")#text(" coprime to ")#mi("{3}")#text(" and ")#mi("{a}")#text(" at most ")#mi("{k}")#text(", we can write this sum as")

#align(center)[#tao-fit-display[#mitex("\\sum_{a=0}^k \\sum_{1 \\leq m \\leq n/3^j} \\tilde \\chi(3^a m).")]]

#text("Now observe that ")#mi("{\\tilde \\chi(3^a m) = \\tilde \\chi(3)^a \\tilde \\chi(m) = \\chi(m)}")#text(". The function ")#mi("{\\chi}")#text(" has mean zero on every interval of length three, and ")#mi("{\\lfloor n/3^j\\rfloor}")#text(" is equal to ")#mi("{1}")#text(" mod ")#mi("{3}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq m \\leq n/3^j} \\tilde \\chi(3^a m) = 1")]]

#text("for every ")#mi("{a=0,\\dots,k}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^n \\tilde \\chi(j) = k+1 \\gg \\log n.")]]

#text("Thus ")#mi("{\\tilde \\chi}")#text(" also has unbounded discrepancy, but only barely so (it grows logarithmically in ")#mi("{n}")#text("). These examples suggest that the main “enemy” to proving Conjecture ")#link(<tao-6bf99799d0ef91be6c25>)[#text("2")]#text(" comes from completely multiplicative functions ")#mi("{f}")#text(" that somehow “pretend” to be like a Dirichlet character but do not vanish at the zeroes of that character. (Indeed, the special case of Conjecture ")#link(<tao-6bf99799d0ef91be6c25>)[#text("2")]#text(" when ")#mi("{f}")#text(" is completely multiplicative is already open, appears to be an important subcase.)")

#text("All of these conjectures remain open. However, I would like to record in this blog post the following striking connection, illustrating the power of the Elliott conjecture (particularly in its nonasymptotic formulation):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Elliott conjecture implies unbounded discrepancy)")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" Conjecture ")#link(<tao-0f9c00b3f38f964ee172>)[#text("1")]#text(" implies Conjecture ")#link(<tao-6bf99799d0ef91be6c25>)[#text("2")]#text(".")
]

#text("The argument relies heavily on two observations that were previously made in connection with the Polymath5 project. The first is a ")#link("http://michaelnielsen.org/polymath1/index.php?title=Fourier_reduction")[#text("Fourier-analytic reduction")]#text(" that replaces the Erdos Discrepancy Problem with an averaged version for completely multiplicative functions ")#mi("{g}")#text(". An application of Cauchy-Schwarz then shows that any counterexample to that version will violate the conclusion of Conjecture ")#link(<tao-0f9c00b3f38f964ee172>)[#text("1")]#text(", so if one assumes that conjecture then ")#mi("{g}")#text(" must pretend to be like a function of the form ")#mi("{n \\mapsto \\chi(n) n^{it}}")#text(". One then uses (a generalisation) of a ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_discrepancy_multiplicative_functions_do_not_correlate_with_characters")[#text("second argument from Polymath5")]#text(" to rule out this case, basically by reducing matters to a more complicated version of the Borwein-Choi-Coons analysis. Details are provided below the fold.")

#text("There is some hope that the Chowla and Elliott conjectures can be attacked, as the parity barrier which is so impervious to attack for the twin prime conjecture seems to be more permeable in this setting. (For instance, in my ")#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/")[#text("previous post")]#text(" I raised a possible approach, based on establishing expander properties of a certain random graph, which seems to get around the parity problem, in principle at least.)")

#text("(Update, Sep 25: fixed some treatment of error terms, following a suggestion of Andrew Granville.)")

#metadata(none) <tao-4d22dcb83bbb29586a9a>

#heading(level: 1)[#strong[#text(" — 1. Fourier reduction — ")]]

#text("We will prove Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("3")]#text(" by contradiction, assuming that there is a function ")#mi("{f}")#text(" with bounded discrepancy and then concluding a violation of the Elliott conjecture.")

#text("The function ")#mi("{f: {\\bf N} \\rightarrow \\{-1,+1\\}}")#text(" need not have any multiplicativity properties, but by using ")#link("http://michaelnielsen.org/polymath1/index.php?title=Fourier_reduction")[#text("an argument from Polymath5")]#text(" we can extract a ")#emph[#text("random")]#text(" completely multiplicative function which also has good discrepancy properties (albeit in an probabilistic sense only):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (Fourier reduction)")]#text(" ")#metadata(none) <tao-2a693d0890235a642d03>#text(" Suppose that ")#mi("{f: {\\bf N} \\rightarrow \\{-1,+1\\}}")#text(" is a function such that ")#metadata(none) <tao-8bd574fdb05c2dc50171>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\sup_{n,d \\in {\\bf N}} \\left|\\sum_{j=1}^n f(jd)\\right| < +\\infty.", block: true)]]

#text("Then there exists a random completely multiplicative function ")#mi("{g}")#text(" of magnitude ")#mi("{1}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|\\sum_{j=1}^n g(j)\\right|^2 \\ll 1", block: true)]]

#text("uniformly for all natural numbers ")#mi("{n}")#text(" (we allow implied constants to depend on ")#mi("{f}")#text(").")
]

#emph[#text("Proof:")]#text(" For the readers convenience, we reproduce the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Fourier_reduction")[#text("Polymath5 argument")]#text(".")

#text("The space of completely multiplicative functions ")#mi("{g}")#text(" of magnitude ")#mi("{1}")#text(" can be identified with the infinite product ")#mi("{(S^1)^{\\bf Z}}")#text(" since ")#mi("{g}")#text(" is determined by its values ")#mi("{g(p) \\in S^1}")#text(" at the primes. In particular, this space is compact metrisable in the product topology. The functions ")#tao-math("{g \\mapsto \\left|\\sum_{j=1}^n g(j)\\right|^2}", block: false)#text(" are continuous in this topology for all ")#mi("{n}")#text(". By vague compactness of probability measures on compact metrisable spaces (Prokhorov’s theorem), it thus suffices to construct, for each ")#mi("{X \\geq 1}")#text(", a random completely multiplicative function ")#mi("{g}")#text(" of magnitude ")#mi("{1}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|\\sum_{j=1}^n g(j)\\right|^2 \\ll 1", block: true)]]

#text("for all ")#mi("{n \\leq X}")#text(", where the implied constant is uniform in ")#mi("{n}")#text(" and ")#mi("{X}")#text(".")

#text("By hypothesis, we have ")#metadata(none) <tao-f94e292b42137e8bc2ae>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|\\sum_{j=1}^n f(jd)\\right| \\ll 1", block: true)]]

#text("for all ")#mi("{n,d}")#text(" (the implied constant can depend on ")#mi("{f}")#text(" but is otherwise absolute). Let ")#mi("{X \\geq 1}")#text(", and let ")#mi("{p_1,\\dots,p_r}")#text(" be the primes up to ")#mi("{X}")#text(". Let ")#mi("{M \\geq X}")#text(" be a natural number that we assume to be sufficiently large depending on ")#mi("{X}")#text(". Define a function ")#mi("{F: ({\\bf Z}/M{\\bf Z})^r \\rightarrow \\{-1,+1\\}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("F( a_1,\\dots,a_r ) := f( p_1^{a_1} \\dots p_r^{a_r} )")]]

#text("for ")#mi("{a_1,\\dots,a_r \\in \\{0,\\dots,M-1\\}}")#text(". We also define the function ")#mi("{\\pi: [1,X] \\rightarrow ({\\bf Z}/M{\\bf Z})^r}")#text(" by setting ")#mi("{\\pi( p_1^{a_1} \\dots p_r^{a_r} ) := (a_1,\\dots,a_r)}")#text(" whenever ")#mi("{p_1^{a_1} \\dots p_r^{a_r}}")#text(" is in ")#mi("{[1,X]}")#text(" (this is well defined for ")#mi("{M \\geq X}")#text("). Applying ")#link(<tao-f94e292b42137e8bc2ae>)[#text("(4)")]#text(" for ")#mi("{n \\leq X}")#text(" and ")#mi("{d}")#text(" of the form ")#mi("{p_1^{a_1} \\dots p_r^{a_r}}")#text(" with ")#mi("{1 \\leq a_i \\leq M - X}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{j=1}^n F( x + \\pi(j) )\\right| \\ll 1", block: true)]]

#text("for all ")#mi("{n \\leq X}")#text(" and all but ")#mi("{O_X( M^{r-1} )}")#text(" of the ")#mi("{M^r}")#text(" elements ")#mi("{x = (a_1,\\dots,a_r)}")#text(" of ")#mi("{({\\bf Z}/M{\\bf Z})^r}")#text(". For the exceptional elements, we have the trivial bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{j=1}^n F( x + \\pi(j) )\\right| \\leq X.", block: true)]]

#text("Square-summing in ")#mi("{x}")#text(", we conclude (if ")#mi("{M}")#text(" is sufficiently large depending on ")#mi("{X}")#text(") that ")#metadata(none) <tao-af3e0180867cc177902a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("{\\bf E}_{x \\in ({\\bf Z}/M{\\bf Z})^r} \\left|\\sum_{j=1}^n F( x + \\pi(j) )\\right|^2 \\ll 1", block: true)]]

#text("By Fourier expansion, we can write")

#align(center)[#tao-fit-display[#mitex("F(x) = \\sum_{\\xi \\in ({\\bf Z}/M{\\bf Z})^r} \\hat F(\\xi) e( \\frac{x \\cdot \\xi}{M} )")]]

#text("where ")#mi("{(a_1,\\dots,a_r) \\cdot (\\xi_1,\\dots,\\xi_r) := a_1 \\xi_1 + \\dots + a_r \\xi_r}")#text(", ")#mi("{e(\\theta) := e^{2\\pi i \\theta}}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\hat F(\\xi) := {\\bf E}_{x \\in ({\\bf Z}/M{\\bf Z})^r} F(x) e( -\\frac{x \\cdot \\xi}{M} ).")]]

#text("A little Fourier-analytic calculation then allows us to write the left-hand side of ")#link(<tao-af3e0180867cc177902a>)[#text("(5)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\xi \\in ({\\bf Z}/M{\\bf Z})^r} \\left|\\hat F(\\xi)\\right|^2 \\left|\\sum_{j=1}^n e( \\frac{\\pi(j) \\cdot \\xi}{M} )\\right|^2.", block: true)]]

#text("On the other hand, from the Plancherel identity we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\xi \\in ({\\bf Z}/M{\\bf Z})^r} \\left|\\hat F(\\xi)\\right|^2 = 1", block: true)]]

#text("and so we can interpret ")#tao-math("{\\left|\\hat F(\\xi)\\right|^2}", block: false)#text(" as the probability distribution of a random frequency ")#mi("{\\xi = (\\xi_1,\\dots,\\xi_r) \\in ({\\bf Z}/M{\\bf Z})^r}")#text(". The estimate ")#link(<tao-af3e0180867cc177902a>)[#text("(5)")]#text(" now takes the form")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|\\sum_{j=1}^n e( \\frac{\\pi(j) \\cdot \\xi}{M} )\\right|^2 \\ll 1", block: true)]]

#text("for all ")#mi("{n \\leq N}")#text(". If we then define the completely multiplicative function ")#mi("{g}")#text(" by setting ")#mi("{g(p_j) := e( \\xi_j / M )}")#text(" for ")#mi("{j=1,\\dots,r}")#text(", and ")#mi("{g(p) := 1}")#text(" for all other primes, we obtain")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|\\sum_{j=1}^n g(j)\\right|^2 \\ll 1", block: true)]]

#text("for all ")#mi("{n \\leq X}")#text(", as desired. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" A similar reduction applies if the original function ")#mi("{f}")#text(" took values in the unit sphere of a complex Hilbert space, rather than in ")#mi("{\\{-1,+1\\}}")#text(". Conversely, the random ")#mi("{g}")#text(" constructed above can be viewed as an element of a unit sphere of a suitable Hilbert space, so the conclusion of Proposition ")#link(<tao-2a693d0890235a642d03>)[#text("4")]#text(" is in fact logically equivalent to failure of the Hilbert space version of the Erdös discrepancy conjecture.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" From linearity of expectation, we see from Proposition ")#link(<tao-2a693d0890235a642d03>)[#text("4")]#text(" that for any natural number ")#mi("{N}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\frac{1}{N} \\sum_{n=1}^N \\left|\\sum_{j=1}^n g(j)\\right|^2 \\ll 1", block: true)]]

#text("and hence for each ")#mi("{N}")#text(" we conclude that there exists a ")#emph[#text("deterministic")]#text(" completely multiplicative function of unit magnitude such that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{N} \\sum_{n=1}^N \\left|\\sum_{j=1}^n g(j)\\right|^2 \\ll 1.", block: true)]]

#text("This was the original formulation of the Fourier reduction in Polymath5, however the fact that ")#mi("{g}")#text(" varied with ")#mi("{N}")#text(" made this formulation inconvenient for our argument.")
]

#heading(level: 1)[#strong[#text(" — 2. Applying the Elliott conjecture — ")]]

#text("Suppose for contradiction that Conjecture ")#link(<tao-0f9c00b3f38f964ee172>)[#text("1")]#text(" holds but that there exists a function ")#mi("{f: {\\bf N} \\rightarrow \\{-1,+1\\}}")#text(" of bounded discrepancy in the sense of ")#link(<tao-8bd574fdb05c2dc50171>)[#text("(3)")]#text(". By Proposition ")#link(<tao-2a693d0890235a642d03>)[#text("4")]#text(", we may thus find a random completely multiplicative function ")#mi("{g}")#text(" of magnitude ")#mi("{1}")#text(" such that ")#metadata(none) <tao-e0c85f7b2112fbf034af>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("{\\bf E} \\left|\\sum_{j=1}^n g(j)\\right|^2 \\ll 1", block: true)]]

#text("for all ")#mi("{n}")#text(".")

#text("We now use Elliott’s conjecture as a sort of “inverse theorem” (in the spirit of the inverse sumset theorem of Frieman, and the inverse theorems for the Gowers uniformity norms) to force ")#mi("{g}")#text(" to pretend to behave like a modulated character quite often.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7")]#text(" ")#metadata(none) <tao-525eca1d5089dbdcbb67>#text(" Let the hypotheses and notation be as above. Let ")#mi("{\\varepsilon > 0}")#text(", and suppose that ")#mi("{X}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon}")#text(". Then with probability ")#mi("{1-O(\\varepsilon)}")#text(", one can find a Dirichlet character ")#mi("{\\chi}")#text(" of period ")#mi("{q = O_\\varepsilon(1)}")#text(" and a real number ")#mi("{t = O_\\varepsilon(X)}")#text(" such that ")#metadata(none) <tao-fb2b7fce0940161406a6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\sum_{p \\leq X} \\text{Re} \\frac{1 - g(p) \\overline{\\chi(p)} p^{-it}}{p} \\ll_\\varepsilon 1.")]]
]

#emph[#text("Proof:")]#text(" We use the van der Corput trick. Let ")#mi("{H \\geq 1}")#text(" be a moderately large natural number depending on ")#mi("{\\varepsilon}")#text(" to be chosen later, and suppose that ")#mi("{X}")#text(" is sufficiently large depending on ")#mi("{H,\\varepsilon}")#text(". From ")#link(<tao-e0c85f7b2112fbf034af>)[#text("(6)")]#text(" and the triangle inequality we have")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} {\\bf E}_{n \\in [1,X]} \\left|\\sum_{j=1}^n g(j)\\right|^2 \\ll 1", block: true)]]

#text("so from Markov’s inequality we see with probability ")#mi("{1-O(\\varepsilon)}")#text(" that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_{n \\in [1,X]} \\left|\\sum_{j=1}^n g(j)\\right|^2 \\ll_\\varepsilon 1.", block: true)]]

#text("Let us condition to this event. Shifting ")#mi("{n}")#text(" by ")#mi("{H}")#text(" we conclude (for ")#mi("{X}")#text(" large enough) that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_{n \\in [1,X]} \\left|\\sum_{j=1}^{n+H} g(j)\\right|^2 \\ll_\\varepsilon 1", block: true)]]

#text("and hence by the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_{n \\in [1,X]} \\left|\\sum_{j=n+1}^{n+H} g(j)\\right|^2 \\ll_\\varepsilon 1,", block: true)]]

#text("which we rewrite as")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_{n \\in [1,X]} \\left|\\sum_{h=1}^{H} g(n+h)\\right|^2 \\ll_\\varepsilon 1,", block: true)]]

#text("We can square the left-hand side out as")

#align(center)[#tao-fit-display[#mitex("\\sum_{h_1, h_2 \\in [1,H]} {\\bf E}_{n \\in [1,X]} g(n+h_1) \\overline{g(n+h_2)}.")]]

#text("The diagonal term ")#mi("{h_1,h_2}")#text(" contributes ")#mi("{H}")#text(" to this expression. Thus, for ")#mi("{H=O_\\varepsilon(1)}")#text(" sufficiently large depending on ")#mi("{\\varepsilon}")#text(", we can apply the triangle inequality and pigeonhole principle to find ")#emph[#text("distinct")]#text(" ")#mi("{h_1,h_2 \\in [1,H]}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E}_{n \\in [1,X]} g(n+h_1) \\overline{g(n+h_2)}\\right| \\gg_\\varepsilon 1.", block: true)]]

#text("By symmetry we can take ")#mi("{h_2 > h_1}")#text(". Setting ")#mi("{h := h_2 - h_1}")#text(", we conclude (for ")#mi("{X}")#text(" large enough) that")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E}_{n \\in [1,X]} g(n) \\overline{g(n+h)}\\right| \\gg_\\varepsilon 1.", block: true)]]

#text("Applying Conjecture ")#link(<tao-0f9c00b3f38f964ee172>)[#text("1")]#text(" in the contrapositive, we obtain the claim. ")#mi("\\Box")

#text("The conclusion ")#link(<tao-fb2b7fce0940161406a6>)[#text("(8)")]#text(" asserts that in some sense, ")#mi("{g}")#text(" “pretends” to be like the function ")#mi("{n \\mapsto \\chi(n)n^{it}}")#text("; as it has magnitude one, it should resemble the function ")#mi("{\\tilde \\chi}")#text(" discussed in the introduction. The remaining task is to find some generalisation of the argument that shows that ")#mi("{\\tilde \\chi}")#text(" had (logarithmically) large discrepancy to show that ")#mi("{g}")#text(" likewise fails to obey ")#link(<tao-e0c85f7b2112fbf034af>)[#text("(6)")]#text(".")

#heading(level: 1)[#strong[#text(" — 3. Ruling out correlation with modulated characters — ")]]

#text("We now use (a generalisation of) ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_discrepancy_multiplicative_functions_do_not_correlate_with_characters")[#text("this Polymath5 argument")]#text(". Let ")#mi("{g}")#text(" be the random completely multiplicative function provided by Proposition ")#link(<tao-2a693d0890235a642d03>)[#text("4")]#text(". We will need the following parameters:")

#list(
[#text("A sufficiently small quantity ")#mi("{0 < \\varepsilon < 1/2}")#text(".")],
[#text("A natural number ")#mi("{H \\geq 1}")#text(" that is sufficiently large depending on ")#mi("{\\varepsilon}")#text(".")],
[#text("A quantity ")#mi("{0 < \\delta < 1/2}")#text(" that is sufficiently small depending on ")#mi("{\\varepsilon,H}")#text(".")],
[#text("A natural number ")#mi("{k \\geq 1}")#text(" that is sufficiently large depending on ")#mi("{\\varepsilon,H,\\delta}")#text(".")],
[#text("A real number ")#mi("{X \\geq 1}")#text(" that is sufficiently large depending on ")#mi("{\\varepsilon,H,\\delta,k}")#text(".")]
)

#text("By Proposition ")#link(<tao-525eca1d5089dbdcbb67>)[#text("7")]#text(", we see with probability ")#mi("{1-O(\\varepsilon)}")#text(" that there exists a Dirichlet character ")#mi("{\\chi}")#text(" of period ")#mi("{q=O_\\varepsilon(1)}")#text(" and a real number ")#mi("{t = O_\\varepsilon(X)}")#text(" such that ")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\sum_{p \\leq X} \\text{Re} \\frac{1 - g(p) \\overline{\\chi(p)} p^{-it}}{p} \\ll_\\varepsilon 1.")]]

#text("By reducing ")#mi("{\\chi}")#text(" if necessary we may assume that ")#mi("{\\chi}")#text(" is primitive.")

#text("It will be convenient to cut down the size of ")#mi("{t}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8")]#text(" With probability ")#mi("{1-O(\\varepsilon)}")#text(", one has ")#metadata(none) <tao-7a918ea1f19a0c5baf9b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("t = O_{\\varepsilon}(X^\\delta).")]]
]

#emph[#text("Proof:")]#text(" By Proposition ")#link(<tao-525eca1d5089dbdcbb67>)[#text("7")]#text(" with ")#mi("{X}")#text(" replaced by ")#mi("{X^\\delta}")#text(", we see that with probability ")#mi("{1-O(\\varepsilon)}")#text(", one can find a Dirichlet character ")#mi("{\\chi^{\\prime}}")#text(" of period ")#mi("{q^{\\prime} = O_\\varepsilon(1)}")#text(" and a real number ")#mi("{t^{\\prime} = O_\\varepsilon( X^\\delta )}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq X^\\delta} \\text{Re} \\frac{1 - g(p) \\overline{\\chi^{\\prime}(p)} p^{-it^{\\prime}}}{p} \\ll_\\varepsilon 1.")]]

#text("We may assume that ")#tao-math("{\\left|t^{\\prime}-t\\right| \\geq X^\\delta}", block: false)#text(", since we are done otherwise. Applying the pretentious triangle inequality (see Lemma 3.1 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2276774")[#text("this paper of Granville and Soundararajan")]#text("), we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq X^\\delta} \\text{Re} \\frac{1 - \\chi(p) \\overline{\\chi^{\\prime}(p)} p^{-i(t^{\\prime}-t)}}{p} \\ll_\\varepsilon 1.")]]

#text("However, from the Vinogradov-Korobov zero-free region for ")#mi("{L(\\cdot,\\chi \\overline{\\chi^{\\prime}})}")#text(" (see ")#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/")[#text("this previous blog post")]#text(") it is not difficult to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq X^\\delta} \\text{Re} \\frac{1 - \\chi(p) \\overline{\\chi^{\\prime}(p)} p^{-i(t^{\\prime}-t)}}{p} \\gg \\log\\log X")]]

#text("if ")#mi("{X}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon,\\delta}")#text(", a contradiction. The claim follows. ")#mi("\\Box")

#text("Let us now condition to the probability ")#mi("{1-O(\\varepsilon)}")#text(" event that ")#mi("{\\chi}")#text(", ")#mi("{t}")#text(" exist obeying ")#link(<tao-fb2b7fce0940161406a6>)[#text("(8)")]#text(" and the bound ")#link(<tao-7a918ea1f19a0c5baf9b>)[#text("(9)")]#text(".")

#text("The bound ")#link(<tao-fb2b7fce0940161406a6>)[#text("(8)")]#text(" asserts that ")#mi("{g}")#text(" “pretends” to be like the completely multiplicative function ")#mi("{n \\mapsto \\chi(p) p^{it}}")#text(". We can formalise this by making the factorisation ")#metadata(none) <tao-c1299854f2b209632ab2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("g(n) := \\tilde \\chi(n) n^{it} h(n)")]]

#text("where ")#mi("{\\tilde \\chi}")#text(" is the completely multiplicative function of magnitude ")#mi("{1}")#text(" defined by setting ")#mi("{\\tilde \\chi(p) := \\chi(p)}")#text(" for ")#mi("{p \\not | q}")#text(" and ")#mi("{\\tilde \\chi(p) := g(p) p^{-it}}")#text(" for ")#mi("{p|q}")#text(", and ")#mi("{h}")#text(" is the completely multiplicative function of magnitude ")#mi("{1}")#text(" defined by setting ")#mi("{h(p) := g(p) \\overline{\\chi(p)} p^{-it}}")#text(" for ")#mi("{p \\not | q}")#text(", and ")#mi("{h(p) = 1}")#text(" for ")#mi("{p|q}")#text(". The function ")#mi("{\\tilde \\chi}")#text(" should be compared with the function of the same name studied in the introduction.")

#text("The bound ")#link(<tao-fb2b7fce0940161406a6>)[#text("(8)")]#text(" then becomes ")#metadata(none) <tao-54d5dbf0124e59afba31>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left|\\sum_{p \\leq X} \\text{Re} \\frac{1-h(p)}{p}\\right| \\ll_\\varepsilon 1.", block: true)]]

#text("We now perform some manipulations to remove the ")#mi("{n^{it}}")#text(" and ")#mi("{h}")#text(" factors from ")#mi("{g}")#text(" and isolate the ")#mi("{\\tilde \\chi}")#text(" factor, which is more tractable to compute with; then we will perform more computations to arrive at an expression just involving ")#mi("{\\chi}")#text(" which we will be able to evaluate fairly easily.")

#text("From ")#link(<tao-e0c85f7b2112fbf034af>)[#text("(6)")]#text(" and the triangle inequality we have")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} {\\bf E}_{H^{\\prime} \\in [H/2,H]} \\left|\\sum_{m=1}^{H^{\\prime}} g(n+m)\\right|^2 \\ll 1", block: true)]]

#text("for all ")#mi("{n}")#text(" (even after conditioning to the ")#mi("{1-O(\\varepsilon)}")#text(" event). The ")#mi("{{\\bf E}_{H^{\\prime} \\in [H/2,H]}}")#text(" averaging will not be used until much later in the argument, and the reader may wish to ignore it for now.")

#text("By ")#link(<tao-c1299854f2b209632ab2>)[#text("(10)")]#text(", the above estimate can be written as")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} {\\bf E}_{H^{\\prime} \\in [H/2,H]} \\left|\\sum_{m=1}^{H^{\\prime}} \\tilde \\chi(n+m) (n+m)^{it} h(n+m)\\right|^2 \\ll 1.", block: true)]]

#text("For ")#mi("{n \\geq X^{2\\delta}}")#text(" we can use ")#link(<tao-7a918ea1f19a0c5baf9b>)[#text("(9)")]#text(" to conclude that ")#mi("{(n+m)^{it} = n^{it} + O_{\\varepsilon,H,\\delta}(X^{-\\delta})}")#text(". The contribution of the error term is negligible, thus")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} {\\bf E}_{H^{\\prime} \\in [H/2,H]} \\left|\\sum_{m=1}^{H^{\\prime}}\\tilde \\chi(n+m) n^{it} h(n+m)\\right|^2 \\ll 1", block: true)]]

#text("for all ")#mi("{n \\geq X^{2\\delta}}")#text(". We can factor out the ")#mi("{n^{it}}")#text(" to obtain")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} {\\bf E}_{H^{\\prime} \\in [H/2,H]} \\left|\\sum_{m=1}^{H^{\\prime}} \\tilde \\chi(n+m) h(n+m)\\right|^2 \\ll 1.", block: true)]]

#text("For ")#mi("{n < X^{2\\delta}}")#text(" we can crudely bound the left-hand side by ")#mi("{H^2}")#text(". If ")#mi("{\\delta}")#text(" is sufficiently small, we can then sum weighted by ")#mi("{\\frac{1}{n^{1+1/\\log X}}}")#text(" and conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} {\\bf E}_{H^{\\prime} \\in [H/2,H]} \\frac{1}{\\log X} \\sum_n \\frac{1}{n^{1+1/\\log X}} \\left|\\sum_{m=1}^{H^{\\prime}} \\tilde \\chi(n+m) h(n+m)\\right|^2 \\ll 1.", block: true)]]

#text("(The zeta function type weight of ")#mi("{\\frac{1}{n^{1+1/\\log X}}}")#text(" will be convenient later in the argument when one has to perform some multiplicative number theory, as the relevant sums can be computed quite directly and easily using ")#link("https://en.wikipedia.org/wiki/Euler_product")[#text("Euler products")]#text(".) Thus, with probability ")#mi("{1-O(\\varepsilon)}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_{H^{\\prime} \\in [H/2,H]} \\sum_n \\frac{1}{n^{1+1/\\log X}} \\left|\\sum_{m=1}^{H^{\\prime}} \\tilde \\chi(n+m) h(n+m)\\right|^2 \\ll_\\varepsilon \\log X.", block: true)]]

#text("We condition to this event. We have successfully eliminated the role of ")#mi("{n^{it}}")#text("; we now work to eliminate ")#mi("{h}")#text(". Call a residue class ")#mi("{a \\text{ mod } q^k}")#text(" ")#emph[#text("bad")]#text(" if ")#mi("{a+m}")#text(" is divisible by ")#mi("{p^k}")#text(" for some ")#mi("{p|q}")#text(" and ")#mi("{1 \\leq m \\leq H}")#text(". and ")#emph[#text("good")]#text(" otherwise. We restrict ")#mi("{n}")#text(" to good residue classes, thus")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_{H^{\\prime} \\in [H/2,H]}\\sum_{a \\in [1,q^k], \\text{ good}} \\sum_{n = a \\text{ mod } q^k} \\frac{1}{n^{1+1/\\log X}} \\left|\\sum_{m=1}^{H^{\\prime}}\\tilde \\chi(n+m) h(n+m)\\right|^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll_\\varepsilon \\log X.")]]

#text("By Cauchy-Schwarz, we conclude that")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{H^{\\prime} \\in [H/2,H]} \\sum_{a \\in [1,q^k], \\text{ good}}")]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n = a \\text{ mod } q^k} \\frac{1}{n^{1+1/\\log X}} \\sum_{m=1}^{H^{\\prime}} \\tilde \\chi(n+m) h(n+m)\\right|^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll_\\varepsilon \\frac{1}{q^k} \\log^2 X.")]]

#text("Now we claim that for a ")#mi("{n}")#text(" in a good residue class ")#mi("{a \\text{ mod } q^k}")#text(", the quantity ")#mi("{\\chi(n+m)}")#text(" does not depend on ")#mi("{n}")#text(". Indeed, by hypothesis, ")#mi("{(n+m,q^k) = (a+m,q^k)}")#text(" is not divisible by ")#mi("{p^k}")#text(" for any ")#mi("{p|q}")#text(" and is thus a factor of ")#mi("{q^{k-1}}")#text(", and ")#mi("{\\frac{n+m}{(n+m,q^k)} = \\frac{n+m}{(a+m,q^k)}}")#text(" is coprime to ")#mi("{q}")#text(". We then factor")

#tao-aligned(keep: true)[


#tao-math("\\tilde \\chi(n+m) & = \\tilde \\chi((n+m,q^k)) \\tilde \\chi( \\frac{n+m}{(n+m,q^k)} )", block: true)



#tao-math(" & = \\tilde \\chi((a,q^k)) \\chi( \\frac{n+m}{(a+m,q^k)} )", block: true)



#tao-math(" & = \\tilde \\chi((a,q^k)) \\chi( \\frac{a+m}{(a+m,q^k)} )", block: true)
]

#text("where in the last line we use the periodicity of ")#mi("{\\chi}")#text(". Thus we have ")#mi("{\\tilde \\chi(n+m) = \\tilde \\chi(a+m)}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{H^{\\prime} \\in [H/2,H]} \\sum_{a \\in [1,q^k], \\text{ good}}")]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{m=1}^{H^{\\prime}} \\tilde \\chi(a+m) \\sum_{n = a \\text{ mod } q^k} \\frac{1}{n^{1+1/\\log X}} h(n+m)\\right|^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll_\\varepsilon \\frac{1}{q^k} \\log^2 X.")]]

#text("Shifting ")#mi("{n}")#text(" by ")#mi("{m}")#text(" we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n = a \\text{ mod } q^k} \\frac{1}{n^{1+1/\\log X}} h(n+m)")]]

#align(center)[#tao-fit-display[#mitex("= \\sum_{n = a+m \\text{ mod } q^k} \\frac{1}{n^{1+1/\\log X}} h(n) + O_H(1)")]]

#text("and thus (for ")#mi("{X}")#text(" large enough) ")#metadata(none) <tao-13a0a44104ce7c9406be>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("{\\bf E}_{H^{\\prime} \\in [H/2,H]} \\sum_{a \\in [1,q^k], \\text{ good}} \\left|\\sum_{m=1}^{H^{\\prime}} \\tilde \\chi(a+m) \\sum_{n = a+m \\text{ mod } q^k} \\frac{h(n)}{n^{1+1/\\log X}}\\right|^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll_\\varepsilon \\frac{1}{q^k} \\log^2 X.")]]

#text("Now, we perform some multiplicative number theory to understand the innermost sum. From taking Euler products we have")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{h(n)}{n^{1+1/\\log X}} = {\\mathfrak S}")]]

#text("for ")#mi("{{\\mathfrak S} := \\prod_p (1 - \\frac{h(p)}{p^{1+1/\\log X}})^{-1}}")#text("; from ")#link(<tao-54d5dbf0124e59afba31>)[#text("(11)")]#text(" and Mertens’ theorem one can easily verify that ")#metadata(none) <tao-64c83df872d808a1820a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\log X \\ll_\\varepsilon \\left|{\\mathfrak S}\\right| \\ll_\\varepsilon \\log X.", block: true)]]

#text("More generally, for any Dirichlet character ")#mi("{\\chi_1}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\chi_1(n) h(n)}{n^{1+1/\\log X}} = \\prod_p (1 - \\frac{h(p) \\chi_1(p)}{p^{1+1/\\log X}})^{-1}.")]]

#text("Since")

#align(center)[#tao-fit-display[#mitex("\\prod_p (1 - \\frac{\\chi_1(p)}{p^{1+1/\\log X}})^{-1} = L(1+\\frac{1}{\\log X}, \\chi_1) \\ll_{q,k} 1")]]

#text("we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_n \\frac{\\chi_1(n) h(n)}{n^{1+1/\\log X}} \\ll_{q,k} \\exp( \\sum_p \\frac{\\left|1-h(p)\\right|}{p^{1+1/\\log X}})", block: true)]]

#text("which after using ")#link(<tao-54d5dbf0124e59afba31>)[#text("(11)")]#text(", Cauchy-Schwarz (using ")#tao-math("{\\left|1-h(p)\\right| \\ll (1-\\text{Re} h(p))^{1/2})}", block: false)#text(" and Mertens theorem gives")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\chi_1(n) h(n)}{n^{1+1/\\log X}} \\ll_{q,k} \\exp(O_\\varepsilon(\\sqrt{\\log\\log X}))")]]

#text("for any non-principal character ")#mi("{\\chi_1}")#text(" of period dividing ")#mi("{q^k}")#text("; for a principal character ")#mi("{\\chi_0}")#text(" of period ")#mi("{r}")#text(" dividing ")#mi("{q^k}")#text(" we have")

#tao-aligned(keep: true)[


#tao-math("\\sum_n \\frac{\\chi_0 h(n)}{n^{1+1/\\log X}}  & = \\prod_{p \\not | r} (1 - \\frac{h(p)}{p^{1+1/\\log X}})^{-1}", block: true)



#tao-math(" & = \\frac{\\phi(r)}{r} {\\mathfrak S} + O_{q,k}(1)", block: true)
]

#text("since ")#mi("{h(p)=1}")#text(" and hence ")#mi("{\\frac{h(p)}{p^{1+1/\\log X}} = \\frac{1}{p} + O(\\frac{1}{\\log X})}")#text(" for all ")#mi("{p|r}")#text(", where we have also used ")#link(<tao-64c83df872d808a1820a>)[#text("(13)")]#text(". By expansion into Dirichlet characters we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n = b \\text{ mod } r} \\frac{h(n)}{n^{1+1/\\log X}} = \\frac{1}{r} {\\mathfrak S} + O_{q,k}(\\exp(O_\\varepsilon(\\sqrt{\\log\\log X})))")]]

#text("for all ")#mi("{r|q^k}")#text(" and primitive residue classes ")#mi("{b \\text{ mod } r}")#text(". For non-primitive residue classes ")#mi("{b \\text{ mod } r}")#text(", we write ")#mi("{r = (b,r) r^{\\prime}}")#text(" and ")#mi("{b = (b,r) b^{\\prime}}")#text(". The previous arguments then give")

#align(center)[#tao-fit-display[#mitex("\\sum_{n = b^{\\prime} \\text{ mod } r^{\\prime}} \\frac{h(n)}{n^{1+1/\\log X}} = \\frac{1}{r^{\\prime}} {\\mathfrak S} + O_{q,k}(\\exp(O_\\varepsilon(\\sqrt{\\log\\log X})))")]]

#text("which since ")#mi("{h((b,r))=1}")#text(" gives (again using ")#link(<tao-64c83df872d808a1820a>)[#text("(13)")]#text(")")

#align(center)[#tao-fit-display[#mitex("\\sum_{n = b \\text{ mod } r} \\frac{h(n)}{n^{1+1/\\log X}} = \\frac{1}{r} {\\mathfrak S} + O_{q,k}(\\exp(O_\\varepsilon(\\sqrt{\\log\\log X})))")]]

#text("for all ")#mi("{b \\text{ mod } r}")#text(" (not necessarily primitive). Inserting this back into ")#link(<tao-13a0a44104ce7c9406be>)[#text("(12)")]#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_{H^{\\prime} \\in [H/2,H]}\\sum_{a \\in [1,q^k] \\text{ good}} \\left| \\sum_{m=1}^{H^{\\prime}}\\tilde \\chi(a+m) (\\frac{1}{q^k} {\\mathfrak S} + O_{q,k}(\\exp(O_\\varepsilon(\\sqrt{\\log\\log X})))) \\right|^2 \\ll_\\varepsilon \\frac{1}{q^k} \\log^2 X", block: true)]]

#text("and thus by ")#link(<tao-64c83df872d808a1820a>)[#text("(13)")]#text(" we conclude (for ")#mi("{X}")#text(" large enough) that ")#metadata(none) <tao-2270e73a86e507f7a99d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\frac{1}{q^k} \\sum_{a \\in [1,q^k] \\text{ good}} {\\bf E}_{H^{\\prime} \\in [H/2,H]} \\left|\\sum_{m=1}^{H^{\\prime}} \\tilde \\chi(a+m)\\right|^2 \\ll_\\varepsilon 1.", block: true)]]

#text("We have now eliminated both ")#mi("{t}")#text(" and ")#mi("{h}")#text(". The remaining task is to establish some lower bound on the discrepancy of ")#mi("{\\tilde \\chi}")#text(" that will contradict ")#link(<tao-2270e73a86e507f7a99d>)[#text("(14)")]#text(". As mentioned above, this will be a more complicated variant of the Borwein-Choi-Coons analysis in the introduction. The square in ")#link(<tao-2270e73a86e507f7a99d>)[#text("(14)")]#text(" will be helpful in dealing with the fact that we don’t have good control on the ")#mi("{\\tilde \\chi(p)}")#text(" for ")#mi("{p|q}")#text(" (as we shall see, the squaring introduces two terms of this type that end up cancelling each other).")

#text("We expand ")#link(<tao-2270e73a86e507f7a99d>)[#text("(14)")]#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{H^{\\prime} \\in [H/2,H]} \\sum_{m_1,m_2 \\in [1,H^{\\prime}]} \\sum_{a \\in [1,q^k], \\text{ good}} \\tilde \\chi(a+m_1) \\overline{\\tilde \\chi(a+m_2)} \\ll_\\varepsilon q^k.")]]

#text("Write ")#mi("{d_1 := (a+m_1,q^k)}")#text(" and ")#mi("{d_2 := (a+m_2,q^k)}")#text(", thus ")#mi("{d_1,d_2 | q^{k-1}}")#text(" and for ")#mi("{i=1,2}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\tilde \\chi(a+m_i) = \\tilde \\chi(d_i) \\chi( \\frac{a+m_i}{d_i} ).")]]

#text("We thus have")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2|q^{k-1}} \\tilde \\chi(d_1) \\overline{\\tilde \\chi}(d_2) {\\bf E}_{H^{\\prime} \\in [H/2,H]} \\sum_{m_1,m_2 \\in [1,H^{\\prime}]}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{a \\in [1,q^k], \\text{ good}: (a+m_1,q^k)=d_1, (a+m_2,q^k)=d_2}")]]

#align(center)[#tao-fit-display[#mitex("\\chi(\\frac{a+m_1}{d_1}) \\overline{\\chi}(\\frac{a+m_2}{d_2}) \\ll_\\varepsilon q^k.")]]

#text("We reinstate the bad ")#mi("{a}")#text(". The number of such ")#mi("{a}")#text(" is at most ")#mi("{O(2^{-k} q^k )}")#text(", so their total contribution here is ")#mi("{O_H(2^{-k} q^k)}")#text(" which is negligible, thus ")#metadata(none) <tao-6c45cb72a36e63d522aa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\sum_{d_1,d_2|q^{k-1}} \\tilde \\chi(d_1) \\overline{\\tilde \\chi}(d_2) {\\bf E}_{H^{\\prime} \\in [H/2,H]}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{m_1,m_2 \\in [1,H^{\\prime}]} \\sum_{a \\in [1,q^k]: (a+m_1,q^k)=d_1, (a+m_2,q^k)=d_2}")]]

#align(center)[#tao-fit-display[#mitex("\\chi(\\frac{a+m_1}{d_1}) \\overline{\\chi}(\\frac{a+m_2}{d_2}) \\ll_\\varepsilon q^k.")]]

#text("For ")#mi("{d_1 \\geq q^{k/10}}")#text(" or ")#mi("{d_2 \\geq q^{k/10}}")#text(", the inner sum is ")#mi("{O_H(q^{-k/10} q^k )}")#text(", which by the ")#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/")[#text("divisor bound")]#text(" gives a negligible contribution. Thus we may restrict to ")#mi("{d_1,d_2 < q^{k/10}}")#text(". Note that as ")#mi("{\\chi}")#text(" is already restricted to numbers coprime to ")#mi("{q}")#text(", and ")#mi("{d_1,d_2}")#text(" divide ")#mi("{q^{k-1}}")#text(", we may replace the constraints ")#mi("{(a+m_i,q^k)=d_i}")#text(" with ")#mi("{d_i|a+m_i}")#text(" for ")#mi("{i=1,2}")#text(".")

#text("We consider the contribution of an off-diagonal term ")#mi("{d_1 \\neq d_2}")#text(" for a fixed choice of ")#mi("{m_1,m_2}")#text(". To handle these terms we expand the non-principal character ")#mi("{\\chi(n)}")#text(" as a linear combination of ")#mi("{e( \\xi n / q )}")#text(" for ")#mi("{\\xi \\in ({\\bf Z}/q{\\bf Z})^\\times}")#text(" with Fourier coefficients ")#mi("{O(1)}")#text(". Thus we can expand out")

#align(center)[#tao-fit-display[#mitex("\\sum_{a \\in [1,q^k]: d_1|a+m_1; d_2|a+m_2} \\chi(\\frac{a+m_1}{d_1}) \\overline{\\chi}(\\frac{a+m_2}{d_2})")]]

#text("as a linear combination of ")#mi("{O(1)}")#text(" expressions of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{a \\in [1,q^k]: d_1|a+m_1; d_2|a+m_2} e(\\frac{\\xi_1}{q} \\frac{a+m_1}{d_1} - \\frac{\\xi_2}{q} \\frac{a+m_2}{d_2})")]]

#text("with ")#mi("{\\xi_1,\\xi_2 \\in ({\\bf Z}/q{\\bf Z})^\\times}")#text(" and coefficients of size ")#mi("{O(1)}")#text(".")

#text("The constraints ")#mi("{ d_1|a+m_1; d_2|a+m_2}")#text(" are either inconsistent, or constrain ")#mi("{a}")#text(" to a single residue class ")#mi("{a = b \\text{ mod } [d_1,d_2]}")#text(". Writing ")#mi("{a = b + n [d_1,d_2]}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("e(\\frac{\\xi_1}{q} \\frac{a+m_1}{d_1} - \\frac{\\xi_2}{q} \\frac{a+m_2}{d_2}) = e( \\theta + \\frac{n}{q} ( \\xi_1 \\frac{[d_1,d_2]}{d_1} - \\xi_2 \\frac{[d_1,d_2]}{d_2} ) )")]]

#text("for some phase ")#mi("{\\theta}")#text(" that can depend on ")#mi("{b,m_1,m_2,d_1,d_2,q,\\xi_1,\\xi_2}")#text(" but is independent of ")#mi("{n}")#text(". If ")#mi("{d_1 \\neq d_2}")#text(", then at least one of the two quantities ")#mi("{\\frac{[d_1,d_2]}{d_1}}")#text(" and ")#mi("{\\frac{[d_1,d_2]}{d_2}}")#text(" is divisible by a prime ")#mi("{p|q}")#text(" that does not divide the other quantity. Therefore ")#mi("{\\xi_1 \\frac{[d_1,d_2]}{d_1} - \\xi_2 \\frac{[d_1,d_2]}{d_2}}")#text(" cannot be divisible by ")#mi("{p}")#text(", and thus by ")#mi("{q}")#text(". We can then sum the geometric series in ")#mi("{n}")#text(" (or ")#mi("{a}")#text(") and conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{a \\in [1,q^k]: d_1|a+m_1; d_2|a+m_2} e(\\frac{\\xi_1}{q} \\frac{a+m_1}{d_1} - \\frac{\\xi_2}{q} \\frac{a+m_2}{d_2}) \\ll [d_1,d_2] \\ll q^{k/5}")]]

#text("and so by the divisor bound the off-diagonal terms ")#mi("{d_1 \\neq d_2}")#text(" contribute at most ")#mi("{O_H( q^{k/5 + o(k)} )}")#text(" to ")#link(<tao-6c45cb72a36e63d522aa>)[#text("(15)")]#text(". For ")#mi("{k}")#text(" large, this is negligible, and thus we only need to consider the diagonal contribution ")#mi("{d_1 = d_2 < q^{k/10}}")#text(". Here the ")#mi("{ \\tilde \\chi(d_1) \\overline{\\tilde \\chi}(d_2)}")#text(" terms helpfully cancel, and we obtain")

#align(center)[#tao-fit-display[#mitex("\\sum_{d|q^{k-1}: d < q^{k/10}} {\\bf E}_{H^{\\prime} \\in [H/2,H]} \\sum_{m_1,m_2 \\in [1,H^{\\prime}]} \\sum_{a \\in [1,q^k]: d | a+m_1, a+m_2}")]]

#align(center)[#tao-fit-display[#mitex("\\chi(\\frac{a+m_1}{d}) \\overline{\\chi}(\\frac{a+m_2}{d}) \\ll_\\varepsilon q^k.")]]

#text("We have now eliminated ")#mi("{\\tilde \\chi}")#text(", leaving only the Dirichlet character ")#mi("{\\chi}")#text(" which is much easier to work with. We gather terms and write the left-hand side as")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d|q^{k-1}: d < q^{k/10}} {\\bf E}_{H^{\\prime} \\in [H/2,H]} \\sum_{a \\in [1,q^k]} \\left|\\sum_{m \\in [1,H^{\\prime}]: d|a+m} \\chi(\\frac{a+m}{d})\\right|^2 \\ll \\varepsilon q^k.", block: true)]]

#text("The summand in ")#mi("{d}")#text(" is now non-negative. We can thus throw away all the ")#mi("{d}")#text(" except of the form ")#mi("{d = q^i}")#text(" with ")#mi("{q^i < \\sqrt{H}}")#text(", to conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i: q^i < \\sqrt{H}} {\\bf E}_{H^{\\prime} \\in [H/2,H]} \\sum_{a \\in [1,q^k]} \\left|\\sum_{m \\in [1,H^{\\prime}]: q^i|a+m} \\chi(\\frac{a+m}{q^i})\\right|^2 \\ll_\\varepsilon q^k.", block: true)]]

#text("It is now that we finally take advantage of the averaging ")#mi("{{\\bf E}_{H^{\\prime} \\in [H/2,H]}}")#text(" to simplify the ")#mi("{m}")#text(" summation. Observe from the triangle inequality that for any ")#mi("{H^{\\prime} \\in [H/2, 3H/4]}")#text(" and ")#mi("{a \\in [1,q^k]}")#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{H^{\\prime} < a \\leq H^{\\prime} + q^i: q^i|a+m} \\chi(\\frac{a+m}{q^i})\\right|^2", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\ll \\left|\\sum_{m \\in [1,H^{\\prime}]: q^i|a+m} \\chi(\\frac{a+m}{q^i})\\right|^2 + \\left|\\sum_{m \\in [1,H^{\\prime}+q^i]: q^i|a+m} \\chi(\\frac{a+m}{q^i})\\right|^2;", block: true)]]

#text("summing over ")#mi("{i,H^{\\prime},a}")#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i: q^i < \\sqrt{H}} {\\bf E}_{H^{\\prime} \\in [H/2,3H/4]} \\sum_{a \\in [1,q^k]} \\left|\\sum_{H^{\\prime} < m \\leq H^{\\prime}+q^i: q^i|a+m} \\chi(\\frac{a+m}{q^i})\\right|^2 \\ll_\\varepsilon q^k.", block: true)]]

#text("In particular, by the pigeonhole principle there exists ")#mi("{H^{\\prime} \\in [H/2,3H/4]}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i: q^i < \\sqrt{H}} \\sum_{a \\in [1,q^k]} \\left|\\sum_{H^{\\prime} < m \\leq H^{\\prime}+q^i: q^i|a+m} \\chi(\\frac{a+m}{q^i})\\right|^2 \\ll_\\varepsilon q^k.", block: true)]]

#text("Shifting ")#mi("{a}")#text(" by ")#mi("{H^{\\prime}}")#text(" and discarding some terms, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i: q^i < \\sqrt{H}} \\sum_{a \\in [1,q^k/2]} \\left|\\sum_{1 \\leq m \\leq q^i: q^i|a+m} \\chi(\\frac{a+m}{q^i})\\right|^2 \\ll_\\varepsilon q^k.", block: true)]]

#text("Observe that for a fixed ")#mi("{a}")#text(" there is exactly one ")#mi("{m}")#text(" in the inner sum, and ")#mi("{\\frac{a+m}{q^i} = \\lfloor \\frac{a}{q^i} \\rfloor + 1}")#text(". Thus we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i: q^i < \\sqrt{H}} \\sum_{a \\in [1,q^k/2]} \\left|\\chi(\\lfloor \\frac{a}{q^i}\\rfloor + 1)\\right|^2 \\ll_\\varepsilon q^k.", block: true)]]

#text("Making the change of variables ")#mi("{b := \\lfloor \\frac{a}{q^i} \\rfloor + 1}")#text(", we thus have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i: q^i < \\sqrt{H}} q^i \\sum_{b \\in [1,q^{k-i}/4]} \\left|\\chi(b)\\right|^2 \\ll_\\varepsilon q^k.", block: true)]]

#text("But ")#tao-math("{b \\mapsto \\left|\\chi(b)\\right|^2}", block: false)#text(" is periodic of period ")#mi("{q}")#text(" with mean ")#mi("{\\gg 1}")#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\sum_{b \\in [1,q^{k-i}/4]} \\left|\\chi(b)\\right|^2 \\gg q^{k-i}", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{i: q^i < \\sqrt{H}} 1 \\ll_\\varepsilon 1,")]]

#text("which leads to a contradiction for ")#mi("{H}")#text(" large enough (note the logarithmic growth in ")#mi("{H}")#text(" here, matching the logarithmic growth in the Borwein-Choi-Coons analysis). The claim follows.")

#heading(level: 1)[#text("Comments (49)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459085")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2015")])]

#text("Since the LHS of (2) is dependent on ")#mi("t")#text(", it is not sufficiently clear which values of ")#mi("t")#text(" should satisfy (2).")

#emph[#text("[Oops, there was a typo: (2) was meant to hold for all values of ")#mi("t")#text(". I’ve edited the text to reflect this. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0fd56049a8189a380fda42273fee0bc2b9ce50a7a224700afce1fe96194008-d71b4d207f9bb85a02159d9eb02ffc3ded2bfbce61de425e7d3d85b4f53db867.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uwe Stroinski")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459110")[#strong[#text("Uwe Stroinski")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2015")])]

#text("In the proof of Proposition 4 near the end, the definition of ")#mi("g(p_j)")#text(" should contain ")#mi("\\xi_j")#text(" instead of ")#mi("\\pi(j)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459119")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2015")])]

#text("Dear Terry,")#linebreak()#text(" This is very cool. Two questions: first, there is some probabilistic heuristics that for Erdos discrepancy problem the actual Sup behaves like sqrt (log n). Does this makes sense/fits other heuristics, when you transfer it to Elliot conjecture? Second, Do Elliott or Chowla conjectures (perhaps in some strong forms or for some special cases) follow from GRH or similar conjectures?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459127")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2015")])]

#text("Let’s restrict to completely multiplicative functions ")#mi("f")#text(" for the sake of discussion (the Fourier reduction already more or less does this, at the cost of making the completely multiplicative function stochastic instead of deterministic). One can make a distinction between the “pretentious” case when the multiplicative function ")#mi("f")#text(" behaves like a modulated character ")#mi("n \\mapsto \\chi(n) n^{it}")#text(", and the “non-pretentious” case when it doesn’t. For instance, the Borwein-Choi-Coons example (and the randomised version of that example that is giving the ")#mi("\\sqrt{\\log n}")#text(" discrepancy) are in the “pretentious” category.")

#text("The argument I give in Section 3 to handle the pretentious case does indeed seem to give a ")#mi("\\sqrt{\\log n}")#text(" type lower bound (there is a squaring at some point, and then the final contradiction is by a logarithmic factor). To get such a bound overall, though, one needs a quantitative version of the Elliott conjecture (i.e. some info on how ")#mi("A")#text(" depends on ")#mi("\\varepsilon")#text("). The averaged version of Elliott’s conjecture in my paper with Matomaki and Radziwill has such a quantitative version but there are some error terms that involve small powers of ")#mi("\\log n")#text(" which would prevent one from getting the discrepancy lower bound all the way up to ")#mi("\\sqrt{\\log n}")#text(". But these are probably artefacts of our method and if one assumed a sufficiently strong quantitative version of Elliott’s conjecture one could imagine that one could get close to the conjectural ")#mi("\\sqrt{\\log n}")#text(".")

#text("Conjectures like GRH are very helpful in multiplicative number theory, for instance in controlling sums such as ")#mi("\\sum_{n \\leq x} f(n)")#text(" or ")#mi("\\sum_{n \\leq x} f(n) \\chi(n)")#text(" for multiplicative f. However they are not nearly as helpful for non-multiplicative situations such as controlling ")#mi("\\sum_{n \\leq x} f(n) f(n+h)")#text(". Of course, they certainly don’t hurt, but I think the improvements to existing Chowla type results from assuming GRH are actually relatively modest.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459142")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2015")])]

#text("In conjecture 1, the “sufficiently large” ")#mi("A")#text(" and ")#mi("X")#text(" are independent of the function ")#mi("g")#text(". Is this independence really important?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459143")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2015")])]

#text("Yes, for instance for the application to the discrepancy problem it is essential that the parameters A and X do not depend on g. If they are allowed to depend on g then the conjecture more or less reverts back to the qualitative version of the Elliott conjecture discussed in the introduction to the blog post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d9e338e0cd3c5854d68f121b5bf4dd9161377bdb81e3cdc27ffbef30ef3227b-78ebb2d5d5bd8641134d35ec8cda100165b35ec3350266a25bb780abe9cd2e13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459145")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2015")])]

#text("Presumably, Polymath 5 is active??")

#text("I am surprised by Conjecture 2. No idea why bounded self-correlation (say for the Mobius function ")#mi("\\mu")#text(" would lead to infinite discrepancy.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/feda2708ab41aeb5a863f024d1bdf0b1d8e756e1e19ef3e175c14fd9820c8eca-3335bed4a94ed4d3a639469274e25dfa6b77c1b83e32303b80b4b71de3b79cf8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mixedmath")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459376")[#strong[#text("mixedmath")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2015")])]

#text("I’m afraid not. Polymath5 has been quite dormant for a few years now. At least, online it has. Sometimes questions follow you around, wake you up at night, and the like.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459162")[#strong[#text("The Erdos discrepancy problem | Exploratoria")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2015")]

#text("[…] via the Elliot Conjecture ~ via Terry Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459221")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2015")])]

#text("Concerning conjecture 2, what is known about best lower/upper bounds of")#linebreak()#text(" ")#tao-math("\\inf_f \\sup_d \\left|\\sum_{j=1}^n f(j d)\\right|", block: false)#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459239")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2015")])]

#text("The best upper bound is ")#mi("C \\sqrt{\\log n}")#text(" (possibly with an iterated logarithm correction) for some absolute constant ")#mi("C")#text(", using a randomised version of the Borwein-Choi-Coons example (which already gives a bound of the form ")#mi("C \\log n")#text("); I don’t have a reference for this though (perhaps some of the Polymath5 participants would know). The best lower bound, remarkably, is just ")#mi("3")#text(" (for ")#mi("n > 1160")#text("); see ")#link("http://arxiv.org/pdf/1402.2184v1.pdf")[#text("this paper of Konev and Lisitsa")]#text(".")

#text("EDIT: See also Tim Gowers’ survey on these problems, recently made available on the arXiv at ")#link("http://arxiv.org/abs/1509.03421")[#text("http://arxiv.org/abs/1509.03421")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a830450fdc42640734c399aefa8d8f69203b5cf003a6fb3d85c05a81a6dcced-6aa92d6fbc6161814fa75065d6b8ebec555852a948f8c3d0155ac32fac6aeb95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459510")[#strong[#text("Joseph")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2015")])]

#text("I am wondering how one can randomise the Borwein-Choi-Coons example in order to get ")#mi("C \\sqrt{\\log n}")#text(" (I don’t know how to do it and I see in your paper (p. 5-6): “although it is unclear to the author whether such a slowly diverging example can also be attained for Corollary 1.2”). What is more precisely known about this question?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459514")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2015")])]

#text("Yes, the situation here appears to be a bit subtle. One can construct a random multiplicative function ")#mi("{\\bf g}")#text(" such that ")#tao-math("{\\bf E} \\left|\\sum_{j=1}^n g(j)\\right|^2 \\ll \\log n", block: false)#text(" for all ")#mi("n")#text(", which gives ")#mi("O( \\sqrt{\\log n})")#text(" growth on the average, by randomising Borwein-Choi-Coons, but this isn’t the same as locating a deterministic ")#mi("g")#text(" such that ")#tao-math("\\left|\\sum_{j=1}^n g(j)\\right| \\ll \\sqrt{\\log n}", block: false)#text(" for all n. As I said, it may be that some other Polymath5 participants would know the precise status of this question.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/feda2708ab41aeb5a863f024d1bdf0b1d8e756e1e19ef3e175c14fd9820c8eca-3335bed4a94ed4d3a639469274e25dfa6b77c1b83e32303b80b4b71de3b79cf8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mixedmath")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459375")[#strong[#text("mixedmath")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2015")])]

#text("Dear Terry,")#linebreak()#text(" This is very interesting. I’ve kept thinking about the Erdos Discrepancy Problem on and off since the Polymath Project. I notice your new preprint on the arXiv, which is very exciting.")

#text("I wonder: can you extend to a complexified Erdos Discrepancy Problem, where the underlying function perhaps is of form ")#mi("f: \\mathbb{Z}^d \\longrightarrow \\mu_n")#text(" where ")#mi("\\mu_n")#text(" are the ")#mi("n")#text("th roots of unity? Or perhaps all the way to ")#mi("\\mathbb{C}^\\times")#text("?")

#text("I don’t quite have the intuition to know when these should be true, but I do feel that something more general should be true. If I recall correctly, the Fourier transition from general to multiplicative functions relied on Plancherel’s identity, and that ")#mi("(\\pm 1)^2 = 1")#text(". I suppose this would be the first question to consider.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/feda2708ab41aeb5a863f024d1bdf0b1d8e756e1e19ef3e175c14fd9820c8eca-3335bed4a94ed4d3a639469274e25dfa6b77c1b83e32303b80b4b71de3b79cf8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mixedmath")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459401")[#strong[#text("mixedmath")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2015")])]

#text("I realize I commented too soon. I’ll use the excuse that it was late, and I was tired.")

#text("Could you say a few more words about how to extend proposition 4 to the unit sphere?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459392")[#strong[#text("Updates and plans III. | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2015")]

#text("[…] by Terry Tao (1), (2) (reporting also on subsequent works by Matomaki, Radzwill, and Tao) NEW (3) (4)). Update (Sept 18, 2015): Terry Tao have just uploaded a paper to the arxive where he solves the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459425")[#strong[#text("The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2015")])]

#text("[…] pair of papers is an outgrowth of these two recent blog posts and the ensuing discussion. In the first paper, we establish the following logarithmically averaged […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/584cd02f839ef6f42551e80d351f9a4a15cb388eea2c96194a9925dcd6248b8b-d4a31d6f5ab8c8b59637f67c32594b522a6199cfd232e67ffe727dace4462076.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459463")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2015")])]

#text("This is truly beautiful. In the Erdős discrepancy paper, in the last display of page 10, I think that ")#mi("\\gg_{C,\\epsilon,H} 1")#text(" should be ")#mi("\\gg_{C,\\epsilon,H}\\log X")#text(" in order to apply Theorem 1.8. (Similarly, in the next display, ")#mi("\\gg_\\epsilon")#text(" should be ")#mi("\\gg_{C,\\epsilon}\\log X")#text(", but this display is not even needed as one can apply the last display of page 10 directly).")

#emph[#text("[This will be corrected in the next revision of the MS – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459497")[#strong[#text("EDP28 — problem solved by Terence Tao! | Gowers's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2015")]

#text("[…] Tao has solved the Erdős discrepancy problem. He has blogged about the solution in two posts, a first that shows how to reduce the problem to the Elliott conjecture in number theory, and a second that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0fd56049a8189a380fda42273fee0bc2b9ce50a7a224700afce1fe96194008-d71b4d207f9bb85a02159d9eb02ffc3ded2bfbce61de425e7d3d85b4f53db867.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uwe Stroinski")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459525")[#strong[#text("Uwe Stroinski")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2015")])]

#text("Congratulation! A quick skim through your xarchive papers shows that the Fourier-reduction part is essentially a copy of your post here. Since it is published now I would like to ask you whether it is possible to spell out the routine Fourier argument. As far as I can see in (2.2) (or (5) here) ")#mi("x+\\pi(j)")#text(" is not always in the domain of ")#mi("F")#text(" (take eg ")#mi("x = (M-1,0,\\ldots,0)")#text(" and j = 2). Is that a problem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459541")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2015")])]

#text("The domain of ")#mi("F")#text(" is the finite abelian group ")#mi("{\\bf Z}/M{\\bf Z})^r")#text(", not the discrete cube ")#mi("\\{0,\\dots,M-1\\}^r")#text(" (which is a fundamental domain for that group). In particular, the addition ")#mi("x + \\pi(j)")#text(" takes place in this group and so does not leave the domain of ")#mi("F")#text(". (The corresponding addition operation on the discrete cube can leave that cube, which is why there are the ")#mi("O_X(M^{r-1})")#text(" exceptions to the inequality two displays before (5).)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0fd56049a8189a380fda42273fee0bc2b9ce50a7a224700afce1fe96194008-d71b4d207f9bb85a02159d9eb02ffc3ded2bfbce61de425e7d3d85b4f53db867.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uwe Stroinski")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459545")[#strong[#text("Uwe Stroinski")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2015")])]

#text("Got it. The result then follows from linearity, translation property (applied to $\\pi(j)$ and Plancherel. Thanks a lot.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Royce Peng")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459528")[#strong[#text("Royce Peng")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2015")])]

#text("On reddit, the following interesting question was asked concerning the Erdos discrepancy problem: Can one always choose a single infinite sequence whose partial sums are unbounded? i.e. does there exist a d such that ")#tao-math("\\sup_n \\left|\\sum_{j=1}^n f(jd)\\right| = \\infty", block: false)#text("?")

#text("Sorry if this questions is obvious or already answered.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459542")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2015")])]

#text("This is a nice question. Looks like there is a counterexample as follows. Set ")#mi("f(1) := +1")#text(", and then perform the following recursive construction for ")#mi("D = 1,2,3,\\dots")#text(":")

#list(
[#text("Once ")#mi("f(1),\\dots,f(D!)")#text(" have been selected, define ")#mi("f(D!+1),\\dots,f((D+1)!)")#text(" by setting ")#mi("f(jD! + k) := (-1)^j f(k)")#text(" for ")#mi("k=1,\\dots,D!")#text(" and ")#mi("j=1,\\dots,D")#text(".")]
)

#text("Informally, the block ")#mi("f(1),\\dots,f((D+1)!)")#text(" is ")#mi("D+1")#text(" alternating copies of the block ")#mi("f(1),\\dots,f(D!)")#text(".")#linebreak()#text(" Thus the sequence ")#mi("f(1), f(2), \\dots")#text(" is")

#mi("1, -1, -1, 1, 1, -1, -1, 1, 1, -1, -1, 1, 1, -1, 1, -1, -1, 1, \\dots")#text(".")

#text("If ")#mi("d")#text(" is a natural number and ")#mi("D")#text(" is any odd number larger than ")#mi("d")#text(", then we see that the block ")#mi("f(d), f(2d), \\dots, f( (D+1)! )")#text(" is D+1 alternating copies of ")#mi("f(d), f(2d), \\dots, f(D!)")#text(" and thus sums to zero; in fact if we divide ")#mi("f(d), f(2d), \\dots")#text(" into consecutive blocks of length ")#mi("(D+1)!/d")#text(" then all such blocks sum to zero, and so ")#tao-math("\\sum_n \\left|\\sum_{j=1}^n f(jd)\\right|", block: false)#text(" is finite for all d.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459651")[#strong[#text("Frogs and Lily Pads and Discrepancy | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2015")]

#text("[…] Conjecture” (DC) of Paul Erdős. This emerged from discussion of his two earlier posts this month on his blog. They and his 9/18 announcement post re-create much of the content of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459734")[#strong[#text("Математик Теренс Тао обогнал компьютер в решении проблемы несоответствия Эрдеша | news.siras.ru")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2015")]

#text("[…] литературы). Аргументы математика использовали специального вида гипотезу Эллиота-Халберстама (о распределении […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a606ebaa57b9f1eedb5962fb3ab0acaecfdd4b097bd4d1af841c32c20916df9-ea88ff0447db8bfb07329677a122c8917a848c79e6629ea685e14a8abf7362cc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459736")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2015")])]

#text("I am a big fan of Paul Erdos and his legacy to mathematics. I am Physics major and was recently reading and discussing this paper with some friends (Pysicists and Mathematicians) but could not get grasp of it all. I asked the people at Fermat’s Library (platform to annotate and discuss scientific papers) to upload the paper and was wondering if anyone wanted to help me annotate it: ")#link("http://fermatslibrary.com/s/the-erdos-discrepancy-problem")[#text("http://fermatslibrary.com/s/the-erdos-discrepancy-problem")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76accfe5628579d6d7b031a1601c5efcb8eab510e10c8bd8847b792f9312add3-cabe31d49f0a491a27c2a2c4043a07ffe49d2f1dbebf64cf7dd62d5f3a999b45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Stanley")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459737")[#strong[#text("Richard Stanley")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2015")])]

#text("The Erdős discrepancy problem is vaguely similar to another long-standing problem, the circulant Hadamard matrix conjecture. Namely, if ")#mi("n> 4")#text(" then there does not exist a sequence ")#mi("(a_1,\\dots,a_n)")#text(" of ")#mi("\\pm 1")#text("‘s that is orthogonal to every non-identity cyclic shift of itself. Can any of these discrepancy techniques be applied to Hadamard circulants?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459768")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2015")])]

#text("This is a nice question! I spent a bit of time looking at the literature on this problem (though it seems one has to be careful of the claimed proofs of the conjecture that didn’t work out). It’s unlikely that the methods here can be applied directly to the circulant problem, since multiplicative sequences seem to play no special role in the circulant problem while being central to the discrepancy problem. But one could imagine the following strategy, analogous to the EDP strategy of generalising +1/-1 sequences to Hilbert-space valued sequences, then reducing to (stochastic) multiplicative sequences, and thence to multiplicative sequences that pretend to be modulated Dirichlet characters.")

#text("Let’s first generalise the situation by considering sequences taking values in ")#mi("S^1")#text(" rather than ")#mi("\\pm 1")#text(". Now there are a family of counterexamples for every odd ")#mi("n")#text(" coming from the quadratic phases ")#mi("a_j = e^{2\\pi i( aj^2+bj+c ) / n}")#text(" for integers ")#mi("a,b,c")#text(" with ")#mi("a")#text(" coprime to ")#mi("n")#text(". Naively, one could conjecture that these are essentially the only counterexamples, in that any ")#mi("S^1")#text("-valued sequence orthogonal to its cyclic shifts must “pretend” to be a quadratic phase in some sense. This would reduce the problem to figuring out which ")#mi("\\pm 1")#text(" sequences pretend to be quadratic, and checking them individually for orthogonality, which looks like a relatively tractable problem. But this could be too naive, and there could be some more exotic sequences than quadratic which are also orthogonal to their cyclic shifts. Perhaps the recent advances in design theory may help clarify whether such exotic sequences would be expected to exist? (I haven’t followed the design theory literature too closely though.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459772")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2015")])]

#text("It is interesting to note that a Dirichlet character mod a prime is nearly a counterexample. By this I mean that the shifts of such a Dirichlet character are nearly orthogonal in the sense that ")#mi("\\sum_{x} \\chi(x+n)\\overline{\\chi(x+m)}=-1")#text(" for ")#mi("m \\neq n")#text(". This is a bit unintuitive, at least to me, as one might expect this sum to be ")#mi("\\Omega(p^{1/2})")#text(". On the other hand, Dirichlet characters do not correlate with quadratic phases (by Weil’s bound). Thus a reduction will need a mechanism for distinguishing between orthogonal and nearly orthogonal sequences (or, perhaps, one should consider twisted quadratic phases).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76accfe5628579d6d7b031a1601c5efcb8eab510e10c8bd8847b792f9312add3-cabe31d49f0a491a27c2a2c4043a07ffe49d2f1dbebf64cf7dd62d5f3a999b45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Stanley")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459796")[#strong[#text("Richard Stanley")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2015")])]

#text("We can border the “Dirichlet character matrix” with a row and column of 1’s to obtain a Hadamard matrix. This is a construction of Paley. See")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/Paley_construction")[#text("https://en.wikipedia.org/wiki/Paley_construction")]#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459798")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2015")])]

#text("Yes but of course that destroys the circulant property.")

#text("From Freddie Manners’ mathoverflow post (linked below) one sees that there are in fact “exotic” complex circulant Hadamard matrices. On the other hand the example he gives there correlates with a quadratic Dirichlet character. Perhaps one can naively move the goal to something like: a complex circulant matrix either “pretends” to be a quadratic phase or a Dirichlet character.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459787")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2015")])]

#text("On further thought, here is some support for your proposed strategy:")

#text("Let ")#mi("f: [N] \\rightarrow S^{1}")#text(" be a unimodular circulant sequence. Define the shift of ")#mi("f")#text(" by ")#mi("t")#text(" as ")#mi("f_t(x) = f(x-t)")#text(". By hypothesis ")#mi("\\langle f, f_t \\rangle=0")#text(". By Plancherel one then has ")#mi("\\langle \\hat f, \\hat f_t \\rangle=0")#text(". Using the fact that the Fourier transform takes translations to modulations this implies ")#tao-math("\\sum_{\\xi} e(t\\xi) \\left|\\hat{f}(\\xi)\\right|^2 =0", block: false)#text(" for ")#mi("t \\neq 0")#text(". In turn, this implies that ")#mi("\\hat{f}(\\xi)|^2")#text("=1. One is thus left with the question of when a function and its Fourier transform have constant modulus. It seems there is some literature on this question, for instance see this mathoverflow post (")#link("http://mathoverflow.net/questions/181102/functions-f-on-mathbbz-n-mathbbz-with-f-and-widehatf-constan")[#text("http://mathoverflow.net/questions/181102/functions-f-on-mathbbz-n-mathbbz-with-f-and-widehatf-constan")]#text("). In particular, it seems to be known that if ")#mi("f(x)=e(g(x)/N)")#text(" for ")#mi("g:[N] \\rightarrow Z")#text(" then ")#mi("g")#text(" must be a quadratic polynomial. That seems very close to what you are looking for.")

#text("(I see Yemon Choi pointed the mathoverflow discussion referenced to a paper on “circulant complex Hadamard matrices” so it’s likely everything I just stated is well know in the context of this problem.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459806")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2015")])]

#text("Interesting that these results are ultimately powered by Segre’s theorem in combinatorial finite field incidence geometry! (Though it seems they are currently restricted to cases when N has very few prime factors.) There was already some interest in trying to find more robust versions of Segre type theorems (perhaps somehow using the modern polynomial method) but as far as I know there isn’t a breakthrough in that area yet. One may have to wait for (or to encourage) a further advance in this area (which would be more or less an exact analogue of the situation with Polymath5 and the Erdos discrepancy problem).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-495756")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2018")])]

#text("A comment regarding Richard Stanley’s proposal (here and also over MO) to study the circulant Hadamard conjecture (CHC) as a natural analog of EDP.")

#text("For a sequence ")#mi("a=(a_1,a_2,\\dots,a_n)")#text(" of ")#mi("\\pm 1")#text(" vectors, let ")#mi("D(a)")#text(" be the largest absolute value of the inner product of ")#mi("a")#text(" with a cyclic shift and let ")#mi("D(n)")#text(" be the minimum value of ")#mi("D(a)")#text(" over all ")#mi("\\pm 1")#text(" vectors of length ")#mi("n")#text(".")

#text("The CHC assets that ")#mi("D(n)>0")#text(" for every ")#mi("n \\ge 4")#text(".")

#text("It is natural to ask: what is known about ")#mi("D(n)")#text("? Is it plausible that ")#mi("D(n)")#text(" tends to infinity with ")#mi("n")#text("?")

#text("I wonder also what the large deviation heuristic that I proposed in EDP23 suggests about the value.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f861c0ca20daa711eae006acaa4a64cf9bfbc44410b1a5d1b50def939aedfd7f-7a67dd37d4f1ae92259d7257f1372ba8c64e84e53fa3d4b8bd67397d63bf1107.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Tung")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459820")[#strong[#text("Daniel Tung")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2015")])]

#text("Hi,")#linebreak()#text(" I wonder if the discrepancy problem would have any impact to the meaning of probability (especially its frequency interpretation).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 0: Foundations of probability theory | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459861")[#strong[#text("275A, Notes 0: Foundations of probability theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2015")])]

#text("[…] and Elliott conjectures, and random multiplicative functions similarly played a central role in the paper on the Erdos discrepancy problem), this will actually be the first time I will be teaching a course on probability itself (although […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-460041")[#strong[#text("TECNOLOGÍA » 275A, Notes 0: Foundations of probability theory")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2015")]

#text("[…] and Elliott conjectures, and random multiplicative functions similarly played a central role in the paper on the Erdos discrepancy problem), this will actually be the first time I will be teaching a course on probability itself (although […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-460200")[#strong[#text("Terence Tao magic breakthrough again with EDP, Erdos Discrepancy Problem | Turing Machine")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2015")]

#text("[…] 7. The Erdos discrepancy problem via the Elliott conjecture / Tao blog […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-460243")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2015")])]

#text("if you represent a decision problem with 1 and -1 as outputs instead of 0 and 1 does this problem contribute to analyse decision problems?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-460637")[#strong[#text("Il problema della discrepanza: provata una congettura di Erdős? | OggiScienza")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2015")]

#text("[…] dibatte, Tao ha fatto una cronologia dei suggerimenti più utili sia sul blog di Tim Gowers che sul proprio (ha scritto anche una seconda parte) dove la peer-review ha preceduto quella della rivista, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-460755")[#strong[#text("EDP Reflections and Celebrations | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2015")]

#text("[…] argument proving EDC based on a number-theoretic conjecture (The Eliott Conjecture) can be found in this very readable blog post by Tao. In 2010 Tim Gowers ran a polymath project devoted to the Erdős discrepancy problem (EDP). A […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0371c5cb0d2f2963d92607f5014151f98e6e20c874e43a1dd54072012784e7c-68e3117565c6615a7fe4d045b9f6a7f7468b34769084052927bec6ee1bb3241d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Bouris")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-461334")[#strong[#text("William Bouris")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2015")])]

#text("Tao Number, t(n) = (18n)^n – (4(n+1))^n +3^[(1/2)(n-1)(n+2)]; t(0)=0, t(1)=11, t(2)=1161, t(3)=153,611>130,000, etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-463427")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2015")])]

#text("Consider a generalization of Erdos discrepancy problem where ")#tao-math("\\left|f\\right|", block: false)#text(" takes values in a set ")#mi("E")#text(" of positive numbers. The problem is to determine all possible such sets ")#mi("E")#text(" for which the generalized discrepancy problem has an affirmative answer. Is it possible for such ")#mi("E")#text(" to have more than one element ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3170687540c66dc22acac3ff153a5f7b25b10303e42e1144b148a6cfe32bff3d-0c12835ec5ba8882b4301c470ff7175f999ad4539c3167aabdb48ab191ff6473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eulogio Garcia")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-474161")[#strong[#text("Eulogio Garcia")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2016")])]

#text("Counterexample to the Erdös discrepency problem.")

#text("We know that:")

#mi("\\forall(Z^{+}) = \\sum (1)")

#text("So:")

#text("(i) ")#mi("\\sum (+1) + \\sum_{n=2} (-1)^{n} = O(Z^{+}) - 1")

#text("Being ")#mi("O(Z^{+})")#text(" the greated integer that exists.")

#text("hence the sum of a finite set of terms always converges; that is to say.")

#mi("f(a) + f(b) < O(Z^{+})")

#text("To have the expression (i) if we have that ")#mi("\\sum_{n=2} (-1)^{n} = -1")

#text("this is obtained as follows.")

#mi("\\sum_{n=2}^{\\infty} (-1)^{n} = (-1)^{2} + (-1)^{4} + (-1)^{3} + (-1)^{6} + (-1)^{5} + (-1)^{8} + (-1)^{7} + \\cdot\\cdot\\cdot + (-1)^{k} + (-1)^{k-1} = -1")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3170687540c66dc22acac3ff153a5f7b25b10303e42e1144b148a6cfe32bff3d-0c12835ec5ba8882b4301c470ff7175f999ad4539c3167aabdb48ab191ff6473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eulogio Garcia")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-474225")[#strong[#text("Eulogio Garcia")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2016")])]

#text("A more concrete and precise explanation of the counterexample.")

#text("(i) ")#mi("\\sum_{lm=k} (+1) + \\sum_{n=2} (-1)^{n} = \\sum_{lm=k} (1) + 2")

#text("This is always that the value of ")#mi("(n)")#text(" in the last summing is ")#mi("(n = even)")#text("; in ")#mi("\\forall(k \\rightarrow \\infty)")#text(".")

#text("Now if we apply the Erdos conjecture ( sum of terms equidistant ")#mi("[\\sum (1)_{tq}]")#text(" in (i) we will have.")

#tao-math("\\left|\\sum_{lm=k} (+1) + \\sum_{n=2} (-1)^{n} \\right| > \\sum (1)_{tq}", block: false)

#text("Because: it does not allow the consecutive sum of ")#mi("\\sum (+1)")#text(" and therefore we will never a value tan ")#mi("(k + 2)")#text(".")

#text("example: ")#mi("k = 7")#text(".")

#mi("1 + 1 + 1 + 1 + 1 + 1 + 1 + (-1)^{2} + (-1)^{4} + (-1)^{3} + (-1)^{6} + (-1)^{5} + (-1)^{8} = 9")

#text("for the sum ")#mi("(d=1)")#text(" we have.")

#mi("1 + 1 + 1 + 1  + (-1)^{4} + (-1)^{6} + (-1)^{8} = 7 <  (k + 2)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-493873")[#strong[#text("Terence Tao dimostra una congettura di Erdős (with a little help from his friends) - Maddmaths!")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2018")]

#text("[…] giorno fa Terence Tao ha annunciato (qui e qui) di aver dimostrato una congettura di Pál (Paul) Erdős, nota come il problema della discrepanza. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3872039d6438c92ecf5e993019e122e2ef6a4004387aebf0469d619449d1ba2c-70a4fd527ec6d9db06fc84f71888f24e62bf99cb9495fc0b2edf356b1e193df3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hermawan Wiwit")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-513166")[#strong[#text("Hermawan Wiwit")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2019")])]

#text("That’s an interesting topic to discuss. Do you know that it can be solved by programming? the computer vision or recommender system?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/840c0a7f4c0cfe80495ec93dc1a97261fec85991604d5dd0ad23ab1d17264a2f-c967a676b87019705247a5f98f70dacaca52226d08ba935b4903c327cb897cd2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zekeyy210")]], [#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-636663")[#strong[#text("zekeyy210")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2021")])]

#text("Hi! thank you for the information this article is very interesting")
]
