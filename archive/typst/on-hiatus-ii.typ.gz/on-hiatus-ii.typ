// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/07/22/on-hiatus-ii/
// Converted to Typst by tao2typ: "2026-10-14T09:00:27.173490+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On hiatus II", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On hiatus II")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 July 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/07/22/on-hiatus-ii/")[#text("https://terrytao.wordpress.com/2010/07/22/on-hiatus-ii/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’ll be taking a break from blogging and other work for a few weeks.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c12db7c7eaab9ab62c3c8247d8ea433b70a293503fa59e81534badd33981beea-3a3e1afe3bc15edc644626ea16978057f21d37a24774ea35d6a8404804040047.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2010/07/22/on-hiatus-ii/#comment-46150")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2010")])]

#text("Theorem. This is simply => impossible really die <= : this would be truly UNTHINKABLE.")#linebreak()#text(" The desired result follows immediately. Q.E.D.")

#text("————————————————————")

#text("You are truly a marvel of industry and insight: enjoy your (terrifically well-deserved) vacation!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/07/22/on-hiatus-ii/#comment-46151")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2010")])]

#text("Enjoy your vacation Dear Prof. Tao.")#linebreak()#text(" We are looking forward to reading your great block posts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8fb99ea86767dc5427b9c6666fc7e0ba61d2d9fcfb35b9b369151a292134dc8b-8bb760d6c636a39da5c9510352a5424b7aae63e318a119622e8dda6907a5543a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of patzer")]], [#link("https://terrytao.wordpress.com/2010/07/22/on-hiatus-ii/#comment-46152")[#strong[#text("patzer")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2010")])]

#text("have a great vacation –")#linebreak()#text(" your blog brings much joy to all the people")#linebreak()#text(" with an interest in math")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11cac8bde0677bc43849cc66b6c6c521d3d5a7cf91c7fdeac73e56aae0504d7d-8314babeb03af470dda611f556254e78f7322714dcc217a2d0f56def9d134eaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Researcher")]], [#link("https://terrytao.wordpress.com/2010/07/22/on-hiatus-ii/#comment-46194")[#strong[#text("Researcher")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2010")])]

#text("Have a great vacation!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/07/22/on-hiatus-ii/#comment-46488")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2010")])]

#text("I see you’re keeping busy with that P/NP proof. I hope it didn’t interrupt your vacation!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e908a3792224d7bc081b781a19e8ee17d15d774d02b4d689977a417fc36ef74-c315bcd556d9675f9bf224d5ab2405f6eb9d92124d698e9216013ce036d9e669.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dream")]], [#link("https://terrytao.wordpress.com/2010/07/22/on-hiatus-ii/#comment-46542")[#strong[#text("dream")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2010")])]

#text("hello,prof.tao,i am a 16 girl,and i come from china. i’m very glad to meet you!! i like you very much,and i will support you forever!! may you happy every day!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e908a3792224d7bc081b781a19e8ee17d15d774d02b4d689977a417fc36ef74-c315bcd556d9675f9bf224d5ab2405f6eb9d92124d698e9216013ce036d9e669.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dream")]], [#link("https://terrytao.wordpress.com/2010/07/22/on-hiatus-ii/#comment-46543")[#strong[#text("dream")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2010")])]

#text("i hope you can reply me, thank you very much!!have a good vacation!!!")
]
