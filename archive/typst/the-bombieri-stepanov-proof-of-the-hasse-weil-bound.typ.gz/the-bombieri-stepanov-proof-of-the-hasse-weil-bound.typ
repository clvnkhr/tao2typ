// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/
// Converted to Typst by tao2typ: "2026-10-14T16:37:23.599968+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Bombieri-Stepanov proof of the Hasse-Weil bound", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Bombieri-Stepanov proof of the Hasse-Weil bound")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 May 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/")[#text("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{{\\bf F}_q}")#text(" be a finite field of order ")#mi("{q = p^n}")#text(", and let ")#mi("{C}")#text(" be an ")#link("http://en.wikipedia.org/wiki/Absolutely_irreducible")[#text("absolutely irreducible")]#text(" ")#link("http://en.wikipedia.org/wiki/Smooth_variety")[#text("smooth")]#text(" ")#link("http://en.wikipedia.org/wiki/Projective_variety")[#text("projective")]#text(" ")#link("http://en.wikipedia.org/wiki/Algebraic_curve")[#text("curve")]#text(" defined over ")#mi("{{\\bf F}_q}")#text(" (and hence over the algebraic closure ")#mi("{k := \\overline{{\\bf F}_q}}")#text(" of that field). For instance, ")#mi("{C}")#text(" could be the projective ")#link("http://en.wikipedia.org/wiki/Elliptic_curve")[#text("elliptic curve")]

#align(center)[#tao-fit-display[#mitex("C = \\{ [x,y,z]: y^2 z = x^3 + ax z^2 + b z^3 \\}")]]

#text("in the projective plane ")#mi("{{\\bf P}^2 = \\{ [x,y,z]: (x,y,z) \\neq (0,0,0) \\}}")#text(", where ")#mi("{a,b \\in {\\bf F}_q}")#text(" are coefficients whose discriminant ")#mi("{-16(4a^3+27b^2)}")#text(" is non-vanishing, which is the projective version of the affine elliptic curve")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y): y^2 = x^3 + ax + b \\}.")]]

#text("To each such curve ")#mi("{C}")#text(" one can associate a ")#link("http://en.wikipedia.org/wiki/Geometric_genus")[#text("genus")]#text(" ")#mi("{g}")#text(", which we will define later; for instance, elliptic curves have genus ")#mi("{1}")#text(". We can also count the cardinality ")#tao-math("{\\left|C({\\bf F}_q)\\right|}", block: false)#text(" of the set ")#mi("{C({\\bf F}_q)}")#text(" of ")#mi("{{\\bf F}_q}")#text("-points of ")#mi("{C}")#text(". The ")#emph[#text("Hasse-Weil bound")]#text(" relates the two:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Hasse-Weil bound)")]#text(" ")#metadata(none) <tao-db111a357721818c6bc3>#text(" ")#tao-math("{\\left|\\left|C({\\bf F}_q)\\right| - q - 1\\right| \\leq 2g\\sqrt{q}}", block: false)#text(".")
]

#text("The usual proofs of this bound proceed by first establishing a trace formula of the form ")#metadata(none) <tao-eafe895eb8119e6e5d06>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|C({\\bf F}_{p^n})\\right| = p^n - \\sum_{i=1}^{2g} \\alpha_i^n + 1", block: true)]]



#text(" for some complex numbers ")#mi("{\\alpha_1,\\dots,\\alpha_{2g}}")#text(" independent of ")#mi("{n}")#text("; this is in fact a special case of the ")#link("http://en.wikipedia.org/wiki/Lefschetz_trace_formula#Frobenius")[#text("Lefschetz-Grothendieck trace formula")]#text(", and can be interpreted as an assertion that the ")#link("http://en.wikipedia.org/wiki/Hasse%E2%80%93Weil_zeta_function")[#text("zeta function associated to the curve")]#text(" ")#mi("{C}")#text(" is rational. The task is then to establish a bound ")#tao-math("{\\left|\\alpha_i\\right| \\leq \\sqrt{p}}", block: false)#text(" for all ")#mi("{i=1,\\dots,2g}")#text("; this (or more precisely, the slightly stronger assertion ")#tao-math("{\\left|\\alpha_i\\right| = \\sqrt{p}}", block: false)#text(") is the Riemann hypothesis for such curves. This can be done either by passing to the ")#link("http://en.wikipedia.org/wiki/Jacobian_variety")[#text("Jacobian variety")]#text(" of ")#mi("{C}")#text(" and using a certain duality available on the cohomology of such varieties, known as ")#link("http://en.wikipedia.org/wiki/Rosati_involution")[#text("Rosati involution")]#text("; alternatively, one can pass to the product surface ")#mi("{C \\times C}")#text(" and apply the ")#link("http://en.wikipedia.org/wiki/Riemann%E2%80%93Roch_theorem")[#text("Riemann-Roch theorem")]#text(" for that surface.")

#text("In 1969, ")#link("http://www.ams.org/mathscinet-getitem?mr=252400")[#text("Stepanov introduced")]#text(" an elementary method (a version of what is now known as the polynomial method) to count (or at least to upper bound) the quantity ")#tao-math("{\\left|C({\\bf F}_q)\\right|}", block: false)#text(". The method was initially restricted to hyperelliptic curves, but was soon extended to general curves. In particular, ")#link("http://www.ams.org/mathscinet-getitem?mr=429903")[#text("Bombieri used")]#text(" this method to give a short proof of the following weaker version of the Hasse-Weil bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Weak Hasse-Weil bound)")]#text(" ")#metadata(none) <tao-8417fa7a92ccdb99fecb>#text(" If ")#mi("{q}")#text(" is a perfect square, and ")#mi("{q \\geq (g+1)^4}")#text(", then ")#tao-math("{\\left|C({\\bf F}_q)\\right| \\leq q + (2g+1) \\sqrt{q} + 1}", block: false)#text(".")
]

#text("In fact, the bound on ")#tao-math("{\\left|C({\\bf F}_q)\\right|}", block: false)#text(" can be sharpened a little bit further, as we will soon see.")

#text("Theorem ")#link(<tao-8417fa7a92ccdb99fecb>)[#text("2")]#text(" is only an upper bound on ")#tao-math("{\\left|C({\\bf F}_q)\\right|}", block: false)#text(", but there is a Galois-theoretic trick to convert (a slight generalisation of) this upper bound to a matching lower bound, and if one then uses the trace formula ")#link(<tao-eafe895eb8119e6e5d06>)[#text("(1)")]#text(" (and the “")#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/")[#text("tensor power trick")]#text("” of sending ")#mi("{n}")#text(" to infinity to control the weights ")#mi("{\\alpha_i}")#text(") one can then recover the full Hasse-Weil bound. We discuss these steps below the fold.")

#text("I’ve discussed Bombieri’s proof of Theorem ")#link(<tao-8417fa7a92ccdb99fecb>)[#text("2")]#text(" in ")#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/")[#text("this previous post")]#text(" (in the special case of hyperelliptic curves), but now wish to present the full proof, with some minor simplifications from Bombieri’s original presentation; it is mostly elementary, with the deepest fact from algebraic geometry needed being Riemann’s inequality (a weak form of the ")#link("http://en.wikipedia.org/wiki/Riemann%E2%80%93Roch_theorem")[#text("Riemann-Roch theorem")]#text(").")

#text("The first step is to reinterpret ")#tao-math("{\\left|C({\\bf F}_q)\\right|}", block: false)#text(" as the number of points of intersection between two curves ")#mi("{C_1,C_2}")#text(" in the surface ")#mi("{C \\times C}")#text(". Indeed, if we define the ")#link("http://en.wikipedia.org/wiki/Frobenius_endomorphism")[#text("Frobenius endomorphism")]#text(" ")#mi("{\\text{Frob}_q}")#text(" on any projective space by")

#align(center)[#tao-fit-display[#mitex("\\text{Frob}_q( [x_0,\\dots,x_n] ) := [x_0^q, \\dots, x_n^q]")]]

#text("then this map preserves the curve ")#mi("{C}")#text(", and the fixed points of this map are precisely the ")#mi("{{\\bf F}_q}")#text(" points of ")#mi("{C}")#text(":")

#align(center)[#tao-fit-display[#mitex("C({\\bf F}_q) = \\{ z \\in C: \\text{Frob}_q(z) = z \\}.")]]

#text("Thus one can interpret ")#tao-math("{\\left|C({\\bf F}_q)\\right|}", block: false)#text(" as the number of points of intersection between the diagonal curve")

#align(center)[#tao-fit-display[#mitex("\\{ (z,z): z \\in C \\}")]]

#text("and the Frobenius graph")

#align(center)[#tao-fit-display[#mitex("\\{ (z, \\text{Frob}_q(z)): z \\in C \\}")]]

#text("which are copies of ")#mi("{C}")#text(" inside ")#mi("{C \\times C}")#text(". But we can use the additional hypothesis that ")#mi("{q}")#text(" is a perfect square to write this more symmetrically, by taking advantage of the fact that the Frobenius map has a square root")

#align(center)[#tao-fit-display[#mitex("\\text{Frob}_q = \\text{Frob}_{\\sqrt{q}}^2")]]

#text("with ")#mi("{\\text{Frob}_{\\sqrt{q}}}")#text(" also preserving ")#mi("{C}")#text(". One can then also interpret ")#tao-math("{\\left|C({\\bf F}_q)\\right|}", block: false)#text(" as the number of points of intersection between the curve ")#metadata(none) <tao-668b2c3d9d9558acbae9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("C_1 := \\{ (z, \\text{Frob}_{\\sqrt{q}}(z)): z \\in C \\}")]]



#text(" and its transpose")

#align(center)[#tao-fit-display[#mitex("C_2 := \\{ (\\text{Frob}_{\\sqrt{q}}(w), w): w \\in C \\}.")]]

#text("Let ")#mi("{k(C \\times C)}")#text(" be the field of rational functions on ")#mi("{C \\times C}")#text(" (with coefficients in ")#mi("{k}")#text("), and define ")#mi("{k(C_1)}")#text(", ")#mi("{k(C_2)}")#text(", and ")#mi("{k(C_1 \\cap C_2)}")#text(" analogously )(although ")#mi("{C_1 \\cap C_2}")#text(" is likely to be disconnected, so ")#mi("{k(C_1 \\cap C_2)}")#text(" will just be a ring rather than a field. We then (morally) have the commuting square")

#align(center)[#tao-fit-display[#mitex("\\begin{array}{ccccc} && k(C \\times C) && \\\\ & \\swarrow & & \\searrow & \\\\ k(C_1) & & & & k(C_2) \\\\ & \\searrow & & \\swarrow & \\\\ && k(C_1 \\cap C_2) && \\end{array},")]]

#text("if we ignore the issue that a rational function on, say, ")#mi("{C \\times C}")#text(", might blow up on all of ")#mi("{C_1}")#text(" and thus not have a well-defined restriction to ")#mi("{C_1}")#text(". We use ")#mi("{\\pi_1: k(C \\times C) \\rightarrow k(C_1)}")#text(" and ")#mi("{\\pi_2: k(C \\times C) \\rightarrow k(C_2)}")#text(" to denote the restriction maps. Furthermore, we have obvious isomorphisms ")#mi("{\\iota_1: k(C_1) \\rightarrow k(C)}")#text(", ")#mi("{\\iota_2: k(C_2) \\rightarrow k(C)}")#text(" coming from composing with the graphing maps ")#mi("{z \\mapsto (z, \\text{Frob}_{\\sqrt{q}}(z))}")#text(" and ")#mi("{w \\mapsto (\\text{Frob}_{\\sqrt{q}}(w), w)}")#text(".")

#text("The idea now is to find a rational function ")#mi("{f \\in k(C \\times C)}")#text(" on the surface ")#mi("{C \\times C}")#text(" of controlled degree which vanishes when restricted to ")#mi("{C_1}")#text(", but is non-vanishing (and not blowing up) when restricted to ")#mi("{C_2}")#text(". On ")#mi("{C_2}")#text(", we thus get a non-zero rational function ")#mi("{f \\downharpoonright_{C_2}}")#text(" of controlled degree which vanishes on ")#mi("{C_1 \\cap C_2}")#text(" – which then lets us bound the cardinality of ")#mi("{C_1 \\cap C_2}")#text(" in terms of the degree of ")#mi("{f \\downharpoonright_{C_2}}")#text(". (In Bombieri’s original argument, one required vanishing to high order on the ")#mi("{C_1}")#text(" side, but in our presentation, we have factored out a ")#mi("{\\text{Frob}_{\\sqrt{q}}}")#text(" term which removes this high order vanishing condition.)")

#text("To find this ")#mi("{f}")#text(", we will use linear algebra. Namely, we will locate a finite-dimensional subspace ")#mi("{V}")#text(" of ")#mi("{k(C \\times C)}")#text(" (consisting of certain “controlled degree” rational functions) which projects injectively to ")#mi("{k(C_2)}")#text(", but whose projection to ")#mi("{k(C_1)}")#text(" has strictly smaller dimension than ")#mi("{V}")#text(" itself. The ")#link("http://en.wikipedia.org/wiki/Rank%E2%80%93nullity_theorem")[#text("rank-nullity theorem")]#text(" then forces the existence of a non-zero element ")#mi("{P}")#text(" of ")#mi("{V}")#text(" whose projection to ")#mi("{k(C_1)}")#text(" vanishes, but whose projection to ")#mi("{k(C_2)}")#text(" is non-zero.")

#text("Now we build ")#mi("{V}")#text(". Pick a ")#mi("{{\\bf F}_q}")#text(" point ")#mi("{P_\\infty}")#text(" of ")#mi("{C}")#text(", which we will think of as being a point at infinity. (For the purposes of proving Theorem ")#link(<tao-8417fa7a92ccdb99fecb>)[#text("2")]#text(", we may clearly assume that ")#mi("{C({\\bf F}_q)}")#text(" is non-empty.) Thus ")#mi("{P_\\infty}")#text(" is fixed by ")#mi("{\\text{Frob}_q}")#text(". To simplify the exposition, we will also assume that ")#mi("{P_\\infty}")#text(" is fixed by the square root ")#mi("{\\text{Frob}_{\\sqrt{q}}}")#text(" of ")#mi("{\\text{Frob}_q}")#text("; in the opposite case when ")#mi("{\\text{Frob}_{\\sqrt{q}}}")#text(" has order two when acting on ")#mi("{P_\\infty}")#text(", the argument is essentially the same, but all references to ")#mi("{P_\\infty}")#text(" in the second factor of ")#mi("{C \\times C}")#text(" need to be replaced by ")#mi("{\\text{Frob}_{\\sqrt{q}} P_\\infty}")#text(" (we leave the details to the interested reader).")

#text("For any natural number ")#mi("{n}")#text(", define ")#mi("{R_n}")#text(" to be the set of rational functions ")#mi("{f \\in k(C)}")#text(" which are allowed to have a pole of order up to ")#mi("{n}")#text(" at ")#mi("{P_\\infty}")#text(", but have no other poles on ")#mi("{C}")#text("; note that as we are assuming ")#mi("{C}")#text(" to be smooth, it is unambiguous what a pole is (and what order it will have). (In the fancier language of ")#link("http://en.wikipedia.org/wiki/Divisor_(algebraic_geometry)#Weil_divisor")[#text("divisors")]#text(" and ")#link("http://en.wikipedia.org/wiki/%C4%8Cech_cohomology")[#text("Cech cohomology")]#text(", we have ")#mi("{R_n = H^0( C, {\\mathcal O}_C(-n P_\\infty) )}")#text(".) The space ")#mi("{R_n}")#text(" is clearly a vector space over ")#mi("{k}")#text("; one can view intuitively as the space of “polynomials” on ")#mi("{C}")#text(" of “degree” at most ")#mi("{n}")#text(". When ")#mi("{n=0}")#text(", ")#mi("{R_0}")#text(" consists just of the constant functions. Indeed, if ")#mi("{f \\in R_0}")#text(", then the image ")#mi("{f(C)}")#text(" of ")#mi("{f}")#text(" avoids ")#mi("{\\infty}")#text(" and so lies in the affine line ")#mi("{k = {\\mathbf P}^1 \\backslash \\{\\infty\\}}")#text("; but as ")#mi("{C}")#text(" is projective, the image ")#mi("{f(C)}")#text(" needs to be compact (hence closed) in ")#mi("{{\\mathbf P}^1}")#text(", and must therefore be a point, giving the claim.")

#text("For higher ")#mi("{n \\geq 1}")#text(", we have the easy relations ")#metadata(none) <tao-e78618f499c47e470b9d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\text{dim}(R_{n-1}) \\leq \\text{dim}(R_n) \\leq \\text{dim}(R_{n-1})+1.")]]



#text(" The former inequality just comes from the trivial inclusion ")#mi("{R_{n-1} \\subset R_n}")#text(". For the latter, observe that if two functions ")#mi("{f, g}")#text(" lie in ")#mi("{R_n}")#text(", so that they each have a pole of order at most ")#mi("{n}")#text(" at ")#mi("{P_\\infty}")#text(", then some linear combination of these functions must have a pole of order at most ")#mi("{n-1}")#text(" at ")#mi("{P_\\infty}")#text("; thus ")#mi("{R_{n-1}}")#text(" has codimension at most one in ")#mi("{R_n}")#text(", giving the claim.")

#text("From ")#link(<tao-e78618f499c47e470b9d>)[#text("(3)")]#text(" and induction we see that each of the ")#mi("{R_n}")#text(" are finite dimensional, with the trivial upper bound ")#metadata(none) <tao-15d07b62819e39a4c5e9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\text{dim}(R_n) \\leq n+1.")]]



#text(" ")#emph[#text("Riemann’s inequality")]#text(" complements this with the lower bound ")#metadata(none) <tao-804009875b8f14742850>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\text{dim}(R_n) \\geq n+1-g,")]]



#text(" thus one has ")#mi("{\\text{dim}(R_n) = \\text{dim}(R_{n-1})+1}")#text(" for all but at most ")#mi("{g}")#text(" exceptions (in fact, exactly ")#mi("{g}")#text(" exceptions as it turns out). This is a consequence of the ")#link("http://en.wikipedia.org/wiki/Riemann-Roch_theorem")[#text("Riemann-Roch theorem")]#text("; it can be proven from abstract nonsense (the ")#link("http://en.wikipedia.org/wiki/Snake_lemma")[#text("snake lemma")]#text(") if one defines the genus ")#mi("{g}")#text(" in a non-standard fashion (as the dimension of the first Cech cohomology ")#mi("{H^1(C)}")#text(" of the structure sheaf ")#mi("{{\\mathcal O}_C}")#text(" of ")#mi("{C}")#text("), but to obtain this inequality with a standard definition of ")#mi("{g}")#text(" (e.g. as the dimension of the zeroth Cech cohomolgy ")#mi("{H^0(C, \\Omega_C^1)}")#text(" of the line bundle of differentials) requires the more non-trivial tool of ")#link("http://en.wikipedia.org/wiki/Serre_duality")[#text("Serre duality")]#text(".")

#text("At any rate, now that we have these vector spaces ")#mi("{R_n}")#text(", we will define ")#mi("{V \\subset k(C \\times C)}")#text(" to be a tensor product space")

#align(center)[#tao-fit-display[#mitex("V = R_\\ell \\otimes R_m")]]

#text("for some natural numbers ")#mi("{\\ell, m \\geq 0}")#text(" which we will optimise in later. That is to say, ")#mi("{V}")#text(" is spanned by functions of the form ")#mi("{(z,w) \\mapsto f(z) g(w)}")#text(" with ")#mi("{f \\in R_\\ell}")#text(" and ")#mi("{g \\in R_m}")#text(". This is clearly a linear subspace of ")#mi("{k(C \\times C)}")#text(" of dimension ")#mi("{\\text{dim}(R_\\ell) \\text{dim}(R_m)}")#text(", and hence by Rieman’s inequality we have ")#metadata(none) <tao-e9e28f7c7d91e3901e03>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\text{dim}(V) \\geq (\\ell+1-g) (m+1-g)")]]



#text(" if ")#metadata(none) <tao-4b7490db833aa7cb1e07>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\ell,m \\geq g-1.")]]





#text("Observe that ")#mi("{\\iota_1 \\circ \\pi_1}")#text(" maps a tensor product ")#mi("{(z,w) \\mapsto f(z) g(w)}")#text(" to a function ")#mi("{z \\mapsto f(z) g(\\text{Frob}_{\\sqrt{q}} z)}")#text(". If ")#mi("{f \\in R_\\ell}")#text(" and ")#mi("{g \\in R_m}")#text(", then we see that the function ")#mi("{z \\mapsto f(z) g(\\text{Frob}_{\\sqrt{q}} z)}")#text(" has a pole of order at most ")#mi("{\\ell+m\\sqrt{q}}")#text(" at ")#mi("{P_\\infty}")#text(". We conclude that ")#metadata(none) <tao-cd01cfa971c6048f0be5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\iota_1 \\circ \\pi_1( V ) \\subset R_{\\ell + m\\sqrt{q}}")]]



#text(" and in particular by ")#link(<tao-15d07b62819e39a4c5e9>)[#text("(4)")]#text(" ")#metadata(none) <tao-c5bf6a66392e10f475fa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\text{dim}(\\pi_1(V)) \\leq \\ell + m \\sqrt{q} + 1")]]



#text(" and similarly ")#metadata(none) <tao-cc03dc084790707c32ba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\text{dim}(\\pi_2(V)) \\leq \\ell \\sqrt{q} + m + 1.")]]





#text("We will choose ")#mi("{m}")#text(" to be a bit bigger than ")#mi("{\\ell}")#text(", to make the ")#mi("{\\pi_2}")#text(" image of ")#mi("{V}")#text(" smaller than that of ")#mi("{\\pi_1}")#text(". From ")#link(<tao-e9e28f7c7d91e3901e03>)[#text("(6)")]#text(", ")#link(<tao-cc03dc084790707c32ba>)[#text("(10)")]#text(" we see that if we have the inequality ")#metadata(none) <tao-3b0ba1249a487dd215ca>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("(\\ell+1-g) (m+1-g) > \\ell \\sqrt{q}+m + 1")]]



#text(" (together with ")#link(<tao-4b7490db833aa7cb1e07>)[#text("(7)")]#text(") then ")#mi("{\\pi_2}")#text(" cannot be injective.")

#text("On the other hand, we have the following basic fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Injectivity)")]#text(" If ")#metadata(none) <tao-307a1e4bcb0c57131bb5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\ell < \\sqrt{q},")]]



#text(" then ")#mi("{\\pi_1: V \\rightarrow \\pi_1(V)}")#text(" is injective.")
]

#emph[#text("Proof:")]#text(" From ")#link(<tao-e78618f499c47e470b9d>)[#text("(3)")]#text(", we can find a linear basis ")#mi("{f_1,\\dots,f_a}")#text(" of ")#mi("{R_\\ell}")#text(" such that each of the ")#mi("{f_i}")#text(" has a distinct order ")#mi("{d_i}")#text(" of pole at ")#mi("{P_\\infty}")#text(" (somewhere between ")#mi("{0}")#text(" and ")#mi("{\\ell}")#text(" inclusive). Similarly, we may find a linear basis ")#mi("{g_1,\\dots,g_b}")#text(" of ")#mi("{R_m}")#text(" such that each of the ")#mi("{g_j}")#text(" has a distinct order ")#mi("{e_j}")#text(" of pole at ")#mi("{P_\\infty}")#text(" (somewhere between ")#mi("{0}")#text(" and ")#mi("{m}")#text(" inclusive). The functions ")#mi("{z \\mapsto f_i(z) g_j(\\text{Frob}_{\\sqrt{q}} z)}")#text(" then span ")#mi("{\\iota_1(\\pi_1(V))}")#text(", and the order of pole at ")#mi("{P_\\infty}")#text(" is ")#mi("{d_i + \\sqrt{q} e_j}")#text(". But since ")#mi("{\\ell < \\sqrt{q}}")#text(", these orders are all distinct, and so these functions must be linearly independent. The claim follows. ")#mi("\\Box")

#text("This gives us the following bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" Let ")#mi("{\\ell,m}")#text(" be natural numbers such that ")#link(<tao-4b7490db833aa7cb1e07>)[#text("(7)")]#text(", ")#link(<tao-3b0ba1249a487dd215ca>)[#text("(11)")]#text(", ")#link(<tao-307a1e4bcb0c57131bb5>)[#text("(12)")]#text(" hold. Then ")#tao-math("{\\left|C({\\bf F}_q)\\right| \\leq \\ell + m \\sqrt{q}}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" As ")#mi("{\\pi_2}")#text(" is not injective, we can find ")#mi("{f \\in V}")#text(" with ")#mi("{\\pi_2(f)}")#text(" vanishing. By the above lemma, the function ")#mi("{\\iota_1(\\pi_1(f))}")#text(" is then non-zero, but it must also vanish on ")#mi("{\\iota_1(C_1 \\cap C_2)}")#text(", which has cardinality ")#tao-math("{\\left|C({\\bf F}_q)\\right|}", block: false)#text(". On the other hand, by ")#link(<tao-cd01cfa971c6048f0be5>)[#text("(8)")]#text(", ")#mi("{\\iota_1(\\pi_1(f))}")#text(" has a pole of order at most ")#mi("{\\ell+m\\sqrt{q}}")#text(" at ")#mi("{P_\\infty}")#text(" and no other poles. Since the number of poles and zeroes of a rational function on a projective curve must add up to zero, the claim follows. ")#mi("\\Box")

#text("If ")#mi("{q \\geq (g+1)^4}")#text(", we may make the explicit choice")

#align(center)[#tao-fit-display[#mitex("m := \\sqrt{q}+2g; \\quad \\ell := \\lfloor \\frac{g}{g+1} \\sqrt{q} \\rfloor + g + 1")]]

#text("and a brief calculation then gives Theorem ")#link(<tao-8417fa7a92ccdb99fecb>)[#text("2")]#text(". In some cases one can optimise things a bit further. For instance, in the genus zero case ")#mi("{g=0}")#text(" (e.g. if ")#mi("{C}")#text(" is just the projective line ")#mi("{{\\mathbf P}^1}")#text(") one may take ")#mi("{\\ell=1, m = \\sqrt{q}}")#text(" and conclude the absolutely sharp bound ")#tao-math("{\\left|C({\\bf F}_q)\\right| \\leq q+1}", block: false)#text(" in this case; in the case of the projective line ")#mi("{{\\mathbf P}^1}")#text(", the function ")#mi("{f}")#text(" is in fact the very concrete function ")#mi("{f(z,w) := z - w^{\\sqrt{q}}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" When ")#mi("{q = p^{2n+1}}")#text(" is not a perfect square, one can try to run the above argument using the factorisation ")#mi("{\\text{Frob}_q = \\text{Frob}_{p^n} \\text{Frob}_{p^{n+1}}}")#text(" instead of ")#mi("{\\text{Frob}_q = \\text{Frob}_{\\sqrt{q}} \\text{Frob}_{\\sqrt{q}}}")#text(". This gives a weaker version of the above bound, of the shape ")#tao-math("{\\left|C({\\bf F}_q)\\right| \\leq q + O( \\sqrt{p} \\sqrt{q} )}", block: false)#text(". In the hyperelliptic case at least, one can erase this loss by working with a variant of the argument in which one requires ")#mi("{f}")#text(" to vanish to high order at ")#mi("{C_1}")#text(", rather than just to first order; see ")#link("http://arxiv.org/abs/1310.6482")[#text("this survey article of mine")]#text(" for details.")
]

#metadata(none) <tao-8ee6f493784be286d821>

#heading(level: 1)[#strong[#text(" — 1. Additional notes — ")]]

#text("One can get a “cheap” proof of Riemann’s inequality (with the “wrong” definition of the genus ")#mi("{g}")#text(") from ")#link("http://en.wikipedia.org/wiki/Cech_cohomology")[#text("Cech cohomology")]#text(" as follows. For any natural number ")#mi("{n}")#text(", let ")#mi("{{\\mathcal O}_C(-nP_\\infty)}")#text(" denote the sheaf on ")#mi("{C}")#text(", defined by setting the sections on any open set ")#mi("{U}")#text(" of ")#mi("{C}")#text(" to be the rational functions with no poles at ")#mi("{U}")#text(", except possibly for a pole of order up to ")#mi("{n}")#text(" at ")#mi("{P_\\infty}")#text(" in the case that ")#mi("{U}")#text(" contains ")#mi("{P_\\infty}")#text(". Then ")#mi("{R_n}")#text(" is the space of global sections on this sheaf, that is to say the zeroth Cech cohomology ")#mi("{H^0({\\mathcal O}_C(-nP_\\infty))}")#text(". On the other hand, we also have the ")#link("http://en.wikipedia.org/wiki/Stalk_(sheaf)#Skyscraper_sheaf")[#text("skyscraper sheaf")]#text(" ")#mi("{k_{P_\\infty}}")#text(" on ")#mi("{C}")#text(", defined by setting the sections on ")#mi("{U}")#text(" to be ")#mi("{k}")#text(" if ")#mi("{U}")#text(" contains ")#mi("{P_\\infty}")#text(" and ")#mi("{\\{0\\}}")#text(" otherwise. For ")#mi("{n \\geq 1}")#text(", we have an obvious short ")#link("http://en.wikipedia.org/wiki/Exact_sequence")[#text("exact sequence")]#text(" of sheaves")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow {\\mathcal O}_C(-(n-1)P_\\infty) \\rightarrow {\\mathcal O}_C(-nP_\\infty) \\rightarrow k_{P_\\infty} \\rightarrow 0")]]

#text("which upon taking Cech cohomology (and using the ")#link("http://en.wikipedia.org/wiki/Snake_lemma")[#text("snake lemma")]#text(") gives the long exact sequence")

#tao-aligned(keep: true)[


#tao-math("0  & \\rightarrow H^0({\\mathcal O}_C(-(n-1)P_\\infty)) \\rightarrow H^0({\\mathcal O}_C(-nP_\\infty)) \\rightarrow H^0(k_{P_\\infty}) \\rightarrow", block: true)



#tao-math("H^1({\\mathcal O}_C(-(n-1)P_\\infty))  & \\rightarrow H^1({\\mathcal O}_C(-nP_\\infty)) \\rightarrow H^1(k_{P_\\infty}).", block: true)
]

#text("One can compute that ")#mi("{H^0(k_{P_\\infty}) = k}")#text(" and ")#mi("{H^1(k_{P_\\infty})=0}")#text(", so the long exact sequence becomes")

#tao-aligned(keep: true)[


#tao-math("0  & \\rightarrow R_{n-1} \\rightarrow R_n \\rightarrow k \\rightarrow", block: true)



#tao-math("H^1({\\mathcal O}_C(-(n-1)P_\\infty))  & \\rightarrow H^1({\\mathcal O}_C(-nP_\\infty)) \\rightarrow 0.", block: true)
]

#text("The first part of this long exact sequence already recovers the trivial bounds ")#link(<tao-e78618f499c47e470b9d>)[#text("(3)")]#text(". But it also shows that the dimensions of the spaces ")#mi("{H^1({\\mathcal O}_C(-nP_\\infty))}")#text(" are non-increasing, and decrease by one precisely when the left inequality in ")#link(<tao-e78618f499c47e470b9d>)[#text("(3)")]#text(" is sharp. If one then makes the non-standard definition ")#mi("{g := \\text{dim}( H^1( {\\mathcal O}_C ) )}")#text(", then this decrease can occur at most ")#mi("{g}")#text(" times, and Riemann’s inequality then follows. (However, it is not immediately obvious with this definition that ")#mi("{g}")#text(" is finite; this requires some additional effort, e.g. invoking the ")#link("http://en.wikipedia.org/wiki/Riemann-Hurwitz_formula")[#text("Riemann-Hurwitz formula")]#text(".) To relate this definition of ")#mi("{g}")#text(" to the more usual notions of genus requires the use of ")#link("http://en.wikipedia.org/wiki/Serre_duality")[#text("Serre duality")]#text(", which will not be discussed here.")

#text("The upper bound in Theorem ")#link(<tao-8417fa7a92ccdb99fecb>)[#text("2")]#text(" (or more precisely, a generalisation of this bound) can be converted into a comparable lower bound, namely")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5")]#text(" ")#metadata(none) <tao-2d24c9d4a6b65772ca58>#text(" Let ")#mi("{C}")#text(" be an absolutely irreducible quasiprojective curve of bounded degree, defined over ")#mi("{{\\bf F}_q}")#text(", and let ")#mi("{q = p^n}")#text(" be a perfect square. Then")

#align(center)[#tao-fit-display[#tao-math("\\left|C({\\bf F}_q)\\right| = q + O(\\sqrt{q}),", block: true)]]

#text("where the implied constant can depend on ")#mi("{C}")#text(" but is uniform in ")#mi("{n}")#text(" in the limit ")#mi("{n \\rightarrow \\infty}")#text(" (holding ")#mi("{p}")#text(" and ")#mi("{C}")#text(" fixed).")
]

#emph[#text("Proof:")]#text(" The upper bound follows from Theorem ")#link(<tao-8417fa7a92ccdb99fecb>)[#text("2")]#text(", after first removing all the singularities from ")#mi("{C}")#text(", normalising ")#mi("{C}")#text(" to be projective, and noting that the genus does not depend on ")#mi("{n}")#text(". (Note that removing singularities only deletes ")#mi("{O(1)}")#text(" points at most.) So the remaining task is to establish the matching lower bound. Unfortunately, the trace formula ")#link(<tao-eafe895eb8119e6e5d06>)[#text("(1)")]#text(" is not enough by itself to convert upper bounds to lower bounds, due to the case in which all the ")#mi("{\\alpha_i}")#text(" are positive, although strangely enough it can be used for the reverse task of converting lower bounds to upper bounds. Instead, we use a Galois-theoretic argument, though for (somewhat idiosyncratic) reasons, I will disguise the Galois theory by writing everything in a geometric language rather than an algebraic one.")

#text("The basic idea is to embed ")#mi("{C}")#text(" (perhaps with a bounded number of points removed) as a component of a larger (non-reducible) curve ")#mi("{C^{\\prime}}")#text(" for which (a) the number of “rational points” on this larger curve ")#mi("{C^{\\prime}}")#text(" can be counted almost exactly; and (b) an upper bound similar to Theorem ")#link(<tao-8417fa7a92ccdb99fecb>)[#text("2")]#text(" exists for the number of “rational points” on each of the components of ")#mi("{C^{\\prime}}")#text(", so that a lower bound can then be established by subtraction.")

#text("An easy instance of this trick arises in the case of hyperelliptic curves, which we will write affinely (deleting the point at infinity, by abuse of notation) as ")#mi("{C = \\{ (x,y): y^2 = f(x) \\}}")#text(" for some polynomial ")#mi("{f}")#text(" defined over ")#mi("{{\\bf F}_q}")#text(" that is not a perfect square. We can embed this in the reducible curve")

#align(center)[#tao-fit-display[#mitex("C^{\\prime} := \\{ (x,y): y^2 = f(x) \\} \\cup \\{(x,y): y^2 = af(x) \\}")]]

#text("where ")#mi("{a}")#text(" is an arbitrarily chosen quadratic non-residue of ")#mi("{{\\bf F}_q}")#text(". The curve ")#mi("{C^{\\prime}}")#text(" is the union of two curves, one of which is a dilate of the other, so they both have the same genus ")#mi("{g}")#text(", and so they each have at most ")#mi("{q + O(\\sqrt{q})}")#text(" points (in the regime when ")#mi("{g}")#text(" is bounded and ")#mi("{q}")#text(" is a perfect square), thanks to Theorem ")#link(<tao-8417fa7a92ccdb99fecb>)[#text("2")]#text(". On the other hand, if ")#mi("{f(x)}")#text(" is non-zero, then exactly one of ")#mi("{f(x)}")#text(" and ")#mi("{af(x)}")#text(" is a quadratic residue, and so for all but a bounded number of ")#mi("{x}")#text(", there are exactly two values of ")#mi("{y}")#text(" with ")#mi("{(x,y) \\in C^{\\prime}}")#text(", and so ")#tao-math("{\\left|C^{\\prime}({\\bf F}_q)\\right| = 2q + O(1)}", block: false)#text(". One can then subtract the upper bound for one of the components from this estimate to obtain a matching lower bound for the other component, and in particular ")#tao-math("{\\left|C({\\bf F}_q)\\right| \\geq q - O(\\sqrt{q})}", block: false)#text(".")

#text("In general we can proceed as follows. Let ")#mi("{d}")#text(" be the degree of ")#mi("{C}")#text(", so ")#mi("{d=O(1)}")#text(". After deleting ")#mi("{O(1)}")#text(" points from ")#mi("{C}")#text(", we can view ")#mi("{C}")#text(" as a degree ")#mi("{d}")#text(" cover of the affine line ")#mi("{{\\bf A}^1}")#text(" with ")#mi("{O(1)}")#text(" many points removed, with projection map ")#mi("{\\pi: C \\rightarrow {\\bf A}^1}")#text(". Once we do so, we can pass to the lifted curve ")#mi("{\\tilde C := \\bigwedge^d C}")#text(", defined as the collection of distinct ")#mi("{d}")#text("-tuples ")#mi("{y_1,\\dots,y_d}")#text(" in ")#mi("{C}")#text(" that lie over the same point in ")#mi("{{\\bf A}^1}")#text(", thus ")#mi("{\\pi(y_1)=\\dots=\\pi(y_d)}")#text(". This is a degree ")#mi("{d!}")#text(" cover of (most of) ")#mi("{{\\bf A}^1}")#text(", and is defined over ")#mi("{{\\bf F}_q}")#text(". It also carries a free action of the permutation group ")#mi("{S_d}")#text(": if ")#mi("{\\sigma \\in S_d}")#text(", we define")

#align(center)[#tao-fit-display[#mitex("\\sigma(y_1,\\dots,y_d) := (y_{\\sigma^{-1}(1)},\\dots,y_{\\sigma^{-1}(d)})")]]

#text("(the inverse is there to make the action a left action; one could also work with right actions instead if desired).")

#text("The curve ")#mi("{\\tilde C}")#text(" need not be absolutely irreducible, so we break it into absolutely irreducible components. The permutation group ")#mi("{S_d}")#text(" acts transitively on these components, so if we pick one of these components, say ")#mi("{\\tilde C_0}")#text(", and let ")#mi("{H := \\{ \\sigma \\in S_d: \\sigma \\tilde C_0 = \\tilde C_0 \\}}")#text(" be the stabiliser, then ")#mi("{H}")#text(" is a subgroup of ")#mi("{S_d}")#text(" (in particular, ")#mi("{H=O(1)}")#text("), and one can index the components of ")#mi("{\\tilde C_0}")#text(" as ")#mi("{\\sigma \\tilde C_0}")#text(", as ")#mi("{\\sigma}")#text(" ranges over a set of coset representatives of ")#mi("{S_d/H}")#text(". Each fibre of ")#mi("{\\tilde C_0}")#text(" over a generic point of the base ")#mi("{{\\bf A}^1}")#text(" is an orbit of ")#mi("{H}")#text("; since the map ")#mi("{(y_1,\\dots,y_d) \\rightarrow y_1}")#text(" projects ")#mi("{\\tilde C_0}")#text(" to the connected curve ")#mi("{C}")#text(", we conclude that the projection of this orbit must have cardinality ")#mi("{d}")#text(". In other words, the permutation group ")#mi("{H}")#text(" is a transitive group.")

#text("Even though ")#mi("{\\tilde C}")#text(" is defined over ")#mi("{{\\bf F}_q}")#text(", the individual components ")#mi("{\\sigma \\tilde C_0}")#text(" of ")#mi("{\\tilde C}")#text(" need not be. In particular, the Frobenius image ")#mi("{\\text{Frob}_q \\tilde C_0}")#text(" of ")#mi("{\\tilde C_0}")#text(" might be another component of ")#mi("{\\tilde C_0}")#text(", say ")#mi("{\\rho_q \\tilde C_0}")#text(".")

#text("Now let ")#mi("{x}")#text(" be a generic point of ")#mi("{{\\bf A}^1}")#text(" defined over ")#mi("{{\\bf F}_q}")#text(", then the fibre of ")#mi("{\\tilde C_0}")#text(" above ")#mi("{x}")#text(" is a free ")#mi("{H}")#text("-orbit and thus has cardinality ")#tao-math("{\\left|H\\right|}", block: false)#text(" orbit. Let ")#mi("{y}")#text(" be a point in this fibre. Applying Frobenius, we see that ")#mi("{\\text{Frob}_q(y)}")#text(" lies in the fibre of ")#mi("{\\rho_q \\tilde C_0}")#text(" above ")#mi("{x}")#text(", and hence ")#metadata(none) <tao-bf417c88aae840d98e4d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\text{Frob}_q(y) = \\rho_q \\sigma y")]]



#text(" for a unique ")#mi("{\\sigma \\in H}")#text(". Of course, if ")#mi("{y \\in \\tilde C_0}")#text(" does not lie over a point ")#mi("{x}")#text(" defined over ")#mi("{{\\bf F}_q}")#text(", then the equation ")#link(<tao-bf417c88aae840d98e4d>)[#text("(13)")]#text(" cannot hold. Since there are ")#mi("{q-O(1)}")#text(" points in ")#mi("{{\\bf A}^1}")#text(" with ")#mi("{O(1)}")#text(" points removed that are defined over ")#mi("{{\\bf F}_q}")#text(", and each of these give rise to ")#tao-math("{\\left|H\\right|}", block: false)#text(" points in ")#mi("{\\tilde C_0}")#text(", we conclude that ")#metadata(none) <tao-95474ef85f37ce52c279>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\sum_{\\sigma \\in H} \\left| \\{ y \\in \\tilde C_0: \\text{Frob}_q(y) = \\rho_q \\sigma y \\} \\right| = q \\left|H\\right| - O(1).", block: true)]]



#text(" On the other hand, a modification of Theorem ")#link(<tao-8417fa7a92ccdb99fecb>)[#text("2")]#text(" shows the upper bound ")#metadata(none) <tao-317e502f36a1dcbc03d7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left| \\{ y \\in \\tilde C_0: \\text{Frob}_q(y) = \\rho_q \\sigma y \\} \\right| \\leq q + O(\\sqrt{q})", block: true)]]



#text(" for each ")#mi("{\\sigma \\in H}")#text(". Strictly speaking, Theorem ")#link(<tao-8417fa7a92ccdb99fecb>)[#text("2")]#text(" is only directly applicable in the case when ")#mi("{\\rho_q \\sigma}")#text(" is the identity. However, even when ")#mi("{\\rho_q \\sigma}")#text(" is not the identity, one can “twist” the proof of Theorem ")#link(<tao-8417fa7a92ccdb99fecb>)[#text("2")]#text(" to establish the above estimate, basically by replacing the curve ")#mi("{C_1}")#text(" in ")#link(<tao-668b2c3d9d9558acbae9>)[#text("(2)")]#text(" by a twisted variant")

#align(center)[#tao-fit-display[#mitex("C^{\\prime}_1 := \\{ (\\rho_q \\sigma z, \\text{Frob}_{\\sqrt{q}}(z)): z \\in C \\}")]]

#text("which is still isomorphic to ")#mi("{C_1}")#text("; we leave the details to the interested reader. If we subtract ")#tao-math("{\\left|H\\right|-1}", block: false)#text(" instances of ")#link(<tao-317e502f36a1dcbc03d7>)[#text("(15)")]#text(" from ")#link(<tao-95474ef85f37ce52c279>)[#text("(14)")]#text(", we obtain that")

#align(center)[#tao-fit-display[#tao-math("\\left| \\{ y \\in \\tilde C_0: \\text{Frob}_q(y) = \\rho_q \\sigma y \\} \\right| \\geq q - O(\\sqrt{q})", block: true)]]

#text("for each ")#mi("{\\sigma \\in H}")#text(", which on combining with ")#link(<tao-317e502f36a1dcbc03d7>)[#text("(15)")]#text(" gives")

#align(center)[#tao-fit-display[#tao-math("\\left| \\{ y \\in \\tilde C_0: \\text{Frob}_q(y) = \\rho_q \\sigma y \\} \\right| = q + O(\\sqrt{q})", block: true)]]

#text("for each ")#mi("{\\sigma \\in H}")#text(".")

#text("Next, as ")#mi("{H}")#text(" acts transtively on ")#mi("{\\{1,\\dots,d\\}}")#text(", we see that there are ")#tao-math("{\\left|H\\right|/d}", block: false)#text(" values of ")#mi("{\\sigma}")#text(" such that ")#mi("{\\rho_q \\sigma(1) = 1}")#text(". We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left| \\{ (y_1,\\dots,y_d) \\in \\tilde C_0: \\text{Frob}_q(y_1) = y_1 \\} \\right| = \\frac{\\left|H\\right|}{d} q + O(\\sqrt{q}).", block: true)]]

#text("But as ")#mi("{C}")#text(" has degree ")#mi("{d}")#text(" above ")#mi("{{\\bf A}^1}")#text(", and ")#mi("{\\tilde C_0}")#text(" has degree ")#tao-math("{\\left|H\\right|}", block: false)#text(", we see that for generic ")#mi("{y_1}")#text(" there are exactly ")#tao-math("{\\left|H\\right|/d}", block: false)#text(" points ")#mi("{(y_1,\\dots,y_d)}")#text(" in ")#mi("{\\tilde C_0}")#text(" that lie above ")#mi("{y_1}")#text(". We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left| \\{ y_1 \\in C: \\text{Frob}_q(y_1) = y_1 \\} \\right| = q + O(\\sqrt{q}),", block: true)]]

#text("and the claim follows. ")#mi("\\Box")

#text("Finally, if one uses the trace formula ")#link(<tao-eafe895eb8119e6e5d06>)[#text("(1)")]#text(", then Theorem ")#link(<tao-2d24c9d4a6b65772ca58>)[#text("5")]#text(" implies the bounds ")#metadata(none) <tao-6b905c825ebff86a4a06>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left|\\alpha_i\\right| \\leq \\sqrt{p}", block: true)]]



#text(" for all ")#mi("{i=1,\\dots,2g}")#text(", and hence Theorem ")#link(<tao-db111a357721818c6bc3>)[#text("1")]#text(". Indeed, if we let ")#mi("{\\alpha_i}")#text(" be of maximal magnitude, thus ")#tao-math("{\\left|\\alpha_i\\right| \\geq \\left|\\alpha_j\\right|}", block: false)#text(" for all ")#mi("{j=1,\\dots,2g}")#text(", and an easy application of the ")#link("http://en.wikipedia.org/wiki/Dirichlet's_approximation_theorem")[#text("Dirichlet approximation theorem")]#text(" then shows that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{j=1}^{2g} \\alpha_j^n\\right| \\geq \\left|\\alpha_i\\right|^n", block: true)]]

#text("for infinitely many even ")#mi("{n}")#text(", which when combined with Theorem ")#link(<tao-2d24c9d4a6b65772ca58>)[#text("5")]#text(" implies that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\alpha_i\\right|^n = O( p^{n/2} )", block: true)]]

#text("for infinitely many even ")#mi("{n}")#text(". Taking ")#mi("{n^{th}}")#text(" roots and then sending ")#mi("{n}")#text(" to infinity (cf. the “")#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/")[#text("tensor power trick")]#text("“) we obtain ")#link(<tao-6b905c825ebff86a4a06>)[#text("(16)")]#text(" as required.")

#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3733a801797823657dfa0253bac48e89caa162c77c32917cad05d2bd4554505a-bf493af84157d5439e36ca78781005a6acda7dfacc3a20d09da73962fc6e9279.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Che!")]], [#link("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/#comment-321579")[#strong[#text("Che!")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2014")])]

#text("I think you have typo “elliptic curves have genus 1”")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/#comment-331384")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2014")])]

#text("I still see “elliptic curves have genus 1” in the text. Why is it a typo?")

#emph[#text("[This is the corrected form of the text; previously I had written “elliptic curves had genus ")#mi("g")#text("“. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c8aeceacf7496f4f04e0d12785336f86421e2127d1cc1dd0397d327f56c691a-b979a3525b3136d36f3632dc95da5463f578049c32cdcd4780b74e6f8a41026d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew S")]], [#link("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/#comment-321588")[#strong[#text("Andrew S")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2014")])]

#text("I think there is a small typo near the beginning. Is the number of rational points ")#mi("C[\\mathbb F_q]")#text(" or ")#mi("C[\\mathbb F_q]|")#text(" or ")#tao-math("\\left|C(\\mathbb F_q)\\right|", block: false)#text("? A nice post, nonetheless. Though, if you think the definition ")#mi("g = H^1(\\mathcal O_C)")#text(" is wrong, then I wonder what you must think of the definition via the Hilbert polynomial!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/#comment-321904")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2014")])]

#text("There’s an arrow missing in the second version of the long exact sequence in cohomology (after the k). Also, I think “non-reducible” was supposed to be “non-irreducible”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/#comment-321910")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2014")])]

#text("Also, in the formula after (16) you use i both as a bound and as a free variable, with the value of the free instance fixed by the previous sentence.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian Mingus")]], [#link("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/#comment-322639")[#strong[#text("Brian Mingus")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2014")])]

#text("It would be awesome if you could include a note indicating why a particular proof is interesting and important or what about it is novel for those of us more lay readers who still enjoy following your technical blog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/079deae0ec034960e02957e2200c28798219de41c022abcc50f2fc0b9edf36b5-2c2d02eda54aebd87e0c7dc9833200eb8bf7c492d48d57c22e473f023613a2c0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of O Ahmadi")]], [#link("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/#comment-340185")[#strong[#text("O Ahmadi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2014")])]

#text("There is a typo in the formula for the elliptic discriminant. The coefficient of b^2 should be 27.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd07dcea576c58f5ba8e26f5f8e1708a83f3310d14f777048c780246eaf4e033-60a38ffe34f6cd85111cf5c8281639cee7688a72a1427b77a339480f4513d484.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Angel Fernandez")]], [#link("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/#comment-387068")[#strong[#text("Angel Fernandez")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2014")])]

#text("It is true the projection in some of the elliptic curves are integers. He has demonstrated the mathematical Enfer Diez; by an equation, we can deternine whether there is an elliptical curve.")

#text("See in: Universal Journal of Computational Mathematics Vol 1 (1);2013")

#text("Title: Equation for solve elliptical curves.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/#comment-458141")[#strong[#text("משפט הסה בהסתברות גבוהה (מיני-פוסט) | One and One")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2015")]

#text("[…] עם תכונות התאפסות מסויימות, ואפשר לקרוא עליה כאן או כאן. למעשה, ההוכחה שלו לא הייתה חזקה מספיק כדי לתת את הקבוע […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A function field analogue of Riemann zeta statistics | What's new")]], [#link("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/#comment-516398")[#strong[#text("A function field analogue of Riemann zeta statistics | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2019")])]

#text("[…] can in turn be established by elementary methods such as Stepanov’s method, as discussed in this previous post). The non-squarefree case is more complicated (and can be established using the machinery of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32065b81c16f187944d8c30e760cd8d517709c8ac8b7fd61fc96b9e15e310ac3-26bbdb9819ad9c35bc05f817557b45172536330a2f6cd94c8a4ec0de03846620.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Recent Progress on a Problem of Sárközy | George Shakan")]], [#link("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/#comment-516746")[#strong[#text("Recent Progress on a Problem of Sárközy | George Shakan")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2019")])]

#text("[…] now proceed to the proof of Theorem 1, which adopts the Stepanov method of auxiliary […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/#comment-642913")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2022")])]

#text("Legend!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/#comment-682367")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2023")])]

#text("Hello,")

#text("There are two details of this proof I don’t quite follow:")

#text("1. Does Frob_sqrt{q} preserve C? If so, why?")

#text("Possible counter-example: If q = 25 and C is the elliptic curve y^{2} = x^{3} + aX where a is an element of order 24 in the finite field F_{25}, the point [1:(1+a)^{1/2}:1] is mapped to [1:(1+a)^{5/2}:1], which does not appear to satisfy the original curve?")

#text("2. I think Equation 11 is too strong of an inequality for the choice of l and m following Proposition 4:")

#text("Possible counter-example: If q = 25 and g = 1, then l = 4 and m = 7, and both sides of Equation 11 are equal to 28.")

#text("Note that Equation 11 can be weakened to fix this problem: As in Bombieri’s original proof, as long as l and m are at least g, m + l(sqrt(q)) is at least 2g. By Riemann-Roch, the dimension of R_{m+l(sqrt(q))} is then equal to m + l(sqrt(q))+1-g.")

#text("Thank you for your assistance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/#comment-682378")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2023")])]

#text("Thanks for the corrections. For issue 1, the intent was to assume that ")#mi("C")#text(" was in fact defined over ")#mi("{\\bf F}_{\\sqrt{q}}")#text(" and not just ")#mi("{\\bf F}_q")#text(". For issue 2, I guess my intended simplification of just using Riemann’s inequality instead of Riemann-Roch does not quite work. The simplest thing to do is indeed just to point back to Bombieri’s original paper for a full treatment.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/#comment-682380")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2023")])]

#text("That makes sense, and considering curves defined over F_sqrt(q) at first is sufficient to prove the Hasse-Weil bound because Theorem 5 concerns the asymptotic behavior of the number of points on the curve, so there is no harm in making a finite base field extension. Thank you.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/#comment-685555")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2024")])]

#text("Could you elaborate on the “easy application of Dirichlet’s theorem”? All the sources for this proof suggest it is obvious but I can’t for the life of me figure it out.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/#comment-685581")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2024")])]

#text("Write ")#mi("\\alpha_j")#text(" in polar coordinates as ")#mi("\\alpha_j = r_j e^{2\\pi \\theta_j}")#text(", thus ")#mi("\\alpha_j^n = r_j^n e^{2\\pi i n \\theta_j}")#text(". Then use the (simultaneous version of the) Dirichlet approximation theorem to find ")#mi("n")#text(" for which all of the ")#mi("n \\theta_j")#text(" are close to an integer.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/#comment-685585")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2024")])]

#text("I see! Thanks prof., I was going insane trying to see what to apply the theorem to.")
]
]
]
