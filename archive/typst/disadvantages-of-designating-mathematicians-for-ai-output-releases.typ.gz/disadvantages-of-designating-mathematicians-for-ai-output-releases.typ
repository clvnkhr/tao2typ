// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/
// Converted to Typst by tao2typ: "2026-10-26T13:22:16.648442+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Disadvantages of Designating Mathematicians for AI Output Releases", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Disadvantages of Designating Mathematicians for AI Output Releases")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/")[#text("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-26 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by the ")#link("https://agmai.org/")[#text("Advisory Group on Mathematics and Artificial Intelligence")]#text(", crossposted from their site. This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("In our ")#link("https://agmai.org/general-sep29/")[#text("September 29 recommendations")]#text(", we outlined an approach to the release of AI-generated mathematical output by AI labs. Since then, we have been asked by people from multiple labs and by several mathematicians about a specific aspect of the recommendations — that the development of human understanding following a release must remain organic and community led — and what it says about the question of the labs choosing specific mathematicians to participate in various ways in the release of their output. The purpose of this document is to clarify this point and to explain the reasoning behind our position on it. We welcome further feedback from the community and engagement with these arguments.")

#text("In some past releases an AI company has designated mathematicians to receive the output on a problem, often before anyone else. Those mathematicians then worked to uncover the ideas in the output, check them, develop them, and present them to the wider community. The appeal of this release model is easy to see: it puts expert eyes on the output early, can lead to a better initial public writeup, and gives each result a knowledgeable point of contact.")

#text("After consideration of many negative effects that this release plan has, however, we have come to the conclusion that on balance the disadvantages outweigh the advantages. This should in no way be construed as criticism of the mathematicians who have taken on such a role: they have acted in good faith and done valuable work. Nonetheless, we recommend that AI companies do not adopt this practice for future releases, for the reasons below.")

#strong[#text("Delayed or unequal access.")]#text(" In cases where designated mathematicians see material before everyone else, they get a head start on problems others may have worked on for years. Other mathematicians may have valuable contributions to make based on the material but may not have access to it, and may be dissuaded from working on it.")

#text("The remaining reasons apply even if all the material is released publicly at once.")

#strong[#text("Denied agency.")]#text(" The choice of who works to understand, check, and write up an important AI-generated result is consequential, both for those chosen and for the field, especially in the current period of transition when norms around credit for mathematical activities are in flux. If an AI company designates a particular mathematician to undertake or lead this task, it is to an extent making this decision for the community and denying it agency over its field of study. Further, this choice may discourage other mathematicians from contributing to the understanding of the results.")

#strong[#text("Biased selection.")]#text(" Any choice of designated mathematicians by the AI companies reflects their networks and priorities, which are different from those of the mathematical community. However carefully the choice is made, it is opaque and unaccountable. Moreover, this practice could incentivize mathematicians to align with whatever they perceive the AI companies’ priorities to be.")

#strong[#text("Borrowed reputation.")]#text(" In practice, designated mathematicians’ names end up vouching for the release and shielding the AI company from criticism. Given the wide range of views on the release of results by companies in the mathematical community, that puts the designated mathematicians in a difficult position that could compromise their role of helping with understanding.")

#strong[#text("It is unnecessary.")]#text(" Recent experience has shown that human understanding can develop organically and efficiently when AI-generated material is made available. In many cases recently, mathematicians have independently read released AI output, worked to understand it, and written useful papers providing clear arguments that solve the problems. We are also aware of several reading groups, workshops and websites being organized to understand other AI-generated output, and there are new funding opportunities for such activities.")

#strong[#text("What we recommend instead")]

#text("We recommend that any lab releasing AI-generated mathematical output should follow either pathway 2A of our recommendations (for scholarly articles produced by AI lab employees, adhering to standards set by the mathematical community) or pathway 2B (for unfinished products that the employees do not intend to write up as scholarly articles). A brief summary of pathway 2B is:")

#enum(start: 1, 
[#text("AI labs should make a serious good faith effort to improve citations and exposition, including scouring the literature for any ideas that should be cited.")],
[#text("Products should be posted on scholarly repositories that are not controlled by the posting AI lab, have citable identifiers, and record modifications.")],
[#text("Products should be accompanied by information about the process that produced them: the name of the model, prompts, chains of thought, number of attempts, compute used, and costs.")],
[#text("Proofs should be Lean-formalized where possible, unless it leads to unacceptable delays. Formalization artifacts should meet several community standards.")],
[#text("AI labs should state how the problems were chosen and how many problems were attempted.")],
[#text("AI companies should provide support, including funding, for the development of human understanding of the released products through academic workshops, working groups, and other activities. Decisions about which particular efforts are supported should be taken neither by AGMAI nor by AI companies, but by separate, independent nonprofit institutions.")]
)

#text("Full details of our recommendations are provided in our ")#link("https://agmai.org/general-sep29/")[#text("September 29 recommendations")]#text(". We recall that our recommendations are intended for mathematics, and not necessarily for other areas of science.")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5aa8a8b38c6132e360e84bc81a6cd793772627202503b77d6ca5bb2bd605c93-1fc5a6105cb29de1383d400fbb0efca3bfabdc0ae64d4d82e79fbb225cb808f9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shannon7774")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698778")[#strong[#text("shannon7774")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("For point 1, I think the citations should be done “properly.” In an OpenAI paper I read, all citations came from an introductory section summarizing the known results. But in the body of the paper they did not cite ideas where they were used. I think that method of citation is improper. Moreover, I think AI could fix this automatically, with some prompting.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698785")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("For us, doing this is not so easy, but for them it’s easier because they have the chain of thought.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3a67e42ee6dddacfe12657ab6801ed29cd7965344c6646279b187c7b76fefcd-cebbe0226281f777dfd322b06ca6de71b1485abcc4c199db5f5e8d10bdec0816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698782")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("The arile is fine in general, and proposed pathway 2B in particular. But point 5 of that proposal does not make sense. Would you accept such a request to a human mathematician?")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("AI labs should state ")#strong[#text("how the problems were chosen")]#text(" and how many problems were attempted.")
]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698788")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("I think that’s not the right analogy. If the human mathematician could easily clone himself thousands of times and work together on problems, it would be reasonable for him to report what percentage of open problems him and his clones could not solve.")

#text("OAI does have a very strong incentive to only discuss their successes and not their failures. So unfortunately this may not be realistic. But it would be nice, since we would get an accurate assessment of AI capabilities and we would know which problems are out of the reach of the latest AI model.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698793")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("I agree. It’s an odd request. The rest seem fine, but this one seems quite intrusive and onerous.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cad39830180b36030c39fee1b0b435df2dfa88b2a78f8637853142eeb26949c7-48f8c90388b1977ec27408ae090dd8360db7a65a8d874d8b3699b1dc03098653.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Observer")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698783")[#strong[#text("Observer")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("Can we reiterate that AI companies should not be trying to solve open math problems at all?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ece0f22696b73b3dabc4f59b892919d0e26a135ebe32ea87c0b7296a443d2ee0-1366977166783e28b4b8a26b1576b76f4f2888019ce22147df7e77749f17c6b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lemon")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698786")[#strong[#text("Lemon")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("Dear AGMAI!")

#text("On October 6 2026, we all witnessed firsthand the magnificent efficiency of your good and carefully constructed advices! We all express the deepest gratitude to you for your tireless guidance of AI-megacorporations on how exactly they should grant us crumbs of shining wisdom of their frontier closed models! We all see the deepest respect that said corporations pay to your work!")

#text("Don’t stop!")
]
