// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/
// Converted to Typst by tao2typ: "2026-10-28T13:17:06.411056+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Disadvantages of Designating Mathematicians for AI Output Releases", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Disadvantages of Designating Mathematicians for AI Output Releases")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/")[#text("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-28 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by the ")#link("https://agmai.org/")[#text("Advisory Group on Mathematics and Artificial Intelligence")]#text(", crossposted from their site. This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("In our ")#link("https://agmai.org/general-sep29/")[#text("September 29 recommendations")]#text(", we outlined an approach to the release of AI-generated mathematical output by AI labs. Since then, we have been asked by people from multiple labs and by several mathematicians about a specific aspect of the recommendations — that the development of human understanding following a release must remain organic and community led — and what it says about the question of the labs choosing specific mathematicians to participate in various ways in the release of their output. The purpose of this document is to clarify this point and to explain the reasoning behind our position on it. We welcome further feedback from the community and engagement with these arguments.")

#text("In some past releases an AI company has designated mathematicians to receive the output on a problem, often before anyone else. Those mathematicians then worked to uncover the ideas in the output, check them, develop them, and present them to the wider community. The appeal of this release model is easy to see: it puts expert eyes on the output early, can lead to a better initial public writeup, and gives each result a knowledgeable point of contact.")

#text("After consideration of many negative effects that this release plan has, however, we have come to the conclusion that on balance the disadvantages outweigh the advantages. This should in no way be construed as criticism of the mathematicians who have taken on such a role: they have acted in good faith and done valuable work. Nonetheless, we recommend that AI companies do not adopt this practice for future releases, for the reasons below.")

#strong[#text("Delayed or unequal access.")]#text(" In cases where designated mathematicians see material before everyone else, they get a head start on problems others may have worked on for years. Other mathematicians may have valuable contributions to make based on the material but may not have access to it, and may be dissuaded from working on it.")

#text("The remaining reasons apply even if all the material is released publicly at once.")

#strong[#text("Denied agency.")]#text(" The choice of who works to understand, check, and write up an important AI-generated result is consequential, both for those chosen and for the field, especially in the current period of transition when norms around credit for mathematical activities are in flux. If an AI company designates a particular mathematician to undertake or lead this task, it is to an extent making this decision for the community and denying it agency over its field of study. Further, this choice may discourage other mathematicians from contributing to the understanding of the results.")

#strong[#text("Biased selection.")]#text(" Any choice of designated mathematicians by the AI companies reflects their networks and priorities, which are different from those of the mathematical community. However carefully the choice is made, it is opaque and unaccountable. Moreover, this practice could incentivize mathematicians to align with whatever they perceive the AI companies’ priorities to be.")

#strong[#text("Borrowed reputation.")]#text(" In practice, designated mathematicians’ names end up vouching for the release and shielding the AI company from criticism. Given the wide range of views on the release of results by companies in the mathematical community, that puts the designated mathematicians in a difficult position that could compromise their role of helping with understanding.")

#strong[#text("It is unnecessary.")]#text(" Recent experience has shown that human understanding can develop organically and efficiently when AI-generated material is made available. In many cases recently, mathematicians have independently read released AI output, worked to understand it, and written useful papers providing clear arguments that solve the problems. We are also aware of several reading groups, workshops and websites being organized to understand other AI-generated output, and there are new funding opportunities for such activities.")

#strong[#text("What we recommend instead")]

#text("We recommend that any lab releasing AI-generated mathematical output should follow either pathway 2A of our recommendations (for scholarly articles produced by AI lab employees, adhering to standards set by the mathematical community) or pathway 2B (for unfinished products that the employees do not intend to write up as scholarly articles). A brief summary of pathway 2B is:")

#enum(start: 1, 
[#text("AI labs should make a serious good faith effort to improve citations and exposition, including scouring the literature for any ideas that should be cited.")],
[#text("Products should be posted on scholarly repositories that are not controlled by the posting AI lab, have citable identifiers, and record modifications.")],
[#text("Products should be accompanied by information about the process that produced them: the name of the model, prompts, chains of thought, number of attempts, compute used, and costs.")],
[#text("Proofs should be Lean-formalized where possible, unless it leads to unacceptable delays. Formalization artifacts should meet several community standards.")],
[#text("AI labs should state how the problems were chosen and how many problems were attempted.")],
[#text("AI companies should provide support, including funding, for the development of human understanding of the released products through academic workshops, working groups, and other activities. Decisions about which particular efforts are supported should be taken neither by AGMAI nor by AI companies, but by separate, independent nonprofit institutions.")]
)

#text("Full details of our recommendations are provided in our ")#link("https://agmai.org/general-sep29/")[#text("September 29 recommendations")]#text(". We recall that our recommendations are intended for mathematics, and not necessarily for other areas of science.")

#heading(level: 1)[#text("Comments (26)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5aa8a8b38c6132e360e84bc81a6cd793772627202503b77d6ca5bb2bd605c93-1fc5a6105cb29de1383d400fbb0efca3bfabdc0ae64d4d82e79fbb225cb808f9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shannon7774")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698778")[#strong[#text("shannon7774")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("For point 1, I think the citations should be done “properly.” In an OpenAI paper I read, all citations came from an introductory section summarizing the known results. But in the body of the paper they did not cite ideas where they were used. I think that method of citation is improper. Moreover, I think AI could fix this automatically, with some prompting.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698785")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("For us, doing this is not so easy, but for them it’s easier because they have the chain of thought.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698796")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("I saw this in the 10th discriminant challenge. When I told the model to “attribute all provenance” it inserted a stream-of-consciousness paragraph at the start of the paper with all attributions, with nothing in the body of the paper. But all I had to do was tell it to cite prior art where it was used and it did fine.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3a67e42ee6dddacfe12657ab6801ed29cd7965344c6646279b187c7b76fefcd-cebbe0226281f777dfd322b06ca6de71b1485abcc4c199db5f5e8d10bdec0816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698782")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("The arile is fine in general, and proposed pathway 2B in particular. But point 5 of that proposal does not make sense. Would you accept such a request to a human mathematician?")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("AI labs should state ")#strong[#text("how the problems were chosen")]#text(" and how many problems were attempted.")
]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698788")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("I think that’s not the right analogy. If the human mathematician could easily clone himself thousands of times and work together on problems, it would be reasonable for him to report what percentage of open problems him and his clones could not solve.")

#text("OAI does have a very strong incentive to only discuss their successes and not their failures. So unfortunately this may not be realistic. But it would be nice, since we would get an accurate assessment of AI capabilities and we would know which problems are out of the reach of the latest AI model.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698793")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("I agree. It’s an odd request. The rest seem fine, but this one seems quite intrusive and onerous.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698804")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("Machines and corporations do not deserve the same rights as humans.")

#text("This mistake has already been made in copyright law, because no one foresaw AI when it was written. Humans learning from texts is fair use, machines learning from text is not.")

#text("Humans breathing is obviously a natural right, coal power plants are increasingly restricted. Fair use law needs to be rewritten.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b7b3926b86891cd8fedf7356c5670a2085f0c301511360deb7eaae9c13e3adf-339354f41f3a9dec6adc3e2b49e3163e5e3e83c3605a89451fd3c1823b3f1267.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of just different")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698811")[#strong[#text("just different")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("Human mathematicians often ")#emph[#text("do")]#text(" state where a problem came from. I believe the point here is that AI companies always get problems the same way they get everything else: by trawling the internet. Human mathematicians who ")#emph[#text("don’t")]#text(" provide the source of a problem generally came up with it during their own research work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a989836e67e21e16c9aa2ce6a7cc124d741c8cbe532f05ef59774758538bc11-21fdbc77968d114cd99bae5f0dbfe9a8b0bec978f168d319534919800b817661.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin Russell")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698831")[#strong[#text("Kevin Russell")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("On point 5, I’d come down on the side of keeping it. Without a denominator, a list of successes is a highlight reel, not a capability claim. In our own small project, the hardest-won rule was “impressive is cheap, survived is expensive.” Our first apparent minimum-overlap win exploited a rescaling step the scorer did not check tightly enough. We refused to submit it. We kept that in the record because retracted or weakened claims are not buried; they become part of the method. A lab saying “we tried N problems, here’s how we picked them, and here’s what didn’t survive” costs it some shine, but it’s the only version a reader can calibrate against. Genuine question for old-bielefelder: is the objection to disclosure itself, or that “how many problems were attempted” is hard to define when one attempt branches into thousands of agent runs?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3a67e42ee6dddacfe12657ab6801ed29cd7965344c6646279b187c7b76fefcd-cebbe0226281f777dfd322b06ca6de71b1485abcc4c199db5f5e8d10bdec0816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698843")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Answer in 2 parts.")

#text("Part I: Assume, I were creative director in OpenAI and had to organize a research math working session. I would take 50 of our creative math employees and ask each of them to provide 20 interesting math papers with accompanying open problems.")

#text("These 1,000 problems I would feed into (1,000) agents and let them compute for 2 hours. The 1,000 outputs would be evaluated by a small group of additional AI agents, who split the problems in two groups of equal size: promising ones and less promising.")

#text("Then the 500 promising ones would be given to 500 or 1,000 agents with the task to make more progress. This shortlisting procedure would procede in several more rounds until finally 10 or 23 solutions were there. Those would be discussed (with the human employees again) over the question which of them to make public.")

#text("Having such a procedure in mind, “normal” answers to item “5” would not make much sense.")

#text("* * * * * * * *")

#text("Part II from my PhD project.")#linebreak()#text("The project started in August 1985. My advisor (Prof. Ahlswede) arranged an initial date and told me: “I might give you some topic for the PhD project. But I prefer to let you find the topic by yourself.” I was happy with this.")

#text("My overall goal was to make mathematics that might turn out to be helpful for “computer chess”. I knew some papers (Knuth & Moore 1975 ; Pearl; Nau) but not too many.")

#text("I tried several dozen ideas – only a few of them turned out to give interesting research. These became the base of my PhD thesis in late 1986.")

#text("I would NEVER have told someone about all my failed attempts. But also: nobody asked me, which was completely fine. Having this short phase in my math history in mind, I would find it absurd to have been asked or to ask my PhD students what all they tried.")

#text("Ingo Althöfer.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cad39830180b36030c39fee1b0b435df2dfa88b2a78f8637853142eeb26949c7-48f8c90388b1977ec27408ae090dd8360db7a65a8d874d8b3699b1dc03098653.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Observer")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698783")[#strong[#text("Observer")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("Can we reiterate that AI companies should not be trying to solve open math problems at all?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698802")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("Is this math cartel going to decide who can work on which problems from now on?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698806")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("They can do whatever they want, you do not have a patent on knowledge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0034ededecf4c8af3a0b27bb02c23241832b564237a5c06a1d2e01e8c05e579b-92345ce847ad29f2a22c82ec382f9f22dd3e4b24c78ff35fc93a69d970efb626.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698829")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("They shouldn’t be doing it. Of course, people who believe that like you or myself can’t stop them. But what we can do is cease to support the mathematics community for cooperating with AI or using AI. If you don’t agree with it, try and leave and not support the activity of math, which is no longer a human activity.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ece0f22696b73b3dabc4f59b892919d0e26a135ebe32ea87c0b7296a443d2ee0-1366977166783e28b4b8a26b1576b76f4f2888019ce22147df7e77749f17c6b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lemon")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698786")[#strong[#text("Lemon")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("Dear AGMAI!")

#text("On October 6 2026, we all witnessed firsthand the magnificent efficiency of your good and carefully constructed advices! We all express the deepest gratitude to you for your tireless guidance of AI-megacorporations on how exactly they should grant us crumbs of shining wisdom of their frontier closed models! We all see the deepest respect that said corporations pay to your work!")

#text("Don’t stop!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698795")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("AI labs should make a serious good faith effort to improve citations and exposition, including scouring the literature for any ideas that should be cited.")
]

#text("In my experience, this is as simple as telling the AI to do it. In my own research, I simply tell the models to scour the literature and attribute all the key ideas. It does a better job than I can do: I have uncovered under-cited prior art this way.")

#text("On the 10th discriminant challenge, it initially didn’t cite ideas from the comments. Once I told it to, and to put them in the place they’re used, it did so (it did quite well in my non-professional opinion).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c362f3735b211c22413bc8c3ad496aeba4d5f0261acab76e3f1522ab660816f3-1176ea5ca7062b5905272d590bbc6941a0f42c89c5d8f0843babd657e962b537.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel M Gessel")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698798")[#strong[#text("Daniel M Gessel")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("This reads like a list of demands (or a manifesto) but doesn’t give any downsides for companies failing to meet them. Are you prepared for action in the legal and political spheres? Have you reached out to potential allies, like the Union of Concerned Scientists or Stand Up For Science? The Authors Guild has joined some class action lawsuit with authors – scientists and Mathematicians may be welcomed.")

#text("We all know the world outside Mathematics is messy, and these days, it’s even messier than usual – but that’s where your battle has to be fought.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cb9da7b47cbc1465e0b09da0544196e13d96f0c56575d23836e70f75d7c7ea9-07fd7823e24366159ef7adf6492058c9a574d4b59dd935489112043bd5dc8fff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of darkomulej")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698815")[#strong[#text("darkomulej")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("The math community is swinging between two completely wild extremes right now.")

#text("On the human side, we still put up with a glacial, regulated 19th-century pipeline. You write a paper in LaTeX—doing all the publisher’s typesetting for them—submit it, and then wait 1 to 3 years while a couple of unpaid, overworked referees slowly dig through it. The big commercial publishers sit back, take all that free academic labor, lock the paper behind an outrageous paywall, and sell it back to our own universities. And the community just goes along with it, because ")#emph[#text("publish or perish")]#text(" forces young researchers to buy prestige from that ‘cartel’.")

#text("Then AI shows up, and the guild flips 180 degrees overnight. Suddenly, having designated referees is bad. Instead, we demand an instant, frictionless public dump of everything, complete with compute logs, prompts, and every failed attempt thrown in the wastebasket, standards we would laugh out of the room if someone demanded them from a human mathematician.")

#text("Why the sudden panic? Because the whole peer-review process only worked under (artificial) cognitive scarcity. It relied on proofs being rare enough for unpaid humans to check them. When a model can dump hundreds of candidate solutions over a weekend, the referee system collapses instantly. This isn’t just about vetting rigor anymore; it’s an effort by the academic establishment to stop tech labs from taking over the one thing journals actually controlled: the power to decide what gets accepted as legitimate mathematical truth.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1a9fe8710b4c27675deac31b21284211734b809e327bd74df596085a4badcc0-64e82a8f9e8359f7a05a2b62807a79f18e2052d757d62a8eec7cb749673d2697.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grigori Avramidi")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698818")[#strong[#text("Grigori Avramidi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("I think this is a good policy.")

#text("I’m also really surprised that a group of eminent mathematical physicists decided to keep an openai produced proof to themselves for now: ")#link("https://openai.com/index/building-scientific-understanding-with-academic-communities/")[#text("https://openai.com/index/building-scientific-understanding-with-academic-communities/")]

#text("If that happened in my part of math, I would be furious. Is the culture in math phys substantially different from other parts of pure math?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698828")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("As far as I know, it’s not math physics culture. This is absolutely outrageous in my view. I guarantee they’re sharing it with their inner circle. Do you think Witten hasn’t gotten a copy already?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1a9fe8710b4c27675deac31b21284211734b809e327bd74df596085a4badcc0-64e82a8f9e8359f7a05a2b62807a79f18e2052d757d62a8eec7cb749673d2697.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grigori Avramidi")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698856")[#strong[#text("Grigori Avramidi")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Witten appears to be one of the people asking them to release it in ")#link("https://agmai.org/")[#text("https://agmai.org/")]#text(", so maybe not? (I’m amused that the message is ”we ask openai to release the preprints”. It suggests that they’ve given up on just asking the group of math physicists to do it themselves.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cb9da7b47cbc1465e0b09da0544196e13d96f0c56575d23836e70f75d7c7ea9-07fd7823e24366159ef7adf6492058c9a574d4b59dd935489112043bd5dc8fff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of darkomulej")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698821")[#strong[#text("darkomulej")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("OpenAI ")#link("https://openai.com/index/building-scientific-understanding-with-academic-communities/")[#text("has just released")]#text(" three (monumental?) results across mathematics, computer science, and physics, utilizing three entirely different modes of relaying findings to the scientific community based on expert advice:")

#text("“We reached out to external experts and asked them to act as shepherds, organizing groups to understand the new results. They advised three different release strategies:")

#list(
[#text("For the math result, release the AI output, leaving researchers free to organize their own efforts to explain the result.")],
[#text("For the computer science result, form an external group of collaborators to explain the result, while making the AI output publicly available for anyone to examine and build on.")],
[#text("For the physics result, form an external group of collaborators and defer to them on the release of materials.")]
)

#text("We do not yet know which of these three approaches will be most useful, and we welcome feedback on what works and what we can improve.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/876f1434ccc2f20b748b59ae2694d76a5878ff6bb2aacb5716a8faf06c233cdf-905035f2bbd6068d125ae7506f5950121d3cf16661d0d1383a6fc964487b8354.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698824")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("Has anyone seen this?")#linebreak()#link("https://github.com/openai/math/blob/main/preprints/Local-smoothing-for-the-Euclidean-wave-equation-October-25-2026/paper.pdf")[#text("https://github.com/openai/math/blob/main/preprints/Local-smoothing-for-the-Euclidean-wave-equation-October-25-2026/paper.pdf")]#linebreak()#text("I’m not sure")#linebreak()#text("1. If it’s correct, as the method seems completely new")#linebreak()#text("2. If it is correct, how to process what it will do to harmonic analysis.")#linebreak()#text("Appreciate any thoughts…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698827")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("At least the mathematicians did the right thing today. The physicists, not so much.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3a67e42ee6dddacfe12657ab6801ed29cd7965344c6646279b187c7b76fefcd-cebbe0226281f777dfd322b06ca6de71b1485abcc4c199db5f5e8d10bdec0816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698832")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("When I look at the announcement of OpenAI from this night (three breakthrough results, including counter example to Exp Time Hypothesis) the company seems to be willing to improve their “publishing” behaviour. I think they are on a good way.")

#text("Ingo Althöfer alias old bielefelder")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/25/disadvantages-of-designating-mathematicians-for-ai-output-releases/comment-page-1/#comment-698869")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("OpenAI scooped Ethan Sussman and Levent Alpoge.")
]
