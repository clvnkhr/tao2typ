// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/
// Converted to Typst by tao2typ: "2026-10-14T16:35:27.151599+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "When are eigenvalues stable?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("When are eigenvalues stable?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 October 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/")[#text("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I was asked recently (in relation to my recent work with Van Vu on the spectral theory of random matrices) to explain some standard heuristics regarding how the eigenvalues ")#mi("\\lambda_1,\\ldots,\\lambda_n")#text(" of an ")#mi("n \\times n")#text(" matrix A behave under small perturbations. These heuristics can be summarised as follows:")

#enum(start: 1, 
[#text("For ")#link("http://en.wikipedia.org/wiki/Normal_matrix")[#text("normal matrices")]#text(" (and in particular, ")#link("http://en.wikipedia.org/wiki/Unitary_matrix")[#text("unitary")]#text(" or ")#link("http://en.wikipedia.org/wiki/Hermitian_matrix")[#text("self-adjoint")]#text(" matrices), eigenvalues are very stable under small perturbations. For more general matrices, eigenvalues can become unstable if there is ")#link("http://en.wikipedia.org/wiki/Pseudospectrum")[#text("pseudospectrum")]#text(" present.")],
[#text("For self-adjoint (Hermitian) matrices, eigenvalues that are too close together tend to repel quickly from each other under such perturbations. For more general matrices, eigenvalues can either be repelled or be attracted to each other, depending on the type of perturbation.")]
)

#text("In this post I would like to briefly explain why these heuristics are plausible.")

#metadata(none) <tao-498c4c0106c69298221e>

#heading(level: 1)[#text("— Pseudospectrum —")]

#text("As any student of linear algebra knows, the ")#link("http://en.wikipedia.org/wiki/Spectrum_of_an_operator")[#text("spectrum")]#text(" ")#mi("\\sigma(A)")#text(" of a ")#mi("n \\times n")#text(" matrix A consists of all the complex numbers ")#mi("\\lambda")#text(" such that ")#mi("A-\\lambda I")#text(" fails to be invertible, thus there exists a non-zero vector v such that ")#mi("(A-\\lambda I)v")#text(" is zero. This is a finite set, consisting of at most n points. But there is also an important set containing the spectrum (and which, at times, can be much larger than that spectrum), which is the ")#link("http://en.wikipedia.org/wiki/Pseudospectrum")[#emph[#text("pseudospectrum")]]#text(" of the matrix A. Unlike the spectrum, which is canonically defined, there is more than one definition of the pseudospectrum; also, this concept depends on an additional parameter, a small number ")#mi("\\varepsilon > 0")#text(". We will define the pseudospectrum (or more precisely, the ")#mi("\\varepsilon")#text("-pseudospectrum) ")#mi("\\sigma_\\varepsilon(A)")#text(" to be the set of all the complex numbers ")#mi("\\lambda")#text(" such that ")#mi("A-\\lambda I")#text(" has least singular value at most ")#mi("\\varepsilon")#text(", or equivalently that there exists a unit vector v such that ")#tao-math("\\left| (A-\\lambda I) v \\right| \\leq \\varepsilon", block: false)#text(". (Another equivalent definition is that the ")#mi("\\varepsilon")#text("-pseudospectrum consists of the spectrum, together with those complex numbers ")#mi("\\lambda")#text(" for which the ")#link("http://en.wikipedia.org/wiki/Resolvent_formalism")[#text("resolvent")]#text(" ")#mi("(A-\\lambda)^{-1}")#text(" has ")#link("http://en.wikipedia.org/wiki/Operator_norm")[#text("operator norm")]#text(" at least ")#mi("1/\\varepsilon")#text(".)")

#text("The significance of the pseudospectrum ")#mi("\\sigma_\\varepsilon(A)")#text(" is that ")#emph[#text("it describes where the spectrum ")#mi("\\sigma(A)")#text(" can go to under small perturbations")]#text(". Indeed, if ")#mi("\\lambda")#text(" lies in the pseudospectrum ")#mi("\\sigma_\\varepsilon(A)")#text(", so that there exists a unit vector v whose image ")#mi("w := (A-\\lambda I) v")#text(" has magnitude at most ")#mi("\\varepsilon")#text(", then we see that")

#align(center)[#tao-fit-display[#mitex("(A - w v^* - \\lambda I) v = (A-\\lambda I) v - w v^* v = w - w = 0")]]

#text("and so ")#mi("\\lambda")#text(" lies in the spectrum ")#mi("\\sigma(A-wv^*)")#text(" of the perturbation ")#mi("A-wv^*")#text(" of A. Note that the operator norm of ")#mi("wv^*")#text(" is at most ")#mi("\\varepsilon")#text(".")

#text("Conversely, if ")#mi("\\lambda")#text(" does ")#emph[#text("not ")]#text("lie in the pseudospectrum ")#mi("\\sigma_\\varepsilon(A)")#text(", and ")#mi("A+E")#text(" is a small perturbation of A (with E having operator norm at most ")#mi("\\varepsilon")#text("), then for any unit vector v, one has")

#align(center)[#tao-fit-display[#tao-math("\\left|(A+E - \\lambda I) v\\right| \\geq \\left|(A-\\lambda I)v\\right| - \\left|Ev\\right| > \\varepsilon - \\varepsilon = 0", block: true)]]

#text("by the triangle inequality, and so ")#mi("\\lambda")#text(" cannot lie in the spectrum of ")#mi("A+E")#text(".")

#text("Thus, if the pseudospectrum is tightly clustered around the spectrum, the spectrum is stable under small perturbations; but if the pseudospectrum is widely dispersed, then the spectrum becomes unstable.")

#text("No matter what A is, the pseudospectrum ")#mi("\\sigma_\\varepsilon(A)")#text(" always contains the ")#mi("\\varepsilon")#text("-neighbourhood of the spectrum ")#mi("\\sigma(A)")#text(". Indeed, if v is a unit eigenvector with eigenvalue ")#mi("\\lambda \\in \\sigma(A)")#text(", then ")#mi("(A-\\lambda I) v = 0")#text(", which implies that ")#tao-math("\\left|(A-\\lambda^{\\prime} I) v\\right| = \\left|\\lambda - \\lambda^{\\prime}\\right| \\leq \\varepsilon", block: false)#text(" for any ")#mi("\\lambda^{\\prime}")#text(" in the ")#mi("\\varepsilon")#text("-neighbourhood of ")#mi("\\lambda")#text(", and the claim follows.")

#text("Conversely, when A is normal, ")#mi("\\sigma_\\varepsilon(A)")#text(" consists ")#emph[#text("only")]#text(" of the ")#mi("\\varepsilon")#text("-neighbourhood of ")#mi("\\sigma(A)")#text(". This is easiest to see by using the ")#link("http://en.wikipedia.org/wiki/Spectral_theorem")[#text("spectral theorem")]#text(" to diagonalise A and then computing everything explicitly. In particular, we conclude that if we perturb a normal matrix by a (possibly non-normal) perturbation of operator norm at most ")#mi("\\varepsilon")#text(", then the spectrum moves by at most ")#mi("\\varepsilon")#text(".")

#text("In the non-normal case, things can be quite different. A good example is provided by the shift matrix")

#align(center)[#tao-fit-display[#mitex("U := \\begin{pmatrix} 0 & 1 & 0 & \\ldots & 0 \\\\ 0 & 0 & 1 & \\ldots & 0 \\\\ \\vdots & \\vdots & \\vdots & \\ddots & \\vdots \\\\ 0 & 0 & 0 & \\ldots & 1 \\\\ 0 & 0 & 0 & \\ldots & 0 \\end{pmatrix}.")]]

#text("This matrix is ")#link("http://en.wikipedia.org/wiki/Nilpotent_matrix")[#text("nilpotent")]#text(": ")#mi("U^n=0")#text(". As such, the only eigenvalue is zero. But observe that for any complex number ")#mi("\\lambda")#text(",")

#align(center)[#mi("\\displaystyle (U -\\lambda I) \\begin{pmatrix} 1 \\\\ \\lambda \\\\ \\ldots \\\\ \\lambda^{n-1} \\\\ \\lambda^n \\end{pmatrix} = \\begin{pmatrix} 0 \\\\ 0 \\\\ \\ldots \\\\ 0 \\\\ -\\lambda^{n+1} \\end{pmatrix}")#text(".")]

#text("From this and a little computation, we see that if ")#tao-math("\\left|\\lambda\\right| < 1", block: false)#text(", then ")#mi("\\lambda")#text(" will lie in the ")#tao-math("O( \\frac{\\left|\\lambda\\right|^{n+1}}{1-\\left|\\lambda\\right|} )", block: false)#text("-pseudospectrum of U. For fixed ")#mi("\\varepsilon")#text(", we thus see that ")#mi("\\sigma_\\varepsilon(U)")#text(" fills up the unit disk in the high dimensional limit ")#mi("n \\to \\infty")#text(". (The pseudospectrum will not venture far beyond the unit disk, as the operator norm of U is 1.) And indeed, it is easy to perturb U so that its spectrum moves far away from the origin. For instance, observe that the perturbation")

#align(center)[#tao-fit-display[#mitex("U + E := \\begin{pmatrix} 0 & 1 & 0 & \\ldots & 0 \\\\ 0 & 0 & 1 & \\ldots & 0 \\\\ \\vdots & \\vdots & \\vdots & \\ddots & \\vdots \\\\ 0 & 0 & 0 & \\ldots & 1 \\\\ \\varepsilon & 0 & 0 & \\ldots & 0 \\end{pmatrix}")]]

#text("of U has a ")#link("http://en.wikipedia.org/wiki/Characteristic_polynomial")[#text("characteristic polynomial")]#text(" of ")#mi("(-\\lambda)^n - (-1)^n \\varepsilon")#text(" (or note that ")#mi("(U+E)^n = \\varepsilon I")#text(", which is basically the same fact thanks to the ")#link("http://en.wikipedia.org/wiki/Cayley%E2%80%93Hamilton_theorem")[#text("Cayley-Hamilton theorem")]#text(") and so has eigenvalues equal to the ")#mi("n^{th}")#text(" roots of ")#mi("\\varepsilon")#text("; for fixed ")#mi("\\varepsilon")#text(" and n tending to infinity, this spectrum becomes asymptotically uniformly distributed on the unit circle, rather than at the origin.")

#text("[")#emph[#text("Update")]#text(", Nov 8: Much more on the theory of pseudospectra can be found at ")#link("http://www.comlab.ox.ac.uk/pseudospectra/")[#text("this web site")]#text("; thanks to Nick Trefethen for the link.]")

#heading(level: 1)[#text("— Spectral dynamics —")]

#text("The pseudospectrum tells us, roughly speaking, ")#emph[#text("how far")]#text(" the spectrum ")#mi("\\sigma(A)")#text(" of a matrix A can move with respect to a small perturbation, but does not tell us the ")#emph[#text("direction")]#text(" in which the spectrum moves. For this, it is convenient to use the language of calculus: we suppose that A=A(t) varies smoothly with respect to some time parameter t, and would like to “differentiate” the spectrum ")#mi("\\sigma(A)")#text(" with respect to t.")

#text("Since it is a little unclear what it means to differentiate a set, let us work instead with the eigenvalues ")#mi("\\lambda_j = \\lambda_j(t)")#text(" of ")#mi("A = A(t)")#text(". Note that generically (e.g. for almost all A), the eigenvalues will be distinct. (Proof: the eigenvalues are distinct when the characteristic polynomial has no repeated roots, or equivalently when the resultant of the characteristic polynomial with its derivative is non-zero. This is clearly a ")#link("http://en.wikipedia.org/wiki/Zariski_topology")[#text("Zariski")]#text("-open condition; since the condition is obeyed at least once, it is thus Zariski-dense.) So it is not unreasonable to assume that for all t in some open interval, the ")#mi("\\lambda_j(t)")#text(" are distinct; an application of the implicit function theorem then allows one to make the ")#mi("\\lambda_j(t)")#text(" smooth in t. Similarly, we can make the eigenvectors ")#mi("v_j = v_j(t)")#text(" vary smoothly in t. (There is some freedom to multiply each eigenvector by a scalar, but this freedom will cancel itself out in the end, as we are ultimately interested only in the eigenvalues rather than the eigenvectors.)")

#text("The eigenvectors ")#mi("v_1,\\ldots,v_n")#text(" form a basis of ")#mi("{\\Bbb C}^n")#text(". Let ")#mi("w_1,\\ldots,w_n")#text(" be the ")#link("http://en.wikipedia.org/wiki/Dual_basis")[#text("dual basis")]#text(", thus ")#mi("w_j^* v_k = \\delta_{jk}")#text(" for all ")#mi("1 \\leq j,k \\leq n")#text(", and so we have the reproducing formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("u = \\sum_{j=1}^n (w_j^* u) v_j")]]

#text("for all vectors u. Combining this with the eigenvector equations")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("A v_k = \\lambda_k v_k")]]

#text("we obtain the adjoint eigenvector equations")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("w_k^* A = \\lambda_k w_k^*.")]]

#text("Next, we differentiate (2) using the product rule to obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\dot A v_k + A \\dot v_k = \\dot \\lambda_k v_k + \\lambda_k \\dot v_k.")]]

#text("Taking the inner product of this with the dual vector ")#mi("w_k")#text(", and using (3) to cancel some terms, we obtain the ")#emph[#text("first variation formula")]#text(" for eigenvalues:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\dot \\lambda_k = w_k^* \\dot A v_k.")]]

#text("Note that if A is normal, then we can take the eigenbasis ")#mi("v_k")#text(" to be orthonormal, in which case the dual basis ")#mi("w_k")#text(" is identical to ")#mi("v_k")#text(". In particular we see that ")#tao-math("\\left|\\dot \\lambda_k\\right| \\leq \\left\\|\\dot A\\right\\|_{op}", block: false)#text("; the infinitesimal change of each eigenvalue does not exceed the infinitesimal size of the perturbation. This is consistent with the stability of the spectrum for normal operators mentioned in the previous section.")

#text("[Side remark: if A evolves by the ")#link("http://en.wikipedia.org/wiki/Lax_pair")[#text("Lax pair")]#text(" equation ")#mi("\\dot A = [A,P]")#text(" for some matrix ")#mi("P = P(t)")#text(", then ")#mi("w_k^* \\dot A v_k = w_k^* \\lambda P v_k - w_k^* P \\lambda v_k = 0")#text(", and so from (5) we see that the spectrum of A is invariant in time. This fact underpins the ")#link("http://en.wikipedia.org/wiki/Inverse_scattering_transform")[#text("inverse scattering method")]#text(" for solving ")#link("http://en.wikipedia.org/wiki/Integrable_system")[#text("integrable systems")]#text(".]")

#text("Now we look at how the eigen")#emph[#text("vectors")]#text(" vary. Taking the inner product instead with a dual vector ")#mi("w_j")#text(" for ")#mi("j \\neq k")#text(", we obtain")

#align(center)[#mi("w_j^* \\dot A v_k + (\\lambda_j - \\lambda_k) w_j^* \\dot v_k = 0")#text(";")]

#text("applying (1) we conclude a first variation formula for the eigenvectors ")#mi("v_k")#text(", namely that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\dot v_k = \\sum_{j \\neq k} \\frac{w_j^* \\dot A v_k}{\\lambda_k - \\lambda_j} v_j + c_k v_k")]]

#text("for some scalar ")#mi("c_k")#text(" (the presence of this term reflects the freedom to multiply ")#mi("v_k")#text(" by a scalar). Similar considerations for the adjoint give")

#align(center)[#mi("\\displaystyle \\dot w_k^* = \\sum_{j \\neq k} \\frac{w_k^* \\dot A v_j}{\\lambda_k - \\lambda_j} w_j^* - c_k w_k^*")#text(" (6′)")]

#text("(here we use the derivative of the identity ")#mi("w_k^* v_k = 1")#text(" to get the correct multiple of ")#mi("w_k^*")#text(" on the right.)")

#text("We can use (5), (6), (6′) to obtain a second variation formula for the eigenvalues. Indeed, by differentiating (5) we obtain")

#align(center)[#mi("\\ddot \\lambda_k = \\dot w_k^* \\dot A v_k + w_k^* \\ddot A v_k + w_k^* \\dot A \\dot v_k")#text(";")]

#text("applying (6), (6′) we conclude the second variation formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\ddot \\lambda_k = w_k^* \\ddot A v_k + 2\\sum_{j \\neq k} \\frac{ (w_k^* \\dot A v_j) (w_j^* \\dot A v_k) }{\\lambda_k - \\lambda_j}.")]]

#text("Now suppose that A is self-adjoint, so as before we can take ")#mi("v_k=w_k")#text(" to be orthonormal. The above formula then becomes")

#align(center)[#tao-fit-display[#tao-math("\\ddot \\lambda_k = v_k^* \\ddot A v_k + 2\\sum_{j \\neq k} \\frac{ \\left|v_k^* \\dot A v_j\\right|^2 }{\\lambda_k - \\lambda_j}.", block: true)]]

#text("One can view the terms on the right-hand side here as various “forces” acting on the eigenvalue ")#mi("\\lambda_k")#text("; the acceleration of the original matrix A provides one such force, while all the other eigenvalues ")#mi("\\lambda_j")#text(" provide a repulsive force (and note, as with Newton’s third law, that the force that ")#mi("\\lambda_j")#text(" exerts on ")#mi("\\lambda_k")#text(" is equal and opposite to the force that ")#mi("\\lambda_k")#text(" exerts on ")#mi("\\lambda_j")#text("; this is consistent with the trace formula ")#mi("\\sum_{k=1}^n \\lambda_k = \\text{tr}(A)")#text("). The closer two eigenvalues are to each other, the stronger the repulsive force becomes.")

#text("When the matrix A is not self-adjoint, then the interaction between ")#mi("\\lambda_j")#text(" and ")#mi("\\lambda_k")#text(" can be either repulsive or attractive. Consider for instance the matrices")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} 1 & t \\\\ -t & -1 \\end{pmatrix}.")]]

#text("The eigenvalues of this matrix are ")#mi("\\pm \\sqrt{1-t^2}")#text(" for ")#mi("-1 < t < 1")#text(" – so we see that they are attracted to each other as t evolves, until the matrix becomes degenerate at ")#mi("t = \\pm 1")#text(". In contrast, the self-adjoint matrices")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} 1 & t \\\\ t & -1 \\end{pmatrix}.")]]

#text("have eigenvalues ")#mi("\\pm \\sqrt{1+t^2}")#text(", which repel each other as t evolves.")

#text("The repulsion effect of eigenvalues is also consistent with the smallness of the set of matrices with repeated eigenvalues. Consider for instance the space of Hermitian ")#mi("n \\times n")#text(" matrices, which has real dimension ")#mi("n^2")#text(". The subset of Hermitian matrices with distinct eigenvalues can be described by a collection of n orthogonal (complex) one-dimensional eigenspaces (which can be computed to have ")#mi("2(n-1) + 2(n-2) + \\ldots + 2 = n(n-1)")#text(" degrees of freedom) plus n real eigenvalues (for an additional n degrees of freedom), thus the set of matrices with distinct eigenvalues has full dimension ")#mi("n^2")#text(".")

#text("Now consider the space of matrices with one repeated eigenvalue. This can be described by n-2 orthogonal complex one-dimensional eigenspaces, plus a complex two-dimensional orthogonal complement (which has ")#mi("2(n-1) + 2(n-2)+\\ldots+4 = n(n-1)-2")#text(" degrees of freedom) plus n-1 real eigenvalues, thus the set of matrices with repeated eigenvalues only has dimension ")#mi("n^2-3")#text(". Thus it is in fact very rare for eigenvalues to actually collide, which helps explain why there must be a repulsion effect in the first place.")

#text("An example can help illustrate this phenomenon. Consider the one-parameter family of Hermitian matrices")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} t & 0 \\\\ 0 & -t \\end{pmatrix}.")]]

#text("The eigenvalues of this matrix at time t are of course t and -t, which cross over each other when t changes sign. Now consider instead the Hermitian perturbation")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} t & \\varepsilon \\\\ \\varepsilon & -t \\end{pmatrix}")]]

#text("for some small ")#mi("\\varepsilon > 0")#text(". The eigenvalues are now ")#mi("\\sqrt{t^2+\\varepsilon^2}")#text(" and ")#mi("-\\sqrt{t^2+\\varepsilon^2}")#text("; they come close to each other as t approaches 0, but then “bounce” off of each other due to the repulsion effect.")

#heading(level: 1)[#text("Comments (52)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-33307")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2008")])]

#text("Dear Terry,")

#text("thanks for the nice post! By the way, let me make a suggestion (if you permit): after reading your post, I thought that you could complement it with a few comments about the stability of the spectrum in the infinite dimensional case, e.g., the results of Feldmann, Trubowitz and Knorrer about perturbations of the form ")#mi("\\Delta+V")#text(" of Laplacian ")#mi("\\Delta")#text(" on the d-dimensional torus (if you are able to find the time to write it down of course).")

#text("Bests,")

#text("Matheus")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-33309")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2008")])]

#text("Dear Matheus,")

#text("I was not familiar with the work of Feldmann et al., but in any event one can understand the spectral theory of self-adjoint unbounded operators such as ")#mi("\\Delta + V")#text(" by viewing them as the limit of the finite-dimensional self-adjoint truncations ")#mi("P_N(\\Delta + V)P_N")#text(", where ")#mi("P_N")#text(" is a Fourier projection to all modes of size less than N; the spectral theorem for ")#mi("\\Delta + V")#text(" shows that any finite number of eigenvalues and eigenvectors of the latter converge to the former in the limit ")#mi("N \\to \\infty")#text(" (one can also use the minimax formulae for these eigenvalues and eigenvectors here). So any stability statement concerning a bounded number of finite-dimensional eigenvalues or eigenvectors which is uniform in N can be recovered in this infinite-dimensional limit (in principle, at least).")

#text("A version of the first variation formula for eigenvalues of Laplacians was used recently by Hassell in his proof of the scarring conjecture for generic Bunimovich stadia, see")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2008/07/07/hassells-proof-of-scarring-for-the-bunimovich-stadium/")[#text("Hassell’s proof of scarring for the Bunimovich stadium")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of orr")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-33327")[#strong[#text("orr")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2008")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Is it possible that you meant to write, in the definition of the pseudospectrum, that it is the set of all numbers for which the resolvent has operator norm AT LEAST (and not AT MOST) one over epsilon?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-33328")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2008")])]

#text("Dear orr: thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-33341")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2008")]

#text("[…] When are eigenvalues stable? I was asked recently (in relation to my recent work with Van Vu on the spectral theory of random matrices) to explain […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e3b959399992f110f84d4a3d18b2460fdfe975efed8e8a6d258d19b774811769-c134577090e2f00f9d90c8f12f44f28d7942254c684b4375eee459edc041fd35.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carlos Matheus")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-33348")[#strong[#text("Carlos Matheus")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2008")])]

#text("Dear Terry,")

#text("this approach (ie, either approximation by finite dimensional self-adjoint operators or minimax principle) works well for the issue of stability of a bounded part of the spectrum in general. Also, we can push this argument to make it work for the whole spectrum in the 1d ‘torus’ case (this is particularly important when dealing with the KAM theory of NLS). In fact, the case of the circle is a bit special because the eigenvalues are simple and they have a ‘good spacing’ (ie the distance between two consecutive eigenvalues grows linearly).")

#text("Of course, these two facts are not true for higher dimensional tori. However, Feldman, Trubowitz and Knorrer manage to show in dimensions 2 and 3 (for the usual ‘square, flat’ torus and also for a ‘generic’ torus obtained from a typical lattice) that ‘most’ of eigenvalues are stable (in the sense that the set of stable eigenvalues form a subset of density 1 of the set of eigenvalues). Moreover, they constructed examples where the set of unstable eigenvalues is ‘non-trivial’ (although it has zero density). In particular, this is a technical problem if one would like to show KAM results for the NLS in higher dimensions.")

#text("By the way, the references for the papers of Feldman et al. are the following:")

#text("Stability results: ”The perturbatively stable spectrum of a periodic Schrödinger operator”. Invent. Math. 100 (1990), no. 2, 259–300.")

#text("Instability results: ”Perturbatively unstable eigenvalues of a periodic Schrödinger operator”. Comment. Math. Helv. 66 (1991), no. 4, 557–579.")

#text("Bests,")

#text("Matheus")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-33394")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2008")])]

#text("Is there a connection between this approach and the new submissions for Tue, 4 Nov 08")

#text("arXiv:0811.0007")#linebreak()#text(" Title: Large gaps between random eigenvalues")#linebreak()#text(" Authors: Benedek Valkó, Bálint Virág")#linebreak()#text(" Comments: 18 pages, 1 figure")#linebreak()#text(" Subjects: Probability (math.PR)")

#text("We show that in the point process limit of the bulk eigenvalues of $\\beta$-ensembles of random matrices, the probability of having no eigenvalue in a fixed interval of size $\\lambda$ is given by ")#tao-fit-display[#mitex("(\\kappa_\\beta+o(1))\\lambda^{\\gamma_\\beta} \\exp(- \\frac{\\beta}{64}\\lambda^2+(\\frac{\\beta}{4}-\\frac18)\\lambda)")]#text(" as $\\lambda\\to\\infty$, where ")#tao-fit-display[#mitex("\\gamma_\\beta={1/4}(\\frac\\beta{2}+\\frac{2}{\\beta}- 3).")]#text(" This is a slightly corrected version of a prediction by Dyson. Our proof uses the new Brownian carousel representation of the limit process, as well as the Cameron-Martin-Girsanov transformation in stochastic calculus.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-33456")[#strong[#text("Carnival of Mathematics #43 « The Number Warrior")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2008")]

#text("[…] of Terence Tao, I recommend his recent post on when eigenvalues are stable. If you’re intimidated by some of his other posts (say, his 19-part series on Ricci flow and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0aa174104fef35bc1bac80e593405c8675a317adf59f457d32ab8e5e6dd17218-76ebe96909c7b7c253aaba98a3fb9ef62c529e334cd156ad4f8ab2fd4cfd74e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of E Brian Davies")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-33460")[#strong[#text("E Brian Davies")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2008")])]

#text("Terry’s articles about the uses of pseudospectra touches on what is now a substantial research field. The book by Trefethen and Embree: Spectra and Pseudospectra, Princeton University Press, 2005, provides a wide range of theorems and real-world examples of their application. My own book, Linear Operators and Their Spectra, CUP 2007, is written at a more pure-mathematical level and has a chapter devoted to pseudospectra and what are often called nonlinear generalizations. Terry’s example of a small perturbation of a large Jordan matrix has been explored in detail by M Hager and myself — several relevant papers are in the arXiv.")

#text("It is generally considered that theorems about pseudospectra have nicer formulations if one defines the epsilon pseudospectrum using a strict inequality rather than a non-strict one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0aa174104fef35bc1bac80e593405c8675a317adf59f457d32ab8e5e6dd17218-76ebe96909c7b7c253aaba98a3fb9ef62c529e334cd156ad4f8ab2fd4cfd74e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of E Brian Davies")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-33461")[#strong[#text("E Brian Davies")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2008")])]

#text("With reference to the communications between Terry and Matheus above.")

#text("One has to be very careful about computing the spectrum of a self-adjoint operator H by looking at the limit of the spectra of ")#mi("P_NHP_N")#text(" as ")#mi("N\\to\\infty")#text(".")

#text("This can be justified by a minimax argument if one restricts attention to the part of the spectrum below the essential spectrum. It almost always gives a completely wrong answer if the operator H has a gap between two parts of the essential spectrum. The truncations seem to suggest that the gap is not present. This applies in particular to Schrodinger operators with periodic potentials acting in ")#mi("L^2(R)")#text(", which generally have a band-gap structure to the spectrum. If ")#mi("P_N")#text(" is an increasing sequence of finite rank projections constructed by standard finite element methods and converging strongly to the identity operator, then the spectra of the truncations fill up the gaps more and more densely as ")#mi("N\\to\\infty")#text(".")

#text("Once again there is a substantial numerical and analytic literature explaining why this method does not work and what one should do to get the right answer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0aa174104fef35bc1bac80e593405c8675a317adf59f457d32ab8e5e6dd17218-76ebe96909c7b7c253aaba98a3fb9ef62c529e334cd156ad4f8ab2fd4cfd74e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of E Brian Davies")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-33470")[#strong[#text("E Brian Davies")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2008")])]

#text("More dangers of truncation. I should have mentioned the many papers, indeed books, of Albrecht Boettcher and his co-workers on infinite non-self-adjoint bounded Toeplitz matrices. The spectra of the obvious finite truncations do converge as N\\to\\infty, but the limits are completely different from the spectra of the infinite matrices. This is a large and fascinating subject, but the message is the same – do not trust truncation unless you actually know that it works in your particular context.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad84740aadc8eb3c65c9c2df8183fac5863018967698c6e5352e7e90d4dbbe61-fa464e854b5d43196d104af87d938cea992f7b72759250dbba840392903ed290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of me")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-33567")[#strong[#text("me")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2008")])]

#text("Also, you may want to check out the papers of Burke, Lewis, and Overton. Together (and apart) they have many papers on Matrix stability, pseudospectral subdifferentials, etc. All very interesting and related work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f28160957b85b0b795af77e6dea6c99888f1d0e8b76b2b910249f77ebfc73a-0d11cc1252eba8719ed1bf3fb7b049debc2373b2e5a9579cd4cd35dd252d751d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Heilman")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-38089")[#strong[#text("Steven Heilman")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2009")])]

#text("Hi-")

#text("I think I found a few errors (most likely due to transcription?):")

#text("1. Eq. (3) is missing a * on the right hand side")#linebreak()#text(" 2. after Eq. (6), should read “… freedom to multiply v_{k}…”")

#text("Best-")#linebreak()#text(" -Steve")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3ad04e1ced21016b87f666e7ec164e56c2708dad17af723dc25b10a436a26d4-f0dc59139b53639bb39975118265aa1fa073a175964f544a2ff9618f3b8c1f65.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tusarepides")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-38436")[#strong[#text("Tusarepides")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2009")])]

#text("Hi, there unfortunately seems to be plenty of formulae that do not parse on this page – I have no trouble with other pages on your blog. Any hints on how I could fix this?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random matrices: universality of local eigenvalue statistics « What’s new")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-39171")[#strong[#text("Random matrices: universality of local eigenvalue statistics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2009")])]

#text("[…] of the matrix, and the unit eigenvector of the matrix associated to that eigenvalue. (See this earlier blog post for further discussion of this and related formulae). If one assumes that the eigenvectors are […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random matrices: Universality of local eigenvalue statistics up to the edge « What’s new")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-41052")[#strong[#text("Random matrices: Universality of local eigenvalue statistics up to the edge « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2009")])]

#text("[…] eigenvalues of “repel” the eigenvalues of (cf. the eigenvalue repulsion discussed in this previous blog post). On the other hand, the term on the right-hand side of (3) can be viewed as an attractive force […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3a: Eigenvalues and sums of Hermitian matrices « What’s new")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-43222")[#strong[#text("254A, Notes 3a: Eigenvalues and sums of Hermitian matrices « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2010")])]

#text("[…] (and also proportional to the square of the matrix coefficient of in the eigenbasis). See this earlier blog post for more discussion. Remark 4 In the proof of the four moment theorem of Van Vu and myself, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 4: The semi-circular law « What’s new")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-43466")[#strong[#text("254A, Notes 4: The semi-circular law « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2010")])]

#text("[…] In a similar vein, we may apply the truncation argument (much as was done for the central limit theorem in Notes 2) to reduce the semi-circular law to the bounded case: Exercise 5 Show that in order to prove the semi-circular law (in the almost sure sense), it suffices to do so under the additional hypothesis that the random variables are bounded. Similarly for the convergence in probability or in expectation senses. Remark 2 These facts ultimately rely on the stability of eigenvalues with respect to perturbations. This stability is automatic in the Hermitian case, but for non-symmetric matrices, serious instabilities can occur due to the presence of pseudospectrum. We will discuss this phenomenon more in later lectures (but see also this earlier blog post). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 5: Free probability « What’s new")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-43567")[#strong[#text("245A, Notes 5: Free probability « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2010")])]

#text("[…] (This is ultimately due to the stable nature of eigenvalues in the self-adjoint setting; see this previous blog post for discussion.) For non-self-adjoint operators, free probability needs to be augmented with […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90a582fad837ee236821ac802a09c6b9c0eb00fffe72a877a049c4751f31c54a-9138c1c2ea869b6652b46a70da4aeb23d0f43053774a1cd5c41a5e65e42f027f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hoda")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-44129")[#strong[#text("Hoda")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2010")])]

#text("Hi,")

#text("From the post:")#linebreak()#text(" “1.For normal matrices (and in particular, unitary or self-adjoint matrices), eigenvalues are very stable under small perturbations. For more general matrices, eigenvalues can become unstable if there is pseudospectrum present.”")

#text("A question: Does this result also apply for the genralized eigenvalue problem? (Ax = λBx)")

#text("Thank you for your help,")#linebreak()#text(" Hoda")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-44134")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2010")])]

#text("Well, if B is invertible (and well-conditioned), one can recast the generalised eigenvalue problem as an eigenvalue problem for ")#mi("AB^{-1}")#text(". In general, one does not expect this matrix to have any good properties unless A, B happen to lie in the same Lie group (e.g. they are both unitary), or if A and B commute. But in general (e.g. if A, B are generic Hermitian matrices, whose eigenspaces are “skew” with respect to each other) the problem could be highly unstable in the worst-case scenario (though perhaps only moderately unstable in the average-case scenario, thanks to the smoothed analysis phenomenon).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-44142")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2010")])]

#text("Thank you for your explanation")#linebreak()#text(" Hoda")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Outliers in the spectrum of iid matrices with bounded rank permutations « What’s new")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-49102")[#strong[#text("Outliers in the spectrum of iid matrices with bounded rank permutations « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2010")])]

#text("[…] non-Hermitian matrices were quite unstable with respect to general perturbations (as discussed in this previous blog post), and that there were no interlacing inequalities in this case to control bounded rank […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KKK")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-50198")[#strong[#text("KKK")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2011")])]

#text("Suppose the eigenvalues of the (normal?) matrices ")#mi("A(t)")#text(" are not necessarily distinct, does it follow that we can find a smooth family of n eigenvalues ")#mi("\\lambda_j(t)")#text(" if ")#mi("A(t)")#text(" is smooth?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-50200")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2011")])]

#text("In general, the answer is no. A simple example is the family of matrices ")#mi("A(t) := \\begin{pmatrix} 0 & t \\\\ 1 & 0 \\end{pmatrix}")#text(", which has eigenvalues ")#mi("\\pm t^{1/2}")#text(", which is not smooth at t=0. The characteristic polynomial of course depends smoothly on t, but as this example shows, the roots of that polynomial need not depend smoothly when there are repeated zeroes.")

#text("In the self-adjoint case, though, the answer is yes (first observed by Rellich in the analytic category, but I believe the observation is also valid in the smooth category). The basic point is that complex branch points such as ")#mi("\\pm t^{1/2}")#text(" cannot occur when the eigenvalues are forced to be real.")

#text("It seems to me that the normal case follows from the self-adjoint case by taking real and imaginary parts (or more precisely, self-adjoint and skew-adjoint parts).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da43068c67d0114422c125573516e28727be610d1f46e5ccf08e2466ae91badd-7cdb6db3aa8c50b3828513b61c113603c612cf77db6db74eeff644f15606902a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-50445")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2011")])]

#text("Dear Terrence, I’m very interested in the equations you obtain for the time dependence of the eigenvalues eqns. (5) through (7). However I don’t understand the term ")#mi("c_k v_k")#text(" in equation (6). In the eigenvector expansion, I get for the diagonal term ")#mi("w_{j}^{*} \\dot u_j")#text(". Which should be zero I think?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-50449")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2011")])]

#text("The expression ")#mi("w_k^* v_k")#text(" is unconstrained, and can take an arbitrary value; as noted in the text, this reflects the fact that eigenvectors are only determined up to scalar multiplication.")

#text("In the case of normal matrices (so that ")#mi("w_j = v_j")#text("), one can normalise all the ")#mi("v_j")#text(" to be of unit magnitude, which would indeed force ")#mi("w_k^* v_k")#text(" to vanish. However, in general one would not expect this vanishing unless one has specifically chosen a normalisation that guarantees it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/648e1ac79cd35a5a91224108665dd85e1de1506bfcdd47676bc6e83bc35ba954-7172b34fea187c83824d89270700d1db04fcf28437f323fc26d97145e35562fd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arkadas")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-145642")[#strong[#text("Arkadas")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2012")])]

#text("Terry, I think in your parenthetical remark “the presence of this term reflects the freedom to multiply c_k by a scalar”, the c_k should be replaced with v_k. (There is also a small glitch in the formatting of the matrix in the equation that begins with “U+E:=”.)")

#text("Thank you for this useful post.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da43068c67d0114422c125573516e28727be610d1f46e5ccf08e2466ae91badd-7cdb6db3aa8c50b3828513b61c113603c612cf77db6db74eeff644f15606902a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-51067")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2011")])]

#text("I think that equation 5 here is known as the Hellmann-Feynman formula in quantum mechanics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da43068c67d0114422c125573516e28727be610d1f46e5ccf08e2466ae91badd-7cdb6db3aa8c50b3828513b61c113603c612cf77db6db74eeff644f15606902a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-51068")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2011")])]

#text("The Hellman-Feynman formula takes derivatives with respect to some parameter other than ")#mi("t")#text(". But the derivation is the same.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0abc530355ca859abdf45e1983c5d0aa71a49963c398110ff56153a766213e9a-9562b5bf2e84d8146d1785c2938ab925d2df24c41f84c2d978f6cd4abda9612a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Reem")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-149106")[#strong[#text("Daniel Reem")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2012")])]

#text("Interesting post. Sorry for arriving somewhat late. Actually I arrived here")#linebreak()#text(" after visiting the recent Polymath7 research threads about the Hot Spots")#linebreak()#text(" Conjecture")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://polymathprojects.org/2012/06/24/polymath7-research-threads-3-the-hot-spots-conjecture/")[#text("Polymath7 research threads 3: the Hot Spots Conjecture")]
]

#text("My comment seems to be related to these threads too. Perhaps there is")#linebreak()#text(" the place to post it? anyway, later I may post additional and more specific")#linebreak()#text(" comments there. But let’s go to business now:")

#text("From the discussion at the beginning it follows that if a normal matrix A")#linebreak()#text(" is perturbed by a matrix E of operator norm at most epsilon, then the")#linebreak()#text(" spectrum of the perturbed matrix A’=A+E (not necessarily normal) will be in the")#linebreak()#text(" epsilon-neighborhood of A. The question is whether the converse is true")#linebreak()#text(" too, i.e., whether the spectrum of A will be in the [pmath] \\epsilon [/pmath]")#linebreak()#text(" neighborhood of the spectrum of A’. Otherwise this is only a weak form of")#linebreak()#text(" stability which may lead to undesired results. For instance, assume")#linebreak()#text(" that the spectrum of A consists of 4 separated eigenvalues")#linebreak()#text(" lambda_1, …, lambda_4. In principle it may happen that the spectrum of")#linebreak()#text(" the perturbed matrix A’ will consist of several eigenvalues, but all of them")#linebreak()#text(" will be concentrated around, say, lambda_1, and hence be far away from")#linebreak()#text(" the other eigenvalues.")

#text("In other words, the question is whether the Hausdorff distance between")#linebreak()#text(" sigma_(A) and sigma(A’) is at most epsilon, or at least a continuous")#linebreak()#text(" function of epsilon. This strong notion of stability seems to be quite")#linebreak()#text(" natural, in particular when the original spectrum may contain infinitely")#linebreak()#text(" many points. However, I am not an expert in this field, so perhaps this")#linebreak()#text(" property can be obtained easily from a discussion similar to the above")#linebreak()#text(" one, or, on the negative side, that it is known that such a stability property")#linebreak()#text(" is not realistic (or at least does not hold in some rare cases).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-149131")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2012")])]

#text("Yes, the spectrum of a (not necessarily normal) matrix is continuous in the Hausdorff metric with respect to perturbations. This can be seen from complex analysis; the number of eigenvalues (counting multiplicity) of a matrix A in a region ")#mi("\\Omega")#text(" is the same as the sum of the residues of the poles of the Stieltjes transform ")#mi("\\text{tr}(z-A)^{-1}")#text(", which can be expressed as a contour integral which will depend continuously on A as long as no eigenvalues enter or exit the region ")#mi("\\Omega")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0abc530355ca859abdf45e1983c5d0aa71a49963c398110ff56153a766213e9a-9562b5bf2e84d8146d1785c2938ab925d2df24c41f84c2d978f6cd4abda9612a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Reem")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-149491")[#strong[#text("Daniel Reem")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2012")])]

#text("Thanks for the response. Life in this blog seems to go somewhat fast.")#linebreak()#text(" Anyway, in the beginning of the post it was claimed that when the")#linebreak()#text(" matrix is not normal, then its spectrum may not be stable with respect")#linebreak()#text(" to small perturbations. A counterexample based on the shift matrix was")#linebreak()#text(" given, but perhaps this counterexample is not completely relevant,")#linebreak()#text(" since actually the space (and hence the dimension) should be fixed in")#linebreak()#text(" advance and we can always take smaller $\\epsilon$ for the")#linebreak()#text(" perturbation bound. In the book “An Introduction to Random Matrices”,")#linebreak()#text(" by Greg Anderson, Alice Guionnet and Ofer Zeitouni (2010), only weak")#linebreak()#text(" stability for normal matrices was mentioned (page 415), but strong")#linebreak()#text(" stability results for the specific case of Hermitian matrices were")#linebreak()#text(" mentioned on page 416")

#link("http://www.math.umn.edu/~zeitouni/technion/cupbook.pdf")[#text("Click to access cupbook.pdf")]

#text("Furthermore, does the fact that the number of eigenvalues depends")#linebreak()#text(" continuously on the operator mean that the whole spectrum depends")#linebreak()#text(" continuously on the operator? and is it true in the infinite dimensional")#linebreak()#text(" case?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0abc530355ca859abdf45e1983c5d0aa71a49963c398110ff56153a766213e9a-9562b5bf2e84d8146d1785c2938ab925d2df24c41f84c2d978f6cd4abda9612a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Reem")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-151222")[#strong[#text("Daniel Reem")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2012")])]

#text("Well, I think that indeed the spectrum of an arbitrary square matrix A, not necessarily normal, is strongly stable with respect to small perturbations of the matrix. An explanation is given below. Since the argument given in a previous comment regarding the contour integral and the Stieltjes transform is not clear to me (is it possible to give more details about it?), I will use a different approach, but it should be emphasized that nothing below is really new (it seems to be too classical; see also the remark at the end). I am going to give a description which is very detailed simply in order to illustrate the fact that explicit estimates can be given, and also for illustrating the fact that contradicting notions of stability appear in the literature.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0abc530355ca859abdf45e1983c5d0aa71a49963c398110ff56153a766213e9a-9562b5bf2e84d8146d1785c2938ab925d2df24c41f84c2d978f6cd4abda9612a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Reem")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-151223")[#strong[#text("Daniel Reem")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2012")])]

#text("PROOF: We want to show that given a positive number epsilon and a")#linebreak()#text(" matrix A, there exists a positive number delta such that if A’ is any")#linebreak()#text(" square matrix for which the operator norm of A’-A is less than delta,")#linebreak()#text(" then the Hausdorff distance between the spectrum of A and of A’ is less than epsilon.")

#text("Observation: there exists a universal positive constant C (depending only on the dimension) such that whenever the operator norm of A’-A is less than some delta, then the absolute value |a’_ij-a_ij| of the difference between (all) the corresponding components is less than C*delta. This is because the space of linear operators on R^n is an n^2 dimensional vector space and hence it is equivalent, via a bounded linear operator, to R^{n^2} endowed with the max norm (or any other norm).")

#text("Returning to the proof, let’s look at the list of eigenvalues of the")#linebreak()#text(" matrix A. It is obtained from a polynomial equation, corresponding to some polynomial P, and the coefficients of P depend on the components of the matrix. A classical result in complex analysis says that the roots of a polynomial equation (including the case of roots with multiplicities) depend in a continuous way on the coefficients of the polynomial. This result can be found in [1,5,6,7,8,9]. As a matter of fact, one can even give explicit estimates, as shown, e.g., in [1, pp. 14-15], [5], [7], [8, Appendix, A].")

#text("For the convenience of explanation denote by (Q) the vector of")#linebreak()#text(" coefficients of a polynomial Q having the same degree as of P. The above discussion about the classical result from complex analysis shows that for the given epsilon there exists a positive number r such that given any polynomial Q (having the same degree of P) satisfying")#linebreak()#text(" the condition that |(Q)-(P)|<r (in terms, e.g., of the max norm),")#linebreak()#text(" the roots of Q and P can be enumerated in such a way that the absolute value of the difference between the corresponding pairs of them is less than ")#tao-fit-display[#mitex("\\epsilon")]#text(". By the simple observation above, if A' is any matrix satisfying the condition that the operator norm of A'-A is less than delta=r/C (where C is defined in that observation), then the difference between any one of its components and the corresponding component of A is less than r. Summarizing the above, if |A'-A|<delta, then for any point in the spectrum of A' we can find a point in the spectrum and A such that the distance between them is less than epsilon, and for any point in the spectrum of A we can find a point in the spectrum and A' such that the distance between them is less than epsilon.")

#text("This proves the assertion. In particular, this shows that some")#linebreak()#text(" of the heuristics mentioned at the beginning of the post are")#linebreak()#text(" true (in a more general setting than mentioned), at least when")#linebreak()#text(" they are interpreted in the above language.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0abc530355ca859abdf45e1983c5d0aa71a49963c398110ff56153a766213e9a-9562b5bf2e84d8146d1785c2938ab925d2df24c41f84c2d978f6cd4abda9612a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Reem")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-151274")[#strong[#text("Daniel Reem")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2012")])]

#text("Well, the r from the estimate |(Q)-(P)|<r is not the same r from the Observation, since the entries of the matrices are not the coefficients of the corresponding polynomials. Fortunately, a simple modification solves this problem and explicit estimates can still be given. Unfortunately, these estimates are more complicated than before.")

#text("The modification is as follows: denote by rho the positive number corresponding to epsilon. Since each coefficient of P is a continuous function (explicit) of the entries of A, and since there are finitely many such functions, there exists a positive number r such that if the")#linebreak()#text(" absolute values of the differences between all the corresponding entries of A and A' are less than r, then |(Q)-(P)|<rho. Now we proceed with the proof as written (delta=r/C , etc.).")

#text("I am starting to think that instead of giving such a detailed proof")#linebreak()#text(" just to discover later that it suffers from problems and it wasn't detailed")#linebreak()#text(" enough, perhaps a better idea would have been to say briefly that the")#linebreak()#text(" roots of P depend in a continuous and explicit way on its coefficients, and that the coefficients depend in a continuous and explicit way on")#linebreak()#text(" the entries of A, which by themselves vary in a continuous and explicit")#linebreak()#text(" way when A is (norm) perturbed.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0abc530355ca859abdf45e1983c5d0aa71a49963c398110ff56153a766213e9a-9562b5bf2e84d8146d1785c2938ab925d2df24c41f84c2d978f6cd4abda9612a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Reem")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-151224")[#strong[#text("Daniel Reem")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2012")])]

#text("REMARK about contradicting notions of stability")

#text("At the beginning of the post and in various places in the literature, e.g., in [3, pp. 1,7 (arXiv version)], [2, pp. v, 238 (2006 version)], [4, page 586], [10, pp. 153-154], [11, p. 597], it is claimed that the spectrum of")#linebreak()#text(" a non-normal matrix can be (very) unstable with respect to small")#linebreak()#text(" perturbations of the matrix. However, a careful reading of all of these")#linebreak()#text(" places shows that always the dimension considered there is allowed to")#linebreak()#text(" vary (in particular, to grow to infinity) and at the same time either")#linebreak()#text(" the perturbation bound is fixed or it becomes a function of the")#linebreak()#text(" dimension. While this may be a legitimize way for")#linebreak()#text(" estimating issues related to stability, in particular in numerical analysis")#linebreak()#text(" and other practical/applied scenarios (where. e.g., the perturbation bound is often the rounding error of the given computing device and related limitations are taken into account), this is not a standard way of")#linebreak()#text(" formulating a pure continuity result since the space (and hence the")#linebreak()#text(" dimension) on which the operator acts should be fixed in advance,")#linebreak()#text(" and the perturbation bound can be taken as smaller as we want without")#linebreak()#text(" any limitation. It is interesting to note that sometimes the apparent contradiction between the two notions of stability is very explicit: on page 586 of [4] one can find a claim (without any proof or reference) about the continuity of the spectrum with respect to perturbation of the matrix, and a few lines later a warning about the possible dramatic change of the eigenvalues when small perturbations of the same matrix occur!")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eecd66a337c2a4e86e826a83728d9e8eafa931528e06c8e39a12720fd9c72ab9-a2f288599044367771d0e441dea02b25f62c0a5c58b10e26624a15bcdd990a33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orr Shalit")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-176260")[#strong[#text("Orr Shalit")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2012")])]

#text("There is no contradiction. A function can be continuous and yet have a very big modulus of continuity, and therefore be unstable in practice. That’s why in one place the word “continuity” is used, and in the other “dramatic change”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0abc530355ca859abdf45e1983c5d0aa71a49963c398110ff56153a766213e9a-9562b5bf2e84d8146d1785c2938ab925d2df24c41f84c2d978f6cd4abda9612a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Reem")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-151225")[#strong[#text("Daniel Reem")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2012")])]

#text("REFERENCES")

#text("[1] B. Curgus and V. Mascioni, Roots and polynomials as homeomorphic spaces,")#linebreak()#text(" Expositiones Mathematicae 24 (2006) no. 1, 81–95, arXiv: math/0502037")

#link("http://arxiv.org/abs/math/0502037")[#text("http://arxiv.org/abs/math/0502037")]

#text("(the arXiv version cites more or less some of the references below, and contains")#linebreak()#text(" some explicit estimates on pages 14-15.)")

#text("[2] E. B. Davies, Linear Operators and Their Spectra, Cambridge. University Press, 2008")

#text("preprint from 2006: ")#link("http://www.mth.kcl.ac.uk/staff/eb_davies/printmaster.pdf")[#text("http://www.mth.kcl.ac.uk/staff/eb_davies/printmaster.pdf")]

#text("[3] E.B. Davies and M. Hager, Perturbations of Jordan Matrices,")#linebreak()#text(" Journal of Approximation Theory 156, Issue 1 (2009), 82-94")

#link("http://arxiv.org/abs/math/0612158")[#text("http://arxiv.org/abs/math/0612158")]

#text("[4] M. Embree and L. N. Trefethen, Generalizing eigenvalue theorems")#linebreak()#text(" to pseudospectra theorems, SIAM J. Sci. Comput. 23 (2001), 583-590.")

#link("http://people.maths.ox.ac.uk/trefethen/publication/PDF/2001_94.pdf")[#text("Click to access 2001_94.pdf")]

#text("[5] A. Galantai and C. J. Hegedus, Perturbation bounds for polynomials,")#linebreak()#text(" Numerische Mathematik 109, Number 1 (2008)")#linebreak()#text(" ")#link("http://www.springerlink.com/content/g77p2860w302v2xx/")[#text("http://www.springerlink.com/content/g77p2860w302v2xx/")]

#text("(better estimates than the ones given in previous works are claimed)")

#text("[6] M. Marden, Geometry of Polynomials, second ed., Providence,")#linebreak()#text(" American Mathematical Society, 1966")

#text("[7] A. M., Ostrowski, Recherches sur la methode de graeffe et les zeros des")#linebreak()#text(" polynomes et des series de laurent, Acta Mathematica 72, Number 1 (1940), 99-257.")

#link("http://www.springerlink.com/content/0001-5962/72/1/")[#text("http://www.springerlink.com/content/0001-5962/72/1/")]

#text("[8] A. M. Ostrowski, Solution of Equations in Euclidean and Banach Spaces,")#linebreak()#text(" third ed., Pure and Applied Mathematics, Vol. 9, Academic Press, 1973.")

#text("[9] Q. I. Rahman, G. Schmeisser, Analytic Theory of Polynomials,")#linebreak()#text(" Oxford University Press, 2002.")

#text("[10] L. Reichel and L. N. Trefethen, Eigenvalues and Pseudo-eigenvalues")#linebreak()#text(" of Toeplitz Matrices, Linear Algebra and Its Applications 162-164 (1992), 153-185")

#link("http://people.maths.ox.ac.uk/trefethen/publication/PDF/1992_53.pdf")[#text("Click to access 1992_53.pdf")]

#text("[11] L. N. Trefethen, M. Contedini and M. Embree,")#linebreak()#text(" Spectra, pseudospectra and localization for random bidiagonal matrices,")#linebreak()#text(" Comm. Pure Appl. Math. 54 (2001), 595-623.")

#link("http://people.maths.ox.ac.uk/trefethen/publication/PDF/2001_96.pdf")[#text("Click to access 2001_96.pdf")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0abc530355ca859abdf45e1983c5d0aa71a49963c398110ff56153a766213e9a-9562b5bf2e84d8146d1785c2938ab925d2df24c41f84c2d978f6cd4abda9612a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Reem")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-151253")[#strong[#text("Daniel Reem")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2012")])]

#text("Something minor about the comment after Ref [1] : neither [1] nor the references mentioned in [1] are about the stability of the eigenvalues of a matrix with respect to perturbations of the matrix. (My mistake: this comment was written before many of the references were added.")#linebreak()#text(" I should have deleted most of it, with the exception of mentioning")#linebreak()#text(" [1, pp. 14-15].)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0abc530355ca859abdf45e1983c5d0aa71a49963c398110ff56153a766213e9a-9562b5bf2e84d8146d1785c2938ab925d2df24c41f84c2d978f6cd4abda9612a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Reem")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-177619")[#strong[#text("Daniel Reem")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2012")])]

#text("[This comment is a response to the one given by Orr Shalit on September 28, 2012 at 5:05 pm. It is given here because I cannot reply there (no reply button). ]")

#text("It is interesting to see that also past commenters of this post have not lost their interest in the relevant issues. As for the comment itself, let me add that perhaps the derivation of the explicit bounds described in the detailed discussion from July 10, 2012 may help in explaining the behavior of some magnitudes, e.g., the modulus of continuity or related notions [the relevant function here is actually multi-valued, assigning to a matrix A the (multi)set spectrum(A) ].")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random matrices have simple spectrum | What's new")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-443858")[#strong[#text("Random matrices have simple spectrum | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2014")])]

#text("[…] are distinct. This is a very typical property of matrices to have: for instance, as discussed in this previous post, in the space of all Hermitian matrices, the space of matrices without all eigenvalues simple has […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random matrices: tail bounds for gaps between eigenvalues | What's new")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-453770")[#strong[#text("Random matrices: tail bounds for gaps between eigenvalues | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2015")])]

#text("[…] in isolation, once their associated eigenvalue is well separated from the other eigenvalues; see this previous blog post for more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b570b8b7b97267fd96e32e31eacbafa06288f3b1c59959e82b34fd2173cff4d3-61787377e9dfe56c09358e505064f14c7eb83886d891daeb018d22ee4a690013.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Functions")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-458280")[#strong[#text("Functions")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2015")])]

#text("Nice job! Recently i asked my self about solving a linear system with the form X’=AX, as you know the solution of this system is: X=K*Exp(A)*(v1 v2)^T Means transpose, sorry i’m using my cel) somehow i see the matrix equations work exactly the same as variables do. Why? In this case i am working in the linear system X=A(t)X. I have been searching and trying the characteristcs of eigen values in matrix with functions. What is the relationship between A(t) and A'(t) in their eigen values. I am trying to give a general solution of a differential equation order two. Which means to understand furthermore the work of eigenvalues in matrix with functions. If you have any information about this. Please let me know. Have a nice day.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/803266c7ab6472ec9611dec2a090501ff6a79f58d5fafdfa3adcb82545657a27-c970c3296e1dc3dc780be6c4b796c7dbe0400c04eb3c2551fa89687a5f60e113.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ramis Movassagh")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-462699")[#strong[#text("Ramis Movassagh")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2015")])]

#text("Hi Terry, Thanks once again for the very nice post! Regarding #2 in the introductory section of this post, I wanted to mention that in general the force between any two eigenvalues of a non-self adjoint matrix may not even be central (neither attractive, nor repulsive). This follows from your Eq. 7.")

#text("Some further discussions may be found in:")#linebreak()#text(" “Eigenvalue Attraction”, to appear in Journal of Statistical Physics:")

#link("http://arxiv.org/pdf/1404.4113v3.pdf")[#text("Click to access 1404.4113v3.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-462714")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2015")])]

#text("An interesting general relativistic analog is to interpret elementary particles as singularities (e.g. “mini blackholes”) of the space-time metric, and study their corresponding world-lines (i.e. their trajectories in space-time, which are singular lines in the space-time metric) for possible local attractions among nearby particles.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oskar")]], [#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-474056")[#strong[#text("Oskar")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2016")])]

#text("There is an error in the paragraph directly above the heading “Spectral dynamics”. Instead of")#linebreak()#text(" ")#mi("U^n=\\epsilon I")#linebreak()#text(" it should be")#linebreak()#text(" ")#mi("(U+E)^n=\\epsilon I")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-479092")[#strong[#text("Singular value decomposition | Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2017")]

#text("[…] of a square matrix can have a large effect on its eigenvalues. This is explained e.g. in in this blog post by Terence Tao, and is related […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-480121")[#strong[#text("Courant-Fischer Theorem")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2017")]

#text("[…] of a square matrix can have a large effect on its eigenvalues. This is explained e.g. in in this blog post by Terence Tao, and is related to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-480182")[#strong[#text("Inventing singular value decomposition")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2017")]

#text("[…] of a square matrix can have a large effect on its eigenvalues. This is explained e.g. in in this blog post by Terence Tao, and is related to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-643220")[#strong[#text("eigenvalues eigenvectors - Spectral properties of two positive-definite Toeplitz matrices - ITTone")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2022")]

#text("[…] if so, could anyone give some hints on how to prove it? I was looking at Terry Tao’s blog on ")#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/")[#text("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/")]#text(" and some work on eigenvalue perturbation but I’m not sure if this is the right direction. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/#comment-643256")[#strong[#text("linear algebra - Eigenvalues of two positive-definite Toeplitz matrices Answer - Lord Web")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2022")]

#text("[…] if so, could anyone give some hints on how to prove it? I was looking at Terry Tao’s blog on ")#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/")[#text("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/")]#text(" and some work on eigenvalue perturbation (eg. perturbation theory in quantum mechanics) but […]")
]
