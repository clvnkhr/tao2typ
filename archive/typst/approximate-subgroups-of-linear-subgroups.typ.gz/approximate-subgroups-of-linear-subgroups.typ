// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/05/12/approximate-subgroups-of-linear-subgroups/
// Converted to Typst by tao2typ: "2026-10-14T15:17:46.079464+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Approximate subgroups of linear groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Approximate subgroups of linear groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 May 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/05/12/approximate-subgroups-of-linear-subgroups/")[#text("https://terrytao.wordpress.com/2010/05/12/approximate-subgroups-of-linear-subgroups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#link("http://www.math.u-psud.fr/~breuilla/indexgb.html")[#text("Emmanuel Breuillard")]#text(", ")#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(", and I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" our paper “")#link("http://arxiv.org/abs/1005.1881")[#text("Approximate subgroups of linear groups")]#text("“, submitted to GAFA. This paper contains (the first part) of the results ")#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/")[#text("announced previously by us")]#text("; the second part of these results, concerning expander groups, will appear subsequently. The release of this paper has been coordinated with the release of a parallel paper by Pyber and Szabo (")#link("http://arxiv.org/abs/1001.4556")[#text("previously announced")]#text(" within an hour(!) of our own announcement).")

#text("Our main result describes (with polynomial accuracy) the “sufficiently Zariski dense” approximate subgroups of simple algebraic groups ")#mi("{{\\bf G}(k)}")#text(", or more precisely absolutely almost simple algebraic groups over ")#mi("{k}")#text(", such as ")#mi("{SL_d(k)}")#text(". More precisely, define a ")#emph[#mi("{K}")#text("-approximate subgroup")]#text(" of a genuine group ")#mi("{G}")#text(" to be a finite symmetric neighbourhood of the identity ")#mi("{A}")#text(" (thus ")#mi("{1 \\in A}")#text(" and ")#mi("{A^{-1}=A}")#text(") such that the product set ")#mi("{A \\cdot A}")#text(" can be covered by ")#mi("{K}")#text(" left-translates (and equivalently, ")#mi("{K}")#text(" right-translates) of ")#mi("{A}")#text(".")

#text("Let ")#mi("{k}")#text(" be a field, and let ")#mi("{\\overline{k}}")#text(" be its algebraic closure. For us, an absolutely almost simple algebraic group over ")#mi("{k}")#text(" is a linear ")#link("http://en.wikipedia.org/wiki/Algebraic_group")[#text("algebraic group")]#text(" ")#mi("{{\\bf G}(k)}")#text(" defined over ")#mi("{k}")#text(" (i.e. an algebraic subvariety of ")#mi("{GL_n(k)}")#text(" for some ")#mi("{n}")#text(" with group operations given by regular maps) which is connected (i.e. irreducible), and such that the completion ")#mi("{{\\bf G}(\\overline{k})}")#text(" has no proper normal subgroups of positive dimension (i.e. the only normal subgroups are either finite, or are all of ")#mi("{{\\bf G}(\\overline{k})}")#text(". To avoid degeneracies we also require ")#mi("{{\\bf G}}")#text(" to be non-abelian (i.e. not one-dimensional). These groups can be classified in terms of their associated finite-dimensional simple complex Lie algebra, which of course is determined by its Dynkin diagram, together with a choice of weight lattice (and there are only finitely many such choices once the Lie algebra is fixed). However, the exact classification of these groups is not directly used in our work.")

#text("Our first main theorem classifies the approximate subgroups ")#mi("{A}")#text(" of such a group ")#mi("{{\\bf G}(k)}")#text(" in the model case when ")#mi("{A}")#text(" generates the entire group ")#mi("{{\\bf G}(k)}")#text(", and ")#mi("{k}")#text(" is finite; they are either very small or very large.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Approximate groups that generate)")]#text(" Let ")#mi("{{\\bf G}(k)}")#text(" be an absolutely almost simple algebraic group over ")#mi("{k}")#text(". If ")#mi("{k}")#text(" is finite and ")#mi("{A}")#text(" is a ")#mi("{K}")#text("-approximate subgroup of ")#mi("{{\\bf G}(k)}")#text(" that generates ")#mi("{{\\bf G}(k)}")#text(", then either ")#tao-math("{\\left|A\\right| \\leq K^{O(1)}}", block: false)#text(" or ")#tao-math("{\\left|A\\right| \\geq K^{-O(1)} \\left|{\\bf G}(k)\\right|}", block: false)#text(", where the implied constants depend only on ")#mi("{{\\bf G}}")#text(".")
]

#text("The hypothesis that ")#mi("{A}")#text(" generates ")#mi("{{\\bf G}(k)}")#text(" cannot be removed completely, since if ")#mi("{A}")#text(" was a proper subgroup of ")#mi("{{\\bf G}(k)}")#text(" of size intermediate between that of the trivial group and of ")#mi("{{\\bf G}(k)}")#text(", then the conclusion would fail (with ")#mi("{K=O(1)}")#text("). However, one can relax the hypothesis of generation to that of being ")#emph[#text("sufficiently Zariski-dense")]#text(" in ")#mi("{{\\bf G}(k)}")#text(". More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Zariski-dense approximate groups)")]#text(" Let ")#mi("{{\\bf G}(k)}")#text(" be an absolutely almost simple algebraic group over ")#mi("{k}")#text(". If ")#mi("{A}")#text(" is a ")#mi("{K}")#text("-approximate group) is not contained in any proper algebraic subgroup of ")#mi("{k}")#text(" of complexity at most ")#mi("{M}")#text(" (where ")#mi("{M}")#text(" is sufficiently large depending on ")#mi("{{\\bf G}}")#text("), then either ")#tao-math("{\\left|A\\right| \\leq K^{O(1)}}", block: false)#text(" or ")#tao-math("{\\left|A\\right| \\geq K^{-O(1)} \\left|\\langle A \\rangle\\right|}", block: false)#text(", where the implied constants depend only on ")#mi("{{\\bf G}}")#text(" and ")#mi("{\\langle A \\rangle}")#text(" is the group generated by ")#mi("{A}")#text(".")
]

#text("Here, we say that an algebraic variety has complexity at most ")#mi("{M}")#text(" if it can be cut out of an ambient affine or projective space of dimension at most ")#mi("{M}")#text(" by using at most ")#mi("{M}")#text(" polynomials, each of degree at most ")#mi("{M}")#text(". (Note that this is not an intrinsic notion of complexity, but will depend on how one embeds the algebraic variety into an ambient space; but we are assuming that our algebraic group ")#mi("{{\\bf G}(k)}")#text(" is a linear group and thus comes with such an embedding.)")

#text("In the case when ")#mi("{k = {\\bf C}}")#text(", the second option of this theorem cannot occur since ")#mi("{{\\bf G}({\\bf C})}")#text(" is infinite, leading to a satisfactory classification of the Zariski-dense approximate subgroups of almost simple connected algebraic groups over ")#mi("{{\\bf C}}")#text(". On the other hand, every approximate subgroup of ")#mi("{GL_n({\\bf C})}")#text(" is Zariski-dense in ")#emph[#text("some")]#text(" algebraic subgroup, which can be then split as an extension of a semisimple algebraic quotient group by a solvable algebraic group (the radical of the Zariski closure). Pursuing this idea (and glossing over some annoying technical issues relating to connectedness), together with the Freiman theory for solvable groups over ")#mi("{{\\bf C}}")#text(" ")#link("http://arxiv.org/abs/0907.0927")[#text("due to Breuillard and Green")]#text(", we obtain our third theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Freiman’s theorem in ")#mi("{GL_n({\\bf C})}")#text(")")]#text(" Let ")#mi("{A}")#text(" be a ")#mi("{K}")#text("-approximate subgroup of ")#mi("{GL_n({\\bf C})}")#text(". Then there exists a nilpotent ")#mi("{K}")#text("-approximate subgroup ")#mi("{B}")#text(" of size at most ")#tao-math("{K^{O(1)}\\left|A\\right|}", block: false)#text(", such that ")#mi("{A}")#text(" is covered by ")#mi("{K^{O(1)}}")#text(" translates of ")#mi("{B}")#text(".")
]

#text("This can be compared with Gromov’s celebrated theorem that any finitely generated group of polynomial growth is virtually nilpotent. Indeed, the above theorem easily implies Gromov’s theorem in the case of finitely generated subgroups of ")#mi("{GL_n({\\bf C})}")#text(".")

#text("By fairly standard arguments, the above classification theorems for approximate groups can be used to give bounds on the expansion and diameter of Cayley graphs, for instance one can establish a conjecture of Babai and Seress that connected Cayley graphs on absolutely almost simple groups over a finite field have polylogarithmic diameter at most. Applications to expanders include the result on Suzuki groups mentioned in a ")#link("https://terrytao.wordpress.com/2010/05/06/suzuki-groups-as-expanders/")[#text("previous post")]#text("; further applications will appear in a forthcoming paper.")

#text("Apart from the general structural theory of algebraic groups, and some quantitative analogues of the basic theory of algebraic geometry (which we chose to obtain via ultrafilters, as ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("discussed in this post")]#text("), we rely on two basic tools. Firstly, we use a version of the pivot argument developed first by Konyagin and Bourgain-Glibichuk-Konyagin in the setting of sum-product estimates, and generalised to more non-commutative settings by Helfgott; this is discussed in ")#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/")[#text("this previous post")]#text(". Secondly, we adapt an argument of Larsen and Pink (which we learned from a paper of Hrushovski) to obtain a sharp bound on the extent to which a sufficiently Zariski-dense approximate groups can concentrate in a (bounded complexity) subvariety; this is discussed at the end of ")#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/")[#text("this blog post")]#text(".")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebddbfe42ee54857332bb7d03af74b0f9058f0aac37b2cccba68ab3955fe2952-6a08acde4437f22c89be596b0747a34a10a2140d1543fdb3a09e94c765b5fa9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James")]], [#link("https://terrytao.wordpress.com/2010/05/12/approximate-subgroups-of-linear-subgroups/#comment-44818")[#strong[#text("James")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2010")])]

#text("Your links aren’t rendering properly, in chrome at least.")

#emph[#text("[Fixed now – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mads")]], [#link("https://terrytao.wordpress.com/2010/05/12/approximate-subgroups-of-linear-subgroups/#comment-44819")[#strong[#text("Mads")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2010")])]

#text("It is the same in the Firefox browser.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Noud")]], [#link("https://terrytao.wordpress.com/2010/05/12/approximate-subgroups-of-linear-subgroups/#comment-44820")[#strong[#text("Noud")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2010")])]

#text("Looks like the html output was put in the wysiwyg editor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/05/12/approximate-subgroups-of-linear-subgroups/#comment-44821")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2010")])]

#text("The same in IE8…")#linebreak()#text(" But why the tags such as")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("are not recognized?..")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/05/12/approximate-subgroups-of-linear-subgroups/#comment-44831")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2010")])]

#text("You have a typo in the title of the post: Approximate subgroups of linear *sub*groups.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A note on approximate subgroups of GL_n(C) and uniformly nonamenable groups « What’s new")]], [#link("https://terrytao.wordpress.com/2010/05/12/approximate-subgroups-of-linear-subgroups/#comment-49613")[#strong[#text("A note on approximate subgroups of GL_n(C) and uniformly nonamenable groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2011")])]

#text("[…] further proofs of this theorem were obtained by ourselves, as well as in the most recent version of a similar preprint by Pyber and Szabo. The arguments used […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Expansion in finite simple groups of Lie type | What's new")]], [#link("https://terrytao.wordpress.com/2010/05/12/approximate-subgroups-of-linear-subgroups/#comment-244507")[#strong[#text("Expansion in finite simple groups of Lie type | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2013")])]

#text("[…] Seitz-Zalesskii, and the product theorem was already established by Pyber-Szabo and independently by Breuillard, Green, and myself. So the main problem is to establish non-concentration: that for a random Cayley graph on a finite […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qualitative probability theory, types, and the group chunk and group configuration theorems | What's new")]], [#link("https://terrytao.wordpress.com/2010/05/12/approximate-subgroups-of-linear-subgroups/#comment-251377")[#strong[#text("Qualitative probability theory, types, and the group chunk and group configuration theorems | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2013")])]

#text("[…] pushes forward to the uniform measure of some almost irreducible subset of ; see e.g. Lemma A.8 of this previous paper of Breuillard, Green, and myself. Also, generic points in have fibres in of dimension , just as one would expect from naive […]")
]
