// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/03/28/the-cayley-salmon-theorem-via-classical-differential-geometry/
// Converted to Typst by tao2typ: "2026-10-14T16:37:23.217873+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Monge-Cayley-Salmon theorem via classical differential geometry", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Monge-Cayley-Salmon theorem via classical differential geometry")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 March 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/03/28/the-cayley-salmon-theorem-via-classical-differential-geometry/")[#text("https://terrytao.wordpress.com/2014/03/28/the-cayley-salmon-theorem-via-classical-differential-geometry/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{f: {\\bf R}^3 \\rightarrow {\\bf R}}")#text(" be an irreducible polynomial in three variables. As ")#mi("{{\\bf R}}")#text(" is not algebraically closed, the zero set ")#mi("{Z_{\\bf R}(f) = \\{ x \\in{\\bf R}^3: f(x)=0\\}}")#text(" can split into various components of dimension between ")#mi("{0}")#text(" and ")#mi("{2}")#text(". For instance, if ")#mi("{f(x_1,x_2,x_3) = x_1^2+x_2^2}")#text(", the zero set ")#mi("{Z_{\\bf R}(f)}")#text(" is a line; more interestingly, if ")#mi("{f(x_1,x_2,x_3) = x_3^2 + x_2^2 - x_2^3}")#text(", then ")#mi("{Z_{\\bf R}(f)}")#text(" is the union of a line and a surface (or the product of an ")#link("http://en.wikipedia.org/wiki/Acnode")[#text("acnodal")]#text(" cubic curve with a line). We will assume that the ")#mi("{2}")#text("-dimensional component ")#mi("{Z_{{\\bf R},2}(f)}")#text(" is non-empty, thus defining a real surface in ")#mi("{{\\bf R}^3}")#text(". In particular, this hypothesis implies that ")#mi("{f}")#text(" is not just irreducible over ")#mi("{{\\bf R}}")#text(", but is in fact ")#link("http://en.wikipedia.org/wiki/Absolutely_irreducible")[#text("absolutely irreducible")]#text(" (i.e. irreducible over ")#mi("{{\\bf C}}")#text("), since otherwise one could use the complex factorisation of ")#mi("{f}")#text(" to contain ")#mi("{Z_{\\bf R}(f)}")#text(" inside the intersection ")#mi("{{\\bf Z}_{\\bf C}(g) \\cap {\\bf Z}_{\\bf C}(\\bar{g})}")#text(" of the complex zero locus of complex polynomial ")#mi("{g}")#text(" and its complex conjugate, with ")#mi("{g,\\bar{g}}")#text(" having no common factor, forcing ")#mi("{Z_{\\bf R}(f)}")#text(" to be at most one-dimensional. (For instance, in the case ")#mi("{f(x_1,x_2,x_3)=x_1^2+x_2^2}")#text(", one can take ")#mi("{g(z_1,z_2,z_3) = z_1 + i z_2}")#text(".) Among other things, this makes ")#mi("{{\\bf Z}_{{\\bf R},2}(f)}")#text(" a ")#link("http://en.wikipedia.org/wiki/Zariski_topology")[#text("Zariski-dense")]#text(" subset of ")#mi("{{\\bf Z}_{\\bf C}(f)}")#text(", thus any polynomial identity which holds true at every point of ")#mi("{{\\bf Z}_{{\\bf R},2}(f)}")#text(", also holds true on all of ")#mi("{{\\bf Z}_{\\bf C}(f)}")#text(". This allows us to easily use tools from algebraic geometry in this real setting, even though the reals are not quite algebraically closed.")

#text("The surface ")#mi("{Z_{{\\bf R},2}(f)}")#text(" is said to be ")#link("http://en.wikipedia.org/wiki/Ruled_surface")[#text("ruled")]#text(" if, for a Zariski open dense set of points ")#mi("{x \\in Z_{{\\bf R},2}(f)}")#text(", there exists a line ")#mi("{l_x = \\{ x+tv_x: t \\in {\\bf R} \\}}")#text(" through ")#mi("{x}")#text(" for some non-zero ")#mi("{v_x \\in {\\bf R}^3}")#text(" which is completely contained in ")#mi("{Z_{{\\bf R},2}(f)}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("f(x+tv_x)=0")]]

#text("for all ")#mi("{t \\in {\\bf R}}")#text(". Also, a point ")#mi("{x \\in {\\bf Z}_{{\\bf R},2}(f)}")#text(" is said to be a ")#link("http://www.encyclopediaofmath.org/index.php/Flecnode")[#text("flecnode")]#text(" if there exists a line ")#mi("{l_x = \\{ x+tv_x: t \\in {\\bf R}\\}}")#text(" through ")#mi("{x}")#text(" for some non-zero ")#mi("{v_x \\in {\\bf R}^3}")#text(" which is tangent to ")#mi("{Z_{{\\bf R},2}(f)}")#text(" to third order, in the sense that")

#align(center)[#tao-fit-display[#mitex("f(x+tv_x)=O(t^4)")]]

#text("as ")#mi("{t \\rightarrow 0}")#text(", or equivalently that ")#metadata(none) <tao-93ce248b8b9c8758eb55>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{d^j}{dt^j} f(x+tv_x)|_{t=0} = 0")]]



#text(" for ")#mi("{j=0,1,2,3}")#text(". Clearly, if ")#mi("{Z_{{\\bf R},2}(f)}")#text(" is a ruled surface, then a Zariski open dense set of points on ")#mi("{Z_{{\\bf R},2}}")#text(" are a flecnode. We then have the remarkable theorem (discovered first by Monge, and then later by Cayley and Salmon) asserting the converse:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Monge-Cayley-Salmon theorem)")]#text(" Let ")#mi("{f: {\\bf R}^3 \\rightarrow {\\bf R}}")#text(" be an irreducible polynomial with ")#mi("{{\\bf Z}_{{\\bf R},2}}")#text(" non-empty. Suppose that a Zariski dense set of points in ")#mi("{Z_{{\\bf R},2}(f)}")#text(" are flecnodes. Then ")#mi("{Z_{{\\bf R},2}(f)}")#text(" is a ruled surface.")
]

#text("Among other things, this theorem was used in the ")#link("http://arxiv.org/abs/1011.4105")[#text("celebrated result of Guth and Katz")]#text(" that almost solved the ")#link("http://en.wikipedia.org/wiki/Erd%C5%91s_distinct_distances_problem")[#text("Erdos distance problem in two dimensions")]#text(", as discussed in ")#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/")[#text("this previous blog post")]#text(". Vanishing to third order is necessary: observe that in a surface of negative curvature, such as the saddle ")#mi("{\\{ (x_1,x_2,x_3): x_3 = x_1^2 - x_2^2 \\}}")#text(", every point on the surface is tangent to second order to a line (the line in the direction for which the ")#link("http://en.wikipedia.org/wiki/Second_fundamental_form")[#text("second fundamental form")]#text(" vanishes). This surface happens to be ruled, but a generic perturbation of this surface (e.g. ")#mi("{x_3 = x_1^2 - x_2^2 + x_2^4}")#text(") will no longer be ruled, although it is still negative curvature near the origin.")

#text("The original proof of the Monge-Cayley-Salmon theorem is not easily accessible and not written in modern language. A modern proof of this theorem (together with substantial generalisations, for instance to higher dimensions) is given ")#link("http://www.ams.org/mathscinet-getitem?mr=1676869")[#text("by Landsberg")]#text("; the proof uses the machinery of modern algebraic geometry. The purpose of this post is to record an alternate proof of the Monge-Cayley-Salmon theorem based on classical differential geometry (in particular, the notion of ")#link("http://en.wikipedia.org/wiki/Torsion_of_curves")[#text("torsion of a curve")]#text(") and basic ODE methods (in particular, ")#link("http://en.wikipedia.org/wiki/Gronwall_inequality")[#text("Gronwall’s inequality")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Picard%E2%80%93Lindel%C3%B6f_theorem")[#text("Picard existence theorem")]#text("). The idea is to “integrate” the lines ")#mi("{l_x}")#text(" indicated by the flecnode to produce smooth curves ")#mi("{\\gamma}")#text(" on the surface ")#mi("{{\\bf Z}_{{\\bf R},2}}")#text("; one then uses the vanishing ")#link(<tao-93ce248b8b9c8758eb55>)[#text("(1)")]#text(" and some basic calculus to conclude that these curves have zero torsion and are thus planar curves. Some further manipulation using ")#link(<tao-93ce248b8b9c8758eb55>)[#text("(1)")]#text(" (now just to second order instead of third) then shows that these curves are in fact straight lines, giving the ruling on the surface.")

#text("Update: Janos Kollar has informed me that the above theorem was essentially known to Monge in 1809; see his ")#link("http://arxiv-web3.library.cornell.edu/abs/1404.4613")[#text("recent arXiv note")]#text(" for more details.")

#text("I thank Larry Guth and Micha Sharir for conversations leading to this post.")

#metadata(none) <tao-a292a53b5e898fb68115>

#heading(level: 1)[#strong[#text(" — 1. Proof — ")]]

#text("Let ")#mi("{M}")#text(" denote the smooth points of ")#mi("{Z_{{\\bf R},2}(f)}")#text(", then ")#mi("{M}")#text(" is a smooth surface that is a Zariski open dense subset of ")#mi("{Z_{{\\bf R},2}(f)}")#text(", and hence Zariski dense in ")#mi("{Z_{\\bf C}(f)}")#text(". We consider the projective tangent bundle ")#mi("{PTM}")#text(" of ")#mi("{M}")#text("; this is a smooth three-dimensional manifold, which is a bundle of copies of the projective line ")#mi("{P^1}")#text(" over ")#mi("{M}")#text(", with elements ")#mi("{(x, [v_x])}")#text(" consisting of a point ")#mi("{x}")#text(" in ")#mi("{M}")#text(" and the projective class of a direction ")#mi("{v_x}")#text(" that is tangent to ")#mi("{M}")#text(" at ")#mi("{x}")#text(" and is non-zero. Since ")#mi("{P^1}")#text(" and ")#mi("{M}")#text(" are both irreducible varieties, it is easy to see that ")#mi("{PTM}")#text(" is also an irreducible variety.")

#text("Inside ")#mi("{PTM}")#text(", we consider the subset ")#mi("{Flec}")#text(" of points ")#mi("{(x,[v])}")#text(" which obey the flecnode condition ")#link(<tao-93ce248b8b9c8758eb55>)[#text("(1)")]#text(" for ")#mi("{j=0,1,2,3}")#text(". By hypothesis, the projection of ")#mi("{Flec}")#text(" to ")#mi("{M}")#text(" is Zariski dense. On the other hand, ")#mi("{Flec}")#text(" is clearly an algebraic set. Thus the dimension of ")#mi("{Flec}")#text(" is at least ")#mi("{2}")#text(", and there is at least one component whose projection to ")#mi("{M}")#text(" is two-dimensional (i.e. is dominant). In particular we can find an irreducible algebraic surface ")#mi("{S}")#text(" in ")#mi("{Flec}")#text(" whose projection to ")#mi("{M}")#text(" is open dense (not just in the Zariski sense, but also in the differential geometry sense). By removing the singular points of ")#mi("{S}")#text(", we may assume that ")#mi("{S}")#text(" is a smooth surface.")

#text("We now claim that the projection map ")#mi("{\\pi: S \\rightarrow M}")#text(" is generically a local diffeomorphism, thus ")#mi("{D\\pi(x,[v_x])}")#text(" has full rank for a Zariski dense set of points ")#mi("{(x,[v_x])}")#text(" in ")#mi("{S}")#text(". This is a simple consequence of ")#link("http://en.wikipedia.org/wiki/Sard%27s_theorem")[#text("Sard’s theorem")]#text(", but for our purposes it is also instructive to see an ODE proof: if ")#mi("{D\\pi}")#text(" fails to have full rank generically, then it must have rank one generically or rank zero generically. If it has rank one generically, one can use the ")#link("http://en.wikipedia.org/wiki/Picard_existence_theorem")[#text("Picard existence theorem")]#text(" to locally foliate an open dense subset of ")#mi("{S}")#text(" by curves ")#mi("{\\gamma: (-\\epsilon,\\epsilon) \\rightarrow S}")#text(" with the property that for each ")#mi("{t \\in(-\\epsilon,\\epsilon)}")#text(", the derivative ")#mi("{\\gamma^{\\prime}(t)}")#text(" lies in the kernel of ")#mi("{D\\pi(\\gamma(t))}")#text(", so that if we write ")#mi("{\\gamma(t) = (x(t), [v_x(t)])}")#text(", then ")#mi("{x^{\\prime}(t) = 0}")#text(" for all ")#mi("{t}")#text(", and so ")#mi("{x(t)}")#text(" is constant; thus the curves each lie in a single fibre of ")#mi("{\\pi}")#text(". This locally describes ")#mi("{S}")#text(" as a one-dimensional smooth family of curves inside the fibre of ")#mi("{\\pi}")#text(", and so the image ")#mi("{\\pi(S)}")#text(" is locally one-dimensional, contradicting the two-dimensional nature of ")#mi("{\\pi(S)}")#text(". A similar argument works when ")#mi("{D\\pi}")#text(" has rank zero generically.")

#text("Since ")#mi("{\\pi: S \\rightarrow M}")#text(" is a local diffeomorphism generically, we may apply the ")#link("http://en.wikipedia.org/wiki/Inverse_function_theorem")[#text("inverse function theorem")]#text(" to conclude that on an open dense subset of ")#mi("{M}")#text(", we can locally invert this map, which in particular gives ")#emph[#text("smooth")]#text(" local maps ")#mi("{x \\mapsto v_x}")#text(" from open subsets of ")#mi("{M}")#text(" to unit tangent vectors ")#mi("{v_x}")#text(" at ")#mi("{x}")#text(" such that the flecnode condition ")#link(<tao-93ce248b8b9c8758eb55>)[#text("(1)")]#text(" is satisfied for all such ")#mi("{x}")#text(" and ")#mi("{j=0,1,2,3}")#text(".")

#text("By the ")#link("http://en.wikipedia.org/wiki/Picard_existence_theorem")[#text("Picard existence theorem")]#text(", we may thus locally foliate ")#mi("{M}")#text(" by curves ")#mi("{\\gamma: (-\\epsilon,\\epsilon) \\rightarrow M}")#text(" with the property that")

#align(center)[#tao-fit-display[#mitex("\\gamma^{\\prime}(t) = v_{\\gamma(t)}")]]

#text("for all ")#mi("{t \\in (-\\epsilon,\\epsilon)}")#text("; thus ")#mi("{\\gamma}")#text(" has unit speed and is always tangent to a flecnode direction. Thus, by ")#link(<tao-93ce248b8b9c8758eb55>)[#text("(1)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\frac{d^j}{ds^j} f( \\gamma(t) + s \\gamma^{\\prime}(t) )|_{s=0} = 0")]]

#text("for ")#mi("{j=0,1,2,3}")#text(". Expanding this out in coordinates by the chain rule (and using the ")#link("http://en.wikipedia.org/wiki/Einstein_notation")[#text("usual summation conventions")]#text("), using ")#mi("{\\gamma^1,\\gamma^2,\\gamma^3}")#text(" to denote the components of ")#mi("{\\gamma}")#text(", and ")#mi("{f_i = \\frac{d}{dx_i} f(x)}")#text(" to denote the first partial derivatives of ")#mi("{f}")#text(" for ")#mi("{i=1,2,3}")#text(", ")#mi("{f_{ij} = \\frac{d^2}{dx_i dx_j} f(x)}")#text(" to denote the second partial derivatives, and so forth, we have ")#metadata(none) <tao-865ab0d317f36965e43d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("f( \\gamma(t) ) = 0")]]



#text(" ")#metadata(none) <tao-3f524cdc07a11d7c6220>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\gamma^{\\prime}(t)^i f_i( \\gamma(t) ) = 0")]]



#text(" ")#metadata(none) <tao-e4ab4e3b1493d5a997b4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\gamma^{\\prime}(t)^i \\gamma^{\\prime}(t)^j f_{ij}( \\gamma(t) ) = 0")]]



#text(" and ")#metadata(none) <tao-625e0f649de27800fc3b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\gamma^{\\prime}(t)^i \\gamma^{\\prime}(t)^j \\gamma^{\\prime}(t)^k f_{ijk}( \\gamma(t) ) = 0.")]]



#text(" We can obtain further differential equations by differentiating the above equations in ")#mi("{t}")#text(". For instance, if we differentiate ")#link(<tao-3f524cdc07a11d7c6220>)[#text("(3)")]#text(" in ")#mi("{t}")#text(" we obtain")

#align(center)[#tao-fit-display[#mitex("\\gamma^{\\prime\\prime}(t)^i f_i(\\gamma(t)) + \\gamma^{\\prime}(t)^i \\gamma^{\\prime}(t)^j f_{ij}(\\gamma(t)) = 0")]]

#text("and hence by ")#link(<tao-e4ab4e3b1493d5a997b4>)[#text("(4)")]#text(" ")#metadata(none) <tao-4322f5485ef15b227987>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\gamma^{\\prime\\prime}(t)^i f_i(\\gamma(t)) = 0.")]]



#text(" Similarly, if we differentiate ")#link(<tao-e4ab4e3b1493d5a997b4>)[#text("(4)")]#text(" in ")#mi("{t}")#text(" we obtain")

#align(center)[#tao-fit-display[#mitex("2 \\gamma^{\\prime\\prime}(t)^i \\gamma^{\\prime}(t)^j f_{ij}(\\gamma(t)) + \\gamma^{\\prime}(t)^i \\gamma^{\\prime}(t)^j \\gamma^{\\prime}(t)^k f_{ijk}( \\gamma(t) ) = 0")]]

#text("and hence by ")#link(<tao-625e0f649de27800fc3b>)[#text("(5)")]#text(" ")#metadata(none) <tao-ee599e81533f0990eed7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\gamma^{\\prime\\prime}(t)^i \\gamma^{\\prime}(t)^j f_{ij}(\\gamma(t)) = 0.")]]



#text(" Finally, if we differentiate ")#link(<tao-4322f5485ef15b227987>)[#text("(6)")]#text(" in ")#mi("{t}")#text(" we obtain")

#align(center)[#tao-fit-display[#mitex("\\gamma^{\\prime\\prime\\prime}(t)^i f_i(\\gamma(t)) + \\gamma^{\\prime\\prime}(t)^i \\gamma^{\\prime}(t)^j f_{ij}(\\gamma(t)) = 0")]]

#text("and hence by ")#link(<tao-ee599e81533f0990eed7>)[#text("(7)")]#text(" ")#metadata(none) <tao-f90c684589bc4ecddb0c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\gamma^{\\prime\\prime\\prime}(t)^i f_i(\\gamma(t)) = 0.")]]



#text(" The equations ")#link(<tao-3f524cdc07a11d7c6220>)[#text("(3)")]#text(", ")#link(<tao-4322f5485ef15b227987>)[#text("(6)")]#text(", ")#link(<tao-f90c684589bc4ecddb0c>)[#text("(8)")]#text(" have a simple geometric interpretation: the first three derivatives ")#mi("{\\gamma^{\\prime}(t), \\gamma^{\\prime\\prime}(t), \\gamma^{\\prime\\prime\\prime}(t)}")#text(" are all orthogonal to the gradient ")#mi("{\\nabla f(\\gamma(t))}")#text(". Generically, this gradient is non-zero, and we are in three dimensions, so we conclude that ")#mi("{\\gamma^{\\prime}(t), \\gamma^{\\prime\\prime}(t), \\gamma^{\\prime\\prime\\prime}(t)}")#text(" are always coplanar. Equivalently, the ")#link("http://en.wikipedia.org/wiki/Torsion_of_curves")[#text("torsion of the curve")]#text(" ")#mi("{\\gamma}")#text(" vanishes, and hence the curve ")#mi("{\\gamma}")#text(" is necessarily planar (locally, at least). Another way to see this is to start with the identity")

#align(center)[#tao-fit-display[#mitex("\\partial_t ( \\gamma^{\\prime}(t) \\times \\gamma^{\\prime\\prime}(t) ) = \\gamma^{\\prime}(t) \\times \\gamma^{\\prime\\prime\\prime}(t),")]]

#text("where ")#mi("{\\times}")#text(" is the cross product, and conclude that ")#mi("{\\partial_t ( \\gamma^{\\prime}(t) \\times \\gamma^{\\prime\\prime}(t) )}")#text(" is a scalar multiple of ")#mi("{\\gamma^{\\prime}(t) \\times \\gamma^{\\prime\\prime}(t)}")#text(" whenever it is non-vanishing, which by ")#link("http://en.wikipedia.org/wiki/Gronwall's_inequality")[#text("Gronwall’s inequality")]#text(" shows that ")#mi("{\\gamma^{\\prime}(t) \\times \\gamma^{\\prime\\prime}(t)}")#text(" has fixed orientation whenever it is non-vanishing.")

#text("So there is a plane ")#mi("{P}")#text(" in ")#mi("{{\\bf R}^3}")#text(" in which ")#mi("{\\gamma}")#text(" locally lies. If ")#mi("{f}")#text(" vanished on this plane, then ")#mi("{Z_{{\\bf R},2}(f)}")#text(", being irreducible, would be just ")#mi("{P}")#text(" and we would be done, so we may assume that ")#mi("{f}")#text(" is non-vanishing here, thus ")#mi("{Z_{{\\bf R},2}(f) \\cap P}")#text(" is at most one-dimensional. On the other hand, ")#link(<tao-3f524cdc07a11d7c6220>)[#text("(3)")]#text(", ")#link(<tao-4322f5485ef15b227987>)[#text("(6)")]#text(" show that ")#mi("{\\gamma^{\\prime}, \\gamma^{\\prime\\prime}}")#text(" are both orthogonal to the gradient of ")#mi("{f}")#text(" restricted to ")#mi("{P}")#text(", which is generically non-zero; as we now only have two dimensions, this implies that ")#mi("{\\gamma^{\\prime}, \\gamma^{\\prime\\prime}}")#text(" are parallel. Thus the ")#link("http://en.wikipedia.org/wiki/Curvature")[#text("curvature")]#text(" of ")#mi("{\\gamma}")#text(" now also vanishes, which implies that ")#mi("{\\gamma}")#text(" is a straight line. Hence we have locally foliated at least a small open neighbourhood in ")#mi("{M}")#text(" by straight lines, which ensures that ")#mi("{M}")#text(" is ruled as desired.")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3edc2b5793392836af950eeb23fe4605cd1a49edfd489217490ae36ad4439b53-0befbbaa0c92eb31ff3b7ad1eb168e3471bcece25afb5f3e4263ee0f85a8dc49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nets Katz")]], [#link("https://terrytao.wordpress.com/2014/03/28/the-cayley-salmon-theorem-via-classical-differential-geometry/#comment-280158")[#strong[#text("Nets Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2014")])]

#text("Compare with Art 437 of Salmon’s Treatise of Analytic Geometry in Three Dimensions volume 2 and is on pages 18-20 of that volume.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3edc2b5793392836af950eeb23fe4605cd1a49edfd489217490ae36ad4439b53-0befbbaa0c92eb31ff3b7ad1eb168e3471bcece25afb5f3e4263ee0f85a8dc49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nets Katz")]], [#link("https://terrytao.wordpress.com/2014/03/28/the-cayley-salmon-theorem-via-classical-differential-geometry/#comment-280180")[#strong[#text("Nets Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2014")])]

#text("I mean his only crime is that he uses p,q, r,s,t, \\alpha \\beta, \\gamma, \\delta to denote components of the 3-jet of the surface, and now 160 years later, no one will use his textbook.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b544fbea8487108c4c9dcb3056f26fbf7cc559f7a53708463f9c918f339b4bf-40fc3c7ec90a74401940f28a09703bae5dc816501a60c66655a2d9d6590201fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of belwas")]], [#link("https://terrytao.wordpress.com/2014/03/28/the-cayley-salmon-theorem-via-classical-differential-geometry/#comment-280188")[#strong[#text("belwas")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2014")])]

#text("dear terry please change: ‘I think Larry Guth and Micha Sharir’ to I thank")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c935d3e0b69c3fe73a864a2de52513750618e1267ad7f7e5046377635d58c4ca-ae25666e2277e547f496e73140b31709b4b8ce234d70b62cbc1c158f9aea36c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomcircle")]], [#link("https://terrytao.wordpress.com/2014/03/28/the-cayley-salmon-theorem-via-classical-differential-geometry/#comment-280498")[#strong[#text("tomcircle")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2014")])]

#text("Reblogged this on ")#link("http://tomcircle.wordpress.com/2014/03/29/the-cayley-salmon-theorem-via-classical-differential-geometry/")[#text("Math Online Tom Circle")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b9d2b471a95950cf9ab900a2a956433a802e53dd7dce19b8f99e969eecbfb6d-928b219cdc034ba412fab685a5c24ece80537934e15e706cc872bf337f74deba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of allenknutson")]], [#link("https://terrytao.wordpress.com/2014/03/28/the-cayley-salmon-theorem-via-classical-differential-geometry/#comment-281633")[#strong[#text("allenknutson")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2014")])]

#text("I don’t understand the statement near the top, “We’ll assume the 2-d oomponent is nonempty, and therefore f is absolutely irreducible.” What about f = x_1 x_2 x_3? Do you maybe want irreducible => absolutely irreducible?")

#emph[#text("[f is assumed irreducible in the first line of the post – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bdb7190f26092729631bbc0b729506c85a298ce6af17e6ba7de6adad18926791-02e18e36e67edfdb10c63418998e57703a3ece2e906e012efedadbbea29ac251.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomsim")]], [#link("https://terrytao.wordpress.com/2014/03/28/the-cayley-salmon-theorem-via-classical-differential-geometry/#comment-281948")[#strong[#text("tomsim")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2014")])]

#text("Secondlast Intro Paragraph contains a “clsasical” typo.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mustafa")]], [#link("https://terrytao.wordpress.com/2014/03/28/the-cayley-salmon-theorem-via-classical-differential-geometry/#comment-285638")[#strong[#text("Mustafa")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2014")])]

#text("Is there a non-commutative analog of the Cayley-Salmon theorem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/03/28/the-cayley-salmon-theorem-via-classical-differential-geometry/#comment-286763")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2014")])]

#text("In paragraph 2 do you mean “…Zariski open dense *set* of points…”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/03/28/the-cayley-salmon-theorem-via-classical-differential-geometry/#comment-459703")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2015")])]

#text("Dear Tao, surely I don’t understand, but the example after theorem 1, the saddle, seems doubly ruled, like z=xy.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/03/28/the-cayley-salmon-theorem-via-classical-differential-geometry/#comment-459705")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2015")])]

#text("Oh, that’s a bit unfortunate. But one can perturb the saddle a little bit while still keeping it negatively curved (say, near the origin) while destroying its ruledness; I’ve added a remark to this effect in the post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/03/28/the-cayley-salmon-theorem-via-classical-differential-geometry/#comment-613975")[#strong[#text("19th Century Precursors of Polynomial Methods – Some Plane Truths")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2020")]

#text("[…] can consider results such as the Monge-Cayley-Salmon theorem. However, for simplicity, let’s stick to shorter and more elementary proofs. Pascal’s […]")
]
