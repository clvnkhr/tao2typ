// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/
// Converted to Typst by tao2typ: "2026-10-14T16:37:47.110676+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "275A, Notes 0: Foundations of probability theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("275A, Notes 0: Foundations of probability theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 September 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/")[#text("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Starting this week, I will be teaching an ")#link("https://ccle.ucla.edu/mod/page/view.php?id=834267")[#text("introductory graduate course (Math 275A)")]#text(" on probability theory here at UCLA. While I find myself ")#emph[#text("using")]#text(" probabilistic methods routinely nowadays in my research (for instance, the probabilistic concept of ")#link("https://en.wikipedia.org/wiki/Entropy_(information_theory)")[#text("Shannon entropy")]#text(" played a crucial role in my ")#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/")[#text("recent paper on the Chowla and Elliott conjectures")]#text(", and random multiplicative functions similarly played a central role in the ")#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/")[#text("paper on the Erdos discrepancy problem")]#text("), this will actually be the first time I will be ")#emph[#text("teaching")]#text(" a course on probability itself (although I did give a ")#link("https://terrytao.wordpress.com/category/teaching/254a-random-matrices/")[#text("course on random matrix theory")]#text(" some years ago that presumed familiarity with graduate-level probability theory). As such, I will be relying primarily on an existing textbook, in this case Durrett’s ")#link("https://sites.math.duke.edu/~rtd/PTE/pte.html")[#text("Probability: Theory and Examples")]#text(". I still need to prepare lecture notes, though, and so I thought I would continue my practice of putting my notes online, although in this particular case they will be less detailed or complete than with other courses, as they will mostly be focusing on those topics that are not already comprehensively covered in the text of Durrett. Below the fold are my first such set of notes, concerning the classical measure-theoretic foundations of probability. (I wrote on these foundations also in ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("this previous blog post")]#text(", but in that post I already assumed that the reader was familiar with measure theory and basic probability, whereas in this course not every student will have a strong background in these areas.)")

#text("Note: as this set of notes is primarily concerned with foundational issues, it will contain a large number of pedantic (and nearly trivial) formalities and philosophical points. We dwell on these technicalities in this set of notes primarily so that they are out of the way in later notes, when we work with the actual mathematics of probability, rather than on the supporting foundations of that mathematics. In particular, the excessively formal and philosophical language in this set of notes will not be replicated in later notes.")

#metadata(none) <tao-b8af6ea7317086e5afac>

#heading(level: 1)[#strong[#text(" — 1. Some philosophical generalities — ")]]

#text("By default, mathematical reasoning is understood to take place in a ")#emph[#text("deterministic")]#text(" mathematical universe. In such a universe, any given mathematical statement ")#mi("{S}")#text(" (that is to say, a sentence with no free variables) is either true or false, with no intermediate truth value available. Similarly, any deterministic variable ")#mi("{x}")#text(" can take on only one specific value at a time.")

#text("However, for a variety of reasons, both within pure mathematics and in the applications of mathematics to other disciplines, it is often desirable to have a rigorous mathematical framework in which one can discuss ")#emph[#text("non-deterministic")]#text(" statements and variables – that is to say, statements which are not always true or always false, but in some intermediate state, or variables that do not take one particular value or another with definite certainty, but are again in some intermediate state. In probability theory, which is by far the most widely adopted mathematical framework to formally capture the concept of non-determinism, non-deterministic statements are referred to as ")#emph[#text("events")]#text(", and non-deterministic variables are referred to as ")#emph[#text("random variables")]#text(". In the standard foundations of probability theory, as laid out by Kolmogorov, we can then ")#emph[#text("model")]#text(" these events and random variables by introducing a ")#link("https://en.wikipedia.org/wiki/Sample_space")[#text("sample space")]#text(" (which will be given the structure of a ")#link("https://en.wikipedia.org/wiki/Probability_space")[#text("probability space")]#text(") to capture all the ambient sources of randomness; events are then modeled as measurable subsets of this sample space, and random variables are modeled as measurable functions on this sample space. (We will briefly discuss a more abstract way to set up probability theory, as well as other frameworks to capture non-determinism than classical probability theory, at the end of this set of notes; however, the rest of the course will be concerned exclusively with classical probability theory using the orthodox Kolmogorov models.)")

#text("Note carefully that sample spaces (and their attendant structures) will be used to ")#emph[#text("model")]#text(" probabilistic concepts, rather than to actually ")#emph[#text("be")]#text(" the concepts themselves. This distinction (a mathematical analogue of the ")#link("https://en.wikipedia.org/wiki/Map%E2%80%93territory_relation")[#text("map-territory")]#text(" distinction in philosophy) actually is implicit in much of modern mathematics, when we make a distinction between an abstract version of a mathematical object, and a concrete representation (or ")#emph[#text("model")]#text(") of that object. For instance:")

#list(
[#text("In linear algebra, we distinguish between an ")#link("https://en.wikipedia.org/wiki/Vector_space")[#text("abstract vector space")]#text(" ")#mi("{V}")#text(", and a concrete system of coordinates ")#mi("{\\phi: V \\rightarrow {\\bf R}^n}")#text(" given by some ")#link("https://en.wikipedia.org/wiki/Basis_(linear_algebra)")[#text("basis")]#text(" of ")#mi("{V}")#text(".")],
[#text("In group theory, we distinguish between an ")#link("https://en.wikipedia.org/wiki/Group_(mathematics)")[#text("abstract group")]#text(" ")#mi("{G}")#text(", and a concrete ")#link("https://en.wikipedia.org/wiki/Group_representation")[#text("representation of that group")]#text(" ")#mi("{\\phi: G \\rightarrow \\text{Aut}(X)}")#text(" as isomorphisms on some space ")#mi("{X}")#text(".")],
[#text("In differential geometry, we distinguish between an ")#link("https://en.wikipedia.org/wiki/Manifold")[#text("abstract manifold")]#text(" ")#mi("{M}")#text(", and a concrete ")#link("https://en.wikipedia.org/wiki/Atlas_(topology)")[#text("atlas of coordinate systems")]#text(" that coordinatises that manifold.")],
[#text("Though it is rarely mentioned explicitly, the abstract ")#link("https://en.wikipedia.org/wiki/Number#Classification")[#text("number systems")]#text(" such as ")#mi("{{\\bf N}, {\\bf Z}, {\\bf Q}, {\\bf R}, {\\bf C}}")#text(" are distinguished from the concrete ")#link("https://en.wikipedia.org/wiki/Numeral_system")[#text("numeral systems")]#text(" (e.g. the decimal or binary systems) that are used to represent them (this distinction is particularly useful to keep in mind when faced with the ")#link("https://en.wikipedia.org/wiki/0.999...")[#text("infamous identity")]#text(" ")#mi("{0.999\\dots = 1}")#text(", or when switching from one numeral representation system to another).")]
)

#text("The distinction between abstract objects and concrete models can be fairly safely discarded if one is only going to use a single model for each abstract object, particularly if that model is “canonical” in some sense. However, one needs to keep the distinction in mind if one plans to switch between different models of a single object (e.g. to perform change of basis in linear algebra, change of coordinates in differential geometry, or ")#link("https://en.wikipedia.org/wiki/Base_change")[#text("base change")]#text(" in algebraic geometry). As it turns out, in probability theory it is often desirable to change the sample space model (for instance, one could ")#emph[#text("extend")]#text(" the sample space by adding in new sources of randomness, or one could couple together two systems of random variables by ")#emph[#text("joining")]#text(" their sample space models together). Because of this, we will take some care in this foundational set of notes to distinguish probabilistic concepts (such as events and random variables) from their sample space models. (But we may be more willing to conflate the two in later notes, once the foundational issues are out of the way.)")

#text("From a foundational point of view, it is often logical to begin with some axiomatic description of the abstract version of a mathematical object, and discuss the concrete representations of that object later; for instance, one could start with the axioms of an abstract group, and then later consider concrete representations of such a group by permutations, invertible linear transformations, and so forth. This approach is often employed in the more algebraic areas of mathematics. However, there are at least two other ways to present these concepts which can be preferable from a pedagogical point of view. One way is to start with the concrete representations as motivating examples, and only later give the abstract object that these representations are modeling; this is how linear algebra, for instance, is often taught at the undergraduate level, by starting first with ")#mi("{{\\bf R}^2}")#text(", ")#mi("{{\\bf R}^3}")#text(", and ")#mi("{{\\bf R}^n}")#text(", and only later introducing the abstract vector spaces. Another way is to avoid the abstract objects altogether, and focus exclusively on concrete representations, but taking care to emphasise how these representations transform when one switches from one representation to another. For instance, in general relativity courses in undergraduate physics, it is not uncommon to see tensors presented purely through the concrete representation of coordinates indexed by multiple indices, with the transformation of such tensors under changes of variable carefully described; the abstract constructions of tensors and tensor spaces using operations such as tensor product and duality of vector spaces or vector bundles are often left to an advanced differential geometry class to set up properly.")

#text("The foundations of probability theory are usually presented (almost by default) using the last of the above three approaches; namely, one talks almost exclusively about sample space models for probabilistic concepts such as events and random variables, and only occasionally dwells on the need to extend or otherwise modify the sample space when one needs to introduce new sources of randomness (or to forget about some existing sources of randomness). However, much as in differential geometry one tends to work with manifolds without specifying any given atlas of coordinate charts, in probability one usually manipulates events and random variables without explicitly specifying any given sample space. For a student raised exclusively on concrete sample space foundations of probability, this can be a bit confusing, for instance it can give the misconception that any given random variable is somehow associated to its own unique sample space, with different random variables possibly living on different sample spaces, which often leads to nonsense when one then tries to combine those random variables together. Because of such confusions, we will try to take particular care in these notes to separate probabilistic concepts from their sample space models.")

#heading(level: 1)[#strong[#text(" — 2. A simple class of models: discrete probability spaces — ")]]

#text("The simplest models of probability theory are those generated by ")#emph[#text("discrete probability spaces")]#text(", which are adequate models for many applications (particularly in combinatorics and other areas of discrete mathematics), and which already capture much of the essence of probability theory while avoiding some of the finer measure-theoretic subtleties. We thus begin by considering discrete sample space models.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Discrete probability theory)")]#text(" A ")#emph[#text("discrete probability space")]#text(" ")#mi("{\\Omega = (\\Omega, (p_\\omega)_{\\omega \\in \\Omega})}")#text(" is an at most countable set ")#mi("{\\Omega}")#text(" (whose elements ")#mi("{\\omega \\in \\Omega}")#text(" will be referred to as ")#emph[#text("outcomes")]#text("), together with a non-negative real number ")#mi("{p_\\omega}")#text(" assigned to each outcome ")#mi("{\\omega}")#text(" such that ")#mi("{\\sum_{\\omega \\in \\Omega} p_\\omega = 1}")#text("; we refer to ")#mi("{p_\\omega}")#text(" as the ")#emph[#text("probability")]#text(" of the outcome ")#mi("{\\omega}")#text(". The set ")#mi("{\\Omega}")#text(" itself, without the structure ")#mi("{(p_\\omega)_{\\omega \\in \\Omega}}")#text(", is often referred to as the ")#emph[#text("sample space")]#text(", though we will often abuse notation by using the sample space ")#mi("{\\Omega}")#text(" to refer to the entire discrete probability space ")#mi("{(\\Omega, (p_\\omega)_{\\omega \\in \\Omega})}")#text(".")

#text("In discrete probability theory, we choose an ambient discrete probability space ")#mi("{\\Omega}")#text(" as the randomness model. We then model ")#emph[#text("events")]#text(" ")#mi("{E}")#text(" by subsets ")#mi("{E_\\Omega}")#text(" of the sample space ")#mi("{\\Omega}")#text(". The ")#emph[#text("probability")]#text(" ")#mi("{{\\bf P}(E)}")#text(" of an event ")#mi("{E}")#text(" is defined to be the quantity")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(E) := \\sum_{\\omega \\in E_\\Omega} p_\\omega;")]]

#text("note that this is a real number in the interval ")#mi("{[0,1]}")#text(". An event ")#mi("{E}")#text(" is ")#emph[#text("surely true")]#text(" or is the ")#emph[#text("sure event")]#text(" if ")#mi("{E_\\Omega = \\Omega}")#text(", and is ")#emph[#text("surely false")]#text(" or is the ")#emph[#text("empty event")]#text(" if ")#mi("{E_\\Omega =\\emptyset}")#text(".")

#text("We model random variables ")#mi("{X}")#text(" taking values in the range ")#mi("{R}")#text(" by functions ")#mi("{X_\\Omega: \\Omega \\rightarrow R}")#text(" from the sample space ")#mi("{\\Omega}")#text(" to the range ")#mi("{R}")#text(". Random variables taking values in ")#mi("{{\\bf R}}")#text(" will be called ")#emph[#text("real random variables")]#text(" or ")#emph[#text("random real numbers")]#text(". Similarly for random variables taking values in ")#mi("{{\\bf C}}")#text(". We refer to real and complex random variables collectively as ")#emph[#text("scalar random variables")]#text(".")

#text("We consider two events ")#mi("{E,F}")#text(" to be equal if they are modeled by the same set: ")#mi("{E=F \\iff E_\\Omega = F_\\Omega}")#text(". Similarly, two random variables ")#mi("{X,Y}")#text(" taking values in a common range ")#mi("{R}")#text(" are considered to be equal if they are modeled by the same function: ")#mi("{X=Y \\iff X_\\Omega = Y_\\Omega}")#text(". In particular, if the discrete sample space ")#mi("{\\Omega}")#text(" is understood from context, we will usually abuse notation by identifying an event ")#mi("{E}")#text(" with its model ")#mi("{E_\\Omega}")#text(", and similarly identify a random variable ")#mi("{X}")#text(" with its model ")#mi("{X_\\Omega}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can view classical (deterministic) mathematics as the special case of discrete probability theory in which ")#mi("{\\Omega}")#text(" is a singleton set (there is only one outcome ")#mi("{\\omega}")#text("), and the probability assigned to the single outcome ")#mi("{\\omega}")#text(" in ")#mi("{\\Omega}")#text(" is ")#mi("{1}")#text(": ")#mi("{p_\\omega = 1}")#text(". Then there are only two events (the surely true and surely false events), and a random variable in ")#mi("{R}")#text(" can be identified with a deterministic element of ")#mi("{R}")#text(". Thus we can view probability theory as a generalisation of deterministic mathematics.")
]

#text("As discussed in the preceding section, the distinction between a collection of events and random variable and its models becomes important if one ever wishes to modify the sample space, and in particular to ")#emph[#text("extend")]#text(" the sample space to a larger space that can accommodate new sources of randomness (an operation which we will define formally later, but which for now can be thought of as an analogue to change of basis in linear algebra, coordinate change in differential geometry, or ")#link("https://en.wikipedia.org/wiki/Base_change")[#text("base change")]#text(" in algebraic geometry). This is best illustrated with a simple example.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3 (Extending the sample space)")]#text(" Suppose one wishes to model the outcome ")#mi("{X}")#text(" of rolling a single, unbiased six-sided die using discrete probability theory. One can do this by choosing the discrete probability space ")#mi("{\\Omega}")#text(" to be the six-element set ")#mi("{\\{1,2,3,4,5,6\\}}")#text(", with each outcome ")#mi("{i \\in \\{1,2,3,4,5,6\\}}")#text(" given an equal probability of ")#mi("{p_i := 1/6}")#text(" of occurring; this outcome ")#mi("{i}")#text(" may be interpreted as the state in which the die roll ")#mi("{X}")#text(" ended up being equal to ")#mi("{i}")#text(". The outcome ")#mi("{X}")#text(" of rolling a die may then be identified with the identity function ")#mi("{X_\\Omega: \\Omega \\rightarrow \\{1,\\dots,6\\}}")#text(", defined by ")#mi("{X_\\Omega(i) := i}")#text(" for ")#mi("{i \\in \\Omega}")#text(". If we let ")#mi("{E}")#text(" be the event that the outcome ")#mi("{X}")#text(" of rolling the die is an even number, then with this model ")#mi("{\\Omega}")#text(" we have ")#mi("{E_\\Omega = \\{2,4,6\\}}")#text(", and")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(E) = \\sum_{\\omega \\in E_\\Omega} p_\\omega = 3 \\times \\frac{1}{6} = \\frac{1}{2}.")]]

#text("Now suppose that we wish to roll the die again to obtain a second random variable ")#mi("{Y}")#text(". The sample space ")#mi("{\\Omega = \\{1,2,3,4,5,6\\}}")#text(" is inadequate for modeling both the original die roll ")#mi("{X}")#text(" and the second die roll ")#mi("{Y}")#text(". To accommodate this new source of randomness, we can then move to the larger discrete probability space ")#mi("{\\Omega^{\\prime} := \\{1,\\dots,6\\} \\times \\{1,\\dots,6\\}}")#text(", where each outcome ")#mi("{(i,j) \\in \\Omega^{\\prime}}")#text(" now having probability ")#mi("{p^{\\prime}_{(i,j)} := \\frac{1}{36}}")#text("; this outcome ")#mi("{(i,j)}")#text(" can be interpreted as the state in which the die roll ")#mi("{X}")#text(" ended up being ")#mi("{i}")#text(", and the die roll ")#mi("{Y}")#text(" ended up being ")#mi("{j}")#text(". The random variable ")#mi("{X}")#text(" is now modeled by a new function ")#mi("{X_{\\Omega^{\\prime}}: \\Omega^{\\prime} \\rightarrow \\{1,\\dots,6\\}}")#text(" defined by ")#mi("{X_{\\Omega^{\\prime}}(i,j) := i}")#text(" for ")#mi("{(i,j) \\in \\Omega^{\\prime}}")#text("; the random variable ")#mi("{Y}")#text(" is similarly modeled by the function ")#mi("{Y_{\\Omega^{\\prime}}: \\Omega^{\\prime} \\rightarrow \\{1,\\dots,6\\}}")#text(" defined by ")#mi("{Y_{\\Omega^{\\prime}}(i,j) := j}")#text(" for ")#mi("{(i,j) \\in \\Omega^{\\prime}}")#text(". The event ")#mi("{E}")#text(" that ")#mi("{X}")#text(" is even is now modeled by the set")

#align(center)[#tao-fit-display[#mitex("E_{\\Omega^{\\prime}} = \\{2,4,6\\} \\times \\{1,2,3,4,5,6\\}.")]]

#text("This set is distinct from the previous model ")#mi("{E_\\Omega}")#text(" of ")#mi("{E}")#text(" (for instance, ")#mi("{E_{\\Omega^{\\prime}}}")#text(" has eighteen elements, whereas ")#mi("{E_\\Omega}")#text(" has just three), but the probability of ")#mi("{E}")#text(" is unchanged:")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(E) = \\sum_{\\omega^{\\prime} \\in E_{\\Omega^{\\prime}}} p^{\\prime}_{\\omega^{\\prime}} = 18 \\times\\frac{1}{36} = \\frac{1}{2}.")]]

#text("One can of course also combine together the random variables ")#mi("{X,Y}")#text(" in various ways. For instance, the sum ")#mi("{X+Y}")#text(" of the two die rolls is a random variable taking values in ")#mi("{\\{2,\\dots,12\\}}")#text("; it cannot be modeled by the sample space ")#mi("{\\Omega}")#text(", but in ")#mi("{\\Omega^{\\prime}}")#text(" it is modeled by the function")

#align(center)[#tao-fit-display[#mitex("(X+Y)_{\\Omega^{\\prime}}: (i,j) \\mapsto i+j.")]]

#text("Similarly, the event ")#mi("{X=Y}")#text(" that the two die rolls are equal cannot be modeled by ")#mi("{\\Omega}")#text(", but is modeled in ")#mi("{\\Omega^{\\prime}}")#text(" by the set")

#align(center)[#tao-fit-display[#mitex("(X=Y)_{\\Omega^{\\prime}} = \\{ (i,i): i=1,\\dots,6\\}")]]

#text("and the probability ")#mi("{{\\bf P}(X=Y)}")#text(" of this event is")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(X=Y) = \\sum_{\\omega^{\\prime} \\in (X=Y)_{\\Omega^{\\prime}}} p^{\\prime}_{\\omega^{\\prime}} = 6 \\times \\frac{1}{36} = \\frac{1}{6}.")]]

#text("We thus see that extending the probability space has also enlarged the space of events one can consider, as well as the random variables one can define, but that existing events and random variables continue to be interpretable in the extended model, and that probabilistic concepts such as the probability of an event remain unchanged by the extension of the model.")
]

#text("The set-theoretic operations on the sample space ")#mi("{\\Omega}")#text(" induce similar boolean operations on events:")

#list(
[#text("The ")#emph[#text("conjunction")]#text(" ")#mi("{E \\wedge F}")#text(" of two events ")#mi("{E,F}")#text(" is defined through the intersection of their models: ")#mi("{(E \\wedge F)_\\Omega := E_\\Omega \\cap F_\\Omega}")#text(".")],
[#text("The ")#emph[#text("disjunction")]#text(" ")#mi("{E \\vee F}")#text(" of two events ")#mi("{E,F}")#text(" is defined through the union of their models: ")#mi("{(E \\vee F)_\\Omega := E_\\Omega \\cup F_\\Omega}")#text(".")],
[#text("The ")#emph[#text("symmetric difference")]#text(" ")#mi("{E \\Delta F}")#text(" of two events ")#mi("{E,F}")#text(" is defined through the symmetric difference of their models: ")#mi("{(E \\Delta F)_\\Omega := E_\\Omega \\Delta F_\\Omega}")#text(".")],
[#text("The ")#emph[#text("complement")]#text(" ")#mi("{\\overline{E}}")#text(" of an event ")#mi("{E}")#text(" is defined through the complement of their models: ")#mi("{\\overline{E}_\\Omega := \\Omega \\backslash E_\\Omega}")#text(".")],
[#text("We say that one event ")#mi("{E}")#text(" is ")#emph[#text("contained in")]#text(" or ")#emph[#text("implies")]#text(" another event ")#mi("{F}")#text(", and write ")#mi("{E \\subset F}")#text(", if we have containment of their models: ")#mi("{E \\subset F \\iff E_\\Omega \\subset F_\\Omega}")#text(". We also write “")#mi("{F}")#text(" is true on ")#mi("{E}")#text("” synonymously with ")#mi("{E \\subset F}")#text(".")],
[#text("Two events ")#mi("{E,F}")#text(" are ")#emph[#text("disjoint")]#text(" if their conjunction is the empty event, or equivalently if their models ")#mi("{E_\\Omega, F_\\Omega}")#text(" are disjoint.")]
)

#text("Thus, for instance, the conjunction of the event that a die roll ")#mi("{X}")#text(" is even, and that it is less than ")#mi("{3}")#text(", is the event that the die roll is exactly ")#mi("{2}")#text(". As before, we will usually be in a situation in which the sample space ")#mi("{\\Omega}")#text(" is clear from context, and in that case one can safely identify events with their models, and view the symbols ")#mi("{\\vee}")#text(" and ")#mi("{\\wedge}")#text(" as being synonymous with their set-theoretic counterparts ")#mi("{\\cup}")#text(" and ")#mi("{\\cap}")#text(" (this is for instance what is done in Durrett).")

#text("With these operations, the space of all events (known as the ")#emph[#text("event space")]#text(") thus has the structure of a ")#link("https://en.wikipedia.org/wiki/Boolean_algebra")[#text("boolean algebra")]#text(" (defined below in Definition ")#link(<tao-50041f7c9fed1e0f457c>)[#text("4")]#text("). We observe that the probability ")#mi("{{\\bf P}}")#text(" is ")#emph[#text("finitely additive")]#text(" in the sense that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( E \\vee F ) = {\\bf P}(E) + {\\bf P}(F)")]]

#text("whenever ")#mi("{E,F}")#text(" are disjoint events; by induction this implies that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(E_1 \\vee \\dots \\vee E_n) = {\\bf P}(E_1) + \\dots + {\\bf P}(E_n)")]]

#text("whenever ")#mi("{E_1,\\dots,E_n}")#text(" are pairwise disjoint events. We have ")#mi("{{\\bf P}(\\emptyset)=0}")#text(" and ")#mi("{{\\bf P}(\\overline{\\emptyset})=1}")#text(", and more generally")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(\\overline{E}) = 1 - {\\bf P}(E)")]]

#text("for any event ")#mi("{E}")#text(". We also have monotonicity: if ")#mi("{E \\subset F}")#text(", then ")#mi("{{\\bf P}(E) \\leq {\\bf P}(F)}")#text(".")

#text("Now we define operations on random variables. Whenever one has a function ")#mi("{f: R \\rightarrow S}")#text(" from one range ")#mi("{R}")#text(" to another ")#mi("{S}")#text(", and a random variable ")#mi("{X}")#text(" taking values in ")#mi("{R}")#text(", one can define a random variable ")#mi("{f(X)}")#text(" taking values in ")#mi("{S}")#text(" by composing the relevant models:")

#align(center)[#tao-fit-display[#mitex("f(X)_\\Omega := f \\circ X_\\Omega,")]]

#text("thus ")#mi("{f(X)_\\Omega}")#text(" maps ")#mi("{\\omega}")#text(" to ")#mi("{f(X_\\Omega(\\omega))}")#text(" for any outcome ")#mi("{\\omega \\in \\Omega}")#text(". Given a finite number ")#mi("{X_1,\\dots,X_n}")#text(" of random variables taking values in ranges ")#mi("{R_1,\\dots,R_n}")#text(", we can form the joint random variable ")#mi("{(X_1,\\dots,X_n)}")#text(" taking values in the Cartesian product ")#mi("{R_1 \\times \\dots \\times R_n}")#text(" by concatenation of the models, thus")

#align(center)[#tao-fit-display[#mitex("(X_1,\\dots,X_n)_\\Omega: \\omega \\mapsto ((X_1)_\\Omega(\\omega),\\dots, (X_n)_{\\Omega}(\\omega)).")]]

#text("Combining these two operations, given any function ")#mi("{f: R_1 \\times \\dots \\times R_n \\rightarrow S}")#text(" of ")#mi("{n}")#text(" variables in ranges ")#mi("{R_1,\\dots,R_n}")#text(", and random variables ")#mi("{X_1,\\dots,X_n}")#text(" taking values in ")#mi("{R_1,\\dots,R_n}")#text(" respectively, we can form a random variable ")#mi("{f(X_1,\\dots,X_n)}")#text(" taking values in ")#mi("{S}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("f(X_1,\\dots,X_n)_\\Omega: \\omega \\mapsto f((X_1)_\\Omega(\\omega),\\dots, (X_n)_{\\Omega}(\\omega)).")]]

#text("Thus for instance we can add, subtract, or multiply two scalar random variables to obtain another scalar random variable.")

#text("A deterministic element ")#mi("{x}")#text(" of a range ")#mi("{R}")#text(" will (by abuse of notation) be identified with a random variable ")#mi("{x}")#text(" taking values in ")#mi("{R}")#text(", whose model in ")#mi("{\\Omega}")#text(" is constant: ")#mi("{x_\\Omega(\\omega) = x}")#text(" for all ")#mi("{\\omega \\in \\Omega}")#text(". Thus for instance ")#mi("{37}")#text(" is a scalar random variable.")

#text("Given a relation ")#mi("{F: R_1 \\times \\dots \\times R_n \\rightarrow \\{ \\text{ true}, \\text{ false}\\}}")#text(" on ")#mi("{n}")#text(" ranges ")#mi("{R_1,\\dots,R_n}")#text(", and random variables ")#mi("{X_1,\\dots,X_n}")#text(", we can define the event ")#mi("{F(X_1,\\dots,X_n)}")#text(" by setting")

#align(center)[#tao-fit-display[#mitex("F(X_1,\\dots,X_n) :=\\{ \\omega \\in \\Omega: F((X_1)_\\Omega(\\omega),\\dots,(X_n)_\\Omega(\\omega)) \\text{ true}\\}.")]]

#text("Thus for instance, for two real random variables ")#mi("{X,Y}")#text(", the event ")#mi("{X > Y}")#text(" is modeled as")

#align(center)[#tao-fit-display[#mitex("(X>Y)_\\Omega := \\{ \\omega \\in \\Omega: X_\\Omega(\\omega) > Y_\\Omega(\\omega) \\}")]]

#text("and the event ")#mi("{X=Y}")#text(" is modeled as")

#align(center)[#tao-fit-display[#mitex("(X=Y)_\\Omega := \\{ \\omega \\in \\Omega: X_\\Omega(\\omega) = Y_\\Omega(\\omega) \\}.")]]

#text("At this point we encounter a slight notational conflict between the dual role of the equality symbol ")#mi("{=}")#text(" as a logical symbol and as a binary relation: we are interpreting ")#mi("{X=Y}")#text(" both as an external equality relation between the two random variables (which is true iff the functions ")#mi("{X_\\Omega}")#text(", ")#mi("{Y_\\Omega}")#text(" are identical), and as an internal event (modeled by ")#mi("{(X=Y)_\\Omega}")#text("). However, it is clear that ")#mi("{X=Y}")#text(" is true in the external sense if and only if the internal event ")#mi("{X=Y}")#text(" is surely true. As such, we shall abuse notation and continue to use the equality symbol for both the internal and external concepts of equality (and use the modifier “surely” for emphasis when referring to the external usage).")

#text("It is clear that any equational identity concerning functions or operations on deterministic variables implies the same identity (in the external, or surely true, sense) for random variables. For instance, the commutativity of addition ")#mi("{x+y=y+x}")#text(" for deterministic real numbers ")#mi("{x,y}")#text(" immediately implies the commutativity of addition: ")#mi("{X+Y=Y+X}")#text(" is surely true for real random variables ")#mi("{X,Y}")#text("; similarly ")#mi("{X+0=X}")#text(" is surely true for all scalar random variables ")#mi("{X}")#text(", etc.. We will freely apply the usual laws of algebra for scalar random variables without further comment.")

#text("Given an event ")#mi("{E}")#text(", we can associate the ")#link("https://en.wikipedia.org/wiki/Indicator_function")[#text("indicator random variable")]#text(" ")#mi("{1_E}")#text(" (also written as ")#mi("{{\\bf I}(E)}")#text(" in some texts) to be the unique real random variable such that ")#mi("{1_E=1}")#text(" when ")#mi("{E}")#text(" is true and ")#mi("{1_E=0}")#text(" when ")#mi("{E}")#text(" is false, thus ")#mi("{(1_E)_\\Omega(\\omega)}")#text(" is equal to ")#mi("{1}")#text(" when ")#mi("{\\omega \\in E_\\Omega}")#text(" and ")#mi("{0}")#text(" otherwise. (The indicator random variable is sometimes called the ")#emph[#text("characteristic function")]#text(" in analysis, and sometimes denoted ")#mi("{\\chi_E}")#text(" instead of ")#mi("{1_E}")#text(", but we avoid using the term “characteristic function” here, as it will have an ")#link("https://en.wikipedia.org/wiki/Characteristic_function_(probability_theory)")[#text("unrelated but important meaning")]#text(" in probability theory.) We record the trivial but useful fact that Boolean operations on events correspond to arithmetic manipulations on their indicators. For instance, if ")#mi("{E,F}")#text(" are events, we have")

#tao-aligned(keep: true)[


#tao-math("1_{E \\wedge F}  & = 1_E 1_F", block: true)



#tao-math("1_{\\overline{E}}  & = 1 - 1_E", block: true)
]

#text("and the inclusion-exclusion principle ")#metadata(none) <tao-8f95ec0c5e79d05794d9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("1_{E \\vee F} = 1_E + 1_F - 1_{E \\wedge F}.")]]

#text(" In particular, if the events ")#mi("{E,F}")#text(" are disjoint, then")

#align(center)[#tao-fit-display[#mitex("1_{E \\vee F} = 1_E + 1_F.")]]

#text("Also note that ")#mi("{E \\subset F}")#text(" if and only if the assertion ")#mi("{1_E \\leq 1_F}")#text(" is surely true. We will use these identities and equivalences throughout the course without further comment.")

#text("Given a scalar random variable ")#mi("{X}")#text(", we can attempt to define the ")#link("https://en.wikipedia.org/wiki/Expected_value")[#text("expectation")]#text(" ")#mi("{{\\bf E}(X)}")#text(" through the model ")#mi("{X_\\Omega}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("{\\bf E}(X) := \\sum_{\\omega \\in \\Omega} X_\\Omega(\\omega) p_\\omega.")]]

#text("If the discrete sample space ")#mi("{\\Omega}")#text(" is finite, then this sum is always well-defined and so every scalar random variable has an expectation. If however the discrete sample space ")#mi("{\\Omega}")#text(" is infinite, the expectation may not be well defined. There are however two key cases in which one has a meaningful expectation. The first is if the random variable ")#mi("{X}")#text(" is ")#emph[#text("unsigned")]#text(", that is to say it takes values in the non-negative reals ")#mi("{[0,+\\infty)}")#text(", or more generally in the extended non-negative real line ")#mi("{[0,+\\infty]}")#text(". In that case, one can interpret the expectation ")#mi("{{\\bf E}(X)}")#text(" as an element of ")#mi("{[0,+\\infty]}")#text(". The other case is when the random variable ")#mi("{X}")#text(" is ")#emph[#text("absolutely integrable")]#text(", which means that the absolute value ")#tao-math("{\\left|X\\right|}", block: false)#text(" (which is an unsigned random variable) has finite expectation: ")#tao-math("{{\\bf E} \\left|X\\right| < \\infty}", block: false)#text(". In that case, the series defining ")#mi("{{\\bf E}(X)}")#text(" is absolutely convergent to a real or complex number (depending on whether ")#mi("{X}")#text(" was a real or complex random variable.)")

#text("We have the basic link")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(E) = {\\bf E}(1_E)")]]

#text("between probability and expectation, valid for any event ")#mi("{E}")#text(". We also have the obvious, but fundamentally important, property of ")#emph[#text("linearity of expectation")]#text(": we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E}(cX) = c {\\bf E}(X)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("{\\bf E}(X+Y) = {\\bf E}(X) + {\\bf E}(Y)")]]

#text("whenever ")#mi("{c}")#text(" is a scalar and ")#mi("{X,Y}")#text(" are scalar random variables, either under the assumption that ")#mi("{c,X,Y}")#text(" are all unsigned, or that ")#mi("{X,Y}")#text(" are absolutely integrable. Thus for instance by applying expectations to ")#link(<tao-8f95ec0c5e79d05794d9>)[#text("(1)")]#text(" we obtain the identity")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(E \\vee F) = {\\bf P}(E) + {\\bf P}(F) - {\\bf P}(E \\wedge F).")]]

#text("We close this section by noting that discrete probabilistic models stumble when trying to model ")#emph[#text("continuous")]#text(" random variables, which take on an uncountable number of values. Suppose for instance one wants to model a random real number ")#mi("{X}")#text(" drawn uniformly at random from the unit interval ")#mi("{[0,1]}")#text(", which is an uncountable set. One would then expect, for any subinterval ")#mi("{[a,b]}")#text(" of ")#mi("{[0,1]}")#text(", that ")#mi("{X}")#text(" will fall into this interval with probability ")#mi("{b-a}")#text(". Setting ")#mi("{a=b}")#text(" (or, if one wishes instead, taking a limit such as ")#mi("{b \\rightarrow a^+}")#text("), we conclude in particular that for any real number ")#mi("{a}")#text(" in ")#mi("{[0,1]}")#text(", that ")#mi("{X}")#text(" will equal ")#mi("{a}")#text(" with probability ")#mi("{0}")#text(". If one attempted to model this situation by a discrete probability model, we would find that each outcome ")#mi("{\\omega}")#text(" of the discrete sample space ")#mi("{\\Omega}")#text(" has to occur with probability ")#mi("{p_\\omega = 0}")#text(" (since for each ")#mi("{\\omega}")#text(", the random variable ")#mi("{X}")#text(" has only a single value ")#mi("{X_\\Omega(\\omega)}")#text("). But we are also requiring that the sum ")#mi("{\\sum_{\\omega \\in \\Omega} p_\\omega}")#text(" is equal to ")#mi("{1}")#text(", a contradiction. In order to address this defect we must generalise from discrete models to more general probabilistic models, to which we now turn.")

#heading(level: 1)[#strong[#text(" — 3. The Kolmogorov foundations of probability theory — ")]]

#text("We now present the more general measure-theoretic foundation of Kolmogorov which subsumes the discrete theory, while also allowing one to model continuous random variables. It turns out that in order to perform sums, limits and integrals properly, the finite additivity property of probability needs to be amplified to ")#emph[#text("countable")]#text(" additivity (but, as we shall see, ")#emph[#text("uncountable")]#text(" additivity is too strong of a property to ask for).")

#text("We begin with the notion of a measurable space. (See also this ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/")[#text("previous blog post")]#text(", which covers similar material from the perspective of a real analysis graduate class rather than a probability class.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4 (Measurable space)")]#text(" ")#metadata(none) <tao-50041f7c9fed1e0f457c>#text(" Let ")#mi("{\\Omega}")#text(" be a set. A ")#link("https://en.wikipedia.org/wiki/Boolean_algebra")[#text("Boolean algebra")]#text(" in ")#mi("{\\Omega}")#text(" is a collection ")#mi("{{\\mathcal F}}")#text(" of subsets of ")#mi("{\\Omega}")#text(" which")

#list(
[#text("contains ")#mi("{\\emptyset}")#text(" and ")#mi("{\\Omega}")#text(";")],
[#text("is closed under pairwise unions and intersections (thus if ")#mi("{E,F \\in {\\mathcal F}}")#text(", then ")#mi("{E \\cup F}")#text(" and ")#mi("{E \\cap F}")#text(" also lie in ")#mi("{{\\mathcal F}}")#text("); and")],
[#text("is closed under complements (thus if ")#mi("{E \\in {\\mathcal F}}")#text(", then ")#mi("{\\Omega \\backslash E}")#text(" also lies in ")#mi("{{\\mathcal F}}")#text(".")]
)

#text("(Note that some of these assumptions are redundant and can be dropped, thanks to ")#link("https://en.wikipedia.org/wiki/De_Morgan%27s_laws")[#text("de Morgan’s laws")]#text(".) A ")#link("https://en.wikipedia.org/wiki/Sigma-algebra")[#mi("{\\sigma}")#text("-algebra")]#text(" in ")#mi("{\\Omega}")#text(" (also known as a ")#mi("{\\sigma}")#text("-field) is a Boolean algebra ")#mi("{{\\mathcal F}}")#text(" in ")#mi("{\\Omega}")#text(" which is also")

#list(
[#text("closed under countable unions and countable intersections (thus if ")#mi("{E_1,E_2,E_3,\\dots \\in {\\mathcal F}}")#text(", then ")#mi("{\\bigcup_{n=1}^\\infty E_n \\in {\\mathcal F}}")#text(" and ")#mi("{\\bigcap_{n=1}^\\infty E_n \\in {\\mathcal F}}")#text(").")]
)

#text("Again, thanks to de Morgan’s laws, one only needs to verify closure under just countable union (or just countable intersection) in order to verify that a Boolean algebra is a ")#mi("{\\sigma}")#text("-algebra. A ")#emph[#text("measurable space")]#text(" is a pair ")#mi("{(\\Omega, {\\mathcal F})}")#text(", where ")#mi("{\\Omega}")#text(" is a set and ")#mi("{{\\mathcal F}}")#text(" is a ")#mi("{\\sigma}")#text("-algebra in ")#mi("{\\Omega}")#text(". Elements of ")#mi("{{\\mathcal F}}")#text(" are referred to as ")#emph[#text("measurable sets")]#text(" in this measurable space.")

#text("If ")#mi("{{\\mathcal F}, {\\mathcal F}^{\\prime}}")#text(" are two ")#mi("{\\sigma}")#text("-algebras in ")#mi("{\\Omega}")#text(", we say that ")#mi("{{\\mathcal F}}")#text(" is ")#emph[#text("coarser than")]#text(" ")#mi("{{\\mathcal F}^{\\prime}}")#text(" (or ")#mi("{{\\mathcal F}^{\\prime}}")#text(" is ")#emph[#text("finer than")]#text(" ")#mi("{{\\mathcal F}}")#text(") if ")#mi("{{\\mathcal F} \\subset {\\mathcal F}^{\\prime}}")#text(", thus every set that is measurable in ")#mi("{(\\Omega,{\\mathcal F})}")#text(" is also measurable in ")#mi("{(\\Omega,{\\mathcal F}^{\\prime})}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 5 (Trivial measurable space)")]#text(" Given any set ")#mi("{\\Omega}")#text(", the collection ")#mi("{\\{\\emptyset, \\Omega\\}}")#text(" is a ")#mi("{\\sigma}")#text("-algebra; in fact it is the coarsest ")#mi("{\\sigma}")#text("-algebra one can place on ")#mi("{\\Omega}")#text(". We refer to ")#mi("{(\\Omega, \\{\\emptyset,\\Omega\\})}")#text(" as the ")#emph[#text("trivial")]#text(" measurable space on ")#mi("{\\Omega}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 6 (Discrete measurable space)")]#text(" At the other extreme, given any set ")#mi("{\\Omega}")#text(", the power set ")#mi("{2^\\Omega := \\{ E: E \\subset \\Omega\\}}")#text(" is a ")#mi("{\\sigma}")#text("-algebra (and is the finest ")#mi("{\\sigma}")#text("-algebra one can place on ")#mi("{\\Omega}")#text("). We refer to ")#mi("{(\\Omega, 2^\\Omega)}")#text(" as the ")#emph[#text("discrete")]#text(" measurable space on ")#mi("{\\Omega}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 7 (Atomic measurable spaces)")]#text(" Suppose we have a partition ")#mi("{\\Omega = \\biguplus_{\\alpha \\in A} E_\\alpha}")#text(" of a set ")#mi("{\\Omega}")#text(" into disjoint subsets ")#mi("{E_\\alpha}")#text(" (which we will call ")#emph[#text("atoms")]#text("), indexed by some label set ")#mi("{A}")#text(" (which may be finite, countable, or uncountable). Such a partition defines a ")#mi("{\\sigma}")#text("-algebra on ")#mi("{\\Omega}")#text(", consisting of all sets of the form ")#mi("{\\bigcup_{\\alpha \\in B} E_\\alpha}")#text(" for subsets ")#mi("{B}")#text(" of ")#mi("{A}")#text(" (we allow ")#mi("{B}")#text(" to be empty); thus a set is measurable here if and only if it can be described as a union of atoms. One can easily verify that this is indeed a ")#mi("{\\sigma}")#text("-algebra. The trivial and discrete measurable spaces in the preceding two examples are special cases of this atomic construction, corresponding to the trivial partition ")#mi("{\\Omega = \\Omega}")#text(" (in which there is just one atom ")#mi("{\\Omega}")#text(") and the discrete partition ")#mi("{\\Omega = \\biguplus_{x \\in \\Omega} \\{x\\}}")#text(" (in which the atoms are individual points in ")#mi("{\\Omega}")#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 8")]#text(" Let ")#mi("{\\Omega}")#text(" be an uncountable set, and let ")#mi("{{\\mathcal F}}")#text(" be the collection of sets in ")#mi("{\\Omega}")#text(" which are either at most countable, or are cocountable (their complement is at most countable). Show that this is a ")#mi("{\\sigma}")#text("-algebra on ")#mi("{\\Omega}")#text(" which is non-atomic (i.e. it is not of the form of the preceding example).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 9 (Generated measurable spaces)")]#text(" It is easy to see that if one has a non-empty family ")#mi("{({\\mathcal F}_\\alpha)_{\\alpha \\in A}}")#text(" of ")#mi("{\\sigma}")#text("-algebras on a set ")#mi("{\\Omega}")#text(", then their intersection ")#mi("{\\bigcap_{\\alpha \\in A} {\\mathcal F}_\\alpha}")#text(" is also a ")#mi("{\\sigma}")#text("-algebra, even if ")#mi("{A}")#text(" is uncountably infinite. Because of this, whenever one has an arbitrary collection ")#mi("{{\\mathcal A}}")#text(" of subsets in ")#mi("{\\Omega}")#text(", one can define the ")#mi("{\\sigma}")#text("-algebra ")#mi("{\\langle {\\mathcal A} \\rangle}")#text(" ")#emph[#text("generated")]#text(" by ")#mi("{{\\mathcal A}}")#text(" to be the intersection of all the ")#mi("{\\sigma}")#text("-algebras that contain ")#mi("{{\\mathcal A}}")#text(" (note that there is always at least one ")#mi("{\\sigma}")#text("-algebra participating in this intersection, namely the discrete ")#mi("{\\sigma}")#text("-algebra). Equivalently, ")#mi("{\\langle {\\mathcal A} \\rangle}")#text(" is the coarsest ")#mi("{\\sigma}")#text("-algebra that views every set in ")#mi("{{\\mathcal A}}")#text(" as being measurable. (This is a rather indirect way to describe ")#mi("{\\langle {\\mathcal A} \\rangle}")#text(", as it does not make it easy to figure out exactly what sets lie in ")#mi("{\\langle {\\mathcal A} \\rangle}")#text(". There is a more direct description of this ")#mi("{\\sigma}")#text("-algebra, but it requires the use of the ")#link("https://en.wikipedia.org/wiki/First_uncountable_ordinal")[#text("first uncountable ordinal")]#text("; see Exercise 15 of ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/")[#text("these notes")]#text(".) In Durrett, the notation ")#mi("{\\sigma({\\mathcal A})}")#text(" is used in place of ")#mi("{\\langle {\\mathcal A}\\rangle}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 10 (Borel ")#mi("{\\sigma}")#text("-algebra)")]#text(" Let ")#mi("{\\Omega}")#text(" be a topological space; to avoid pathologies let us assume that ")#mi("{\\Omega}")#text(" is locally compact Hausdorff and ")#mi("{\\sigma}")#text("-compact, though the definition below also can be made for more general spaces. For instance, one could take ")#mi("{\\Omega = {\\bf R}^n}")#text(" or ")#mi("{\\Omega = {\\bf C}^n}")#text(" for some finite ")#mi("{n}")#text(". We define the ")#link("https://en.wikipedia.org/wiki/Borel_set")[#text("Borel ")#mi("{\\sigma}")#text("-algebra")]#text(" on ")#mi("{\\Omega}")#text(" to be the ")#mi("{\\sigma}")#text("-algebra generated by the open sets of ")#mi("{\\Omega}")#text(". (Due to our topological hypotheses on ")#mi("{\\Omega}")#text(", the Borel ")#mi("{\\sigma}")#text("-algebra is also generated by the compact sets of ")#mi("{\\Omega}")#text(".) Measurable subsets in the Borel ")#mi("{\\sigma}")#text("-algebra are known as ")#emph[#text("Borel sets")]#text(". Thus for instance open and closed sets are Borel, and countable unions and countable intersections of Borel sets are Borel. In fact, as a rule of thumb, any subset of ")#mi("{{\\bf R}^n}")#text(" or ")#mi("{{\\bf C}^n}")#text(" that arises from a “non-pathological” construction (not using the axiom of choice, or from a deliberate attempt to build a non-Borel set) can be expected to be a Borel set. Nevertheless, non-Borel sets exist in abundance if one looks hard enough for them, even without the axiom of choice; see for instance Exercise 16 of ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/")[#text("this previous blog post")]#text(".")
]

#text("The following exercise gives a useful tool (somewhat analogous to mathematical induction) to verify properties regarding measurable sets in generated ")#mi("{\\sigma}")#text("-algebras, such as Borel ")#mi("{\\sigma}")#text("-algebras.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Let ")#mi("{{\\mathcal A}}")#text(" be a collection of subsets of a set ")#mi("{\\Omega}")#text(", and let ")#mi("{P(E)}")#text(" be a property of subsets ")#mi("{E}")#text(" of ")#mi("{\\Omega}")#text(" (thus ")#mi("{P(E)}")#text(" is true or false for each ")#mi("{E \\subset \\Omega}")#text("). Assume the following axioms:")

#list(
[#mi("{P(\\emptyset)}")#text(" is true.")],
[#mi("{P(E)}")#text(" is true for all ")#mi("{E \\in {\\mathcal A}}")#text(".")],
[#text("If ")#mi("{E \\subset \\Omega}")#text(" is such that ")#mi("{P(E)}")#text(" is true, then ")#mi("{P(\\Omega \\backslash E)}")#text(" is also true.")],
[#text("If ")#mi("{E_1, E_2, \\dots \\subset \\Omega}")#text(" are such that ")#mi("{P(E_n)}")#text(" is true for all ")#mi("{n}")#text(", then ")#mi("{P(\\bigcup_n E_n)}")#text(" is true.")]
)

#text("Show that ")#mi("{P(E)}")#text(" is true for all ")#mi("{E \\in \\langle {\\mathcal A} \\rangle}")#text(". (")#emph[#text("Hint:")]#text(" what can one say about ")#mi("{\\{ E \\subset \\Omega: P(E) \\text{ true}\\}}")#text("?)")
]

#text("Thus, for instance, if a property of subsets of ")#mi("{{\\bf R}^n}")#text(" is true for all open sets, and is closed under countable unions and complements, then it is automatically true for all Borel sets.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 12 (Pullback)")]#text(" Let ")#mi("{(R, {\\mathcal B})}")#text(" be a measurable space, and let ")#mi("{\\phi: \\Omega \\rightarrow R}")#text(" be any function from another set ")#mi("{\\Omega}")#text(" to ")#mi("{R}")#text(". Then we can define the ")#emph[#text("pullback")]#text(" ")#mi("{\\phi^*({\\mathcal B})}")#text(" of the ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}}")#text(" to be the collection of all subsets in ")#mi("{\\Omega}")#text(" that are of the form ")#mi("{\\phi^{-1}(S)}")#text(" for some ")#mi("{S \\in {\\mathcal B}}")#text(". This is easily verified to be a ")#mi("{\\sigma}")#text("-algebra. We refer to the measurable space ")#mi("{(\\Omega, \\phi^*({\\mathcal B}))}")#text(" as the pullback of the measurable space ")#mi("{(R, {\\mathcal B})}")#text(" by ")#mi("{\\phi}")#text(". Thus for instance an atomic measurable space on ")#mi("{\\Omega}")#text(" generated by a partition ")#mi("{\\Omega = \\biguplus_{\\alpha \\in A} E_\\alpha}")#text(" is the pullback of ")#mi("{A}")#text(" (viewed as a discrete measurable space) by the “colouring” map from ")#mi("{\\Omega}")#text(" to ")#mi("{A}")#text(" that sends each element of ")#mi("{E_\\alpha}")#text(" to ")#mi("{\\alpha}")#text(" for all ")#mi("{\\alpha \\in A}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 13")]#text(" In probabilistic terms, one can interpret the space ")#mi("{\\Omega}")#text(" in the above construction as a sample space, and the function ")#mi("{\\phi}")#text(" as some collection of “random variables” or “measurements” on that space, with ")#mi("{R}")#text(" being all the possible outcomes of these measurements. The pullback then represents all the “information” one can extract from that given set of measurements.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 14 (Product space)")]#text(" Let ")#mi("{(R_\\alpha, {\\mathcal B}_\\alpha)_{\\alpha \\in A}}")#text(" be a family of measurable spaces indexed by a (possibly infinite or uncountable) set ")#mi("{A}")#text(". We define the product ")#mi("{(\\prod_{\\alpha \\in A} R_\\alpha, \\prod_{\\alpha \\in A} {\\mathcal B}_\\alpha)}")#text(" on the Cartesian product space ")#mi("{\\prod_{\\alpha \\in A} R_\\alpha}")#text(" by defining ")#mi("{\\prod_{\\alpha \\in A} {\\mathcal B}_\\alpha}")#text(" to be the ")#mi("{\\sigma}")#text("-algebra generated by the ")#link("https://en.wikipedia.org/wiki/Cylinder_set")[#text("basic cylinder sets")]#text(" of the form")

#align(center)[#tao-fit-display[#mitex("\\{ (x_\\alpha)_{\\alpha \\in A} \\in \\prod_{\\alpha \\in A} R_\\alpha: x_\\beta \\in E_\\beta \\}")]]

#text("for ")#mi("{\\beta \\in A}")#text(" and ")#mi("{E_\\beta \\in {\\mathcal B}_\\beta}")#text(". For instance, given two measurable spaces ")#mi("{(R_1, {\\mathcal B}_1)}")#text(" and ")#mi("{(R_2, {\\mathcal B}_2)}")#text(", the product ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}_1 \\times {\\mathcal B}_2}")#text(" is generated by the sets ")#mi("{E_1 \\times R_2}")#text(" and ")#mi("{R_1 \\times E_2}")#text(" for ")#mi("{E_1 \\in {\\mathcal B}_1, E_2 \\in {\\mathcal B}_2}")#text(". (One can also show that ")#mi("{{\\mathcal B}_1 \\times {\\mathcal B}_2}")#text(" is the ")#mi("{\\sigma}")#text("-algebra generated by the products ")#mi("{E_1 \\times E_2}")#text(" for ")#mi("{E_1 \\in {\\mathcal B}_1, E_2 \\in {\\mathcal B}_2}")#text(", but this observation does not extend to uncountable products of measurable spaces.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" Show that ")#mi("{{\\bf R}^n}")#text(" with the Borel ")#mi("{\\sigma}")#text("-algebra is the product of ")#mi("{n}")#text(" copies of ")#mi("{{\\bf R}}")#text(" with the Borel ")#mi("{\\sigma}")#text("-algebra.")
]

#text("As with almost any other notion of space in mathematics, there is a natural notion of a map (or ")#emph[#text("morphism")]#text(") between measurable spaces.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 16")]#text(" A function ")#mi("{\\phi: \\Omega \\rightarrow R}")#text(" between two measurable spaces ")#mi("{(\\Omega, {\\mathcal F})}")#text(", ")#mi("{(R,{\\mathcal B})}")#text(" is said to be ")#emph[#text("measurable")]#text(" if one has ")#mi("{\\phi^{-1}(S) \\in {\\mathcal F}}")#text(" for all ")#mi("{S \\in {\\mathcal B}}")#text(".")
]

#text("Thus for instance the pullback of a measurable space ")#mi("{R}")#text(" by a map ")#mi("{\\phi: \\Omega \\rightarrow R}")#text(" could alternatively be defined as the coarsest measurable space structure on ")#mi("{\\Omega}")#text(" for which ")#mi("{\\phi}")#text(" is still measurable. It is clear that the composition of measurable functions is also measurable.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Show that any continuous map from one topological space ")#mi("{X}")#text(" to another ")#mi("{Y}")#text(" is necessarily measurable (when one gives ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" the Borel ")#mi("{\\sigma}")#text("-algebras).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" If ")#mi("{X_1: \\Omega \\rightarrow R_1, \\dots, X_n: \\Omega \\rightarrow R_n}")#text(" are measurable functions into measurable spaces ")#mi("{R_1,\\dots,R_n}")#text(", show that the joint function ")#mi("{(X_1,\\dots,X_n): \\Omega \\rightarrow R_1 \\times \\dots \\times R_n}")#text(" into the product space ")#mi("{R_1 \\times \\dots \\times R_n}")#text(" defined by ")#mi("{(X_1,\\dots,X_n): \\omega \\mapsto (X_1(\\omega),\\dots,X_n(\\omega))}")#text(" is also measurable.")
]

#text("As a corollary of the above exercise, we see that if ")#mi("{X_1: \\Omega \\rightarrow R_1, \\dots, X_n: \\Omega \\rightarrow R_n}")#text(" are measurable, and ")#mi("{F: R_1 \\times \\dots \\times R_n \\rightarrow S}")#text(" is measurable, then ")#mi("{F(X_1,\\dots,X_n): \\Omega \\rightarrow S}")#text(" is also measurable. In particular, if ")#mi("{X_1, X_2: \\Omega \\rightarrow {\\bf R}}")#text(" or ")#mi("{X_1,X_2: \\Omega \\rightarrow {\\bf C}}")#text(" are scalar measurable functions, then so are ")#mi("{X_1 +X_2}")#text(", ")#mi("{X_1 - X_2}")#text(", ")#mi("{X_1 \\cdot X_2}")#text(", etc..")

#text("Next, we turn measurable spaces into measure spaces by adding a measure.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 19 (Measure spaces)")]#text(" Let ")#mi("{(\\Omega, {\\mathcal F})}")#text(" be a measurable space. A ")#emph[#text("finitely additive measure")]#text(" on this space is a map ")#mi("{\\mu: {\\mathcal F} \\rightarrow [0,+\\infty]}")#text(" obeying the following axioms:")

#list(
[#text("(Empty set) ")#mi("{\\mu(\\emptyset)=0}")#text(".")],
[#text("(Finite additivity) If ")#mi("{E, F \\in {\\mathcal F}}")#text(" are disjoint, then ")#mi("{\\mu(E \\cup F) = \\mu(E) + \\mu(F)}")#text(".")]
)

#text("A ")#link("https://en.wikipedia.org/wiki/Measure_(mathematics)")[#text("countably additive measure")]#text(" is a finitely additive measure ")#mi("{\\mu: {\\mathcal F} \\rightarrow [0,+\\infty]}")#text(" obeying the following additional axiom:")

#list(
[#text("(Countable additivity) If ")#mi("{E_1, E_2, E_3, \\dots \\in {\\mathcal F}}")#text(" are disjoint, then ")#mi("{\\mu(\\bigcup_{n=1}^\\infty E_n) = \\sum_{n=1}^\\infty \\mu(E_n)}")#text(".")]
)

#text("A ")#link("https://en.wikipedia.org/wiki/Probability_measure")[#text("probability measure")]#text(" on ")#mi("{\\Omega}")#text(" is a countably additive measure ")#mi("{\\mu: {\\mathcal F} \\rightarrow [0,+\\infty]}")#text(" obeying the following additional axiom:")

#list(
[#text("(Unit total probability) ")#mi("{\\mu(\\Omega)=1}")#text(".")]
)

#text("A ")#link("https://en.wikipedia.org/wiki/Measure_(mathematics)#measure_space")[#text("measure space")]#text(" is a triplet ")#mi("{\\Omega = (\\Omega, {\\mathcal F}, \\mu)}")#text(" where ")#mi("{(\\Omega,{\\mathcal F})}")#text(" is a measurable space and ")#mi("{\\mu}")#text(" is a measure on that space. If ")#mi("{\\mu}")#text(" is furthermore a probability measure, we call ")#mi("{(\\Omega, {\\mathcal F}, \\mu)}")#text(" a ")#link("https://en.wikipedia.org/wiki/Probability_space")[#text("probability space")]#text(".")

#text("A set of measure zero is known as a ")#emph[#text("null set")]#text(". A property ")#mi("{P(x)}")#text(" that holds for all ")#mi("{x \\in \\Omega}")#text(" outside of a null set is said to hold ")#emph[#text("almost everywhere")]#text(" or ")#emph[#text("for almost every ")#mi("{x}")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 20 (Discrete probability measures)")]#text(" Let ")#mi("{\\Omega}")#text(" be a discrete measurable space, and for each ")#mi("{\\omega \\in \\Omega}")#text(", let ")#mi("{p_\\omega}")#text(" be a non-negative real number such that ")#mi("{\\sum_{\\omega \\in \\Omega} p_\\omega = 1}")#text(". (Note that this implies that there are at most countably many ")#mi("{\\omega}")#text(" for which ")#mi("{p_\\omega > 0}")#text(" – why?.) Then one can form a probability measure ")#mi("{\\mu}")#text(" on ")#mi("{\\Omega}")#text(" by defining")

#align(center)[#tao-fit-display[#mitex("\\mu(E) := \\sum_{\\omega \\in E} p_\\omega")]]

#text("for all ")#mi("{E \\subset \\Omega}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 21 (Lebesgue measure)")]#text(" Let ")#mi("{{\\bf R}}")#text(" be given the Borel ")#mi("{\\sigma}")#text("-algebra. Then it turns out there is a unique measure ")#mi("{m}")#text(" on ")#mi("{{\\bf R}}")#text(", known as ")#link("https://en.wikipedia.org/wiki/Lebesgue_measure")[#text("Lebesgue measure")]#text(" (or more precisely, the restriction of Lebesgue measure to the Borel ")#mi("{\\sigma}")#text("-algebra) such that ")#mi("{m([a,b]) = b-a}")#text(" for every closed interval ")#mi("{[a,b]}")#text(" with ")#mi("{-\\infty \\leq a \\leq b \\leq \\infty}")#text(" (this is also true if one uses open intervals or half-open intervals in place of closed intervals). More generally, there is a unique measure ")#mi("{m^n}")#text(" on ")#mi("{{\\bf R}^n}")#text(" for any natural number ")#mi("{n}")#text(", also known as Lebesgue measure, such that")

#align(center)[#tao-fit-display[#mitex("m^n( [a_1,b_1] \\times \\dots \\times[a_n,b_n]) = (b_1-a_1) \\times \\dots \\times (b_n-a_n)")]]

#text("for all closed boxes ")#mi("{[a_1,b_1] \\times \\dots \\times[a_n,b_n]}")#text(", that is to say products of ")#mi("{n}")#text(" closed intervals. The construction of Lebesgue measure is a little tricky; see ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("this previous blog post")]#text(" for details.")
]

#text("We can then set up general probability theory similarly to how we set up discrete probability theory:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 22 (Probability theory)")]#text(" In probability theory, we choose an ambient probability space ")#mi("{\\Omega = (\\Omega,{\\mathcal F}_\\Omega,\\mu)}")#text(" as the randomness model, and refer to the set ")#mi("{\\Omega}")#text(" (without the additional structures ")#mi("{{\\mathcal F}_\\Omega}")#text(", ")#mi("{\\mu}")#text(") as the ")#emph[#text("sample space")]#text(" for that model. We then model an ")#emph[#text("event")]#text(" ")#mi("{E}")#text(" by an element ")#mi("{E_\\Omega}")#text(" of ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal F}_\\Omega}")#text(", with each such element describing an event. The ")#emph[#text("probability")]#text(" ")#mi("{{\\bf P}(E)}")#text(" of an event ")#mi("{E}")#text(" is defined to be the quantity")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(E) := \\mu( E_\\Omega ).")]]

#text("An event ")#mi("{E}")#text(" is ")#emph[#text("surely true")]#text(" or is the ")#emph[#text("sure event")]#text(" if ")#mi("{E_\\Omega = \\Omega}")#text(", and is ")#emph[#text("surely false")]#text(" or is the ")#emph[#text("empty event")]#text(" if ")#mi("{E_\\Omega =\\emptyset}")#text(". It is ")#emph[#text("almost surely true")]#text(" or an ")#emph[#text("almost sure event")]#text(" if ")#mi("{{\\bf P}(E) = 1}")#text(", and ")#emph[#text("almost surely false")]#text(" or a ")#emph[#text("null event")]#text(" if ")#mi("{{\\bf P}(E)=0}")#text(".")

#text("We model random variables ")#mi("{X}")#text(" taking values in the range ")#mi("{R}")#text(" by measurable functions ")#mi("{X_\\Omega: \\Omega \\rightarrow R}")#text(" from the sample space ")#mi("{\\Omega}")#text(" to the range ")#mi("{R}")#text(". We define real, complex, and scalar random variables as in the discrete case.")

#text("As in the discrete case, we consider two events ")#mi("{E,F}")#text(" to be equal if they are modeled by the same set: ")#mi("{E=F \\iff E_\\Omega = F_\\Omega}")#text(". Similarly, two random variables ")#mi("{X,Y}")#text(" taking values in a common range ")#mi("{R}")#text(" are considered to be equal if they are modeled by the same function: ")#mi("{X=Y \\iff X_\\Omega = Y_\\Omega}")#text(". Again, if the sample space ")#mi("{\\Omega}")#text(" is understood from context, we will usually abuse notation by identifying an event ")#mi("{E}")#text(" with its model ")#mi("{E_\\Omega}")#text(", and similarly identify a random variable ")#mi("{X}")#text(" with its model ")#mi("{X_\\Omega}")#text(".")
]

#text("As in the discrete case, set-theoretic operations on the sample space induce similar boolean operations on events. Furthermore, since the ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal F}_\\Omega}")#text(" is closed under countable unions and countable intersections, we may similarly define the countable conjunction ")#mi("{\\bigwedge_{n=1}^\\infty E_n}")#text(" or countable disjunction ")#mi("{\\bigvee_{n=1}^\\infty E_n}")#text(" of a sequence ")#mi("{E_1,E_2,\\dots}")#text(" of events; however, we do ")#emph[#text("not")]#text(" define uncountable conjunctions or disjunctions as these may not be well-defined as events.")

#text("The axioms of a probability space then yield the ")#link("https://en.wikipedia.org/wiki/Probability_axioms")[#text("Kolmogorov axioms for probability")]#text(":")

#list(
[#mi("{{\\bf P}(\\emptyset)=0}")#text(".")],
[#mi("{{\\bf P}(\\overline{\\emptyset})=1}")#text(".")],
[#text("If ")#mi("{E_1,E_2,\\dots}")#text(" are disjoint events, then ")#mi("{{\\bf P}(\\bigvee_{n=1}^\\infty E_n) = \\sum_{n=1}^\\infty {\\bf P}(E_n)}")#text(".")]
)

#text("We can manipulate random variables just as in the discrete case, with the only caveat being that we have to restrict attention to ")#emph[#text("measurable")]#text(" operations. For instance, if ")#mi("{X}")#text(" is a random variable taking values in a measurable space ")#mi("{R}")#text(", and ")#mi("{f: R \\rightarrow S}")#text(" is a measurable map, then ")#mi("{f(X)}")#text(" is well defined as a random variable taking values in ")#mi("{S}")#text(". Similarly, if ")#mi("{f: R_1 \\times \\dots \\times R_n \\rightarrow S}")#text(" is a measurable map and ")#mi("{X_1,\\dots,X_n}")#text(" are random variables taking values in ")#mi("{R_1,\\dots,R_n}")#text(" respectively, then ")#mi("{f(X_1,\\dots,X_n)}")#text(" is a random variable taking values in ")#mi("{S}")#text(". Similarly we can create events ")#mi("{F(X_1,\\dots,X_n)}")#text(" out of ")#emph[#text("measurable")]#text(" relations ")#mi("{F: R_1 \\times \\dots \\times R_n \\rightarrow \\{ \\text{true}, \\text{false}\\}}")#text(" (giving the boolean range ")#mi("{\\{ \\text{true}, \\text{false}\\}}")#text(" the discrete ")#mi("{\\sigma}")#text("-algebra, of course). Finally, we continue to view deterministic elements of a space ")#mi("{X}")#text(" as a special case of a random element of ")#mi("{X}")#text(", and associate the indicator random variable ")#mi("{1_E}")#text(" to any event ")#mi("{E}")#text(" as before.")

#text("We say that two random variables ")#mi("{X,Y}")#text(" ")#emph[#text("agree almost surely")]#text(" if the event ")#mi("{X=Y}")#text(" is almost surely true; this is an equivalence relation. In many cases we are willing to consider random variables up to almost sure equivalence. In particular, we can generalise the notion of a random variable slightly by considering random variables ")#mi("{X}")#text(" whose models ")#mi("{X_\\Omega: \\Omega \\rightarrow R}")#text(" are only defined almost surely, i.e. their domain is not all of ")#mi("{\\Omega}")#text(", but instead ")#mi("{\\Omega}")#text(" with a set of measure zero removed. This is, technically, not a random variable as we have defined it, but it can be associated canonically with an equivalence class of random variables up to almost sure equivalence, and so we view such objects as random variables “up to almost sure equivalence”. Similarly, we declare two events ")#mi("{E}")#text(" and ")#mi("{F}")#text(" ")#emph[#text("almost surely equivalent")]#text(" if their symmetric difference ")#mi("{E \\Delta F}")#text(" is a null event, and will often consider events up to almost sure equivalence only.")

#text("We record some simple consequences of the measure-theoretic axioms:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Let ")#mi("{(\\Omega, {\\mathcal F}_\\Omega, \\mu)}")#text(" be a measure space.")

#enum(start: 1, 
[#text("(Monotonicity) If ")#mi("{E \\subset F}")#text(" are measurable, then ")#mi("{\\mu(E) \\leq \\mu(F)}")#text(".")],
[#text("(Subadditivity) If ")#mi("{E_1,E_2,\\dots}")#text(" are measurable (not necessarily disjoint), then ")#mi("{\\mu(\\bigcup_{n=1}^\\infty E_n) \\leq \\sum_{n=1}^\\infty \\mu(E_n)}")#text(".")],
[#text("(Continuity from below) If ")#mi("{E_1 \\subset E_2 \\subset \\dots }")#text(" are measurable, then ")#mi("{\\mu(\\bigcup_{n=1}^\\infty E_n) = \\lim_{n \\rightarrow \\infty} \\mu(E_n)}")#text(".")],
[#text("(Continuity from above) If ")#mi("{E_1 \\supset E_2 \\supset \\dots}")#text(" are measurable and ")#mi("{\\mu(E_1)}")#text(" is finite, then ")#mi("{\\mu(\\bigcap_{n=1}^\\infty E_n) = \\lim_{n \\rightarrow \\infty} \\mu(E_n)}")#text(". Give a counterexample to show that the claim can fail when ")#mi("{\\mu(E_1)}")#text(" is infinite.")]
)
]

#text("Of course, these measure-theoretic facts immediately imply their probabilistic counterparts (and the pesky hypothesis that ")#mi("{\\mu(E_1)}")#text(" is finite is automatic and can thus be dropped):")

#enum(start: 1, 
[#text("(Monotonicity) If ")#mi("{E \\subset F}")#text(" are events, then ")#mi("{{\\mathbf P}(E) \\leq {\\mathbf P}(F)}")#text(". (In particular, ")#mi("{0 \\leq {\\mathbf P}(E) \\leq 1}")#text(" for any event ")#mi("{E}")#text(".)")],
[#text("(Subadditivity) If ")#mi("{E_1,E_2,\\dots}")#text(" are events (not necessarily disjoint), then ")#mi("{{\\mathbf P}(\\bigvee_{n=1}^\\infty E_n) \\leq \\sum_{n=1}^\\infty {\\mathbf P}(E_n)}")#text(".")],
[#text("(Continuity from below) If ")#mi("{E_1 \\subset E_2 \\subset \\dots }")#text(" are events, then ")#mi("{{\\mathbf P}(\\bigvee_{n=1}^\\infty E_n) = \\lim_{n \\rightarrow \\infty} {\\mathbf P}(E_n)}")#text(".")],
[#text("(Continuity from above) If ")#mi("{E_1 \\supset E_2 \\supset \\dots}")#text(" is events, then ")#mi("{{\\mathbf P}(\\bigwedge_{n=1}^\\infty E_n) = \\lim_{n \\rightarrow \\infty} {\\mathbf P}(E_n)}")#text(".")]
)

#text("Note that if a countable sequence ")#mi("{E_1, E_2, \\dots}")#text(" of events each hold almost surely, then their conjunction does as well (by applying subadditivity to the complementary events ")#mi("{\\overline{E_1},\\overline{E_2},\\dots}")#text(". As a general rule of thumb, the notion of “almost surely” behaves like “surely” as long as one only performs an at most countable number of operations (which already suffices for a large portion of analysis, such as taking limits or performing infinite sums).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Let ")#mi("{(\\Omega, {\\mathcal B})}")#text(" be a measurable space.")

#list(
[#text("If ")#mi("{f: \\Omega \\rightarrow [-\\infty,\\infty]}")#text(" is a function taking values in the extended reals ")#mi("{[-\\infty,\\infty]}")#text(", show that ")#mi("{f}")#text(" is measurable (giving ")#mi("{[-\\infty,\\infty]}")#text(" the Borel ")#mi("{\\sigma}")#text("-algebra) if and only if the sets ")#mi("{\\{ \\omega \\in \\Omega: f(\\omega) \\leq t \\}}")#text(" are measurable for all real ")#mi("{t}")#text(".")],
[#text("If ")#mi("{f,g: \\Omega \\rightarrow [-\\infty,\\infty]}")#text(" are functions, show that ")#mi("{f=g}")#text(" if and only if ")#mi("{\\{ \\omega \\in \\Omega: f(\\omega) \\leq t \\} = \\{ \\omega \\in \\Omega: g(\\omega) \\leq t \\}}")#text(" for all reals ")#mi("{t}")#text(".")],
[#text("If ")#mi("{f_1,f_2,\\dots: \\Omega \\rightarrow [-\\infty,\\infty]}")#text(" are measurable, show that ")#mi("{\\sup_n f_n}")#text(", ")#mi("{\\inf_n f_n}")#text(", ")#mi("{\\limsup_{n \\rightarrow \\infty} f_n}")#text(", and ")#mi("{\\liminf_{n \\rightarrow \\infty} f_n}")#text(" are all measurable.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 25")]#text(" Occasionally, there is need to consider uncountable suprema or infima, e.g. ")#mi("{\\sup_{t \\in {\\bf R}} f_t}")#text(". It is then no longer automatically the case that such an uncountable supremum or infimum of measurable functions is again measurable. However, in practice one can avoid this issue by carefully rewriting such uncountable suprema or infima in terms of countable ones. For instance, if it is known that ")#mi("{f_t(\\omega)}")#text(" depends continuously on ")#mi("{t}")#text(" for each ")#mi("{\\omega}")#text(", then ")#mi("{\\sup_{t \\in {\\bf R}} f_t = \\sup_{t \\in {\\bf Q}} f_t}")#text(", and so measurability is not an issue.")
]

#text("Using the above exercise, when given a sequence ")#mi("{X_1,X_2,\\dots}")#text(" of random variables taking values in the extended real line ")#mi("{[-\\infty,\\infty]}")#text(", we can define the random variables ")#mi("{\\sup_n X_n}")#text(", ")#mi("{\\inf_n X_n}")#text(", ")#mi("{\\limsup_{n \\rightarrow \\infty} X_n}")#text(", ")#mi("{\\liminf_{n \\rightarrow \\infty} X_n}")#text(" which also take values in the extended real line, and which obey relations such as")

#align(center)[#tao-fit-display[#mitex("(\\sup_n X_n > t) = \\bigvee_{n=1}^\\infty (X_n > t)")]]

#text("for any real number ")#mi("{t}")#text(".")

#text("We now say that a sequence ")#mi("{X_1,X_2,\\dots}")#text(" of random variables in the extended real line ")#link("https://en.wikipedia.org/wiki/Convergence_of_random_variables#Almost_sure_convergence")[#text("converges almost surely")]#text(" if one has")

#align(center)[#tao-fit-display[#mitex("\\liminf_{n \\rightarrow \\infty} X_n = \\limsup_{n \\rightarrow \\infty} X_n")]]

#text("almost surely, in which case we can define the limit ")#mi("{\\lim_{n \\rightarrow \\infty} X_n}")#text(" (up to almost sure equivalence) as")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} X_n = \\liminf_{n \\rightarrow \\infty} X_n = \\limsup_{n \\rightarrow \\infty} X_n.")]]

#text("This corresponds closely to the concept of ")#link("https://en.wikipedia.org/wiki/Pointwise_convergence#Almost_everywhere_convergence")[#text("almost everywhere convergence")]#text(" in measure theory, which is a slightly weaker notion than pointwise convergence which allows for bad behaviour on a set of measure zero. (See ")#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/")[#text("this previous blog post")]#text(" for more discussion on different notions of convergence of measurable functions.)")

#text("We will defer the general construction of expectation of a random variable to the next set of notes, where we review the notion of integration on a measure space. For now, we quickly review the basic construction of continuous scalar random variables.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" Let ")#mi("{\\mu}")#text(" be a probability measure on the real line ")#mi("{{\\bf R}}")#text(" (with the Borel ")#mi("{\\sigma}")#text("-algebra). Define the ")#emph[#text("Stieltjes measure function")]#text(" ")#mi("{F: {\\bf R} \\rightarrow [0,1]}")#text(" associated to ")#mi("{\\mu}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("F( t ) := \\mu( (-\\infty,t] ) = \\mu( \\{ x \\in {\\bf R}: x \\leq t \\} ).")]]

#text("Establish the following properties of ")#mi("{F}")#text(":")

#list(
[#text("(i) ")#mi("{F}")#text(" is non-decreasing.")],
[#text("(ii) ")#mi("{\\lim_{t \\rightarrow -\\infty} F(t) = 0}")#text(" and ")#mi("{\\lim_{t \\rightarrow +\\infty} F(t) = 1}")#text(".")],
[#text("(iii) ")#mi("{F}")#text(" is right-continuous, thus ")#mi("{F(t) = \\lim_{s \\rightarrow t^+} F(s)}")#text(" for all ")#mi("{t \\in {\\bf R}}")#text(".")]
)
]

#text("There is a somewhat difficult converse to this exercise: if ")#mi("{F}")#text(" is a function obeying the above three properties, then there is a unique probability measure ")#mi("{\\mu}")#text(" on ")#mi("{{\\bf R}}")#text(" (the ")#link("https://en.wikipedia.org/wiki/Lebesgue%E2%80%93Stieltjes_integration")[#text("Lebesgue-Stieltjes measure")]#text(" associated to ")#mi("{F}")#text(") for which ")#mi("{F}")#text(" is the Stieltjes measure function. See Section 3 of ")#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/")[#text("this previous post")]#text(" for details. As a consequence of this, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 27 (Construction of a single continuous random variable)")]#text(" Let ")#mi("{F: {\\bf R} \\rightarrow [0,1]}")#text(" be a function obeying the properties (i)-(iii) of the above exercise. Then, by using a suitable probability space model, we can construct a real random variable ")#mi("{X}")#text(" with the property that")

#align(center)[#tao-fit-display[#mitex("F(t) = {\\bf P}( X \\leq t)")]]

#text("for all ")#mi("{t \\in {\\bf R}}")#text(".")
]

#text("Indeed, we can take the probability space to be ")#mi("{{\\bf R}}")#text(" with the Borel ")#mi("{\\sigma}")#text("-algebra and the Lebesgue-Stieltjes measure associated to ")#mi("{F}")#text(". This corollary is not fully satisfactory, because often we may already have chosen a probability space to model some other random variables, and the probability space provided by this corollary may be completely unrelated to the one used. We can resolve these issues with product measures and other joinings, but this will be deferred to a later set of notes.")

#text("Define the ")#link("https://en.wikipedia.org/wiki/Cumulative_distribution_function")[#text("cumulative distribution function")]#text(" ")#mi("{F: {\\bf R} \\rightarrow [0,1]}")#text(" of a real random variable ")#mi("{X}")#text(" to be the function")

#align(center)[#tao-fit-display[#mitex("F(t) := {\\bf P}(X \\leq t).")]]

#text("Thus we see that cumulative distribution functions obey the properties (i)-(iii) above, and conversely any function with those properties is the cumulative distribution function of some real random variable. We say that two real random variables (possibly on different sample spaces) ")#emph[#text("agree in distribution")]#text(" if they have the same cumulative distribution function. One can therefore define a real random variable, up to agreement in distribution, by specifying the cumulative distribution function. See Durrett for some standard real distributions (uniform, normal, geometric, etc.) that one can define in this fashion.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" Let ")#mi("{X}")#text(" be a real random variable with cumulative distribution function ")#mi("{F}")#text(". For any real number ")#mi("{t}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(X < t) = \\lim_{s \\rightarrow t^-} F(s)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(X = t) = F(t) - \\lim_{s \\rightarrow t^-} F(s).")]]

#text("In particular, one has ")#mi("{{\\bf P}(X=t)=0}")#text(" for all ")#mi("{t}")#text(" if and only if ")#mi("{F}")#text(" is continuous.")
]

#text("Note in particular that this illustrates the distinction between almost sure and sure events: if ")#mi("{X}")#text(" has a continuous cumulative distribution function, and ")#mi("{t}")#text(" is a real number, then ")#mi("{X=t}")#text(" is almost surely false, but it does not have to be surely false. (Indeed, if one takes the sample space to be ")#mi("{{\\bf R}}")#text(" and ")#mi("{X_\\Omega}")#text(" to be the identity function, then ")#mi("{X=t}")#text(" will not be surely false.) On the other hand, the fact that ")#mi("{X}")#text(" is equal to ")#emph[#text("some")]#text(" real number is of course surely true. The reason these statements are consistent with each other is that there are uncountably many real numbers ")#mi("{t}")#text(". (Countable additivity tells us that a countable disjunction of null events is still null, but says nothing about uncountable disjunctions.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29 (Skorokhod representation of scalar variables)")]#text(" Let ")#mi("{U}")#text(" be a uniform random variable taking values in ")#mi("{[0,1]}")#text(" (thus ")#mi("{U}")#text(" has cumulative distribution function ")#mi("{F_U(t) := \\min(\\max(t,0),1)}")#text("), and let ")#mi("{F: {\\bf R} \\rightarrow [0,1]}")#text(" be another cumulative distribution function. Show that the random variables")

#align(center)[#tao-fit-display[#mitex("X^- := \\sup \\{ y \\in {\\bf R}: F(y) < U \\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("X^+ := \\inf \\{ y \\in {\\bf R}: F(y) \\geq U \\}")]]

#text("are indeed random variables (that is to say, they are measurable in any given model ")#mi("{\\Omega}")#text("), and have cumulative distribution function ")#mi("{F}")#text(". (This construction is attributed to Skorokhod, but it should not be confused with the ")#link("https://en.wikipedia.org/wiki/Skorokhod%27s_representation_theorem")[#text("Skorokhod representation theorem")]#text(". It provides a quick way to generate a single scalar variable, but unfortunately it is difficult to modify this construction to generate multiple scalar variables, especially if they are somehow coupled to each other.)")
]

#text("There is a multidimensional analogue of the above theory, which is almost identical, except that the monotonicity property has to be strengthened:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30")]#text(" Let ")#mi("{\\mu}")#text(" be a probability measure on ")#mi("{{\\bf R}^n}")#text(" (with the Borel ")#mi("{\\sigma}")#text("-algebra). Define the ")#emph[#text("Stieltjes measure function")]#text(" ")#mi("{F: {\\bf R}^n \\rightarrow [0,1]}")#text(" associated to ")#mi("{\\mu}")#text(" by the formula")

#tao-aligned(keep: true)[


#tao-math("F( t_1,\\dots,t_n )  & := \\mu( (-\\infty,t_1] \\times \\dots \\times (-\\infty,t_n] )", block: true)



#tao-math(" & = \\mu( \\{ (x_1,\\dots,x_n) \\in {\\bf R}^n: x_i \\leq t_i \\forall i=1,\\dots,n \\} ).", block: true)
]

#text("Establish the following properties of ")#mi("{F}")#text(":")

#list(
[#text("(i) ")#mi("{F}")#text(" is non-decreasing: ")#mi("{F(t_1,\\dots,t_n) \\leq F(t^{\\prime}_1,\\dots,t^{\\prime}_n)}")#text(" whenever ")#mi("{t_i \\leq t^{\\prime}_i}")#text(" for all ")#mi("{i}")#text(".")],
[#text("(ii) ")#mi("{\\lim_{t_1,\\dots,t_n \\rightarrow -\\infty} F(t_1,\\dots,t_n) = 0}")#text(" and ")#mi("{\\lim_{t_1,\\dots,t_n \\rightarrow +\\infty} F(t_1,\\dots,t_n) = 1}")#text(".")],
[#text("(iii) ")#mi("{F}")#text(" is right-continuous, thus ")#mi("{F(t_1,\\dots,t_n) = \\lim_{(s_1,\\dots,s_n) \\rightarrow (t_1,\\dots,t_n)^+} F(s_1,\\dots,s_n)}")#text(" for all ")#mi("{(t_1,\\dots,t_n) \\in {\\bf R}^n}")#text(", where the ")#mi("{+}")#text(" superscript denotes that we restrict each ")#mi("{s_i}")#text(" to be greater than or equal to ")#mi("{t_i}")#text(".")],
[#text("(iv) One has")

#align(center)[#tao-fit-display[#mitex("\\sum_{(\\omega_1,\\dots,\\omega_n) \\in \\{0,1\\}^n} (-1)^{\\omega_1+\\dots+\\omega_n+n} F( t_{1,\\omega_1}, \\dots, t_{n,\\omega_n} ) \\geq 0")]]

#text("whenever ")#mi("{t_{i,0} \\leq t_{i,1}}")#text(" are real numbers for ")#mi("{i=1,\\dots,n}")#text(". (")#emph[#text("Hint:")]#text(" try to express the measure of a box ")#mi("{(t_{1,0},t_{1,1}] \\times \\dots \\times (t_{n,0},t_{n,1}]}")#text(" with respect to ")#mi("{\\mu}")#text(" in terms of the Stieltjes measure function ")#mi("{F}")#text(".)")]
)
]

#text("Again, there is a difficult converse to this exercise: if ")#mi("{F}")#text(" is a function obeying the above four properties, then there is a unique probability measure ")#mi("{\\mu}")#text(" on ")#mi("{{\\bf R}^n}")#text(" for which ")#mi("{F}")#text(" is the Stieltjes measure function. See Durrett for details; one can also modify the arguments in ")#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/")[#text("this previous post")]#text(". In particular, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 31 (Construction of several continuous random variables)")]#text(" Let ")#mi("{F: {\\bf R}^n \\rightarrow [0,1]}")#text(" be a function obeying the properties (i)-(iv) of the above exercise. Then, by using a suitable probability space model, we can construct real random variables ")#mi("{X_1,\\dots,X_n}")#text(" with the property that")

#align(center)[#tao-fit-display[#mitex("F(t_1,\\dots,t_n) = {\\bf P}( X_1 \\leq t_1 \\wedge \\dots \\wedge X_n \\leq t_n)")]]

#text("for all ")#mi("{t_1,\\dots,t_n \\in {\\bf R}}")#text(".")
]

#text("Again, this corollary is not completely satisfactory because the probability space produced by it (which one can take to be ")#mi("{{\\bf R}^n}")#text(" with the Borel ")#mi("{\\sigma}")#text("-algebra and the Lebesgue-Stieltjes measure on ")#mi("{F}")#text(") may not be the probability space one wants to use; we will return to this point later.")

#heading(level: 1)[#strong[#text(" — 4. Variants of the standard foundations (optional) — ")]]

#text("We have focused on the orthodox foundations of probability theory in which we model events and random variables through probability spaces. In this section, we briefly discuss some alternate ways to set up the foundations, as well as alternatives to probability theory itself. (Actually, many of the basic objects and concepts in mathematics have multiple such foundations; see for instance ")#link("https://terrytao.wordpress.com/2009/10/19/grothendiecks-definition-of-a-group/")[#text("this blog post")]#text(" exploring the many different ways to define the notion of a group.) We mention them here in order exclude them from discussion in subsequent notes, which will be focused almost exclusively on orthodox probability.")

#text("One approach to the foundations of probability is to view the event space as an ")#emph[#text("abstract")]#text(" ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal E}}")#text(" – a collection of abstract objects with operations such as ")#mi("{\\wedge}")#text(" and ")#mi("{\\vee}")#text(" (and ")#mi("{\\bigwedge_{n=1}^\\infty}")#text(" and ")#mi("{\\bigvee_{n=1}^\\infty}")#text(") that obey a number of axioms; see ")#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/")[#text("this previous post")]#text(" for a formal definition. The probability map ")#mi("{E \\mapsto {\\bf P}(E)}")#text(" can then be viewed as an abstract probability measure on ")#mi("{{\\mathcal E}}")#text(", that is to say a map from ")#mi("{{\\mathcal E}}")#text(" to ")#mi("{[0,1]}")#text(" that obeys the Kolmogorov axioms. Random variables ")#mi("{X}")#text(" taking values in a measurable space ")#mi("{(R, {\\mathcal B})}")#text(" can be identified with their pullback map ")#mi("{X^*: {\\mathcal B} \\rightarrow {\\mathcal E}}")#text(", which is the morphism of (abstract) ")#mi("{\\sigma}")#text("-algebras that sends a measurable set ")#mi("{S \\in {\\mathcal B}}")#text(" to the event ")#mi("{X \\in S}")#text(" in ")#mi("{{\\mathcal E}}")#text("; with some care one can then redefine all the operations in previous sections (e.g. applying a measurable map ")#mi("{f: R \\rightarrow S}")#text(" to a random variable ")#mi("{X}")#text(" taking values in ")#mi("{R}")#text(" to obtain a random variable ")#mi("{f(X)}")#text(" taking values in ")#mi("{S}")#text(") in terms of this pullback map, allowing one to define random variables satisfactorily in this abstract setting. The probability space models discussed above can then be viewed as ")#emph[#text("representations")]#text(" of abstract probability spaces by concrete ones. It turns out that (up to null events) any abstract probability space can be represented by a concrete one, a result known as the ")#emph[#text("Loomis-Sikorski theorem")]#text("; see ")#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/")[#text("this previous post")]#text(" for details.")

#text("Another, related, approach is to start not with the event space, but with the space of scalar random variables, and more specifically with the space ")#mi("{L^\\infty}")#text(" of ")#emph[#text("almost surely bounded")]#text(" scalar random variables ")#mi("{X}")#text(" (thus, there is a deterministic scalar ")#mi("{C}")#text(" such that ")#tao-math("{\\left|X\\right| \\leq C}", block: false)#text(" almost surely). It turns out that this space has the structure of a commutative tracial (abstract) ")#link("https://en.wikipedia.org/wiki/Von_Neumann_algebra")[#text("von Neumann algebra")]#text(". Conversely, starting from a commutative tracial von Neumann algebra one can form an abstract probability space (using the idempotent elements of the algebra as the events), and thus represent this algebra (up to null events) by a concrete probability space. This particular choice of probabilistic foundations is particularly convenient when one wishes to generalise classical probability to ")#emph[#text("noncommutative")]#text(" probability, as this is simply a matter of dropping the axiom that the von Neumann algebra is commutative. This leads in particular to the subjects of ")#link("https://en.wikipedia.org/wiki/Quantum_probability")[#text("quantum probability")]#text(" and ")#link("https://en.wikipedia.org/wiki/Free_probability")[#text("free probability")]#text(", which are generalisations of classical probability that are beyond the scope of this course (but see ")#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/")[#text("this blog post")]#text(" for an introduction to the latter, and ")#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/")[#text("this previous post")]#text(" for an abstract algebraic description of a probability space).")

#text("It is also possible to model continuous probability via a nonstandard version of discrete probability (or even finite probability), which removes some of the technicalities of measure theory at the cost of replacing them with the formalism of ")#link("https://en.wikipedia.org/wiki/Non-standard_analysis")[#text("nonstandard analysis")]#text(" instead. This approach was ")#link("http://www.ams.org/mathscinet-getitem?mr=906454")[#text("pioneered by Ed Nelson")]#text(", but will not be discussed further here. (See also ")#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/")[#text("these")]#text(" ")#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/")[#text("previous")]#text(" ")#link("https://terrytao.wordpress.com/2014/06/25/lebesgue-measure-as-the-invariant-factor-of-loeb-measure/")[#text("posts")]#text(" on the Loeb measure construction, which is a closely related way to combine the power of measure theory with the conveniences of nonstandard analysis.)")

#text("One can generalise the traditional, countably additive, form of probability by replacing countable additivity with finite additivity, but then one loses much of the ability to take limits or infinite sums, which reduces the amount of analysis one can perform in this setting. Still, finite additivity is good enough for many applications, particularly in discrete mathematics. An even broader generalisation is that of ")#emph[#text("qualitative")]#text(" probability, in which events that are neither almost surely true or almost surely false are not assigned any specific numerical probability between ")#mi("{0}")#text(" or ")#mi("{1}")#text(", but are simply assigned a symbol such as ")#mi("{I}")#text(" to indicate their indeterminate status; see ")#link("https://terrytao.wordpress.com/2013/11/16/qualitative-probability-theory-types-and-the-group-chunk-and-group-configuration-theorems/")[#text("this previous blog post")]#text(" for this generalisation, which can for instance be used to view the concept of a “generic point” in algebraic geometry or metric space topology in probabilistic terms.")

#text("There have been multiple attempts to move more radically beyond the paradigm of probability theory and its relatives as discussed above, in order to more accurately capture mathematically the concept of non-determinism. One family of approaches is based on replacing deterministic ")#emph[#text("logic")]#text(" by some sort of ")#link("https://en.wikipedia.org/wiki/Probabilistic_logic")[#text("probabilistic logic")]#text("; another is based on allowing several parameters in one’s model to be unknown (as opposed to being probabilistic random variables), leading to the area of ")#link("https://en.wikipedia.org/wiki/Uncertainty_quantification")[#text("uncertainty quantification")]#text(". These topics are well beyond the scope of this course.")

#heading(level: 1)[#text("Comments (163)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/982364535595cee2d77fafdb1416bd44103b34982ef4069f228bf3248807cf9c-7410c01346df81fe5c9a26a09d88fd2cb7ff08b62d8e32e5efa7d161e761260e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rajeeva Karandikar")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-517391")[#strong[#text("Rajeeva Karandikar")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2019")])]

#text("Dear Prof Tao,")#linebreak()#text(" This is regarding your comment about finitely additive probability theory : “One can generalise the traditional, countably additive, form of probability by replacing countable additivity with finite additivity, but then one loses much of the ability to take limits or infinite sums, which reduces the amount of analysis one can perform in this setting. Still, finite additivity is good enough for many applications, particularly in discrete mathematics.”")

#text("Well. Lots of limit theory can be done in finitely additive setting. Long ago, I had proven a meta-theorem: Almost all limit theorems that are true in countably additive setup are also true in finitely additive setup:")

#text("For the case of a sequence of independent random variables- see:")

#text("A General Principle For Limit Theorems In Finitely Additive Probability")

#text("Transactions Of The American Mathematical Society Volume 273, Number 2. October 1982")

#link("http://www.ams.org/journals/tran/1982-273-02/S0002…/S0002-9947-1982-0667159-6.pdf")[#text("Click to access S0002-9947-1982-0667159-6.pdf")]

#text("and for dependent case:")

#text("A general principle for limit theorems in finitely additive probability: The dependent case")

#text("Journal of Multivariate Analysis")#linebreak()#text(" Volume 24, Issue 2, February 1988, Pages 189-206")

#link("https://doi.org/10.1016/0047-259X(88)90035-8")[#text("https://doi.org/10.1016/0047-259X(88)90035-8")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae7e98cfe54bfc4f1e5d9b160718c15279a92accb5dd6bb56b9541cdc2799bf6-f46d222773ee7423ccb1d519d2e8b8a496be800ad85bacc5930b0f934a5f8cdd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quentin")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-520755")[#strong[#text("Quentin")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2019")])]

#text("Dear Professor Tao,")

#text("Regarding Exercise 29, let ")#mi("\\Omega")#text(" be the sample space and suppose that there exists ")#mi("\\omega\\in\\Omega")#text(" such that ")#mi("U\\left(\\omega\\right)=0")#text(". Is this possibility allowed by the definition of ")#mi("X^{-}")#text("? Isn’t ")#mi("\\left\\{ \\sup y\\in\\mathbb{R}:F\\left(y\\right)<0\\right\\}")#text(" undefined?")

#text("Thanks,")

#text("Quentin")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-520759")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2019")])]

#text("This possibility can only occur with probability 0, so this is not a major issue (all the usual concepts of probability continue to hold for random variables that are only defined almost surely, as long as one only works with at most countably many such random variables at once; cf. the discussion preceding Exercise 23).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 9 – second moment and entropy methods | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-528571")[#strong[#text("254A, Notes 9 – second moment and entropy methods | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2019")])]

#text("[…] space , but this distinction will not be so important in these notes and so we shall ignore it. See this previous set of notes for more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-534325")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2019")])]

#text("Dear Prof. Tao:")

#text("May I ask you if this course notes together with Durrett’s book are suitable for someone interested in learning probability theory and that also read your books on analysis?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-534376")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2019")])]

#text("These are notes for a first graduate course in probability; it would be expected that the students would already have been exposed to an undergraduate course in probability (similar to how students in a first course in real analysis would have been expected to already been exposed to single and multivariable calculus).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-542244")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2020")])]

#text("The link to Durrett’s book at the top of the post is now dead, but this Wayback link works: ")#link("https://web.archive.org/web/20141030190358if_/http://www.math.duke.edu:80/~rtd/PTE/PTE4_1.pdf")[#text("https://web.archive.org/web/20141030190358if_/http://www.math.duke.edu:80/~rtd/PTE/PTE4_1.pdf")]

#text("Can I ask if you like Rényi’s books “Foundations of Probability” and “Probability Theory”?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-542138")[#strong[#text("יומיות 03.10.2015: ספרי המדב”פ הטובים ביותר של אוקטובר, משחק ברווז וערב מפתחי משחקי מחשב בהאקרספייס, טרילוגיית קוטל המלכים, פורומים לקוסמים וע")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2020")]

#text("[…] טאו, המתמטיקאי החביב על הבלוג, מעביר קורס חדש: הבסיס של תורת ההסתברות. כרגיל אצל טאו, טקסט מלא של כל ההרצאות מופיע אצלו בבלוג. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-542625")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 February 2020")])]

#text("Dear Prof Tao,")

#text("In example 14, “product sigma-algebra B1xB2 is generated by E1xR2 and R1xE2”, I have difficulty understanding which set in B1 is E1 referring to since B1 contains many sets, if E1 means taking each set in B1 consecutively, wouldn’t it mean the product sigma-algebra is generated by R1xR2? Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-542629")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 February 2020")])]

#text("Sorry, I realize the problem of my last question, and figure out what is E1, please ignore the question and thank you for the wonderful notes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-548683")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2020")])]

#text("In the world of mathematics, there seems to be no difference between the notion of “Bayesian probability” and that of “frequentist probability”, which are very different in the realm of statistics. Are there axioms for these two notions? Or are they really the same thing in mathematics?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-593946")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2020")])]

#text("Let me reply on behalf.")#linebreak()#text(" So, let’s address the questions one by one.")#linebreak()#text(" 1. What is a “formal definition” of a probability ?")#linebreak()#text(" It comes from measure theory : a probability (or a probability measure) is a normalized finite measure.")#linebreak()#text(" The first definition of probability people (including myself) hear is usually the axiomatic definition named after Kolmogorov. But these two definitions (i.e., Kolmogorov’s axiomatic definition and the above mentioned measure theoretic definition) are exactly the same.")

#text("2. Do Bayesian and / or frequentists use a different definition of probability ?")#linebreak()#text(" NO. What they call a probability is also a normalized finite measure.")

#text("3.Do Bayesian and frequentists have different opinions on the notion of probability ?")#linebreak()#text(" YES. While the formal definition of probability remains the same always, the notion is slightly different. Frequentists believe in the long term behaviour to shape their probabilities. So, a frequentist would say that a fair coin has probability of showing heads = 0.5, because if you toss it many times, you’ll get roughly equal number of heads as the number of tails.")#linebreak()#text(" Bayesian statistics assumes a prior distribution of the parameters. So, for instance if you have a coin and you don’t know the probability that it will shows heads, then you may assume that the probability itself follows some distribution (this may be easier to understand if you consider several parallel events and the probabilities being sampled). This distribution depends on several factors (but I will not discuss about them over here).")

#text("Hope this resolves your doubt.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-608519")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2020")])]

#text("In the definition of indicator random variable, how to derive “E is true ")#mi("\\iff")#text(" ")#mi("\\omega \\in E_\\Omega")#text("?” I cannot find the definition of “E is true”, it seems not the same as “E is surely true” in Definition 1, thanks.")

#emph[#text("[This is done in the fifth bullet point after Example 3: the statement “")#mi("1_E = 1")#text(" is true when ")#mi("E")#text(" is true” is synonymous with “")#mi("1_{E_\\Omega}(\\omega)=1")#text(" is true when $\\omega \\in E_\\Omega$” for all models ")#mi("\\Omega")#text(" and all ")#mi("\\omega \\in \\Omega")#text(". -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-608709")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2020")])]

#text("Thank you!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-612304")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2020")])]

#text("In Definition 1, ")#emph[#text("what")]#text(" are (definiton of) “events” ")#mi("E")#text(" and ")#mi("F")#text("? It is clear that they are ")#emph[#text("modeled")]#text(" by “sets” ")#mi("E_\\Omega")#text(" and ")#mi("F_\\Omega")#text(". Is it intentional that they are somehow agnostic in this definition?")

#text("In the abstract-vs-models examples at the beginning of this text, the ")#emph[#text("abstract")]#text(" notions of vector spaces, groups, and manifolds are all “sets” (together with some other structure): the vector space ")#mi("V")#text(", the group ")#mi("G")#text(", and the manifold ")#mi("M")#text(". Are “events” in Definition 1 sets as well?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-612423")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2020")])]

#text("Yes, this is intentionally agnostic. Depending on one’s personal taste and the application at hand, one could think of an event in many different ways, such as")

#text("(1) A measurable subset of a sample space (identifying an event ")#mi("E")#text(" with its representative ")#mi("E_\\Omega")#text(" in some designated probability space model ")#mi("\\Omega")#text(");")

#text("(2) An element of an abstract sigma-complete Boolean algebra ")#mi("{\\mathcal B}")#text(" (which is equipped with a countably additive probability measure);")

#text("(3) An idempotent in an abstract commutative tracial von Neumann algebra (this is the noncommutative probability perspective);")

#text("(4) (if one has a sufficiently informal metamathematics) actual potentially realisable events in the physical universe;")

#text("(5) etc.")

#text("Only interpretation (1) actually views an event as a set; interpretations (2), (3) view events instead as elements of various abstract spaces. The spaces themselves are sets (with additional structures), but the events need not be. (To connect with the examples at the beginning of the text, a single event would be analogous to a single vector in an abstract vector space, a single group element of an abstract group, or a single point in an abstract manifold. These objects are typically not viewed primarily as sets, though in a pure set theoretic universe they could be modeled as such.) All of the above viewpoints are useful and so I choose to remain agnostic regarding which one is to be “preferred”; any interpretation is viable so long as it can be modeled by probability spaces in the manner indicated in this blog post. In particular if one wishes to avoid philosophical and foundational issues altogether one can simply go with interpretation (1) which is the route taken in most probability texts, though if one does so one can encounter conceptual difficulties whenever one wishes to extend the probability space to add more sources of randomness, as discussed in this post. (The presentation given in this post is probably most compatible with interpretation (2); presentations in other texts may be optimised for other interpretations.)")

#text("See also the discussion in Section 4 of this post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-612319")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2020")])]

#text("(I) On the one hand, in example 3, it is said that")

#text("… the sum ")#mi("{X+Y}")#text(" of the two die rolls is a random variable taking values in ")#mi("{\\{2,\\dots,12\\}}")#text("; it cannot be modeled by the sample space ")#mi("{\\Omega}")#text(", but in ")#mi("{\\Omega^{\\prime}}")#text(" it is modeled by the function")

#mi("\\displaystyle  (X+Y)_{\\Omega^{\\prime}}: (i,j) \\mapsto i+j.")

#text("(II) On the other hand, it is said after example 3 that")

#emph[#linebreak()#text(" Combining these two operations, given any function ")#mi("{f: R_1 \\times \\dots \\times R_n \\rightarrow S}")#text(" of ")#mi("{n}")#text(" variables in ranges ")#mi("{R_1,\\dots,R_n}")#text(", and random variables ")#mi("{X_1,\\dots,X_n}")#text(" taking values in ")#mi("{R_1,\\dots,R_n}")#text(" respectively, we can form a random variable ")#mi("{f(X_1,\\dots,X_n)}")#text(" taking values in ")#mi("{S}")#text(" by the formula")]

#mi("\\displaystyle  f(X_1,\\dots,X_n)_\\Omega: \\omega \\mapsto f((X_1)_\\Omega(\\omega),\\dots, (X_n)_{\\Omega}(\\omega)).")

#text("Thus for instance we can add, subtract, or multiply two scalar random variables to obtain another scalar random variable.")#linebreak()

#text("As a special case where ")#mi("n=2")#text(" in (II), can’t we model ")#mi("{X+Y}")#text(" in (I) by ")#mi("(X+Y)_{\\Omega}:=f(X,Y)_\\Omega=X_\\Omega+Y_\\Omega")#text(" with ")#mi("f(x,y)=x+y")#text("? Why is ")#mi("\\Omega^{\\prime}")#text(" necessary in (I) but not in (II)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-612402")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2020")])]

#text("Okay, this question seems to have been answered in this thread:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/")[#text("275A, Notes 0: Foundations of probability theory")]
]

#text("(II) ")#emph[#text("assumes")]#text(" that ")#mi("\\Omega")#text(" has been sufficient to model ")#mi("X")#text(" and ")#mi("Y")#text(" together, while in (I) ")#mi("\\Omega")#text(" is not sufficient.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81802423a19ab563c06add8c195d40b33845564cdef97e7e3f263b7e5b501f07-dca206cb5e3ced6f94efd0a9b764191e7c0d7da51ff1764a2f0cdd70700f9bb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ed Tam")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-612627")[#strong[#text("Ed Tam")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2020")])]

#text("Hi Terry,")

#text("In Exercise 18, I believe there is a small typo: it should be “R_n” instead of “R_m”.")

#text("Thanks!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-641763")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2022")])]

#text("In Example 3, consider the event ")#mi("A")#text(" being ")#mi("X=2")#text(" and ")#mi("Y=3")#text(". Then this event ")#mi("A")#text(" can be only modeled in ")#mi("\\Omega^{\\prime}")#text(", not ")#mi("\\Omega")#text(".")

#text("By counting in ")#mi("\\Omega^{\\prime}")#text(", one has ")#mi("P(A)=\\frac{1}{36}")#text(".")

#text("On the other hand, the probability can be “calculated/interpreted” as ")#mi("P(A)=P((X=2)_\\Omega)\\cdot P((X=3)_\\Omega)")#text(", where the right-hand side involves only events in the “smaller” model ")#mi("\\Omega")#text(". In this particular case, one finds the probability of an event that can be only modeled in ")#mi("\\Omega^{\\prime}")#text(" using only the information of the smaller model ")#mi("\\Omega")#text(".")

#text("Is this coincidence?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-641766")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2022")])]

#text("This occurs because we are modeling ")#link("https://en.wikipedia.org/wiki/Independent_and_identically_distributed_random_variables")[#text("independent identically distributed variables")]#text(" (iid) in this example. If one is modeling variables that are independent but not identically distributed (e.g., rolling a 6-sided die and then an 8-sided die), then one can model the joint variables by the product of several different probability spaces, each of which models one of the variables, but one cannot reduce all the probability computations to that of a single random variable as in the iid case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-642891")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2022")])]

#text("In Exercise 11, ")#mi("E")#text(" in ")#mi("\\Omega")#text(" should be I think ")#mi("E \\subseteq \\Omega.")

#text("This is a beautiful result that captures the good-set principle which as far as I have seen is one of the most widely used proving techniques in measure theory, and which in my opinion is a broader form of the well-ordering principle one uses in number theory (the connection is that here we can speak about smallest sigma algebra containing a collection of subsets of ")#mi("\\Omega")#text(" and in number theory one utilizes the existence of a smallest element of every non-empty subset of the natural numbers).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-674340")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2023")])]

#text("Reblogged this on ")#link("https://scoutmathematics.wordpress.com/2023/02/22/275a-notes-0-foundations-of-probability-theory/")[#text("Aditya Guha Roy's weblog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-680174")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" I want to make sure that I properly understand your remark following Corollary 27. By using the probability space model ")#mi("(\\mathbb R, \\mathcal B[\\mathbb R], \\mu)")#text(", any function ")#mi("{F: {\\mathbb R} \\rightarrow [0,1]}")#text(" obeying the properties (i)-(iii) can be seen as the CDF of the real random variable ")#mi("X")#text(" modeled by the identity map on ")#mi("\\mathbb R")#text(".")

#text("Conversely, given a real random variable ")#mi("X")#text(", modeled say on some ")#mi("(\\Omega, \\mathcal F, \\mu)")#text(", we can define the function ")#mi("\\mu^{\\prime}: \\mathcal B[\\mathbb R]: \\rightarrow [0, 1]")#text(" by ")#mi("\\mu^{\\prime}(S) = \\mu(X^{-1}(S))")#text(". By Example 12 ")#mi("\\mu^{\\prime}")#text(" is a probability measure on ")#mi("\\mathbb R")#text("(with the Borel ")#mi("\\sigma")#text("-algebra), as it’s essentially the probability measure ")#mi("\\mu")#text(" on ")#mi("\\Omega")#text("(with the pullback algebra ")#mi("X^*(\\mathcal B[\\mathbb R])")#text(". Then ")#mi("X")#text(" agrees in distribution to the the identity map on ")#mi("\\mathbb R")#text(", using the probability model ")#mi("(\\mathbb R, \\mathcal B[\\mathbb R], \\mu^{\\prime})")#text(".")

#text("Is this what you meant?")

#emph[#text("[Yes – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-680176")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2023")])]

#text("In the first paragraph I meant that by taking thr probability space to be ")#mi("{{\\mathbb R}}")#text(" with the Borel ")#mi("{\\sigma}")#text("-algebra and the Lebesgue-Stieltjes measure associated to ")#mi("{F}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ae709e4351caa78ecb5c5549127c27fe0e141b6036127389255b322082e9370-db00375cebf01103110634c72b4d811f003c27af23eb63b299d8694bceaf1b0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guanyuming He")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-686833")[#strong[#text("Guanyuming He")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2024")])]

#text("Dear Prof. Tao,")

#text("At the beginning you wrote,")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("However, for a variety of reasons, both within pure mathematics and in the applications of mathematics to other disciplines, it is often desirable to have a rigorous mathematical framework in which one can discuss ")#emph[#text("non-deterministic")]#text(" statements and variables …")
]

#text("About that, may I ask the dumb question that, except for providing a framework for applied math, what are the various reasons that we establish such rigorous frameworks? Roughly, in other words, I want to ask that:")

#emph[#text("Is nondeterminism necessary — is one’s reach (or results) limited if he does not consider nondeterminism at all?")]#text(" ")#emph[#text("Are there interesting connections between the nondeterminism framework and deterministic results?")]

#text("I don’t know much about math, but I can recall in computer science (my background) something about the necessity of nondeterminism. A most famous problem might be the P=NP? problem, where people wonder if deterministic and non-deterministic Turing machines have the same set of problems solvable in polynomial time. Another interesting thing is about randomized algorithms, which are algorithms that can only output a correct answer with some probability (although it can often be pushed as close to 1 as desired, by increasing running time or some other means). People have been wondering if randomness is necessary in fast (polynomial-time) algorithms by various attempts to derandomize famous polynomial-time randomized algorithms. For instance, given any natural number ")#mi("n")#text(", the challenge to find a prime number ")#mi("p > n")#text(" is easy by randomized algorithms but very hard to do deterministically in polynomial time. There have been many successful attempts, and once Impagliazzo & Wigderson ")#link("https://dl.acm.org/doi/10.1145/258533.258590")[#text("showed")]#text(" that randomness is not necessary to create fast algorithms, under some unproven assumptions.")

#text("Therefore, I want to ask about the necessity of nondeterminism in math and the various reasons beside application why people developed such rigorous frameworks.")

#text("Thank you for your time in advance. Yours truly, Guanyuming He")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-686834")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2024")])]

#text("I view the dividing line between pure and applied mathematics as extremely blurry, and so many of the justifications for non-deterministic methods in the more applied areas of mathematics can have analogues in pure mathematics. For instance, the ")#link("https://en.wikipedia.org/wiki/Probabilistic_method")[#text("probabilistic method")]#text(" in combinatorics can be viewed as a way of implementing non-deterministic constructions, in close analogy with randomized algorithms in theoretical computer science. In algebra, we have the fundamental concept of an ")#link("https://en.wikipedia.org/wiki/Indeterminate_(variable)")[#text("indeterminate variable")]#text(", and in algebraic geometry, we have the notion of a ")#link("https://en.wikipedia.org/wiki/Generic_point")[#text("generic point")]#text(". I interpret these concepts as also trying to capture a non-deterministic object (or at least, an object for which the precise deterministic nature is unimportant), although the standard formalism used to encode these concepts usually does not stress this point.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-687093")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2025")])]

#text("Hello Professor, this is regarding the discrete measurable space, Suppose a sample space has three outcomes {1,2,3}, results of rolling a three faced dice, I was wondering if the discrete measurable space only counts the subset {1,3} or {3,1} is also included as a seperate entity? or both are treated as one entity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-687109")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2025")])]

#text("The sets ")#mi("\\{1,3\\}")#text(" and ")#mi("\\{3,1\\}")#text(" are equal, by the axiom of extensionality: ")#link("https://en.wikipedia.org/wiki/Axiom_of_extensionality")[#text("https://en.wikipedia.org/wiki/Axiom_of_extensionality")]#text(" . If you wish to make a distinction of this type, one can use ordered tuples instead of sets: ")#mi("(1,3)")#text(" is not equal to ")#mi("(3,1)")#text(". (This has nothing to do with probability of course; this is just the basic notation of set theory. However, we use sets to construct probability spaces, as discussed in this blog post.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-687977")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2025")])]

#text("Dear Prof. Tao,")

#text("The link you give at the beginning of this set of notes to Durret’s book appears to be broken. You could consider to upgradei to ")#link("https://sites.math.duke.edu/~rtd/PTE/PTE5_011119.pdf")[#text("this")]#text(", alas the title of the document suggests that the problem would repeat itself too soon. I suggest to redirect to the ")#link("https://sites.math.duke.edu/~rtd/PTE/pte.html")[#text("html")]#text(" version instead, from which one can still download the pdf.")

#text("Thanks in advance.")

#text("[")#emph[#text("link updated – T.")]#text("]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ae709e4351caa78ecb5c5549127c27fe0e141b6036127389255b322082e9370-db00375cebf01103110634c72b4d811f003c27af23eb63b299d8694bceaf1b0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guanyuming He")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-688054")[#strong[#text("Guanyuming He")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2025")])]

#text("Dear Prof. Tao,")

#text("I have been trying to formalize a few results from my undergraduate probability class (that did not talk about formal foundations), using the formal foundation here. I met with a big obstacle in formalizing a seemingly trivial result:")

#text("Let ")#mi("i")#text(" be an integer in ")#mi("\\mathbf{Z}_n := \\{0,1, \\dots, n-1 \\}")#text(". One uniformly picks an integer from ")#mi("\\mathbf{Z}_n")#text(" (and discards it) until one encounters ")#mi("i")#text(". Then the average number of tries is approximately ")#mi("n/2")#text(".")

#text("My first attempt is to directly translate the reasoning I learned in my undergraduate class: each pick sequence can be seen as a permutation of ")#mi("\\mathbf{Z}_n")#text(". Thus, I define the sample space to be all permutations of ")#mi("\\mathbf{Z}_n")#text(", each is associated with an equal probability ")#mi("1/n!")#text(", and the formalization follows quite straightforward from here.")

#text("But I then realized that there’s a big gap: how can I arrive at each permutation’s being of equal probability from the assumption that each pick itself is uniform (first pick ")#mi("1/n")#text(", second ")#mi("1/(n-1)")#text(", and so on)?")

#text("Well, intuitively, it is not hard to figure out, as each permutation is the result of one of the first picks, one of the second picks, and so on, and thus its probability should equal to ")#mi("(\\frac{1}{n})(\\frac{1}{n-1})...(1) =  \\frac{1}{n!}")#text(". However, it feels pretty circular to me: to define the first sample space where each element associates ")#mi("\\frac{1}{n!}")#text(", I need to reason with probability elsewhere, and then I have to define that sample space first.")

#text("So I proceed to define the sample space in which I can formalize the above argument. I try to recursively define the sample space as ")#mi("\\Omega_0 := \\mathbf{Z}_n")#text(", and depending on the first pick ")#mi("a_0")#text(", ")#mi("\\Omega_1 := \\Omega_0 \\setminus \\{ a_0 \\}")#text(", and so on. Finally I take the Cartesian product of them. But the problem is that the definition is dependent on every step, which is non-deterministic.")

#text("I later realized that I could simply define ")#mi("\\Omega_0 := \\mathbf{Z}_n")#text(", ")#mi("\\Omega_1 := \\mathbf{Z}_{n-1}")#text(", ")#mi("\\Omega_2 := \\mathbf{Z}_{n-2}")#text(", just interpreting each number i as the ")#mi("i")#text("th element to pick from the remaining set. Then I happily try to take the Cartesian product of them, and sadly discovered that I went back to the original problem: I can’t assign a probability to each element of their Cartesian product, because I only know the probability of each step from the assumption!")

#text("Thus, I am quite stuck here and would wish to ask for help. I also have a feeling that such things will appear frequently in such formalizing attempts.")

#text("Thank you in advance,")#linebreak()#text("Guanyuming He")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-688055")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2025")])]

#text("I would work with a very small value of ")#mi("n")#text(", say ")#mi("n=2")#text(" or ")#mi("n=3")#text(", to try to figure out how to proceed here. You may find the ")#link("https://en.wikipedia.org/wiki/Law_of_total_probability")[#text("law of total probability")]#text(" to be useful.")

#text("This would also be a good opportunity to learn a formal proof assistant language, such as Lean (which has reasonably good support for probability theory).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ae709e4351caa78ecb5c5549127c27fe0e141b6036127389255b322082e9370-db00375cebf01103110634c72b4d811f003c27af23eb63b299d8694bceaf1b0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guanyuming He")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-688057")[#strong[#text("Guanyuming He")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2025")])]

#text("Dear Prof. Tao,")

#text("Replying to your first paragraph, by reasoning with a small ")#mi("n")#text(", I did find a better way to build the sample space, as the set of all sequences that ends with ")#mi("i")#text(", the element I want to pick.")

#text("But one source of my confusion still remains. The assignment of the probability to each element in the sample space isn’t immediately obtainable from the problem description, requiring some reasoning of probability first. I think it is related to ")#link("https://terrytao.wordpress.com/books/analysis-i/comment-page-16/#comment-687841")[#text("what you replied to me")]#text(" under Analysis I, in the sense that we first use an external probability system to reason about the assignment of probability to elements in the sample space, and then use the sample space to reason about the internal probability I am studying. I think it also presents in your example of tossing a die twice where you defined ")#mi("\\Omega^{\\prime} := \\{1, \\dots ,6\\} \\times \\{1, \\dots ,6\\}")#text(". The source of randomness comes from each toss, but the sample space seems to model the outcome instead of directly modelling the source, and as a result, although trivial, one would need to first reason externally about probability to assign ")#mi("1/36")#text(" to each element there.")

#text("Among all my attempts, I think the one defining ")#mi("\\Omega := \\mathbf{Z}_n \\times \\mathbf{Z}_{n-1} \\times \\cdots \\mathbf{Z}_1")#text(" is closest to capturing the source of randomness directly. And it turns out that I can transform this sample space into all the set of all permutations, and also into the one I mentioned at the beginning. Still, it seems that I cannot escape from the problem of having to reason about probability first using some external system, before I can assign each element a probability.")

#text("It is to reply to your first paragraph only, because I haven’t looked into how people use Lean to formalize probability yet. Probably I will find new inspirations there.")

#text("Thank you again,")#linebreak()#text("Guanyuming He")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-688061")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2025")])]

#text("While the final proof of a result can only use non-circular reasoning, it is perfectly fine (and in fact highly encouraged) to use circular reasoning (such as assuming a result or theory you are trying to establish) as heuristics in order to ")#emph[#text("locate")]#text(" the desired final proof. So you can assume heuristically that the probability space you seek already exists, use that to figure out what the probability distribution ")#emph[#text("ought")]#text(" to be, and then use that to motivate the definition for your construction, which you then verify separately, independently of the heuristic motivation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ae709e4351caa78ecb5c5549127c27fe0e141b6036127389255b322082e9370-db00375cebf01103110634c72b4d811f003c27af23eb63b299d8694bceaf1b0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guanyuming He")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-688058")[#strong[#text("Guanyuming He")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2025")])]

#text("As an analogy, assume we need to have a Java class ")#emph[#text("SampleSpace")]#text(" to reason about probability. But inside the constructor of ")#emph[#text("SampleSpace")]#text(", we need to reason about probability too, and thus need to construct another ")#emph[#text("SampleSpace")]#text(" first.")

#text("I read what you wrote that a sample space is just a model, but we can’t formally talk about a concept without a model first, I guess; and I think it’s the reason why we need to have an external system of natural numbers first before we formally study proofs.")

#text("Do I understand the issue correctly?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-688806")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2025")])]

#text("Dear Prof. Tao,")#linebreak()#text("I have been confused about some terms in probability.")#linebreak()#text("(a) In this blog you mention that ”…non-deterministic ")#strong[#text("variables")]#text(" are referred to as random variables…” , but the wiki says a random variable is a ")#strong[#text("function")]#text(". If this is true, I wonder why mathematicians would call it random variables.")#linebreak()#text("(b) I am also confused about the term probability distribution, I read your article Distributions in the Princeton Companion, but I cannot find the connection between these two words. Is probability distribution the ”distribution(generalized functions)”?")#linebreak()#text("(c) Many concepts related to probability distributions can be quite confusing, such as distribution, distribution function and density function… Can you give me a intuitive description (or motivation) of the probability distribution?")#linebreak()#text("I apologize in advance for my ignorance ,and thank you for taking the time to reply!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-688808")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2025")])]

#text("Technically, I view functions such as ")#mi("X_\\Omega: \\Omega \\to {\\bf R}")#text(" as a *model* of a random variable ")#mi("X")#text(", rather than the random variable itself, as per the ")#link("https://en.wikipedia.org/wiki/Map%E2%80%93territory_relation")[#text("map-territory relation")]#text(". However, in many situations it is fine to elide this rather philosophical distinction and say that random variables *are* functions, as opposed to being modeled by functions; this is the approach taken by Wikipedia for instance. [The main situation in which the distinction becomes relevant is if one wishes at some point to enlarge the ambient sample space of possible events, without changing the essential features of the random variables that were previously introduced.]")

#text("Probability distributions are a type of measure, which are in turn a type of distribution in the sense of Schwartz; apparently Schwartz was motivated in his choice of terminology more by distributions of electric charges than distributions of probability, though the terms are broadly similar in theme. In general, physical distributions such as mass distribution or charge distribution can be one type of analogy that can help gain intuition on probability distributions (with measure theory (and more generally, distribution theory) being the unifying mathematical theory that can describe all of these types of distributions).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/254a2b1475d9570003dcf1d7e6f0dba68720739e2820d2607021e907313e9e4d-3fd0b15b2d789886545d7520ea9f1aee26ae36ba418c664dd003dc5066cda1ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-688873")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2025")])]

#text("Is the Skorokhod theorem and example of an enraging of the probability space you talk about ?")

#text("And if yes, can you explain what we “loose” when we apply the Skorokhod theorem.")

#text("Thanks !")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-688874")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2025")])]

#text("Strictly speaking the Skorohod thoerem would be swapping a sequence of probability spaces with a common probability space that is not necessarily an extension of the previous spaces, so if the previous random variables were already coupled in some way with other variables, then this coupling would be lost when passing to the Skorohod-provided space. But presumably one could develop fancier versions of this theorem that could also transfer over additional variables and their couplings.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-689092")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2025")])]

#text("Hi prof. ,")

#text("Wouldn’t the equality of limsup and liminf while defining the limit of a sequence of random variables, be the definition of pointwise convergence (unless we think of equality as equivalence as mentioned earlier in the notes)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-689218")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2025")])]

#text("Prof. Tao,")

#text("I am confused about some terms you used:")

#text("(a) What do you mean “canonical”? Is it mean “natural” or “standard” or something else?")

#text("(b) You said that “one could extend the sample space by adding in new sources of randomness”, so what are sources of randomness?")

#text("(c) I have seen the term “couple” in other fields of mathematics, but I don’t quite understand what it means.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-689219")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2025")])]

#text("a) It’s not a fully precise term, but the various answers at ")#link("https://mathoverflow.net/questions/19644/what-is-the-definition-of-canonical")[#text("https://mathoverflow.net/questions/19644/what-is-the-definition-of-canonical")]#text(" should convey the general sense.")

#text("b) In the physical world, common sources of randomness (or pseudorandomness) include coin flips, dice rolls, drawing cards from a shuffled deck, or using some sort of random number generator. Mathematically, this might be modeled by a product space construction; for instance, if one wants to add another die roll to one’s sample space ")#mi("\\Omega")#text(", one could replace that sample space with the product space ")#mi("\\Omega \\times \\{1,\\dots,6\\}")#text(" with the product measure.")

#text("c) See ")#link("https://en.wikipedia.org/wiki/Coupling_(probability)")[#text("https://en.wikipedia.org/wiki/Coupling_(probability)")]#text(" . Couplings between random variables can range from a fully decoupled situation in which the random variables are independent, to a completely coupled setting in which one random variable is a deterministic function of the other, to various intermediate levels of coupling in between. The measure-theoretic analogue of this concept is that of a “joining”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-689235")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2025")])]

#text("Dr Tao,")

#text("I found one small typo: in Example 3, …the discrete “proability” space… should be: the discrete “probability” space.")

#text("Due to my ignorance, I would like to ask:")

#text("(a) I notice you said: “a sample space(which will be given the structure of a probability space) to capture all the ambient sources of randomness”. In the spirit of “viewing mathematical structure as a package” (which is the MO answer you gaved), when a ordinary set X is equipped with the Probability Space structure, this means X is equipped with a package of various probabilistic notions like the Expectation, the Variance, the Independence, and so forth, right? Am I missing something essential?")

#text("(b) Since there is a strong connection between Probability Theory and Mathematical Statistics, I wonder whether there might exist something that could be referred to as a “statistical structure” or “statistics structure”? If such a structure does exist, how is it connected to probabilistic structures?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-689237")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2025")])]

#text("Typo corrected, thanks.")

#text("Yes, a “package”-oriented view to probability would contain all of the notions you mention as components.")

#text("Statistics is a somewhat different discipline from the various subfields of mathematics (including probability), because it is concerned with fitting real-world data to mathematical models, whereas probability is concerned with the study of such models and their predictions, without matching it to real-world data. The real-world data can itself be modeled in various metamathematical ways, but one has to make some philosophical choices in this regard (e.g., making some selection of Bayesian priors); one can try to use mathematical language, such as the language of probability, to perform this metamathematics, but one can also reason about real-world data in other non-mathematical ways, and one should not insist on a purely mathematical approach to this side of statistics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-689238")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2025")])]

#metadata(none) <tao-39e3a5cbc551b98c80a6>

#text("Thanks for your explanation!")

#metadata(none) <tao-a60d5f00e2db41e01f42>

#text("I am a statistics undergrad. and I don’t have as extensive knowledge as you do, so I want to gain different perspectives on how to view things.")

#metadata(none) <tao-c0df7af09bc3bbc5a108>

#text("Could you please explain more on what you said “the philosophical choices in this regard (e.g., making some selection of Bayesian priors)”?")

#metadata(none) <tao-a0d1e4374aff6cbc7083>

#text("What different philosophical choices there are? And what advantages different philosophies bring when approaching the same question?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-689435")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2025")])]

#text("Dear Tao,")

#text("Why is the foundation of modern probability theory built upon measure theory rather than on other theoretical frameworks? Like σ-algebra, measurable subsets, measurable functions, and so forth, why did Kolmogorov choose measure theory as the model of probability theory?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-689437")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2025")])]

#text("I am not an expert on the history of the era, but Kolmogorov was certainly trained in measure theory and recognized the need to have a foundation that could rigorously handle countable operations such as infinite sums and pointwise (almost sure) limits in a manageable fashion. Other, essentially equivalent, frameworks are known, such as ones based on commutative von Neumann algebras, but measure theory was available, well developed, and supported all the operations needed for probability theory (except possibly in some technical instances involving infinitely many random variables taking values in pathological spaces, but these are rare), and is also teachable in graduate math classes, so is good enough for most purposes. In principle one could imagine an alternate history where other foundations were adopted as the orthodox foundation, however.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-689493")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2025")])]

#text("Dear Dr Tao,")

#text("When you difine disjunction, there are two repeated words “…the the…”. [Corrected, thanks – T.]")

#text("I found that the “model-objects” perspective quite useful, but I would like to ask: Are the statistics terms “population” and “sample” ")#strong[#text("modeled")]#text(" by “probability distribution” and “random variable”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-689514")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2025")])]

#text("Dear Dr Tao, am I wrong about these? What are the model of sample and population in lingos of probability theory?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-689545")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2026")])]

#text("These sorts of ")#link("https://terrytao.wordpress.com/career-advice/theres-more-to-mathematics-than-rigour-and-proofs/")[#text("postrigorous")]#text(" questions will be more satisfactorily resolved for you once you have more technical facility with both probability and statistics. In particular I would recommend working out some concrete numerical problems (involving, say, sampling from a large population) in both subjects, and then asking yourself these questions in the specific context of these problems.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-689541")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2026")])]

#metadata(none) <tao-9d983bf379aa1fe01d4d>

#text("Dr Tao,")

#metadata(none) <tao-74e3e3377ddbe83328f3>

#text("Why would we define that Stieltjesmeasurefunction is right-continuous instead of left-continuous? Also, why do we define CDF to be P(X≤t) instead of P(X≥t)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-689543")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2026")])]

#text("These are somewhat arbitrary sign conventions; one could have set up the entire theory with the opposite conventions (but then there would be more conflicts with other literature sources). It’s similar to how, in a given country, it is important to decide whether vehicles should all drive on the left, or all drive on the right; there are few significant advantages of one choice over another, yet it is still important to break the symmetry and make the choice.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-691703")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2026")])]

#text("Dear Prof. Tao,")

#text("It seems that probabilists would choose the structure of Borel σ-algebra instead of σ-algebra in probability theory. But in measure theory it seems that the structure of σ-algebra is more common that borel σ-algebra. Could you please explain what leads to this distinction?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-691705")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2026")])]

#text("I am ")#link("https://gemini.google.com/share/680d7b2671c3")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-691709")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2026")])]

#text("I noticed that in several recent posts you’ve been outsourcing certain exploratory questions to AI tools, first ChatGPT and more recently Gemini.")

#text("Have you formed any impressions about their relative performance for this kind of task? In particular, do you find Gemini preferable for questions similar to the ones you’ve been outsourcing, or are they largely interchangeable in your experience?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-691726")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2026")])]

#text("Dr Tao,")

#text("Why is the definition of Lebesgue measure you used in these probability theory notes different from the one in your measure theory textbook?")

#text("Additionally, I would like to ask: in modern probability theory, do probabilists treat Lebesgue measure as a black box and ignore its tricky construction?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-691727")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2026")])]

#text("The definitions are equivalent (basically due to all the uniqueness properties of Lebesgue measure), so whichever one one selects for any given text is a matter of taste more than anything else.")

#text("It is indeed true that the construction of measures such as Lebesgue measure is not the main focus of most probability texts, including my own, so I selected a definition here which was as easy to ")#emph[#text("state")]#text(" as possible (assuming that existence, uniqueness, and equivalence to other standard definitions can be proven somehow), whereas in a measure theory text it is often useful to instead give a definition of Lebesgue measure that makes it as easy to ")#emph[#text("construct")]#text(" as possible (which is a very different standard).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-691816")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2026")])]

#text("Professor,")

#text("Both CDF and PDF are used to describe probability distributions. Thus, what are the distinctions in the focus of these two concepts?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-691817")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2026")])]

#text("I am ")#link("https://gemini.google.com/share/6d78a24528e0")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-692075")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2026")])]

#text("Dear Prof Tao,")

#text("I am confused about what you wrote in Remark 13: ")#emph[#text("The pullback then represents all the “information” one can extract from that given set of measurements.")]

#text("I remember that you have mentioned that the distribution μ_X captures all the probabilistic information one wants to know about a random variable X. But μ_X is a pushforward instead of a pullback. What am I missing here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-692085")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2026")])]

#text("I am ")#link("https://claude.ai/share/e2d73f60-dd64-46f7-96d9-5b45fdbfb22e")[#text("outsourcing this question to an AI")]#text(". Note also that the pullback of a sigma algebra was defined in the preceding example (Example 12).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-692682")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2026")])]

#text("Does the Skorokhod representation (of scalar variables) has any direct or indirect connections to the Skorokhod representation theorem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-692687")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2026")])]

#text("I am ")#link("https://claude.ai/share/1f70076b-7293-4813-a61f-d6739e1dc124")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-692728")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2026")])]

#text("Dear Prof. Tao,")

#text("In Section 1, you highlight the “map-territory” distinction between abstract probabilistic concepts and their concrete models. Can both frequentist probability and Bayesian probability also adopt the perspective you mentioned?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-692768")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2026")])]

#text("I am ")#link("https://claude.ai/share/1c3ab1af-3e5f-4b7c-b011-60afc6bccd1a")[#text("outsourcing this question to an AI")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-692826")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2026")])]

#text("Do you have a preference for frequentist or Bayesian approach, or do you remain neutral?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-2/#comment-693233")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2026")])]

#text("This is a wonderful post. The question I want to ask is: the objects of study in many fields are inherently deterministic and do not possess randomness in themselves. But after introducing random structures, such as turning graphs into random graphs, matrices into random matrices— what is the reason for introducing random structures into deterministic objects?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/170ab5070c5da5909eef21733dff6ef8348db84ec9cf8e1343d42959d66dd6e0-494626b32aa27f7c1e66b016d4913357e06f0ce8898a381e368dfbf71ec44482.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-459865")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2015")])]

#link("https://www.academia.edu/3247833/Statistical_induction_and_prediction")[#text("https://www.academia.edu/3247833/Statistical_induction_and_prediction")]#text(" This useful elementary result is not widely known.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-459961")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2015")])]

#text("Is this available anywhere else, like arxiv.org? There doesn’t seem to be a way to download it without enrolling on that annoying academia.edu social media site. Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460171")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2015")])]

#text("Sorry, I was not aware that academia.edu is annoying. Here is a dropbox link. ")#link("https://www.dropbox.com/s/yzxugqjxigkpw5b/Induction.pdf?dl=0")[#text("https://www.dropbox.com/s/yzxugqjxigkpw5b/Induction.pdf?dl=0")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/383858e782b35410f016eecda45aec7577f086cd92516987aef70bcc4836c3da-b0e4263578a2a364c03e0061ecedfe6716740b71930160a287a486f8c04e93f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-459875")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2015")])]

#text("Since these notes will have also a focus on foundations, it would be interesting to point out the connection of Kolmogorov’s axioms for probability to (quantifying) plausible reasoning via the connection of ")#mi("\\sigma")#text("-algebras to Boolean ")#mi("\\sigma")#text("-algebras provided by the Loomis-Sikorski theorem, so that probability measures amount to “generalized truth” functions, so to speak.")

#emph[#text("[This point is briefly covered in the final section of the notes – T.]")]#emph[]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5a49c892c8aed4236f553593502260ff325d400e183ec6fd93524317f6acb643-889b6be4d0e411f6eecd93a86c00c4f25e106b1f019a1723b0ee6b48591db702.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Thomas")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-459882")[#strong[#text("Scott Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2015")])]

#text("I look forward to reading the notes. I do wonder why Durrett’s book was chosen, however. It has a nasty reputation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf321d2381e42eadefd8656eac9e6e7b6d3ff9a7151d5d15179969026eac88b8-6feb69172594a33a6fb9335aa62951fddf7db2d141a6be16bbeb13cf2f217a2a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brendan Murphy")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-459886")[#strong[#text("Brendan Murphy")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2015")])]

#text("Durrett’s book is free and covers the standard topics. I liked some of the problems in it as well. Maybe it’s not the best choice for self-study, but as an adjunct to a graduate course it’s pretty good.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f316a54015e487680737fce3241ec92455593512c6fc61ecff9325c2b9926943-b75b6c8c11f46dd61a2dbb240d96bee50df78c87e9b4f2544019b01bc796e968.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D Ghatak")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-459896")[#strong[#text("D Ghatak")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2015")])]

#text("Which book is a good choice for self-study?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-459962")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2015")])]

#text("I’ve found Wikipedia’s coverage to be pretty good, though maybe it’s rotted my mind. I’m looking forward to following these notes. There’ are a couple of well-known books by Alfréd Rényi that I’ve been wanting to read but so far I’ve only looked at a few pages.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f316a54015e487680737fce3241ec92455593512c6fc61ecff9325c2b9926943-b75b6c8c11f46dd61a2dbb240d96bee50df78c87e9b4f2544019b01bc796e968.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D Ghatak")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-459969")[#strong[#text("D Ghatak")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2015")])]

#text("Thanks.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ff40b9c549307a372d57622e0e192454a08176dbd09c89de9f786b7eca01851-b6f70a52522248bc064fdd70e4ad8496fd2627600f5a83956366f8f17d5edf96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jldohmann")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460002")[#strong[#text("jldohmann")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2015")])]

#text("Durrett’s book is pretty standard, at least in my experience with probability and stochastics courses. He also has interesting advanced topics, like his book on random graph dynamics (that i’m currently reading) which his previous books sort of set the stage for. Though I agree, he’s not always the easiest to read.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad3f3a79ef213c98c05db1ab441cb92661583507ac1a7a5e31f4beaa785f1e3b-bd0c7862157994459c7704585bcfde3a1c363765d691789fd896ca4a5396e667.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Martin")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-459891")[#strong[#text("Greg Martin")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2015")])]

#text("Excellent post! In Definition 21, you write “We then model an event {E} by subsets {E_\\Omega} of the sample space {\\Omega}.” Should that instead be “We then model an event {E} by elements {E_\\Omega} of the {\\sigma}-algebra {\\mathcal F}”, or is there a nuance I’m missing that makes the original phrasing more appropriate?")#linebreak()#text(" (Also, a typo: in Exercise 23, the penultimate curly bracket of the penultimate math expression should be a close-bracket rather than open-bracket.)")

#emph[#text("[Sorry, that was a result of a careless cut-and-paste, now corrected. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460640")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2015")])]

#text("The subsequent example makes it clear that Definition 1 should read")#linebreak()#text(" “We then model an event {E} by a subset {E_\\Omega} of the sample space {\\Omega}.”")#linebreak()#text(" or more readably")#linebreak()#text(" “We then model events {E} by subsets {E_\\Omega} of the sample space {\\Omega}.”")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbcc43d1cec42c3efe2dd1870eba6f8dd86cc19d21a6a6226000d3afd7973b43-7519701d53f0c3768a6d515c92400ff93af41299bc34751d8a3ba47fc61cb921.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-459928")[#strong[#text("James")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2015")])]

#text("Dear Terrence:")

#text("Have you read or browsed ‘Probability: The Logic of Science’ by the late physicist E.T. Jaynes, and if so, what did you think of it, and would you ever consider using it for parts of such a course?")

#text("Sincerely,")#linebreak()#text(" James")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460009")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2015")])]

#text("I have not looked in detail at this text, but it may be more suitable for a foundations of probability course rather than a graduate mathematics course in probability like this one. (This current set of notes is indeed devoted to foundations, but the bulk of the course will not be.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460080")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("Do you ever have the intention of doing a foundations course and offering your opinions there?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e49d537d57f8aeb01edf8c94fbd7731457fcae8b276a5081e8e4fe2d8ebf6318-810704db2063670971780639c00c79394b533a6bf8b444027f59ed2412a0e16f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-459934")[#strong[#text("Chris")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2015")])]

#text("From the measure-theoretic point of view a “random variable” $X$ is considered as a deterministic function (as defined above). On the other hand, in practice one often just writes something like $X \\sim N(\\mu,\\sigma)$ to signify the random variable is distributed as the normal distribution for example, say, without reference to any sample spaces. The above corollary shows this suffices in practices as only the CDF really matters. The question that has always been a bit of a puzzle from a foundations point of view is how to interpret the randomness of the so-called random variable? How does the random variable modelling, say, a coin toss as an explicit function from a sample space fit with the practice of generating a coin toss, either by computer or with physical coins (which is determined by the CDF)? A related corollary issue come with the related concept of a “statistic”, which is taken to be some function of a random variable or several such, and what can be realised/explicitly calculated from a given set of data.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-459960")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2015")])]

#text("It is the ")#link("https://en.wikipedia.org/wiki/Equidistributed_sequence")[#text("equidistribution")]#text(" of many “real-life” processes that allow them to be usefully modeled by probability theory, even if they are ultimately generated by some deterministic physical or mathematical law. For instance, a well-designed ")#link("https://en.wikipedia.org/wiki/Pseudorandomness")[#text("pseudorandom")]#text(" number generator is deterministic, but asymptotically has the same statistics as a genuinely random number generator, and so can be accurately modeled by such.")

#text("To me, the more interesting phenomenon is that of ")#emph[#text("universality")]#text(" – not only can complex systems be modeled by probability theory, but moreover one only needs to use a small set of universal probability distributions (e.g. gaussian, uniform, GUE, etc.) to model such systems, almost irrespective of the underlying mechanics of that system. I discuss this phenomenon in ")#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/")[#text("this previous post")]#text(". Probability theory can help explain this phenomenon by establishing universality results such as the central limit theorem.")

#text("By the way, the CDF of a random variable ")#mi("X")#text(" only serves to accurately model that random variable in isolation. If that variable is to be coupled with other random variables, knowing the CDFs of the individual random variables is no longer sufficient (unless one assumes joint independence of these variables); one must know the full joint CDF instead.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e49d537d57f8aeb01edf8c94fbd7731457fcae8b276a5081e8e4fe2d8ebf6318-810704db2063670971780639c00c79394b533a6bf8b444027f59ed2412a0e16f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-459974")[#strong[#text("Chris")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2015")])]

#text("On the foundation aspect I just want to draw attention to the “lingo” used to bridge between the thinking behind the concept as it is used in applications and the realisation in a mathematical framework. Something like… to answer the question “What is meant by a random variable?” we could say: A random variable is a variable that takes on different values depending on the outcome of a “random event”. Or: A random variable is a variable whose value depends on “unknown events”, where we can summarise the unknown events as a set of outcomes in a sample space so that the random variable can be considered as a function from this space to a set of values (hence the above measure function formulation). The stats textbooks often ignore or don’t mention the event space, as Corollary 26 or 29 are effectively invoked in most cases, and certainly don’t point out that the sample space may need extending or augmenting even though the exact set of outcomes/events might be irrelevant (philosophically very much like the atlas is not normally referred to explicitly in Differential Geometry).")

#text("On the universality aspect I think it is important to emphasis the framework popularised by K Pearson / RA Fisher in the way many of the probability models have in mind some Epidemiology/Biostatistics application or philosophy underpinning them (since the research branch was developed from such “model” problems). The particularly statistical/probability terminology used reflects this and the meaning and interpretation that surounds the concepts is often important to be clear on (as it is often subject to misunderstanding).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-459993")[#strong[#text("Bookmarks for October 1st through October 2nd | Chris's Digital Detritus")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2015")]

#text("[…] 275A, Notes 0: Foundations of probability theory | What’s new – […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/821f2df740c79cb09603b0b4b5fdc0c7033ce5b1205e436bb514259f77e90d32-8b04166d786e3df048df23a13b92a0d667c17edcce7c30fea53eec06d1df724d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Byron Schmuland")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460000")[#strong[#text("Byron Schmuland")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2015")])]

#text("Thanks very much for posting this!")

#text("A minor point: Durrett’s surname has two “r”s.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a194655935be0ff77ccad47f6a58cb18b1a9c5d02db43cd15e907a59bd2ae762-fd3dc93cf83f9ca056b0976e93d651b992fd20a62b2d032463de027ee8f38005.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Travis")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460003")[#strong[#text("Travis")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2015")])]

#text("In Definition #1, the discrete sample space ")#mi("\\Omega")#text(" is defined in terms of itself using ")#mi("\\Omega")#text(" again. Is this circular definition intentional? Why not use a different designation for the discrete sample space?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460004")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2015")])]

#mi("\\Omega")#text(" is used here as a ")#link("https://en.wikipedia.org/wiki/Synecdoche")[#text("synecdoche")]#text(", which is a standard convention in mathematics when referring to a structured space. For instance a group is formally a tuple ")#mi("(G, \\cdot, e, ()^{-1})")#text(" consisting of a set ")#mi("G")#text(" together with various operations on it, but we usually abbreviate it via synecdoche as just ")#mi("G")#text(", thus by abuse of notation ")#mi("G = (G, \\cdot, e, ()^{-1})")#text(". Similarly for vector spaces, topological spaces, rings, fields, manifolds, metric spaces, etc..")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd399e859e4769d93169a0844e6e08cdd218b05eda4619900a7bc5c0ead78445-9ba0c3652aedcdf100874fb53f20cb42f2a3c87b6720104be6a7e21d4f525409.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tapen Sinha")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460032")[#strong[#text("Tapen Sinha")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2015")])]

#text("Jumping from the finitely additive probabilities to the countably additive ones looks deceptively simple but it is not. Rajeeva Karandikar has a beautiful lecture on the subject. He should know. He has done some deep work on that matter.")

#link("http://math.iisc.ernet.in/~imi/downloads/LimitTheoremsFinitelyAdditiveProbability3.pdf")[#text("Click to access LimitTheoremsFinitelyAdditiveProbability3.pdf")]

#text("Tapen Sinha")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/982364535595cee2d77fafdb1416bd44103b34982ef4069f228bf3248807cf9c-7410c01346df81fe5c9a26a09d88fd2cb7ff08b62d8e32e5efa7d161e761260e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rajeeva Karandikar")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460045")[#strong[#text("Rajeeva Karandikar")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("I would like to elaborate a little on what my friend Tapen Sinha has mentioned.")

#text("One naively believes that it is countably additivity assumptions that enables us to prove limit theorems in probability theory. This is not quite correct. I had shown that almost all limit theorems with convergence in law or convergence in distribution that are true in Countably additive framework are also true in the finitely additive framework.")

#text("See:")

#link("http://goo.gl/uHxANk")[#text("http://goo.gl/uHxANk")]#text(" (paper from Transactions of AMS, 1982)")#linebreak()#text(" and")#linebreak()#text(" ")#link("http://goo.gl/KuOHgq")[#text("http://goo.gl/KuOHgq")]#text(" (paper from Journal of Multivariate Analysis, 1988).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59f9f0b83a52d3783947a9e8ccd9f678d3e8f512f7bd70b53bc6edeaeb96fe45-8ca135ef6847cf14d67a73f7baf6bc57abd733c58d55e960f98f24e063e483e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of First new cache-coherence mechanism in 30 years « Pink Iguana")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460048")[#strong[#text("First new cache-coherence mechanism in 30 years « Pink Iguana")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("[…] Terry Tao, What’s New, 275A, Notes 0: Foundations of probability theory, here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 1: Integration and expectation | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460064")[#strong[#text("275A, Notes 1: Integration and expectation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("[…] Notes 0, we introduced the notion of a measure space , which includes as a special case the notion of a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460070")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("Dear Terry,")

#text("I’m not sure that base change in algebraic geometry is a good example of the modelling you have in mind. It is quite different from coordinate changes in linear algebra and differential geometry. For one thing, it is irreversible; one can base change from ")#mi("\\mathbf{R}")#text(" to ")#mi("\\mathbf{C}")#text(" but not the other way around.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460074")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("Actually, it is this irreversibility that made me include base change in the list of analogues to changing the probabilistic model, because there is a similar irreversibility in probability: one can extend a sample space to a larger one by adding more sources of randomness, but one cannot reverse the process and reduce back to a smaller space (because events and random variables that are measurable in the larger model may cease to be measurable in the smaller model).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460076")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("Would you have an example to illustrate this irreversibility for sample spaces?")

#text("As for base change, it is not clear to me what the invariant thing that schemes under different bases are modeling. One guess would be the underlying defining equations. However, I usually see it done the other way: that the defining equations are models giving a concrete realization of a variety in affine space.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460111")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2015")])]

#text("See Example 3: one always has the freedom to extend the sample space to a larger space, but not conversely (one can only pass back down to the smaller space if one has discarded all the events and random variables that cannot be modeled in that smaller space).")

#text("The base change analogy is not perfect because the original scheme embeds into the larger scheme, rather than being a quotient (or factor) of it; for instance a variety over the reals embeds into the same variety over the complex numbers, in contrast to probabilistic spaces where the extended space projects back down to the original space. Of course, the change of linear basis analogy (or the change of coordinates analogy) are not perfect either, since in these cases the models are isomorphic rather than being related by an embedding or a projection. However they still are examples of the general theme of distinguishing abstract mathematical objects from their concrete models in order to be able to change the latter without disrupting the former, and my main point was that this distinction is not some quirk unique to probability theory but is in fact pervasive throughout modern mathematics, albeit in somewhat different forms as one goes from one subfield of mathematics to another.")

#text("(Perhaps a closer analogy would be some sort of “numerical base change” in which a variety that is being computationally modeled by (say) single-precision reals, is instead modeled by the extended model of double-precision reals, since in this case it is more natural to project the latter to the former than to embed the former in the latter, but this is not a concept that is well suited for formalisation in modern algebraic geometry.)")

#text("ADDED LATER: The base change analogy looks more aligned with probabilistic language if one views the base space geometrically rather than algebraically (e.g. working with ")#mi("\\text{Spec} k")#text(" instead of ")#mi("k")#text("). For instance, an analogue of a real-valued random variable modeled by some probability space ")#mi("\\Omega")#text(" would be a section of a line bundle over some base space ")#mi("\\Omega")#text(". Extending the probability space to some extension ")#mi("\\pi: \\Omega^{\\prime} \\to \\Omega")#text(" corresponds to performing a base change on the line bundle using some extension ")#mi("\\pi: \\Omega^{\\prime} \\to \\Omega")#text(" of the underlying base. There is also an interesting analogy between “random element of ")#mi("\\Omega")#text("” in probability theory and “generic point of ")#mi("\\Omega\"")#text(" in algebraic geometry. It might even be possible to put probability theory and algebraic geometry on exactly the same footing by using some topos-theoretic language, but I haven’t worked this through carefully.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460139")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2015")])]

#text("At first I thought I understood what the “object vs model” analogy you were trying to describe is, but now I’m not so sure.")

#text("Are you saying that a fixed sample space is something like an finite-level approximation of some ultimate (perhaps non-mathematical) “space” of all possible outcomes (including future experiments we have not yet decided to perform or record)? In the same way that, say, the ")#mi("p")#text("-adic integers can be “modeled” by the projections to its finite quotients ")#mi("\\mathbf{Z}/p^n \\mathbf{Z}")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460144")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2015")])]

#text("Yes, I think this is a good way to think about things. In principle one could try to pass to an inverse limit of “all” sample spaces to work in some “universal” sample space, but one would have to exit the category of sets to do so, in order to avoid Russell type paradoxes, so this seems like more trouble than it is worth.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460147")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2015")])]

#text("Ah, okay. That makes more sense. Are there examples where an extension of sample spaces is something more subtle than just adding an extra factor?")

#text("In example 3, for instance, rolling the die a second time amounts to taking a direct product of our old sample space with a six-point set. Is it always the case that extending the sample space amounts to taking a direct product with something?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460159")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2015")])]

#text("One can be substantially more general than a direct product. Consider for instance a “")#link("https://en.wikipedia.org/wiki/Gambler%27s_ruin")[#text("gamblers ruin")]#text("” (or “stopping time”) type of scenario in which one performs some random actions at a casino until one’s money runs out. The sample space is extended as time progresses, but not as a direct product because for a certain portion of the outcomes, one is no longer gambling and producing additional sources of randomness. More generally, any new source of randomness that is coupled somehow to prior sources of randomness will lead to an extension that is not a direct product. (One often analyses such situations by jumping to the final extension of the sample space after the game has completely played out, viewing times prior to the final time as being associated to various sub-sigma-algebras of the final sigma algebra, but one can also take a more “real-time” perspective, thinking of the sample space as dynamically evolving over time. The choice of which perspective to use is to some extent a matter of personal taste.)")

#text("For a more concrete example, one could be studying some random graph (e.g. an Erdos-Renyi random graph) and find it convenient at some point in the analysis to take some random subgraph of that graph, e.g. by randomly selecting each edge of the graph to survive in the subgraph with some probability p. This requires extending the sample space in a manner more complicated than a direct product, since the amount of randomness one needs to build the subgraph depends on how many edges the original graph had. (In this particular case one could model things by a direct product, e.g. by viewing the random subgraph as the intersection of the original graph with an independent Erdos-Renyi graph, and this perspective may in fact be useful for whatever task one is trying to accomplish, but one could imagine more complicated probabilistic constructions which do not naturally arise from a direct product. In certain parts of theoretical computer science, such as computational complexity and cryptography, it can be useful to view randomness as a finite resource, to be used sparingly if possible, in which case it can be more efficient to use non-direct-product models in which a random number generator is only used when absolutely necessary, which in particular makes each new use of that generator conditional on previous ones.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e41a655a43fd81844baa8c4f3ca019946f619b05e1629676fc0ef441fc8e775-727dab67ebceb17c501056072241b00fde24bbfdceb166aeb0301d41e8f6543e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PerryZhao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460092")[#strong[#text("PerryZhao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("Reblogged this on ")#link("https://perryzhao.wordpress.com/2015/10/04/275a-notes-0-foundations-of-probability-theory/")[#text("木秀于林")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Colin Rust")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460109")[#strong[#text("Colin Rust")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2015")])]

#text("In Exercise 28, in the first sentence it looks like the words “real line” are extraneous. In part (iv), I think you’re missing a factor of ")#mi("(-1)^n")#text(". Possibly you might also want to add a hint that the formula represents the measure of a box in ")#mi("R^n")#text(".")

#emph[#text("[Corrections and hint added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460123")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2015")])]

#text("The last centered equation in Example 3 is missing a “\\” in the omega and there’s a right parenthesis missing in the first sentence of Exercise 11.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460124")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2015")])]

#text("In the definition of the expectation ")#mi("E(X)")#text(", how does one know that it is independent of the ")#emph[#text("model")]#text(" ")#mi("X_\\Omega")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460130")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2015")])]

#text("This is not shown in this set of notes (since we did not specify how we were permitted to extend the model), but is shown in Notes 1 (see the discussion at the end of Section 2 there).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bbac32f4d797c7cefcad9e47bdc87299f127572c530c4401f8ecee2e92bbe362-123da8c5136fbe13dbdb4c1814776caf56028e875deeff843136f9dc10859259.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M. Klazar")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460194")[#strong[#text("M. Klazar")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2015")])]

#text("In the displayed formula after Exercise 24, should not there be rather “=” and disjunction?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/acb60df38d3f64e49ba0d925a29a0de078644878e593b196fe216dba8a3f3f81-90f18da174327c251ee030f93cbb28f46145e90cf1e5d15d2b2f0e1db5c883d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Golub")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460206")[#strong[#text("Ben Golub")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2015")])]

#text("As a complement to Durrett’s book, I always found Amir Dembo’s notes on probability to be useful for a course of this type… their main virtue is that they are very systematic and (perhaps obsessively!) organized. ")#link("http://statweb.stanford.edu/~adembo/stat-310a/lnotes.pdf")[#text("http://statweb.stanford.edu/~adembo/stat-310a/lnotes.pdf")]

#text("(Initially posted this on old notes but thought it would be more relevant here.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of EXP LOG")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460330")[#strong[#text("EXP LOG")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2015")])]

#text("Dear Professor Tao, have you thought about videotaping your classes so that students can benefit from your lectures in a better way, especially given that real analysis and probability theory have a large audience other than PhD students in Math, e.g., engineering, physics, economics, and finance?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ba1f46ec449f44720e9abdc6a401ba593680128fb2afa054ff39c62d096760f-3bb8c0a9a6b9cbf761eaeda4ec81f2e2ab86cf8064826e0dc0d1d72e15d4c223.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alik")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460403")[#strong[#text("Alik")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2015")])]

#text("Dear Professor Tao, my impression is that in probability people focus a lot on independence of random variables? Why independence is so much more important than any other type of dependence between random variables?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460414")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2015")])]

#text("For one thing, it is the simplest model to compute with, since we have ")#mi("{\\bf E} F(X) G(Y) = {\\bf E} F(X) {\\bf E} G(Y)")#text(" for independent random variables ")#mi("X,Y")#text(" and arbitrary ")#mi("F,G")#text(". So even if in practice one needs to work with random variables with more complicated couplings, one often works with the independent case first as a simplified model to establish some baselines as to what to expect in more general cases. The other thing is that independence (or something close to it) is often a reasonable assumption in real life settings, for instance when one has two sources of randomness that one believes to not be in communication with each other, e.g. because of physical separation, or lack of knowledge of one source of the other, and which are not both drawing on a common third source of randomness. Contrapositively, one can use an independence assumption to make various predictions which, if then they then fail to match observed data, suggest that there is some non-trivial correlation between two observables, and which can then be used to draw statistical inferences (or, in some cases, even causal inferences).")

#text("There are certainly however other types of coupling than independence which are widely studied. For instance, in highly noncommutative settings (e.g. in random matrix theory), free independence often becomes the more natural notion to study than classical independence.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ba1f46ec449f44720e9abdc6a401ba593680128fb2afa054ff39c62d096760f-3bb8c0a9a6b9cbf761eaeda4ec81f2e2ab86cf8064826e0dc0d1d72e15d4c223.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alik")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460416")[#strong[#text("Alik")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2015")])]

#text("Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 2: Product measures and independence | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460457")[#strong[#text("275A, Notes 2: Product measures and independence | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2015")])]

#text("[…] number of probability spaces for , where can be infinite or even uncountable. Recall from Notes 0 that the product -algebra on is defined to be the -algebra generated by the sets for and , […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a6be96d0b33334c6a31c2b3bf2f20ef8ce2f7d97e0c701463b95bf4270e9e25-ce514ac0ea720ed87fa8c8930f4a34ce09507f5e810209a52d960dbea35d2d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Venky")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460520")[#strong[#text("Venky")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2015")])]

#text("In Example 14, shouldn’t E_\\beta \\in \\Beta_\\beta, not \\Beta_\\alpha? Great notes. Thanks.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/746863bc34d8fefbe2b2f82325b0841a52b8353f001b7f5448e3ce16efbe52e4-c6a8acdf4e8514444632e322d604268f40521f079bcf637d4e0e254edc126a88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L.")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460567")[#strong[#text("L.")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2015")])]

#text("Dear Professor Tao,")

#text("In the definitions of boolean operations of events below Exercise 3, would it be better to say, for example, “The conjunction {E \\wedge F} of two events {E}, {F} is modeled (instead of defined) as the intersection of their models”?")

#text("Several lines below regarding the relation {F}, I think “the event {F(R_1,\\dots,R_n)}” should be “{F(X_1,\\dots,X_n)}”.")

#text("Below Remark 25, “{(\\sup_n X_n > t) := \\bigwedge_{n=1}^\\infty (X_n > t)}” should be “{(\\sup_n X_n > t) := \\bigvee_{n=1}^\\infty (X_n > t)}”.")

#text("In Exercise 30 (ii), “{F(t)}” should be “{F(t_1,…,t_n)}”, and in (iii), “{F(s)}” should be “{F(s_1,…s_n)}”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MartinScorsese")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460617")[#strong[#text("MartinScorsese")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2015")])]

#text("Dear professor Tao,")

#text("do you know a text (book, article – anything) that focuses a lot on the foundational aspects of probability and develops and treats in greater detail the issue you touched upon in these notes ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-460682")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2015")])]

#text("Example 9 : for “Becaue” read “Because” ;")#linebreak()#text(" Exercise 15 : for “{\\sigma-}algebra” read ” {\\sigma}-algebra” ;")#linebreak()#text(" Remark 25 foll. : delete “if one is ” ; for “if one has” read “when” .")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7040cb462f1644b182a056255c35d035e26f9ef775880e1fd889732dce93684e-242958bd98399958a3b856c99d2fa843d2f1ccb9da938f5ff7af9d1ef3186736.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zxmzxmzxm")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-461305")[#strong[#text("zxmzxmzxm")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2015")])]

#text("Reblogged this on ")#link("https://zxmwordpresscom.wordpress.com/2015/11/02/275a-notes-0-foundations-of-probability-theory/")[#text("ZXM rules!")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 4: The central limit theorem | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-461367")[#strong[#text("275A, Notes 4: The central limit theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2015")])]

#text("[…] (iv) Show that converges in distribution to if and only if, after extending the probability space model if necessary, one can find copies and of and respectively such that converges in probability to . (Hint: use the Skorohod representation, Exercise 29 of Notes 0.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/699af3a3fc4203ea620dca481e9250ca5afe390a9f0c1a899a851e6f15bc55d0-ae5673e90ba4078fef52fa664e446f1c71bee8d8b4b357b561f7459225012e5b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ManInThe")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-461714")[#strong[#text("ManInThe")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2015")])]

#text("Dear professor Tao,")

#text("In definition 1 and in definition 22, the the meaning of “to model something by something else” is not clear to me. In particular are you saying that the measurable subsets are called events, or are you saying something else?")

#text("Thanks for your clarification")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-461715")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2015")])]

#text("A model is a representation of a mathematical object, but strictly speaking one should distinguish it from the object itself, although often in practice one sees the “abuse of notation” of identifying an object with its model, particularly if one is working with a fixed representation for each class of objects being considered.")

#text("A basic example is the distinction between a natural number and its representation in a numeral system such as the decimal system. Strictly speaking, a string of digits such as 13 is not a number, it is rather a ")#link("https://en.wikipedia.org/wiki/Numeral_system")[#text("numeral")]#text(" used to model a number. Of course, we usually abuse notation and identify numerals with numbers, e.g. “let n be the natural number 13”. This usually does not cause problems unless one needs to use two different numeral systems for the same number. For instance, if n is modeled in the decimal system by the numeral 13, then it is also modeled in the octal system by the numeral 15, despite the fact that 13 and 15 are clearly different numerals (different strings of digits). This can be confusing unless one is very clear about the distinction between a number and the numerals that model it in various representations. Using the notational conventions of this post, the accurate thing to write here is that there is a natural number ")#mi("n")#text(" whose decimal representation ")#mi("n_{dec}")#text(" is 13, and whose octal representation ")#mi("n_{oct}")#text(" is 15; they both model the same natural number ")#mi("n")#text(" despite 13 and 15 being distinct numerals. However, to be pedantic, the number ")#mi("n")#text(" itself is distinct from both the numeral 13 and the numeral 15; we have ")#mi("n_{dec}=13")#text(" and ")#mi("n_{oct}=15")#text(", but ")#mi("n \\neq 13")#text(" and ")#mi("n \\neq 15")#text(".")

#text("Another example that is the distinction between a vector in some vector space (e.g. a two-dimensional plane) and its representation as a pair ")#mi("(x,y)")#text(" of numbers with respect to some basis. Again, if one is committed to only using one basis for the vector space in question, there is little harm in abusing notation and identifying a vector ")#mi("v")#text(" in that space by its model ")#mi("(x,y)")#text(", but this can lead to confusion when one wishes to change the basis (which is often useful, for instance when performing a multi-step linear algebra calculation, one component of which is easy to carry out in one basis, and another component of which is easy to carry out in a different basis). For instance, a vector ")#mi("v")#text(" which is modeled in one basis ")#mi("B")#text(" by the pair ")#mi("(2,2)")#text(" might also be modeled in a different basis ")#mi("B^{\\prime}")#text(" (rotated from the first one by 45 degrees) by ")#mi("(2\\sqrt{2}, 0)")#text(". (Similarly when changing coordinate systems, e.g. from Cartesian coordinates to polar coordinates.) With the notational conventions of this post, I would write that ")#mi("v_B = (2,2)")#text(" and ")#mi("v_{B^{\\prime}} = (2\\sqrt{2},0)")#text("; they both model the same underlying vector ")#mi("v")#text(", despite the fact that ")#mi("(2,2) \\neq (2\\sqrt{2},0)")#text(" are two distinct pairs of real numbers. Again, to be pedantic, the vector ")#mi("v")#text(" should be kept distinct from both the pair ")#mi("(2,2)")#text(" and the pair ")#mi("(2\\sqrt{2},0)")#text(".")

#text("[The one-dimensional version of the above example is also instructive, illustrating the role of physical units to model physical quantities (such as length, mass, speed, etc.) as numbers. A given length might be modeled both as 3 meters by the metric system and (approximately) 10 feet in the imperial system, despite 3 and 10 being different numbers; as such, it is strictly speaking inaccurate to think of a length as a number, but rather that numbers can be used to model lengths in various representation systems.]")

#text("Once one makes the distinction between an object and its models, we see that the models of the object do not define the object in an ontological sense: if one is told for instance that a numeral is a finite string of digits from the set {0,1,2,3,4,5,6,7,8,9} that does not start with 0, this does not quite define what a natural number ")#emph[#text("is")]#text(", unless one abuses notation by identifying a natural number with its numeral model. However, models can serve to define the ")#emph[#text("functionality")]#text(" of a mathematical object, which is often good enough for mathematical purposes. For instance, as we are taught in primary school, the numeral system can be used to define arithmetic operations on natural numbers such as addition and multiplication. This lets us manipulate natural numbers for the purposes of doing mathematics, even if it still doesn’t address the philosophical question of what a natural number actually ")#emph[#text("is")]#text(". (Of course, one has to check at some point that the arithmetic operations defined from different numeral systems are consistent with each other, e.g. that long multiplication in decimal is consistent with long multiplication in octal. This requires some mathematical argument to check; the simplest way to do it is to verify that both operations are consistent with the multiplication operation in an axiomatic description of the natural numbers, e.g. the Peano axiom formulation.)")

#text("Of course, one can also try to define mathematical objects without recourse to models. For instance, the natural numbers can be described axiomatically using axiom systems such as Peano arithmetic or ZFC. It is also possible to set up the foundations of probability axiomatically (e.g. through the ")#link("https://en.wikipedia.org/wiki/Probability_axioms")[#text("Kolmogorov axioms")]#text(", together with the sigma-algebra version of the ")#link("https://en.wikipedia.org/wiki/Boolean_algebra_(structure)#Definition")[#text("axioms of Boolean algebra")]#text("), but I prefer to avoid this approach for a first course in graduate probability, for much the same reason that arithmetic is often first taught using the decimal representation, or linear algebra is first taught by modeling vectors as tuples of numbers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-624573")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2021")])]

#text("Dear Prof. Tao,")

#text("I very much liked your explanation about the difference between models and mathematical objects.")#linebreak()#text(" However, there is still something than I do not grasp properly: if as you mentioned, one decides to define a certain mathematical object axiomatically, one finds that those axioms are then interpreted on a certain model-like structure, right? i.e. the mathematical object “Group” can be axiomatized by a few first order axioms. Then one declares that a group is every interpretation that is a model for those axioms. Is the problem here that the word “model” is used with different meaning?")

#text("Thanks in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-624999")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2021")])]

#text("Models can be given not only for axiomatic theories, but more general ")#link("https://en.wikipedia.org/wiki/Theory_(mathematical_logic)")[#text("theories")]#text(" that do not necessarily have an explicit (or recursively enumerable) axiomatisation. In this case, a theory might be a collection of statements that one asserts it be true about a collection of events, various boolean (and sigma-boolean) operations applied to these events, and the probabilities of these events (e.g., ")#mi("{\\bf P}(E) = 1/2")#text(", ")#mi("{\\bf P}(F) = 1/2")#text(", ")#mi("{\\bf E}(E \\wedge F) = 1/4")#text(", ")#mi("{\\bf E}(E \\vee F) = 3/4")#text(", etc.); and the probability space models described in these posts would then be a (type of) model of such a theory in the usual model-theoretic sense of providing an ")#link("https://en.wikipedia.org/wiki/Interpretation_(logic)")[#text("interpretation")]#text(" of all of the abstract objects and operations of that theory.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/699af3a3fc4203ea620dca481e9250ca5afe390a9f0c1a899a851e6f15bc55d0-ae5673e90ba4078fef52fa664e446f1c71bee8d8b4b357b561f7459225012e5b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ManInThe")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-461756")[#strong[#text("ManInThe")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2015")])]

#text("Dear professor Tao,")

#text("Thanks for you answer. It helped me a lot improve my understanding.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8371d943e11f2ee5630e1ad2f23ac18b7fbfc6e7f7e523227453d483bd27ebf-8dc2eb16c022b6652f932e7b7c23a69facf039f182263717919a45eb31c25dec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-462589")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2015")])]

#text("Exercise 17, was the intent to write continuous function from X to Y.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8371d943e11f2ee5630e1ad2f23ac18b7fbfc6e7f7e523227453d483bd27ebf-8dc2eb16c022b6652f932e7b7c23a69facf039f182263717919a45eb31c25dec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-462592")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2015")])]

#text("In Definition 22 an event E is meant to be an element (singular) of F, while it is written elements.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8371d943e11f2ee5630e1ad2f23ac18b7fbfc6e7f7e523227453d483bd27ebf-8dc2eb16c022b6652f932e7b7c23a69facf039f182263717919a45eb31c25dec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-462593")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2015")])]

#text("After Remark 25, in the Equation: (sup X_n > t) := …. does the equality need the ‘define equal’ colon?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8371d943e11f2ee5630e1ad2f23ac18b7fbfc6e7f7e523227453d483bd27ebf-8dc2eb16c022b6652f932e7b7c23a69facf039f182263717919a45eb31c25dec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-462596")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2015")])]

#text("Exercise 30 (ii) ")#mi("-\\infty")#text(" might be written as a vector ")#mi("(-\\infty,\\ldots,-\\infty)")#text(" in the limit notation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-465976")[#strong[#text("Final Word on Richard Carrier | Letters to Nature")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2016")]

#text("[…] Bertsekas and Tsitsiklis; Rosenthal; Bayer; Dembo; Sokol and Rønn-Nielsen; Venkatesh; Durrett; Tao. I recently stopped by Sydney University’s Library to pick up a book on nuclear reactions, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec08264c245b158d5f9be642ebd7fb9fa67b8979f3bfa41d4398939164aef389-38929e106897b23689d0fd22a6363bd3bb9a86dfcc36d82bdf7a7f4d99873942.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joel K")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-466310")[#strong[#text("Joel K")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2016")])]

#text("I recently came across a quite intresting approach to probability theory based on using the Henstock integral. See this book by P. Muldowney : A Modern Theory of Random Variation. Draft is available ")#link("https://sites.google.com/site/stieltjescomplete/supplement")[#text(" here ")]#linebreak()#text(" This approach simplifies some ideas in standard probability, and can be used for example to provide a nice probabilistic interpretation of Feynman path integrals.")

#text("Anyone here that have had experience with this approach and it’s potential advantages and disadvantages?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-467814")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2016")])]

#emph[#text("In linear algebra, we distinguish between an abstract vector space ")#mi("{V}")#text(", and a concrete system of coordinates ")#mi("{\\phi: V \\rightarrow {\\bf R}^n}")#text(" given by some basis of ")#mi("{V}")#text(".")]

#text("In group theory, we distinguish between an abstract group ")#mi("{G}")#text(", and a concrete representation of that group ")#mi("{\\phi: G \\rightarrow \\text{Aut}(X)}")#text(" as isomorphisms on some space ")#mi("{X}")#text(".")

#text("In the above two cases, one has a set of mathematics axioms for each of the abstract concepts, “vector spaces” and “groups”.")

#text("I’m confused by definition 1, and definition 19. You say that the probability spaces are ")#emph[#text("models")]#text(", which as I understand, correspond to ")#mi("{\\phi: V \\rightarrow {\\bf R}^n}")#text(" and ")#mi("{\\phi: G \\rightarrow \\text{Aut}(X)}")#text(" above. But what are the axioms for the “stuff” the probability spaces are modeling? This note vaguely mentions that they are modeling “randomness”, but what is “randomness” mathematically? Also, in Definition 1, you distinguish “event ")#mi("E")#text("” and its model ")#mi("E_\\Omega")#text(". Then what is the definition/axiom for the abstract concept “events”? (Similar question for “random variables”.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-467818")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2016")])]

#text("Abstract probability spaces are discussed in Section 4 of the blog post. Alternatively, one can eschew axiomatisation algoether, and simply define an abstract probability space to be a structure of events and probabilities that has at least one concrete model. This would be analogous to defining (say) a group to be an object with a multiplication operation that had at least one concrete representation as an action; indeed, this is close to how groups were first viewed historically. (In this particular case, Cayley’s theorem tells us that the two definitions of a group are equivalent.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-474346")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("In Definition 1,")

#emph[#linebreak()#text(" We consider two events ")#mi("{E,F}")#text(" to be equal if they are modeled by the same set: ")#mi("{E=F \\iff E_\\Omega = F_\\Omega}")#text(".")#linebreak()#text(" ")]

#text("Do we need this to be true for any models? Namely, ")#mi("E_\\Omega = F_\\Omega")#text(" for any ")#mi("\\Omega")#text("?")

#emph[#text("[Yes, we only consider faithful models (aka faithful representations) of probability spaces. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-474348")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("When we say “We then model events ")#mi("{E}")#text(" by subsets ")#mi("{E_\\Omega}")#text(" of the sample space ")#mi("{\\Omega}")#text(". “, what mathematical object (or category?) is an “event” ")#mi("{E}")#text("? Is it a set?")

#emph[#text("[It can be, if you like; but it doesn’t have to be. From a formal mathematical viewpoint, the only requirement is that the events lie in an abstract sigma algebra equipped with a probability measure. An analogy is with vectors in a finite-dimensional space; they can be modeled by row or column vectors of numbers, but they themselves could just be elements of an abstract vector space. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-474369")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("I have confusion about your comments.")

#text("(I) an “event” ")#mi("E")#text(" “does not have to” be a set.")

#text("(II)”the only requirement is that the events lie in an abstract sigma algebra equipped with a probability measure”")

#text("Would you elaborate what you mean by “abstract sigma algebra”? Isn’t a sigma algebra is a collection of subsets of a given set with the sigma algebra structure and thus any element lies in an abstract sigma algebra must be a “set”? (if an event ")#mi("E")#text(" is not a set, would you give an example to illustrate what else it could be?)")

#text("I’m also not very clear about the analogy with vectors in a finite-dimensional space. Suppose ")#mi("V")#text(" is a real vector space of dimension ")#mi("2")#text(". Then a model for ")#mi("V")#text(" is ")#mi("\\mathbb{R}^2")#text(". But isn’t it true that the abstract vector space $V$ itself is also a “set” in the first place by definition?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-474372")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("You are describing a concrete sigma algebra. See for instance ")#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/")[#text("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/")]#text(" for a definition of an abstract sigma algebra and its relationship with the concrete sigma algebra notion. A simple example would be the (abstract) Boolean algebra ")#mi("\\{0,1\\}")#text(" with the usual Boolean operations. In this case there are two events, ")#mi("0")#text(" and ")#mi("1")#text("; depending on how one is modeling the natural numbers, these events might be sets, but there is no necessity for them to be so.")

#text("As for the vector analogy, the vector ")#emph[#text("space")]#text(" is always a set, but the individual ")#emph[#text("vectors")]#text(" do not have to be sets (or arrays of numbers, or anything else for that matter). Similarly, the event space is always a set, but individual events (the elements of the event space) need not be.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-474386")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2016")])]

#text("I think it is clear now. I find the linked article of the Kolmogrov axioms (")#link("https://en.wikipedia.org/wiki/Probability_axioms")[#text("https://en.wikipedia.org/wiki/Probability_axioms")]#text(") is actually very confusing. If one checks the Axiom Three there, one can see that individual events are described as sets while they do not have to be as you pointed out. At least one should notice that those events in the event space do not have to be subsets of the probability space ")#mi("\\Omega")#text(" at all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-474387")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2016")])]

#text("As I read from the English translation of the work by Kolmogrov himself (")#link("http://www.york.ac.uk/depts/maths/histstat/kolmogorov_foundations.pdf")[#text("http://www.york.ac.uk/depts/maths/histstat/kolmogorov_foundations.pdf")]#text("), it seems that Kolmogrov didn’t use the notation of abstract sigma algebra but the concrete one. So the link in")

#emph[#text("The axioms of a probability space then yield the ")#strong[#text("Kolmogorov axioms")]#text(" for probability:")]

#text("might be not very appropriate?")

#text("In Definition 22,")#linebreak()#text(" ")#emph[#linebreak()#text(" We then model an event ")#mi("{E}")#text(" by an element ")#mi("{E_\\Omega}")#text(" of ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal F}}")#text(", with each such element describing an event.")]

#text("should ")#mi("{{\\mathcal F}}")#text(" be a concrete sigma algebra and thus a collection of subsets of ")#mi("\\Omega")#text("? And hence, we are not only modeling an event ")#mi("E")#text(" by an element ")#mi("E_\\Omega")#text(" of ")#mi("\\mathcal{F}")#text(" but also modeling the “event space” by a concrete sigma algebra ")#mi("\\mathcal{F}")#text(" (hence the notation ")#mi("\\mathcal{F}_\\Omega")#text(" might be better)?")

#emph[#text("[Fair enough; I’ve added the subscript. -T]")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4496f3aaf94340423070e8ca4577f9f831dbade6c767ed6d477450327ffb46d6-713cbc90c5b884e2c79ef3693d4c078597aaa2281c37b047a524cc68da7064e4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kelvin Koor")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-597286")[#strong[#text("Kelvin Koor")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2020")])]

#text("Dear Prof Tao,")

#text("I am rather confused along the same lines of this comment as well. I have the impression that modeling objects in reality/the physical world (sorry, this is probably a bad phrase but I can’t think of a better term to use) is not quite the same as representing a mathematical object by a ‘concrete-r’ mathematical object.")

#text("For instance, the map-territory relation you mentioned. The territory is a physical thing in reality, and we could model it mathematically, say, by defining a map representing the territory to be a certain set of points on a sphere, all of which are well-defined mathematical objects. This is in the same spirit as much of physics, where we model the earth, cannon, atom, electron etc. with mathematical objects (of increasing complexity as the sophistication of the theory increases, but ultimately mathematical objects nonetheless). I feel that modeling the space of events with a sigma-algebra is of the same flavour.")

#text("However, aren’t these a little different from representing a vector with its representation w.r.t. a chosen basis, or a number and its representation w.r.t. a chosen numeral system? In these cases, we already have well-defined mathematical objects, but for computational convenience we identify them with concrete-r mathematical objects possessing the same structure.")

#text("So as far as mathematics is concerned, why bother with the distinction between E and E_omega, since we don’t ever talk about E? Just like in classical physics, where the ball *is* the position and momentum coordinates describing it, and we don’t talk about how in reality the ball is a clump of atoms etc etc.")

#text("Excuse me for the long-winded rambling.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-597451")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2020")])]

#text("There is of course a limit to how literally one should take any analogy, but in both cases one is modeling a structure that is supposed to correspond naturally to some “real-world” concept, by a more artificial system that can incorporate some arbitrary choices. For instance, when using Cartesian coordinates to model locations in physical space by three real numbers ")#mi("x,y,z")#text(", one is implicitly making some choices about a special origin in space, a special choice of three coordinate axes, and a special choice of length unit, none of which necessarily have any physical significance. Thus, the price one pays for identifying a physical or abstract structure with a specific concrete model is that there are model-specific features of the latter which one may mistake for being features of the original inherent structure. For instance, it is physically meaningless to ask whether the length of a given physical rod is an integer or not; it depends on the choice of units, but if one completely identifies physical space with ")#mi("{\\bf R}^3")#text(" (and does not specify a canonical choice of length unit) one may mistakenly believe that this is a physically meaningful question to ask. (Physically, it is more natural to model physical space by a more abstract three-dimensional vector space, equipped with an inner product that takes values in a one-dimensional ")#link("https://en.wikipedia.org/wiki/Principal_homogeneous_space")[#text("torsor")]#text(" of ")#mi("{\\bf R}")#text(" rather than in the real numbers. This abstract mathematical structure can then be modeled (non-uniquely) by more concrete models such as the standard copy of ")#mi("{\\bf R}^3")#text(".) Similarly, if one identifies an event space with some concrete ")#mi("\\sigma")#text("-algebra that models it, one may be under the mistaken impression that model-dependent questions such as “is this given event ")#mi("E")#text(" finite or infinite in cardinality?” have significant probabilistic meaning, when in fact such questions are almost totally irrelevant in modern probability.")

#text("The situation is also somewhat analogous to the object-oriented approach to software engineering, in which one tries to focus on abstractions of objects that purposely make it difficult to discuss implementation-dependent features, in order to enforce better programming practices that lead to less buggy code (particularly if one expects the implementation to change over time). Distinguishing between an abstract system of random variables and events and their concrete model(s) is a similarly good practice that can avoid incorrect, misleading, or inefficient mathematical arguments, particularly if one ends up changing the model over time, for instance by inserting new sources of randomness at some intermediate stage of the argument. [However, if one knows that one will only ever work with one specific concrete model and never consider any others, then it is reasonably safe to identify a structure with that one model, though even in that case one may still end up wasting some time focusing on some model-specific phenomena that end up having little to do with the original structure under consideration.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-597479")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2020")])]

#text("Such models of the physical universe are compatible with the general “Mathematical Universe Hypothesis” in which the universe can be precisely modelled by a certain (still unknown) abstract mathematical space.")#linebreak()#text(" It is important to note that any probability space can be modelled by a deterministic mathematical space (with a deterministic structure) so without loss of generality, even quantum phenomena can be described by a deterministic mathematical structure.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ada5025cd616e13b8b04da4f8bf70f0fd980b33c0b6091e86ba1e3bf503912d-713cbc90c5b884e2c79ef3693d4c078597aaa2281c37b047a524cc68da7064e4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kelvin Koor")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-597534")[#strong[#text("Kelvin Koor")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2020")])]

#text("I see..")

#text("I’d like to ask what you meant when you wrote that the cardinality of an event is model-dependent and hence meaningless. Did you mean")

#text("i. There are different ways to Kolmogorov-model the event space, i.e. using different measure spaces such that an event could be finite in one but infinite in the other?")

#text("ii. In other models of probability, like the von Neumann algebra version, an event is an operator, hence cardinality is not a meaningful property (ignoring the part where all mathematical objects are encoded by sets)?")

#text("iii. Something else?")

#emph[#text("[i. and ii.. are both true and relevant for this discussion. -T]")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Visualising random variables | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-468589")[#strong[#text("Visualising random variables | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2016")])]

#text("[…] variables) that do depend (in some measurable fashion) on the state . (As discussed in this previous post, it is often helpful to adopt a perspective that suppresses the sample space as much as possible, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Confused Robitaille")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-469921")[#strong[#text("Confused Robitaille")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2016")])]

#text("I’m also not sure how well your analogy to linear algebra is, because of different levels of abstractions used in the definition of real vector space vs. real vector space model resp. abstract probability space (in the sense that you mentioned of Kolmogorffs axioms + sigma-algebra version of Boolean algebra axioms) vs. probability space (as in Definition 19):")#linebreak()#text(" Real vector spaces are abstract, but representations of them are concrete, in the sense each representation is a fixed set built out of numbers that one could write down. But abstract probability spaces and probability spaces are both abstract, because the latter is not a concrete set that one could write down, but itself a set that is given abstractly by axioms that characterize it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-469939")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2016")])]

#text("This is technically true, but in practice, probability spaces are often quite concrete, being a set of outcomes (with the discrete sigma algebra) or some explicit subset of ")#mi("{\\bf R}^n")#text(" (with the Borel sigma algebra), or perhaps a finite or infinite product of these spaces.")

#text("It’s true though that the object that is considered “concrete” in one setting could be considered “abstract” in another. For instance, one could imagine a probability space, concrete in the sense of probability theory, in which the sample space was a manifold, which was abstract in the sense of differential geometry, but for which the real number system ")#mi("{\\bf R}")#text(" underlying both the probability space and the manifold is given concretely by digit strings, as opposed to some axiomatic presentation of the reals. I don’t see any inconsistency here, though, and as long as one keeps all the different categories (probability theory, differential geometry, real closed fields, etc.) here conceptually distinct from each other there should not be any serious confusion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-474350")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("Are “conjunction” and “disjunction” actually “set” operations and it is just because we want to distinguish explicitly an event and its model in a sample space ")#mi("\\Omega")#text(" that we deliberately use different terminologies than those in set theory?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-474353")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("(I) On the one hand, we have the following:")#linebreak()#text(" ")#emph[#linebreak()#text(" Given a finite number ")#mi("{X_1,\\dots,X_n}")#text(" of random variables taking values in ranges ")#mi("{R_1,\\dots,R_n}")#text(", we can form the joint random variable ")#mi("{(X_1,\\dots,X_n)}")#text(" taking values in the Cartesian product ")#mi("{R_1 \\times \\dots \\times R_n}")#text(" by concatenation of the models, thus")]

#mi("\\displaystyle  (X_1,\\dots,X_n)_\\Omega: \\omega \\mapsto ((X_1)_\\Omega(\\omega),\\dots, (X_n)_{\\Omega}(\\omega)).")#linebreak()

#text("(II) But you write in Example 3 the following:")#linebreak()#text(" ")#emph[#linebreak()#text(" Now suppose that we wish to roll the die again to obtain a second random variable ")#mi("{Y}")#text(". The sample space ")#mi("{\\Omega = \\{1,2,3,4,5,6\\}}")#text(" is ")#strong[#text("inadequate")]#text(" for modeling both the original die roll ")#mi("{X}")#text(" and the second die roll ")#mi("{Y}")#text(".")#linebreak()#text(" ")]

#text("It seems from (I) that one does not need to enlarge the sample space no matter how many random variables are added in Example 3. How should one reconcile such “contradiction”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-474361")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("Making the sample space explicit, (I) asserts that if the sample space is already capable of simultaneously modeling each of the random variables ")#mi("X_1, \\dots, X_n")#text(", then it can also model the joint random variable ")#mi("(X_1,\\dots,X_n)")#text(". But in the situation in (II), one cannot model both ")#mi("X")#text(" and ")#mi("Y")#text(" simultaneously, and one certainly cannot model the joint random variable ")#mi("(X,Y)")#text(". This is not in contradiction with (I) because the hypothesis in (I) was not satisfied.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-474354")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("Would you elaborate how Corollary 27 is proved?")

#text("It is said in the notes that")#linebreak()#text(" ")#emph[#linebreak()#text(" Indeed, we can take the probability space to be ")#mi("{{\\bf R}}")#text(" with the Borel ")#mi("{\\sigma}")#text("-algebra and the Lebesgue-Stieltjes measure associated to ")#mi("{F}")#text(".")#linebreak()#text(" ")]

#text("I’m very confused here. What is the random variable ")#mi("X")#text(" with the desired property in Corollary 27?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-474362")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("In this case, the random variable ")#mi("X")#text(" is modeled by the identity function ")#mi("X_{\\mathbf R}: t \\mapsto t")#text(".")

#text("Strictly speaking, Corollary 27 covers both discrete and continuous random variables (the measure ")#mi("dF")#text(" is allowed to be either a discrete measure, a continuous measure, or a combination of both), but given that discrete random variables are already easy to construct, the main novelty of the corollary is in the continuous case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-474355")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("Also, as I can see from the statement of Corollary 27, there is nothing about “continuous” random variables? What definition is given for “continuous random variables”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-474356")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("Similarly in Corollary 31. I think what you really want to say is “construction of random variables/vectors with the given distribution function ")#mi("F")#text("“?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-476784")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2017")])]

#text("In Example 3, it is said that ")#emph[#text("The sample space ")#mi("{\\Omega = \\{1,2,3,4,5,6\\}}")#text(" is inadequate for modeling both the original die roll ")#mi("{X}")#text(" and the second die roll ")#mi("{Y}")#text(". ")]

#text("On the other hand, if one “only” wants to know the probability of the event ")#mi("{E}")#text(" that ")#mi("{X}")#text(" is even, one can only use the old model ")#mi("\\Omega")#text(" instead of the new model ")#mi("\\Omega^{\\prime}")#text(" to conclude that")

#mi("\\displaystyle P(E)=\\frac{3}{6}=\\frac{1}{2}")#text(".")

#text("In a more general case, if one assumes that ")#mi("X")#text(" and ")#mi("Y")#text(" are “independent”, then the joint distribution ")#mi("P(X=i,Y=j)=P(X=i)P(Y=j)")#text(" completely depends on ")#mi("P(X=i)")#text(" and $P(Y=j)$, the calculation of which can be done in the model ")#mi("\\Omega")#text(". Can one say in this case that one does not need to expand the sample space?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-476804")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2017")])]

#text("Sorry for the wrong question above.")

#text("In Example 3, it is said that “Now suppose that we wish to roll the die again to obtain a second random variable $\\latex {Y}$. ” At this point, do we implicitly ")#emph[#text("assume")]#text(" that ")#mi("Y")#text(" is independent of ")#mi("X")#text(" so that we define later ")#mi("Y_{\\Omega^{\\prime}}(i,j)=j")#text(" or do we have to see by ")#emph[#text("calculation")]#text(" (via the definition of ")#mi("X_{\\Omega^{\\prime}}")#text(" and ")#mi("Y_{\\Omega^{\\prime}}")#text(") of the joint distribution of ")#mi("(X,Y)")#text(" that ")#mi("X")#text(" and ")#mi("Y")#text(" are indeed independent?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-476817")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2017")])]

#text("In this example, the die rolls ")#mi("X,Y")#text(" are constructed to be independent through the choice of the probability distribution ")#mi("p^{\\prime}_{(i,j)} = 1/36")#text(". (This is not stressed in the example, because the notion of independence is only discussed later in the post.) One could model correlated die rolls using the same set ")#mi("\\Omega^{\\prime} = \\{1,\\dots,6\\} \\times \\{1,\\dots,6\\}")#text(" and random variables ")#mi("X_{\\Omega^{\\prime}}(i,j) = i")#text(", ")#mi("Y_{\\Omega^{\\prime}}(i,j)")#text(", but with a different choice of probability distribution ")#mi("p^{\\prime}_{(i,j)}")#text(". For instance, if the second die roll is going to be equal to the first die roll with a probability of ")#mi("1/2")#text(", and is a completely independent die roll otherwise, one could use the distribution ")#mi("p^{\\prime}_{(i,j)} = \\frac{1}{2} \\frac{1}{6} 1_{i=j} + \\frac{1}{2} \\frac{1}{36}")#text(" instead.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: The central limit theorem | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-478165")[#strong[#text("254A, Notes 2: The central limit theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("[…] (iv) Show that converges in distribution to if and only if, after extending the probability space model if necessary, one can find copies and of and respectively such that converges almost surely to . (Hint: use the Skorohod representation, Exercise 29 of Notes 0.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c791a2e2807f98638f149d80769f1a5af49fc7e5ceae89f37407406af0797aa-ddcf4e753e4b745cb3770643160180712a8a6e482edf7e96e9db0ca3c2a231ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fsaymon")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-479867")[#strong[#text("fsaymon")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2017")])]

#text("Dear Prof. Tao,")

#text("you wrote in an earlier post, on 14 November, 2016 at 4:21 pm, that")

#text("“As for the vector analogy, the vector space is always a set, but the individual vectors do not have to be sets (or arrays of numbers, or anything else for that matter).”")

#text("This completely confused me, as reviewing the possibilities of formalizing the concept of a vector space I can’t see any way to arrive at it in such a way that the vector space is constructed out of an “underlying” set (+ vector operations on it), but whose elements are not sets, or anything else.")

#text("My main point confusion comes from the standard (ZFC induced) convention that everything in “standard” mathematics is a set, resp. can be constructed as one, even though we don’t think of it as a set (in a similar way in which we don’t think of a number as a set). Thus, there can’t be such a thing as a set whose elements are not sets.")

#text("Are you perhaps having a different, impure set theory in mind, such as the one you developed in your Analysis 1 book, were you have primitive notions of “sets” and “objects” ?")#linebreak()#text(" Even though axiomatization models more closely how we think about mathematical objects such as numbers (which we informally don’t regard as sets), this would still be a non-standard set theory, that probably confuses beginners.")

#text("Or did you perhaps meant to perceive the theory of vector spaces in a similar way to the way mathematical theories are approach in introductory books on mathematical logic? (I.e., formal language is defined and axioms are stated, completely out of any set theory.)")#linebreak()#text(" Of course, this precludes us from doing various things that are commonly done when developing linear algebra, such as considering maps between two different vector spaces (since, working at this very basic formal level, we are working outside a framework of set theory that permits us to consider mappings between vector spaces).")

#text("Couly you please help me (and further readers) clarify this issue?")

#text("(And sorry in case I double posted, my account did some weird things the first time I posted this comment.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-479890")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2017")])]

#text("It’s more accurate to say that everything in mathematics can be ")#emph[#text("encoded")]#text(" as a set, as opposed to ")#emph[#text("being")]#text(" a set. See for instance ")#link("https://mathoverflow.net/a/255824/766")[#text("https://mathoverflow.net/a/255824/766")]#text(" and ")#link("https://mathoverflow.net/a/90945/766")[#text("https://mathoverflow.net/a/90945/766")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c791a2e2807f98638f149d80769f1a5af49fc7e5ceae89f37407406af0797aa-ddcf4e753e4b745cb3770643160180712a8a6e482edf7e96e9db0ca3c2a231ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fsaymon")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-479976")[#strong[#text("fsaymon")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2017")])]

#text("But you did not yet clarify how to encode vectors, if they are *not* supposed to be sets “or anything else”.")

#text("(Of course I agree with your remark; I used the word “constructed as a set” instead of “encoded”, which seems to convey the intention more clearly.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-479985")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2017")])]

#text("I prefer to remain agnostic on this issue; one can encode all (or almost all) mathematical objects as sets, if one wishes, but it is also perfectly possible to work in formal systems (e.g. ZFC with urelements) in which one does not do this. Or one can adopt the practices of most working mathematicians and work with a reasoning system which is ")#emph[#text("formalisable")]#text(", rather than ")#emph[#text("formal")]#text("; one does not strictly adhere to any given formal system such as ZFC, but one structures one’s arguments in such a way that, if one chose, one could translate the arguments into such formal systems (at which point one would indeed be forced to encode various objects, such as vectors in a vector space, as sets, if one insisted on working strictly within ZFC).")

#text("For instance, take the standard vector space ")#mi("{\\bf R}^n")#text(". We generally view elements of this vector space as ")#mi("n")#text("-tuples of real numbers. Now, if one strictly wanted to adhere to ZFC, one would have to interpret such tuples as sets. One can do so by a variety of means (e.g. by viewing a ")#mi("n")#text("-tuple as a function from ")#mi("\\{1,\\dots,n\\}")#text(" to the reals, and then encoding functions as sets by viewing them as an ordered triple consisting of the domain, range, and graph of the function, and then using something like the Kuratowski pair construction to model the ordered triple as a set). But outside of foundational and model-theoretic considerations, these sorts of encodings play virtually no role in the linear algebra of ")#mi("{\\bf R}^n")#text(", and I think it is much clearer conceptually to not try to fix any such encoding when actually doing linear algebra, though it certainly should be noted that these encodings exist should one care to use them.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97c6e2a22a3632ed2d32c6e877ee6ed05fabea1b365df2e197466fed3788ebd3-de4693fd37536e752e38612d626edd4d211b3474ad9cc68b56c2cfa44a2ede40.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rith")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-513959")[#strong[#text("Rith")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2019")])]

#text("Dear Professor Tao,")#linebreak()#text(" This post really deepened my understanding of probability theory. I just got a quick question about the notation used for the joint random variables. For this part you wrote")

#text("“Given a finite number ")#mi("{X_1,\\dots,X_n}")#text(" of random variables taking values in ranges ")#mi("{R_1,\\dots,R_n}")#text(", we can form the joint random variable ")#mi("{(X_1,\\dots,X_n)}")#text(" taking values in the Cartesian product ")#mi("{R_1 \\times \\dots \\times R_n}")#text(" by concatenation of the models, thus")

#mi("\\displaystyle  (X_1,\\dots,X_n)_\\Omega: \\omega \\mapsto ((X_1)_\\Omega(\\omega),\\dots, (X_n)_{\\Omega}(\\omega)).")#text(" ”")

#text("I feel I don’t understand this notation well, and I’m wondering why you are not using the following notation:")

#mi("\\displaystyle  (X_1,\\dots,X_n)_\\Omega: (\\omega_1,\\dots,\\omega_n) \\mapsto ((X_1)_\\Omega(\\omega_1),\\dots, (X_n)_{\\Omega}(\\omega_n)).")

#text("As it seems to be a mapping from n outcomes to n numbers.")

#text("Thank you very much for the clarification!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-513966")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2019")])]

#text("The random variables ")#mi("X_1,\\dots,X_n")#text(", as well as their concatenation ")#mi("(X_1,\\dots,X_n)")#text(", are all being modeled by the same sample space ")#mi("\\Omega")#text(", the elements of which represent the outcomes of ")#emph[#text("all")]#text(" conceivable measurements on the sample (which includes, but is not restricted to, the outcomes of ")#mi("X_1,\\dots,X_n")#text(").")

#text("Suppose for instance one is modeling the outcomes of three dice, e.g., a red die, a green die, and a blue die, with ")#mi("X_1")#text(" the outcome of the red die and ")#mi("X_2")#text(" the outcome of the green die. One possible sample space to model this is ")#mi("\\Omega = \\{1,\\dots,6\\}^3")#text(", with each element ")#mi("(a_{red}, a_{green}, a_{blue})")#text(" of this sample space describing the outcomes of all three dice. Then ")#mi("(X_1)_\\Omega: \\Omega \\to \\{1,\\dots,6\\}")#text(" is the map ")#mi("(a_{red}, a_{green}, a_{blue}) \\mapsto a_{red}")#text(" that extracts the outcome of the red die, ")#mi("(X_2)_\\Omega: \\Omega \\to \\{1,\\dots,6\\}")#text(" is the map ")#mi("(a_{red}, a_{green}, a_{blue}) \\mapsto a_{green}")#text(" is the map that extracts the outcome of the green die, and ")#mi("(X_1,X_2)_\\Omega: \\Omega \\to \\{1,\\dots,6\\}^2")#text(" is the map ")#mi("(a_{red}, a_{green}, a_{blue}) \\mapsto (a_{red}, a_{green})")#text(" that extracts the outcome of the red and green dice jointly.")

#text("Of course, if one is only interested in modeling the red and green dice and are totally uninterested in the blue die, one could also work instead with the smaller sample space ")#mi("\\Omega^{\\prime} = \\{1,\\dots,6\\}^2")#text(" that only describes the outcomes of the former two dice and ignores the third die. Or one could work with a much larger sample space incorporating lots of other measurements as well. The point of the probabilistic way of thinking, though, is that the choice of model is to a large extent irrelevant for one’s analysis.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97c6e2a22a3632ed2d32c6e877ee6ed05fabea1b365df2e197466fed3788ebd3-de4693fd37536e752e38612d626edd4d211b3474ad9cc68b56c2cfa44a2ede40.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rith")]], [#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/comment-page-1/#comment-513973")[#strong[#text("Rith")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2019")])]

#text("Thank you very much, Prof. Tao. This really helps.")
]
]
]
