// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/
// Converted to Typst by tao2typ: "2026-10-14T16:38:24.114444+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Gamifying propositional logic: QED, an interactive textbook", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Gamifying propositional logic: QED, an interactive textbook")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 July 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/")[#text("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("About six years ago on this blog, I ")#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/")[#text("started thinking")]#text(" ")#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/")[#text("about trying")]#text(" to make a web-based game based around high-school algebra, and ended up using ")#link("https://en.wikipedia.org/wiki/Scratch_(programming_language)")[#text("Scratch")]#text(" to write a ")#link("https://scratch.mit.edu/projects/2477436/")[#text("short but playable puzzle game")]#text(" in which one solves linear equations for an unknown ")#mi("{x}")#text(" using a restricted set of moves. (At almost the same time, there were a number of more professionally made games released along similar lines, most notably ")#link("https://dragonbox.com/")[#text("Dragonbox")]#text(".)")

#text("Since then, I have thought a couple times about whether there were other parts of mathematics which could be gamified in a similar fashion. Shortly after my first blog posts on this topic, I ")#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/")[#text("experimented with")]#text(" a ")#link("http://scratch.mit.edu/projects/teorth/2486639")[#text("similar gamification")]#text(" of Lewis Carroll’s classic list of logic puzzles, but the results were quite clunky, and I was never satisfied with the results.")

#text("Over the last few weeks I returned to this topic though, thinking in particular about how to gamify the ")#link("https://en.wikipedia.org/wiki/List_of_rules_of_inference")[#text("rules of inference")]#text(" of ")#link("https://en.wikipedia.org/wiki/Propositional_calculus")[#text("propositional logic")]#text(", in a manner that at least vaguely resembles how mathematicians actually go about making logical arguments (e.g., splitting into cases, arguing by contradiction, using previous result as lemmas to help with subsequent ones, and so forth). The rules of inference are a list of a dozen or so deductive rules concerning propositional sentences (things like “(")#mi("{A}")#text(" AND ")#mi("{B}")#text(") OR (NOT ")#mi("{C}")#text(")”, where ")#mi("{A,B,C}")#text(" are some formulas). A typical such rule is ")#link("https://en.wikipedia.org/wiki/Modus_ponens")[#text("Modus Ponens")]#text(": if the sentence ")#mi("{A}")#text(" is known to be true, and the implication “")#mi("{A}")#text(" IMPLIES ")#mi("{B}")#text("” is also known to be true, then one can deduce that ")#mi("{B}")#text(" is also true. Furthermore, in this deductive calculus it is possible to temporarily introduce some unproven statements as an assumption, only to discharge them later. In particular, we have the ")#link("https://en.wikipedia.org/wiki/Deduction_theorem")[#text("deduction theorem")]#text(": if, after making an assumption ")#mi("{A}")#text(", one is able to derive the statement ")#mi("{B}")#text(", then one can conclude that the implication “")#mi("{A}")#text(" IMPLIES ")#mi("{B}")#text("” is true without any further assumption.")

#text("It took a while for me to come up with a workable game-like graphical interface for all of this, but I ")#link("http://www.math.ucla.edu/~tao/QED/QED.html")[#text("finally managed to set one up")]#text(", now using Javascript instead of Scratch (which would be hopelessly inadequate for this task); indeed, part of the motivation of this project was to finally learn how to program in Javascript, which turned out to be not as formidable as I had feared (certainly having experience with other C-like languages like C++, Java, or lua, as well as some prior knowledge of HTML, was very helpful). The main code for this project is ")#link("http://www.math.ucla.edu/~tao/QED/code.js")[#text("available here")]#text(". Using this code, I have ")#link("http://www.math.ucla.edu/~tao/QED/QED.html")[#text("created an interactive textbook in the style of a computer game, which I have titled “QED”")]#text(". This text contains thirty-odd exercises arranged in twelve sections that function as game “levels”, in which one has to use a given set of rules of inference, together with a given set of hypotheses, to reach a desired conclusion. The set of available rules increases as one advances through the text; in particular, each new section gives one or more rules, and additionally each exercise one solves automatically becomes a new deduction rule one can exploit in later levels, much as lemmas and propositions are used in actual mathematics to prove more difficult theorems. The text automatically tries to match available deduction rules to the sentences one clicks on or drags, to try to minimise the amount of manual input one needs to actually make a deduction.")

#text("Most of one’s proof activity takes place in a “root environment” of statements that are known to be true (under the given hypothesis), but for more advanced exercises one has to also work in sub-environments in which additional assumptions are made. I found the graphical metaphor of nested boxes to be useful to depict this tree of sub-environments, and it seems to combine well with the drag-and-drop interface.")

#text("The text also logs one’s moves in a more traditional proof format, which shows how the mechanics of the game correspond to a traditional mathematical argument. My hope is that this will give students a way to understand the underlying concept of forming a proof in a manner that is more difficult to achieve using traditional, non-interactive textbooks.")

#text("I have tried to organise the exercises in a game-like progression in which one first works with easy levels that train the player on a small number of moves, and then introduce more advanced moves one at a time. As such, the order in which the rules of inference are introduced is a little idiosyncratic. The most powerful rule (the law of the excluded middle, which is what separates classical logic from intuitionistic logic) is saved for the final section of the text.")

#text("Anyway, I am now satisfied enough with the state of the code and the interactive text that I am willing to ")#link("http://www.math.ucla.edu/~tao/QED")[#text("make both available")]#text(" (and open source; I selected a CC-BY licence for both), and would be happy to receive feedback on any aspect of the either. In principle one could extend the game mechanics to other mathematical topics than the propositional calculus – the ")#link("https://en.wikipedia.org/wiki/First-order_logic#Rules_of_inference")[#text("rules of inference for first-order logic")]#text(" being an obvious next candidate – but it seems to make sense to focus just on propositional logic for now.")

#heading(level: 1)[#text("Comments (130)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd2ab81b388589c937b099cb5923ac16e2a9ca5aa7c975ea20b220ef1a7c447f-795ae681064273478353929990489c001aa0e93dbbef8da7552beb35f6c63546.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Åsa-Nietzsche")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503561")[#strong[#text("Åsa-Nietzsche")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("Thank you so much for making this, it’s a blast!")

#text("At the current version, when I get to 3.1(a) (where formulas are introduced) I can’t seem to drag the formulas to the root environment. I am also not able to create new formulas from the existing ones (however I can’t seem to recall if this is possible yet at this stage in the “game”).")#linebreak()#text(" I’ve noticed this after resetting my progress, and I’ve tested this in both chrome and firefox with the same result. Are you able to reproduce this error, or am I just missing something?")

#text("Once again, such a great learning tool!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503567")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("Implication introduction (dragging formulas to the root environment) is only unlocked in Section 4; combining formulas using logical connectives is unlocked (for AND and OR) in Section 5, and for the remaining logical connectives in the subsequent sections in which they are introduced.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd2ab81b388589c937b099cb5923ac16e2a9ca5aa7c975ea20b220ef1a7c447f-795ae681064273478353929990489c001aa0e93dbbef8da7552beb35f6c63546.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Åsa-Nietzsche")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503576")[#strong[#text("Åsa-Nietzsche")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("I’m terribly sorry (and possibly a bit thick), but the exercise text states “To use one of these laws, drag a formula from the Formulas window to a sentence in the Root environment window.” after introducing formulas. Am I stuck in some cached state that resists cache invalidation? At least for me, Exercise 3.1 (a) (‘Given A, formula “B”, formula “C”: deduce C OR (A OR B).’) also has the headline “Section 1: Disjunction introduction”, where I would suspect it to say “Section 3: …”. Am I right to suspect it is mixed up in some weird state for me?")

#text("I’ve tried resetting, refreshing without cache and changing browser but nothing quiet seems to work, whereas I was able to complete the exercise in an earlier version. I’m at Version 1.6.2.")

#text("If it is of any importance, I’ve been resetting since I’ve had trouble getting Disjunction Introduction to work properly for later exercises.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503577")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("You need to drag the formula to a sentence in an environment, rather than to just the environment. (The section numbering was a typo, now fixed.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd2ab81b388589c937b099cb5923ac16e2a9ca5aa7c975ea20b220ef1a7c447f-795ae681064273478353929990489c001aa0e93dbbef8da7552beb35f6c63546.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Åsa-Nietzsche")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503579")[#strong[#text("Åsa-Nietzsche")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("I’m an idiot. Thank you so much for your time and have a great week!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87da479966e9b01927993aac9869d90a386a1317323dace2ef2d1c3e8321622d-71aef8fa9ea1253772ba6af129f14e96ed7597d3e302c0f19f029df78c06eade.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Melissa Tacy")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503581")[#strong[#text("Melissa Tacy")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("A fun thing to play around with! I wonder about the possibilities of making such things more “beginner friendly”. I guess I’m thinking of a gamification where you start by getting some of the proof and need to fill in gaps with the available objects, at higher levels the gaps would get larger.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/346a3e84faf02ec40592e9efb4c9c2718d5151590a4446fe7b9627a43d85eda7-7e6cdac14496a2ae8eeb38f96abd40e5e423b11861ef2b0251f1dc58053d5bb5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob H.")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503588")[#strong[#text("Jacob H.")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("🤔 although I think some of the “fun” is in figuring out the “trick” to different kinds of proofs. It makes the occasional hours-long struggle worth it, and you definitely don’t forget after a struggle like that")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87da479966e9b01927993aac9869d90a386a1317323dace2ef2d1c3e8321622d-71aef8fa9ea1253772ba6af129f14e96ed7597d3e302c0f19f029df78c06eade.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Melissa Tacy")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503589")[#strong[#text("Melissa Tacy")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("True, the best problem is always one that’s a little out of reach. However having a beginner level doesn’t prevent anyone from enjoying more advanced levels, just opens it up to a wider range of people.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65b640fcc8088a92c4ea3f003a868061bf8b3391a48325174445797bdeff8c66-de0e5026dfd7fd7faa68b145805b1eb3954197fe26489cd7a67eeb5c0eb39d5c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503592")[#strong[#text("Max")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2018")])]

#text("Very nice. (Consider also Smullyan’s logic puzzles.) For easier use in Mobile devices it would be great to be able to “fold away” subsections. (The exercise list already takes up more than a whole screen full.) Maybe the exercise list could also be a in a drop down menu (easy to do with CSS).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4899a6c320808d232367f9ec0ffe97c2d00a4a4b61233af140429f93079fe17e-d2a4ef82c46ab57c3bf97717c348097ef73bb5ec158e701de781d4a6a7fad1b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L Spice")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503594")[#strong[#text("L Spice")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2018")])]

#text("Two more possible UI tweaks, both to do with commutativity. First, is there a reason to have the options available when combining two propositions depend on the order? (I find myself unable to remember whether, for example, I drag NOT A to A OR B, or whether I draw A OR B to NOT A, and it’s not clear to me that the requirement to remember (or, as I do, just try both) is improving the game or my understanding of propositional logic.) Second, if I use the REVERSE DEDUCTION THEOREM to deduce B [ assuming A ] from A IMPLIES B, and if I then use IMPLICATION INTRODUCTION to deduce A [ assuming A ] from formula “A”, then I have two separate “assuming A” environments, with no obvious way to combine them; whereas, if I *first* use IMPLICATION INTRODUCTION, then the two environments are combined. Since it is almost always the latter that I want, maybe it could be made the behaviour in both cases?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503607")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2018")])]

#text("I have now implemented the first suggestion. However, I cannot duplicate the splitting of assumption windows reported in your second suggestion (which should not be the outcome of the code as currently written). Is there an exact sequence of steps you have found that can produce this error?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4899a6c320808d232367f9ec0ffe97c2d00a4a4b61233af140429f93079fe17e-d2a4ef82c46ab57c3bf97717c348097ef73bb5ec158e701de781d4a6a7fad1b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L Spice")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503621")[#strong[#text("L Spice")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2018")])]

#text("I also cannot duplicate the splitting of assumption windows. Either I imagined it in the first place, or it has since been fixed. Thank you!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8229db6ec4f01a7b84ddc201d2bd7d6fe8941af645b90aca0239468bb5a55550-0362b6387e6dca1f252e868949ad1d47760ba7d8d6929e692f9360d34ba04b90.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roy Dong")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503600")[#strong[#text("Roy Dong")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2018")])]

#text("When I was in undergrad, I took a metalogic class that used Barwise & Etchemendy’s “Language, Proof, and Logic”. It came with software that reminds me of this game. (It’s called “Fitch”.) I think it’s definitely worth checking out; it looks like you and B&E had similar goals, but came to different UI implementations for them. It’s really interesting to me how the implementations are different, and, also, I think one or the other would be more effective depending on the type of learner playing the games.")

#text("(They also have a software “Tarski’s World” for some very basic model theory, which, in retrospect, helped me greatly in conceptualizing the semantic metamathematics courses I took several years later.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2c0a48a834d4bec7a48cf02868182f8e1527c6f6c9ab161cdf91dbde7014ec4-398c7ac1266e3e121ee2380c678ae76980dbca7c18c8e559826dbbabb370cb57.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron Chen")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503613")[#strong[#text("Aaron Chen")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2018")])]

#text("Great game/exercises! Three comments:")

#text("– Not sure if this was intended, but exercises 12.2a through 13.1a are unlocked together, which means that upon clicking on 13.1a, the formulas TRUE and FALSE show up in the section 12 exercises.")#linebreak()#text(" – On a couple of occasions, I had to go back to redo some exercises for them to become usable (refreshing/merely clicking on them didn’t work).")#linebreak()#text(" – A UX suggestion would be to allow CTRL to select two (or even multiple [for future additions]) formulas at a time instead of dragging a formula onto another one (an even fancier idea would be to have it so that once a tentative move has been made, to allow selection of the action via hotkeys rather than clicking).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503617")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2018")])]

#text("I’ve now added ctrl-click and hotkey functionality. (In particular, it is now possible to apply exercises that involve three or more hypotheses, which was not previously possible, using ctrl-click. Thanks for the suggestion!)")

#text("The unlocking order is as intended. For a beginner it is best to do the exercises in sequential order, in particular finishing an entire section completely before moving on to the next one, but if one just wants to unlock the sections as fast as possible one just has to do the first exercise of each section. Once this is unlocked, earlier exercises will acquire the tools unlocked by later ones (in particular, once 13.1(a) is unlocked one gains access to TRUE and FALSE, though this is not actually all that helpful for any exercise before Section 13).")

#text("Some of the unlocking quirks may be due to version updates between refreshes. If it is a persistent problem, please let me know of a specific way to reproduce the issue and I can try to debug it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd643503858305a50272d712785df7a1a6ece67b8a7b717ebd94708222872e82-69638d9a519d8b356c1d42a1c61c342a48193e215ce7da214d9cb2ce0183180d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mauricio de Oliveira")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503666")[#strong[#text("Mauricio de Oliveira")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2018")])]

#text("Hello Tao :), the conjunction introduction hyperlink is redirecting to ")#link("https://en.wikipedia.org/wiki/Conjunction_introduction_target%3D")[#text("https://en.wikipedia.org/wiki/Conjunction_introduction_target%3D")]#linebreak()#text(" instead of ")#link("https://en.wikipedia.org/wiki/Conjunction_introduction")[#text("https://en.wikipedia.org/wiki/Conjunction_introduction")]

#emph[#text("[Fixed in latest version -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503682")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2018")])]

#text("Thanks for doing this! Potential [[deletes]] & [adds] to the Ex. 1.1 explanatory bullets:")#linebreak()#text(" • If one drags one [[hypothesis]] [true statement] to another, the Available deductions window below will show what conclusions one can draw [from those statements] using the available deduction rules …")#linebreak()#text(" • For instance, to solve this level one drags the B statement onto the A statement (or vice versa), clicks on the button marked “B AND A” [to add that statement to the root environment], drags [[that]] [the new “B AND A” statement] [on]to the B statement ….")#linebreak()#text(" • The exercise is completed when you have managed to obtain the desired conclusion (in this case, (B AND A)[ AND B]) …")

#emph[#text("[Suggestions incorporated into latest version, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab00358290ca3f655a329ec5d873b89c34b4a6bcf273fce7516e3f7feebd1e49-71f33326c7f7847a9036f8f561b57b711f6304a1bfd0edadc28f087bb64f2246.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian Slesinsky")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503735")[#strong[#text("Brian Slesinsky")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2018")])]

#text("I’m wondering if 14.1 is supposed to work yet? I tried dragging P(x) and Q(x) to the predefined root and child environments in that exercise and nothing happened. It’s also unclear if I can make a new environment.")

#text("—")

#text("I also tried redoing 13.1a. The first two steps worked fine:")

#text("Deduce A [assuming A]. [IMPLICATION INTRODUCTION]")#linebreak()#text(" Deduce TRUE [assuming A]. [TRUE]")

#text("I then tried dragging A to TRUE and I don’t get offered “A AND True (assuming A)” as a choice. Instead I’m offered two more complicated choices:")#linebreak()#text(" “(TRUE AND A) AND TRUE (assuming A)”")#linebreak()#text(" “(A AND TRUE) AND TRUE (assuming A)”")

#text("I think the last time I played, it was version 1.8, and I had finished all the exercises.")

#emph[#text("[This should now be fixed, but if conjunction introduction is still unavailable, try clicking on Exercise 1.1 again. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8951d29e0facf663b2ff907919a622cf79a07bcf099958d34672a014756d86f9-8fd0c668fadae523d3e1b04594f399e65502daa4aae6dff43526a7b07ea69c6e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503739")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2018")])]

#text("In the current UI it is very hard to guess (I failed) how to prove 7.1 in an optimal way. I need to create an environment with assumption B (inside the environment with assumption A), but I don’t need B inside that environment — how to do it? If I agree to put B inside, an extra (unused) step in the proof is created…")

#emph[#text("[Fair enough – new version has an alternate push functionality that does not require the unused step. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503762")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2018")])]

#text("I am running into some trouble getting a desired layout to occur and am hoping that there are some CSS or layout experts here that can help me.")

#text("Right now there are four main windows to create proofs: the “Root environment” window, the “Formulas” window, the “Available deductions” window, and the “Terms” window. (The “Formulas” and “Terms” windows are hidden initially, and are only unlocked in later sections.) There will also be a fourth window (“Predicates/Operators”) to be implemented in the future. I would like a layout in which the location of the “Root”, “Formulas”, “Terms”, and “Predicates/Operators” windows are fairly stable, but in which the “Available deductions” window can become rather long, but in which all five windows can be visible on a single screen if at all possible. (The text has other windows like the Exercises, Proofs, Achievements, and Notifications windows, but it is less essential that these also be visible on a single screen.) The format I currently am implementing is a fixed width 2 x 3 grid")

#text("A B C")#linebreak()#text(" D E F")

#text("in which the root environment occupies position A, formulas occupies position B, terms occupies position D, the future Predicates/Operators window occupies position E, and Available deductions occupies columns C and F. This layout is sort of close to what I would like, except for the behaviour of the height of the elements. Namely, in the event that the available deductions window gets too lengthy, I would like it to keep flowing downwards without resizing the A,B,D,E windows as well. Currently it seems that the A and B windows are stretching to match the available deductions window, which is thus stuck in C and never flows down to F, let alone beyond F.")

#text("Probably the better thing to do is to put the root, formulas, terms, and predicates/operators window in a separate element occupying 2/3 of the screen width, and the available deductions in an element occupying 1/3 of the screen width, but I have been having some trouble making such a layout behave properly.")

#text("Another issue is that the grid display I am using does not seem to be compatible with IE and Edge, so a solution that is supported by these browsers would be preferable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503764")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2018")])]

#text("Dear Prof. Tao,")

#text("I think there are several ways to do this, as so often.")

#text("My personal philosophy on webdesign is to use as little div (or similar block) elements as possible, since each increases rendering time. (On slower computers, eg. your website is pretty slow because of this. No offence.)")

#text("A solution that would match that paradigm would be to use display:inline-block and float:right (where one would have to set the width accordingly). The right bar would have to precede the others in the HTML code. (I hope I’m not messing up the syntax now, but the specs are easily googlable and w3schools is the link one should click.)")

#text("This should be compatible with IE (especially since the new versions ought to have fixed the old box model issue), but maybe the margins are defaulted in a different way in IE, so that they would have to be manually set to zero in order to avoid unwanted linebreaks.")

#text("If my solution should not work, you could always use nested divs; eg. you could put ABDE in one div and CF in another and have them display side by side using position:absolute (which positions with respect to the next-higher level block element, not the screen).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503765")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2018")])]

#text("Speaking of margins, let alone paddings, positions, font-sizes, borders, etc.")

#text("(Regarding your blog, I’ve still got my CMS very much on the agenda. At the about section, I had an inquiry regarding that…)")

#text("In principle, I could also program the layout and send you a copy of the source per email.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb335dd926f0aba67d981d44299918f0bd044cc6672d3ebafdc416dc92930cfa-d00acf4edbcad093e4f09e3a6b963726bb329f03d6a09187f23a19f9f2587ff2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of redblobgames")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503766")[#strong[#text("redblobgames")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2018")])]

#text("For .deductions change grid-row: 1/2 to grid-row: 1/3. I believe it’s a half-open interval, so 1/2 is only one row and 1/3 is two rows. (I am new to css grid and was expecting it to be a closed interval)")

#text("CanIUse says Edge should support css grid ")#link("https://caniuse.com/#feat=css-grid")[#text("https://caniuse.com/#feat=css-grid")]#text(" and the grid seems to be working for me in Edge.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503767")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2018")])]

#text("Thanks! Setting grid-row to 1/4 actually gave the behaviour I wanted, namely that lengthening the deductions window had no impact on the placing of the other windows. Perhaps there is a leaner and more elegant solution, but this seems “good enough” for now.")

#text("Currently the page is not working on Edge, but the problem was not the grid as I had thought, there seems to be a bug in Edge regarding how localStorage is handled ")#link("https://developer.microsoft.com/en-us/microsoft-edge/platform/issues/14930573/")[#text("https://developer.microsoft.com/en-us/microsoft-edge/platform/issues/14930573/")]#text(" . I assume this will get patched eventually so I am not sure whether it is worth trying to make a workaround for it now. ")#emph[#text("[UPDATE: weirdly, the edge localStorage bug only shows up for my local copy of the code, not the one on the web page, so actually it’s a bug that only affects me! ]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2122ee7b38c07898709e829c054a43179d1fa76fee6bd5d581730b99e6b0778-eec583d82551f80e193c2b280e9404b7a513116fc7a3e0331c59a68b2c4b5bb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Corentin Louboutin")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503778")[#strong[#text("Corentin Louboutin")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2018")])]

#text("Hi, thank you for the website, it’s very interesting and I have a lot of fun doing the exercises, however, since the last update, I’m facing a interface bug. See : ")#link("https://i29.servimg.com/u/f29/19/02/08/32/screen10.png")[#text("https://i29.servimg.com/u/f29/19/02/08/32/screen10.png")]

#text("I’m using firefox with fedora (I think its 22 but I’m not sure).")

#text("I hope you can solve")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503789")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2018")])]

#text("It seems that the grid layout I am using is supported from version 54 of Firefox onwards; I encountered the same issue with an older version of Firefox when testing just now, but the problem resolved once I updated to the latest version.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2122ee7b38c07898709e829c054a43179d1fa76fee6bd5d581730b99e6b0778-eec583d82551f80e193c2b280e9404b7a513116fc7a3e0331c59a68b2c4b5bb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Corentin Louboutin")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503793")[#strong[#text("Corentin Louboutin")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2018")])]

#text("Ok, thank you very much !")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/644708a37ad48d1e5cbd2d36dedfa9c0ff955e0805dc868d5e897da67e7b7dc7-94d2ea3a8a07e14c36ae8110096e78c755a5494a0ae9d746642939e3495301d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of curious")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503893")[#strong[#text("curious")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2018")])]

#text("Does propositional logic help extract grammar from scenes in vision?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28b3868b80ddac4925ef086ec21dfa6072e21c4b29229fe8b5c3cf3d35e3449b-bfdd190fab8f1a5bcbe14c22cda807b92bd161077c1788a4e461aa77ec67166d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine Deleforge")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503988")[#strong[#text("Antoine Deleforge")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2018")])]

#text("Hello,")

#text("It looks like starting from section 14, most exercises are not reusable once they are solved. The only exceptions are 15.2(a-c), 18.2(b), 19.2(a-b) and 21.1, which are all re-usable. But I am not able to reuse, for instance, exercises 17.2, 18.2(a), 18.4, 18.5, 18.6, 20.1, 22.2, 22.3(a-b), though they could all be helpful in shortening some subsequent proofs. Is it due to a bug occuring on my side or is it intended?")

#text("Thanks !")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-503994")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2018")])]

#text("I haven’t been able to come up with a good general matching algorithm yet for exercises that involve predicates, for two reasons. One is non-unique matching: for instance, if one wants to express ")#mi("Q(x,y)")#text(" in the form ")#mi("P(z)")#text(", then one could choose ")#mi("P(z) = Q(x,z)")#text(" and ")#mi("z = y")#text(", or ")#mi("P(z) = Q(z,y)")#text(" and ")#mi("z=x")#text(", or ")#mi("P(z) = Q(x,y)")#text(" and ")#mi("z")#text(" equal to any variable other than ")#mi("x,y")#text(". the other problem, potentially more serious, is the need to carefully check side conditions. For instance, right now, given “THERE EXISTS X: A”, one can deduce “FOR ALL X: A”, by pulling A (which does not depend on x) out of a “setting x” environment and then pushing it into a “let x be arbitrary” environment. However, if one then tries to use this deduction with A replaced by something that involves X, then one gets an invalid deduction: for instance, given “THERE EXISTS X=0”, one cannot deduce “FOR ALL X: X=0”. So to reuse this exercise, the code has to somehow know that A must remain independent of X. [In some cases I was able to prevent this by requiring that the conclusion be well-formed (e.g. does not use any free variables that are not introduced in the ambient environment, but the above example is the first instance where the well-formed requirement is insufficient.)")

#text("For certain key laws and exercises I have been implementing the matching by hand, writing special code for each such law. But this isn’t really a scaleable solution (and I’m finding that a lot of bugs can be introduced by this). So I’m not sure how to proceed in general.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of QED version 2.0: an interactive text in first-order logic | What's new")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-504076")[#strong[#text("QED version 2.0: an interactive text in first-order logic | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2018")])]

#text("[…] readers who have followed my previous post will know, I have been spending the last few weeks extending my previous interactive text on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-504077")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2018")])]

#text("As the number of comments to this post is getting rather large, I recommend people wishing to report bugs, make suggestions, or offer other feedback use the new blog post for QED: ")#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/")[#text("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-504452")[#strong[#text("Resumen de lecturas compartidas durante julio de 2018 | Vestigium")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2018")]

#text("[…] Gamifying propositional logic: QED, an interactive textbook. ~ Terence Tao #Teaching #Logic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-2/#comment-533285")[#strong[#text("יומיות 02.08.2018: הקונגרס למתמטיקה 2018 התחיל, וכבר הוענקו מדליות פילדס | ניימן 3.0")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2019")]

#text("[…] בפינה מבדחת. טרנס טאו, אולי המתמטיקאי הגדול של זמננו, הכין משחק מחשב כיפי שאמור ללמד […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d72d6a58481f06f205b6f3f645c528227efef597e07e492f4f2697bcf00ba24-322954602a9c9cb9249f20c7292d00f7fd7d83c749cd4276d4bdf6c47a87bd5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexi")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503388")[#strong[#text("Alexi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2018")])]

#text("Thanks for making this! I always get so excited to see math education forward progress, and I would count a truly interactive text as part of what we should head toward. I’ll need to try this on a computing device other than my iPhone.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jr")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503389")[#strong[#text("jr")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2018")])]

#text("This is awesome! It reminds me of edukera.com, a platform that teaches formal logic in a similar way (first order logic works really well too; and they seem to have ambitions of going beyond logic; they have an experimental calculus module for instance).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c233ddc2aa54e526356577f379913dc3260b8fc00628082bb76b0f5ca1581875-f94952855084b14b398098612c9da477fd3d7d4b40eb88ab38dd9f7c64b516c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pg261")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-504113")[#strong[#text("pg261")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2018")])]

#text("Edukera is a web interface on top of Coq, itself a very powerful proof assistant. It’s worth checking it out.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/346a3e84faf02ec40592e9efb4c9c2718d5151590a4446fe7b9627a43d85eda7-7e6cdac14496a2ae8eeb38f96abd40e5e423b11861ef2b0251f1dc58053d5bb5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob H.")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503390")[#strong[#text("Jacob H.")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2018")])]

#text("What a great little app. minor erratum: exercise 6.1(a) says “(or the condiional)”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e368eee5a14c4e8825e4ef070a0f1968c967775975f43bb870f98f3c0456bb1-460be13454d28a1bc8ede2d89e01d2b779359975107e240d6416b1226217ab17.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stuart Errol Anderson")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503392")[#strong[#text("Stuart Errol Anderson")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2018")])]

#text("At high school, one my math teachers introduced us to WFF’N PROOF. A WFF is a well formed formula. In the game, students must be able to recognize a WFF and use seven different Rules of logic to manipulate those WFFs into a proof. Games are played in groups of two or three. The first player rolls the cubes and sets a WFF as a Goal. The goal is the conclusion")#linebreak()#text(" of a proof. Each student then tries to construct a proof that ends with")#linebreak()#text(" the goal. The Solution to the goal is the premises which they started their proof with, and the rules they used to get to the goal.")

#link("https://www.oercommons.org/authoring/1364-basic-wff-n-proof-a-teaching-guide/view")[#text("https://www.oercommons.org/authoring/1364-basic-wff-n-proof-a-teaching-guide/view")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/198042b9d466e811a27e6979fc69aabf6eeb57c3354e456bc1055ae499d0cf3a-f57c7c6c54477adecb1fad498459b9594b460059af33cfc97e9dd609821823be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503394")[#strong[#text("Brian")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2018")])]

#text("How do I move on from Ex 1.1?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/198042b9d466e811a27e6979fc69aabf6eeb57c3354e456bc1055ae499d0cf3a-f57c7c6c54477adecb1fad498459b9594b460059af33cfc97e9dd609821823be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503395")[#strong[#text("Brian")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2018")])]

#text("OK got it")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc3019e0b7229da37c9cae1b97a333e79a83a74c66c22c37a4aedb5d630e507d-3bbcbff41f5bd89e98a66533a8a75603d78131de30d4fd25d4b79760f98b9aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brahadeesh Sankarnarayanan")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503396")[#strong[#text("Brahadeesh Sankarnarayanan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("Can you let me know how you got it? I’m stuck on Ex 1.1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc3019e0b7229da37c9cae1b97a333e79a83a74c66c22c37a4aedb5d630e507d-3bbcbff41f5bd89e98a66533a8a75603d78131de30d4fd25d4b79760f98b9aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brahadeesh Sankarnarayanan")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503398")[#strong[#text("Brahadeesh Sankarnarayanan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("Aaand, now I feel foolish. Never mind.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73cab4c7799fd38d56e778603f26b99c20272b79ffc2fe13b51a9dd91542dd74-4ca5d8b41e1fcb2da86e3efd3d8878ce798b598eaae63d392d5163e86d0669e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503403")[#strong[#text("Dave")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("OK, why not let us foolish people in on the secret so we won’t have to keep asking it over and over? :)")

#text("It doesn’t seem to work in Internet Explorer 11: dragging the A box over the B box does not result in A AND B.")

#text("In Firefox 52.9ESR I get a box labeled A AND B; clicking on that box adds the A AND B proof step, but I see nothing relevant to click on from that point.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503408")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("Hmm, you’re right about Internet Explorer 11. I guess something in the javascropt is not supported on that browser (presumably relating to a drop event listener), will try to pin it down. Works in Edge 42 and Chrome 67 though.")

#text("For Firefox, this is the correct behaviour if one drags A to B. Try also dragging B to A.")

#text("Browser issues aside, though, it does seem though that Exercise 1.1 (which was intended as a “tutorial” exercise) is not sufficiently self-explanatory. I would appreciate any suggestions to make it more so.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503409")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("Ah, I think I found the IE problem: I was assuming that the browser supported local storage (to save progress between sessions), but it seems that some browsers do not. I’ll update the code to disable the local storage features if they are not available.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503411")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("I’ve now updated the code so that it runs in browsers such as IE and Opera that do not support local storage. (Of course, with such browsers, your progress will not be saved between sessions.) I’ve also now displayed all the exercises that have not yet been unlocked as disabled (red) buttons. (This clutters the screen a bit, unfortunately, but it now gives a sense of how much of the text one has already completed.) Incidentally, I would be happy to accept any suggestions on how to improve the graphical layout of the text (I do not have any formal design or GUI experience).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/500fe966761263f94962e8aad6d95e02132aeaca22d72a667b1f0968a2814bc6-33ca44aebdc2812716a5b8eb89fbbd1b96591d3561c1e6aad5d2d93703df325f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ihenderson")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503428")[#strong[#text("ihenderson")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("One nice UI improvement would be to highlight the “drop target” as you’re dragging a statement over another compatible statement (to emphasize the fact that the two statements will interact when you release the mouse button).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Timo")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503397")[#strong[#text("Timo")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("Great idea, thank you, Terry!")#linebreak()#text(" If you are interested in it historically, there were many forms of logic games and interactive logic, especially in the middle ages, most prominently a practice called “obligatio”. This short paper introduces it quite well: ")#link("http://apcz.umk.pl/czasopisma/index.php/LLP/article/view/LLP.2012.020")[#text("http://apcz.umk.pl/czasopisma/index.php/LLP/article/view/LLP.2012.020")]

#text("Best wishes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc8d238f2c7cce8ce3de8ac9de4dbaf95fdebad43d8184cb0bcb853c31d2b51b-54012e2a02eb231535659cd57c4f3da5ba4902c853bdcf793b0f59c4d542cd62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marvin Meyer")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503400")[#strong[#text("Marvin Meyer")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("Unfortunately I am stuck on Exercise 1.1 as well. How to proceed, what is to do? From the explanations it is not clear to me what the content of the exercisr is.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6903009ef14c5d03924f633bcb0cc51300a8f60d31193b3dee2e0447528690-b85c3528dd9fc627686ecb36265c26512c6f006c20dc3ec961820231450e21c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hugo")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503502")[#strong[#text("Hugo")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2018")])]

#text("dragging the B box over the A box result in B AND A.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503401")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("Is it possible to describe each proposition as a vertex of some (abstract) graph such that any proposition is connected by some directed(!) edges to some other propositions (represented by some vertices) from which it can be deduced?")#linebreak()#text(" Is it possible (for some simple inference problems), to prove that some proposition follows from others just “by inspection” that the new proposition is connected (via some edges) to the other propositions?")#linebreak()#text(" Using available advanced graph theory tools, it seems that such graph theoretic approach (with possible combination of “deep learning” tools) may lead to some nontrivial mathematical discoveries.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/269fcd5199eff373d83f6447233e879eb30401ed8fb394d47c2209fb1d2bd86d-ad60521264b91f93efc4ed3ea9732fde3cb1ee06f4fcb37941198ff8b0c34b23.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dmitriy")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503402")[#strong[#text("Dmitriy")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("Fun game, thanks!")

#text("I’m confused though. According to the description, “this text contains thirty-odd exercises arranged in twelve sections”, but I’m only able to access 13 exercises in 7 sections. After completing exercise 7.1 I got a congratulatory message implying I’ve reached the end, and no further exercises are available.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/131e3775112c97ca41229dbea7879237229727fd68ddb719b1015333f62eaed2-ec6bab676206deac3d43cc64555dae7d8990975bf0a9ae0406b98f9ed9f4ae5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vassily")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503404")[#strong[#text("Vassily")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("Does anyone know of anything similar to: ")#link("http://www.math.ucla.edu/~tao/QED/QED.html")[#text("http://www.math.ucla.edu/~tao/QED/QED.html")]#text(" It was a great fun but it ended in 5 minutes unfortunately.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/046753e798fe90935c01f67229ca3c8321cb3e9d52394046985025cbc3973a2f-f3e1bb1ed27531b97d170976eb5c3b2673cacaf9532d797aea87a983dfb1d98f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anton Trunov (@Anton_A_Trunov)")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503410")[#strong[#text("Anton Trunov (@Anton_A_Trunov)")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("Hi! You might like ")#link("http://logitext.mit.edu/main")[#text("http://logitext.mit.edu/main")]#text(" or already mentioned ")#link("https://www.edukera.com")[#text("https://www.edukera.com")]#text(". There is also “Introduction to Logic” course on Coursera by Mike Genesereth (")#link("https://www.coursera.org/learn/logic-introduction/")[#text("https://www.coursera.org/learn/logic-introduction/")]#text(". Also, proof assistants (e.g. Coq) are pretty fun too :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4989f13b6e1178d79115cba1b968294fbd09d7e7b6b10ba67098b784b2b0c2a2-006fd46d609e21c2958d33aa5c13d965ae73aa97bac5c7a3ce24c11b3bdb3f30.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antony Karl Bartlett")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503414")[#strong[#text("Antony Karl Bartlett")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("The Incredible Proof Machine? ")#link("http://incredible.pm/")[#text("http://incredible.pm/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/84920028c8a77fa6badf79cc16fbf381c8e2d92ed7c47302f6bb1cc34c348f9e-01ef04b5ef1b58a71fbe0cc8f3b459639a6650f6e3bd441f92d2281551b7dd30.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luis Ignacio")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503405")[#strong[#text("Luis Ignacio")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("Er… Tao, i think there is an error: “var Exercise72 = new Exercise(“EXERCISE 7.2”, “DOUBLE PUSH”, [A, environmentcontext([B,C])], assuming(assuming(A,C),B));")#linebreak()#text(" Exercise72.unlockedBy(Exercise71);")#linebreak()#text(" Exercise72.notes = ‘This is an easy consequence of the push law, but turns out to be convenient in some subsequent exercises.’")#linebreak()#text(" “")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/84920028c8a77fa6badf79cc16fbf381c8e2d92ed7c47302f6bb1cc34c348f9e-01ef04b5ef1b58a71fbe0cc8f3b459639a6650f6e3bd441f92d2281551b7dd30.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luis Ignacio")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503406")[#strong[#text("Luis Ignacio")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("Uncaught ReferenceError: environmentcontext is not defined")#linebreak()#text(" at QED.html:158")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503407")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("Gah! The “c” in context should have been capitalised. Fixed now. (Unfortunately, anyone who has gotten to that exercise or the one preceding it may need to reset the text in order to be able to unlock this exercise and the subsequent ones.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b7a838c8a9565df0f600b1e67d60303fed5274d9ae83791074023a874284d1b-177794126f73ac30034fde55d6176bb95ab60182a2743ee670dc60fe3e4f951f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zrabel")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503413")[#strong[#text("zrabel")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("This is great! I wonder if this could be useful next time I teach discrete math. Minor typo: In the statement of 7.2, I believe “[assuming B,C]” should only appear in the deduction, not the given. Also, 12.4b is possible in 13 lines!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1d0c9b6e3d598fc6819a9be70726912eb2945d73e74e961443995e631e7c3e4-e5a143bae28f525b55b430b325d4eaeb879ffbbbaf6aa4f7025a0bb4879843c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joerg Grande")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503415")[#strong[#text("Joerg Grande")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("Thanks for the nice diversion.")

#text("There is a typo in the popup box after exercise 1.1: “quad” should be “quod”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1f8ba60258f2fe287742c70e31c82fc784f2f1d90366d94305084d291f3ff04-46edd238a81d690eb0e927bbe8b2fcf73aadf386f1bf4b986acf14ebb9da4f76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ahartel")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503416")[#strong[#text("ahartel")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("Thanks for this very nice game. I like the idea very much.")#linebreak()#text(" There is a minor suggestion for improvement I have: When (accidentally) clicking twice on one of the available deductions then that same deduction gets added twice to the proof list and the root environment. This will also happen when the proof is already complete (in which case two extra lines get added for each click, namely the deduction itself and another QED). When this first happened to me accidentally I found it a bit annoying because it made my score (number of proof lines) look bad. But in general it didn’t decrease the fun of the game too much :)")

#emph[#text("[Thanks for the idea! Now implemented – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d1cf1d0467526ca0a139eeb0ff6a12c4778a2b518c36d91699d81fac709da097-ac294f4e05017da706e95728d5d390f89489c3df09c42a3c09cba2b480d57cd4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cory")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503419")[#strong[#text("cory")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("This was fun. I believe there is a mistake at 12.1(c) – if we assume B and get a contradiction how could we deduce B? At 12.4(b), does the caveat “not using anything at this exercise” suppose to prevent us from using the deduction of (NOT(NOT(A))) from A? (otherwise it is possible to solve it with 7 lines and 12.5(d) seems to be solvable with 9 lines)")

#emph[#text("[Now corrected, thanks. Also thanks for pointing out the shorter proofs. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503420")[#strong[#text("Anton Farmar")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")]

#text("It’s worth noting that there are an awful lot of logic ‘games’ in the same vein as this, such asThe incredible proof machine (")#link("http://incredible.pm/")[#text("http://incredible.pm/")]#text(") and Logitext (")#link("http://logitext.mit.edu/main")[#text("http://logitext.mit.edu/main")]#text("). I’m really glad you find this interesting, as I personally really love this sort of puzzle!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f473b47a288f5cd4c4a31378dcefa706dffad08d6cde68edf0b53b9f63a9ae3-054c6105fdccf0c64ab2896a4c8a1923cbc71751d82f58a4cdd02d004678c0d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marisa Kirisame")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503421")[#strong[#text("Marisa Kirisame")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("I am getting undefined… see ")#link("https://imgur.com/a/w3jrecw")[#text("https://imgur.com/a/w3jrecw")]

#emph[#text("[Now corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Crust")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503422")[#strong[#text("Crust")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("typo in 2.2(a): (such as A or B can -> (such as A or B) can")

#emph[#text("[Now corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503424")[#strong[#text("New top story on Hacker News: Gamifying propositional logic: QED, an interactive textbook – World Best News")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")]

#text("[…] Gamifying propositional logic: QED, an interactive textbook 5 by robinhouston | 0 comments on Hacker News. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503425")[#strong[#text("New top story on Hacker News: Gamifying propositional logic: QED, an interactive textbook – News about world")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")]

#text("[…] Gamifying propositional logic: QED, an interactive textbook 6 by robinhouston | 0 comments on Hacker News. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503426")[#strong[#text("New top story on Hacker News: Gamifying propositional logic: QED, an interactive textbook – Tech + Hckr News")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")]

#text("[…] Gamifying propositional logic: QED, an interactive textbook 6 by robinhouston | 0 comments on Hacker News. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503427")[#strong[#text("New top story on Hacker News: Gamifying propositional logic: QED, an interactive textbook – Latest news")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")]

#text("[…] Gamifying propositional logic: QED, an interactive textbook 6 by robinhouston | 0 comments on Hacker News. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503429")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("Thanks for all the feedback! The new version has corrected the errors pointed out and also implemented the no-double-click feature. Also I have moved the achievements and notifications windows to be side-by-side, and have the achievements go from newest to oldest rather than vice versa. One or two more exercises have also been added (but if you want to access them, you may need to reset the text which will mean that you will have to redo the exercises.)")

#text("I have also now indicated below each exercise the shortest length of proof I can find using the tools provided up to that exercise. (These exercises will tend to get much shorter proofs though after the exercise is solved, in particular one can often use the exercise to solve itself in a handful of lines.) If anyone can improve upon any of these lengths, please let me know and I will acknowledge your contribution in the next version of the game.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503430")[#strong[#text("Gamifying propositional logic: QED, an interactive textbook – TARIAN LIMITED")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")]

#text("[…] About six years ago on this blog, I started thinking about trying to make a web-based game based around high-school algebra, and ended up using Scratch to write a short but playable puzzle game in …Read More […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab00358290ca3f655a329ec5d873b89c34b4a6bcf273fce7516e3f7feebd1e49-71f33326c7f7847a9036f8f561b57b711f6304a1bfd0edadc28f087bb64f2246.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian Slesinsky")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503431")[#strong[#text("Brian Slesinsky")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("I’m stuck at exercise 5.2. This exercise is about creating nested assumption boxes, but I don’t see a way to do so in the UI. (I can separately assume any of {A,B,A AND B} at top level, but don’t see a way to nest, combine, or split assumptions.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab00358290ca3f655a329ec5d873b89c34b4a6bcf273fce7516e3f7feebd1e49-71f33326c7f7847a9036f8f561b57b711f6304a1bfd0edadc28f087bb64f2246.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian Slesinsky")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503433")[#strong[#text("Brian Slesinsky")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("It turns out this was because I had forgotten the UI interaction used to solve 4.1. (After solving it once, you don’t technically need it again.) Maybe repeat the directions for drag and drop?")

#emph[#text("[Thanks for the suggestion, I have added a line to the text for Exercise 5.2. -T]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/365a2ba385f33cd246174415ed7d112c02351f7184efd5e6fce011d6559159b3-1c8dd3d3314121506a7334cbbbca716b42f9244623417f774701789cd841a09b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam Nemecek (@a_nemecek)")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503432")[#strong[#text("Adam Nemecek (@a_nemecek)")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("Are you aware of linear logic, aka the gamified version of classical logic? It’s a fascinating formalism, basically it’s classical logic with two players. I see some deep connections between QED and linear logic (the fact that QED is a game of sorts is only the beginning). I’m also strongly convinced that it’s a superior logic for mathematics, as for example all optimization falls outside of classical logic but linear logic can handle it.")

#text("The wikipedia entry is actually pretty good ")#link("https://en.wikipedia.org/wiki/Linear_logic")[#text("https://en.wikipedia.org/wiki/Linear_logic")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/19eaf477638a923393844679a22a190da14c412d9885aef2af0da6bfd354be73-7e523f2069b71faa2c6f13b65a26433e0cf7e07c0421968a1c991619934baed2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Johnsen")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503434")[#strong[#text("Fred Johnsen")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#link("https://en.wikipedia.org/wiki/Tarski%27s_World")[#text("https://en.wikipedia.org/wiki/Tarski%27s_World")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/421c1d09702cde925a0633de4ece70927f925ba23f59ce163101305acec8ff08-88817afe06097aa4f59473bd7da1f3fcf58d210d54f1bb5ac3ca9b23b7cfb9a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nazgand")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503437")[#strong[#text("Nazgand")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("8.1(b) should not be provable with less than 3 lines. I am not seeing the notification for matching the shortest known proof.")

#text("EXERCISE 8.1(b) was reproved in 3 lines.")#linebreak()#text(" EXERCISE 8.2 was reproved in 7 lines.")#linebreak()#text(" You matched the record for the shortest known proof!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/421c1d09702cde925a0633de4ece70927f925ba23f59ce163101305acec8ff08-88817afe06097aa4f59473bd7da1f3fcf58d210d54f1bb5ac3ca9b23b7cfb9a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nazgand")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503439")[#strong[#text("Nazgand")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("Perhaps the buttons which would result in circular proofs should be a different color so the player knows that clicking them would not count toward breaking records. Similarly, if the colored buttons are used, the following popup should not appear.")

#text("EXERCISE 8.4(a) was reproved in 3 lines. A new personal best!")

#text("You ")#strong[#text("beat")]#text(" the record for the shortest known proof! If your proof was non-circular (that is, it did not use the current exercise, or any rules obtained subsequently to this exercise), please send it to me at ")#link("mailto:tao@math.ucla.edu")[#text("tao@math.ucla.edu")]#text(" and I will update the record (with an acknowledgment) in the next version of the text.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/421c1d09702cde925a0633de4ece70927f925ba23f59ce163101305acec8ff08-88817afe06097aa4f59473bd7da1f3fcf58d210d54f1bb5ac3ca9b23b7cfb9a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nazgand")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503441")[#strong[#text("Nazgand")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("A IMPLIES (B IMPLIES C). [given]")#linebreak()#text(" Deduce A AND B [assuming A AND B]. [IMPLICATION INTRODUCTION]")#linebreak()#text(" From A IMPLIES (B IMPLIES C): deduce A IMPLIES (B IMPLIES C) [assuming A AND B]. [PUSH]")#linebreak()#text(" From A AND B [assuming A AND B]: deduce A [assuming A AND B]. [CONJUNCTION ELIMINATION (left)]")#linebreak()#text(" From A [assuming A AND B], A IMPLIES (B IMPLIES C) [assuming A AND B]: deduce B IMPLIES C [assuming A AND B]. [MODUS PONENS]")#linebreak()#text(" From A AND B [assuming A AND B]: deduce B [assuming A AND B]. [CONJUNCTION ELIMINATION (right)]")#linebreak()#text(" From B [assuming A AND B], B IMPLIES C [assuming A AND B]: deduce C [assuming A AND B]. [MODUS PONENS]")#linebreak()#text(" From C [assuming A AND B]: deduce (A AND B) IMPLIES C. [DEDUCTION THEOREM]")#linebreak()#text(" QED! (again)")

#text("The shortest non-circular proof I can see for EXERCISE 8.4(a) is the 9 lines above, yet a record of 8 lines is claimed to be the shortest known.")#linebreak()#text(" I thus request an answer key containing a record shortest known proof for each exercise.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503438")[#strong[#text("Gamifying propositional logic: QED, an interactive textbook | Terry Tao - Nevin Manimala's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")]

#text("[…] by /u/tick_tock_clock [link] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503442")[#strong[#text("Gamifying propositional logic: QED, an interactive textbook | Infozonic")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")]

#text("[…] Read More […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb335dd926f0aba67d981d44299918f0bd044cc6672d3ebafdc416dc92930cfa-d00acf4edbcad093e4f09e3a6b963726bb329f03d6a09187f23a19f9f2587ff2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of redblobgames")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503443")[#strong[#text("redblobgames")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("Cool! If you’re looking for any suggestions for styling, I made some minor changes here: ")#link("https://www.redblobgames.com/x/1830-terence-tao-qed-textbook/")[#text("https://www.redblobgames.com/x/1830-terence-tao-qed-textbook/")]#text(" (made locked exercises less bright so that the eye is drawn towards the currently active ones; replaced some borders with box-shadow; set mouse pointer; added mouseover effect; added contrast inside root and formula windows)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503446")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("Thanks for the suggestions and code! This is now implemented in the latest version, together with a feature to view completed proofs in the notification window.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab00358290ca3f655a329ec5d873b89c34b4a6bcf273fce7516e3f7feebd1e49-71f33326c7f7847a9036f8f561b57b711f6304a1bfd0edadc28f087bb64f2246.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian Slesinsky")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503444")[#strong[#text("Brian Slesinsky")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")])]

#text("I noticed that clicking on any hyperlink causes you to lose any work in progress on the current proof when you go back. Perhaps links should open a new tab instead? (Apparently will do this.)")

#text("Also, I noticed that after reloading the page, it remembers which exercises were completed, but not their proofs. (At one point I wanted to go back and look at how I did a previous proof since I had forgotten how I did it.)")

#emph[#text("[The latest version now stores proofs in the notifications window, though you may have to reset the game first to make this feature available, unfortunately, -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503448")[#strong[#text("New top story on Hacker News: Gamifying propositional logic: QED, an interactive textbook – ÇlusterAssets Inc.,")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2018")]

#text("[…] Gamifying propositional logic: QED, an interactive textbook 105 by robinhouston | 7 comments on Hacker News. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1fc5bbdc089d93ce3b2b38c82cfe5e32110dc60426890ba932867faf1ae23e98-7854ffeaeca6f9e5f0bea4419c4e2e2006c86d18496b1b21e0daf075598cc304.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roger Joseph Witte")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503449")[#strong[#text("Roger Joseph Witte")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2018")])]

#text("You need to play with Coq, a logic game for professional homotpists ;)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e497d8e41e70a837fbd853674a8f3e6f53e4e396ffa099a866e9bc6b935a21a-36ef04fca7c112ac96fb0ca02f47e0c55dd78d8e62bfc1e3bd52033d376f0225.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luke")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503450")[#strong[#text("Luke")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2018")])]

#text("After completing Exercise 7.1, it says that I am a Master in propositional logic! Well done, Luke, well done!! ;)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/980a933205b63e465ecf7d0a3274a393f6f75a3c24f570b36f0fc67a23e4670a-f5abbcc682a8c72d1e4ffd09ab43d1f321b266e37d2d8762c340462af6d9b56c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hamish Todd")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503452")[#strong[#text("Hamish Todd")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2018")])]

#text("This is cool! You may be aware that there is a whole community of us making “Explorable explanations” ")#link("http://explorabl.es")[#text("http://explorabl.es")]

#text("One of my favourites, on special relativity, is this one ")#link("https://www.youtube.com/watch?v=RQGa0DPwes0")[#text("https://www.youtube.com/watch?v=RQGa0DPwes0")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4899a6c320808d232367f9ec0ffe97c2d00a4a4b61233af140429f93079fe17e-d2a4ef82c46ab57c3bf97717c348097ef73bb5ec158e701de781d4a6a7fad1b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L Spice")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503455")[#strong[#text("L Spice")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2018")])]

#text("On Mobile Safari (at least on my iPad), dragging one item onto another is frequently dodgy: for exercise 1.1, dragging B onto A would usually just give me “From B, …” rather than “From B and A, …”. (I tried it quite a few times. Once it happened, it would keep happening, but occasionally a refresh fixed it.) It works flawlessly on Desktop Safari, so I’m not sure what could be happening.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4899a6c320808d232367f9ec0ffe97c2d00a4a4b61233af140429f93079fe17e-d2a4ef82c46ab57c3bf97717c348097ef73bb5ec158e701de781d4a6a7fad1b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L Spice")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503457")[#strong[#text("L Spice")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2018")])]

#text("Also, is it possible to abandon a proof in progress (to try a different approach) without resetting the game entirely?")

#emph[#text("[Click on the exercise button again to restart a proof in progress; alternatively, refresh the page. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503458")[#strong[#text("Adriano Arce")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2018")]

#text("Typo in the 5th bullet of Exercise 11.1: “A OR (NOT A)” should instead be “A AND (NOT A)”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503459")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2018")])]

#text("There are a number of user interface issues. There are even people who only study human-computer interaction. Here, perhaps you’d like to make all the exercise tiles the same width? (height is already the same).")

#text("Logic is really good for situations where common sense fails. In a newspaper article, it might be fun to replace the named entities with variables and the various relationships with arrows.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4899a6c320808d232367f9ec0ffe97c2d00a4a4b61233af140429f93079fe17e-d2a4ef82c46ab57c3bf97717c348097ef73bb5ec158e701de781d4a6a7fad1b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L Spice")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503462")[#strong[#text("L Spice")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2018")])]

#text("One more request. Would it be possible to have exercises to which I have found a shortest known solution appear in a different colour from ones for which I have found a, but not a shortest known, solution? (I also amend a previous request. I discovered that clicking again on an exercise will reset the proof; can I *backtrack* in the proof without resetting?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503463")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2018")])]

#text("Some minor feedback from an unintelligent person, if it is of any use to you: Exercise 7.1 states “If a statement is known without an assumption, then it can be “pushed” into an enviroment with that assumption”. However, in order to solve the exercise, you are required to assume A. Perhaps confusion may be avoided if you were to either reword that statement, or to put A in the root environment for this exercise?")

#emph[#text("[Another line of explanation added. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/94b119ca4cc69e81179906465f31bc5b87f9af4b97c1d7374f6748d2dd704368-e8dddf8432bc45860ddd8d154896028c6e96836d226ce972fbbb96f057a24065.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jair")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503476")[#strong[#text("Jair")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2018")])]

#text("This is excellent! I wish I had had a tool like this when I was teaching (or learning) logic.")

#text("– Jair")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503478")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2018")])]

#text("New features for Version 1.4:")

#text("* Exercises now organised by section.")

#text("* “Immediate undo” button that can undo a deduction if it is selected immediately after the deduction was made, and if the deduction did not solve the problem.")

#text("* Exercises that were proven are now either green or blue, depending on whether the shortest known length was attained (or surpassed) or not.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503488")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2018")])]

#text("Version 1.5:")

#text("* Once one completes all the exercises, each exercise will contain a button that one can click on to expand out the shortest known non-circular proof for that exercise. (While coding this, I found out that some of the shortest lengths claimed were not correct; they are now adjusted.)")

#text("* As per Brian’s suggestion, a new exercise (4.2) has been added to give alternate functionality to implication introduction (at least at the root level; to use implication introduction in sub-environments, one still needs to use drag-and-drop).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4899a6c320808d232367f9ec0ffe97c2d00a4a4b61233af140429f93079fe17e-d2a4ef82c46ab57c3bf97717c348097ef73bb5ec158e701de781d4a6a7fad1b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L Spice")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503491")[#strong[#text("L Spice")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2018")])]

#text("Your responsiveness and the rapid evolution are great. The new changes make the whole much improved (and a refresh captures them without requiring to reset QED, too). Thank you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503551")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2018")])]

#text("Version 1.6:")

#text("* Laws that appear in the text at or after a given exercise can still be used in proofs, but have an asterisk next to them, and proofs using such laws do not qualify for shortest length records.")

#text("* New boolean connectives, TRUE and FALSE, and a new section (Section 13) to test out these connectives. Also two more exercises added to Section 9.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503606")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2018")])]

#text("Version 1.7:")

#text("* Dragging is now symmetric: dragging X to Y will also check for laws previously available by dragging Y to X. (As a consequence, though, Exercise 1.1 had to be changed as it was now redundant, and so legacy players may artificially have a world record on this exercise.)")

#text("* Many windows of the game are now collapsed by default.")

#text("* A number of “invisible” code changes in preparation for extension to first-order logic. These should not affect the gameplay thus far, however there is the possibility that some unusual new bugs may have been created by these changes.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503635")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2018")])]

#text("Version 1.8:")

#text("* A “restart exercise” button added (functionally equivalent to clicking on the button of the current exercise again)")

#text("* This change is a bit technical. There are some laws and exercises which do not specify a target environment, so their conclusion is produced by default in the root environment. In those cases, an alternate version of the law has now been added with an additional input of the target environment, in particular allowing for insertion into an arbitrary environment (not just the root) without the need for any additional PUSH type law. For instance, if the law was previously activated by clicking on a formula, it can now also be activated by dragging the formula to an environment. (In some cases there may now be three hypotheses, and the ctrl-click functionality of the previous version would be needed to use this form of the law.) This change will be needed in the upcoming expansion to predicate logic, because there are certain tautologies (involving free variables) which will not be legal sentences in the root environment, but only in sub-environments where certain variables are defined. One consequence of this change is that Exercise 4.2 became completely redundant and has thus been deleted.")

#text("* More “invisible” code changes (basically generalising the notion of an environment, and setting up the constructors etc. for free variables and the like). As usual, please report any new bugs you discover here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503668")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2018")])]

#text("Version 1.9:")

#text("* Environments are now clickable (this is important for laws that involve three or more inputs, one of which is an environment)")

#text("* More hotkeys: “u” for undo, “r” for reset exercise.")

#text("* Bugfixes: bad HTML link repaired, and variants of laws that take an extra environment input are now no longer automatically considered circular to use.")

#text("* Alpha introduction of some predicate logic in Sections 14 and 15 (still very preliminary so far). Ordinarily I would wait until a more complete predicate logic component of the text is fully developed and then releasing a beta version, but given the current level of interest, I’ll try a strategy of adding features incrementally instead and releasing for playtesting. Currently only two components of predicate logic are implemented: free variable environments, and pushing into such environments. More to come…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503681")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2018")])]

#text("Version 1.10:")

#text("* Another alpha section, Section 16, introducing the ability to introduce free variables into an environment by dragging in from a new Term window (which also has a button to create as many free variables as are needed).")

#text("* code.js file split into two smaller files as it was becoming unwieldy (also this may help make the code more modular in the future).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503744")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2018")])]

#text("Version 1.11:")

#text("* Some bugs that led to some deductions not being available have been fixed. However, there may be issues with game states from legacy versions. If a law you are expecting (e.g. conjunction introduction) is still unavailable, try clicking on the relevant exercise that introduces that law (this will be the first exercise in a section). If all else fails, reset the text.")

#text("* Alternate push functionality added: one can push into an assumption by dragging the sentence to a formula containing the assumption, rather than the assumption itself. This saves a step in Exercises 7.1 and 7.2 (and possibly other exercises as well).")

#text("* Alpha version of new section: Section 17, introducing universal quantification and bound variables.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503749")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2018")])]

#text("Version 1.12:")

#text("* Alpha version of new section: Section 18, introducing universal specification and primitive terms, and a couple of exercises.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503750")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2018")])]

#text("Version 1.13:")

#text("* Alpha version of Section 19, introducing the existential quantifier and the law of existential instantiation, which also introduces a new type of subenvironment (where a free variable is set, rather than ranging arbitrarily).")

#text("* Section 10 reorganised with the addition of a new helper exercise (Exercise 10.3) that shortens the proofs of various later exercises involving IFF. Legacy players may have to redo some of the Section 10 material to restore the laws unlocked in this section properly.")

#text("* New hotkeys: ‘n’ for first available unsolved exercise, and ‘N’ for last available unsolved exercise.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503795")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2018")])]

#text("Version 1.14:")

#text("* Deductions resulting in non-well-formed formulas will still be listed, but greyed out and unavailable for selection.")#linebreak()#text(" * New helper exercises in Sections 13, 15 (and some renumbering in Section 13; unfortunately this means that legacy players may have to redo some of these exercises).")#linebreak()#text(" * Main windows of text now organised in a grid layout, as per other comments in this thread.")#linebreak()#text(" * An important omission in the law of universal specification (from FOR ALL ")#mi("X")#text(": ")#mi("P(X)")#text(" and a term ")#mi("\\alpha")#text(", deduce ")#mi("P(\\alpha)")#text(") that I had overlooked has been corrected: it is essential that the term ")#mi("\\alpha")#text(" not contain any bound variables! Otherwise we could have absurdities such as this: starting from the true statement FOR ALL ")#mi("X")#text(": THERE EXISTS ")#mi("Y")#text(": ")#mi("Y = X+1")#text(" in the natural numbers, one could “specify” ")#mi("X")#text(" to equal the term ")#mi("Y")#text(" to conclude the false statement THERE EXISTS ")#mi("Y")#text(": ")#mi("Y = Y+1")#text(".")#linebreak()#text(" * Alpha versions of new sections: 20 and 21. Section 20 introduces a “PULL” law that allows one to pull statements ")#mi("A")#text(" out of “setting ")#mi("x")#text(" s.t. ")#mi("P(x)")#text("” environments (providing that ")#mi("A")#text(" does not depend on ")#mi("x")#text("). Section 21 introduces the “EXISTENCE” law, that asserts that at least one object in the domain of discourse exists (i.e., we are not working in a ")#link("https://en.wikipedia.org/wiki/Free_logic")[#text("free logic")]#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503872")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2018")])]

#text("Version 1.15:")

#text("* Fixed a bug with universal specification.")

#text("* Section and exercise layout has been revamped.")

#text("* Alpha version of Section 22, introducing the law of existential introduction, and a number of exercises including most of the classical syllogisms.")

#text("* some helper exercises added to shorten proofs, but more should be done in this regard. (Many of the exercises in Section 22 are a little tedious right now, in part because most exercises at this point cannot be reused to prove later ones because I have not been able to come up with a good general matching algorithm that covers all cases. Instead, I have been coding matching for the key laws (e.g. existential introduction) by hand.)")

#text("* various technical changes to data structures. Hopefully all bugs caused by this have been squashed, but it is possible that some functionality that was previously correct could be glitchy right now.")

#text("* Experiencing a weird visual bug where occasionally clicking on a button will temporarily blank some screen elements. The bug is sporadic and I have not yet been able to track down the cause (a memory leak?).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503935")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2018")])]

#text("Version 1.16:")

#text("* Alpha version of Section 23, introducing the predicates and operators window that can be used to create compound terms and predicates.")#linebreak()#text(" * Various bug fixes, mostly to do with matching. Some new exercises.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-504004")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2018")])]

#text("Version 1.17:")

#text("* Alpha version of Section 24, introducing the equality relation and the laws of equality.")

#text("At this point I have completed my goal of establishing a deductive system for first-order logic in the form of an interactive text. Pending any final bug fixes etc., I will convert this text to a Version 2.0 and make a new blog post for discussing where to go from here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46e7a76cd66a757d19d9f5af908aaed13cda328d2dc85fc45cb638835f8f0b2a-8f4cfbdf2ec7a89c9d4c76f0eb76619c0bc29a5ea4ff8cf298140822c00bc6f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andre")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503637")[#strong[#text("Andre")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2018")])]

#text("This is a reply to Version 1.8, Firefox 61.0.1, Exercise 7.1 is broken,")#linebreak()#text(" Step 1 create Assume A env")#linebreak()#text(" Step 2 inside Assume A env create B env")#linebreak()#text(" Step 3 (push A down to B) doesn’t work for me")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503654")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2018")])]

#text("Thanks for finding this bug! It was a consequence of some of the “invisible” code changes I had made in which I was generalising the notion of an assumption. I think it’s fixed now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28b3868b80ddac4925ef086ec21dfa6072e21c4b29229fe8b5c3cf3d35e3449b-bfdd190fab8f1a5bcbe14c22cda807b92bd161077c1788a4e461aa77ec67166d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine Deleforge")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503743")[#strong[#text("Antoine Deleforge")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2018")])]

#text("Thanks a lot for this!")

#text("Exercise 14.1 does not work for me. When I try to drag P(x) or Q(x) on the “let x be arbitrary” environment, I only get “No available deductions can be formed from this selection.” I use Chrome on Windows 10. As I started the game on an early version I tried to reset QED and redo the exercises until 14.1, but it didn’t help.")

#emph[#text("[Should hopefully be fixed now, though another reset may possibly be required, or at least clicking again on all the exercises that introduce laws. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28b3868b80ddac4925ef086ec21dfa6072e21c4b29229fe8b5c3cf3d35e3449b-bfdd190fab8f1a5bcbe14c22cda807b92bd161077c1788a4e461aa77ec67166d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine Deleforge")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503756")[#strong[#text("Antoine Deleforge")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2018")])]

#text("Yes, it works now, thanks a lot. I immediately became addicted to this game, and not being able to progress was quite frustrating! I am wondering what will be your next step after 1st order logic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28b3868b80ddac4925ef086ec21dfa6072e21c4b29229fe8b5c3cf3d35e3449b-bfdd190fab8f1a5bcbe14c22cda807b92bd161077c1788a4e461aa77ec67166d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine Deleforge")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503760")[#strong[#text("Antoine Deleforge")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2018")])]

#text("In Exercise 19.1: The hyperlink for “existential quantifier” appears to span 3 lines. Similarly, the last 3 lines of text are in bold.")

#text("A suggestion for Exercise 15.2: introducing “DOUBLE PUSH (for free variables)”, which would be convenient for subsequent exercises.")

#emph[#text("[Now implemented in latest update – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46e7a76cd66a757d19d9f5af908aaed13cda328d2dc85fc45cb638835f8f0b2a-8f4cfbdf2ec7a89c9d4c76f0eb76619c0bc29a5ea4ff8cf298140822c00bc6f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andre")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503876")[#strong[#text("Andre")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2018")])]

#text("This is a reply to Version 1.15, Firefox 61.0.1, Exercise 16.1 is broken")#linebreak()#text(" (having solved all previous exercises in an unreproducible order)")

#text("If I would like to drag the free variable x to the root env, all I get is")#linebreak()#text(" “letting y be arbitrary”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503880")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2018")])]

#text("Thanks for this! This should now be fixed (but you may need to force refresh your web page).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46e7a76cd66a757d19d9f5af908aaed13cda328d2dc85fc45cb638835f8f0b2a-8f4cfbdf2ec7a89c9d4c76f0eb76619c0bc29a5ea4ff8cf298140822c00bc6f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andre")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503894")[#strong[#text("Andre")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2018")])]

#text("This is a reply to Version 1.15.1, Firefox 61.0.1, Exercise 21.1 seems to be broken")

#text("(having solved all of 1-8, 9.1a, 10.1a, 11.1, 12.1a, 13.1a, 14-20)")

#text("So now I see a")#linebreak()#text(" Environment “Set x s.t. TRUE” and inside")#linebreak()#text(" “TRUE”, “FOR ALL X: A”")

#text("if I drag ‘x’ or ‘X’ onto the “FOR ALL X: A” statement, I get both times a “Universal Specification” deduction which isn’t selectable")

#emph[#text("[This bug is fixed as of version 1.15.2. -T]")]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab00358290ca3f655a329ec5d873b89c34b4a6bcf273fce7516e3f7feebd1e49-71f33326c7f7847a9036f8f561b57b711f6304a1bfd0edadc28f087bb64f2246.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian Slesinsky")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503485")[#strong[#text("Brian Slesinsky")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2018")])]

#text("A UI suggestion: after clicking on any formula, show a button to assume that formula at top level. (As an alternative to the drag and drop gesture.)")

#text("This seems better because it seems a bit odd to show a button that says “A and A [assuming A]” but not “A [assuming A]”, which is the more common action?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4899a6c320808d232367f9ec0ffe97c2d00a4a4b61233af140429f93079fe17e-d2a4ef82c46ab57c3bf97717c348097ef73bb5ec158e701de781d4a6a7fad1b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L Spice")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503505")[#strong[#text("L Spice")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2018")])]

#text("For Exercise 9.1(a) in Safari, I proved B OR A [assuming A OR B]. However, if I (1) try to drag A OR B onto B OR A [assuming A OR B] to apply modus ponens, or (2) try to drag B OR A [assuming A OR B] to the root environment (to deduce that (A OR B) IMPLIES (B OR A)), then I am told that no deductions are available from the given selections. This problem survives a refresh (and re-doing the same proof). The same proof in Firefox works fine, so this seems to be a bug.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503509")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2018")])]

#text("When performing (1) or (2), what is listed in the “From” line above the notification that no deductions are available?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4899a6c320808d232367f9ec0ffe97c2d00a4a4b61233af140429f93079fe17e-d2a4ef82c46ab57c3bf97717c348097ef73bb5ec158e701de781d4a6a7fad1b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L Spice")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503548")[#strong[#text("L Spice")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2018")])]

#text("For (1), “From A OR B, B OR A [assuming A OR B]”. For (2), “From B OR A [assuming A OR B], [root environment]”. I took screenshots if it helps, though I can’t imagine how it would. Could this have been caused by my starting with Version 1.3, and then continuing after the update to Version 1.5?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503549")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2018")])]

#text("Sounds like the modus ponens and deduction theorem was lost through the version update (probably because of a slight name change having to do with adding HTML to the name of the law). This should presumably be verifiable through inspection of the Achievements window. You can try clicking on the exercises which supply these laws (6.1(a) and 8.1(a)) which should restore these laws. (If not, then there is always the reset button…)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4899a6c320808d232367f9ec0ffe97c2d00a4a4b61233af140429f93079fe17e-d2a4ef82c46ab57c3bf97717c348097ef73bb5ec158e701de781d4a6a7fad1b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L Spice")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503550")[#strong[#text("L Spice")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2018")])]

#text("I think that my issue was the same as that of @AntonyKarlBartlett. Once I re-solved Exercise 8.1(a), I was able to use MODUS PONENS as expected.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac003c2905e6a4ead51ee2ab7b61266e7a8d899e3ac0cd91ab27faa7c47237ea-006fd46d609e21c2958d33aa5c13d965ae73aa97bac5c7a3ce24c11b3bdb3f30.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antony Karl Bartlett")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503507")[#strong[#text("Antony Karl Bartlett")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2018")])]

#text("Progress is indeed saved between sessions, but upon returning to the latest exercise the tools needed to complete it might not be unlocked (I had to click through all the previous exercises to unlock what I needed for the next exercise).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503508")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2018")])]

#text("I am not able to duplicate this phenomenon (it may have been caused by the text being replaced by a new version between the previous session and the current one). If you can find a reliable way to produce the bug (e.g., by performing a specific sequence of exercises, refreshing, and then noticing that certain rules of inference are missing), please let me know.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d34a6a11e4a20685d3a1062e07452fcd9f71ba58e168a989a8679b3039804761-006fd46d609e21c2958d33aa5c13d965ae73aa97bac5c7a3ce24c11b3bdb3f30.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antony Karl Bartlett")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503510")[#strong[#text("Antony Karl Bartlett")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2018")])]

#text("Yes, probably happened because I was between versions, because I can’t duplicate this phenomenon now either. Thanks.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64d2b7da41942b896cb596ba4239242c344424a9409a0a15045a25e09454002f-6a3622eb73de624bbc03dcb805202cc7a29484176a700ce6e926a7aeb3825137.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Dancstep")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503546")[#strong[#text("Paul Dancstep")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2018")])]

#text("In terms of “gamifying” math learning, the Exploratorium is working on something in a similar spirit for exploring arithmetic:")#linebreak()#text(" ")#link("https://vimeo.com/265259400")[#text("The Digital Abacus")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4899a6c320808d232367f9ec0ffe97c2d00a4a4b61233af140429f93079fe17e-d2a4ef82c46ab57c3bf97717c348097ef73bb5ec158e701de781d4a6a7fad1b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L Spice")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503559")[#strong[#text("L Spice")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("If a rule is proven multiple times, then it appears multiple times whenever applicable. For example, I have proven DOUBLE PUSH twice in an attempt to find the shortest proof; and now, when solving Exercise 8.4(b), I get “From (A AND B) IMPLIES C, [assuming A, B]: DOUBLE PUSH: (A AND B) IMPLIES C [assuming A, B]; DOUBLE PUSH: (A AND B) IMPLIES C [assuming A, B]”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/comment-page-1/#comment-503566")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("Duplicate unlocking of laws has now been prevented in the latest version, thanks for pointing out the issue.")
]
]
