// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/12/17/the-mesoscopic-structure-of-gue-eigenvalues/
// Converted to Typst by tao2typ: "2026-10-14T15:17:58.573600+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The mesoscopic structure of GUE eigenvalues", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The mesoscopic structure of GUE eigenvalues")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 December 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/12/17/the-mesoscopic-structure-of-gue-eigenvalues/")[#text("https://terrytao.wordpress.com/2010/12/17/the-mesoscopic-structure-of-gue-eigenvalues/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This week I am at the ")#link("http://www.aimath.org/")[#text("American Institute of Mathematics")]#text(", as an organiser on a ")#link("http://www.aimath.org/ARCC/workshops/randommatrices.html")[#text("workshop on the universality phenomenon in random matrices")]#text(". There have been a number of interesting discussions so far in this workshop. ")#link("http://en.wikipedia.org/wiki/Percy_Deift")[#text("Percy Deift")]#text(", in a lecture on universality for invariant ensembles, gave some applications of what he only half-jokingly termed “the most important identity in mathematics”, namely the formula")

#align(center)[#tao-fit-display[#mitex("\\text{det}( 1 + AB ) = \\text{det}(1 + BA)")]]

#text("whenever ")#mi("{A, B}")#text(" are ")#mi("{n \\times k}")#text(" and ")#mi("{k \\times n}")#text(" matrices respectively (or more generally, ")#mi("{A}")#text(" and ")#mi("{B}")#text(" could be linear operators with sufficiently good spectral properties that make both sides equal). Note that the left-hand side is an ")#mi("{n \\times n}")#text(" determinant, while the right-hand side is a ")#mi("{k \\times k}")#text(" determinant; this formula is particularly useful when computing determinants of large matrices (or of operators), as one can often use it to transform such determinants into much smaller determinants. In particular, the asymptotic behaviour of ")#mi("{n \\times n}")#text(" determinants as ")#mi("{n \\rightarrow \\infty}")#text(" can be converted via this formula to determinants of a fixed size (independent of ")#mi("{n}")#text("), which is often a more favourable situation to analyse. Unsurprisingly, this trick is particularly useful for understanding the asymptotic behaviour of ")#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/")[#text("determinantal processes")]#text(".")

#text("There are many ways to prove the identity. One is to observe first that when ")#mi("{A, B}")#text(" are invertible square matrices of the same size, that ")#mi("{1+BA}")#text(" and ")#mi("{1+AB}")#text(" are conjugate to each other and thus clearly have the same determinant; a density argument then removes the invertibility hypothesis, and a padding-by-zeroes argument then extends the square case to the rectangular case. Another is to proceed via the spectral theorem, noting that ")#mi("{AB}")#text(" and ")#mi("{BA}")#text(" have the same non-zero eigenvalues.")

#text("By rescaling, one obtains the variant identity")

#align(center)[#tao-fit-display[#mitex("\\text{det}( z + AB ) = z^{n-k} \\text{det}(z + BA)")]]

#text("which essentially relates the characteristic polynomial of ")#mi("{AB}")#text(" with that of ")#mi("{BA}")#text(". When ")#mi("{n=k}")#text(", a comparison of coefficients this already gives important basic identities such as ")#mi("{\\text{tr}(AB) = \\text{tr}(BA)}")#text(" and ")#mi("{\\text{det}(AB) = \\text{det}(BA)}")#text("; when ")#mi("{n}")#text(" is not equal to ")#mi("{k}")#text(", an inspection of the ")#mi("{z^{n-k}}")#text(" coefficient similarly gives the ")#link("http://en.wikipedia.org/wiki/Cauchy%E2%80%93Binet_formula")[#text("Cauchy-Binet formula")]#text(" (which, incidentally, is also useful when performing computations on determinantal processes).")

#text("Thanks to this formula (and with a crucial insight of ")#link("http://www.umpa.ens-lyon.fr/~aguionne/")[#text("Alice Guionnet")]#text("), I was able to solve a problem (on outliers for the circular law) that I had in the back of my mind for a few months, and initially posed to me by ")#link("http://neurotheory.columbia.edu/~larry/")[#text("Larry Abbott")]#text("; I hope to talk more about this in a future post.")

#text("Today, though, I wish to talk about another piece of mathematics that emerged from an afternoon of free-form discussion that we managed to schedule within the AIM workshop. Specifically, we hammered out a heuristic model of the ")#emph[#text("mesoscopic")]#text(" structure of the eigenvalues ")#mi("{\\lambda_1 \\leq \\ldots \\leq \\lambda_n}")#text(" of the ")#mi("{n \\times n}")#text(" ")#link("http://en.wikipedia.org/wiki/Gaussian_unitary_ensemble")[#text("Gaussian Unitary Ensemble")]#text(" (GUE), where ")#mi("{n}")#text(" is a large integer. As is well known, the probability density of these eigenvalues is given by the ")#emph[#text("Ginebre distribution")]

#align(center)[#tao-fit-display[#mitex("\\frac{1}{Z_n} e^{-H(\\lambda)}\\ d\\lambda")]]

#text("where ")#mi("{d\\lambda = d\\lambda_1 \\ldots d\\lambda_n}")#text(" is Lebesgue measure on the Weyl chamber ")#mi("{\\{ (\\lambda_1,\\ldots,\\lambda_n) \\in {\\bf R}^n: \\lambda_1 \\leq \\ldots \\leq \\lambda_n \\}}")#text(", ")#mi("{Z_n}")#text(" is a constant, and the Hamiltonian ")#mi("{H}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#tao-math("H(\\lambda_1,\\ldots,\\lambda_n) := \\sum_{j=1}^n \\frac{\\lambda_j^2}{2} - 2 \\sum_{1 \\leq i < j \\leq n} \\log \\left|\\lambda_i-\\lambda_j\\right|.", block: true)]]

#text("At the macroscopic scale of ")#mi("{\\sqrt{n}}")#text(", the eigenvalues ")#mi("{\\lambda_j}")#text(" are distributed according to the ")#link("http://en.wikipedia.org/wiki/Wigner_semicircle_distribution")[#text("Wigner semicircle law")]

#align(center)[#tao-fit-display[#mitex("\\rho_{sc}(x) := \\frac{1}{2\\pi} (4-x^2)_+^{1/2}.")]]

#text("Indeed, if one defines the ")#emph[#text("classical location")]#text(" ")#mi("{\\gamma_i^{cl}}")#text(" of the ")#mi("{i^{th}}")#text(" eigenvalue to be the unique solution in ")#mi("{[-2\\sqrt{n}, 2\\sqrt{n}]}")#text(" to the equation")

#align(center)[#tao-fit-display[#mitex("\\int_{-2\\sqrt{n}}^{\\gamma_i^{cl}/\\sqrt{n}} \\rho_{sc}(x)\\ dx = \\frac{i}{n}")]]

#text("then it is known that the random variable ")#mi("{\\lambda_i}")#text(" is quite close to ")#mi("{\\gamma_i^{cl}}")#text(". Indeed, a ")#link("http://www.ams.org/mathscinet-getitem?mr=2124079")[#text("result of Gustavsson")]#text(" shows that, in the bulk region when ")#mi("{\\epsilon n < i  0}")#text(", ")#mi("{\\lambda_i}")#text(" is distributed asymptotically as a gaussian random variable with mean ")#mi("{\\gamma_i^{cl}}")#text(" and variance ")#mi("{\\sqrt{\\frac{\\log n}{\\pi}} \\times \\frac{1}{\\sqrt{n} \\rho_{sc}(\\gamma_i^{cl})}}")#text(". Note that from the semicircular law, the factor ")#mi("{\\frac{1}{\\sqrt{n} \\rho_{sc}(\\gamma_i^{cl})}}")#text(" is the mean eigenvalue spacing.")

#text("At the other extreme, at the microscopic scale of the mean eigenvalue spacing (which is comparable to ")#mi("{1/\\sqrt{n}}")#text(" in the bulk, but can be as large as ")#mi("{n^{-1/6}}")#text(" at the edge), the eigenvalues are asymptotically distributed with respect to a special determinantal point process, namely the Dyson sine process in the bulk (and the Airy process on the edge), as discussed in this ")#link("https://terrytao.wordpress.com/2010/10/23/the-dyson-and-airy-kernels-of-gue-via-semiclassical-analysis/")[#text("previous post")]#text(".")

#text("Here, I wish to discuss the ")#emph[#text("mesoscopic")]#text(" structure of the eigenvalues, in which one involves scales that are intermediate between the microscopic scale ")#mi("{1/\\sqrt{n}}")#text(" and the macroscopic scale ")#mi("{\\sqrt{n}}")#text(", for instance in correlating the eigenvalues ")#mi("{\\lambda_i}")#text(" and ")#mi("{\\lambda_j}")#text(" in the regime ")#tao-math("{\\left|i-j\\right| \\sim n^\\theta}", block: false)#text(" for some ")#mi("{0 < \\theta < 1}")#text(". Here, there is a surprising phenomenon; there is quite a long-range correlation between such eigenvalues. The result of Gustavsson shows that both ")#mi("{\\lambda_i}")#text(" and ")#mi("{\\lambda_j}")#text(" behave asymptotically like gaussian random variables, but a further result from the same paper shows that the correlation between these two random variables is asymptotic to ")#mi("{1-\\theta}")#text(" (in the bulk, at least); thus, for instance, adjacent eigenvalues ")#mi("{\\lambda_{i+1}}")#text(" and ")#mi("{\\lambda_i}")#text(" are almost perfectly correlated (which makes sense, as their spacing is much less than either of their standard deviations), but that even very distant eigenvalues, such as ")#mi("{\\lambda_{n/4}}")#text(" and ")#mi("{\\lambda_{3n/4}}")#text(", have a correlation comparable to ")#mi("{1/\\log n}")#text(". One way to get a sense of this is to look at the trace")

#align(center)[#tao-fit-display[#mitex("\\lambda_1 + \\ldots + \\lambda_n.")]]

#text("This is also the sum of the diagonal entries of a GUE matrix, and is thus normally distributed with a variance of ")#mi("{n}")#text(". In contrast, each of the ")#mi("{\\lambda_i}")#text(" (in the bulk, at least) has a variance comparable to ")#mi("{\\log n/n}")#text(". In order for these two facts to be consistent, the average correlation between pairs of eigenvalues then has to be of the order of ")#mi("{1/\\log n}")#text(".")

#text("Below the fold, I give a heuristic way to see this correlation, based on Taylor expansion of the convex Hamiltonian ")#mi("{H(\\lambda)}")#text(" around the minimum ")#mi("{\\gamma}")#text(", which gives a conceptual probabilistic model for the mesoscopic structure of the GUE eigenvalues. While this heuristic is in no way rigorous, it does seem to explain many of the features currently known or conjectured about GUE, and looks likely to extend also to other models.")

#metadata(none) <tao-b30d7193866e086485d1>

#heading(level: 1)[#strong[#text(" — 1. Fekete points — ")]]

#text("It is easy to see that the Hamiltonian ")#mi("{H(\\lambda)}")#text(" is convex in the Weyl chamber, and goes to infinity on the boundary of this chamber, so it must have a unique minimum, at a set of points ")#mi("{\\gamma = (\\gamma_1,\\ldots,\\gamma_n)}")#text(" known as the ")#emph[#text("Fekete points")]#text(". At the minimum, we have ")#mi("{\\nabla H(\\gamma) = 0}")#text(", which expands to become the set of conditions ")#metadata(none) <tao-e00443c76cfe2be97aa8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\gamma_j - 2 \\sum_{i \\neq j} \\frac{1}{\\gamma_j - \\gamma_i} = 0")]]

#text("for all ")#mi("{1 \\leq j \\leq n}")#text(". To solve these conditions, we introduce the monic degree ")#mi("{n}")#text(" polynomial")

#align(center)[#tao-fit-display[#mitex("P(x) := \\prod_{i=1}^n (x-\\gamma_i).")]]

#text("Differentiating this polynomial, we observe that ")#metadata(none) <tao-6ee2cc105a67743140cf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("P^{\\prime}(x) = P(x) \\sum_{i=1}^n \\frac{1}{x-\\gamma_i}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("P^{\\prime\\prime}(x) = P(x) \\sum_{1 \\leq i,j \\leq n: i \\neq j} \\frac{1}{x-\\gamma_i} \\frac{1}{x-\\gamma_j}.")]]

#text("Using the identity")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x-\\gamma_i} \\frac{1}{x-\\gamma_j} = \\frac{1}{x-\\gamma_i} \\frac{1}{\\gamma_i-\\gamma_j} + \\frac{1}{x-\\gamma_j} \\frac{1}{\\gamma_j-\\gamma_i}")]]

#text("followed by ")#link(<tao-e00443c76cfe2be97aa8>)[#text("(1)")]#text(", we can rearrange this as")

#align(center)[#tao-fit-display[#mitex("P^{\\prime\\prime}(x) = P(x) \\sum_{1 \\leq i \\leq n: i \\neq j} \\frac{\\gamma_i}{x-\\gamma_i}.")]]

#text("Comparing this with ")#link(<tao-6ee2cc105a67743140cf>)[#text("(2)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("P^{\\prime\\prime}(x) = x P^{\\prime}(x) - n P(x),")]]

#text("or in other words that ")#mi("{P}")#text(" is the ")#mi("{n^{th}}")#text(" ")#link("http://en.wikipedia.org/wiki/Hermite_polynomial")[#text("Hermite polyomial")]

#align(center)[#tao-fit-display[#mitex("P(x) = H_n(x) := (-1)^n e^{x^2/2} \\frac{d}{dx^2} e^{-x^2/2}.")]]

#text("Thus the Fekete points ")#mi("{\\gamma_i}")#text(" are nothing more than the zeroes of the ")#mi("{n^{th}}")#text(" Hermite polynomial.")

#text("Heuristically, one can study these zeroes by looking at the function")

#align(center)[#tao-fit-display[#mitex("\\phi(x) := P(x) e^{-x^2/4}")]]

#text("which solves the eigenfunction equation")

#align(center)[#tao-fit-display[#mitex("\\phi^{\\prime\\prime}(x) + (n - \\frac{x^2}{4}) \\phi(x) = 0.")]]

#text("Comparing this equation with the harmonic oscillator equation ")#mi("{\\phi^{\\prime\\prime}(x) + k^2 \\phi(x) = 0}")#text(", which has plane wave solutions ")#mi("{\\phi(x) = A \\cos(kx+\\theta)}")#text(" for ")#mi("{k^2}")#text(" positive and exponentially decaying solutions for ")#mi("{k^2}")#text(" negative, we are led (heuristically, at least) to conclude that ")#mi("{\\phi}")#text(" is concentrated in the region where ")#mi("{n-\\frac{x^2}{4}}")#text(" is positive (i.e. inside the interval ")#mi("{[-2\\sqrt{n},2\\sqrt{n}]}")#text(") and will oscillate at frequency roughly ")#mi("{\\sqrt{n-\\frac{x^2}{4}}}")#text(" inside this region. As such, we expect the Fekete points ")#mi("{\\gamma_i}")#text(" to obey the same spacing law as the classical locations ")#mi("{\\gamma_i^{sc}}")#text("; indeed it is possible to show that ")#mi("{\\gamma_i = \\gamma_i^{sc} + O(1/\\sqrt{n})}")#text(" in the bulk (with some standard modifications at the edge). In particular, we have the heuristic ")#metadata(none) <tao-d95d5d9a4237845e5bae>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\gamma_i - \\gamma_j \\approx (i-j)/\\sqrt{n}")]]

#text("for ")#mi("{i,j}")#text(" in the bulk.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" If one works with the ")#link("http://en.wikipedia.org/wiki/Circular_ensemble")[#text("circular unitary ensemble")]#text(" (CUE) instead of the GUE, the Fekete points become equally spaced around the unit circle, so that this heuristic essentially becomes exact.")
]

#heading(level: 1)[#strong[#text(" — 2. Taylor expansion — ")]]

#text("Now we expand around the Fekete points by making the ansatz")

#align(center)[#tao-fit-display[#mitex("\\lambda_i = \\gamma_i + x_i,")]]

#text("thus Gustavsson’s result predicts that each ")#mi("{x_i}")#text(" is normally distributed with standard deviation ")#mi("{O(\\sqrt{\\log n}/\\sqrt{n})}")#text(" (in the bulk). We Taylor expand")

#align(center)[#tao-fit-display[#mitex("H(\\lambda) = H(\\gamma) + \\nabla H(\\gamma)(x) + \\frac{1}{2} \\nabla^2 H(\\gamma)(x,x) + \\ldots.")]]

#text("We heuristically drop the cubic and higher order terms. The constant term ")#mi("{H(\\gamma)}")#text(" can be absorbed into the partition constant ")#mi("{Z_n}")#text(", while the linear term vanishes by the property ")#mi("{\\nabla H(\\gamma)}")#text(" of the Fekete points. We are thus lead to a quadratic (i.e. gaussian) model")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{Z^{\\prime}_n} e^{-\\frac{1}{2} \\nabla^2 H(\\gamma)(x,x)}\\ dx")]]

#text("for the probability distribution of the shifts ")#mi("{x_i}")#text(", where ")#mi("{Z^{\\prime}_n}")#text(" is the appropriate normalisation constant.")

#text("Direct computation allows us to expand the quadratic form ")#mi("{\\frac{1}{2} \\nabla^2 H(\\gamma)}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} \\nabla^2 H(\\gamma)(x,x) = \\sum_{j=1}^n \\frac{x_j^2}{2} + \\sum_{1 \\leq i < j \\leq n} \\frac{(x_i-x_j)^2}{(\\gamma_i - \\gamma_j)^2}.")]]

#text("The Taylor expansion is not particularly accurate when ")#mi("{j}")#text(" and ")#mi("{i}")#text(" are too close, say ")#mi("{j=i+O(\\log^{O(1)} n)}")#text(", but we will ignore this issue as it should only affect the microscopic behaviour rather than the mesoscopic behaviour. This models the ")#mi("{x_i}")#text(" as (coupled) gaussian random variables whose covariance matrix can in principle be explicitly computed by inverting the matrix of the quadratic form. Instead of doing this precisely, we shall instead work heuristically (and somewhat inaccurately) by re-expressing the quadratic form in the Haar basis. For simplicity, let us assume that ")#mi("{n}")#text(" is a power of ")#mi("{2}")#text(". Then the Haar basis consists of the basis vector")

#align(center)[#tao-fit-display[#mitex("\\psi_0 := \\frac{1}{\\sqrt{n}} (1,\\ldots,1)")]]

#text("together with the basis vectors")

#align(center)[#tao-fit-display[#tao-math("\\psi_I := \\frac{1}{\\sqrt{\\left|I\\right|}} ( 1_{I_l} - 1_{I_r} )", block: true)]]

#text("for every discrete dyadic interval ")#mi("{I \\subset \\{1,\\ldots,n\\}}")#text(" of length between ")#mi("{2}")#text(" and ")#mi("{n}")#text(", where ")#mi("{I_l}")#text(" and ")#mi("{I_r}")#text(" are the left and right halves of ")#mi("{I}")#text(", and ")#mi("{1_{I_l}}")#text(", ")#mi("{1_{I_r} \\in {\\bf R}^n}")#text(" are the vectors that are one on ")#mi("{I_l, I_r}")#text(" respectively and zero elsewhere. These form an orthonormal basis of ")#mi("{{\\bf R}^n}")#text(", thus we can write")

#align(center)[#tao-fit-display[#mitex("x = \\xi_0 \\psi_0 + \\sum_I \\xi_I \\psi_I")]]

#text("for some coefficients ")#mi("{\\xi_0, \\xi_I}")#text(".")

#text("From orthonormality we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^n x_j^2 = \\xi_0^2 + \\sum_I \\xi_I^2")]]

#text("and we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq i < j \\leq n} \\frac{(x_i-x_j)^2}{(\\gamma_i - \\gamma_j)^2} = \\sum_{I, J} \\xi_I \\xi_J c_{I,J}")]]

#text("where the matrix coefficients ")#mi("{c_{I,J}}")#text(" are given by")

#align(center)[#tao-fit-display[#mitex("c_{I,J} := \\sum_{1 \\leq i < j \\leq n} \\frac{(\\psi_I(i) - \\psi_I(j))(\\psi_J(i) - \\psi_J(j))}{(\\gamma_i - \\gamma_j)^2}.")]]

#text("A standard heuristic wavelet computation using ")#link(<tao-d95d5d9a4237845e5bae>)[#text("(3)")]#text(" suggests that ")#mi("{c_{I,J}}")#text(" is small unless ")#mi("{I}")#text(" and ")#mi("{J}")#text(" are actually equal, in which case one has")

#align(center)[#tao-fit-display[#tao-math("c_{I,I} \\sim \\frac{n}{\\left|I\\right|}", block: true)]]

#text("(in the bulk, at least). Actually, the decay of the ")#mi("{c_{I,J}}")#text(" away from the diagonal ")#mi("{I=J}")#text(" is not so large, because the Haar wavelets ")#mi("{\\psi_I}")#text(" have poor moment and regularity properties. But one could in principle use much smoother and much more balanced wavelets, in which case the decay should be much faster.")

#text("This suggests that the GUE distribution could be modeled by the distribution ")#metadata(none) <tao-d36eecdc5cdd81f0bc08>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\frac{1}{Z^{\\prime}_n} e^{-\\xi_0^2/2} e^{- C \\sum_I \\frac{n}{\\left|I\\right|} \\xi_I^2} d\\xi", block: true)]]

#text("for some absolute constant ")#mi("{C}")#text("; thus we may model ")#mi("{\\xi_0 \\equiv N(0,1)}")#text(" and ")#tao-math("{\\xi_I \\equiv C^{\\prime} \\sqrt{\\left|I\\right|}{\\sqrt{n}} g_I}", block: false)#text(" for some iid gaussians ")#mi("{g_I \\equiv N(0,1)}")#text(" independent of ")#mi("{\\xi_0}")#text(". We then have as a model")

#align(center)[#tao-fit-display[#mitex("x_i = \\frac{\\xi_0}{\\sqrt{n}} + \\frac{C^{\\prime}}{\\sqrt{n}} \\sum_I (1_{I_l}(i) - 1_{I_r}(i)) g_I")]]

#text("for the fluctuations of the eigenvalues (in the bulk, at least), leading of course to the model ")#metadata(none) <tao-28a16ec8581aa01a9674>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\lambda_i = \\gamma_i + \\frac{\\xi_0}{\\sqrt{n}} + \\frac{C^{\\prime}}{\\sqrt{n}} \\sum_I (1_{I_l}(i) - 1_{I_r}(i)) g_I")]]

#text("for the fluctuations themselves. This model does not capture the microscopic behaviour of the eigenvalues such as the sine kernel (indeed, as noted before, the contribution of the very short ")#mi("{I}")#text(" (which corresponds to very small values of ")#tao-math("{\\left|j-i\\right|}", block: false)#text(") is inaccurate), but appears to be a good model to describe the mesoscopic behaviour. For instance, observe that for each ")#mi("{i}")#text(" there are ")#mi("{\\sim \\log n}")#text(" independent normalised gaussians in the above sum, and so this model is consistent with the result of Gustavsson that each ")#mi("{\\lambda_i}")#text(" is gaussian with standard deviation ")#mi("{\\sim \\frac{\\sqrt{\\log n}}{\\sqrt{n}}}")#text(". Also, if ")#tao-math("{\\left|i-j\\right| \\sim n^\\theta}", block: false)#text(", then the expansions ")#link(<tao-28a16ec8581aa01a9674>)[#text("(5)")]#text(" of ")#mi("{\\lambda_i, \\lambda_j}")#text(" share about ")#mi("{(1-\\theta) \\log n}")#text(" of the ")#mi("{\\log n}")#text(" terms in the sum in common, which is consistent with the further result of Gustavsson that the correlation between such eigenvalues is comparable to ")#mi("{1-\\theta}")#text(".")

#text("If one looks at the gap ")#mi("{\\lambda_{i+1}-\\lambda_i}")#text(" using ")#link(<tao-28a16ec8581aa01a9674>)[#text("(5)")]#text(" (and replacing the Haar cutoff ")#mi("{1_{I_l}(i) - 1_{I_r}(i)}")#text(" by something smoother for the purposes of computing the gap), one is led to a heuristic of the form")

#align(center)[#tao-fit-display[#tao-math("\\lambda_{i+1}-\\lambda_i = \\frac{1}{\\rho_{sc}(\\gamma_i/\\sqrt{n})} \\frac{1}{\\sqrt{n}} + \\frac{C^{\\prime}}{\\sqrt{n}} \\sum_I (1_{I_l}(i) - 1_{I_r}(i)) \\frac{g_I}{\\left|I\\right|}.", block: true)]]

#text("The dominant terms here are the first term and the contribution of the very short intervals ")#mi("{I}")#text(". At present, this model cannot be accurate, because it predicts that the gap can sometimes be negative; the contribution of the very short intervals must instead be replaced some other model that gives sine process behaviour, but we do not know of an easy way to set up a plausible such model.")

#text("On the other hand, the model suggests that the gaps are largely decoupled from each other, and have gaussian tails. Standard heuristics then suggest that of the ")#mi("{\\sim n}")#text(" gaps in the bulk, the largest one should be comparable to ")#mi("{\\sqrt{\\frac{\\log n}{n}}}")#text(", which was indeed established recently ")#link("http://arxiv.org/abs/1010.1294")[#text("by Ben Arous and Bourgarde")]#text(".")

#text("Given any probability measure ")#mi("{\\mu = \\rho\\ dx}")#text(" on ")#mi("{{\\bf R}^n}")#text(" (or on the Weyl chamber) with a smooth nonzero density, one can can create an associated heat flow on other smooth probability measures ")#mi("{f\\ dx}")#text(" by performing gradient flow with respect to the Dirichlet form")

#align(center)[#tao-fit-display[#tao-math("D(f\\ dx) := \\frac{1}{2} \\int_{{\\bf R}^n} \\left|\\nabla \\frac{f}{\\rho}\\right|^2\\ d\\mu.", block: true)]]

#text("Using the ansatz ")#link(<tao-d36eecdc5cdd81f0bc08>)[#text("(4)")]#text(", this flow decouples into a system of independent Ornstein-Uhlenbeck processes")

#align(center)[#tao-fit-display[#mitex("d\\xi_0 = - \\xi_0 dt + dW_0")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("d g_I = C^{\\prime\\prime} \\frac{n}{\\left|I\\right|} ( - g_I dt + dW_I )", block: true)]]

#text("where ")#mi("{dW_0, dW_I}")#text(" are independent Wiener processes (i.e. Brownian motion). This is a toy model for the Dyson Brownian motion. In this model, we see that the mixing time for each ")#mi("{g_I}")#text(" is ")#tao-math("{O(\\left|I\\right|/n)}", block: false)#text("; thus, the large-scale variables (")#mi("{g_I}")#text(" for large ")#mi("{I}")#text(") evolve very slowly by Dyson Brownian motion, taking as long as ")#mi("{O(1)}")#text(" to reach equilibrium, while the fine scale modes (")#mi("{g_I}")#text(" for small ")#mi("{I}")#text(") can achieve equilibrium in as brief a time as ")#mi("{O(1/n)}")#text(", with the intermediate modes taking an intermediate amount of time to reach equilibrium. It is precisely this picture that underlies the Erdos-Schlein-Yau approach to universality for Wigner matrices via the local equilibrium flow, in which the measure ")#link(<tao-d36eecdc5cdd81f0bc08>)[#text("(4)")]#text(" is given an additional (artificial) weight, roughly of the shape ")#mi("{e^{- n^{1-\\epsilon} (\\xi_0^2 + \\sum_I \\xi_I^2)}}")#text(", in order to make equilibrium achieved globally in just time ")#mi("{O(n^{1-\\epsilon})}")#text(", leading to a local log-Sobolev type inequality that ensures convergence of the local statistics once one controls a Dirichlet form connected to the local equilibrium measure; and then one can use the localisation of eigenvalues provided by a local semicircle law to control that Dirichlet form in turn for measures that have undergone Dyson Brownian motion.")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/12/17/the-mesoscopic-structure-of-gue-eigenvalues/#comment-48994")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2010")])]

#text("Shouldn’t the identity matrix be “I” instead of “1”?")

#emph[#text("[Either notation is appropriate. In the modern abstract algebra, the multiplicative identity of any ring is often denoted 1, for much the same reason that the additive identity is often denoted 0. -T] ")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2d4ab3bc48f38053d5bed6cb8509c92f142fb196f5df472c263109a8a6e77f7-6a5be68c477a5be6586b62f07fa83c3f9ed2c1a1f363e39f316e0d181b8044c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marek")]], [#link("https://terrytao.wordpress.com/2010/12/17/the-mesoscopic-structure-of-gue-eigenvalues/#comment-49003")[#strong[#text("Marek")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2010")])]

#text("The equation for the harmonic oscillator is missing a sign.")

#emph[#text("[Corrected, thanks -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/12/17/the-mesoscopic-structure-of-gue-eigenvalues/#comment-49098")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2010")])]

#text("Is there a website for this workshop")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9523766cab66f2ba4ce9690d1c51bdfe7ec677c6b12a034fea6bce1e97b66c0-4113eeef07dc6fc5be73379718349704654c10c8e33a8886776c026cdd7d5f93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Golub")]], [#link("https://terrytao.wordpress.com/2010/12/17/the-mesoscopic-structure-of-gue-eigenvalues/#comment-49143")[#strong[#text("Ben Golub")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2010")])]

#text("“namely the Dyson sine process in the bulk (and the Airy process on the edge), as discussed in this previous post” is missing a link")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9523766cab66f2ba4ce9690d1c51bdfe7ec677c6b12a034fea6bce1e97b66c0-4113eeef07dc6fc5be73379718349704654c10c8e33a8886776c026cdd7d5f93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Golub")]], [#link("https://terrytao.wordpress.com/2010/12/17/the-mesoscopic-structure-of-gue-eigenvalues/#comment-49146")[#strong[#text("Ben Golub")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2010")])]

#text("Sorry for posting twice, but there is one more possible typo and a question")

#text("On the line following")

#text("“From orthonormality we have”, it seems the upper bound of the summation should be n.")

#text("after “A standard heuristic wavelet computation”: it seems that naively plugging in $I=J$ in the summation defining $c_{I,J}$ makes the expression $(\\psi_I – \\psi_J)^2$ equal to $0$ (interpreting squaring as taking the dot product of the vector with itself). It seems I am missing something simple — any help would be appreciated.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/12/17/the-mesoscopic-structure-of-gue-eigenvalues/#comment-49592")[#strong[#text("The 3rd lecture in 2011 Spring « Y.-K. Lau's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2011")]

#text("[…] was drawn attention to (1) by an article in Tao’s blog. A proof (different from ours) is given there. Professor Terence Tao is a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4cad1a010f9380dd14085fa79297dd91592711193635d6c1195123a5b6cb13a-e91bc3c6aaf9cd87d2bab820ff083bc3a607f5e5838479c7bafa19dd1c4bd887.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Subsynchronous Resonance in Power Systems | BUKU PDF")]], [#link("https://terrytao.wordpress.com/2010/12/17/the-mesoscopic-structure-of-gue-eigenvalues/#comment-50052")[#strong[#text("Subsynchronous Resonance in Power Systems | BUKU PDF")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2011")])]

#text("[…] The mesoscopic structure of GUE eigenvalues (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Topics in random matrix theory « What’s new")]], [#link("https://terrytao.wordpress.com/2010/12/17/the-mesoscopic-structure-of-gue-eigenvalues/#comment-50424")[#strong[#text("Topics in random matrix theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2011")])]

#text("[…] which was based primarily on my graduate course in the topic, though it also contains material from some additional posts related to random matrices on the blog. It is available online here. As usual, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0671028695df12570b85a13a89a7c69cc72f386f749196ab56a7db3314f0b26-833881ac4a66553b60e4bd9be52437f821ebebd02c75da2691247c0cb10f64c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Djalil")]], [#link("https://terrytao.wordpress.com/2010/12/17/the-mesoscopic-structure-of-gue-eigenvalues/#comment-53633")[#strong[#text("Djalil")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2011")])]

#text("It seems that the det(1+AB)=det(1+BA) identity is attributed to Sylvester: ")#link("http://en.wikipedia.org/wiki/Sylvester%27s_determinant_theorem")[#text("http://en.wikipedia.org/wiki/Sylvester%27s_determinant_theorem")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matrix identities as derivatives of determinant identities « What’s new")]], [#link("https://terrytao.wordpress.com/2010/12/17/the-mesoscopic-structure-of-gue-eigenvalues/#comment-213089")[#strong[#text("Matrix identities as derivatives of determinant identities « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2013")])]

#text("[…] which relates an determinant with an determinant, is very useful in random matrix theory (a point emphasised in particular by Deift), particularly in regimes in which is much smaller than […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miklós Kornyik")]], [#link("https://terrytao.wordpress.com/2010/12/17/the-mesoscopic-structure-of-gue-eigenvalues/#comment-474505")[#strong[#text("Miklós Kornyik")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2016")])]

#text("After inroducing the orthonormal Haar basis you write that sum_j x_j^2/2 = sum_k xi_k^2. Where does the 1/2 come from? Shouldn’t it be just sum_j x_j^2 = sum_k xi_k^2 ?")

#emph[#text("[Corrected, thanks – T.]")]
]
