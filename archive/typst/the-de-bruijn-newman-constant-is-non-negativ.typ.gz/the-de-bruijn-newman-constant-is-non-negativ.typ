// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/
// Converted to Typst by tao2typ: "2026-10-14T16:38:15.850984+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The De Bruijn-Newman constant is non-negative", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The De Bruijn-Newman constant is non-negative")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 January 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/")[#text("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www-personal.umich.edu/~rbrad/")[#text("Brad Rodgers")]#text(" and I have uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/1801.05914")[#text("The De Bruijn-Newman constant is non-negative")]#text("“. This paper affirms a conjecture of Newman regarding to the extent to which the Riemann hypothesis, if true, is only “barely so”. To describe the conjecture, let us begin with the ")#link("https://en.wikipedia.org/wiki/Riemann_Xi_function")[#text("Riemann xi function")]

#align(center)[#tao-fit-display[#mitex("\\xi(s) := \\frac{s(s-1)}{2} \\pi^{-s/2} \\Gamma(\\frac{s}{2}) \\zeta(s)")]]

#text("where ")#mi("{\\Gamma(s) := \\int_0^\\infty e^{-t} t^{s-1}\\ dt}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Gamma_function")[#text("Gamma function")]#text(" and ")#mi("{\\zeta(s) := \\sum_{n=1}^\\infty \\frac{1}{n^s}}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Riemann_zeta_function")[#text("Riemann zeta function")]#text(". Initially, this function is only defined for ")#mi("{\\mathrm{Re} s > 1}")#text(", but, as was already known to Riemann, we can manipulate it into a form that extends to the entire complex plane as follows. Firstly, in view of the standard identity ")#mi("{s \\Gamma(s) = \\Gamma(s+1)}")#text(", we can write")

#align(center)[#tao-fit-display[#mitex("\\frac{s(s-1)}{2} \\Gamma(\\frac{s}{2}) = 2 \\Gamma(\\frac{s+4}{2}) - 3 \\Gamma( \\frac{s+2}{2} )")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\xi(s) = \\sum_{n=1}^\\infty 2 \\pi^{-s/2} n^{-s} \\int_0^\\infty e^{-t} t^{\\frac{s+4}{2}-1}\\ dt - 3 \\pi^{-s/2} n^{-s} \\int_0^\\infty e^{-t} t^{\\frac{s+2}{2}-1}\\ dt.")]]

#text("By a rescaling, one may write")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty e^{-t} t^{\\frac{s+4}{2}-1}\\ dt = (\\pi n^2)^{\\frac{s+4}{2}} \\int_0^\\infty e^{-\\pi n^2 t} t^{\\frac{s+4}{2}-1}\\ dt")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty e^{-t} t^{\\frac{s+2}{2}-1}\\ dt = (\\pi n^2)^{\\frac{s+2}{2}} \\int_0^\\infty e^{-\\pi n^2 t} t^{\\frac{s+2}{2}-1}\\ dt")]]

#text("and thus (after applying Fubini’s theorem)")

#align(center)[#tao-fit-display[#mitex("\\xi(s) = \\int_0^\\infty \\sum_{n=1}^\\infty 2 \\pi^2 n^4 e^{-\\pi n^2 t} t^{\\frac{s+4}{2}-1} - 3 \\pi n^2 e^{-\\pi n^2 t} t^{\\frac{s+2}{2}-1}\\ dt.")]]

#text("We’ll make the change of variables ")#mi("{t = e^{4u}}")#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("\\xi(s) = 4 \\int_{\\bf R} \\sum_{n=1}^\\infty (2 \\pi^2 n^4 e^{8u} - 3 \\pi n^2 e^{4u}) \\exp( 2su - \\pi n^2 e^{4u} )\\ du.")]]

#text("If we introduce the mild renormalisation")

#align(center)[#tao-fit-display[#mitex("H_0(z) := \\frac{1}{8} \\xi( \\frac{1}{2} + \\frac{iz}{2} )")]]

#text("of ")#mi("{\\xi}")#text(", we then conclude (at least for ")#mi("{\\mathrm{Im} z > 1}")#text(") that ")#metadata(none) <tao-5a6509b77b9a987ab78e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("H_0(z) = \\frac{1}{2} \\int_{\\bf R} \\Phi(u)\\exp(izu)\\ du")]]



#text(" where ")#mi("{\\Phi: {\\bf R} \\rightarrow {\\bf C}}")#text(" is the function ")#metadata(none) <tao-df8f798d9388c2deba77>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\Phi(u) := \\sum_{n=1}^\\infty (2 \\pi^2 n^4 e^{9u} - 3 \\pi n^2 e^{5u}) \\exp( - \\pi n^2 e^{4u} ),")]]



#text(" which one can verify to be rapidly decreasing both as ")#mi("{u \\rightarrow +\\infty}")#text(" and as ")#mi("{u \\rightarrow -\\infty}")#text(", with the decrease as ")#mi("{u \\rightarrow +\\infty}")#text(" faster than any exponential. In particular ")#mi("{H_0}")#text(" extends holomorphically to the upper half plane.")

#text("If we normalize the Fourier transform ")#mi("{{\\mathcal F} f(\\xi)}")#text(" of a (Schwartz) function ")#mi("{f(x)}")#text(" as ")#mi("{{\\mathcal F} f(\\xi) := \\int_{\\bf R} f(x) e^{-2\\pi i \\xi x}\\ dx}")#text(", it is well known that the Gaussian ")#mi("{x \\mapsto e^{-\\pi x^2}}")#text(" is its own Fourier transform. The ")#link("https://en.wikipedia.org/wiki/Quantum_harmonic_oscillator#Ladder_operator_method")[#text("creation operator")]#text(" ")#mi("{2\\pi x - \\frac{d}{dx}}")#text(" interacts with the Fourier transform by the identity")

#align(center)[#tao-fit-display[#mitex("{\\mathcal F} (( 2\\pi x - \\frac{d}{dx} ) f) (\\xi) = -i (2 \\pi \\xi - \\frac{d}{d\\xi} ) {\\mathcal F} f(\\xi).")]]

#text("Since ")#mi("{(-i)^4 = 1}")#text(", this implies that the function")

#align(center)[#tao-fit-display[#mitex("x \\mapsto (2\\pi x - \\frac{d}{dx})^4 e^{-\\pi x^2} = 128 \\pi^2 (2 \\pi^2 x^4 - 3 \\pi x^2) e^{-\\pi x^2} + 48 \\pi^2 e^{-\\pi x^2}")]]

#text("is its own Fourier transform. (One can view the polynomial ")#mi("{128 \\pi^2 (2\\pi^2 x^4 - 3 \\pi x^2) + 48 \\pi^2}")#text(" as a renormalised version of the fourth ")#link("https://en.wikipedia.org/wiki/Hermite_polynomials")[#text("Hermite polynomial")]#text(".) Taking a suitable linear combination of this with ")#mi("{x \\mapsto e^{-\\pi x^2}}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("x \\mapsto (2 \\pi^2 x^4 - 3 \\pi x^2) e^{-\\pi x^2}")]]

#text("is also its own Fourier transform. Rescaling ")#mi("{x}")#text(" by ")#mi("{e^{2u}}")#text(" and then multiplying by ")#mi("{e^u}")#text(", we conclude that the Fourier transform of")

#align(center)[#tao-fit-display[#mitex("x \\mapsto (2 \\pi^2 x^4 e^{9u} - 3 \\pi x^2 e^{5u}) \\exp( - \\pi x^2 e^{4u} )")]]

#text("is")

#align(center)[#tao-fit-display[#mitex("x \\mapsto (2 \\pi^2 x^4 e^{-9u} - 3 \\pi x^2 e^{-5u}) \\exp( - \\pi x^2 e^{-4u} ),")]]

#text("and hence by the Poisson summation formula (using symmetry and vanishing at ")#mi("{n=0}")#text(" to unfold the ")#mi("{n}")#text(" summation in ")#link(<tao-df8f798d9388c2deba77>)[#text("(2)")]#text(" to the integers rather than the natural numbers) we obtain the functional equation")

#align(center)[#tao-fit-display[#mitex("\\Phi(-u) = \\Phi(u),")]]

#text("which implies that ")#mi("{\\Phi}")#text(" and ")#mi("{H_0}")#text(" are even functions (in particular, ")#mi("{H_0}")#text(" now extends to an entire function). From this symmetry we can also rewrite ")#link(<tao-5a6509b77b9a987ab78e>)[#text("(1)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("H_0(z) = \\int_0^\\infty \\Phi(u) \\cos(zu)\\ du,")]]

#text("which now gives a convergent expression for the entire function ")#mi("{H_0(z)}")#text(" for all complex ")#mi("{z}")#text(". As ")#mi("{\\Phi}")#text(" is even and real-valued on ")#mi("{{\\bf R}}")#text(", ")#mi("{H_0(z)}")#text(" is even and also obeys the functional equation ")#mi("{H_0(\\overline{z}) = \\overline{H_0(z)}}")#text(", which is equivalent to the usual functional equation for the Riemann zeta function. The Riemann hypothesis is equivalent to the claim that all the zeroes of ")#mi("{H_0}")#text(" are real.")

#link("https://mathscinet.ams.org/mathscinet-getitem?mr=37351")[#text("De Bruijn introduced")]#text(" the family ")#mi("{H_t: {\\bf C} \\rightarrow {\\bf C}}")#text(" of deformations of ")#mi("{H_0: {\\bf C} \\rightarrow {\\bf C}}")#text(", defined for all ")#mi("{t \\in {\\bf R}}")#text(" and ")#mi("{z \\in {\\bf C}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("H_t(z) := \\int_0^\\infty e^{tu^2} \\Phi(u) \\cos(zu)\\ du.")]]

#text("From a PDE perspective, one can view ")#mi("{H_t}")#text(" as the evolution of ")#mi("{H_0}")#text(" under the backwards heat equation ")#mi("{\\partial_t H_t(z) = - \\partial_{zz} H_t(z)}")#text(". As with ")#mi("{H_0}")#text(", the ")#mi("{H_t}")#text(" are all even entire functions that obey the functional equation ")#mi("{H_t(\\overline{z}) = \\overline{H_t(z)}}")#text(", and one can ask an analogue of the Riemann hypothesis for each such ")#mi("{H_t}")#text(", namely whether all the zeroes of ")#mi("{H_t}")#text(" are real. De Bruijn showed that these hypotheses were monotone in ")#mi("{t}")#text(": if ")#mi("{H_t}")#text(" had all real zeroes for some ")#mi("{t}")#text(", then ")#mi("{H_{t^{\\prime}}}")#text(" would also have all zeroes real for any ")#mi("{t^{\\prime} \\geq t}")#text(". ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=434982")[#text("Newman later sharpened")]#text(" this claim by showing the existence of a finite number ")#mi("{\\Lambda \\leq 1/2}")#text(", now known as the ")#emph[#text("de Bruijn-Newman constant")]#text(", with the property that ")#mi("{H_t}")#text(" had all zeroes real if and only if ")#mi("{t \\geq \\Lambda}")#text(". Thus, the Riemann hypothesis is equivalent to the inequality ")#mi("{\\Lambda \\leq 0}")#text(". Newman then conjectured the complementary bound ")#mi("{\\Lambda \\geq 0}")#text("; in his words, this conjecture asserted that if the Riemann hypothesis is true, then it is only “barely so”, in that the reality of all the zeroes is destroyed by applying heat flow for even an arbitrarily small amount of time. Over time, a significant amount of evidence was established in favour of this conjecture; most recently, in 2011, ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2813360")[#text("Saouter, Gourdon, and Demichel showed")]#text(" that ")#mi("{\\Lambda \\geq -1.15 \\times 10^{-11}}")#text(".")

#text("In this paper we finish off the proof of Newman’s conjecture, that is we show that ")#mi("{\\Lambda \\geq 0}")#text(". The proof is by contradiction, assuming that ")#mi("{\\Lambda < 0}")#text(" (which among other things, implies the truth of the Riemann hypothesis), and using the properties of backwards heat evolution to reach a contradiction.")

#text("Very roughly, the argument proceeds as follows. As observed ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1260363")[#text("by Csordas, Smith, and Varga")]#text(" (and also discussed in ")#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/")[#text("this previous blog post")]#text(", the backwards heat evolution of the ")#mi("{H_t}")#text(" introduces a nice ODE dynamics on the zeroes ")#mi("{x_j(t)}")#text(" of ")#mi("{H_t}")#text(", namely that they solve the ODE ")#metadata(none) <tao-87e5ad485acb89c18788>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\frac{d}{dt} x_j(t) = -2 \\sum_{j \\neq k} \\frac{1}{x_k(t) - x_j(t)}")]]



#text(" for all ")#mi("{j}")#text(" (one has to interpret the sum in a principal value sense as it is not absolutely convergent, but let us ignore this technicality for the current discussion). Intuitively, this ODE is asserting that the zeroes ")#mi("{x_j(t)}")#text(" repel each other, somewhat like positively charged particles (but note that the dynamics is first-order, as opposed to the second-order laws of Newtonian mechanics). Formally, a steady state (or equilibrium) of this dynamics is reached when the ")#mi("{x_k(t)}")#text(" are arranged in an arithmetic progression. (Note for instance that for any positive ")#mi("{u}")#text(", the functions ")#mi("{z \\mapsto e^{tu^2} \\cos(uz)}")#text(" obey the same backwards heat equation as ")#mi("{H_t}")#text(", and their zeroes are on a fixed arithmetic progression ")#mi("{\\{ \\frac{2\\pi (k+\\tfrac{1}{2})}{u}: k \\in {\\bf Z} \\}}")#text(".) The strategy is to then show that the dynamics from time ")#mi("{-\\Lambda}")#text(" to time ")#mi("{0}")#text(" creates a ")#emph[#text("convergence to local equilibrium")]#text(", in which the zeroes ")#mi("{x_k(t)}")#text(" locally resemble an arithmetic progression at time ")#mi("{t=0}")#text(". This will be in contradiction with known results on pair correlation of zeroes (or on related statistics, such as the fluctuations on gaps between zeroes), such as the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=337821")[#text("results of Montgomery")]#text(" (actually for technical reasons it is slightly more convenient for us to use related ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=780348")[#text("results of Conrey, Ghosh, Goldston, Gonek, and Heath-Brown")]#text("). Another way of thinking about this is that even very slight deviations from local equilibrium (such as a small number of gaps that are slightly smaller than the average spacing) will almost immediately lead to zeroes colliding with each other and leaving the real line as one evolves backwards in time (i.e., under the ")#emph[#text("forward")]#text(" heat flow). This is a refinement of the strategy used in previous lower bounds on ")#mi("{\\Lambda}")#text(", in which “Lehmer pairs” (pairs of zeroes of the zeta function that were unusually close to each other) were used to limit the extent to which the evolution continued backwards in time while keeping all zeroes real.")

#text("How does one obtain this convergence to local equilibrium? We proceed by broad analogy with the “local relaxation flow” method of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2810797")[#text("Erdos, Schlein, and Yau")]#text(" in random matrix theory, in which one combines some initial control on zeroes (which, in the case of the Erdos-Schlein-Yau method, is referred to with terms such as “local semicircular law”) with convexity properties of a relevant Hamiltonian that can be used to force the zeroes towards equilibrium.")

#text("We first discuss the initial control on zeroes. For ")#mi("{H_0}")#text(", we have the classical Riemann-von Mangoldt formula, which asserts that the number of zeroes in the interval ")#mi("{[0,T]}")#text(" is ")#mi("{\\frac{T}{4\\pi} \\log \\frac{T}{4\\pi} - \\frac{T}{4\\pi} + O(\\log T)}")#text(" as ")#mi("{T \\rightarrow \\infty}")#text(". (We have a factor of ")#mi("{4\\pi}")#text(" here instead of the more familiar ")#mi("{2\\pi}")#text(" due to the way ")#mi("{H_0}")#text(" is normalised.) This implies for instance that for a fixed ")#mi("{\\alpha}")#text(", the number of zeroes in the interval ")#mi("{[T, T+\\alpha]}")#text(" is ")#mi("{\\frac{\\alpha}{4\\pi} \\log T + O(\\log T)}")#text(". Actually, because we get to assume the Riemann hypothesis, we can sharpen this to ")#mi("{\\frac{\\alpha}{4\\pi} \\log T + o(\\log T)}")#text(", a result of Littlewood (see ")#link("https://terrytao.wordpress.com/2015/03/01/254a-supplement-7-normalised-limit-profiles-of-the-log-magnitude-of-the-riemann-zeta-function-optional/")[#text("this previous blog post")]#text(" for a proof). Ideally, we would like to obtain similar control for the other ")#mi("{H_t}")#text(", ")#mi("{\\Lambda \\leq t < 0}")#text(", as well. Unfortunately we were only able to obtain the weaker claims that the number of zeroes of ")#mi("{H_t}")#text(" in ")#mi("{[0,T]}")#text(" is ")#mi("{\\frac{T}{4\\pi} \\log \\frac{T}{4\\pi} - \\frac{T}{4\\pi} + O(\\log^2 T)}")#text(", and that the number of zeroes in ")#mi("{[T, T+\\alpha \\log T]}")#text(" is ")#mi("{\\frac{\\alpha}{4 \\pi} \\log^2 T + o(\\log^2 T)}")#text(", that is to say we only get good control on the distribution of zeroes at scales ")#mi("{\\gg \\log T}")#text(" rather than at scales ")#mi("{\\gg 1}")#text(". Ultimately this is because we were only able to get control (and in particular, lower bounds) on ")#tao-math("{\\left|H_t(x-iy)\\right|}", block: false)#text(" with high precision when ")#mi("{y \\gg \\log x}")#text(" (whereas ")#tao-math("{\\left|H_0(x-iy)\\right|}", block: false)#text(" has good estimates as soon as ")#mi("{y}")#text(" is larger than (say) ")#mi("{2}")#text("). This control is obtained by the expressing ")#mi("{H_t(x-iy)}")#text(" in terms of some contour integrals and using the method of steepest descent (actually it is slightly simpler to rely instead on the ")#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/")[#text("Stirling approximation")]#text(" for the Gamma function, which can be proven in turn by steepest descent methods). Fortunately, it turns out that this weaker control is still (barely) enough for the rest of our argument to go through.")

#text("Once one has the initial control on zeroes, we now need to force convergence to local equilibrium by exploiting convexity of a Hamiltonian. Here, the relevant Hamiltonian is")

#align(center)[#tao-fit-display[#tao-math("H(t) := \\sum_{j,k: j \\neq k} \\log \\frac{1}{\\left|x_j(t) - x_k(t)\\right|},", block: true)]]

#text("ignoring for now the rather important technical issue that this sum is not actually absolutely convergent. (Because of this, we will need to truncate and renormalise the Hamiltonian in a number of ways which we will not detail here.) The ODE ")#link(<tao-87e5ad485acb89c18788>)[#text("(3)")]#text(" is formally the gradient flow for this Hamiltonian. Furthermore, this Hamiltonian is a convex function of the ")#mi("{x_j}")#text(" (because ")#mi("{t \\mapsto \\log \\frac{1}{t}}")#text(" is a convex function on ")#mi("{(0,+\\infty)}")#text("). We therefore expect the Hamiltonian to be a decreasing function of time, and that the derivative should be an increasing function of time. As time passes, the derivative of the Hamiltonian would then be expected to converge to zero, which should imply convergence to local equilibrium.")

#text("Formally, the derivative of the above Hamiltonian is ")#metadata(none) <tao-b9776d7ddf459c9ad5b0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\partial_t H(t) = -4 E(t),")]]



#text(" where ")#mi("{E(t)}")#text(" is the “energy”")

#align(center)[#tao-fit-display[#tao-math("E(t) := \\sum_{j,k: j \\neq k} \\frac{1}{\\left|x_j(t) - x_k(t)\\right|^2}.", block: true)]]

#text("Again, there is the important technical issue that this quantity is infinite; but it turns out that if we renormalise the Hamiltonian appropriately, then the energy will also become suitably renormalised, and in particular will vanish when the ")#mi("{x_j}")#text(" are arranged in an arithmetic progression, and be positive otherwise. One can also formally calculate the derivative of ")#mi("{E(t)}")#text(" to be a somewhat complicated but manifestly non-negative quantity (a sum of squares); see ")#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/")[#text("this previous blog post")]#text(" for analogous computations in the case of heat flow on polynomials. After flowing from time ")#mi("{\\Lambda}")#text(" to time ")#mi("{0}")#text(", and using some crude initial bounds on ")#mi("{H(t)}")#text(" and ")#mi("{E(t)}")#text(" in this region (coming from the Riemann-von Mangoldt type formulae mentioned above and some further manipulations), we can eventually show that the (renormalisation of the) energy ")#mi("{E(0)}")#text(" at time zero is small, which forces the ")#mi("{x_j}")#text(" to locally resemble an arithmetic progression, which gives the required convergence to local equilibrium.")

#text("There are a number of technicalities involved in making the above sketch of argument rigorous (for instance, justifying interchanges of derivatives and infinite sums turns out to be a little bit delicate). I will highlight here one particular technical point. One of the ways in which we make expressions such as the energy ")#mi("{E(t)}")#text(" finite is to truncate the indices ")#mi("{j,k}")#text(" to an interval ")#mi("{I}")#text(" to create a truncated energy ")#mi("{E_I(t)}")#text(". In typical situations, we would then expect ")#mi("{E_I(t)}")#text(" to be decreasing, which will greatly help in bounding ")#mi("{E_I(0)}")#text(" (in particular it would allow one to control ")#mi("{E_I(0)}")#text(" by time-averaged quantities such as ")#mi("{\\int_{\\Lambda/2}^0 E_I(t)\\ dt}")#text(", which can in turn be controlled using variants of ")#link(<tao-b9776d7ddf459c9ad5b0>)[#text("(4)")]#text("). However, there are boundary effects at both ends of ")#mi("{I}")#text(" that could in principle add a large amount of energy into ")#mi("{E_I}")#text(", which is bad news as it could conceivably make ")#mi("{E_I(0)}")#text(" undesirably large even if integrated energies such as ")#mi("{\\int_{\\Lambda/2}^0 E_I(t)\\ dt}")#text(" remain adequately controlled. As it turns out, such boundary effects are negligible as long as there is a large gap between adjacent zeroes at boundary of ")#mi("{I}")#text(" – it is only narrow gaps that can rapidly transmit energy across the boundary of ")#mi("{I}")#text(". Now, narrow gaps can certainly exist (indeed, the GUE hypothesis predicts these happen a positive fraction of the time); but the pigeonhole principle (together with the Riemann-von Mangoldt formula) can allow us to pick the endpoints of the interval ")#mi("{I}")#text(" so that no narrow gaps appear at the boundary of ")#mi("{I}")#text(" for any given time ")#mi("{t}")#text(". However, there was a technical problem: this argument did not allow one to find a single interval ")#mi("{I}")#text(" that avoided gaps for ")#emph[#text("all")]#text(" times ")#mi("{\\Lambda/2 \\leq t \\leq 0}")#text(" simultaneously – the pigeonhole principle could produce a different interval ")#mi("{I}")#text(" for each time ")#mi("{t}")#text("! Since the number of times was uncountable, this was a serious issue. (In physical terms, the problem was that there might be very fast “longitudinal waves” in the dynamics that, at each time, cause some gaps between zeroes to be highly compressed, but the specific gap that was narrow changed very rapidly with time. Such waves could, in principle, import a huge amount of energy into ")#mi("{E_I}")#text(" by time ")#mi("{0}")#text(".) To resolve this, we borrowed a PDE ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1626257")[#text("trick of Bourgain’s")]#text(", in which the pigeonhole principle was coupled with local conservation laws. More specifically, we use the phenomenon that very narrow gaps ")#mi("{g_i = x_{i+1}-x_i}")#text(" take a nontrivial amount of time to expand back to a reasonable size (this can be seen by comparing the evolution of this gap with solutions of the scalar ODE ")#mi("{\\partial_t g = \\frac{4}{g^2}}")#text(", which represents the fastest at which a gap such as ")#mi("{g_i}")#text(" can expand). Thus, if a gap ")#mi("{g_i}")#text(" is reasonably large at some time ")#mi("{t_0}")#text(", it will also stay reasonably large at slightly earlier times ")#mi("{t \\in [t_0-\\delta, t_0]}")#text(" for some moderately small ")#mi("{\\delta>0}")#text(". This lets one locate an interval ")#mi("{I}")#text(" that has manageable boundary effects during the times in ")#mi("{[t_0-\\delta, t_0]}")#text(", so in particular ")#mi("{E_I}")#text(" is basically non-increasing in this time interval. Unfortunately, this interval is a little bit too short to cover all of ")#mi("{[\\Lambda/2,0]}")#text("; however it turns out that one can iterate the above construction and find a nested sequence of intervals ")#mi("{I_k}")#text(", with each ")#mi("{E_{I_k}}")#text(" non-increasing in a different time interval ")#mi("{[t_k - \\delta, t_k]}")#text(", and with all of the time intervals covering ")#mi("{[\\Lambda/2,0]}")#text(". This turns out to be enough (together with the obvious fact that ")#mi("{E_I}")#text(" is monotone in ")#mi("{I}")#text(") to still control ")#mi("{E_I(0)}")#text(" for some reasonably sized interval ")#mi("{I}")#text(", as required for the rest of the arguments.")

#text("ADDED LATER: the following analogy (involving functions with just two zeroes, rather than an infinite number of zeroes) may help clarify the relation between this result and the Riemann hypothesis (and in particular why this result does not make the Riemann hypothesis any easier to prove, in fact it confirms the delicate nature of that hypothesis). Suppose one had a quadratic polynomial ")#mi("{P}")#text(" of the form ")#mi("{P(z) = z^2 + \\Lambda}")#text(", where ")#mi("{\\Lambda}")#text(" was an unknown real constant. Suppose that one was for some reason interested in the analogue of the “Riemann hypothesis” for ")#mi("{P}")#text(", namely that all the zeroes of ")#mi("{P}")#text(" are real. A priori, there are three scenarios:")

#list(
[#text("(Riemann hypothesis false) ")#mi("{\\Lambda > 0}")#text(", and ")#mi("{P}")#text(" has zeroes ")#tao-math("{\\pm i \\left|\\Lambda\\right|^{1/2}}", block: false)#text(" off the real axis.")],
[#text("(Riemann hypothesis true, but barely so) ")#mi("{\\Lambda = 0}")#text(", and both zeroes of ")#mi("{P}")#text(" are on the real axis; however, any slight perturbation of ")#mi("{\\Lambda}")#text(" in the positive direction would move zeroes off the real axis.")],
[#text("(Riemann hypothesis true, with room to spare) ")#mi("{\\Lambda < 0}")#text(", and both zeroes of ")#mi("{P}")#text(" are on the real axis. Furthermore, any slight perturbation of ")#mi("{P}")#text(" will also have both zeroes on the real axis.")]
)

#text("The analogue of our result in this case is that ")#mi("{\\Lambda \\geq 0}")#text(", thus ruling out the third of the three scenarios here. In this simple example in which only two zeroes are involved, one can think of the inequality ")#mi("{\\Lambda \\geq 0}")#text(" as asserting that if the zeroes of ")#mi("{P}")#text(" are real, then they must be repeated. In our result (in which there are an infinity of zeroes, that become increasingly dense near infinity), and in view of the convergence to local equilibrium properties of ")#link(<tao-87e5ad485acb89c18788>)[#text("(3)")]#text(", the analogous assertion is that if the zeroes of ")#mi("{H_0}")#text(" are real, then they do not behave locally as if they were in arithmetic progression.")

#heading(level: 1)[#text("Comments (71)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/218e404d738140cb6dc729ac737203d72ec8abe60ce9dd56aed9d286311d5e79-b2fda9eff617c850e80417d72ea9306dbee8e0b29e22651f4dde32019414c7ed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nikita Sidorov")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491518")[#strong[#text("Nikita Sidorov")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2018")])]

#text("Terry, I believe the link should be ")#link("https://arxiv.org/abs/1801.05914")[#text("https://arxiv.org/abs/1801.05914")]

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c53cf3dccf2b7383c667276b96c9dd158363f6aeb1f0b1d37a3d80f67225239-fabe0f0c36b6aef5e67b0aae242a20ba3052360346acb25e9e48e3d6b27567fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491522")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2018")])]

#text("1. the link to the paper is wrong( ")#link("https://arxiv.org/abs/1801.03908")[#text("https://arxiv.org/abs/1801.03908")]#text("). It should probably be ")#link("https://arxiv.org/pdf/1801.05914.pdf")[#text("https://arxiv.org/pdf/1801.05914.pdf")]#linebreak()#text(" 2. Rodgers and I have uploaded to the arXiv _its_ paper")#linebreak()#text(" 3. of Newman regarding _to_ the extent to which")#linebreak()#text(" 4. Furthermore, this Hamiltonian _ _ a convex function")#linebreak()#text(" 5. evolution of this gap _with_ with solutions")#linebreak()#text(" 6. This lets one get _a_ locate an interval")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491525")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2018")])]

#text("“As observed by Csordas, Smith, and Vargas” it should be Varga without s")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491526")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2018")])]

#text("“have only real zeros” seems clearer than “have all real zeros”.")

#emph[#text("[Reworded – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491527")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2018")])]

#text("Since previous results used “Lehmer pairs”, is it possible that this result implies some new information on the behavior of “Lehmer pairs”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491528")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2018")])]

#text("We don’t quite use the Csordas-Smith-Varga method to lower bound the de Bruijn-Newman constant using Lehmer pairs, because we were unable to produce a sufficiently strong sequence of such pairs without introducing powerful hypotheses such as GUE. (However, we were able to use the CSV method to give a shorter proof of our theorem conditional on the GUE hypothesis; this is not detailed in the preprint, but I might write this up in a separate blog post.) As such, we do not directly say anything new about these pairs.")

#text("One can compare the arguments in this way. CSV used the dynamics of zeroes (equation (3) in this blog post) to show that if the de Bruijn-Newman constant ")#mi("\\Lambda")#text(" was significantly below zero, then any pair of adjacent zeroes of ")#mi("H_0")#text(" would be repelled from each other, in the sense that they could not be much closer to each other than to other nearby zeroes. Such repulsion would be in contradiction with the existence of sufficiently strong Lehmer pairs, which is why one can use a given Lehmer pair to produce a lower bound on ")#mi("\\Lambda")#text(". Our argument makes a more complicated analysis of the dynamics of (3) (incorporating the CSV arguments, but several other arguments besides, including ideas from Erdos-Schlein-Yau and Bourgain) to make a stronger assertion, namely that if the de Bruijn-Newman constant was significantly below zeroes, then the zeroes are not only repelled from each other, but are approximately in local equilibrium in the sense that they behave like an arithmetic progression at small scales. This type of behaviour was already ruled out from prior work on pair correlation (in particular by the work of Montgomery and Conrey-Ghosh-Gonek mentioned in the blog post).")

#text("So, basically to establish this result, we didn’t actually prove any new results about the distribution of zeroes of the zeta function, relying instead on existing literature. Instead, the main advance came from a better understanding of the dynamics of (3). (We also needed some coarse-scale control on the zeroes of ")#mi("H_t")#text(" which was not explicitly in prior literature, but which was obtainable from relatively standard, though lengthy, computations.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491529")[#strong[#text("New top story on Hacker News: The De Bruijn-Newman constant is non-negative – Tech + Hckr News")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2018")]

#text("[…] The De Bruijn-Newman constant is non-negative 3 by lisper | 0 comments on Hacker News. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aula")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491533")[#strong[#text("Aula")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2018")])]

#text("The second display above (1) is missing du at the end.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491535")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2018")])]

#text("Assuming RH (i.e. by this result ")#mi("\\Lambda = 0")#text("), are these methods sufficient to improve on the current bound ")#mi("O(\\log T)")#text(" on the multiplicities of the zeros?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491542")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2018")])]

#text("On RH I believe one can obtain a bound of ")#mi("O( \\log T / \\log\\log T)")#text(" on the multiplicity of zeroes (Theorem 14.13 of Titchmarsh). I am not aware of any further improvement. Our methods unfortunately don’t seem to say anything new about zeta in the actual world where ")#mi("\\Lambda \\geq 0")#text("; they only give (unreasonably) strong control on zeta in the counterfactual world where ")#mi("\\Lambda < 0")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491536")[#strong[#text("The De Bruijn-Newman constant is non-negative - KISCAFE")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2018")]

#text("[…] Read More […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/311f35de97c691c5c0137779f57c11d409acbf176bb1d6cd1b211af6c9cf3d03-0f6b5b2c03b806f1b1bb8476adbf615652263319f89d56808318adbbf255c3bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous HN user")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491537")[#strong[#text("Anonymous HN user")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2018")])]

#text("Posted on HN (HackerNews): ")#link("https://news.ycombinator.com/item?id=16187499")[#text("https://news.ycombinator.com/item?id=16187499")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b86d42e82de0383981f35411068f6ac1055505b0c141ccc7345be3525ce5b0c6-2284f8606b31475d25bb16f44d90b8b4f0d746a5aa035a2f2aec37835ec43aef.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Cole")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491538")[#strong[#text("David Cole")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2018")])]

#text("Wow! Impressive effort! And Congratulations to you, Prof. Tao and Prof. Rodgers provided your work, proof of Newman’s Conjecture, is rings true!")

#text("On the Riemann Hypothesis, your ‘barely’ is not the best way to state perfection or Λ =0 (assuming your proof is correct) via the Newman’s Conjecture with regards to the truth of the Riemann Hypothesis.")

#text("FYI:")

#link("https://www.researchgate.net/post/Does_the_nth_nontrivial_simple_zero_of_the_Riemann_Zeta_Function_indicate_the_nth_prime_p_n_occurs_as_a_prime_factor_in_all_multiples_of_p_n")[#text("https://www.researchgate.net/post/Does_the_nth_nontrivial_simple_zero_of_the_Riemann_Zeta_Function_indicate_the_nth_prime_p_n_occurs_as_a_prime_factor_in_all_multiples_of_p_n")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b86d42e82de0383981f35411068f6ac1055505b0c141ccc7345be3525ce5b0c6-2284f8606b31475d25bb16f44d90b8b4f0d746a5aa035a2f2aec37835ec43aef.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Cole")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491539")[#strong[#text("David Cole")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2018")])]

#text("Oops!")#linebreak()#text(" “… rings true!” Your proof assuming it rings true is still a long away from affirming the truth of the Riemann Hypothesis.")

#text("But, please trust me (or my work on the Riemann Hypothesis).")

#text("The Riemann Hypothesis is true! :-)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491541")[#strong[#text("De Bruijn-Newman meets Riemann – The nth Root")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2018")]

#text("[…] …. (Terence Tao) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491544")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2018")])]

#text("So Λ should be 0 ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491547")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2018")])]

#text("In the preprint, for equation 38 and 39, there is a constant difference of -\\frac{\\ln4\\pi}{4\\pi} between the derivative of 38 and what is written for 39. Does this have anything to do with equation 37 being an asymptotic relationship?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491550")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2018")])]

#text("Yes, one can absorb this constant factor into the ")#mi("O( \\log_+ T)")#text(" error.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491548")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2018")])]

#text("Is the currently known best explicit(!) upper bound on ")#mi("\\Lambda")#text(" still ")#mi("1/2")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491551")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2018")])]

#text("Yes, although ")#link("http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.164.5595&rep=rep1&type=pdf")[#text("Ki, Kim, and Lee")]#text(" have improved the bound a tiny bit from ")#mi("\\Lambda \\leq 1/2")#text(" to ")#mi("\\Lambda < 1/2")#text(". It may be possible to do better than this by refining the Riemann-von Mangoldt formulae for H_t in our paper, as well as somehow numerically verifying the Riemann hypothesis for ")#mi("H_t")#text(" up to some large height (possibly leveraging the existing numerical verification for the zeta function), but I have not tried to do this in detail.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491554")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2018")])]

#text("Is there any known 1:1 correspondence between (the possible value of)")#linebreak()#text(" ")#mi("\\Lambda")#text(" and (the possible value of) the supremum (")#mi("\\sigma_{max}")#text(" ,say) on the real parts of zeta zeros ?")#linebreak()#text(" If so, it seems that the result ")#mi("\\Lambda < 1/2")#text(" implies that ")#mi("\\sigma_{max} < 1")#text(" as well !")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491557")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2018")])]

#text("I think there is a relation of the form ")#mi("\\Lambda \\leq \\frac{1}{2} (2\\sigma_{max} - 1)^2")#text(" (this follows for instance from Theorem A of the Ki-Kim-Lee paper after a little bit of effort). Roughly speaking, this relation arises from the attraction that a zero off the critical line will feel from its reflected partner on the other side of the line when evolving under backwards heat flow. However this is not the only source of attraction – the other zeroes will also pull at this zero – so I doubt that one can hope to reverse this inequality exactly (other than by proving ")#mi("\\Lambda=0")#text(" and ")#mi("\\sigma_{max}=1/2")#text(", of course). Indeed the Ki-Kim-Lee paper is in some sense showing that this sort of relationship between ")#mi("\\Lambda")#text(" and ")#mi("\\sigma_{max}")#text(" is not optimal, and does not give any new results on ")#mi("\\sigma_{max}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491559")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2018")])]

#text("My question was motivated by observing that the parameter ")#mi("t")#text(" plays the role of a “regulating parameter” in the sense that if ")#mi("H_t")#text(" has only real zeros, then so is ")#mi("H_t^{\\prime}")#text(" for any ")#mi("t^{\\prime} \\geq t")#text(".")#linebreak()#text(" So increasing ")#mi("t")#text(" has a kind of “regulating effect” on the zeros of ")#mi("H_t")#text(" in the sense of keeping them on the real axis.")#linebreak()#text(" Hence a natural question is whether this regulating effect may have an extension to include also the case of parameters ")#mi("t")#text(" for which ")#mi("H_t(z)")#text(" has all its zeroes in a strip ")#tao-math("\\left| \\Im z \\right| \\leq c(t)", block: false)#text(" for some positive ")#mi("c(t)")#text(" which is the supremum over the imaginary parts of the zeros of ")#mi("H_t")#text(". A natural generalization of the regulating effect for such ")#mi("H_t")#text(" is that by increasing ")#mi("t")#text(", the zeros of ")#mi("H_t")#text(" tend to decrease their distances from the real axis (i.e. are “attracted” by the real axis), and in particular, the function ")#mi("c(t)")#text(" should (strictly?) decrease with increasing ")#mi("t")#text(". Hence, the constant ")#mi("\\Lambda")#text(" may be viewed as the minimal value of the parameter ")#mi("t")#text(" needed to “pull back” the zeros of ")#mi("H_0")#text(" (assuming ")#mi("c(0) > 0")#text(") into the real axis (i.e. ")#mi("c(\\Lambda) = 0")#text("). Since ")#mi("\\sigma_{max}")#text(" is closely related with ")#mi("c(0)")#text(", the extended regulating effect seems to imply that ")#mi("\\sigma_{max}")#text(" should (strictly?) increase with increasing ")#mi("\\Lambda")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491567")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2018")])]

#text("One has the differential inequality")

#mi("\\displaystyle \\frac{d}{dt} c(t) \\leq -\\frac{1}{c(t)}")

#text("whenever ")#mi("c(t) > 0")#text(", basically because of the attraction between any zero ")#mi("x+iy")#text(" off the real axis to its conjugate ")#mi("x-iy")#text(". (Again, see the Ki-Kim-Lee paper for more details.) Combining this with ")#mi("c(0) = 2 \\sigma_{max} - 1")#text(" gives the bound ")#mi("\\Lambda \\leq \\frac{1}{2}(2\\sigma_{max}-1)^2")#text(" I mentioned in my previous comment. However, this inequality will not be an equality in general, due to the additional attraction that such a zero will also experience with respect to the remaining zeroes of ")#mi("H_t")#text(". This latter effect is complicated and does not necessarily behave in a monotone fashion with respect to ")#mi("\\Lambda")#text(" or ")#mi("c(0)")#text(" (actually, it’s hard to quantify exactly what such a monotonicity would even mean, given that ")#mi("\\Lambda")#text(" is an absolute constant rather than a parameter). So it could be that a configuration of zeroes with a larger value of ")#mi("\\sigma_{max}")#text(" could in fact have a faster convergence to the real axis than a different configuration with a smaller value of ")#mi("\\sigma_{max}")#text(" due to these other effects. As such, I doubt that there is any particularly clean relationship between ")#mi("\\sigma_{max}")#text(" and ")#mi("\\Lambda")#text(", though one could still hope to improve upon the Ki-Kim-Lee analysis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491584")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2018")])]

#text("It seems that in order to use this approach to show that ")#mi("\\sigma_{max} < 1")#text(", one needs also a good lower bound for the derivative ")#mi("c^{\\prime}(t)")#text(" (sufficiently close to the upper bound above) to get a sufficiently good estimate on the dependence of ")#mi("\\Lambda")#text(" on ")#mi("\\sigma_{max}")#text(" such that a sufficiently good explicit(!) upper bound on ")#mi("\\Lambda")#text(" (e.g. by refining the Ki-Kim-Lee merhod) would give an explicit new upper bound on ")#mi("\\sigma_{max}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491598")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2018")])]

#text("It is interesting to observe that since for ")#mi("t > 0")#text(" there are only finitely many non-real zeros of ")#mi("H_t")#text(" (by theorem 1.3 of the KKL paper), the function ")#mi("c(t)")#text(" (defined as the supremum over the imaginary parts of ")#mi("H_t")#text(" zeros) is actually attained by the imaginary part of some non-real zero of ")#mi("H_t")#text(" whenever ")#mi("c(t) >0")#text(" – showing that ")#mi("c(t)")#text(" is determined by the dynamics of that zero – so it is not only (piecewise) differentiable but even piecewise analytic (it may not be analytic for those ")#mi("t")#text(" values for which it is attained by the imaginary parts of at least two non-real zeros of ")#mi("H_t")#text(").")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491564")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2018")])]

#text("If a large scale computational effort can help in upper bounding the constant, I think several people would want to help. Do write more on this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491592")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2018")])]

#text("In principle one could do this as follows. The analysis of Ki-Kim-Lee (see in particular the proof of Proposition 3.1 of ")#link("http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.164.5595&rep=rep1&type=pdf")[#text("their paper")]#text(") shows that for any ")#mi("t > 0")#text(" and ")#mi("\\varepsilon > 0")#text(", there exists ")#mi("T>0")#text(" such that there are no zeroes ")#mi("H_t(x+iy)=0")#text(" with ")#mi("y \\geq \\varepsilon")#text(" and ")#mi("x \\geq T")#text(". They do not explicitly compute ")#mi("T")#text(" in terms of ")#mi("t")#text(" and ")#mi("\\varepsilon")#text(", but it could in principle be made effective. If it is not too large, one could also numerically verify (e.g. by argument principle and quadrature) that all zeroes of ")#mi("H_t")#text(" with real part in ")#mi("[0,T]")#text(" have imaginary part less than ")#mi("\\varepsilon")#text(". Combining this with Proposition A of Ki-Kim-Lee gives an upper bound of the form ")#mi("\\Lambda \\leq t + \\frac{1}{2} \\varepsilon^2")#text(", so presumably for ")#mi("t,\\varepsilon")#text(" small enough one can improve upon the bound of ")#mi("1/2")#text(" (of course, making ")#mi("t,\\varepsilon")#text(" smaller will make ")#mi("T")#text(" larger).")

#text("One could possibly envisage a Polymath style project in this direction, which would naturally split into two halves: a computational effort to establish rectangular zero-free regions ")#mi("\\{ x+iy: 0 \\leq x \\leq T, \\varepsilon \\leq y \\leq 1 \\}")#text(" for ")#mi("H_t")#text(", and an optimisation of the KKL arguments to obtain an explicit dependence of ")#mi("T")#text(" on ")#mi("t,\\varepsilon")#text(". [EDIT: there is also a third direction, which is to try to improve the bound ")#mi("\\Lambda \\leq t + \\frac{1}{2} \\varepsilon^2")#text(" by using the dynamics of zeroes.] If there is enough interest I would be willing to launch and moderate such a project.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491593")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2018")])]

#text("I strongly support such Polymath style project!")#linebreak()#text(" Some remarks:")#linebreak()#text(" 1. In practice, to use the argument principle one needs only to compute approximately (with precision better than ")#mi("\\pi")#text(", say) the argument of the integrand on a sufficiently dense set of “grid points” on the rectangular integration contour such that the argument increment between any two consecutive grid points is assured(!) to remain sufficiently small (e.g. less than ")#mi("pi/2")#text(" in absolute value).")#linebreak()#text(" 2. By theorem 1.3 of the KKL paper, for each ")#mi("t > 0")#text(" there are at most finitely many non-real zeros of ")#mi("H_t")#text(" – so even for ")#mi("\\epsilon =0")#text(", there is a finite corresponding ")#mi("T")#text(" (but its numerical estimation seems to be much more difficult).")#linebreak()#text(" 3. By theorem 1.4 of the KKL paper, for each ")#mi("t > 0")#text(", the zeros of ")#mi("H_t")#text(" are distributed much more regularly with better asymptotic estimates than the zeros of ")#mi("H_0")#text(" – which might help in estimating their dynamics (in the third direction of the suggested project).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491596")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2018")])]

#text("I too support the idea of a Polymath project for this. As the other reply said, Theorem 1.3 of KKL finally mentions only T and not epsilon which makes this quite exciting but presumably much more difficult.")

#text("It would also be quite interesting to see the magnitude of T for extremely small positive t values once the explicit dependence is established, even if the computational effort for such t gets prohibitive.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6803f451a822a44c3357dffe0946273ac8b678c1381d8f6f15471f78bf5064e-c0cdd6fbf9fa11cb38f669d32e0c33214ced4ab5f9e837265aa2a25f482e13f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brad")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491691")[#strong[#text("Brad")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2018")])]

#text("I also would be interested such a polymath. If we make progress on the size of ")#mi("\\Lambda")#text(" for ")#mi("H_0(z)")#text(", it may also be interesting to consider somewhat more general questions: e.g. for an entire function ")#mi("h_0(z)")#text(" with rapidly decaying real and even Fourier transform, and with a Riemann – von Mangoldt formula akin to that for ")#mi("H_0(z)")#text(" (that is, with the same asymptotic form and error term, and which counts zeros in the same critical strip), how large can ")#mi("\\Lambda")#text(" for the function ")#mi("h_t(z)")#text(" be? De Bruijn gives in general ")#mi("1/2")#text(", but it’s not clear to me if this is optimal when zeros increase in density along the critical strip. (This may already be in the literature, but I’m not aware of a reference.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/15fdd26260b7494ddff8ae819232b8672e2244d264a794710238bd87a2460350-bf33e1a619ddefa0ea9c77e08888cfca229a3c54d92f5aa63c15cd9e70570d84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nicodean")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491693")[#strong[#text("nicodean")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2018")])]

#text("i would love to participate at some point to such a project. while i am no number theoretist, i could maybe help on the numerics (at least i would really like to follow the numerics-part of the project closely to understand these approaches better).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lehmer pairs and GUE | What's new")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491568")[#strong[#text("Lehmer pairs and GUE | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2018")])]

#text("[…] is non-negative. This implication is now redundant in view of the unconditional results of this recent paper of myself and Rodgers; however, the question of whether an infinite number of Lehmer pairs exist remain […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d3a5481b2dce23f559221115a98d4d16283316e2cbe837021bc66f78a772211-1458b9040bd9a2768f842b42edcd3f062c91a085270fba9a766951943098f3b6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jm")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491572")[#strong[#text("jm")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2018")])]

#text("Is there an analogue of your result for the function-field RH, and does it become something easier there?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491583")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2018")])]

#text("This was investigated by Chang et al., see ")#link("https://www.math.cornell.edu/~dmehrle/research/papers/newmanpaper-final.pdf")[#text("https://www.math.cornell.edu/~dmehrle/research/papers/newmanpaper-final.pdf")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62c695a598660d3c933fd051bf60b99756e32a6448304d45df0d096038fb0a5f-88bcf0ba80ef192b1653b545b934477e32f4565275b6c920083630599e2f8a85.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ahmad Heydari")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491585")[#strong[#text("Ahmad Heydari")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2018")])]

#text("thank’s for share this article")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5162cf9bfb600aae7b0dc75c9f8954e80ab40e82e0a8fce12c188ea5c394ffa1-a5f3ee3445e76a613b7f243e63de1aa8fa020a569c47d4983450280115329df4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michel Eve")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491644")[#strong[#text("Michel Eve")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2018")])]

#text("I have a basic and perhaps naïve question about the Newman conjecture now a theorem. Generally a conjecture is an assumption which allows further important results (like RH in prime number theory) or can be readily understood by non mathematicians (like FLT which was not a theorem until 1994).I understand from reading your comments that this new theorem does not help much to solve RH and it is far too complex to mean anything to the general public. So what is its usefulness ? One could be tempted to try to lower the constant upper bound down to zero but is this avenue more promising than other approaches to solve RH ? Can it be used to make progress in other areas of number theory ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491648")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2018")])]

#text("Besides the possibility of immediate applications (which are indeed somewhat slim), or the historical interest of settling a question that had attracted a fair amount of previous literature, I think this result will help demystify somewhat the functions ")#mi("H_t")#text(" introduced by de Bruijn, and in particular emphasise the role of both ODE and oscillatory integral estimates in understanding them further. If in the future it turns out that these functions – or other functions similar to them – have additional interesting properties to exploit (e.g. some variant of an Euler product factorisation), then one could well have some unexpected application of the existing literature on these functions, including my paper with Brad. But I think it is also justifiable to study these questions for their own sake.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491717")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("Congratulations Brad and Terry. Two very naive question.One is if the Cramer probabilistic heuristic gives reason to think that Lambda is 0. (or some other simple heuristic reason.) The second is if the the heat flow of the zeta is the same or analogous to a zeta function of some “perturbation” of the primes. (beurling primes) E.g. you create a new sequence of “primes” with precisely the same density where you take p_n 0,1,2… times according to some probability distribution (perhaps depending on n) with expectation one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491719")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("Actually that seems to be the one key thing that the de Bruijn perturbations ")#mi("H_t")#text(" of ")#mi("H_0")#text(" (which is essentially the Riemann xi function) is lacking – they do have analytic continuation and a functional equation, but they are missing anything resembling an Euler product that would relate them to something resembling prime numbers. So, at least at our current level of understanding, they are largely objects of an analytic nature rather than an arithmetic one. It in fact seems remarkably hard to deform the Riemann zeta function in a way that keeps both the functional equation structure and the Euler product structure; the known examples of such functions (basically the ")#link("https://en.wikipedia.org/wiki/Selberg_class")[#text("Selberg class")]#text(") are very arithmetic in nature, with no continuous parameter to deform in.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491720")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("I see, out of curiosity: you can consider Beurling primes where ")#mi("p_n")#text(" is taken with probability ")#mi("(1-\\delta_n)")#text(", where ")#mi("\\delta_n")#text(" goes to zero as quickly as you wish. This will lead to some deformation of the zeta function. Do all the desirable properties zeta and the statistical properties of primes disappear no matter how quickly these delta’s tends to 0?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491741")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("I think the functional equation is all but guaranteed to be destroyed when modifying the zeta function in this fashion. The functional equation is basically reflecting the fact that the multiplicative semigroup generated by the primes – that is to say, the natural numbers – is essentially an abelian group with respect to addition (it is one half of the integers), and so enjoys a Poisson summation formula which eventually becomes the functional equation. If one randomly perturbs the set of primes, there is no longer any reason to expect additive structure in the semigroup generated by the remaining primes.")

#text("To put it another way, the Euler product reflects the multiplicative structure of the integers, whereas the functional equation reflects the additive structure. It’s hard to perturb the integers to retain both structures (other than to work with other rings of algebraic integers or similar objects, of course).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491748")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("Perhaps there is a way to formulate a necessary and sufficient condition for such a continuous (preferably differentiable) perturbation probably in terms of some differential equation?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491751")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2018")])]

#text("Putting Beurling primes aside. Had ")#mi("\\Lambda")#text(" been negative, were there some implications on the distribution of primes stronger than those given by RH. Similarly if one proves say ")#mi("\\Lambda \\le 0.2")#text(", would it have any implications on the distribution of primes (weaker, of course, than those given by RH)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491764")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2018")])]

#text("The literature so far has almost exclusively focused on implications of the form “information about zeroes of zeta” -> “information about the de Bruijn-Newman constant”, with the notable exception of course of the implication ")#mi("\\Lambda \\leq 0 \\implies \\mathrm{RH}")#text(". It is conceivable that one could work on the converse and eventually show, for instance, that smallness of ")#mi("\\Lambda")#text(" implies a zero free region for zeta which in turn implies some reasonably good error term in the prime number theorem. But given that our project to bound ")#mi("\\Lambda")#text(" will use, among other things, numerical zero free regions for zeta and related functions, I would imagine that this would be an extremely inefficient route to get new information about zeta.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath proposal: upper bounding the de Bruijn-Newman constant | What's new")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491739")[#strong[#text("Polymath proposal: upper bounding the de Bruijn-Newman constant | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("[…] on the interest expressed in the comments to this previous post, I am now formally proposing to initiate a “Polymath project” on the topic of obtaining […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491757")[#strong[#text("El duro camino hacia la demostración de la hipótesis de Riemann | Ciencia | La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2018")]

#text("[…] matemáticos) en Terence Tao, “The De Bruijn-Newman constant is non-negative,” What’s new, 19 Jan 2018. Sabemos que 0 ≤ Λ < 1/2, reducir esta cota superior es el objetivo del nuevo proyecto […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4ad6c18186ffa1aab4aadbb6437ddfdfd03ffdb28fa7b75fb5a4b74dadd060d-b17876bb6ed44b4eb4e6f409d6e9c2e04bf2fd6789fad7fda897a642de72445e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A new polymath proposal (related to the Riemann Hypothesis) over Tao’s blog | The polymath blog")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491787")[#strong[#text("A new polymath proposal (related to the Riemann Hypothesis) over Tao’s blog | The polymath blog")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2018")])]

#text("[…] Terry Tao’s blog who wrote: “Building on the interest expressed in the comments to this previous post, I am now formally proposing to initiate a “Polymath project” on the topic of obtaining new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath15, first thread: computing $H_t$, asymptotics, and dynamics of zeroes | What's new")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491837")[#strong[#text("Polymath15, first thread: computing $H_t$, asymptotics, and dynamics of zeroes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")])]

#text("[…] real part on this strip. One can use the Poisson summation formula to verify that is even, (see this previous post for details). This lets us obtain a number of other formulae for . Most obviously, one can unfold […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-491877")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("THE DE BRUIJN NEWMAN CONSTANT IS POSITIVE IF THE “FAMOUS” RIEMANN HYPOTHESIS IS WRONG. AS THE TITLE OF THIS BLOG POST SUGGESTS, COULD THIS BE A STEP TO DISPROVING THE RIEMANN HYPOTHESIS?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath15, second thread: generalising the Riemann-Siegel approximate functional equation | What's new")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-492042")[#strong[#text("Polymath15, second thread: generalising the Riemann-Siegel approximate functional equation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("[…] real part on this strip. One can use the Poisson summation formula to verify that is even, (see this previous post for details). This lets us obtain a number of other formulae for . Most obviously, one can unfold […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heat flow and zeroes of polynomials II: zeroes on a circle | What's new")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-501372")[#strong[#text("Heat flow and zeroes of polynomials II: zeroes on a circle | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2018")])]

#text("[…] arguments in my paper with Brad Rodgers (discussed in this previous post) indicate that for a “typical” polynomial of degree that obeys the Riemann […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b6047afb90d576d1c9ace654857b3277dc9bafd44209834e0c864d8feb7b895-edd221e986e18ee9ac17ae96d7b6bb4d7ce518563f42a785e2c21e65e895f0ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Irfan Ali")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-503967")[#strong[#text("Irfan Ali")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2018")])]

#text("That’s a great move towards a Problem of Riemann I am student of MS Applied mathematics at IBA Sukkur University Sindh,Pakistan also working on the Problem but still iam reading the work which has done towards Riemann Hypothesis what would be the next move ?")#linebreak()#text(" working on constant is zero and see what happens either contradiction happens or not?")#linebreak()#text(" Or working in the region (0,0.22)?")#linebreak()#text(" Now which difficulties arises to work on the Newman constant is 0 or greater than 0?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-505898")[#strong[#text("Watching Over the Zeroes | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2018")]

#text("[…] to a possible argument that the RH is false. In January of this year, Brad Rogers and Terence Tao turned up the heat on this connection by proving that the GUE conjecture entails the existence of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-513264")[#strong[#text("Dan Romik Studies the Riemann’s Zeta Function, and Other Zeta News. | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2019")]

#text("[…] It is now the 10 year anniversary of polymath projects and let me belatedly mention a successful project polymath15 that took place over Terry Tao blog. The problem is related to the Hermite expansion of the Zeta function. Roughly speaking you can apply a noise operator on Zeta that causes higher degrees to decay exponentially. (The noise can be “negative” and then the higher degrees explode exponentially.) The higher the amount t of noise the easier the assertion of the Riemann Hypothesis (RH) becomes. Let , the de Bruijn-Newman constant, be the smallest amount of noise under which the assertion of RH is correct. It was conjectured that namely the assertion of the RH fails when you apply negative noise no matter how small. This follows from known conjectures on the spacing between zeroes of the Zeta function since when the assertion of RH is known for some level (positive or negative) of noise, then with a higher level of noise spacing between zeroes become more boring. The conjecture was settled by Brad Rodgers and Terry Tao. (See this blog post by Terry Tao.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3de0971aa98986c59e57f76238c236536bbf74450298b40bccba65aaefdc5ad9-4ea34b276d8ccaca362647255e28225be4a33c216c4e97d34fd82798bf1184c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Isaac TK")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-518271")[#strong[#text("Isaac TK")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2019")])]

#text("Dear Prof. Tao, in your video lecture, ”Vaporizing and freezing the Riemann zeta function,” Prof. Tao, in your video lecture, ”Vaporizing and freezing the Riemann zeta function ")#link("https://www.youtube.com/watch?v=t908N5gUZA0,”")[#text("https://www.youtube.com/watch?v=t908N5gUZA0,”")]#text(" you said")

#text("”De Bruijn showed that if for some real ")#mi("t_0")#text(" the zeros of ")#mi("H_{t_0}")#text(" are contained in the horizontal strip ")#tao-math("\\lbrace x+iy: \\left|y\\right|\\leq y_0 \\rbrace", block: false)#text(", then \\textit{for all} ")#mi("t>t_0")#text(", they will be contained in a narrower strip")

#tao-math("\\displaystyle \\{x+iy: \\left|y\\right|\\leq (y_{0}^2 - 2(t-t_0))^{1/2}_+ \\},", block: false)#text("”")

#text("where ")#mi("x,y")#text(" are real. Note that ")#mi("8H_{0}(z)=xi(1/2 + iz/2)")#text(", where ")#mi("\\xi")#text(" denotes the Riemann xi function. Since ")#mi("\\xi(s)\\neq 0")#text(" for ")#mi("\\mathrm{Re}(s)\\geq 1")#text(", we can take ")#mi("t_0 = 0")#text(", ")#mi("y_0 = 1")#text(", ")#mi("{t = t_0 + \\frac{y_0^2}{2} -c}")#text(" where ")#mi("c")#text(" is an arbitrarily small positive number, and deduce that all the zeros of ")#mi("H_t")#text(" must be real for ")#mi("t>0")#text(". This implies that if all zeros of ")#mi("H_t")#text(" are real if and only if ")#mi("t\\geq \\Lambda")#text(", then ")#mi("\\Lambda \\leq 0")#text(", (the Riemann Hypothesis !)")

#text("This would mean that de Bruijn proved the RH, but did not realize it !")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-518329")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2019")])]

#text("This argument gives real zeroes of ")#mi("H_t")#text(" only for ")#mi("t > t_0 + \\frac{y_0^2}{2} = \\frac{1}{2}")#text(", not for all ")#mi("t > 0")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3de0971aa98986c59e57f76238c236536bbf74450298b40bccba65aaefdc5ad9-4ea34b276d8ccaca362647255e28225be4a33c216c4e97d34fd82798bf1184c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous1")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-521030")[#strong[#text("Anonymous1")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2019")])]

#text("Dear Prof Tao, recall that for ")#mi("t<0,")#text(" one has ")#tao-math("H_{t}(z)=\\frac{1}{4\\pi} \\int_{-\\infty}^{\\infty} e^{-r^2/4}H_{0}(z+r\\left|t\\right|^{1/2}) \\mathrm{d}r", block: false)#text(". By the mean-value theorem for integrals, it follows that ")#tao-math("H_{t}(z)=\\frac{1}{4\\pi}H_{0}(z+\\alpha \\left|t\\right|^{1/2}) \\int_{-\\infty}^{\\infty} e^{-r^2/4} \\mathrm{d}r=\\frac{1}{2}H_{0}(z+\\alpha \\left|t\\right|^{1/2})", block: false)#text(" for some real number ")#mi("\\alpha")#text(". By your intuition, $H_t$ can be regarded as a ´piece of matter´ and exists in gaseous form for ")#mi("t<0")#text(". So doesn the above equation entail that $H_0$ must also be a gas ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-521046")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2019")])]

#text("The mean value theorem is only valid for real-valued functions, not complex-valued ones. For instance, ")#mi("0 = \\frac{1}{2\\pi} \\int_0^{2\\pi} e^{i \\theta}\\ d\\theta")#text(" is the mean of ")#mi("e^{i\\theta}")#text(", but ")#mi("0 \\neq e^{i\\theta}")#text(" for any ")#mi("0 \\leq \\theta \\leq 2\\pi")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3de0971aa98986c59e57f76238c236536bbf74450298b40bccba65aaefdc5ad9-4ea34b276d8ccaca362647255e28225be4a33c216c4e97d34fd82798bf1184c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous1")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-521052")[#strong[#text("Anonymous1")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2019")])]

#text("Oh sure, had overlooked that, so ")#mi("z")#text(" must be real, which leads me to the following question: doesn’t the equation ")#tao-math("4\\pi H_{t}(z)=H_{0}(z+\\alpha \\left|t\\right|^{1/2})", block: false)#text(" for some real number ")#mi("\\alpha")#text(" and ")#mi("t<0")#text(" entail that ")#mi("H_{t}")#text(" should have an Euler product since ")#mi("H_0")#text(" has one ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3de0971aa98986c59e57f76238c236536bbf74450298b40bccba65aaefdc5ad9-4ea34b276d8ccaca362647255e28225be4a33c216c4e97d34fd82798bf1184c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous1")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-521053")[#strong[#text("Anonymous1")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2019")])]

#text("Recall that ")#mi("H_{0}(y) =\\frac{1}{8}\\xi(\\frac{1}{2}+\\frac{iy}{2})")#text(" is real whenever ")#mi("z")#text(" is real.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3de0971aa98986c59e57f76238c236536bbf74450298b40bccba65aaefdc5ad9-4ea34b276d8ccaca362647255e28225be4a33c216c4e97d34fd82798bf1184c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous1")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-521054")[#strong[#text("Anonymous1")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2019")])]

#text("Typo at the end of my previous comment: there should be a ")#mi("y")#text(" instead of a ")#mi("z")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3de0971aa98986c59e57f76238c236536bbf74450298b40bccba65aaefdc5ad9-4ea34b276d8ccaca362647255e28225be4a33c216c4e97d34fd82798bf1184c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous1")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-521058")[#strong[#text("Anonymous1")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2019")])]

#text("In particular, since the RH is equivalent to the statement that all local minima of ")#mi("\\xi(1/2 +it)")#text(" are negative and all of its local maxima are positive, the equality ")#tao-math("4\\pi H_{t}(z)=H_{0}(z+\\alpha \\left|t\\right|^{1/2})=\\frac{1}{2}\\xi\\Big(\\frac{1}{2}+\\Big(\\frac{i(z+\\alpha\\left|t\\right|^{1/2}}{2}\\Big)\\Big)", block: false)#text(" yields a reformulation of the RH in terms of ")#mi("H_t")#text(" ! See my question on MathOverflow ")#link("https://mathoverflow.net/q/339698/145279")[#text("https://mathoverflow.net/q/339698/145279")]#text(". Since the function $H_t$ has proved to be much easier to deal with, a Polymath paper can come out of the above reformulation. However, if it is already known that all local minima of ")#mi("H_{t}")#text(" are negative and all local maxima are negative, then the RH follows. If the opposite is known, then the RH is false.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3de0971aa98986c59e57f76238c236536bbf74450298b40bccba65aaefdc5ad9-4ea34b276d8ccaca362647255e28225be4a33c216c4e97d34fd82798bf1184c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous1")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-521059")[#strong[#text("Anonymous1")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2019")])]

#text("See also my MathOverflow question ")#link("https://mathoverflow.net/q/339698/145279")[#text("https://mathoverflow.net/q/339698/145279")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-559431")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2020")])]

#text("Making a short note here that my student Alexander Dobner has found a simpler proof of Newman’s conjecture that uses complex analysis instead of PDE type arguments, and extends from the zeta function to quite general Dirichlet series: ")#link("https://arxiv.org/abs/2005.05142")[#text("https://arxiv.org/abs/2005.05142")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-559517")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2020")])]

#text("Is it possible to find non-trivial upper bounds also for the corresponding de Bruijn-Newman constants of more general Dirichlet series?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-559698")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2020")])]

#text("Nice question! The original work of Polya already gives an upper bound for the dBN constant of any Dirichlet series obeying a functional equation in terms of the width of a strip known to contain all the zeroes of the (completed) series. It may well be possible to adapt the work of Ki, Kim, and Lee to improve this bound slightly from a non-strict inequality to a strict inequality. The methods of the new paper of Dobner will probably not be of direct use though, it is based on approximations to the modified function ")#mi("\\xi_t")#text(" (related to the function ")#mi("H_t")#text(" in the notation of my paper with Rodgers) that are accurate for ")#mi("t0")#text(", which is the regime one would need to study for the upper bound problem.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/207e157a58092ddf4ff7996841f4560883b1021de51805839b2f13e8337c6eef-7a0629acf743aeac7d699940a3774da7b77bb1c3e4876418f818aa2e6a3cd556.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aaa108")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-633336")[#strong[#text("aaa108")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2021")])]

#text("Does this result fall under any positivity paradigm?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/207e157a58092ddf4ff7996841f4560883b1021de51805839b2f13e8337c6eef-7a0629acf743aeac7d699940a3774da7b77bb1c3e4876418f818aa2e6a3cd556.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aaa108")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-633338")[#strong[#text("aaa108")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2021")])]

#text("By this I mean can you translate this result to the purported approaches through modifying Deligne’s works? If not why and if yes how to think about it?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-670846")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2022")])]

#text("Thanks T.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86517a0250e0d07fac7c67edc4d116ce1bd86e1b770d5e7946e6c679dda5d914-380dfe326e07a18a2285931bc25f78c5ecb42ebbd28c82c174b5f78d9129b37c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/#comment-672384")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2023")])]

#text("If you’re well-versed in basic complex analysis and basic analytic number theory, i kindly invite you to judge this 4-page paper for yourself:")

#link("https://figshare.com/articles/preprint/Untitled_Item/14776146")[#text("https://figshare.com/articles/preprint/Untitled_Item/14776146")]
]
