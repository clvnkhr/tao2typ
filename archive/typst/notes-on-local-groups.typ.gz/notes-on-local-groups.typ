// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/08/17/notes-on-local-groups/
// Converted to Typst by tao2typ: "2026-10-14T09:14:16.591453+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Notes on local groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Notes on local groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 August 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/08/17/notes-on-local-groups/")[#text("https://terrytao.wordpress.com/2011/08/17/notes-on-local-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the fundamental structures in modern mathematics is that of a ")#link("http://en.wikipedia.org/wiki/Group_(mathematics)")[#text("group")]#text(". Formally, a group is a set ")#mi("{G = (G,1,\\cdot,()^{-1})}")#text(" equipped with an identity element ")#mi("{1 = 1_G \\in G}")#text(", a multiplication operation ")#mi("{\\cdot: G \\times G \\rightarrow G}")#text(", and an inversion operation ")#mi("{()^{-1}: G \\rightarrow G}")#text(" obeying the following axioms:")

#list(
[#text("(Closure) If ")#mi("{g, h \\in G}")#text(", then ")#mi("{g \\cdot h}")#text(" and ")#mi("{g^{-1}}")#text(" are well-defined and lie in ")#mi("{G}")#text(". (This axiom is redundant from the above description, but we include it for emphasis.)")],
[#text("(Associativity) If ")#mi("{g, h, k \\in G}")#text(", then ")#mi("{(g \\cdot h) \\cdot k = g \\cdot (h \\cdot k)}")#text(".")],
[#text("(Identity) If ")#mi("{g \\in G}")#text(", then ")#mi("{g \\cdot 1 = 1 \\cdot g = g}")#text(".")],
[#text("(Inverse) If ")#mi("{g \\in G}")#text(", then ")#mi("{g \\cdot g^{-1} = g^{-1} \\cdot g = 1}")#text(".")]
)

#text("One can also consider additive groups ")#mi("{G = (G,0,+,-)}")#text(" instead of multiplicative groups, with the obvious changes of notation. By convention, additive groups are always understood to be abelian, so it is convenient to use additive notation when one wishes to emphasise the abelian nature of the group structure. As usual, we often abbreviate ")#mi("{g \\cdot h}")#text(" by ")#mi("{gh}")#text(" (and ")#mi("{1_G}")#text(" by ")#mi("{1}")#text(") when there is no chance of confusion.")

#text("If furthermore ")#mi("{G}")#text(" is equipped with a topology, and the group operations ")#mi("{\\cdot, ()^{-1}}")#text(" are continuous in this topology, then ")#mi("{G}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Topological_group")[#text("topological group")]#text(". Any group can be made into a topological group by imposing the ")#link("http://en.wikipedia.org/wiki/Discrete_topology")[#text("discrete topology")]#text(", but there are many more interesting examples of topological groups, such as ")#link("http://en.wikipedia.org/wiki/Lie_group")[#text("Lie groups")]#text(", in which ")#mi("{G}")#text(" is not just a topological space, but is in fact a smooth manifold (and the group operations are not merely continuous, but also smooth).")

#text("There are many naturally occuring group-like objects that obey some, but not all, of the axioms. For instance, ")#link("http://en.wikipedia.org/wiki/Monoid")[#text("monoids")]#text(" are required to obey the closure, associativity, and identity axioms, but not the inverse axiom. If we also drop the identity axiom, we end up with a ")#link("http://en.wikipedia.org/wiki/Semigroup")[#text("semigroup")]#text(". ")#link("http://en.wikipedia.org/wiki/Groupoid")[#text("Groupoids")]#text(" do not necessarily obey the closure axiom, but obey (versions of) the associativity, identity, and inverse axioms. And so forth.")

#text("Another group-like concept is that of a ")#emph[#text("local topological group")]#text(" (or ")#emph[#text("local group")]#text(", for short), which is essentially a topological group with the closure axiom omitted (but do not obey the same axioms set as groupoids); they arise primarily in the study of local properties of (global) topological groups, and also in the study of approximate groups in additive combinatorics. Formally, a local group ")#mi("{G = (G, \\Omega, \\Lambda, 1, \\cdot, ()^{-1})}")#text(" is a topological space ")#mi("{G}")#text(" equipped with an identity element ")#mi("{1 \\in G}")#text(", a partially defined but continuous multiplication operation ")#mi("{\\cdot: \\Omega \\rightarrow G}")#text(" for some domain ")#mi("{\\Omega \\subset G \\times G}")#text(", and a partially defined but continuous inversion operation ")#mi("{()^{-1}: \\Lambda \\rightarrow G}")#text(", where ")#mi("{\\Lambda \\subset G}")#text(", obeying the following axioms:")

#list(
[#text("(Local closure) ")#mi("{\\Omega}")#text(" is an open neighbourhood of ")#mi("{G \\times \\{1\\} \\cup \\{1\\} \\times G}")#text(", and ")#mi("{\\Lambda}")#text(" is an open neighbourhood of ")#mi("{1}")#text(".")],
[#text("(Local associativity) If ")#mi("{g, h, k \\in G}")#text(" are such that ")#mi("{(g \\cdot h) \\cdot k}")#text(" and ")#mi("{g \\cdot (h \\cdot k)}")#text(" are both well-defined, then they are equal. (Note however that it may be possible for one of these products to be defined but not the other, in contrast for instance with groupoids.)")],
[#text("(Identity) For all ")#mi("{g \\in G}")#text(", ")#mi("{g \\cdot 1 = 1 \\cdot g = g}")#text(".")],
[#text("(Local inverse) If ")#mi("{g \\in G}")#text(" and ")#mi("{g^{-1}}")#text(" is well-defined, then ")#mi("{g \\cdot g^{-1} = g^{-1} \\cdot g = 1}")#text(". (In particular this, together with the other axioms, forces ")#mi("{1^{-1} = 1}")#text(".)")]
)

#text("We will often refer to ordinary groups as ")#emph[#text("global groups")]#text(" (and topological groups as ")#emph[#text("global topological groups")]#text(") to distinguish them from local groups. Every global topological group is a local group, but not conversely.")

#text("One can consider ")#emph[#text("discrete local groups")]#text(", in which the topology is the discrete topology; in this case, the openness and continuity axioms in the definition are automatic and can be omitted. At the other extreme, one can consider ")#emph[#text("local Lie groups")]#text(", in which the local group ")#mi("{G}")#text(" has the structure of a smooth manifold, and the group operations are smooth. We can also consider ")#emph[#text("symmetric local groups")]#text(", in which ")#mi("{\\Lambda=G}")#text(" (i.e. inverses are always defined). Symmetric local groups have the advantage of ")#emph[#text("local homogeneity")]#text(": given any ")#mi("{g \\in G}")#text(", the operation of left-multiplication ")#mi("{x \\mapsto gx}")#text(" is locally inverted by ")#mi("{x \\mapsto g^{-1} x}")#text(" near the identity, thus giving a homeomorphism between a neighbourhood of ")#mi("{g}")#text(" and a neighbourhood of the identity; in particular, we see that given any two group elements ")#mi("{g, h}")#text(" in a symmetric local group ")#mi("{G}")#text(", there is a homeomorphism between a neighbourhood of ")#mi("{g}")#text(" and a neighbourhood of ")#mi("{h}")#text(". (If the symmetric local group is also Lie, then these homeomorphisms are in fact diffeomorphisms.) This local homogeneity already simplifies a lot of the possible topology of symmetric local groups, as it basically means that the local topological structure of such groups is determined by the local structure at the origin. (For instance, all connected components of a local Lie group necessarily have the same dimension.) It is easy to see that any local group has at least one symmetric open neighbourhood of the identity, so in many situations we can restrict to the symmetric case without much loss of generality.")

#text("A prime example of a local group can be formed by ")#emph[#text("restricting")]#text(" any global topological group ")#mi("{G}")#text(" to an open neighbourhood ")#mi("{U \\subset G}")#text(" of the identity, with the domains")

#align(center)[#tao-fit-display[#mitex("\\Omega := \\{ (g,h) \\in U: g \\cdot h \\in U \\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\Lambda := \\{ g \\in U: g^{-1} \\in U \\};")]]

#text("one easily verifies that this gives ")#mi("{U}")#text(" the structure of a local group (which we will sometimes call ")#mi("{G\\downharpoonright_U}")#text(" to emphasise the original group ")#mi("{G}")#text("). If ")#mi("{U}")#text(" is symmetric (i.e. ")#mi("{U^{-1}=U}")#text("), then we in fact have a symmetric local group. One can also restrict ")#emph[#text("local")]#text(" groups ")#mi("{G}")#text(" to open neighbourhoods ")#mi("{U}")#text(" to obtain a smaller local group ")#mi("{G\\downharpoonright_U}")#text(" by the same procedure (adopting the convention that statements such as ")#mi("{g \\cdot h \\in U}")#text(" or ")#mi("{g^{-1} \\in U}")#text(" are considered false if the left-hand side is undefined). (Note though that if one restricts to non-open neighbourhoods of the identity, then one usually does not get a local group; for instance ")#mi("{[-1,1]}")#text(" is not a local group (why?).)")

#text("Finite subsets of (Hausdorff) groups containing the identity can be viewed as local groups. This point of view turns out to be particularly useful for studying ")#emph[#text("approximate groups")]#text(" in additive combinatorics, a point which I hope to expound more on later. Thus, for instance, the discrete interval ")#mi("{\\{-9,\\ldots,9\\} \\subset {\\bf Z}}")#text(" is an additive symmetric local group, which informally might model an adding machine that can only handle (signed) one-digit numbers. More generally, one can view a local group as an object that behaves like a group near the identity, but for which the group laws (and in particular, the closure axiom) can start breaking down once one moves far enough away from the identity.")

#text("One can formalise this intuition as follows. Let us say that a word ")#mi("{g_1 \\ldots g_n}")#text(" in a local group ")#mi("{G}")#text(" is ")#emph[#text("well-defined in ")#mi("{G}")]#text(" (or ")#emph[#text("well-defined")]#text(", for short) if every possible way of associating this word using parentheses is well-defined from applying the product operation. For instance, in order for ")#mi("{abcd}")#text(" to be well-defined, ")#mi("{((ab)c)d}")#text(", ")#mi("{(a(bc))d}")#text(", ")#mi("{(ab)(cd)}")#text(", ")#mi("{a(b(cd))}")#text(", and ")#mi("{a((bc)d)}")#text(" must all be well-defined. In the preceding example ")#mi("{\\{-9,\\ldots,9\\}}")#text(", ")#mi("{-2+6+5}")#text(" is not well-defined because one of the ways of associating this sum, namely ")#mi("{-2+(6+5)}")#text(", is not well-defined (even though ")#mi("{(-2+6)+5}")#text(" is well-defined).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1 (Iterating the associative law)")]

#list(
[#text("Show that if a word ")#mi("{g_1 \\ldots g_n}")#text(" in a local group is well-defined, then all ways of associating this word give the same answer, and so we can uniquely evaluate ")#mi("{g_1 \\ldots g_n}")#text(" as an element in ")#mi("{G}")#text(".")],
[#text("Give an example of a word ")#mi("{g_1 \\ldots g_n}")#text(" in a local group which has two ways of being associated that are both well-defined, but give ")#emph[#text("different")]#text(" answers. (")#emph[#text("Hint:")]#text(" the local associativity axiom prevents this from happening for ")#mi("{n \\leq 3}")#text(", so try ")#mi("{n=4}")#text(". A small discrete local group will already suffice to give a counterexample; verifying the local group axioms are easier if one makes the domain of definition of the group operations as small as one can get away with while still having the counterexample.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Show that the number of ways to associate a word ")#mi("{g_1 \\ldots g_n}")#text(" is given by the ")#link("http://en.wikipedia.org/wiki/Catalan_number")[#text("Catalan number")]#text(" ")#mi("{C_{n-1} := \\frac{1}{n} \\binom{2n-2}{n-1}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Let ")#mi("{G}")#text(" be a local group, and let ")#mi("{m \\geq 1}")#text(" be an integer. Show that there exists a symmetric open neighbourhood ")#mi("{U_m}")#text(" of the identity such that every word of length ")#mi("{m}")#text(" in ")#mi("{U_m}")#text(" is well-defined in ")#mi("{G}")#text(" (or more succinctly, ")#mi("{U_m^m}")#text(" is well-defined). (Note though that these words will usually only take values in ")#mi("{G}")#text(", rather than in ")#mi("{U_m}")#text(", and also the sets ")#mi("{U_m}")#text(" tend to become smaller as ")#mi("{m}")#text(" increases.)")
]

#text("In many situations (such as when one is investigating the local structure of a global group) one is only interested in the ")#emph[#text("local")]#text(" properties of a (local or global) group. We can formalise this by the following definition. Let us call two local groups ")#mi("{G = (G, \\Omega, \\Lambda, 1_G, \\cdot, ()^{-1})}")#text(" and ")#mi("{G^{\\prime} = (G^{\\prime}, \\Omega^{\\prime}, \\Lambda^{\\prime}, 1_{G^{\\prime}}, \\cdot, ()^{-1})}")#text(" ")#emph[#text("locally identical")]#text(" if they have a common restriction, thus there exists a set ")#mi("{U \\subset G \\cap G^{\\prime}}")#text(" such that ")#mi("{G\\downharpoonright_U = G^{\\prime}\\downharpoonright_U}")#text(" (thus, ")#mi("{1_G = 1_{G^{\\prime}}}")#text(", and the topology and group operations of ")#mi("{G}")#text(" and ")#mi("{G^{\\prime}}")#text(" agree on ")#mi("{U}")#text("). This is easily seen to be an equivalence relation. We call an equivalence class ")#mi("{[G]}")#text(" of local groups a ")#link("http://en.wikipedia.org/wiki/Germ_(mathematics)")[#text("group germ")]#text(".")

#text("Let ")#mi("{{\\mathcal P}}")#text(" be a property of a local group (e.g. abelianness, connectedness, compactness, etc.). We call a group germ ")#emph[#text("locally ")#mi("{{\\mathcal P}}")]#text(" if every local group in that germ has a restriction that obeys ")#mi("{{\\mathcal P}}")#text("; we call a local or global group ")#mi("{G}")#text(" ")#emph[#text("locally ")#mi("{{\\mathcal P}}")]#text(" if its germ is locally ")#mi("{{\\mathcal P}}")#text(" (or equivalently, every open neighbourhood of the identity in ")#mi("{G}")#text(" contains a further neighbourhood that obeys ")#mi("{{\\mathcal P}}")#text("). Thus, the study of local properties of (local or global) groups is subsumed by the study of group germs.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]

#list(
[#text("Show that the above general definition is consistent with the usual definitions of the properties “")#link("http://en.wikipedia.org/wiki/Connectedness")[#text("connected")]#text("” and “")#link("http://en.wikipedia.org/wiki/Locally_connected_space")[#text("locally connected")]#text("” from point-set topology.")],
[#text("Strictly speaking, the above definition is ")#emph[#text("not")]#text(" consistent with the usual definitions of the properties “")#link("http://en.wikipedia.org/wiki/Compact_space")[#text("compact")]#text("” and “")#link("http://en.wikipedia.org/wiki/Locally_compact_space")[#text("local compact")]#text("” from point-set topology because in the definition of local compactness, the compact neighbourhoods are certainly not required to be open. Show however that the point-set topology notion of “locally compact” is equivalent, using the above conventions, to the notion of “locally ")#link("http://en.wikipedia.org/wiki/Relatively_compact_subspace")[#text("precompact")]#text(" inside of an ambient local group”. Of course, this is a much more clumsy terminology, and so we shall abuse notation slightly and continue to use the standard terminology “locally compact” even though it is, strictly speaking, not compatible with the above general convention.")],
[#text("Show that a local group is discrete if and only if it is locally trivial.")],
[#text("Show that a connected global group is abelian if and only if it is locally abelian. (")#emph[#text("Hint:")]#text(" in a connected global group, the only open subgroup is the whole group.)")],
[#text("Show that a global topological group is ")#link("http://en.wikipedia.org/wiki/First-countable_space")[#text("first-countable")]#text(" if and only if it is locally first countable. (By the ")#link("https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/")[#text("Birkhoff-Kakutani theorem")]#text(", this implies that such groups are metrisable if and only if they are locally metrisable.)")],
[#text("Let ")#mi("{p}")#text(" be a prime. Show that the ")#link("http://en.wikipedia.org/wiki/Solenoid_(mathematics)")[#text("solenoid group")]#text(" ")#mi("{{\\bf Z}_p \\times {\\bf R} / {\\bf Z}^\\Delta}")#text(", where ")#mi("{{\\bf Z}_p}")#text(" is the ")#link("http://en.wikipedia.org/wiki/P-adic")[#mi("{p}")#text("-adic integers")]#text(" and ")#mi("{{\\bf Z}^\\Delta := \\{ (n,n): n \\in {\\bf Z}\\}}")#text(" is the diagonal embedding of ")#mi("{{\\bf Z}}")#text(" inside ")#mi("{{\\bf Z}_p \\times {\\bf R}}")#text(", is connected but not locally connected.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One can also study the local properties of groups using ")#link("http://en.wikipedia.org/wiki/Non-standard_analysis")[#text("nonstandard analysis")]#text(". Instead of group germs, one works (at least in the case when ")#mi("{G}")#text(" is first countable) with the ")#link("http://en.wikipedia.org/wiki/Monad_(non-standard_analysis)")[#text("monad")]#text(" ")#mi("{o(G)}")#text(" of the identity element ")#mi("{1_G}")#text(" of ")#mi("{G}")#text(", defined as the nonstandard group elements ")#mi("{g = \\lim_{n \\rightarrow \\alpha} g_n}")#text(" in ")#mi("{{}^* G}")#text(" that are infinitesimally close to the origin in the sense that they lie in every standard neighbourhood of the identity. The monad ")#mi("{o(G)}")#text(" is closely related to the group germ ")#mi("{[G]}")#text(", but has the advantage of being a genuine (global) group, as opposed to an equivalence class of local groups. It is possible to recast most of the results here in this nonstandard formulation; see e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=205854")[#text("the classic text of Robinson")]#text(". However, we will not adopt this perspective here.")
]

#text("A useful fact to know is that Lie structure is local. Call a (global or local) topological group ")#emph[#text("Lie")]#text(" if it can be given the structure of a (global or local) Lie group.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Lie is a local property)")]#text(" ")#metadata(none) <tao-d17300f4c635746da735>#text(" A global topological group ")#mi("{G}")#text(" is Lie if and only if it is locally Lie. The same statement holds for local groups ")#mi("{G}")#text(" as long as they are symmetric.")
]

#text("We sketch a proof of this lemma below the fold. One direction is obvious, as the restriction a global Lie group to an open neighbourhood of the origin is clearly a local Lie group; for instance, the continuous interval ")#mi("{(-10,10) \\subset {\\bf R}}")#text(" is a symmetric local Lie group. The converse direction is almost as easy, but (because we are not assuming ")#mi("{G}")#text(" to be connected) requires one non-trivial fact, namely that local homomorphisms between local Lie groups are automatically smooth; details are provided below the fold.")

#text("As with so many other basic classes of objects in mathematics, it is of fundamental importance to specify and study the ")#emph[#text("morphisms")]#text(" between local groups (and group germs). Given two local groups ")#mi("{G, G^{\\prime}}")#text(", we can define the notion of a ")#emph[#text("(continuous) homomorphism")]#text(" ")#mi("{\\phi: G \\rightarrow G^{\\prime}}")#text(" between them, defined as a continuous map with")

#align(center)[#tao-fit-display[#mitex("\\phi(1_G) = 1_{G^{\\prime}}")]]

#text("such that whenever ")#mi("{g, h \\in G}")#text(" are such that ")#mi("{gh}")#text(" is well-defined, then ")#mi("{\\phi(g)\\phi(h)}")#text(" is well-defined and equal to ")#mi("{\\phi(gh)}")#text("; similarly, whenever ")#mi("{g \\in G}")#text(" is such that ")#mi("{g^{-1}}")#text(" is well-defined, then ")#mi("{\\phi(g)^{-1}}")#text(" is well-defined and equal to ")#mi("{\\phi(g^{-1})}")#text(". (In abstract algebra, the continuity requirement is omitted from the definition of a homomorphism; we will call such maps ")#emph[#text("discrete")]#text(" homomorphisms to distinguish them from the continuous ones which will be the ones studied here.)")

#text("It is often more convenient to work locally: define a ")#emph[#text("local (continuous) homomorphism")]#text(" ")#mi("{\\phi: U \\rightarrow G^{\\prime}}")#text(" from ")#mi("{G}")#text(" to ")#mi("{G^{\\prime}}")#text(" to be a homomorphism from an open neighbourhood ")#mi("{U}")#text(" of the identity to ")#mi("{G^{\\prime}}")#text(". Given two local homomorphisms ")#mi("{\\phi: U \\rightarrow G^{\\prime}}")#text(", ")#mi("{\\tilde \\phi: \\tilde U \\rightarrow \\tilde G^{\\prime}}")#text(" from one pair of locally identical groups ")#mi("{G, \\tilde G}")#text(" to another pair ")#mi("{G^{\\prime}, \\tilde G^{\\prime}}")#text(", we say that ")#mi("{\\phi, \\phi^{\\prime}}")#text(" are ")#emph[#text("locally identical")]#text(" if they agree on some open neighbourhood of the identity in ")#mi("{U \\cap \\tilde U^{\\prime}}")#text(" (note that it does not matter here whether we require openness in ")#mi("{G}")#text(", in ")#mi("{\\tilde G}")#text(", or both). An equivalence class ")#mi("{[\\phi]}")#text(" of local homomorphisms will be called a ")#emph[#text("germ homomorphism")]#text(" (or ")#emph[#text("morphism")]#text(" for short) from the group germ ")#mi("{[G]}")#text(" to the group germ ")#mi("{[G^{\\prime}]}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Show that the class of group germs, equipped with the germ homomorphisms, becomes a ")#link("http://en.wikipedia.org/wiki/Category_(mathematics)")[#text("category")]#text(". (Strictly speaking, because group germs are themselves ")#link("http://en.wikipedia.org/wiki/Class_(set_theory)")[#text("classes")]#text(" rather than sets, the collection of all group germs is a second-order class rather than a class, but this set-theoretic technicality can be resolved in a number of ways (e.g. by restricting all global and local groups under consideration to some fixed “universe”) and should be ignored for this exercise.)")
]

#text("As is usual in category theory, once we have a notion of a morphism, we have a notion of an ")#link("http://en.wikipedia.org/wiki/Isomorphism")[#text("isomorphism")]#text(": two group germs ")#mi("{[G], [G^{\\prime}]}")#text(" are isomorphic if there are germ homomorphisms ")#mi("{\\phi: [G] \\rightarrow [G^{\\prime}]}")#text(", ")#mi("{\\psi: [G^{\\prime}] \\rightarrow [G]}")#text(" that invert each other. Lifting back to local groups, the associated notion is that of ")#emph[#text("local isomorphism")]#text(": two local groups ")#mi("{G, G^{\\prime}}")#text(" are locally isomorphic if there exist local isomorphisms ")#mi("{\\phi: U \\rightarrow G^{\\prime}}")#text(" and ")#mi("{\\psi: U^{\\prime} \\rightarrow G}")#text(" from ")#mi("{G}")#text(" to ")#mi("{G^{\\prime}}")#text(" and from ")#mi("{G^{\\prime}}")#text(" to ")#mi("{G}")#text(" that locally invert each other, thus ")#mi("{\\psi(\\phi(g))=g}")#text(" for ")#mi("{g \\in G}")#text(" sufficiently close to ")#mi("{1_G}")#text(", and ")#mi("{\\phi(\\psi(g))}")#text(" for ")#mi("{g^{\\prime} \\in G^{\\prime}}")#text(" sufficiently close to ")#mi("{1_{G^{\\prime}}}")#text(". Note that all local properties of (global or local) groups that can be defined purely in terms of the group and topological structures will be preserved under local isomorphism. Thus, for instance, if ")#mi("{G, G^{\\prime}}")#text(" are locally isomorphic local groups, then ")#mi("{G}")#text(" is locally connected iff ")#mi("{G^{\\prime}}")#text(" is, ")#mi("{G}")#text(" is locally compact iff ")#mi("{G^{\\prime}}")#text(" is, and (by Lemma ")#link(<tao-d17300f4c635746da735>)[#text("1")]#text(") ")#mi("{G}")#text(" is Lie iff ")#mi("{G^{\\prime}}")#text(" is.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]

#text("Show that the additive global groups ")#mi("{{\\bf R}/{\\bf Z}}")#text(" and ")#mi("{{\\bf R}}")#text(" are locally isomorphic.")

#text("Show that every locally path-connected group ")#mi("{G}")#text(" is locally isomorphic to a path-connected, simply connected group.")
]

#heading(level: 1)[#strong[#text(" — 1. Lie’s third theorem — ")]]

#text("Lie’s fundamental theorems of Lie theory link the Lie group germs to Lie algebras. Observe that if ")#mi("{[G]}")#text(" is a locally Lie group germ, then the tangent space ")#mi("{{\\mathfrak g} := T_1 G}")#text(" at the identity of this germ is well-defined, and is a finite-dimensional vector space. If we choose ")#mi("{G}")#text(" to be symmetric, then ")#mi("{{\\mathfrak g}}")#text(" can also be identified with the left-invariant (say) vector fields on ")#mi("{G}")#text(", which are first-order differential operators on ")#mi("{C^\\infty(M)}")#text(". The ")#link("http://en.wikipedia.org/wiki/Lie_bracket_of_vector_fields")[#text("Lie bracket for vector fields")]#text(" then endows ")#mi("{{\\mathfrak g}}")#text(" with the structure of a ")#link("http://en.wikipedia.org/wiki/Lie_algebra")[#text("Lie algebra")]#text(". It is easy to check that every morphism ")#mi("{\\phi: [G] \\rightarrow [H]}")#text(" of locally Lie germs gives rise (via the derivative map at the identity) to a morphism ")#mi("{D\\phi(1): {\\mathfrak g} \\rightarrow {\\mathfrak h}}")#text(" of the associated Lie algebras. From the Baker-Campbell-Hausdorff formula (which is valid for local Lie groups, as discussed in this previous post) we conversely see that ")#mi("{D\\phi(1)}")#text(" uniquely determines the germ homomorphism ")#mi("{\\phi}")#text(". Thus the derivative map provides a ")#link("http://en.wikipedia.org/wiki/Functor")[#text("covariant functor")]#text(" from the category of locally Lie group germs to the category of (finite-dimensional) Lie algebras. In fact, this functor is an isomorphism, which is part of a fact known as ")#link("http://en.wikipedia.org/wiki/Lie%27s_third_theorem")[#text("Lie’s third theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Lie’s third theorem)")]#text(" For this theorem, all Lie algebras are understood to be finite dimensional (and over the reals).")

#enum(start: 1, 
[#text("Every Lie algebra ")#mi("{{\\mathfrak g}}")#text(" is the Lie algebra of a local Lie group germ ")#mi("{[G]}")#text(", which is unique up to germ isomorphism (fixing ")#mi("{{\\mathfrak g}}")#text(").")],
[#text("Every Lie algebra ")#mi("{{\\mathfrak g}}")#text(" is the Lie algebra of some global connected, simply connected Lie group ")#mi("{G}")#text(", which is unique up to Lie group isomorphism (fixing ")#mi("{{\\mathfrak g}}")#text(").")],
[#text("Every homomorphism ")#mi("{\\Phi: {\\mathfrak g} \\rightarrow {\\mathfrak h}}")#text(" between Lie algebras is the derivative of a unique germ homomorphism ")#mi("{\\phi: [G] \\rightarrow [H]}")#text(" between the associated local Lie group germs.")],
[#text("Every homomorphism ")#mi("{\\Phi: {\\mathfrak g} \\rightarrow {\\mathfrak h}}")#text(" between Lie algebras is the derivative of a unique Lie group homomorphism ")#mi("{\\phi: G \\rightarrow H}")#text(" between the associated global connected, simply connected, Lie groups.")],
[#text("Every local Lie group germ is the germ of a global connected, simply connected Lie group ")#mi("{G}")#text(", which is unique up to Lie group isomorphism. In particular, every local Lie group is locally isomorphic to a global Lie group.")]
)
]

#text("We record the (standard) proof of this theorem below the fold, which is ultimately based on ")#link("http://en.wikipedia.org/wiki/Ado%27s_theorem")[#text("Ado’s theorem")]#text(" and the Baker-Campbell-Hausdorff formula. Lie’s third theorem (which, actually, was proven in full generality by Cartan) demonstrates the equivalence of three categories: the category of finite-dimensonal Lie algebras, the category of local Lie group germs, and the category of connected, simply connected Lie groups.")

#heading(level: 1)[#strong[#text(" — 2. Globalising a local group — ")]]

#text("Many properties of a local group improve after passing to a smaller neighbourhood of the identity. Here are some simple examples:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Let ")#mi("{G}")#text(" be a local group.")

#list(
[#text("Give an example to show that ")#mi("{G}")#text(" does not necessarily obey the cancellation laws")

#metadata(none) <tao-2374d91794b79f4fb4ec>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("gk=hk \\implies g=h; \\quad kg=kh \\implies g=h")]]

#text("for ")#mi("{g,h,k \\in G}")#text(" (with the convention that statements such as ")#mi("{gk=hk}")#text(" are false if either side is undefined). However, show that there exists an open neighbourhood ")#mi("{U}")#text(" of ")#mi("{G}")#text(" within which the cancellation law holds.")],
[#text("Repeat the previous part, but with the cancellation law ")#link(<tao-2374d91794b79f4fb4ec>)[#text("(1)")]#text(" replaced by the inversion law")

#metadata(none) <tao-418df28d06f462b0eb70>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("(gh)^{-1} = h^{-1} g^{-1}")]]

#text("for any ")#mi("{g,h \\in G}")#text(" for which both sides are well-defined.")],
[#text("Repeat the previous part, but with the inversion law replaced by the involution law")

#metadata(none) <tao-23c47da8df8ff35eeed9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("(g^{-1})^{-1} = g")]]

#text("for any ")#mi("{g}")#text(" for which the left-hand side is well-defined.")]
)
]

#text("Note that the counterexamples in the above exercise demonstrate that not every local group is the restriction of a global group, because global groups (and hence, their restrictions) always obey the cancellation law ")#link(<tao-2374d91794b79f4fb4ec>)[#text("(1)")]#text(", the inversion law ")#link(<tao-418df28d06f462b0eb70>)[#text("(2)")]#text(", and the involution law ")#link(<tao-23c47da8df8ff35eeed9>)[#text("(3)")]#text(". Another way in which a local group can fail to come from a global group is if it contains relations which can interact in a “global’ way to cause trouble, in a fashion which is invisible at the local level. For instance, consider the open unit cube ")#mi("{(-1,1)^3}")#text(", and consider four points ")#mi("{a_1, a_2, a_3, a_4}")#text(" in this cube that are close to the upper four corners ")#mi("{(1,1,1), (1,1,-1), (1,-1,1), (1,-1,-1)}")#text(" of this cube respectively. Define an equivalence relation ")#mi("{\\sim}")#text(" on this cube by setting ")#mi("{x \\sim y}")#text(" if ")#mi("{x, y \\in (-1,1)^3}")#text(" and ")#mi("{x-y}")#text(" is equal to either ")#mi("{0}")#text(" or ")#mi("{\\pm 2a_i}")#text(" for some ")#mi("{i=1,\\ldots,4}")#text(". Note that this indeed an equivalence relation if ")#mi("{a_1,a_2,a_3,a_4}")#text(" are close enough to the corners (as this forces all non-trivial combinations ")#mi("{\\pm 2a_i \\pm 2a_j}")#text(" to lie outside the doubled cube ")#mi("{(-2,2)^3}")#text("). The quotient space ")#mi("{(-1,1)^3/\\sim}")#text(" (which is a cube with bits around opposite corners identified together) can then be seen to be a symmetric additive local Lie group, but will usually not come from a global group. Indeed, it is not hard to see that if ")#mi("{(-1,1)^3/\\sim}")#text(" is the restriction of a global group ")#mi("{G}")#text(", then ")#mi("{G}")#text(" must be a Lie group with Lie algebra ")#mi("{{\\bf R}^3}")#text(" (by Lemma ")#link(<tao-d17300f4c635746da735>)[#text("1")]#text("), and so the connected component ")#mi("{G^\\circ}")#text(" of ")#mi("{G}")#text(" containing the identity is isomorphic to ")#mi("{{\\bf R}^3/\\Gamma}")#text(" for some sublattice ")#mi("{\\Gamma}")#text(" of ")#mi("{{\\bf R}^3}")#text(" that contains ")#mi("{a_1,a_2,a_3,a_4}")#text("; but for generic ")#mi("{a_1,a_2,a_3,a_4}")#text(", there is no such lattice, as the ")#mi("{a_i}")#text(" will generate a dense subset of ")#mi("{{\\bf R}^3}")#text(". (The situation here is somewhat analogous to a number of famous Escher prints, such as ")#link("http://en.wikipedia.org/wiki/Ascending_and_Descending")[#text("Ascending and Descending")]#text(", in which the geometry is locally consistent but globally inconsistent.) We will give this sort of argument in more detail below the fold (see the proof of Proposition ")#link(<tao-ef431f36f939da403b8a>)[#text("7")]#text(").")

#text("Nevertheless, the space ")#mi("{(-1,1)^3/\\sim}")#text(" is still ")#emph[#text("locally")]#text(" isomorphic to a global Lie group, namely ")#mi("{{\\bf R}^3}")#text("; for instance, the open neighbourhood ")#mi("{(-0.5,0.5)^3/\\sim}")#text(" is isomorphic to ")#mi("{(-0.5,0.5)^3}")#text(", which is an open neighbourhood of ")#mi("{{\\bf R}^3}")#text(". More generally, Lie’s third theorem tells us that any local Lie group is locally isomorphic to a global Lie group.")

#text("Let us call a local group ")#emph[#text("globalisable")]#text(" if it is locally isomorphic to a global group; thus Lie’s third theorem tells us that every local Lie group is globalisable. Thanks to ")#link("http://www.ams.org/mathscinet-getitem?mr=2680491")[#text("Goldbring’s")]#text(" solution to the local version of Hilbert’s fifth problem, we also know that locally Euclidean local groups are globalisable. A modification of this argument ")#link("http://www.ams.org/mathscinet-getitem?mr=2743102")[#text("by van den Dries and Goldbring")]#text(" shows in fact that every locally compact local group is globalisable.")

#text("In view of these results, it is tempting to conjecture that ")#emph[#text("all")]#text(" local groups are globalisable;; among other things, this would simplify the proof of Lie’s third theorem (and of the local version of Hilbert’s fifth problem). Unfortunately, this claim as stated is false:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(" ")#metadata(none) <tao-efe899c74558f20b08bb>#text(" There exists local groups ")#mi("{G}")#text(" which are not globalisable.")
]

#text("The counterexamples used to establish Theorem ")#link(<tao-efe899c74558f20b08bb>)[#text("3")]#text(" are remarkably delicate; the first example I know of is due ")#link("http://www.ams.org/mathscinet-getitem?mr=160851")[#text("to van Est and Korthagen")]#text(". One reason for this, of course, is that the previous results prevents one from using any local Lie group, or even a locally compact group as a counterexample. We will present a (somewhat complicated) example below, based on the unit ball in the infinite-dimensional Banach space ")#mi("{\\ell^\\infty({\\bf N}^2)}")#text(".")

#text("However, there are certainly many situations in which we can globalise a local group. For instance, this is the case if one has a locally faithful representation of that local group inside a global group:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Faithful representation implies globalisability)")]#text(" ")#metadata(none) <tao-ca27e538f3b183aad14e>#text(" Let ")#mi("{G}")#text(" be a local group, and suppose there exists an injective local homomorphism ")#mi("{\\phi: U \\rightarrow H}")#text(" from ")#mi("{G}")#text(" into a global topological group ")#mi("{H}")#text(" with ")#mi("{U}")#text(" symmetric. Then ")#mi("{U}")#text(" is isomorphic to the restriction of a global topological group to an open neighbourhood of the identity; in particular, ")#mi("{G}")#text(" is globalisable.")
]

#text("The material here is based in part on ")#link("http://www.ams.org/mathscinet-getitem?mr=1406004")[#text("this paper of Olver")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2680491")[#text("this paper of Goldbring")]#text(".")

#metadata(none) <tao-d8cc920a0c0fa088a93d>

#heading(level: 1)[#strong[#text(" — 3. Globalisation — ")]]

#text("We begin by proving Lemma ")#link(<tao-ca27e538f3b183aad14e>)[#text("4")]#text(". Let ")#mi("{G, \\phi, U, H}")#text(" be as in that lemma. The set ")#mi("{\\phi(U)}")#text(" generates a subgroup ")#mi("{\\langle \\phi(U) \\rangle}")#text(" of ")#mi("{H}")#text(", which contains an embedded copy ")#mi("{\\phi(U)}")#text(" of ")#mi("{U}")#text(". It is then tempting to restrict the topology of ")#mi("{H}")#text(" to that of ")#mi("{\\langle \\phi(U) \\rangle}")#text(" to give ")#mi("{\\langle \\phi(U) \\rangle}")#text(" the structure of a global topological group and then declare victory, but the difficulty is that ")#mi("{\\phi(U)}")#text(" need not be an open subset of ")#mi("{\\langle \\phi(U) \\rangle}")#text(", as the following key example demonstrates.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" Take ")#mi("{G = U = (-1,1)}")#text(", ")#mi("{H = ({\\bf R}/{\\bf Z})^2}")#text(", and ")#mi("{\\phi(t) := (t,\\alpha t) \\text{ mod } {\\bf Z}^2}")#text(", where ")#mi("{\\alpha}")#text(" is an irrational number (e.g. ")#mi("{\\alpha = \\sqrt{2}}")#text("). Then ")#mi("{\\langle \\phi(U) \\rangle}")#text(" is the dense subgroup ")#mi("{\\{ (t,\\alpha t) \\text{ mod } {\\bf Z}^2: t \\in {\\bf R} \\}}")#text(" of ")#mi("{({\\bf R}/{\\bf Z})^2}")#text(", which is not locally isomorphic to ")#mi("{G}")#text(" if endowed with the topology inherited from ")#mi("{({\\bf R}/{\\bf Z})^2}")#text(" (for instance, ")#mi("{\\langle \\phi(U)\\rangle}")#text(" is not locally connected in this topology, whereas ")#mi("{G}")#text(" is). Also, ")#mi("{\\phi(U)}")#text(", while homeomorphic to ")#mi("{U}")#text(", is not an open subset of ")#mi("{\\langle \\phi(U) \\rangle}")#text(". Thus we see that the “global” behaviour of ")#mi("{\\phi(U)}")#text(", as captured by the group ")#mi("{\\langle \\phi(U) \\rangle}")#text(", can be rather different from the “local” structure of ")#mi("{\\phi(U)}")#text(".")
]

#text("However, the problem can be easily resolved by giving ")#mi("{\\langle \\phi(U) \\rangle}")#text(" a different topology, as follows. We use the sets ")#mi("{\\{ \\phi(W): 1 \\in W \\subset U, W \\text{ open} \\}}")#text(" as a neighbourhood base for the identity in ")#mi("{\\langle \\phi(U) \\rangle}")#text(", and their left-translates ")#mi("{\\{ g\\phi(W): 1 \\in W \\subset U, W \\text{ open} \\}}")#text(" as a neighbourhood base for any other element ")#mi("{g}")#text(" of ")#mi("{\\langle \\phi(U) \\rangle}")#text(". This is easily seen to generate a topology. To show that the group operations remain continuous in this topology, the main task is to show that the conjugation operations ")#mi("{x \\mapsto gxg^{-1}}")#text(" are continuous with respect to the neighbourhood base at the identity, in the sense that for every open neighbourhood ")#mi("{W}")#text(" of the identity in ")#mi("{U}")#text(" and every ")#mi("{g \\in \\langle \\phi(U) \\rangle}")#text(", there exists an open neighbourhood ")#mi("{W^{\\prime}}")#text(" of the identity such that ")#mi("{\\phi(W^{\\prime}) \\subset g \\phi(W) g^{-1}}")#text(". But for ")#mi("{g \\in \\phi(U)}")#text(" this is clear from the injective local homomorphism properties of ")#mi("{\\phi}")#text(" (after shrinking ")#mi("{W}")#text(" small enough that ")#mi("{g \\phi(W) g^{-1}}")#text(" will still fall in ")#mi("{\\phi(U)}")#text("), and then an induction shows the same is true for ")#mi("{g}")#text(" in any product set ")#mi("{\\phi(U)^n}")#text(" of ")#mi("{\\phi(U)}")#text(", and hence in all of ")#mi("{\\langle \\phi(U) \\rangle}")#text(". (It is instructive to follow through this argument for the example given above.)")

#text("There is another characterisation of globalisability, ")#link("http://www.ams.org/mathscinet-getitem?mr=8814")[#text("due to Mal’cev")]#text(", which is stronger than Lemma ")#link(<tao-ca27e538f3b183aad14e>)[#text("4")]#text(", but this strengthening is usually not needed in applications. Call a local group ")#mi("{G}")#text(" ")#emph[#text("globally associative")]#text(" if, whenever ")#mi("{g_1,\\ldots,g_n \\in G}")#text(" and there are two ways to associate the product ")#mi("{g_1 \\ldots g_n}")#text(" which are individually well-defined, then the value obtained by these two associations are equal to each other. This implies but is stronger than local associativity (which only covers the cases ")#mi("{n\\leq 3}")#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5 (Globalisation criterion)")]#text(" ")#metadata(none) <tao-22c39fc6548220e9804e>#text(" Let ")#mi("{G}")#text(" be a symmetric local group. Then ")#mi("{G}")#text(" is isomorphic to (a restriction of) an open symmetric neighbourhood of the identity in a global topological group if and only if it is globally associative.")
]

#text("By “restriction of an open symmetric neighbourhood of the identity ")#mi("{U}")#text("“, I mean the local group formed from ")#mi("{U}")#text(" by restricting the set ")#mi("{\\Omega \\subset U \\times U}")#text(" of admissible products for the local group law to some open neighbourhood of ")#mi("{\\{1\\} \\times U \\cup U \\times \\{1\\}}")#text(" in ")#mi("{U \\times U}")#text(".")

#emph[#text("Proof:")]#text(" The “only if” direction is clear, so now suppose that ")#mi("{G}")#text(" is a globally associative symmetric local group. Let us call a formal product ")#mi("{g_1 \\ldots g_n}")#text(" with ")#mi("{g_1,\\ldots,g_n \\in G}")#text(" ")#emph[#text("weakly well-defined")]#text(" if there is at least one way to associate the product so that it can be defined in ")#mi("{G}")#text(" (this is opposed to actual well-definedness of ")#mi("{g_1 \\ldots g_n}")#text(", which requires ")#emph[#text("all")]#text(" associations to be well-defined). By global associativity, the product ")#mi("{g_1 \\ldots g_n}")#text(" has a unique evaluation in ")#mi("{G}")#text(" whenever it is weakly well-defined.")

#text("Let ")#mi("{F = (F, *)}")#text(" be the (discrete) free group generated by the elements of ")#mi("{G}")#text(" (now viewed merely as a discrete set), thus each element of ")#mi("{F}")#text(" can be expressed as a formal product ")#mi("{g_1^{*\\epsilon_1} * \\ldots * g_n^{*\\epsilon_n}}")#text(" of elements ")#mi("{g_1,\\ldots,g_n}")#text(" in ")#mi("{G}")#text(" and their formal inverses ")#mi("{g_1^{*-1},\\ldots,g_n^{*-1}}")#text(", where ")#mi("{\\epsilon_1,\\ldots,\\epsilon_n \\in \\{-1,+1\\}}")#text(", and ")#mi("{G}")#text(" can be viewed (only as a set, not as a local group) as a subset of ")#mi("{F}")#text(". Let ")#mi("{N}")#text(" be the set of elements in ")#mi("{F}")#text(" that have at least one representation (not necessarily reduced) of the form ")#mi("{g_1^{*\\epsilon_1} * \\ldots * g_n^{*\\epsilon_n}}")#text(" such that ")#mi("{g_1,\\ldots,g_n \\in G}")#text(" and ")#mi("{\\epsilon_1,\\ldots,\\epsilon_n \\in \\{-1,+1\\}}")#text(" with ")#mi("{g_1^{\\epsilon_1} \\ldots g_n^{\\epsilon_n}}")#text(" weakly well-defined and evaluating to the identity in ")#mi("{G}")#text(". It is easy to see that ")#mi("{N}")#text(" is a normal subgroup of ")#mi("{F}")#text(", and so we may form the quotient group ")#mi("{F/N}")#text(" and the quotient map ")#mi("{\\pi: F \\rightarrow F/N}")#text(". We claim ")#mi("{\\pi}")#text(" is injective on ")#mi("{G}")#text(", and so ")#mi("{G}")#text(" is isomorphic (as a discrete local group) to ")#mi("{\\pi(G)}")#text(". To see this, suppose for contradiction that there are distinct ")#mi("{g,h \\in G}")#text(" such that ")#mi("{\\pi(g)=h}")#text(", thus ")#mi("{g * g_1^{*\\epsilon_1} * \\ldots * g_n^{*\\epsilon_n} = h}")#text(" for some ")#mi("{g_1^{*\\epsilon_1} * \\ldots * g_n^{*\\epsilon_n} \\in N}")#text(". As this identity takes place in the free group ")#mi("{F}")#text(", this implies that the formal word ")#mi("{g * g_1^{*\\epsilon_1} * \\ldots * g_n^{*\\epsilon_n}}")#text(" can be reduced to the generator ")#mi("{h}")#text(" of ")#mi("{G}")#text(" by a finite number of operations in which an adjacent pair of the form ")#mi("{k * k^{*-1}}")#text(" or ")#mi("{k^{*-1} * k}")#text(" for some ")#mi("{k \\in G}")#text(", or a singleton of the form ")#mi("{1}")#text(", is deleted. In particular, this implies that ")#mi("{g g_1^{\\epsilon_1} \\ldots g_n^{\\epsilon_n}}")#text(" is weakly well-defined and evaluates to ")#mi("{h}")#text(" in ")#mi("{G}")#text(". On other hand, as ")#mi("{g_1^{*\\epsilon_1} * \\ldots * g_n^{*\\epsilon_n} \\in N}")#text(", we also see (by associating in a different way) that ")#mi("{g g_1^{\\epsilon_1} \\ldots g_n^{\\epsilon_n}}")#text(" is weakly well-defined and evaluates to ")#mi("{g}")#text(" in ")#mi("{G}")#text(". This contradicts global associativity, and the claim follows.")

#text("To conclude the proof, we need to place a topology on ")#mi("{F/N}")#text(" that makes ")#mi("{G}")#text(" homeomorphic to ")#mi("{G}")#text(". This can be done by taking the sets ")#mi("{x \\pi(W)}")#text(", with ")#mi("{W}")#text(" an open neighbourhood of the identity in ")#mi("{G}")#text(", as a neighbourhood base for each ")#mi("{x \\in F/N}")#text(". By arguing as in the proof of Lemma ")#link(<tao-ca27e538f3b183aad14e>)[#text("4")]#text(" one can verify that this generates a topology that makes ")#mi("{F/N}")#text(" a topological group, and makes ")#mi("{G}")#text(" homeomorphic to ")#mi("{\\pi(G)}")#text("; we leave the details as an exercise. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Complete the proof of the above proposition.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Use Proposition ")#link(<tao-22c39fc6548220e9804e>)[#text("5")]#text(" to give an alternate proof of Proposition ")#link(<tao-ca27e538f3b183aad14e>)[#text("4")]#text(".")
]

#heading(level: 1)[#strong[#text(" — 4. Globalising Lie structure — ")]]

#text("To prove Theorem ")#link(<tao-d17300f4c635746da735>)[#text("1")]#text(" we need the following basic lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (Continuity implies smoothness for local Lie homomorphisms)")]#text(" Let ")#mi("{\\phi: U \\rightarrow H}")#text(" be a local homomorphism between two local Lie groups ")#mi("{G, H}")#text(". Then ")#mi("{\\phi}")#text(" is smooth near the origin. If ")#mi("{U}")#text(" is symmetric, then ")#mi("{\\phi}")#text(" is in fact smooth on all of ")#mi("{U}")#text(".")
]

#emph[#text("Proof:")]#text(" Define a ")#emph[#text("local one-parameter subgroup")]#text(" of ")#mi("{G}")#text(" to be a germ homomorphism ")#mi("{f}")#text(" from the additive germ ")#mi("{[{\\bf R}]}")#text(" to ")#mi("{[G]}")#text("; for any sufficiently small ")#mi("{\\epsilon > 0}")#text(", this is associated with a continuous homomorphism ")#mi("{f: (-\\epsilon,\\epsilon) \\rightarrow G}")#text(" of local groups. Note that for any sufficiently small ")#mi("{t}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("f(t) = f(t/n)^n")]]

#text("for all natural numbers ")#mi("{n \\geq 1}")#text(". Working in exponential coordinates in a sufficiently small neighbourhood of ")#mi("{G}")#text(", for which we have a smooth logarithm map to the Lie algebra ")#mi("{{\\mathfrak g}}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\log f(t) = n \\log f(t/n)")]]

#text("for all sufficiently small ")#mi("{t}")#text(", which implies in particular that")

#align(center)[#tao-fit-display[#mitex("\\log f(t) = \\frac{t}{t^{\\prime}} \\log f(t^{\\prime})")]]

#text("for all sufficiently small positive ")#mi("{t, t^{\\prime}}")#text(" with ")#mi("{t/t^{\\prime}}")#text(" rational. By continuity we may omit the rationality hypothesis, and we conclude that there exists a unique ")#mi("{X \\in {\\mathfrak g}}")#text(" such that ")#mi("{\\log f(t) = t X}")#text(" for all small positive ")#mi("{t}")#text("; since ")#mi("{f(-t) = f(t)^{-1}}")#text(" for sufficiently small ")#mi("{t}")#text(" as well, this is also true for small negative ")#mi("{t}")#text(". Thus we have ")#mi("{f(t) = \\exp(tX)}")#text(" for all sufficiently small ")#mi("{t}")#text(". Conversely, every element ")#mi("{X}")#text(" of ")#mi("{{\\mathfrak g}}")#text(" generates a local one-parameter subgroup in this fashion.")

#text("The map ")#mi("{\\phi}")#text(" clearly takes local one-parameter subgroups of ")#mi("{G}")#text(" to one-parameter subgroups of ")#mi("{H}")#text(", thus defining a “derivative” map ")#mi("{D\\phi(1): {\\mathfrak g} \\rightarrow {\\mathfrak h}}")#text(". It is easy to see that this map is continuous; using the law")

#align(center)[#tao-fit-display[#mitex("\\exp(X+Y) = \\lim_{n \\rightarrow \\infty} (\\exp(X/n) \\exp(Y/n))^n")]]

#text("we also verify that this map is an additive homomorphism, and is hence linear (and in particular is smooth). For sufficiently small ")#mi("{g}")#text(", ")#mi("{\\phi}")#text(" is then given by the formula ")#metadata(none) <tao-4a7f92ea5b21944b4573>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\phi(g) = \\exp( D\\phi(1)( \\log g ) )")]]

#text("which is manifestly smooth near the identity. If ")#mi("{U}")#text(" is symmetric, we can then use local homogeneity to make ")#mi("{\\phi}")#text(" symmetric at all points of ")#mi("{U}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" By using the Baker-Campbell-Hausdorff formula, we can upgrade the smoothness here to real analyticity.")
]

#text("Now we sketch the proof of Theorem ")#link(<tao-d17300f4c635746da735>)[#text("1")]#text(". Clearly, every global Lie group is locally Lie as well. Conversely, if ")#mi("{G}")#text(" is locally Lie, then we have at least one smooth coordinate chart for ")#mi("{G}")#text(" near the origin. Also, from the above lemma, all conjugation maps ")#mi("{x \\mapsto gxg^{-1}}")#text(" for a given ")#mi("{g \\in G}")#text(" are smooth for a sufficiently small neighbourhood of the origin in this chart (we allow this neighbourhood to depend on ")#mi("{g}")#text(", but for ")#mi("{g}")#text(" in a compact set it is easy to see that we can take the neighbourhood to be uniform). We can translate the smooth chart around by left-invariance to give an atlas for all of ")#mi("{G}")#text("; the smooth compatibility of the charts with each other is easily established using the local smoothness of the conjugation map (shrinking the chart if necessary first). The smoothness of the group operations are proven similarly.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Fill out the details in the above proof.")
]

#text("Now we can prove Lie’s third theorem. Part 5 follows from Parts 1-4, so we focus on the first four parts. We first dispose of uniqueness, which is easy. From the formula ")#link(<tao-4a7f92ea5b21944b4573>)[#text("(4)")]#text(" we see that ")#mi("{D\\phi(1)}")#text(" uniquely determines ")#mi("{\\phi}")#text(" locally, which gives the uniqueness claims in Part 3. A monodromy argument then shows that ")#mi("{\\phi}")#text(" is also uniquely determined if ")#mi("{G}")#text(" is connected and simply connected, giving the uniqueness claim in Part 4. The uniqueness claims in Parts 1-2 then follow from those in Parts 3-4.")

#text("Now we turn to existence. We establish this first for Parts 1 and 2. Let ")#mi("{{\\mathfrak g}}")#text(" be a Lie algebra. Applying ")#link("http://en.wikipedia.org/wiki/Ado%27s_theorem")[#text("Ado’s theorem")]#text(" (discussed in ")#link("https://terrytao.wordpress.com/2011/05/10/ados-theorem/")[#text("this blog post")]#text("), we can identify ")#mi("{{\\mathfrak g}}")#text(" with a subalgebra of the Lie algebra ")#mi("{{\\mathfrak gl}_n({\\bf R})}")#text(" for some finite ")#mi("{n}")#text(". If ")#mi("{U}")#text(" is a small symmetric neighbourhood of the identity in ")#mi("{{\\mathfrak g}}")#text(", we can then form the exponential ")#mi("{\\exp(U)}")#text(", which (as the exponential map is a local diffeomorphism) is a submanifold of ")#mi("{GL_n({\\bf R})}")#text(". Applying the Baker-Campbell-Hausdorff formula in ")#mi("{GL_n({\\bf R})}")#text(", we see that ")#mi("{\\exp(U)}")#text(" is a local group (because ")#mi("{\\exp(X)^{-1} = \\exp(-X)}")#text(", and ")#mi("{\\exp(X) \\exp(Y)}")#text(" will lie in ")#mi("{\\exp(U)}")#text(" for ")#mi("{X}")#text(" in ")#mi("{U}")#text(" and ")#mi("{Y}")#text(" sufficiently small, or vice versa). This already gives Part 1; as ")#mi("{\\exp(U)}")#text(" clearly has a faithful representation in ")#mi("{GL_n({\\bf R})}")#text(", we may use Lemma ")#link(<tao-ca27e538f3b183aad14e>)[#text("4")]#text(" (and Lemma ")#link(<tao-d17300f4c635746da735>)[#text("1")]#text(") to extend ")#mi("{\\exp(U)}")#text(" to a global Lie group, giving Part 2.")

#text("Existence in Part 3 follows from ")#link(<tao-4a7f92ea5b21944b4573>)[#text("(4)")]#text(" and the Baker-Campbell-Hausdorff formula; extending the germ homorphism to a Lie group homomorphism on the connected, simply connected Lie group ")#mi("{G}")#text(" then follows by a standard monodromy argument, giving Part 4. This completes the proof of Lie’s third theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" The full strength of Ado theorem was not needed here. For instance, knowing Ado’s theorem for nilpotent Lie algebras already suffices to establish Lie’s third theorem in the nilpotent case. By considering the free nilpotent groups and letting the step go to infinity, this shows that the Baker-Campbell-Hausdorff-Dynkin formula is formally associative (and hence associative, due to the absolute convergence of the formula), which already suffices to construct the local Lie group and thence the global Lie group.")

#text("On the other hand, it is possible to eliminate the reliance on the Baker-Campbell-Hausdorff formula by using ")#link("http://en.wikipedia.org/wiki/Frobenius_theorem_(differential_topology)")[#text("Frobenius’s theorem")]#text(" to construct the local Lie group instead; we omit the details.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" The above argument also reveals one advantage of local Lie groups over global ones; local Lie groups are locally linearisable (in the sense that they are isomorphic to a local subgroup of a linear group), whereas global Lie groups need not be globally linearisable, as discussed in ")#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/")[#text("this previous post")]#text(".")
]

#heading(level: 1)[#strong[#text(" — 5. A non-globalisable group — ")]]

#text("We now prove Theorem ")#link(<tao-efe899c74558f20b08bb>)[#text("3")]#text(". We begin with a preliminary construction, which gives a local group that has a fixed small neighbourhood that cannot arise from a global group.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7 (Preliminary counterexample)")]#text(" ")#metadata(none) <tao-ef431f36f939da403b8a>#text(" For any ")#mi("{m \\geq 1}")#text(", there exists an equivalence relation ")#mi("{\\sim_m}")#text(" on the open unit ball ")#mi("{B(0,1)}")#text(" of ")#mi("{\\ell^\\infty({\\bf N})}")#text(" which gives ")#mi("{B(0,1)/\\sim_m}")#text(" the structure of a local group, but such that ")#mi("{B(0,1/m)/\\sim_m}")#text(" is not isomorphic (even as a discrete local group) to a subset of a global group.")
]

#emph[#text("Proof:")]#text(" We will use a probabilistic construction, mimicking the three-dimensional example ")#mi("{(-1,1)^3/\\sim}")#text(" from the introduction. Fix ")#mi("{m}")#text(", and let ")#mi("{N}")#text(" be a large integer (depending on ")#mi("{m}")#text(") to be chosen later. We identify the ")#mi("{N}")#text("-dimensional cube ")#mi("{(-1,1)^N}")#text(" with the unit ball in ")#mi("{\\ell^\\infty(\\{1,\\ldots,N\\})}")#text(", which embeds in the unit ball in ")#mi("{\\ell^\\infty({\\bf N})}")#text(" via extension by zero. Let ")#mi("{b_1, \\ldots, b_{N+1} \\in \\{-1,1\\}^N}")#text(" be randomly chosen corners of this cube. A simple application of the union bound shows that with probability approaching ")#mi("{1}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(", we have ")#mi("{b_i \\neq \\pm b_j}")#text(" for all ")#mi("{i < j}")#text(", but also that for any ")#mi("{1 \\leq i_1 < \\ldots < i_{100m} \\leq N}")#text(" and any choice of signs ")#mi("{\\epsilon_1,\\ldots,\\epsilon_{100m}}")#text(", the vectors ")#mi("{\\epsilon_1 b_{i_1},\\ldots,\\epsilon_{100m} b_{i_{100m}}}")#text(" agree on at least one coordinate. As a corollary of this, we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{i=1}^{N+1} n_i b_i \\right\\|_{\\ell^\\infty} = \\sum_{i=1}^{N+1} \\left|n_i\\right|", block: true)]]

#text("for any integers ")#mi("{n_1,\\ldots,n_{N+1}}")#text(" with ")#tao-math("{\\sum_{i=1}^{N+1} \\left|n_i\\right| \\leq 100m}", block: false)#text(".")

#text("Let ")#mi("{\\epsilon > 0}")#text(" be a small number (depending on ")#mi("{m}")#text(", ")#mi("{N}")#text(") to be chosen later. We let ")#mi("{a_i}")#text(" be an element of ")#mi("{(-1,1)^N}")#text(" which is within distance ")#mi("{\\epsilon}")#text(" of ")#mi("{b_i}")#text(", then we have ")#metadata(none) <tao-b704817d754a29fcdb51>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| \\sum_{i=1}^{N+1} n_i a_i \\right\\|_{\\ell^\\infty} = \\sum_{i=1}^{N+1} \\left|n_i\\right| + O(\\epsilon)", block: true)]]

#text("(allowing implied constants to depend on ")#mi("{m,N}")#text(") for ")#mi("{n_1,\\ldots,n_{N+1}}")#text(" as above. By generically perturbing the ")#mi("{a_1,\\ldots,a_{N+1}}")#text(", we may assume that they are ")#emph[#text("noncommensurable")]#text(" in the sense that span a dense subset of ")#mi("{{\\bf R}^N}")#text(". In particular, the ")#mi("{a_1,\\ldots,a_{N+1}}")#text(" are linearly independent over ")#mi("{{\\bf Z}}")#text(".")

#text("We now define an equivalence relation ")#mi("{\\sim_m}")#text(" on ")#mi("{B(0,1)}")#text(" by defining ")#mi("{f \\sim_m g}")#text(" whenever ")#metadata(none) <tao-f34f5acaf141b5e1fa31>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("f - g = \\frac{1}{2m} \\sum_{i=1}^{N+1} n_i a_i")]]

#text("for some integers ")#mi("{n_1,\\ldots,n_N}")#text(" with ")#tao-math("{\\sum_{i=1}^{N+1} \\left|n_i\\right| \\leq 100m}", block: false)#text(". Since ")#tao-math("{\\left\\|f-g\\right\\|_{\\ell^\\infty} \\leq 2}", block: false)#text(", we see from ")#link(<tao-b704817d754a29fcdb51>)[#text("(5)")]#text(" (if ")#mi("{\\epsilon}")#text(" is small enough) that the equation ")#link(<tao-f34f5acaf141b5e1fa31>)[#text("(6)")]#text(" can only be true if ")#tao-math("{\\sum_{i=1}^{N+1} \\left|n_i\\right| \\leq 4m}", block: false)#text(". As a consequence, we see that ")#mi("{\\sim_m}")#text(" is a equivalence relation. We can then form the quotient space ")#mi("{B(0,1)/\\sim_m}")#text(". Observe that if ")#mi("{f_1,f_2,g_1,g_2 \\in B(0,1)}")#text(" are such that ")#mi("{f_1 \\sim_m g_1}")#text(", ")#mi("{f_2 \\sim_m g_2}")#text(", and ")#mi("{f_1+f_2, g_1+g_2 \\in B(0,1)}")#text(", then we also have ")#mi("{f_1+f_2 \\sim_m g_1+g_2}")#text(". Thus ")#mi("{B(0,1)/\\sim_m}")#text(" has an addition operation ")#mi("{+}")#text(", defined on those equivalence classes ")#mi("{[f], [g] \\in B(0,1)/\\sim_m}")#text(" for which ")#mi("{f+g \\in B(0,1)}")#text(" for at least one representative ")#mi("{f, g}")#text(" of ")#mi("{[f], [g]}")#text(" respectively. One easily verifies that this gives ")#mi("{B(0,1)/\\sim_m}")#text(" the structure of a local group.")

#text("Now suppose for sake of contradiction that ")#mi("{B(0,1/m)/\\sim_m}")#text(" is isomorphic to a restriction of a global topological group ")#mi("{G}")#text(". Since ")#mi("{0 \\sim \\frac{1}{m} a_i}")#text(" for all ")#mi("{i=1,\\ldots,N+1}")#text(", we thus have a map ")#mi("{\\phi: B(0,1/m) \\rightarrow G}")#text(" which annihilates all of the ")#mi("{\\frac{1}{2m} a_i}")#text(", and is locally additive in the sense that ")#mi("{\\phi(f+g)= \\phi(f) \\cdot \\phi(g)}")#text(" whenever ")#mi("{f, g, f+g \\in B(0,1/m)}")#text(". In particular, we see that all the elements of ")#mi("{\\phi(B(0,1/2m))}")#text(" commute with each other. Furthermore the kernel ")#mi("{\\{ f \\in B(0,1/m): \\phi(f)=1\\}}")#text(" is precisely equal to the set ")#metadata(none) <tao-6923dd1bc0460082c5d5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\{ \\frac{1}{2m} \\sum_{i=1}^{N+1} n_i a_i: \\sum_{i=1}^{N+1} \\left|n_i\\right| \\leq 4m \\} \\cap B(0,1/m).", block: true)]]

#text("As the ")#mi("{a_1,\\ldots,a_{N+1}}")#text(" span a dense subset of ")#mi("{{\\bf R}^n}")#text(", we can find integers ")#mi("{n_1,\\ldots,n_{N+1}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("n_1 a_1 + \\ldots + n_{N+1} a_{N+1} \\in B(0,1)")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i=1}^{N+1} \\left|n_i\\right| > 4 m.", block: true)]]

#text("We claim that ")#mi("{\\frac{1}{2m} (n_1 a_1 + \\ldots + n_{N+1} a_{N+1})}")#text(" lies in the kernel of ")#mi("{\\phi}")#text(", contradicting the description ")#link(<tao-6923dd1bc0460082c5d5>)[#text("(7)")]#text(" of that description (and the linear independence of the ")#mi("{a_i}")#text("). To see this, we observe for a sufficiently large natural number ")#mi("{M}")#text(" that the local homomorphism property (and the commutativity) gives")

#align(center)[#tao-fit-display[#mitex("\\phi( \\frac{1}{2mM} (n_1 a_1 + \\ldots + n_{N+1} a_{N+1}) ) = \\prod_{i=1}^{N+1} \\phi( \\frac{1}{2mM} a_{N+1} )^{n_{N+1}}")]]

#text("and hence (by further application of local homomorphism and commutativity)")

#align(center)[#tao-fit-display[#mitex("\\phi( \\frac{1}{2m} (n_1 a_1 + \\ldots + n_{N+1} a_{N+1}) ) = \\prod_{i=1}^{N+1} \\phi( \\frac{1}{2mM} a_{N+1} )^{M n_{N+1}}.")]]

#text("But by yet more application of the local homomorphism property,")

#align(center)[#tao-fit-display[#mitex("\\phi( \\frac{1}{2mM} a_{N+1} )^M = \\phi( \\frac{1}{2m} a_{N+1} ) = 1")]]

#text("and the claim follows. ")#mi("\\Box")

#text("Now we glue together the examples in Proposition ")#link(<tao-ef431f36f939da403b8a>)[#text("7")]#text(" to establish Theorem ")#link(<tao-efe899c74558f20b08bb>)[#text("3")]#text(". We work in the space ")#mi("{\\ell^\\infty({\\bf N}^2)}")#text(", the elements of which we can think of as a sequence ")#mi("{(f_m)_{m \\in {\\bf N}}}")#text(" of uniformly bounded functions ")#mi("{f_m \\in \\ell^\\infty({\\bf N})}")#text(". The unit ball in this space can then be identified (as a set) with the product ")#mi("{B(0,1)^{\\bf N}}")#text(", where ")#mi("{B(0,1)}")#text(" is the unit ball in ")#mi("{\\ell^\\infty({\\bf N})}")#text(", though we caution that the topology on ")#mi("{B(0,1)^{\\bf N}}")#text(" is ")#emph[#text("not")]#text(" given by the product topology (or the box topology).")

#text("We can combine the equivalence relations ")#mi("{\\sim_m}")#text(" on ")#mi("{B(0,1)}")#text(" to a relation ")#mi("{\\sim}")#text(" on ")#mi("{B(0,1)^{\\bf N}}")#text(", defined by setting ")#mi("{(f_m)_{m \\in {\\bf N}} \\sim (g_m)_{m \\in {\\bf N}}}")#text(" iff ")#mi("{f_m \\sim_m g_m}")#text(" for all ")#mi("{m \\in {\\bf N}}")#text(". This is clearly an equivalence relation on ")#mi("{B(0,1)^{\\bf N}}")#text(", and so we can create the quotient space ")#mi("{B(0,1)^{\\bf N}/\\sim}")#text(" with the quotient topology. One easily verifies that this gives a local group. The sets ")#mi("{B(0,1/m)^{\\bf N}/\\sim}")#text(" form a neighbourhood base of the identity, but none of these sets is isomorphic (even as a discrete local group) to a subset of a global group, as it contains a copy of ")#mi("{B(0,1/m)/\\sim_m}")#text(", and the claim follows.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mikael")]], [#link("https://terrytao.wordpress.com/2011/08/17/notes-on-local-groups/#comment-68231")[#strong[#text("mikael")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2011")])]

#text("The restriction ")#mi("G\\downharpoonright_U")#text(" of a group to an open neighbourhood does not satisfy the first part of the (local closure) axiom in your definition of a local group. Perhaps this axiom should be that ")#mi("\\Omega")#text(" be a neigbourhood of ")#mi("\\{1\\} \\times \\{1\\}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/17/notes-on-local-groups/#comment-68284")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2011")])]

#text("The first axiom is satisfied by ")#mi("G \\downharpoonright_U")#text(" because ")#mi("\\Omega = \\{ (g,h) \\in U: gh \\in U \\}")#text(" contains a neighbourhood of ")#mi("\\{1\\}\\times U \\cup U \\times \\{1\\}")#text(". (Note that the underlying set in the local group ")#mi("G \\downharpoonright_U")#text(" is ")#mi("U")#text(", not ")#mi("G")#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 0 – Hilbert’s fifth problem and related topics « What’s new")]], [#link("https://terrytao.wordpress.com/2011/08/17/notes-on-local-groups/#comment-70858")[#strong[#text("254A, Notes 0 – Hilbert’s fifth problem and related topics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2011")])]

#text("[…] which is isomorphic the image of the Heisenberg group under the Weil representation, or equivalently the group of isometries of generated by translations and modulations. Despite this, though, it is helpful to think of closed linear groups and Lie groups as being almost the same concept as a first approximation. For instance, one can show using Ado’s theorem that every Lie group is locally isomorphic to a linear local group (we will discuss local groups later in this course, and see also this post). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 1: Lie groups, Lie algebras, and the Baker-Campbell-Hausdorff formula « What’s new")]], [#link("https://terrytao.wordpress.com/2011/08/17/notes-on-local-groups/#comment-72424")[#strong[#text("254A, Notes 1: Lie groups, Lie algebras, and the Baker-Campbell-Hausdorff formula « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2011")])]

#text("[…] up the barest bones of the theory of local groups here; a more detailed discussion may be found at this previous blog post. Definition 1 (Local group) A local topological group , or local group for short, is a topological […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec7c6b0e3060e1c806f619bf4b492030a739cda006aaf0a178402739ff75194-2c3659f7497f4bb1cf1e6e85fafd68a9d10b53737c2f3b03f29c35b080ae39ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2011/08/17/notes-on-local-groups/#comment-78544")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2011")])]

#text("You should look into formal groups in characteristic $p$, i.e. group structures on Spec F_p[[x]]; I think you might appreciate (or even like!) them at this point.")

#text("Sample new concept: the additive group and multiplicative group give isomorphic formal group laws on Q[[x]], but not on F_p[[x]].")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Example: Gromov-Hausdorff distances and the Heisenberg group, PART 2 | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/08/17/notes-on-local-groups/#comment-79999")[#strong[#text("Example: Gromov-Hausdorff distances and the Heisenberg group, PART 2 | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2011")])]

#text("[…] the groups and are isomorphic. If you don’t know what a local group is then see the post Notes on local groups by Terence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/480336f0d94581ae75511fdf06393a90c2a79ffdec8474e275a70fb427cf415c-89074df338e4a66a4409a5c3dfa8cf172f57f74042a296da494043a429bac65b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aaal2")]], [#link("https://terrytao.wordpress.com/2011/08/17/notes-on-local-groups/#comment-86296")[#strong[#text("aaal2")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2011")])]

#text("I really eager to know how will your team to use these knowledge to solve sum-product problem.Looking forward new posts. ")#link("http://adines.ro")[#text("licitatii")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Associativity of the Baker-Campbell-Hausdorff formula « What’s new")]], [#link("https://terrytao.wordpress.com/2011/08/17/notes-on-local-groups/#comment-98102")[#strong[#text("Associativity of the Baker-Campbell-Hausdorff formula « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2011")])]

#text("[…] by using (3) to define a smooth local group structure on a neighbourhood of the identity. (See this previous post for a definition of a local Lie group.) The main difficulty in doing so is in verifying that the […]")
]
