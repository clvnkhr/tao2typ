// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/
// Converted to Typst by tao2typ: "2026-10-14T16:37:53.264780+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Finite time blowup for a supercritical defocusing nonlinear wave system", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Finite time blowup for a supercritical defocusing nonlinear wave system")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 February 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/")[#text("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper ")#link("http://arxiv.org/abs/1602.08059")[#text("Finite time blowup for a supercritical defocusing nonlinear wave system")]#text(", submitted to ")#link("http://msp.org/apde/about/cover/cover.html")[#text("Analysis and PDE")]#text(". This paper was inspired by a question asked of me by Sergiu Klainerman recently, regarding whether there were any analogues of ")#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/")[#text("my blowup example for Navier-Stokes type equations")]#text(" in the setting of nonlinear wave equations.")

#text("Recall that the ")#emph[#text("defocusing nonlinear wave (NLW) equation")]#text(" reads ")#metadata(none) <tao-2bf7b9c6978001b98c57>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\Box u = \\left|u\\right|^{p-1} u", block: true)]]



#text(" where ")#mi("{u: {\\bf R}^{1+d} \\rightarrow {\\bf R}}")#text(" is the unknown scalar field, ")#mi("{\\Box = -\\partial_t^2 + \\Delta}")#text(" is the d’Alambertian operator, and ")#mi("{p>1}")#text(" is an exponent. We can generalise this equation to the ")#emph[#text("defocusing nonlinear wave system")]#text(" ")#metadata(none) <tao-7ade893d8bd880ac6133>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\Box u = (\\nabla F)(u)")]]



#text(" where ")#mi("{u: {\\bf R}^{1+d} \\rightarrow {\\bf R}^m}")#text(" is now a system of scalar fields, and ")#mi("{F: {\\bf R}^m \\rightarrow {\\bf R}}")#text(" is a potential which is homogeneous of degree ")#mi("{p+1}")#text(" and strictly positive away from the origin; the scalar equation corresponds to the case where ")#mi("{m=1}")#text(" and ")#tao-math("{F(u) = \\frac{1}{p+1} \\left|u\\right|^{p+1}}", block: false)#text(". We will be interested in smooth solutions ")#mi("{u}")#text(" to ")#link(<tao-7ade893d8bd880ac6133>)[#text("(2)")]#text(". It is only natural to restrict to the smooth category when the potential ")#mi("{F}")#text(" is also smooth; unfortunately, if one requires ")#mi("{F}")#text(" to be homogeneous of order ")#mi("{p+1}")#text(" all the way down to the origin, then ")#mi("{F}")#text(" cannot be smooth unless it is identically zero or ")#mi("{p+1}")#text(" is an odd integer. This is too restrictive for us, so we will only require that ")#mi("{F}")#text(" be homogeneous away from the origin (e.g. outside the unit ball). In any event it is the behaviour of ")#mi("{F(u)}")#text(" for large ")#mi("{u}")#text(" which will be decisive in understanding regularity or blowup for the equation ")#link(<tao-7ade893d8bd880ac6133>)[#text("(2)")]#text(".")

#text("Formally, solutions to the equation ")#link(<tao-7ade893d8bd880ac6133>)[#text("(2)")]#text(" enjoy a conserved energy")

#align(center)[#tao-fit-display[#tao-math("E[u] = \\int_{{\\bf R}^d} \\frac{1}{2} \\left\\|\\partial_t u \\right\\|^2 + \\frac{1}{2} \\left\\| \\nabla_x u \\right\\|^2 + F(u)\\ dx.", block: true)]]

#text("Using this conserved energy, it is possible to establish global regularity for the Cauchy problem ")#link(<tao-7ade893d8bd880ac6133>)[#text("(2)")]#text(" in the ")#emph[#text("energy-subcritical")]#text(" case when ")#mi("{d \\leq 2}")#text(", or when ")#mi("{d \\geq 3}")#text(" and ")#mi("{p < 1+\\frac{4}{d-2}}")#text(". This means that for any smooth initial position ")#mi("{u_0: {\\bf R}^d \\rightarrow {\\bf R}^m}")#text(" and initial velocity ")#mi("{u_1: {\\bf R}^d \\rightarrow {\\bf R}^m}")#text(", there exists a (unique) smooth global solution ")#mi("{u: {\\bf R}^{1+d} \\rightarrow {\\bf R}^m}")#text(" to the equation ")#link(<tao-7ade893d8bd880ac6133>)[#text("(2)")]#text(" with ")#mi("{u(0,x) = u_0(x)}")#text(" and ")#mi("{\\partial_t u(0,x) = u_1(x)}")#text(". These classical global regularity results (essentially ")#link("http://www.ams.org/mathscinet-getitem?mr=130462")[#text("due to Jörgens")]#text(") were famously extended to the ")#emph[#text("energy-critical")]#text(" case when ")#mi("{d \\geq 3}")#text(" and ")#mi("{p = 1 + \\frac{4}{d-2}}")#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=1162370")[#text("by")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=1078267")[#text("Grillakis")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1015805")[#text("Struwe")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=1247991")[#text("Shatah-Struwe")]#text(" (though for various technical reasons, the global regularity component of these results was limited to the range ")#mi("{3 \\leq d \\leq 7}")#text("). A key tool used in the energy-critical theory is the ")#emph[#text("Morawetz estimate")]

#align(center)[#tao-fit-display[#tao-math("\\int_0^T \\int_{{\\bf R}^d} \\frac{\\left|u(t,x)\\right|^{p+1}}{\\left|x\\right|}\\ dx dt \\lesssim E[u]", block: true)]]

#text("which can be proven by manipulating the properties of the stress-energy tensor")

#align(center)[#tao-fit-display[#mitex("T_{\\alpha \\beta} = \\langle \\partial_\\alpha u, \\partial_\\beta u \\rangle - \\frac{1}{2} \\eta_{\\alpha \\beta} (\\langle \\partial^\\gamma u, \\partial_\\gamma u \\rangle + F(u))")]]

#text("(with the usual summation conventions involving the Minkowski metric ")#tao-math("{\\eta_{\\alpha \\beta} dx^\\alpha dx^\\beta = -dt^2 + \\left|dx\\right|^2}", block: false)#text(") and in particular exploiting the divergence-free nature of this tensor: ")#mi("{\\partial^\\beta T_{\\alpha \\beta}}")#text(" See for instance the ")#link("http://www.ams.org/mathscinet-getitem?mr=1674843")[#text("text of Shatah-Struwe")]#text(", or ")#link("https://terrytao.wordpress.com/books/nonlinear-dispersive-equations-local-and-global-analysis/")[#text("my own PDE book")]#text(", for more details. The energy-critical regularity results have also been extended to slightly supercritical settings in which the potential grows by a logarithmic factor or so faster than the critical rate; see the results ")#link("http://www.ams.org/mathscinet-getitem?mr=2329385")[#text("of myself")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2603799")[#text("of Roy")]#text(".")

#text("This leaves the question of global regularity for the ")#emph[#text("energy supercritical")]#text(" case when ")#mi("{d \\geq 3}")#text(" and ")#mi("{p > 1+\\frac{4}{d-2}}")#text(". On the one hand, global smooth solutions are known for small data (if ")#mi("{F}")#text(" vanishes to sufficiently high order at the origin, see e.g. the ")#link("http://www.ams.org/mathscinet-getitem?mr=1408499")[#text("work of Lindblad and Sogge")]#text("), and global weak solutions for large data were constructed long ago ")#link("http://www.ams.org/mathscinet-getitem?mr=153967")[#text("by Segal")]#text(". On the other hand, the solution map, if it exists, is known to be extremely unstable, particularly at high frequencies; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=1904059")[#text("this paper of Lebeau")]#text(", ")#link("http://arxiv.org/abs/math/0311048")[#text("this paper of Christ, Colliander, and myself")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1735230")[#text("this paper of Brenner and Kumlin")]#text(", or ")#link("http://www.ams.org/mathscinet-getitem?mr=2859857")[#text("this paper of Ibrahim, Majdoub, and Masmoudi")]#text(" for various formulations of this instability. In the case of the focusing NLW ")#tao-math("{-\\partial_{tt} u + \\Delta u = - \\left|u\\right|^{p-1} u}", block: false)#text(", one can easily create solutions that blow up in finite time by ODE constructions, for instance one can take ")#mi("{u(t,x) = c (1-t)^{-\\frac{2}{p-1}}}")#text(" with ")#mi("{c = (\\frac{2(p+1)}{(p-1)^2})^{\\frac{1}{p-1}}}")#text(", which blows up as ")#mi("{t}")#text(" approaches ")#mi("{1}")#text(". However the situation in the defocusing supercritical case is less clear. The strongest positive results are of ")#link("http://arxiv.org/abs/0810.4834")[#text("Kenig-Merle")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2763767")[#text("and")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2775831")[#text("Killip-Visan")]#text(", which show (under some additional technical hypotheses) that global regularity for such equations holds under the additional assumption that the critical Sobolev norm of the solution stays bounded. Roughly speaking, this shows that “Type II blowup” cannot occur for ")#link(<tao-7ade893d8bd880ac6133>)[#text("(2)")]#text(".")

#text("Our main result is that finite time blowup can in fact occur, at least for three-dimensional systems where the number ")#mi("{m}")#text(" of degrees of freedom is sufficiently large:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" Let ")#mi("{d=3}")#text(", ")#mi("{p > 5}")#text(", and ")#mi("{m \\geq 76}")#text(". Then there exists a smooth potential ")#mi("{F: {\\bf R}^m \\rightarrow {\\bf R}}")#text(", positive and homogeneous of degree ")#mi("{p+1}")#text(" away from the origin, and a solution to ")#link(<tao-7ade893d8bd880ac6133>)[#text("(2)")]#text(" with smooth initial data that develops a singularity in finite time.")
]

#text("The rather large lower bound of ")#mi("{76}")#text(" on ")#mi("{m}")#text(" here is primarily due to our use of the ")#link("https://en.wikipedia.org/wiki/Nash_embedding_theorem")[#text("Nash embedding theorem")]#text(" (which is the first time I have actually had to use this theorem in an application!). It can certainly be lowered, but unfortunately our methods do not seem to be able to bring ")#mi("{m}")#text(" all the way down to ")#mi("{1}")#text(", so we do not directly exhibit finite time blowup for the scalar supercritical defocusing NLW. Nevertheless, this result presents a barrier to any attempt to prove global regularity for that equation, in that it must somehow use a property of the scalar equation which is not available for systems. It is likely that the methods can be adapted to higher dimensions than three, but we take advantage of some special structure to the equations in three dimensions (related to the strong Huygens principle) which does not seem to be available in higher dimensions.")

#text("The blowup will in fact be of discrete self-similar type in a backwards light cone, thus ")#mi("{u}")#text(" will obey a relation of the form")

#align(center)[#tao-fit-display[#mitex("u(e^S t, e^S x) = e^{-\\frac{2}{p-1} S} u(t,x)")]]

#text("for some fixed ")#mi("{S>0}")#text(" (the exponent ")#mi("{-\\frac{2}{p-1}}")#text(" is mandated by dimensional analysis considerations). It would be natural to consider ")#emph[#text("continuously self-similar")]#text(" solutions (in which the above relation holds for ")#emph[#text("all")]#text(" ")#mi("{S}")#text(", not just one ")#mi("{S}")#text("). And ")#emph[#text("rough")]#text(" self-similar solutions have been constructed in the literature by perturbative methods (see ")#link("http://www.ams.org/mathscinet-getitem?mr=1782103")[#text("this paper of Planchon")]#text(", or ")#link("http://www.ams.org/mathscinet-getitem?mr=1888223")[#text("this paper of Ribaud and Youssfi")]#text("). However, it turns out that continuously self-similar solutions to a defocusing equation have to obey an additional monotonicity formula which causes them to not exist in three spatial dimensions; this argument is given in my paper. So we have to work just with discretely self-similar solutions.")

#text("Because of the discrete self-similarity, the finite time blowup solution will be “locally Type II” in the sense that scale-invariant norms inside the backwards light cone stay bounded as one approaches the singularity. But it will not be “globally Type II” in that scale-invariant norms stay bounded outside the light cone as well; indeed energy will leak from the light cone at every scale. This is consistent with the results of ")#link("http://www.ams.org/mathscinet-getitem?mr=2257393")[#text("Kenig-Merle")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2763767")[#text("and")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2775831")[#text("Killip-Visan")]#text(" which preclude “globally Type II” blowup solutions to these equations in many cases.")

#text("We now sketch the arguments used to prove this theorem. Usually when studying the NLW, we think of the potential ")#mi("{F}")#text(" (and the initial data ")#mi("{u_0,u_1}")#text(") as being given in advance, and then try to solve for ")#mi("{u}")#text(" as an unknown field. However, in this problem we have the freedom to select ")#mi("{F}")#text(". So we can look at this problem from a “backwards” direction: we first choose the field ")#mi("{u}")#text(", and ")#emph[#text("then")]#text(" fit the potential ")#mi("{F}")#text(" (and the initial data) to match that field.")

#text("Now, one cannot write down a completely arbitrary field ")#mi("{u}")#text(" and hope to find a potential ")#mi("{F}")#text(" obeying ")#link(<tao-7ade893d8bd880ac6133>)[#text("(2)")]#text(", as there are some constraints coming from the homogeneity of ")#mi("{F}")#text(". Namely, from the ")#link("https://en.wikipedia.org/wiki/Homogeneous_function")[#text("Euler identity")]

#align(center)[#tao-fit-display[#mitex("\\langle u, (\\nabla F)(u) \\rangle = (p+1) F(u)")]]

#text("we see that ")#mi("{F(u)}")#text(" can be recovered from ")#link(<tao-7ade893d8bd880ac6133>)[#text("(2)")]#text(" by the formula ")#metadata(none) <tao-54dc235e3364758ae063>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("F(u) = \\frac{1}{p+1} \\langle u, \\Box u \\rangle")]]



#text(" so the defocusing nature of ")#mi("{F}")#text(" imposes a constraint")

#align(center)[#tao-fit-display[#mitex("\\langle u, \\Box u \\rangle > 0.")]]

#text("Furthermore, taking a derivative of ")#link(<tao-54dc235e3364758ae063>)[#text("(3)")]#text(" we obtain another constraining equation")

#align(center)[#tao-fit-display[#mitex("\\langle \\partial_\\alpha u, \\Box u \\rangle = \\frac{1}{p+1} \\partial_\\alpha \\langle u, \\Box u \\rangle")]]

#text("that does not explicitly involve the potential ")#mi("{F}")#text(". Actually, one can write this equation in the more familiar form")

#align(center)[#tao-fit-display[#mitex("\\partial^\\beta T_{\\alpha \\beta} = 0")]]

#text("where ")#mi("{T_{\\alpha \\beta}}")#text(" is the stress-energy tensor")

#align(center)[#tao-fit-display[#mitex("T_{\\alpha \\beta} = \\langle \\partial_\\alpha u, \\partial_\\beta u \\rangle - \\frac{1}{2} \\eta_{\\alpha \\beta} (\\langle \\partial^\\gamma u, \\partial_\\gamma u \\rangle + \\frac{1}{p+1} \\langle u, \\Box u \\rangle),")]]

#text("now written in a manner that does not explicitly involve ")#mi("{F}")#text(".")

#text("With this reformulation, this suggests a strategy for locating ")#mi("{u}")#text(": first one selects a stress-energy tensor ")#mi("{T_{\\alpha \\beta}}")#text(" that is divergence-free and obeys suitable positive definiteness and self-similarity properties, and then locates a self-similar map ")#mi("{u}")#text(" from the backwards light cone to ")#mi("{{\\bf R}^m}")#text(" that has that stress-energy tensor (one also needs the map ")#mi("{u}")#text(" (or more precisely the direction component ")#tao-math("{u/\\left\\|u\\right\\|}", block: false)#text(" of that map) injective up to the discrete self-similarity, in order to define ")#mi("{F(u)}")#text(" consistently). If the stress-energy tensor was replaced by the simpler “energy tensor”")

#align(center)[#tao-fit-display[#mitex("E_{\\alpha \\beta} = \\langle \\partial_\\alpha u, \\partial_\\beta u \\rangle")]]

#text("then the question of constructing an (injective) map ")#mi("{u}")#text(" with the specified energy tensor is precisely the embedding problem that was famously solved by Nash (viewing ")#mi("{E_{\\alpha \\beta}}")#text(" as a Riemannian metric on the domain of ")#mi("{u}")#text(", which in this case is a backwards light cone quotiented by a discrete self-similarity to make it compact). It turns out that one can adapt the Nash embedding theorem to also work with the stress-energy tensor as well (as long as one also specifies the mass density ")#tao-math("{M = \\left\\|u\\right\\|^2}", block: false)#text(", and as long as a certain positive definiteness property, related to the positive semi-definiteness of ")#link("https://en.wikipedia.org/wiki/Gramian_matrix")[#text("Gram matrices")]#text(", is obeyed). Here is where the dimension ")#mi("{76}")#text(" shows up:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" Let ")#mi("{M}")#text(" be a smooth compact Riemannian ")#mi("{4}")#text("-manifold, and let ")#mi("{m \\geq 76}")#text(". Then ")#mi("{M}")#text(" smoothly isometrically embeds into the sphere ")#mi("{S^{m-1}}")#text(".")
]

#emph[#text("Proof:")]#text(" The Nash embedding theorem (in the form given in ")#link("http://www.ams.org/mathscinet-getitem?mr=1159298")[#text("this ICM lecture of Gunther")]#text(") shows that ")#mi("{M}")#text(" can be smoothly isometrically embedded into ")#mi("{{\\bf R}^{19}}")#text(", and thus in ")#mi("{[-R,R]^{19}}")#text(" for some large ")#mi("{R}")#text(". Using an irrational slope, the interval ")#mi("{[-R,R]}")#text(" can be smoothly isometrically embedded into the ")#mi("{2}")#text("-torus ")#mi("{\\frac{1}{\\sqrt{38}} (S^1 \\times S^1)}")#text(", and so ")#mi("{[-R,R]^{19}}")#text(" and hence ")#mi("{M}")#text(" can be smoothly embedded in ")#mi("{\\frac{1}{\\sqrt{38}} (S^1)^{38}}")#text(". But from Pythagoras’ theorem, ")#mi("{\\frac{1}{\\sqrt{38}} (S^1)^{38}}")#text(" can be identified with a subset of ")#mi("{S^{m-1}}")#text(" for any ")#mi("{m \\geq 76}")#text(", and the claim follows. ")#mi("\\Box")

#text("One can presumably improve upon the bound ")#mi("{76}")#text(" by being more efficient with the embeddings (e.g. by modifying the proof of Nash embedding to embed directly into a round sphere), but I did not try to optimise the bound here.")

#text("The remaining task is to construct the stress-energy tensor ")#mi("{T_{\\alpha \\beta}}")#text(". One can reduce to tensors that are invariant with respect to rotations around the spatial origin, but this still leaves a fair amount of degrees of freedom (it turns out that there are four fields that need to be specified, which are denoted ")#mi("{M, E_{tt}, E_{tr}, E_{rr}}")#text(" in my paper). However a small miracle occurs in three spatial dimensions, in that the divergence-free condition involves only two of the four degrees of freedom (or three out of four, depending on whether one considers a function that is even or odd in ")#mi("{r}")#text(" to only be half a degree of freedom). This is easiest to illustrate with the scalar NLW ")#link(<tao-2bf7b9c6978001b98c57>)[#text("(1)")]#text(". Assuming spherical symmetry, this equation becomes")

#align(center)[#tao-fit-display[#tao-math("- \\partial_{tt} u + \\partial_{rr} u + \\frac{2}{r} \\partial_r u = \\left|u\\right|^{p-1} u.", block: true)]]

#text("Making the substitution ")#mi("{\\phi := ru}")#text(", we can eliminate the lower order term ")#mi("{\\frac{2}{r} \\partial_r}")#text(" completely to obtain")

#align(center)[#tao-fit-display[#tao-math("- \\partial_{tt} \\phi + \\partial_{rr} \\phi= \\frac{1}{r^{p-1}} \\left|\\phi\\right|^{p-1} \\phi.", block: true)]]

#text("(This can be compared with the situation in higher dimensions, in which an undesirable zeroth order term ")#mi("{\\frac{(d-1)(d-3)}{r^2} \\phi}")#text(" shows up.) In particular, if one introduces the null energy density")

#align(center)[#tao-fit-display[#tao-math("e_+ := \\frac{1}{2} \\left|\\partial_t \\phi + \\partial_r \\phi\\right|^2", block: true)]]

#text("and the potential energy density")

#align(center)[#tao-fit-display[#tao-math("V := \\frac{\\left|\\phi\\right|^{p+1}}{(p+1) r^{p-1}}", block: true)]]

#text("then one can verify the equation")

#align(center)[#tao-fit-display[#mitex("(\\partial_t - \\partial_r) e_+ + (\\partial_t + \\partial_r) V = - \\frac{p-1}{r} V")]]

#text("which can be viewed as a transport equation for ")#mi("{e_+}")#text(" with forcing term depending on ")#mi("{V}")#text(" (or vice versa), and is thus quite easy to solve explicitly by choosing one of these fields and then solving for the other. As it turns out, once one is in the supercritical regime ")#mi("{p>5}")#text(", one can solve this equation while giving ")#mi("{e_+}")#text(" and ")#mi("{V}")#text(" the right homogeneity (they have to be homogeneous of order ")#mi("{-\\frac{4}{p-1}}")#text(", which is greater than ")#mi("{-1}")#text(" in the supercritical case) and positivity properties, and from this it is possible to prescribe all the other fields one needs to satisfy the conclusions of the main theorem. (It turns out that ")#mi("{e_+}")#text(" and ")#mi("{V}")#text(" will be concentrated near the boundary of the light cone, so this is how the solution ")#mi("{u}")#text(" will concentrate also.)")

#heading(level: 1)[#text("Comments (23)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-466489")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2016")])]

#text("For maps one should use \\colon instead of : to get the correct spacing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-466490")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2016")])]

#text("Also, use \\langle and \\rangle instead of .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-466491")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2016")])]

#text("Can theorem 1 method of proof be extended for other (similar) PDE’s?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e313009dee40e5542aebadbcf4fb2d7bf7a8ec11b7d3ed0f79248eb0ab32f474-ff717f1f7a38fa3ea81cc5a87d69c48db8e5854acdb232f7a5be01a5b84c20ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bert")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-466493")[#strong[#text("Bert")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2016")])]

#text("I just wanted to ask the same, in particular of course; is there some potential connection to the Navier-Stokes equation, or a particular reason why it can not be used there?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-466496")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2016")])]

#text("It seems there is a good chance that one can do a similar construction for the NLW in higher dimensions, as well as for wave maps (there is already a known connection between equivariant wave maps and the NLW). In particular, one may hope that the ")#link("http://www.ams.org/mathscinet-getitem?mr=1622539")[#text("examples of Cazenave, Shatah, and Tahvildar-Zadeh")]#text(" on blowup of wave maps into negatively curved targets in seven and higher dimensions can be extended to lower dimensions.")

#text("I have some hope that a version of this construction can be adapted to a circulation-preserving modification of the 3D Euler equations (somewhat in the spirit of the previous blog post), but I’m still working on it.")

#text("I should also have mentioned that the impetus for working on NLW came from a question posed to me by Sergiu Klainerman about a month ago after speaking about the Navier-Stokes results.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46e7a76cd66a757d19d9f5af908aaed13cda328d2dc85fc45cb638835f8f0b2a-8f4cfbdf2ec7a89c9d4c76f0eb76619c0bc29a5ea4ff8cf298140822c00bc6f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andre")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-466492")[#strong[#text("Andre")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2016")])]

#text("Isn’t it d’Alembertian instead of d’Lambertian? See the line after eq. (1)")

#emph[#text("[Corrected, thanks – T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46e7a76cd66a757d19d9f5af908aaed13cda328d2dc85fc45cb638835f8f0b2a-8f4cfbdf2ec7a89c9d4c76f0eb76619c0bc29a5ea4ff8cf298140822c00bc6f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andre")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-466503")[#strong[#text("Andre")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2016")])]

#text("Ahem, there is still a typo.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/544b1f1094cb92da163cc8f363134577d685eaf1fc6808ccd488209b2fa8b7bd-45a87c02dd0d18e656a35324090a2cac31dfa0f5ab67e779db2c5b9b4fab0a3e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of HAMOUDA Makram")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-466494")[#strong[#text("HAMOUDA Makram")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2016")])]

#text("Dear Terence, Thank you for the two nice results on NSE and the supercritical waves. However, I am wondering if it would be better maybe to study the same question for Burger’s equation of which the nonlinearity is close to the NSE (?) What do you think? The aim purpose would be to see how the nonlinearity or/and the coupling with the pressure will influence the blow-up results. Many thanks for your time. Best regards. Makram")

#text("2016-02-27 22:16 GMT-05:00 Whats new :")

#text("> Terence Tao posted: ” I’ve just uploaded to the arXiv my paper Finite time > blowup for a supercritical defocusing nonlinear wave system, submitted to > Analysis and PDE. This paper was inspired by a question asked of me by > Sergiu Klainerman recently, regarding whether there we” >")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tumur")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-466726")[#strong[#text("Tumur")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2016")])]

#text("Burgers equations are globally well-posed in 3 dimensions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-466502")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2016")])]

#text("Why the NLW (2) is called “defocusing” ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/680171dc78c80bd8820dc89c6589ab936e646fe12cbe1b0adf01f5612fa70a88-14f626dfd791b19f757cff15bafa94be9184aea65306a62e5aa4da22acc50a2e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zuchongzhi")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-466505")[#strong[#text("zuchongzhi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2016")])]

#text("See:")

#link("http://wiki.math.toronto.edu/DispersiveWiki/index.php/Defocusing")[#text("http://wiki.math.toronto.edu/DispersiveWiki/index.php/Defocusing")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/38a9dc09b72dde9d1cc44d168491b7365bcead610d6990925c633db387a6a1ef-135e14592c9ddada12279f27ae7c2ee8e726c4bd2f6d969400ab732c580d344f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marc Nardmann")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-466647")[#strong[#text("Marc Nardmann")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2016")])]

#text("(There are some typos in the proof of Proposition 2: \\sqrt{34} should be \\sqrt{38}, and (S^1)^{19} should be (S^1)^{38}. Moreover, m \\geq 76 can obviously be improved to m \\geq 75 = 4*19-1. On p. 14 of your article, (S^1)^{2M} should be (S^1)^{2D}.)")

#text("The condition m \\geq 75 can be improved easily, as follows.")

#text("Let X be the set of linear isometries from R^{19} to R^{20}. There exists an element of X whose image meets the lattice L = \\frac{1}{\\sqrt{20}}Z^{20} only in the point 0. (For each v in L\\{0}, the set X(v) consisting of all elements of X whose image does not contain v is open and dense in X. Since L is countable, the intersection of all X(v) with v in L\\{0} is dense in X, in particular nonempty.)")

#text("Hence there is an injective isometric immersion from R^{19} to R^{20}/L = \\frac{1}{\\sqrt{20}}(S^1)^{20}. As before, we get from this an isometric embedding of the given compact Riemannian 4-manifold into S^{39}. (In the context of your article, this generalises to an embedding into S^{2D+1}.)")

#text("Dimension 39 is most likely still far from optimal. I guess that without revolutionary new ideas, one could get something between 19 and 22.")

#emph[#text("[Corrected, thanks. I’ll put your improved argument into the next revision of the ms. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Finite time blowup for high dimensional nonlinear wave systems with bounded smooth nonlinearity | What's new")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-466716")[#strong[#text("Finite time blowup for high dimensional nonlinear wave systems with bounded smooth nonlinearity | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2016")])]

#text("[…] the higher-dimensional sine-Gordon equation is not covered by our arguments. Nevertheless (as with previous finite-time blowup results discussed on this blog), one can view this result as a barrier to trying to prove […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on the Nash embedding theorem | What's new")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-468512")[#strong[#text("Notes on the Nash embedding theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2016")])]

#text("[…] recently had the need to invoke the Nash embedding theorem to establish a blowup result for a nonlinear wave equation, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-468527")[#strong[#text("Notes on the Nash embedding theorem | 神刀安全网")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2016")]

#text("[…] recently had the need to invoke the Nash embedding theorem to establish a blowup result for a nonlinear wave equation, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Finite time blowup for Lagrangian modifications of the three-dimensional Euler equation | What's new")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-470144")[#strong[#text("Finite time blowup for Lagrangian modifications of the three-dimensional Euler equation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2016")])]

#text("[…] of the three-dimensional Euler equation“. This paper is loosely in the spirit of other recent papers of mine in which I explore how close one can get to supercritical PDE of physical interest […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An integration approach to the Toeplitz square peg problem | What's new")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-474546")[#strong[#text("An integration approach to the Toeplitz square peg problem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2016")])]

#text("[…] by my previous work on finite time blowup for various PDEs, I first tried looking for a counterexample in the category […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Finite time blowup for a supercritical defocusing nonlinear Schrodinger system | What's new")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-474869")[#strong[#text("Finite time blowup for a supercritical defocusing nonlinear Schrodinger system | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2016")])]

#text("[…] nonlinear Schrödinger system, submitted to Analysis and PDE. This paper is an analogue of a recent paper of mine in which I constructed a supercritical defocusing nonlinear wave (NLW) system which exhibited […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0711632ef58b1b14bd82fe4e4f177ba94151e1ef5564eb5a692efd04ed2c8a7e-ad1f41e50481b8aaba4829f1259e97d0889560d21bcae83463e5f2e11b4ad845.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cui Yan")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-475286")[#strong[#text("Cui Yan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2016")])]

#text("Dear Prof.Tao, Does it possible to construct a high frequency finite time blow up solution of wave equation on a manifold with smooth boundary by using the same method (Nash embedding Thm).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-476004")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2017")])]

#text("Well, the boundary will not be an issue because one can use finite speed of propagation to work locally. But the variable curvature of the manifold means that one cannot compactify the problem by using a discretely self-similar ansatz, but perhaps some sort of perturbation of this ansatz might still be possible (but then one could no longer use Nash embedding as a “black box”, but would have to somehow adapt that theorem to such an ansatz also). A model problem would be to first work with the supercritical nonlinear Klein-Gordon equation in Minkowski space, which is a simpler situation in which a perfect discrete self-similar ansatz is not available.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On the universality of potential well dynamics | What's new")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-483619")[#strong[#text("On the universality of potential well dynamics | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2017")])]

#text("[…] of potential well dynamics“, submitted to Dynamics of PDE. This is a spinoff from my previous paper on blowup of nonlinear wave equations, inspired by some conversations with Sungjin Oh. Here we focus mainly on the zero-dimensional case […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On the universality of the incompressible Euler equation on compact manifolds | What's new")]], [#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-484245")[#strong[#text("On the universality of the incompressible Euler equation on compact manifolds | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2017")])]

#text("[…] proceeds by an “elimination of variables” strategy that was used in some of my previous papers in this area, though in this particular case the Nash embedding theorem (or variants thereof) are not […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/#comment-626026")[#strong[#text("To cheer you up in difficult times 23: the original hand-written slides of Terry Tao’s 2015 Einstein Lecture in Jerusalem | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2021")]

#text("[…] topic of Tao’s lecture was discussed on Terry’s blog (also here and several other posts), here on my blog, on SO, on GLL, on Quanta Magazine, and in various other […]")
]
