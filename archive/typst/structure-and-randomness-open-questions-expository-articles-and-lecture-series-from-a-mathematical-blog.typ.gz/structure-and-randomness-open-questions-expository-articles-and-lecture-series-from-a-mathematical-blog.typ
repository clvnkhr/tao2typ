// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/11/23/structure-and-randomness-open-questions-expository-articles-and-lecture-series-from-a-mathematical-blog/
// Converted to Typst by tao2typ: "2026-10-14T16:35:28.267892+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Structure and Randomness: pages from year one of mathematical blog", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Structure and Randomness: pages from year one of mathematical blog")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 November 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/11/23/structure-and-randomness-open-questions-expository-articles-and-lecture-series-from-a-mathematical-blog/")[#text("https://terrytao.wordpress.com/2008/11/23/structure-and-randomness-open-questions-expository-articles-and-lecture-series-from-a-mathematical-blog/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("https://terrytao.wordpress.com/wp-content/uploads/2008/11/mbk-tao-cov_0001.png")[#image("../assets/cca5d904dedfd9f5fc9b4949acb01a487cfe77ece58dfa071c5dc256ee73d2de-7a6f29e5a43ae83e5674a26e59f30f164f8a4e3f3174eeaeb15a061454c9eab6.png", width: 90%, alt: "mbk-tao-cov_0001")]#text("The ")#link("http://www.ams.org/")[#text("AMS")]#text(" has just notified me that the book version of the first year of my blog, now retitled “")#link("https://terrytao.wordpress.com/books/whats-new-2007/")[#text("Structure and Randomness: pages from year one of a mathematical blog")]#text("“, is ")#link("http://www.ams.org/bookstore-getitem/item=mbk-59")[#text("now available")]#text(". An official web page for this book has also been set up ")#link("http://www.ams.org/bookpages/mbk-59/")[#text("here")]#text(", though it is fairly empty at present. A (2MB) high-resolution PDF file of the cover can be ")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/11/mbk-tao-cov.pdf")[#text("found here")]#text(".")

#text("I plan to start on converting this year’s blog posts to book form in January, and hopefully the process should be a little faster this time. Given that my lecture notes ")#link("https://terrytao.wordpress.com/category/teaching/254a-ergodic-theory/")[#text("on ergodic theory")]#text(" and ")#link("https://terrytao.wordpress.com/category/teaching/285g-poincare-conjecture/")[#text("on the Poincaré conjecture")]#text(" will form the bulk of that book, I have chosen the working title for that book to be “")#link("https://terrytao.wordpress.com/books/poincares-legacies-course-notes-expository-articles-and-lecture-series-from-a-mathematical-blog/")[#text("Poincaré’s legacies: pages from year two of a mathematical blog")]#text("“.")

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tom")]], [#link("https://terrytao.wordpress.com/2008/11/23/structure-and-randomness-open-questions-expository-articles-and-lecture-series-from-a-mathematical-blog/#comment-33625")[#strong[#text("tom")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2008")])]

#text("Dear Terry, that’s great news! Congratulations on your dedication to have things done right (the high quality of your blog first, and then the AMS are great publishers indeed IMHO, and the price is low enough so that many libraries and students can afford it I’m sure).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/11/23/structure-and-randomness-open-questions-expository-articles-and-lecture-series-from-a-mathematical-blog/#comment-33627")[#strong[#text("Michael Nielsen » Biweekly links for 11/24/2008")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2008")]

#text("[…] Structure and Randomness: pages from year one of mathematical blog « What’s new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2008/11/23/structure-and-randomness-open-questions-expository-articles-and-lecture-series-from-a-mathematical-blog/#comment-33629")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2008")])]

#text("Terry, your weblog is a gold mine of theorems, algorithms, and ideas for doing system engineering and simulation science … and I think that many people, from many disciplines, discover similar resources in your writings.")

#text("But what I admire most about this weblog is its generosity of spirit, and its embodiment of the sheer enjoyment of doing mathematics.")

#text("This series of books will distill and preserve that generosity and that enjoyment of doing mathematics.")

#text("For which, thank you ")#emph[#text("very")]#text(" much.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cf34068aa748654a2db455a6d6a7117d79ffc9db7d628a1e127ecc2e4aa2786-655ca8bdb8d9d362326c1956bdd9e7611b3ac81ce5651f2762f89fcc1783dde9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Danielle Fong")]], [#link("https://terrytao.wordpress.com/2008/11/23/structure-and-randomness-open-questions-expository-articles-and-lecture-series-from-a-mathematical-blog/#comment-33633")[#strong[#text("Danielle Fong")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2008")])]

#text("Terry,")

#text("You’re an inspiration to me, my own work, and my own writing. I feel blessed by your advice, inspired by the depth of your writings, and encouraged by the accessibility of your educational posts. Most of all I am appreciative of the fact that you are helping lead the way into a new era for scientific publishing, wherein barriers fade, one holds *themselves* to a high standard, and then one simply posts to a blog. It has helped change my life; I can still do real science, even while remaining outside the university. When I think of something, or work something out, I just fire up wordpress, and write a draft. Ideas flow.")

#text("I am very happy that blogging has been so productive for you as well. Congratulations on your book! May this year continue to go just as well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2008/11/23/structure-and-randomness-open-questions-expository-articles-and-lecture-series-from-a-mathematical-blog/#comment-33634")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2008")])]

#text("Danielle Fong, please let me say that your post was wonderful.")

#text("I hope you don’t mind my saying that your blog is terrific and that your company Lightsail Designs looks like it is doing work that is interesting *and* important.")

#text("It is very fun that so many mechanical engineers read and appreciate Terry’s blog (our QSE lab is in ME). This makes the title of Terry’s forthcoming book, ")#emph[#text("Poincaré’s Legacies")]#text(", seem even more appropriate … because after all, Poincaré’ worked all his life as a practicing engineer! :)")

#text("A great many of Poincaré’s mathematical discoveries proved to be useful for engineering purposes … perhaps the same thing will prove true of Terry’s work (especially now that engineers are reading this weblog). :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2008/11/23/structure-and-randomness-open-questions-expository-articles-and-lecture-series-from-a-mathematical-blog/#comment-33641")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2008")])]

#link("http://www.nytimes.com/2008/11/24/business/24ito.html?pagewanted=print")[#text("Kiyoshi Ito, 93, Mathematician Who Described Random Motion, Dies")]#linebreak()#text(" By STEVE LOHR")#linebreak()#text(" The New York Times")#linebreak()#text(" November 24, 2008")

#text("Kiyoshi Ito, a mathematician whose innovative models of random motion are used today in fields as diverse as finance and biology, died Nov. 10 at a hospital in Kyoto, Japan. He was 93.")

#text("His death was confirmed by his daughter, Junko Ito.")

#text("Mr. Ito is known for his contributions to probability theory, the study of randomness. His work, starting in the 1940s, built on the earlier breakthroughs of Albert Einstein and Norbert Wiener. Mr. Ito’s mathematical framework for describing the evolution of random phenomena came to be known as the Ito Calculus.")

#text("[truncated]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2008/11/23/structure-and-randomness-open-questions-expository-articles-and-lecture-series-from-a-mathematical-blog/#comment-33649")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2008")])]

#text("I don’t remember whether I said this at the time, but the group A that is being acted upon need not be abelian – only the group G acting on it needs to be. (I do not know to what extent the latter requirement is a consequence of the limitations of the proof we know and to what extent it is a feature of reality.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2008/11/23/structure-and-randomness-open-questions-expository-articles-and-lecture-series-from-a-mathematical-blog/#comment-33738")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2008")])]

#text("Hi Terence,")

#text("Your lecture series on Ergodic Theory led to my interest in Mathematical Dynamics. I have found this appled by thermophysicsts in the Springer book:")

#text("SV Alekseenko, PA Kuibin, VL Okulov,")#linebreak()#text(" Theory of Concentrated Vortices: An Introduction")

#text("They seem to move from a 2D globally flat surface to an equivalent 3D cylindirical surface that is globally curved. Both surfaces are locally flat. The diagonal of the former is replaced by helix in the latter.")

#text("They discuss Beltrami flows. These seem primary to secondary Ricci flows which create bubbles in fluids; planets and stars in the cosmos through the Laplace-Beltrami Operator?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/11/23/structure-and-randomness-open-questions-expository-articles-and-lecture-series-from-a-mathematical-blog/#comment-228779")[#strong[#text("Bird’s-eye views of Structure and Randomness (Series) | Abstract Art")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2013")]

#text("[…] put me off reading his blog until I recently read a compilation of some of his posts in his book Structure and Randomness [1] (See cover at […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/11/23/structure-and-randomness-open-questions-expository-articles-and-lecture-series-from-a-mathematical-blog/#comment-228787")[#strong[#text("Strengthening inequalities: a mathematical trick | Abstract Art")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2013")]

#text("[…] Part 3 of a six-part series of summaries and adaptations from Terence Tao’s book “Structure and Randomness“. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/11/23/structure-and-randomness-open-questions-expository-articles-and-lecture-series-from-a-mathematical-blog/#comment-228835")[#strong[#text("Tomb raider: an analogy for quantum weirdness | Abstract Art")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2013")]

#text("[…] Part 1 of a six-part series of adaptations from Terence Tao’s book “Structure and Randomness“. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/11/23/structure-and-randomness-open-questions-expository-articles-and-lecture-series-from-a-mathematical-blog/#comment-228914")[#strong[#text("Abstract Art")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2013")]

#text("[…] Part 2 of a six-part series of adaptations from Terence Tao’s book “Structure and Randomness“. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/11/23/structure-and-randomness-open-questions-expository-articles-and-lecture-series-from-a-mathematical-blog/#comment-229611")[#strong[#text("Drawing networks on a plane | Abstract Art")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2013")]

#text("[…] Part 4 of a six-part series of adaptations from Terence Tao’s book “Structure and Randomness“. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/11/23/structure-and-randomness-open-questions-expository-articles-and-lecture-series-from-a-mathematical-blog/#comment-230425")[#strong[#text("Analogies between finitary and infinitary math | Abstract Art")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2013")]

#text("[…] Part 5 of a six-part series of adaptations from Terence Tao’s book “Structure and Randomness“. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a797c6c39380180ff80238bff5e643ef4f24eac9692e0f0f39902fb20f6bfd28-9c82f0908c8aa5d3686ef4a39e2ff2931a882bf250e355900bfc94ad9b8d8738.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ani shedrack")]], [#link("https://terrytao.wordpress.com/2008/11/23/structure-and-randomness-open-questions-expository-articles-and-lecture-series-from-a-mathematical-blog/#comment-232775")[#strong[#text("ani shedrack")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("prof terence tao,i am so happy about your post.ever since i know you on net ,you have being an inspiration to me.although i am a physics student,i have a special interest for math.it gives me joy to see one like you, who have fine mathematical insight and does it with so much ease.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/11/23/structure-and-randomness-open-questions-expository-articles-and-lecture-series-from-a-mathematical-blog/#comment-235216")[#strong[#text("Infinities as numbers: purging the epsilons and deltas from proofs | Abstract Art")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")]

#text("[…] Part 6 of a six-part series of adaptations from Terence Tao’s book “Structure and Randomness“. […]")
]
