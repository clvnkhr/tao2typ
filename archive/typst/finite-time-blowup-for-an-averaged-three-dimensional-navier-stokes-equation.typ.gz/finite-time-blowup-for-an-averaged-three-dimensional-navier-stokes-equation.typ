// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/
// Converted to Typst by tao2typ: "2026-10-14T15:18:56.511907+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Finite time blowup for an averaged three-dimensional Navier-Stokes equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Finite time blowup for an averaged three-dimensional Navier-Stokes equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 February 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/")[#text("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv the paper “")#link("http://arxiv.org/abs/1402.0290")[#text("Finite time blowup for an averaged three-dimensional Navier-Stokes equation")]#text("“, submitted to J. Amer. Math. Soc.. The main purpose of this paper is to formalise the “supercriticality barrier” for the global regularity problem for the Navier-Stokes equation, which roughly speaking asserts that it is not possible to establish global regularity by any “abstract” approach which only uses upper bound function space estimates on the nonlinear part of the equation, combined with the energy identity. This is done by constructing a modification of the Navier-Stokes equations with a nonlinearity that obeys essentially all of the function space estimates that the true Navier-Stokes nonlinearity does, and which also obeys the energy identity, but for which one can construct solutions that blow up in finite time. Results of this type had been previously established by ")#link("http://www.ams.org/mathscinet-getitem?mr=1840108")[#text("Montgomery-Smith")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2480289")[#text("Gallagher-Paicu")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=2390325")[#text("Li-Sinai")]#text(" for variants of the Navier-Stokes equation without the energy identity, and by ")#link("http://www.ams.org/mathscinet-getitem?mr=2095627")[#text("Katz-Pavlovic")]#text(" and by ")#link("http://www.ams.org/mathscinet-getitem?mr=2415066")[#text("Cheskidov")]#text(" for dyadic analogues of the Navier-Stokes equations in five and higher dimensions that obeyed the energy identity (see also the work ")#link("http://www.ams.org/mathscinet-getitem?mr=1843986")[#text("of Plechac")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2012858")[#text("and Sverak")]#text(" and of ")#link("http://www.ams.org/mathscinet-getitem?mr=2492706")[#text("Hou and Lei")]#text(" that also suggest blowup for other Navier-Stokes type models obeying the energy identity in five and higher dimensions), but to my knowledge this is the first blowup result for a Navier-Stokes type equation in three dimensions that also obeys the energy identity. Intriguingly, the method of proof in fact hints at a possible route to establishing blowup for the true Navier-Stokes equations, which I am now increasingly inclined to believe is the case (albeit for a very small set of initial data).")

#text("To state the results more precisely, recall that the Navier-Stokes equations can be written in the form")

#align(center)[#tao-fit-display[#mitex("\\partial_t u + (u \\cdot \\nabla) u = \\nu \\Delta u + \\nabla p")]]

#text("for a divergence-free velocity field ")#mi("{u}")#text(" and a pressure field ")#mi("{p}")#text(", where ")#mi("{\\nu>0}")#text(" is the viscosity, which we will normalise to be one. We will work in the non-periodic setting, so the spatial domain is ")#mi("{{\\bf R}^3}")#text(", and for sake of exposition I will not discuss matters of regularity or decay of the solution (but we will always be working with strong notions of solution here rather than weak ones). Applying the Leray projection ")#mi("{P}")#text(" to divergence-free vector fields to this equation, we can eliminate the pressure, and obtain an evolution equation ")#metadata(none) <tao-7f59cc79a33a10c45f55>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\partial_t u = \\Delta u + B(u,u)")]]

#text("purely for the velocity field, where ")#mi("{B}")#text(" is a certain bilinear operator on divergence-free vector fields (specifically, ")#mi("{B(u,v) = -\\frac{1}{2} P( (u \\cdot \\nabla) v + (v \\cdot \\nabla) u)}")#text(". The global regularity problem for Navier-Stokes is then equivalent to the global regularity problem for the evolution equation ")#link(<tao-7f59cc79a33a10c45f55>)[#text("(1)")]#text(".")

#text("An important feature of the bilinear operator ")#mi("{B}")#text(" appearing in ")#link(<tao-7f59cc79a33a10c45f55>)[#text("(1)")]#text(" is the cancellation law")

#align(center)[#tao-fit-display[#mitex("\\langle B(u,u), u \\rangle = 0")]]

#text("(using the ")#mi("{L^2}")#text(" inner product on divergence-free vector fields), which leads in particular to the fundamental energy identity")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} \\int_{{\\bf R}^3} \\left|u(T,x)\\right|^2\\ dx + \\int_0^T \\int_{{\\bf R}^3} \\left|\\nabla u(t,x)\\right|^2\\ dx dt = \\frac{1}{2} \\int_{{\\bf R}^3} \\left|u(0,x)\\right|^2\\ dx.", block: true)]]

#text("This identity (and its consequences) provide essentially the only known ")#emph[#text("a priori")]#text(" bound on solutions to the Navier-Stokes equations from large data and arbitrary times. Unfortunately, as discussed in ")#link("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")[#text("this previous post")]#text(", the quantities controlled by the energy identity are supercritical with respect to scaling, which is the fundamental obstacle that has defeated all attempts to solve the global regularity problem for Navier-Stokes without any additional assumptions on the data or solution (e.g. perturbative hypotheses, or ")#emph[#text("a priori")]#text(" control on a critical norm such as the ")#mi("{L^\\infty_t L^3_x}")#text(" norm).")

#text("Our main result is then (slightly informally stated) as follows")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" There exists an ")#emph[#text("averaged")]#text(" version ")#mi("{\\tilde B}")#text(" of the bilinear operator ")#mi("{B}")#text(", of the form")

#align(center)[#tao-fit-display[#mitex("\\tilde B(u,v) := \\int_\\Omega m_{3,\\omega}(D) Rot_{3,\\omega}")]]

#align(center)[#tao-fit-display[#mitex("B( m_{1,\\omega}(D) Rot_{1,\\omega} u, m_{2,\\omega}(D) Rot_{2,\\omega} v )\\ d\\mu(\\omega)")]]

#text("for some probability space ")#mi("{(\\Omega, \\mu)}")#text(", some spatial rotation operators ")#mi("{Rot_{i,\\omega}}")#text(" for ")#mi("{i=1,2,3}")#text(", and some Fourier multipliers ")#mi("{m_{i,\\omega}}")#text(" of order ")#mi("{0}")#text(", for which one still has the cancellation law")

#align(center)[#tao-fit-display[#mitex("\\langle \\tilde B(u,u), u \\rangle = 0")]]

#text("and for which the averaged Navier-Stokes equation ")#metadata(none) <tao-da3ccdcc2168341812f6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\partial_t u = \\Delta u + \\tilde B(u,u)")]]

#text("admits solutions that blow up in finite time.")
]

#text("(There are some integrability conditions on the Fourier multipliers ")#mi("{m_{i,\\omega}}")#text(" required in the above theorem in order for the conclusion to be non-trivial, but I am omitting them here for sake of exposition.)")

#text("Because spatial rotations and Fourier multipliers of order ")#mi("{0}")#text(" are bounded on most function spaces, ")#mi("{\\tilde B}")#text(" automatically obeys almost all of the upper bound estimates that ")#mi("{B}")#text(" does. Thus, this theorem blocks any attempt to prove global regularity for the true Navier-Stokes equations which relies purely on the energy identity and on upper bound estimates for the nonlinearity; one must use some additional structure of the nonlinear operator ")#mi("{B}")#text(" which is not shared by an averaged version ")#mi("{\\tilde B}")#text(". Such additional structure certainly exists – for instance, the Navier-Stokes equation has a vorticity formulation involving only differential operators rather than pseudodifferential ones, whereas a general equation of the form ")#link(<tao-da3ccdcc2168341812f6>)[#text("(2)")]#text(" does not. However, “abstract” approaches to global regularity generally do not exploit such structure, and thus cannot be used to affirmatively answer the Navier-Stokes problem.")

#text("It turns out that the particular averaged bilinear operator ")#mi("{B}")#text(" that we will use will be a finite linear combination of ")#emph[#text("local cascade operators")]#text(", which take the form")

#align(center)[#tao-fit-display[#mitex("C(u,v) := \\sum_{n \\in {\\bf Z}} (1+\\epsilon_0)^{5n/2} \\langle u, \\psi_{1,n} \\rangle \\langle v, \\psi_{2,n} \\rangle \\psi_{3,n}")]]

#text("where ")#mi("{\\epsilon_0>0}")#text(" is a small parameter, ")#mi("{\\psi_1,\\psi_2,\\psi_3}")#text(" are Schwartz vector fields whose Fourier transform is supported on an annulus, and ")#mi("{\\psi_{i,n}(x) := (1+\\epsilon_0)^{3n/2} \\psi_i( (1+\\epsilon_0)^n x)}")#text(" is an ")#mi("{L^2}")#text("-rescaled version of ")#mi("{\\psi_i}")#text(" (basically a “wavelet” of wavelength about ")#mi("{(1+\\epsilon_0)^{-n}}")#text(" centred at the origin). Such operators were essentially introduced by ")#link("http://www.ams.org/mathscinet-getitem?mr=2095627")[#text("Katz and Pavlovic")]#text(" as dyadic models for ")#mi("{B}")#text("; they have the essentially the same scaling property as ")#mi("{B}")#text(" (except that one can only scale along powers of ")#mi("{1+\\epsilon_0}")#text(", rather than over all positive reals), and in fact they can be expressed as an average of ")#mi("{B}")#text(" in the sense of the above theorem, as can be shown after a somewhat tedious amount of Fourier-analytic symbol manipulations.")

#text("If we consider nonlinearities ")#mi("{\\tilde B}")#text(" which are a finite linear combination of local cascade operators, then the equation ")#link(<tao-da3ccdcc2168341812f6>)[#text("(2)")]#text(" more or less collapses to a system of ODE in certain “wavelet coefficients” of ")#mi("{u}")#text(". The precise ODE that shows up depends on what precise combination of local cascade operators one is using. Katz and Pavlovic essentially considered a single cascade operator together with its “adjoint” (needed to preserve the energy identity), and arrived (more or less) at the system of ODE ")#metadata(none) <tao-fc44678719aab6149ed0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\partial_t X_n = - (1+\\epsilon_0)^{2n} X_n + (1+\\epsilon_0)^{\\frac{5}{2}(n-1)} X_{n-1}^2 - (1+\\epsilon_0)^{\\frac{5}{2} n} X_n X_{n+1}")]]

#text("where ")#mi("{X_n: [0,T] \\rightarrow {\\bf R}}")#text(" are scalar fields for each integer ")#mi("{n}")#text(". (Actually, Katz-Pavlovic worked with a technical variant of this particular equation, but the differences are not so important for this current discussion.) Note that the quadratic terms on the RHS carry a higher exponent of ")#mi("{1+\\epsilon_0}")#text(" than the dissipation term; this reflects the supercritical nature of this evolution (the energy ")#mi("{\\frac{1}{2} \\sum_n X_n^2}")#text(" is monotone decreasing in this flow, so the natural size of ")#mi("{X_n}")#text(" given the control on the energy is ")#mi("{O(1)}")#text("). There is a slight technical issue with the dissipation if one wishes to embed ")#link(<tao-fc44678719aab6149ed0>)[#text("(3)")]#text(" into an equation of the form ")#link(<tao-da3ccdcc2168341812f6>)[#text("(2)")]#text(", but it is minor and I will not discuss it further here.")

#text("In principle, if the ")#mi("{X_n}")#text(" mode has size comparable to ")#mi("{1}")#text(" at some time ")#mi("{t_n}")#text(", then energy should flow from ")#mi("{X_n}")#text(" to ")#mi("{X_{n+1}}")#text(" at a rate comparable to ")#mi("{(1+\\epsilon_0)^{\\frac{5}{2} n}}")#text(", so that by time ")#mi("{t_{n+1} \\approx t_n + (1+\\epsilon_0)^{-\\frac{5}{2} n}}")#text(" or so, most of the energy of ")#mi("{X_n}")#text(" should have drained into the ")#mi("{X_{n+1}}")#text(" mode (with hardly any energy dissipated). Since the series ")#mi("{\\sum_{n \\geq 1} (1+\\epsilon_0)^{-\\frac{5}{2} n}}")#text(" is summable, this suggests finite time blowup for this ODE as the energy races ever more quickly to higher and higher modes. Such a scenario was indeed established by Katz and Pavlovic (and refined by Cheskidov) if the dissipation strength ")#mi("{(1+\\epsilon)^{2n}}")#text(" was weakened somewhat (the exponent ")#mi("{2}")#text(" has to be lowered to be less than ")#mi("{\\frac{5}{3}}")#text("). As mentioned above, this is enough to give a version of Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" in five and higher dimensions.")

#text("On the other hand, it was shown a few years ago by ")#link("http://www.ams.org/mathscinet-getitem?mr=2844828")[#text("Barbato, Morandin, and Romito")]#text(" that ")#link(<tao-fc44678719aab6149ed0>)[#text("(3)")]#text(" in fact admits global smooth solutions (at least in the dyadic case ")#mi("{\\epsilon_0=1}")#text(", and assuming non-negative initial data). Roughly speaking, the problem is that as energy is being transferred from ")#mi("{X_n}")#text(" to ")#mi("{X_{n+1}}")#text(", energy is also simultaneously being transferred from ")#mi("{X_{n+1}}")#text(" to ")#mi("{X_{n+2}}")#text(", and as such the solution races off to higher modes a bit too prematurely, without absorbing all of the energy from lower modes. This weakens the strength of the blowup to the point where the moderately strong dissipation in ")#link(<tao-fc44678719aab6149ed0>)[#text("(3)")]#text(" is enough to kill the high frequency cascade before a true singularity occurs. Because of this, the original Katz-Pavlovic model cannot quite be used to establish Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" in three dimensions. (Actually, the original Katz-Pavlovic model had some additional dispersive features which allowed for another proof of global smooth solutions, which is an unpublished result of Nazarov.)")

#text("To get around this, I had to “engineer” an ODE system with similar features to ")#link(<tao-fc44678719aab6149ed0>)[#text("(3)")]#text(" (namely, a quadratic nonlinearity, a monotone total energy, and the indicated exponents of ")#mi("{(1+\\epsilon_0)}")#text(" for both the dissipation term and the quadratic terms), but for which the cascade of energy from scale ")#mi("{n}")#text(" to scale ")#mi("{n+1}")#text(" was not interrupted by the cascade of energy from scale ")#mi("{n+1}")#text(" to scale ")#mi("{n+2}")#text(". To do this, I needed to insert a ")#emph[#text("delay")]#text(" in the cascade process (so that after energy was dumped into scale ")#mi("{n}")#text(", it would take some time before the energy would start to transfer to scale ")#mi("{n+1}")#text("), but the process also needed to be ")#emph[#text("abrupt")]#text(" (once the process of energy transfer started, it needed to conclude very quickly, before the delayed transfer for the next scale kicked in). It turned out that one could build a “quadratic circuit” out of some basic “quadratic gates” (analogous to how an electrical circuit could be built out of basic gates such as amplifiers or resistors) that achieved this task, leading to an ODE system essentially of the form")

#tao-aligned(keep: false)[


#tao-math("\\partial_t X_{1,n}  & = - (1+\\epsilon_0)^{2n} X_{1,n}", block: true)



#tao-math(" & + (1+\\epsilon_0)^{5n/2} (- \\epsilon^{-2} X_{3,n} X_{4,n} - \\epsilon X_{1,n} X_{2,n} - \\epsilon^2 \\exp(-K^{10}) X_{1,n} X_{3,n}", block: true)



#tao-math(" & + K X_{4,n-1}^2)", block: true)



#tao-math("\\partial_t X_{2,n}  & = - (1+\\epsilon_0)^{2n} X_{2,n} + (1+\\epsilon_0)^{5n/2} (\\epsilon X_{1,n}^2 - \\epsilon^{-1} K^{10} X_{3,n}^2)", block: true)



#tao-math("\\partial_t X_{3,n}  & = - (1+\\epsilon_0)^{2n} X_{3,n} + (1+\\epsilon_0)^{5n/2} (\\epsilon^2 \\exp(-K^{10}) X_{1,n}^2", block: true)



#tao-math(" & + \\epsilon^{-1} K^{10} X_{2,n} X_{3,n} )", block: true)



#tao-math("\\partial_t X_{4,n}  & =- (1+\\epsilon_0)^{2n} X_{4,n} + (1+\\epsilon_0)^{5n/2} (\\epsilon^{-2} X_{3,n} X_{1,n}", block: true)



#tao-math(" & - (1+\\epsilon_0)^{5/2} K X_{4,n} X_{1,n+1})", block: true)
]

#text("where ")#mi("{K \\geq 1}")#text(" is a suitable large parameter and ")#mi("{\\epsilon > 0}")#text(" is a suitable small parameter (much smaller than ")#mi("{1/K}")#text("). To visualise the dynamics of such a system, I found it useful to describe this system graphically by a “circuit diagram” that is analogous (but not identical) to the circuit diagrams arising in electrical engineering:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2014/02/circuit-1.png")[#image("../assets/6a78165312eaf4c9a1a0e85f63af0153375adf0c00915f1013b740e73be8d0e2-a002209d3dde3efb1e3386bf65155e547208a3ecb22566363a78cb184665e367.png", width: 90%, alt: "circuit-1")]

#text("The coupling constants here range widely from being very large to very small; in practice, this makes the ")#mi("{X_{2,n}}")#text(" and ")#mi("{X_{3,n}}")#text(" modes absorb very little energy, but exert a sizeable influence on the remaining modes. If a lot of energy is suddenly dumped into ")#mi("{X_{1,n}}")#text(", what happens next is roughly as follows: for a moderate period of time, nothing much happens other than a trickle of energy into ")#mi("{X_{2,n}}")#text(", which in turn causes a rapid exponential growth of ")#mi("{X_{3,n}}")#text(" (from a very low base). After this delay, ")#mi("{X_{3,n}}")#text(" suddenly crosses a certain threshold, at which point it causes ")#mi("{X_{1,n}}")#text(" and ")#mi("{X_{4,n}}")#text(" to exchange energy back and forth with extreme speed. The energy from ")#mi("{X_{4,n}}")#text(" then rapidly drains into ")#mi("{X_{1,n+1}}")#text(", and the process begins again (with a slight loss in energy due to the dissipation). If one plots the total energy ")#mi("{E_n := \\frac{1}{2} ( X_{1,n}^2 + X_{2,n}^2 + X_{3,n}^2 + X_{4,n}^2 )}")#text(" as a function of time, it looks schematically like this:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2014/02/energy-blowup.png")[#image("../assets/4ab09221b7fdfb5f09aed8c004a5380199efb741e9873f478fd2cfe4ef0832c2-3a8cf1ffb27120e49cd1a123593b4a81a94bd02c5aa1058cf76a8c7425774d00.png", width: 90%, alt: "energy-blowup")]

#text("As in the previous heuristic discussion, the time between cascades from one frequency scale to the next decay exponentially, leading to blowup at some finite time ")#mi("{T}")#text(". (One could describe the dynamics here as being similar to the famous “")#link("http://www.youtube.com/watch?v=i6LGJ7evrAg")[#text("lighting the beacons")]#text("” scene in the Lord of the Rings movies, except that (a) as each beacon gets ignited, the previous one is extinguished, as per the energy identity; (b) the time between beacon lightings decrease exponentially; and (c) there is no soundtrack.)")

#text("There is a real (but remote) possibility that this sort of construction can be adapted to the true Navier-Stokes equations. The basic blowup mechanism in the averaged equation is that of a ")#link("http://en.wikipedia.org/wiki/Self-replicating_machine")[#text("von Neumann machine")]#text(", or more precisely a construct (built within the laws of the inviscid evolution ")#mi("{\\partial_t u = \\tilde B(u,u)}")#text(") that, after some time delay, manages to suddenly create a replica of itself at a finer scale (and to largely erase its original instantiation in the process). In principle, such a von Neumann machine could also be built out of the laws of the inviscid form of the Navier-Stokes equations (i.e. the Euler equations). In physical terms, one would have to build the machine purely out of an ideal fluid (i.e. an inviscid incompressible fluid). If one could somehow create enough “logic gates” out of ideal fluid, one could presumably build a sort of “fluid computer”, at which point the task of building a von Neumann machine appears to reduce to a software engineering exercise rather than a PDE problem (providing that the gates are suitably stable with respect to perturbations, but (as with actual computers) this can presumably be done by converting the analog signals of fluid mechanics into a more error-resistant digital form). The key thing missing in this program (in both senses of the word) to establish blowup for Navier-Stokes is to construct the logic gates within the laws of ideal fluids. (Compare with the situation for cellular automata such as Conway’s “")#link("http://en.wikipedia.org/wiki/Conway's_Game_of_Life")[#text("Game of Life")]#text("“, in which Turing complete computers, universal constructors, and replicators have all been built within the laws of that game.)")

#heading(level: 1)[#text("Comments (198)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d266db86d747d43312de4b28cae766058765dbcc9205dbf243949d157be432a-c131edf723cb55c8de49d02ba06642b15ebbd3a9c7494196a8bcb4c22e34d6b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of joe")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-450103")[#strong[#text("joe")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2015")])]

#text("Andreas, are you referring to me? or Prof. Tao")

#text("I have the complete equations but never submitted to any journals. Was hoping to help Prof Tao in submitting or co-author the papers since he has the deep mathematical skill and reputation on the subject.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/354447698bd39b8e45648c483ba1a14642b319577389b37bf46d74d6f340e1fa-71a14a4663ff2517f8b6838d797905585c9266d48657d3bd9f57dde8ac18eeb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ainuru")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-450113")[#strong[#text("Ainuru")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2015")])]

#text("See the research of 3D incompressible fluid, which is published at the end of 2014")#linebreak()#text(" ")#link("http://www.smolensk.ru/user/sgma/MMORPH/N-43-html/cont.htm")[#text("http://www.smolensk.ru/user/sgma/MMORPH/N-43-html/cont.htm")]#linebreak()#text(" The proximity of solutions of the Navier-Stokes and Euler equations given in a separate paragraph. The results are summarized for the Navier-Stokes equations in multidimensional space.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3033bfa8855b64521474bcf3ed5f6ee0ea8dd15aa5022aa6d9619caba0650ca0-8209bc03762b6e4ea7fdbc9e12086f85e9e27da4faa1078396d1e34ae7e2a236.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of matthew miller")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-453502")[#strong[#text("matthew miller")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2015")])]

#text("For Professor Tao,")

#text("If you’ll oblige me, what are the author’s views with regards overlap between a recent publication on FPU and your own on Naiver-Stokes?")

#text("Does this special business about 6 wave modes (and not another number) leading to dissipation in the absence of viscosity apply positively, negatively or neutrally to global regularity of the Naiver-Stokes problem – especially as regards your program/suggestion to establish finite time blowup?")

#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3033bfa8855b64521474bcf3ed5f6ee0ea8dd15aa5022aa6d9619caba0650ca0-8209bc03762b6e4ea7fdbc9e12086f85e9e27da4faa1078396d1e34ae7e2a236.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of matthew miller")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-453503")[#strong[#text("matthew miller")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2015")])]

#text("From the above comment here’s the name of the paper, published in PNAS on the 23rd of March. Can also find on arXiv.")

#text("Route to thermalization in the α-Fermi-Pasta-Ulam system.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-453513")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2015")])]

#text("As far as I can tell, the analysis in that paper is specific to the Fermi-Pasta-Ulam system and does not appear to have any analogue for Navier-Stokes evolution, which has quite a different dynamics.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8616a12550cbf512db9d864776b20f932f6acc272a6494d8a2b3a2ad44be175-98a304c8394b6f593a9967c0beb75f2d5ad323160be95bf62ed248e8caf2151b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shaurabh aggarwal")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-453506")[#strong[#text("shaurabh aggarwal")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2015")])]

#text("Can we solve navier stokes equation with more than 4 dimensions")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-638940")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2022")])]

#text("yes. there have been papers in Journal of Fluid Mechanics dealing with 4th dimension turbulent channel flow.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-453533")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2015")])]

#text("It seems like the crux of the matter is to bound the ratio of the energy distributed in the high frequencies to the low frequencies, so extra dimensions should make the problem even harder.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-453534")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2015")])]

#text("I apologize if this is a wrong forum for these kind of queries, but there are hints that a global existence result of regular solutions would require a global _lower_ bound for the energy of the solutions. There are results such as Schönbek’s, which say that if the Fourier-transform of the solution does not vanish too fast at the origin, then the energy of the solution decays slower than C(1+t)^-(n/2+1). Is there a known lower bound for the energy for any initial data in, say, the Schwartz-class?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-453551")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2015")])]

#text("I consider this unlikely: blowup or lack thereof is going to be decided by the dynamics of the high-frequency component of the solution, whereas questions of energy decay are mostly decided by the dynamics of the low-frequency components (as the result of Schonbek indicates). Note that if a solution has unusually rapid energy decay, then one should be able to modify that solution to one which does not exhibit such decay simply by placing an additional low-frequency component to the initial velocity that is supported sufficiently far away from the rest of the initial data that it does not significantly affect the dynamics of that data (other than by an approximately linear superposition of the original solution with the evolution of the low-frequency component). This suggests that the singularity behaviour of the solution is more or less decoupled from the energy decay behaviour. (Note also that the construction in my paper suggests that blowup can be achieved using arbitrarily small amounts of energy.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c66ead9d57be1b9fb7c592d26498fb6199c971c567dc67ba8ee06bc82148674-581fe2315e6309a341cd26d11f68809d4c26c86e03c878e710d821f1ed6602fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Juha-Matti Perkkiö")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-453568")[#strong[#text("Juha-Matti Perkkiö")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2015")])]

#text("Dear prof. Tao,")

#text("Of course the route from a lower bound of the energy to a possible long-time existence of regular solutions is far from obvious. However, they are at least somewhat connected already in a very primitive level: If there was a solution whose energy decays too rapidly, say at the exact rate E(t)=(T-t)^a for some interval [T’,T] and a<1, then the H^1-norm would blow up at t=T. This naive remark is of course not in discord with your argument, but it already suggests that energy decay and regularity are at least somewhat coupled.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/89c8e6d39e680619113cb97060118a81c1d4762297b44ce173cc8166e6c08077-bcd617ca79e0b7a87dcbc6683877f6f75bed285687ec63c8603ff1f81dc1a4ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andreas Z.")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-456184")[#strong[#text("Andreas Z.")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2015")])]

#text("This is one of the most fascinating post I have read at your blog. If there any chance that you continue post about this topic and your progress or ideas? Thank you a lot! :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b9ea251d916a2c6590f5b3f959dea6053a939093d61c82b43b65a54c4877341-9b7fa5c51d835cd3f7d3c9e10b839fd5d2510ec2fa1ad3aa6f1c273410966e1e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergey")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-456293")[#strong[#text("Sergey")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2015")])]

#text("Dear Dr. Tao, let me present my article regarding the general solution of Navier-Stokes Eqs.:")

#link("http://arxiv.org/abs/1502.01206")[#text("http://arxiv.org/abs/1502.01206")]

#text("– I kindly ask you to give a few comments, if possible…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e68faf6a1de56db129cccfac7e546cadbea98b487f4d9d17dbc49782200dd9b6-8fd099777f67efdf56ad0645747efbfff1a8630ac9dfc2a865ecb6edb3c671a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-456507")[#strong[#text("Daniel")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2015")])]

#text("Dear Prof. Tao,")#linebreak()#text(" It is kinda hard to imagine how it is possible to create blowups while obeying the energy identity. Is the key here “finite time”? If your fluid has to be ideal in this system and you are taking dissipation terms into consideration, doesn’t it mean that your fluid can be non-ideal, too? I mean, if your system actually needs dissipation to operate as gates, why can’t it work with non-ideal fluids that will come with intrinsic dissipation? It sounded to me like a system where the wires has to be perfect conductors but you put resistive components into the circuit so you can do the gating. Did I misunderstand what ideal fluid or dissipation is? Another question, is there a fundamental reason why this approach won’t work with electromagnetic waves?")

#text("-Kind regard, Daniel.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-456508")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2015")])]

#text("The energy identity controls the total energy of the fluid, integrated over all of space, but it does not control the pointwise energy density of the fluid (or equivalently, the square of the speed of the fluid), because the energy could be concentrated in an arbitrary small ball of space. In particular, in the blowup scenario envisaged here, the energy remains bounded but is being concentrated into smaller and smaller balls, and in finite time one arrives at a singularity in which a finite nonzero amount of energy is supposed to concentrate into a single point, which cannot occur for a smooth solution to Navier-Stokes.")

#text("By “ideal fluid” here, I mean an incompressible fluid without dissipation, whereas Navier-Stokes models incompressible fluids with dissipation. So a system that is designed to work for ideal fluids does not work perfectly when one instead substitutes the viscous fluids modeled by Navier-Stokes. However, if one shrinks the system down to a very small spatial scale (and scales up the velocity field accordingly, keeping the total energy constant), this rescaling is effectively equivalent (in the sense of matching Reynolds number) to scaling down the viscosity to become very small while keeping the physical length scale unchanged, making the ideal fluid approximation much more accurate (and it will become exponentially more accurate if the system evolves as predicted to smaller and smaller scales). Because of this, I expect that if one can create the desired approximately self-similar dynamics for an ideal fluid (with suitable “error correction” coded in if necessary to give enough stability), then one can also obtain such dynamics for viscous fluids if one initialises the system to be supported in a sufficiently small scale (or equivalently, one assumes the viscosity parameter to be sufficiently small).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-456513")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2015")])]

#text("“…the energy remains bounded but is being concentrated into smaller and smaller balls, and in finite time one arrives at a singularity in which a finite nonzero amount of energy is supposed to concentrate into a single point…”")

#text("This reminds me of something I think I once read concerning the crack of a bullwhip (namely, that it results from the tip going supersonic).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d416f5927596debf18841a88ad56030bbd3b4742ac4fd29de2b90ca31f4b71d0-3793b5ea5bc549a25f8a9646914ee298b9185989c72bce6c43f8bf1105ae8a43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rbcoulter")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-456872")[#strong[#text("rbcoulter")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2015")])]

#text("Hello Professor Tao: Is it necessarily so that the energy is finite at a point in the blowup scenario? Assuming that the energy density is infinite in the blowup scenario, I would imagine that one would need to take limits to calculate the actual energy at that point. For example, if r is the radius of a ball surrounding the blowup point, then the mass of the ball is proportional to r cubed. If the velocity blows up proportional to 1/r^n then the energy blows up 1/r^2n. Since the energy at the blowup point is the product of the energy density and the mass of the ball, only in the case of n = 1.5 will the energy be finite at the point. For n1.5 the energy at the point is infinite.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7cdea2635a4a26437363f6317c926189ab29314cf00dcf8f1457917b328192f1-5bd989768bc567bdee96e8b37e5e158e942cc84c4f143162062a3b80459c4d0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of danield")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-457834")[#strong[#text("danield")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2015")])]

#text("I wonder what could be shown if the fluid were acted on by an external force – say the fluid was a turbulent plasma under the influence of a magnetic field – and somehow altering that magnetic field to control the direction of the turbulence")

#text("basically using an external force to do this – ”the energy remains bounded but is being concentrated into smaller and smaller balls”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-457847")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2015")])]

#text("It depends on how smooth the external force is, or equivalently how quickly it oscillates at small scales. If one applies a smooth external force, then by the time the energy is concentrated into a small ball, the force is effectively constant, and can be normalised to be negligible by applying a Galilean change of coordinates. (The analogy I sometimes use is that a smooth force is like the ability to manipulate an object with very fat, clumsy fingers; one do all sorts of macroscopic changes to the state with such a force, but it is difficult to obtain precise fine-scale control.)")

#text("If one allows for very rough external force, then one could certainly exhibit blowup as well – a singular external force can certainly produce a singular solution. But this is is rather easy to accomplish and doesn’t seem to shed much light on the global regularity question (which requires a smooth external force).")

#text("One possible interesting scenario, which has neither been constructed nor prohibited to my knowledge, is to find some singular (but still bounded velocity) ")#emph[#text("initial data")]#text(" that leads to blowup (in the sense of, say, the L^3 norm of velocity diverging) in finite time, without the assistance of a singular external force. In principle, one could imagine singularities in the data being somehow sustained until the time comes that they are needed to guide the solution from one fine scale to an even finer scale. There is a little bit of hope that such a scenario could be constructed for active scalar equations such as SQG, where the scalar is transported and so “remembers” in some sense its initial configuration. This would still be fairly far from a finite time blowup from smooth data with smooth external force, though.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-458140")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2015")])]

#text("What do you mean by singular initial data (but finite velocity)? How can we generate a fluid motion with such data?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-458143")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2015")])]

#text("By “singular” I mean here “not smooth”, for instance the velocity may be bounded, while the derivative of the velocity (or related quantities such as the vorticity) are unbounded (or perhaps it is the second derivatives of the velocity are unbounded). This allows for nontrivial fine scale structure to the initial data which could conceivably be used to “steer” the solution through its evolution through finer and finer scales into finite time blowup.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-458416")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2015")])]

#text("There is a paper (arXiv:1104.3615 or CommMathPhys 312(3)) whose initial data is close to the type you mentioned. It was claimed that the critical case L3-velocity norm blows up in finite time from initial smooth data with compact support (i.e. finite initial energy in R^3). Apart from lack of convincing apriori bounds and a few technical glitches, one assumption made in that paper was velocity field (and pressure) might be split into two parts: one part is linear and governed by the Stokes system, and the rest by the NSEs. Moreover, the separation assumption was considered to hold independent of the size of the initial data, and of time interval ahead possible singularity. No justification and qualification were given. By the well-known NS regularity for small data, the assumption cannot be valid for arbitrary initial data. In general, the claimed out-of-bound condition (Theorem 1.1) at most implies that the assumed flowfield breaks down in finite time; the blowup does not necessarily represent a genuine singularity condition for the NSEqs. (Similar arguments apply to paper arXiv:1508.05313.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b9ea251d916a2c6590f5b3f959dea6053a939093d61c82b43b65a54c4877341-9b7fa5c51d835cd3f7d3c9e10b839fd5d2510ec2fa1ad3aa6f1c273410966e1e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergey_Ershkov")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-456510")[#strong[#text("Sergey_Ershkov")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2015")])]

#text("Dear Prof. Tao, as for ansatz in the reference arXiv.org above, the momentum equation of NSE has been presented as a system of PDE (each was solved accordingly): invariant for pressure, and the sum of 2 equations: – with zero curl for the field of flow velocity (viscous-free), and the proper Eq. with viscous effects but variable curl.")

#text("A solenoidal Eq. with viscous effects is represented by the proper Heat equation for each component of flow velocity with variable curl.")#linebreak()#text(" Non-viscous case is presented by the PDE-system of 3 linear differential equations (in regard to the time-parameter), depending on the components of solution of the above Heat Eq. The general solution of PDE-system above is composed of the solutions of 2 complex Riccati Eqs. (which are chosen to form such a composed solution as the real function in any case).")

#text("So, the existence of the general solution of Navier-Stokes equations is proved to be the question of existence of the proper solution for such a PDE-system of linear equations. Final solution is proved to be the sum of 2 components: – an irrotational (curl-free) one and a solenoidal (variable curl) components.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-456610")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2015")])]

#text("Paper arXiv:1502.01206v3 is absolutely INCORRECT. Curl on every term in the large brackets in (2.1) equals to zero because curl(grad A)=0 for any scalar A. But the expression of 1st eqn in (2.3) does not vanish and is NOT the Bernoulli principle in general. Helmholtz’s decomposition of the velocity (vector) field has nothing to do with the (scalar) pressure. Eqns (2.3)-(2.5) are nonsense. It may be helpful to go back to basic textbooks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b9ea251d916a2c6590f5b3f959dea6053a939093d61c82b43b65a54c4877341-9b7fa5c51d835cd3f7d3c9e10b839fd5d2510ec2fa1ad3aa6f1c273410966e1e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergey_Ershkov")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-456612")[#strong[#text("Sergey_Ershkov")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2015")])]

#text("“Curl on every term in the large brackets in (2.1) equals to zero because curl(grad A)=0 for any scalar A.” – yes, this is true (this is trivial, obvious note). And what else?")

#text("“But the expression of 1st eqn in (2.3) does not vanish and is NOT the Bernoulli principle in general” – I don’t suggest it to be vanish or to be equal to Bernoulli invariant (I supposed it to be like ~ Bernoulli invariant).")

#text("I suggest to present 1 non-linear PDE (Navier-Stokes) as a sum of 3 parts: Bernoulli-like invariant, and 2 others (curl-free and with variable curl).")

#text("You should be more attentive when you read a text!")

#text("“Helmholtz’s decomposition of the velocity (vector) field has nothing to do with the (scalar) pressure” – I have no aim “to do with the (scalar) pressure”. I just present the vector gradient field of the scalar components of pressure is to be dependent on the appropriate components of the velocity field.")

#text("“Eqns (2.3)-(2.5) are nonsense” – this is my approach to represent of initial NSE as a sum of 3 Eqs. (I have explained it above already). Such decomposition is true, if we could find the proper solution to each of them.")

#text("“It may be helpful to go back to basic textbooks” – I kindly advise you not to be dubious and also you should be more attentive when you read any scientific material.")

#text("Kind regards!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/06914662c60bd7e108bcd09fb1139b1881783139d7b96e79fb71cc9a010b0ac1-d6b22910efcc6a94916e631b122a6d0cfc29807072bde205b6cf7d3ca7f29eb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-457453")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2015")])]

#text("Ershkov’s solution is CORRECT and must enter in the basic textbooks as the most closer one to the problem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b9ea251d916a2c6590f5b3f959dea6053a939093d61c82b43b65a54c4877341-9b7fa5c51d835cd3f7d3c9e10b839fd5d2510ec2fa1ad3aa6f1c273410966e1e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergey_Ershkov")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-457954")[#strong[#text("Sergey_Ershkov")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2015")])]

#text("Thank you for your esteemed opinion, my unknown friend Anonymous (#2). We are under attack with you :) {I mean the enormous number of likes/dislikes}.")

#text("Yes, I think that my solution has been presented in a more general form than ever. But it concerns only the time-depending structure of solution; the space part is determined by 4 PDEs of 1-st order {for curl-free part of solution} – i.e., by 1 continuity equation and 3 “zero curl” conditions – and additionaly determined by the Heat-transfer Eq. {for the part of solution with variable curl}.")

#text("Such a decomposition – curl-free vs. variable curl – is defined by the fundamental Helmholtz theorem of vector calculus.")

#text("As for decomposition of one non-linear PDE (for curl-free part of solution) to the system of 1 invariant of Bernoulli-type + system of linear PDEs in regard to the time-parameter t: – of course, you should know a Caratheodory’s existence theorem – it proves the existense of a solution for such a case.")

#text("So, in a future it should be investigated properly the space part of a solution (I mean the solving of 4 PDEs of 1-st order above + Heat-transfer Eq.) as well as it should be calculated the appropriate estimations for energy of the flow – according to the demands of Clay Mathematics institute.")

#text("I hope that my first result (concerning the presentation of general solution of Navier-Stokes Eqs.) will make it possible to solve this problem by some unknown genius … if you have any questions regarding my paper or about some collaborations {may be, future mutual publications about NSE}, you could contact me through ResearchGate.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b9ea251d916a2c6590f5b3f959dea6053a939093d61c82b43b65a54c4877341-9b7fa5c51d835cd3f7d3c9e10b839fd5d2510ec2fa1ad3aa6f1c273410966e1e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergey_Ershkov")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-456586")[#strong[#text("Sergey_Ershkov")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2015")])]

#text("Here below you will find the up-to-date reference, for your perusal:")

#text("“On Existence of General Solution of the Navier − Stokes Equations for 3D Non-Stationary Incompressible Flow”")

#link("http://www.dl.begellhouse.com/ru/journals/71cb29ca5b40f8f8,669062760250c799,0679e1964365ade8.html")[#text("http://www.dl.begellhouse.com/ru/journals/71cb29ca5b40f8f8,669062760250c799,0679e1964365ade8.html")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-457455")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2015")])]

#text("So many likes/dislikes")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/250ef44e5d9d1498ea529d42aadcaffe2e5b53cc77b294899c5c801f565a46d1-6ecc6a0b1cac73fe5554dc1b87ebbcb29d1c33f3132fd813bcce6c454eaf5b50.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Ericson")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-457767")[#strong[#text("Lars Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2015")])]

#text("Regarding the self-replicating at finer scales von Neumann machine, would the ideas of digital physics be relevant? (")#link("https://en.wikipedia.org/wiki/Digital_physics")[#text("https://en.wikipedia.org/wiki/Digital_physics")]#text(") In digital physics, the universe is a cellular automata. There is nothing smaller than a single cell, and the speed of light is the “clock speed”, the rate at which information can move from one cell to the next. In that model, you can’t keep infinitely self-replicating at smaller scales, because you can’t replicate smaller than a single cell.")

#text("Also there is that intuition that computation = energy, in the sense that if I have an idle GPU it consumes 35W. When it is 100% utilized it consumes 235W and heats up. You can try to speed up the GPU by freezing it or by increasing the clock speed. At higher clock speeds, the GPU consumes quadratically more energy. The freezing also takes energy. Both of these imply a physical limit on miniaturizing computation. (")#link("http://electronics.stackexchange.com/questions/81344/is-cpu-gpgpu-heat-dissipation-quadratic-in-clock-frequency")[#text("http://electronics.stackexchange.com/questions/81344/is-cpu-gpgpu-heat-dissipation-quadratic-in-clock-frequency")]#text(")")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-457849")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2015")])]

#text("NS regularity is a problem in pure mathematics, inspired by physics but not constrained by it. It’s set in a continuum so there is no “Planck constant”. It’s just like geometry was inspired by surveying but intuitions from surveying are of no use in understanding the Banach-Tarski paradox. You have to work out all the details, and in the case of NS, it’s hard enough that nobody has been able to do that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/250ef44e5d9d1498ea529d42aadcaffe2e5b53cc77b294899c5c801f565a46d1-6ecc6a0b1cac73fe5554dc1b87ebbcb29d1c33f3132fd813bcce6c454eaf5b50.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Ericson")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-457891")[#strong[#text("Lars Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2015")])]

#text("It’s a thought experiment to make computers out of water that make tinier computers out of water. It’s a real experiment to take a chip and overclock it to make it go faster and then discover that you have to add a tower of liquid nitrogen so it doesn’t melt, and that the amount of energy consumption and concomitant required cooling grows exponentially (not quadratically as I said mistakenly in the post) with clock speed. Tiny fast computers need giant hot coolers so they can be tiny and fast. There are all kinds of physically-induced tradeoffs. These are experimentally observable. Theoretically, digital physics posits a lower bound (the cell) on even-tinier self-replication. John Wheeler posited the “it from bit” connection. (")#link("https://en.wikipedia.org/wiki/Digital_physics#Wheeler.27s_.22it_from_bit.22")[#text("https://en.wikipedia.org/wiki/Digital_physics#Wheeler.27s_.22it_from_bit.22")]#text(") Ed Fredkin posited that all things are discrete rather than continuous. (")#link("http://www.bottomlayer.com/bottom/finite-all.html")[#text("http://www.bottomlayer.com/bottom/finite-all.html")]#text(") Cellular models explain the speed of light as the clock speed to move information from one cell to the next. (")#link("https://en.wikipedia.org/wiki/Speed_of_light_%28cellular_automaton%29")[#text("https://en.wikipedia.org/wiki/Speed_of_light_%28cellular_automaton%29")]#text(")")#linebreak()#text(" A non-trivial thought experiment would take into consideration both the real, observable physical limits to computing, and the theoretical ones. So to say that NS is inspired by physics but not constrained by it is, pragmatically speaking, nonsense, because physically unconstrained solutions will have no physical relevance. Yes, you can mathematically construct an infinite sequence of numbers, but you can’t construct them all and pile them on a plate.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-457878")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2015")])]

#text("According to the official problem description (by the Clay Math. Institute), “… if there is a solution with a finite blowup time ")#mi("T")#text(", then the velocity ")#mi("u(x, t)")#text(" becomes unbounded near the blowup time.” (pages 2-3).")#linebreak()#text(" Therefore, it seems reasonable to expect that there is a (special) relativistic version of the NS equations without a finite blowup time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90c02f41607c68dc2bed941e13427d5caa05ebbef2fbcce8749d6ba70055a4a2-ba58d5187ecfe093fa29070570e91eae9d0d8a98aca2cf6ce452f53fa4647938.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arithmetica")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-457885")[#strong[#text("arithmetica")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2015")])]

#text("So who’s the dingus who downvoted all of Terry’s comments for no reason? What juvenile behavior.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b9ea251d916a2c6590f5b3f959dea6053a939093d61c82b43b65a54c4877341-9b7fa5c51d835cd3f7d3c9e10b839fd5d2510ec2fa1ad3aa6f1c273410966e1e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergey_Ershkov")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-457889")[#strong[#text("Sergey_Ershkov")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2015")])]

#text("arithmetica, this is indeed juvenile behavior.")

#text("I suspect Anonymous as the main hooligan, who commented before you (see such an enormous number of likes/dislikes at his reply to me from 12-17 June 2015 as well as in my posts). This is unnormal behaviour.")

#text("As for me, I respect opinion of Dr.Tao.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/318c21e03549232532ba40248dbd7f1d212da5f84e4e003c954b80189feba4d4-038039ecb74a0d97e1ed2f8baed80547c8ee70949e03ee2a557bad902c5d3de8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philip L")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-458316")[#strong[#text("Philip L")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2015")])]

#text("I saw your talk for the Einstein Memorial lecture, and it was interesting. Your method reminds me of several things, aside from of course cellular automata. Some automata are able to perform all computations, I suppose this includes non-linear dynamics.")

#text("1. Density functional theory. Density functional theory was originally used in chemistry to determine the spectrum of molecules. It allows approximation of a relatively intractable multi-body systems (i.e. electron-electron interaction, electron-nucleus interaction). It uses correlations (k-space mean field), providing additional structure (in the literal sense). The approximation can be refined by including 3-body correlations, 4-… etc. Ground states of main interest for chemists, physicists, and maybe molecular biologists because this is normally the only states that are thermodynamically accessible, and is the closest to the actual symmetry of the molecule. I also would like to mention the correspondence between (self interacting) solitons and the Schroedinger inverse problem.")

#text("2. Formation of (essential) singularities in finite time. This is also found in relativity, or calculations for formation of black holes. GR are nonlinear equations, which do not (yet?) have a proper Feynman diagrammatic perturbative description.")

#text("3. Diagrammatic expansion, This relates to points 1. and 2. . However, your work would differ in the sense that an exact description of non-renormalizable dynamics, where the approximation is refinable. The Feynman approximation involves linear interactions only (though QED might remain true for high amplitude/energy interactions, I think). There is no theory like this for gravity that I know. But my knowledge is humble.")

#text("Also, I learned in fluid mechanics Richardson-Kolmogorov cascade.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/318c21e03549232532ba40248dbd7f1d212da5f84e4e003c954b80189feba4d4-038039ecb74a0d97e1ed2f8baed80547c8ee70949e03ee2a557bad902c5d3de8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philip L")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-458318")[#strong[#text("Philip L")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2015")])]

#text("There are also multi-time/scale approximations. There being the possibility of separable time scales, despite the absence of superposition. How do the frequencies of these modes change as parameters are changed? There may be a ‘topological phase transitions’ in the spectrum, and other global changes (e.g. bifurcations, cusps).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/318c21e03549232532ba40248dbd7f1d212da5f84e4e003c954b80189feba4d4-038039ecb74a0d97e1ed2f8baed80547c8ee70949e03ee2a557bad902c5d3de8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philip L")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-458321")[#strong[#text("Philip L")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2015")])]

#text("The GR case may be bit different. Here the singular is more like a 3 sphere in hyperbolic space. I have not encountered metrics with blackhole formation after a certain amount. It seems the topology or geometry is different in that case (maybe a 3 sphere cut out for example)? But there are theorems apparently about this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-459358")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2015")])]

#text("It should be that it applies at ‘high energy’ instead of ‘large amplitude’, I believe.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/938c0ad76c99f00e3c4f1c273ca756f90b746c912b793a778c6874567fe5d39e-21d263315e6389bff835655d8520e33f2f934e52f4c754b1f9be8797b0c0bc43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergey_Ershkov")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-459935")[#strong[#text("Sergey_Ershkov")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2015")])]

#text("Very interesting article of Michael Thambynayagam regarding the ansatz for resolving of Navier-Stokes eqs.:")

#link("http://arxiv.org/abs/1509.08766")[#text("http://arxiv.org/abs/1509.08766")]

#text("– who is keen in the matter, should recognize this article to be worthy of a review at the Annals of Mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-464520")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2015")])]

#text("Let me try to give a more restrictive definition of what it would mean that")

#text("(*) “NS only supports ‘easy’ computation”.")

#text("This can have two purposes. The first, in case that Terry’s conjecture is correct and full computation is supported by 3D NS evolutions, (*) can be used to describe additional (implicit) conditions on realistic NS evolutions.")

#text("The second, more exciting, possibility is that (*) can actually be proved for 3D Navier-Stokes equation. This would be interesting on its own and may be a step for proving regularity.")

#text("In a comment above I proposed to take “easy computation” to be “bounded depth computation”. Namely (*) would mean that every computation described by NS can be approximated by bounded depth computation (circuit). A considerably weaker form of computation (and thus a much stronger form of (*)), would take “easy computation” to refer to the ability to describe (approximate) the computation by bounded-degree polynomials. (This is related to the notion of “noise-stability” used by Benjamini Schramm and myself.) A recent paper were “easy computation” of this kind was demonstrated to certain quantum systems is a paper by Guy Kindler and me")#linebreak()#text(" on Gaussian noise sensitivity and BosonSampling ")#link("http://arxiv.org/abs/1409.3093")[#text("http://arxiv.org/abs/1409.3093")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Finite time blowup for an Euler-type equation in vorticity stream form | What's new")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-465904")[#strong[#text("Finite time blowup for an Euler-type equation in vorticity stream form | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2016")])]

#text("[…] been meaning to return to fluids for some time now, in order to build upon my construction two years ago of a solution to an averaged Navier-Stokes equation that exhibited finite time blowup. (I recently […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-466063")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2016")])]

#link("http://www.navier-stokes-equations.com/problem")[#text("http://www.navier-stokes-equations.com/problem")]#linebreak()#text(" This is an intersting website.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d416f5927596debf18841a88ad56030bbd3b4742ac4fd29de2b90ca31f4b71d0-3793b5ea5bc549a25f8a9646914ee298b9185989c72bce6c43f8bf1105ae8a43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rbcoulter")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-466475")[#strong[#text("rbcoulter")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2016")])]

#text("It seems that the averaged operator. T , can be viewed as the difference of the NS transport operator, TS, minus an external force (F).")

#text("Specifically T = NS – F")

#text("or F = NS – T")

#text("If F passes the conditions of (5) or (9) then this may acceptable as a blowup solution under the Clay rules.")

#text("The main question, in my mind at least, does F stay bounded at the blowup time?")

#text("In this interpretation the external force “pushes” or “is pushed” by the fluid. It can only be allowed to do this in a macro (smooth) way since any other way, that I can imagine, would violate conditions (5) or (9). The trick, however, is that at the instance of blowup, the last bit of energy must come naturally from the fluid itself to avoid the trivial blowup scenario of simply extracting energy at an infinite power density rate at the blowup point (from the external force field).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Finite time blowup for a supercritical defocusing nonlinear wave system | What's new")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-466480")[#strong[#text("Finite time blowup for a supercritical defocusing nonlinear wave system | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2016")])]

#text("[…] a question asked of me by Sergiu Klainerman recently, regarding whether there were any analogues of my blowup example for Navier-Stokes type equations in the setting of nonlinear wave […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Finite time blowup for high dimensional nonlinear wave systems with bounded smooth nonlinearity | What's new")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-466717")[#strong[#text("Finite time blowup for high dimensional nonlinear wave systems with bounded smooth nonlinearity | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2016")])]

#text("[…] sine-Gordon equation is not covered by our arguments. Nevertheless (as with previous finite-time blowup results discussed on this blog), one can view this result as a barrier to trying to prove regularity for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Finite time blowup for Lagrangian modifications of the three-dimensional Euler equation | What's new")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-470143")[#strong[#text("Finite time blowup for Lagrangian modifications of the three-dimensional Euler equation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2016")])]

#text("[…] of the three-dimensional Euler equation“. This paper is loosely in the spirit of other recent papers of mine in which I explore how close one can get to supercritical PDE of physical […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98d192abd70f5311db8ec60dec56a48604f76cb7ff6a4cf4f5df43803680c3ff-cb5dcadf7bcf8b56cb8857c450f2fddd18645e59e478b53d2f6ab76b378a6646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jhon Manugal")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-470151")[#strong[#text("Jhon Manugal")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2016")])]

#text("Can you explain a little bit more about your “water computer” — I am afraid after reading this once or twice I could not find the operators.")

#text("I know that ODE can be discretized into recurrence relations (e.g. Euler Method), but that Euler Method “ought to” converge to the ODE.")

#text("Yet Cellular Automata can also be encoded as recurrence relations… therefore should be some vague relation between ODE and the model of computation of your choice.")

#text("All of that is excellent in theory except, in any one specific case I wouldn’t know how to build a computer. Not if my life depended on it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-470152")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2016")])]

#text("Is there any explicit(!) lower bound (in terms of the initial data) for a possible blowup time?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-470188")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2016")])]

#text("In two of the theorems, the data is carefully selected with an upper bound of the blowup time of 1, but the result does not say anything about generic data. For the first blowup result, which is more stable, if the initial data is supported in a narrow cylinder of width ")#mi("r")#text(" around the origin with a total circulation of ")#mi("C > 0")#text(", then the blowup time will be bounded by ")#mi("O( r^2 / C )")#text(", which is consistent with dimensional analysis and also the Beale-Kato-Majda criterion (vorticity has units of inverse time, while circulation has units of length squared per unit time).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-470199")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2016")])]

#text("Is the implied constant in ")#mi("O(r^2/C)")#text(" an absolute (i.e. independent of the initial data) and effectively computable?")

#text("Is there also a similar lower(!) bound for the blowup time?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-470204")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2016")])]

#text("Assuming that the data is supported inside the cylinder of radius r (at least in a large neighbourhood of the origin), the constant is absolute. With enough control on higher derivatives of the initial vorticity, one should also be able to obtain a matching lower bound from the usual local existence theory (since one can morally rescale both time and space to normalise ")#mi("r")#text(" and ")#mi("C")#text(" to both be comparable to 1), but I haven’t checked this.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb8144d0ddbf6f26b1756bcfa91c227be21d20dae40125954860dc4c1b05df1e-1fdd9d7b6209fad093a3bf06f2d0f7716eea55691ee7fd0b4b322b0d9f3df142.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fahad")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-471524")[#strong[#text("Fahad")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2016")])]

#text("I know that the Navier-Stokes existence is really hard (probably that is the reason why you choose to solve variations of the Navier-Stokes) but I am just curious to know whether the energy dissipation can be used along with local existence and smoothness to prove global smoothness and existence in 2D or 3D? (like the one proposed by the Clay Mathematics Institute)")

#text("I am just a high school student, so, mostly my proof will be turned down by the math community.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5300af1818b8761458a6f02cfea203aa82326dfa94d21ebf450c03d10cbb52ee-cf9c768b018abac89ec66cccb335f859e5e145972366ade7b7ce092b5046b429.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dejan Kovacevic")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-471594")[#strong[#text("Dejan Kovacevic")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2016")])]

#text("Fahrad- I hope that Terry will answer your question. However, regarding likelihood to be turned down by math community – don’t worry about that, follow your instincts, consult others, and make sure that you cover and analyze all possible issues and question all, even yourself. Keep questioning and finding the answers, as there is only one truth, regardless of communities of practice or interest. Eventually, what is truthful surfaces up as such, inevitably so.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-471644")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2016")])]

#text("This is discussed in detail in my other blog post ")#link("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")[#text("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")]#text(" . Basically, the answer is no, because the time of existence provided by the local theory can be arbitrarily small even when there is very little energy left to dissipate, and iteration of the local existence theory could thus conceivably lead to a convergent series which is consistent with finite time blowup. Note also that the equation considered in my paper here also has local existence and regularity as well as an energy dissipation inequality, yet still manages to exhibit solutions that blow up in finite time.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb8144d0ddbf6f26b1756bcfa91c227be21d20dae40125954860dc4c1b05df1e-1fdd9d7b6209fad093a3bf06f2d0f7716eea55691ee7fd0b4b322b0d9f3df142.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fahad")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-471665")[#strong[#text("Fahad")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2016")])]

#text("Even I thought the same when I first encountered the problem initially. But, the energy dissipation in (28, Vorticity and Incompressible flow – Bertozzi, Majda) implies that before a singularity is formed, a small region of high energy is formed. This, in turn, forces the energy of the remaining regions")#linebreak()#text(" to be approximately close to zero. Let this region be Ω. the energy at the boundary ∂Ω is approximately zero compared to the absolute maximum in Ω. This almost forces the velocity field and its derivatives to be almost zero due to the above energy dissipation. Now, the proof proceeds as below link.")

#link("https://drive.google.com/file/d/0Bw5XWeTV9WGOLXhHMUxPUFFsY3M/view?usp=sharing")[#text("https://drive.google.com/file/d/0Bw5XWeTV9WGOLXhHMUxPUFFsY3M/view?usp=sharing")]

#text("leading to the conclusion that the energy of the point where the energy is maximum in Ω, should decrease. Therefore, the solution remains in Schwartz space till infinity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb8144d0ddbf6f26b1756bcfa91c227be21d20dae40125954860dc4c1b05df1e-1fdd9d7b6209fad093a3bf06f2d0f7716eea55691ee7fd0b4b322b0d9f3df142.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fahad")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-472037")[#strong[#text("Fahad")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2016")])]

#text("Sir")#linebreak()#text(" I expect your view about my idea shown above :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23528d86ce5cfe031ad2ac34fb5eef8f5c3e5dc35dfa73c6ed9e2079ba6d6372-33bd23c9cf3503b14036c27c265c327f47fa3a35c8c9ac8d0e58819f9f68bc61.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tao Chi")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-471666")[#strong[#text("Tao Chi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2016")])]

#text("hi… Terence Tao… my name is Tao Chi… and I Iive in Slovenia…")#linebreak()#text(" I saw… that you have deleted my video…")#linebreak()#text(" ")#linebreak()#text(" I give you a information… that I don’t care about this… that you have deleted… but I do care… that you didn’t give any reason for this action… or any explanation on my knowledge… which of course is not only mine… because it is a universal knowledge… like all of the knowledge… and that also means… that no human being should not give himself any special awards for any knowledge… everything what the human should do is… that he is a grateful for this knowledge… and that he apply this knowledge with ethics…")#linebreak()#text(" and ethics is… that you answer me on this message and that you explain me… what is wrong or what is right in my video…")#linebreak()#text(" if not… then I ask you… that you also delete my previously videos…")#linebreak()#text(" thank you…")#linebreak()#text(" P.S. If you see and work only with intelligence… you can be very wrong… because this is only a little part of wholeness…")#linebreak()#text(" intelligence is only a muscle which you can pumped up… but there are always a limits… like they are by muscles on the human body… but If you cross these limits… then you do more damage to yourself… than the benefits… by the intelligence we call this madness…")#linebreak()#text(" math… geometry… etc… are very welcome tools… for understanding how the universe work… but this tools are tools of the source… and that’s why we must use this tools with ethics… gratefulness… love… and in balance… if not… then you do more damage to yourself and to the others… than the benefits…")

#text("and that’s why the primes must be in interaction with non-primes… otherwise the intelligence will be in imbalance and in a state of ignorance…")

#text("with love and gratefulness…")#linebreak()#text(" TaoChi…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb8144d0ddbf6f26b1756bcfa91c227be21d20dae40125954860dc4c1b05df1e-1fdd9d7b6209fad093a3bf06f2d0f7716eea55691ee7fd0b4b322b0d9f3df142.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fahad")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-471668")[#strong[#text("Fahad")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2016")])]

#text("Well, Terence Tao has put forth some requests (rules) of commenting in his blog, and it reads:")

#text("“I welcome comments from people with all kinds of mathematical backgrounds and levels of expertise; my only requests are that the discussions are kept constructive, polite, and at least tangentially relevant to the topic at hand. Comments which are spam, self-promoting, off-topic, or otherwise not fulfilling the above requests will be summarily deleted; repeated offenders in this regard may be subject to blocking. In particular, comments devoted primarily to promoting one’s own research are subject to deletion.”")

#text("And it probably is the reason why yours got deleted.")

#text("If you wish it to be promoted, formalise it in a form acceptable in the modern math community, and then publish it in a peer-reviewed journal. You can ask questions here, but it should be specific to the post (or thread).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23528d86ce5cfe031ad2ac34fb5eef8f5c3e5dc35dfa73c6ed9e2079ba6d6372-33bd23c9cf3503b14036c27c265c327f47fa3a35c8c9ac8d0e58819f9f68bc61.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tao Chi")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-471671")[#strong[#text("Tao Chi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2016")])]

#text("hi Fahad…")#linebreak()#text(" thank you for your explanation… I didn’t know for this rules… and certainly my presentation is not for promoting myself… it’s just the knowledge for which I am happy and I wish to shere… discuss and to use this knowledge with others…")

#text("with love and gratefulness…")#linebreak()#text(" TaoChi")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23528d86ce5cfe031ad2ac34fb5eef8f5c3e5dc35dfa73c6ed9e2079ba6d6372-33bd23c9cf3503b14036c27c265c327f47fa3a35c8c9ac8d0e58819f9f68bc61.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tao Chi")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-471826")[#strong[#text("Tao Chi")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2016")])]

#text("because I see… that you didn’t understand… what I have given to you… I will explain this with some other facts…")#linebreak()#text(" 5 x 5 = 25")#linebreak()#text(" 5 x 7 = 35")#linebreak()#text(" 7 x 7 = 49")#linebreak()#text(" 11 x 5 = 55")#linebreak()#text(" 13 x 5 = 65")#linebreak()#text(" etc…")#linebreak()#text(" we see… that primes creates non-primes with a meaningful reason… because without them… they cannot work as wholeness or in harmony…")

#text("all systems like military systems… banking systems… etc… which for use only apply the prime numbers… are always in chaotic state… which proves everything what they do… and that’s why they must always fight for their own existence… because otherwise they will collapse immediately… and the reason for this is… because they don’t use the wholeness… and this is easy to see through perception where a man see only himself… and that’s why he is always in chaos… but when he see also a woman of course as equivalent… then suddenly everything is in balance… and this simple equation or algorithm… I have given to you in this video… etc…")#linebreak()#text(" all mathematicians… which will continuously search the meaning only in primes… they will always be in chaos… because they will not see the wholeness or harmony… and they will continuously chasing some ghost… which always disappears in the middle of some algorithm… what I have seen in my research… therefore… there are no twin primes… sexy primes… etc… because they are only here and there… and in mathematics and geometry… this is not a proof or algorithm… which work into infinity…")#linebreak()#text(" so… now is the decision… like always is… we can accept the solution or not… but the reality for this decision… always show us the real picture in our daily lives… what we see as…")#linebreak()#text(" action = reaction")#linebreak()#text(" cause = consequence")

#text("with love and gratefulness…")#linebreak()#text(" TaoChi…")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-471832")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2016")])]

#text("???")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23528d86ce5cfe031ad2ac34fb5eef8f5c3e5dc35dfa73c6ed9e2079ba6d6372-33bd23c9cf3503b14036c27c265c327f47fa3a35c8c9ac8d0e58819f9f68bc61.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tao Chi")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-471836")[#strong[#text("Tao Chi")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2016")])]

#text("Anonymous… ask me… what you wish to know… and then I can give you an answer… if I can…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23528d86ce5cfe031ad2ac34fb5eef8f5c3e5dc35dfa73c6ed9e2079ba6d6372-33bd23c9cf3503b14036c27c265c327f47fa3a35c8c9ac8d0e58819f9f68bc61.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tao Chi")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-471980")[#strong[#text("Tao Chi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2016")])]

#text("try to make a rectangle… hexagram… 8-gon… etc… only with primes… and you will see… that this is not possible… or you will see… that you get a chaos… and therefore non-primes are necessary and meaningful…")#linebreak()#text(" in real life… this is clearly to see… if we look for example through the monetary system… where is possible… that someone has a lot of money and someone has no money… with a simple math equation… we can clearly see… that there is no balance… therefore if we see only the primes as important… as if we see only the humans which are rich as important… then we get a chaos… because we cannot connect the lines… which can create a harmony… and this is shown in this video…")#linebreak()#text(" so… in this game the primes together with non-primes can make a harmony… balance… and of course a wholeness… but this is only math and geometry… in real life… we must use also other skills…")#linebreak()#text(" but in the monetary system we can create a balance… if we all have only one currency… and this can be simple created through the virtual world… like onecoin… bitcoin… etc… but by this currency… there are no more external owners… this means… that each individual… which will open this account and he will start to use this currency… it will become the sole owner of this account and all of the money on his own account… the beauty in this is… that all of this is similar… how the source of everything work… which is essentially 0… that means… that you start with 0… and then you have no limits… like the source don’t have no limits…")#linebreak()#text(" of course in this reality is only one law… and in this law is good to be honestly and sincerely… because this law is the source law… which cannot be changed… tricked or bypassed… and this law is…")#linebreak()#text(" action = reaction")#linebreak()#text(" or…")#linebreak()#text(" cause = consequence")#linebreak()#text(" this means… it is necessary… that we use the energy wisely… with ethic… gratefulness… in balance… and of course with love… like with the life energy… because only so… we can be in balance…")#linebreak()#text(" this is simple mathematical equation… which can create a beautiful life on this beautiful planet… and only we are capable to make this into the reality… thank you…")

#text("with love and gratefulness…")#linebreak()#text(" TaoChi…")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb8144d0ddbf6f26b1756bcfa91c227be21d20dae40125954860dc4c1b05df1e-1fdd9d7b6209fad093a3bf06f2d0f7716eea55691ee7fd0b4b322b0d9f3df142.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fahad")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-472036")[#strong[#text("Fahad")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2016")])]

#text("Hello Tao Chi")

#text("It is a humble request not to post irrelevant comments here. By this action most of the relevant ones are left behind not being able to get it replied. This post is about fluids, and yours is not at all related to this. Thus, It isn’t a good idea to post these kind of ideas here…")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e80c2bfa298d4886a507d9a4a825c9b92eda39a3f6beb10f7bb921d5adde1ae-b1f05f42ac1417ca9a591ad51a17dd49c39b80a1e267d76997fd2a9e69319ce2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Viktor Ivanov")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-473692")[#strong[#text("Viktor Ivanov")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2016")])]

#text("Dear Professor Tao,")#linebreak()#text(" Here are 3 counterexamples to your “supercriticality barrier”,: ‘The main purpose of’ the paper “Finite time blowup for an averaged three-dimensional Navier-Stokes equation“, submitted to J. Amer. Math. Soc.. 29 (3): 601–674.")#linebreak()#text(" 1. Let us consider the 3D \\int [(Z\\cdot u)u](Z, r)A_r(Z)dZ = I, \\int A_r(Z)dZ = 1, where A_r(Z) under r \\rightarrow 0 is 3D Dirac delta function, u is a square integrable solution of the 3D Navier-Stokes equations. It is clear that I = 0, but almost all averages of (Z\\cdot u)u yield I \\neq 0. And \\int _0^t I(r)/rdr , where t C > 0} z_ju_k^2(Z, r)e^{-|z_j|^2/r}dz_j/r^3dr \\leq const., where u_k \\neq 0 is a component of u and t < blowup time, and hence has no blowup time, but its averages can be \\infinity.")#linebreak()#text(" 3. I(r) = \\int_0^\\infty \\int _0^\\infty \\int sign (z_j)e{-|z_j|h}|u(Z, r)|^2dZ\\sum _{l \\neq j} s_l^2 \\prod_{l \\neq j}ds_l , h = (\\sum _{l \\neq j} s_l^2)^{1/2}, I \\leq \\int_0^\\infty \\int _0^\\infty e{-Ch} \\sum _{l \\neq j}s_l^2\\prod_{l \\neq j}ds_l | |u(., r)||^2 \\leq C||u(., r)||^2, where C is a positive constant. So, \\int_0^t I(r)dr \\leq Ctsup_r ||u(., r)||, i.e., we have no blowup time. However, for almost any averages inside of the integrals, we have I(r) = \\infty.")#linebreak()#text(" All 3 counterexamples-types are employed in my paper ‘A classical solution of the 3D Navier-Stokes and Euler problems’, which I sent you and asked to endorse for ArXiv, but have no response.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e80c2bfa298d4886a507d9a4a825c9b92eda39a3f6beb10f7bb921d5adde1ae-b1f05f42ac1417ca9a591ad51a17dd49c39b80a1e267d76997fd2a9e69319ce2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Viktor Ivanov")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-474490")[#strong[#text("Viktor Ivanov")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2016")])]

#text("Here is the second counter example:")

#text("2. \\int_0^t \\int _{-\\infty}^\\infty z_ju_k^2(Z, r)e^{-|z_j|^2/r}dz_j/r^3dr \\leq \\int_0^t \\int _{|z_j| > C > 0} z_ju_k^2(Z, r)e^{-|z_j|^2/r}dz_j/r^3dr \\leq const., where u_k \\neq 0 is a component of u and t < blowup time, and hence has no blowup time, but its averages can be \\infinity")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-475218")[#strong[#text("Sketch of the Koch-Tataru theorem | Analysis and PDE Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2016")]

#text("[…] Mild solutions are constructed by considering the Navier-Stokes as a perturbation of the heat equation. In particular, the arguments used in the construction do not use the special cancellation structure (4) of the non-linearity. By themselves, they are not enough to solve the global regularity conjecture (see Tao’s discussion here). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/25e91d0a1e843c4440eb1cdeb229e0ae758ca9f91797cc059dbed9cdcb065c2b-99a410c9bb639d7a9ed75da40029f09573b3fe07f0c76390da287574826a4fb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon C")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-475742")[#strong[#text("Jon C")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2016")])]

#text("I must have read this article a long time ago, and have thought about this issue for a few years. My original motivation for thinking about ‘fluid machines’ was based from a science fiction novel called ‘Star Maker’ by Olaf Stapledon, which posits that the stars themselves can be alive. I wondered if perhaps they could indeed be alive. I also felt that water would likely possess this property of being able to ‘be alive’, but that probably the closest to being able to prove it would be to prove that it can sustain a self-replicating structure, and that structure can derive energy from an input to the entire system. I’m almost certain that the approach you describe here will one day be able to prove (or disprove) such an idea. Perhaps either vortices or solar granules (respectively) could function as a fundamental unit to perform these operations.")

#text("One key difference with Conway’s Game of Life (and most cellular automata, L-systems, etc), is that they do not concern itself with energy derivation from its environment – which I suspect is highly important. In other words – the behaviour of Navier-Stokes with a bounded input function might give just as interesting of a result as whether NS are regular or not without an input. To that end, I wonder if going on a tangent to investigate ‘simple fluid machines’ that could derive energy from simple fluid flows, and remain self-sufficient would be a worthwhile investment. This is similar to recent developments in astrobiology, which recognize that a fundamental characteristic of life is that it acts as a concentrator of negentropy: ")#link("https://www.cambridge.org/core/journals/international-journal-of-astrobiology/article/div-classtitlethe-potential-for-detecting-life-as-we-donandapost-know-it-by-fractal-complexity-analysisdiv/81169D2F63946BCA4BB0DE6548597663")[#text("https://www.cambridge.org/core/journals/international-journal-of-astrobiology/article/div-classtitlethe-potential-for-detecting-life-as-we-donandapost-know-it-by-fractal-complexity-analysisdiv/81169D2F63946BCA4BB0DE6548597663")]

#text("This approach, if able to reach a result, might be able to be mapped to the original problem (i.e. if a particular bounded input function that develops a ‘water machine’ can produce life / infinite blowup exists, can that be ‘mapped’ (folded up somehow) to a set of initial conditions without an input function that produce identical output for the original NS problem?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db518652cc3070afcdabaa00554b256190b351b0c4b9c71591e17406f7c13d2c-3aeee3abec9d9c13ede67bd756ec0d9e752e956fb03715ee421141933f4762d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of itaibn")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-479494")[#strong[#text("itaibn")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2017")])]

#text("In section 6, I don’t see how you got inequality (6.71), which says that ")#tao-math("\\left|c_1 (\\tau_1)\\right| \\leq 10^{-5} \\exp (- K^{10}) \\epsilon^2 \\mu_1", block: false)#text(". Thinking about it heuristically I do not expect this inequality to be true: it should take ")#mi("\\sim 1/K")#text(" time for the energy to be transferred for ")#mi("d_0")#text(" to ")#mi("a_1")#text(", which takes place before ")#mi("\\tau_1")#text(". During this time ")#mi("b_1")#text(" should grow to approximately ")#mi("\\epsilon / K")#text(", and exert an amplifying force of ")#mi("\\sim K^9")#text(" for time ")#mi("\\sim 1/K")#text(". Combined with the pumping from ")#mi("a_1")#text(" for time ")#mi("1/K")#text(", the value of ")#mi("c_1")#text(" should be around ")#mi("C_0 \\epsilon^2 \\exp (C_1 K^8 - K^{10}) / K")#text(", which is much greater than ")#mi("\\epsilon^2 \\exp (-K^{10})")#text(".")

#text("Skimming the rest of Section 6, I believe you infer this from inequality (6.108) of Proposition 6.12. In page 67 you justify Proposition 12 in terms of Proposition 6.13 and Proposition 6.15. However, the corresponding (6.117) of Proposition 6.13 gives a weaker inequality in terms of ")#mi("\\exp (-K^{10}/2)")#text(" rather than ")#mi("\\exp (-K^{10})")#text(".")

#text("I don’t expect any of this to effect the global structure of your proof, as you can just replace ")#mi("\\exp (-K^{10})")#text(" with ")#mi("\\exp (-K^{10}/2)")#text(" in (6.17), (6.32), (6.71), and (6.108).")

#emph[#text("[Thanks for this, this will be corrected in the next version of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On the universality of potential well dynamics | What's new")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-483620")[#strong[#text("On the universality of potential well dynamics | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2017")])]

#text("[…] my previous work on blowup for Navier-Stokes like equations, I speculated that if one could somehow replicate a universal Turing machine within the Euler […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On the universality of the incompressible Euler equation on compact manifolds | What's new")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-484243")[#strong[#text("On the universality of the incompressible Euler equation on compact manifolds | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2017")])]

#text("[…] and curved manifold. This includes portions of the self-similar “machine” I used in a previous paper to establish finite time blowup for an averaged version of the Navier-Stokes (or Euler) equations. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/51e59967bac0c7254f370eb72d788066560f8f5f86d0950554f1aea48c569912-af4bc60f19eda8025b681ceb22e5a2d5cab1347a00e09aec6f31ea8a4f39891c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sadik Shahidain")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-485231")[#strong[#text("Sadik Shahidain")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2017")])]

#text("HI Terry,")

#text("Is there a relativistic form of the equations which has extra symmetry I could maybe try and use to our advantage?")

#text("Also lol at the analogy to turning this into a programming problem. I’m not really super good at math yet but programming I can get started on right aways! :)")

#text("Thanks,")#linebreak()#text(" Sadik")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-487828")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2017")])]

#text("Is there any known result showing that the initial data needed for finite time blowup for the NS equations should be “very special” in some sense ?")

#text("It is very unlikely, but is there any known result showing the opposite (that is, such initial data is “generic”, or at least “not very special” in some sense) ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-487855")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2017")])]

#text("It is generally expected that finite time blowup should be avoided for “generic” initial data for 3D Navier-Stokes (for a suitable notion of “generic”), but there are not many rigorous results in this direction. One such is by ")#link("https://arxiv.org/abs/1204.5444")[#text("Andrea Nahmod, Natasa Pavlovic, and Gigliola Staffilani")]#text(", who show that almost all random data in a rough Sobolev space will at least admit weak global solutions to 3D Navier-Stokes, although their result does not establish regularity of these weak solutions (or even uniqueness of these solutions). But in general we have not been terribly successful in leveraging genericity hypotheses on initial data to obtain better existence and regularity results on the evolution than one could get from deterministically worst-case initial data of the same regularity class.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-489593")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2017")])]

#text("Is it possible that the solution to this problem depends on some still unknown invariant of the NS equations? Is there a known list (generated e.g. by Cartan’s method) of all such invariants ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-489896")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2017")])]

#text("There have been efforts to systematically locate conservation laws for the Navier-Stokes and Euler equations, see e.g. ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3345572")[#text("https://mathscinet.ams.org/mathscinet-getitem?mr=3345572")]#text(" . Thus far no usable new conserved or otherwise controlled integrals of motion have emerged. This is not to say that no such law will ever be found, but personally I would assume as a default hypothesis that this will not happen for Navier-Stokes (but for Euler there is a bit more chance, as this equation is more geometric and has more symmetries).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-489711")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2017")])]

#text("It is very standard to applying the Leray projection {P} to divergence-free vector fields to eliminate the pressure term in the equation.The kinematic pressure p is determined uniquely by the velocity field up to an additive constant.")

#text("Is the other way around also correct: if p is know, can we expect that the velocity v can be recovered?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-489898")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2017")])]

#text("No, this should not be true: in three and higher dimensions, a scalar field such as ")#mi("p")#text(" does not have enough degrees of freedom to determine a vector field ")#mi("v")#text(", even if one knows that vector field to be divergence free; one can perform Taylor expansions of ")#mi("v")#text(" and ")#mi("p")#text(" around the origin and compare coefficients to see the underdetermined nature of ")#mi("v")#text(" from ")#mi("p")#text(" more concretely. There is also the trivial redundancy that ")#mi("v")#text(" and ")#mi("-v")#text(" determine the same pressure ")#mi("p")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-489902")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2017")])]

#text("So the space dimension seems to be the main concern. What if one only works at the 2D NSE? (I’m very interested in the Taylor expansions idea but I don’t quite get it. Would you elaborate it a bit more?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-489905")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2017")])]

#text("The Navier-Stokes equations are known to be globally well posed in two dimensions (where the equations are critical rather than subcritical), a result that I believe is due to Ladyshenskaya.")

#text("As for Taylor series: expand the pressure ")#mi("p")#text(" and the velocity components ")#mi("v_1,v_2,v_3")#text(" around the origin, assuming for sake of argument that all fields are analytic:")

#mi("\\displaystyle p(x_1,x_2,x_3) = \\sum_{a,b,c} p_{abc} x_1^a x_2^b x_3^c")

#mi("\\displaystyle v_i(x_1,x_2,x_3) = \\sum_{a,b,c} v_{abc,i} x_1^a x_2^b x_3^c.")

#text("Taking divergences of the Navier-Stokes equation gives the equation relating the pressure to the velocity:")

#mi("\\displaystyle - \\Delta p = \\sum_{i,j} (\\partial_{x_i} v_j) (\\partial_{x_j} v_i)")

#text("Equating coefficients up to ")#mi("n^{th}")#text(" order for some large ")#mi("n")#text(", this gives a system ")#mi("\\frac{n^3}{3!} + O(n^2)")#text(" (quadratic) equations involving the coefficients ")#mi("v_{abc,i}")#text(" with ")#mi("a+b+c \\leq n")#text(" in terms of the specified pressure. The divergence-free condition ")#mi("\\nabla \\cdot v = 0")#text(" yields a further ")#mi("\\frac{n^3}{3!} + O(n^2)")#text(" equations. On the other hand, the number of coefficients ")#mi("v_{abc,i}")#text(" with ")#mi("a+b+c \\leq n")#text(" is ")#mi("3 \\times \\frac{n^3}{3!} + O(n^2)")#text(". Thus there are significantly more unknowns than equations in the limit ")#mi("n \\to \\infty")#text(", and so this is a highly underdetermined system and one expects to find many velocity fields ")#mi("v")#text(" attached to each pressure ")#mi("p")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-489925")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2017")])]

#text("Since one has the globally well posedness for the 2D NSE, can we expect then that the pressure ")#mi("p")#text(" can determine the velocity up to the redundancy (")#mi("v")#text(" and ")#mi("-v")#text(") you mentioned? (It seems that one can pass the Taylor series check in the 2D case since")#linebreak()#text(" ")#mi("\\frac{n^2}{2!}+\\frac{n^2}{2!}=2\\times \\frac{n^2}{2!}")#linebreak()#text(" )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-489990")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2017")])]

#text("Writing ")#mi("u")#text(" in terms of a stream function ")#mi("\\Psi")#text(" as ")#mi("u = (-\\partial_y \\Psi, \\partial_x \\Psi)")#text(", it appears that the equation relating the pressure with the stream function is a Monge-Ampere equation ")#mi("\\mathrm{det} D^2 \\Psi = - \\frac{1}{2} \\Delta p")#text(". I’m not sure exactly what the uniqueness theory for this equation is; my understanding is that for the Dirichlet problem on a bounded Euclidean domain there is uniqueness due to a convex variational formulation, but on, say, the 2-torus, I am not familiar with the literature.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-490883")[#strong[#text("Pop Goes The Weasel: Navier Stokes and Compactness – bonefactory")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2017")]

#text("[…] Tao’s fluid computer program for proving the impossibility of solving Navier stokes equations has not progressed, but it makes […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/972cc4e9c8bf0e276a01983231bfb83bf16fff77bdffd7673fbbd390ca107551-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guy Cirier")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-493849")[#strong[#text("Guy Cirier")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2018")])]

#text("Dear T. Tao,")#linebreak()#text(" Your blog is specialised on the Navier- Stokes equation (NSE):")#linebreak()#text(" ∂")#linebreak()#text(" And I thank you very much. So, I propose a solution using your strategy 1, when the external forces don’t depend on the time. The demonstration is based on the following arguments:")#linebreak()#text(" At time , the velocity is a known smooth function of : . We deduce easily the pressure as the unique solution of the Poisson’s equation (under, for instance, Dirichlet’s conditions on the domain of ). Then, substituting and all the derivatives of by functions of in the NSE :")#linebreak()#text(" ∂,")#linebreak()#text(" where is now a function of only. We observe:")#linebreak()#text(" . Then, we obtain an ordinary differential equation (ONSE) of in function of in a neighbourhood 𝒱of :")

#text("By this transformation, the unknown function is now and the solution is But, the conditions of existence of this solution are more easy to check. (For example, we see easily that the domain of , at the origin, must be inside the set if we want avoid turbulences).")#linebreak()#text(" Now, we can suppose at an arbitrary fixed time 0 that the velocity is known in function of the position : . We translate easily the demonstration from to and find the solution in a neighbourhood 𝒱of under new conditions of existence at . And so on.")#linebreak()#text(" We find other restrictive conditions of the existence of the solution of the ONSE. The solution exists under all these conditions.")

#text("Now, we observe that we can put in the function , any functions (smooth functions, derivatives, even unique solution of a functional or integro-differential equation of as the pressure of . The important condition is that will be smooth and not the linearity of the equations.")

#text("You may find more complete demonstrations in English in hal-01716814, v. 1 on the portal web of HAL : ( HAL https://hal.archives-ouvertes.fr ).")

#text("Could you say me what do you think about this paper?")#linebreak()#text(" If somebody is interested by my presentation, I am happy to receive all purposes or objections.")

#text("With my best regards.")#linebreak()#text(" Guy cirier")#linebreak()#text(" ")#link("mailto:guy.cirier@gmail.com")[#text("guy.cirier@gmail.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a5c083d3b87ecba3760cb1acb73f02194c022d0f8fec842f5cbe467be7a1ad95-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guy Cirier")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-494898")[#strong[#text("Guy Cirier")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2018")])]

#text("Dear T. Tao,")#linebreak()#text(" It seems that you are interested by the Navier- Stokes equation (NSE):")#linebreak()#text(" ∂")#linebreak()#text(" I think I have found a solution using your strategy 1, when the external forces don’t depend on the time.")#linebreak()#text(" The demonstration is based on the following arguments:")#linebreak()#text(" At time , the function of is a known smooth function: . We deduce easily the pressure as the unique solution of the Poisson’s equation (if, for instance, the domain of satisfies the Dirichlet’s conditions). Then, substituting (and all the derivatives of) by functions of in the NSE :")#linebreak()#text(" ∂,")#linebreak()#text(" where is now a function of only. We observe:")#linebreak()#text(" . Then, we obtain an ordinary differential equation of in function of in a neighbourhood 𝒱of :")

#text("By this transformation, the unknown function is now and the solution is But, the conditions of existence of this solution are more easy to check. (For example, we see easily that the domain of must be inside the set if we want avoid turbulences at the origin).")#linebreak()#text(" Now, if we suppose at an arbitrary fixed time 0 that the velocity is known in function of the position : . We translate easily the demonstration from to and find the solution in a neighbourhood 𝒱of under new conditions of existence at . And so on.")#linebreak()#text(" We observe that we can put in the function , any functions (smooth functions, derivatives, even unique solution of a functional or integro-differential equation of as the pressure of . The important condition is that will be smooth and not the linearity of the equations.")#linebreak()#text(" You may find the demonstration in English in hal-01716814, v. 1 on the portal web of HAL : ( HAL https://hal.archives-ouvertes.fr ).")

#text("Could you say me what do you think about this paper?")#linebreak()#text(" With my best regards.")#linebreak()#text(" Guy cirier")#linebreak()#text(" ")#link("mailto:guy.cirier@gmail.com")[#text("guy.cirier@gmail.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-527262")[#strong[#text("Hobgoblins in Our Equations | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2019")]

#text("[…] Tao proved it can happen under a plausible modification of the Navier-Stokes equations of fluid dynamics. He […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/992c4d1922ecd3fe6e513657c81cf7dc74b6718546b6fa80a754a9a9b91e9a2f-1e581bca25ce5e9e7750d6cad5df6d1a0e965e4a2d6314c6987af320991e4b58.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hussain")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-533181")[#strong[#text("Hussain")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2019")])]

#text("Dear Prof. Tao")

#text("I have a small question regarding your averaged equation, which might be trivial. Do you have a regularity criteria in terms of the Lipschitz constant of the solution? That is, say ")#mi("u")#text(" is the solution to your averaged equation, and suppose that ")#tao-math("\\sup_{t\\in[0,T)}\\left\\|\\nabla u(t,\\cdot)\\right\\|_{L^{\\infty}(\\mathbb{R}^3)}\\leq C0", block: false)#text(" and ")#mi("T>0")#text(". Can you control higher order norms of the solution on ")#mi("[0,T)")#text("?")

#text("This certainly is the case for the original Navier-Stokes system, due to, e.g., Beal-Kato-Majda criteria. One can also rather simply prove this by direct energy estimates. You do mention in your paper that ")#mi("L^{\\infty}")#text(" bounds on the original bilinear operator may not carry over to the averaged one, and I was wondering if this is one such bound.")

#text("Many thanks in advance,")

#text("Hussain")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-533244")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2019")])]

#text("I believe for the specific bilinear operator I use for the blowup example there is a suitable endpoint paraproduct estimate which allows one to obtain this sort of regularity result, though for the general averaged bilinear operators in the class I describe in the paper there may not be such an estimate. On the other hand, I do not know if one can extend the Beal-Kato-Majda criterion (assuming only ")#mi("L^1_t L^\\infty_x")#text(" control of the vorticity) to my equation because it does not have a usable vorticity equation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c831a38340931ebdd5930972acd71dcdc8932ba8cceebce0ea719a78095da1af-fa4879db645c8fe3c1cc850a2e78311652c09c9edc8d9962c60d249e16336f82.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Navier")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-621760")[#strong[#text("Navier")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2021")])]

#text("What is a logic gates that respects ideal fluid? You only need one of the universal gates.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-626025")[#strong[#text("To cheer you up in difficult times 23: the original hand-written slides of Terry Tao’s 2015 Einstein Lecture in Jerusalem | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2021")]

#text("[…] topic of Tao’s lecture was discussed on Terry’s blog (also here and several other posts), here on my blog, on SO, on GLL, on Quanta Magazine, and in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31523089fab11b79fe5a0defd99b08825237358d5206dc79a571a09198864ba8-a0b9d10e04e2bc6efa3eed867385597e1a0e7d022d9f438f174e5fc1dfa3600c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dwight Walsh")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-638584")[#strong[#text("Dwight Walsh")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2021")])]

#text("As I noted in Dr. Tao’s previous posting at ")#link("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")[#text("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")]#text(", he makes the assertion “…, but we will not need to study the pressure here” without references or supporting arguments. The grad p term, however, cannot be negligible compared to the nonlinear transport term since the sum of these two terms must have a zero divergence. In fact, the very purpose of the grad p term is to maintain a zero divergence of the right-hand side of the NS equation. Then, in the analysis that follows, he discusses the possibility of a blowup occurring as a result of energy being shifted to successively smaller space scales due to only the non-linearity of the transport term. Therefore, I believe the results of both this article and the earlier posting are invalid.")

#text("In the paper I posted at ")#link("http://www.navierstokessmoothsolutions.com")[#text("http://www.navierstokessmoothsolutions.com")]#text(", however, I show that when grad p is correctly taken into account, then no such blowup is possible.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0545852da5807914429ef5ae24101202050d1b410f4c40859ea6459d39e306c7-d47625e23651b8423526a35f6e40ecdfa22a915d923b0d2c0d66cf3cf80cb2eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-638585")[#strong[#text("Daniel")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2021")])]

#text("You are way off here Dwight. Prof Tao never said grad p is negligible.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31523089fab11b79fe5a0defd99b08825237358d5206dc79a571a09198864ba8-a0b9d10e04e2bc6efa3eed867385597e1a0e7d022d9f438f174e5fc1dfa3600c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dwight Walsh")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-638594")[#strong[#text("Dwight Walsh")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2021")])]

#text("Then what is Prof. Tao assuming about p and grad p? After his statement about not needing to study the pressure here, he never once mentions it. He merely argues intuitively that the viscosity and transport terms are “fighting” with each other over dominance of the solutions.")#linebreak()#text(" Then he makes “scaling” arguments to claim that a blowup could occur as a result of energy being shifted into progressively smaller scale sizes. In summary, Dr. Tao’s methods and arguments here are far from complete and no one knows how he is maintaining a zero divergence of the fluid velocity.")

#text("In my solution, however, I keep the NS equation intact by not using “scaling” or “averaging” methods, and I show existence and smoothness of solutions to this equations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31523089fab11b79fe5a0defd99b08825237358d5206dc79a571a09198864ba8-a0b9d10e04e2bc6efa3eed867385597e1a0e7d022d9f438f174e5fc1dfa3600c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dwight Walsh")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-638729")[#strong[#text("Dwight Walsh")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2021")])]

#text("All right, you thumb-downers — No one is stopping you from shooting down my arguments. So please do so! Otherwise, you will only convince me more and more that you have no ground to stand on.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-638591")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2021")])]

#text("It is quite comical that you think you solved the millennium problem but are apparently unaware of the Leray projection.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31523089fab11b79fe5a0defd99b08825237358d5206dc79a571a09198864ba8-a0b9d10e04e2bc6efa3eed867385597e1a0e7d022d9f438f174e5fc1dfa3600c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dwight Walsh")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-638595")[#strong[#text("Dwight Walsh")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2021")])]

#text("Wrong! I am well aware of the Leray projection. I am also aware, however, that it is not needed for solving the NS Millennium Problem and may actually complicate matters.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-2/#comment-692211")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2026")])]

#text("Do we (or do you) have any news from the teams trying to prove blow-up for 3d Navier-Stokes, or even for 3D Euler? I know Thomas Hou and collaborators have achieved some very good results for 3d axisymmetric Euler in a cylinder; I know also that Gomez-Serrano and collaborators are actively working on this. Maybe other teams are trying to use AI to construct approximate blowing-up solutions. ")#linebreak()#text("Do you know any exposition of the strategies these teams are trying to make work, and why we may expect them to succeed in a few months/years? I heard Gomez-Serrano saying that he believed this could be done in a few months/years, but this was already more than a year ago (in the Spanish news paper “El pais”).")#linebreak()#text("I’d really like to read more from the current on-going proof attempts leveraging AI in some parts of the arguments.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9dd66fe519c5aa0e210c2287f353d32c5a351ee5d3a21cc6350ba577f8bc40f4-fe9b82abe2924ec9fbaaab3e85c73ef7a791ef7149fa3606750265e1cd9dd631.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mitzpe Ramon")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-269836")[#strong[#text("Mitzpe Ramon")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2014")])]

#text("This seems to be the first post on the Navier-Stokes problem where you do *not* say from the beginning that you do not claim a substantial progress. So would you say that this is a big step forward towards a solution of the problem? Maybe the biggest step in the last decades, because you found a program which is not unrealistic?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b509ff5588f95b4a744b4d63c83f70da01f355231d53ff7bf3db271f609e477-13c0faccc9ec00053834923e09b4977265385e5b7891017b9e9ac61148ae0e68.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liam")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270169")[#strong[#text("Liam")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2014")])]

#text("Of course, other people have to decide this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b43c103f6265edbd077c1a468bb92ffdf8bfa6b23a3609d9f1832f3835e11d5-514eb53c3fb3b47700cc4eb36615151c4df487ff079b5fe7190a0358ec8467f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Warren D Smith")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-459795")[#strong[#text("Warren D Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2015")])]

#text("I suggest reading my 2003 paper available online as #58 here")#linebreak()#text(" ")#link("http://rangevoting.org/WarrenSmithPages/homepage/works.html")[#text("http://rangevoting.org/WarrenSmithPages/homepage/works.html")]#linebreak()#text(" which proved that EITHER")#linebreak()#text(" 1. the Navier Stokes equations of hydrodynamics (incompressible fluid with viscosity; confined within a certain compact strange-shaped rigid container) would in finite time solve the Turing “halting problem,” OR")#linebreak()#text(" 2. no solution of the NS equations necessarily exists, OR")#linebreak()#text(" 3. solutions of the NS")#linebreak()#text(" equations do always exist, but disagree hugely with experiments")#linebreak()#text(" on real fluids like water & air in certain simple and seemingly innocent scenarios, said experiments having been performed millions of times.")#linebreak()#text(" (3 options, all rather ruinous for the discipline of “computational fluid dynamics.”)")

#text("Unfortunately this paper was rejected by an idiot anonymous referee who did not understand the meaning of the word “undecidability” but thought he did, and no amount of supporting letters from, e.g. professors who’d written books on the topic of undecidability, etc, would convince him otherwise. Anyhow, the paper is correct.")

#text("It also contains some philosophical discussion, e.g. arguing that the so-called “hydrodynamic limit” is a fiction.")#linebreak()#text(" I personally think my paper kills CFD. It does not, however, establish which of the 3 options above, is correct.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d5b854297318ea1f130ea8eadd4e46d5c823f5f980eab3e5bcf0b4ecbc05c72b-e756f619d048fde361a695662daf7d80cb7279850a159b94bc19bf179e776584.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mason Bogue")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-465538")[#strong[#text("Mason Bogue")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2016")])]

#text("Hey, this paper is wrong. Essentially you fail to prove that the additional error-correction circuitry on a “child” fluid computer does not effectively make it larger than its “parent”. In fact I think it’s highly likely that this kills your idea in its present form. There are also some issues with style; you should be familiar with how academic papers are written.")

#text("Also I strongly suggest not attempting to solve problems in fields where you do not yet have true literacy. Inventing your own notation (before an exhaustive search for extant alternatives) is usually a sign you’re on the wrong path.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b0bc4ff58e9f725174d6883325394b25e77602bbe15bf5b0163662478631940-f56b943efc2c39cd8c3be04dbf21fde6993535ed9ed28bcbb4b779f016bca753.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Warren D Smith")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-482268")[#strong[#text("Warren D Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2017")])]

#text("Dear Mason Bogue, if you object I suggest emailing me directly, Since you did not, I only discovered this hit-and-run post by you fortuitously 1.5 years later. In any case I’m not yet accepting your “discovery” of an “error” in my paper based on the non-details you fail to provide here. First of all, error-correction was an “added bonus” feature in my proof which for the simplest version we would just omit and just assume no errors ever, and you apparently have no objection to that proof (?) which already is a significant result.")#linebreak()#text(" Second, the whole idea you advance is dubious. My child computers have various constant factors (such as 1.001) times more memory, speed, and ops-performed than the parent computer; but fit in a constant factor less volume. Now if for example the Nth generation computer needed to obey the property that the chance of it suffering an undetected error was, say, less than 0.1N^(-2), that would be good enough to yield at least positive constant success chance for the entire infinite computation. Observe that summing N^k exp(-0.00001N)")#linebreak()#text(" over N, converges to a finite answer for any fixed k>0. That tells us")#linebreak()#text(" that if we expand the Nth computer by a factor of N^k (for any fixed k>0) in the quest to error-correct it, then my whole proof still would be ok. Well, the simplest most trivial possible kind of error correction is just N-fold duplication of each wire and circuit element with majority-vote correction methods, which seems to expand things")#linebreak()#text(" by a factor of N^k where k=1 or anyhow k clearly is bounded.")#linebreak()#text(" Also observe that the error chance then is reduced by exponential(N)")#linebreak()#text(" factors (using Chernoff bound) versus the parent, which clearly is way better than I need for that 0.1N^(-2). So I think your objection is simply wrong. Perhaps if you provided details I’d change my mind.")#linebreak()#text(" Third, re whatever stylistic objections you may have, try actually naming any, just as a start. Similarly, re any lack-of-literacy problems I may have, I suggest naming any other competing paper obtaining results like mine. I could not find them. Perhaps that is due to my lack of literacy, but it might also be due to the lack of existence of those papers. (You could resolve this question in your favor by pointing out such a paper.) If they do indeed fail to exist then the problem is not my lack of literacy but rather the lack of literacy (or of something) of the prior denizens of that area. In fact I had an anonymous referee who vociferously rejected my paper and was claimed by the editor who’d invited my paper, to be a Great Expert on (Computational?) Fluid Mechanics. This referee did not detect your objection. Instead his objection consisted of making false claims about what “undecidability” was. He was convinced he also was a great, or at least adequate, expert about undecidability, but he actually did not know what it was! So that is only one datapoint, but it suggests to me that there exist alleged great experts in fluid mechanics who fail to have even a first-year understanding of computer science. That if so indeed is a literacy problem, but not mine.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-488144")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2017")])]

#text("I had a good time laughing at your explanations and excuses.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b0bc4ff58e9f725174d6883325394b25e77602bbe15bf5b0163662478631940-f56b943efc2c39cd8c3be04dbf21fde6993535ed9ed28bcbb4b779f016bca753.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Warren D Smith")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-488146")[#strong[#text("Warren D Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2017")])]

#text("How does this work? First “Mason Bogue” (whom google informs me is a “software engineer at Salesforce.com”) does a hit and run attack on my paper completely free of details and without notifying me. My paper actually did prove what he says it did not, and even a much cruder approach than my paper used would also have proven it (according to my crude analysis posted above) and in fact there have been many many papers over the last 70 years on the topic of making computers built from unreliable components, reliable, and providing bounds of how well you can and cannot do that — which is an entire literature which Mason Bogue shows no sign of having heard of, nor any sign of appreciating even the basics of what they showed, at all (although perhaps he often posts to other places saying that whole literature was bunk?). Then “Anonymous” says he “had a good time laughing” about it. I’m not sure how that all constitutes legitimate scientific debate. I kind of wish the other participants in this “debate” had slightly higher standards. By coincidence, I was just invited by scgp.stonybrook.edu with little notice to give a talk at 2pm on 23 october 2017 about this very paper at a workshop on fluid mechanics in Stony Brook NY. I gave the talk on a chalkboard, which they video recorded. If they post that video online someplace, then perhaps that will help those who prefer video over reading. While unfortunately this talk was not one of my greatest performances, it seemed to pretty much get the proof across to them.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2c4699af39d6e67f42f26e4f37f3764ee24c183deb651e3957ec0129bfcb3ca-7a803e7c9ef94a2af874c1479a84d6eda02163a89803ab17c35b84ba75194a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of E.L. Wisty")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-269839")[#strong[#text("E.L. Wisty")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2014")])]

#text("Reblogged this on ")#link("http://pinkiguana2.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/")[#text("Pink Iguana")]#text(" and commented:")#linebreak()#text(" Tao’s Navier-Stokes paper")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0842619b40b080de5f59589ccb82d5e51cd8f7bc0181cc5fa8bbcb7cba4b187-bad285d30d50227a646bb8300032a3e4d1f861a297ec8f9b4e6bf4636dbac760.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-269968")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2014")])]

#text("As a first-year undergraduate, I am curious as to what this actually means. Given the timing of this and the statement “…using a blowup solution to a certain averaged version of the Navier-Stokes equation to demonstrate that any proposed positive solution to the regularity problem which does not use the finer structure of the nonlinearity cannot possibly successful.”, would it be safe to read this as “Otelbaev’s claimed proof is wrong.”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac08578e0edfc897ba8259f941762c2c4419cb63fb57bafed3975794bd8573a-78dfc549694bf79c3787425760bffa7b7a0389839d3af0e3c06010309348dcf7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of samuelfhopkins")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-269989")[#strong[#text("samuelfhopkins")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2014")])]

#text("Of course it’s always possible that both proofs are correct and mathematics is inconsistent. :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ad5c42fe82487230a30392028f42e1abcd73bac1b1c3107d1200eb40362f487-86a1b68e1026b92ecc5257605c1ef2a1241297705954af099ce19c1008247a01.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jussilindgren")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270006")[#strong[#text("jussilindgren")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2014")])]

#text("Dear Terry, what do you think of this simple argument:")

#text("The full Navier-Stokes equations can be stated as")

#mi("\\frac{\\partial \\mathbf{u}}{\\partial t}+ \\mathbf{u}\\cdot \\nabla \\mathbf{u}=-\\nabla p +\\nu \\Delta \\mathbf{u}")

#text("with the usual incompressibility condition")

#mi("\\nabla \\cdot \\mathbf{u}=0")

#text("We transform the equation in a more useful form using the following vector calculus identity")

#mi("\\mathbf{u}\\cdot \\nabla \\mathbf{u}=\\frac{1}{2}\\nabla (\\mathbf{u}\\cdot \\mathbf{u})-\\mathbf{u}\\times \\mathbf{\\omega}")

#text("Substituting this back into the Navier-Stokes equation one has")

#mi("\\frac{\\partial \\mathbf{u}}{\\partial t}=-\\frac{1}{2}\\nabla (\\mathbf{u}\\cdot \\mathbf{u})+\\mathbf{u}\\times \\mathbf{\\omega}-\\nabla p +\\nu \\Delta \\mathbf{u}")

#text("Operating with the curl operator, one gets the vorticity equation")

#mi("\\frac{\\partial \\mathbf{\\omega}}{\\partial t}=\\nabla \\times (\\mathbf{u}\\times \\mathbf{\\omega}) +\\nu \\Delta \\mathbf{\\omega}")

#text("In order to ultimately obtain the enstrophy equation, one needs to dot the Navier-Stokes equation with vorticity:")

#mi("\\frac{1}{2}\\frac{\\partial \\mathbf{\\omega}\\cdot \\mathbf{\\omega}}{\\partial t}=\\mathbf{\\omega}\\cdot \\nabla \\times (\\mathbf{u}\\times \\mathbf{\\omega})+\\mathbf{\\omega}\\cdot \\nu \\Delta \\mathbf{\\omega}")

#text("Now we use the following vector calculus identity, which is the key in this rather short proof of regularity :")

#mi("\\nabla \\cdot (\\mathbf{A}\\times \\mathbf{B})=\\mathbf{B}\\cdot (\\nabla \\times \\mathbf{A})-\\mathbf{A}\\cdot (\\nabla \\times \\mathbf{B})")

#text("Let us make then the following identification:")

#mi("\\mathbf{B}=\\mathbf{\\omega}")

#text("and")

#mi("\\mathbf{A}=\\mathbf{u}\\times \\mathbf{\\omega}")

#text("We then have")

#mi("\\mathbf{\\omega}\\cdot \\nabla \\times (\\mathbf{u}\\times \\mathbf{\\omega})=\\nabla \\cdot ((\\mathbf{u}\\times \\mathbf{\\omega})\\times \\mathbf{\\omega})+(\\mathbf{u}\\times \\mathbf{\\omega})\\cdot (\\nabla \\times \\mathbf{\\omega})")

#text("We substitute this expression back to the enstrophy equation to get:")

#mi("\\frac{1}{2}\\frac{\\partial \\mathbf{\\omega}\\cdot \\mathbf{\\omega}}{\\partial t}=\\nabla \\cdot ((\\mathbf{u}\\times \\mathbf{\\omega})\\times \\mathbf{\\omega})+(\\mathbf{u}\\times \\mathbf{\\omega})\\cdot (\\nabla \\times \\mathbf{\\omega})+\\mathbf{\\omega}\\cdot \\nu \\Delta \\mathbf{\\omega}")

#text("The only problematic term now is the second one on the right side of the equation. Let us consider it more closely:")

#mi("(\\mathbf{u}\\times \\mathbf{\\omega})\\cdot (\\nabla \\times \\mathbf{\\omega})")

#text("We can write it as")

#mi("(\\mathbf{u}\\times \\mathbf{\\omega})^T\\mathbf{R}\\mathbf{\\omega}")

#text("Where we have introduced the matrix differential operator")

#mi("\\mathbf{R}=\\begin{bmatrix} 0 & -\\frac{\\partial}{\\partial z} & \\frac{\\partial}{\\partial y} \\\\  \\frac{\\partial}{\\partial z} & 0 & -\\frac{\\partial}{\\partial x} \\\\  -\\frac{\\partial}{\\partial y} & \\frac{\\partial}{\\partial x} & 0 \\\\  \\end{bmatrix}")

#text("It is important to note that this representation matrix is skew-symmetric.")

#text("Now we know that a scalar is invariant under transposition, so we have the equality")

#mi("(\\mathbf{u}\\times \\mathbf{\\omega})^T \\mathbf{R}\\mathbf{\\omega}=\\mathbf{\\omega}^T \\mathbf{R}^T (\\mathbf{u}\\times \\mathbf{\\omega})")

#text("From skew-symmetry of the operator matrix we then have")

#mi("(\\mathbf{u}\\times \\mathbf{\\omega})^T \\mathbf{R}\\mathbf{\\omega}=-\\mathbf{\\omega}^T \\mathbf{R}(\\mathbf{u}\\times \\mathbf{\\omega})")

#text("So that finally we have the rather surprising equality")

#mi("(\\mathbf{u}\\times \\mathbf{\\omega})\\cdot (\\nabla \\times \\mathbf{\\omega})=-\\mathbf{\\omega}\\cdot \\nabla \\times (\\mathbf{u}\\times \\mathbf{\\omega})")

#text("From the enstrophy equation we can solve for this!")

#mi("-\\mathbf{\\omega}\\cdot \\nabla \\times (\\mathbf{u}\\times \\mathbf{\\omega})=-\\frac{1}{2}\\frac{\\partial \\mathbf{\\omega}\\cdot \\mathbf{\\omega}}{\\partial t}+\\mathbf{\\omega}\\cdot \\nu \\Delta \\mathbf{\\omega}")

#text("Substituting back this to the latter version of the enstrophy equation, one gets")

#mi("\\frac{\\partial \\mathbf{\\omega}\\cdot \\mathbf{\\omega}}{\\partial t}=\\nabla \\cdot ((\\mathbf{u}\\times \\mathbf{\\omega})\\times \\mathbf{\\omega}) + \\mathbf{\\omega}\\cdot 2\\nu \\Delta \\mathbf{\\omega}")

#text("Now if integrate over the whole space ")#mi("\\mathbb{R}^3")#text(" and keep in mind that the velocity field decays sufficiently fast at infinity, by direct use of divergence theorem the divergence term on the right hand side is killed by the space-integral, and we get that")

#mi("\\frac{d}{dt}\\int_{\\mathbb{R}^3}\\mathbf{\\omega}\\cdot \\mathbf{\\omega}d\\mathbf{x}\\leq 0")

#text("It is well known that if the total enstrophy stays bounded, the solutions stay regular. Note that in particular for the Euler equations, total enstrophy is conserved. QED. Best, Jussi Lindgren")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-274835")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2014")])]

#text("The proof of this dissipation law is clearly erroneous, but it does not imply the claim is false. Do there exist examples of suitably regular solutions, say, in H^1([0,T],H^1(R^3,R^3)), that violate this inequality? (I know that there are solutions of infinite total energy that produce singularities.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f52126d6f0dd2105800a025a7de01abffdf9d656597d90b88ba5bf95ca05f290-e05eb0dff299725b521b4908ffaebcbe3f82438775e06c7560c1125fa9a39a1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-313836")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2014")])]

#text("All of the vector calculus stuff looks fine, at least.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ad5c42fe82487230a30392028f42e1abcd73bac1b1c3107d1200eb40362f487-86a1b68e1026b92ecc5257605c1ef2a1241297705954af099ce19c1008247a01.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jussilindgren")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270010")[#strong[#text("jussilindgren")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2014")])]

#text("you can comment at my blog at ")#link("http://navierstokesregularity.wordpress.com")[#text("http://navierstokesregularity.wordpress.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f49e45a4771effffff4a553afc76d0299d02e04f9aecdde1c41b61f000caeb66-b4143f8a8a625675b503b7c1852daf8c5301f43a30a770a2164d67243dd600cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vlado Vrhovski")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270023")[#strong[#text("Vlado Vrhovski")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2014")])]

#link("http://www.newscientist.com/article/dn24915-kazakh-mathematician-may-have-solved-1-million-puzzle.html#.UvLKT7TvnIU")[#text("http://www.newscientist.com/article/dn24915-kazakh-mathematician-may-have-solved-1-million-puzzle.html#.UvLKT7TvnIU")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72bb4b3b123b951b3779834df10ff01d90784215406b24cb662a9117251cfcd4-85366a9c612b269b60238e4341df1c1915833739ac0620637b21859681434ca8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of friend48")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270085")[#strong[#text("friend48")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2014")])]

#text("Jussi wrote")

#text("Now we know that a scalar is invariant under transposition, so we have the equality")

#text("(\\mathbf{u}\\times \\mathbf{\\omega})^T \\mathbf{R}\\mathbf{\\omega}=\\mathbf{\\omega}^T \\mathbf{R}^T (\\mathbf{u}\\times \\mathbf{\\omega})")

#text("This would be correct if R were a usual matrix. However with an operator matrix this is wrong. Just try the product of 2 scalar functions with a differential operator in between. Then the formula ovbiously fails.")

#text("Another issue.")

#text("Prof. Tao’s paper does not formally kill Otelbaev’s one. O., while considering the periodic problem, has the linear part, the Laplacian on the torus, i.e., the operator with discrete sectrum. In Prof. Tao’s realization of his abstract setting, the linear part is the Laplacian in the whole space, i.e., the operator with the whole spectrum continuouos. Moreover, Otelbaev’s ‘proof’ is heavily based upon the lowest point in the spectrum being isolated.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270102")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2014")])]

#text("Otelbaev has implicitly used BOTH integral condition (1.4) and the periodic boundary conditions (1.3); they are assumed in deriving (4.5) from (4.4). These conditions are extra to the Clay formulation in periodic domains. Hence he is working on an over-determined system of pde. The (subtle) point is that we are constrained in applying the Helmholtz-Leray projection; any attempt to invert the pressure Poisson equation must be fully justified. Otelbaev did not derive any apriori bound on the “RHS” function of the Poisson equation. At most, his “proof” is formal and is not for the Clay NS problems.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3705d9f698ffabb6353e65ff4031a628be23f4781ef837a3fa9df650149a6556-1ef07bed96654f17c6609a07717b68526de13857a3b6a058267fa3e0d7762d93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arie Israel")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270128")[#strong[#text("Arie Israel")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2014")])]

#text("Dear Terry, Thanks for the incredible blog post. This has already become a personal favorite of mine. The idea of using intuition from electrical engineering to help construct blow-up solutions really struck me as profound. As a non-expert on fluid mechanics, I have a very simple question: Do you believe that one can make any formal equivalence or connection between regularity for Navier-Stokes and regularity for averaged Navier-Stokes. e.g., for given fixed initial data, is the solution to the averaged version of Navier-Stokes _more_ regular than the solution to true Navier-Stokes (with the same initial data)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270329")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")])]

#text("For short time (local) theory, in which the evolution is close to linear, one expects any local existence theory for the non-averaged NS equation to carry over to the averaged NS equation, basically because local existence theory is based on linear or multilinear estimates, which behave well with respect to averaging (Minkowski’s inequality). But for long time theory the two could be quite different. In particular the NS equation has the vorticity equation formulation (with all the attendant phenomena such as vortex stretching), which the averaged one does not. There is some work of Hou and Lei, ")#link("http://www.ams.org/mathscinet-getitem?mr=2492706")[#text("http://www.ams.org/mathscinet-getitem?mr=2492706")]#text(", that I recently learned about that suggests that the true NS equations may have some stabilising effects in their nonlinearity that make their behaviour better (at least for typical data) than other NS-like equations. This suggests there are going to be real challenges in transferring the blowup results from the averaged NS setting to the true NS setting, but they do not seem to be completely insurmountable. (Even if true NS behaves better than averaged NS for “most” data, one just needs a very special set of initial data in which the true NS can exhibit the “fluid logic gate” behaviour that the averaged NS equation enjoys by design, in order to (in principle, at least) replicate the blowup scenario.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-457508")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2015")])]

#text("Is it possible that any possible blowup is represented near the singular time by exactly one type of singularity from a finite set of singularities? (e.g. as in the case of Ricci flow near the singular time.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-458390")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2015")])]

#text("Is it possible that the needed condition on the “very special initial data” needed for the “fluid logic gate” behavior for the true NS setting, may be formulated as a PDE (for the initial data)? (if so, it is very important to explicitly find this PDE and check if it has any solution.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270138")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2014")])]

#text("I have a variant of Mitzpe Ramon’s question, but would understand if you didn’t want to answer it. You say that your proof hints at a way of establishing blow-up for the true Navier-Stokes equation. Would it be correct to deduce from your willingness to go public with this that there are some clearly identifiable serious difficulties in turning that hint into a proof? Given your speed at doing mathematics, the deduction is not all that convincing, but I’m still curious, as a total non-expert, to know whether there’s any prospect of seeing another Clay problem fall in the next few years.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed7fe480a3961266e21303169a56485024d3761fdd7df6313fdb8a9c1d61f7a0-75a66dce3db0742badf7bb3b53131cb1c0febb8c669081d6c1961ecdd8c48a16.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felipe Voloch")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270141")[#strong[#text("Felipe Voloch")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2014")])]

#text("@gowers re: Clay problem falls. My understanding, from asking Jaffe a question many years ago, is that there is no Clay prize for disproving any of the conjectures featured in the prizes, except perhaps PvsNP.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66a7e40444d8b0753ad1b6b223c1cb5c31e838d4b34acc858cf3ead206fdbf54-7ed5b743d02ca2cc55495dba89f6910305bb5beb74ed108ec14c0073debb1c95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of comment")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270143")[#strong[#text("comment")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2014")])]

#text("“To give reasonable lee-way to solvers while retaining the heart of the problem, we ask for a proof of one of the following four statements. […] (C) Breakdown of Navier–Stokes solutions on ")#mi("\\mathbb{R}^3")#text("”")

#link("http://www.claymath.org/sites/default/files/navierstokes.pdf")[#text("Click to access navierstokes.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9de13c3c77059e2381357dce91d8408811e186d9d73d672aa8a814d24502a97-6908235e9bb52c626e6c19f1d38e16ef432f563317e7085fab69ed891489f3c0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sniffnoy")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270144")[#strong[#text("Sniffnoy")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2014")])]

#text("Not so; see the ")#link("http://www.claymath.org/millennium-problems/rules-millennium-prizes")[#text("rules")]#text(". For P vs NP and the Navier-Stokes problems, either a proof or counterexample will get the full prize. (And for Navier-Stokes, doing it for either the non-periodic version or the periodic version suffices for the prize.) For the other ones, a counterexample ")#emph[#text("may")]#text(" be awarded the prize, or may get a smaller prize, or nothing; it’s up to them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed7fe480a3961266e21303169a56485024d3761fdd7df6313fdb8a9c1d61f7a0-75a66dce3db0742badf7bb3b53131cb1c0febb8c669081d6c1961ecdd8c48a16.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felipe Voloch")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270147")[#strong[#text("Felipe Voloch")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2014")])]

#text("Thanks for the corrections. I was misinformed by Jaffe. Since I asked him that at the end of one of the Millennium lectures at UT, his answer may be on tape. ")#link("https://www.ma.utexas.edu/millenium_site/mlectures.html")[#text("https://www.ma.utexas.edu/millenium_site/mlectures.html")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3db045b38c9ccef84722fe9fc7ea0e1d513e19863fbeaa9c2ac9335503859dd-c28374a49f4f4a485d5d16ecfb886627dd2026da415ab1be028dd79bcb2a5958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Brown")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-271046")[#strong[#text("David Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2014")])]

#text("How long will the Clay Mathematics Institute survive?")#linebreak()#text(" “The average life expectancy of a multinational corportation—Fortune 500 or its equivalent—is between 40 and 50 years.” ")#link("http://www.businessweek.com/chapter/degeus.htm")[#text("http://www.businessweek.com/chapter/degeus.htm")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270331")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")])]

#text("I think there’s a limit to how much one can deduce from “dogs that don’t bark in the night” :-). The paper reflects my current thinking on the subject, which is that (a) proving global regularity for Navier-Stokes is a hopeless task for the foreseeable future, but (b) proving blowup for Navier-Stokes is not. (This is a shift from my previous viewpoint that (a) and the negation of (b) were both true; it was only through the course of trying to formalise (a) that I was able to glimpse a possible route to (b) that I didn’t see before.)")

#text("But there is still quite a long way to go to actually reach a proof of blowup for Navier-Stokes. Most obviously, we currently don’t have any designs for logic gates made out of pure fluid (although the pointer to the fluidics literature that Arie Israel makes below is extremely intriguing), whereas in the averaged Navier-Stokes equation I could “bake in” these gates into the laws of physics by fiat. I certainly intend to look at these issues further, but I can’t predict what will come out of this program yet.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270152")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2014")])]

#text("Dear Terry, you draw the analogy with Conway’s game of life which allows universal computation.Can you show such universal computation for the (dyadic?) variants of NS you considered in the paper? One apparatus that can be helpful is the fault-tolerance apparatus (which also goes back to von-Newmann) which allows universal computation for noisy logical gates.")#linebreak()#text(" (Appropos that, to the best of my knowledge it is not known if noisy game of life allows universal computation ")#link("http://cstheory.stackexchange.com/questions/17914/does-a-noisy-version-of-conways-game-of-life-support-universal-computation")[#text("http://cstheory.stackexchange.com/questions/17914/does-a-noisy-version-of-conways-game-of-life-support-universal-computation")]#text(" .)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270273")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")])]

#text("Gil, why is error correction important? It’s needed for practical quantum computation because the qubits can’t be initialized perfectly. But for the purely mathematical NS problem, isn’t it enough if there’s some set of initial conditions (i.e. of measure 0) where the computation goes through? For that matter, it seems odd that the Millenium problem calls for an explicit counterexample in the case of a negative answer. Maybe there’s a blowup that only has a non-constructive existence proof. What then?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270332")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")])]

#text("One would have to be precise about the computational model, but I do have the impression that if one was allowed to chain together an unlimited number of ‘quadratic gates’ together connecting an unlimited number of modes (i.e. to solve arbitrary quadratic ODE ")#mi("\\partial_t X = Q(X,X)")#text(", subject to the energy conservation law ")#mi("Q(X,X) \\cdot X = 0")#text("), one could then perform an essentially Turing-complete set of (continuous) computing tasks. This is reasoning in analogy with systems of quadratic equations over, say, ")#mi("{\\bf F}_2")#text("; one can convert any bounded degree algebraic system of equations over this field into a system of quadratic equations by expanding the number of variables by a bounded amount. In particular, I think one can already show that solving quadratic equations over finite fields is NP-complete (it’s pretty close to 3-SAT, for instance).")

#text("Some noise tolerance is going to be needed, because it would be hopeless to expect the von Neumann machine to create a perfect rescaled version of itself, while completely deleting all previous traces of itself. (In particular, the rescaling we are using does not preserve the viscosity term (it is supercritical in that regard), so one cannot expect perfect self-replication.) However, it may well be that by choosing parameters appropriately that the noise tolerance could be obtained by PDE methods (e.g. Gronwall inequality) rather than by deliberately encoding error correction into the software; this is what happened in the averaged NS model I considered (although it took a while to figure out exactly how to select the parameters and to control the noise levels, leading to a rather lengthy and complicated bootstrap argument in the paper). I have a vague hope that if one can make the fluidic circuitry be based on “digital” signals rather than “analog” ones, then this will automatically give a certain degree of noise tolerance (the same way that physical electronic computers are somewhat resistant to low levels of external radiation due to the digital nature of the signals) and this may be all that is needed for the purposes of creating the von Neumann machine that blows up in finite time.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270466")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2014")])]

#text("Thanks… the Wikipedia article on fluidics was interesting and I didn’t realize they were that computationally powerful. But I thought fluidic devices (such as automatic transmissions in old cars) involved putting carefully designed physical obstructions in the moving fluid: if the NS problem is supposed to be obstruction-free then can those techniques still work? Could there be a way to use solitons (since they are self-reinforcing) to communicate between stages, like gliders in Conway’s Life game, instead of fancy digital error correction? As probably shows, I’m pretty ignorant about this general topic, and don’t know if solitons even arise in NS.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270708")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("Solitons (or at least travelling waves) are a possibility, although stability of these solutions will be an issue.")

#text("It’s true that before one can use the fluidics literature, one has to first solve the “materials science” problem of constructing materials out of pure ideal fluid which can function as the physical obstructions used in fluidic gates. This looks practically impossible, but perhaps not mathematically impossible: if for instance one can create vortex sheets of extremely high vorticity that are reasonably stable, and not penetrable by lower-vorticity streams of fluids, then they might be able to functionally serve as the walls and other obstructions of fluidic gates. (There is a price one pays for using such fancy fluid formations in one’s machine, though, which is that the task of constructing the replica of this machine becomes more difficult. Still, this feels like it is “merely” an extremely difficult engineering problem, rather than a fundamental obstruction.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3db045b38c9ccef84722fe9fc7ea0e1d513e19863fbeaa9c2ac9335503859dd-c28374a49f4f4a485d5d16ecfb886627dd2026da415ab1be028dd79bcb2a5958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Brown")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-271205")[#strong[#text("David Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2014")])]

#text("“… if for instance one can create vortex sheets of extremely high vorticity that that are reasonably stable, and not penetrable by lower-vorticity streams of fluids, then they might be able to serve as the walls and other obstructions of fluidic gates. …” Could it be of some value to look into MHD solutions? If there are ideal fluid vortices that could approximate an infinite number of electron energy-density levels, then perhaps spintronics could suggest a way of approximating ideal fluidic gates. ")#link("http://en.wikipedia.org/wiki/Spintronics")[#text("http://en.wikipedia.org/wiki/Spintronics")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbcb3ca01e8aa63fdb0a6312f037d6b9240a2ca82cecfbd0db12b6ad0857f090-c95ccc3bbe3dd6f707404643f00c1ee9b60d91f6bd617ef1b0ab4963ecb7fb2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jay")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-273980")[#strong[#text("Jay")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("Suppose we could construct a bunch of fluidic gates from water and some material we can move and shrink at will (say for 2-4 orders of magnitude).")

#text("How should we arrange the gates so that it looks like a physical proof of concept for your mathematical proposal?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-273984")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("Well, there would be a large variety of possible designs (cf. the many possible ways to design “")#link("http://conwaylife.com/wiki/Spaceships")[#text("spaceships")]#text("” in the Game of Life, with many of the larger designs using more primitive objects such as “glider guns” as an analogue of the hypothetical fluidic logic gates considered here). The conservation laws of the Euler equations, particularly conservation of energy, however provide a significant additional challenge which is not present in the Game of Life (in which there is no upper bound on the number of active cells one can generate).")

#text("In analogy with the constructions in my paper, once one has enough gates to build reliable and programmable machines, one could imagine a design that consists of a large, slow machine ")#mi("A")#text(" whose primary purpose is to create a tiny, fast, and low-energy machine ")#mi("B")#text(", which then dismantles (and cannibalises) the large machine ")#mi("A")#text(" to create a smaller copy ")#mi("A^{\\prime}")#text(" of that large machine, which holds a large fraction (say 99%) of the original energy of ")#mi("A")#text(". The smaller machine ")#mi("B")#text(" then “turns on” the smaller copy ")#mi("A^{\\prime}")#text(" to repeat the process, and then moves away from that copy ")#mi("A^{\\prime}")#text(" (at which point we don’t care too much what happens next to ")#mi("B")#text(", though it may be a good idea to put in some sort of “self-destruct” mechanism into B’s programming to guarantee that it doesn’t come back to disrupt the dynamics). The process them repeats itself, with the majority of the energy shifting itself to the next finer scale at increasingly rapid scales. As long as the energy transfer process is efficient enough, one should be able to “outrun” the effects of viscosity, which can then be treated as a negligible error (it becomes weaker at an exponential rate as one moves from one scale to the next, while renormalising the dynamics appropriately).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbcb3ca01e8aa63fdb0a6312f037d6b9240a2ca82cecfbd0db12b6ad0857f090-c95ccc3bbe3dd6f707404643f00c1ee9b60d91f6bd617ef1b0ab4963ecb7fb2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jay")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-273988")[#strong[#text("Jay")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("Is there any garantee that, if you can construct A, there’s a machine B that can dismantle A?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-273992")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("Well, if B has sufficiently advanced programming, I believe this is possible in principle, particularly if it is possible to first “turn A off”, effectively converting A into a collection of much smaller, mostly inert, components. In particular, even though A is much more massive than B, each individual component of A could be a lot smaller than B, so B could work on deactivating and then reassembling individual components of A one at a time.")

#text("Of course, the task of actually engineering the required hardware and software for these machines would be enormously difficult, but I don’t see why it is necessarily impossible.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbcb3ca01e8aa63fdb0a6312f037d6b9240a2ca82cecfbd0db12b6ad0857f090-c95ccc3bbe3dd6f707404643f00c1ee9b60d91f6bd617ef1b0ab4963ecb7fb2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jay")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-273993")[#strong[#text("Jay")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("Yep, if A was inert that sounds “easy”. But what if we can’t turn A off? Actually, it would most probably need to be self-correcting, no?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbcb3ca01e8aa63fdb0a6312f037d6b9240a2ca82cecfbd0db12b6ad0857f090-c95ccc3bbe3dd6f707404643f00c1ee9b60d91f6bd617ef1b0ab4963ecb7fb2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jay")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-273995")[#strong[#text("Jay")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("(Ok, let’s just add a backdoor A could not correct for)")

#text("Thank you very much for your answers!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-274210")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2014")])]

#text("I notice that the Clay problem statement has a force term, that we think of as constant (like gravity) but it’s written as completely parametrized in time and space, so it can do anything it wants, subject to its Jacobian decaying at superpolynomial (but maybe only slightly superpolynomial) speed. So if the von Neumann machine can scale itself down at superpolynomial speed asymtotically faster than the force decay, maybe the force term can be used to “operate the machinery”, i.e. control errors by nudging stuff back into place as needed? As the force decays more slowly than the machine scales down, it becomes more and more powerful (relative to the machine) as time increases.")

#text("Am I reading that right? Is the force constraint really given too loosely to resemble a physical system? Your paper doesn’t seem to use the force term, but maybe I missed it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-274218")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2014")])]

#text("In the global regularity problem, the forcing term is also required to be smooth as well as decaying in space; in particular, all derivatives of the forcing term remain bounded. Because of this, the forcing term is not much use for directly manipulating the fine-scale dynamics of a solution; in fact, at fine scales, the strength of this term is even smaller than the viscosity term, which is already being treated perturbatively. (However, the forcing term can be used to deal with coarse scale components of the solution, and as such is useful for such tasks as passing back and forth between periodic and non-periodic formulations of the Navier-Stokes problem; I exploited this fact in a previous paper on Navier-Stokes.)")

#text("For related reasons, fine tuning the initial data at fine scales will also not help in engineering blowup: by the time the blowup machine actually gets to such fine scales, the fine scale components of the initial data would have long since dissipated away. The blowup mechanism has to be completely endogenous at fine scales: the initial data and/or forcing term can set things up at the initial scale, but after that the solution has to “blow itself up” rather than rely on data or forcing term.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270215")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2014")])]

#text("The question if NS evolutions in three dimensions and in two dimensions support universal classical computation and classical fault tolerance was also raised in my debate with Aram Harrow regarding quantum computation in ")#link("http://rjlipton.wordpress.com/2012/09/16/quantum-repetition/#comment-27054")[#text("this comment")]#text(" (to the seventh post). NS equations were also considered a couple of times earlier in the debate by John Sidles. The context was the question of how to define classical processes “without classical fault-tolerance.” A specific question that was asked is if 2-dimensional Navier-Stokes evolutions can be approximated (in all scales) by bounded depth (probabilistic) circuits? (Or at least is it the case that they do not support universal classical computation.)")

#text("See also ")#link("http://rjlipton.wordpress.com/2012/09/16/quantum-repetition/#comment-26948")[#text("this earlier comment there")]#text(" speculating a connection between the computational complexity/fault tolerance capabilities of a class of classic evolutions and questions about regularity, well-posedness Maxwell daemons and other self-defeating behavior. The comments and threads following these comments contains further interesting links: To a paper by Andy Yau “Classical physics and the Curch-Turing Thesis,” to an MO question by Mariano Suárez-Alvarez, and to an earlier post on self-defeating behavior over this blog.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3705d9f698ffabb6353e65ff4031a628be23f4781ef837a3fa9df650149a6556-1ef07bed96654f17c6609a07717b68526de13857a3b6a058267fa3e0d7762d93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arie Israel")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270304")[#strong[#text("Arie Israel")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")])]

#text("Gil, I was surprised to learn that experimental fluid mechanics people had thought of this analogy before. Apparently the key name is ‘Fluidics’ and those ideas date back at least to the sixties. Not sure what is the state of the art. Additionally, early electrical engineers believed that electricity followed laws similar to fluid dynamics. This is called the ‘hydraulic analogy’. Historically, that’s where the word ‘current’ comes from. All this can be found on Wikipedia.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270605")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2014")])]

#text("So the ideas have been around for more than 50 years.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270239")[#strong[#text("Navier-Stokes Fluid Computers | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")]

#text("[…] Tao posted a very intriguing post on the Navier-Stokes equation, based on a recently uploaded paper Finite time blowup for an […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2ef31a4a4dfc43fc578da32fded71e2ac6a9cd7ab0191b373f15e3080ac0a47-d714c83d9093cc0e6ad88b38e26bbded069dd47b8d82671a87fdc559db8e4e01.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kurt")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270311")[#strong[#text("kurt")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")])]

#text("Well, I thought this was clear when looking at the projections")#linebreak()#text(" $u_\\theta=\\langle u,\\theta\\rangle,\\;\\theta \\in S^2$ and writing NS as")#linebreak()#text(" ")#tao-fit-display[#mitex("\\partial_t u_\\theta + div(u_\\theta u -\\nu \\nabla u_\\theta +\\theta p)=0")]#linebreak()#text(" followed by some estimates on the vector field $X=u_\\theta u -\\nu \\nabla u_\\theta +\\theta p$ using linear theory for the scalar functions $u_\\theta$,")#linebreak()#text(" (\\vert\\vert\\nabla u_\\theta + u_\\theta X\\vert\\vert = ..).")#linebreak()#text(" But I’m certainly wrong as I abandoned NS a long time ago :)")

#text("At any rate a great result. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270392")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2014")])]

#text("Typographical comment: For inner products, one should use")

#text("\\usepackage{mathtools}")#linebreak()#text(" \\DeclarePairedDelimiter{\\inner}{\\langle}{\\rangle}")

#text("Then “\\inner{v,v}” will produce “")#mi("\\langle v,v\\rangle")#text("”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270398")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2014")])]

#text("This was a comment to the paper—not your blogpost. :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270409")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2014")])]

#text("You can build computers out of many things. I am impressed you can build a computer out of the Navier-Stokes equation.")

#text("A long time ago, I read this paper ")#link("http://www.minesweeper.info/articles/MinesweeperIsNPComplete.pdf")[#text("MineSweeper is NP Complete")]#text(". Nobody plays Minesweeper anymore — instead they play Candy Crush Saga.")

#text("When I solve Sudoku’s I always imagine the numbers moving across the page. It is not that effective on the harder puzzles though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270417")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2014")])]

#text("Another comment: For maps, one should use “\\colon” to get the correct horizontal spacing. A possibility is to envoke")

#text("\\newcommand*\\map[3]{#1\\colon #2\\to #3}")

#text("in the preamble and then use, say “\\map{f}{A}{B}” to get “")#mi("f\\colon A\\to B")#text("”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91ba065c8bb4f7d002b7842a03f300980122cd55943861d33657023f8cd401c6-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270460")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2014")])]

#text("The computational potentiality of Navier-Stokes flow, and its relation to open questions in quantum dynamical simulation, both were discussed as long ago as 2008, in the context of Scott Aaronson’s lecture ")#emph[#text("Quantum Computing Since Democritus Lecture 13: How Big Are Quantum States")]#text(" (per comment")#strong[#link("http://www.scottaaronson.com/blog/?p=332#comment-10625")[#text(" #45")]]#text(" of Scott’s post).")

#text("It’s *WONDERFUL* to see that high-level mathematical techniques and creativity now are being focused upon these tough-but-crucial questions, which are important equally to mathematicians, scientists, engineers … and (in the long run) even medical researchers like me.")

#text("Please accept my appreciation of these fine new results, my thanks for the work they represent, and my sincere hopes for sustained progress in this fascinating and far-reaching line of research.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270619")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2014")])]

#text("Tao is unable to prove the Navier Stokes global regularity in the foreseeable future. That’s all folks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c7cf24de845e7fba0d65307250c9fab76d195580f9169bbf98f920d5aeca7694-b86d157d8d7c5ec89a5357b3cd5c121df2ea2a4cc64a8e4b7334c031437b83aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Me")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270624")[#strong[#text("Me")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2014")])]

#text("Dear Terry")

#text("The analogy with electrical engineering is truly fascinating.")

#text("I was wondering what would be the obstruction to applying your ideas in 2D ? (where Navier-Stokes and Euler equations are known to have global regular solutions). In other words, could we build in 2D such quadratics circuits that quickly replicate signals to finer and finer scales ? Maybe in 2D dimensions you get less X_n modes to play with for a given n, and so the circuits you can build are smaller")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270699")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("See my answer to a similar question at ")#link("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/#comment-270129")[#text("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/#comment-270129")]#text(" . Basically, in 2D the dissipation term is much stronger, and I don’t think my construction adapts to 2D Navier-Stokes. It is perhaps possible that one could modify the methods to create an averaged 2D Euler-type equation which exhibits rapid growth for a fixed amount of time (similar to a result I had worked out with Colliander, Keel, Takaoka and Staffilani for 2D periodic cubic NLS, see ")#link("https://terrytao.wordpress.com/2008/08/14/weakly-turbulent-solutions-for-the-cubic-defocusing-nonlinear-schrodinger-equation/")[#text("https://terrytao.wordpress.com/2008/08/14/weakly-turbulent-solutions-for-the-cubic-defocusing-nonlinear-schrodinger-equation/")]#text(" ), but over long enough time, all the error terms will eventually pile up and prevent any accurate analysis of the situation. (With finite time blowup, there is not enough time for the low frequency modes to cause much mischief as the von Neumann machine replicates to ever finer scales, but I don’t see how to deal with these modes for arbitrary amounts of time. In particular,in the absence of viscosity, there is the bizarre but not entirely impossible scenario in which the low frequency errors eventually manage to spontaneously form into their own von Neumann machine, which is “faster” than the original one and can “intercept” and then “disable” the original machine, halting the cascade to finer and finer scales.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270853")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("Hi Terry Tao,")

#text("I have some comments and queries. All equation numbers refer to arXiv:1402.0290. (a) For large initial data and for long-time solutions, equations (1.1) and (1.5) have not been shown to be equivalent.")#linebreak()#text(" A “blowup” is a weak solution. (b) The NS equations are locally well-posed (or globally for small data) for t in [0, t_a], where t_a depends on the size of initial data. Within Schwartz class, infinitely many initial flows, u_0(x), can be specified. Over [0, t_a], (1.9) is, if not false, irrelevant to the Navier-Stokes (1.1). (c) Initial value problem (1.9) defines a new set of equations for fluid motions but describes a stochastic field which is already in existence. In view of (b), when/where do the stochastic characters of (1.9) originate? (d) Denote your blowup time by t_b. Following (b) and (c), IVP (1.9) with u_0(x) is irrelevant to the Navier-Stokes (1.1) for any t in (t_a,t_b]. (e) Given any *finite-energy* initial data (Schwartz), what is the implication in physics for the finite-time blowup in a *stochastic field*? What happens to the field *beyond* t_b?")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270886")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("(a) The precise sense in which I show (1.1) and (1.5) to be equivalent is stated and proved in Lemma 1.3.")

#text("(b)-(d). It is true that the averaged Navier-Stokes equation (1.9) (which, by the way, is a deterministic equation, not a stochastic one, as the probabilistic (or averaging) variable in the definition of ")#mi("\\tilde B")#text(" is integrated out) is not directly related to the true Navier-Stokes flow (1.1) (or its equivalent form (1.5)). So the results of this paper do not ")#emph[#text("directly")]#text(" say anything about the true Navier-Stokes equations. However, as described in the introduction, a blowup result for the averaged Navier-Stokes equation does create a ")#emph[#text("barrier")]#text(" to certain strategies for proving global regularity for the true Navier-Stokes equation, in that any such strategy must be capable of distinguishing (1.1) from (1.9) if it is to have any chance to work. Many proposed strategies for establishing global regularity for true Navier-Stokes (including some that were proposed very recently) fail this test and can thus be excluded as viable strategies.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-271377")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2014")])]

#text("It is a salient point that eqn (1.5) is a DERIVED equation from (1.1). Close to blow-up time t_b, u unnecessarily stays in L^1 for example. The velocity Hessian of mild solutions tends to be unbounded throughout R^3. Therefore it is invalid to invert the pressure Laplacian without knowledge of velocity decays at infinity. In other words, (1.5) may well become an increasingly useless substitution for (1.1) as time approaches t_b. Above all, (1.5) must be fully justified to exist for blow-ups. The generalisation from (1.5) to (1.9) would not have a well-defined meaning, particularly for solutions involving finite-time singularities. Wherever potential blow-ups are implied, such as the Euler in S1.3, this line of reasoning has ramifications.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-271420")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2014")])]

#text("The justification of the equivalence of the global regularity problems (or equivalently after taking contrapositives, the blowup problems) for (1.1) and (1.5) is indeed non-trivial, and occupies a significant portion of my previous paper ")#link("http://msp.org/apde/2013/6-1/p02.xhtml")[#text("http://msp.org/apde/2013/6-1/p02.xhtml")]#text(" . As I said in my previous comment, the precise sense in which I show (1.1) and (1.5) to be equivalent is stated and proved in Lemma 1.3 (which relies heavily on the results of that previous paper).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cb3280d4a3ac59b59c4cf2c33043f35c9d5c9f277083c51cc4b2e3163aa25a7-6a9cd9f58b7183b2038ce7a394dc5461cc80a5a1b8a2711b65195916592b725c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo de Almeida")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-270940")[#strong[#text("Marcelo de Almeida")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("Reblogged this on ")#link("http://nucaltiado.wordpress.com/2014/02/11/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/")[#text("Being simple")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72bb4b3b123b951b3779834df10ff01d90784215406b24cb662a9117251cfcd4-85366a9c612b269b60238e4341df1c1915833739ac0620637b21859681434ca8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of friend48")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-271071")[#strong[#text("friend48")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2014")])]

#text("Prof. Tao,")

#text("concerning your final remark")

#text("Many proposed strategies for establishing global regularity for true Navier-Stokes (including some that were proposed very recently) fail this test and can thus be excluded as viable strategies.")

#text("Your great paper does not formally exclude as viable strategy the recent paper by Otelbaev, since in the abstract part the latter contains an extra condition for the main linear operator (the Laplacian, for the NS), the condition that is not present in your paper.")#linebreak()#text(" The condition requires that the lowest eigenvalue be isolated. This is correct for the peridic problem, but wrong for the problem for the everaged NS in the whole space. Moreover, it is not that easily visible, how your construction can be adapted to the periodic case, since it uses the everaging over rotations, this one being prevented by the geometry of the torus..")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-271074")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2014")])]

#text("My paper is set in the non-periodic setting for technical convenience, but one can transfer from the non-periodic setting to the periodic setting in a number of ways. For instance, in ")#link("http://arxiv.org/abs/1108.1165")[#text("this previous paper")]#text(" of mine I showed that global regularity for the homogeneous non-periodic Navier-Stokes problem follows from global regularity for the inhomogeneous periodic Navier-Stokes problem with ")#mi("H^1")#text(" forcing term, and so any obstruction to solving the former problem also gives an obstruction to the latter. Alternatively, one can take the local cascade operators ")#mi("C")#text(" in my current paper and adapt them to the periodic setting by throwing away all negative frequency scales ")#mi("n \\leq 0")#text(" (which were never actually excited by the local cascade evolution ")#mi("\\partial_t u = \\Delta u + C(u,u)")#text(" in any event) and restricting the frequency variable to be integer. The resulting periodic equation has essentially the same dynamics as the non-periodic cascade equation; it is no longer an average of the periodic Navier-Stokes equation (since, as you say, rotations are no longer directly available on the torus), but the periodic local cascade operator still obeys essentially the same estimates as the periodic Euler operator, because the non-periodic version of the former is still an average of the non-periodic version of the latter, and essentially all periodic estimates one uses on these operators can be derived from their non-periodic counterparts (together with estimates that exploit the compactness of the domain, e.g. Holder’s inequality).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72bb4b3b123b951b3779834df10ff01d90784215406b24cb662a9117251cfcd4-85366a9c612b269b60238e4341df1c1915833739ac0620637b21859681434ca8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of friend48")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-271073")[#strong[#text("friend48")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2014")])]

#text("the lowest eigenvalue…..")#linebreak()#text(" I meant, of course, the lowest point of the spectrum.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-271517")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2014")])]

#text("Otelbaev attempts to solve *a* NS problem which demands additional symmetry (via periodic BC’s) and his flow is assumed to satisfy further integral constraints. He deals with a pde system (with specific IC/BC’s) which has an essentially DIFFERENT formulation compared to the present periodic settings. We cannot say that his proof is free from inconsistencies and he breaks new ground. The point is: implications concluded from a NS-irrelevant pde throw little new light on how to overcome the NS difficulties.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ad5c42fe82487230a30392028f42e1abcd73bac1b1c3107d1200eb40362f487-86a1b68e1026b92ecc5257605c1ef2a1241297705954af099ce19c1008247a01.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jussilindgren")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-271389")[#strong[#text("jussilindgren")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2014")])]

#text("What about the following argument:")

#text("It seems to me that the following geometric argument is sufficient to ensure smooth solutions:")

#text("Given that the question of regularity depends on the behaviour of the volume integral (over the whole space) of the following scalar product:")

#mi("(\\mathbf{u}\\times \\mathbf{\\omega})\\cdot \\nabla \\times \\mathbf{\\omega}")

#text("By utilising the scalar triple product, one can easily see that this term depends only the mutually perpendicular parts of the velocity, vorticity and curl of vorticity fields (as swapping the order of the terms using scalar triple product always kills the parallel part in the cross product). Then we can reduce the question of regularity into such fields where these three fields are mutually perpendicular. But on the other hand using the divergence theorem, it is clear that the enstrophy is identically the volume integral of")

#mi("\\mathbf{u}_{\\parallel}\\cdot \\nabla \\times \\mathbf{\\omega}")

#text("as the component which is perpendicular to the curl of vorticity is killed by the scalar product.")

#text("So, in other words for such perpendicular fields the enstrophy is identically zero and so the solution is regular. This means that the solutions must be regular for all fields, as adding a non-perpendicular parts to the fields do not change the critical integral.")

#text("The whole story is at my blog: ")#link("http://navierstokesregularity.wordpress.com/")[#text("http://navierstokesregularity.wordpress.com/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72bb4b3b123b951b3779834df10ff01d90784215406b24cb662a9117251cfcd4-85366a9c612b269b60238e4341df1c1915833739ac0620637b21859681434ca8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of friend48")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-271432")[#strong[#text("friend48")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2014")])]

#text("jussilindgren:What about the following argument:……….")

#text("Wouldn’t it be polite and professional to start your post by admittng that, yes, your latest ‘proof’ is wrong, and what is you are wrtig now is not a continuation of this latest one but something completely new.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-271456")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2014")])]

#text("indeed, I fully agree with you friend48. Sorry. I don’t care about the millions, I just care about whether we can could establish some certainty. Would be fantastic, if we knew the limits of computers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72bb4b3b123b951b3779834df10ff01d90784215406b24cb662a9117251cfcd4-85366a9c612b269b60238e4341df1c1915833739ac0620637b21859681434ca8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of friend48")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-271583")[#strong[#text("friend48")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2014")])]

#text("jussilindgren:”Then we can reduce the question of regularity into such fields where these three fields are mutually perpendicular. ”")#linebreak()#text(" ——————–")#linebreak()#text(" This statement is not proved. You should have described the process of your reduction.You did not do this, moreover, you cannot do this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-272760")[#strong[#text("More Quick Links | Not Even Wrong")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2014")]

#text("[…] Tao has some new ideas about the Navier-Stokes equation. See his blog here, a paper here, and a story by Erica Klarreich at Quanta […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/283dd095ba5a977a8b5c763cbc1b76b18fcf0f014099332e0bc243cfb2651ffd-ec7409933e94ad7da2f9f2c9a701b14c431c29a641c0cef7f2288328c16a36cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of weather_or_not")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-272773")[#strong[#text("weather_or_not")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2014")])]

#text("So does you work have any bearing on long-term climate predictions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/79a190795d80e8c530d4a698e6be06bac867e32eed945b944b9cc603f8f83754-717d77f039a97e939bab0746ac8ac93e3d6f29dd80ba56d28d6bf76de4a9939f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of none")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-272820")[#strong[#text("none")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2014")])]

#text("I’d say this has no implications at all since it’s about transferring energy to finer and finer scales without limit. The NS equations for air or water (i.e. in physics) break down at the molecular scale.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Conserved quantities for the Euler equations | What's new")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-272838")[#strong[#text("Conserved quantities for the Euler equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2014")])]

#text("[…] Euler equations are the inviscid limit of the Navier-Stokes equations; as discussed in my previous post, one potential route to establishing finite time blowup for the latter equations when is to be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59f9f0b83a52d3783947a9e8ccd9f678d3e8f512f7bd70b53bc6edeaeb96fe45-8ca135ef6847cf14d67a73f7baf6bc57abd733c58d55e960f98f24e063e483e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Navier Stokes looks like its gonna blow « Pink Iguana")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-273462")[#strong[#text("Navier Stokes looks like its gonna blow « Pink Iguana")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2014")])]

#text("[…] Tao has some new ideas about the Navier-Stokes equation. See his blog here, a paper here, and a story by Erica Klarreich at […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-273616")[#strong[#text("La mystérieuse équation de Navier-Stokes | Science étonnante")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2014")]

#text("[…] Un autre billet de Terry Tao qui semble doucher les espoirs kazakhs […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-273621")[#strong[#text("Shtetl-Optimized » Blog Archive » Recent papers by Susskind and Tao illustrate the long reach of computation")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2014")]

#text("[…] see that, in blog comments here and here, Tao says that the crucial difference between the 2- and 3-dimensional Navier-Stokes […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-273915")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("Prof. Tao, do you think it’s feasible and interesting, for someone to do a numerical simulation of the blowup in this result, making some nice pictures, or is there just too much “stuff” going on for simulation to be practical? Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-273985")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("The five-dimensional ODE in Section 5.5 of my paper, which models a single stage of the energy transition process, should be solvable numerically for reasonable choices of the parameters ")#mi("K, \\varepsilon")#text("; the dynamics should then look like the schematic depicted in Figure 6 of my paper. One could then try to chain several of these ODE together to give a system similar to (6.3)-(6.6), which describes the full blowup dynamics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-274331")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2014")])]

#text("Maybe I’m reading too much into the “fluid computer” analogy, but-")

#text("In order to programmably self-replicate, it seems that the Navier-Stokes computer’s hardware would need to support not only computation, but also at least some minimal fabrication primitives. If so, would the latter capability somehow come for free with Navier-Stokes based computation (which I understand is itself still just a glimmer), or must it be explicitly designed in?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-274334")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2014")])]

#text("Yes, this will have to be done also; strictly speaking one needs a “universal constructor” in addition to a “universal computer” in order to build a self-replicating machine by this route. But given that the computer will literally be (fluid) mechanical in nature, I expect the “fabrication primitives” to be not so different actually from the “logic gate primitives” that are also needed, and if one can engineer the latter then it is reasonable to expect that one can also engineer the former. (This is not to say that the task is trivial: after all, we still have not engineered a true von Neumann machine in the real world, despite having more or less perfected the art of computation. On the other hand, in Conway’s game of life, my understanding is that the tasks of building a universal computer and of building a universal constructor, while technically different, were of comparable levels of difficulty.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-274365")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2014")])]

#text("I see, thanks.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-275417")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2014")])]

#text("Do physics-of-computation results such as Landauer’s energy minimum for bit erasure have any relevance to the potential N-S blowup scenario sketched here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-275532")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2014")])]

#text("Perhaps not directly, but the second law of thermodynamics is certainly a concern, as it would suggest that the total disorder present in a fluid machine will tend to increase over time. One way to ameliorate this is to try to rely on reversible computing, but I think the more promising route is simply to accept the increase in total disorder, and try instead to reduce local disorder, so that a von Neumann machine ")#mi("A_n")#text(" can create a near-perfect replica ")#mi("A_{n+1}")#text(" of itself at a smaller scale (and with smaller energy and, hopefully, smaller entropy too), at the cost of leaving behind a discarded and highly disordered remnant of ")#mi("A_n")#text(" that is absorbing the entropy (but which has been moved sufficiently far from ")#mi("A_{n+1}")#text(" in either physical space or frequency space so as not to disrupt the remaining dynamics).")

#text("Note also that other model equations in physics (e.g. focusing nonlinear Schrodinger equation) can exhibit stable self-similar blowup solutions in finite time, so finite time blowup is not intrinsically in contradiction to the second law of thermodynamics (there is some small radiation dispersing away from the bulk of the self-similar solution which is basically carrying the disorder in the system).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-276280")[#strong[#text("Could We Have Felt Evidence For SDP ≠ P? | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2014")]

#text("[…] the latter, Terry Tao’s recent breakthrough on the Navier-Stokes equations is an example of how much the same ideas keep recirculating, and how […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-293361")[#strong[#text("Multiple-Credit Tests | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2014")]

#text("[…] Tree” is Terence Tao, and our extrapolation of his new result on Navier-Stokes is a flight of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/14cf20c7c454401fa999db4bac38b8379ce766dfe95f74573fa31f1fb0fe1ffd-3bf766085715cf1f2b61b141f54beac8c66b0409c6e378e74e74c87d4e7d265c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JOE")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-298563")[#strong[#text("JOE")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2014")])]

#text("I think this is probably the wrong place to put this but I read your previous article ”Does one have to be a genius to do maths?” and I think I must be ailing from one of the condition you spoke of. Now where does the Navier-Stokes problem come in; well I threw much of myself into tackling this one for 2yrs now. I am no proffesional mathematician but I believe I may have cracked something; like I have found the main basis of boundedness in the NSE; smoothness isnt that hard to achieve afterwards.")#linebreak()#text(" I wish to publish these findings but I am discouraged by the fact that as an amateur I will be taking down an icon in an already protective scientific community & I dont mean Prof. Otelbaev. Having gone through Otelbayiev’s own work I have found an error consistent with other peoples attempts at attacking the NSE.")#linebreak()#text(" Dear Dr Tao, I love your new way of looking at this problem and something interesting hit me! Forgive me for suggesting this but would you mind looking into whether you could fit this idea into galactic clusters, I thought Gamma ray bursts but it would be interesting to see what you might come up with. By the way, can you give me in your proffessional capasity advice on what to do?")#linebreak()#text(" Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-301115")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2014")])]

#text("Dear Terry, following is a question about another (rather natural) possible direction from your philosophy but this time towards a positive solution rather than a negative solution for the NS question. Namely, perhaps a key for showing that finite-time blow up is ")#emph[#text("not possible")]#text(" would be by showing (an apparently weaker statement) that the NS/Euler equation do not support “deep” computation. You drew the analogy with quantum computing (and fault-tolerance) and indeed in this area there are several results which asserts that under certain conditions “deep computation” is not available. Limitation on computation immediately leads to a large number of conserved quantities, which is the quantum case are sometimes referred to as “phases of matter.” (Before, I proposed to impose such limitation on computation and to derived conservation laws on top of the equations in order to explain why deep computation is absent from fluids in nature, but it is a possibility that limitation on deep computation can be derived from the equation itself.) On the technical level (on the quantum side) results of this kind usually refer to “gapped systems” (so some spectral gap is assumed) and a prominent technical tool that is used (with much success in the last decade) is the Lieb-Robinson inequality. (See, e.g. this ")#link("http://de.arxiv.org/pdf/1102.0835.pdf")[#text("review paper")]#text(".) I don’t know if spectral gaps and Lieb-Robinson have some analogs for the NS/Euler evolutions. Anyway, this is a direction worth noting.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-301795")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2014")])]

#text("My personal feeling is that because the Navier-Stokes/Euler equations are nonlinear rather than linear, there will be far fewer barriers to computation than in the quantum setting, and that one should be able to almost freely traverse the “energy surface” of state space coming from the various conserved quantities of the Euler equations (energy, momentum, angular momentum, circulation, helicity). (Well, I’m not 100% sure about circulation, because this is essentially a pointwise conservation law (conservation of the vorticity 2-form) and could potentially be a serious barrier to how freely the state can evolve, but the other conservation laws at least do not seem to constrain the dynamics to the extent that they preclude computation.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-381483")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2014")])]

#text("It seems (but I am not sure about it at all) that perhaps the crux of the matter for supporting a von Neumann machine is to show that NS supports computation of arbitrary depth. (Namely that there is no absolute bound on the depth of the computation independent of the number of bits you can use, and that you do not need arbitrary long computation with fixed number of n bits). If this is the case this is good news in the sense that the mathematical distinction between bounded depth computation and computation beyond bounded depth is much more definite and clear compared to other computational complexity issues. So a crucial question is if you can implement with a NS-machine something like the “majority function.” (If NS supports only bounded depth computation (is it the case for D=2?), I don’t know if this has direct consequences on the regularity conjectures but at least it will imply (by a theorem of Green) Mobius randomness. :) )")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e80c2bfa298d4886a507d9a4a825c9b92eda39a3f6beb10f7bb921d5adde1ae-b1f05f42ac1417ca9a591ad51a17dd49c39b80a1e267d76997fd2a9e69319ce2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Viktor Ivanov")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-314324")[#strong[#text("Viktor Ivanov")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2014")])]

#text("Global regularity is proven in my paper A SOLUTION OF THE 3D NAVIER-STOKES PROBLEM published in Int. Journal of Pure and Applied Mathematics, Vol. 91 No. 3 2014, 321-328,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b8bee07d9eaa7672349f3e844ae62b164d6d941f4e7463605deb49bab2b6038-841154f15932dba170ca40b709ca6a2f5d5c61a06a787e32b74a0a103a70aaa8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Baiamos")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-355608")[#strong[#text("Baiamos")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2014")])]

#text("But what about Otelbayev proof?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-379442")[#strong[#text("So what happened to the abc conjecture and Navier-Stokes? | The Aperiodical")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2014")]

#text("[…] the arXiv, which states some limits on what a solution to Navier-Stokes can look like, but comments on his blog post about the paper say that it doesn’t rule out Otelbaev’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-408182")[#strong[#text("Un ordinateur liquide | www.Affectueusement.Biz")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2014")]

#text("[…] ")#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier&#8230")[#text("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier&#8230")]#text("; (dernier paragraphe) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-410426")[#strong[#text("Links For February - My blog")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2014")]

#text("[…] Tao, whom I like to admire from afar, has posted what is maybe a takedown of Otelbaev’s claimed proof of Navier-Stokes, but the best part? […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1097ee771bdc656de86ab924801d4d07e33dc51620cf8a2133bba767c7ad48b7-70c763413f74e6f5c483579ac247353042f7479425314327f75bcd676a0dab68.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Other Clay Maths Problem | Ajit Jadhav's Weblog")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-410568")[#strong[#text("The Other Clay Maths Problem | Ajit Jadhav's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2014")])]

#text("[…] That, indeed, turns out to have been the actual case. Terry Tao didn’t directly tackle the Clay Maths problem itself. See the Simons Foundation’s original coverage here [^], or the San Francisco-based Scientific American’s copy-paste job, here [^]. What Terry instead did is to pose a similar, and related, problem, and then solved it [^]. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c36817f8e4ad9aaab78e1f6cfa2abda3bf022ce6f1b3eef33038c678c0c02ba6-d6451608f1cf046d8fec1414d440d651320107150fb7cfe7f6a77266bc8f1e25.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Chapman (@fwchapman)")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-416913")[#strong[#text("Fred Chapman (@fwchapman)")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2014")])]

#text("Prof. Tao, I enjoyed your lecture on this topic at Lehigh University last week. I have a follow-up question.")

#text("I am intrigued by your idea of building a Turing-complete computer out of water. If you can do this, it would be of considerable interest in its own right!")

#text("Are you familiar with Stephen Wolfram’s work on universal Turing machines in his “New Kind of Science” (NKS) research initiative? Could there be some useful connections between various NKS representations of universal Turing machines and the machine you want to build using fluid dynamics?")

#text("In 2007, Wolfram awarded a prize to Alex Smith for proving that a particular Turing machine with 2 states and 3 symbols (colors) is universal. This may be the simplest universal Turing machine that exists. Here’s more info:")

#link("http://www.wolframscience.com/prizes/tm23/")[#text("http://www.wolframscience.com/prizes/tm23/")]

#link("http://en.wikipedia.org/wiki/Wolfram's_2-state_3-symbol_Turing_machine")[#text("http://en.wikipedia.org/wiki/Wolfram's_2-state_3-symbol_Turing_machine")]

#text("Wishing you success,")

#text("Fred Chapman")#linebreak()#text(" Bethlehem, PA")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c36817f8e4ad9aaab78e1f6cfa2abda3bf022ce6f1b3eef33038c678c0c02ba6-d6451608f1cf046d8fec1414d440d651320107150fb7cfe7f6a77266bc8f1e25.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Chapman (@fwchapman)")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-416917")[#strong[#text("Fred Chapman (@fwchapman)")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2014")])]

#text("P.S. When Wolfram was at the Institute for Advanced Study in 1983-1986, he simulated physical processes like turbulent fluid flow using cellular automata. Would it be fruitful to collaborate with Wolfram on your approach to Navier-Stokes via fluid-mechanical universal Turing machines?")

#link("http://en.wikipedia.org/wiki/Stephen_Wolfram#Complex_systems_and_cellular_automata")[#text("http://en.wikipedia.org/wiki/Stephen_Wolfram#Complex_systems_and_cellular_automata")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-434871")[#strong[#text("If You Can Explain What Happens When Smoke Comes Off A Cigarette, You'll Get A $1 Million Prize | Business Insider")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2014")]

#text("[…] In a more recent blog post and paper preprint, Tao constructs a set of differential equations that behave like an “averaged” version of Navier-Stokes and devises a clever model of a very abstract “fluid machine,” vaguely analogous to electronic computers built out of electronic components. […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62838afe5b878640636cd3bdbe65ea3e6894cfc2005643ef712d40e4744b97f5-7bfb8d7b7ae1c5a25fbcceeb8cefb01557bc941c1189ef586f6f361b57c8318e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Choro Tukembaev")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-436412")[#strong[#text("Choro Tukembaev")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2014")])]

#text("Dear Prof. Terence Tao,")#linebreak()#text(" Harness a stallion with a timid doe in one bridle together?")#linebreak()#text(" Harness a compressibility with incompressibility in one bridle together? Alexander Pushkin warned that this is impossible (Poem “Poltava”, 1829).")

#text("“Socrates first brought down philosophy from heaven to earth”. Your counter-example does not apply to an incompressible fluid, therefore very fit the words of Cicero. Required descend from heaven to earth, and then to solve the Navier-Stokes equations for an incompressible fluid, strictly following the requirements “The Millennium Prize Problems”.")

#text("Finally, professor Omurov has found a solution for Navier-Stokes equations exactly as it was required in “The Millennium Prize Problems” of the Clay Mathematics Institute, and for this purpose he invented a new analytical method, see:")#linebreak()#text(" (English) ")#link("http://literatura.kg/articles/?aid=2030")[#text("http://literatura.kg/articles/?aid=2030")]#linebreak()#text(" (in Russian) ")#link("http://literatura.kg/articles/?aid=2042")[#text("http://literatura.kg/articles/?aid=2042")]#linebreak()#text(" “Nullius in verba” ■")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d266db86d747d43312de4b28cae766058765dbcc9205dbf243949d157be432a-c131edf723cb55c8de49d02ba06642b15ebbd3a9c7494196a8bcb4c22e34d6b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of joe")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-450042")[#strong[#text("joe")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2015")])]

#text("Prof. Tao,")#linebreak()#text(" The Navier Stokes equations in the current form could includes momentum conservation terms like angular momentum conservation in space? for example ocean waves carry large momentum energy due to gravitational forces, this could counter the positive curvature inflow to a negative outflow. The constant velocity of this flow would follow a geodesic path along a smooth surface conserving both momentum and constant flow velocity much like the Riemannian surface.")

#text("The entropy of this flow volume would minimize energy loss since all particles are confined in a Riemannian surface of constant total curvature irrespective of its shape, like turbulence? even for 3 dimension !")

#text("You would expect a smooth group velocity over this surface since the geodesic path conserves energy and momentum on any point. This could solve the problem of blow up, if angular momentum is taken into account. If the Gaussian K>0, you get a circular in-flow motion, K<0, the flow diverges away, if K=0 then a steady flow.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21b1383b8a28dfb0977c0449135f6de3d3d62f94f684ebb6f4543a03c551fa35-90b71ee999da76a51a89a39897ef03751846071d69027384e36d99ea707f348d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andreas")]], [#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/comment-page-1/#comment-450081")[#strong[#text("Andreas")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2015")])]

#text("I found this topic highly interesting due to the unexpected methods used here; and especially the great potential for future breakthroughs. Now there has not been any update on this kind of research for nearly a year, so i’m very curious about the progress. Is the proposed method still an active area of research of yours or did you suspend it for some time? Much success with your project – and thanks alot for this entertaining blog!")
]
