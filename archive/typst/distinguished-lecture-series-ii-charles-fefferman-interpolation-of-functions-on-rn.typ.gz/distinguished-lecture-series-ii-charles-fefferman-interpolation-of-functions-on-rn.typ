// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/11/15/distinguished-lecture-series-ii-charles-fefferman-interpolation-of-functions-on-rn/
// Converted to Typst by tao2typ: "2026-10-14T16:35:04.948421+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Distinguished Lecture Series II: Charles Fefferman, “Interpolation of functions on R^n”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Distinguished Lecture Series II: Charles Fefferman, “Interpolation of functions on R^n”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 November 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/11/15/distinguished-lecture-series-ii-charles-fefferman-interpolation-of-functions-on-rn/")[#text("https://terrytao.wordpress.com/2007/11/15/distinguished-lecture-series-ii-charles-fefferman-interpolation-of-functions-on-rn/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("On Thursday, ")#link("http://en.wikipedia.org/wiki/Charles_Fefferman")[#text("Charlie Fefferman")]#text(" continued his lecture series on interpolation of functions. Here, he stated the main technical theorem about bundles that underlies all the results, answering the “cliffhanger” question from ")#link("https://terrytao.wordpress.com/2007/11/13/distinguished-lecture-series-i-charles-fefferman-interpolation-of-functions-on-rn/")[#text("the last lecture")]#text(", and broadly outlined the proof, except for a major technical wrinkle about “Whitney convexity” which he will discuss on Friday. ")#metadata(none) <tao-d4c392f1309abcd10128>#text("Last time, Charlie introduced the notion of a ")#emph[#text("bundle ")]#mi("{\\mathcal H} = (H_x)_{x \\in E}")#text(" on a compact set ")#mi("E \\subset {\\Bbb R}^n")#text(", as a collection of subsets ")#mi("H_x \\subset {\\mathcal P}_x")#text(" of the ring ")#mi("{\\mathcal P}_x")#text(" of Taylor polynomials up to some order m based at x, such that each ")#mi("H_x")#text(" is either empty, or is the coset of an ideal in ")#mi("{\\mathcal P}_x")#text(". A ")#emph[#text("section")]#text(" of that bundle is then a function ")#mi("F \\in C^m({\\Bbb R}^n)")#text(" such that the ")#link("http://en.wikipedia.org/wiki/Jet_%28mathematics%29")[#text("jet")]#text(" ")#mi("J_x(F) \\in {\\mathcal P}_x")#text(" of F at x (i.e. the ")#link("http://en.wikipedia.org/wiki/Taylor_polynomial")[#text("Taylor expansion")]#text(" of F at x up to order m) lies in ")#mi("H_x")#text(". The set of all sections F of a bundle ")#mi("{\\mathcal H}")#text(" will then be denoted ")#mi("{\\mathcal O}({\\mathcal H})")#text(". We are interested in the following basic questions, given m, n, E, and ")#mi("{\\mathcal H}")#text(":")

#enum(start: 1, 
[#text("When is ")#mi("{\\mathcal O}({\\mathcal H})")#text(" non-empty?")],
[#text("What can we say about the jets ")#mi("J_x(F)")#text(" of sections F of ")#mi("{\\mathcal H}")#text("? We know they lie in ")#mi("H_x")#text(", but can they take on every value in that space?")],
[#text("What is the best value of ")#tao-math("\\left\\|F\\right\\|_{C^m({\\Bbb R}^n)}", block: false)#text(", as F ranges over sections of ")#mi("{\\mathcal H}")#text("?")]
)

#text("As mentioned earlier, this problem generalises the problem of how to extend a function f on E (possibly with some derivatives prescribed) to a ")#mi("C^m")#text(" function F on ")#mi("{\\Bbb R}^d")#text("; the bundle ")#mi("{\\mathcal H}")#text(" is describing all the constraints that F has to satisfy. Later on, we will also discuss a more general version of these results, in which ")#mi("J_x(F)")#text(" is supposed to lie in a convex set, rather than a coset. As stated, this question is ")#emph[#text("too")]#text(" general (it includes as a special case the existence problem for arbitrary linear partial differential equations with linear boundary conditions, which is clearly a hopeless task to solve in complete generality), but Charlie mentioned that there was a special additional condition, which he called Whitney convexity, which makes everything solvable, and ends up being key to the whole argument.")

#text("As mentioned in the first lecture, if E was a finite set, then the first two questions here are trivial, and the last one is given by the finiteness theorem. However, there is a compactness problem when moving from the finite world to the infinite world, basically because the uniform limit of uniformly ")#mi("C^m")#text(" functions need not be ")#mi("C^m")#text(" (consider for instance how the one-dimensional uniformly ")#mi("C^1")#text(" functions ")#mi("(\\varepsilon^2 + x^2)^{1/2}")#text(" converge to the merely ")#mi("C^{0,1}")#text(" function |x| as ")#mi("\\varepsilon \\to 0")#text(". However, as mentioned before, no such difficulty arises when one works in more compact spaces such as ")#mi("C^{m-1,1}")#text(": in that case, the answer to all the above problems is that the task of finding a section on an infinite set E is equivalent to that of finding sections on each finite set S of E of a bounded size ")#tao-math("\\left|S\\right| = O_{n,m}(1)", block: false)#text(", with bounds on the resulting extensions that are uniform in S, and that the norm of the best extension on the whole set E is comparable to the sup of the norms of the best extensions on each of the sets S. A little more generally, one can replace the space ")#mi("C^{m-1,1}")#text(" with spaces such as ")#mi("C^{m,\\omega}")#text(", where ")#mi("\\omega: {\\Bbb R}^+ \\to {\\Bbb R}^+")#text(" is a ")#link("http://en.wikipedia.org/wiki/Modulus_of_continuity")[#text("modulus of continuity")]#text("; this is the space of ")#mi("C^m")#text(" functions F where the ")#mi("m^{th}")#text(" derivative ")#mi("\\nabla^m F")#text(" is not only continuous, but is continuous with modulus ")#mi("\\omega")#text(" in the sense that ")#tao-math("\\left|\\nabla^m F(x) - \\nabla^m F(y)\\right| \\leq M \\omega(\\left|x-y\\right|)", block: false)#text(" for all ")#mi("x,y")#text(" and some M. (This generalisation will be important later.)")

#text("Anyway, let us return to questions 1-3 above. There is an obvious obstruction to solvability of Q1: if the bundle ")#mi("{\\mathcal H} = (H_x)_{x \\in E}")#text(" has any empty fibre, thus ")#mi("H_x = \\emptyset")#text(" for at least x, then clearly the bundle admits no sections. Is this the only obstruction – or in other words, does solvability at each point imply global solvability? The answer is rather clearly no, even in the easy case m=0 and n=1. For instance, take ")#mi("E = [-1,1]")#text(", let ")#mi("H_0 \\equiv {\\Bbb R}")#text(" be the set of all constant functions, and let ")#mi("H_x \\equiv \\{ \\text{sgn}(x) \\}")#text(" consist of a single constant function, namely ")#mi("\\text{sgn}(x)")#text(" for ")#mi("x \\in E \\backslash \\{0\\}")#text(". Finding a section of this bundle then amounts to finding a continuous (i.e. ")#mi("C^0")#text(") function ")#mi("F: {\\Bbb R} \\to {\\Bbb R}")#text(" with ")#mi("F(x) = \\text{sgn}(x)")#text(" for ")#mi("x \\in E \\backslash \\{0\\}")#text(", and F(0) apparently unconstrained. Each fibre is non-empty, and so the problem is solvable pointwise. But it is not solvable globally. This is because the constraints ")#mi("F(x) = +1")#text(" for ")#mi("0 < x \\leq 1")#text(", together with the qualitative requirement that F be continuous, forces a new constraint on F(0), namely that F(0) = +1. On the other hand, the constraints coming from ")#mi("-1 \\leq x < 0")#text(" force F(0)=-1. Together they force F(0) to take values in the empty set, which is absurd.")

#text("What has gone on here is that while the original bundle ")#mi("{\\mathcal H}")#text(" looked ")#link("http://en.wikipedia.org/wiki/Prima_facie")[#text("prima facie")]#text(" like it could support sections, the qualitative nature of the solution space ")#mi("C^m")#text(" showed that the constraints in that bundle actually forced sections to lie in a smaller bundle ")#mi("{\\mathcal H}^{\\prime}")#text(" (which, in the above simple example, is the same as the original bundle but in which the fiber at 0 was replaced with the empty set). The smaller bundle did not admit sections, and so the original bundle did not.")

#text("It turns out that there is a natural way to generalise the idea of “using continuity to deduce new constraints from old” to the ")#mi("C^m")#text(" problem and not just the ")#mi("C^0")#text(" problem, known as ")#emph[#text("Glaeser reduction")]#text(". To explain it, let us give a more sophisticated example, now in the category of ")#mi("C^1({\\Bbb R}^2)")#text(" rather than ")#mi("C^0({\\Bbb R})")#text(". Let ")#mi("\\phi: (0,1] \\to [-1,1]")#text(" be a ")#mi("C^1")#text(" function with ")#mi("-x \\leq \\phi(x) \\leq x")#text(" for ")#mi("x \\in (0,1]")#text(", and with ")#mi("\\phi^{\\prime}")#text(" oscillating infinitely often between -1 and 1. (A simple example of such a function is ")#mi("\\phi(x) := \\frac{1}{\\sqrt{2}} x \\sin(\\log x)")#text(".) Let ")#mi("E :=  \\{(0,0)\\} \\cup \\{ (x, \\phi(x)): x \\in (0,1] \\}")#text(" be the graph of ")#mi("\\phi")#text(", with the origin adjoined. Consider the problem of extending a given function ")#mi("f: E \\to {\\Bbb R}")#text(" in a ")#mi("C^1")#text(" manner to a function ")#mi("F: {\\Bbb R}^2 \\to {\\Bbb R}")#text(" defined on the entire plane. At any point ")#mi("(x,\\phi(x))")#text(" on E which is not the origin, the value ")#mi("F(x,\\phi(x))")#text(" of F at this point is prescribed; it is equal to f. Differentiating this along x, we also see that the tangential derivative ")#mi("F_{x_1}(x,\\phi(x)) + \\phi^{\\prime}(x) F_{x_2}(x,\\phi(x))")#text(" is prescribed (and may in fact be forced to live in the empty set, if f is not differentiable tangentially), but that the normal derivative is not. Thus we see that the jet ")#mi("J_{(x,\\phi(x))}(F) = F(x,\\phi(x)) + F_{x_1}(x,\\phi(x)) (x-x_1) + F_{x_2}(x,\\phi(x)) (x_2-\\phi(x))")#text(" is constrained to a coset of a one-dimensional ideal of the three-dimensional space ")#mi("{\\mathcal P}_{(x,\\phi(x))}")#text(", or possibly the empty set if f is not differentiable.")

#text("But what is happening at the origin (0,0)? The value of F(0,0) is of course prescribed to equal f(0,0), but what about the first derivatives ")#mi("F_{x_1}(0,0), F_{x_2}(0,0)")#text("? The curve E is not differentiable at (0,0), so one cannot directly differentiate f to recover any of these first derivatives. However, we are requiring F to be not just differentiable, but ")#emph[#text("continuously")]#text(" differentiable. Because of this, we can infer constraints on ")#mi("F_{x_1}(0,0), F_{x_2}(0,0)")#text(" from the constraints on the tangential derivatives ")#mi("F_{x_1}(x,\\phi(x)) + \\phi^{\\prime}(x) F_{x_2}(x,\\phi(x))")#text(" as x approaches 0. Indeed, it is not hard use the infinite oscillation of ")#mi("\\phi")#text(" to conclude that if all of these tangential derivatives are prescribed, then both first derivatives ")#mi("F_{x_1}(0,0), F_{x_2}(0,0)")#text(" of F at the origin must be prescribed also.")

#text("One can even concoct iterated examples in which the continuity is used once to deduce new constraints from old, and then used again to deduce even more constraints from the ones just established. Consider for instance the compact set ")#mi("E = \\overline{\\bigcup_{n=1}^\\infty E_n} \\subset {\\Bbb R}^2")#text(", where each ")#mi("E_n")#text(" is the curve")

#align(center)[#tao-fit-display[#mitex("E_n = \\{ ( 4^{-n} (1+x), 8^{-n} \\phi(x) ): 0 < x \\leq 1 \\}")]]

#text("and ")#mi("\\phi: (0,1] \\to [-1,1]")#text(" is the function defined earlier. (E is thus a collection of infinitely oscillating curves which become increasingly horizontal as they accumulate at the origin.) If one prescribes a function ")#mi("f: E \\to {\\Bbb R}")#text(" and tries to extend it a ")#mi("C^1({\\Bbb R}^2)")#text(" function F on the entire plane, then to begin with there are no constraints on the first derivatives of F at the origin, or at the accumulation points ")#mi("(4^{-n}, 0)")#text(", though as before one has constraints on tangential first derivatives of F on the rest of E. But by using the continuously differentiable nature of F to take limits, one can infer that both first derivatives of F are prescribed at each of the points ")#mi("(4^{-n},0)")#text(", and that ")#mi("F_{x_1}(0,0)")#text(" is also prescribed. The vertical derivative ")#mi("F_{x_2}(0,0)")#text(" is not prescribed by such a limiting process directly, but can instead be prescribed by an iteration of the limiting process, using the control on ")#mi("F_{x_2}(4^{-n},0)")#text(" obtained from the preceding limiting process.")

#text("Now we formalise the most general version of this “limiting process” for ")#mi("C^m({\\Bbb R}^n)")#text(". The key observation is the following: if ")#mi("F \\in C^m({\\Bbb R}^n)")#text(", ")#mi("x_0 \\in {\\Bbb R}^n")#text(", and ")#mi("\\varepsilon > 0")#text(", then for all x sufficiently close to ")#mi("x_0")#text(", the jets ")#mi("J_x(F) \\in {\\mathcal P}_x")#text(" are all close to each other in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\nabla^l (J_x(F) - J_{x^{\\prime}}(F))(x)\\right|  \\leq \\varepsilon \\left|x-x^{\\prime}\\right|^{m-l}", block: true)]]

#text("for all x,x’ sufficiently close to ")#mi("x_0")#text(" and all ")#mi("0 \\leq l \\leq m")#text(". (This fact is essentially just Taylor’s theorem with remainder.)")

#text("From the above observation, we conclude that if F is a section of a bundle ")#mi("{\\mathcal H} = (H_x)_{x \\in E}")#text(", ")#mi("x_0 \\in E")#text(", and ")#mi("k > 0")#text(" is an integer, then the jet ")#mi("P_0 := J_{x_0}(F) \\in H_{x_0}")#text(" must have the following property: for every ")#mi("\\varepsilon > 0")#text(" there must exist a neighbourhood of ")#mi("x_0")#text(" such that for all ")#mi("x_1,\\ldots,x_k \\in E")#text(" in this neighbourhood, there exist polynomials ")#mi("P_j \\in H_{x_j}")#text(" for ")#mi("1 \\leq j \\leq k")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\nabla^l (P_i - P_j)(x_i)\\right|  \\leq \\varepsilon \\left|x_i-x_j\\right|^{m-l}", block: true)]]

#text("for all ")#mi("0 \\leq i,j \\leq k")#text(" and ")#mi("0 \\leq l \\leq m")#text(". Let us say that ")#mi("P_0")#text(" is a ")#emph[#text("limit polynomial")]#text(" of ")#mi("{\\mathcal H}")#text(" if it has the above property (with k set equal to some sufficiently large integer depending only on n and m). We then define the Glaeser refinement ")#mi("{\\mathcal H}^{\\prime} = (H^{\\prime}_x)_{x \\in E}")#text(" of ")#mi("{\\mathcal H}")#text(" by declaring ")#mi("H^{\\prime}_{x_0}")#text(" to be the set of all ")#mi("P_0 \\in H_{x_0}")#text(" which are limit polynomials. One easily checks that ")#mi("{\\mathcal H}^{\\prime}")#text(" is a sub-bundle of ")#mi("{\\mathcal H}")#text(", and the above discussion shows that every section of ")#mi("{\\mathcal H}")#text(" must in fact be a section of ")#mi("{\\mathcal H}^{\\prime}")#text(", thus ")#mi("{\\mathcal O}({\\mathcal H}) = {\\mathcal O}({\\mathcal H}^{\\prime})")#text(". Note that Glaeser refinement is quite a constructive process; it is possible to describe it using only a finite number of algebraic operations, together with the limit operation. It can certainly produce bundles with empty fibres, even when the original bundle had no empty fibres; this means that the Glaeser process discovered that the original constraints on F were incompatible with F being m-times continuously differentiable.")

#text("One then quickly sees that to answer any of questions 1,2,3 for a bundle, it suffices to do so for its Glaeser refinement, which can be viewed as the same bundle but with some additional constraints that have been “deduced” from the original constraints by limiting arguments. It is then natural to iterate this process, taking Glaeser refinements of Glaeser refinements (as was implicitly done in the examples discussed before), and see whether the bundle stabilises or not.")

#text("In the case of m=0 (i.e. for continuous extensions), this process stabilises immediately; a Glaeser refinement is its own Glaeser refinement, for much the same reason that the closure of a set is its own closure. For ")#mi("m \\geq 1")#text(", the process can be non-trivial for a little longer, as we have already seen, but it is actually not hard to show that it still stabilises after O(1) many steps. (If you divide the bundle into strata, depending on the dimension of the fibre, the stratum with the highest dimensional fibres will stop generating new constraints fairly quickly, then the next highest stratum will stop doing so soon after that, and so forth.) Thus one quickly reduces matters to ")#emph[#text("Glaeser-stable")]#text(" bundles – bundles which are their own Glaeser refinement.")

#text("With this reduction, Charlie could now finally give the main theorem, which more or less completely answers Q1, Q2, Q3 above.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem")]#text(". Fix m,n,E, and let ")#mi("{\\mathcal H} = (H_x)_{x \\in E}")#text(" be a Glaeser-stable bundle.")

#enum(start: 1, 
[#mi("{\\mathcal H}")#text(" admits sections if and only if every fibre ")#mi("H_x")#text(" of ")#mi("{\\mathcal H}")#text(" is non-empty.")],
[#text("If ")#mi("{\\mathcal H}")#text(" admits sections, and ")#mi("x \\in E")#text(", then every element of ")#mi("H_x")#text(" can arise as the jet of a section of ")#mi("{\\mathcal H}")#text(".")],
[#text("If ")#mi("{\\mathcal H}")#text(" admits sections, then there exists a finite subset S of E of cardinality O(1) such that")#linebreak()#text(" ")#tao-math("\\inf \\{ \\left\\|F\\right\\|_{C^m}: F \\in {\\mathcal O}({\\mathcal H}) \\} \\sim \\inf \\{ \\left\\|F\\right\\|_{C^m}: F \\in {\\mathcal O}({\\mathcal H}|_S) \\}", block: false)#text(".")]
)
]

#text("Informally, part 1 of this theorem asserts that after all deductions of Glaeser type have been made, there are no further obstructions to global solvability other than the pointwise ones. Part 2 is in a similar spirit, and says that after all deductions of Glaeser type have been made, no further constraints on the derivatives of the function F can be located. The third is a finiteness theorem: in order to compute the quality of the best section of a bundle (up to multiplicative constants), it suffices to do so on a set of bounded cardinality. This can in fact be done in an explicitly computable manner: the quantity ")#tao-math("\\inf \\{ \\left\\|F\\right\\|_{C^m}: F \\in {\\mathcal O}({\\mathcal H}|_S) \\}", block: false)#text(", up to multiplicative constants, is equal to the best constant M such that one can find polynomials ")#mi("P_x \\in H_x")#text(" for all ")#mi("x \\in S")#text(" with coefficients at most M (when expanded around x) and such that")

#align(center)[#tao-fit-display[#tao-math("\\nabla^l (P_x - P_y)(y)| \\leq M \\left|x-y\\right|^{m-l}", block: true)]]

#text("for all ")#mi("x,y \\in S")#text(" and ")#mi("0 \\leq l \\leq m")#text(". This M can be computed by ")#link("http://en.wikipedia.org/wiki/Linear_programming")[#text("linear programming")]#text(" methods. Thus the above result, combined with the computability of the Glaeser refinement process, gives about as computable and constructive a resolution to Q1, Q2, Q3 as one could hope for.")

#text("(The bound on the cardinality of S is actually rather explicit. In the m=1 case, one can take S to have cardinality at most ")#mi("3 \\times 2^{n-1}")#text(", and this is best possible. For higher m, the best known bound is equal to an absolute constant times ")#mi("2^{\\dim({\\mathcal P})}")#text(".)")

#text("Charlie then briefly discussed how one proves the main theorem. The idea, which already appeared earlier in this post, is to ")#link("http://en.wikipedia.org/wiki/Stratification_%28mathematics%29#In_singularity_theory")[#text("stratify")]#text(" the set E using the dimensions of the fibres (though Charlie indicated that the precise stratification used was slightly more complicated than this), and to induct on the number of non-trivial strata. The case of zero strata was rather vacuous, so suppose that there was at least one non-trivial stratum. One then looks at the stratum with the lowest dimensional fibres; from Glaeser stability, this is a compact subset E’ of E. Furthermore, the bundle over E’ must exhibit a kind of “continuity” (since, by Glaeser stability, every point in every fibre is a limit polynomial of the nearby fibres). From continuity and compactness one can get “uniform continuity”, which means that on E’ one can replace ")#mi("C^m")#text(" by ")#mi("C^{m,\\omega}")#text(" for some modulus of continuity ")#mi("\\omega")#text(". By using the finiteness theorem for this modulus of continuity (which, as discussed before, extends without difficulty to infinite domains) we can then get everything we want regarding sections – but only on E’ instead of E. To get sections on all of E, we need to modify the sections just obtained, as they obey the right constraints on E’ but not necessarily on E. But this can be done by taking a ")#emph[#text("Whitney decomposition")]#text(" of ")#mi("{\\Bbb R}^n \\backslash E^{\\prime}")#text(" into various cubes; in other words, a decomposition of the complement of E’ into a collection of finitely overlapping cubes, where the distance of each cube to E’ is comparable to the diameter of that cube. On each cube, there is at least one fewer stratum than in the general case, so by the inductive hypothesis we can create sections on each cube, and by use of smooth partitions of unity we can glue things together. However, if one wants to sum up and retain ")#mi("C^m")#text(" control all the way up to the set ")#mi("E^{\\prime}")#text(", it turns out that one needs quantitative control on all the pieces being glued together. With our current setup, this is simply not available; the jets of the sections F are constrained to live in cosets of ideals, but otherwise do not obey any bounds.")

#text("To fix this, one in fact has to start all over again, working in a more general framework, in which the cosets of ideals are replaced by translates of symmetric convex bodies. As noted before, this framework is far too general to have any hope of a reasonable solution, but it turns out that all the above arguments can be carried over to this case provided that the convex bodies obey the additional property of ")#emph[#text("Whitney convexity")]#text(". But the time for the lecture was up, and so Charlie left off with another cliffhanger regarding the actual definition of Whitney convexity and how it affects the above arguments.")

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 2: Three categories of dynamical systems « What’s new")]], [#link("https://terrytao.wordpress.com/2007/11/15/distinguished-lecture-series-ii-charles-fefferman-interpolation-of-functions-on-rn/#comment-23869")[#strong[#text("254A, Lecture 2: Three categories of dynamical systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2008")])]

#text("[…] times before one reaches a minimal orbit (cf. the “Glaeser refinements” in this lecture of Charlie Fefferman). For instance, consider the boolean Bernoulli system again, but now consider the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ef5325325dca9c6e9bcd44542dbbbba3679b7612dd318b10eea9e44ed870546-8bb2980bd3f55e425c5cb45ee93cc27eb6f3437f0b0904de8fc38cb2bec889d2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hari")]], [#link("https://terrytao.wordpress.com/2007/11/15/distinguished-lecture-series-ii-charles-fefferman-interpolation-of-functions-on-rn/#comment-46491")[#strong[#text("Hari")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2010")])]

#text("Just thought I’d paste a link to a talk Prof. Fefferman gave at IMA.")

#link("http://www.ima.umn.edu/videos/?id=570")[#text("http://www.ima.umn.edu/videos/?id=570")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e50ee7c98712a9d9c915eacf93e99b483fb158b6d652fb2ce55903dfb79baaa5-d21824e788c978a15d91a7a6540e4f8ac93170f751988a9c723b05e0a6f82e0e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cxseven")]], [#link("https://terrytao.wordpress.com/2007/11/15/distinguished-lecture-series-ii-charles-fefferman-interpolation-of-functions-on-rn/#comment-451945")[#strong[#text("cxseven")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2015")])]

#text("Thank you so much for this great blog. A minor nit: phi has a derivative that oscillates between +/-sqrt(2)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e50ee7c98712a9d9c915eacf93e99b483fb158b6d652fb2ce55903dfb79baaa5-d21824e788c978a15d91a7a6540e4f8ac93170f751988a9c723b05e0a6f82e0e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cxseven")]], [#link("https://terrytao.wordpress.com/2007/11/15/distinguished-lecture-series-ii-charles-fefferman-interpolation-of-functions-on-rn/#comment-452097")[#strong[#text("cxseven")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2015")])]

#text("Was sqrt(x) meant to be sqrt(2)? I also noticed further along that there was some $ delimited LaTeX that somehow escaped rendering, but it hardly affected readability. Thank you again for these tremendously valuable notes.")

#emph[#text("[Corrected, thanks – T.]")]
]
