// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/
// Converted to Typst by tao2typ: "2026-10-14T16:35:50.099857+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "P=NP, relativisation, and multiple choice exams", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("P=NP, relativisation, and multiple choice exams")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 August 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/")[#text("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The most fundamental unsolved problem in complexity theory is undoubtedly the ")#link("http://en.wikipedia.org/wiki/P_%3D_NP_problem")[#text("P=NP problem")]#text(", which asks (roughly speaking) whether a problem which can be solved by a ")#link("http://en.wikipedia.org/wiki/NP_(complexity)")[#text("non-deterministic polynomial-time (NP)")]#text(" algorithm, can also be solved by a ")#link("http://en.wikipedia.org/wiki/P_(complexity)")[#text("deterministic polynomial-time (P)")]#text(" algorithm. The general belief is that ")#mi("{P \\neq NP}")#text(", i.e. there exist problems which can be solved by non-deterministic polynomial-time algorithms but not by deterministic polynomial-time algorithms.")

#text("One reason why the ")#mi("{P \\neq NP}")#text(" question is so difficult to resolve is that a certain generalisation of this question has an affirmative answer in some cases, and a negative answer in other cases. More precisely, if we give all the algorithms access to an ")#link("http://en.wikipedia.org/wiki/Oracle_machine")[#text("oracle")]#text(", then for one choice ")#mi("{A}")#text(" of this oracle, all the problems that are solvable by non-deterministic polynomial-time algorithms that calls ")#mi("{A}")#text(" (")#mi("{NP^A}")#text("), can also be solved by a deterministic polynomial-time algorithm algorithm that calls ")#mi("{A}")#text(" (")#mi("{P^A}")#text("), thus ")#mi("{P^A = NP^A}")#text("; but for another choice ")#mi("{B}")#text(" of this oracle, there exist problems solvable by non-deterministic polynomial-time algorithms that call ")#mi("{B}")#text(", which ")#emph[#text("cannot")]#text(" be solved by a deterministic polynomial-time algorithm that calls ")#mi("{B}")#text(", thus ")#mi("{P^B \\neq NP^B}")#text(". One particular consequence of this result (which is ")#link("http://www.ams.org/mathscinet-getitem?mr=395311")[#text("due to Baker, Gill, and Solovay")]#text(") is that there cannot be any ")#emph[#text("relativisable")]#text(" proof of either ")#mi("{P=NP}")#text(" or ")#mi("{P \\neq NP}")#text(", where “relativisable” means that the proof would also work without any changes in the presence of an oracle.")

#text("The Baker-Gill-Solovay result was quite surprising, but the idea of the proof turns out to be rather simple. To get an oracle ")#mi("{A}")#text(" such that ")#mi("{P^A=NP^A}")#text(", one basically sets ")#mi("{A}")#text(" to be a powerful simulator that can simulate non-deterministic machines (and, furthermore, can also simulate ")#emph[#text("itself")]#text("); it turns out that any ")#link("http://en.wikipedia.org/wiki/PSPACE-complete")[#text("PSPACE-complete")]#text(" oracle would suffice for this task. To get an oracle ")#mi("{B}")#text(" for which ")#mi("{P^B \\neq NP^B}")#text(", one has to be a bit sneakier, setting ")#mi("{B}")#text(" to be a query device for a sparse set of random (or high-complexity) strings, which are too complex to be guessed at by any deterministic polynomial-time algorithm.")

#text("Unfortunately, the simple idea of the proof can be obscured by various technical details (e.g. using ")#link("http://en.wikipedia.org/wiki/Turing_machine")[#text("Turing machines")]#text(" to define ")#mi("{P}")#text(" and ")#mi("{NP}")#text(" precisely), which require a certain amount of time to properly absorb. To help myself try to understand this result better, I have decided to give a sort of “allegory” of the proof, based around a (rather contrived) story about various students trying to pass a multiple choice test, which avoids all the technical details but still conveys the basic ideas of the argument. This allegory was primarily for my own benefit, but I thought it might also be of interest to some readers here (and also has some tangential relation to the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Finding_primes")[#text("proto-polymath project of determinstically finding primes")]#text("), so I reproduce it below.")

#metadata(none) <tao-13bbefbd88a9edecef3d>

#heading(level: 1)[#strong[#text(" — 1. ")#mi("{P}")#text(" and ")#mi("{NP}")#text(" students — ")]]

#text("In this story, two students, named ")#mi("{P}")#text(" and ")#mi("{NP}")#text(" (and which for sake of grammar, I will arbitrarily assume to be male), are preparing for their final exam in a maths course, which will consist of a long, tedious sequence of multiple-choice questions, or more precisely true-false questions. The exam has a reasonable but fixed time limit (e.g. three hours), and unlimited scratch paper is available during the exam. Students are allowed to bring one small index card into the exam. Other than scratch paper, an index card, and a pencil, no other materials are allowed. Students cannot leave questions blank; they must answer each question true or false. The professor for this course is dull and predictable; everyone knows in advance the type of questions that will be on the final, the only issue being the precise numerical values that will be used in the actual questions.")

#text("For each student response to a question, there are three possible outcomes:")

#list(
[#strong[#text("Correct answer.")]#text(" The student answers the question correctly.")],
[#strong[#text("False negative.")]#text(" The student answers “false”, but the actual answer is “true”.")],
[#strong[#text("False positive.")]#text(" The student answers “true”, but the actual answer is “false”.")]
)

#text("We will assume a certain asymmetry in the grading: a few points are deducted for false negatives, but a large number of points are deducted for false positives. (There are many real-life situations in which one type of error is considered less desirable than another; for instance, when deciding on guilt in a capital crime, a false positive is generally considered a much worse mistake than a false negative.) So, while students would naturally like to ace the exam by answering all questions correctly, they would tend to err on the side of caution and put down “false” when in doubt.")

#text("Student ")#mi("{P}")#text(" is hard working and careful, but unimaginative and with a poor memory. His exam strategy is to put all the techniques needed to solve the exam problems on the index card, so that they can be applied by rote during the exam. If the nature of the exam is such that ")#mi("{P}")#text(" can be guaranteed to ace it by this method, we say that the exam ")#emph[#text("is in class ")#mi("{P}")]#text(". For instance, if the exam will consist of verifying various multiplication problems (e.g. “Is ")#mi("{231*136=31516}")#text("?”), then this exam is in class ")#mi("{P}")#text(", since ")#mi("{P}")#text(" can put the algorithm for long multiplication, together with a multiplication table, on the index card, and perform these computations during the exam. A more non-trivial example of an exam in class ")#mi("{P}")#text(" would be an exam consisting solely of determining whether various large numbers are prime; here ")#mi("{P}")#text(" could be guaranteed to ace the test by writing down on his index card the details of the ")#link("http://en.wikipedia.org/wiki/AKS_primality_test")[#text("AKS primality test")]#text(".")

#text("Student ")#mi("{NP}")#text(" is similar to ")#mi("{P}")#text(", but is substantially less scrupulous; he has bribed the proctor of the exam to supply him with a full solution key, containing not only the answers, but also the worked computations that lead to that answer (when the answer is “true”). The reason he has asked (and paid) for the latter is that he does not fully trust the proctor to give reliable answers, and is terrified of the impact to his grades if he makes a false positive. Thus, if the answer key asserts that the answer to a question is “true”, he plans to check the computations given to the proctor himself before putting down “true”; if he cannot follow these computations, and cannot work out the problem himself, he will play it safe and put down “false” instead.")

#text("We will say that the exam ")#emph[#text("is in class ")#mi("{NP}")]#text(" if")

#list(
[#mi("{NP}")#text(" is guaranteed to ace the exam if the information given to him by the proctor is reliable;")],
[#mi("{NP}")#text(" is guaranteed not to make a false positive, even if the proctor has given him unreliable information.")]
)

#text("For instance, imagine an exam consisting of questions such as “Is Fermat’s last theorem provable in ten pages or less?”. Such an exam is in the class ")#mi("{NP}")#text(", as the student can bribe the proctor to ask for a ten-page proof of FLT, if such exists, and then would check that proof carefully before putting down “True”. This way, the student is guaranteed not to make a false positive (which, in this context, would be a severe embarrassment to any reputable mathematician), and will ace the exam if the proctor actually does happen to have all the relevant proofs available.")

#text("It is clear that ")#mi("{NP}")#text(" is always going to do at least as well as ")#mi("{P}")#text(", since ")#mi("{NP}")#text(" always has the option of ignoring whatever the proctor gives him, and copying ")#mi("{P}")#text("‘s strategy instead. But how much of an advantage does ")#mi("{NP}")#text(" have over ")#mi("{P}")#text("? In particular, if we give ")#mi("{P}")#text(" a little bit more time (and a somewhat larger index card), could every exam that is in class ")#mi("{NP}")#text(", also be in class ")#mi("{P}")#text("? This, roughly speaking, is the ")#mi("{P=NP}")#text(" problem. It is believed that ")#mi("{P \\neq NP}")#text(", thus there are exams which ")#mi("{NP}")#text(" will ace (with reliable information) and will at least not make a false positive (even with unreliable information), but for which ")#mi("{P}")#text(" is not guaranteed to ace, even with a little extra time and space.")

#heading(level: 1)[#strong[#text(" — 2. Oracles — ")]]

#text("Now let’s modify the exams a bit by allowing a limited amount of computer equipment in the exam. In addition to the scratch paper, pencil, and index card, every student in the exam is now also given access to a computer ")#mi("{A}")#text(" which can perform a carefully limited set of tasks that are intended to assist the student. Examples of tasks permitted by ")#mi("{A}")#text(" could include a scientific calculator, a mathematics package such as Matlab or SAGE, or access to Wikipedia or Google. We say that an exam is ")#emph[#text("in class ")#mi("{P^A}")]#text(" if it can be guaranteed to be aced by ")#mi("{P}")#text(" if he has access to ")#mi("{A}")#text(", and similarly the exam ")#emph[#text("is in class ")#mi("{NP^A}")]#text(" if it can be guaranteed to be aced by ")#mi("{NP}")#text(" if he has access to ")#mi("{A}")#text(" and the information obtained from the proctor was reliable, and if he is at least guaranteed not to make a false positive with access to ")#mi("{A}")#text(" if the information from the proctor turned out to be unreliable. Again, it is clear that ")#mi("{NP}")#text(" will have the advantage over ")#mi("{P}")#text(", in the sense that every exam in class ")#mi("{P^A}")#text(" will also be in class ")#mi("{NP^A}")#text(". (In other words, the proof that ")#mi("{P \\subset NP}")#text(" ")#emph[#text("relativises")]#text(".) But what about the converse – is every exam in class ")#mi("{NP^A}")#text(", also in class ")#mi("{P^A}")#text(" (if we give ")#mi("{P}")#text(" a little more time and space, and perhaps also a slightly larger and faster version of ")#mi("{A}")#text(")?")

#text("We now give an example of a computer ")#mi("{A}")#text(" with the property that ")#mi("{P^A=NP^A}")#text(", i.e. that every exam in class ")#mi("{NP^A}")#text(", is also in class ")#mi("{P^A}")#text(". Here, ")#mi("{A}")#text(" is an extremely fast computer with reasonable amount of memory and a compiler for a general-purpose programming language, but with no additional capabilities. (More precisely, ")#mi("{A}")#text(" should be a ")#link("http://en.wikipedia.org/wiki/PSPACE-complete")[#text("PSPACE-complete")]#text(" language, but let me gloss over the precise definition of this term here.)")

#text("Suppose that an exam is in class ")#mi("{NP^A}")#text(", thus ")#mi("{NP}")#text(" will ace the exam if he can access ")#mi("{A}")#text(" and has reliable information, and will not give any false positive if he can access ")#mi("{A}")#text(" and has unreliable information. We now claim that ")#mi("{P}")#text(" can also ace this exam, if given a little bit more time and a slightly larger version of ")#mi("{A}")#text(". The way he does it is to program his version of ")#mi("{A}")#text(" to simulate ")#mi("{NP}")#text("‘s strategy, by looping through all possible values of the solution key that ")#mi("{NP}")#text(" might be given, and also simulating ")#mi("{NP}")#text("‘s copy of ")#mi("{A}")#text(" as well. (The latter task is possible as long as ")#mi("{P}")#text("‘s version of ")#mi("{A}")#text(" is slightly larger and faster than ")#mi("{NP}")#text("‘s version.) There are of course an extremely large number of combinations of solution key to loop over (for instance, consider how many possible proofs of Fermat’s last theorem under ten pages there could be), but we assume that the computer is so fast that it can handle all these combinations without difficulty. If at least one of the possible choices for a solution key causes the simulation of ")#mi("{NP}")#text(" to answer “true”, then ")#mi("{P}")#text(" will answer “true” also; if instead none of the solution keys cause ")#mi("{NP}")#text(" to answer “true”, then ")#mi("{P}")#text(" will answer “false” instead. If the exam is in class ")#mi("{NP^A}")#text(", it is then clear that ")#mi("{P}")#text(" will ace the exam.")

#text("Now we give an example of a computer ")#mi("{B}")#text(" with the property that ")#mi("{P^B \\neq NP^B}")#text(", i.e. there exists an exam which is in class ")#mi("{NP^B}")#text(", but for which ")#mi("{P}")#text(" is not guaranteed to ace even with the assistance of ")#mi("{B}")#text(". The only software loaded on ")#mi("{B}")#text(" is a web browser, which can fetch any web page desired after typing in the correct URL. However, rather than being connected to the internet, the browser can only access a local file system of pages. Furthermore, there is no directory or search feature in this file system; the only way to find a page is to type in its URL, and if you can’t guess the URL correctly, there is no way to access that page. (In particular, there are no links between pages.)")

#text("Furthermore, to make matters worse, the URLs are not designed according to any simple scheme, but have in fact been generated randomly, by the following procedure. For each positive integer ")#mi("{n}")#text(", flip a coin. If the coin is heads, then create a URL of ")#mi("{n}")#text(" random characters and place a web page at that URL. Otherwise, if the coin is tails, do nothing. Thus, for each ")#mi("{n}")#text(", there will either be one web page with a URL of length ")#mi("{n}")#text(", or there will be no web pages of this length; but in the former case, the web page will have an address consisting of complete gibberish, and there will be no means to obtain this address other than by guessing.")

#text("The exam will consist of a long series of questions such as “Is there a web page on ")#mi("{B}")#text(" with a URL of ")#mi("{1254}")#text(" characters in length?”.")

#text("It is clear that this exam is in class ")#mi("{NP^B}")#text(". Indeed, for ")#mi("{NP}")#text(" to ace this exam, he just needs to bribe the proctor for the URLs of all the relevant web pages (if they exist). He can then confirm their existence by typing them into ")#mi("{B}")#text(", and then answer “true” if he finds the page, and “false” otherwise. It is clear that ")#mi("{NP}")#text(" will ace the exam if the proctor information is reliable, and will avoid false positives otherwise.")

#text("On the other hand, poor ")#mi("{P}")#text(" will have no chance to ace this exam if the length of the URLs are long enough, for two reasons. Firstly, the browser ")#mi("{B}")#text(" is useless to him: any URL he can guess will have almost no chance of being the correct one, and so the only thing he can generate on the browser is an endless stream of “404 Not Found” messages. (Indeed, these URLs are very likely to have a high ")#link("http://en.wikipedia.org/wiki/Kolmogorov_complexity")[#text("Kolmogorov complexity")]#text(", and thus cannot be guessed by ")#mi("{P}")#text(". Admittedly, ")#mi("{P}")#text(" does have ")#mi("{B}")#text(" available, but one can show by induction on the number of queries that ")#mi("{B}")#text(" is useless to ")#mi("{P}")#text(". We also make the idealised assumption that ")#link("http://en.wikipedia.org/wiki/Side-channel_attack")[#text("side-channel attacks")]#text(" are not available.) As ")#mi("{B}")#text(" is useless, the only hope ")#mi("{P}")#text(" has is to guess the sequence of coin flips that were used to determine the set of ")#mi("{n}")#text(" for which URLs exist of that length. But the random sequence of coin flips is also likely to have high Kolmogorov complexity, and thus cannot be guaranteed to be guessed by ")#mi("{P}")#text(" either. Thus ")#mi("{P^B \\neq NP^B}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Note how the existence of long random strings could be used to make an oracle that separates ")#mi("{P}")#text(" from ")#mi("{NP}")#text(". In the absence of oracles, it appears that separation of ")#mi("{P}")#text(" from ")#mi("{NP}")#text(" is closely connected to the existence of long ")#emph[#text("pseudorandom")]#text(" strings – strings of numbers which can be deterministically generated (perhaps from a given seed) in a reasonable amount of time, but are difficult to distinguish from genuinely random strings by any quick tests. See ")#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/")[#text("my writeup of this lecture by Avi Wigderson")]#text(" for more discussion.")
]

#heading(level: 1)[#text("Comments (37)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5536e2ed5c1fa87e54776ade5c0361da235581bd08d9265280e5bf61c2141ed-12b84bee07fb83b2ffe132e11959371bef82c8c3b1a80d1c8030af90cbdec6dc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. Eppstein")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-40781")[#strong[#text("D. Eppstein")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2009")])]

#emph[#text("it appears that separation of {P} from {NP} is closely connected to the existence of long pseudorandom strings")]

#text("Huh. If P=NP then P=BPP, because BPP is part of the polynomial hierarchy. Intuitively, the way for P=BPP would be for there to exist a deterministic pseudorandom number generator that cannot be distinguished from truly random within P — then any BPP program could be derandomized using this generator. But, being able to invert a pseudorandom number generator (distinguishing it from random) is an NP task. So if P=BPP then (waves hands extra-vigorously) there exists an NP task that can’t be performed within P, namely inverting the supposed pseudorandom number generator, and therefore P≠NP.")

#text("In summary: P=NP => P=BPP => P≠NP or more simply P≠NP.")

#text("Sadly, I doubt this line of reasoning has much probability of leading to a million-dollar prize for me.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6f35cd52575d3b70420c2058eaed4fd261c8b1f593a75e06fbda8ed59eee972-4f3a90a0bc891b73bfcea4a2b84eab1c9d34401b21aef32cef2ab2be223b7932.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Suresh")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-40784")[#strong[#text("Suresh")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2009")])]

#text("This sounds like razborov-rudich in disguise….")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f116bf22e5bd64bf827ebcc897a0414b436761f21bfc94676685db2b975cb19-cf19f4dd08641c2109a5f48cf106d2d1d1638df9ffade0619b608c6a048a8bde.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Björn Edström")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-40790")[#strong[#text("Björn Edström")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2009")])]

#text("Good exposition, thanks. A good follow up would be an anology about natural proofs. I think I’m not the only one who would appreciate such an article.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/826a2728424b30ad8cc83000d2bfd8744edcd1bafba060e1c70b63281a0934f6-5e3de4a3d5bde314bee2c1b42ac7f851cee463773970099eaeb046cc61a7dd19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harrison")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-40824")[#strong[#text("Harrison")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2009")])]

#text("The problem with natural proofs is I’m not sure what the proper analogy for circuits is in this metaphor. Personally, I’d like to see a multiple-choice explanation of algebrization, which I feel I understand a lot less and which is more obviously connected with oracles.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43f36f94e4d004ccfdd54abca3b780c86cbccc21b25934a7cd56da2b0ffdca7b-c5418ce346a4e74ccdd7910682367db9b88e1724b790e0118579d972a86cdd81.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rasmus")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-40796")[#strong[#text("rasmus")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2009")])]

#text("Are you going to work on P vs NP?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2e69fe991008100445ec71dcce3acc2dd72f160b39f34a569b2669354396f85-1909c969e8c28926f573b796901e14bbf8458eb0ecb81c2ff446a678aa5879f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy D")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-40797")[#strong[#text("Andy D")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2009")])]

#text("These are useful analogies. As Terry says, the simple ideas of oracle results can be obscured by technical details arising from the TM model. In practice, I think complexity theorists feel the same way, and have developed ways of defining and thinking about oracles that make life easier, although these techniques may not always come thru clearly in papers (and may not have as much narrative quality as Terry’s story).")

#text("The main idea is usually to view Turing machines as taking oracles as input, and trying to solve problems defined in terms of the oracle’s bits on a particular input length. The Turing machine’s access to the oracle is quite limited, hopefully to the extent that there are provable limitations on its ability to reason about the oracle.")

#text("For instance, the existence of an oracle relative to which P^A != NP^A is often seen as a ‘translation’ or ‘scaling up’ of the fact that the OR function on N bits has deterministic query complexity N, but nondeterministic query complexity 1.")

#text("Another example: the existence of an oracle relative to which the Polynomial Hierarchy (PH) is properly contained in PSPACE, is seen (and proved) as a translation of the fact that an efficiently computable function (namely, PARITY on N bits) requires exponential-size constant-depth AND/OR circuits (aka ‘AC^0 circuits’) to compute.")

#text("This seems to’ve actually been the original motivation to study constant-depth circuits. A lot of research in the more ‘concrete’ models of query- and circuit-based computation received its impetus from the more ‘abstract’ world of oracles in the Turing machine model. Of course, concrete computational models are also interesting to study in their own right, but they remain useful frameworks thru which to view oracle questions in complexity.")

#text("Unfortunately, I’m not aware of any single paper that comprehensively teaches the use of this perspective and how to make the appropriate translations. Maybe someone else can chime in with one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2e69fe991008100445ec71dcce3acc2dd72f160b39f34a569b2669354396f85-1909c969e8c28926f573b796901e14bbf8458eb0ecb81c2ff446a678aa5879f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy D")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-40798")[#strong[#text("Andy D")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2009")])]

#text("What keeps David’s sketch-argument from being more lucrative is partly the fact that derandomization hypotheses come in a variety of strengths. There are three that are relevant here, which I’ll list in increasing order of strength.")

#text("H1: P = BPP.")

#text("H2: For every c > 0, there exists a poly-time-computable pseudorandom generator that fools any distinguisher running in time n^c.")

#text("H3: There exists a poly-time-computable pseudorandom generator that fools every poly-time distinguisher.")

#text("(I’m neglecting the additional variable of the seed-length for the generator; assume this is logarithmic in the output length.)")

#text("Now, it’s not known that H1 implies H2 or that H2 implies H3. David suggests that ‘intuitively’ P = BPP would be established by proving H3, which indeed would imply P != NP. And indeed, H3 is quite plausible, and follows from the existence of one-way functions.")

#text("However, the reason most complexity theorists now strongly believe P=BPP, is due to papers (roughly speaking, starting with Nisan-Wigderson and culminating in Impagliazzo-Wigderson) that give plausible computational-hardness assumptions which would imply H2 and therefore P=BPP. But neither H2 nor the hardness assumptions used in these papers seem to imply P != NP.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-40799")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2009")])]

#text("on second line should be “whether A problem” ")#emph[#text("[Corrected, thanks – T].")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-40803")[#strong[#text("Random bits « Equilibrium Networks")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2009")]

#text("[…] Terry Tao on why “there cannot be any relativisable proof of either or “ […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d132c66d23606535c4b4e8d713c86209508b72752f28a35baf38443bd0725f4-51166bded42be6a43b36baf9dde4f8351b2c435986218fcc64bbed81dbb70253.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hezhigang")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-40804")[#strong[#text("hezhigang")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2009")])]

#text("description of Millennium Problems of CMI")#linebreak()#text(" ")#link("http://www.claymath.org/millennium/P_vs_NP/")[#text("http://www.claymath.org/millennium/P_vs_NP/")]

#link("http://claymath.msri.org/pversusnp.mov")[#text("http://claymath.msri.org/pversusnp.mov")]#linebreak()#text(" the lecturer is a woman, her explaination is pleasure to watch.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-40814")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2009")])]

#text("The metaphor of a student taking a test is extremely useful for understanding many complexity classes and their interactions with oracles. In my opinion, though, you don’t need to be as fancy as to allow computer assistance; you could instead have the oracle be a thick textbook. This is clearer as a metaphor because the textbook is clearly static, and its contents are well-controlled. Oracles are required to be static. By contrast, the rule of an interactive proof system is that the Merlin (or the ringer in your scenario) does not have to answer predictably.")

#text("Another example is the oracle that separates BPP from P. In this construction, most pages of the textbook simply state the correct answer. Thus, a student capable of making random choices can probably provide a correct answer simply by opening the book to a random page. However, the textbook is constructed to penalize uncreative students. The nth exam and the nth textbook are designed so that all of the pages visited by the nth deterministic student are blank. That student won’t learn the correct answer from the book. In other words, the textbook is a kind of conspiracy.")

#text("An oracle can also be used to address David Eppstein’s question. In this case you just let the allowed book be filled with random numbers, like just the phone numbers from a phone book. On the one hand, it can be shown that such a book works as an effective pseudo-random number generator and renders BPP equal to P. On the other hand, a book with random contents also works for Terry’s construction and separates NP from P. At least the simplest derandomization arguments relativize, so this construction shows you that the assumptions must be stronger than just that P does not equal NP.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-40826")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2009")])]

#text("Sorry, the random oracle does not address David Eppstein’s question, because relative to that oracle P = BPP as expected and P ≠ NP, also as expected. However, the conspiracy oracle does address the question. Some (or all?) derandomization arguments relativize, yet there is an oracle relative to which P ≠ BPP.")

#text("That may sound paradoxical, but it’s not, because a derandomization argument can use an extra resource, or it can depend on an assumption that does not hold relative to some oracle. For instance, the first such argument was that BPP is contained in P/poly, where “/poly” is trustworthy advice that depends on the length but not the content of the input. Instead of an untrustworthy ringer who wants you to say “yes” to yes/no questions, the advice might be written on the board by an honest exam proctor. But the advice can only depend on the time allotted for the exam (say) and not on the contents of the exam. (Otherwise the result would be the universal complexity class ALL, because the proctor could write the answers on the board.) The idea of the proof of this inclusion is that the deterministic student should ask the proctor to write a random string on the board. Even though the string is fixed, if it was randomly chosen beforehand, it can serve as a source of pseudo-random numbers.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-40815")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2009")]

#text("[…] P=NP, relativisation, and multiple choice exams The most fundamental unsolved problem in complexity theory is undoubtedly the P=NP problem, which asks (roughly […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-41002")[#strong[#text("Tao on relativisation | An Academic Log of Zirui")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2009")]

#text("[…] Read: ")#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/")[#text("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The “no self-defeating object” argument « What’s new")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-42243")[#strong[#text("The “no self-defeating object” argument « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("[…] basically because such arguments tend to be relativisable whereas the problem is not; see this earlier blog post for more discussion. On the other hand, one has the curious feature that many proposed proofs that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7cf53a7e16b7387dbc34cd59a135484cbef965e23355e2b61ee77ed33f429a38-2b23bf1d80f0031a3b996b9fac753b056d5603b1ffe21c83d18e52e89c9c9498.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-46429")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2010")])]

#text("Prof Tao — did you see this?")

#link("http://www.hpl.hp.com/personal/Vinay_Deolalikar/Papers/pnp_preliminary.pdf")[#text("Click to access pnp_preliminary.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-46431")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2010")])]

#text("This paper is already being discussed at the blogs ")#link("http://rjlipton.wordpress.com/2010/08/08/a-proof-that-p-is-not-equal-to-np/")[#text("of Lipton")]#text(" and ")#link("http://scottaaronson.com/blog/?p=456")[#text("of Aaronson")]#text(", both of whom are more expert in this area than I am. Readers who are interested in this paper should probably follow the discussions there.")

#text("My initial impressions are that the paper does not raise any of the usual and obvious “")#link("http://www.scottaaronson.com/blog/?p=304")[#text("red flags")]#text("” that accompany the majority of proposed solutions to famous problems, but also does not yet align comfortably with the established progress on this problem (in particular, the focus on the properties of random k-SAT seems to be incongruous with what we have learned from the work of Razbarov and Rudich, even if it may technically be compatible), or on related problems in complexity theory.")

#text("It may take some time for an understanding of how this paper fits with the existing body of work on the problem to emerge, and this in turn means that it will also take time for experts to perform a careful verification of this rather lengthy manuscript. (The latter is of course needed to ensure that the argument is ")#emph[#text("correct")]#text(", but the former is more important for ensuring that the argument is ")#emph[#text("convincing")]#text(", and also for salvaging useful mathematics out of it in case there turns out to be a gap. ) So some patience may be required before we can get a clearer evaluation of the paper; even in this internet age, mathematical research usually does not follow the 24-hour news cycle.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-46442")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2010")])]

#text("Regarding compatibility with Razbarov and Rudich: ")#link("http://arxiv.org/abs/0805.1385")[#text("http://arxiv.org/abs/0805.1385")]#text(" says a modification to the technique which R-R excluded, might still work. This make Vinay’s work more possible to be technically compatible with RR work. Although Vinay’s proof is non constructive, it might just work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-46445")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2010")])]

#text("Actually, I may need to revise my last comment; there is now the beginnings of an online effort to collectively understand the argument at")

#link("http://rjlipton.wordpress.com/2010/08/09/issues-in-the-proof-that-p≠np")[#text("http://rjlipton.wordpress.com/2010/08/09/issues-in-the-proof-that-p≠np")]

#text("and")

#link("http://geomblog.blogspot.com/2010/08/on-deolalikar-proof-crowdsourcing.html")[#text("http://geomblog.blogspot.com/2010/08/on-deolalikar-proof-crowdsourcing.html")]

#text("So the time scales here may in fact be shorter than in previous events of this type.")

#text("Still, even if these efforts find problems with the specific manuscript, the question of what can be salvaged from this paper (which does seem to contain a number of innovative new ideas) will still probably take a while to resolve.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-46447")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2010")])]

#text("Just curious. If statistical physics was powerful enough to attack P != NP, why was it not used to give alternate proofs of simpler complexity results?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-46449")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2010")])]

#text("Perhaps this event is moving at internet speeds after all. There is now a ")#link("http://michaelnielsen.org/polymath1/index.php?title=Deolalikar%27s_P%21%3DNP_paper")[#text("clearinghouse wiki page")]#text(" for analysis of the Deolalikar paper hosted on the Polymath wiki; this is derived from an earlier online document of Suresh Venkatasubramanian. It is now open for corrections and contributions. At this stage, though, it is not officially a polymath project.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1ff67fe6d12fbf22cfce865d73f8624072beec7614558b3eb69ba57c7eb96d0-48271cd75ace021963a7ed38c137bc3d13fd9534b4495e526465ee3fe971695c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-46456")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2010")])]

#text("I hope to decide there is a bug in his proof or not is not np-hard:)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1ff67fe6d12fbf22cfce865d73f8624072beec7614558b3eb69ba57c7eb96d0-48271cd75ace021963a7ed38c137bc3d13fd9534b4495e526465ee3fe971695c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-46549")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2010")])]

#text("Great collaborative work Prof Tao. I really enjoyed many of your insightful comments including the car having 200mpg analogy.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3ad04e1ced21016b87f666e7ec164e56c2708dad17af723dc25b10a436a26d4-f0dc59139b53639bb39975118265aa1fa073a175964f544a2ff9618f3b8c1f65.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tushar das")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-46450")[#strong[#text("tushar das")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2010")])]

#text("The following is from")

#link("http://www.hpl.hp.com/personal/Vinay_Deolalikar/")[#text("http://www.hpl.hp.com/personal/Vinay_Deolalikar/")]

#text("“Vinay Deolalikar. P is not equal to NP. 6th August, 2010 (66 pages 10pt, 102 pages 12pt). Manuscript sent on 6th August to several leading researchers in various areas. Confirmations began arriving 8th August early morning. The preliminary version made it to the web without my knowledge. I have made minor updates, here. Please note that the final version of the paper is under preparation, and is to be posted here very shortly. Stay tuned. “")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-46451")[#strong[#text("Vinay Deolalikar says P ≠ NP « viXra log")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2010")]

#text("[…] about ordered and unordered structures. For more details follow the discussions here, here, here, here and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-46462")[#strong[#text("My pennyworth about Deolalikar « Gowers's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2010")]

#text("[…] 6. I am not sure about this one, but I have a feeling that experts would tell me that any attempt along these lines would relativize: that is, it would also prove the false result that PNP relative to any oracle. I don’t want to say more than that because my understanding of this barrier is such that I am likely to get things wrong. Instead, let me refer you to this post of Terry Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1ff67fe6d12fbf22cfce865d73f8624072beec7614558b3eb69ba57c7eb96d0-48271cd75ace021963a7ed38c137bc3d13fd9534b4495e526465ee3fe971695c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-46478")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2010")])]

#text("I saw this comment on the wiki “…..the discrete probabilistic distributions in the paper can be viewed as tensors, or very special multilinear polynomials. The assumptions “P=NP” somehow gives a (polynomial?) upper bound on the tensor rank. And finally, using known probabilistic results, he gets nonmatching (exponential?) lower bound on the same rank. If I am right, then this approach is a very clever, in a good sense elementary, way to push the previous algebraic-geometric approaches”… is there an easier way to understand this statement with an example?")#linebreak()#text(" Thank you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7646e6b1d35adbfaa921d634120fcb1eb33282ee29912c6fd34e7ffe580d4376-23f75807c0d2711a674be352bdac5bff038841e313540a7ac4659036feb4f45c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Muhammad Alkarouri")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-46502")[#strong[#text("Muhammad Alkarouri")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2010")])]

#text("On an administrational note, this post does not appear in the blog’s front page nor in the RSS feed. Is this deliberate?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d60f3d5e13c034e9900289b8b371f72d362b65fce2c1959d39a814b2ec9b872-ac601a5d0c6f5887d2a28d3af251bd26dbe6a4a2c59c03944ed5e579afe41141.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Drubetskoy")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-46537")[#strong[#text("Peter Drubetskoy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2010")])]

#text("You seemed to not have used diagonalization in coming up with the oracle B (as is usual in the proof of Baker-Gill-Solovay) but rather randomness (“un-guessability”?) of B’s URLs and the coin flips. Are these somehow equivalent? Or is diagonalization not essential for the proof?")#linebreak()#text(" I still cannot seem to get my head around the idea that showing that two objects (viz. complexity classes) are not equal under some “transformation” is ")#strong[#text("not")]#text(" good for showing them unequal. Here the “transformation” is the oracle and it is clearly “not good” since even classes that are one and the same (IP=PSPACE) can be different in the presence of an oracle. Is there an intuitive way you can think of to explain this phenomenon?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-46544")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2010")])]

#text("In keeping with the analogy of the main post: it is entirely possible to have two students who are equally competent at exams when not given any external assistance, to have differing levels of competence when given a form of assistance (e.g. a cheat sheet).")

#text("Diagonalisation and randomisation are both ways to achieve the same purpose, namely to avoid an unwanted collision (or, in the language of the above analogy, to avoid the student ever “getting lucky” and finding the correct URL by accident). The underlying intuition (that finding a (randomly or diagonally selected) needle in an exponentially large haystack should be a very computationally difficult task) is probably more important here than the specific tool used to formalise that intuition.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d60f3d5e13c034e9900289b8b371f72d362b65fce2c1959d39a814b2ec9b872-ac601a5d0c6f5887d2a28d3af251bd26dbe6a4a2c59c03944ed5e579afe41141.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Drubetskoy")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-46546")[#strong[#text("Peter Drubetskoy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2010")])]

#text("Thanks! I guess you just highlighted the fact that for complexity classes to be “equal” means “accepting the same languages”, not really about being “one and the same”. I wonder if all such relativazing results work in one direction – i.e., there exists A such that NP^A “is stronger” than P^A, so, in some respect even if P=NP, NP is still somehow “richer”. Or do there exist complexity classes X and Y such that, for some oracle A, X^A \\subset Y^A and, for some oracle B, Y^B \\subset X^B – that is, X and Y both have “potential strengths” relative to each other.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dee2646de0eeac7020d185d0c64df19172f5395f9c45110795446b11108464bb-49cef1a583d90c2afde082456d00d5562f14b672bfa9e7f9127716b253855308.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frank")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-197341")[#strong[#text("Frank")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2012")])]

#text("Dear Tao")

#text("Could I have your opinion about this point of view?")

#link("http://the-point-of-view-of-frank.blogspot.com/2012/08/p-versus-up.html")[#text("http://the-point-of-view-of-frank.blogspot.com/2012/08/p-versus-up.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7d43b5f54be651569788dd11bd52ed916929b14aabb6e9991f71553eed688138-6c7d9277034a49aa2d33d265be1108031eb79da0fa42dd878751db8e8bb9f7b2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jasper")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-211631")[#strong[#text("Jasper")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2012")])]

#text("Dear Dr. Tao,")

#text("I think I have an equation solution for the problem, would you like to read it?")

#text("Sincerely yours,")#linebreak()#text(" Jasper")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81c7ee47219767de6af71eb6b5313e9894d7c3914be6d57431ae7e1b00c157a1-a1e079dc8e5844fbe1b13fa79adf07f02d1892bfbe1b6c1e95a39cc933de0cdd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vznvzn")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-454825")[#strong[#text("vznvzn")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2015")])]

#text("hey for one would wish youd write more on P vs NP & complexity theory… :|")

#text(":arrow: :star: :idea: :!: fyi a quick summary/ overview of some striking new results maybe eventually touching the area & its all just begging for some hardcore mathematicians to jump into the ")#emph[#text("fray")]#text(": ")#link("https://vzn1.wordpress.com/2015/05/01/algebraic-circuit-complexity-valiants-vpvnp-recent-advances-breakthroughs/")[#text("arithmetic circuit complexity, Valiants VP=?VNP, recent advances/ breakthroughs, new directions")]#text(" :D :cool:")

#text("elsewhere more on P vs NP as a ")#link("https://vzn1.wordpress.com/2012/10/18/math-monster/")[#text("“math monster/ everest/ olympus mons”")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-461313")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2015")])]

#text("The P = NP problem is demonstrated.")

#text("P = NP, in the factorization of all odd number.")

#text("See: ")#link("http://www.ijma.info")[#text("http://www.ijma.info")]#text(" Vol 6 (9) 2015")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-468010")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2016")])]

#text("Just my intuition. I believe that the Riemann hypothesis is connected with concentration of measure – ttps://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/.In particular, this expression: ")#mi("\\mid \\pi (x) - Li(x)\\mid < \\frac{x}{log(x)}")#text(".Here's another hint that this hypothesis may be associated with random variables -https://en.wikipedia.org/wiki/Riemann_hypothesis#Number_of_zeros, Ghosh proof(\"…resembles a Gaussian random variable with mean 0 and variance…\").If this hypothesis is in fact associated with random variables, we can make that kind of that particular formulation of the problem (relying on RH) is ")#mi("\\mathbf{NP-complete}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/#comment-530603")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2019")])]

#text("Hm, let us prepare for the (unlikely) case if P=NP. Then any proof of a reasonable length can be found by a computer quickly.")

#text("The next step would be to define such things as generalization and beautify (how much a theorem is related with other theorems) formally, for the sake of computers being able to do this, if it is solvable in P time ;-)")
]
