// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/12/11/course-announcement-246b-complex-analysis/
// Converted to Typst by tao2typ: "2026-10-14T16:38:53.191534+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Course announcement: 246B, complex analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Course announcement: 246B, complex analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 December 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/12/11/course-announcement-246b-complex-analysis/")[#text("https://terrytao.wordpress.com/2020/12/11/course-announcement-246b-complex-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a short announcement that next quarter I will be continuing the recently concluded ")#link("https://ccle.ucla.edu/course/view/20F-MATH246A-1")[#text("246A complex analysis class")]#text(" as ")#link("https://ccle.ucla.edu/course/view/21W-MATH246B-1")[#text("246B")]#text(". Topics I plan to cover:")

#list(
[#text("Schwartz-Christoffel transformations and the uniformisation theorem (using the")#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/")[#text(" remainder of the 246A notes")]#text(");")],
[#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/")[#text("Jensen’s formula and factorisation theorems (particularly Weierstrass and Hadamard); the Gamma function")]#text(";")],
[#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/")[#text("Connections with the Fourier transform on the real line")]#text(";")],
[#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/")[#text("Elliptic functions and their relatives")]#text(";")],
[#text("(if time permits) ")#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/")[#text("the Riemann zeta function and the prime number theorem")]#text(".")]
)

#text("Notes for the later material will appear on this blog in due course.")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11a24b38007dc03aa218f3eb92b8e79681e6f810e378f3bfa2729b078f8609ac-505d6030ec57e5ef3a5aa385754c06d78ee8b223b1e093b26795af5b0a91bc31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of raian anantharaman")]], [#link("https://terrytao.wordpress.com/2020/12/11/course-announcement-246b-complex-analysis/#comment-609501")[#strong[#text("raian anantharaman")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2020")])]

#text("Thanks for this complex 2nd")#linebreak()#text(" It seems that the Paley..Weiner .theorem in the complex plane Cis included. also")#linebreak()#text(" may be Stein s generalizarion?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/654860f7ab3bccdacdd1edf4ed9ca7a452824bc33757d21bd183dd0012aafae1-bef87085757bcf462a3a59c721d677df37b119c3fd1e9113e67b868e9183be0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edgawliet")]], [#link("https://terrytao.wordpress.com/2020/12/11/course-announcement-246b-complex-analysis/#comment-610266")[#strong[#text("Edgawliet")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2020")])]

#text("Very good. Thank you Professor Tao. I hope I could enrol in your online courses in the future when I have enough knowledge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Date of start")]], [#link("https://terrytao.wordpress.com/2020/12/11/course-announcement-246b-complex-analysis/#comment-610676")[#strong[#text("Date of start")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2020")])]

#text("Prof. Tao can you please tell us the date when the course 246B will begin ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee2818a8fbb15188eb4e40d2f9c9c2311c00e296eb667c105919a3d4cab305a8-c67e62210f60b7b75525de9568c9eb46dcc4049a9dc4e0a836b8cf27fa827802.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LC")]], [#link("https://terrytao.wordpress.com/2020/12/11/course-announcement-246b-complex-analysis/#comment-613096")[#strong[#text("LC")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2020")])]

#text("I understand the first lecture is Monday January 4th")

#link("https://ccle.ucla.edu/mod/page/view.php?id=3434115")[#text("https://ccle.ucla.edu/mod/page/view.php?id=3434115")]

#text("at 10-10:50am PT, but it would be cool to have a confirmation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20f8ed5b29eb1eaa13c08b93b7522aa9c483f0b141bdb82cdc99c310173ad94e-bccd47b8f5bc23ad1f32c283f577463b4b2079084b1503cd70afa41050c7c0e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/11/course-announcement-246b-complex-analysis/#comment-610703")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2020")])]

#text("You can find all your answer from this link ")#link("https://ccle.ucla.edu/course/view/21W-MATH246B-1")[#text("https://ccle.ucla.edu/course/view/21W-MATH246B-1")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c354172d0692d35b6eebd4a914c6111f91cca0adc5af80f45a5f787514d3da2-feb52201bc36c83a9a2e58ee85de1e4645bf57b022c0b135b33839bb9c542a49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of paul miller")]], [#link("https://terrytao.wordpress.com/2020/12/11/course-announcement-246b-complex-analysis/#comment-611661")[#strong[#text("paul miller")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2020")])]

#text("Thank you. Will you be making the lectures publicly available? I was inspired by your 246A lectures and would love to be able to hear 246B if possible. regards, Paul Miller")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/11/course-announcement-246b-complex-analysis/#comment-617301")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2021")])]

#text("Dear Prof. Tao:")

#text("Could you teach 246C in the spring? It will be nice to complete the sequence. When things go back to normal next year, non-UCLA students won’t be able to attend your classes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/11/course-announcement-246b-complex-analysis/#comment-622383")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2021")])]

#text("Is there no class on Feb 15 due to Presidents’ Day holiday?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d380eed1b8ce19b306ee631f0f7fe4ba8d1640f6aa7c87ba99c149981c1db51-0db9cb72e4fcae65beb249711891235ac47b6fffa63daa1b48a69b7c6c0c9b05.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of h0sane")]], [#link("https://terrytao.wordpress.com/2020/12/11/course-announcement-246b-complex-analysis/#comment-623971")[#strong[#text("h0sane")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2021")])]

#text("Will the notes for this be available online after?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/11/course-announcement-246b-complex-analysis/#comment-623999")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2021")])]

#text("It is already posted.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d380eed1b8ce19b306ee631f0f7fe4ba8d1640f6aa7c87ba99c149981c1db51-0db9cb72e4fcae65beb249711891235ac47b6fffa63daa1b48a69b7c6c0c9b05.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of h0sane")]], [#link("https://terrytao.wordpress.com/2020/12/11/course-announcement-246b-complex-analysis/#comment-624000")[#strong[#text("h0sane")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2021")])]

#text("thank you so much!")
]
]
]
