// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/20/postdoc-positions-at-the-columbia-data-science-institute/
// Converted to Typst by tao2typ: "2026-11-21T14:49:56.448819+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Postdoc positions at the Columbia Data Science Institute", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Postdoc positions at the Columbia Data Science Institute")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/20/postdoc-positions-at-the-columbia-data-science-institute/")[#text("https://terrytao.wordpress.com/2026/11/20/postdoc-positions-at-the-columbia-data-science-institute/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-21 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://www.math.columbia.edu/~corwin/")[#text("Ivan Corwin")]#text(" – T.]")]

#text("Dear colleagues,")

#text("I am writing to encourage applications to the ")#link("https://datascience.columbia.edu/research/postdoctoral-fellows-program")[#text("Columbia Data Science Institute’s postdoc program")]#text(", for those interested in being involved in Columbia’s AI and Mathematical Foundations research activities. See the (Fun)damental AI & Math description ")#link("https://datascience.columbia.edu/research/frontiers-data-science-and-ai/thinkingmachines")[#text("here")]#text(" for some activity in spring 2026 and ")#link("https://svenhirsch.com/ai/")[#text("here")]#text(" for activities in fall 2026.")

#strong[#text("To apply, please click ")#link("https://apply.interfolio.com/180076")[#text("here")]#text(" and follow the instructions. The deadline is December 1 for applications")]#text(", though letters can arrive for up to two weeks afterwards.")

#text("DSI postdocs are two-year positions with no teaching. To ensure lots of activity, we have cohorts of 3 postdocs in each focus area for the year. The application asks that you identify a DSI research center (you should select the Foundations center) and some faculty you may want to interact with. There are many faculty at Columbia to choose from who work at this interface of AI and mathematical foundations, including in Mathematics (Ivan Corwin, Andrew Blumberg, Johan de Jong), Computer Science theory group (Daniel Hsu, Christos Papadimitriou, Rocco Servedio, Alex Andoni, Henry Yuen, Josh Alman, Micah Goldblum, Adam Block), Statistics (Cynthia Rush, Arian Maleki, Samory Kpotufe, Bodhi Sen, Marcel Nutz), Decision Risk and Optimization in the Business School (Hongseok Namkoong, Carrie Chan, Paul Glasserman, Yash Kanoria), Industrial Engineering and Operations Research (Rachel Cummings, Garud Iyengar, Anran Hu, Daniel Lacker, Wenpin Tang, Jay Sethuraman), Applied Physics and Applied Mathematics (Qiang Du, Michael Weinstein, Kui Ren, Liliana Borcea), and many others.")

#text("Should you have any questions, please feel free to reach out to me (Ivan Corwin ")#link("mailto:ic2354@columbia.edu")[#text("ic2354@columbia.edu")]#text(").")

#text("Best,")

#text("Ivan Corwin, Professor of Mathematics and Statistics @ Columbia University")
