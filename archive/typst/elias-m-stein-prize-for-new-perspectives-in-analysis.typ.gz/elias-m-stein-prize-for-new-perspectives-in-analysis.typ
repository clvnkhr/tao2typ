// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/04/04/elias-m-stein-prize-for-new-perspectives-in-analysis/
// Converted to Typst by tao2typ: "2026-10-14T16:39:06.485542+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Elias M. Stein Prize for New Perspectives in Analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Elias M. Stein Prize for New Perspectives in Analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 April 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/04/04/elias-m-stein-prize-for-new-perspectives-in-analysis/")[#text("https://terrytao.wordpress.com/2023/04/04/elias-m-stein-prize-for-new-perspectives-in-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The ")#link("https://community.ams.org/prizes-awards/paview.cgi?parent_id=54")[#text("Elias M. Stein Prize for New Perspectives in Analysis")]#text(" is awarded for the development of groundbreaking methods in analysis which demonstrate promise to revitalize established areas or create new opportunities for mathematical discovery. The current prize amount is US$5,000 and the prize is awarded every three years for work published in the preceding six years.")

#text("This prize was endowed in 2022 by students, colleagues, and friends of ")#link("https://en.wikipedia.org/wiki/Elias_M._Stein")[#text("Elias M. Stein")]#text(" (my former advisor) to honor his remarkable legacy in the area of mathematical analysis. Stein, who ")#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/")[#text("passed away in 2018")]#text(", is remembered for identifying many deep principles and methods which transcend their original context, and for opening entirely new areas of research which captivated the attention and imagination of generations of analysts. This prize seeks to recognize mathematicians at any career stage who, like Stein, have found exciting new avenues for mathematical exploration in subjects old or new or made deep insights which demonstrate promise to reshape thinking across areas.")

#text("This will be the inaugural year for the prize, and I have agreed to serve on the prize committee. We welcome ")#link("https://www.mathprograms.org/db/programs/1444")[#text("nominations")]#text(" for the prize, which will be accepted until June 30, 2023, and are seeking a strong and diverse pool of nominees. Nominations (submitted at ")#link("https://www.mathprograms.org/db/programs/1444")[#text("this link")]#text(") should include a letter of nomination and a brief citation to be used in the event that the nomination is successful. Alternatively, if you are aware of a strong potential candidate but are not able to provide the nomination yourself, we welcome your suggestion (by private email) along with — if possible — your suggestions of possible nominators.")

#text("For questions about this award, please contact the AMS Secretary at ")#link("mailto:secretary@ams.org")[#text("secretary@ams.org")]#text(".")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2023/04/04/elias-m-stein-prize-for-new-perspectives-in-analysis/#comment-677314")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2023")])]

#text("Are the “students, colleagues, and friends of Elias M. Stein” who endowed the prize eligible to receive it? If not, it may be helpful to list these people, to forestall a flood of nominations on their behalf.")

#text("Also, the prize description “This prize seeks to recognize mathematicians at any career stage who, like Stein, have found exciting new avenues for mathematical exploration in subjects old or new or made deep insights which demonstrate promise to reshape thinking across areas.” does not seem to mention any particular focus on analysis. Is this intentional?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/04/04/elias-m-stein-prize-for-new-perspectives-in-analysis/#comment-677318")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2023")])]

#text("As stated in the first paragraph, the prize is awarded for groundbreaking methods in analysis.")

#text("Naturally, as per standard practices, any member of the committee will be ineligible for the prize, and any member having a close association with a nominee (e.g., former student/advisor or close collaborator) would have to declare a conflict of interest, perhaps leading to a recusal from discussion of that nominee. But there is no restriction on donors to the prize fund being considered (indeed, our committee does not have access to the list of donors), nor is any past connection to Stein a disqualification for nomination (but it is not a requirement either).")

#text("All things being equal, we would rather prefer to have a flood of nominations (which we would then narrow down to a shortlist) than to have so few nominations that some viable candidates are not nominated at all.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/04/04/elias-m-stein-prize-for-new-perspectives-in-analysis/#comment-677363")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2023")])]

#text("Dr. Tao: Does the conflict of interest extends to academic grandchildren/grandparents? e.g. former student’s student.")

#emph[#text("[This could theoretically be a conflict of interest if the awarding of a prize to a grand-student could convey a significant benefit to the grand-advisor, but this would probably have to be ruled upon by the rest of the committee. The official guidance for conflict of interest for AMS committees can be found at ")#link("http://www.ams.org/about-us/governance/policy-statements/sec-conflict-of-interest-officers")[#text("http://www.ams.org/about-us/governance/policy-statements/sec-conflict-of-interest-officers")]#text(" -T]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/04/04/elias-m-stein-prize-for-new-perspectives-in-analysis/#comment-677362")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2023")])]

#text("There seems to be a typo in Them 1.3 of Book III of the “Princeton Lectures in Analysis” series. It says every open set in ")#mi("R")#text(" can be written uniquely as a countable union of disjoint open intervals. Don’t think it is “unique”. Please confirm this error.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/04/04/elias-m-stein-prize-for-new-perspectives-in-analysis/#comment-677534")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2023")])]

#text("The decomposition is unique. Basically, if V and W are disjoint open intervals, and U an open interval, then U is a subset of V union W implies either U is subset of V or a subset of W, but not both. (Connectedness).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4c9b301cd1a9e8f3f50a2da225c95aeb109bbfe2e1525e967925fdffc4717b7-fb316f7fc5c88f5da7b88287e0c50ce2d26b006f9516b10b5ffca5df8dfa4f69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/04/04/elias-m-stein-prize-for-new-perspectives-in-analysis/#comment-677777")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2023")])]

#text("Good.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9f50b92342b3380d7e757b183416c7fb311bddb1a160293c8251bf1c68d6bae-a7478d0ab164772a8824b5e38d40b058a16d3288dc4d15fe965b2cf4bef8c686.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eva Tutor")]], [#link("https://terrytao.wordpress.com/2023/04/04/elias-m-stein-prize-for-new-perspectives-in-analysis/#comment-677910")[#strong[#text("Eva Tutor")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2023")])]

#text("I just came across the blog post announcing the Elias M. Stein Prize for New Perspectives in Analysis, and it’s truly inspiring! Recognizing groundbreaking contributions in the field of analysis, this prestigious award celebrates the brilliance and innovation of mathematicians. It’s wonderful to see such recognition for pushing the boundaries of mathematical knowledge. Congratulations to all the recipients and a big thank you to Terry Tao for shedding light on their remarkable achievements!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arman")]], [#link("https://terrytao.wordpress.com/2023/04/04/elias-m-stein-prize-for-new-perspectives-in-analysis/#comment-677930")[#strong[#text("Arman")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2023")])]

#text("PROF please new posts🧠✍️👍")
]
