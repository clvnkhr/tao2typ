// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/03/01/254b-notes-7-sieving-and-expanders/
// Converted to Typst by tao2typ: "2026-10-14T15:18:23.243990+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254B, Notes 7: Sieving and expanders", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254B, Notes 7: Sieving and expanders")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 March 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/03/01/254b-notes-7-sieving-and-expanders/")[#text("https://terrytao.wordpress.com/2012/03/01/254b-notes-7-sieving-and-expanders/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In this final set of course notes, we discuss how (a generalisation of) the expansion results obtained in the preceding notes can be used for some number-theoretic applications, and in particular to locate almost primes inside orbits of thin groups, following ")#link("http://www.ams.org/mathscinet-getitem?mr=2587341")[#text("the work of Bourgain, Gamburd, and Sarnak")]#text(". We will not attempt here to obtain the sharpest or most general results in this direction, but instead focus on the simplest instances of these results which are still illustrative of the ideas involved.")

#text("One of the basic general problems in analytic number theory is to locate tuples of primes of a certain form; for instance, the famous (and still unsolved) ")#link("http://en.wikipedia.org/wiki/Twin_prime")[#text("twin prime conjecture")]#text(" asserts that there are infinitely many pairs ")#mi("{(n_1,n_2)}")#text(" in the line ")#mi("{\\{ (n_1,n_2) \\in {\\bf Z}^2: n_2-n_1=2\\}}")#text(" in which both entries are prime. In a similar spirit, one of the ")#link("http://en.wikipedia.org/wiki/Landau%27s_problems")[#text("Landau conjectures")]#text(" (also still unsolved) asserts that there are infinitely many primes in the set ")#mi("{\\{ n^2+1: n \\in {\\bf Z} \\}}")#text(". The Mersenne prime conjecture (also unsolved) asserts that there are infinitely many primes in the set ")#mi("{\\{ 2^n - 1: n \\in {\\bf Z} \\}}")#text(", and so forth.")

#text("More generally, given some explicit subset ")#mi("{V}")#text(" in ")#mi("{{\\bf R}^d}")#text(" (or ")#mi("{{\\bf C}^d}")#text(", if one wishes), such as an algebraic variety, one can ask the question of whether there are infinitely many integer lattice points ")#mi("{(n_1,\\ldots,n_d)}")#text(" in ")#mi("{V \\cap {\\bf Z}^d}")#text(" in which all the coefficients ")#mi("{n_1,\\ldots,n_d}")#text(" are simultaneously prime; let us refer to such points as ")#emph[#text("prime points")]#text(".")

#text("At this level of generality, this problem is impossibly difficult. Indeed, even the much simpler problem of deciding whether the set ")#mi("{V \\cap {\\bf Z}^d}")#text(" is non-empty (let alone containing prime points) when ")#mi("{V}")#text(" is a hypersurface ")#mi("{\\{ x \\in {\\bf R}^d: P(x) = 0 \\}}")#text(" cut out by a polynomial ")#mi("{P}")#text(" is essentially ")#link("http://en.wikipedia.org/wiki/Hilbert's_tenth_problem")[#text("Hilbert’s tenth problem")]#text(", which is known to be undecidable in general by ")#link("http://en.wikipedia.org/wiki/Matiyasevich%27s_theorem#Matiyasevich.27s_theorem")[#text("Matiyasevich’s theorem")]#text(". So one needs to restrict attention to a more special class of sets ")#mi("{V}")#text(", in which the question of finding integer points is not so difficult. One model case is to consider ")#emph[#text("orbits")]#text(" ")#mi("{V = \\Gamma b}")#text(", where ")#mi("{b \\in {\\bf Z}^d}")#text(" is a fixed lattice vector and ")#mi("{\\Gamma}")#text(" is some discrete group that acts on ")#mi("{{\\bf Z}^d}")#text(" somehow (e.g. ")#mi("{\\Gamma}")#text(" might be embedded as a subgroup of the special linear group ")#mi("{SL_d({\\bf Z})}")#text(", or on the affine group ")#mi("{SL_d({\\bf Z}) \\ltimes {\\bf Z}^d}")#text("). In such a situation it is then quite easy to show that ")#mi("{V = V \\cap {\\bf Z}^d}")#text(" is large; for instance, ")#mi("{V}")#text(" will be infinite precisely when the stabiliser of ")#mi("{b}")#text(" in ")#mi("{\\Gamma}")#text(" has infinite index in ")#mi("{\\Gamma}")#text(".")

#text("Even in this simpler setting, the question of determining whether an orbit ")#mi("{V = \\Gamma b}")#text(" contains infinitely prime points is still extremely difficult; indeed the three examples given above of the twin prime conjecture, Landau conjecture, and Mersenne prime conjecture are essentially of this form (possibly after some slight modification of the underlying ring ")#mi("{{\\bf Z}}")#text(", see ")#link("http://www.ams.org/mathscinet-getitem?mr=2587341")[#text("this paper of Bourgain-Gamburd-Sarnak")]#text(" for details), and are all unsolved (and generally considered well out of reach of current technology). Indeed, the list of non-trivial orbits ")#mi("{V = \\Gamma b}")#text(" which are known to contain infinitely many prime points is quite slim; ")#link("http://en.wikipedia.org/wiki/Euclid%27s_theorem")[#text("Euclid’s theorem")]#text(" on the infinitude of primes handles the case ")#mi("{V = {\\bf Z}}")#text(", ")#link("http://en.wikipedia.org/wiki/Dirichlet%27s_theorem_on_arithmetic_progressions")[#text("Dirichlet’s theorem")]#text(" handles infinite arithmetic progressions ")#mi("{V = a{\\bf Z} + r}")#text(", and a somewhat complicated ")#link("http://www.ams.org/mathscinet-getitem?mr=2680398")[#text("result of")]#text(" ")#link("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/")[#text("Green, Tao")]#text(", ")#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("and Ziegler")]#text(" handles “non-degenerate” affine lattices in ")#mi("{{\\bf Z}^d}")#text(" of rank two or more (such as the lattice of length ")#mi("{d}")#text(" arithmetic progressions), but there are few other positive results known that are not based on the above cases (though we will note the remarkable theorem of ")#link("http://www.ams.org/mathscinet-getitem?mr=1670065")[#text("Friedlander and Iwaniec")]#text(" that there are infinitely many primes of the form ")#mi("{a^2+b^4}")#text(", and the ")#link("http://www.ams.org/mathscinet-getitem?mr=1828372")[#text("related result of Heath-Brown")]#text(" that there are infinitely many primes of the form ")#mi("{a^3+2b^3}")#text(", as being in a kindred spirit to the above results, though they are not explicitly associated to an orbit of a reasonable action as far as I know).")

#text("On the other hand, much more is known if one is willing to replace the primes by the larger set of ")#emph[#text("almost primes")]#text(" – integers with a small number of prime factors (counting multiplicity). Specifically, for any ")#mi("{r \\geq 1}")#text(", let us call an ")#emph[#mi("{r}")#text("-almost prime")]#text(" an integer which is the product of at most ")#mi("{r}")#text(" primes, and possibly by the unit ")#mi("{-1}")#text(" as well. Many of the above sorts of questions which are open for primes, are known for ")#mi("{r}")#text("-almost primes for ")#mi("{r}")#text(" sufficiently large. For instance, with regards to the twin prime conjecture, it is a ")#link("http://en.wikipedia.org/wiki/Chen's_theorem")[#text("result of Chen")]#text(" that there are infinitely many pairs ")#mi("{p,p+2}")#text(" where ")#mi("{p}")#text(" is a prime and ")#mi("{p+2}")#text(" is a ")#mi("{2}")#text("-almost prime; in a similar vein, it is a ")#link("http://www.ams.org/mathscinet-getitem?mr=485740")[#text("result of Iwaniec")]#text(" that there are infinitely many ")#mi("{2}")#text("-almost primes of the form ")#mi("{n^2+1}")#text(". On the other hand, it is still open for any fixed ")#mi("{r}")#text(" whether there are infinitely many Mersenne numbers ")#mi("{2^n-1}")#text(" which are ")#mi("{r}")#text("-almost primes. (For the superficially similar situation with the numbers ")#mi("{2^n+1}")#text(", it is in fact believed (but again unproven) that there are only finitely many ")#mi("{r}")#text("-almost primes for any fixed ")#mi("{r}")#text(" (the ")#link("http://en.wikipedia.org/wiki/Fermat_number")[#text("Fermat prime conjecture")]#text(").)")

#text("The main tool that allows one to count almost primes in orbits is ")#link("http://en.wikipedia.org/wiki/Sieve_theory")[#text("sieve theory")]#text(". The reason for this lies in the simple observation that in order to ensure that an integer ")#mi("{n}")#text(" of magnitude at most ")#mi("{x}")#text(" is an ")#mi("{r}")#text("-almost prime, it suffices to guarantee that ")#mi("{n}")#text(" is not divisible by any prime less than ")#mi("{x^{1/(r+1)}}")#text(". Thus, to create ")#mi("{r}")#text("-almost primes, one can start with the integers up to some large threshold ")#mi("{x}")#text(" and remove (or “sieve out”) all the integers that are multiples of any prime ")#mi("{p}")#text(" less than ")#mi("{x^{1/(r+1)}}")#text(". The difficulty is then to ensure that a sufficiently non-trivial quantity of integers remain after this process, for the purposes of finding points in the given set ")#mi("{V}")#text(".")

#text("The most basic sieve of this form is the ")#emph[#text("sieve of Eratosthenes")]#text(", which when combined with the inclusion-exclusion principle gives the ")#emph[#text("Legendre sieve")]#text(" (or ")#emph[#text("exact sieve")]#text("), which gives an exact formula for quantities such as the number ")#mi("{\\pi(x,z)}")#text(" of natural numbers less than or equal to ")#mi("{x}")#text(" that are not divisible by any prime less than or equal to a given threshold ")#mi("{z}")#text(". Unfortunately, when one tries to evaluate this formula, one encounters error terms which grow exponentially in ")#mi("{z}")#text(", rendering this sieve useful only for very small thresholds ")#mi("{z}")#text(" (of logarithmic size in ")#mi("{x}")#text("). To improve the sieve level up to a small power of ")#mi("{x}")#text(" such as ")#mi("{x^{1/(r+1)}}")#text(", one has to replace the exact sieve by ")#emph[#text("upper bound sieves")]#text(" and ")#emph[#text("lower bound sieves")]#text(" which only seek to obtain upper or lower bounds on quantities such as ")#mi("{\\pi(x,z)}")#text(", but contain a polynomial number of terms rather than an exponential number. There are a variety of such sieves, with the two most common such sieves being ")#emph[#text("combinatorial sieves")]#text(" (such as the ")#emph[#text("beta sieve")]#text("), based on various combinatorial truncations of the inclusion-exclusion formula, and the ")#emph[#text("Selberg upper bound sieve")]#text(", based on upper bounds that are the square of a divisor sum. (There is also the ")#emph[#text("large sieve")]#text(", which is somewhat different in nature and based on ")#mi("{L^2}")#text(" almost orthogonality considerations, rather than on any actual sieving, to obtain upper bounds.) We will primarily work with a specific sieve in this notes, namely the beta sieve, and we will not attempt to optimise all the parameters of this sieve (which ultimately means that the almost primality parameter ")#mi("{r}")#text(" in our results will be somewhat large). For a more detailed study of sieve theory, see the ")#link("http://www.ams.org/mathscinet-getitem?mr=424730")[#text("classic text of Halberstam and Richert")]#text(", or the more recent texts ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("of Iwaniec-Kowalski")]#text(" or ")#link("http://www.ams.org/mathscinet-getitem?mr=2647984")[#text("of Friedlander-Iwaniec")]#text(".")

#text("Very roughly speaking, the end result of sieve theory is that excepting some degenerate and “exponentially thin” settings (such as those associated with the Mersenne primes), all the orbits which are expected to have a large number of primes, can be proven to at least have a large number of ")#mi("{r}")#text("-almost primes for some finite ")#mi("{r}")#text(". (Unfortunately, there is a major obstruction, known as the ")#emph[#text("parity problem")]#text(", which prevents sieve theory from lowering ")#mi("{r}")#text(" all the way to ")#mi("{1}")#text("; see ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("this blog post")]#text(" for more discussion.) One formulation of this principle was established ")#link("http://www.ams.org/mathscinet-getitem?mr=2587341")[#text("by Bourgain, Gamburd, and Sarnak")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Bourgain-Gamburd-Sarnak)")]#text(" ")#metadata(none) <tao-20df97752cefa9847776>#text(" Let ")#mi("{\\Gamma}")#text(" be a subgroup of ")#mi("{SL_2({\\bf Z})}")#text(" which is not virtually solvable. Let ")#mi("{f: {\\bf Z}^4 \\rightarrow {\\bf Z}}")#text(" be a polynomial with integer coefficients obeying the following ")#emph[#text("primitivity")]#text(" condition: for any positive integer ")#mi("{q}")#text(", there exists ")#mi("{A \\in \\Gamma \\subset {\\bf Z}^4}")#text(" such that ")#mi("{f(A)}")#text(" is coprime to ")#mi("{q}")#text(". Then there exists an ")#mi("{r \\geq 1}")#text(" such that there are infinitely many ")#mi("{A \\in \\Gamma}")#text(" with ")#mi("{f(A)}")#text(" non-zero and ")#mi("{r}")#text("-almost prime.")
]

#text("This is not the strongest version of the Bourgain-Gamburd-Sarnak theorem, but it captures the general flavour of their results. Note that the theorem immediately implies an analogous result for orbits ")#mi("{\\Gamma b \\subset {\\bf Z}^2}")#text(", in which ")#mi("{f}")#text(" is now a polynomial from ")#mi("{{\\bf Z}^2}")#text(" to ")#mi("{{\\bf Z}}")#text(", and one uses ")#mi("{f(Ab)}")#text(" instead of ")#mi("{f(A)}")#text(". It is in fact conjectured that one can set ")#mi("{r=1}")#text(" here, but this is well beyond current technology. For the purpose of reaching ")#mi("{r=1}")#text(", it is very natural to impose the primitivity condition, but as long as one is content with larger values of ")#mi("{r}")#text(", it is possible to relax the primitivity condition somewhat; see ")#link("http://www.ams.org/mathscinet-getitem?mr=2587341")[#text("the paper of Bourgain, Gamburd, and Sarnak")]#text(" for more discussion.")

#text("By specialising to the polynomial ")#mi("{f: \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} \\rightarrow abcd}")#text(", we conclude as a corollary that as long as ")#mi("{\\Gamma}")#text(" is primitive in the sense that it contains matrices with all coefficients coprime to ")#mi("{q}")#text(" for any given ")#mi("{q}")#text(", then ")#mi("{\\Gamma}")#text(" contains infinitely many matrices whose elements are all ")#mi("{r}")#text("-almost primes for some ")#mi("{r}")#text(" depending only on ")#mi("{\\Gamma}")#text(". For further applications of these sorts of results, for instance to ")#link("http://en.wikipedia.org/wiki/Apollonian_gasket")[#text("Appolonian packings")]#text(", see ")#link("http://www.ams.org/mathscinet-getitem?mr=2587341")[#text("the paper of Bourgain, Gamburd, and Sarnak")]#text(".")

#text("It turns out that to prove Theorem ")#link(<tao-20df97752cefa9847776>)[#text("1")]#text(", the Cayley expansion results in ")#mi("{SL_2(F_p)}")#text(" from the ")#link("https://terrytao.wordpress.com/2012/02/13/254b-notes-6-non-concentration-in-subgroups/")[#text("previous set of notes")]#text(" are not quite enough; one needs a more general Cayley expansion result in ")#mi("{SL_2({\\bf Z}/q{\\bf Z})}")#text(" where ")#mi("{q}")#text(" is square-free but not necessarily prime. The proof of this expansion result uses the same basic methods as in the ")#mi("{SL_2(F_p)}")#text(" case, but is significantly more complicated technically, and we will only discuss it briefly here. As such, we do not give a complete proof of Theorem ")#link(<tao-20df97752cefa9847776>)[#text("1")]#text(", but hopefully the portion of the argument presented here is still sufficient to give an impression of the ideas involved.")

#metadata(none) <tao-b3c15459270e7d316cd6>

#heading(level: 1)[#strong[#text(" — 1. Combinatorial sieving — ")]]

#text("In this section we set up the combinatorial sieve needed to establish Theorem ")#link(<tao-20df97752cefa9847776>)[#text("1")]#text(". To motivate this sieve, let us focus first on a much simpler model problem, namely the task of estimating the number ")#mi("{\\pi(x,z)}")#text(" of natural numbers less than or equal to a given threshold ")#mi("{x}")#text(" which are not divisible by any prime less than or equal to ")#mi("{z}")#text(". Note that for ")#mi("{z}")#text(" between ")#mi("{\\sqrt{x}}")#text(" and ")#mi("{x}")#text(", ")#mi("{\\pi(x,z)}")#text(" is simply the number of primes in the interval ")#mi("{(z,x]}")#text("; but for ")#mi("{z}")#text(" less than ")#mi("{\\sqrt{x}}")#text(", ")#mi("{\\pi(x,z)}")#text(" also counts some almost primes in addition to genuine primes. This quantity can be studied quite precisely by a variety of tools, such as those coming from multiplicative number theory; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=2099829")[#text("this paper of Granville and Soundararajan")]#text(" for some of the most precise results in this direction.")

#text("The quantity ")#mi("{\\pi(x,z)}")#text(" is easiest to estimate when ")#mi("{z}")#text(" is small. For instance, ")#mi("{\\pi(x,1)}")#text(" is simply the number of natural numbers less than ")#mi("{x}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("\\pi(x,1) = x + O(1).")]]

#text("Similarly, ")#mi("{\\pi(x,2)}")#text(" is the number of odd numbers less than ")#mi("{x}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("\\pi(x,2) = \\frac{1}{2} x + O(1).")]]

#text("Carrying this further, ")#mi("{\\pi(x,3)}")#text(" is the number of numbers less than ")#mi("{x}")#text(" that are coprime to ")#mi("{6}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("\\pi(x,3) = \\frac{1}{3} x + O(1)")]]

#text("(but note that the implied constant in the ")#mi("{O(1)}")#text(" error is getting increasingly large). Continuing this analysis, it is not hard to see that")

#align(center)[#tao-fit-display[#mitex("\\pi(x,z) = (\\prod_{p \\leq z} (1-\\frac{1}{p})) x + O_z(1)")]]

#text("for any fixed ")#mi("{z}")#text("; note from ")#link("http://en.wikipedia.org/wiki/Mertens'_theorems")[#text("Mertens’ theorem")]#text(" that ")#metadata(none) <tao-063266a19bdb6bfb585e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\prod_{p \\leq z} (1-\\frac{1}{p}) = \\frac{e^{\\gamma} + o(1)}{\\log z}")]]

#text("leading to the heuristic approximation")

#align(center)[#tao-fit-display[#mitex("\\pi(x,z) \\approx e^\\gamma \\frac{x}{\\log z}")]]

#text("where ")#mi("{\\gamma= 0.577\\ldots}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Euler%E2%80%93Mascheroni_constant")[#text("Euler-Mascheroni constant")]#text(". Note though that this heuristic should be treated with caution when ")#mi("{z}")#text(" is large; for instance, from the prime number theorem we see that we have the conflicting asymptotic")

#align(center)[#tao-fit-display[#mitex("\\pi(x,z) = (1+o(1)) \\frac{x}{\\log x}")]]

#text("when ")#mi("{\\sqrt{x} \\leq z \\leq o(x)}")#text(". This is already a strong indication that one needs to pay careful attention to the error terms in this analysis. (Indeed, many false “proofs” of conjectures in analytic number theory, such as the twin prime conjecture, have been based on a cavalier attitude to such error terms, and their asymptotic behaviour under various limiting regimes.)")

#text("Let us thus work more carefully to control the error term ")#mi("{O_z(1)}")#text(". Write ")#mi("{P(z) := \\prod_{p \\leq z} p}")#text(" for the product of all the primes less than or equal to ")#mi("{z}")#text(" (this quantity is also known as the ")#link("http://en.wikipedia.org/wiki/Primorial")[#text("primorial")]#text(" of ")#mi("{z}")#text("). Then we can write")

#align(center)[#tao-fit-display[#mitex("\\pi(x,z) = \\sum_{n \\leq x} 1_{(n,P(z))=1}")]]

#text("where the sum ranges over natural numbers ")#mi("{n}")#text(" less than ")#mi("{x}")#text(", and ")#mi("{(n,P(z))}")#text(" is the greatest common divisor of ")#mi("{n}")#text(" and ")#mi("{P(z)}")#text(". The function ")#mi("{1_{(n,P(z))=1}}")#text(" is periodic of period ")#mi("{P(z)}")#text(", and is equal to ")#mi("{1}")#text(" on ")#mi("{(\\prod_{p\\leq z} (1-\\frac{1}{p})) P(z)}")#text(" of the residue classes modulo ")#mi("{P(z)}")#text(", which leads to the crude bound ")#metadata(none) <tao-641d7a19d7a611da023e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\pi(x,z) = (\\prod_{p \\leq z} (1-\\frac{1}{p})) x + O(P(z)).")]]

#text("However, this error term is too large for most applications: from the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(", we see that ")#mi("{P(z) = \\exp((1+o(1)) z)}")#text(", so the error term grows exponentially in ")#mi("{z}")#text(". In particular, this estimate is only non-trivial in the regime ")#mi("{z = O( \\log x )}")#text(".")

#text("One can do a little better than this by using the ")#link("http://en.wikipedia.org/wiki/Inclusion-exclusion_principle")[#text("inclusion-exclusion principle")]#text(", which in this context is also known as the ")#emph[#text("Legendre sieve")]#text(". Consider for instance ")#mi("{\\pi(x,3)}")#text(", which counts the number of natural numbers ")#mi("{n \\leq x}")#text(" coprime to ")#mi("{P(3) = 2 \\times 3}")#text(". We can compute this quantity by first counting all numbers less than ")#mi("{x}")#text(", then subtracting those numbers divisible by ")#mi("{2}")#text(" and by ")#mi("{3}")#text(", and then adding back those numbers divisible by both ")#mi("{2}")#text(" and ")#mi("{3}")#text(". A convenient way to describe this procedure in general is to introduce the ")#link("http://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(" ")#mi("{\\mu(n)}")#text(", defined to equal ")#mi("{(-1)^k}")#text(" when ")#mi("{n}")#text(" is the product of ")#mi("{k}")#text(" distinct primes for some ")#mi("{k \\geq 0}")#text(". The key point is that ")#metadata(none) <tao-2cda36e6665669fdf88e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("1_{n=1} = \\sum_{d|n} \\mu(d)")]]

#text("for any natural number ")#mi("{n}")#text(", where ")#mi("{d}")#text(" ranges over the divisors of ")#mi("{n}")#text("; indeed, this identity can be viewed as an alternate way to define the Möbius function. In particular, ")#mi("{1_{(n,P(z))=1} = \\sum_{d|P(z)} \\mu(d) 1_{d|n}}")#text(", leading to the ")#link("http://en.wikipedia.org/wiki/Legendre_sieve")[#text("Legendre identity")]

#align(center)[#tao-fit-display[#mitex("\\pi(x,z) = \\sum_{d|P(z)} \\mu(d) \\sum_{n \\leq x; d|n} 1.")]]

#text("The inner sum can be easily estimated as ")#metadata(none) <tao-4d889c136d99c2f7bcbf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{n \\leq x; d|n} 1 = \\frac{x}{d} + O(1);")]]

#text("since ")#mi("{P(z)}")#text(" has ")#mi("{2^{\\pi(z)}}")#text(" distinct factors, where ")#mi("{\\pi(z)}")#text(" is the number of primes less than or equal to ")#mi("{z}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\pi(x,z) = \\sum_{d|P(z)} \\mu(d) \\frac{x}{d} + O( 2^{\\pi(z)} ).")]]

#text("The main term here can be factorised as ")#metadata(none) <tao-41a093100bbbb59e31dc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{d|P(z)} \\mu(d) \\frac{x}{d} = x \\prod_{p \\leq z} (1 - \\frac{1}{p})")]]

#text("leading to the following slight improvement")

#align(center)[#tao-fit-display[#mitex("\\pi(x,z) = (\\prod_{p \\leq z} (1-\\frac{1}{p})) x + O(2^{\\pi(z)})")]]

#text("to ")#link(<tao-641d7a19d7a611da023e>)[#text("(2)")]#text(". Note from the prime number theorem that ")#mi("{2^{\\pi(z)} = O( \\exp( O( z / \\log z ) ) )}")#text(", so this error term is asymptotically better than the one in ")#link(<tao-641d7a19d7a611da023e>)[#text("(2)")]#text("; the bound here is now non-trivial in the slightly larger regime ")#mi("{z = O( \\log x \\log \\log x )}")#text(". But this is still not good enough for the purposes of counting almost primes, which would require ")#mi("{z}")#text(" as large as a power of ")#mi("{x}")#text(".")

#text("To do better, we will replace the exact identity ")#link(<tao-2cda36e6665669fdf88e>)[#text("(3)")]#text(" by combinatorial truncations ")#metadata(none) <tao-b98cae4b324710d7c5ab>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{d|n: d \\in {\\mathcal D}_-} \\mu(d) \\leq 1_{n=1} \\leq \\sum_{d|n: d \\in {\\mathcal D}_+} \\mu(d)")]]

#text("of that identity, where ")#mi("{n}")#text(" divides ")#mi("{P(z)}")#text(" and ")#mi("{{\\mathcal D}_-, {\\mathcal D}_+}")#text(" are sets to be specified later, leading to the upper bound sieve ")#metadata(none) <tao-9f73cd7c814a8bd49a0e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\pi(x,z) \\leq \\sum_{d|P(z); d \\in {\\mathcal D}_+} \\mu(d) \\frac{x}{d} + O( \\left|{\\mathcal D}_+\\right| )", block: true)]]

#text("and the lower bound sieve ")#metadata(none) <tao-0f22321da16f114b7965>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\pi(x,z) \\geq \\sum_{d|P(z); d \\in {\\mathcal D}_-} \\mu(d) \\frac{x}{d} + O( \\left|{\\mathcal D}_-\\right| ).", block: true)]]

#text("The key point will be that ")#mi("{{\\mathcal D}_+}")#text(" and ")#mi("{{\\mathcal D}_-}")#text(" can be chosen to be only polynomially large in ")#mi("{z}")#text(", rather than exponentially large, without causing too much damage to the main terms ")#mi("{\\sum_{d|P(z); d \\in D_\\pm} \\mu(d) \\frac{x}{d}}")#text(", which lead to upper and lower bounds on ")#mi("{\\pi(x,z)}")#text(" that remain non-trivial for moderately large values of ")#mi("{z}")#text(" (e.g. ")#mi("{z = x^{1/(r+1)}}")#text(" for some fixed ")#mi("{r}")#text(").")

#text("We now turn to the task of locating reasonably small sets ")#mi("{{\\mathcal D}_+, {\\mathcal D}_-}")#text(" obeying ")#link(<tao-b98cae4b324710d7c5ab>)[#text("(6)")]#text(". We begin with")#link(<tao-2cda36e6665669fdf88e>)[#text("(3)")]#text(", which we rewrite as ")#metadata(none) <tao-e9e0a67a8948104fbf92>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("1_{n=1} = \\sum_{d|P(z)} \\mu(d) 1_{d|n}")]]

#text("for ")#mi("{n}")#text(" a divisor of ")#mi("{P(z)}")#text(". One can view the divisors of ")#mi("{P(z)}")#text(" as a ")#mi("{\\pi(z)}")#text("-dimensional combinatorial cube, with the right-hand side in ")#link(<tao-e9e0a67a8948104fbf92>)[#text("(9)")]#text(" being a sum over that cube; the idea is then to hack off various subcubes of that cube in a way that only serves to increase (for the upper bound sieve) or decrease (for the lower bound sieve) that sum, until only a relatively small portion of the cube remains.")

#text("We turn to the details. Our starting point will be the identity ")#metadata(none) <tao-50d2ddd6c402fb60a70d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\sum_{d|P(z): d = p_1 \\ldots p_k d^{\\prime}, d^{\\prime} | P(p_k)} \\mu(d) 1_{d|n} = (-1)^k 1_{n=p_1 \\ldots p_k m; (m,P(p_k)=1)}")]]

#text("whenever ")#mi("{z \\geq p_1 > p_2 > \\ldots > p_k}")#text(" are primes, which follows easily from applying ")#link(<tao-2cda36e6665669fdf88e>)[#text("(3)")]#text(" to ")#mi("{n / (p_1 \\ldots p_k)}")#text(" when ")#mi("{p_1,\\ldots,p_k}")#text(" divide ")#mi("{n}")#text(". One can view the left-hand side of ")#link(<tao-50d2ddd6c402fb60a70d>)[#text("(10)")]#text(" as a subsum of the sum in ")#link(<tao-e9e0a67a8948104fbf92>)[#text("(9)")]#text(", and ")#link(<tao-50d2ddd6c402fb60a70d>)[#text("(10)")]#text(" implies that this subsum is non-negative when ")#mi("{k}")#text(" is even and non-positive when ")#mi("{k}")#text(" is odd. In particular, we see that ")#link(<tao-b98cae4b324710d7c5ab>)[#text("(6)")]#text(" will hold when ")#mi("{{\\mathcal D}_+}")#text(" is formed from the “cube” ")#mi("{\\{ d: d|P(z)\\}}")#text(" by removing some disjoint “subcubes” of the form ")#mi("{\\{ d =p_1 \\ldots p_k d^{\\prime}: d^{\\prime} | P(p_k) \\}}")#text(" for ")#mi("{z \\geq p_1 > \\ldots > p_k}")#text(" and ")#mi("{k}")#text(" odd, and similarly for ")#mi("{{\\mathcal D}_-}")#text(" but with ")#mi("{k}")#text(" now required to be even instead of odd.")

#text("Observe that the subcube ")#mi("{\\{ d =p_1 \\ldots p_k d^{\\prime}: d^{\\prime} | P(p_k) \\}}")#text(" consists precisely of those divisors ")#mi("{d}")#text(" of ")#mi("{P(z)}")#text(" whose top ")#mi("{k}")#text(" prime factors are ")#mi("{p_1,\\ldots,p_k}")#text(". We now have the following general inequality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Combinatorial sieve)")]#text(" Let ")#mi("{z>0}")#text(". For each natural number ")#mi("{k}")#text(", let ")#mi("{A_k( p_1,\\ldots,p_k)}")#text(" be a predicate pertaining to ")#mi("{k}")#text(" decreasing primes ")#mi("{z \\geq p_1>\\ldots>p_k}")#text(" (thus ")#mi("{A_k(p_1,\\ldots,p_k)}")#text(" is either true or false for each choice of ")#mi("{p_1,\\ldots,p_k}")#text("). Let ")#mi("{{\\mathcal D}_+}")#text(" be the set of all natural numbers ")#mi("{n|P(z)}")#text(" which, when factored as ")#mi("{n = p_1 \\ldots p_r}")#text(" for ")#mi("{z \\geq p_1 > \\ldots > p_r}")#text(", is such that ")#mi("{A_k(p_1,\\ldots,p_k)}")#text(" holds for all odd ")#mi("{1 \\leq k \\leq r}")#text(". Similarly define ")#mi("{{\\mathcal D}_-}")#text(" by requiring ")#mi("{k}")#text(" to be even instead of odd. Then ")#link(<tao-b98cae4b324710d7c5ab>)[#text("(6)")]#text(" holds for all ")#mi("{n|P(z)}")#text(".")
]

#emph[#text("Proof:")]#text(" ")#mi("{{\\mathcal D}_+}")#text(" is formed from ")#mi("{\\{ d: d|P(z)\\}}")#text(" by removing those subcubes of the form ")#mi("{\\{ d =p_1 \\ldots p_k d^{\\prime}: d^{\\prime} | P(p_k) \\}}")#text(" for ")#mi("{z \\geq p_1 > \\ldots > p_k}")#text(", ")#mi("{k}")#text(" odd, and such that ")#mi("{A_{k^{\\prime}}(p_1,\\ldots,p_{k^{\\prime}})}")#text(" holds for all odd ")#mi("{1 \\leq k^{\\prime} < k}")#text(" but fails for ")#mi("{k^{\\prime}=k}")#text(". These subcubes are all disjoint, and so the claim for ")#mi("{{\\mathcal D}_+}")#text(" follows from the preceding discussion. Similarly for ")#mi("{{\\mathcal D}_-}")#text(". ")#mi("\\Box")

#text("This gives us the upper and lower bounds ")#link(<tao-9f73cd7c814a8bd49a0e>)[#text("(7)")]#text(", ")#link(<tao-0f22321da16f114b7965>)[#text("(8)")]#text(" for ")#mi("{\\pi(x,z)}")#text(". To make these bounds useful, we need to choose ")#mi("{{\\mathcal D}_\\pm}")#text(" so that the partial sums ")#mi("{\\sum_{d|P(z); d \\in {\\mathcal D}_\\pm} \\mu(d) \\frac{x}{d}}")#text(" are close to")

#align(center)[#tao-fit-display[#mitex("\\sum_{d|P(z)} \\mu(d) \\frac{x}{d} = x \\prod_{p \\leq z} (1 - \\frac{1}{p}).")]]

#text("To do this, one must select the predicates ")#mi("{A_k(p_1,\\ldots,p_k)}")#text(" carefully. The best choices for these predicates are not immediately obvious; but after much trial and error, it was discovered that one fairly efficient choice is to let ")#mi("{A_k(p_1,\\ldots,p_k)}")#text(" be the predicate")

#align(center)[#tao-fit-display[#mitex("p_1 \\ldots p_{k-1} p_k^{\\beta+1} < y")]]

#text("for some moderately large parameter ")#mi("{\\beta \\geq 2}")#text(" (we will eventually take ")#mi("{\\beta := 10}")#text(") and some parameter ")#mi("{y := z^s}")#text(" for some ")#mi("{s > \\beta}")#text(" to be optimised in later (we will eventually take it to be almost as large as ")#mi("{x}")#text("). The use of this choice is referred to as the ")#emph[#text("beta sieve")]#text(".")

#text("Let us now estimate the errors ")#metadata(none) <tao-b2fec115043348fde0ca>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left|\\sum_{d|P(z)} \\mu(d) \\frac{x}{d} - \\sum_{d|P(z): d \\in {\\mathcal D}_\\pm} \\mu(d) \\frac{x}{d}\\right|.", block: true)]]

#text("For sake of argument let us work with ")#mi("{{\\mathcal D}_-}")#text(", as the ")#mi("{{\\mathcal D}_+}")#text(" case is almost identical. By the triangle inequality, we can bound this error by")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k \\text{ even}} \\sum^* \\left|\\sum_{d = p_1 \\ldots p_k d^{\\prime}: d^{\\prime} |P(p_k)} \\mu(d) \\frac{x}{d}\\right|", block: true)]]

#text("where ")#mi("{k}")#text(" ranges over positive even integers, and ")#mi("{\\sum^*}")#text(" denotes a sum over primes ")#mi("{z \\geq p_1 > \\ldots > p_k}")#text(" ranges over primes such that ")#metadata(none) <tao-bd66796784e4bb256fb9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("p_1 \\ldots p_{k^{\\prime}-1} p_{k^{\\prime}}^{\\beta+1} < y")]]

#text("for all even ")#mi("{k^{\\prime} < k}")#text(", but ")#metadata(none) <tao-5ccd1ce30074d7150eca>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("p_1 \\ldots p_{k-1} p_{k}^{\\beta+1} \\geq y.")]]

#text("Since ")#mi("{p_1,\\ldots,p_k \\leq z}")#text(" and ")#mi("{y = z^s}")#text(", this in particular gives the bound")

#align(center)[#tao-fit-display[#mitex("k \\geq s - \\beta.")]]

#text("From ")#link(<tao-bd66796784e4bb256fb9>)[#text("(12)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("p_1 \\ldots p_{k^{\\prime}-1} p_{k^{\\prime}}^{\\beta} < y")]]

#text("for all ")#mi("{1 \\leq k^{\\prime} < k}")#text(" (not necessarily even); note that the case ")#mi("{k^{\\prime}=1}")#text(" follows from the hypothesis ")#mi("{y > z^\\beta}")#text(". We can rewrite this inequality as")

#align(center)[#tao-fit-display[#mitex("\\frac{y}{p_1 \\ldots p_{k^{\\prime}}} > (\\frac{y}{p_1 \\ldots p_{k^{\\prime}-1}})^{\\frac{\\beta-1}{\\beta}}")]]

#text("and hence by induction")

#align(center)[#tao-fit-display[#mitex("\\frac{y}{p_1 \\ldots p_{k^{\\prime}}} > y^{(\\frac{\\beta-1}{\\beta})^{k^{\\prime}-1}}")]]

#text("for all ")#mi("{1 \\leq k^{\\prime}< k}")#text(". From ")#link(<tao-5ccd1ce30074d7150eca>)[#text("(13)")]#text(" we then have")

#align(center)[#tao-fit-display[#mitex("p_k > y^{\\frac{1}{\\beta+1} (\\frac{\\beta-1}{\\beta})^{k-1}} > y^{\\frac{1}{\\beta}(\\frac{\\beta-1}{\\beta})^k} > z^{(\\frac{\\beta-1}{\\beta})^k}.")]]

#text("We conclude that the error ")#link(<tao-b2fec115043348fde0ca>)[#text("(11)")]#text(" is bounded by")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k=1}^\\infty \\sum_{z \\geq p_1 > \\ldots > p_k > z^{(\\frac{\\beta-1}{\\beta})^k}} \\left|\\sum_{d = p_1 \\ldots p_k d^{\\prime}: d^{\\prime} |P(p_k)} \\mu(d) \\frac{x}{d}\\right|", block: true)]]

#text("in the ")#mi("{{\\mathcal D}_+}")#text("; a similar argument also gives this bound in the ")#mi("{{\\mathcal D}_-}")#text(" case. The inner sum can be computed as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{d = p_1 \\ldots p_k d^{\\prime}: d^{\\prime} |P(p_k)} \\mu(d) \\frac{x}{d}\\right| = \\frac{x}{p_1 \\ldots p_k} \\prod_{p < p_k} (1 - \\frac{1}{p})", block: true)]]

#text("and thus by Mertens’ theorem ")#link(<tao-063266a19bdb6bfb585e>)[#text("(1)")]#text(" and the bound ")#mi("{p_k > z^{(\\frac{\\beta-1}{\\beta})^k}}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{d = p_1 \\ldots p_k d^{\\prime}: d^{\\prime} |P(p_k)} \\mu(d) \\frac{x}{d}\\right| \\ll (\\frac{\\beta}{\\beta-1})^k \\frac{x}{p_1 \\ldots p_k \\log z}.", block: true)]]

#text("We have thus bounded ")#link(<tao-b2fec115043348fde0ca>)[#text("(11)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\ll \\frac{x}{\\log z} \\sum_{k \\geq s-\\beta} (\\frac{\\beta}{\\beta-1})^k \\sum_{z \\geq p_1 > \\ldots > p_k > z^{(\\frac{\\beta-1}{\\beta})^k}} \\frac{1}{p_1 \\ldots p_k}.")]]

#text("The inner sum can be bounded by")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{k!} (\\sum_{z \\geq p > z^{(\\frac{\\beta-1}{\\beta})^k}} \\frac{1}{p})^k.")]]

#text("By another of Mertens’ theorems (or by taking logarithms of ")#link(<tao-063266a19bdb6bfb585e>)[#text("(1)")]#text(") one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{z \\geq p > z^{(\\frac{\\beta-1}{\\beta})^k}} \\frac{1}{p} \\leq k \\log \\frac{\\beta}{\\beta-1} + O(1)")]]

#text("and so ")#link(<tao-b2fec115043348fde0ca>)[#text("(11)")]#text(" is bounded by")

#align(center)[#tao-fit-display[#mitex("\\ll \\frac{x}{\\log z} \\sum_{k \\geq s-\\beta} \\frac{1}{k!} ( k \\frac{\\beta}{\\beta-1} \\log \\frac{\\beta}{\\beta-1} + O(1) )^k.")]]

#text("Using the crude bound ")#mi("{k! \\geq \\frac{k^k}{e^k}}")#text(" (as can be seen by considering the ")#mi("{k^{th}}")#text(" term in the Taylor expansion of ")#mi("{e^k}")#text(") we conclude the bound")

#align(center)[#tao-fit-display[#mitex("\\ll \\frac{x}{\\log z} \\sum_{k \\geq s-\\beta} ( e \\frac{\\beta}{\\beta-1} \\log \\frac{\\beta}{\\beta-1} + O(\\frac{1}{k}) )^k.")]]

#text("If ")#mi("{\\beta}")#text(" is large enough (")#mi("{\\beta=10}")#text(" will suffice) then the expression ")#mi("{e \\frac{\\beta}{\\beta-1} \\log \\frac{\\beta}{\\beta-1}}")#text(" is less than ")#mi("{1/e}")#text("; since ")#mi("{(1 + O(1/k))^k = O(1)}")#text(", this leads to the bound")

#align(center)[#tao-fit-display[#mitex("\\ll \\frac{x}{\\log z} \\sum_{k \\geq s-\\beta} e^{-k}")]]

#text("which after summing the geometric series becomes")

#align(center)[#tao-fit-display[#mitex("\\ll e^{-s} \\frac{x}{\\log z}")]]

#text("(allowing implied constants to depend on ")#mi("{\\beta}")#text("). From this bound on ")#link(<tao-b2fec115043348fde0ca>)[#text("(11)")]#text(" and ")#link(<tao-41a093100bbbb59e31dc>)[#text("(5)")]#text(", ")#link(<tao-063266a19bdb6bfb585e>)[#text("(1)")]#text(" we have We thus have")

#align(center)[#tao-fit-display[#mitex("\\sum_{d|P(z): d \\in {\\mathcal D}_\\pm} \\mu(d) \\frac{x}{d} = \\frac{x}{\\log z}( e^\\gamma + O( e^{-s} ) + o(1) ).")]]

#text("Finally, if ")#mi("{d = p_1 \\ldots p_k}")#text(" is an element of ")#mi("{{\\mathcal D}_\\pm}")#text(", then by ")#link(<tao-bd66796784e4bb256fb9>)[#text("(12)")]#text(" and the hypothesis ")#mi("{\\beta \\geq 2}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("d = p_1 \\ldots p_k \\leq y")]]

#text("and so we have the crude upper bounds ")#tao-math("{\\left|{\\mathcal D}_\\pm\\right| \\leq y}", block: false)#text(". From ")#link(<tao-9f73cd7c814a8bd49a0e>)[#text("(7)")]#text(", ")#link(<tao-0f22321da16f114b7965>)[#text("(8)")]#text(" and recalling that ")#mi("{y = z^s}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("\\pi(x,z) = \\frac{x}{\\log z}( e^\\gamma + O( e^{-s} ) + o(1) ) + O(z^s).")]]

#text("If ")#mi("{x > z^{11}}")#text(", we may optimise in ")#mi("{s}")#text(" by setting ")#mi("{s := \\frac{\\log x}{\\log z} - 1}")#text(" (in order to make the final error term much less than ")#mi("{x}")#text("), leading to the bound")

#align(center)[#tao-fit-display[#mitex("\\pi(x,z) = \\frac{x}{\\log z}( e^\\gamma + O( e^{-\\log x/\\log z} ) + o(1) ).")]]

#text("In particular, we have ")#metadata(none) <tao-9ed1515819dec61fd361>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\frac{x}{\\log z} \\ll \\pi(x,z) \\ll \\frac{x}{\\log z}")]]

#text("whenever ")#mi("{2 \\leq z \\leq x^\\epsilon}")#text(" for some sufficiently small absolute constant ")#mi("{\\epsilon>0}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The bound ")#link(<tao-9ed1515819dec61fd361>)[#text("(14)")]#text(" implies, among other things, that there exists an absolute constant ")#mi("{r}")#text(" such that the number of ")#mi("{r}")#text("-almost primes less than ")#mi("{x}")#text(" is ")#mi("{\\gg x/\\log x}")#text(", which is a very weak version of the prime number theorem. Note though that the upper bound in ")#link(<tao-9ed1515819dec61fd361>)[#text("(14)")]#text(" does ")#emph[#text("not")]#text(" directly imply a corresponding upper bound on this count of ")#mi("{r}")#text("-almost primes, because ")#mi("{r}")#text("-almost primes are allowed to have prime factors that are less than ")#mi("{x}")#text(". Indeed, a routine computation using Mertens’ theorem shows that for any fixed ")#mi("{r}")#text(", the number of ")#mi("{r}")#text("-almost primes less than ")#mi("{x}")#text(" is comparable to ")#mi("{\\frac{x}{\\log x} (\\log \\log x)^{r-1}}")#text(".")
]

#text("We can generalise the above argument as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1 (Beta sieve)")]#text(" Let ")#mi("{a_n}")#text(" be an absolutely convergent sequence of non-negative reals for ")#mi("{n \\geq 1}")#text(". Let ")#mi("{x > 1}")#text(", ")#mi("{\\kappa \\geq 1}")#text(", and ")#mi("{\\epsilon > 0}")#text(". Let ")#mi("{g: {\\bf N} \\rightarrow {\\bf R}^+}")#text(" be a multiplicative function taking values between ")#mi("{0}")#text(" and ")#mi("{1}")#text(", with ")#mi("{g(p)<1}")#text(" for all primes ")#mi("{p}")#text(". Assume the following axioms:")

#list(
[#text("(i) (Control in arithmetic progressions) For any ")#mi("{d \\leq x^\\epsilon}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n: d|n} a_n = g(d) x + O( x^{1-\\epsilon} ).")]]],
[#text("(ii) (Mertens type theorem) For all ")#mi("{2 \\leq z \\leq x^\\epsilon}")#text(", one has ")#metadata(none) <tao-5e0cf7bd1dfa3831788b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\frac{1}{\\log^\\kappa z} \\ll \\prod_{p \\leq z} (1-g(p)) \\ll \\frac{1}{\\log^\\kappa z}.")]]]
)

#text("Conclude that there is an ")#mi("{\\epsilon^{\\prime}>0}")#text(" depending only on ")#mi("{\\kappa,\\epsilon}")#text(", and the implied constants in the above axioms, such that")

#align(center)[#tao-fit-display[#mitex("\\frac{x}{\\log^\\kappa z} \\ll \\sum_{n: (n,P(z))=1} a_n \\ll \\frac{x}{\\log^\\kappa z}")]]

#text("whenever ")#mi("{2 \\leq z \\leq x^{\\epsilon^{\\prime}}}")#text(", and the implied constants may depend on ")#mi("{\\kappa, \\epsilon}")#text(", and the implied constants in the above axioms. (Note that ")#link(<tao-9ed1515819dec61fd361>)[#text("(14)")]#text(" corresponds to the case when ")#mi("{\\kappa := 1}")#text(", ")#mi("{g(n) := 1/n}")#text(", and ")#mi("{a_n := 1_{n \\leq x}}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" ")#metadata(none) <tao-20c1509e7e444092b3ce>#text(" Suppose we have the notation and hypotheses of the preceding exercise, except that the estimate ")#link(<tao-5e0cf7bd1dfa3831788b>)[#text("(15)")]#text(" is replaced by the weaker bound ")#metadata(none) <tao-2e3a282d530f0362727d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("g(p) \\leq \\frac{\\kappa}{p} + O(\\frac{1}{p^2})")]]

#text("for all sufficiently large ")#mi("{p}")#text(". (For small ")#mi("{p}")#text(", note that we still have the bound ")#mi("{g(p)<1}")#text(".) Show that we still have the lower bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n: (n,P(z))=1} a_n \\gg \\frac{x}{\\log^\\kappa z}")]]

#text("whenever ")#mi("{2 \\leq z \\leq x^{\\epsilon^{\\prime}}}")#text(" for sufficiently small ")#mi("{\\epsilon^{\\prime}}")#text(" (which may depend on ")#mi("{g}")#text("), where the implied constant is now allowed to depend on ")#mi("{g}")#text(". (")#emph[#text("Hint:")]#text(" the main trick here is to extract out a common factor of ")#mi("{\\prod_{p \\leq z} (1-g(p))}")#text(" from the analysis first, and then use the bound ")#link(<tao-2e3a282d530f0362727d>)[#text("(16)")]#text(" to upper bound quantities such as ")#mi("{\\prod_{p_k \\leq p \\leq z} (1-g(p))^{-1}}")#text(".)")
]

#text("One can weaken the axioms somewhat and still obtain non-trivial results from the beta sieve, but this somewhat crude version of the sieve will suffice for our purposes. Another, more abstract, formalisation of the above argument (involving a construction of sets ")#mi("{{\\mathcal D}_\\pm}")#text(" obeying ")#link(<tao-b98cae4b324710d7c5ab>)[#text("(6)")]#text(" and a number of other desirable properties) is sometimes referred to as ")#link("http://en.wikipedia.org/wiki/Fundamental_lemma_of_sieve_theory")[#text("the fundamental lemma of sieve theory")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3 (Twin almost primes)")]#text(" Let ")#mi("{\\pi_2(x,z)}")#text(" be the number of integers ")#mi("{n}")#text(" between ")#mi("{1}")#text(" and ")#mi("{x}")#text(" such that ")#mi("{n}")#text(" and ")#mi("{n+2}")#text(" are both coprime to ")#mi("{P(z)}")#text(".")

#list(
[#text("(i) Show that")

#align(center)[#tao-fit-display[#mitex("\\frac{x}{\\log^2 z} \\ll \\pi_2(x,z) \\ll \\frac{x}{\\log^2 z}")]]

#text("if ")#mi("{2 \\leq z \\leq x^\\epsilon}")#text(", and ")#mi("{\\epsilon>0}")#text(" is a sufficiently small absolute constant.")],
[#text("(ii) Show that there exists an ")#mi("{r \\geq 1}")#text(" such that there are infinitely many pairs ")#mi("{n,n+2}")#text(" which are both ")#mi("{r}")#text("-almost primes. (Indeed, the argument here allows one to take ")#mi("{r=20}")#text(" without much effort, and by working considerably harder to optimise everything, one can lower ")#mi("{r}")#text(" substantially, although the parity problem mentioned earlier prevents one from taking ")#mi("{r}")#text(" below ")#mi("{2}")#text(".)")],
[#text("(iii) Establish ")#link("http://en.wikipedia.org/wiki/Brun's_theorem")[#text("Brun’s theorem")]#text(" that the sum of reciprocals of the twin primes is convergent.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4 (Landau conjecture for almost primes)")]#text(" ")#metadata(none) <tao-4cdcbb0ac2132ff4462f>#text(" Let ")#mi("{\\pi_*(x,z)}")#text(" be the number of integers ")#mi("{n}")#text(" between ")#mi("{1}")#text(" and ")#mi("{x}")#text(" such that ")#mi("{n^2+1}")#text(" is coprime to ")#mi("{P(z)}")#text(".")

#list(
[#text("(i) Show that")

#align(center)[#tao-fit-display[#mitex("\\frac{x}{\\log z} \\ll \\pi_2(x,z) \\ll \\frac{x}{\\log z}")]]

#text("if ")#mi("{2 \\leq z \\leq x^\\epsilon}")#text(", and ")#mi("{\\epsilon>0}")#text(" is a sufficiently small absolute constant. (")#emph[#text("Hint:")]#text(" you will need the fact that ")#mi("{-1}")#text(" is a quadratic residue mod ")#mi("{p}")#text(" if and only if ")#mi("{p \\neq 3 \\text{ mod } 4}")#text(", and Merten’s theorem for arithmetic progressions, which among other things asserts that ")#mi("{\\sum_{p \\leq x: p=1 \\text{ mod } 4} \\frac{1}{p} = \\frac{1}{2} \\log x + O(1)}")#text(".)")],
[#text("(ii) Show that there exists an ")#mi("{r \\geq 1}")#text(" such that there are infinitely natural numbers ")#mi("{n}")#text(" such that ")#mi("{n^2+1}")#text(" is an ")#mi("{r}")#text("-almost primes.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Let ")#mi("{P: {\\bf Z} \\rightarrow {\\bf Z}}")#text(" be a polynomial with integer coefficients and degree ")#mi("{k}")#text(". Assume that ")#mi("{P}")#text(" is ")#emph[#text("primitive")]#text(" in the sense that for each natural number ")#mi("{q}")#text(", there exists a natural number ")#mi("{n}")#text(" such that ")#mi("{P(n)}")#text(" is coprime to ")#mi("{q}")#text(". Show that there exists an ")#mi("{r}")#text(" depending only on ")#mi("{P}")#text(" such that for all sufficiently large ")#mi("{x}")#text(", there are at least ")#mi("{\\gg_P x / \\log^k x}")#text(" natural numbers ")#mi("{n}")#text(" less than ")#mi("{x}")#text(" such that ")#mi("{P(n)}")#text(" is an ")#mi("{r}")#text("-almost prime.")

#text("In many cases (e.g. if ")#mi("{P}")#text(" is irreducible) one can decrease the power of ")#mi("{\\log x}")#text(" here (as in Exercise ")#link(<tao-4cdcbb0ac2132ff4462f>)[#text("4")]#text("), by using tools such as ")#link("http://en.wikipedia.org/wiki/Landau_prime_ideal_theorem")[#text("Landau’s prime ideal theorem")]#text("; see ")#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/")[#text("this previous blog post")]#text(" for some related discussion.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The combinatorial sieve is not the only type of sieve used in sieve theory. Another popular choice is the ")#emph[#text("Selberg upper bound sieve")]#text(", in which the starting point is not the combinatorial inequalities ")#link(<tao-b98cae4b324710d7c5ab>)[#text("(6)")]#text(", but rather the variant")

#align(center)[#tao-fit-display[#mitex("1_{n=1} \\leq (\\sum_{d|n} \\lambda_d)^2")]]

#text("where the ")#mi("{\\lambda_d}")#text(" are arbitrary real parameters with ")#mi("{\\lambda_1 := 1}")#text(", typically supported up to some level ")#mi("{d < y}")#text(". By optimising the choice of weights ")#mi("{\\lambda_d}")#text(", the Selberg sieve can lead to upper bounds on quantities such as ")#mi("{\\pi(x,z)}")#text(" which are competitive with the beta sieve (particularly when ")#mi("{z}")#text(" is moderately large), although it is more difficult for this sieve to produce matching lower bounds. A somewhat different type of sieve is the ")#emph[#text("large sieve")]#text(", which does not upper bound or lower bound indicator functions such as ")#mi("{1_{n=1}}")#text(" directly, but rather controls the size of a function that avoids many residue classes by exploiting the ")#mi("{L^2}")#text(" properties of these residue classes, such as almost orthogonality phenomena or Fourier uncertainty principles. See ")#link("http://www.ams.org/mathscinet-getitem?mr=2647984")[#text("this text of Friedlander and Iwaniec")]#text(" for a much more thorough discussion and comparison of these sieves.")
]

#heading(level: 1)[#strong[#text(" — 2. The strong approximation property — ")]]

#text("For any natural number ")#mi("{q}")#text(", let ")#mi("{\\pi_q: SL_2({\\bf Z}) \\rightarrow SL_2({\\bf Z}/q{\\bf Z})}")#text(" be the obvious projection homomorphism. An easy application of ")#link("http://en.wikipedia.org/wiki/B%C3%A9zout%27s_identity")[#text("Bezout’s theorem")]#text(" (or the ")#link("http://en.wikipedia.org/wiki/Euclidean_algorithm")[#text("Euclidean algorithm")]#text(") shows that this map is surjective. From the ")#link("http://en.wikipedia.org/wiki/Chinese_remainder_theorem")[#text("Chinese remainder theorem")]#text(", we also have ")#mi("{SL_2({\\bf Z}/q{\\bf Z}) \\equiv SL_2({\\bf Z}/q_1 {\\bf Z}) \\times SL_2({\\bf Z}/q_2{\\bf Z})}")#text(" whenever ")#mi("{q=q_1q_2}")#text(" and ")#mi("{q_1,q_2}")#text(" are coprime.")

#text("To set up the sieve needed to establish Theorem ")#link(<tao-20df97752cefa9847776>)[#text("1")]#text(", we need to understand the images ")#mi("{\\pi_q(\\Gamma)}")#text(" of a non-virtually-solvable subgroup ")#mi("{\\Gamma}")#text(" of ")#mi("{SL_2({\\bf Z})}")#text(". Clearly this is a subgroup of ")#mi("{SL_2({\\bf Z}/q{\\bf Z})}")#text(". Given that ")#mi("{\\Gamma}")#text(" is fairly “large” (in particular, such groups can be easily seen to be Zariski-dense in ")#mi("{SL_2}")#text("), we expect that in most cases ")#mi("{\\pi_q(\\Gamma)}")#text(" is in fact all of ")#mi("{SL_2({\\bf Z}/q{\\bf Z})}")#text(". This type belief is formalised in general as the ")#link("http://en.wikipedia.org/wiki/Approximation_in_algebraic_groups")[#text("strong approximation property")]#text(". We will not prove the most general instance of this property, but instead focus on the model case of ")#mi("{SL_2({\\bf Z}/q{\\bf Z})}")#text(" for ")#mi("{q}")#text(" square-free, in which one can proceed by ")#emph[#text("ad hoc")]#text(" elementary arguments. The general treatment of the strong approximation property was first achieved by ")#link("http://www.ams.org/mathscinet-getitem?mr=735226")[#text("Matthews, Vaserstein, and Weisfeiler")]#text(" using the classification of finite simple groups; a ")#link("http://www.ams.org/mathscinet-getitem?mr=880952")[#text("subsequent paper of Nori")]#text(" gave an alternate treatment that avoided the use of this classification.")

#text("In the ")#link("https://terrytao.wordpress.com/2012/02/13/254b-notes-6-non-concentration-in-subgroups/")[#text("previous set of notes")]#text(" (see Remark 2) it was already observed that ")#mi("{\\pi_p(\\Gamma) =SL_2({\\bf Z}/p{\\bf Z})}")#text(" for all sufficiently large primes ")#mi("{p}")#text(". (Indeed, ")#mi("{\\Gamma}")#text(" did not need to be free for this to hold; it was enough that ")#mi("{\\Gamma}")#text(" not be virtually solvable.) To extend from the prime case to the (square-free) composite case, we will need some basic group theory, and in particular the theory of composition factors.")

#text("Define a ")#link("http://en.wikipedia.org/wiki/Composition_series")[#text("composition series")]#text(" for a group ")#mi("{G}")#text(" to be a finite sequence")

#align(center)[#tao-fit-display[#mitex("\\{1\\}= H_0\\lhd H_1 \\lhd \\ldots\\lhd H_n = G")]]

#text("of subgroups, where each ")#mi("{H_i}")#text(" is a normal subgroup of ")#mi("{H_{i+1}}")#text(", and the quotients ")#mi("{H_{i+1}/H_i}")#text(" are all simple. (By convention, we do not consider the trivial group to be simple.) The quotients ")#mi("{H_{i+1}/H_i}")#text(" for ")#mi("{i=1,\\ldots,n-1}")#text(" are referred to as the ")#emph[#text("composition factors")]#text(" of this series.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Show that every finite group has at least one composition series.")
]

#text("A key fact about composition factors, known as the ")#link("http://en.wikipedia.org/wiki/Composition_series")[#text("Jordan-Holder theorem")]#text(", asserts that, up to permutation and isomorphism, they are independent of the choice of series:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Jordan-Holder theorem)")]#text(" Let")

#align(center)[#tao-fit-display[#mitex("\\{1\\}= H_0\\lhd H_1 \\lhd \\ldots\\lhd H_n = G")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\{1\\}= K_0\\lhd K_1 \\lhd \\ldots\\lhd K_m = G")]]

#text("be two composition series of the same group ")#mi("{G}")#text(". Then there is a bijection ")#mi("{\\sigma: \\{0,\\ldots,n-1\\} \\rightarrow\\{0,\\ldots,m-1\\}}")#text(" such that for each ")#mi("{i=0,\\ldots,n-1}")#text(", ")#mi("{H_{i+1}/H_{i}}")#text(" is isomorphic to ")#mi("{K_{\\phi(i+1)}/K_{\\phi(i)}}")#text(". (In particular, ")#mi("{n}")#text(" and ")#mi("{m}")#text(" must be equal.)")
]

#emph[#text("Proof:")]#text(" By symmetry we may assume that ")#mi("{n \\leq m}")#text(". Fix ")#mi("{0 \\leq i < n}")#text(". Let ")#mi("{\\pi_i: H_{i+1} \\rightarrow H_{i+1}/H_i}")#text(" be the quotient map, and consider the groups ")#mi("{A_j^{(i)} := \\pi_i(H_{i+1} \\cap K_j) \\equiv (H_{i+1} \\cap K_j)/(H_i \\cap K_j)}")#text(" for ")#mi("{j=0,\\ldots,m}")#text(". These are an increasing family of subgroups of ")#mi("{H_{i+1}/H_i}")#text(", with ")#mi("{A^{(i)}_0 = \\{1\\}}")#text(" and ")#mi("{A^{(i)}_m = H_{i+1}/H_i}")#text(". Since each ")#mi("{K_j}")#text(" is a normal subgroup of ")#mi("{K_{j+1}}")#text(", we see that ")#mi("{A^{(i)}_j}")#text(" is a normal subgroup of ")#mi("{A^{(i)}_{j+1}}")#text(". As ")#mi("{A^{(i)}_m}")#text(" is simple, this implies that there is a unique element ")#mi("{\\sigma(i)}")#text(" of ")#mi("{\\{0,\\ldots,m-1\\}}")#text(" such that ")#mi("{A^{(i)}_j}")#text(" is trivial for ")#mi("{j \\leq \\sigma(i)}")#text(" and ")#mi("{A^{(i)}_j}")#text(" is equal to ")#mi("{H_{i+1}/H_i}")#text(" for ")#mi("{j > \\sigma(i)}")#text(".")

#text("Now we claim that ")#mi("{\\sigma}")#text(" is a bijection. Suppose this is not the case. Since ")#mi("{n \\leq m}")#text(", there thus exists ")#mi("{j \\in \\{0,\\ldots,m-1\\}}")#text(" which is not in the range of ")#mi("{\\sigma}")#text(". This implies that ")#mi("{A^{(i)}_j = A^{(i)}_{j+1}}")#text(" for all ")#mi("{i}")#text(". An induction on ")#mi("{i}")#text(" then shows that ")#mi("{H_i \\cap K_j = H_i \\cap K_{j+1}}")#text(" for all ")#mi("{i}")#text(", and thus ")#mi("{K_j = K_{j+1}}")#text(", contradicting the assumption that ")#mi("{K_{j+1}/K_j}")#text(" is simple.")

#text("Finally, fix ")#mi("{i_0 \\in \\{0,\\ldots,n-1\\}}")#text(", and let ")#mi("{j_0 := \\sigma(i_0)}")#text(". Then we have ")#mi("{A^{(i)}_{j_0} = A^{(i)}_{j_0+1}}")#text(" for all ")#mi("{i \\neq i_0}")#text(", while ")#mi("{A^{(i_0)}_{j_0} = \\{1\\}}")#text(" and ")#mi("{A^{(i_0)}_{j_0+1} \\equiv H_{i_0+1}/H_{i_0}}")#text(". From this and induction we see that ")#mi("{(H_i \\cap K_{j_0+1})/(H_i \\cap K_{j_0})}")#text(" is trivial for ")#mi("{i \\leq i_0}")#text(" but isomorphic to ")#mi("{H_{i_0+1}/H_{i_0}}")#text(" for ")#mi("{i>i_0}")#text(". (Here we are basically relying on a special case of the ")#link("http://en.wikipedia.org/wiki/Zassenhaus_lemma")[#text("Zassenhaus lemma")]#text(".) In particular, ")#mi("{K_{j_0+1}/K_{j_0}}")#text(" is isomorphic to ")#mi("{H_{i_0+1}/H_{i_0}}")#text(", and the claim follows. ")#mi("\\Box")

#text("In view of this theorem, we can assign to each finite group a set (or more precisely, ")#link("http://en.wikipedia.org/wiki/Multiset")[#text("multiset")]#text(") of composition factors of simple groups, which are unique up to permutation and isomorphism. This is somewhat analogous to how the fundamental theorem of arithmetic assigns to each positive integer a multiset of prime numbers, which are unique up to permutation. (Indeed, the latter can be viewed as the special case of the former in the case of cyclic groups.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" ")#metadata(none) <tao-343cb40628bfd83d695c>#text(" Show that for ")#mi("{p \\geq 5}")#text(" a prime, the composition factors of ")#mi("{SL_2(F_p)}")#text(" are (up to isomorphism and permutation) the cyclic group ")#mi("{{\\bf Z}/2{\\bf Z}}")#text(" and the projective special linear group ")#mi("{PSL_2(F_p)}")#text(". What happens instead when ")#mi("{p = 2}")#text(" or ")#mi("{p=3}")#text("?")

#text("Also, show that the only normal subgroup of ")#mi("{SL_2(F_p)}")#text(" (other than the trivial group and all of ")#mi("{SL_2(F_p)}")#text(") is the center ")#mi("{Z(SL_2(F_p))\\equiv {\\bf Z}/2{\\bf Z}}")#text(" of the group. Thus, we see (in contrast with the fundamental theorem of arithmetic) that one cannot permute the composition factors arbitrarily.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" ")#metadata(none) <tao-fc6a3d0fff933962afcc>#text(" Let ")#mi("{N}")#text(" be a normal subgroup of a finite group ")#mi("{G}")#text(". Show that the set of composition factors of ")#mi("{G}")#text(" is equal to (up to isomorphism, and counting multiplicity) the union of the set of composition factors of ")#mi("{N}")#text(", and the set of composition factors of ")#mi("{G/N}")#text(". In particular, the set of composition factors of ")#mi("{N}")#text(" and of ")#mi("{G/N}")#text(" are subsets of the set of composition factors of ")#mi("{G}")#text(" (again up to isomorphism, and counting multiplicity). As another corollary, we see that the composition factors of a direct product ")#mi("{G \\times H}")#text(" or semidirect product ")#mi("{G \\ltimes H}")#text(" of two finite groups ")#mi("{G, H}")#text(" is the union of the set of composition factors of ")#mi("{G}")#text(" and ")#mi("{H}")#text(" separately (again up to isomorphism, and counting multiplicity).")
]

#text("Knowing the composition factors of a group can assist in classifying its subgroups; in particular, groups which are “coprime” in the sense of having no composition factors in common are difficult to “join” together. (Interestingly, the phenomenon of “coprimality” implying “disjointness” also shows up in ergodic theory, in the theory of joinings, but we will not discuss this further here.) Here is an example of this which will be of importance in our application:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4")]#text(" ")#metadata(none) <tao-5b2a59135929d8d60263>#text(" Let ")#mi("{p \\geq 5}")#text(" be a prime, and ")#mi("{G}")#text(" be a finite group which does not have a copy of ")#mi("{PSL_2(F_p)}")#text(" amongst its composition factors. Let ")#mi("{H}")#text(" be a subgroup of ")#mi("{G \\times SL_2(F_p)}")#text(" whose projections to ")#mi("{G}")#text(" and ")#mi("{SL_2(F_p)}")#text(" are surjective. Then ")#mi("{H}")#text(" is all of ")#mi("{G \\times SL_2(F_p)}")#text(".")
]

#emph[#text("Proof:")]#text(" We apply ")#link("http://en.wikipedia.org/wiki/Goursat's_lemma")[#text("Goursat’s lemma")]#text(" (see Exercise ")#link(<tao-2622d2f670c77ec5dc69>)[#text("9")]#text(" below). Thus if ")#mi("{N_1 := \\{ g \\in G: (g,1) \\in H\\}}")#text(" and ")#mi("{N_2 := \\{ h \\in SL_2(F_p): (1,h) \\in H \\}}")#text(", then ")#mi("{N_1,N_2}")#text(" are normal subgroups of ")#mi("{G, SL_2(F_p)}")#text(" respectively such that ")#mi("{G/N_1}")#text(" is isomorphic to ")#mi("{SL_2(F_p)/N_2}")#text(". From Exercise ")#link(<tao-343cb40628bfd83d695c>)[#text("7")]#text(" we see that ")#mi("{N_2}")#text(" is either trivial, all of ")#mi("{SL_2(F_p)}")#text(", or is the center ")#mi("{Z(SL_2(F_p))}")#text(".")

#text("If ")#mi("{N_2}")#text(" is trivial, then ")#mi("{SL_2(F_p)}")#text(" is isomorphic to a quotient of ")#mi("{G}")#text(", and thus by Exercise ")#link(<tao-fc6a3d0fff933962afcc>)[#text("8")]#text(" the composition factors of ")#mi("{SL_2(F_p)}")#text(" are a subset of those of ")#mi("{G}")#text(". But this is a contradiction, since ")#mi("{PSL_2(F_p)}")#text(" is a composition factor of ")#mi("{SL_2(F_p)}")#text(" but not of ")#mi("{G}")#text(". Similarly if ")#mi("{N_2}")#text(" is the center, since ")#mi("{SL_2(F_p)/N_2}")#text(" is then isomorphic to ")#mi("{PSL_2(F_p)}")#text(". So the only remaining case is when ")#mi("{N_2}")#text(" is all of ")#mi("{SL_2(F_p)}")#text(". But then as ")#mi("{H}")#text(" surjects onto ")#mi("{G}")#text(", we see that ")#mi("{H}")#text(" is all of ")#mi("{G \\times SL_2(F_p)}")#text(" and we are done. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9 (Goursat’s lemma)")]#text(" ")#metadata(none) <tao-2622d2f670c77ec5dc69>#text(" Let ")#mi("{G_1,G_2}")#text(" be groups, and let ")#mi("{H}")#text(" be a subgroup of ")#mi("{G_1 \\times G_2}")#text(" whose projections to ")#mi("{G_1,G_2}")#text(" are surjective. Let ")#mi("{N_1 := \\{ g_1 \\in G_1: (g_1,1) \\in H \\}}")#text(" and ")#mi("{N_2 := \\{ g_2 \\in G_2: (1,g_2) \\in H \\}}")#text(". Show that ")#mi("{N_1,N_2}")#text(" are normal subgroups of ")#mi("{G_1,G_2}")#text(", and that ")#mi("{G_1/N_1}")#text(" and ")#mi("{G_2/N_2}")#text(" are isomorphic. (Indeed, after quotienting out by ")#mi("{N_1 \\times N_2}")#text(", ")#mi("{H}")#text(" becomes a graph of such an isomorphism.) Conclude that the set of composition factors of ")#mi("{H}")#text(" are a subset of the union of the set of composition factors of ")#mi("{G_1}")#text(" and the set of composition factors of ")#mi("{G_2}")#text(" (up to isomorphism and counting multiplicity, as usual).")
]

#text("As such, we have the following satisfactory description of the images ")#mi("{\\pi_q(\\Gamma)}")#text(" of a free group ")#mi("{\\Gamma}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 5 (Strong approximation)")]#text(" ")#metadata(none) <tao-c04cbf03d2eb78483333>#text(" Let ")#mi("{\\Gamma}")#text(" be a subgroup of ")#mi("{SL_2({\\bf Z})}")#text(" which is not virtually solvable. Let ")#mi("{M \\geq 1}")#text(" be an integer. Then there exists a multiple ")#mi("{q_1}")#text(" of ")#mi("{M}")#text(" with the following property: whenever ")#mi("{q}")#text(" is of the form ")#mi("{q = d p_1 \\ldots p_k}")#text(" with ")#mi("{d|q_1}")#text(" and ")#mi("{p_1,\\ldots,p_k}")#text(" distinct and coprime to ")#mi("{q_1}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\pi_q(\\Gamma) = \\pi_d(\\Gamma) \\times SL_2(F_{p_1}) \\times \\ldots\\times SL_2(F_{p_k})")]]

#text("(after using the Chinese remainder theorem to identify ")#mi("{SL_2(F_q)}")#text(" with ")#mi("{SL_2(F_d) \\times SL_2(F_{p_1}) \\times \\ldots \\times SL_2(F_{p_k})}")#text("). In particular, one has")

#align(center)[#tao-fit-display[#mitex("\\pi_q(\\Gamma) = \\pi_d(\\Gamma) \\times SL_2({\\bf Z}/p_1\\ldots p_k{\\bf Z}).")]]
]

#text("The parameter ")#mi("{M}")#text(" will not actually be needed in our application, but is useful in the more general setting in which ")#mi("{f}")#text(" has rational coefficients instead of integer coefficients.")

#emph[#text("Proof:")]#text(" We already know that ")#mi("{\\pi_p(\\Gamma)= SL_2(F_p)}")#text(" for all but finitely many primes ")#mi("{p}")#text(". Let ")#mi("{q_0}")#text(" be the product of ")#mi("{M}")#text(" with all the eceptional primes, as well as ")#mi("{2}")#text(" and ")#mi("{3}")#text(", thus ")#mi("{p \\geq 5}")#text(" and ")#mi("{\\pi_p(\\Gamma)= SL_2(F_p)}")#text(" for all ")#mi("{p}")#text(" coprime to ")#mi("{q_0}")#text(". By repeated application of Lemma ")#link(<tao-5b2a59135929d8d60263>)[#text("4")]#text(" this implies that ")#mi("{\\pi_{p_1 \\ldots p_k}(\\Gamma) = SL_2(F_{p_1}) \\times \\ldots \\times SL_2(F_{p_k})}")#text(" for any distinct primes ")#mi("{p_1,\\ldots,p_k}")#text(" coprime to ")#mi("{q_0}")#text(" (the key point being that the groups ")#mi("{PSL_2(F_p)}")#text(" for primes ")#mi("{p \\geq 5}")#text(" are all non-isomorphic to each other and to ")#mi("{{\\bf Z}/2{\\bf Z}}")#text(" by cardinality considerations).")

#text("The finite group ")#mi("{\\pi_{q_0}(\\Gamma)}")#text(" may contain copies of ")#mi("{PSL_2(F_p)}")#text(" amongst their composition factors for a finite number of primes ")#mi("{p}")#text(" coprime to ")#mi("{q_0}")#text("; let ")#mi("{q_1}")#text(" be the product of ")#mi("{q_0}")#text(" with all these primes. By many applications of Exercise ")#link(<tao-2622d2f670c77ec5dc69>)[#text("9")]#text(", we see that the set of composition factors of ")#mi("{\\pi_{q_1}(\\Gamma)}")#text(" are contained in the union of the set of composition factors of ")#mi("{\\pi_{q_0}(\\Gamma)}")#text(", and the set of composition factors of ")#mi("{\\pi_p(\\Gamma) = SL_2(F_p)}")#text(" for all ")#mi("{p}")#text(" dividing ")#mi("{q_1}")#text(" but not ")#mi("{q_0}")#text(". As a consequence, we see that ")#mi("{PSL_2(F_p)}")#text(" is ")#emph[#text("not")]#text(" a composition factor of ")#mi("{\\pi_{q_1}(\\Gamma)}")#text(" for any ")#mi("{p}")#text(" coprime to ")#mi("{q_1}")#text("; by Exercise ")#link(<tao-fc6a3d0fff933962afcc>)[#text("8")]#text(", ")#mi("{PSL_2(F_p)}")#text(" is also not a composition factor of ")#mi("{\\pi_d(\\Gamma)}")#text(" for any ")#mi("{d}")#text(" dividing ")#mi("{q_1}")#text(" and ")#mi("{p}")#text(" coprime to ")#mi("{q_1}")#text(". By many applications of Lemma ")#link(<tao-5b2a59135929d8d60263>)[#text("4")]#text(", we then obtain the claim. ")#mi("\\Box")

#text("As a simple application of the above corollary, we observe that we may reduce Theorem ")#link(<tao-20df97752cefa9847776>)[#text("1")]#text(" to the case when ")#mi("{\\Lambda}")#text(" is a free group on two generators. Indeed, if ")#mi("{\\Lambda}")#text(" is not virtually solvable, then by the ")#link("http://en.wikipedia.org/wiki/Tits_alternative")[#text("Tits alternative")]#text(" (Theorem 5 from ")#link("https://terrytao.wordpress.com/2012/02/13/254b-notes-6-non-concentration-in-subgroups/")[#text("Notes 6")]#text("), ")#mi("{\\Lambda}")#text(" contains a subgroup ")#mi("{\\Lambda^{\\prime}}")#text(" which is a free group on two generators (and in particular, continues to not be virtually solvable). Now the polynomial ")#mi("{f}")#text(" need not be primitive on ")#mi("{\\Lambda^{\\prime}}")#text(", so we cannot deduce Theorem ")#link(<tao-20df97752cefa9847776>)[#text("1")]#text(" for ")#mi("{\\Lambda,f}")#text(" from its counterpart for ")#mi("{\\Lambda^{\\prime},f}")#text(". However, by Corollary ")#link(<tao-c04cbf03d2eb78483333>)[#text("5")]#text(" we have an integer ")#mi("{q_1 \\geq 1}")#text(" such that ")#metadata(none) <tao-0266e7e7128f859e5906>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\pi_q(\\Gamma^{\\prime}) = \\pi_d(\\Gamma^{\\prime}) \\times SL_2({\\bf Z}/p_1\\ldots p_k{\\bf Z})")]]

#text("whenever ")#mi("{q=dp_1\\ldots p_k}")#text(" with ")#mi("{d|q_1}")#text(" and ")#mi("{p_1,\\ldots,p_k}")#text(" are distinct primes coprime to ")#mi("{q_1}")#text(".")

#text("As ")#mi("{f}")#text(" is primitive with respect to ")#mi("{\\Lambda}")#text(", we may find ")#mi("{a \\in \\Gamma}")#text(" such that ")#mi("{f(a)}")#text(" is coprime to ")#mi("{q_1}")#text(". By translating ")#mi("{f}")#text(" by ")#mi("{a}")#text(", we obtain a new polynomial ")#mi("{f^{\\prime}}")#text(" for which ")#mi("{f^{\\prime}(1)}")#text(" is coprime to ")#mi("{q_1}")#text(". In particular, for any ")#mi("{d|q_1}")#text(", we have ")#mi("{f^{\\prime}(1)}")#text(" coprime to ")#mi("{d}")#text(". By ")#link(<tao-0266e7e7128f859e5906>)[#text("(17)")]#text(", this implies that for any square-free ")#mi("{q}")#text(" (and hence for arbitrary ")#mi("{q}")#text("), we can find ")#mi("{a \\in \\Gamma^{\\prime}}")#text(" with ")#mi("{f^{\\prime}(a)}")#text(" coprime to ")#mi("{q}")#text(". Thus ")#mi("{f^{\\prime}}")#text(" is primitive with respect to ")#mi("{\\Lambda^{\\prime}}")#text(", and so we may deduce Theorem ")#link(<tao-20df97752cefa9847776>)[#text("1")]#text(" for ")#mi("{\\Lambda,f}")#text(" from its counterpart for ")#mi("{\\Lambda^{\\prime},f^{\\prime}}")#text(".")

#heading(level: 1)[#strong[#text(" — 3. Sieving in thin groups — ")]]

#text("We can now deduce Theorem ")#link(<tao-20df97752cefa9847776>)[#text("1")]#text(" from the following expander result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Uniform expansion)")]#text(" ")#metadata(none) <tao-04441957fa510f1089b9>#text(" Let ")#mi("{a,b}")#text(" generate a free group ")#mi("{\\Lambda}")#text(" in ")#mi("{SL_2({\\bf Z})}")#text(". Then, as ")#mi("{q}")#text(" runs through the square-free integers, ")#mi("{Cay(\\pi_q(\\Lambda), \\pi_q(\\{a,b,a^{-1},b^{-1}\\}))}")#text(" form a two-sided expander family.")
]

#text("When ")#mi("{q}")#text(" is restricted to be prime, this result follows from Theorem 3 from ")#link("https://terrytao.wordpress.com/2012/02/13/254b-notes-6-non-concentration-in-subgroups/")[#text("Notes 6")]#text(". The extension of this theorem to non-prime ")#mi("{q}")#text(" is more difficult, and will be discussed later. For now, let us assume Theorem ")#link(<tao-04441957fa510f1089b9>)[#text("6")]#text(" and see how we can use it, together with the beta sieve, to imply Theorem ")#link(<tao-20df97752cefa9847776>)[#text("1")]#text(".")

#text("As discussed in the preceding section, to show Theorem ")#link(<tao-20df97752cefa9847776>)[#text("1")]#text(" we may assume without loss of generality that ")#mi("{\\Lambda}")#text(" is a free group on two generators ")#mi("{a,b}")#text(". Let ")#mi("{\\mu := \\frac{1}{4} (\\delta_a +\\delta_b+\\delta_{a^{-1}}+\\delta_{b^{-1}})}")#text(" be the generator of the associated random walk, and let ")#mi("{T}")#text(" be a large integer. Then ")#mi("{\\mu^{(T)}}")#text(" will be supported on elements of ")#mi("{\\Lambda}")#text(" whose coefficients have size ")#mi("{O(\\exp(O(T)))}")#text(", where we allow implied constants to depend on ")#mi("{a,b}")#text(". In particular, for ")#mi("{x}")#text(" in this support, ")#mi("{f(x)}")#text(" will be an integer of size ")#mi("{O(\\exp(O(T)))}")#text(", where we allow implied constants to depend on ")#mi("{f}")#text(" also. On the other hand, ")#mi("{\\mu^{(T)}}")#text(" has an ")#mi("{\\ell^\\infty}")#text(" norm that decreases exponentially in ")#mi("{T}")#text(" (by Exercise 6 of ")#link("https://terrytao.wordpress.com/2012/02/13/254b-notes-6-non-concentration-in-subgroups/")[#text("Notes 6")]#text("). If we then set ")#mi("{z := \\exp(\\epsilon^{\\prime} T)}")#text(" for a sufficiently small absolute constant ")#mi("{\\epsilon^{\\prime}>0}")#text(", it will then suffice to show that with probability ")#mi("{\\gg T^{-O(1)}}")#text(", an element ")#mi("{x}")#text(" drawn from ")#mi("{\\Lambda}")#text(" with distribution ")#mi("{\\mu^{(T)}}")#text(" is such that ")#mi("{f(x)}")#text(" is non-zero and coprime to ")#mi("{P(z)}")#text(".")

#text("It will be convenient to knock out a few exceptional primes. From Corollary ")#link(<tao-c04cbf03d2eb78483333>)[#text("5")]#text(", we may find an integer ")#mi("{q_1}")#text(" with the property that")

#align(center)[#tao-fit-display[#mitex("\\pi_q(\\Gamma) = \\pi_d(\\Gamma) \\times SL_2(F_{p_1}) \\times \\ldots\\times SL_2(F_{p_k})")]]

#text("whenever ")#mi("{q = d p_1 \\ldots p_k}")#text(" with ")#mi("{d|q_1}")#text(" and ")#mi("{p_1,\\ldots,p_k}")#text(" distinct and coprime to ")#mi("{q_1}")#text(". As ")#mi("{f}")#text(" is primitive, we may find a residue class ")#mi("{x_1 \\in \\pi_{q_1}(\\Gamma)}")#text(" such that ")#mi("{f(x_1)}")#text(" is coprime to ")#mi("{q_1}")#text(". For each integer ")#mi("{n}")#text(", let ")#mi("{a_n}")#text(" denote the quantity")

#align(center)[#tao-fit-display[#mitex("a_n := \\sum_{x \\in \\Lambda: f(x)=n; x = x_1 \\mod q_1} \\mu^{(T)}(x).")]]

#text("It will suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n: (n,P(z))=1} a_n \\gg T^{-O(1)}.")]]

#text("To do this, we will use the beta sieve. Indeed, by Exercise ")#link(<tao-20c1509e7e444092b3ce>)[#text("2")]#text(" it suffices to establish a bound of the form ")#metadata(none) <tao-8910f9ec7a13ccb6fcad>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\sum_{n: d|n} a_n = \\frac{1}{\\left|\\pi_{q_1}(\\Lambda)\\right|} g(d) + O( \\exp(-\\epsilon T) )", block: true)]]

#text("for all square-free ")#mi("{1 \\leq d \\leq \\exp(\\epsilon T)}")#text(", some constant ")#mi("{\\epsilon>0}")#text(", and some multiplicative function ")#mi("{g}")#text(" obeying the bounds")

#align(center)[#tao-fit-display[#mitex("g(p)<1")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("g(p) \\ll 1/p")]]

#text("for all primes ")#mi("{p}")#text(".")

#text("By choice of ")#mi("{x_1}")#text(", the quantity ")#mi("{a_n}")#text(" vanishes whenever ")#mi("{n}")#text(" is not coprime to ")#mi("{q_1}")#text(". So we will set ")#mi("{g(p)=0}")#text(" for the primes ")#mi("{p}")#text(" dividing ")#mi("{q_1}")#text(", and it will suffice to establish ")#link(<tao-8910f9ec7a13ccb6fcad>)[#text("(18)")]#text(" for ")#mi("{d}")#text(" coprime to ")#mi("{q_1}")#text(". The left-hand side of ")#link(<tao-8910f9ec7a13ccb6fcad>)[#text("(18)")]#text(" can then be expressed as")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\in \\pi_d(\\Lambda): f(x)=0} ((\\pi_{q_1 d})_* \\mu)^{(T)}(x_1,x),")]]

#text("where we descend the polynomial ")#mi("{f: SL_2({\\bf Z}) \\rightarrow {\\bf Z}}")#text(" to a polynomial ")#mi("{f: SL_2({\\bf Z}/d{\\bf Z}) \\rightarrow {\\bf Z}/d{\\bf Z}}")#text(" in the obvious fashion. However, in view of Theorem ")#link(<tao-04441957fa510f1089b9>)[#text("6")]#text(" (and the random walk interpretation of expansion), we have")

#align(center)[#tao-fit-display[#tao-math("((\\pi_{q_1 d})_* \\mu)^{(T)}(x) = \\left|\\pi_{q_1 d}(\\Lambda)\\right|^{-1} + O( \\exp(-cT) )", block: true)]]

#text("for some ")#mi("{c>0}")#text(" independent of ")#mi("{\\epsilon}")#text(". Note that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\pi_d(\\Lambda)\\right| \\leq \\left|SL_2({\\bf Z}/d{\\bf Z})\\right| \\ll d^{O(1)} \\ll \\exp(O(\\epsilon T))", block: true)]]

#text("while from Corollary ")#link(<tao-c04cbf03d2eb78483333>)[#text("5")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\pi_{q_1 d}(\\Lambda)\\right| = \\left|\\pi_{q_1}(\\Lambda)\\right| \\left|\\pi_d(\\Lambda)\\right|", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n: d|n} a_n = \\frac{1}{\\left|\\pi_{q_1}(\\Lambda)\\right|} g(d) + O( \\exp(-\\epsilon T) )", block: true)]]

#text("for ")#mi("{\\epsilon>0}")#text(" small enough, where ")#mi("{g(d)}")#text(" is defined for ")#mi("{d}")#text(" coprime to ")#mi("{q_1}")#text(" as")

#align(center)[#tao-fit-display[#tao-math("g(d) := \\frac{1}{\\left|\\pi_d(\\Gamma)\\right|} |\\{ x \\in SL_2({\\bf Z}/d{\\bf Z}): f(x)=0 \\}|.", block: true)]]

#text("As ")#mi("{f}")#text(" is primitive, we have ")#mi("{g(d)<1}")#text(" for all such ")#mi("{d}")#text("; from Corollary ")#link(<tao-c04cbf03d2eb78483333>)[#text("5")]#text(" we see that ")#mi("{g}")#text(" is multiplicative for such ")#mi("{d}")#text(". Finally, from the Schwarz-Zippel lemma (see Exercise 23 from ")#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/")[#text("Notes 5")]#text(") we have")

#align(center)[#tao-fit-display[#mitex("g(p) \\ll 1/p")]]

#text("and Theorem ")#link(<tao-20df97752cefa9847776>)[#text("1")]#text(" follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" One can obtain more precise bounds on ")#mi("{g(p)}")#text(" using the ")#link("http://www.ams.org/mathscinet-getitem?mr=65218")[#text("Lang-Weil theorem")]#text(", but we will not need this result here. (Such results would however be needed if one wanted more quantitative information than Theorem ")#link(<tao-20df97752cefa9847776>)[#text("1")]#text("; see ")#link("http://www.ams.org/mathscinet-getitem?mr=2587341")[#text("the paper of Bourgain, Gamburd, and Sarnak")]#text(" for details.)")
]

#text("It remains to establish Theorem ")#link(<tao-20df97752cefa9847776>)[#text("1")]#text(". In the case when ")#mi("{q}")#text(" is prime, this was achieved in previous sections using the ingredients of quasirandomness, product theorems, and non-concentration. In the ")#link("http://www.ams.org/mathscinet-getitem?mr=2587341")[#text("original paper of Bourgain, Gamburd, and Sarnak")]#text(", these ingredients were extendedto the square-free case by hand, which led to a fairly lengthy argument. In the subsequent ")#link("http://arxiv.org/abs/1001.3664")[#text("paper of Varju")]#text(", it was shown that each of these ingredients can in fact be more or less automatically bootstrapped from the prime case to the square-free case by using tools such as the Chinese remainder theorem (or strong approximation) to “factor” the latter case into copies of the former, thus simplifying the extension to the square-free case significantly. We will not give the full argument here, but just to convey a taste of these sorts of product arguments, we will discuss the product structure of just one of the three ingredients, namely quasirandomness. (The extension of this ingredient to the square-free setting was already observed in the ")#link("http://www.ams.org/mathscinet-getitem?mr=2587341")[#text("Bourgain-Gamburd-Sarnak paper")]#text(".)")

#text("As a consequence of Proposition 4 of ")#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/")[#text("Notes 3")]#text(", the following claim was shown:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7")]#text(" ")#metadata(none) <tao-441e18787253482a21d4>#text(" Let ")#mi("{G}")#text(" be a ")#tao-math("{\\left|G\\right|^\\alpha}", block: false)#text("-quasirandom finite group, ")#mi("{S}")#text(" is a symmetric set of generators of ")#mi("{G}")#text(" not containing the identity of cardinality ")#mi("{k}")#text(", and ")#tao-math("{\\mu = \\frac{1}{\\left|S\\right|} \\sum_{s \\in S} \\delta_s}", block: false)#text(" be such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mu^{*n} \\right\\|_{\\ell^2(G)} \\leq \\left|G\\right|^{-1/2+\\alpha/4}", block: true)]]

#text("(say) for some ")#tao-math("{n = O(\\log \\left|G\\right|)}", block: false)#text(" with ")#tao-math("{\\mu := \\frac{1}{\\left|S\\right|} \\sum_{s \\in S} \\delta_s}", block: false)#text(", then ")#mi("{Cay(G,S)}")#text(" is a two-sided ")#mi("{\\epsilon}")#text("-expander for some ")#mi("{\\epsilon}")#text(" depending only on ")#mi("{\\alpha, k}")#text(" and the implied constants in the ")#mi("{O()}")#text(" notation.")
]

#text("It turns out that this fact can be extended to product groups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8")]#text(" Proposition ")#link(<tao-441e18787253482a21d4>)[#text("7")]#text(" continues to hold if the hypothesis that ")#mi("{G}")#text(" is ")#tao-math("{\\left|G\\right|^\\alpha}", block: false)#text("-quasirandom is replaced with the hypothesis that ")#mi("{G = G_1 \\times \\ldots \\times G_n}")#text(" for some ")#mi("{n \\geq 0}")#text(" and some finite groups ")#mi("{G_1,\\ldots,G_n}")#text(", with each ")#mi("{G_i}")#text(" being ")#tao-math("{\\left|G_i\\right|^\\alpha}", block: false)#text("-quasirandom.")
]

#text("The key point here is that the expansion constant ")#mi("{\\epsilon}")#text(" does not depend on the number ")#mi("{n}")#text(" of groups in this factorisation.")

#emph[#text("Proof:")]#text(" (Sketch) For technical reasons it is convenient to allow ")#mi("{S}")#text(" to have multiplicity and to possibly contain the identity; this will require generalising the notion of Cayley graph, and of expansion in such generalised graphs.")

#text("Let ")#mi("{f}")#text(" be a non-constant eigenfunction of the adjacency operator, thus ")#mi("{f * \\mu = \\lambda f}")#text(" for some real ")#mi("{\\lambda}")#text(". The objective is to prove that ")#tao-math("{\\left|\\lambda\\right| \\leq 1-\\epsilon}", block: false)#text(" for some sufficiently small ")#mi("{\\epsilon>0}")#text(" independent of ")#mi("{n}")#text(".")

#text("The claim ")#mi("{n=0}")#text(" is trivial, so assume inductively that ")#mi("{n \\geq 1}")#text(" and that the claim is proven for all smaller values of ")#mi("{n}")#text(" (with a fixed choice of ")#mi("{\\epsilon}")#text("). For each ")#mi("{G_i}")#text(", we can partition the eigenspaces of the adjacency operator into those functions which are invariant in the ")#mi("{G_i}")#text(" direction, and those functions which have mean zero in each coset of ")#mi("{G_i}")#text(". These partitions are compatible with each other as ")#mi("{i}")#text(" varies (basically because the operations of averaging in ")#mi("{G_i}")#text(" and averaging in ")#mi("{G_j}")#text(" commute). Thus, without loss of generality, we may assume that the eigenfunction ")#mi("{f}")#text(" is such that for each ")#mi("{i}")#text(", either ")#mi("{f}")#text(" is ")#mi("{G_i}")#text("-invariant, or has mean zero on each ")#mi("{G_i}")#text(" coset.")

#text("Suppose that ")#mi("{f}")#text(" was ")#mi("{G_n}")#text("-invariant, then the eigenvalue ")#mi("{\\lambda}")#text(" would also persist after projecting ")#mi("{S}")#text(" down from ")#mi("{G}")#text(" to ")#mi("{G_1 \\times G_{n-1}}")#text(" (possibly picking up the identity or some multiplicity in the process). The claim then follows from the induction hyopthesis. Similarly if ")#mi("{f}")#text(" was ")#mi("{G_i}")#text("-invariant for any other value of ")#mi("{i}")#text(". Thus we may assume that ")#mi("{f}")#text(" has mean zero in each ")#mi("{G_i}")#text(" coset.")

#text("One can show that every irreducible unitary representation of ")#mi("{G}")#text(" splits as a tensor product of irreducible unitary representations of the ")#mi("{G_i}")#text(". If one lets ")#mi("{V}")#text(" be the subspace of ")#mi("{\\ell^2(G)}")#text(" spanned by ")#mi("{f}")#text(" and its left translates, we thus see that ")#mi("{V}")#text(" contains at least one such tensor product; but as every element of ")#mi("{V}")#text(" will have mean zero in each ")#mi("{G_i}")#text(" coset, the factors in this tensor product will all be non-trivial. Using quasirandomness, the ")#mi("{i^{th}}")#text(" factor will have dimension at least ")#tao-math("{\\left|G_i\\right|^\\alpha}", block: false)#text(", and so ")#mi("{V}")#text(" must have dimension at least ")#tao-math("{\\left|G\\right|^\\alpha}", block: false)#text(". At this point, one can use a trace formula to relate ")#mi("{V}")#text(" to ")#tao-math("{\\left\\|\\mu^{*n}\\right\\|_{\\ell^2(G)}^2}", block: false)#text(" to conclude the argument. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Develop the above sketch into a complete proof of the proposition.")
]

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/989412513299ae06f797d0e3081ededeee670518489d28bb033a2d30bc9b624e-be16ffe6b0234a4ec6f566872952f9b269df55e496d300091bd2c49b0e3864b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon")]], [#link("https://terrytao.wordpress.com/2012/03/01/254b-notes-7-sieving-and-expanders/#comment-131151")[#strong[#text("Jon")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2012")])]

#text("A very interesting topic, thank you for these notes!")#linebreak()#text(" An easy typo: in section 1, when introducing ")#mi("P(z)")#text(" you correctly link to the primorial, but instead of using the word “primorial” in your sentence there’s a URL for the PNT (which perhaps you wanted to use in the previous paragraph, which mentions it without a link).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/03/01/254b-notes-7-sieving-and-expanders/#comment-131153")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2012")])]

#text("Small typo: in the second paragraph, I think you want")#linebreak()#text(" \\{ (n_1,n_2) \\in \\mathbf{Z}^2 : n_2 – n_1 = 2\\}, not")#linebreak()#text(" \\{ (n_1,n_2) \\in \\mathbf{Z} : n_2 – n_1 = 2\\}")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2012/03/01/254b-notes-7-sieving-and-expanders/#comment-131500")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2012")])]

#text("Small typo – definition of Fermat number is missing a 2 in the stack of exponentials: 2^n instead of 2^2^n.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2012/03/01/254b-notes-7-sieving-and-expanders/#comment-131551")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2012")])]

#text("Terry, I think the the work of Varju was a more fundamental advance than you make out. The paper of Bourgain, Gamburd and Sarnak went into the inner workings of Helfgott’s paper and did everything with ")#mi("q")#text(" instead of ")#mi("p")#text(". That was quite painful, because of the need for a satisfactory sum-product theory for ")#mi("Z/qZ")#text(". By contrast Varju took Helfgott’s conclusion for ")#mi("SL_2(Z/pZ)")#text(" as a black box; his argument works for ")#mi("G(Z/pZ)")#text(", for any semisimple ")#mi("G")#text(". Nice post!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/03/01/254b-notes-7-sieving-and-expanders/#comment-131633")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2012")])]

#text("Fair enough; I edited the post accordingly. On the one hand, B-G-S already had the clean “Cartesian” approach to quasirandomness and non-concentration in their original paper, but the Cartesian approach to the product theorem (which is certainly the most difficult of the three ingredients to obtain) is clearly Varju’s contribution.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2012/03/01/254b-notes-7-sieving-and-expanders/#comment-131645")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2012")])]

#text("Professor Tao, small question to clarify your definition of “almost primes.”")

#text("Is 2 x 2 x 2 x 3 x 3 x 5 a 3-almost prime or a 6-almost prime?")

#text("Thanks,")

#text("Pete")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/03/01/254b-notes-7-sieving-and-expanders/#comment-131672")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2012")])]

#text("As stated in the main post, prime factors are being counted with multiplicity; thus, for instance, the number you mention is an r-almost prime for any ")#mi("r \\geq 6")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CE")]], [#link("https://terrytao.wordpress.com/2012/03/01/254b-notes-7-sieving-and-expanders/#comment-131697")[#strong[#text("CE")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2012")])]

#text("I think there is a typo: you mean: ")#mi("r \\geq 6")#text(".")#linebreak()#text(" (An 11-almost prime has at most 11 prime factors, so a number with 6 prime factors (with multiplicity) is an 11-almost prime).")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0fb56b7dcf10e8ccf92cde38c0dd3d10fdffc6b203174faeb49bb233699409b7-2ce7621580a9cecbda59675a22d1537a09d7fb6d7093b9ea289724ea339f688f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lew")]], [#link("https://terrytao.wordpress.com/2012/03/01/254b-notes-7-sieving-and-expanders/#comment-131984")[#strong[#text("Lew")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2012")])]

#text("The Landau conjecture mentioned (also attributed to Hardy & Littlewood) is possibly the “simplest” unsolved math problem, where “simplest” means shortest in first order number theory (using a suitable small set of symbols). See:")

#link("http://math.andrej.com/2006/11/04/are-small-sentences-of-peano-arithmetic-decidable/comment-page-1/")[#text("http://math.andrej.com/2006/11/04/are-small-sentences-of-peano-arithmetic-decidable/comment-page-1/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 4: Some sieve theory | What's new")]], [#link("https://terrytao.wordpress.com/2012/03/01/254b-notes-7-sieving-and-expanders/#comment-452122")[#strong[#text("254A, Notes 4: Some sieve theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2015")])]

#text("[…] theory of expander graphs (the latter arises in the recent theory of the affine sieve, discussed in this previous blog post). However, the sieve-theoretic tools developed in this post are not particularly sensitive to how a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da87e6971d472723c5320e567915782b17a0a6f3a7b77d257bf00bc0df3d93a7-2d9ebf36b3b42665bb549f067b7e88557c0cb0b1ecbc1c8609a55b4f000307f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Claudeh5")]], [#link("https://terrytao.wordpress.com/2012/03/01/254b-notes-7-sieving-and-expanders/#comment-479715")[#strong[#text("Claudeh5")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2017")])]

#text("Hello professor Tao,")#linebreak()#text(" I think there is a small typo in (6): the D_+ is in fact {\\mathcal D}_+")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/03/01/254b-notes-7-sieving-and-expanders/#comment-503877")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2018")])]

#text("Professor Tao, a small typo: in the 2nd there’s an extra n in number-theoretic.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66cd5a97d9dda25df46bd8922b0055249255d9831369e4946a661deb615a9840-71763a0988a9d8b71e0f546a1719a0db1bcdb45d42f73e6d61657b0c4ddfb1cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin Broughan")]], [#link("https://terrytao.wordpress.com/2012/03/01/254b-notes-7-sieving-and-expanders/#comment-517875")[#strong[#text("Kevin Broughan")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2019")])]

#text("Hi Prof Tao,")

#text("For the definition of r-almost prime should it be x^{1/r} rather than x^{1/(r+1)}: the given sufficient condition is p\\mid n\\implies p\\ge x^{1/r} so \\Omega(n)=s\\implies x\\ge n\\ge x^{s/r} so s\\le r ? or am I missing something!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/03/01/254b-notes-7-sieving-and-expanders/#comment-517896")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2019")])]

#text("You should use strict inequalities instead of non-strict inequalities here to gain an extra ")#mi("1")#text(" (the “integrality gap”). If ")#mi("n \\leq x")#text(" is the product of ")#mi("s")#text(" prime factors, each strictly larger than ")#mi("x^{\\frac{1}{r+1}}")#text(", then ")#mi("x \\geq n > x^{\\frac{s}{r+1}}")#text(", hence ")#mi("s < r+1")#text(", hence ")#mi("s \\leq r")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/565cc4f24ae487569bf8d1cf0238d083778cdbfb8c5ba67512f7f0d1545533de-6ce5f428bb2b46ca5191abfe64b463994560d6192dc62bdf0c71e08fa88b3976.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Limith")]], [#link("https://terrytao.wordpress.com/2012/03/01/254b-notes-7-sieving-and-expanders/#comment-672507")[#strong[#text("Limith")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2023")])]

#text("I don’t see how identity (10) holds with condition ")#mi("d|P(p_k)")#text(". In fact, the LHS of (10) becomes ")#mi("(-1)^k\\sum_{d^{\\prime}|\\frac{n}{p_1\\dots p_k}, d^{\\prime}|\\frac{P(z)}{p_1 \\dots p_k}}\\mu(d^{\\prime})")#text(". I don’t see how you obtain (10) unless ")#mi("p_1,\\dots ,p_k")#text(" are exactly the ")#mi("k")#text(" bigger primes appearing in ")#mi("P(z)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/03/01/254b-notes-7-sieving-and-expanders/#comment-672693")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2023")])]

#text("Thanks for pointing this out. The condition ")#mi("n=p_1 \\dots p_k")#text(" should be replaced by the more complicated condition that ")#mi("n = p_1 \\dots p_k m")#text(" where ")#mi("m")#text(" is coprime to ")#mi("P(k)")#text(". The main feature of this identity remains, namely that the right-hand side is non-negative for even ")#mi("k")#text(" and non-positive for odd ")#mi("k")#text(".")
]
]
