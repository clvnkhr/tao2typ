// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/
// Converted to Typst by tao2typ: "2026-10-14T15:19:59.020588+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Bi-invariant metrics of linear growth on the free group, II", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Bi-invariant metrics of linear growth on the free group, II")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 December 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/")[#text("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This post is a continuation of the ")#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/")[#text("previous post")]#text(", which has attracted a large number of comments. I’m recording here some calculations that arose from those comments (particularly those of Pace Nielsen, Lior Silberman, Tobias Fritz, and Apoorva Khare). Please feel free to either continue these calculations or to discuss other approaches to the problem, such as those mentioned in the remaining comments to the previous post.")

#text("Let ")#mi("{F_2}")#text(" be the free group on two generators ")#mi("{a,b}")#text(", and let ")#mi("{\\| \\|: F_2 \\rightarrow {\\bf R}^+}")#text(" be a quantity obeying the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| xy\\right\\| \\leq \\left\\|x \\right\\| + \\left\\|y\\right\\|", block: true)]]

#text("and the linear growth property")

#align(center)[#tao-fit-display[#tao-math("\\left\\| x^n \\right\\| = \\left|n\\right| \\left\\| x\\right\\|", block: true)]]

#text("for all ")#mi("{x,y \\in F_2}")#text(" and integers ")#mi("{n \\in {\\bf Z}}")#text("; this implies the conjugation invariance")

#align(center)[#tao-fit-display[#tao-math("\\left\\| y^{-1} x y \\right\\| = \\left\\|x\\right\\|", block: true)]]

#text("or equivalently")

#align(center)[#tao-fit-display[#tao-math("\\left\\| xy \\right\\| = \\left\\| yx\\right\\|", block: true)]]

#text("We consider inequalities of the form ")#metadata(none) <tao-87aaf606ddebb4099c78>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| xyx^{-1}y^{-1} \\right\\| \\leq \\alpha \\left\\|x\\right\\| + \\beta \\left\\| y\\right\\|", block: true)]]

#text("or ")#metadata(none) <tao-d5c401328d3bc60f858a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| xyx^{-2}y^{-1} \\right\\| \\leq \\gamma \\left\\|x\\right\\| + \\delta \\left\\| y\\right\\|", block: true)]]

#text("for various real numbers ")#mi("{\\alpha,\\beta,\\gamma,\\delta}")#text(". For instance, since")

#align(center)[#tao-fit-display[#tao-math("\\left\\| xyx^{-1}y^{-1} \\right\\| \\leq \\left\\| xyx^{-1}\\right\\| + \\left\\|y^{-1} \\right\\| = \\left\\|y\\right\\| + \\left\\|y\\right\\|", block: true)]]

#text("we have ")#link(<tao-87aaf606ddebb4099c78>)[#text("(1)")]#text(" for ")#mi("{(\\alpha,\\beta) = (2,0)}")#text(". We also have the following further relations:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]

#list(
[#text("(i) If ")#link(<tao-87aaf606ddebb4099c78>)[#text("(1)")]#text(" holds for ")#mi("{(\\alpha,\\beta)}")#text(", then it holds for ")#mi("{(\\beta,\\alpha)}")#text(".")],
[#text("(ii) If ")#link(<tao-87aaf606ddebb4099c78>)[#text("(1)")]#text(" holds for ")#mi("{(\\alpha,\\beta)}")#text(", then ")#link(<tao-d5c401328d3bc60f858a>)[#text("(2)")]#text(" holds for ")#mi("{(\\alpha+1, \\frac{\\beta}{2})}")#text(".")],
[#text("(iii) If ")#link(<tao-d5c401328d3bc60f858a>)[#text("(2)")]#text(" holds for ")#mi("{(\\gamma,\\delta)}")#text(", then ")#link(<tao-87aaf606ddebb4099c78>)[#text("(1)")]#text(" holds for ")#mi("{(\\frac{2\\gamma}{3}, \\frac{2\\delta}{3})}")#text(".")],
[#text("(iv) If ")#link(<tao-87aaf606ddebb4099c78>)[#text("(1)")]#text(" holds for ")#mi("{(\\alpha,\\beta)}")#text(" and ")#link(<tao-d5c401328d3bc60f858a>)[#text("(2)")]#text(" holds for ")#mi("{(\\gamma,\\delta)}")#text(", then ")#link(<tao-87aaf606ddebb4099c78>)[#text("(1)")]#text(" holds for ")#mi("{(\\frac{2\\alpha+1+\\gamma}{4}, \\frac{\\delta+\\beta}{4})}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" For (i) we simply observe that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| xyx^{-1} y^{-1} \\right\\| = \\left\\| (xyx^{-1} y^{-1})^{-1} \\right\\| = \\left\\| y^{-1} x^{-1} y x \\right\\| = \\left\\| y x y^{-1} x^{-1} \\right\\|.", block: true)]]

#text("For (ii), we calculate")

#tao-aligned(keep: true)[


#tao-math("\\left\\| xyx^{-2}y^{-1} \\right\\|  & = \\frac{1}{2}\\left\\| (xyx^{-2}y^{-1})^2 \\right\\|", block: true)



#tao-math(" & = \\frac{1}{2} \\left\\| (xyx^{-2}y^{-1} x) (yx^{-2} y^{-1}) \\right\\|", block: true)



#tao-math(" & \\leq \\frac{1}{2} (\\left\\| xyx^{-2}y^{-1} x\\right\\| + \\left\\|yx^{-2} y^{-1}\\right\\|)", block: true)



#tao-math(" & \\leq \\frac{1}{2} ( \\left\\| x^2 y x^{-2} y^{-1} \\right\\| + 2 \\left\\|x\\right\\| )", block: true)



#tao-math(" & \\leq \\frac{1}{2} ( 2 \\alpha \\left\\|x\\right\\| + \\beta \\left\\|y\\right\\| + 2 \\left\\|x\\right\\|)", block: true)
]

#text("giving the claim.")

#text("For (iii), we calculate")

#tao-aligned(keep: true)[


#tao-math("\\left\\| xyx^{-1}y^{-1}\\right\\|  & = \\frac{1}{3} \\left\\| (xyx^{-1}y^{-1})^3 \\right\\|", block: true)



#tao-math(" & = \\frac{1}{3} \\left\\| (xyx) (x^{-2} y^{-1} xy) (xyx)^{-1} (x^2 y x^{-1} y^{-1}) \\right\\|", block: true)



#tao-math(" & \\leq \\frac{1}{3} ( \\left\\| x^{-2} y^{-1} xy\\right\\| + \\left\\| x^2 y x^{-1} y^{-1}\\right\\| )", block: true)



#tao-math(" & = \\frac{1}{3} ( \\left\\| xy x^{-2} y^{-1} \\right\\| + \\left\\|x^{-1} y^{-1} x^2 y \\right\\| )", block: true)



#tao-math(" & \\leq \\frac{1}{3} ( \\gamma \\left\\|x\\right\\| + \\delta \\left\\|y\\right\\| + \\gamma \\left\\|x\\right\\| + \\delta \\left\\|y\\right\\|)", block: true)
]

#text("giving the claim.")

#text("For (iv), we calculate")

#tao-aligned(keep: false)[


#tao-math("\\left\\| xyx^{-1}y^{-1}\\right\\|  & = \\frac{1}{4} \\left\\| (xyx^{-1}y^{-1})^4 \\right\\|", block: true)



#tao-math(" & = \\frac{1}{4} \\left\\| (xy) (x^{-1} y^{-1} x) (y x^{-1} y^{-1}) (xyx^{-1}) (xy)^{-1} (x^2yx^{-1}y^{-1}) \\right\\|", block: true)



#tao-math(" & \\leq \\frac{1}{4} ( \\left\\| (x^{-1} y^{-1} x) (y x^{-1} y^{-1}) (xyx^{-1}) \\right\\| + \\left\\|x^2yx^{-1}y^{-1}\\right\\| )", block: true)



#tao-math(" & \\leq \\frac{1}{4} ( \\left\\|(y x^{-1} y^{-1}) (xy^{-1}x^{-1})(x^{-1} y x) \\right\\| + \\gamma \\left\\|x\\right\\| + \\delta \\left\\|y\\right\\|)", block: true)



#tao-math(" & \\leq \\frac{1}{4} ( \\left\\|x\\right\\| + \\left\\|(xy^{-1}x^{-1})(x^{-1} y x) \\right\\| + \\gamma \\left\\|x\\right\\| + \\delta \\left\\|y\\right\\|)", block: true)



#tao-math(" & = \\frac{1}{4} ( \\left\\|x\\right\\| + \\left\\|x^{-2} y x^2 y^{-1} \\right\\|+ \\gamma \\left\\|x\\right\\| + \\delta \\left\\|y\\right\\|)", block: true)



#tao-math(" & \\leq \\frac{1}{4} ( \\left\\|x\\right\\| + 2\\alpha \\left\\|x\\right\\| + \\beta \\left\\|y\\right\\| + \\gamma \\left\\|x\\right\\| + \\delta \\left\\|y\\right\\|)", block: true)
]

#text("giving the claim. ")#mi("\\Box")

#text("Here is a typical application of the above estimates. If ")#link(<tao-87aaf606ddebb4099c78>)[#text("(1)")]#text(" holds for ")#mi("{(\\alpha,\\beta)}")#text(", then by part (i) it holds for ")#mi("{(\\beta,\\alpha)}")#text(", then by (ii) ")#link(<tao-d5c401328d3bc60f858a>)[#text("(2)")]#text(" holds for ")#mi("{(\\beta+1,\\frac{\\alpha}{2})}")#text(", then by (iv) ")#link(<tao-87aaf606ddebb4099c78>)[#text("(1)")]#text(" holds for ")#mi("{(\\frac{3\\beta+2}{4}, \\frac{3\\alpha}{8})}")#text(". The map ")#mi("{(\\alpha,\\beta) \\mapsto (\\frac{3\\beta+2}{4}, \\frac{3\\alpha}{8})}")#text(" has fixed point ")#mi("{(\\alpha,\\beta) = (\\frac{16}{23}, \\frac{6}{23})}")#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\| xyx^{-1}y^{-1} \\right\\| \\leq \\frac{16}{23} \\left\\|x\\right\\| + \\frac{6}{23} \\|y\\|.", block: true)]]

#text("For instance, if ")#tao-math("{\\left\\|a\\right\\|, \\left\\|b\\right\\| \\leq 1}", block: false)#text(", then ")#tao-math("{\\left\\|aba^{-1}b^{-1} \\right\\| \\leq 22/23 = 0.95652\\dots}", block: false)#text(".")

#heading(level: 1)[#text("Comments (96)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490308")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("Trying again, the fixed point of (iv) is ")#mi("(\\alpha,\\beta)=(\\frac{1+\\gamma}{2},\\frac{\\delta}{3})")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490313")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("This has become redundant since a nice bound below 1 has been found, but (for completeness) I have a computer generated proof that ")#mi("(aba^{-1}b^{-1}a)^6a")#text(" has norm less than 5, hence the commutator has norm less than one. This is a proof in the sense of the structure at")#linebreak()#text(" ")#link("https://github.com/siddhartha-gadgil/Superficial/blob/master/src/main/scala/freegroups/LinNormBound.scala")[#text("https://github.com/siddhartha-gadgil/Superficial/blob/master/src/main/scala/freegroups/LinNormBound.scala")]#text(" with the proof itself at")#linebreak()#text(" ")#link("https://github.com/siddhartha-gadgil/Superficial/blob/master/pf6raw.txt")[#text("https://github.com/siddhartha-gadgil/Superficial/blob/master/pf6raw.txt")]

#text("I will format stuff better when I have a better bound.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490315")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("Wouldn’t it also be possible to consider the system from Proposition 1 as one big iteration, ")#mi("(\\alpha,\\beta,\\gamma,\\delta)\\mapsto(\\tfrac{2\\gamma}{3},\\tfrac{2\\delta}{3},\\tfrac{2\\alpha+\\gamma+1}{4},\\tfrac{\\beta+\\delta}{4})")#text("? The unique fixed point of this is ")#mi("(\\tfrac{2}{5},0,\\tfrac{3}{5},0)")#text(". Thus we obtain ")#tao-math("\\left|\\left|xyx^{-1}y^{-1}\\right|\\right|\\leq \\tfrac{2}{5}\\left|\\left|x\\right|\\right|", block: false)#text(".")

#text("Can this be right? I feel like I’ve made a mistake somewhere.")

#text("If it is correct, then we would also have ")#tao-math("\\left|\\left|x^2 y x^{-2} y^{-1}\\right|\\right|\\leq \\tfrac{2}{5}\\left|\\left|y\\right|\\right|", block: false)#text(", which may lead to further improvements when plugged into Terry’s argument for (ii).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490319")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("Are you using (iv) to get those new ")#mi("\\gamma,\\delta")#text(" values? Those should be ")#mi("\\alpha,\\beta")#text(" values if so.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490320")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("Ah of course, thanks!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490317")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("Here are some (more or less straightforward) thoughts on the current status.")

#text("1) If we can prove that ")#tao-math("\\left|\\left|aba^{-1}b^{-1}\\right|\\right| = 0", block: false)#text(", then it follows that every norm on any group ")#mi("G")#text(" arises by pullback from the abelianization ")#mi("G_{\\mathrm{ab}} = G/[G,G]")#text(". This is because it’s enough to show that the norm of any commutator vanishes, but by pulling back to ")#mi("F_2")#text(", it’s enough to show ")#tao-math("\\left|\\left|aba^{-1}b^{-1}\\right|\\right| = 0", block: false)#text(". And on ")#mi("G_{\\mathrm{ab}}")#text(", the norms are in bijection with norms on the vector space ")#mi("G_{\\mathrm{ab}}\\otimes\\mathbb{R}")#text(". In this sense, we’d have a complete classification.")

#text("2) So optimally, we’d like to derive estimates like in Proposition 1, but without any constant terms; currently there still is a constant in (ii). But this would require bounding the norm of an element of the commutator subgroup only in terms of other elements of the commutator subgroup. (Since outside of the commutator subgroup, we obviously cannot expect the norm to vanish.) So effectively, we’d be looking at norms on the commutator subgroup. But then we cannot hope to prove that every such norm must vanish, since this is not the case: the commutator subgroup again has nontrivial abelianization.")#linebreak()#text(" In conclusion, I think that if there is an argument for ")#tao-math("\\left|\\left|aba^{-1}b^{-1}\\right|\\right| = 0", block: false)#text(" in the style of Proposition 1, then it will necessarily involve an infinite sequence of terms giving better and better bounds.")

#text("3) Linear programming duality suggests that if ")#tao-math("\\left|\\left|aba^{-1}b^{-1}\\right|\\right| = 0", block: false)#text(" is necessarily true, then there indeed must be an argument of this type which proves it. (It should be possible to make this reasoning rigorous via the Hahn-Banach theorem for order unit spaces; the collection of all length functions on ")#mi("F_2")#text(" is the positive cone of an order unit space, with generator word length as order unit.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490322")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("Concerning (iii), here’s an argument that reduces the factor of ")#mi("\\tfrac{2}{3}")#text(" in both components to ")#mi("\\tfrac{4}{7}")#text(": the power ")#mi("(xyx^{-1}y^{-1})^7")#text(" is a product of four terms of type ")#mi("xyx^{-1}y^{-1}xyx^{-1}")#text(". But this is conjugate to ")#mi("y^2 x^{-1}y^{-1}x")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490327")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("That’s very useful: suppose the constant in (iii) is ")#mi("t")#text(". Combining with (i),(ii) gives the iteration ")#mi("(\\alpha,\\beta)\\mapsto (t(1+\\beta),t\\alpha/2)")#text(", which has the fixed point ")#mi("(\\frac{2t}{2-t^2},\\frac{t^2}{2-t^2})")#text(".")

#text("This is monotone in ")#mi("t")#text(", and the sum crosses ")#mi("1")#text(" when ")#mi("t=\\frac{-1+\\sqrt{5}}{2}\\approx 0.618")#text(". With ")#mi("t=4/7")#text(" we get the admissible value ")#mi("(\\alpha,\\beta)=(\\frac{28}{41},\\frac{8}{41})")#text(" which add up to ")#mi("\\frac{36}{41}\\approx 0.878")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490338")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("It is interesting to observe that now (iii) is active (replacing the role of (iv) which was used for the previous bound.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490353")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("Actually I seem to have messed up there…! What I actually get is ")#tao-math("7\\left|\\left|xyx^{-1}y^{-1}\\right|\\right|\\leq 2(\\left|\\left|xy^2x^{-1}y^{-1}\\right|\\right| + \\left|\\left|yx^2y^{-1}x^{-1}\\right|\\right|)\\leq \\tfrac{2(\\gamma+\\delta)}{7}(\\left|\\left|x\\right|\\right| + \\left|\\left|y\\right|\\right|)", block: false)#text(". In other words, if (2) holds for ")#mi("(\\gamma,\\delta)")#text(", then (1) holds for ")#mi("(\\tfrac{4(\\gamma+\\delta)}{7},\\tfrac{4(\\gamma+\\delta)}{7})")#text(". This is less useful than what I had claimed.")

#text("I’m afraid that this also invalidates the last sentence of Lior’s comment. Sorry, my bad…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490357")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("Does this 4/7 trick account for the fact that the ")#mi("(\\gamma,\\delta)")#text(" space isn’t symmetric? Rather than ")#mi("(\\frac{4}{7}\\gamma,\\frac{4}{7}\\delta)")#text(" don’t we end up with ")#mi("(\\frac{4}{7}(\\gamma+\\delta),\\frac{4}{7}(\\gamma+\\delta))")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490358")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("Woops, should have refreshed before I posted. Good to know we both caught this!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490368")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("… and we seem to have independently made the same additional mistake! What my argument really gives is ")#mi("\\left(\\tfrac{2}{7}(\\gamma+\\delta),\\tfrac{2}{7}(\\gamma+\\delta)\\right)")#text(". Phew.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490372")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("Iterating now we might as well assume ")#mi("\\alpha=\\beta")#text(" so ")#mi("\\gamma +\\delta = 1+\\alpha+\\alpha/2 = 1+3\\alpha/2")#text(". Then the iteration scheme is ")#mi("\\alpha \\mapsto \\frac27 (1+\\frac32 \\alpha)")#text(" with the fixed point ")#mi("\\alpha=\\beta=\\frac12")#text(" — which is still a new point!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cbc2d27be35b52d76218f729437fb6f59d7159dd6ad519e6b5824e55164b893-b88a1ccc43798cb3a67a8dee5b4ebd33a294ad10b1c2db24678b09ee1cd9bfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490379")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("If I understand correctly, the corrected valid map here is ")#mi("(\\alpha, \\beta) \\mapsto (2/7(\\alpha + \\beta/2 + 1), 2/7 (\\alpha + \\beta/2+1))")#text(". By post-composing this with ")#mi("(\\alpha,\\beta) \\mapsto (3\\beta/8, (3\\alpha + 2)/4)")#text(" (Terry’s (ii), (iv), then (i)), you get ")#mi("(\\alpha,\\beta) \\mapsto ((3\\alpha + 3\\beta + 10)/28, (3\\alpha + 3\\beta + 10)/28)")#text(". After iterating this you get to ")#mi("(5/11, 5/11)")#text(". So this still counts as state-of-the-art I think.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490324")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("A slight (although equivalent) “generalization” of proposition 1(i) is to take any convex combination of ")#mi("(\\alpha, \\beta)")#text(" and ")#mi("(\\beta, \\alpha)")#text(", i.e. any non-negative pair ")#mi("( \\alpha^{\\prime} , \\beta^{\\prime})")#text(" satisfying")#linebreak()#text(" ")#mi("\\alpha^{\\prime} + \\beta^{\\prime} = \\alpha + \\beta")#text(".")#linebreak()#text(" Hopefully, it may give more flexibility to possible iterations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490329")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("I don’t think this can help. The reason is that the sets of admissible ")#mi("(\\alpha,\\beta),(\\gamma,\\delta)")#text(" are convex and all the inequalities we derived are preserved under convex combinations. This means we can always defer taking convex combinations till the end, or equivalently that the strongest inequalities are given by extreme points of the convex sets.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aula")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490328")[#strong[#text("Aula")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("In the first display, the LHS of the triangle inequality has additive notation for the group operation, while everything else has multiplicative notation. In the next display, the RHS of the linear growth equation is missing the left vertical bar of the absolute value of n.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490341")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("Notice that our only control over the ")#mi("\\gamma,\\delta")#text(" points satisfying (2) comes from condition (ii) of the Proposition. In other words, these points are precisely the points of the form ")#mi("\\alpha+1,\\beta/2")#text(" where ")#mi("(\\alpha,\\beta)")#text(" satisfies (1).")

#text("Thus, we can avoid passing through the ")#mi("\\gamma,\\delta")#text(" space altogether. Now condition (iii) of the Proposition (replacing 2/3 with 4/7 using Tobias’ idea) just says that the ")#mi("\\alpha,\\beta")#text(" region satisfying (1) is preserved under the map ")#mi("(\\alpha,\\beta)\\mapsto (\\frac{4\\alpha+4}{7},\\frac{2\\beta}{7})")#text(". Similarly, condition (iv) just says that if ")#mi("(\\alpha,\\beta),(\\alpha^{\\prime},\\beta^{\\prime})")#text(" are two points satisfying (1), then so is")

#mi("\\displaystyle (\\frac{2\\alpha+\\alpha^{\\prime}+2}{4},\\frac{2\\beta+\\beta^{\\prime}}{8})")

#text("Now setting ")#mi("(x_0,y_0)=(8/41, 28/41)")#text(", we may recursively set ")#mi("(x_{n+1},y_{n+1})=((4x_n+4)/7,2y_{n}/7)")#text(" for each integer ")#mi("n\\geq 0")#text(". By the symmetry in condition (i), we have that the points ")#mi("(x_{-n},y_{-n})=(y_{n+1},x_{n+1})")#text(" also belong to the region of interest. Connecting each successive point by a line segment, we get an infinite polygonal type region, with the points having limit ")#mi("(4/3,0)")#text(" and ")#mi("(0,4/3)")#text(". (The slopes of each successive line segment are half of the previous segment.) It is easy to check that the condition in (iii) sends lines to lines, so this boundary is invariant under that transformation (with each boundary piece sent to the next).")

#text("I haven’t checked all the details, but numerical computations suggest this region is also invariant under the linear combination expressed in (iv). If that’s true, then without some further relations we should expect no further improvement.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490348")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("I’m hoping that it will be possible to do more with the bounds that involve only one term on the right-hand side, ")#tao-math("\\left|\\left|xyx^{-1}y^{-1}\\right|\\right|\\leq \\tfrac{4}{3}\\left|\\left|y\\right|\\right|", block: false)#text(". These are great because we can replace ")#mi("x")#text(" by powers of ")#mi("x")#text(", resulting in ")#tao-math("\\left|\\left|x^nyx^{-n}y^{-1}\\right|\\right|\\leq \\tfrac{4}{3}", block: false)#text(", or even other words. My hope is that we can combine this fact with tricks like ")#mi("[x^2,y] = x[x,y]x^{-1}[x,y]")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490362")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("My previous ")#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490353")[#text("error")]#text(" means that all of Pace’s expressions that derive from the ")#mi("\\tfrac{4}{7}")#text(" are a bit off. Fortunately, we still get the ")#mi("x")#text("-independent bound ")#tao-math("\\left|\\left|xyx^{-1}y^{-1}\\right|\\right|\\leq 2\\left|\\left|y\\right|\\right|", block: false)#text(" upon using the original factor of ")#mi("\\tfrac{2}{3}")#text(" in (iii).")

#text("Knowing that ")#tao-math("\\left|\\left|x^nyx^{-n}y^{-1}\\right|\\right|", block: false)#text(" is upper bounded by a constant, can we show the same for ")#tao-math("\\left|\\left|x^n y^n x^{-n} y^{-n}\\right|\\right|", block: false)#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490371")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("That ")#tao-math("\\left\\| xyx^{-1}y^{-1} \\right\\| \\leq \\left\\| xyx^{-1}\\right\\| + \\left\\| y^{-1}\\right\\| = 2\\left\\| y \\right\\|", block: false)#text(" is immediate from the hypotheses.")

#text("We know that all conjugates of the ")#mi("r")#text("-ball are in the ")#mi("2r")#text("-ball, which seems preposterous in a torsion-free non-commutative group, but I don’t have any idea how to use this observation.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490342")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("A small comment: now that the commutator bound has a constant less than 1, this implies that there exist non-trivial group elements of arbitrarily small norm; in particular, integer-valued norms have now been totally ruled out. This suggests that there is no simple “combinatorial” example of a norm (such as one based on edit distance), though it still doesn’t rule out more complicated constructions, perhaps coming from an iterative construction (e.g. starting with the zero seminorm and gradually making more and more elements have non-zero norm) or something like the functional analysis approach I suggested in the previous post.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490347")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("More precisely, either every term of the derived series has an element of non-zero norm, in which case the set of norms is dense in the positive reals, or (modulu elements of norm zero) the group is solvable, hence (as we saw) abelian.")

#text("In the abelian case there are both discrete and dense norms — on ")#mi("\\mathbb{Z}^2")#text(" we can take either ")#tao-math("\\left\\|(a,b)\\right\\| = \\left| a\\right| + \\left| b\\right|", block: false)#text(" or ")#tao-math("\\left\\|(a,b)\\right\\| = \\left| a+b\\sqrt{2}\\right|", block: false)#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490346")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("In order to generalize the relations (1), (2), it seems that a general notation is needed for the norm of a general word ")#mi("x^{n_1}y^{n_2}x^{n_3} ...")#linebreak()#text(" where ")#mi("n_1. n_2, n_3, ...")#text(" is a finite sequence of integers.")#linebreak()#text(" For such cases, it is possible to use the generalized notation")#linebreak()#text(" ")#mi("(\\alpha, \\beta ; n_1, n_2, ...)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/99077de2ce4cd90a3bab5c7a180eb894bd6bb365e81afb59c315af204aca3bbb-36afb7bbf9d844f5451ab123fdd86fedf8736cf48b85879d1658adbe17de608a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of António Machiavelo")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490349")[#strong[#text("António Machiavelo")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("Normalize ")#mi("\\Vert\\cdot\\Vert")#text(" so that ")#tao-math("\\left\\| a\\right\\|=1", block: false)#text(" and ")#tao-math("\\left\\| b\\right\\|\\leq1", block: false)#text(". Then")

#tao-math("\\begin{aligned}  2= \\left\\| a^2\\right\\| &\\leq \\left\\| a^2 b a b^{-1} a^{-2}\\right\\| + \\left\\| a^2 b a^{-1} b^{-1}\\right\\| \\\\ &= 1 + \\left\\| a^{-1} b^{-1} a^2 b\\right\\| , \\end{aligned}", block: false)

#text("and so ")#tao-math("\\left\\| a^{-1} b^{-1} a^2 b\\right\\|\\geq 1", block: false)#text(". This shows that it is not the case that one has ")#tao-math("\\left\\| x y x^{-2} y^{-1}\\right\\| < 1", block: false)#text(" for all ")#mi("x,y\\in F_2")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490352")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("Ah, so what you are saying is ")#mi("a^{-1} b^{-1} a^2 b")#text(" has norm at least the max of the norms of a,b. (Certainly, it would be something to get a similar lower bound for the commutator!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490366")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#emph[#text("[I’ve deleted some comments here that were based on an inequality that was incorrect -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65a861b523fdb5071ea2d4a76fc38e1e600a3ba2bd97dce963341b3770c82a2e-f09146c65c3fa56f5cfde78a2d6c10c19270ab040979ff9bf0dfd539cba72163.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490350")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#emph[#text("[This appears to be a response to Tobias’s comment ")#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490317")[#text("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490317")]#text(" -T.]")]

#text("I was thinking along similar lines to your (2), trying to make the argument formal. One issue I ran into is the argument (ii), which involves plugging a different variable into an already known inequality. This is a way to pass from estimates inside the commutator subgroup to estimates inside the commutator subgroup that isn’t necessarily foiled by the abelianization of the commutator subgroup. To demonstrate this, we can formulate the Hesienberg group argument in this way:")

#text("Suppose ")#tao-math("\\left|\\left| [a,b]\\right|\\right| \\leq \\alpha \\left|\\left|a\\right|\\right|+ \\beta \\left|\\left|b\\right|\\right|", block: false)#text(" in the Heisenberg group. Then we have ")#tao-math("\\left|\\left| [a,b] \\right|\\right| = \\left|\\left| [a,b] ^4 \\right|\\right|/4 = \\left|\\left| [a^2,b^2] \\right|\\right|/4 \\leq (2 \\alpha \\left|\\left|a\\right|\\right| + 2 \\beta \\left|\\left|b\\right|\\right|)/4 = (\\alpha/2) \\left|\\left|a\\right|\\right| + (\\beta/2) \\left|\\left|b\\right|\\right|", block: false)#text(" which gives an iteration whose fixed point is ")#mi("\\alpha=0,\\beta=0")#text(".")

#text("So it’s not obvious we need infinitely many identities in the free group case either. However, if you forbid this plugging-in trick, and only look at identities between group elements, not functions on group elements, then exactly the argument you state applies to a general subgroup and shows that no finite collection of identities can be used to show that the norm of any nontrivial element of the free group vanishes.")

#text("For your 3), I think there’s no problem to make it rigorous, and Hahn-Banach is unnecessary. For any element ")#mi("g")#text(" in ")#mi("F_2")#text(", let ")#mi("f(g)")#text(" be the infimum of all upper bounds on ")#tao-math("\\left|\\left|g\\right|\\right|", block: false)#text(" provable using this method under the assumptions ")#tao-math("\\left|\\left|a\\right|\\right|=\\left|\\left|b\\right|\\right|=1", block: false)#text(". Then ")#mi("f")#text(" satisfies all the axioms to be a norm – if we had ")#mi("f(ab) > f(a)+ f(b)")#text(", we could combine arguments giving bounds close to the infimum for ")#tao-math("\\left|\\left|a\\right|\\right|", block: false)#text(" and ")#tao-math("\\left|\\left|b\\right|\\right|", block: false)#text(" with multiplication to get a better-than-infimum bound for ")#tao-math("\\left|\\left|ab\\right|\\right|", block: false)#text(", contradiction, and similarly with ")#mi("n f(a)> f(a^n)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490375")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("This looks quite interesting, but I’m not sure I understand where the ")#tao-math("\\left|\\left|[a^2,b^2]\\right|\\right|\\leq 2\\alpha\\left|\\left|a\\right|\\right| + 2\\beta\\left|\\left|b\\right|\\right|", block: false)#text(" came from. Can you elaborate a bit?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65a861b523fdb5071ea2d4a76fc38e1e600a3ba2bd97dce963341b3770c82a2e-f09146c65c3fa56f5cfde78a2d6c10c19270ab040979ff9bf0dfd539cba72163.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490404")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("I’m applying the bound ")#tao-math("\\left|\\left|[a,b]\\right|\\right| \\leq \\alpha \\left|\\left|a\\right|\\right| + \\beta \\left|\\left|b\\right|\\right|", block: false)#text(", but plugging in ")#mi("a^2")#text(" and ")#mi("b^2")#text(" instead of ")#mi("a")#text(" and ")#mi("b")#text(". This is supposed to be similar to one of the arguments used in this post.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa110cd843baa2000ae418ed3de2ae68b28bc66ef4075ccbcac1820a765bc52e-85a2258f3dc17fc3c3f5478e04ec551c8963350f4e5cfb87059b48fab2cfb0f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cjerdonek")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490356")[#strong[#text("cjerdonek")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("What about an idea like the following? Consider the closed unit ball with three open discs removed from the boundary, and take the free group to be the fundamental group of that boundary. For the norm of a loop on the boundary, you can consider minimizing the area of the surface bounded by the loop inside the ball. It seems like a simple geometric construction would yield the triangle inequality, since you can connect two discs by an arbitrarily thin band.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490367")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("In order to have concatenation of loops as a well-defined operation, you need to consider based loops. But then your construction will fail to satisfy the desired linearity condition ")#tao-math("\\left|\\left|x^n\\right|\\right| = \\left|n\\right| \\,\\left|\\left|x\\right|\\right|", block: false)#text(": as you loop two or more times around a puncture, you can contract your loop much further than in the case where you have to pass through the basepoint after every winding.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa110cd843baa2000ae418ed3de2ae68b28bc66ef4075ccbcac1820a765bc52e-85a2258f3dc17fc3c3f5478e04ec551c8963350f4e5cfb87059b48fab2cfb0f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cjerdonek")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490373")[#strong[#text("cjerdonek")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("Elements of the fundamental group (the free group) are represented by based loops. But I was suggesting disregarding the base and considering the free loop when evaluating the norm and minimizing the spanned area. (Technically, I’m not sure it would matter because it seems you could replace a path to and from the base with an arbitrarily thin band, which wouldn’t contribute to the area.) I’m not sure I understand your point about looping two or more times though.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490374")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("Ah, I see! Then I agree with Terry, the doubling identity is probably what breaks down. In particular, the surface area for ")#mi("(aba^{-1})^2 = ab^2 a^{-1}")#text(" seems to be less than double than that of ")#mi("aba^{-1}")#text(".")

#text("Actually, could it be that your proposal coincides with a ‘weighted’ version of word length, where each generator is counted with a weight given by the corresponding minimal surface area?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa110cd843baa2000ae418ed3de2ae68b28bc66ef4075ccbcac1820a765bc52e-85a2258f3dc17fc3c3f5478e04ec551c8963350f4e5cfb87059b48fab2cfb0f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cjerdonek")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490380")[#strong[#text("cjerdonek")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("If there is a problem with doubling, I think it will be much more subtle than that (e.g. involving properties of area-minimizing immersed discs in the 3-ball). In your example, it doesn’t seem like taking a conjugate should help since it will be in the same free homotopy class and so have the same area.")

#text("I don’t see a connection to weighted word length since minimal spanning discs of products of elements might not correspond combinatorially to generators. But maybe there is some loose connection.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490369")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("This seems to be somewhat incompatible with the recently obtained observation that there must exist nontrivial group elements of arbitrarily small norm. Presumably what is going on is that the doubling identity ")#tao-math("\\left\\|x^2\\right\\| = 2 \\left\\|x\\right\\|", block: false)#text(" is breaking down.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490370")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("Another trivial comment: I have found it useful (as suggested in some other comments) to view words as paths in ")#mi("{\\bf Z}^2")#text(", with ")#mi("a, b, a^{-1}, b^{-1}")#text(" representing a unit move in (say) the north, east, south, and west directions respectively. Then for instance ")#mi("a b a^{-1} b^{-1}")#text(" is a loop going around a unit square, while for instance ")#mi("b^{-1} a b a^{-1} b^{-1} ab")#text(" (which is a conjugate of ")#mi("a^2 b a^{-1} b^{-1}")#text(") traverses a square seven quarter times, which explains why ")#mi("(aba^{-1} b^{-1})^7")#text(" can be split into four conjugates of words looking like ")#mi("a^2 b a^{-1} b^{-1}")#text(". Drawing these sorts of loop pictures helped me understand a number of the word identities used in the above comments (as well as to catch some incorrect ones).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490403")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("The evidence seems to be slowly turning in the favour of the hypothesis that no norm exists on the free group, but it is still worth pursuing the opposing hypothesis that such a norm can be constructed. Here is one possible route to doing so. Work in a small non-abelian special unitary group, such as ")#mi("SU(2)")#text(", and let ")#mi("U_a, U_b")#text(" be generic elements of this group. This gives a unitary representation ")#mi("x \\mapsto U_x")#text(" of the free group in the usual fashion. The idea is to define the norm as")

#tao-math("\\displaystyle \\left\\| x\\right\\| := \\left\\| \\log U_x \\right\\|_{op},", block: false)

#text("but the issue is to select the “correct” branch of the logarithm for ")#mi("\\log U_x")#text(". If ")#mi("U_a, U_b")#text(" are close to the identity, then for words ")#mi("x")#text(" of small length, ")#mi("U_x")#text(" is also close to the identity, and one can use the standard branch, in which the doubling condition is obvious and the triangle inequality comes from the Weyl inequalities for eigenvalues of unitary groups (arranged in the “Weyl alcove” where the arguments of the eigenvalues sum to zero and have diameter less than ")#mi("2\\pi")#text("). But I’m not quite sure how to proceed once one moves further away from the identity. One possibility is to try to extend the matrix logarithm by monodromy: one can consider a continuous (in fact real analytic) one-parameter family of representations ")#mi("x \\mapsto U_{x,t}")#text(" by defining ")#mi("U_{a,t} = \\exp( t \\log U_a )")#text(" for some fixed choice of logarithm ")#mi("\\log U_a")#text(". One can define ")#mi("\\log U_{x,t}")#text(" unambiguously for small ")#mi("t")#text(", and I think one can extend this by analytic continuation to large ")#mi("t")#text(" (one may possibly need to use the genericity hypotheses on ")#mi("U_a,U_b")#text(" for this). Then one sets ")#mi("t=1")#text(" to obtain the required branch for ")#mi("\\log U_x = \\log U_{x,1}")#text(".")

#text("Here is a model problem that captures the difficulty. Given two “generic” skew-Hermitian matrices ")#mi("X, Y")#text(", can one define a binary operation ")#mi("X*Y")#text(", also a skew-Hermitian matrix, with the property that ")#mi("(tX)* (tY)")#text(" depends continuously on the real number ")#mi("t")#text(" with ")#mi("0 * 0 = 0")#text(" and")

#mi("\\exp( (tX) * (tY) ) = \\exp(tX) \\exp(tY)")

#text("for all ")#mi("t")#text("? (For small ")#mi("X,Y")#text(", one can uniquely define ")#mi("X*Y = \\log( \\exp(X) \\exp(Y))")#text(" by the Baker-Campbell-Hausdorff formula, so the question is basically whether one can analytically continue this formula generically.) Furthermore, is it the case that this operation is (generically) associative and obeys the Weyl inequality ")#tao-math("\\left\\| X * Y \\right\\|_{op} \\leq \\left\\| X \\right\\|_{op} + \\left\\|Y\\right\\|_{op}", block: false)#text("? If one had these properties then we could define ")#mi("\\log U_x")#text(" by iterating the formula ")#mi("\\log U_{xy} = \\log U_x * \\log U_y")#text(" and I think we would get a norm with all the required properties this way.")#linebreak()#text(" The key stumbling block I am having is that it appears the exponential map ceases to be a local diffeomorphism when two eigenvalues differ by a multiple of ")#mi("2\\pi i")#text(" (and this is where, not coincidentally, the Baker-Campbell-Hausdorff-Dynkin formula also breaks down), but I am hoping that one can work around this problem if the matrices involved are sufficiently generic.")

#text("Perhaps one could try to test this sort of construction numerically?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490410")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Hmm, it actually appears that (in contrast to the complex logarithm) the matrix logarithm is genuinely discontinuous at places where two eigenvalues of the logarithm differ by a multiple of ")#mi("2\\pi i")#text(", so this monodromy idea probably doesn’t work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cbc2d27be35b52d76218f729437fb6f59d7159dd6ad519e6b5824e55164b893-b88a1ccc43798cb3a67a8dee5b4ebd33a294ad10b1c2db24678b09ee1cd9bfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490426")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Does this at least give a quick proof that there is a valid norm on any finite ball in ")#mi("F_2")#text("? (I’m still trying to convince myself of the triangle inequality.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490485")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("I think so, yes. Regarding the triangle inequality: consider a one-parameter family ")#mi("U(t)")#text(" of unitary matrices of the form ")#mi("U(t) = \\exp( it X) U(0)")#text(" for some Hermitian matrix ")#mi("X")#text(", and suppose that on some open interval of times ")#mi("t")#text(", the eigenvalues ")#mi("e^{i \\theta_1(t)}, \\dots, e^{i \\theta_n(t)}")#text(" of ")#mi("U(t)")#text(" are distinct, with each ")#mi("\\theta_j")#text(" varying smoothly in ")#mi("t")#text(". Then one can verify the Hadamard variation formula")

#mi("\\displaystyle \\partial_t \\theta_j(t) = u_j^* X u_j")

#text("where ")#mi("u_j")#text(" is the unit eigenvector associated to the eigenvalue ")#mi("e^{i \\theta_j}")#text(". In particular, the derivative of ")#mi("\\theta_j")#text(" does not exceed ")#tao-math("\\left\\| X \\right\\|_{op}", block: false)#text(" in magnitude, and this gives the triangle inequality in this open interval for any continuous branch of the logarithm.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490445")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("For the representation of the matrix logarithm by Cauchy formula, the integration contour should encircle all the matrix eigenvalues but not the logarithmic branch point at ")#mi("0")#text(", so if ")#mi("t")#text(" is contained in some compact real interval ")#mi("I")#text(", such that the spectrum of ")#mi("\\exp(t X) \\exp(t Y)")#text(" can be enclosed by such integration contour for all ")#mi("t \\in I")#text(", then the matrix logarithm is real analytic over ")#mi("I")#text(". Is this condition (on the existence of such integration contour) also necessary for a real analytic matrix logarithm over ")#mi("I")#text("?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490486")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("I haven’t understood the full context of your suggestion, but I believe I can show that, for any ")#mi("X_1")#text(", ")#mi("X_2")#text(", …, ")#mi("X_n")#text(" in ")#mi("\\mathfrak{su}(2)")#text(", there is a unique real analytic ")#mi("\\lambda : \\mathbb{R} \\to \\mathfrak{su}(2)")#text(" such that ")#mi("\\lambda(0)=0")#text(" and ")#mi("\\exp(\\lambda(t)) = \\exp(t X_1) \\cdots \\exp(t X_n)")#text(". More generally, I claim:")

#text("Theorem: If ")#mi("\\phi: \\mathbb{R} \\to SU(2)")#text(" is any real analytic map with ")#mi("\\phi(0)=1")#text(", then there is a unique real analytic ")#mi("\\lambda")#text(" with ")#mi("\\lambda(0)=0")#text(" and ")#mi("\\exp(\\lambda(t))=\\phi(t)")#text(".")

#text("We recall the definition of the blow up of ")#mi("\\mathbb{R}^3")#text(" at the origin: It is a submanifold of ")#mi("\\mathbb{R}^3 \\times \\mathbb{RP}^2")#text(" consisting of pairs ")#mi("(\\vec{v}, \\ell)")#text(" such that the vector ")#mi("\\vec{v}")#text(" lies on the line ")#mi("\\ell")#text(". Projection onto ")#mi("\\mathbb{R}^3")#text(" is a diffeomorphism away from the origin; projection onto ")#mi("\\mathbb{RP}^2")#text(" is a line bundle.")

#text("We’ll denote this blow up as ")#mi("B")#text(". The key property of analytic functions is that any real analytic map ")#mi("(a,b) \\to \\mathbb{R}^3")#text(" which is not identically zero, lifts uniquely to an analytic map ")#mi("(a,b) \\to B")#text(". (Not true for smooth maps: ")#mi("e^{-1/t} (\\sin t^{-1}, \\cos t^{-1})")#text(" is smooth, but the line it spans doesn’t have a well defined limit in ")#mi("\\mathbb{RP}^1")#text(".)")

#text("We put the standard norm on ")#mi("\\mathfrak{su}(2)")#text(", normalized so that ")#tao-math("\\mathrm{Tr}\\ \\exp(X) = 2 \\cos \\left|X\\right|", block: false)#text(". I’ll write the nontrivial central element of ")#mi("SU(2)")#text(" as ")#mi("-1")#text(" and the identity as ")#mi("1")#text(".")

#text("Lemma: Let ")#mi("k")#text(" be a nonnegative integer and let ")#mi("(a,b)")#text(" be an interval such that the real analytic map ")#mi("\\phi")#text(" does not assume the value ")#mi("(-1)^{k+1}")#text(" on ")#mi("(a,b)")#text(". Then we can find ")#mi("\\lambda: (a,b) \\to \\mathfrak{su}(2)")#text(" such that ")#mi("\\phi = \\exp \\circ \\lambda")#text(" and ")#tao-math("\\left|\\lambda(t)\\right| \\in ((k-1) \\pi, (k+1) \\pi)", block: false)#text(" for all ")#mi("t \\in (a,b)")#text(". If ")#mi("k=0")#text(", there is a unique such lift; otherwise, there are precisely two.")

#text("Proof: If ")#mi("k=0")#text(", we use the fact that ")#mi("\\exp")#text(" is a diffeomorphism from the open ball of radius ")#mi("\\pi")#text(" to ")#mi("SU(2) \\setminus \\{ -1 \\}")#text(".")

#text("If ")#mi("k>0")#text(", then we use stereographic projection to identify ")#mi("SU(2) \\setminus \\{ (-1)^{k+1} \\}")#text(" with ")#mi("\\mathbb{R}^3")#text(", and then lift ")#mi("\\phi")#text(" up to ")#mi("B")#text(". We now use the fact (must be standard, though I don’t know a reference) that ")#tao-math("\\exp: \\{ (k-1) \\pi < \\left|X\\right| < (k+1) \\pi \\} \\to B", block: false)#text(" is the double cover. So this follows from the lifting lemma for covers. $\\square$")

#text("Now, we prove the theorem. If ")#mi("\\phi")#text(" is identically ")#mi("1")#text(", the claim is obvious, so I ignore this case. Otherwise, since ")#mi("\\phi")#text(" is analytic, ")#mi("\\phi^{-1}(1)")#text(" and ")#mi("\\phi^{-1}(-1)")#text(" are discrete. The lemma lets us lift on each connected component of ")#mi("\\mathbb{R} \\setminus \\phi^{-1}(1)")#text(", and on each connected component of ")#mi("\\mathbb{R} \\setminus \\phi^{-1}(-1)")#text(", and the finite number of lifts let us glue on the overlaps.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490487")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("A bit more conceptually: Let ")#mi("\\widehat{SU}(2)")#text(" be the blow up of ")#mi("SU(2)")#text(" at ")#mi("\\pm 1")#text(" and let ")#mi("\\widehat{\\mathfrak{su}}(2)")#text(" be the blow up of ")#mi("\\mathfrak{su}(2)")#text(" at ")#mi("0")#text(". Then ")#mi("\\exp")#text(" extends to a covering map ")#mi("\\widehat{\\mathfrak{su}}(2) \\to \\widehat{SU(2)}")#text(". (The corresponding fundamental groups are ")#mi("\\mathbb{Z}/2")#text(" and ")#mi("\\mathbb{Z}/2 \\ltimes \\mathbb{Z}")#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490503")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("I think I now understand the context of your idea, and I think this is not going to be useful. This notion of length is very unstable with respect to group multiplication, so I don’t see how you can expect the triangle inequality to hold. For example, if ")#mi("\\phi(t)")#text(" is a path through ")#mi("SU(2)")#text(" then, for generic ")#mi("g \\in SU(2)")#text(", the path ")#mi("g \\phi(t)")#text(" is never $-1$, which means that we can just lift the path to $|X| < \\pi$.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0feebce63889a84eb3a6651b092a2b7a97dd231a14fc272b2e48ac9fa2f2d48d-cdad64271e8367f6d0ec7282b92f0776a95e791939c5c3136ee411308ac37ece.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Hartnick")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490428")[#strong[#text("Tobias Hartnick")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("It seems that people are focussing on trying to show that a bi-invariant metric of linear growth on ")#mi("F_2")#text(". It might be worthwhile to note that there do exist bi-invariant linear metrics of “almost linear growth”. More precisely, for every ")#mi("\\epsilon > 0")#text(" we can find a bi-invariant metric on ")#mi("F_2")#text(" such that the associated norm satisfies")

#tao-math("\\displaystyle n(\\left\\|x\\right\\|-\\epsilon) \\leq \\left\\|x\\right\\|^n \\leq n(\\left\\|x\\right\\|).", block: false)

#text("Examples can be constructed as follows: Let ")#mi("f: F_2 \\to {\\bf R}")#text(" be a homogeneous quasimorphism of defect ")#mi("D > 0")#text(" and let ")#tao-math("\\left\\|x\\right\\| := \\left|f(x)\\right|+D", block: false)#text(" if ")#mi("x \\neq e")#text(" and ")#tao-math("\\left\\|e\\right\\| := 0", block: false)#text(". For ")#mi("x, y \\neq e")#text(" one has")

#tao-math("\\displaystyle \\left\\|xy\\right\\| = \\left|f(x) + f(y)\\right| + D \\leq \\left|f(x)\\right|+\\left|f(y)\\right| + 2D = \\left\\|x\\right\\|+\\left\\|y\\right\\|.", block: false)

#text("If ")#mi("x")#text(" or ")#mi("y")#text(" is the identity, then the same inequality holds of trivial reasons, and since ")#mi("D>0")#text(" we have ")#tao-math("\\left\\|x\\right\\| = 0", block: false)#text(" if and only if ")#mi("x = e")#text(", hence ")#mi("\\|\\cdot\\|")#text(" is a norm. The associated metric is bi-invariant, since homogeneous quasimorphisms are conjugation-invariant.")

#text("Moreover we have for all ")#mi("x \\neq e")#text(",")

#tao-math("\\displaystyle \\left\\|x^n\\right\\| = f(x^n) + D = n(\\|x|+D) - (n-1)D = n\\left\\|x\\right\\| - (n-1)D,", block: false)

#text("hence")

#tao-math("\\displaystyle n(\\left\\|x\\right\\|-D) \\leq \\left\\|x^n\\right\\| \\leq n(\\left\\|x\\right\\|).", block: false)

#text("By rescaling ")#mi("f")#text(" we can make ")#mi("D")#text(" as small as we like.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490436")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("That’s interesting to know. But we could also simply take every nontrivial group element to have norm ")#mi("\\epsilon")#text(", which achieves ")#tao-math("n(\\left\\|x\\right\\|-\\epsilon) \\leq \\left\\|x\\right\\|^n", block: false)#text(" in a rather silly way. So I guess the point of your construction is that there moreover are elements of arbitrarily large norm.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0feebce63889a84eb3a6651b092a2b7a97dd231a14fc272b2e48ac9fa2f2d48d-cdad64271e8367f6d0ec7282b92f0776a95e791939c5c3136ee411308ac37ece.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Hartnick")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490460")[#strong[#text("Tobias Hartnick")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Yes, I wanted to say that there exist unbouned almost linear norms. Thanks for the correction.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490451")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("This would answer a query of Manjunath Krishnapur to me yesterday.")

#text("If I recall correctly, his other question was whether one can find a norm on the free group that is “approximately linear”, in that for all elements ")#mi("x")#text(", one has ")#tao-math("\\left\\|x^n\\right\\| / n \\to \\left\\|x\\right\\|", block: false)#text(" as ")#mi("n \\to \\infty")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cbc2d27be35b52d76218f729437fb6f59d7159dd6ad519e6b5824e55164b893-b88a1ccc43798cb3a67a8dee5b4ebd33a294ad10b1c2db24678b09ee1cd9bfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490458")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("This condition implies linearity, right? Because for every ")#mi("x, m")#text(" the sequence ")#tao-math("\\left\\|x^{mn}\\right\\|/(mn)", block: false)#text(" would have to converge to both ")#tao-math("\\left\\|x\\right\\|", block: false)#text(" and to ")#tao-math("\\left\\|x^m\\right\\|/m", block: false)#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490471")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Aha, that’s very nice!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490701")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2017")])]

#text("Our Proposition 2.1 of the current draft also implies that every homogeneous quasi-morphism is bounded on commutators. This is apparently a known result due to Bavard (although his constant is better). I’m in the process of clarifying the details here and adding them to the manuscript.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490704")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2017")])]

#text("… but then again, quasi-morphisms are trivially bounded on commutators, since their codomain is always the abelian group ")#mi("(\\mathbb{R},+)")#text(".")

#text("I’ve written a few sentences about quasi-morphisms on how they relate to our results. I’ve just uploaded the new version.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cbc2d27be35b52d76218f729437fb6f59d7159dd6ad519e6b5824e55164b893-b88a1ccc43798cb3a67a8dee5b4ebd33a294ad10b1c2db24678b09ee1cd9bfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490711")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2017")])]

#text("It does feel like there is some underlying connection yet to be fleshed out between these results and more well known stuff about quasimorphisms and Bavard duality and so on.")

#text("Here’s a stab: Is there a Hahn–Banach theorem for quasinorms? Suppose ")#mi("\\|\\cdot\\|")#text(" is a quasinorm of defect ")#mi("D")#text(". Is it true that ")#tao-math("\\left\\|x\\right\\| = \\sup_\\phi \\left|\\phi(x)\\right|", block: false)#text(", where the sup runs over all quasimorphisms ")#mi("\\phi")#text(" of defect (optimistically) ")#mi("D")#text(" dominated by ")#mi("\\|\\cdot\\|")#text("?")

#text("This would imply our main result via Bavard’s result (which incidentally is not very deep). Hahn–Banach would give us a quasimorphism such that ")#tao-math("\\phi([a,b]) = \\left\\|[a,b]\\right\\|", block: false)#text(", and then Bavard would give us ")#tao-math("\\left|\\phi([a,b])\\right| \\leq D", block: false)#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490717")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2017")])]

#text("I agree, I also had the impression that there could be more to say! Your stab is going in an interesting direction, but as it stands it can hardly be correct, since you haven’t imposed any actual bounds on ")#tao-math("\\left|\\phi(x)\\right|", block: false)#text("; in particular, your ")#mi("\\sup_\\phi")#text(" also runs over all homomorphisms ")#mi("G\\to\\mathbb{R}")#text(", and rescaling such a ")#mi("\\phi")#text(" yields another homomorphism. So how about e.g. optimizing only over those ")#mi("\\phi")#text(" that satisfy ")#tao-math("\\left|\\phi(y)\\right|\\leq \\left\\|y\\right\\|", block: false)#text(" for all ")#mi("y")#text("?")

#text("In case that you know more about this: is the bound ")#tao-math("\\left|\\phi([a,b])\\right|\\leq D", block: false)#text(" what Bavard actually proved? Applying the triangle inequality gives the trivial bound of ")#mi("3D")#text(", which is the ")#mi("k=1")#text(" case of his Lemme 1.1 in “Longueur stable des commutateurs”. But I haven’t read the whole paper, and he’s quoted as having shown ")#tao-math("\\left|\\phi([a,b])\\right|\\leq D", block: false)#text(" in that paper ")#link("http://math.uchicago.edu/~subhadip/Talks/Winter%202014/Topic%20Proposal.pdf")[#text("also elsewhere")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cbc2d27be35b52d76218f729437fb6f59d7159dd6ad519e6b5824e55164b893-b88a1ccc43798cb3a67a8dee5b4ebd33a294ad10b1c2db24678b09ee1cd9bfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490719")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2017")])]

#text("Exactly, that’s what I meant when I said “dominated by ")#mi("\\|\\cdot\\|")#text("“.")

#text("I think I’ve seen the bound ")#tao-math("\\left|\\phi([a,b])\\right| \\leq D", block: false)#text(" asserted only for homogeneous ")#mi("\\phi")#text(". Such ")#mi("\\phi")#text(" are also conjugation-invariant, as we know. Then the bound just comes from ")#tao-math("\\left|\\phi([a,b])\\right| = \\left|\\phi([a,b]) - \\phi(aba^{-1}) - \\phi(b^{-1})\\right| \\leq D", block: false)#text(". This holds because ")#mi("\\phi(aba^{-1}) = \\phi(b) = -\\phi(b^{-1})")#text(". For plain old quasimorphisms, maybe ")#mi("3D")#text(" is all you can do: I don’t know.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cbc2d27be35b52d76218f729437fb6f59d7159dd6ad519e6b5824e55164b893-b88a1ccc43798cb3a67a8dee5b4ebd33a294ad10b1c2db24678b09ee1cd9bfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490720")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2017")])]

#text("I should say I think the more interesting part of Bavard’s result is that ")#mi("D")#text(" is actually the sup of ")#tao-math("\\left|\\phi([a,b])\\right|", block: false)#text(" over all ")#mi("a,b")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490727")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2017")])]

#text("Ah, sorry. I need to take more time to think for myself before commenting.")

#text("So by defect of a quasinorm, you mean the maximal violation of the triangle inequality ")#tao-math("\\sup_{x,y} (\\left\\| x + y\\right\\| - \\left\\|x\\right\\| - \\left\\|y\\right\\|", block: false)#text(", right? If so, then don’t we already get counterexample from actual norms (i.e. length functions) on abelian groups, e.g. on ")#mi("\\mathbb{Z}_2")#text("?")

#text("I’m aware of one Hahn-Banach theorem for norms on ")#emph[#text("abelian")]#text(" groups: suppose that ")#mi("G")#text(" is an additively written abelian group and ")#mi("\\|\\,\\| : G \\to [0,\\infty)")#text(" is any function that satisfies the triangle inequality and ")#tao-math("\\left\\|0\\right\\| = 0", block: false)#text(". Then for all ")#mi("x \\in G")#text(",")

#tao-math("\\sup_{\\phi} \\phi(x) = \\lim_{n\\to\\infty} \\frac{\\left\\|nx\\right\\|}{n},", block: false)

#text("where ")#mi("\\phi")#text(" ranges over all homomorphisms ")#mi("G \\to \\mathbb{R}")#text(" with ")#tao-math("\\phi(y) \\leq \\left\\|y\\right\\|", block: false)#text(". (Symmetry of the norm is not required, which manifests itself in the absence of the absolute value in the ")#mi("\\phi(\\cdot)")#text("-expressions.)")

#text("One can generalize this a bit further to suitable distance functions on commutative monoids satisfying ")#mi("d(x+z,y+z)\\leq d(x,y)")#text(". But I’m not aware of any interesting statements in the nonabelian case and haven’t yet thought about how to ‘quasify’ this either.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cbc2d27be35b52d76218f729437fb6f59d7159dd6ad519e6b5824e55164b893-b88a1ccc43798cb3a67a8dee5b4ebd33a294ad10b1c2db24678b09ee1cd9bfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490756")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2017")])]

#text("Your examples show why we need to assume homogeneity. So suppose ")#mi("\\|\\cdot\\|")#text(" satisfies ")#tao-math("\\left\\|x^n\\right\\| = \\left|n\\right| \\left\\|x\\right\\|", block: false)#text(" and ")#tao-math("\\left\\|x+y\\right\\| \\leq \\left\\|x\\right\\| + \\left\\|y\\right\\| + D", block: false)#text(". Then does it hold that ")#tao-math("\\sup_\\phi \\phi(x) = \\left\\|x\\right\\|", block: false)#text(", where ")#mi("\\phi")#text(" ranges over defect-")#mi("D")#text(" quasimorphisms such that ")#tao-math("\\phi(y) \\leq \\left\\|y\\right\\|", block: false)#text(" for all ")#mi("y")#text("?")

#text("For what it’s worth, we do know this for ")#mi("D=0")#text(", just because it reduces to the abelian case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cbc2d27be35b52d76218f729437fb6f59d7159dd6ad519e6b5824e55164b893-b88a1ccc43798cb3a67a8dee5b4ebd33a294ad10b1c2db24678b09ee1cd9bfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490757")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2017")])]

#text("Another known case: ")#mi("\\text{scl}")#text(" is a quasinorm in this sense of defect ")#mi("1/2")#text(". Another result of Bavard is that ")#tao-math("\\mathrm{scl}(a) = \\sup_\\phi \\left|\\phi(a)\\right|/(2D(\\phi))", block: false)#text(" over all quasimorphisms ")#mi("\\phi")#text(". (See Theorem 3.11 at ")#link("https://arxiv.org/pdf/math/0605354.pdf")[#text("https://arxiv.org/pdf/math/0605354.pdf")]#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cbc2d27be35b52d76218f729437fb6f59d7159dd6ad519e6b5824e55164b893-b88a1ccc43798cb3a67a8dee5b4ebd33a294ad10b1c2db24678b09ee1cd9bfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490758")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2017")])]

#text("Sorry, ")#tao-math("\\text{scl}(a) = \\sup_\\phi \\left|\\phi(a)\\right|/D(\\phi)", block: false)#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cbc2d27be35b52d76218f729437fb6f59d7159dd6ad519e6b5824e55164b893-b88a1ccc43798cb3a67a8dee5b4ebd33a294ad10b1c2db24678b09ee1cd9bfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490759")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2017")])]

#text("Still sorry, ")#tao-math("\\text{scl}(a) = \\sup_\\phi \\left|\\phi(a)\\right|/(2D(\\phi))", block: false)#text(". Sorry for spamming.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490775")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2017")])]

#text("Thank you for the clarification. Suddenly Bavard duality makes a lot more sense to me!")

#text("As you may know, Theorem 1.12 in ")#link("https://arxiv.org/abs/1606.01961")[#text("this paper")]#text(" is of a vaguely similar flavour as to what you’re suggesting. But the pseudo-norms there are not required to be homogeneous, and correspondingly the author uses a weaker notion of quasimorphism. And the result is not as quantitative as one would perhaps hope.")

#text("I’m not sure if this has anything to do at all, but perhaps one could also try to modify bounded cohomology by enhancing/substituting the boundedness requirement on cochains ")#mi("f : G^n \\to \\mathbb{R}")#text(" by something like ")#tao-math("\\left|f(g_1,\\ldots,g_n)\\right|\\leq O(\\left\\|g_1\\right\\|+\\ldots+\\left\\|g_n\\right\\|)", block: false)#text("? (I assume that the case of trivial real coefficients would be of primary interest, so I’ve formulated it in these terms.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490507")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Apologies if this is already answered somewhere I missed. Let ")#mi("a")#text(" and ")#mi("b")#text(" be the standard generators of ")#mi("F_2")#text(", let ")#mi("S")#text(" be the set of all conjugates of ")#mi("a^{\\pm 1}")#text(" and ")#mi("b^{\\pm 1}")#text(", and let ")#mi("\\ell_S")#text(" be the length function with respect to this generating set. It seems to me that a lot of the effort here is dedicated to proving bounds of the form")#linebreak()#text(" ")#mi("\\ell_S((aba^{-1} b^{-1})^n) \\leq c(n)")#text(" with the eventual aim of finding a bound such that ")#mi("\\lim_{n \\to \\infty} c(n)/n=0")#text(".")

#text("Do we know any lower bounds for ")#mi("\\ell_S((aba^{-1} b^{-1})^n)")#text("? Do we know that it goes to ")#mi("\\infty")#text("? Can we even show ")#mi("\\ell_S((aba^{-1} b^{-1})^2)>2")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cbc2d27be35b52d76218f729437fb6f59d7159dd6ad519e6b5824e55164b893-b88a1ccc43798cb3a67a8dee5b4ebd33a294ad10b1c2db24678b09ee1cd9bfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490582")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Interesting question! But I do think it’s a different question. There is a linear lower bound. Suppose that ")#mi("w")#text(" is a product of ")#mi("\\ell")#text(" generator-conjugates. Then by collecting generators appropriately we can write ")#mi("w")#text(" as ")#mi("w^{\\prime} a^m b^n")#text(", where ")#mi("w^{\\prime}")#text(" is a product of ")#mi("\\ell")#text(" commutators (using ")#mi("a^g a^{-1} = [g^{-1}, a]")#text("). It follows that ")#mi("\\ell_S([a,b]^n)/n")#text(" is at least ")#mi("\\textup{scl}([a,b]) = 1/2")#text(". On the other hand I can prove that ")#mi("\\limsup \\ell_S([a,b]^n)/n \\leq 1")#text(". I would guess ")#mi("1")#text(" is the truth.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490609")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("I’ll also mention that ")#mi("\\ell_S")#text(" seems closely related to the notion of ")#link("https://en.wikipedia.org/wiki/Edit_distance")[#text("edit distance")]#text(" (or ")#link("https://en.wikipedia.org/wiki/Levenshtein_distance")[#text("Levenshtein distance")]#text("). The question of understanding ")#mi("\\ell_S([a,b]^n)/n")#text(" doesn’t quite capture the full subtleties of these linear growth norms because this quantity somehow only uses the identity ")#tao-math("\\left\\|x\\right\\| = \\frac{1}{n} \\left\\|x^n\\right\\|", block: false)#text(" “once”, whereas we now know from the proof of abelianisation that one has to use this identity many, many times.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cbc2d27be35b52d76218f729437fb6f59d7159dd6ad519e6b5824e55164b893-b88a1ccc43798cb3a67a8dee5b4ebd33a294ad10b1c2db24678b09ee1cd9bfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490617")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("I was just thinking about a rigorous version of this statement. Suppose ")#mi("S")#text(" is the “stabilization operator” which replaces a function ")#mi("f(x)")#text(" by ")#mi("\\liminf_{n\\to\\infty} f(nx)/n")#text(", and ")#mi("K")#text(" is the “Kobayashi operator” which replaces ")#mi("f(x)")#text(" by the infimum of ")#mi("f(y_1) + \\cdots + f(y_m)")#text(" over all ")#mi("y_1, \\dots, y_m")#text(" such that ")#mi("y_1 \\cdots y_m = x")#text(". Let ")#mi("\\ell_0")#text(" be the word length function on the standard generators. Then we have shown that ")#mi("\\lim_{n\\to\\infty} (KS)^n \\ell_0")#text(" is zero on ")#mi("[F_2, F_2]")#text(", while David’s question is about ")#mi("SKS\\ell_0")#text(". One could ask whether there is a finite ")#mi("n")#text(" such that ")#mi("(SK)^n \\ell_0([a,b]) = 0")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490510")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("I’m recording here my understanding of the “inward repetition” method developed in the previous post by Siddharta, Pace, and Tobias. It can be abstracted as")

#strong[#text("Lemma.")]#text(" Suppose ")#mi("x,y,z,w \\in {\\bf F}_2")#text(" are such that ")#mi("w^i")#text(" is conjugate to ")#mi("xy")#text(" and ")#mi("w^j")#text(" is conjugate to ")#mi("z x^{-1}")#text(". Then")#linebreak()#text(" ")#tao-math("\\left\\|w\\right\\| \\leq \\frac{1}{i+j} ( \\left\\|y\\right\\| + \\left\\|z\\right\\|)", block: false)#text(".")

#strong[#text("Proof.")]#text(" By hypothesis, we have ")#mi("w^i = sxys^{-1}")#text(" and ")#mi("w^j = t zx^{-1} t^{-1}")#text(" for some ")#mi("s,t")#text(", and hence for any ")#mi("n")

#mi("\\displaystyle w^{in} w^{jn} = s xy \\dots xy s^{-1} t zx^{-1} \\dots zx^{-1} t,")

#text("where the patterns ")#mi("xy")#text(" and ")#mi("zx^{-1}")#text(" are repeated ")#mi("n")#text(" times each. Repeatedly using the triangle inequality and the fact that conjugation by ")#mi("x")#text(" does not affect the norm, we conclude that")

#tao-math("\\displaystyle \\left\\| w^{in} w^{jn} \\right\\| \\leq \\left\\|s\\right\\| + n \\left\\| y \\right\\| + \\left\\| s^{-1} t \\right\\| + n \\left\\|z\\right\\| + \\left\\|t\\right\\|;", block: false)

#text("dividing by ")#mi("(i+j)n")#text(" and taking the limit ")#mi("n \\to \\infty")#text(" gives the claim. ")#mi("\\Box")

#strong[#text("Example 1")]#text(": (Tobias) ")#mi("([x,y])^2")#text(" is conjugate both to ")#mi("x (yx^{-1}y^{-1}[x,y])")#text(" and to ")#mi("(y^{-1} [x,y] xy) x^{-1}")#text(", hence")

#tao-math("\\displaystyle \\left\\| [x,y] \\right\\| \\leq \\frac{1}{4} ( \\left\\| yx^{-1}y^{-1}[x,y] \\right\\| + \\left\\|y^{-1} [x,y] xy\\right\\| )", block: false)#linebreak()#text(" ")#tao-math("\\displaystyle = \\frac{1}{4} (\\left\\| x^{-2}y^{-1}xy \\right\\| + \\left\\| x^2 y x^{-1}y^{-1} \\right\\| ).", block: false)

#strong[#text("Example 2")]#text(": (Pace) ")#mi("[x,y]^2 x")#text(" is conjugate both to ")#mi("y (x^{-1} y^{-1} [x,y] x^2)")#text(" and to ")#mi("(x[x,y]xyx^{-1}) y^{-1}")#text(", hence")

#tao-math("\\displaystyle \\left\\|[x,y]^2 x\\right\\| \\leq \\frac{1}{2} ( \\left\\|x^{-1} y^{-1} [x,y] x^2\\right\\| + \\left\\|x[x,y]xyx^{-1}\\right\\|)", block: false)#linebreak()#text(" ")#tao-math("\\displaystyle = \\frac{1}{2} ( \\left\\| x y^{-1} [x,y] \\right\\| +  \\left\\| xy [x,y] \\right\\| ).", block: false)

#strong[#text("Example 3")]#text(": (Pace) ")#mi("([x,y] x)^2")#text(" is conjugate both to ")#mi("y^{-1} (x [x,y] x^2 y x^{-1})")#text(" and to ")#mi("(x^{-1} y^{-1} x [x,y] x^2) y")#text(", hence")

#tao-math("\\displaystyle \\left\\| [x,y] x\\right\\| \\leq \\frac{1}{4} ( \\left\\| x [x,y] x^2 y x^{-1} \\right\\| + \\left\\| x^{-1} y^{-1} x [x,y] x^2 \\right\\| )", block: false)#linebreak()#text(" ")#tao-math("\\displaystyle = \\frac{1}{4} ( \\left\\| x^2 y [x,y] \\right\\| + \\left\\| xy^{-1} x [x,y] \\right\\| )", block: false)#text(".")

#strong[#text("Example 4")]#text(": (Tobias) ")#mi("[x,y]^{k+1}")#text(" is conjugate both to ")#mi("x(y[x^{-1},y^{-1}]^k x^{-1}y^{-1})")#text(" and to ")#mi("(y^{-1} [x,y]^k xy)x^{-1}")#text(", hence")

#tao-math("\\displaystyle \\left\\| [x,y] \\right\\| \\leq \\frac{1}{2k+2} ( \\left\\| y[x^{-1},y^{-1}]^k x^{-1} \\right\\| + \\left\\| (y^{-1} [x,y]^k xy)x^{-1}\\right\\|)", block: false)#linebreak()#text(" ")#tao-math("\\displaystyle = \\frac{1}{2k+2} (\\left\\| [x^{-1},y^{-1}]^k x^{-1} \\right\\| + \\left\\| [x,y]^k x \\right\\|).", block: false)

#text("(Example 1 is the ")#mi("k=1")#text(" case of Example 4.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cbc2d27be35b52d76218f729437fb6f59d7159dd6ad519e6b5824e55164b893-b88a1ccc43798cb3a67a8dee5b4ebd33a294ad10b1c2db24678b09ee1cd9bfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490518")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Here is an interesting consequence of Example 1 (maybe somebody said this already and I missed it). We now know we can replace both the ")#mi("2/3")#text(" in (iii) with ")#mi("1/2")#text(", so ")#mi("(\\alpha,\\beta) \\mapsto ((\\alpha+1)/2, \\beta/4)")#text(" is a valid map. If we iterate this we reach ")#mi("(1,0)")#text(", which means that ")#tao-math("\\left\\|[x,y]\\right\\| \\leq \\left\\|x\\right\\|", block: false)#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490523")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("With ")#mi("t=\\frac12")#text(" in (iii) we also get the bound ")#mi("(\\alpha,\\beta) = (\\frac47,\\frac17)")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490528")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("That’s a nice way to put it! This lemma can be applied nontrivially already with ")#mi("i=j=1")#text(". For example for ")#mi("k,m\\geq 1")#text(", this can be used to show that")

#mi("x^m[x,y]^k \\leq \\frac{1}{2}(x^{m-1}[x,y]^k + x^{m+1}[x,y]^{k-1}).")

#text("(I’m omitting the norm symbols here, either by abuse of notation or by interpreting these inequalities in terms of the partial order on the free abelian group ")#mi("\\mathbb{Z}[G]")#text(" generated by the defining inequalities of a norm.)")

#text("So in particular for ")#mi("m=k=1")#text(", we get")

#mi("x[x,y] \\leq \\frac{1}{2}[x,y] + x,")

#text("which may or may not be new. But I’m hoping to be able to do more by deriving more inequalities of the above type for ")#mi("x^m[x,y]^k")#text(".")

#text("By the way, perhaps it would be useful to have a list of inequalities and current best bounds somewhere that everyone could edit?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490532")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Ah, my thoughts exactly. I had even started a TeX file but it is very primitive. Since Terry has most of the Tex already written up, perhaps he could send it to someone (or compile the rest himself)? I am glad to do this on Friday my time if nobody has done so until then; it is currently 12:30am here and I was about to sleep.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490540")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Actually that system of inequalities looks promising to me. Writing ")#tao-math("\\alpha_{m,k} := \\left|\\left|x^m[x,y]^k\\right|\\right|", block: false)#text(", it says ")#mi("\\alpha_{m,k}\\leq \\frac{\\alpha_{m+1,k} + \\alpha_{m-1,k-1}}{2}")#text(", which can be iterated as we’ve done before. So in each iteration, the value at each grid point ")#mi("(m,k)")#text(" gets replaced by the average of the values of its left neighbour and of its ")#emph[#text("lower")]#text(" right neighbour. This must be the discrete version of some PDE, some sort of ‘heat equation with drift’, which I don’t know. For large times and for initial conditions that make ")#mi("\\alpha_{m,k}")#text(" linear in ")#mi("m")#text(" and ")#mi("k")#text(", I would expect ")#mi("\\alpha_{m,k}")#text(" to be close to the initial ")#tao-math("\\alpha_{m,0} = m\\left|\\left|x\\right|\\right|", block: false)#text(", which seems to be what we want: ")#tao-math("\\left|\\left|x^m[x,y]^k\\right|\\right| \\stackrel{?}{=} m\\left|\\left|x\\right|\\right|", block: false)#text(".")

#text("But this is quite speculative at the moment and there’s a number of things that are wrong with it. First of all, I’ve been ignoring boundary effects completely.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cbc2d27be35b52d76218f729437fb6f59d7159dd6ad519e6b5824e55164b893-b88a1ccc43798cb3a67a8dee5b4ebd33a294ad10b1c2db24678b09ee1cd9bfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490545")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("This looks plausible. The recurrence is related to the standard binomial recurrence, so is surely tractable, and numerically it gives what you guess. But is that useful? As in, suppose you knew ")#tao-math("\\left\\|x^m [x,y]^k\\right\\| = m\\left\\|x\\right\\|", block: false)#text(". Now what? This doesn’t seem to me to imply anything about ")#tao-math("\\left\\|[x,y]\\right\\|", block: false)#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cbc2d27be35b52d76218f729437fb6f59d7159dd6ad519e6b5824e55164b893-b88a1ccc43798cb3a67a8dee5b4ebd33a294ad10b1c2db24678b09ee1cd9bfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490546")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Ah, I guess you’re planning on combining it with something like Example 4 from Terry’s post. OK, looks legit.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490548")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Plugging in ")#mi("m=0")#text(" to ")#mi("x^m [x,y]^k | = m")#text(" shows ")#tao-math("\\left|[x,y]\\right|=0", block: false)#text(". Even if we only directly prove the claimed result for ")#mi("k>0")#text(", we have ")#tao-math("\\left|x [x,y]^k\\right| \\leq 1", block: false)#text(" so ")#tao-math("\\left|[x,y]\\right|^k \\leq 2", block: false)#text(" and then linearity shows ")#tao-math("\\left|[x,y]\\right|=0", block: false)#text(" as desired. (But I’m coming in in the middle, so maybe I missed something.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cbc2d27be35b52d76218f729437fb6f59d7159dd6ad519e6b5824e55164b893-b88a1ccc43798cb3a67a8dee5b4ebd33a294ad10b1c2db24678b09ee1cd9bfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490551")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("There won’t be any useful bound for ")#mi("m = 0")#text(" because that’s explicitly ruled out. I agree that any bounded ")#mi("m")#text(" would kill it, but that’s likely out too (judging from numerics). But maybe ")#mi("m \\approx \\sqrt{k}")#text(" or something would be fine.")

#text("Actually yeah this is probably going to kill it. I’ve just checked that from this that ")#tao-math("\\left\\|x^{10} [x,y]^{100}\\right\\| <= 20", block: false)#text(", which implies ")#tao-math("\\left\\|[x,y]\\right\\| \\leq 0.2", block: false)#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490561")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("I think this does indeed work to give arbitrarily small bounds on ")#tao-math("\\left\\|[x,y]\\right\\|", block: false)#text(", killing off the problem! One can work with some ")#mi("m")#text(" between ")#mi("\\sqrt{k}")#text(" and ")#mi("k")#text(", say ")#mi("m \\approx k^{2/3}")#text(". A simple random walk that starts at ")#mi("(m,k)")#text(" and repeatedly moves by a step ")#mi("(-1,0)")#text(" or ")#mi("(1,-1)")#text(" with a 1/2 probability of each will end up hitting ")#mi("(m^{\\prime},0)")#text(" for some ")#mi("m^{\\prime} \\approx m")#text(" with exponentially high probability by the Chernoff bound, which implies the bound ")#tao-math("\\left\\| x^m [x,y]^k \\right\\| \\ll m \\left\\|x\\right\\| + \\left\\| [x,y]\\right\\|", block: false)#text(", which by the triangle inequality gives ")#tao-math("\\left\\| [x,y]\\right\\| \\ll \\frac{m}{k} \\left\\|x\\right\\|", block: false)#text(", and sending ")#mi("k \\to \\infty")#text(" we win. I’ll write the details on the Wiki. EDIT: now available at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Linear_norm#Solution")[#text("http://michaelnielsen.org/polymath1/index.php?title=Linear_norm#Solution")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cbc2d27be35b52d76218f729437fb6f59d7159dd6ad519e6b5824e55164b893-b88a1ccc43798cb3a67a8dee5b4ebd33a294ad10b1c2db24678b09ee1cd9bfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490552")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("It implies that ")#tao-math("\\left\\|[x,y]\\right\\| \\leq .3", block: false)#text(" rather.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490565")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("The proof of the theorem in the wiki is not quite right — the inequality doesn’t quite work for ")#mi("m=0")#text(". Better to do it as you suggested above — start at the RW ")#mi("(k^{2/3},k)")#text(" and walk ")#mi("3k")#text(" steps. We are exponentially likely to have hit the lower boundary, and (stretched) exponentially very likely to have not walked horizontally more than ")#mi("k^{1/2+\\epsilon}")#text(". In the exponentially unlikely case we still have a linear bound on ")#mi("\\alpha_{m,k}")#text(". This gives the bound")

#tao-math("\\left\\|x^{k^{2/3}}[x,y]^k \\right\\| \\leq O(k^{2/3}) \\left\\|x\\right\\| + \\text{small}", block: false)

#text("so, by the triangle inequality,")

#tao-math("\\left\\| [x,y]^k \\right\\|\\leq O(k^{2/3}) \\left\\|x\\right\\| + \\text{small}", block: false)

#text("and we can now divide by ")#mi("k")#text(" and let ")#mi("k\\to\\infty")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490566")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Actually, it does seem to be that the proof of Corollary 7 continues to work for ")#mi("m")#text(" zero or negative, so the proof on the wiki I think works as stated (though the other way would also work).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cbc2d27be35b52d76218f729437fb6f59d7159dd6ad519e6b5824e55164b893-b88a1ccc43798cb3a67a8dee5b4ebd33a294ad10b1c2db24678b09ee1cd9bfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490568")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Very nice!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490570")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Right — the identities in Corollary 7 hold for all ")#mi("m,k")#text(" so your argument is simpler.")

#text("Very nice!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490571")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Wow! This blows my mind. And should make for some peaceful sleep ;)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490572")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("This is great — the problem is solved for all non-abelian groups! (For abelian groups — and other structures — I’d mentioned ")#link("http://arxiv.org/abs/1610.03037")[#text("http://arxiv.org/abs/1610.03037")]#text(".) In parallel to this, I’ll add the related question of considering (semi)norms on a more primitive algebraic/geometric structure: semigroups and monoids.")

#text("Does there exist a (bi/left/right-invariant) norm on a monoid, i.e. a distance that has linear growth?")

#text("The solution of course has to be different, since conjugations are no longer permitted. And this time there *is* a purported candidate, contrary to the case of groups — told to me by Robert Young to explore:")

#text("Consider the free monoid on a set, with the following distance between words: the number of single-character insertions or deletions it takes to go from one string to the other, so ")#mi("d(\"abcdef\", \"bdgef\") = 3")#text(" (delete ")#mi("a, c")#text(", insert ")#mi("g")#text("). Equivalently, the edit distance between v and w is")

#text("length(v)+length(w)-2*length(longest common subsequence).")

#text("Is this a (bi/left/right-invariant) norm?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490547")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Combined with the obvious bound ")#mi("\\alpha_{m,k} \\leq m+2k")#text(" (we could replace ")#mi("2")#text(" by another constant but it doesn’t effect the end result), it is easy to show by induction on ")#mi("k")#text(" that ")#mi("\\alpha_{m,k} \\leq m")#text(" for ")#mi("m \\geq k")#text(". Your formula doesn’t give a bound for ")#mi("\\alpha_{0,k}")#text(". Using the obvious formula ")#mi("\\alpha_{0,k} \\leq \\alpha_{1,k}+1")#text(", we can recursively compute a triangular array of bounds for ")#mi("\\alpha_{m,k}")#text(" for ")#mi("0 \\leq m \\leq k")#text(". Here are the first 10 bounds for ")#mi("\\alpha_{0,k}")

#text("{2, 3, 15/4, 35/8, 315/64, 693/128, 3003/512, 6435/1024,")#linebreak()#text(" 109395/16384, 230945/32768, 969969/131072, 2028117/262144,")#linebreak()#text(" 16900975/2097152, 35102025/4194304, 145422675/16777216,")#linebreak()#text(" 300540195/33554432, 9917826435/1073741824, 20419054425/2147483648,")#linebreak()#text(" 83945001525/8589934592, 172308161025/17179869184} =")#linebreak()#text(" {2., 3., 3.75, 4.375, 4.92188, 5.41406, 5.86523, 6.28418, 6.67694,")#linebreak()#text(" 7.04788, 7.40028, 7.73665, 8.05901, 8.36897, 8.66787, 8.9568, 9.2367,")#linebreak()#text(" 9.50836, 9.77248, 10.0297}")

#text("It’s hard to tell whether or not this growth is sublinear. One should be able to get asymptotics using generating functions. I’ll try this tonight if someone doesn’t beat me to it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490550")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("As Sean has noted, that system is simple enough to solve explicitly, at least as long as we are away from the boundary. So after ")#mi("t")#text(" iterations we have, at ")#mi("m,k\\geq t")#text(",")

#mi("\\alpha_{m,k}^{(t)} = 2^{-t} \\sum_{s=0}^t \\binom{t}{s} \\alpha_{m+t-2s,k-s}^{(0)} = 2^{-t} \\sum_{s=0}^t \\binom{t}{s} \\left(m+t-2s+\\frac{2}{3}k - \\frac{2}{3}s \\right) = m + \\frac{2}{3}k - \\tfrac{1}{3}t,")

#text("where I’ve taken ")#tao-math("\\left|\\left|x\\right|\\right|,\\:\\left|\\left|y\\right|\\right|\\leq 1", block: false)#text(" for simplicity, and the second equation uses initial conditions based on our current best bound ")#tao-math("\\left|\\left|[x,y]\\right|\\right|\\leq 2/3", block: false)#text(", meaning ")#mi("\\alpha_{m,k}^{(0)} = m+\\tfrac{2}{3}k")#text(".")

#text("Assuming that my computations are correct, this shows that ")#tao-math("\\left|\\left|x^m[x,y]^k\\right|\\right|\\leq m + \\frac{2}{3}k - \\tfrac{1}{3}\\min\\{k,m\\}", block: false)#text(", recovering our earlier bounds ")#tao-math("\\left|\\left|x[x,y]\\right|\\right|\\leq 4/3", block: false)#text(" and ")#tao-math("\\left|\\left|x[x,y]^2\\right|\\right|\\leq 2", block: false)#text(".")

#text("Iterating the system for ")#mi("t > \\min\\{m,k\\}")#text(" iterations will give further improvements, but requires working out the boundary conditions; David has suggested how to do this at the ")#mi("m=0")#text(" boundary; the ")#mi("k=0")#text(" boundary is easier, since there we can just take ")#mi("\\alpha_{m,0}^{(t)} = m")#text(" for all ")#mi("t")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490555")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("You may as well take your boundary condition to be ")#mi("\\alpha_{m,m} = m")#text(", since that is the limit as ")#mi("t \\to \\infty")#text(". All the interest is in the range ")#mi("m \\leq k")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490557")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("1. Note that the fixed points of the iteration are linear in the boundary conditions. Since our boundary conditions are linear functions in ")#mi("m,k")#text(" you can take the boundary conditions to depend each variable separately and sum the results.")

#text("Those recursions are easy to solve directly, and I think you get linear growth.")

#text("2. I think it’s better to define ")#mi("\\alpha_{m,k},\\beta_{m,k}")#text(" by ")#tao-math("\\left\\| x^m[x,y]^k \\right\\| \\leq \\alpha_{m,k}\\left\\| x\\right\\| + \\beta_{m,k}\\left\\| y\\right\\|", block: false)#text(". For example this gives the boundary conditions ")#mi("\\alpha_{m,0} = m")#text(" but ")#mi("\\beta_{m,0} = 0")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490558")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("I also forgot to add that the best bounds used the symmetry of the commutator: that ")#mi("\\alpha_{0,1} = \\alpha = \\beta = \\beta_{0,1}")#text(". In other words, it’s useful to add a switch of ")#mi("\\alpha,\\beta")#text("-values along the ")#mi("k")#text("-axis to the iteration scheme.")

#text("Should also build in ")#mi("\\alpha_{0,k} = k\\alpha_{0,1}, \\beta_{0,k} = k\\beta_{0,1})")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490541")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Terry: can you or Michael Nielsen start a page on the polymath wiki as suggested by Tobias? This can be “mini-polymath 5”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490553")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Tobias, I was not able to establish this inequality. I’ve put it on the wiki page ")#link("http://michaelnielsen.org/polymath1/index.php?title=Linear_norm")[#text("http://michaelnielsen.org/polymath1/index.php?title=Linear_norm")]#text(" as Corollary 7, feel free to insert a proof.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490556")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Done; now the details are there for everyone to check. I hope that I haven’t made some silly mistake.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490542")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("One cute application of the lemma: ")#tao-math("\\left\\|x^n y \\right\\| \\leq \\frac{1}{2} ( \\left\\|x^{n-1} y\\right\\| + \\left\\| x^{n+1} y \\right\\| )", block: false)#text(" for any ")#mi("n \\geq 1")#text(", since ")#mi("x^n y")#text(" is conjugate to both ")#mi("x( x^{n-1} y)")#text(" and ")#mi("(x^{n+1} y) x^{-1}")#text(". Thus the function ")#tao-math("n \\mapsto \\left\\| x^n y \\right\\|", block: false)#text(" is convex in ")#mi("n")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490544")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("I am starting work on a wiki page to collect and organise the various estimates at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Linear_norm")[#text("http://michaelnielsen.org/polymath1/index.php?title=Linear_norm")]#text(" . Right now it is only a stub but I will work on expanding it.")
]
