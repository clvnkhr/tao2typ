// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/
// Converted to Typst by tao2typ: "2026-10-14T16:36:19.448338+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Covering a non-closed interval by disjoint closed intervals", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Covering a non-closed interval by disjoint closed intervals")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 October 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/")[#text("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The following question came up in my 245A class today:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Is it possible to express a non-closed interval in the real line, such as [0,1), as a countable union of disjoint closed intervals?")
]

#text("I was not able to answer the question immediately, but by the end of the class some of the students had come up with an answer. It is actually a nice little test of one’s basic knowledge of real analysis, so I am posing it here as well for anyone else who is interested. Below the fold is the answer to the question (whited out; one has to highlight the text in order to read it).")

#metadata(none) <tao-d38a49b9e6fdbf096380>#text("The answer to the question is… no.")

#text("First of all, it suffices to prove the claim for an open interval such as (0,1). For, if one partitions a half-open interval such as [0,1) into closed intervals, then after selecting any one of these intervals [a,b], the open interval (b,1) must then also be partitioned into countably many disjoint closed intervals.")

#text("By mapping (0,1) homeomorphically to the real line, it suffices to show that the real line R cannot be partitioned into closed intervals.")

#text("As each interval is bounded, we need an infinite number of intervals ")#mi("I_n = [a_n,b_n]")#text(" to cover the real line. Now consider the set")

#align(center)[#tao-fit-display[#mitex("E := \\bigcup_{n=1}^\\infty \\{a_n,b_n\\}")]]

#text("consisting of the endpoints of the intervals ")#mi("I_n")#text(". Clearly, E is countably infinite. Also, as the ")#mi("I_n")#text(" form a disjoint cover of E, E is the complement of the open set ")#mi("\\bigcup_{n=1}^\\infty (a_n,b_n)")#text(" and is hence closed. Finally, we claim that E is ")#link("http://en.wikipedia.org/wiki/Perfect_set")[#text("perfect")]#text(": that not only is E closed, but every point in E is a limit point in E. Indeed, if x lies in E, then x is either the left or right endpoint of an interval ")#mi("I_n")#text(", but it is not both. If it is, say, the right-endpoint of an interval, then by approaching x from the right we see that x is the limit of the left endpoint of intervals to the right of x.")

#text("Now we appeal to a general theorem (a special case of the even more general ")#link("http://en.wikipedia.org/wiki/Baire_category_theorem")[#text("Baire category theorem")]#text(") that asserts that a perfect subset of a complete metric space cannot be countably infinite. A proof is as follows. Suppose for contradiction that ")#mi("E = \\{ x_1, x_2, x_3, \\ldots\\}")#text(" is a countably infinite perfect set. Let ")#mi("B_1")#text(" be any closed ball of positive radius whose centre lies in E (e.g. one can take the closed ball of radius 1 centered at ")#mi("x_1")#text("). Using the fact that ")#mi("x_1")#text(" is a limit point, one can then find a closed ball ")#mi("B_2")#text(" inside ")#mi("B_1")#text(" whose centre still lies in E, but which is disjoint from ")#mi("x_1")#text(", and whose radius is at most half that of ")#mi("B_1")#text(". (Indeed, if ")#mi("x_1")#text(" does not already lie in the interior of ")#mi("B_1")#text(", one simply has to shrink ")#mi("B_1")#text(" by a little bit and recenter to another element of E to move ")#mi("x_1")#text(" off the boundary of ")#mi("B_1")#text("; otherwise, one uses the limit point property to find another point in the interior of ")#mi("B_1")#text(" other than ")#mi("x_1")#text(", and makes a small closed ball around that.) Then one can find a closed ball ")#mi("B_3")#text(" inside ")#mi("B_2")#text(" of radius at most half that of ")#mi("B_2")#text(" whose centre still lies in E, but is now also disjoint from ")#mi("x_2")#text(" in addition to ")#mi("x_1")#text(". Continuing in this fashion we find a sequence ")#mi("B_1, B_2, B_3, \\ldots")#text(" of nested closed balls with radii going to zero, each of which has centre in E. The centres of these balls then form a Cauchy sequence, which by completeness, must converge to a limit in E that also lies in ")#mi("\\bigcap_{n=1}^\\infty B_n")#text(". But by construction, ")#mi("\\bigcap_{n=1}^\\infty B_n")#text(" lies outside each element ")#mi("x_n")#text(" of E, and is thus disjoint from E, a contradiction.")

#text("Several of the students also came up with a proof based on the fact that the set E had the topological structure of a Cantor set, which is necessarily uncountable. This is close to the proof given above, though the above proof has the advantage that it is more readily generalisable to higher dimensions, ")#text("showing for instance that a non-closed box cannot be expressed as the countable union of closed boxes. (For the generalisation, one has to use the full strength of the Baire category theorem, rather than just relying on the theory of perfect sets.) UPDATE: as pointed out in comments, the higher-dimensional result can also be easily deduced from the one-dimensional result by looking at a slice.")

#text("Note that if one replaces the reals in the question by the rationals, then the answer to the question becomes “yes” (this is easiest to see if one uses closed intervals of zero length, though one can also concoct examples using positive length intervals also). This shows that any proof must use a property of the real line, such as completeness, that is not shared by the rationals, and so it is unlikely that there is any elementary proof that is significantly shorter than the one given above.")

#heading(level: 1)[#text("Comments (59)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47404")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2010")])]

#text("“If it is, say, the __right__-endpoint of an interval, then by approaching x from the right we see that x is the limit of the left endpoint of intervals to the right of x.” ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47405")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2010")])]

#text("The formulas in this post are completely messed up.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47406")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2010")])]

#text("Oh, no. It is not messed formulas. It is (in some mysterious reason) invisible text on the page (white on white).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47407")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2010")])]

#text("Oh, sorry, Terry, for this stupid comment. Now I see that you intentionally whited up the text.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-523528")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2019")])]

#text("oh I am still confused about the text")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74bec5665586fa7592c7dc0980cfde5558db478aa11c7a6454e2879bafd4fdfa-b5ba177265e83dda077d072769c5fe0e881e20dd623dd100d1d08f4c49b86394.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47408")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2010")])]

#text("Another question that I still dont know how to prove is:")

#text("Thm:Show that a union of open intervals can be written as a disjoint union of open intervals.")

#text("Induction isn’t enough because induction just works for a finite number of arbitrary open intervals.")

#text("I know how where to find the answer, but I want to solve it by myself. I am more than one week trying to solve it. :o)")

#text("Best")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-49348")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2011")])]

#text("I do not have access to Follands book right now, but nevertheless, I tried to proof Students question.")

#text("Theorem: Any open subset U of R may be expressed as a disjoint union of open intervals. (this implies his question as any union of open intervals is an open subset of R) [R being the real set]")#linebreak()#text(" Proof: Consider the intersection V of U and Q [Q being the rational numbers]. Note that V is countably infinite.")#linebreak()#text(" For each q in V, define")#linebreak()#text(" A_q = inf{a in U | (a,q) is a subset of U}")#linebreak()#text(" B_q = sup{b in U | (q, b) is a subset of U}")#linebreak()#text(" Both values exist in R because U is open.")#linebreak()#text(" Now, I_q = (A_q, B_q) is an open interval fully contained in U. Because if x is in I_q but not in U, it would contradict our definition of either A_q or B_q.")#linebreak()#text(" We obtain a countably infinite amount of intervals I_q, and for q1 and q2 in V we either have")#linebreak()#text(" I_q1 = I_q2, or")#linebreak()#text(" I_q1 and I_q2 are disjoint. (because if two intervals intersect in any point, they have to be the same by our construction)")#linebreak()#text(" Also, because Q is a dense subset of R and U is open, any x in U is an element of I_q for some q in V (consider an open ball around x, and a rational number q within that ball), so we conclude that the union of all I_q equals U.")

#text("This may seem sketchy, but being a foreign undergraduate is leaving me with some problems to express myself precisely.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-523530")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2019")])]

#text("Any open set in ")#mi("\\mathbb R^n")#text(" (and in other topological spaces) is a disjoint union of its (open) connected components.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gautam")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-232270")[#strong[#text("Gautam")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2013")])]

#text("“A Course on Borel Sets” by S M Srivastava. pg.51.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-471398")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2016")])]

#text("The intersection of open intervals is open. Deleting the intersection from one of the offending pairs of open intervals gives two open intervals with equal union.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-471399")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2016")])]

#text("*one from")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-471402")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2016")])]

#text("Intersection of open intervals is not necessarily open (e.g. the intersection of all open intervals containing a closed interval).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9600342ea6c4a9d9b3c467fc166a1c600cb8a5a49b7acc1a145414977e095f9a-e44c4910e771211e44bed0cc8479a2c89f24a6b6a9c6908e32ecf8da5d7ecfcb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ugroh")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47411")[#strong[#text("ugroh")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2010")])]

#text("Remark to the Student-question: A proof can be found e.g. in Folland, Real Analysis, Prop. 0.21 .")

#text("Ulrich")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8889a7cf5518f17e84a86b936b230be227831b59945aa66c9b6d216edf708424-f258b44d46473c2f0fa705e036330056f9ee5efacbe02fb73dd104d6aa943df4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Milovich")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47414")[#strong[#text("David Milovich")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2010")])]

#text("Cantor’s original proof of the reals’ uncountability")#linebreak()#text(" can be adapted to get a shorter elementary proof.")

#text("Start with [0,1) and a sequence (C_n:n=0,1,2,…)")#linebreak()#text(" of disjoint closed subintervals of [0,1).")#linebreak()#text(" Choose i_0 and j_0 such that C_(i_0)<C_(j_0).")#linebreak()#text(" Given C_(i_n)<C_(j_n),")#linebreak()#text(" choose the least i_(n+1) such that")#linebreak()#text(" C_(i_n)<C_(i_(n+1))<C_(j_n).")#linebreak()#text(" Then choose some j_(n+1) such that")#linebreak()#text(" C_(i_(n+1))<C_(j_(n+1))<C_(j_n).")

#text("Let x be the supremum of the union")#linebreak()#text(" of all sets of the form C_(i_n).")#linebreak()#text(" Given any n, since C_(i_n)<x<C_(j_n) and i_(n+1) is")#linebreak()#text(" minimal with respect to C_(i_n)<C_(i_(n+1))<C_(j_n),")#linebreak()#text(" x cannot be in C_k for any k<i_(n+1).")#linebreak()#text(" Thus, for all n, x is not in C_k for any k<i_(n+1).")#linebreak()#text(" But C_(i_n)<C_(i_(n+1)), so the sequence (i_n:n=0,1,2,…)")#linebreak()#text(" never repeats, which implies that the sequence is")#linebreak()#text(" unbounded, which implies that x is not in any C_k.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marton Eekes")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47419")[#strong[#text("Marton Eekes")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2010")])]

#text("A slightly harder nice exercise is (I only modified the very last word):")

#text("Is it possible to express a non-closed interval in the real line, such as [0,1), as a countable union of disjoint closed sets?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47435")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2010")])]

#text("Using the hint on the Baire category theorem one could also infer that a complete connected metric space is not a countable union of disjoint closed subsets. I am not sure whether this result generalizes to Baire spaces, though.")

#text("best regards, pavel")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47437")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2010")])]

#text("I have noticed an error in my reasoning: the space should also be locally connected. Nevertheless, I do not have a counterexample if local connectedness does not hold.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47477")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2010")])]

#text("Here is a counterexample, i.e. a connected complete metric space which is a countable union of closed sets:")

#text("Let {e_{i,j}; i>0, j≥0} be orthonormal vectors in a Hilbert space.")

#text("Let S_i consist of the closed interval [e_{i,0}, 2 e_{i,0}] and the polylines from 2 e_{i,0} to 2 e_{i,0}+e_{i,j} to e_{j,0}+e_{i,j} to e_{j,0}+e_{i,j}/i.")

#text("Then S_i are closed and their union is complete and connected. This set is best visualized as countably many intervals, each of which has antennae in the direction of an endpoint of each other set.")

#text("Note that the boundary of each S_i is just {e_{i,0}}, hence the union of the boundaries is a discrete set (as opposed to a perfect set in the case of intervals on the real line)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47452")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2010")])]

#text("I remembered that we used to call such sets $F_\\sigma^*$ on the problem solving seminar.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47508")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2010")])]

#text("I am ignorant of the difference of a closed set and a closed interval of the real line. Can’t any closed set ve decomposed into closed intervals?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb655f368d3370a90fe3a902af2daf7bcf375c34b0862482659831a6066a2dc3-1fdfd626cb7358163882529c2c80811b4523dc05026e7aba892223b858538ecc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mircea petrache")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47422")[#strong[#text("mircea petrache")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2010")])]

#text("Take a V-shaped function u:[0,1]->[0,1] such that u(0)=u(1)=1 and u(1/2)=0, and such that u is piecewise affine on [0,1/2], [1/2,1].")

#text("Take now a family of intervals which would falsify the theorem. On one such interval [a,b] put v(x)=u((x-a)/(b-a)), then define v(1)=v(0)=1. So from the set of intervals of the text, we got a continuous function v:[0,1]->[0,1], which is =1 just on the union of extrema of the segments.")

#text("v is uniformly continuous, but this contradicts the fact that the lenghts of intervals can be arbitrarily small (thus the slope of v is unbounded).")

#text("does this make sense?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Hagge")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47427")[#strong[#text("Tobias Hagge")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2010")])]

#text("Thank you for your wonderful blog. Here is an argument that uses the compactness of closed intervals in ")#mi("\\mathbb{R}")#text(".")

#text("Given a sequence ")#mi("([a_i, b_i])_{i\\in \\mathbb{N}^+}")#text(" of disjoint closed intervals in ")#mi("(0,1)")#text(", let ")#mi("C_n = \\cup_{i=1}^n [a_i,b_i]")#text(". We’ll construct a nested sequence of nonempty closed intervals ")#mi("S_i")#text(" such that ")#mi("C_i")#text(" and ")#mi("S_i")#text(" are disjoint. The intersection of such is nonempty and does not intersect any ")#mi("[a_i,b_i]")#text(".")

#text("Choose ")#mi("S_0= [c_0,d_0]")#text(" such that ")#mi("c_0 < a_1")#text(" and $a_1 < d_0 < b_1$. If ")#mi("[a_i,b_i]")#text(" is disjoint from ")#mi("S_{i-1}")#text(", let ")#mi("S_i = S_{i-1}")#text(". Otherwise, suppose that ")#mi("S_{i-1} - C_i = [c,d)")#text(". This lies in some component ")#mi("(e,d)")#text(" of the complement of ")#mi("C_i")#text(" in ")#mi("(0,1)")#text(". Set ")#mi("S_i = [c_i,d_i]")#text(", where ")#mi("c <c_i<d_i <d")#text(", chosen so that the least-indexed $[a_i,b_i]$ which lies in ")#mi("(e,d)")#text(" contains ")#mi("c_i")#text(" but not ")#mi("d_i")#text(". The case ")#mi("S_{i-1} - C_i = (c,d]")#text(" is similar.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d509e4a67398165676196d672585ced90e7a9aff3d5e153a8ae82ca3a3719829-6913ece6216ee2882ebb73ce44bcf73b0437e510ad495f289d6450d43f808d08.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Danny Calegari")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47434")[#strong[#text("Danny Calegari")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2010")])]

#text("I think this is a theorem of Sierpinski; the reference I have in mind is “Un theoreme sur les continus” (Tohoku Math 13 (1918) 300-303) but I don’t have the reference handy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47448")[#strong[#text("Top Posts — WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2010")]

#text("[…] Covering a non-closed interval by disjoint closed intervals The following question came up in my 245A class today: Is it possible to express a non-closed interval in the real […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/12ac67459ae8697b4dd7a5c15952868c41b5fbe651408585132aed5e2379190c-aa651e2dd0044893141275bd69956fb1b6e7c627e1bd6c485de82aa57ae81b3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Hagge")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47451")[#strong[#text("Tobias Hagge")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2010")])]

#text("One may give a purely topological proof by constructing a nested sequence of closed intervals S_n, the intersection of which is disjoint from the union of the I_n. Suppose S_n is chosen so that for the least k such that I_k is not disjoint from S_n, S_n – I_k is a half-open interval. Inside of this half-open interval is a closed subinterval S_{n+1} with the same property and larger least k.")

#text("This gives the result for any dense total order on which closed intervals are compact. However, I’m having a little trouble comparing the generality of that argument to the argument in the post. Are such spaces always metrizable?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/12ac67459ae8697b4dd7a5c15952868c41b5fbe651408585132aed5e2379190c-aa651e2dd0044893141275bd69956fb1b6e7c627e1bd6c485de82aa57ae81b3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Hagge")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47479")[#strong[#text("Tobias Hagge")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2010")])]

#text("Why the down vote?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/12ac67459ae8697b4dd7a5c15952868c41b5fbe651408585132aed5e2379190c-aa651e2dd0044893141275bd69956fb1b6e7c627e1bd6c485de82aa57ae81b3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Hagge")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47537")[#strong[#text("Tobias Hagge")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2010")])]

#text("To answer my own question, no. Counterexample: the hyperreals. More general counterexample: the Dedekind-MacNeille completion of any non-metrizable total order. By the least upper bound property, closed intervals are compact. The completion is not metrizable since it has a non-metrizable subspace.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47455")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2010")])]

#text("In Cambridge this is a well-known “exercise for the enthusiast” that has been tackled by several generations of the brighter undergraduates.")

#text("As a little experiment, I just typed “Can [0,1] be covered by countably many disjoint closed intervals?” into Google (with no inverted commas) and this post came up first. So now there will be an easy way of solving the problem. I wonder if eventually this method will work for all exercises. (I’ve just tried it for one or two other questions and it didn’t work, so we haven’t reached this state yet.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91841f5e59201923e09be98a5cf5917591fef164a2a040b79e78d927874dd4bf-c2c4379bfc95793e545279b1b6a44f80c80394352dfb8cc2ea2a9f97264ce0e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47462")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2010")])]

#text("No, in fact we have the opposite problem: it’s often inconveniently difficult to find the answers to basic mathematical questions by searching online.")

#text("(I had a rare success with this the other day when looking for an example of a differentiable function that isn’t continuously differentiable. After a surprisingly long few minutes I found what I was looking for, but in general this is the type of thing that is difficult to find: things that “everyone knows” but that don’t have standard names.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd510153472d42259abe891371a9140439ab72dc5aa8848d761d2e48f1e899d9-2e0699aeb9766f97b1339747600ff56c22895e546e51a43aa4682fc541c0b300.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xueping")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47456")[#strong[#text("Xueping")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2010")])]

#text("I have a different proof which I can’t judge whether it’s available.")#linebreak()#text(" Observation: Let $ (a_n, b_n)$ be a strictly decreasing sequence of open intervals. If $a_n < a_{n+1}< b_{n+1}<b_{n}$ is always true, then their intersection is not empty.")

#text("Suppose that $(0,1)= \\cup [c_n , d_n]$, where $ [c_n , d_n]$ are disjoint. Take $A_0 =(0,1)$.")#linebreak()#text(" Consider the complement of $[c_1 ,d_1]$, $(0, c_1) \\cup (c_2, 1)$, $[c_2, d_2]$ must lie in one of the two intervals, say $(0, c_1) $ for example.")#linebreak()#text(" Then take $A_1 =(d_2 , c_1)$. Wait until the next $[c_i, d_i]$ lies in $A_1$ and another $[c_k, d_k]$ divides an interval of the complement of $[c_i, d_i]$ in $A_1$. Then in the resulting two intervals, choose one that has no common endpoints with $A_1$ to be $A_2$. Inductively we can get a strictly decreasing sequence of open intervals $A_n$, which satisfies that the endpoints never coincide. As a consequence, the intersection of them is nonempty.")#linebreak()#text(" From the construction, we can see that this intersection is a subset of the complement $\\cup [c_n , d_n]$, which is empty. A contradiction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd510153472d42259abe891371a9140439ab72dc5aa8848d761d2e48f1e899d9-2e0699aeb9766f97b1339747600ff56c22895e546e51a43aa4682fc541c0b300.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of huangxueping")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47457")[#strong[#text("huangxueping")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2010")])]

#text("I have a different proof which I can’t judge whether it’s available.")#linebreak()#text(" Observation: Let ")#mi("(a_n, b_n)")#text(" be a strictly decreasing sequence of open intervals. If ")#mi("a_n < a_{n+1}< b_{n+1}<b_{n}")#text(" is always true, then their intersection is not empty.")

#text("Suppose that ")#mi("(0,1)= \\cup [c_n , d_n]")#text(", where ")#mi("[c_n , d_n]")#text(" are disjoint. Take ")#mi("A_0 =(0,1)")#text(".")#linebreak()#text(" Consider the complement of ")#mi("[c_1 ,d_1]")#text(", ")#mi("(0, c_1) \\cup (c_2, 1)")#text(", ")#mi("[c_2, d_2]")#text(" must lie in one of the two intervals, say ")#mi("(0, c_1)")#text(" for example.")#linebreak()#text(" Then take ")#mi("A_1 =(d_2 , c_1)")#text(". Wait until the next ")#mi("[c_i, d_i]")#text(" lies in ")#mi("A_1")#text(" and another ")#mi("[c_k, d_k]")#text(" divides one interval of the complement of ")#mi("[c_i, d_i]")#text(" in ")#mi("A_1")#text(" into two intervals . Then in the resulting two intervals, choose one that has no common endpoints with ")#mi("A_1")#text(" to be ")#mi("A_2")#text(". Inductively we can get a strictly decreasing sequence of open intervals ")#mi("A_n")#text(", which satisfies that their endpoints never coincide. As a consequence, the intersection of them is nonempty.")#linebreak()#text(" From the construction, we can see that this intersection is a subset of the complement ")#mi("\\cup [c_n , d_n]")#text(", which is empty. A contradiction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leena")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47499")[#strong[#text("Leena")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2010")])]

#text(":huangxueping I am sorry but I feel this does not complete the proof… cuz a closed set in (0,1) need not necessarily be in the form [c,d] it could be something like {a,b,c,d} etc…The above proof proves that (0,1) can not be written as a union of disjoint connected and closed subsets of (0,1). I guess We need a more general prof for the above thm.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-240121")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2013")])]

#text("I think this proof also generalizes to the case of closed sets. Consider the complement of each closed set, which is open and can be written as a countable union of open intervals. It is easy to see that there cannot be only one open interval (since the complement is not connected), so you still have the freedom of choice to make a nested sequence of open intervals whose intersection is not empty.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-240122")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2013")])]

#text("Is this proof morally the same as Hagge’s?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aae63a793e21ba239ceef13e0fa1910aed10576bee1e247cad2d5d5dd2c00745-490845dda6d4ad1ace8df3a57513884fc979f98ad195de04f9284b622da59d55.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J Balachandran")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47461")[#strong[#text("J Balachandran")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2010")])]

#text("I might be misunderstanding the question. If I’m correct a finite union of closed sets in a closed set. However the given set is not closed since the limit point 1 does not belong to the set. So there is no way we can have a closed set to represent this non-closed set. Is this reasoning correct? If wrong can someone highlight me where the mistake is")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47466")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2010")])]

#text("Not quite. The question is whether the open set can be expressed as a *countable* union of closed sets (ie infinite unions are allowed). Your explanation only holds if we are constrained to a *finite* union of closed sets.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aae63a793e21ba239ceef13e0fa1910aed10576bee1e247cad2d5d5dd2c00745-490845dda6d4ad1ace8df3a57513884fc979f98ad195de04f9284b622da59d55.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J Balachandran")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47478")[#strong[#text("J Balachandran")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2010")])]

#text("Oh ok. sorry. I got the mistake")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c18447788622f4b07a911f2987fbfc936b33c184d26523b2f48bda19edba8c4-1a22b1dffcc73b00078ad604f783567bb7705d2548ef5b4fc70128067d9dd58f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Weinstein")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47463")[#strong[#text("Jonathan Weinstein")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2010")])]

#text("J Balachandran: It’s a countable union, not finite, so not necessarily closed.")

#text("Huang Xueping: Very nice. You ruined my day though, I solved it your way and scrolled through the first 15 comments without seeing this…oh well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leena")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47498")[#strong[#text("Leena")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2010")])]

#text("but the sets are disjoint… so even if it is a countable union and not finite … it is still a closed set….. if we take its closure … we realize its a closed set.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4fd1352f364285fd5e066b1450b718cc4304e28e07e727a24605893b1c01432-bf4a9c28b7234ea8a3ae3d29eb412a97af1a523be9b789474365b9a91e12fbba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47570")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2010")])]

#text("What about intervals of the form")#linebreak()#text(" [1/(2^(2n+1)),1/(2^(2n)]")#linebreak()#text(" Take the union (for natural numbers n) of all such intervals and 0 is a limit point. Thus, a countable union of disjoint closed intervals need not be a closed set.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47464")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2010")])]

#text("First, Huang Xueping’s proof can basically be modified to work for the more general question of covering (or not) by closed SETS (posed by Marton Eekes).")

#text("Second, to generalize this to higher dimensions (can the open unit ball be covered by countably many disjoint closed SETS in Euclidean space?), is it not enough to intersect with the “X-axis”? For if there were such a cover, then the intersection with the X-axis would give a countable cover of (-1,1) by disjoint closed sets, which is false.")

#emph[#text("[Good point; I’ve added a mention of this in the post. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47465")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2010")])]

#text("Curiously, I first saw the (more general, ref. Eekes) problem eight years ago in graduate school (and I solved it essentially by Huang Xueping’s method too), as well as the “higher dimensions” variant. Just recently, I asked it of my students here at Yale, some three weeks ago! Then I posed it to a friend in Ann Arbor, and he asked it of his students 1-2 weeks ago. Curiously, the same problem showed up in Prof. Tao’s class in UCLA this week.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a5052e44e0d2d52fb5b63f8f92f0b89986297d4bf09d102a86d3c80c1d472b32-71503d431d6d9983a2883615e33e54dfe728793a5f3404b284c6c8ccfa176bff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koen van Woerden")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47473")[#strong[#text("Koen van Woerden")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2010")])]

#text("Suppose a countable cover ")#mi("I_n")#text(" of closed disjoint sets of the interval ")#mi("(0,1)")#text(" exists.")

#text("Define the function ")#mi("f:(0,1) \\to \\mathbf{R}")#text(" as follows: each ")#mi("x")#text(" in ")#mi("(0,1)")#text(" is covered by precisely one ")#mi("I_n")#text(". Send ")#mi("x")#text(" to ")#mi("n")#text(". Then ")#mi("f")#text(" is continuous, and since the image of $f$ is contained in the natural numbers, by the intermediate value theorem ")#mi("f")#text(" is constant. Hence ")#mi("(0,1)")#text(" is covered by a single closed interval. Hence ")#mi("(0,1)")#text(" is closed. Contradiction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a5052e44e0d2d52fb5b63f8f92f0b89986297d4bf09d102a86d3c80c1d472b32-71503d431d6d9983a2883615e33e54dfe728793a5f3404b284c6c8ccfa176bff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koen van Woerden")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47474")[#strong[#text("Koen van Woerden")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2010")])]

#text("Never mind, this is not a good proof. Sorry for that.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9226041291ef97d7e12fb7c418a4e38f95f6da50a8267b7de2dddf2a568a618-ef7985d888a71a03da8603e87d32cd792294c0458b6ee132de5e89a9028aa794.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liu Shiping")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47475")[#strong[#text("Liu Shiping")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2010")])]

#text("Also, as the $I_n$ form a disjoint partition of E,")

#text("I guess it should be a disjoint partition of the real line.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60b322690c6c8d054e7e9c538bdc97493feeccef46063c5523a0db967d897009-ee4b3afc436df78c7aac572b968ac8036e9db2dac0b56771b43ccb18ac519e29.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of some graduate student")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47480")[#strong[#text("some graduate student")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2010")])]

#text("This confused me too. Usually a “partition” is a collection of subsets of the set satisfying certain conditions — but the I_n aren’t subsets of E.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27e8412f888c569a9be1ea171fca277001b3529b40fd5b744477630ab233b68c-05bad328c0ff3a76596d1574691a67abec98c1884bc3f88e4c852126de63b9c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mircea petrache")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47483")[#strong[#text("mircea petrache")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2010")])]

#text("I try to make a proof like Koen van Woerden’s, i.e. using functions and continuity. It looks elementary just because the key points are left to the reader.")

#text("Take a square [0,1]x[-1,0], and consider the inscribed semicircle with diameter the “upper” side [0,1]x{0}. Now suppose a family as in the theorem exists. Then for each segment I in the family, put a shrinked copy of the above square. Then the union of the “shrinked semicircles” will describe the graph of a continuous function (since at the end points of any segment, shorter segments accumulate from one side).")

#text("But this also would define a continuous function on [0,1] (if you extend to zero at the extrema). Thus it should also be uniformly continuous. Still, the fact that the length of segments is arbitrarily close to 0 (and the fact that the tangent to the semicircles is vertical), contradicts any choice of modulus of continuity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27e8412f888c569a9be1ea171fca277001b3529b40fd5b744477630ab233b68c-05bad328c0ff3a76596d1574691a67abec98c1884bc3f88e4c852126de63b9c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mircea petrache")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47484")[#strong[#text("mircea petrache")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2010")])]

#text("again the proof was wrong, maybe stretching the vertical direction of the squares to square root of I makes it work")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e5fe3d47066842fa01ee26395f5b2bab73fa6304d895a37b86989d027f16f3b-ff4ebe4e3ba1b4812672a0263b39dd4c6f3a78ad9fdabef73f94928be466c0a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vladimir Slepnev")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47485")[#strong[#text("Vladimir Slepnev")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2010")])]

#text("I got the answer “no” by the following argument that sounds very natural to me: 1) reduce the problem to the open interval like you did, 2) removing a closed interval turns an open interval into two open intervals, 3) repeating the process countably many times leaves us with a binary tree of intervals, 4) if some interval never gets split then we have our answer, 5) if all intervals get split then alternating left-right-left-right-… gives us an intersection point. Completeness is used in the last step.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0c42e04465ef2446f1c7c611a2103bce1c51a208c5c7f0abfbeda71c3c64226-fe0c27e81d11365aaf7d459a3b91cd420018eeaeb00ef680a8b2048f6ef13ddc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arindam Bandyopadhyay")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47494")[#strong[#text("Arindam Bandyopadhyay")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2010")])]

#text("Dear Sir,")#linebreak()#text(" Please discuss about the following problem:")#linebreak()#text(" Show that $\\{\\sum\\limits_{k=0}^{n}\\frac{1}{k^{2}}\\}$ is a Cauchy sequence by using the following definition of Cauchy sequence:")#linebreak()#text(" A sequence $\\{x_{n}\\}$ is said to be a Cauchy sequence if for any $\\epsilon >0$, there exists a $m\\in\\mathbb{N}$ such that $|x_{n+p}-x_{n}|<\\epsilon$ for all $n\\geq m$ and all $p\\in\\mathbb{N}$.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leena")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47496")[#strong[#text("Leena")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2010")])]

#text("let (0,1) = union of countable union of I(n) where each I (n) is closed and all of them are disjoint. Then denote (0,1) by set A and the countable union of I(n) as B. We claim sets A and B are equal. then Closures of both of them also must be equal.. closure of (0,1) is [0,1]. Now taking the closure of the countable union of I(n) …. all the sets are disjoint and hence closure of union of I (n) is equal to union of closures of each of I (n). but all of I (n) are closed. So its the same set B again. Hence the closure of A is not equal to closure of B . Which is a contradiction. so (0,1) can not be written as a union of countable union of disjoint closed sets. Its applicable to all open intervals too…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df8b488e78cf7b801302abdcc15643f5509fe2a511b943a22585438c19e32562-84e8b251e202d4c8821de364412c66bbf9103569152ded21bb17d1ad4bd136ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lewis Bowen")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-47510")[#strong[#text("Lewis Bowen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2010")])]

#text("I think I found a different proof. It begins the same way; it suffices to show that the real line cannot be covered by countably many disjoint intervals. Suppose for a contradiction that it can. Let C_1, C_2,… be such a covering. Let O_i be the union of the complement of C_i with the interior of C_i (so O_i is the whole line minus the two endpoints of C_i). So O_i is a dense open set. Accordingly the intersection of all the O_i’s is a dense G_delta. But it must be empty if the C_i’s cover and are disjoint. This contradiction proves it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e193a70d5e9f73a6888296fd422c008f17bc84210b1e212e87412373ba9fca91-ce3d6182093f3bbd5c2c4972fbc3b02c8da1af2b458245651ee60a1676df2658.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Local Connectedness and Some Weird Counterexamples « Gracious Living and the Two Meat Meal")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-48089")[#strong[#text("Local Connectedness and Some Weird Counterexamples « Gracious Living and the Two Meat Meal")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2010")])]

#text("[…] only way to do this is by letting itself be the only one in the union; proofs are, for example, here (read the comments for other viewpoints/try it yourself first!). So the only paths in the set are […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dac95bcff7013d5512fbc8af56700cbdaaf200608c2d05093a0fae89dd3c7205-63a227c28fe67c4e070337f741d2321f0b21a1c9902a9c988d600b94d0894e74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manuel")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-50834")[#strong[#text("Manuel")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2011")])]

#text("To prove that [0,1) can’t be expressed as a union of countable many disjoint closed intervals, can’t we just say de following?")

#text("Suppose we can. We have then a countable family F of closed intervals, which can be ordered in the sense reals are (?). We order them creating the sequence {[a_n, b_n]}, where b_1<a_2, b_2<a ")#emph[#text("[text lost here due to unintended HTML processing of the < and > signs – T.]")]#text(" >b_k (since disjoint). So we can find some c in (b_k, a_(k+1)) opened set which hasn’t been covered by the family F.")

#text("Maybe there’s an error when saying we can order that family F, because if not this would sound good to me…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16a661ff9acbf3c36248cca482a7b4c64a141a9df6fcba0384b8dd7ca5730f3f-93c1c808fc14ab5102c39fc058a799088dabfb03a3a268cc8188c3d83e9af409.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergei Ovchinnikov")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-83308")[#strong[#text("Sergei Ovchinnikov")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2011")])]

#text("See American Mathematical Monthly, 84 (1977),827-828.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-240077")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2013")])]

#text("I feel frustrated to see that the answer is “no” because this means that my intuition is not reliable when faced with infinity…")

#text("Which means I need to adjust my intuition.")

#text("Now I give a proof to show why it is impossible to cover a non-closed interval by countable disjoint closed intervals.")

#text("In order to prove that it is impossible to cover [0,1) by countable disjoint closed intervals,it is clear that we just need to prove that it is impossible to cover [0,1] by countable disjoint closed intervals.")

#text("We prove by contradiction.")

#text("Otherwise,")

#text("There must exists a sequence of real numbers ")#mi("a_1,\\cdots,a_n")#text(" in [0,1] which is convergent to a real number in [0,1],and every item in this sequence is exactly covered by one non-degenerate closed interval(we call the interval of the shape [a,a] as the degenerate closed interval),and any of the two non-degenerate closed intervals are disjoint.")

#text("This is impossible,because at the very end of this sequence,two items will be very near that they must be in one non-degenerate intervals.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-241949")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2013")])]

#text("Dear Prof.Tao,")

#text("I don’t know whether you regard [1,1] as a closed interval or not.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-636882")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2021")])]

#text("Since it is singleton it is close")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/caa2fbedecb1e65bc3a53a710328588ae9b18aea02e9c74b80b99cc2d55b53c0-9d2fe90fa96e1cebb08781cdefb077122523e51d6179155b1573633f0b56a4a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of myc10003")]], [#link("https://terrytao.wordpress.com/2010/10/04/covering-a-non-closed-interval-by-disjoint-closed-intervals/#comment-454630")[#strong[#text("myc10003")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2015")])]

#text("I have a different proof. Consider an arbitrary covering of (0, 1) by pairwise disjoint, closed intervals I_x, each I_x is in (0, 1). Denote the covering set by L. One can show that L is a linear continuum and hence uncountable.")

#text("Since the closed intervals are pairwise disjoint, there is a natural total order amongst them. Since L covers (0, 1), for any I_x < I_y in L, there exists an I_z in L such that I_x < I_z < I_y.")

#text("It remains to show that L has the least upper bound property. Suppose a subset of L, S, is bounded above by an I_x. There must exist a least upper bound of the right endpoints of the intervals in this subset. Call it a. Obviously a is either to the left of I_x or in I_x. Hence a is in (0, 1). If a is the right endpoint of an interval in S, that interval is the least upper bound of S. Otherwise, there exists an I_y in L – S that covers a. Since a is the least upper bound of the right ends of intervals in S, a must be the left endpoint of I_y. Hence I_y is the least upper bound. Therefore L has the least upper bound property.")
]
