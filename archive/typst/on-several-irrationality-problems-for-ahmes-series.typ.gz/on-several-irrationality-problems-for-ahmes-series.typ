// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/11/27/on-several-irrationality-problems-for-ahmes-series/
// Converted to Typst by tao2typ: "2026-10-14T11:12:52.426789+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On several irrationality problems for Ahmes series", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On several irrationality problems for Ahmes series")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 November 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/11/27/on-several-irrationality-problems-for-ahmes-series/")[#text("https://terrytao.wordpress.com/2024/11/27/on-several-irrationality-problems-for-ahmes-series/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://web.math.pmf.unizg.hr/~vjekovac/")[#text("Vjeko Kovac")]#text(" and I have just uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/2406.17593")[#text("On several irrationality problems for Ahmes series")]#text("“. This paper resolves (or at least makes partial progress on) some open questions of Erdős and others on the irrationality of ")#emph[#text("Ahmes series")]#text(", which are infinite series of the form ")#mi("{\\sum_{k=1}^\\infty \\frac{1}{a_k}}")#text(" for some increasing sequence ")#mi("{a_k}")#text(" of natural numbers. Of course, since most real numbers are irrational, one expects such series to “generically” be irrational, and we make this intuition precise (in both a probabilistic sense and a Baire category sense) in our paper. However, it is often difficult to establish the irrationality of any specific series. For example, it is already a non-trivial ")#link("https://mathscinet.ams.org/mathscinet/article?mr=29405")[#text("result of Erdős")]#text(" that the series ")#mi("{\\sum_{k=1}^\\infty \\frac{1}{2^k-1}}")#text(" is irrational, while the irrationality of ")#mi("{\\sum_{p \\text{ prime}} \\frac{1}{2^p-1}}")#text(" (equivalent to ")#link("https://www.erdosproblems.com/69")[#text("Erdős problem #69")]#text(") remains open, although ")#link("https://arxiv.org/abs/2409.15185")[#text("very recently Pratt")]#text(" established this conditionally on the Hardy–Littlewood prime tuples conjecture. Finally, the irrationality of ")#mi("{\\sum_n \\frac{1}{n!-1}}")#text(" (")#link("https://www.erdosproblems.com/68")[#text("Erdős problem #68")]#text(") is completely open.")

#text("On the other hand, it has long been known that if the sequence ")#mi("{a_k}")#text(" grows faster than ")#mi("{C^{2^k}}")#text(" for any ")#mi("{C}")#text(", then the Ahmes series is necessarily irrational, basically because the fractional parts of ")#mi("{a_1 \\dots a_m \\sum_{k=1}^\\infty \\frac{1}{a_k}}")#text(" can be arbitrarily small positive quantities, which is inconsistent with ")#mi("{\\sum_{k=1}^\\infty \\frac{1}{a_k}}")#text(" being rational. This growth rate is sharp, as can be seen by iterating the identity ")#mi("{\\frac{1}{n} = \\frac{1}{n+1} + \\frac{1}{n(n+1)}}")#text(" to obtain a rational Ahmes series of growth rate ")#mi("{(C+o(1))^{2^k}}")#text(" for any fixed ")#mi("{C>1}")#text(".")

#text("In our paper we show that if ")#mi("{a_k}")#text(" grows somewhat slower than the above sequences in the sense that ")#mi("{a_{k+1} = o(a_k^2)}")#text(", for instance if ")#mi("{a_k \\asymp 2^{(2-\\varepsilon)^k}}")#text(" for a fixed ")#mi("{0 < \\varepsilon < 1}")#text(", then one can find a comparable sequence ")#mi("{b_k \\asymp a_k}")#text(" for which ")#mi("{\\sum_{k=1}^\\infty \\frac{1}{b_k}}")#text(" is rational. This partially addresses ")#link("https://www.erdosproblems.com/263")[#text("Erdős problem #263")]#text(", which asked if the sequence ")#mi("{a_k = 2^{2^k}}")#text(" had this property, and whether any sequence of exponential or slower growth (but with ")#mi("{\\sum_{k=1}^\\infty 1/a_k}")#text(" convergent) had this property. Unfortunately we barely miss a full solution of both parts of the problem, since the condition ")#mi("{a_{k+1} = o(a_k^2)}")#text(" we need just fails to cover the case ")#mi("{a_k = 2^{2^k}}")#text(", and also does not quite hold for all sequences going to infinity at an exponential or slower rate.")

#text("We also show the following variant; if ")#mi("{a_k}")#text(" has exponential growth in the sense that ")#mi("{a_{k+1} = O(a_k)}")#text(" with ")#mi("{\\sum_{k=1}^\\infty \\frac{1}{a_k}}")#text(" convergent, then there exists nearby natural numbers ")#mi("{b_k = a_k + O(1)}")#text(" such that ")#mi("{\\sum_{k=1}^\\infty \\frac{1}{b_k}}")#text(" is rational. This answers the first part of ")#link("https://www.erdosproblems.com/264")[#text("Erdős problem #264")]#text(" which asked about the case ")#mi("{a_k = 2^k}")#text(", although the second part (which asks about ")#mi("{a_k = k!}")#text(") is slightly out of reach of our methods. Indeed, we show that the exponential growth hypothesis is best possible in the sense a ")#emph[#text("random")]#text(" sequence ")#mi("{a_k}")#text(" that grows faster than exponentially will ")#emph[#text("not")]#text(" have this property, this result does not address any specific superexponential sequence such as ")#mi("{a_k = k!}")#text(", although it does apply to some sequence ")#mi("{a_k}")#text(" of the shape ")#mi("{a_k = k! + O(\\log\\log k)}")#text(".")

#text("Our methods can also handle higher dimensional variants in which multiple series are simultaneously set to be rational. Perhaps the most striking result is this: we can find an increasing sequence ")#mi("{a_k}")#text(" of natural numbers with the property that ")#mi("{\\sum_{k=1}^\\infty \\frac{1}{a_k + t}}")#text(" is rational for ")#emph[#text("every")]#text(" rational ")#mi("{t}")#text(" (excluding the cases ")#mi("{t = - a_k}")#text(" to avoid division by zero)! This answers (in the negative) a question of Stolarsky ")#link("https://www.erdosproblems.com/266")[#text("Erdős problem #266")]#text(", and also reproves ")#link("https://www.erdosproblems.com/265")[#text("Erdős problem #265")]#text(" (and in the latter case one can even make ")#mi("{a_k}")#text(" grow double exponentially fast).")

#text("Our methods are elementary and avoid any number-theoretic considerations, relying primarily on the countable dense nature of the rationals and an iterative approximation technique. The first observation is that the task of representing a given number ")#mi("{q}")#text(" as an Ahmes series ")#mi("{\\sum_{k=1}^\\infty \\frac{1}{a_k}}")#text(" with each ")#mi("{a_k}")#text(" lying in some interval ")#mi("{I_k}")#text(" (with the ")#mi("{I_k}")#text(" disjoint, and going to infinity fast enough to ensure convergence of the series), is possible if and only if the infinite sumset")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{I_1} + \\frac{1}{I_2} + \\dots")]]

#text("to contain ")#mi("{q}")#text(", where ")#mi("{\\frac{1}{I_k} = \\{ \\frac{1}{a}: a \\in I_k \\}}")#text(". More generally, to represent a tuple of numbers ")#mi("{(q_t)_{t \\in T}}")#text(" indexed by some set ")#mi("{T}")#text(" of numbers simultaneously as ")#mi("{\\sum_{k=1}^\\infty \\frac{1}{a_k+t}}")#text(" with ")#mi("{a_k \\in I_k}")#text(", this is the same as asking for the infinite sumset")

#align(center)[#tao-fit-display[#mitex("E_1 + E_2 + \\dots")]]

#text("to contain ")#mi("{(q_t)_{t \\in T}}")#text(", where now")

#metadata(none) <tao-639dd904ba63d53ee28e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("E_k = \\{ (\\frac{1}{a+t})_{t \\in T}: a \\in I_k \\}.")]]

#text("So the main problem is to get control on such infinite sumsets. Here we use a very simple observation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Iterative approximation)")]#text(" ")#metadata(none) <tao-f2e9849680201af17032>#text(" Let ")#mi("{V}")#text(" be a Banach space, let ")#mi("{E_1,E_2,\\dots}")#text(" be sets with each ")#mi("{E_k}")#text(" contained in the ball of radius ")#mi("{\\varepsilon_k>0}")#text(" around the origin for some ")#mi("{\\varepsilon_k}")#text(" with ")#mi("{\\sum_{k=1}^\\infty \\varepsilon_k}")#text(" convergent, so that the infinite sumset ")#mi("{E_1 + E_2 + \\dots}")#text(" is well-defined. Suppose that one has some convergent series ")#mi("{\\sum_{k=1}^\\infty v_k}")#text(" in ")#mi("{V}")#text(", and sets ")#mi("{B_1,B_2,\\dots}")#text(" converging in norm to zero, such that")

#metadata(none) <tao-8630c6c9af0730c3e963>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("v_k + B_k \\subset E_k + B_{k+1}")]]

#text("for all ")#mi("{k \\geq 1}")#text(". Then the infinite sumset ")#mi("{E_1 + E_2 + \\dots}")#text(" contains ")#mi("{\\sum_{k=1}^\\infty v_k + B_1}")#text(".")
]

#text("Informally, the condition ")#link(<tao-8630c6c9af0730c3e963>)[#text("(2)")]#text(" asserts that ")#mi("{E_k}")#text(" occupies all of ")#mi("{v_k + B_k}")#text(" “at the scale ")#mi("{B_{k+1}}")#text("“.")

#emph[#text("Proof:")]#text(" Let ")#mi("{w_1 \\in B_1}")#text(". Our task is to express ")#mi("{\\sum_{k=1}^\\infty v_k + w_1}")#text(" as a series ")#mi("{\\sum_{k=1}^\\infty e_k}")#text(" with ")#mi("{e_k \\in E_k}")#text(". From ")#link(<tao-8630c6c9af0730c3e963>)[#text("(2)")]#text(" we may write")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=1}^\\infty v_k + w_1 = \\sum_{k=2}^\\infty v_k + e_1 + w_2")]]

#text("for some ")#mi("{e_1 \\in E_1}")#text(" and ")#mi("{w_2 \\in B_2}")#text(". Iterating this, we may find ")#mi("{e_k \\in E_k}")#text(" and ")#mi("{w_k \\in B_k}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=1}^\\infty v_k + w_1 = \\sum_{k=m+1}^\\infty v_k + e_1 + e_2 + \\dots + e_m + w_{m+1}")]]

#text("for all ")#mi("{m}")#text(". Sending ")#mi("{m \\rightarrow \\infty}")#text(", we obtain")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=1}^\\infty v_k + w_1 = e_1 + e_2 + \\dots")]]

#text("as required. ")#mi("\\Box")

#text("In one dimension, sets of the form ")#mi("{\\frac{1}{I_k}}")#text(" are dense enough that the condition ")#link(<tao-8630c6c9af0730c3e963>)[#text("(2)")]#text(" can be satisfied in a large number of situations, leading to most of our one-dimensional results. In higher dimension, the sets ")#mi("{E_k}")#text(" lie on curves in a high-dimensional space, and so do not directly obey usable inclusions of the form ")#link(<tao-8630c6c9af0730c3e963>)[#text("(2)")]#text("; however, for suitable choices of intervals ")#mi("{I_k}")#text(", one can take some finite sums ")#mi("{E_{k+1} + \\dots + E_{k+d}}")#text(" which will become dense enough to obtain usable inclusions of the form ")#link(<tao-8630c6c9af0730c3e963>)[#text("(2)")]#text(" once ")#mi("{d}")#text(" reaches the dimension of the ambient space, basically thanks to the inverse function theorem (and the non-vanishing curvatures of the curve in question). For the Stolarsky problem, which is an infinite-dimensional problem, it turns out that one can modify this approach by letting ")#mi("{d}")#text(" grow slowly to infinity with ")#mi("{k}")#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b9d2b471a95950cf9ab900a2a956433a802e53dd7dce19b8f99e969eecbfb6d-928b219cdc034ba412fab685a5c24ece80537934e15e706cc872bf337f74deba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of allenknutson")]], [#link("https://terrytao.wordpress.com/2024/11/27/on-several-irrationality-problems-for-ahmes-series/#comment-686823")[#strong[#text("allenknutson")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2024")])]

#text("You’re misspelling Erdős (wrong umlaut).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0937c030f22328ab0591a0a68d7e1839bb9f0dbc9ff3724e77d0c38dc1a9a212-117b4929f179599ca57251b28c13d88809f4520a0354839ff42e92f7eb551f94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of woutervandoorn")]], [#link("https://terrytao.wordpress.com/2024/11/27/on-several-irrationality-problems-for-ahmes-series/#comment-686825")[#strong[#text("woutervandoorn")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2024")])]

#text("Small typo on page 9: it says ‘by one the present authors’")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/27/on-several-irrationality-problems-for-ahmes-series/#comment-686836")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2024")])]

#text("“")#strong[#text("Proposition 1 (Iterative approximatiom")]#text(")” typo. Should be ")#strong[#text("Proposition 1 (Iterative approximation)” . ")]

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/27/on-several-irrationality-problems-for-ahmes-series/#comment-686842")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2024")])]

#text("An amazing theorem!")

#text("Also,”althuogh” in the fourth paragraph should be “although”.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/27/on-several-irrationality-problems-for-ahmes-series/#comment-686890")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2024")])]

#text("Very interesting read. Does this suggest any new “universal” sequences that can represent rational numbers in infinitely many ways?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/11/27/on-several-irrationality-problems-for-ahmes-series/#comment-686896")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2024")])]

#text("Yes, our methods will allow one to construct various rapidly growing sequences of natural numbers ")#mi("A")#text(" with the property that an infinite number of rational numbers can be represented in the form ")#mi("\\sum_{n \\in B} 1/n")#text(" for infinitely many subsets ")#mi("B")#text(" of ")#mi("A")#text(". For instance, the explicit choice ")#mi("A = \\{ 2^n + b: n \\geq 1, 1 \\leq b \\leq 5 \\}")#text(" will work (all numbers in an open neighbourhood of 0.75, regardless of rationality will have infinitely many such representations, by a slight modification of the arguments already in the paper). On the other hand, if ")#mi("a_n/2^n \\to \\infty")#text(", then a simple union bound argument can show that the set of sums ")#mi("\\sum_{n \\in B} 1/n")#text(" for ")#mi("B \\subset \\{a_1,a_2,\\dots\\}")#text(" has measure zero, and so it is highly unlikely that it can represent an infinite number of rational numbers (though this is not quite a rigorous argument).")
]
]
