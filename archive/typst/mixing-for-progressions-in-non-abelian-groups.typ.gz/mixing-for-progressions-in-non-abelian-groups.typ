// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/12/11/mixing-for-progressions-in-non-abelian-groups/
// Converted to Typst by tao2typ: "2026-10-14T09:28:55.198423+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mixing for progressions in non-abelian groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mixing for progressions in non-abelian groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 December 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/12/11/mixing-for-progressions-in-non-abelian-groups/")[#text("https://terrytao.wordpress.com/2012/12/11/mixing-for-progressions-in-non-abelian-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper “")#link("http://arxiv.org/abs/1212.2586")[#text("Mixing for progressions in non-abelian groups")]#text("“, submitted to ")#link("http://journals.cambridge.org/action/displayJournal?jid=FMS")[#text("Forum of Mathematics, Sigma")]#text(" (which, along with sister publication ")#link("http://journals.cambridge.org/action/displayJournal?jid=FMP")[#text("Forum of Mathematics, Pi")]#text(", has just opened up ")#link("http://journals.cambridge.org/sigma/submit")[#text("its online submission system")]#text("). This paper is loosely related in subject topic to my two previous papers ")#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/")[#text("on polynomial expansion")]#text(" and ")#link("https://terrytao.wordpress.com/2012/11/28/multiple-recurrence-in-quasirandom-groups/")[#text("on recurrence in quasirandom groups")]#text(" (with Vitaly Bergelson), although the methods here are rather different from those in those two papers. The starting motivation for this paper was a question posed in ")#link("http://www.ams.org/mathscinet-getitem?mr=2410393")[#text("this foundational paper of Tim Gowers")]#text(" on ")#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/")[#text("quasirandom groups")]#text(". In that paper, Gowers showed (among other things) that if ")#mi("{G}")#text(" was a quasirandom group, patterns such as ")#mi("{(x,xg,xh, xgh)}")#text(" were mixing in the sense that, for any four sets ")#mi("{A,B,C,D \\subset G}")#text(", the number of such quadruples ")#mi("{(x,xg,xh, xgh)}")#text(" in ")#mi("{A \\times B \\times C \\times D}")#text(" was equal to ")#tao-math("{(\\mu(A) \\mu(B) \\mu(C) \\mu(D) + o(1)) \\left|G\\right|^3}", block: false)#text(", where ")#tao-math("{\\mu(A) := \\left|A\\right| / \\left|G\\right|}", block: false)#text(", and ")#mi("{o(1)}")#text(" denotes a quantity that goes to zero as the quasirandomness of the group goes to infinity. In my recent paper with Vitaly, we also considered mixing properties of some other patterns, namely ")#mi("{(x,xg,gx)}")#text(" and ")#mi("{(g,x,xg,gx)}")#text(". This paper is concerned instead with the pattern ")#mi("{(x,xg,xg^2)}")#text(", that is to say a geometric progression of length three. As observed by Gowers, by applying (a suitably quantitative version of) Roth’s theorem in (cosets of) a cyclic group, one can obtain a recurrence theorem for this pattern without much effort: if ")#mi("{G}")#text(" is an arbitrary finite group, and ")#mi("{A}")#text(" is a subset of ")#mi("{G}")#text(" with ")#mi("{\\mu(A) \\geq \\delta}")#text(", then there are at least ")#tao-math("{c(\\delta) \\left|G\\right|^2}", block: false)#text(" pairs ")#mi("{(x,g) \\in G}")#text(" such that ")#mi("{x, xg, xg^2 \\in A}")#text(", where ")#mi("{c(\\delta)>0}")#text(" is a quantity depending only on ")#mi("{\\delta}")#text(". However, this argument does not settle the question of whether there is a stronger ")#emph[#text("mixing")]#text(" property, in that the number of pairs ")#mi("{(x,g) \\in G^2}")#text(" such that ")#mi("{(x,xg,xg^2) \\in A \\times B \\times C}")#text(" should be ")#tao-math("{(\\mu(A)\\mu(B)\\mu(C)+o(1)) \\left|G\\right|^2}", block: false)#text(" for any ")#mi("{A,B,C \\subset G}")#text(". Informally, this would assert that for ")#mi("{x, g}")#text(" chosen uniformly at random from ")#mi("{G}")#text(", the triplet ")#mi("{(x, xg, xg^2)}")#text(" should resemble a uniformly selected element of ")#mi("{G^3}")#text(" in some weak sense.")

#text("For non-quasirandom groups, such mixing properties can certainly fail. For instance, if ")#mi("{G}")#text(" is the cyclic group ")#mi("{G = ({\\bf Z}/N{\\bf Z},+)}")#text(" (which is abelian and thus highly non-quasirandom) with the additive group operation, and ")#mi("{A = \\{1,\\ldots,\\lfloor \\delta N\\rfloor\\}}")#text(" for some small but fixed ")#mi("{\\delta > 0}")#text(", then ")#mi("{\\mu(A) = \\delta + o(1)}")#text(" in the limit ")#mi("{N \\rightarrow \\infty}")#text(", but the number of pairs ")#mi("{(x,g) \\in G^2}")#text(" with ")#mi("{x, x+g, x+2g \\in A}")#text(" is ")#tao-math("{(\\delta^2/2 + o(1)) \\left|G\\right|^2}", block: false)#text(" rather than ")#tao-math("{(\\delta^3+o(1)) \\left|G\\right|^2}", block: false)#text(". The problem here is that the identity ")#mi("{(x+2g) = 2(x+g) - x}")#text(" ensures that if ")#mi("{x}")#text(" and ")#mi("{x+g}")#text(" both lie in ")#mi("{A}")#text(", then ")#mi("{x+2g}")#text(" has a highly elevated likelihood of also falling in ")#mi("{A}")#text(". One can view ")#mi("{A}")#text(" as the preimage of a small ball under the one-dimensional representation ")#mi("{\\rho: G \\rightarrow U(1)}")#text(" defined by ")#mi("{\\rho(n) := e^{2\\pi i n/N}}")#text("; similar obstructions to mixing can also be constructed from other low-dimensional representations.")

#text("However, by definition, quasirandom groups do not have low-dimensional representations, and Gowers asked whether mixing for ")#mi("{(x,xg,xg^2)}")#text(" could hold for quasirandom groups. I do not know if this is the case for arbitrary quasirandom groups, but I was able to settle the question for a specific class of quasirandom groups, namely the special linear groups ")#mi("{G := SL_d(F)}")#text(" over a finite field ")#mi("{F}")#text(" in the regime where the dimension ")#mi("{d}")#text(" is bounded (but is at least two) and ")#mi("{F}")#text(" is large. Indeed, for such groups I can obtain a count of ")#tao-math("{(\\mu(A) \\mu(B) \\mu(C) + O( \\left|F\\right|^{-\\min(d-1,2)/8} )) \\left|G\\right|^2}", block: false)#text(" for the number of pairs ")#mi("{(x,g) \\in G^2}")#text(" with ")#mi("{(x, xg, xg^2) \\in A \\times B \\times C}")#text(". In fact, I have the somewhat stronger statement that there are ")#tao-math("{(\\mu(A) \\mu(B) \\mu(C) \\mu(D) + O( \\left|F\\right|^{-\\min(d-1,2)/8} )) \\left|G\\right|^2}", block: false)#text(" pairs ")#mi("{(x,g) \\in G^2}")#text(" with ")#mi("{(x,xg,xg^2,g) \\in A \\times B \\times C \\times D}")#text(" for any ")#mi("{A,B,C,D \\subset G}")#text(".")

#text("I was also able to obtain a partial result for the length four progression ")#mi("{(x,xg,xg^2, xg^3)}")#text(" in the simpler two-dimensional case ")#mi("{G = SL_2(F)}")#text(", but I had to make the unusual restriction that the group element ")#mi("{g \\in G}")#text(" was ")#emph[#text("hyperbolic")]#text(" in the sense that it was diagonalisable over the finite field ")#mi("{F}")#text(" (as opposed to diagonalisable over the algebraic closure ")#mi("{\\overline{F}}")#text(" of that field); this amounts to the discriminant of the matrix being a quadratic residue, and this holds for approximately half of the elements of ")#mi("{G}")#text(". The result is then that for any ")#mi("{A,B,C,D \\subset G}")#text(", one has ")#tao-math("{(\\frac{1}{2} \\mu(A) \\mu(B) \\mu(C) \\mu(D) + o(1)) \\left|G\\right|^2}", block: false)#text(" pairs ")#mi("{(x,g) \\in G}")#text(" with ")#mi("{g}")#text(" hyperbolic and ")#mi("{(x,xg,xg^2,xg^3) \\subset A \\times B \\times C \\times D}")#text(". (Again, I actually show a slightly stronger statement in which ")#mi("{g}")#text(" is restricted to an arbitrary subset ")#mi("{E}")#text(" of hyperbolic elements.)")

#text("For the length three argument, the main tools used are the Cauchy-Schwarz inequality, the quasirandomness of ")#mi("{G}")#text(", and some algebraic geometry to ensure that a certain family of probability measures on ")#mi("{G}")#text(" that are defined algebraically are approximately uniformly distributed. The length four argument is significantly more difficult and relies on a rather ")#emph[#text("ad hoc")]#text(" argument involving, among other things, expander properties related to ")#link("http://www.ams.org/mathscinet-getitem?mr=2415383")[#text("the work of Bourgain and Gamburd")]#text(", and also a “twisted” version of an ")#link("http://www.ams.org/mathscinet-getitem?mr=1631259")[#text("argument of Gowers")]#text(" that is used (among other things) to establish an inverse theorem for the ")#mi("{U^3}")#text(" norm.")

#text("I give some details of these arguments below the fold.")

#metadata(none) <tao-fe459bf04fb015d3e9c4>

#heading(level: 1)[#strong[#text(" — 1. Length three progressions — ")]]

#text("One can view the mixing property of length three progressions as an assertion about the unbiased nature of sums of the form ")#metadata(none) <tao-c96c411ca6acc9b15a7c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{x,g \\in G} f_0(x) f_1(xg) f_2(xg^2)")]]

#text("for various bounded functions ")#mi("{f_0,f_1,f_2: G \\rightarrow {\\bf C}}")#text(". (To obtain the stronger statement in which ")#mi("{g}")#text(" is also restricted to some set ")#mi("{D}")#text(", one would throw in an additional function ")#mi("{f_3(g)}")#text(", but let us ignore that generalisation here for sake of simplicity.) Roughly speaking, mixing means that the sum ")#link(<tao-c96c411ca6acc9b15a7c>)[#text("(1)")]#text(" should be small if at least one of the ")#mi("{f_0,f_1,f_2}")#text(" have small mean.")

#text("One way in which mixing fails would be if there was an unexpected constraint between ")#mi("{x, xg, xg^2}")#text(", for instance if there was a constraint of the form ")#metadata(none) <tao-a2052ddf9e8c0c3d01cb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\phi_0(x) + \\phi_1(xg) + \\phi_2(xg^2) = 0")]]

#text("for all ")#mi("{x, g\\in G}")#text(" and some non-trivial functions ")#mi("{\\phi_0,\\phi_1,\\phi_2:G \\rightarrow {\\bf R}/{\\bf Z}}")#text(" (not necessarily homomorphisms). Then one could make the sum ")#link(<tao-c96c411ca6acc9b15a7c>)[#text("(1)")]#text(" for ")#mi("{f_j(x) := e^{2\\pi i \\phi_j(x)}}")#text(" exhibit no cancellation whatsoever, even though one would expect ")#mi("{f_0,f_1,f_2}")#text(" to have small mean if the ")#mi("{\\phi_i}")#text(" were sufficiently non-trivial. (This observation is basically what underlies the failure of mixing in the abelian case.) Thus, this suggests the toy problem of ruling out constraints of the form ")#link(<tao-a2052ddf9e8c0c3d01cb>)[#text("(2)")]#text(" when ")#mi("{G}")#text(" is a special linear group ")#mi("{G = SL_d(F)}")#text(". This toy problem (which can be viewed as ruling out the “")#mi("{100\\%}")#text(" structured” version of the mixing problem, which is about excluding a more general “")#mi("{1\\%}")#text(" structured” situation) is significantly weaker than the general result, but it turns out that the proof strategy for the toy problem can be adapted to the general case (basically by replacing many of the algebraic manipulations below with a suitable analogue involving the Cauchy-Schwarz inequality).")

#text("Let’s see how this works. Suppose for contradiction that we had a constraint of the form ")#link(<tao-a2052ddf9e8c0c3d01cb>)[#text("(2)")]#text(". In the abelian case, standard “double differencing” arguments let one conclude that ")#mi("{\\phi_0,\\phi_1,\\phi_2}")#text(" are affine homomorphisms; see e.g. Section 2 of ")#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/")[#text("these lecture notes")]#text(". It turns out that essentially the same argument can be applied in the nonabelian case, but one acquires a nonabelian “twist” which can be exploited to give additional mixing. Shifting ")#mi("{x}")#text(" by ")#mi("{g}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\phi_0(xg^{-1}) + \\phi_1(x) + \\phi_2(xg) = 0")]]

#text("for all ")#mi("{x,g \\in G}")#text(". Now we use some algebraic manipulation to eliminate ")#mi("{\\phi_1}")#text(". If we replace ")#mi("{g}")#text(" by ")#mi("{ga}")#text(" for some ")#mi("{a \\in G}")#text(", we also have")

#align(center)[#tao-fit-display[#mitex("\\phi_0(xa^{-1} g^{-1}) + \\phi_1(x) + \\phi_2(xga) = 0;")]]

#text("subtracting, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\partial_{ga^{-1}g^{-1}} \\phi_0(xg^{-1}) + \\partial_a \\phi_2(xg) = 0")]]

#text("where ")#mi("{\\partial_a \\phi(x) := \\phi(xa) - \\phi(x)}")#text(" is the “derivative” of ")#mi("{\\phi}")#text(" in the ")#mi("{a}")#text(" direction. Setting ")#mi("{y := xg}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\partial_{ga^{-1}g^{-1}} \\phi_0(yg^{-2}) + \\partial_a \\phi_2(y) = 0")]]

#text("for all ")#mi("{y,g,a \\in G}")#text(".")

#text("We can now perform a similar manipulation to eliminate ")#mi("{\\phi_2}")#text(". Replacing ")#mi("{g}")#text(" by ")#mi("{hg}")#text(" for some ")#mi("{h \\in G}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\partial_{hga^{-1}g^{-1}h^{-1}} \\phi_0(yg^{-1}h^{-1}g^{-1}h^{-1}) + \\partial_a \\phi_2(y) = 0.")]]

#text("Subtracting, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\partial_{ga^{-1}g^{-1}} \\phi_0(yg^{-2}) = \\partial_{hga^{-1}g^{-1}h^{-1}} \\phi_0(yg^{-1}h^{-1}g^{-1}h^{-1})")]]

#text("for all ")#mi("{y,g,a,h \\in G}")#text(". We can clean this up a bit by setting ")#mi("{b := ga^{-1} g}")#text(" and ")#mi("{z := yg^{-2}}")#text(", leading to")

#align(center)[#tao-fit-display[#mitex("\\partial_{b} \\phi_0(z) = \\partial_{hbh^{-1}} \\phi_0(zgh^{-1}g^{-1}h^{-1})")]]

#text("for all ")#mi("{z,g,b,h \\in G}")#text(".")

#text("Next, we exploit the fact that the quantity ")#mi("{hbh^{-1}}")#text(" appearing on the right-hand side does not change if one replaces ")#mi("{h}")#text(" by ")#mi("{hc}")#text(" for any ")#mi("{c}")#text(" in the centraliser ")#mi("{Z(b) := \\{ c\\in G: cb=bc\\}}")#text(" of ")#mi("{b}")#text(". If we then replace ")#mi("{h}")#text(" by ")#mi("{hc}")#text(" in the above equation, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\partial_{b} \\phi_0(z) = \\partial_{hbh^{-1}} \\phi_0(zgc^{-1}h^{-1}g^{-1}h^{-1}c^{-1})")]]

#text("for all ")#mi("{z,g,b,h \\in G}")#text(" and ")#mi("{c \\in Z(b)}")#text(".")

#text("Let us now fix ")#mi("{h,b}")#text(", and let ")#mi("{A_{h,b} \\subset G}")#text(" denote the set")

#align(center)[#tao-fit-display[#mitex("A_{h,b} := \\{ gc^{-1}h^{-1}g^{-1}h^{-1} c^{-1}: g \\in G; c \\in Z(b) \\}.")]]

#text("The above identity then tells us that for ")#mi("{z \\in G}")#text(" and ")#mi("{a \\in A_{h,b}}")#text(", the quantity ")#mi("{\\partial_{hbh^{-1}} \\phi_0( z a )}")#text(" is in fact independent of ")#mi("{a}")#text(". So if one can show that ")#mi("{A_{h,b}}")#text(" is “large” (e.g. has positive density in ")#mi("{G}")#text("), then this suggests that the function ")#mi("{\\partial_{hbh^{-1}} \\phi_0}")#text(" has to be basically constant (and with quasirandomness, one can make this statement precise). Further application of quasirandomness then lets one conclude that ")#mi("{\\phi_0}")#text(" is itself constant, at which point it is not difficult to ensure that ")#mi("{\\phi_1}")#text(" and ")#mi("{\\phi_2}")#text(" are constant as well, rendering the entire constraint ")#link(<tao-a2052ddf9e8c0c3d01cb>)[#text("(2)")]#text(" trivial.")

#text("In the ")#mi("{d=2}")#text(" case, one can establish this by explicit (but ")#emph[#text("ad hoc")]#text(") computations (taking advantage of the special role of the trace in the ")#mi("{d=2}")#text(" case, for instance it is the case that two (non-central) matrices in ")#mi("{SL_2}")#text(" are conjugate iff they have the same trace, and there is also the nice fact that a matrix in ")#mi("{SL_2}")#text(" and its inverse have the same trace). For general ")#mi("{d}")#text(", this largeness of ")#mi("{A_{h,b}}")#text(" can be established by algebraic geometry methods; the key is to show that the map ")#mi("{(g,c) \\mapsto gc^{-1}h^{-1}g^{-1}h^{-1}c^{-1}}")#text(" from ")#mi("{G \\times Z(b)}")#text(" to ")#mi("{G}")#text(" is ")#emph[#text("dominant")]#text(" in the sense that its image is Zariski-dense in ")#mi("{G}")#text(". In the case of ")#mi("{SL_d(F)}")#text(", this can be accomplished by an inspection of the derivative of this map at the identity. (I expect that similar things can be done in other almost simple algebraic groups, but did not attempt to do so in this paper.)")

#heading(level: 1)[#strong[#text(" — 2. Length four progressions — ")]]

#text("It is remarkably difficult to extend the Cauchy-Schwarz based length three arguments to length four or higher in the nonabelian setting. In the abelian case, every application of the Cauchy-Schwarz inequality reduces a certain “complexity” of the average being studied; in terms of raw length, the average may look much more fearsome after Cauchy-Schwarz, but after making some changes of variable and collecting terms, one can arrive at an average that is actually simpler in certain key respects than the original average. But it turns out that in the nonabelian setting, the process of making changes of variable and collecting terms introduces additional complexity into the average that counteracts the abelian phenomenon of complexity reduction. This was already apparent in the length three setting, when one started to see messy looking expressions such as ")#mi("{zgc^{-1}h^{-1}g^{-1}h^{-1}c^{-1}}")#text(" emerge, but the argument was short enough that one could conclude before these expressions spiraled out of control. In the case of length four progressions, the nonabelian complications seem to outrun the simplifying process, and I was not able to end up with a tractable average after a finite number of applications of the Cauchy-Schwarz inequality.")

#text("Instead, we leverage the abelian additive combinatorics theory by working primarily with a metabelian subgroup of ")#mi("{SL_2(F)}")#text(", namely the Borel subgroup ")#mi("{B}")#text(" of upper-triangular elements of ")#mi("{SL_2(F)}")#text(". Note that every hyperbolic element of ")#mi("{SL_2(F)}")#text(" can be conjugated into ")#mi("{B}")#text(", which explains our restriction to the hyperbolic elements. By using the conjugates of ")#mi("{B}")#text(" to trace out all the hyperbolic elements of ")#mi("{SL_2(F)}")#text(" more or less evenly, matters soon reduce to establishing a “relative mixing” property for the pattern ")#mi("{(x,xg,xg^2,xg^3)}")#text(" on ")#mi("{B}")#text(". To explain this relative mixing, first observe that one does not have complete mixing for this pattern in ")#mi("{B}")#text(", due to the presence of an abelian quotient ")#mi("{F^\\times}")#text(" of ")#mi("{B}")#text(", formed by mapping ")#mi("{\\begin{pmatrix} t & a \\\\ 0 & t^{-1} \\end{pmatrix}}")#text(" to ")#mi("{t}")#text(", and one can then pull back the failure of mixing on ")#mi("{F^\\times}")#text(" (e.g. by counting length four progressions inside a single fixed geometric progression) to demonstrate failure of mixing of ")#mi("{B}")#text(". However, one can hope to show that this is the ")#emph[#text("only")]#text(" obstruction to mixing, in the sense that we can get sums such as ")#metadata(none) <tao-09f5ffef28309853265c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{x,g \\in B} f_0(x) f_1(xg) f_2(xg^2) f_3(xg^3)")]]

#text("to be small if at least one of ")#mi("{f_0,f_1,f_2,f_3: B \\rightarrow {\\bf C}}")#text(" pushes down to zero on ")#mi("{F^\\times}")#text(", or equivalently if it has mean zero on every coset of the kernel of this quotient, which is the group ")#mi("{U}")#text(" of unipotent matrices in ")#mi("{B}")#text(".")

#text("In order to upgrade relative mixing on ")#mi("{B}")#text(" and its conjugates back to full mixing on ")#mi("{G}")#text(", we need a certain expansion property of a given conjugacy class ")#mi("{C(a)}")#text(" of a non-central element ")#mi("{a \\in G}")#text(". This property asserts that if ")#mi("{f \\in \\ell^2(G)}")#text(" has mean zero, then after convolving ")#mi("{f}")#text(" with the uniform probability measure on such a conjugacy class, the ")#mi("{\\ell^2}")#text(" norm drops by a positive power of ")#tao-math("{\\left|F\\right|}", block: false)#text(". This type of expansion is related to the work ")#link("http://www.ams.org/mathscinet-getitem?mr=2415383")[#text("of Bourgain and Gamburd")]#text(" (in which the conjugacy class is replaced by a set of bounded cardinality, and the drop in ")#mi("{L^2}")#text(" norm is proportionally smaller as a result), and uses some of the same tools in the proof (in particular the “escape from subvarieties” phenomenon of ")#link("http://www.ams.org/mathscinet-getitem?mr=2129706")[#text("Eskin, Mozes, and Oh)). (On the other hand, the \\href")]#text("{combinatorial product theory of Helfgott}, which plays a central role in the work of Bourgain and Gamburd, is not needed here, because in this setting one only needs to understand products of ")#emph[#text("algebraic")]#text(" sets, such as conjugacy classes, rather than arbitrary subsets.)")

#text("By foliating ")#mi("{B}")#text(" into cosets of ")#mi("{U}")#text(" (which is isomorphic to ")#mi("{F}")#text("), one can after some straightforward calculations rewrite the sum into a sum which is basically of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{s,t \\in F^\\times} \\sum_{a,b \\in F} f_{0,s}(a) f_{1,st}(a+b) f_{2,st^2}(a+(1+t^2)b) f_{3,st^3}(a+(1+t^2+t^4)b)")]]

#text("for some family ")#mi("{f_{i,s}: F \\rightarrow {\\bf C}}")#text(" of bounded functions for ")#mi("{i=0,1,2,3}")#text(" and ")#mi("{s \\in F^\\times}")#text(". The inner sum resembles a count of four term progressions, a statistic which has been studied by higher order Fourier-analytic methods since ")#link("http://www.ams.org/mathscinet-getitem?mr=1631259")[#text("the work of Gowers")]#text(" on Szemerédi’s theorem for length four progressions. In principle one could analyse these expressions using the inverse ")#mi("{U^3}")#text(" theorem of ")#link("http://www.ams.org/mathscinet-getitem?mr=2391635")[#text("Ben Green and myself")]#text(", but this would require a large amount of manipulation of two-step nilsequences, which would lead to a number of technical complications. Instead, we take a “softer” approach, in which we set up some of the quadratic Fourier analysis of Gowers that goes into the proof of the inverse ")#mi("{U^3}")#text(" theorem, but stop well before the nilsequences come in. More precisely, we use a variant of the basic fact in quadratic Fourier analysis (already present in the previously mentioned paper of Gowers) that if a function ")#mi("{f}")#text(" has large ")#mi("{U^3}")#text(" norm, then for many shifts ")#mi("{h}")#text(", the derivative ")#mi("{\\Delta_h f(x) := f(x+h) \\overline{f(x)}}")#text(" correlates with a linear phase ")#mi("{e(\\xi(h) x)}")#text(", and furthermore that this phase ")#mi("{\\xi}")#text(" is approximately linear in the sense that there are many quadruples ")#mi("{(h_1,h_2,h_3,h_4)}")#text(" with ")#mi("{h_1+h_2=h_3+h_4}")#text(" and ")#mi("{\\xi(h_1)+\\xi(h_2) = \\xi(h_3)+\\xi(h_4)}")#text(". Applying this analysis to the above sum, we see that if that sum is large, then one obtains a number of approximate linearity relationships between the frequencies ")#mi("{\\xi}")#text(" for which ")#mi("{\\Delta_h f_{i,s}(x)}")#text(" correlates with ")#mi("{e(\\xi x)}")#text(". On the other hand, for each fixed ")#mi("{h,i,s}")#text(", Plancherel’s theorem tells us that there can only be a bounded number of frequencies ")#mi("{\\xi}")#text(" for which the correlation between ")#mi("{\\Delta_h f_{i,s}(x)}")#text(" and ")#mi("{e(\\xi x)}")#text(" is large. Varying ")#mi("{s,t}")#text(" suitably, this eventually creates so many linear constraints between these frequencies (with coefficients that vary in a sufficiently nonlinear fashion to ensure a high rank) that a contradiction can be derived, unless all the frequencies involved vanish. But this case can be handled by a variant of the above arguments, though in this case one needs to vary ")#mi("{s,t}")#text(" inside a moderately large two-dimensional arithmetic progression before one can finally reduce to a contradiction, which requires invoking the multidimensional Szemereédi theorem in order to ensure that all the pairs ")#mi("{(s,t)}")#text(" used are “good” in a certain technical sense. It is this last step which makes the error terms in the length four progression results to be qualitative (of order ")#mi("{o(1)}")#text(") rather than quantitative (of order ")#tao-math("{O(\\left|F\\right|^{-c})}", block: false)#text("). I feel that there should be a better approach than the rather ")#emph[#text("ad hoc")]#text(" approach employed here which should lead to better bounds (and which would more easily extend to other groups than ")#mi("{SL_2(F)}")#text(").")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d5f4ed0453e3158d3fced2b27355ad51ee23420f59aedded412c3b6f3c1b5caf-75bead472e9b0e5bdbbc4391aa60fe3c202ae01417c29b7698dc24809899e5b6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jeff ezearn")]], [#link("https://terrytao.wordpress.com/2012/12/11/mixing-for-progressions-in-non-abelian-groups/#comment-204617")[#strong[#text("jeff ezearn")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2012")])]

#text("Is it the situation that in the case of the four term progression for which a group element g is non-hyperbolic, that there might probably be a constraint such as (2) above for all x?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/12/11/mixing-for-progressions-in-non-abelian-groups/#comment-204683")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2012")])]

#text("That’s a great question, and resolving it in a sufficiently “robust” fashion would likely lead to the removal of the hyperbolicity restriction in my length four progression results. I did try my hand at this for a while, but could not algebraically simplify the four-term version of (2) by the techniques of changing variable and cancelling (which, roughly speaking, is to the 100% world as Cauchy-Schwarz type methods are to the 1% world). But perhaps another approach is possible (though if the approach is too “global” in nature, it may be restricted to the 100% or 99% worlds, and not to the 1% world which is the world in which the actual problem is set).")
]
]
