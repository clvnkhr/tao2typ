// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/03/17/254a-addendum-some-notes-on-nilprogressions/
// Converted to Typst by tao2typ: "2026-10-14T15:18:24.040388+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, addendum: Some notes on nilprogressions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, addendum: Some notes on nilprogressions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 March 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/03/17/254a-addendum-some-notes-on-nilprogressions/")[#text("https://terrytao.wordpress.com/2012/03/17/254a-addendum-some-notes-on-nilprogressions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is an addendum to ")#link("https://terrytao.wordpress.com/category/teaching/254a-hilberts-fifth-problem/")[#text("last quarter’s course notes")]#text(" on Hilbert’s fifth problem, which I am in the process of reviewing in order to transcribe them into a book (as was done similarly for several other sets of lecture notes on this blog). When reviewing the ")#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/")[#text("zeroth set of notes")]#text(" in particular, I found that I had made a claim (Proposition 11 from those notes) which asserted, roughly speaking, that any sufficiently large nilprogression was an approximate group, and promised to prove it later in the course when we had developed the ability to calculate efficiently in nilpotent groups. As it turned out, I managed finish the course without the need to develop these calculations, and so the proposition remained unproven. In order to rectify this, I will use this post to lay out some of the basic algebra of nilpotent groups, and use it to prove the above proposition, which turns out to be a bit tricky. (In ")#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/")[#text("my paper with Breuillard and Green")]#text(", we avoid the need for this proposition by restricting attention to a special type of nilprogression, which we call a nilprogression in ")#mi("{C}")#text("-normal form, for which the computations are simpler.)")

#text("There are several ways to think about nilpotent groups; for instance one can use the model example of the Heisenberg group")

#align(center)[#tao-fit-display[#mitex("H(R) :=\\begin{pmatrix} 1 & R & R \\\\ 0 & 1 & R\\\\ 0 & 0 & 1 \\end{pmatrix}")]]

#text("over an arbitrary ring ")#mi("{R}")#text(" (which need not be commutative), or more generally any matrix group consisting of unipotent upper triangular matrices, and view a general nilpotent group as being an abstract generalisation of such concrete groups. (In the case of nilpotent Lie groups, at least, this is quite an accurate intuition, thanks to ")#link("http://en.wikipedia.org/wiki/Engel%27s_theorem")[#text("Engel’s theorem")]#text(".) Or, one can adopt a Lie-theoretic viewpoint and try to think of nilpotent groups as somehow arising from nilpotent Lie algebras; this intuition is rigorous when working with nilpotent Lie groups (at least when the characteristic is large, in order to avoid issues coming from the denominators in the Baker-Campbell-Hausdorff formula), but also retains some conceptual value in the non-Lie setting. In particular, nilpotent groups (particularly finitely generated ones) can be viewed in some sense as “nilpotent Lie groups over ")#mi("{{\\bf Z}}")#text("“, even though Lie theory does not quite work perfectly when the underlying scalars merely form an integral domain instead of a field.")

#text("Another point of view, which arises naturally both in analysis and in algebraic geometry, is to view nilpotent groups as modeling “infinitesimal” perturbations of the identity, where the infinitesimals have a certain finite order. For instance, given a (not necessarily commutative) ring ")#mi("{R}")#text(" without identity (representing all the “small” elements of some larger ring or algebra), we can form the powers ")#mi("{R^j}")#text(" for ")#mi("{j=1,2,\\ldots}")#text(", defined as the ring generated by ")#mi("{j}")#text("-fold products ")#mi("{r_1 \\ldots r_j}")#text(" of elements ")#mi("{r_1,\\ldots,r_j}")#text(" in ")#mi("{R}")#text("; this is an ideal of ")#mi("{R}")#text(" which represents the elements which are “")#mi("{j^{th}}")#text(" order” in some sense. If one then formally adjoins an identity ")#mi("{1}")#text(" onto the ring ")#mi("{R}")#text(", then for any ")#mi("{s \\geq 1}")#text(", the multiplicative group ")#mi("{G := 1+R \\text{ mod } R^{s+1}}")#text(" is a nilpotent group of step at most ")#mi("{s}")#text(". For instance, if ")#mi("{R}")#text(" is the ring of strictly upper ")#mi("{s \\times s}")#text(" matrices (over some base ring), then ")#mi("{R^{s+1}}")#text(" vanishes and ")#mi("{G}")#text(" becomes the group of unipotent upper triangular matrices over the same ring, thus recovering the previous matrix-based example. In analysis applications, ")#mi("{R}")#text(" might be a ring of operators which are somehow of “order” ")#mi("{O(\\epsilon)}")#text(" or ")#mi("{O(\\hbar)}")#text(" for some small parameter ")#mi("{\\epsilon}")#text(" or ")#mi("{\\hbar}")#text(", and one wishes to perform Taylor expansions up to order ")#mi("{O(\\epsilon^s)}")#text(" or ")#mi("{O(\\hbar^s)}")#text(", thus discarding (i.e. quotienting out) all errors in ")#mi("{R^{s+1}}")#text(".")

#text("From a dynamical or group-theoretic perspective, one can also view nilpotent groups as towers of central extensions of a trivial group. Finitely generated nilpotent groups can also be profitably viewed as a special type of polycylic group; this is the perspective taken in ")#link("https://terrytao.wordpress.com/2009/12/21/the-free-nilpotent-group/")[#text("this previous blog post")]#text(". Last, but not least, one can view nilpotent groups from a combinatorial group theory perspective, as being words from some set of generators of various “degrees” subject to some commutation relations, with commutators of two low-degree generators being expressed in terms of higher degree objects, and all commutators of a sufficiently high degree vanishing. In particular, generators of a given degree can be moved freely around a word, as long as one is willing to generate commutator errors of higher degree.")

#text("With this last perspective, in particular, one can start computing in nilpotent groups by adopting the philosophy that the lowest order terms should be attended to first, without much initial concern for the higher order errors generated in the process of organising the lower order terms. Only after the lower order terms are in place should attention then turn to higher order terms, working successively up the hierarchy of degrees until all terms are dealt with. This turns out to be a relatively straightforward philosophy to implement in many cases (particularly if one is not interested in explicit expressions and constants, being content instead with qualitative expansions of controlled complexity), but the arguments are necessarily recursive in nature and as such can become a bit messy, and require a fair amount of notation to express precisely. So, unfortunately, the arguments here will be somewhat cumbersome and notation-heavy, even if the underlying methods of proof are relatively simple.")

#metadata(none) <tao-dd42c2bff6ebde7b488d>

#heading(level: 1)[#strong[#text(" — 1. Some elementary group theory — ")]]

#text("Let ")#mi("{g, h}")#text(" be two elements of a group ")#mi("{G = (G,\\cdot)}")#text(". We define the ")#link("http://en.wikipedia.org/wiki/Conjugation_(group_theory)")[#text("conjugate")]#text(" ")#mi("{g^h}")#text(" and ")#link("http://en.wikipedia.org/wiki/Commutator")[#text("commutator")]#text(" ")#mi("{[g,h]}")#text(" by the formulae ")#metadata(none) <tao-322b20bd5e88d3a601b5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("g^h := h^{-1} g h")]]

#text("and ")#metadata(none) <tao-d01fd4a945eab6480708>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("[g,h] := g^{-1} h^{-1} gh.")]]

#text("(Note that this convention for ")#mi("{[g,h]}")#text(" is not universal; for instance, the alternate convention ")#mi("{[g,h] = ghg^{-1}h^{-1}}")#text(" also appears in the literature. The distinctions between the two conventions however are quite minor; the conventions here are optimised for pulling group elements to the right of a word, whereas other conventions may be slightly better for pulling group elements to the left of a word.)")

#text("Conjugation by a fixed element ")#mi("{h}")#text(" is an automorphism of ")#mi("{G}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("(gk)^h = g^h k^h")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(g^h)^{-1} = (g^{-1})^h")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("1^h = 1")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("[g,k]^h = [g^h,k^h]")]]

#text("for all ")#mi("{g,h,k \\in G}")#text(". Conjugation is also an action, thus")

#align(center)[#tao-fit-display[#mitex("(g^h)^k = g^{hk}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("g^1 = g.")]]

#text("An automorphism of the form ")#mi("{g \\mapsto g^h}")#text(" is called an ")#link("https://terrytao.wordpress.com/2012/03/17/254a-addendum-some-notes-on-nilprogressions/???")[#text("inner automorphism")]#text(".")

#text("Conjugation is related to multiplication by the identity")

#align(center)[#tao-fit-display[#mitex("gh = h g^h,")]]

#text("thus one can pull ")#mi("{g}")#text(" to the right of ")#mi("{h}")#text(" at the cost of twisting (i.e. conjugating) it by ")#mi("{h}")#text(". Commutation is related to multiplication by the identity")

#align(center)[#tao-fit-display[#mitex("gh = hg [g,h],")]]

#text("thus one can pull ")#mi("{g}")#text(" to the right of ")#mi("{h}")#text(" at the cost of adding an additional commutator factor ")#mi("{[g,h]}")#text(" to the right. Finally, commutation is related to conjugation by the identity")

#align(center)[#tao-fit-display[#mitex("g^h = g [g,h].")]]

#text("The commutator can be viewed as a nonlinear group-theoretic analogue of the ")#link("http://en.wikipedia.org/wiki/Lie_bracket")[#text("Lie bracket")]#text(". For instance, in a matrix group ")#mi("{G = GL_n({\\bf C})}")#text(", we observe that the commutator ")#mi("{[1+\\epsilon A, 1+\\epsilon B]}")#text(" of two elements ")#mi("{1+\\epsilon A}")#text(" and ")#mi("{1+\\epsilon B}")#text(" close to the identity is of the form ")#mi("{1 + \\epsilon^2 (AB-BA) + O(\\epsilon^3)}")#text(", thus linking the group-theoretic commutator to the Lie bracket ")#mi("{A,B \\mapsto AB-BA}")#text(".")

#text("Because of this link, we expect the group-theoretic commutator to obey some nonlinear analogues of the basic Liebracket identities, and this is indeed the case. For instance, one easily observes that the commutator is antisymmetric in the sense that ")#metadata(none) <tao-e39dab15930913591a0c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("[h,g] = [g,h]^{-1}")]]

#text("and is approximately odd in the sense that ")#metadata(none) <tao-b6b4377acb039899003d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("[g^{-1},h] = ([g,h]^{-1})^{g^{-1}}")]]

#text("and ")#metadata(none) <tao-69834e9f9c512b9c9242>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("[g,h^{-1}] = ([g,h]^{-1})^{h^{-1}}")]]

#text("for any ")#mi("{g,h \\in G}")#text(". We also have the easily verified approximate bilinearity identities")

#align(center)[#tao-fit-display[#mitex("[g,hk] = [g,h] [g,k]^h")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("[gh,k] = [g,k]^h [h,k]")]]

#text("for any ")#mi("{g,h,k \\in G}")#text(". Finally, we have the approximate ")#link("http://en.wikipedia.org/wiki/Jacobi_identity")[#text("Jacobi identity")]#text(" (better known as the ")#link("http://en.wikipedia.org/wiki/Hall-Witt_identity")[#text("Hall-Witt identity")]#text(") ")#metadata(none) <tao-c293c42d9e7cabf1e58e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("[[g,h^{-1}],k]^h [[h,k^{-1}],g]^k [[k,g^{-1}],h]^g = 1.")]]

#text("A subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" is said to be ")#link("https://terrytao.wordpress.com/2012/03/17/254a-addendum-some-notes-on-nilprogressions/???")[#text("normal")]#text(" if it is preserved by all inner automorphisms, thus ")#mi("{H^g = H}")#text(" for all ")#mi("{g}")#text(" (writing ")#mi("{H^g := \\{h^g: h \\in H \\}}")#text(", of course), and ")#link("http://en.wikipedia.org/wiki/Characteristic_subgroup")[#text("characteristic")]#text(" if it is preserved by all automorphisms (not necessarily inner). Thus, all characteristic subgroups are normal, but the converse is not necessarily true. We write ")#mi("{H \\leq G}")#text(" or ")#mi("{G \\geq H}")#text(" if ")#mi("{H}")#text(" is a subgroup of ")#mi("{G}")#text(", and ")#mi("{H \\rhd G}")#text(" or ")#mi("{G \\lhd H}")#text(" if ")#mi("{H}")#text(" is a normal subgroup of ")#mi("{G}")#text(".")

#text("If ")#mi("{N}")#text(" is a normal subgroup of ")#mi("{G}")#text(", we write ")#mi("{g \\mapsto g \\text{ mod } N}")#text(" for the quotient map from ")#mi("{G}")#text(" to ")#mi("{G/N}")#text(", thus ")#mi("{g = h \\text{ mod } N}")#text(" if ")#mi("{g \\in hN = Nh}")#text(". Given any other subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(", we write ")#mi("{H \\text{ mod } N}")#text(" for the image of ")#mi("{H}")#text(" under the ")#mi("{\\text{ mod } N}")#text(" map, thus")

#align(center)[#tao-fit-display[#mitex("H \\text{ mod } N \\equiv HN / N = NH / N \\equiv H / (H \\cap N).")]]

#text("Given two subgroups ")#mi("{H,K}")#text(" of a group ")#mi("{G}")#text(", we define the commutator group ")#mi("{[H,K]}")#text(" to be the group generated by the commutators ")#mi("{[h,k]}")#text(" with ")#mi("{h \\in H, k\\in K}")#text(". We say that ")#mi("{H}")#text(" and ")#mi("{K}")#text(" ")#emph[#text("commute")]#text(" if ")#mi("{[H,K]}")#text(" is trivial, or equivalently if every element of ")#mi("{H}")#text(" commutes with every element of ")#mi("{K}")#text(". Note that if ")#mi("{H, K}")#text(" are normal, then ")#mi("{[H,K]}")#text(" is also normal. In this case, one can view ")#mi("{[H,K]}")#text(" as the smallest subgroup of ")#mi("{G}")#text(" such that ")#mi("{H, K}")#text(" commute modulo ")#mi("{[H,K]}")#text(" (or equivalently, that ")#mi("{H \\text{ mod } [H,K]}")#text(" and ")#mi("{K \\text{ mod } [H,K]}")#text(" commute). Similarly, if ")#mi("{H,K}")#text(" are characteristic, then ")#mi("{[H,K]}")#text(" is also characteristic.")

#text("Observe from ")#link(<tao-e39dab15930913591a0c>)[#text("(3)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("[H,K] = [K,H]")]]

#text("for any subgroups ")#mi("{H, K}")#text(". Also that if ")#mi("{N}")#text(" is a normal subgroup of ")#mi("{G}")#text(", then (as ")#mi("{\\text{ mod } N}")#text(" is a homomorphism)")

#align(center)[#tao-fit-display[#mitex("HK \\text{ mod } N = (H \\text{ mod } N) (K \\text{ mod } N)")]]

#text("and ")#metadata(none) <tao-f8c14b2a7024f15661d6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("[H,K] \\text{ mod } N = [H \\text{ mod } N, K \\text{ mod } N]")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" ")#metadata(none) <tao-aea96c13c0540a330ad5>

#list(
[#text("(i) If ")#mi("{H, K}")#text(" are normal subgroups of ")#mi("{G}")#text(" generated by subsets ")#mi("{A \\subset H}")#text(", ")#mi("{B \\subset K}")#text(" respectively, show that ")#mi("{[H,K]}")#text(" is the normal subgroup of ")#mi("{G}")#text(" generated (as a normal subgroup) by the commutators ")#mi("{[a,b]}")#text(" with ")#mi("{a \\in A}")#text(", ")#mi("{b \\in B}")#text(".")],
[#text("(ii) If ")#mi("{N,H,K}")#text(" are normal subgroups of ")#mi("{G}")#text(", show that ")#mi("{[[N,H],K]}")#text(" lies in the normal subgroup generated by ")#mi("{[[H,K],N]}")#text(" and ")#mi("{[[K,N],H]}")#text(". (")#emph[#text("Hint:")]#text(" use the Hall-Witt identity ")#link(<tao-c293c42d9e7cabf1e58e>)[#text("(6)")]#text(".)")]
)
]

#text("Given an arbitrary group ")#mi("{G}")#text(", we define the ")#link("http://en.wikipedia.org/wiki/Central_series#Lower_central_series")[#text("lower central series")]#text(" ")#mi("{G = G_1 \\lhd G_2 \\ldots}")#text(" of ")#mi("{G}")#text(" by setting ")#mi("{G_1 := G}")#text(" and ")#mi("{G_{i+1} := [G,G_i]}")#text(" for all ")#mi("{i \\geq 1}")#text(". Observe that all of the groups ")#mi("{G_i}")#text(" in this series are characteristic and thus normal. A group ")#mi("{G}")#text(" is said to be ")#emph[#text("nilpotent of step at most ")#mi("{s}")]#text(" if ")#mi("{G_{s+1}}")#text(" is trivial; in particular, by ")#link(<tao-f8c14b2a7024f15661d6>)[#text("(7)")]#text(", we see that ")#mi("{G \\mod G_{s+1} = G/G_{s+1}}")#text(" is nilpotent of step at most ")#mi("{s}")#text(" for any group ")#mi("{G}")#text(". We have a basic inclusion:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" ")#metadata(none) <tao-9294ab38039f60d2ec53>#text(" We have ")#mi("{[G_i,G_j] \\subset G_{i+j}}")#text(" for all ")#mi("{i,j \\geq 1}")#text(". (")#emph[#text("Hint:")]#text(" use Exercise ")#link(<tao-aea96c13c0540a330ad5>)[#text("1")]#text(".)")
]

#text("The commutator structure can be clarified by passing to the “top order” components of this commutator, as follows. (Strictly speaking, this analysis is not needed to study nilprogressions, but it is still conceptually useful nonetheless.) Consider the subquotients ")#mi("{V_i := G_i \\mod G_{i+1}}")#text(" of the group ")#mi("{G}")#text(" for ")#mi("{i=1,2,\\ldots}")#text(". As ")#mi("{G_{i+1}}")#text(" contains ")#mi("{[G_i,G_i]}")#text(", we see that each group ")#mi("{V_i}")#text(" is abelian. To emphasise this, we will write ")#mi("{V_i}")#text(" additively instead of multiplicatively, thus we shall denote the group operation on ")#mi("{V_i}")#text(" as ")#mi("{+}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(" ")#metadata(none) <tao-549ce58984289d8f0391>#text(" For each ")#mi("{i,j \\geq 1}")#text(", the commutator map ")#mi("{[,]: G_i \\times G_j \\rightarrow [G_i,G_j]}")#text(" descends to a map ")#mi("{[,]_{i,j}: V_i \\times V_j \\rightarrow V_{i+j}}")#text(", thus ")#metadata(none) <tao-4e448897946ead9e39e8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("[g, h] \\mod G_{i+j+1} = [g \\mod G_{i+1}, h \\mod G_{j+1}]_{i,j}")]]

#text("for ")#mi("{g \\in G_i, h \\in G_j}")#text(".")
]

#emph[#text("Proof:")]#text(" We can quotient out by ")#mi("{G_{i+j+1}}")#text(", and assume that ")#mi("{G_{i+j+1}}")#text(" is trivial. In particular, by Lemma ")#link(<tao-9294ab38039f60d2ec53>)[#text("2")]#text(", ")#mi("{G_{i+1}}")#text(" commutes with ")#mi("{G_j}")#text(", and ")#mi("{G_i}")#text(" commutes with ")#mi("{G_{j+1}}")#text(". As such, it is easy to see that if ")#mi("{g \\in G_i, h \\in G_j}")#text(", then ")#mi("{[g,h]}")#text(" is unchanged if one multiplies ")#mi("{g}")#text(" (on the left or right) by an element of ")#mi("{G_{i+1}}")#text(", and similarly for ")#mi("{h}")#text(" and ")#mi("{G_{j+1}}")#text(". This defines the map ")#mi("{[,]_{i,j}}")#text(" as required. ")#mi("\\Box")

#text("We refer to the maps ")#mi("{[,]_{i,j}}")#text(" as ")#emph[#text("quotiented commutator maps")]#text(". The identity ")#link(<tao-4e448897946ead9e39e8>)[#text("(8)")]#text(" asserts that these maps ")#mi("{[,]_{i,j}}")#text(" capture the “top order” nonlinear behaviour of the group ")#mi("{G}")#text(". As the following exercise shows, these maps behave like (graded components of) a Lie bracket.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Let ")#mi("{G}")#text(" be a group with lower central series ")#mi("{G = G_1 \\lhd G_2 \\lhd \\ldots}")#text(", subquotients ")#mi("{V_i}")#text(", and quotiented commutator maps ")#mi("{[,]_{i,j}: V_i \\times V_j \\rightarrow V_{i+j}}")#text(". Let ")#mi("{i,j,k \\geq 1}")#text(", let ")#mi("{x,x^{\\prime} \\in V_i}")#text(", ")#mi("{y, y^{\\prime} \\in V_j}")#text(", and ")#mi("{z \\in V_k}")#text(". Establish the antisymmetry")

#align(center)[#tao-fit-display[#mitex("[x,y]_{i,j} = -[y,x]_{j,i},")]]

#text("the bihomomorphism properties")

#tao-aligned(keep: true)[


#tao-math("[x+x^{\\prime},y]_{i,j}  & = [x,y]_{i,j} + [x^{\\prime},y]_{i,j}", block: true)



#tao-math("[-x,y]_{i,j}  & = -[x,y]_{i,j}", block: true)



#tao-math("[0,y]_{i,j}  & = 0", block: true)
]

#text("and")

#tao-aligned(keep: true)[


#tao-math("[x,y+y^{\\prime}]_{i,j}  & = [x,y]_{i,j} + [x,y^{\\prime}]_{i,j}", block: true)



#tao-math("[x,-y]_{i,j}  & = -[x,y]_{i,j}", block: true)



#tao-math("[x,0]_{i,j}  & = 0", block: true)
]

#text("and the Jacobi identity")

#align(center)[#tao-fit-display[#mitex("[[x,y]_{i,j}, z]_{i+j,k} + [[y,z]_{j,k},x]_{j+k,i} + [[z,x]_{k,i},y]_{k+i,j} = 0.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" If one wished, one could combine all of these subquotients ")#mi("{V_i}")#text(" and quotiented commutator maps ")#mi("{[,]_{i,j}}")#text(" into a single ")#link("http://en.wikipedia.org/wiki/Graded_algebra")[#text("graded")]#text(" object, namely the additive group ")#mi("{V := \\oplus_i V_i}")#text(" consisting of tuples ")#mi("{(v_i)_{i =1}^\\infty}")#text(" with ")#mi("{v_i \\in V_i}")#text(" (and all but finitely many of the ")#mi("{v_i}")#text(" trivial), with a bracket ")#mi("{[,]: V \\times V \\rightarrow V}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("[ (v_i)_{i=1}^\\infty, (w_j)_{j=1}^\\infty ] := (\\sum_{i+j=k} [v_i,w_j]_{i,j})_{k=1}^\\infty .")]]

#text("Then this bracket is an antisymmetric bihomomorphism obeying the Jacobi identity, thus ")#mi("{V}")#text(" is a Lie algebra over the integers ")#mi("{{\\bf Z}}")#text(". One could view this object as the “top order” or “Carnot” component of the “Lie algebra” of ")#mi("{G}")#text(". We will however not need this object here.")
]

#text("We can iterate the “bilinear” commutator operations to create “multilinear” operations. Given a non-empty finite set ")#mi("{{\\mathcal A}}")#text(" of formal group elements ")#mi("{{\\bf g}}")#text(", we can define a ")#emph[#text("formal commutator word")]#text(" ")#mi("{w}")#text(" on ")#mi("{{\\mathcal A}}")#text(" to be a word that can be generated by the following rules:")

#list(
[#text("If ")#mi("{{\\bf g}}")#text(" is a formal group element, then ")#mi("{{\\bf g}}")#text(" is a formal commutator word on ")#mi("{\\{ {\\bf g} \\}}")#text(".")],
[#text("If ")#mi("{{\\mathcal A}, {\\mathcal B}}")#text(" are disjoint finite non-empty sets of formal group elements, and ")#mi("{u, v}")#text(" are formal commutator words on ")#mi("{{\\mathcal A}, {\\mathcal B}}")#text(" respectively, then ")#mi("{[u,v]}")#text(" is a formal commutator word on ")#mi("{{\\mathcal A} \\cup {\\mathcal B}}")#text(".")]
)

#text("We refer to ")#tao-math("{\\left|{\\mathcal A}\\right|}", block: false)#text(" as the ")#emph[#text("length")]#text(" of the formal commutator word. Thus, for instance, ")#mi("{[[{\\bf g}_1, {\\bf g}_2], [{\\bf g}_3, {\\bf g}_4]]}")#text(" is a formal commutator word on ")#mi("{\\{ {\\bf g}_1, {\\bf g}_2, {\\bf g}_3, {\\bf g}_4 \\}}")#text(" of length ")#mi("{4}")#text(". Given a formal commutator word ")#mi("{w}")#text(" on ")#mi("{{\\mathcal A}}")#text(" and an assignment ")#mi("{g: {\\bf g} \\mapsto g({\\bf g})}")#text(" of group elements ")#mi("{g({\\bf g})\\in G}")#text(" to each formal group element ")#mi("{{\\bf g} \\in {\\mathcal A}}")#text(", we can define the group element ")#mi("{w(g) \\in G}")#text(" by substituting ")#mi("{g({\\bf g})}")#text(" for ")#mi("{{\\bf g}}")#text(" in ")#mi("{w}")#text(" for each ")#mi("{{\\bf g} \\in G}")#text(". This gives a ")#emph[#text("commutator word map")]#text(" ")#mi("{w: G^{\\mathcal A} \\rightarrow G}")#text(". Given an assignment ")#mi("{i: {\\bf g} \\mapsto i({\\bf g})}")#text(" of a positive integer (or “degree”) ")#mi("{i({\\bf g})}")#text(" to each formal group element ")#mi("{{\\mathcal A}}")#text(", Lemma ")#link(<tao-549ce58984289d8f0391>)[#text("1")]#text(" and induction then gives a map ")#mi("{w_i: \\prod_{{\\bf g} \\in {\\mathcal A}} V_{i({\\bf g})} \\rightarrow V_{\\sum_{{\\bf g} \\in {\\mathcal A}} i({\\bf g})}}")#text(" which is a multihomomorphism (i.e. a homomorphism in each variable). From ")#link(<tao-4e448897946ead9e39e8>)[#text("(8)")]#text(" one has that")

#align(center)[#tao-fit-display[#mitex("w( g ) \\text{ mod } G_{\\sum_{{\\bf g} \\in {\\mathcal A}} i({\\bf g}) + 1} = w_i( g \\text{ mod } G_{i+1} )")]]

#text("where ")#mi("{g \\text{ mod } G_{i+1}}")#text(" is shorthand for the assignment ")#mi("{{\\bf g} \\mapsto g({\\bf g}) \\text{ mod } G_{i({\\bf g}) + 1}}")#text(".")

#text("In particular, using the degree map ")#mi("{i({\\bf g}) := 1}")#text(", we obtain a multihomomorphism")

#align(center)[#tao-fit-display[#mitex("w_1: V_1^l \\rightarrow V_l")]]

#text("for any commutator word ")#mi("{w}")#text(" of length ")#mi("{l}")#text(", such that")

#align(center)[#tao-fit-display[#mitex("w( g ) \\text{ mod } G_{l + 1} = w_1( g \\text{ mod } G_2 ).")]]

#text("From the multihomomorphism nature of ")#mi("{w_1}")#text(", we conclude in particular that ")#metadata(none) <tao-03e3c136a5a2e814f8a3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("w( g_1^{n_1}, \\ldots, g_l^{n_l} ) = w(g_1,\\ldots,g_l)^{n_1 \\ldots n_l} \\text{ mod } G_{l+1}")]]

#text("for any ")#mi("{g_1,\\ldots,g_l \\in G}")#text(" and integers ")#mi("{n_1,\\ldots,n_l}")#text(". A variant of this approximate identity will be key in understanding nilprogressions.")

#text("One can use commutator words to generate a nilpotent group ")#mi("{G}")#text(" and its lower central series:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Let ")#mi("{G}")#text(" be a nilpotent group that is generated by a set ")#mi("{S}")#text(" of generators.")

#list(
[#text("(i) Show that for every positive integer ")#mi("{i}")#text(", ")#mi("{G_i}")#text(" is generated by the words ")#mi("{w(g)}")#text(", where ")#mi("{w}")#text(" ranges over formal commutator words of length ")#mi("{l}")#text(" at least ")#mi("{i}")#text(", and ")#mi("{g}")#text(" is a collection of ")#mi("{l}")#text(" generators from ")#mi("{S}")#text(" (possibly with repetition).")],
[#text("(ii) Suppose further that ")#mi("{S}")#text(" is finite (so that there are only finitely many possible choices for ")#mi("{w(g)}")#text(" for any given length ")#mi("{l}")#text(", and let ")#mi("{e_1,\\ldots,e_n}")#text(" be all the values of ")#mi("{w(g)}")#text(" as ")#mi("{w}")#text(" varies over formal commutator words of length at most ")#mi("{s}")#text(", and ")#mi("{g}")#text(" ranges over collections of generators from ")#mi("{S}")#text(", arranged in non-decreasing length of ")#mi("{w}")#text(" (this arrangement is not unique, and may contain repeated values). Show that for every positive integer ")#mi("{i}")#text(", any element in ")#mi("{G_i}")#text(" can be expressed in the form ")#mi("{e_j^{a_j} \\ldots e_n^{a_n}}")#text(", where ")#mi("{e_j,\\ldots,e_n}")#text(" are the elements of ")#mi("{e_1,\\ldots,e_n}")#text(" arising from words ")#mi("{w}")#text(" of length at least ")#mi("{i}")#text(", and ")#mi("{a_j,\\ldots,a_n}")#text(" are integers.")]
)
]

#heading(level: 1)[#strong[#text(" — 2. Nilprogressions — ")]]

#text("Recall from ")#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/")[#text("Notes 0")]#text(" that a ")#emph[#text("noncommutative progression")]#text(" ")#mi("{P(a_1,\\ldots,a_r;N_1,\\ldots,N_r)}")#text(" in a group ")#mi("{G}")#text(" with generators ")#mi("{a_1,\\ldots,a_r \\in G}")#text(" and dimensions ")#mi("{N_1,\\ldots,N_r > 0}")#text(" is the set of all words with alphabet ")#mi("{a_1^{\\pm 1}, \\ldots, a_r^{\\pm 1}}")#text(", such that for each ")#mi("{1 \\leq i \\leq r}")#text(", the symbols ")#mi("{a_i, a_i^{-1}}")#text(" are used a total of at most ")#mi("{N_i}")#text(" times. A ")#emph[#text("nilprogression")]#text(" is a noncommutative progression in a nilpotent group. The objective of this section is to prove Proposition 11 from Notes 0, restated here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" ")#metadata(none) <tao-bcacb706cf171729008c>#text(" Suppose that ")#mi("{a_1,\\ldots,a_r \\in G}")#text(" generate a nilpotent group of step ")#mi("{s}")#text(", and suppose that ")#mi("{N_1,\\ldots,N_r}")#text(" are all sufficiently large depending on ")#mi("{r,s}")#text(". Then ")#mi("{P := P( a_1,\\ldots,a_r;N_1,\\ldots,N_r)}")#text(" is an ")#mi("{O_{r,s}(1)}")#text("-approximate group.")
]

#text("Recall that a subset ")#mi("{A}")#text(" of a group ")#mi("{G}")#text(" is a ")#mi("{K}")#text("-approximate group if it is symmetric, contains the origin, and if ")#mi("{A^2}")#text(" can be covered by ")#mi("{K}")#text(" left-translates (or equivalently, right-translates) of ")#mi("{A}")#text(". The first two properties are clear, so it suffices to show that ")#mi("{P^2}")#text(" can be covered by ")#mi("{O_{r,s}(1)}")#text(" right-translates of ")#mi("{P}")#text(".")

#text("We allow all implied constants to depend on ")#mi("{r, s}")#text(". We pick a small constant ")#mi("{\\epsilon>0}")#text(" (depending on ")#mi("{r,s}")#text("). It will suffice to show the inclusion")

#align(center)[#tao-fit-display[#mitex("P( a_1,\\ldots,a_r;2N_1,\\ldots,2N_r) \\subset P( a_1,\\ldots,a_r;O(\\epsilon N_1 + 1),\\ldots,O( \\epsilon N_r + 1) ) X")]]

#text("for some set ")#mi("{X}")#text(" of cardinality ")#tao-math("{\\left|X\\right| \\ll_\\epsilon 1}", block: false)#text(".")

#text("We will need some auxiliary objects. For ")#mi("{i \\geq 1}")#text(" and ")#mi("{t>0}")#text(", let ")#metadata(none) <tao-c84c6a9549851a013e86>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("Q^t_i( a_1,\\ldots,a_r;N_1,\\ldots,N_r) := P( a^{\\prime}_1,\\ldots,a^{\\prime}_R; tN^{\\prime}_1,\\ldots,tN^{\\prime}_R ),")]]

#text("where ")#mi("{a^{\\prime}_1,\\ldots,a^{\\prime}_R}")#text(" consists of all group elements of the form ")#mi("{w(a_{i_1},\\ldots,a_{i_l})}")#text(" where ")#mi("{w}")#text(" is a formal commutator word of length ")#mi("{l \\geq i}")#text(", ")#mi("{1 \\leq i_1,\\ldots,i_l \\leq r}")#text(", and each ")#mi("{a^{\\prime}_j = w(a_{i_1},\\ldots,a_{i_l})}")#text(" is associated to the dimension ")#mi("{N^{\\prime}_j := N_{i_1} \\ldots N_{i_l}}")#text(" (note that we allow some of the ")#mi("{a^{\\prime}_i}")#text(" to be equal, or to degenerate to the identity). Thus the ")#mi("{Q_i(a_1,\\ldots,a_r;N_1,\\ldots,N_r)}")#text(" are non-increasing in ")#mi("{i}")#text(" and become trivial for ")#mi("{i \\geq s}")#text(". We will usually abbreviate ")#mi("{Q^t_i(a_1,\\ldots,a_r;N_1,\\ldots,N_r)}")#text(" as ")#mi("{Q^t_i}")#text(". Trivially we also have")

#align(center)[#tao-fit-display[#mitex("P(a_1,\\ldots,a_r;N_1,\\ldots,N_r) \\subset Q^t_1.")]]

#text("Observe also that the ")#mi("{Q^t_i}")#text(" are symmetric, contain the identity, and ")#mi("{Q^t_i Q^{t^{\\prime}}_i \\subset Q^{t+t^{\\prime}}_i}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5 (Approximate filtration property)")]#text(" ")#metadata(none) <tao-cf979e9ac9cbbc243c96>#text(" If ")#mi("{g \\in Q_i^{O(1)}}")#text(" and ")#mi("{h \\in Q_j(a_1,\\ldots,a_r;N_1,\\ldots,N_r)}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("[g,h] \\in Q_{i+j}^{O(1)}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("g^h \\in Q_i^{O(1)}.")]]
]

#text("Next, we need the following variant of ")#link(<tao-03e3c136a5a2e814f8a3>)[#text("(9)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" Let ")#mi("{w}")#text(" be a formal commutator word of length ")#mi("{l \\geq 1}")#text(", and let ")#mi("{1 \\leq i_1,\\ldots,i_l \\leq r}")#text(". For each ")#mi("{1 \\leq j \\leq r}")#text(", let ")#mi("{n_j}")#text(" be an integer with ")#mi("{n_j = O(N_{i_j})}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("w(a_{i_1}^{n_1},\\ldots,a_{i_l}^{n_l}) \\in w(a_{i_1},\\ldots,a_{i_l})^{n_1 \\ldots n_l} Q_{l+1}^{O(1)}.")]]
]

#emph[#text("Proof:")]#text(" When ")#mi("{l > s}")#text(", the expressions involving ")#mi("{w}")#text(" collapse to the identity, and the claim follows, so we may assume that ")#mi("{1 \\leq l \\leq s}")#text(". We induct on ")#mi("{l}")#text(". The claim ")#mi("{l=1}")#text(" is trivial, so suppose that ")#mi("{1 < l \\leq s}")#text(" and that the claim has been proven for smaller values of ")#mi("{l}")#text(".")

#text("We first establish the key case ")#mi("{l=2}")#text(". In this case, it suffices to show that ")#metadata(none) <tao-089564af036951417bad>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("[a^n, b^m] \\in [a,b]^{nm} Q_3^{O(1)}( a,b; \\left|n\\right|, \\left|m\\right| )", block: true)]]

#text("for any ")#mi("{a,b \\in G}")#text(" and ")#mi("{n,m \\in {\\bf Z}}")#text(". By using commutator identities ")#link(<tao-b6b4377acb039899003d>)[#text("(4)")]#text(", ")#link(<tao-69834e9f9c512b9c9242>)[#text("(5)")]#text(" we may assume that ")#mi("{n,m}")#text(" are positive. It suffices to show that")

#align(center)[#tao-fit-display[#mitex("(a^n)^{b^m} \\in a^n [a,b]^{nm} Q_3^{O(1)}(a,b; n, m ).")]]

#text("We can write ")#mi("{(a^n)^{b^m} = (a^{b^m})^n}")#text(". It is then not difficult to see (and we leave as an exercise to the reader) that the claim will follow if we can show")

#align(center)[#tao-fit-display[#mitex("(a)^{b^m} \\in a [a,b]^{m} Q_3^{O(1)}(a,b; 1, m ),")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("[a,b^m] \\in [a,b]^m Q_3^{O(1)}(a,b; 1,m).")]]

#text("Thus we have effectively reduced the problem to the case ")#mi("{n=1}")#text(". A similar argument allows us to also obtain the additional reduction ")#mi("{m=1}")#text(", at which point the claim is trivial. This completes the treatment of the ")#mi("{l=2}")#text(" case.")

#text("Now we handle the general case. After some relabeling, we may write ")#mi("{w = [u,v]}")#text(", where ")#mi("{u,v}")#text(" are words of length ")#mi("{l_1,l_2}")#text(" respectively for some ")#mi("{l_1,l_2<l}")#text(" adding up to ")#mi("{l}")#text(", with")

#align(center)[#tao-fit-display[#mitex("w(a_{i_1}^{n_1},\\ldots,a_{i_l}^{n_l}) = [u(a_{i_1}^{n_1},\\ldots,a_{i_{l_1}}^{n_{l_1}}), v(a_{i_{l_1+1}}^{n_{l_1+1}},\\ldots,a_{i_l}^{n_l}) ]")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("w(a_{i_1},\\ldots,a_{i_l}) = [u(a_{i_1},\\ldots,a_{i_{l_1}}, v(a_{i_{l_1+1}},\\ldots,a_{i_l}) ].")]]

#text("By induction hypothesis, one has")

#align(center)[#tao-fit-display[#mitex("u(a_{i_1}^{n_1},\\ldots,a_{i_{l_1}}^{n_{l_1}}) \\in u(a_{i_1},\\ldots,a_{i_{l_1}})^{n_1 \\ldots n_{l_1}} Q_{l_1+1}^{O(1)}.")]]

#text("In particular we have")

#align(center)[#tao-fit-display[#mitex("u(a_{i_1}^{n_1},\\ldots,a_{i_{l_1}}^{n_{l_1}}) \\in Q_{l_1}^{O(1)}.")]]

#text("Similarly we have")

#align(center)[#tao-fit-display[#mitex("v(a_{i_{l_1+1}}^{n_{l_1+1}},\\ldots,a_{i_l}^{n_l}) \\in v(a_{i_{l_1+1}},\\ldots,a_{i_l})^{n_{l_i+1}\\ldots n_l} Q_{l_2+1}^{O(1)} \\subset Q_{l_2}^{O(1)}.")]]

#text("Using ")#link(<tao-cf979e9ac9cbbc243c96>)[#text("(5)")]#text(" and the approximate homomorphism properties of commutators, we conclude that")

#align(center)[#tao-fit-display[#mitex("[u(a_{i_1}^{n_1},\\ldots,a_{i_{l_1}}^{n_{l_1}}), v(a_{i_{l_1+1}}^{n_{l_1+1}},\\ldots,a_{i_l}^{n_l}) ] \\in [u(a_{i_1},\\ldots,a_{i_{l_1}})^{n_1 \\ldots n_{l_1}}, v(a_{i_{l_1+1}},\\ldots,a_{i_l})^{n_{l_i+1}\\ldots n_l}] Q_{l+1}^{O(1)},")]]

#text("but from ")#link(<tao-089564af036951417bad>)[#text("(11)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("[u(a_{i_1},\\ldots,a_{i_{l_1}})^{n_1 \\ldots n_{l_1}}, v(a_{i_{l_1+1}},\\ldots,a_{i_l})^{n_{l_i+1}\\ldots n_l}] \\subset [u(a_{i_1},\\ldots,a_{i_{l_1}}), v(a_{i_{l_1+1}},\\ldots,a_{i_l})]^{n_1 \\ldots n_l} Q_{l+1}^{O(1)}.")]]

#text("The claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" For positive integers ")#mi("{a,b}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("g^n \\in a^n [a,b]^{nm} Q_3^{O(1)}(a,b; n, m )")]]

#text("whenever")

#align(center)[#tao-fit-display[#mitex("g \\in a [a,b]^{m} Q_3^{O(1)}(a,b; 1, m ).")]]
]

#text("Next, we need the following elementary number-theoretic lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" ")#metadata(none) <tao-89e23f85fa7cf23a91b4>#text(" Let ")#mi("{M_1,\\ldots,M_l \\geq 1}")#text(", and let ")#mi("{n}")#text(" be an integer with ")#mi("{n = O(M_1 \\ldots M_l)}")#text(". Show that ")#mi("{n}")#text(" can be expressed as the sum of ")#mi("{O_l(1)}")#text(" terms of the form ")#mi("{n_1 \\ldots n_l}")#text(", where the ")#mi("{n_1,\\ldots,n_l}")#text(" are integers with ")#mi("{n_i = O(M_i)}")#text(" for each ")#mi("{i=1,\\ldots,l}")#text(". (")#emph[#text("Hint:")]#text(" Despite the superficial similarity here with non-trivial number-theoretic questions such as the ")#link("http://en.wikipedia.org/wiki/Waring's_problem")[#text("Waring problem")]#text(", this is actually a very elementary fact which can be proven by induction on ")#mi("{l}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Let ")#mi("{w}")#text(" be a formal commutator word of length ")#mi("{l \\geq 1}")#text(", and let ")#mi("{1 \\leq i_1,\\ldots,i_l \\leq r}")#text(". Let ")#mi("{n = O(N_{i_1} \\ldots N_{i_r})}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("w(a_{i_1},\\ldots,a_{i_l})^n \\in P^{O(1)} Q_{l+1}^{O(1)}.")]]

#text("Conclude that")

#align(center)[#tao-fit-display[#mitex("Q_l^C \\subset P^{O(1)} Q_{l+1}^{O(1)}")]]

#text("whenever ")#mi("{C=O(1)}")#text(", and on iteration conclude that")

#align(center)[#tao-fit-display[#mitex("Q_1^C \\subset P^{O(1)}")]]

#text("whenever ")#mi("{C = O(1)}")#text(".")
]

#text("A similar argument shows that ")#mi("{Q_1^\\epsilon \\subset P}")#text(" for a sufficiently small ")#mi("{\\epsilon>0}")#text(" depending only on ")#mi("{r,s}")#text(", assuming that ")#mi("{N_1,\\ldots,N_r}")#text(" are sufficiently large depending on ")#mi("{r,s}")#text(". Since ")#mi("{P^2 \\subset Q^2_1}")#text(", it thus suffices to show that for any ")#mi("{\\delta>0}")#text(", that ")#mi("{Q^2_1}")#text(" can be covered by ")#mi("{O_\\delta(1)}")#text(" right-translates of ")#mi("{Q^{O(\\delta)}_1}")#text(". But this then follows by iterating the following exercise:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Let ")#mi("{\\delta>0}")#text(", ")#mi("{l \\geq 1}")#text(", and ")#mi("{C = O(1)}")#text(". Show that ")#mi("{Q^C_l}")#text(" can be covered by ")#mi("{O_\\delta(1)}")#text(" right-translates of ")#mi("{Q^{O(\\delta)}_l \\cdot Q^{O(1)}_{l+1}}")#text(". (")#emph[#text("Hint:")]#text(" this is similar to Exercise ")#link(<tao-cf979e9ac9cbbc243c96>)[#text("5")]#text(". Factor an element of ")#mi("{Q^C_l}")#text(" into words ")#mi("{w(a_{i_1},\\ldots,a_{i_l})}")#text(" of length ")#mi("{l}")#text(", together with words of higher length. Gather all the words of length ")#mi("{l}")#text(" into monomials ")#mi("{w(a_{i_1},\\ldots,a_{i_l})^n}")#text(" with ")#mi("{n = O( N_{i_1} \\ldots N_{i_l})}")#text(", times a factor in ")#mi("{Q^{O(1)}_{l+1}}")#text(". Split these monomials into a monomial with exponent ")#mi("{O(\\delta N_{i_1} \\ldots N_{i_l})}")#text(", times a monomial which can take at most ")#mi("{O_\\delta(1)}")#text(" possible values. Then push the latter monomials (and the ")#mi("{Q^{O(1)}_{l+1}}")#text(" factor) to the right.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Polynomial growth)")]#text(" Suppose that ")#mi("{a_1,\\ldots,a_r \\in G}")#text(" generate a nilpotent group of step ")#mi("{s}")#text(", and suppose that ")#mi("{N_1,\\ldots,N_r \\geq 1}")#text(". Show that")

#align(center)[#tao-fit-display[#tao-math("\\left|P(a_1,\\ldots,a_r;N_1,\\ldots,N_r)\\right| \\ll_{r,s} (N_1 \\ldots N_r)^{O_{r,s}(1)}.", block: true)]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Suppose that ")#mi("{a_1,\\ldots,a_r \\in G}")#text(" generate a nilpotent group of step ")#mi("{s}")#text(", and suppose that ")#mi("{N_1,\\ldots,N_r}")#text(" are sufficiently large depending on ")#mi("{r,s}")#text(". Write ")#tao-math("{P := \\left|P(a_1,\\ldots,a_r;N_1,\\ldots,N_r)\\right|}", block: false)#text(". Let ")#mi("{a^{\\prime}_1,\\ldots,a^{\\prime}_R, N^{\\prime}_1,\\ldots,N^{\\prime}_R}")#text(" be as in ")#link(<tao-c84c6a9549851a013e86>)[#text("(10)")]#text(", arranged in non-decreasing order of the length of the associated formal commutator words.")

#list(
[#text("(i) Show that every element of ")#mi("{P}")#text(" can be represented in the form")

#align(center)[#tao-fit-display[#mitex("(a^{\\prime}_1)^{n_1} \\ldots (a^{\\prime}_R)^{n_R}")]]

#text("for some integers ")#mi("{n_i = O_{r,s}(N^{\\prime}_i)}")#text(". (We do not claim however that this representation is unique, and indeed the generators ")#mi("{a^{\\prime}_1,\\ldots,a^{\\prime}_R}")#text(" are likely to contain quite a lot of redundancy.)")],
[#text("(ii) Conversely, show that there exists an ")#mi("{\\epsilon>0}")#text(" depending only on ")#mi("{r,s}")#text(" such that any expression of the form")

#align(center)[#tao-fit-display[#mitex("(a^{\\prime}_1)^{n_1} \\ldots (a^{\\prime}_R)^{n_R}")]]

#text("with integers ")#mi("{n_i}")#text(" with ")#tao-math("{\\left|n_i\\right| \\leq \\epsilon N^{\\prime}_i}", block: false)#text(", lies in ")#mi("{P}")#text(".")]
)
]

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2012/03/17/254a-addendum-some-notes-on-nilprogressions/#comment-133781")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2012")])]

#text("“the commutator {[1+\\epsilon A, 1+\\epsilon B]} of two elements {1+\\epsilon A} and {1+\\epsilon B} close to the identity is of the form {1 + \\epsilon (AB-BA) + O(\\epsilon^2)}, thus linking the group-theoretic commutator to the Lie bracket {A,B \\mapsto AB-BA}. ”")

#text("is false. The true statement is ")#mi("[1 + \\epsilon A, 1+ \\epsilon B] = 1 + \\epsilon^{2} [A,B] + \\epsilon^{2} O(\\epsilon)")#text(".")

#text("This power 2 is the same which appears in relation with the sectional curvature, namely in a riemannian manifold we have ")#tao-math("d(exp \\, \\epsilon u, exp \\, \\epsilon v) = \\epsilon \\|u-v\\| ( 1 - \\epsilon^{2} K(u,v) \\left\\|u\\right\\| \\left\\|v\\right\\| + \\epsilon^{2} O(\\epsilon))", block: false)#text(".")

#text("Alternatively, we may introduce a ")#link("http://chorasimilarity.wordpress.com/2011/08/30/baker-campbell-hausdorff-polynomials-and-menelaus-theorem/")[#text("halfbracket")]#text(" at scale ")#mi("\\epsilon")#text(" by the formula")#linebreak()#text(" ")#mi("exp \\, (\\epsilon A) exp \\, (\\epsilon B) = exp \\, (\\epsilon (A + B + \\langle A, B\\rangle^{\\epsilon}))")#text(".")

#text("The halfbracket allows to transform the operation in the group into the operation in the tangent space at the identity of the group, with the price of a perturbation.")

#text("Then ")#mi("\\langle A, B \\rangle^{\\epsilon} = \\epsilon \\frac{1}{2}[A,B] + O(\\epsilon)")#text(".")

#text("Hope it does parse, btw is there any way to preview the reply?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2012/03/17/254a-addendum-some-notes-on-nilprogressions/#comment-134543")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2012")])]

#link("http://jaxedit.googlecode.com/svn/trunk/jaxedit/jaxedit.html")[#text("http://jaxedit.googlecode.com/svn/trunk/jaxedit/jaxedit.html")]

#text("Jaxedit is a brilliant place to preview your comments if you do not have ")#mi("Latex")#text(" installed on your machine.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/03/17/254a-addendum-some-notes-on-nilprogressions/#comment-134566")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2012")])]

#text("Hmm, nice source.")
]
]
]
