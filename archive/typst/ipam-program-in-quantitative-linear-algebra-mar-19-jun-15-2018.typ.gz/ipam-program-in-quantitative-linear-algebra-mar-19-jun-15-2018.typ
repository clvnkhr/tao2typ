// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/11/07/ipam-program-in-quantitative-linear-algebra-mar-19-jun-15-2018/
// Converted to Typst by tao2typ: "2026-10-14T10:43:27.569625+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "IPAM program in quantitative linear algebra, Mar 19-Jun 15 2018", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("IPAM program in quantitative linear algebra, Mar 19-Jun 15 2018")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 November 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/11/07/ipam-program-in-quantitative-linear-algebra-mar-19-jun-15-2018/")[#text("https://terrytao.wordpress.com/2017/11/07/ipam-program-in-quantitative-linear-algebra-mar-19-jun-15-2018/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("http://perso.ens-lyon.fr/aguionne/")[#text("Alice Guionnet")]#text(", ")#link("https://web.math.princeton.edu/~naor/")[#text("Assaf Naor")]#text(", ")#link("http://www.math.tamu.edu/~gilles.pisier/")[#text("Gilles Pisier")]#text(", ")#link("http://www.math.ucla.edu/~popa/")[#text("Sorin Popa")]#text(", ")#link("http://www.math.ucla.edu/~shlyakht/")[#text("Dimitri Shylakhtenko")]#text(", and I are organising a three month program here at the ")#link("http://www.ipam.ucla.edu/")[#text("Institute for Pure and Applied Mathematics (IPAM)")]#text(" on the topic of ")#link("https://www.ipam.ucla.edu/programs/long-programs/quantitative-linear-algebra/?tab=overview")[#text("Quantitative Linear Algebra")]#text(". The purpose of this program is to bring together mathematicians and computer scientists (both junior and senior) working in various quantitative aspects of linear operators, particularly in large finite dimension. Such aspects include, but are not restricted to discrepancy theory, spectral graph theory, random matrices, geometric group theory, ergodic theory, von Neumann algebras, as well as specific research directions such as the Kadison-Singer problem, the Connes embedding conjecture and the Grothendieck inequality. There will be ")#link("https://www.ipam.ucla.edu/programs/long-programs/quantitative-linear-algebra/?tab=activities")[#text("several workshops and tutorials during the program")]#text(" (for instance I will be giving a series of introductory lectures on random matrix theory).")

#text("While we already have ")#link("https://www.ipam.ucla.edu/programs/long-programs/quantitative-linear-algebra/?tab=participant-list")[#text("several confirmed participants")]#text(", we are still accepting applications for this program until Dec 4; details of the application process may be found ")#link("https://www.ipam.ucla.edu/programs/long-programs/quantitative-linear-algebra/?tab=application")[#text("at this page")]#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad4c3e019150b140bc6294f3e40473e219b48a2efe695fd61fffd95ce371b23c-1911117f007cf12d1cf989d9df9995a20201c986ba4c70c42d080735f7970b92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergei Ofitserov")]], [#link("https://terrytao.wordpress.com/2017/11/07/ipam-program-in-quantitative-linear-algebra-mar-19-jun-15-2018/#comment-489214")[#strong[#text("Sergei Ofitserov")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2017")])]

#text("Dear Terence Tao! Giving of application. I with attention acquaint. Programs UCLA and IPAM it is necessary me simultaneously, because I foresee similar turn of events. For accelerated adaptation me also it is necessary course of your inaugural lecture’s with calculation of translation into Russian. I greatly want to understand (to investigate) events 20-years remoteness, particularly events of passage XX-XXI century. Thanks! Sergei.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Free fractional convolution powers | What's new")]], [#link("https://terrytao.wordpress.com/2017/11/07/ipam-program-in-quantitative-linear-algebra-mar-19-jun-15-2018/#comment-587474")[#strong[#text("Free fractional convolution powers | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2020")])]

#text("[…] paper Fractional free convolution powers. For me, this project (which we started during the 2018 IPAM program on quantitative linear algebra) was motivated by a desire to understand the behavior of the minor process applied to a large […]")
]
