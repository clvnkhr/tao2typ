// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/
// Converted to Typst by tao2typ: "2026-10-14T09:32:11.161594+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Bounded gaps between primes (Polymath8) – a progress report", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Bounded gaps between primes (Polymath8) – a progress report")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 June 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/")[#text("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("For any ")#mi("{H \\geq 2}")#text(", let ")#mi("{B[H]}")#text(" denote the assertion that there are infinitely many pairs of consecutive primes ")#mi("{p_n, p_{n+1}}")#text(" whose difference ")#mi("{p_{n+1}-p_n}")#text(" is at most ")#mi("{H}")#text(", or equivalently that")

#align(center)[#tao-fit-display[#mitex("\\lim\\inf_{n \\rightarrow \\infty} p_{n+1} - p_n \\leq H;")]]

#text("thus for instance ")#mi("{B[2]}")#text(" is the notorious ")#link("http://en.wikipedia.org/wiki/Twin_prime")[#text("twin prime conjecture")]#text(". While this conjecture remains unsolved, we have the following recent breakthrough ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("result of Zhang")]#text(", building upon earlier work of Goldston-Pintz-Yildirim, Bombieri, Fouvry, Friedlander, and Iwaniec, and others:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Zhang’s theorem)")]#text(" ")#mi("{B[H]}")#text(" is true for some finite ")#mi("{H}")#text(".")
]

#text("In fact, Zhang’s paper shows that ")#mi("{B[H]}")#text(" is true with ")#mi("{H = 70,000,000}")#text(".")

#text("About a month ago, the Polymath8 project was launched with the objective of reading through Zhang’s paper, clarifying the arguments, and then making them more efficient, in order to improve the value of ")#mi("{H}")#text(". This project is still ongoing, but we have made significant progress; currently, we have confirmed that ")#mi("{B[H]}")#text(" holds for ")#mi("{H}")#text(" as low as ")#mi("{12,006}")#text(", and provisionally for ")#mi("{H}")#text(" as low as ")#mi("{6,966}")#text(" subject to certain lengthy arguments being checked. For several reasons, our methods (which are largely based on Zhang’s original argument structure, though with numerous refinements and improvements) will not be able to attain the twin prime conjecture ")#mi("{B[2]}")#text(", but there is still scope to lower the value of ")#mi("{H}")#text(" a bit further than what we have currently.")

#text("The precise arguments here are quite technical, and are discussed at length on other posts on this blog. In this post, I would like to give a “high level” summary of how Zhang’s argument works, and give some impressions of the improvements we have made so far; these would already be familiar to the active participants of the Polymath8 project, but perhaps may be of value to people who are following this project on a more casual basis.")

#text("While Zhang’s arguments (and our refinements of it) are quite lengthy, they are fortunately also very modular, that is to say they can be broken up into several independent components that can be understood and optimised more or less separately from each other (although we have on occasion needed to modify the formulation of one component in order to better suit the needs of another). At the top level, Zhang’s argument looks like this:")

#enum(start: 1, 
[#text("Statements of the form ")#mi("{B[H]}")#text(" are deduced from weakened versions of the ")#link("http://en.wikipedia.org/wiki/Prime_k-tuple")[#text("Hardy-Littlewood prime tuples conjecture")]#text(", which we have denoted ")#mi("{DHL[k_0,2]}")#text(" (the ")#mi("{DHL}")#text(" stands for “Dickson-Hardy-Littlewood”), by locating suitable narrow admissible tuples (see below). Zhang’s paper establishes for the first time an unconditional proof of ")#mi("{DHL[k_0,2]}")#text(" for some finite ")#mi("{k_0}")#text("; in his initial paper, ")#mi("{k_0}")#text(" was ")#mi("{3,500,000}")#text(", but we have lowered this value to ")#mi("{1,466}")#text(" (and provisionally to ")#mi("{902}")#text("). Any reduction in the value of ")#mi("{k_0}")#text(" leads directly to reductions in the value of ")#mi("{H}")#text("; a web site to collect the best known values of ")#mi("{H}")#text(" in terms of ")#mi("{k_0}")#text(" has recently been set up ")#link("http://math.mit.edu/~primegaps/")[#text("here")]#text(" (and is accepting submissions for anyone who finds narrower admissible tuples than are currently known).")],
[#text("Next, by adapting sieve-theoretic arguments of Goldston, Pintz, and Yildirim, the Dickson-Hardy-Littlewood type assertions ")#mi("{DHL[k_0,2]}")#text(" are deduced in turn from weakened versions of ")#link("http://en.wikipedia.org/wiki/Elliott%E2%80%93Halberstam_conjecture")[#text("the Elliott-Halberstam conjecture")]#text(" that we have denoted ")#mi("{MPZ[\\varpi,\\delta]}")#text(" (the ")#mi("{MPZ}")#text(" stands for “Motohashi-Pintz-Zhang”). More recently, we have replaced the conjecture ")#mi("{MPZ[\\varpi,\\delta]}")#text(" by a slightly stronger conjecture ")#mi("{MPZ^{\\prime}[\\varpi,\\delta]}")#text(" to significantly improve the efficiency of this step (using some recent ideas of Pintz). Roughly speaking, these statements assert that the primes are more or less evenly distributed along many arithmetic progressions, including those that have relatively large spacing. A crucial technical fact here is that in contrast to the older Elliott-Halberstam conjecture, the Motohashi-Pintz-Zhang estimates only require one to control progressions whose spacings ")#mi("{q}")#text(" have a lot of small prime factors (the original ")#mi("{MPZ[\\varpi,\\delta]}")#text(" conjecture requires the spacing ")#mi("{q}")#text(" to be smooth, but the newer variant ")#mi("{MPZ^{\\prime}[\\varpi,\\delta]}")#text(" has relaxed this to “densely divisible” as this turns out to be more efficient). The ")#mi("{\\varpi}")#text(" parameter is more important than the technical parameter ")#mi("{\\delta}")#text("; we would like ")#mi("{\\varpi}")#text(" to be as large as possible, as any increase in this parameter should lead to a reduced value of ")#mi("{k_0}")#text(". In Zhang’s original paper, ")#mi("{\\varpi}")#text(" was taken to be ")#mi("{1/1168}")#text("; we have now increased this to be almost as large as ")#mi("{1/148}")#text(" (and provisionally ")#mi("{1/108}")#text(").")],
[#text("By a certain amount of combinatorial manipulation (combined with a useful decomposition of the von Mangoldt function due Heath-Brown), estimates such as ")#mi("{MPZ[\\varpi,\\delta]}")#text(" can be deduced from three subestimates, the “Type I” estimate ")#mi("{Type_I[\\varpi,\\delta,\\sigma]}")#text(", the “Type II” estimate ")#mi("{Type_{II}[\\varpi,\\delta]}")#text(", and the “Type III” estimate ")#mi("{Type_{III}[\\varpi,\\delta,\\sigma]}")#text(", which all involve the distribution of certain Dirichlet convolutions in arithmetic progressions. Here ")#mi("{1/10 < \\sigma < 1/2}")#text(" is an adjustable parameter that demarcates the border between the Type I and Type III estimates; raising ")#mi("{\\sigma}")#text(" makes it easier to prove Type III estimates but harder to prove Type I estimates, and lowering ")#mi("{\\sigma}")#text(" of course has the opposite effect. There is a combinatorial lemma that asserts that as long as one can find some ")#mi("{\\sigma}")#text(" between ")#mi("{1/10}")#text(" and ")#mi("{1/2}")#text(" for which all three estimates ")#mi("{Type_I[\\varpi,\\delta,\\sigma]}")#text(", ")#mi("{Type_{II}[\\varpi,\\delta]}")#text(", ")#mi("{Type_{III}[\\varpi,\\delta,\\sigma]}")#text(" hold, one can prove ")#mi("{MPZ[\\varpi,\\delta]}")#text(". (The condition ")#mi("{\\sigma > 1/10}")#text(" arises from the combinatorics, and appears to be rather essential; in fact, it is currently a major obstacle to further improvement of ")#mi("{\\varpi}")#text(" and hence ")#mi("{k_0}")#text(" and ")#mi("{H}")#text(".)")],
[#text("The Type I estimates ")#mi("{Type_I[\\varpi,\\delta,\\sigma]}")#text(" are asserting good distribution properties of convolutions of the form ")#mi("{\\alpha * \\beta}")#text(", where ")#mi("{\\alpha,\\beta}")#text(" are moderately long sequences which have controlled magnitude and length but are otherwise arbitrary. Estimates that are roughly of this type first appeared in a series of papers by Bombieri, Fouvry, Friedlander, Iwaniec, and other authors, and Zhang’s arguments here broadly follow those of previous authors, but with several new twists that take advantage of the many factors of the spacing ")#mi("{q}")#text(". In particular, the ")#emph[#text("dispersion method")]#text(" of Linnik is used (which one can think of as a clever application of the Cauchy-Schwarz inequality) to ultimately reduce matters (after more Cauchy-Schwarz, as well as treatment of several error terms) to estimation of incomplete Kloosterman-type sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq N} e_d( \\frac{c}{n} ).")]]

#text("Zhang’s argument uses classical estimates on this Kloosterman sum (dating back to the work of Weil), but we have improved this using the “")#mi("{q}")#text("-van der Corput ")#mi("{A}")#text("-process” introduced by Heath-Brown and Ringrose.")],
[#text("The Type II estimates ")#mi("{Type_{II}[\\varpi,\\delta]}")#text(" are similar to the Type I estimates, but cover a small hole in the coverage of the Type I estimates which comes up when the two sequences ")#mi("{\\alpha,\\beta}")#text(" are almost equal in length. It turns out that one can modify the Type I argument to cover this case also. In practice, these estimates give less stringent conditions on ")#mi("{\\varpi,\\delta}")#text(" than the other two estimates, and so as a first approximation one can ignore the need to treat these estimates, although recently our Type I and Type III estimates have become so strong that it has become necessary to tighten the Type II estimates as well.")],
[#text("The Type III estimates ")#mi("{Type_{III}[\\varpi,\\delta,\\sigma]}")#text(" are an averaged variant of the classical problem of understanding the distribution of the ternary divisor function ")#mi("{\\tau_3(n) := \\sum_{abc=n} 1}")#text(" in arithmetic progressions. There are various ways to attack this problem, but most of them ultimately boil down (after the use of standard devices such as Cauchy-Schwarz and completion of sums) to the task of controlling certain higher-dimensional Kloosterman-type sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{t,t^{\\prime} \\in ({\\bf Z}/d{\\bf Z})^\\times} \\sum_{l \\in {\\bf Z}/d{\\bf Z}: (l,d)=(l+k,d)=1} e_d( \\frac{t}{l} - \\frac{t^{\\prime}}{l+k} + \\frac{m}{t} - \\frac{m^{\\prime}}{t^{\\prime}} ).")]]

#text("In principle, any such sum can be controlled by invoking Deligne’s proof of the ")#link("http://en.wikipedia.org/wiki/Weil_conjectures")[#text("Weil conjectures")]#text(" in arbitrary dimension (which, roughly speaking, establishes the analogue of the Riemann hypothesis for arbitrary varieties over finite fields), although in the higher dimensional setting some algebraic geometry is needed to ensure that one gets the full “square root cancellation” for these exponential sums. (For the particular sum above, the necessary details were worked out by Birch and Bombieri.) As such, this part of the argument is by far the least elementary component of the whole. Zhang’s original argument cleverly exploited some additional cancellation in the above exponential sums that goes beyond the naive square root cancellation heuristic; more recently, an alternate argument of Fouvry, Kowalski, Michel, and Nelson uses bounds on a slightly different higher-dimensional Kloosterman-type sum to obtain results that give better values of ")#mi("{\\varpi,\\delta,\\sigma}")#text(". We have also been able to improve upon these estimates by exploiting some additional averaging that was left unused by the previous arguments.")]
)

#text("As of this time of writing, our understanding of the first three stages of Zhang’s argument (getting from ")#mi("{DHL[k_0,2]}")#text(" to ")#mi("{B[H]}")#text(", getting from ")#mi("{MPZ[\\varpi,\\delta]}")#text(" or ")#mi("{MPZ^{\\prime}[\\varpi,\\delta]}")#text(" to ")#mi("{DHL[k_0,2]}")#text(", and getting to ")#mi("{MPZ[\\varpi,\\delta]}")#text(" or ")#mi("{MPZ^{\\prime}[\\varpi,\\delta]}")#text(" from Type I, Type II, and Type III estimates) are quite satisfactory, with the implications here being about as efficient as one could hope for with current methods, although one could still hope to get some small improvements in parameters by wringing out some of the last few inefficiencies. The remaining major sources of improvements to the parameters are then coming from gains in the Type I, II, and III estimates; we are currently in the process of making such improvements, but it will still take some time before they are fully optimised.")

#text("Below the fold I will discuss (mostly at an informal, non-rigorous level) the six steps above in a little more detail (full details can of course be found in the ")#link("https://terrytao.wordpress.com/tag/polymath8/")[#text("other polymath8 posts on this blog")]#text("). This post will also serve as a new research thread, as the previous threads were getting quite lengthy.")

#metadata(none) <tao-cadabbcd064661b090ef>

#heading(level: 1)[#strong[#text(" — 1. Finding narrow prime tuples — ")]]

#text("For any ")#mi("{k_0 \\geq 2}")#text(", we define an ")#emph[#text("admissible ")#mi("{k_0}")#text("-tuple")]#text(" to be a tuple ")#mi("{{\\mathcal H} = (h_1,\\ldots,h_{k_0})}")#text(" of ")#mi("{k_0}")#text(" distinct integers ")#mi("{h_1 < \\ldots < h_{k_0}}")#text(", such that ")#mi("{{\\mathcal H}}")#text(" avoids at least one residue class modulo ")#mi("{p}")#text(" for each prime ")#mi("{p}")#text(". Thus for instance ")#mi("{(0,2)}")#text(" is an admissible ")#mi("{2}")#text("-tuple, and ")#mi("{(0,2,6)}")#text(" is an admissible ")#mi("{3}")#text("-tuple, but ")#mi("{(0,2,4)}")#text(" is not admissible (it does not avoid any residue classes modulo ")#mi("{3}")#text(").")

#text("The prime tuples conjecture asserts that whenever ")#mi("{{\\mathcal H} = (h_1,\\ldots,h_{k_0})}")#text(" is an admissible ")#mi("{k_0}")#text("-tuple, then there are infinitely many translates ")#mi("{n+{\\mathcal H} = (n+h_1,\\ldots,n+h_{k_0})}")#text(" that consist entirely of primes. This conjecture is still out of reach of current methods, but we can hope to establish results of the following form for a given ")#mi("{k_0 \\geq 2}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2")]#text(" (")#mi("{DHL[k_0,2]}")#text(") If ")#mi("{{\\mathcal H}}")#text(" is an admissible ")#mi("{k_0}")#text("-tuple, then there are infinitely many translates ")#mi("{n + {\\mathcal H}}")#text(" of ")#mi("{{\\mathcal H}}")#text(" that contain at least two primes.")
]

#text("Let ")#mi("{H(k_0)}")#text(" be the minimal diameter ")#mi("{h_{k_0}-h_1}")#text(" of an admissible ")#mi("{k_0}")#text("-tuple: thus for instance ")#mi("{H(2) = 2}")#text(", ")#mi("{H(3) = 6}")#text(", and ")#mi("{H(4)=8}")#text(". It is clear that if ")#mi("{DHL[k_0,2]}")#text(" holds for some ")#mi("{k_0}")#text(", then ")#mi("{B[H]}")#text(" is true for ")#mi("{H = H(k_0)}")#text(", since we have an admissible ")#mi("{k_0}")#text("-tuple ")#mi("{{\\mathcal H}}")#text(" of diameter ")#mi("{H(k_0)}")#text(", and any translate of that tuple that contains two primes will generate a pair of consecutive primes of distance at most ")#mi("{H}")#text(" apart. So we can use statements of the form ")#mi("{DHL[k_0,2]}")#text(" to deduce estimates of the form ")#mi("{B[H]}")#text(", provided that we can find admissible ")#mi("{k_0}")#text("-tuples that are as narrow as possible, in order to obtain as good a value of ")#mi("{H}")#text(" that one can hope to get.")

#text("Perhaps the easiest way to obtain an admissible ")#mi("{k_0}")#text("-tuple of reasonably narrow width is to take “the first ")#mi("{k_0}")#text(" primes past ")#mi("{k_0}")#text("“, i.e. the tuple ")#mi("{(p_{m+1},\\ldots,p_{m+k_0})}")#text(", where ")#mi("{p_{m+1}}")#text(" is the first prime larger than ")#mi("{k_0}")#text(". It is not difficult to show that this is an admissible tuple. Zhang used this construction with ")#mi("{k_0 = 3,500,000}")#text(" to obtain ")#mi("{H[3,500,000] \\leq 70,000,000}")#text("; as observed later ")#link("http://arxiv.org/abs/1305.6369")[#text("by Trudgian")]#text(", this construction actually has diameter ")#mi("{59,874,594}")#text(", giving the bound ")#mi("{H[3,500,000] \\leq 59,874,594}")#text(".")

#text("For large ")#mi("{k_0}")#text(", this construction gives an asymptotic of the form")

#align(center)[#tao-fit-display[#mitex("H(k_0) \\leq k_0 \\log k_0 + k_0 \\log\\log k_0 + O(k_0)")]]

#text("as can be seen by a careful application of the prime number theorem.")

#text("One can do better than this in a number of ways. Firstly, it turns out that one can reduce ")#mi("{m}")#text(" a bit and still have ")#mi("{(p_{m+1},\\ldots,p_{m+k_0})}")#text(" admissible; for ")#mi("{k_0=3,500,000}")#text(", it turns out after some computation that this trick ")#link("http://sbseminar.wordpress.com/2013/05/30/i-just-cant-resist-there-are-infinitely-many-pairs-of-primes-at-most-59470640-apart/#comment-23444")[#text("lowers the diameter a little bit")]#text(" to ")#mi("{59,093,364}")#text("; asymptotically this gives")

#align(center)[#tao-fit-display[#mitex("H(k_0) \\leq k_0 \\log k_0 + k_0 \\log\\log k_0 - k_0 + o(k_0)")]]

#text("(because ")#mi("{m}")#text(" can be taken to be ")#mi("{o(k_0/\\log k_0)}")#text("). A larger improvement comes from ")#link("http://www.ams.org/mathscinet-getitem?mr=340194")[#text("the work of Hensley and Richards")]#text(", namely to shift the tuple to cover positive and negative primes around the origin, in order to exploit the slightly increased density of the primes in this interval. Specifically, if one uses a tuple of the form")

#align(center)[#tao-fit-display[#mitex("(-p_{m+\\lfloor k_0-2/2\\rfloor}, \\ldots, -p_{m+1},-1,+1,p_{m+1},\\ldots,p_{m+\\lfloor k_0-1/2 \\rfloor})")]]

#text("and optimises in ")#mi("{m}")#text(", ")#link("http://sbseminar.wordpress.com/2013/05/30/i-just-cant-resist-there-are-infinitely-many-pairs-of-primes-at-most-59470640-apart/#comment-23448")[#text("one can bound")]#text(" ")#mi("{H[3,500,000] \\leq 57,554,068}")#text(". Asymptotically, this gives the slight improvement")

#align(center)[#tao-fit-display[#mitex("H(k_0) \\leq k_0 \\log k_0 + k_0 \\log\\log k_0 - (1 + \\log 2) k_0 + o(k_0).")]]

#text("One can get a little more improvement by deleting a few primes from one end of this tuple and adding them to another, although the gains here are modest. Incidentally, Hensley and Richards used this improved asymptotic to demonstrate that the prime tuples conjecture was inconsistent with the ")#link("http://en.wikipedia.org/wiki/Second_Hardy-Littlewood_conjecture")[#text("second Hardy-Littlewood conjecture")]#text(", which is now widely believed to be false.")

#text("One can view the Hensley-Richard construction as a “sieve” similar to the sieve of Eratosthenes, formed by starting with the integers in an interval ")#mi("{[-p_{m+\\lfloor k_0-2/2\\rfloor}, \\ldots,p_{m+\\lfloor k_0-1/2 \\rfloor}]}")#text(" and striking out the residue class ")#mi("{0 \\ (p) = 0 \\text{ mod } (p)}")#text(" for all primes ")#mi("{p}")#text(" up to ")#mi("{p_m}")#text(". (In principle, this sieve could leave a few extra survivors, namely powers of primes larger than ")#mi("{p_m}")#text(", together with their negations, though in practice such powers fall outside the interval of interest.) This sieve already does most of the “work” of establishing admissibility as it handles all the small moduli, leaving only the larger moduli to be checked computationally. It was observed by Schinzel that one could do very slightly better than this by sieving out the odd integers ")#mi("{1\\ (2)}")#text(" rather than the even integers ")#mi("{0\\ (2)}")#text(", leaving behind numbers of the form ")#mi("{\\pm 2^j p}")#text(" for various primes ")#mi("{p}")#text("; this is conjecturally believed to give the bound")

#align(center)[#tao-fit-display[#mitex("H(k_0) \\leq k_0 \\log k_0 + k_0 \\log\\log k_0 - (1 + 2\\log 2) k_0 + o(k_0).")]]

#text("By similarly sieving out ")#mi("{1\\ (p)}")#text(" for other small primes ")#mi("{p}")#text(", it is in fact conjectured that")

#align(center)[#tao-fit-display[#mitex("H(k_0) \\leq k_0 \\log k_0 + k_0 \\log\\log k_0 - (1+o(1)) k_0 \\log\\log\\log k_0")]]

#text("(see ")#link("http://www.ams.org/mathscinet-getitem?mr=1726073")[#text("this paper of Gordon and Rodemich")]#text(" for a heuristic justification) although for the values of ")#mi("{k_0}")#text(" that we have worked with, these asymptotically superior constructions are actually numerically inferior to what one can get just from the first version of the Schinzel sieve. As before, some slight further gains can be obtained by shifting the interval that one is sieving over.")

#text("More recently, we have worked with tuples that initially started from partially performing the sieving from a Schinzel construction, but at some point switching to a “greedy” algorithm in which one deletes, for each prime, the residue class that removes the fewest elements from the tuple. The next technical innovation was a “merging” approach in which one took two reasonably good tuples already constructed, merged them together by taking their union, and then greedily pruning away residue classes to obtain a merged tuple that is hopefully superior to either of its two “parents”. This procedure can be iterated, and also combined with local optimisations in which the sieving interval is shifted or a small number of elements are otherwise added and deleted. This has produced many of the best constructions so far, typically about 5% narrower than what previous constructions such as the Schinzel sieve construction gave. (For small values of ")#mi("{k_0}")#text(", say ")#mi("{k_0 \\leq 4000}")#text(", the ")#link("http://www.ams.org/mathscinet-getitem?mr=1726073")[#text("older work of Engelsma")]#text(" on finding narrow tuples, which used slightly different methods, is often still the record-holder.")

#text("Very recently, a ")#link("http://math.mit.edu/~primegaps/")[#text("web page has been set up")]#text(" to record the best known tuples of cardinality up to ")#mi("{5,000}")#text(" (including the older data of Engelsma), and to accept submissions for new “record holders”. This will help with further improvements to ")#mi("{B[H]}")#text(", but the database of narrow tuples is likely to have other uses in effective prime number theory as well.")

#text("Numerical regression suggests that ")#mi("{H(k_0)}")#text(" is roughly ")#mi("{k_0 \\log k_0 + k_0}")#text(" for small or medium values of ")#mi("{k_0}")#text(". There is no theoretical justification for this bound; the best lower bounds we have on ")#mi("{H(k_0)}")#text(" asymptotically come from ")#link("http://en.wikipedia.org/wiki/Brun–Titchmarsh_theorem")[#text("the Brun-Titchmarsh theorem")]#text(" and its refinements (and in particular various versions of the ")#link("http://en.wikipedia.org/wiki/Large_sieve")[#text("large sieve")]#text("), and take the form")

#align(center)[#tao-fit-display[#mitex("H(k_0) \\geq (\\frac{1}{2} + o(1)) k_0 \\log k_0.")]]

#text("It looks very difficult to improve upon this loss of ")#mi("{1/2}")#text(" (this problem may possibly be related to the ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("parity problem")]#text(" in sieve theory, although the precise connection is unclear).")

#text("Further information on this part of the Polymath8 project may be found ")#link("http://michaelnielsen.org/polymath1/index.php?title=Finding_narrow_admissible_tuples")[#text("at this page")]#text(".")

#heading(level: 1)[#strong[#text(" — 2. Sieving and Dickson-Hardy-Littlewood type results — ")]]

#text("Now we informally describe how to obtain results of the form ")#mi("{DHL[k_0,2]}")#text(". Zhang’s approach (and thus ours) follows the basic strategy given by the ")#link("http://www.ams.org/mathscinet-getitem?mr=2552109")[#text("breakthrough paper of Goldston, Pintz, and Yildirim")]#text(" establishing small (but not bounded) gaps between primes.")

#text("Let ")#mi("{{\\mathcal H} = (h_1,\\ldots,h_{k_0})}")#text(" be an admissible ")#mi("{k_0}")#text("-tuple. The basic difficulty in trying to locate translates ")#mi("{n + {\\mathcal H} = (n+h_1,\\ldots,n+h_{k_0})}")#text(" that contain two or more primes is that the primes get sparser and sparser when one goes out to infinity, so if one chooses ")#mi("{n}")#text(" to be an integer chosen at random from (say) the interval ")#mi("{[x,2x]}")#text(", one would expect most such tuples to in fact contain ")#emph[#text("no")]#text(" primes.")

#text("The trick of Goldston, Pintz, and Yildirim is not to pick ")#mi("{n}")#text(" ")#emph[#text("uniformly")]#text(" from ")#mi("{[x,2x]}")#text(", but instead to pick ")#mi("{n}")#text(" in a ")#emph[#text("weighted")]#text(" fashion that significantly increases the probability of each member ")#mi("{n+h_i}")#text(" of the translated tuple being prime. To oversimplify, suppose we could construct a moderately large subset ")#mi("{A}")#text(" of ")#mi("{[x,2x]}")#text(" with the property that for each ")#mi("{1 \\leq i \\leq k_0}")#text(", we have that ")#mi("{n+h_i}")#text(" is prime for more than ")#mi("{1/k_0}")#text(" of the elements ")#mi("{n}")#text(" of ")#mi("{A}")#text(". Then just from the pigeonhole principle, one could conclude the existence of at least one ")#mi("{n \\in A}")#text(" such that ")#mi("{n+h_i}")#text(" is prime for at least two choices of ")#mi("{i}")#text(", which give ")#mi("{DHL[k_0,2]}")#text(".")

#text("Of course, one has to choose a set ")#mi("{A}")#text(" for which one can prove the desired claim, that each ")#mi("{n+h_i}")#text(" is prime for more than ")#mi("{1/k_0}")#text(" of the elements ")#mi("{n}")#text(" of ")#mi("{A}")#text(". Intuitively, the strategy of Goldston, Pintz, and Yildirim is to let ")#mi("{A}")#text(" consist of those ")#mi("{n \\in [x,2x]}")#text(" for which the quantity ")#mi("{P(n) := \\prod_{i=1}^{k_0} (n+h_i)}")#text(" is ")#emph[#text("almost prime")]#text(" – that it only has a relatively small number of prime factors (not much more than ")#mi("{k_0}")#text(").")

#text("Actually, it turns out that it is best not to try to use a set ")#mi("{A}")#text(" for the above strategy, but rather a non-negative weight function ")#mi("{\\nu}")#text(" on ")#mi("{[x,2x]}")#text(" which is concentrated on those ")#mi("{n}")#text(" for which ")#mi("{P(n)}")#text(" is almost prime. One then seeks to maximise the ratio ")#metadata(none) <tao-2f04a79ef13b95c1f6a2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{ \\sum_n \\nu(n) 1_{n+h_i \\text{ prime}} }{\\sum_n \\nu(n) }")]]

#text("for each ")#mi("{i}")#text("; in particular, if one can get these ratios all above ")#mi("{1/k_0}")#text(", one has proven ")#mi("{DHL[k_0,2]}")#text(".")

#text("One then needs to construct a non-negative weight ")#mi("{\\nu}")#text(" for which the ratio ")#link(<tao-2f04a79ef13b95c1f6a2>)[#text("(1)")]#text(" is (a) computable, and (b) as large as possible. For this one uses a version of the ")#emph[#text("Selberg sieve")]#text(", choosing ")#mi("{\\nu}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("\\nu(n) := 1_{[x,2x]}(n) (\\sum_{d|P(n)} \\lambda_d)^2")]]

#text("for some weights ")#mi("{\\lambda_d}")#text(" to be optimised later. In order to be able to compute both the numerator and denominator of ")#link(<tao-2f04a79ef13b95c1f6a2>)[#text("(1)")]#text(", one needs to limit the sieve weights ")#mi("{\\lambda_d}")#text(" to be supported on the range ")#mi("{d \\leq R}")#text(" for some ")#emph[#text("sieve level")]#text(" ")#mi("{R}")#text(", which one would like to be as large as possible to give maximum flexibility to the sieve. The denominator of ")#link(<tao-2f04a79ef13b95c1f6a2>)[#text("(1)")]#text(" is relatively easy to compute (as long as ")#mi("{R}")#text(" does not exceed ")#mi("{x^{1/2}}")#text(", but the numerator is more difficult. Expanding out the formula for ")#mi("{\\nu}")#text(", the numerator becomes")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2} \\lambda_{d_1} \\lambda_{d_2} \\sum_{n \\in [x,2x]: [d_1,d_2] | P(n)} 1_{n+h_i \\text{ prime}}.")]]

#text("As is standard in analytic number theory, it is slightly more convenient to replace this sum by the closely related sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2} \\lambda_{d_1} \\lambda_{d_2} \\sum_{n \\in [x,2x]: [d_1,d_2] | P(n)} \\Lambda(n+h_i)")]]

#text("where ")#mi("{\\Lambda}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(", which serves as a useful proxy for the prime numbers.")

#text("The ")#mi("{n}")#text(" summation is restricted to a fairly small number of residue classes ")#mi("{a_q\\ (q)}")#text(" modulo ")#mi("{q := [d_1,d_2]}")#text(", which is a modulus of size at most ")#mi("{R^2}")#text(". To control the numerator of ")#link(<tao-2f04a79ef13b95c1f6a2>)[#text("(1)")]#text(", one thus needs some sort of ")#emph[#text("distribution result")]#text(" for the primes (or the von Mangoldt function) in arithmetic progressions of modulus ")#mi("{q}")#text(" at least as large as ")#mi("{R^2}")#text(". If one had to get good distribution for ")#emph[#text("all")]#text(" moduli ")#mi("{q}")#text(" up to this level, this would be a task comparable to the generalised Riemann hypothesis, and thus hopeless; but fortunately we only need such distribution results ")#emph[#text("on average")]#text(" for such moduli ")#mi("{q}")#text(". For this, standard tools such as the ")#link("http://en.wikipedia.org/wiki/Bombieri-Vinogradov_theorem")[#text("Bomberi-Vinogradov theorem")]#text(" are available, at least for ")#mi("{R^2}")#text(" up to about ")#mi("{x^{1/2}}")#text(" or so. This was already strong enough for Goldston, Pintz, and Yildirim to obtain reasonably narrow prime gaps (in which ")#mi("{p_{n+1}-p_n = o(\\log p_n)}")#text(", for instance), but to get bounded prime gaps it turns out to be necessary to obtain distribution results up to a slightly higher exponent ")#mi("{x^{1/2+2\\varpi}}")#text(" for some ")#mi("{\\varpi > 0}")#text(". The standard distribution conjecture in this direction is the ")#link("http://en.wikipedia.org/wiki/Elliott%E2%80%93Halberstam_conjecture")[#text("Elliott-Halberstam conjecture")]#text(" ")#metadata(none) <tao-0c044a36c373b6a8955c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\sum_{q \\leq x^{1/2+2\\varpi}} \\left| \\sum_{n = a_q\\ (q): n \\in [x,2x]} \\Lambda(n) - \\frac{1}{\\phi(q)} \\sum_{n \\in [x,2x]} \\Lambda(n) \\right| \\ll x \\log^{-A} x", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(", where ")#mi("{a_q\\ (q)}")#text(" is a primitive residue class modulo ")#mi("{q}")#text(" for each ")#mi("{q}")#text(", and ")#mi("{\\phi}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Euler%27s_totient_function")[#text("Euler totient function")]#text(". This estimate is conjectured to hold for ")#mi("{\\varpi}")#text(" arbitrarily close to ")#mi("{1/4}")#text(", and Goldston, Pintz and Yildirim showed that the assertion ")#link(<tao-0c044a36c373b6a8955c>)[#text("(2)")]#text(" for even a small ")#mi("{\\varpi>0}")#text(" was sufficient to imply ")#mi("{DHL[k_0,2]}")#text(" for some ")#mi("{k_0}")#text(" (the condition they obtained was asymptotically of the form ")#mi("{k_0 \\sim \\varpi^{-2}}")#text(", and if one could get ")#mi("{\\varpi}")#text(" sufficiently close to ")#mi("{1/4}")#text(", one could in fact obtain ")#mi("{DHL[6,2]}")#text("). Unfortunately, the Elliott-Halberstam conjecture ")#link(<tao-0c044a36c373b6a8955c>)[#text("(2)")]#text(" remains open for any choice of ")#mi("{\\varpi>0}")#text(".")

#text("Zhang made a number of observations to get around this obstacle. First, he observed that the residue classes ")#mi("{a_q\\ (q)}")#text(" needed for the application to ")#mi("{DHL[k_0,2]}")#text(" were not completely arbitrary, but were linked to each other, basically obeying a Chinese remainder theorem ")#metadata(none) <tao-793ff64f83b41b5d467a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("a_{qr}\\ (qr) = (a_q\\ (q)) \\cap (a_r\\ (r))")]]

#text("for any coprime ")#mi("{q,r}")#text(". (These congruences ")#mi("{a_q\\ (q)}")#text(" basically come from the roots of the polynomial ")#mi("{P}")#text(" modulo ")#mi("{q}")#text(".) Secondly, he observed that by suitably truncating the Selberg sieve, one did not need to establish ")#link(<tao-0c044a36c373b6a8955c>)[#text("(2)")]#text(" for ")#emph[#text("all")]#text(" moduli ")#mi("{q}")#text(", but only those moduli which were squarefree and ")#emph[#text("smooth")]#text(", in the sense that all prime divisors of ")#mi("{q}")#text(" were at most ")#mi("{x^\\delta}")#text(" for some small ")#mi("{\\delta>0}")#text(". (This observation had also been made previously ")#link("http://www.ams.org/mathscinet-getitem?mr=2414788")[#text("by Motohashi and Pintz")]#text(".) One had the freedom to select ")#mi("{\\delta}")#text(" as one wished, although if one set ")#mi("{\\delta}")#text(" to be too small, the value of ")#mi("{k_0}")#text(" one obtained would increase.")

#text("One can then formulate a weakened version of ")#link(<tao-0c044a36c373b6a8955c>)[#text("(2)")]#text(" which we have called ")#mi("{MPZ[\\varpi,\\delta]}")#text(" (the MPZ standing for Motohashi, Pintz, and Zhang), in which the ")#mi("{a_q\\ (q)}")#text(" are constrained to obey the Chinese remainder theorem and the ")#mi("{q}")#text(" are constrained to be square-free and smooth. Zhang was able to establish ")#mi("{MPZ[\\varpi,\\delta]}")#text(" for ")#mi("{\\varpi = \\delta = 1/1,168}")#text(", which he could then use to establish ")#mi("{DHL[k_0,2]}")#text(" for ")#mi("{k_0 = 3,500,000}")#text(" (note that ")#mi("{k_0}")#text(" is roughly of the order of ")#mi("{\\varpi^{-2}}")#text(" as mentioned previously).")

#text("We have improved Zhang’s argument in a number of ways. Firstly, we have made the sieving argument that deduces ")#mi("{DHL[k_0,2]}")#text(" from results of the form ")#link(<tao-0c044a36c373b6a8955c>)[#text("(2)")]#text(" more efficient by optimising a certain cutoff function involved in the construction of the Selberg sieve; the optimal cutoff turns out to be given in terms of a certain Bessel function, and improves the relationship ")#mi("{k_0 \\sim \\varpi^{-2}}")#text(" to ")#mi("{k_0 \\sim \\varpi^{-3/2}}")#text("; see ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("this post")]#text(" for details. Also, a modification of the truncated Selberg sieve due to Pintz allows one to take ")#mi("{\\delta}")#text(" to be extremely small with almost no impact on ")#mi("{k_0}")#text(" (but at a certain technical cost, namely that the property of being smooth has to be weakened to another property which we have called “dense divisibility”, replacing the conjecture ")#mi("{MPZ[\\varpi,\\delta]}")#text(" by a variant that we have called ")#mi("{MPZ^{\\prime}[\\varpi,\\delta]}")#text("); see ")#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/")[#text("this post")]#text(" for details. Finally, by optimising the remaining steps in Zhang’s argument (see below), we have managed to increase ")#mi("{\\varpi}")#text(" significantly, with the currently largest value of ")#mi("{\\varpi}")#text(" that we can use being close to ")#mi("{1/148}")#text(" (and provisionally to ")#mi("{1/108}")#text("). The combination of these improvements has allowed us to take ")#mi("{k_0}")#text(" as low as ")#mi("{1,466}")#text(" (and provisionally to ")#mi("{962}")#text(").")

#text("At this stage we believe our arguments converting ")#mi("{MPZ[\\varpi,\\delta]}")#text(" (or variants thereof) to ")#mi("{DHL[k_0,2]}")#text(" is about as efficient as can be hoped for given the methods we have, and that the most significant further improvements will be coming from raising ")#mi("{\\varpi}")#text(" beyond the currently available range.")

#heading(level: 1)[#strong[#text(" — 3. The Heath-Brown identity and combinatorics — ")]]

#text("Now we discuss how to establish estimates such as ")#link(<tao-0c044a36c373b6a8955c>)[#text("(2)")]#text(" in the case of smooth moduli, and in the case of congruences obeying a Chinese remainder theorem. Prior to Zhang’s paper, there were a number of results of this type established in a series of papers by (various combinations of) Bombieri, Fouvry, Friedlander, and Iwaniec, as well as some followup work by later authors, although the prior results were not directly applicable for the current problem (either because the function ")#mi("{\\Lambda}")#text(" was replaced by a simpler arithmetic function, or the absolute values in ")#link(<tao-0c044a36c373b6a8955c>)[#text("(2)")]#text(" were replaced instead with a “well-factorable” weight, or the congruence classes ")#mi("{a_q\\ (q)}")#text(" involved were more specialised, e.g. of the form ")#mi("{a\\ (q)}")#text(" where ")#mi("{a}")#text(" was bounded and independent of ")#mi("{q}")#text("). However, Zhang was able to adapt and improve the analysis in the previous literature in a number of ways, to the point where he could in fact obtain an estimate ")#mi("{MPZ[\\varpi,\\delta]}")#text(" of the required strength.")

#text("We won’t describe the entire proof here, but give some of the important ideas in these arguments. The first observation is that one can decompose the von Mangoldt function ")#mi("{\\Lambda}")#text(" as a combination of simpler functions, such as the ")#mi("{k^{th}}")#text(" order divisor functions")

#align(center)[#tao-fit-display[#mitex("\\tau_k(n) := \\sum_{n_1,\\ldots,n_k \\geq 1: n_1 \\ldots n_k = n} 1,")]]

#text("the modified ")#mi("{k^{th}}")#text(" order divisor functions")

#align(center)[#tao-fit-display[#mitex("\\tau^{\\prime}_k(n) := \\sum_{n_1,\\ldots,n_k > 1: n_1 \\ldots n_k = n} 1,")]]

#text("or more generally certain combinations")

#align(center)[#tao-fit-display[#mitex("\\psi_1 \\ast \\ldots \\ast \\psi_k")]]

#text("of “nice” arithmetic functions ")#mi("{\\psi_1,\\ldots,\\psi_k}")#text(" (we will be vague about what “nice” means here), where ")#mi("{f \\ast g(n) := \\sum_{d|n} f(d) g(\\frac{n}{d})}")#text(" is the usual ")#link("http://en.wikipedia.org/wiki/Dirichlet_convolution")[#text("Dirichlet convolution")]#text(". The point is that functions with this convolution structure are easier to sum and estimate. For instance, the basic estimate")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) = x + o(x)")]]

#text("is of course the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(", which is already non-trivial, and improving the error term ")#mi("{o(x)}")#text(" here to ")#mi("{O(x^{1-\\epsilon})}")#text(" for some fixed ")#mi("{\\epsilon>0}")#text(" is a major open problem (and would be a huge breakthrough towards the Riemann hypothesis). In contrast, the divisor function")

#align(center)[#tao-fit-display[#mitex("\\tau(n) = \\tau_2(n) = \\sum_{n_1,n_2 \\geq 1: n_1 n_2 = n} 1")]]

#text("is much easier to sum, and one can easily obtain the estimate")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau(n) = x \\log x + (2\\gamma-1) x + O( x^{1/2} )")]]

#text("by the elementary ")#link("http://planetmath.org/dirichlethyperbolamethod")[#text("Dirichlet hyperbola method")]#text(", which ultimately relies on the Dirichlet convolution structure ")#mi("{\\tau = 1 \\ast 1}")#text(" of ")#mi("{\\tau}")#text(". Similarly for the higher order divisor functions ")#mi("{\\tau_k}")#text(" and their variants ")#mi("{\\tau^{\\prime}_k}")#text(", although the error terms become harder to estimate well when ")#mi("{k}")#text(" increases.")

#text("Why would we expect ")#mi("{\\Lambda}")#text(" to be expressible in terms of functions such as ")#mi("{\\tau_k}")#text(" or ")#mi("{\\tau^{\\prime}_k}")#text("? To illustrate this sort of decomposition, let us make the major cheat that all numbers ")#mi("{n}")#text(" are square-free and have at most (say) four prime factors. (This is clearly quite a cheat; but note that a positive fraction of integers are square-free, and if we restrict attention to ")#emph[#text("large")]#text(" prime factors, say factors larger than ")#mi("{n^{1/5}}")#text(", then we do indeed have at most four such prime factors, so the cheat actually is not so terrible in some ways.) Then the quantity ")#mi("{\\Lambda(n)}")#text(" is equal to ")#mi("{\\log n}")#text(" when ")#mi("{n}")#text(" has one prime factor and zero when ")#mi("{n}")#text(" has two, three, or four prime factors. Meanwhile, ")#mi("{\\tau^{\\prime}_2(n)}")#text(" is equal to ")#mi("{0, 2, 6, 14}")#text(" when ")#mi("{n}")#text(" has one, two, three, or four prime factors respectively. Similarly ")#mi("{\\tau^{\\prime}_3(n)}")#text(" is equal to ")#mi("{0, 0, 6, 36}")#text(" and ")#mi("{\\tau^{\\prime}_4(n)}")#text(" is equal to ")#mi("{0,0,0,24}")#text(". Thus we see in all cases that")

#align(center)[#tao-fit-display[#mitex("\\Lambda(n) = \\log(n) ( 1 - \\frac{1}{2} \\tau^{\\prime}_2(n) + \\frac{1}{3} \\tau^{\\prime}_3(n) - \\frac{1}{4} \\tau^{\\prime}_4(n) ).")]]

#text("Note that while a little computation is required to verify this identity, it is immediate from linear algebra that ")#emph[#text("some")]#text(" identity of this type must exist, at least for square-free numbers with a bounded number of factors.")

#text("More generally, we have ")#emph[#text("Linnik’s identity")]#text(" ")#metadata(none) <tao-aac28e6b9f98104b92f5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\Lambda(n) = \\log n \\sum_{k=1}^\\infty \\frac{(-1)^{k-1}}{k} \\tau^{\\prime}_k(n),")]]

#text("which is valid for all natural numbers ")#mi("{n}")#text("; this identity can be proven by starting with the formal identity")

#align(center)[#tao-fit-display[#mitex("\\log \\zeta(s) = \\sum_{k=1}^\\infty \\frac{(-1)^{k-1}}{k} (\\zeta(s) - 1)^k")]]

#text("for the Riemann zeta function ")#mi("{\\zeta(s) := \\sum_{n=1}^\\infty \\frac{1}{n^s}}")#text(", differentiating this identity, then comparing Dirichlet series coefficients. (It is also a fun exercise to find a purely combinatorial proof of this identity.)")

#text("Morally speaking, Linnik’s identity reduces the task of proving ")#link(<tao-0c044a36c373b6a8955c>)[#text("(2)")]#text(" (or variants thereof) to the task of proving ")#metadata(none) <tao-767cb8b4d2372f6c318c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\sum_{q \\leq x^{1/2+2\\varpi}} \\left| \\sum_{n = a_q\\ (q): n \\in [x,2x]} \\tau^{\\prime}_k(n) - \\frac{1}{\\phi(q)} \\sum_{n \\in [x,2x]} \\tau^{\\prime}_k(n) \\right| \\ll x \\log^{-A} x", block: true)]]

#text("for ")#mi("{k=1,2,3,\\ldots}")#text(". However, this implication is not quite rigorous, because the ")#mi("{k}")#text(" parameter on the right-hand side is unbounded. There is however a clever truncation of Linnik’s identity ")#link("http://www.ams.org/mathscinet-getitem?mr=0678676")[#text("due to Heath-Brown")]#text(", which only has finitely many terms, each one of which resembles a divisor function ")#mi("{\\tau_k}")#text(", albeit one which is averaged by an additional Dirichlet convolution. The precise identity is a little complicated (although not difficult to prove); see ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("this post")]#text(" for details. Using this identity, we can indeed reduce ")#link(<tao-0c044a36c373b6a8955c>)[#text("(2)")]#text(" to slightly more complicated versions of the identities ")#link(<tao-767cb8b4d2372f6c318c>)[#text("(5)")]#text(". By decomposing the versions of ")#link(<tao-767cb8b4d2372f6c318c>)[#text("(5)")]#text(" obtained in this fashion into dyadic pieces (actually, one uses a decomposition that is slightly finer than the dyadic decomposition, but never mind this technical detail), it turns out that one can organise the resulting estimates to be proven into three classes, which Zhang calls “Type I estimates”, “Type II estimates”, and “Type III estimates”. The precise formulation of such estimates depends on the two parameters ")#mi("{\\varpi,\\delta}")#text(" alluded to earlier, as well as an additional parameter ")#mi("{1/10 \\leq \\sigma \\leq 1/2}")#text(" demarcating the boundary between the Type I and Type III estimates. (The lower bound ")#mi("{\\sigma \\geq 1/10}")#text(" is needed to effect the combinatorial partition into Type I, Type II, Type III sums; it would be nice to remove this bound, but this seems to necessitate the introduction of further types of estimates (“Type IV” and “Type V”) which we have so far been unable to deal with effectively.) A precise definition of these estimates may be found ")#link("http://michaelnielsen.org/polymath1/index.php?title=Distribution_of_primes_in_smooth_moduli")[#text("at this page")]#text(", but let us for now give an oversimplified caricature of what these estimates look like. A model case of a Type I estimate takes the form ")#metadata(none) <tao-b5e509d769c77bd1fecf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\sum_{q \\leq x^{1/2+2\\varpi}} \\left| \\sum_{n = a_q\\ (q)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(q)} \\sum_n \\alpha\\ast \\beta(n) \\right| \\ll x \\log^{-A} x", block: true)]]

#text("where ")#mi("{\\alpha,\\beta: {\\bf N} \\rightarrow {\\bf C}}")#text(" are two sequences localised to scales ")#mi("{\\{ m: m \\sim M\\}}")#text(" and ")#mi("{\\{ n: n \\sim N\\}}")#text(" respectively, where one should think of ")#mi("{M}")#text(" and ")#mi("{N}")#text(" as being like ")#mi("{x^{1/2+\\sigma}}")#text(" and ")#mi("{x^{1/2-\\sigma}}")#text(" respectively; the functions ")#mi("{\\alpha,\\beta}")#text(" also obey certain bounds similar to those enjoyed by the divisor functions ")#mi("{\\tau_k}")#text(" (e.g. their average value should be ")#mi("{O(\\log^{O(1)} x)}")#text(") which we do not give in detail here. The modulus ")#mi("{q}")#text(" should be understood to be squarefree and smooth as in the statement of ")#mi("{MPZ[\\varpi,\\delta]}")#text(" (or if one is trying to prove ")#mi("{MPZ^{\\prime}[\\varpi,\\delta]}")#text(" instead, “smooth” needs to be replaced by “densely divisible”). The Type II sums are similar, except that one should now think of ")#mi("{M}")#text(" and ")#mi("{N}")#text(" as both being like ")#mi("{x^{1/2}}")#text(". A model case of a Type III estimate takes the form ")#metadata(none) <tao-6d98cf9990217749def8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\sum_{q \\leq x^{\\alpha}} \\left| \\sum_{n = a_q\\ (q): n \\in [x,2x]} \\tau_3(n) - \\frac{1}{\\phi(q)} \\sum_{n \\in [x,2x]} \\tau_3(n) \\right| \\ll x \\log^{-A} x", block: true)]]

#text("where ")#mi("{\\alpha = \\frac{1/2 + 2 \\varpi}{\\frac{3}{2}(\\frac{1}{2}-\\sigma)}}")#text(", and again ")#mi("{q}")#text(" should be understood to be square-free and smooth. (This is an oversimplification; the true Type III estimate involves a smoothly truncated, averaged version of ")#mi("{\\tau_3}")#text(", and it is to compensate for this oversimplification that the upper bound for ")#mi("{q}")#text(" has changed.) The Type I estimates are harder to prove when ")#mi("{\\sigma}")#text(" gets larger, while the Type III estimates become easier. It is thus necessary to work out what estimates one can prove on both the Type I and Type III sides before one can optimise in ")#mi("{\\sigma}")#text(". The Type II estimates are less important (and in practice, in all the regimes in which we can prove Type I and Type III estimates so far, we have also been able to prove Type II estimates), but still need to be dealt of course. Thus far we have not been able to improve upon this portion of Zhang’s arguments much; we rely on the same Heath-Brown identity and combinatorial decomposition that Zhang does, as they seem to be more or less optimally efficient for decompositions of this type, at least for the appliction at hand. The task of proving ")#mi("{MPZ[\\varpi,\\delta]}")#text(" (or ")#mi("{MPZ^{\\prime}[\\varpi,\\delta]}")#text(") and hence ")#mi("{DHL[k_0,2]}")#text(" and ")#mi("{B[H]}")#text(" for various choices of parameters ")#mi("{\\varpi,\\delta,k_0,H}")#text(" is thus reduced to that of verifying Type I, Type II, and Type III estimates.")

#heading(level: 1)[#strong[#text(" — 4. Type I estimates — ")]]

#text("Now we give a very informal sketch of Zhang’s argument for establishing Type I estimates (details may be found at ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("these")]#text(" ")#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/")[#text("two posts")]#text("). It is based on previous arguments of Bombieri, Friedlander, and Iwaniec, relying on various analytic manipulations such as the use of the Cauchy-Schwarz inequality (and in particular on the ")#emph[#text("dispersion method")]#text(" of Linnik that is based on this inequality) and Fourier identities (such as the Pólya-Vinogradov method of completion of sums), in order to eliminate the poorly understood sequences ")#mi("{\\alpha,\\beta}")#text(", until one is only left with the task of estimating a certain incomplete Kloosterman-type sum, to which one uses standard tools from analytic number theory (such as the Weil bound for completed Kloosterman sums). We have continued to follow the same general strategy, but have found some improvements based on better bounds for incomplete Kloosterman sums.")

#text("We now give a little more detail. We will ignore the role of the technical parameter ")#mi("{\\delta}")#text(", and assume simply that all moduli are as smooth as needed for the argument. We change notation a little bit, replacing ")#mi("{n}")#text(" and ")#mi("{q}")#text(" by ")#mi("{\\tilde n}")#text(" and ")#mi("{\\tilde q}")#text(", and consider a dyadic component of ")#link(<tao-b5e509d769c77bd1fecf>)[#text("(8)")]#text(", namely")



#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\sum_{\\tilde q \\sim x^{1/2+2\\varpi}} \\left| \\sum_{\\tilde n = a_{\\tilde q}\\ (\\tilde q)} \\alpha \\ast \\beta(\\tilde n) - \\frac{1}{\\phi(\\tilde q)} \\sum_{\\tilde n} \\alpha\\ast \\beta(\\tilde n) \\right| \\ll x \\log^{-A} x", block: true)]]

#text("One now takes advantage of the square-free smooth nature of ")#mi("{\\tilde q}")#text(" to factor ")#mi("{\\tilde q = qr}")#text(", where ")#mi("{q,r}")#text(" are coprime, and ")#mi("{r}")#text(" is a little bit smaller than ")#mi("{N = x^{1/2-\\sigma}}")#text(", so that ")#mi("{q}")#text(" is a little bit larger than ")#mi("{x^{1/2+2\\varpi}/N = x^{\\sigma+2\\varpi}}")#text("; the reason for this choice of factorisation is that it will turn out that we want ")#mi("{r}")#text(" to be as large as possible while still staying a bit less than ")#mi("{N}")#text(". There is also a technical step in which we shift all the tiny prime factors of ")#mi("{qr}")#text(" to ")#mi("{r}")#text(" and not to ")#mi("{q}")#text(" (where “tiny” means something like “less than ")#mi("{\\exp(\\log^{1/3} x)}")#text("“); this is needed to ensure that most pairs of ")#mi("{q}")#text("‘s that we encounter become coprime at a crucial juncture later in the argument. See ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this post")]#text(" for more details of this step. The congruence ")#mi("{\\tilde n = a_{\\tilde q}\\ (\\tilde q)}")#text(" similarly factors into ")#mi("{\\tilde n = a_q\\ (q)}")#text(" and ")#mi("{\\tilde n = a_r\\ (r)}")#text(" by ")#link(<tao-793ff64f83b41b5d467a>)[#text("(3)")]#text(", so we now have to prove something like")

#align(center)[#tao-fit-display[#mitex("\\sum_{r \\sim R} \\sum_{q \\sim Q: (q,r)=1} | \\sum_{\\tilde n = a_{q}\\ (q); \\tilde n = a_r\\ (r); \\tilde n \\in [x,2x]} \\alpha \\ast \\beta(\\tilde n)")]]

#align(center)[#tao-fit-display[#mitex("- \\frac{1}{\\phi(q) \\phi(r)} \\sum_{\\tilde n \\in [x,2x]} \\alpha\\ast \\beta(\\tilde n) | \\ll x \\log^{-A} x")]]

#text("where ")#mi("{R = x^{1/2-\\sigma-\\epsilon}}")#text(" for some small ")#mi("{\\epsilon>0}")#text(" and ")#mi("{Q = x^{\\sigma+2\\varpi+\\epsilon}}")#text(".")

#text("Roughly speaking, this estimate is asserting that we can estimate a quantity such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{r \\sim R} \\sum_{q \\sim Q: (q,r)=1} c_{q,r} \\sum_{\\tilde n = a_{q}\\ (q); \\tilde n = a_r\\ (r); \\tilde n \\in [x,2x]} \\alpha \\ast \\beta(\\tilde n)")]]

#text("to accuracy ")#mi("{O( x \\log^{-A} x )}")#text(" whenever ")#mi("{c_{q,r}}")#text(" are arbitrary bounded coefficients (where we will be a bit vague on what it means to estimate something to a given accuracy). Splitting ")#mi("{\\alpha \\ast \\beta(\\tilde n)}")#text(" as ")#mi("{\\sum_{m,n: mn = \\tilde n} \\alpha(m) \\beta(n)}")#text(" and ignoring the constraint ")#mi("{\\tilde n \\in [x,2x]}")#text(", we may rearrange this expression as")

#align(center)[#tao-fit-display[#mitex("\\sum_m \\alpha(m) \\sum_{r \\sim R} \\sum_{q \\sim Q: (q,r)=1} c_{q,r} \\sum_{n: mn = a_{q}\\ (q); mn = a_r\\ (r)} \\beta(n).")]]

#text("We are unable to take much advantage of the ")#mi("{r}")#text(" averaging, and will thus seek to estimate")

#align(center)[#tao-fit-display[#mitex("\\sum_m \\alpha(m) \\sum_{q \\sim Q: (q,r)=1} c_{q,r} \\sum_{n: mn = a_{q}\\ (q); mn = a_r\\ (r)} \\beta(n)")]]

#text("to accuracy ")#mi("{O( x R^{-1} \\log^{-A} x)}")#text(" for a fixed ")#mi("{r \\sim R}")#text(".")

#text("Now we start eliminating some of the poorly controlled expressions ")#mi("{\\alpha, c_{q,r}, \\beta}")#text(". Applying a Cauchy-Schwarz, it (morally) suffices to estimate")

#align(center)[#tao-fit-display[#tao-math("\\sum_{m \\sim M} \\left| \\sum_{q \\sim Q: (q,r)=1} c_{q,r} \\sum_{n: mn = a_{q}\\ (q); mn = a_r\\ (r)} \\beta(n)\\right|^2", block: true)]]

#text("to accuracy ")#mi("{O( x^2 R^{-2} M^{-1} \\log^{-A} x )}")#text(", i.e. a little bit better than ")#mi("{O( x^{1/2 + \\sigma} )}")#text(". Note that because ")#mi("{r}")#text(" is a little bit less than ")#mi("{N}")#text(", we have a non-trivial number of ")#mi("{n \\sim N}")#text(" obeying the congruence condition ")#mi("{mn = a_r\\ (r)}")#text(" for any given ")#mi("{m}")#text(". This prevents the summation inside the absolute values from being so trivial that Cauchy-Schwarz could not gain anything.")

#text("The above expression can be rearranged as")

#align(center)[#tao-fit-display[#mitex("\\sum_{q_1,q_2 \\sim Q: (q_1q_2,r)=1} c_{q_1,r} \\overline{c_{q_2,r}} \\sum_{n,n^{\\prime}} \\beta(n) \\overline{\\beta(n^{\\prime})}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\sim M: mn=a_{q_1}\\ (q_1); mn^{\\prime} = a_{q_2}\\ (q_2); mn=mn^{\\prime} = a_r\\ (r)} 1.")]]

#text("The constraint ")#mi("{mn=mn^{\\prime} = a_r\\ (r)}")#text(" forces ")#mi("{n=n^{\\prime}\\ (r)}")#text(". Since ")#mi("{r}")#text(" is so close to ")#mi("{N}")#text(", this basically forces ")#mi("{n^{\\prime}}")#text(" to equal ")#mi("{n}")#text(" (or to equal a shift ")#mi("{n+kr}")#text(" of ")#mi("{n}")#text(" for some small ")#mi("{k}")#text("). To simplify the exposition we will just look at the diagonal case ")#mi("{n=n^{\\prime}}")#text(" (the off-diagonal terms are treated similarly). Our task is now to control")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q_1,q_2 \\sim Q: (q_1q_2,r)=1} c_{q_1,r} \\overline{c_{q_2,r}} \\sum_{n} \\left|\\beta(n)\\right|^2 \\sum_{m \\sim M: mn = a_{q_1}\\ (q_1); mn = a_{q_2}\\ (q_2); mn = a_r\\ (r)} 1", block: true)]]

#text("with accuracy better than ")#mi("{O( x^{1/2+\\sigma})}")#text(". Using averaging notation, this is basically the same as controlling")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_{q_1,q_2 \\sim Q: (q_1q_2,r)=1} c_{q_1,r} \\overline{c_{q_2,r}} {\\bf E}_{n \\sim N} \\left|\\beta(n)\\right|^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\sim M: mn = a_{q_1}\\ (q_1); mn = a_{q_2}\\ (q_2); mn = a_r\\ (r)} 1")]]

#text("with accuracy better than ")#mi("{O( x^{-4\\varpi})}")#text(".")

#text("Recall that we had the foresight to remove all the tiny primes from ")#mi("{q_1,q_2}")#text(". This has the effect of making ")#mi("{q_1,q_2}")#text(" typically coprime. We will discard the non-coprime contributions (it turns out that they can be controlled with relatively easy estimates) and insert the condition ")#mi("{(q_1,q_2)=1}")#text(" in the above summation. We can also make ")#mi("{n}")#text(" coprime to ")#mi("{q_1q_2r}")#text(" since the ")#mi("{m}")#text(" summation vanishes otherwise.")

#text("The ")#mi("{m}")#text(" summation is over an interval of length ")#mi("{M = x^{1/2+\\sigma}}")#text(" over a single congruence class ")#mi("{a_{q_1 q_2 r}/n\\ (q_1 q_2 r)}")#text(" of modulus ")#mi("{q_1 q_2 r \\sim x^{1/2+\\sigma+4\\varpi}}")#text(". This sum can then be inverted via the Fourier transform to a dual sum over a range ")#mi("{H \\sim x^{4\\varpi}}")#text("; morally speaking we may replace")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\sim M: m = a_{q_1 q_2 r} / n\\ (q_1 q_2 r)} 1")]]

#text("with something like ")#metadata(none) <tao-2e1712f7908f611efbf8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("{\\bf E}_{h = O(H)} e_{q_1 q_2 r}( \\frac{a_{q_1 q_2 r}h}{n} )")]]

#text("where ")#mi("{e_q(n) := e^{2\\pi in/q}}")#text(" for ")#mi("{x \\in {\\bf Z}/q{\\bf Z}}")#text(", and the reciprocal ")#mi("{\\frac{1}{n}}")#text(" here is taken inside the ring ")#mi("{{\\bf Z}/q_1q_2 r{\\bf Z}}")#text(". The zero frequency ")#mi("{h=0}")#text(" can be controlled directly; we ignore it and work with non-zero ")#mi("{h}")#text(". We are now trying to control ")#metadata(none) <tao-d6c7dc5b78cc668137cf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("{\\bf E}_{n \\sim N; h = O(H); q_1,q_2 \\sim Q: (q_1 q_2,r) = (q_1,q_2)=1} \\left|\\beta(n)\\right|^2 c_{q_1,r} \\overline{c_{q_2,r}} e_{q_1 q_2 r}( \\frac{a_{q_1 q_2 r}h}{n} )", block: true)]]

#text("to accuracy better than ")#mi("{O( x^{-4\\varpi})}")#text(".")

#text("We can eliminate the ")#mi("{\\beta}")#text(" next by performing a Cauchy-Schwarz in ")#mi("{n}")#text(", but it turns out to be a bit more efficient to Cauchy-Schwarz in ")#mi("{n}")#text(" and ")#mi("{q_1}")#text(", not just in ")#mi("{n}")#text(". This places us in the position of having to control")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{n \\sim N; h,h^{\\prime} = O(H); q_1,q_2,q^{\\prime}_2 \\sim Q} \\overline{c_{q_2,r}} c_{q^{\\prime}_2,r} e_{q_1 q_2 r}( \\frac{a_{q_1 q_2 r}h}{n} ) e_{q_1 q^{\\prime}_2 r}( - \\frac{a_{q_1 q^{\\prime}_2 r}h^{\\prime}}{n} )")]]

#text("to accuracy better than ")#mi("{O( x^{-8\\varpi} )}")#text(", where we have suppressed the various coprimality conditions on the ")#mi("{q_1,q_2,q^{\\prime}_2}")#text(" for brevity. So it suffices to get bounds on the exponential sum")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{n \\sim N} e_{q_1 q_2 r}( \\frac{a_{q_1 q_2 r}h}{n} ) e_{q_1 q^{\\prime}_2 r}( - \\frac{a_{q_1 q^{\\prime}_2 r}h^{\\prime}}{n} )")]]

#text("which beat the trivial bound of ")#mi("{O(1)}")#text(" by about ")#mi("{x^{8\\varpi}}")#text(" on average, for “typical” values of ")#mi("{h,h^{\\prime},q_1,q_2,q^{\\prime}_2}")#text(". This is basically an incomplete Kloosterman sum of the shape ")#metadata(none) <tao-7a1eeca70e68877fc35f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\frac{1}{N} \\sum_{n \\sim N} e_q( \\frac{c}{n} )")]]

#text("for some modulus ")#mi("{q}")#text(" of typical size ")#mi("{q \\sim q_1 q_2 q^{\\prime}_2 r \\sim x^{1/2+2\\sigma+6\\varpi}}")#text(" and a coefficient ")#mi("{c}")#text(" which turns out to typically be more or less coprime to ")#mi("{q}")#text(" except in a certain ")#emph[#text("diagonal case")]#text(" ")#mi("{hq^{\\prime}_2 = h^{\\prime}q_2}")#text(", but it turns out in the Type I case that this diagonal contribution is manageable. A standard “")#link("http://en.wikipedia.org/wiki/Character_sum")[#text("Pólya-Vinogradov")]#text("” type bound for such sums, ultimately based on Weil’s famous bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\in {\\bf Z}/p{\\bf Z}: n \\neq 0} e_p( \\frac{a}{n} + bn)\\right| \\leq 2\\sqrt{p}", block: true)]]

#text("for completed Kloosterman sums, allows one to bound ")#link(<tao-7a1eeca70e68877fc35f>)[#text("(11)")]#text(" by ")#mi("{O( \\frac{1}{N} \\sqrt{q} )}")#text(" (ignoring some logarithmic type errors and lower order terms). This gives us an acceptable estimate if")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{ x^{1/2-\\sigma} } \\sqrt{ x^{1/2+2\\sigma+6\\varpi} } \\ll x^{-8\\varpi}")]]

#text("which may be rearranged as")

#align(center)[#tao-fit-display[#mitex("8 \\sigma + 44 \\varpi < 1.")]]

#text("(Recall that we are treating ")#mi("{\\delta}")#text(" as negligible, otherwise we have to insert some factors of ")#mi("{\\delta}")#text(" in this constraint as well.) Crucially, this constraint allows ")#mi("{\\sigma}")#text(" to exceed ")#mi("{1/10}")#text(", and thus gives a good range of Type I estimates if ")#mi("{\\varpi}")#text(" is small enough. Further improvements have been obtained by using more refined estimates on incomplete Kloosterman sums (first discussed ")#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/")[#text("here")]#text("); to date we have managed to (provisionally) replace the above constraint to")

#align(center)[#tao-fit-display[#mitex("5 \\sigma + 54 \\varpi < 1")]]

#text("which turns out to give superior numerical results. This reveals a tradeoff, in that more advanced exponential sum estimates can improve ")#mi("{\\sigma}")#text(" at the expense of ")#mi("{\\varpi}")#text("; we have not yet located what the optimal balance for this tradeoff is.")

#heading(level: 1)[#strong[#text(" — 5. Type II estimates — ")]]

#text("The Type II estimates are treated quite similarly to the Type I estimates and will only be discussed briefly here. If one repeats the Type I estimates verbatim, most of the same arguments go through (in fact they become better because the ")#mi("{\\sigma}")#text(" terms are not present); however it turns out that the diagonal contribution ")#mi("{hq^{\\prime}_2=h^{\\prime}q_2}")#text(" that was manageable in the Type I setting, no longer becomes manageable in the Type II setting. To get around this one has to reduce the influence of the diagonal by taking a narrower Cauchy-Schwarz when eliminating ")#mi("{\\beta}")#text(" from ")#link(<tao-d6c7dc5b78cc668137cf>)[#text("(10)")]#text(", namely that one only performs a Cauchy-Schwarz in ")#mi("{n}")#text(" rather than ")#mi("{n,q_1}")#text(". The price one pays for this is that the off-diagonal terms become slightly worse (conceding a few more powers of ")#mi("{\\varpi}")#text("); the best estimate we currently have here (again ignoring ")#mi("{\\delta}")#text(" issues) is")

#align(center)[#tao-fit-display[#mitex("68 \\varpi < 1.")]]

#heading(level: 1)[#strong[#text(" — 6. Type III estimates — ")]]

#text("The Type III estimates ")#link(<tao-6d98cf9990217749def8>)[#text("(7)")]#text(" were originally treated by Zhang using the method of Weyl differencing. More recently, a simpler method which gives better numerology was introduced by Fouvry, Kowalski, Michel, and Nelson, and may be sketched as follows. Our goal here is to control something like")

#align(center)[#tao-fit-display[#mitex("\\sum_{q \\sim Q} c_q \\sum_{n = a_q\\ (q): n \\in [x,2x]} \\tau_3(n)")]]

#text("to accuracy better than ")#mi("{O( x )}")#text(", where ")#mi("{c_q}")#text(" are bounded coefficients, and ")#mi("{Q}")#text(" is a quantity larger than ")#mi("{x^{1/2}}")#text(" (which we would like to take to be as large as possible). Expanding out the ")#mi("{\\tau_3}")#text(" function and using dyadic decomposition, this basically amounts to controlling")

#align(center)[#tao-fit-display[#mitex("\\sum_{q \\sim Q} c_q \\sum_{n_1 \\sim N_1; n_2 \\sim N_2; n_3 \\sim N_3} 1_{n_1 n_2 n_3 = a_q\\ (q)}")]]

#text("to accuracy ")#mi("{O( x \\log^{-A} x)}")#text(" for some ")#mi("{N_1,N_2,N_3}")#text(" that multiply to ")#mi("{x}")#text(" (e.g. one can take ")#mi("{N_1=N_2=N_3=x^{1/3}}")#text(" for sake of discussion, although the precise choice of ")#mi("{N_1,N_2,N_3}")#text(" turns out to not be so important). Applying Fourier decomposition as in ")#link(<tao-2e1712f7908f611efbf8>)[#text("(9)")]#text(", one can write this expression roughly speaking as")

#align(center)[#tao-fit-display[#mitex("\\sum_{q \\sim Q} c_q {\\bf E}_{h_1 = O(H_1), h_2 = O(H_2), h_3 = O(H_3)} \\sum_{x,y,z \\in {\\bf Z}/q{\\bf Z}: xyz=a_q} e_q( h_1 x + h_2 y + h_3 z )")]]

#text("where ")#mi("{H_1,H_2,H_3}")#text(" are the dual scales ")#mi("{H_i := Q / N_i}")#text(". It turns out that the contributions when ")#mi("{h_1,h_2,h_3}")#text(" vanish, or more generally share a common factor with ")#mi("{q}")#text(", can be dealt with, so we ignore them and assume that ")#mi("{h_1,h_2,h_3}")#text(" are coprime with ")#mi("{q}")#text(". In this case, we can write the inner sum after a change of variables as")

#align(center)[#tao-fit-display[#mitex("\\sum_{x,y,z \\in {\\bf Z}/q{\\bf Z}: xyz=a_q} e_q( h_1 x + h_2 y + h_3 z ) = q K_3( a_q h_1 h_2 h_3; q )")]]

#text("where ")#mi("{K_3}")#text(" is the ")#emph[#text("hyper-Kloosterman sum")]#text(" ")#metadata(none) <tao-2f5052c9fd15b19a18c5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("K_3(a;q) := \\frac{1}{q} \\sum_{x,y,z \\in {\\bf Z}/q{\\bf Z}: xyz = a} e_q(x+y+z).")]]

#text("The normalisation ")#mi("{\\frac{1}{q}}")#text(" in ")#link(<tao-2f5052c9fd15b19a18c5>)[#text("(12)")]#text(" reflects the expected square root cancellation in this sum, which is a sum of about ")#mi("{O(q^2)}")#text(" phases that one expects to behave more or less independently of each other. Indeed, using the deep results of Deligne on the Weil conjectures, one can show that ")#metadata(none) <tao-ad370ed99b189921e7fe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left|K_3(a;q)\\right| \\ll 1", block: true)]]

#text("for ")#mi("{a}")#text(" coprime to ")#mi("{q}")#text(" (ignoring some log factors).")

#text("Replacing ")#mi("{q}")#text(" by ")#mi("{Q}")#text(" (which can be done by adjusting the ")#mi("{c_q}")#text(" a little bit), our task is now to control")

#align(center)[#tao-fit-display[#mitex("\\sum_{q \\sim Q} c_q {\\bf E}_{h_1 = O(H_1), h_2 = O(H_2), h_3 = O(H_3)} K_3(a_q h_1 h_2 h_3; q)")]]

#text("to accuracy better than ")#mi("{O( x / Q )}")#text(". If we apply Deligne’s bound ")#link(<tao-ad370ed99b189921e7fe>)[#text("(13)")]#text(" right away, we get a bound of ")#mi("{O(Q)}")#text(", which only works for ")#mi("{Q < x^{1/2}}")#text(", which recovers the Bombieri-Vinogradov theorem for ")#mi("{\\tau_3}")#text(" but no better. To improve upon this we perform a Cauchy-Schwarz. We first perform the useful substitution ")#mi("{h=h_1h_2h_3}")#text(", which rewrites the above sum as something like")

#align(center)[#tao-fit-display[#mitex("\\sum_{q \\sim Q} c_q {\\bf E}_{h = O(H_1 H_2 H_3)} \\tilde \\tau_3(h) K_3(a_q h; q)")]]

#text("where ")#mi("{\\tilde \\tau_3}")#text(" is a truncated version of ")#mi("{\\tau_3}")#text(" (counting factorisations ")#mi("{h=h_1h_2h_3}")#text(" with ")#mi("{h_1 = O(H_1), h_2 = O(H_2), h_3=O(H_3)}")#text("). Note that ")#mi("{H := H_1 H_2 H_3}")#text(" is given by ")#mi("{H = Q^3 / N_1 N_2 N_3 \\sim Q^3 / x}")#text(", so that ")#mi("{x/Q \\sim Q^2 / H}")#text(". We interchange the sum, so we are now asking to bound")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{h = O(H)} \\tilde \\tau_3(h) {\\bf E}_{q \\sim Q} c_q K_3(a_q h; q)")]]

#text("to accuracy better than ")#mi("{Q/H}")#text(".")

#text("At this point it turns out to be optimal to use the smoothness of the modulus ")#mi("{q}")#text(" to split ")#mi("{q=rs}")#text(" where ")#mi("{r,s \\sim Q^{1/2}}")#text(", so we wish to control something like")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{h = O(H); r \\sim Q^{1/2}} \\tilde \\tau_3(h) {\\bf E}_{s \\sim Q^{1/2}} c_{rs} K_3(a_{rs} h; rs).")]]

#text("to accuracy better than ")#mi("{Q/H}")#text(". If we Cauchy-Schwarz in ")#mi("{h}")#text(" and ")#mi("{r}")#text(", we end up having to bound")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{h = O(H); r \\sim Q^{1/2}} {\\bf E}_{s,s^{\\prime} \\sim Q^{1/2}} c_{rs} c_{rs^{\\prime}} K_3(a_{rs} h; rs) \\overline{K_3(a_{rs^{\\prime}} h; rs^{\\prime})}")]]

#text("to accuracy better than ")#mi("{Q^2/H^2}")#text(". The diagonal contribution ")#mi("{s=s^{\\prime}}")#text(" is ")#mi("{O( Q^{-1/2} )}")#text(" thanks to ")#link(<tao-ad370ed99b189921e7fe>)[#text("(13)")]#text(". Now we turn to the opposite case when ")#mi("{s,s^{\\prime}}")#text(" are coprime. The goal is then to establish the estimate")

#align(center)[#tao-fit-display[#tao-math("\\left| {\\bf E}_{h= O(H)} K_3(a_{rs} h; rs) \\overline{K_3(a_{rs^{\\prime}} h; rs^{\\prime})} \\right| \\ll Q^2 / H^2", block: true)]]

#text("for an incomplete Kloosterman correlation with net modulus ")#mi("{rss^{\\prime}}")#text(". It turns out that there is a Pólya-Vinogradov type bound of ")#mi("{O( (rss^{\\prime})^{1/2} / H ) \\sim Q^{3/4} / H}")#text(" for this sum (though this requires a non-trivial amount of Deligne’s Weil conjecture machinery to actually prove). So we are done if")

#align(center)[#tao-fit-display[#mitex("Q^{-1/2}, Q^{3/4}/H \\ll Q^2 / H^2")]]

#text("which simplifies to ")#mi("{H \\ll Q^{5/4}}")#text(", or equivalently ")#mi("{Q \\ll x^{4/7}}")#text(". So this argument allows one to obtain ")#link(<tao-6d98cf9990217749def8>)[#text("(7)")]#text(" for ")#mi("{\\alpha}")#text(" up to ")#mi("{4/7}")#text(", which corresponds to the constraint")

#align(center)[#tao-fit-display[#mitex("12 \\sigma > 1 + 28 \\varpi")]]

#text("which, happily, overlaps enough with the Type I bounds and the combinatorial constraint ")#mi("{\\sigma > 1/10}")#text(" to give ")#mi("{MPZ[\\varpi,\\delta]}")#text(" (or ")#mi("{MPZ^{\\prime}[\\varpi,\\delta]}")#text(") for relatively good values of ")#mi("{\\varpi}")#text(" (and ")#mi("{\\delta}")#text(", which we have ignored in this discussion). We have managed to (provisionally) improve upon this constraint to")

#align(center)[#tao-fit-display[#mitex("18 \\sigma > 1 + 56 \\varpi")]]

#text("by exploiting an additional averaging that is present in the true Type III estimate (and which was suppressed in ")#link(<tao-6d98cf9990217749def8>)[#text("(7)")]#text("). Combining this with the best Type I estimate we currently have (and with the combinatorial constraint ")#mi("{\\sigma > 1/10}")#text(") gives us the best value of ")#mi("{\\varpi}")#text(" currently available, namely ")#mi("{1/108}")#text(" (note that this is well below the Type II constraint, which may thus be ignored). Actually, the Type III estimates are now so strong that they are no longer critical for further improvements in the numerology; it is either the Type I estimate or the combinatorial constraint ")#mi("{\\sigma>1/10}")#text(" that needs improving instead. (Alternatively, if one is willing to use a worse value of ")#mi("{\\varpi}")#text(", namely ")#mi("{\\varpi < 1/324}")#text(", one can use the Type I estimates to raise ")#mi("{\\sigma}")#text(" up to ")#mi("{1/6}")#text(", which closes off the Type III case completely and allows for a slightly more elementary proof of Zhang’s theorem in that the full strength of Deligne’s proof of the Weil conjectures is no longer needed (although Weil’s classical bound on Kloosterman sums is still required).)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (86)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-236887")[#strong[#text("Muchos están esperando tu ayuda y que les prediques la palabra de Dios.")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")]

#text("[…] formula 1Bounded gaps between primes (Polymath8) – a progress report For any , let denote the assertion that there are infinitely many pairs of consecutive primes whose […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-236890")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("I haven’t been following every detail of this so far, but if it’s true that the Type I/II estimates cover everything, as hence you avoid the deeper Deligne stuff, then to my tastes that’s the most significant development of the polymath project so far. It means one could in principle teach the whole proof in a graduate course. Furthermore (I haven’t checked this) if you can do Type I for ")#mi("\\sigma \\geq \\frac{1}{6}")#text(" then can’t you in fact use Vaughan’s identity instead of Heath-Brown?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-236949")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("I agree this would be quite significant. I think the gain is described here: ")#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236387")[#text("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236387")]

#text("Namely we achieve ")#mi("\\sqrt {N}(d_1d_2)^{1/6}=\\sqrt {N}(Q^3R)^{1/6}")#text(" rather than the (dominant) ")#mi("\\sqrt {N}Q")#text(" of Lemma 10. My calculations agree that this allows one to take ")#mi("\\sigma")#text(" as large as 1/5. Here ")#mi("R\\sim N\\sim x^{1/2-\\sigma},Q\\sim d/N\\sim \\sqrt {x}/N\\sim x^\\sigma")#text(" (up to ")#mi("\\omega,\\delta")#text(" parts), and the above expressions need to be less than ")#mi("N")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-236995")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("Just recording the results of a discussion I had with Ben on this. It does look like Vaughan’s identity with ")#mi("U=V=x^{1/3}")#text(", together with a Zhang-Type I estimate that works for ")#mi("\\sigma = 1/6")#text(", is enough to establish Zhang’s theorem; the Vaughan-Type II sums can be handled by Zhang’s Type I/II analysis, and the Vaughan-Type I sums can be handled by either Zhang Type I/II or Zhang Type 0, depending on the exact scales involved. So one does not need either the Heath-Brown identity or Deligne’s theory to prove Zhang’s theorem, just Weil’s bound on completed exponential sums. Actually Ben pointed out that the more elementary bound ")#tao-math("\\left|\\sum_{n \\in {\\bf Z}/p{\\bf Z}} e(f(n))\\right| \\ll p^{3/4}", block: false)#text(" of Kloosterman for nonlinear rational functions ")#mi("f")#text(", when combined with sufficiently many iterations of the q-van der Corput method, give non-trivial bounds on even very short incomplete Kloosterman sums on smooth moduli that suffice to give Type I/II estimates for ")#mi("\\sigma")#text(" arbitrarily close to 1/2, and in particular at least as large as 1/6, which suffices for the purposes of establishing Zhang’s theorem (albeit with somewhat worse values of ")#mi("\\varpi,k_0,H")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2695a75cb0a77fcb0da8325436aa1b227e7ebd0d4f5622918293903fe9a8a60c-6b9452bfe07aca30c2ff24cf883768758eeecd14907a9a900924c5c6205ea2d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DP")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237002")[#strong[#text("DP")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("Deligne’s proof of the Weil conjectures, technically, is absolutely “needed” for Dr. Zhang to have his paper accepted by Annals of Math.quickly. If such an amazing big result had been announced with only an elementary proof by a guy whom basically no one knows of, the editors wouldn’t even have taken a look at his manuscript.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-236893")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("In point 1 near the top the link to the k-tuples page is missing – did you mean for it to be on the word ‘here’?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad3f3a79ef213c98c05db1ab441cb92661583507ac1a7a5e31f4beaa785f1e3b-bd0c7862157994459c7704585bcfde3a1c363765d691789fd896ca4a5396e667.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-236897")[#strong[#text("Greg")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("Small typo: two displayed equations before (4), the coefficient of ")#mi("x")#text(" should be ")#mi("2\\gamma-1")#text(" instead of ")#mi("-1")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9de13c3c77059e2381357dce91d8408811e186d9d73d672aa8a814d24502a97-6908235e9bb52c626e6c19f1d38e16ef432f563317e7085fab69ed891489f3c0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sniffnoy")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-236903")[#strong[#text("Sniffnoy")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("Also, something seems to have gotten lost here:")

#text("“This has produced many of the best constructions so far, typically 5 Very recently,”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-236905")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("I just posted an improvement (hopefully) to Theorem 8 in the earlier thread (")#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/")[#text("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/")]#text("). The point is that by properly averaging over ")#mi("q_1")#text(", the constraint (47) can be weakened so that it follows from (45). I have not checked if this leads to any improvement in Theorem 4 of the earlier thread, but eliminating a condition is always a good thing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-236944")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("Thanks for this! Actually it turns out that this condition could already be eliminated by a later refinement of the incomplete Kloosterman sum estimate in which the ")#mi("(c_1,d^{\\prime}_1)^{1/4}/(d^{\\prime}_1)^{1/4}")#text(" factor was improved to ")#mi("\\frac{(c_1,d^{\\prime}_1)}{d^{\\prime}_1} \\frac{(c_2,d^{\\prime}_2)}{d^{\\prime}_2}")#text(" (basically by using the older completion of sums method instead of the van der Corput method when N is large: see ")#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-236033")[#text("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-236033")]#text(" . But this additional refinement you have pushes this contribution down even further, although it is currently not the dominant constraint so unfortunately it does not (yet) give any improvement to the numerology. (But as you say, it doesn’t hurt. :-).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237017")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("Thank you! I will try to catch up with the latest developments. It is not easy (for me): the blog entries and comments that constitute polymath8 would occupy now about 450 printed pages!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-236908")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("Regarding the second Hardy-Littlewood conjecture, this graph (")#link("http://math.mit.edu/~drew/hw2data.gif")[#text("http://math.mit.edu/~drew/hw2data.gif")]#text(") may be of interest. It shows lower bounds for k-pi(w) versus w, with w=H(k)+1, using the most current upper bounds on H(k) from the new tuples database (which in just 4 days has processed more than 1000 submissions, improving some 800 H(k) values). The dips in the chart are good targets for future improvement.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-236942")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("Dear Andrew,")

#text("It looks like the link is 403’ed currently (permissions are not set properly). EDIT: Never mind, it seems to work now.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-236947")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("The 403 error is an intermittent problem that are IT folks are working on, just hit refresh if it happens again.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-236918")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("Thanks for the update! This was helpful.")

#text("Some formatting seems to have gone wrong around “but only those moduli which were squarefree and ")#link("http://www.ams.org/mathscinet-getitem?mr=2414788")[#text("http://www.ams.org/mathscinet-getitem?mr=2414788")]#text(".)…”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-236920")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("Let my computer did a systematic scan to obtain feasible ")#mi("k_0")#text(" values for different ")#mi("(\\varpi, \\delta)")#text(" settings. The table can be found here:")

#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0table.html")[#text("http://www.cs.cmu.edu/~xfxie/project/admissible/k0table.html")]

#text("A basic observation is that the coefficient for ")#mi("\\delta")#text(" seems to have a quite minor effect on determining ")#mi("k_0")#text(" values. So I assume that testing on a single ")#mi("\\delta")#text(" coefficient (or a few more) might be sufficient to gain some knowledge on possible ")#mi("k_0")#text(" values. I did test some rows to confirm more.")

#text("All these data could be generated by an old MacBook machine (otherwise it might be idle forever) in less than one day. So there is no difficulty to generate a more complete table, if it might be useful for some guys. I assume many of them might still be improved. I am also not quite sure about the correctness of the settings of parameter ranges.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237075")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("Just cleared the code and put a download link in the webpage above.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27e7070af2c8cecbe65c0bd2047912d0dde6eaa77e7595e4d0dd4e7741b1f7ee-011cc43a6a7233cc01cb9ca581e8df3b57df1eee94f84c3b434ec595dee77387.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shizhuo Looi")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-236956")[#strong[#text("Shizhuo Looi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("Thank you for this summary and update; it was helpful. Just a very minor point: when you summarize Zhang’s argument, there seems to be a missing parenthesis at the end of point 1.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3942f07859f7b5fe127cb796e43c948c824157669d5e16b415fb85a828af6480-8301924d335b48112e395debdef7e1c2f1a44fc6c678a0dbe603ef34134daa19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grégoire Nicollier")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-236959")[#strong[#text("Grégoire Nicollier")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("In Section 3, a prime is missing in the definition of the modified order divisor functions.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-236972")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("The direction of the ")#mi("\\gg")#text(" sign in the third-to-last display is opposite sense to the following line")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-236985")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("In point 3 of introduction, TypeIII[\\varpi, \\delta] (last mention of TypeIII) should probably be TypeIII[\\varpi, \\delta, \\sigma].")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237001")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("General questions for the polymath participants:")

#text("While I’m comfortable with convolutions, I’m not as familiar with the methods which require smoothness of one of the convolved functions. In particular, I’ve enjoyed learning about “completion of sums,” although it is still somewhat of a black box for me in some of the discussions.")

#text("I noticed that in the (more detailed) Type I analysis, we replace ")#mi("\\alpha")#text(" (after some Cauchy-Schwarzing) by a smooth sequence, in order to take advantage of completion of sums. On the other hand, in the Type III analysis, smoothness is used (as far as I can tell) to do completion of sums twice, and to give a Taylor series once. I was wondering: Can a similar trick as in the Type I case be used to allow non-smoothness in one or more of the completion of sums in the Type III case?")

#text("Also, if ")#mi("\\psi_1,\\psi_2")#text(" are smooth, how “far away” is ")#mi("\\psi_1\\ast \\psi_2")#text(" from being smooth?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237096")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("Dear Pace,")

#text("I can answer your second question first: because Dirichlet convolution is based on the multiplicative structure of the integers rather than the additive structure, the convolution of two smooth functions is unfortunately not very smooth in general. For instance the divisor function ")#mi("\\tau = 1 \\ast 1")#text(" is quite rough, jumping down to 2 at the primes but typically much larger (the average value of ")#mi("\\tau(n)")#text(" is about ")#mi("\\log n")#text(").")

#text("If one replaced a smooth sequence by a rough sequence in the Type III sums, one could eliminate it by Cauchy-Schwarz, but each use of Cauchy-Schwarz tends to halve any gains one gets later on in the argument (e.g. from the Weil conjectures), or equivalently doubles the amount of gain one has to generate in order to make up for losses (e.g. from completion of sums). Conversely, one might be able to improve the Type I sum numerology if ")#mi("\\beta")#text(" was smooth as we could avoid one application of Cauchy-Schwarz; this may potentially deal with some “Type IV” sums (of the form ")#mi("\\psi_1 * \\ldots * \\psi_4")#text(" where the ")#mi("\\psi_i")#text(" are smooth and supported near ")#mi("x^{1/5}, x^{1/5}, x^{1/5}, x^{2/5}")#text(" respectively) but not unfortunately for “Type V” sums (of the form ")#mi("\\psi_1 * \\ldots * \\psi_5")#text(" where the ")#mi("\\psi_i")#text(" are all smooth and supported near ")#mi("x^{1/5}")#text(") where ")#mi("\\beta")#text(" looks a bit like ")#mi("\\tau")#text(" and thus not very smooth. (There are some fancy techniques coming from Eisenstein series that I don’t understand that could potentially start controlling exponential sums such as ")#mi("\\sum_n \\beta(n) \\beta(n+l) \\Phi(\\ldots)")#text(" when ")#mi("\\beta")#text(" looks like a divisor function ")#mi("\\tau")#text(", but the gains are very small and also rather complicated, and may end up being inferior to the current Cauchy-Schwarz methods.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237138")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("Dear Terry,")

#text("Thanks for explaining this so clearly. The reason I asked is that, at present, it isn’t the Type III sums which are the roadblock, and so we can be a little more lossy if we also able to deal with the combinatorial problems. And the Type IV, V,… sums are incorporated into Type III if among ")#mi("\\psi_1,\\psi_2,\\psi_3")#text(", both ")#mi("\\psi_1")#text(" and one of the other two sequences can be assumed non-smooth.")

#text("My current project is to understand these sums well enough to work out how this change affects the numerology, and whether the losses incurred by two Cauchy-Schwarzes are offset by the ability to lower ")#mi("\\sigma")#text(" to 0.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2c4699af39d6e67f42f26e4f37f3764ee24c183deb651e3957ec0129bfcb3ca-7a803e7c9ef94a2af874c1479a84d6eda02163a89803ab17c35b84ba75194a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of E.L. Wisty")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237015")[#strong[#text("E.L. Wisty")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("Reblogged this on ")#link("http://jsandber.wordpress.com/2013/07/01/bounded-gaps-between-primes-polymath8-a-progress-report/")[#text("Pink Iguana")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bf23ebe11fcbe0a61f64f59239b469fe4ee5076b883e15afea619b4b55ffb4b-054844e28292f70f825dd0fb4a8a6b451c1cdf5bd9a9f72293281da9ef6261fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avi Levy")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237058")[#strong[#text("Avi Levy")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("The first two paragraphs below the fold (right before Conjecture 2) have a couple typos regarding ")#mi("k")#text(" and ")#mi("k_0")#text(" being flipped at times. Perhaps just stick to $k_0$ to avoid confusion?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237087")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("I’m recording the outcome of the idea (inspired by a comment of Philippe Michel) to readjust the Cauchy-Schwarz in the Type I sums (something that I’ve called “Level 6” on the wiki, skipping Level 5 for now which was more difficult to implement than I had hoped). This time around it does seem to improve the final value for ")#mi("\\varpi")#text(", in contrast to the Level 4 estimates which actually made things worse. (Although Level 4 (if iterated) does have the effect of showing that Type I estimates hold for ")#mi("\\sigma")#text(" arbitrarily close to 1/2 if one is willing to set ")#mi("\\varpi")#text(" sufficiently close to zero. This observation might be useful for some other application than bounded gaps beween primes, but doesn’t seem to be directly useful for our current project.)")

#text("Anyway, to Level 6. We will need some sort of “double dense divisibility”, but I will punt on this as before by first working in the case when the modulus is ")#mi("x^\\delta")#text("-smooth, which gives us all the dense divisibility we need (at the cost of making the numerology to get from ")#mi("MPZ[\\varpi,\\delta]")#text(" to ")#mi("DHL[k_0,2]")#text(" a bit worse, by forcing ")#mi("\\delta")#text(" and ")#mi("\\delta^{\\prime}")#text(" to be equal).")

#text("If we go through the Type I argument from ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")]#text(" , we reach a point (see equation (39) from that post) where we have to prove the estimate")

#mi("\\sum_{1 \\leq h \\leq H} \\sum_{q_1,q_2 \\sim Q} c_{h,q_1,q_2} \\sum_{n}  \\beta(n) \\beta(n+kr) \\Phi(h,q_1,q_2; n) \\lessapprox x^{-\\varepsilon} Q^2 N")#text(" (*)")

#text("where the ")#mi("c_{h,q_1,q_2}")#text(" are bounded coefficients, and")

#mi("x^{1/2-\\sigma} \\ll N \\ll x^{1/2-2\\varpi-\\varepsilon}")

#mi("M \\sim x/N")

#mi("x^{-\\delta-\\varepsilon} N \\ll R \\ll x^{-\\varepsilon} N")

#mi("Q \\ll x^{1/2+2\\varpi}/R")

#mi("H = x^\\varepsilon Q^2 R/M")

#mi("\\Phi(h,q_1,q_2;n) = 1_{(q_1,r)=(q_2,r)=(q_1,q_2)=(n,r)=(n,q_1)=(n+kr,q_2)=1}")

#mi("e_r( \\frac{a_r h}{nq_1 q_2} ) e_{q_1}( \\frac{b_{q_1}h}{n r q_2} ) e_{q_2}( \\frac{b^{\\prime}_{q_2} h}{(n+kr) r q_1} ) .")

#text("Previously we have dealt with (*) in the Type I case by performing Cauchy-Schwarz in the ")#mi("n, q_1")#text(" variables. Now we rebalance this by factoring ")#mi("q_2")#text(" (which is ")#mi("x^\\delta")#text("-smooth by construction) as ")#mi("q_2 = s_2 t_2")#text(" where ")#mi("s_2 \\sim S")#text(", ")#mi("t_2 \\sim T")#text(" for some ")#mi("ST \\sim Q")#text(", and we can force")

#mi("x^{-\\delta} S_0 \\ll S \\ll S_0")

#text("for some ")#mi("1\\leq S_0 \\leq Q")#text(" to be chosen later. We now need to establish")

#mi("\\sum_h \\sum_{q_1 \\sim Q; s_2 \\sim S; t_2\\sim T} c_{h,q_1,s_2 t_2} \\sum_{n}  \\beta(n) \\beta(n+kr) \\Phi(h,q_1,s_2 t_2; n) \\lessapprox x^{-\\varepsilon} Q^2 N")#text(".")

#text("If we perform Cauchy-Schwarz now in ")#mi("n,q_1,s_2")#text(", we reduce to")

#mi("\\sum_{1 \\leq h,h^{\\prime} \\leq H} \\sum_{q_1 \\sim Q; s_2 \\sim S; t_2,t^{\\prime}_2\\sim T}")

#tao-math("\\left|\\sum_{n} \\psi_N(n) \\Phi(h,q_1,s_2 t_2; n) \\overline{\\Phi(h,q_1,s_2 t^{\\prime}_2; n)}\\right|", block: false)

#mi("\\lessapprox x^{-\\varepsilon} Q^2 T N")#text(".")

#text("We first control the diagonal case ")#mi("h t^{\\prime}_2 = h^{\\prime} t_2")#text(", which is a little stronger than it was in previous arguments. By the divisor bound, there are ")#mi("\\lessapprox H Q S T")#text(" possible values of ")#mi("(h,h^{\\prime},q_1,s_2,t_2,t^{\\prime}_2)")#text(" that contribute to this diagonal case, and for each such contribution we use the")#linebreak()#text(" trivial bound of ")#mi("O(N)")#text(" for the ")#mi("n")#text(" summation. (It just occurred to me on writing this that one could perhaps do a bit better than the trivial bound here, but then I realised that the ")#mi("(h,t_2)=(h^{\\prime},t^{\\prime}_2)")#text(" subcomponent of the diagonal has no such cancellation and is already a significant fraction of the diagonal, so it seems there is no gain available). The diagonal contribution is thus acceptable if")

#mi("HQ S T N \\lessapprox x^{-\\varepsilon} Q^2 T N")

#text("thus")

#mi("S \\lessapprox x^{-\\varepsilon} Q / H.")

#text("We thus set ")#mi("S_0 := x^{-\\varepsilon} Q/H")#text(". (This requires us to have ")#mi("S_0 \\gtrapprox 1")#text(", but this turns out to follow from the Type I condition ")#mi("N \\ll x^{1/2-2\\varpi-\\varepsilon}")#text(".)")

#text("Now for the off-diagonal terms. On using the rebalanced van der Corput estimate (see ")#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236387")[#text("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236387")]#text(" ) we have")

#tao-math("\\left|\\sum_{n} \\psi_N(n) \\Phi(h,q_1,s_2 t_2; n) \\overline{\\Phi(h,q_1,s_2 t^{\\prime}_2; n)}\\right|", block: false)

#mi("\\lessapprox N^{1/2} x^{\\delta/6} (RQST^2)^{1/6} + \\frac{(ht^{\\prime}_2-h^{\\prime}t_2,r)}{r} N,")

#text("so the total off-diagonal contribution is")

#mi("\\lessapprox H^2 QST^2 ( N^{1/2} x^{\\delta/6} (RQST^2)^{1/6} + R^{-1} N ),")

#text("and we win if we have both")

#mi("N^{1/2} x^{\\delta/6} ( RQST^2 )^{1/6} \\lessapprox x^{-\\varepsilon} N / H^2")

#text("and")

#mi("R^{-1} \\lessapprox x^{-\\varepsilon} / H^2.")

#text("We can bound")

#mi("RQST^2 = RQ^3 / S \\lessapprox x^{\\delta+\\varepsilon} RQ^2 H")

#text("so the conditions become")

#mi("x^{\\delta/3} R^{1/6} Q^{1/3} \\lessapprox x^{-7\\varepsilon/6} N^{1/2} H^{-13/6}")

#text("and")

#mi("H^2 \\lessapprox x^{-\\varepsilon} R.")

#text("The worst case arises when")

#mi("QR = x^{1/2+2\\varpi}, N = x^{1/2-\\sigma}, R = x^{1/2-\\sigma-\\delta-\\varepsilon}")

#text("in which case we have")

#mi("Q = x^{2\\varpi + \\sigma + \\delta + \\varepsilon}, H = x^{4\\varpi + \\delta + \\varepsilon}")

#text("and the conditions become")

#mi("\\frac{\\delta}{3} + \\frac{1}{6} (\\frac{1}{2}-\\sigma-\\delta) + \\frac{1}{3} (2\\varpi+\\sigma+\\delta)")

#mi("< \\frac{1}{2} (\\frac{1}{2}-\\sigma) - \\frac{13}{6} (4\\varpi + \\delta)")

#text("and")

#mi("2 (4\\varpi + \\delta) < \\frac{1}{2}-\\sigma-\\delta")

#text("which simplify to")

#mi("56 \\varpi + 16 \\delta + 4 \\sigma < 1")

#text("and")

#mi("16 \\varpi + 6 \\delta + 2\\sigma < 1")

#text("The second condition is implied by the first, so we have obtained a Type I estimate whenever")

#mi("56 \\varpi + 16 \\delta + 4 \\sigma < 1")#text(".")

#text("Playing this against ")#mi("\\sigma > 1/10")#text(" (the Type II and Type III constraints can be checked to be non-dominant here) gives")

#mi("\\frac{280}{3} \\varpi + \\frac{80}{3} \\delta < 1")

#text("which is a little bit better than before in the ")#mi("\\varpi")#text(" aspect, but worse in the ")#mi("\\delta")#text(" aspect, particularly since we had to use ")#mi("x^\\delta")#text("-smoothness rather than dense divsibility and so will have to take ")#mi("\\delta^{\\prime}=\\delta")#text(" when converting to ")#mi("k_0")#text(". However this latter defect is presumably temporary once we figure out what “double dense divisibility” means. (Though the complexity of this argument is beginning to raise the question of whether the final paper should focus on the messiest but strongest results, or instead focus on a slightly less strong but cleaner result. I guess it’s still a bit premature to discuss these things though.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237093")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("Incidentally, I’m coming around to the opinion that absent a radically different way to do the Type I estimates, we’re almost at the end of the road for easy improvements here (and thus probably for the Polymath8 project as a whole). In order to get to the point where we are estimating an exponential sum such as")

#mi("\\sum_n \\psi_N(n) \\Phi(\\ldots) \\overline{\\Phi(\\ldots)}")#text(", (*)")

#text("one has to perform one completion of sums (to deal with the congruence conditions) and two Cauchy-Schwarz’s (to eliminate the ")#mi("\\alpha,\\beta")#text(" coefficients). The completion of sums costs a factor of ")#mi("H")#text(", which is about ")#mi("x^{4\\varpi}")#text(", and this is amplified to ")#mi("H^2 \\approx x^{8\\varpi}")#text(" by the Cauchy-Schwarz. So one has to gain a factor of about ")#mi("x^{8\\varpi}")#text(" over the trivial bound in (*). Even in the best-case scenario (Hooley conjecture) that one has square root cancellation in (*), we still need ")#mi("x^{8\\varpi} \\ll N^{1/2}")#text("; since ")#mi("N")#text(" can be as low as ")#mi("x^{1/2-\\sigma}")#text(" and ")#mi("\\sigma")#text(" has to be at least 1/10, this forces ")#mi("\\varpi > 1/40")#text(". Now we are a long way from actually reaching the Hooley conjecture, even for smooth moduli, which is why our values of ")#mi("\\varpi")#text(" are more like 1/108 or 3/280; it is conceivable that some increasingly heroic efforts could shave a bit more off of the exponential sum estimates (possibly by exploiting the additional averaging in h, r parameters that are available, although my initial efforts in this direction have been rather fruitless) but I think the era of dramatic improvements in the numerology are basically over, I’m afraid, absent a radical new way to perform these estimates (or else a new way to perform Type IV and Type V estimates, which would let us get past the annoying ")#mi("\\sigma > 1/10")#text(" barrier).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237124")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("1. Perhaps the combinatorial lemma should be somehat modified (as well as the definitions of types) to improve the estimate of the “modified type I”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00dc47e8e330cb19d37e5ea9e016efa5bb9b2fb9240b2a171290a849c3a05d9c-d497eb896c681f5a9ba63c6cd8d9a29f038f9088bf1743cc2b7a1649337f3f59.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian Rothbach")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237217")[#strong[#text("Brian Rothbach")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("I think you can gain a little bit by replacing the ")#mi("\\sigma")#text(" in the combinatorial lemma with two parameters: instead of using type II estimates on the interval ")#mi("[1/2-\\sigma,1/2+\\sigma]")#text(", use them on the interval ")#mi("[1/2-\\sigma_1,1/2+\\sigma_2]")#text(". The restraint on sigma becomes ")#mi("3\\sigma_1+2\\sigma_2>=1/2")#text(" (and that the \\sigma’s are positive), by the exact same argument as before, but now you can optimize the two parameters separately to improve the parameters for type I estimates.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237223")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("Suppose we are looking at the situation where we have two numbers whose sum is 1 (which is what happens both in the Type I and Type II cases). Thus, one number is ")#mi("1/2-\\sigma")#text(" and the other number is ")#mi("1/2+\\sigma")#text(". Hence, the extra generality of an uneven interval is no help in Type I/II situations. If you optimize on one end, you must have the same ")#mi("\\sigma")#text(" on the other side.")

#text("You could possibly introduce another type of summation where the boundaries are uneven. If you want to do so, consider the following main case when there are five equal numbers ")#mi("t_1=\\cdots =t_5=1/5")#text(". There are only so many ways to combine them all. Combining them into two numbers either gives ")#mi("2/5,3/5")#text(" or ")#mi("1/5,4/5")#text(" or ")#mi("0,1")#text(". The last doesn’t work, for a number of reasons (lack of a Siegel-Walfisz theorem, lack of picking divisors in appropriate intervals, etc…). The first one is better than the second, and so ")#mi("2/5,3/5")#text(" is the best option, combinatorially, when combining into two numbers.")

#text("Now you can work out what happens when trying to combine them into three numbers, etc…")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00dc47e8e330cb19d37e5ea9e016efa5bb9b2fb9240b2a171290a849c3a05d9c-d497eb896c681f5a9ba63c6cd8d9a29f038f9088bf1743cc2b7a1649337f3f59.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian Rothbach")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237234")[#strong[#text("Brian Rothbach")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("Ah, I see. I was misinterpreting which of the Type estimates correspond to cases in the combinatorial lemma, and the estimates that are causing difficulties are exactly the ones where the unequal intervals don’t help.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237226")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("Brian,")

#text("By the way, I proposed something like that, consisting of a new Type consisting of a convolution of three sequences: the biggest one nonsmooth, and the smaller ones both smooth. In terms of the case I gave above, this would correspond to the decomposition ")#mi("3/5, 1/5,1/5")#text(". The analysis would probably follow the same path as for Type I sums, except we would replace ")#mi("\\beta")#text(" everywhere by a convolution of two smooth sequences (coming from the Heath-Brown decomposition). The trouble would then be to decouple that convolution in a reasonable manner (which unfortunately seems unlikely).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237149")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("Initial calculation got ")#mi("k_0")#text("=722 for (280/3,80/3), for ")#mi("\\varpi")#text(" = 3/280-2.9850449068186893*10-5, ")#mi("\\delta^{\\prime}")#text("=0.03373456067881111, and ")#mi("A")#text("=618.7045821541182.")

#text("Hopefully it does not violate some constraints.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237150")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("This will probably be close to the truth once we figure out how to relax the condition of ")#mi("x^\\delta")#text("-smoothness we are currently using (probably by developing some sort of notion of “double dense divisbility”) but right now we are forced to take ")#mi("\\delta=\\delta^{\\prime}")#text(" in order to get the smoothness (which makes kappa_3 vanish and renders A irrelevant), which will probably make k_0 increase a little bit (but it should still be better than what we had before).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35598924aba40ab439ff5ed4cb5ff894b36068a7207a2d5c6df25c5177e5329b-140b0078e2139ec50e93f18d1fbcc653514264b2e9cdbcc86f776076a297e0c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hannes")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237160")[#strong[#text("Hannes")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("For ")#mi("\\delta = \\delta^{\\prime}")#text(" I think ")#mi("k_0 = 873, \\varpi = 3/280 - 0.1147/10^2")#text(" works. This is a ")#mi("k_0")#text(" for which Engelsma’s bound has been improved.")

#text("Tao: In a previous post you write ")#mi("\\delta = \\tilde\\delta")#text(" instead of ")#mi("\\delta = \\delta^{\\prime}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237262")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("Thanks for this! This illustrates the fair amount of gain we could extract if we could relax back from ")#mi("x^\\delta")#text("-smoothness to something more like dense divisibility, then we would get something much closer to xfxie’s computed values of 720. I’ll try to see if the arguments for the Type I sums can be recast in terms of something like dense divisibility.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237181")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("The maple file is here: ")#link("http://www.cs.cmu.edu/~xfxie/sol_872.mpl")[#text("http://www.cs.cmu.edu/~xfxie/sol_872.mpl")]

#text("The script is based on the maple script by Terence — just added a new constraint ")#mi("\\delta^{\\prime} = \\delta")#text(".")

#text("This file stands for ")#mi("k_0")#text("=872 for (280/3,80/3), as ")#mi("\\varpi= 3/280-4992.469008926887/10^5")#text(", ")#mi("A")#text("=927.8564427404251.")

#text("Hopefully this one will be slightly more correct.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35598924aba40ab439ff5ed4cb5ff894b36068a7207a2d5c6df25c5177e5329b-140b0078e2139ec50e93f18d1fbcc653514264b2e9cdbcc86f776076a297e0c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hannes")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237185")[#strong[#text("Hannes")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("Unfortunately I think ")#mi("\\varpi > 0")#text(" is not satisfied in this case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237191")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("@Hannes, Thanks for pointing out the error. Now I get more sense in setting parameters.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237151")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("A refined result is ")#mi("k_0")#text("=720 for (280/3,80/3), for ")#mi("\\varpi")#text(" = 3/280-1.1591660703532822*10-5, ")#mi("\\delta^{\\prime}")#text("=0.006805137872659862, and ")#mi("A")#text("=369.2931543045393 .")

#text("Seems A is quite flexible, A=369 also works.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237235")[#strong[#text("The quest for narrow admissible tuples | Secret Blogging Seminar")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")]

#text("[…] guest post summarizing the current state of affairs. This task is made easier by Tao’s recent progress report on the polymath project to sharpen Zhang’s result on bounded gaps between primes. If you […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237306")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2013")])]

#text("I’m recording here some notes on double dense divisibility that almost allow us to recover the near-optimal numerology of the Pintz sieve (and in particular to not have to force ")#mi("\\delta^{\\prime}=\\delta")#text(").")

#text("Recall that a number ")#mi("n")#text(" is said to be ")#mi("x^\\delta")#text("-densely divisible if, for every ")#mi("1 \\leq R \\leq n")#text(", one can find a factor of ")#mi("n")#text(" in the range ")#mi("[x^{-\\delta} R, R]")#text(". Let us say that ")#mi("n")#text(" is doubly ")#mi("x^\\delta")#text("-densely divisible if, for every ")#mi("1 \\leq R \\leq n")#text(", one can find a factor of ")#mi("n")#text(" in ")#mi("[x^{-\\delta} R,R]")#text(" which is itself ")#mi("x^\\delta")#text("-densely divisible. Clearly double ")#mi("x^\\delta")#text("-dense divisibility implies ")#mi("x^\\delta")#text("-dense divisibility; also, being ")#mi("x^\\delta")#text("-smooth implies double ")#mi("x^\\delta")#text("-dense divisibility because ")#mi("x^\\delta")#text("-smooth numbers are ")#mi("x^\\delta")#text("-densely divisible, and any factor of a ")#mi("x^\\delta")#text("-smooth number is again ")#mi("x^\\delta")#text("-densely divisible.")

#text("Note though that double dense divisibility is stronger than single dense divisibility. For instance, if ")#mi("p,q")#text(" are primes of size about ")#mi("x^{1/3}, x^{2/3}")#text(" respectively, then the product ")#mi("pq")#text(" is ")#mi("x^{1/3+\\varepsilon}")#text("-densely divisible, but not doubly ")#mi("x^{1/3+\\varepsilon}")#text("-densely divisible.")

#text("In ")#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/")[#text("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/")]#text(" it was shown that if ")#mi("\\delta \\leq \\delta^{\\prime}")#text(" and ")#mi("n")#text(" was a squarefree ")#mi("x^{\\delta^{\\prime}}")#text("-smooth number with")

#mi("\\prod_{p|n: p < x^\\delta} p > x^{\\delta^{\\prime}-\\delta}")

#text("then ")#mi("n")#text(" was ")#mi("x^\\delta")#text("-densely divisible. Indeed, to get a prime factor of ")#mi("n")#text(" in the interval ")#mi("[x^{-\\delta} R, R]")#text(" one multiplies together all the big (")#mi("\\geq x^\\delta")#text(") factors of ")#mi("n")#text(" together until just before one exceeds ")#mi("R")#text(" (or one runs out of big factors), and then multiplies together small factors until one enters the interval ")#mi("[x^{-\\delta} R, R]")#text(".")

#text("An iteration of this argument shows that if we instead assume the stronger condition")

#mi("\\prod_{p|n: p < x^\\delta} p > x^{2(\\delta^{\\prime}-\\delta)}")

#text("then ")#mi("n")#text(" is doubly ")#mi("x^\\delta")#text("-densely divisible. Indeed if one runs the previous argument to find a factor ")#mi("d")#text(" of ")#mi("n")#text(" in ")#mi("[x^{-\\delta} R, R]")#text(", one will find that there are still enough small prime factors left over in ")#mi("n/d")#text(" to make ")#mi("n/d")#text(" ")#mi("x^\\delta")#text("-densely divisible by the previous argument (indeed, ")#mi("n/d")#text(" will either be ")#mi("x^\\delta")#text("-smooth, or else be such that ")#mi("\\prod_{p|n/d: p < x^\\delta} p > x^{\\delta^{\\prime}-\\delta}")#text(". Replacing ")#mi("R")#text(" with ")#mi("n/R")#text(" and ")#mi("d")#text(" with ")#mi("n/d")#text(" we then obtain the claim.")

#text("Let ")#mi("MPZ^{\\prime\\prime}[\\varpi,\\delta]")#text(" be the same conjecture as ")#mi("MPZ^{\\prime}[\\varpi,\\delta]")#text(" defined in Conjecture 2 of ")#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/")[#text("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/")]#text(" , but with dense divisibility replaced by double dense divisibility. We can then repeat the proof of Theorem 5 of that post with only minor changes and obtain that ")#mi("MPZ^{\\prime\\prime}[\\varpi,\\delta]")#text(" implies ")#mi("DHL[k_0,2]")#text(" assuming the hypotheses stated in that theorem are obeyed, except that the quantity ")#mi("(\\delta^{\\prime}-\\delta)/2")#text(" in the definition of ")#mi("\\tilde \\theta")#text(" is replaced instead with ")#mi("\\delta^{\\prime}-\\delta")#text(". (Amusingly, this cancels out an improvement of Gergely Harcos made in the comments to that post in which he had inserted the factor of ")#mi("1/2")#text(" in the theorem.) Thus the Maple verification code for double dense divisibility now takes the following form:")

#raw("\nk0 := [INSERT VALUE HERE];\nvarpi := [INSERT VALUE HERE];\ndelta := [INSERT VALUE HERE];\ndeltap := [INSERT VALUE HERE];\nA := [INSERT VALUE HERE];\ntheta := deltap / (1/4 + varpi);\nthetat := ((deltap - delta) + varpi) / (1/4 + varpi);\ndeltat := delta / (1/4 + varpi);\nj := BesselJZeros(k0-2,1);\neps := 1 - j^2 / (k0 * (k0-1) * (1+4*varpi));\nkappa1 := int( (1-t)^((k0-1)/2)/t, t = theta..1, numeric);\nkappa2 := (k0-1) * int( (1-t)^(k0-1)/t, t=theta..1, numeric);\nalpha := j^2 / (4 * (k0-1));\ne := exp( A + (k0-1) * int( exp(-(A+2*alpha)*t)/t, t=deltat..theta, numeric ) );\ngd := (j^2/2) * BesselJ(k0-3,j)^2;\ntn := sqrt(thetat)*j;\ngn := (tn^2/2) * (BesselJ(k0-2,tn)^2 - BesselJ(k0-3,tn)*BesselJ(k0-1,tn));\nkappa3 := (gn/gd) * e;\neps2 := 2*(kappa1+kappa2+kappa3);\n# we win if eps2 < eps\n")

#text("Next, I claim that the MPZ estimate established in the previous comment ")#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237087")[#text("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237087")]#text(" for ")#mi("\\frac{280}{3} \\varpi + \\frac{80}{3} \\delta < 1")#text(" under the assumption of ")#mi("x^\\delta")#text("-smoothness of the original moduli, also works under the weaker hypothesis of double ")#mi("x^\\delta")#text("-dense divisibility. This was already known for the Type II and Type III estimates (which only need single dense divisibility) so it's just a matter of checking that things are OK for the Type I estimate. But by construction, the quantities ")#mi("q_1 r, q_2 r")#text(" in the Type I argument are doubly ")#mi("x^\\delta")#text("-divisible, so one can arrange matters so that ")#mi("q_1,q_2")#text(" are singly ")#mi("x^\\delta")#text("-divisible while still staying in the same intervals as before. (There is also the point that one has to remove all the tiny prime factors of ")#mi("q_1,q_2")#text(", which can affect dense divisibility slightly, but the net effect here is ")#mi("x^{o(1)}")#text(" and can be neglected.) Thus we can obtain the factorisation ")#mi("q_2 = s_2 t_2")#text(" needed in the above comment without difficulty.")

#text("So, one just has to optimise for ")#mi("k_0")#text(" in the above code subject to the condition ")#mi("\\frac{280}{3} \\varpi + \\frac{80}{3} \\delta < 1")#text(", which should bring us very close to xfxie's calculation of 720 or so.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237313")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2013")])]

#text("Very interesting! For clarity I would change “make ")#mi("n/d")#text(" ")#mi("x^\\delta")#text("-densely divisible” to “ensure that ")#mi("n/d")#text(" is ")#mi("x^\\delta")#text("-densely divisible, namely either ")#mi("n/d")#text(" is ")#mi("x^\\delta")#text("-smooth or its ")#mi("x^\\delta")#text("-smooth part exceeds ")#mi("x^{\\delta^{\\prime}-\\delta}")#text("“. I know you are very busy, but it would be nice and useful to have an updated version of the earlier treatment (")#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/")[#text("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/")]#text("), because all the improvements are now scattered in the comments. Perhaps it could be a post entitled “The distribution of primes in doubly densely divisible moduli”?")

#emph[#text("[Corrected, thanks. I’ll probably write up a post of this sort this weekend. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237315")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2013")])]

#text("Great. Seems it is possible to get ")#mi("k_0=722")#text(" under the new condition. Here is the maple code for validation:")

#link("http://www.cs.cmu.edu/~xfxie/sol_722.mpl")[#text("http://www.cs.cmu.edu/~xfxie/sol_722.mpl")]

#text("Hopefully this time the solution is correct :).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237319")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2013")])]

#text("Seems I was too rush again, ")#mi("k_0")#text(" can be 721:")

#link("http://www.cs.cmu.edu/~xfxie/sol_721.mpl")[#text("http://www.cs.cmu.edu/~xfxie/sol_721.mpl")]

#text("Actually, I am using TeamView in my android phone to connect to my macbook. Somebody might try to further improve the result using the code:")

#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0table.html")[#text("http://www.cs.cmu.edu/~xfxie/project/admissible/k0table.html")]

#text("Just notice there is a slight change in the maple code ( (deltap – delta) instead of (deltap – delta)/2 for thetat), as mentioned by Terence above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237324")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2013")])]

#text("Further search returned the same 720:")

#link("http://www.cs.cmu.edu/~xfxie/sol_720.mpl")[#text("http://www.cs.cmu.edu/~xfxie/sol_720.mpl")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237331")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2013")])]

#text("Before the termination condition satisfied, a new solution k0=719 was found.")

#link("http://www.cs.cmu.edu/~xfxie/sol_719.mpl")[#text("http://www.cs.cmu.edu/~xfxie/sol_719.mpl")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237332")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2013")])]

#text("Sorry, the result 719 is wrong, after I managed to remotely validate using maple.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237337")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2013")])]

#text("Just found the reason. As I tried to verify the correctness of the solution ")#mi("k_0=720")#text(" using maple, its output (a negative value for eps2 – eps) overwrote the file that the search algorithm was using, and thus fooled the algorithm.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237490")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2013")])]

#text("I confirmed this value below (with slightly cleaner and more optimal parameters). So it seems that we have prime gaps of size at most 5414 infinitely often.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237339")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2013")])]

#text("Is the coefficient ")#mi("2")#text(" in the exponent ")#mi("2 (\\delta^{\\prime} - \\delta)")#text(" the minimal one required to get ")#mi("n")#text(" doubly ")#mi("x^{\\delta}")#text(" – densely divisible?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237323")[#strong[#text("Richard Elwes – Carnival of Mathematics 100")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2013")]

#text("[…] • Let’s start with the biggest mathematical news story at the moment. Back in May, Yitang Zhang announced a proof of the following great breakthrough: there are infinitely many pairs of primes which are at most 70,000,000 (= H) apart. Terry Tao reports on subsequent huge success: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0abc530355ca859abdf45e1983c5d0aa71a49963c398110ff56153a766213e9a-9562b5bf2e84d8146d1785c2938ab925d2df24c41f84c2d978f6cd4abda9612a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Reem")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237367")[#strong[#text("Daniel Reem")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2013")])]

#text("Following the “high level” spirit of this post, I wonder whether some geometric arguments can be used in order to improve the analysis (and in particular, some parameters). Let me give a more concrete example. It can be seen that the Cauchy-Schwarz inequality appears over and over again")#linebreak()#text(" in the analysis. However, it is used as it is, in an “analytic manner”, without any attempt to try to use its full power by estimating the angle between the involved vectors. Doing so may indeed be a non-trivial task, but if one can somehow show (at least in certain cases) that the vectors are close to be orthogonal, or at least the angle between them is bounded away from 0 and pi, then this is expected to improve the outcome.")

#text("P.S. It is very interesting to see how much progress has been made in a so short period.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237489")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2013")])]

#text("Just a confirmation that xfxie’s ")#mi("k_0=720")#text(" seems correct, and this yields prime gaps of size ")#mi("H=5414")#text(" (cf. ")#link("http://math.mit.edu/~primegaps/tuples/admissible_720_5414.txt")[#text("http://math.mit.edu/~primegaps/tuples/admissible_720_5414.txt")]#text("). Using ")#mi("\\varpi=3/280-1/62000")#text(", ")#mi("\\delta=(3-280\\varpi)/80")#text(", ")#mi("\\delta^{\\prime}=1/100")#text(", ")#mi("A=252")#text(", I am getting ")#mi("\\epsilon\\approx 1.24\\times 10^{-6}")#text(", ")#mi("2\\kappa_1\\approx 1.02\\times 10^{-7}")#text(", ")#mi("2\\kappa_2\\approx 2.96\\times 10^{-11}")#text(", ")#mi("2\\kappa_3\\approx 7.33\\times 10^{-9}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237562")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2013")])]

#text("Just a comment about the combinatorics part of the program.")

#text("The Type III sums take advantage of the case where there are three somewhat large scale, smooth functions, at the cost of working with bounds on ")#mi("K_3")#text(". We can, instead break things into cases as follows:")

#text("Let ")#mi("\\psi_P")#text(" be the largest smooth function in the Heath-Brown decomposition, with scale ")#mi("1\\ll P\\ll x")#text(". (Perhaps this can be chosen in the Linnik decomposition, if done correctly.) Write ")#mi("P = x^{t}")#text(". If we have ")#mi("t\\geq 1/2+2\\varpi")#text(" we are in Type 0. If ")#mi("1/2-2\\varpi \\leq t \\leq 1/2+2\\varpi")#text(" we are in Type II, but with one of the components smooth (which we won’t use). If ")#mi("2\\sigma \\leq t \\leq  1/2-2\\varpi")#text(", then we are in Type I, but with the smallest component smooth. Finally, if ")#mi("t\\leq 2\\sigma")#text(" we are in Type I/II.")

#text("On the positive side, in this new breakdown ")#mi("\\sigma")#text(" can be arbitrarily small. On the negative side, we are ignoring some extra information (which allows for the creation of the Type III sums). On the positive side again, these new sums are much easier to compute.")

#text("Thus, we still do the Type 0,I,II computations, but also do a Type I computation with ")#mi("\\beta")#text(" smooth and ")#mi("x^{2\\sigma}\\ll N")#text(" (let’s call this new sum, Type IV for now). If I computed correctly, the improved bound from the (first) Type I computations, modified to Type IV, yields the bound ")#mi("4\\varpi +\\frac{1}{2}\\mu+\\frac{1}{2}\\delta < \\sigma")#text(". This seems like a much better border than between Type I and Type III.")

#text("(Note: This inequality was worked on scratch paper, fairly quickly. Others may want to rework it, to double check that the Type I/IV border is better than the Type I/III border.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237566")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2013")])]

#text("If the work above holds, we get the new inequality (which barely misses the Type II bound):")

#mi("76\\varpi + 16\\delta < 1")#text(".")

#text("The work above followed the Type I level 1 computations, but without the last use of Cauchy-Schwarz, and thus needing only to bound ")#tao-math("\\left|\\sum_{n}\\psi_N(n)\\Phi(h,q_1,q_2;n)\\right|", block: false)#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237572")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2013")])]

#text("You say: if ")#mi("2\\sigma \\leq t \\leq 1/2-2\\varpi")#text(", then we are in Type I, but with the smallest component smooth. I don’t see this. For example, there can be several tiny ")#mi("t")#text("‘s which correspond to Möbius convolution factors restricted to small dyadic intervals. Also, Zhang’s argument (and the one presented here) is based on grouping together certain convolution factors in order to create arithmetic functions with fairly large supports and possibly with the requirement of smoothness as well. I don’t see how to achieve that with your classification based on a single ")#mi("t")#text(" only. If you have a new way to treat the whole problem (new types of sums, and new estimates for them), then provide all the details so that we can verify them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237575")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2013")])]

#text("To clarify, if ")#mi("2\\sigma\\leq t\\leq 1/2-2\\varpi")#text(", we are in Type I only in the sense that we are looking at a sum with two convolved sequences ")#mi("\\alpha,\\beta")#text(" (where ")#mi("\\beta")#text(" is the single smooth component corresponding to ")#mi("t")#text(", and ")#mi("\\alpha")#text(" is the convolution of the rest of the components). But we are *not* in Type I in the sense that the sequences have scale ")#mi("x^{1/2+\\sigma},x^{1/2-\\sigma}")#text(". Rather, the scales are (at worst) ")#mi("M=x^{1-2\\sigma}, N=x^{2\\sigma}")#text(". That’s why I called it Type IV.")

#text("So, we are still grouping things together. We just leave the biggest smooth piece alone. The tiny ")#mi("t")#text("‘s, which are not smooth, all get sucked into the ")#mi("\\alpha")#text(". I hope this clarifies things.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237577")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2013")])]

#text("Let us focus on the ranges ")#mi("M=x^{1-2\\sigma}")#text(" and ")#mi("N=x^{2\\sigma}")#text(", and let ")#mi("\\beta")#text(" be smooth. How do you prove (42) from the earlier thread (")#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/")[#text("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/")]#text(")?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237584")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2013")])]

#text("I was following the ideas from the even earlier thread (")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")]#text("). First, we replace ")#mi("\\beta(n)\\beta(n+kr)")#text(" by ")#mi("\\psi_{N}(n)")#text(" (a smooth function). We combine the two exponential terms ")#mi("e_{r}(\\frac{a_r h}{nq_1 q_2})")#text(" and ")#mi("e_{q_1}(\\frac{b_{q_1}h}{nrq_2})")#text(" into a single exponential. Then we use Corollary 10 from that thread, and bound things just as is done there (but since we never had to do the squaring, from the Cauchy-Schwarz, things work out a bit better).")

#text("So, if I did things right, I get")

#tao-math("\\left|\\sum_ n \\psi_{N}(n)\\Phi(h,q_1,q_2;n)\\right| \\ll x^{o(1)}(QR^{1/2}+NHR^{-1})|", block: false)

#text("by using Corollary 10. Here, we have ")#mi("d_1:=rq_2")#text(" and ")#mi("d_2:=q_2")#text(". So ")#mi("(d_1,d_2)=1")#text(". We again bound ")#mi("(c_2,d_2)")#text(" by ")#mi("d_2")#text(", and ")#mi("(c_1,q_1)")#text(" by ")#mi("(c_1,r)q_1")#text(". However, here ")#mi("(c_1,r)=(h,r)")#text(" can be approximated by ")#mi("H")#text(" rather than ")#mi("HQ")#text(".")

#text("———————-")

#text("To establish the needed bound, we now need to establish two inequalities. The first is")

#mi("HQ^3 R^{1/2} \\ll x^{-2\\epsilon+o(1)}Q^{2}N")#text(".")

#text("Recalling that ")#mi("H=x^{\\epsilon}Q^2 R/M")#text(", ignoring ")#mi("\\epsilon")#text("s, we plug in and find that we need (contrary to my earlier computation, by the way, I accidentally dropped one power of ")#mi("Q")#text("):")

#mi("(QR)^{3} \\ll x(R/N)^{3/2}N^{3/2}")#text(".")

#text("This leads to")

#mi("\\frac{3}{2}+6\\varpi \\leq 1-\\frac{3}{2}\\mu-\\frac{3}{2}\\delta+\\frac{3}{2}(2\\sigma)")

#text("which simplifies to")

#mi("\\frac{1}{6}+2\\varpi + \\frac{1}{2}\\mu+\\frac{1}{2}\\delta \\leq \\sigma")#text(".")

#text("So, unfortunately, we have $\\sigma \\geq 1/6$ here. However, there is some hope that this inequality can be improved as we apply the improvements obtained in the Type I case.")

#text("Sorry for dropping that extra ")#mi("Q")#text(", and thanks for making me double check everything.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237586")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2013")])]

#text("I think this is an interesting direction that merits attention.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237578")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2013")])]

#text("You also say: if ")#mi("t\\leq 2\\sigma")#text(" we are in Type I/II. Why is that?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237583")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2013")])]

#text("I’m typing up my answer to your question above, but I can answer this one easily.")

#text("If all ")#mi("t")#text("‘s are ")#mi("\\leq 2\\sigma")#text(", then a greedy algorithm allows us to get into the Type I/II situation. (It is the same argument used in the original combinatorics.) We don’t leave the biggest ")#mi("t")#text(" alone in this case, but force ")#mi("\\alpha,\\beta")#text(" to have scales as close as possible (and neither are smooth anymore).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237585")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2013")])]

#text("The assumption ")#mi("t\\leq 2\\sigma")#text(" is initially made for the smooth convolution factors only, so I guess you are implicitly assuming that the rest of the ")#mi("t")#text("‘s are automatically at most ")#mi("2\\sigma")#text(". This can be achieved, but it requires (e.g. when working with the Heath-Brown decomposition) that ")#mi("\\sigma")#text(" remains above ")#mi("1/K")#text(". Here ")#mi("K")#text(" is as in ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")]#text(". I need to leave the computer now, but it would be nice to get an improved and simplified argument along these lines.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237587")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2013")])]

#text("You can choose ")#mi("K")#text(" as large as you like, so this issue causes no problems. But yes you understood correctly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237588")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2013")])]

#text("I guess to improve and simplify the argument, we would simply say: Let ")#mi("\\psi")#text(" be the sequence in the Heath-Brown decomposition, where if we write the scale as ")#mi("x^{t}")#text(", then ")#mi("t")#text(" is the largest real number that occurs. Letting ")#mi("K")#text(" be big enough, we only assume smoothness for ")#mi("\\psi")#text(" when ")#mi("t\\geq 2\\sigma")#text(" (for ")#mi("\\sigma")#text(" [and hence ")#mi("K")#text("] to be optimized later, using inequalities involving only fixed objects).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73c0e3d57b00886275d80464e248e1bcebafdecaa7b53d9714bdc35de9b99145-e014b284c49640ea982cdd01e62212e14ba40c4e3a909d0cc69bec699d0aa292.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Improved bounds on Prime number gaps | On the learning curve...")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237631")[#strong[#text("Improved bounds on Prime number gaps | On the learning curve...")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2013")])]

#text("[…] and his team steadily managed to improve the bound. Tao has already knitted a nice and detailed summary on the progress. As of last week, the proven gap was , but now the updated gap could be as small as (which is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237634")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2013")])]

#text("Just for fun, I plugged in what would happen in the Type I-Level 6 computations if we used the worse case bounds")

#mi("N\\approx x^{2\\sigma},\\ R\\approx x^{2\\sigma-\\delta},\\ Q\\approx x^{2\\varpi +\\frac{1}{2}-2\\sigma+\\delta}")

#text("which are what arise when trying to do the new Type IV computations with scales ")#mi("M,N")#text(" nearly ")#mi("x^{1-2\\sigma},x^{2\\sigma}")#text(".")

#text("In this case, we obtain the inequality")

#mi("\\frac{1}{8} + 7\\varpi + 2\\delta<\\sigma")#text(".")

#text("Note that this is obtained by following the Type I-Level 6 ideas in the new Type IV situation, *without* taking advantage of the fact that ")#mi("\\beta")#text(" is smooth. So there has to be some room for improvement here, but it would have to be in the constant ")#mi("\\frac{1}{8}")#text(" to improve the current record.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237746")[#strong[#text("Parents of Invention | DeepWeave")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2013")]

#text("[…] find shorter and more elegant ways to achieve it. As of June 30, a collaborative project hosted by Terence Tao had pushed H down to 12,006 and provisionally as low as 6,996. They already know that the path […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The distribution of primes in doubly densely divisible moduli | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237791")[#strong[#text("The distribution of primes in doubly densely divisible moduli | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2013")])]

#text("[…] with respect to the parameter (which, using this constraint, gives a value of as verified in comments, which then implies a value of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237796")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2013")])]

#text("New thread is up: ")#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/")[#text("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/")]

#text("As requested, the latest Type I, II, and III arguments are presented. The Type III arguments turned out to have a few technical twists that were not anticipated in the previous writeups, but fortunately this only affected some lower order terms and the numerology is still basically unchanged. In any case the Type III estimates are currently quite far from being the critical obstacle towards further improvements of the estimates. (I would still recommend the sketchier arguments given in this current post than the more detailed arguments in the most recent post if one just wants to get a sense of how the arguments work, and to play with the numerology.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237824")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("Thank you! I will study it in the coming days.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-238007")[#strong[#text("The p-group fixed point theorem | Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2013")]

#text("[…] theorem on bounded gaps between primes (although my understanding is that this step is unnecessary just to establish the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-238200")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2013")])]

#text("Some typos:")

#text("1. “an interval ")#mi("[-p_{m+\\lfloor k_0-2/2\\rfloor}, \\ldots, -p_{m+1},-1,+1,p_{m+1},\\ldots,p_{m+\\lfloor k_0-1/2 \\rfloor}]")#text("” should be “an interval ")#mi("[-p_{m+\\lfloor k_0-2/2\\rfloor}, \\ldots, p_{m+\\lfloor k_0-1/2 \\rfloor}]")#text("“.")

#text("2. “optimised in later” should be “optimised later”.")

#text("3. In the two displays following “the numerator becomes”, the weight ")#mi("\\lambda_{d_1}\\lambda_{d_2}")#text(" is missing, but perhaps intentionally for the sake of exposition?")

#text("4. “Polyá-Vinogradov” should be “Pólya-Vinogradov”.")

#text("5. In the display following “expression can be rearranged as”, the condition ")#mi("mn=a_{q_1}\\ (q)")#text(" should be ")#mi("mn=a_{q_1}\\ (q_1)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d841279bde782b1cb2e7ccda53cc7961fc14ed2c90a8bc7731bb0c74350c951-eee14fee51eb44b15d62bce8c494cea0959e98139d76d125f021dd3452b6c425.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Batch Auctions, US/EU Swap Reg Deal, and Primal Madness « Pink Iguana")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-238251")[#strong[#text("Batch Auctions, US/EU Swap Reg Deal, and Primal Madness « Pink Iguana")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2013")])]

#text("[…] Internet race in a project called Polymath8. A recent e-mail from Tao announced the latest result: a gap of no more than 12,006 numbers between primes, and a provisional gap of only 6,966—conditi…. The details are in the link […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d787948edf428911d8b15ad79b5f5085d83001cfe16cd3db1271d4701eef37f7-a4fe3e4cef12b0aa6c1709a44ed2b22bfbaf63fff877ed122b527744c8866059.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Maulhardt")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-238300")[#strong[#text("Martin Maulhardt")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2013")])]

#text("Dear Mr Tao,")#linebreak()#text(" I’ve followed and admired your work for a long time and I’m pleased that you mentioned this subject on Zhang’s theorem.")#linebreak()#text(" In connection with this theorem on the difference between two consecutive prime numbers, I wanted to share with you a result I proved recently: “There are infinitely many terns of consecutive primes such that the difference between the two second ones is smaller or equal than the difference between the first two ones.” For example (7,11,13).")#linebreak()#text(" I’d be honored if you want to read more on my paper that I posted on my website (")#link("http://martinmaulhardt.com/?page_id=6")[#text("http://martinmaulhardt.com/?page_id=6")]#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-238305")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2013")])]

#text("Your result follows from Zhang’s theorem: if ")#mi("d_n:=p_{n+1}-p_n")#text(" is the difference between the ")#mi("n")#text("-th prime and the next one, then for any ")#mi("N>0")#text(" the assumption that ")#mi("d_n")#text(" is increasing for ")#mi("n>N")#text(" would imply that ")#mi("d_n")#text(" tends to infinity (because they tend to infinity on average), contrary to Zhang’s theorem. In fact Erdős and Turán proved already in 1948 that ")#mi("d_{n+1}-d_n")#text(" changes sign infinitely often (see (7) here: ")#link("http://www.ams.org/journals/bull/1948-54-04/S0002-9904-1948-09010-3/S0002-9904-1948-09010-3.pdf")[#text("http://www.ams.org/journals/bull/1948-54-04/S0002-9904-1948-09010-3/S0002-9904-1948-09010-3.pdf")]#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d787948edf428911d8b15ad79b5f5085d83001cfe16cd3db1271d4701eef37f7-a4fe3e4cef12b0aa6c1709a44ed2b22bfbaf63fff877ed122b527744c8866059.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Maulhardt")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-238332")[#strong[#text("Martin Maulhardt")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2013")])]

#text("Dear Gergely,")#linebreak()#text(" Thanks for your valuable post and I have to admit that I was not aware of the result of Erdos and Turan. So my result is not new as I first thought. But revising the proof that these great mathematicians had constructed I have to say that mine is completely different and simpler.")#linebreak()#text(" Of course I have not the slightest pretension to compare myself with either of these great mathematicians by saying that my proof is simpler and different.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-238405")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2013")])]

#text("A survey of the known results about the difference ")#mi("d_n")#text(" between consecutive primes can be found in this recent article of Pintz ")#link("http://arxiv.org/abs/1305.6289")[#text("http://arxiv.org/abs/1305.6289")]#text(" (see in particular Section 2.4).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d787948edf428911d8b15ad79b5f5085d83001cfe16cd3db1271d4701eef37f7-a4fe3e4cef12b0aa6c1709a44ed2b22bfbaf63fff877ed122b527744c8866059.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Maulhardt")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-238412")[#strong[#text("Martin Maulhardt")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2013")])]

#text("Thanks very much!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8: Writing the paper, II | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-243642")[#strong[#text("Polymath8: Writing the paper, II | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2013")])]

#text("[…] (For a discussion of the terminology, and for a general overview of the proof strategy, see this previous progress report on the Polymath8 project.) This post can also contain any other discussion pertinent to any […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b557db8f68498eedd7b25bfed35d52da3ad583ac547357b066088d3d8eda85a4-e4881e13d79071708601be5fe67458b229568f2d725c1ac40933e28006270d8e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zeggari")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-272237")[#strong[#text("zeggari")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2014")])]

#text("i am not a matimatician expert but i have some ideas:")#linebreak()#text(" let S the count of the digit of a number. EX S(99)=S(18)=S(9)=9.")#linebreak()#text(" S(i) must be between [2;9], i>1.")#linebreak()#text(" to verify if two number’s are not twin:")#linebreak()#text(" “IF S(p)*S(p+2) different to 8 then p and p+2 are not twin prime numbers”")#linebreak()#text(" note that")#linebreak()#text(" 1)S(p+i)=S(S(p)+i)")#linebreak()#text(" 2)S(i)*S(j)=S(i*j)")#linebreak()#text(" EX:")#linebreak()#text(" S(111413131313131343534231331663534342442442442355343434351141879678685757575756464545353422211109)=6 and S(111413131313131343534231331663534342442442442355343434351141879678685757575756464545353422211111)=6+2")#linebreak()#text(" S(6*8)=S(48)=S(12)=S(3)=3 fifferent to 8 . this two numbers are not twin prime numbers (vérified by hand on less then 3 minutes).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b557db8f68498eedd7b25bfed35d52da3ad583ac547357b066088d3d8eda85a4-e4881e13d79071708601be5fe67458b229568f2d725c1ac40933e28006270d8e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zeggari")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-272239")[#strong[#text("zeggari")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2014")])]

#text("Problem of over bound of the web page")#linebreak()#text(" this is a new exemple beacouse i loste the first number")#linebreak()#text(" EX:")#linebreak()#text(" S(111413131313131343534231331663534342442442442355343434 351141)=7 and S(111413131313131343534231331663534342442442442355343434 351143)=7+2")#linebreak()#text(" S(7*9)=S(63)=S(9)=9 . this two numbers are not twin prime numbers")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b557db8f68498eedd7b25bfed35d52da3ad583ac547357b066088d3d8eda85a4-e4881e13d79071708601be5fe67458b229568f2d725c1ac40933e28006270d8e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zeggari")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-272268")[#strong[#text("zeggari")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2014")])]

#text("sorry, i think that this means simply if we look to test p1 and p2 if they are not twin prime numbers you must devide first p1/3 then p2/3 and so on.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcce52dd50a93956dfef2a36fc14ebd28d8b045b7548794dea14bf0f7702d0eb-452786fe4a33d26d1588035ad1265d94c9c110f7259698ad39358ac48f8291cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 王晓明")]], [#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-446852")[#strong[#text("王晓明")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2014")])]

#text("There are infinitely many primes P and P + 2 is a prime number")#linebreak()#text(" The twin prime formula Using the criterion of prime numbers, we can get the following conclusions:")

#text("“if the natural numbers q and q+2 cannot be any less than\\sqrt{q+2} prime divisibility, then q and q+2 is prime.。")#linebreak()#text(" This is because a natural numbern is prime if and only if it can’t be any less than other prime divisibility on\\sqrt{n} .")#linebreak()#text(" Using mathematical language expresses the conclusions above, is:")#linebreak()#text(" There is a group of natural numberb_{1}, b_{2} \\cdot , b_{k} making")

#text("q=p_{1}m_{1}+b_{1}=p_{2}m_{2}+b_{2}=\\dots=p_{k}m_{k}+b_{k} \\qquad \\qquad \\qquad \\cdots \\qquad (1)")

#text("Thep_{1},p_{2},\\dots,p_{k} from small to large order during the first k prime numbers: 2, 3, 5,…. And meet。")

#text("\\forall 1 \\le i \\le k, \\ \\ 0 < b_{i} < p_{i}, \\ b_{i} \\neq 0, \\ b_{i} \\neq p_{i} – 2.")#linebreak()#text(" Natural number q so obtained if meet the q<p^{2}_{K+1}-2，qandq+2 ，")

#text("are a pair of twin primes. We can think of (1) equivalence of content type conversion become congruence equations。")

#text("q \\equiv b_1 \\pmod{p_1}, q \\equiv b_2 \\pmod{p_2}, \\dots, q \\equiv b_k \\pmod{p_k} \\qquad \\qquad \\qquad \\cdots \\qquad (2)")#linebreak()#text(" Because of (2).p_{1},p_{2},…,p_{k} are all prime numbers, so two two coprime,based on the Chinese Remainder Theorem (China remainder theorem), for a givenb_{1}, b_{2} \\cdot , b_{k}, (2) is only a less than positive integerp_{1} p_{2} \\cdots p_{k} solution。.")

#text("Example")#linebreak()#text(" For example, k=1,q=2m_{1}+1，solutionq=3, 5 。 Since5<3^2-2 ，")

#text("so that 3 and3+2 ；5 and5+2 are the twin prime. Thus the interval(3, 3^2) in the")#linebreak()#text(" whole of prime twins.。")#linebreak()#text(" For instance")

#text("k=2, equation of q=2m_{1}+1=3m_{2}+2， solutionq=5, 11, 17。Since17<5^2-2，")#linebreak()#text(" so the11 with11+2 ；17 and 17+2 are the twin primes.")#linebreak()#text(" Because this isall possible b_{1}, b_{2} \\cdot , b_{k} value, so the interval (5, 5^2) are of prime twins.。")#linebreak()#text(" k=3 5m_{3}+1 5m_{3}+2 5m_{3}+4")#linebreak()#text(" q=2m_{1}+1=3m_{2}+2= 11,41 17 29")#linebreak()#text(" Because this is all possibleb_{1}, b_{2} \\cdot , b_{k} value, so the interva(7, 7^2)are of prime twins。")

#text("k=4 7m_{4}+1 7m_{4}+2 7m_{4}+3 7m_{4}+4 7m_{4}+6")#linebreak()#text(" q=2m_{1}+1=3m_{2}+2=5m_{3}+1= 71 191 101 11 41")#linebreak()#text(" q=2m_{1}+1=3m_{2}+2=5m_{3}+2= 197 107 17 137 167")#linebreak()#text(" q=2m_{1}+1=3m_{2}+2=5m_{3}+4= 29 149 59 179 209")#linebreak()#text(" Because this is all possibleb_{1}, b_{2} \\cdot , b_{k} value, so the interva(11, 11^2)are of prime twins。 8 less than the 121-2 of the solution。")

#text("Copy this to be a not leak to find all the prime twins within an arbitrary largenumber of. For all the possibleb_{1}}, b_{2} … , b_{k} value, (1) and (2) in the（p_{1}）（p_{2}）(p_{3})…（p_{k}）range,， with（p_{1}-1）（p_{2}-2）(p_{3}-2)…（p_{k}-2）…..（3）solution。")

#text("Conclusion")#linebreak()#text(" The twin prime conjecture is (1) and (2) type, value arbitrarily large when a q<p^{2}_{K+1}-2 solution in K.")
]
