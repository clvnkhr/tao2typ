// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/
// Converted to Typst by tao2typ: "2026-10-14T07:10:21.702543+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An explicitly solvable nonlinear wave equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An explicitly solvable nonlinear wave equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 January 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/")[#text("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("As is well known, the linear one-dimensional ")#link("http://en.wikipedia.org/wiki/Wave_equation")[#text("wave equation")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("-\\phi_{tt}+\\phi_{xx} = 0,")]]

#text("where ")#mi("\\phi: {\\Bbb R} \\times {\\Bbb R} \\to {\\Bbb R}")#text(" is the unknown field (which, for simplicity, we assume to be smooth), can be solved explicitly; indeed, the general solution to (1) takes the form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\phi(t,x) = f( t+x ) + g(t-x)")]]

#text("for some arbitrary (smooth) functions ")#mi("f, g: {\\Bbb R} \\to {\\Bbb R}")#text(". (One can of course determine f and g once one specifies enough initial data or other boundary conditions, but this is not the focus of my post today.)")

#text("When one moves from linear wave equations to nonlinear wave equations, then in general one does not expect to have a closed-form solution such as (2). So I was pleasantly surprised recently while playing with the nonlinear wave equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("-\\phi_{tt}+\\phi_{xx} = e^\\phi,")]]

#text("to discover that this equation can also be explicitly solved in closed form. (I hope to explain why I was interested in (3) in the first place in a later post.)")

#emph[#text("A posteriori")]#text(", I now know the reason for this explicit solvability; (3) is the limiting case ")#mi("a = 0, b \\to -\\infty")#text(" of the more general equation")

#align(center)[#tao-fit-display[#mitex("-\\phi_{tt}+\\phi_{xx} = e^{\\phi+a} - e^{-\\phi+b}")]]

#text("which (after applying the simple transformation ")#mi("\\phi = \\frac{b-a}{2} + \\psi( \\sqrt{2} e^{\\frac{a+b}{4}} t, \\sqrt{2} e^{\\frac{a+b}{4}} x)")#text(") becomes the ")#emph[#text("sinh-Gordon equation")]

#align(center)[#tao-fit-display[#mitex("-\\psi_{tt} + \\psi_{xx} = \\sinh(\\psi)")]]

#text("(a close cousin of the more famous ")#link("http://en.wikipedia.org/wiki/Sine-Gordon_equation")[#text("sine-Gordon equation")]#text(" ")#mi("-\\phi_{tt} + \\phi_{xx} = \\sin(\\phi)")#text("), which is known to be completely integrable, and exactly solvable. However, I only realised this after the fact, and stumbled upon the explicit solution to (3) by much more classical and elementary means. I thought I might share the computations here, as I found them somewhat cute, and seem to serve as an example of how one might go about finding explicit solutions to PDE in general; accordingly, I will take a rather pedestrian approach to describing the hunt for the solution, rather than presenting the shortest or slickest route to the answer.")

#text("[The computations do seem to be very classical, though, and thus presumably already in the literature; if anyone knows of a place where the solvability of (3) is discussed, I would be very happy to learn of it.] [")#emph[#text("Update")]#text(", Jan 22: Patrick Dorey has pointed out that (3) is, indeed, extremely classical; it is known as ")#link("http://en.wikipedia.org/wiki/Liouville%27s_equation")[#text("Liouville’s equation")]#text(" and was solved by Liouville in J. Math. Pure et Appl. vol 18 (1853), 71-74, with essentially the same solution as presented here.]")

#metadata(none) <tao-b5f1a98b4ddb91927271>

#heading(level: 1)[#text("— Symmetries of (3) —")]

#text("To simplify the discussion let us ignore all issues of regularity, division by zero, taking square roots and logarithms of negative numbers, etc., and proceed for now in a purely formal fashion, pretending that all functions are smooth and lie in the domain of whatever algebraic operations are being performed. (It is not too difficult to go back after the fact and justify these formal computations, but I do not wish to focus on that aspect of the problem here.)")

#text("Although not strictly necessary for solving the equation (3), I find it convenient to bear in mind the various symmetries that (3) enjoys, as this provides a useful “reality check” to guard against errors (e.g. arriving at a class of solutions which is not invariant under the symmetries of the original equation). These symmetries are also useful to normalise various special families of solutions.")

#text("One easily sees that solutions to (3) are invariant under spacetime translations")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\phi(t,x) \\mapsto \\phi(t-t_0,x-x_0)")]]

#text("and also spacetime reflections")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\phi(t,x) \\mapsto \\phi(\\pm t, \\pm x).")]]

#text("Being relativistic, the equation is also invariant under ")#link("http://en.wikipedia.org/wiki/Lorentz_transformation")[#text("Lorentz transformations")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\phi(t,x) \\mapsto \\phi( \\frac{t-vx}{\\sqrt{1-v^2}}, \\frac{x-vt}{\\sqrt{1-v^2}} ).")]]

#text("Finally, one has the scaling symmetry")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\phi(t,x) \\mapsto \\phi( \\lambda t, \\lambda x ) + 2 \\log \\lambda.")]]

#heading(level: 1)[#text("— Solution to (3) —")]

#text("Henceforth ")#mi("\\phi")#text(" will be a solution to (3). In view of the linear explicit solution (2), it is natural to move to ")#link("http://en.wikipedia.org/wiki/Light_cone_coordinates")[#text("null coordinates")]

#align(center)[#mi("u = t+x, v = t-x")#text(",")]

#text("thus")

#align(center)[#tao-fit-display[#mitex("\\partial_u = \\frac{1}{2} (\\partial_t + \\partial_x); \\partial_v = \\frac{1}{2} (\\partial_t - \\partial_x)")]]

#text("and (3) becomes")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\phi_{uv} = - \\frac{1}{4} e^{\\phi}.")]]

#text("The various symmetries (4)-(7) can of course be rephrased in terms of null coordinates in a straightforward manner. The Lorentz symmetry (6) simplifies particularly nicely in null coordinates, to")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\phi(u,v) \\mapsto \\phi( \\lambda u, \\lambda^{-1} v ).")]]

#text("Motivated by the general theory of ")#link("http://en.wikipedia.org/wiki/Stress-energy_tensor")[#text("stress-energy tensors")]#text(" of relativistic wave equations (of which (3) is a very simple example), we now look at the null energy densities ")#mi("\\phi_u^2, \\phi_v^2")#text(". For the linear wave equation (1) (or equivalently ")#mi("\\phi_{uv}=0")#text("), these null energy densities are transported in null directions:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\partial_v \\phi_u^2 = 0; \\partial_u \\phi_v^2 = 0.")]]

#text("(One can also see this from the explicit solution (2).)")

#text("The above transport law isn’t quite true for the nonlinear wave equation, of course, but we can hope to get some usable substitute. Let us just look at the first null energy ")#mi("\\phi_u^2")#text(" for now. By two applications of (10), this density obeys the transport equation")

#align(center)[#mi("\\displaystyle \\partial_v \\phi_u^2 = 2 \\phi_u \\phi_{uv}")#linebreak()#text(" ")#mi("\\displaystyle = - \\frac{1}{2} \\phi_u e^\\phi")#linebreak()#text(" ")#mi("\\displaystyle = - \\frac{1}{2} \\partial_u( e^\\phi )")#linebreak()#text(" ")#mi("\\displaystyle = 2 \\partial_u \\phi_{uv}")#linebreak()#text(" ")#mi("\\displaystyle = \\partial_v ( 2 \\phi_{uu} )")]

#text("and thus we have the pointwise conservation law")

#align(center)[#tao-fit-display[#mitex("\\partial_v ( \\phi_u^2 - 2 \\phi_{uu} ) = 0")]]

#text("which implies that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("- \\frac{1}{2} \\phi_{uu} + \\frac{1}{4} \\phi_u^2 = U(u)")]]

#text("for some function ")#mi("U: {\\Bbb R} \\to {\\Bbb R}")#text(" depending only on u. Similarly we have")

#align(center)[#tao-fit-display[#mitex("-\\frac{1}{2} \\phi_{vv} + \\frac{1}{4} \\phi_v^2 = V(v)")]]

#text("for some function ")#mi("V: {\\Bbb R} \\to {\\Bbb R}")#text(" depending only on v.")

#text("For any fixed v, (11) is a nonlinear ODE in u. To solve it, we can first look at the homogeneous ODE")

#align(center)[#mi("\\displaystyle - \\frac{1}{2} \\phi_{uu} + \\frac{1}{4} \\phi_u^2 = 0")#text(". (11′)")]

#text("Undergraduate ODE methods (e.g. ")#link("http://en.wikipedia.org/wiki/Separation_of_variables")[#text("separation of variables")]#text(", after substituting ")#mi("\\psi := \\phi_u")#text(") soon reveal that the general solution to this ODE is given by ")#mi("\\phi(u) = -2 \\log( u + C ) + D")#text(" for arbitrary constants C, D (ignoring the issue of singularities or degeneracies for now). Equivalently, (11′) is obeyed if and only if ")#mi("e^{-\\phi/2}")#text(" is linear in u. Motivated by this, we become tempted to rewrite (11) in terms of ")#mi("\\Phi := e^{-\\phi/2}")#text(". One soon realises that")

#align(center)[#tao-fit-display[#mitex("\\partial_{uu} \\Phi = (-\\frac{1}{2} \\phi_{uu} + \\frac{1}{4} \\phi_u^2 ) \\Phi")]]

#text("and hence (11) becomes")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("(-\\partial_{uu} + U(u)) \\Phi = 0,")]]

#text("thus ")#mi("\\Phi")#text(" is a null (generalised) eigenfunction of the ")#emph[#text("Schrodinger operator")]#text(" (or ")#emph[#text("Hill operator")]#text(") ")#mi("- \\partial_{uu} + U(u)")#text(". If we let a(u) and b(u) be two linearly independent solutions to the ODE")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("- f_{uu} + U f = 0,")]]

#text("we thus have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\Phi = a(u) c(v) + b(u) d(v)")]]

#text("for some functions c, d (which one easily verifies to be smooth, since ")#mi("\\phi, a, b")#text(" are smooth and a, b are linearly independent). Meanwhile, by playing around with the second null energy density we have the counterpart to (13),")

#align(center)[#mi("\\displaystyle (-\\partial_{vv} + V(v)) \\Phi = 0")#text(",")]

#text("and hence (by linear independence of a, b) c, d must be solutions to the ODE")

#align(center)[#mi("\\displaystyle - g_{vv} + V g = 0")#text(".")]

#text("This would be a good time to pause and see whether our implications are reversible, i.e. whether any ")#mi("\\phi")#text(" that obeys the relation (14) will solve (3) or (10). It is of course natural to first write (10) in terms of ")#mi("\\Phi")#text(". Since")

#align(center)[#tao-fit-display[#mitex("\\Phi_u = - \\frac{1}{2} \\phi_u \\Phi; \\Phi_v = - \\frac{1}{2} \\phi_v \\Phi; \\Phi_{uv} = (\\frac{1}{4} \\phi_u \\phi_v - \\frac{1}{2} \\phi_{uv} ) \\Phi")]]

#text("one soon sees that (10) is equivalent to")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\Phi \\Phi_{uv} = \\Phi_u \\Phi_v + \\frac{1}{8}.")]]

#text("If we then insert the ")#link("http://en.wikipedia.org/wiki/Ansatz")[#text("ansatz")]#text(" (14), we soon reformulate the above equation as")

#align(center)[#mi("\\displaystyle (a(u)b^{\\prime}(u) - b(u)a^{\\prime}(u)) (c(v)d^{\\prime}(v) - d(v)c^{\\prime}(v)) = \\frac{1}{8}")#text(".")]

#text("It is at this time that one should remember the classical fact that if a, u are two solutions to the ODE (11), then the ")#link("http://en.wikipedia.org/wiki/Wronskian")[#text("Wronskian")]#text(" ")#mi("ab^{\\prime} - ba^{\\prime}")#text(" is constant; similarly ")#mi("cd^{\\prime}-dc^{\\prime}")#text(" is constant. Putting this all together, we see that")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem.")]#text(" A smooth function ")#mi("\\phi")#text(" solves (3) if and only if we have the relation (12) for some functions a, b, c, d obeying the Wronskian conditions ")#mi("ab^{\\prime}-ba^{\\prime} = \\alpha")#text(", ")#mi("cd^{\\prime}-dc^{\\prime} = \\beta")#text(" for some constants ")#mi("\\alpha, \\beta")#text(" multiplying to ")#mi("\\frac{1}{8}")#text(".")
]

#text("Note that one can generate solutions to the Wronskian equation ")#mi("ab^{\\prime}-ba^{\\prime} = \\alpha")#text(" by a variety of means, for instance by first choosing a arbitrarily and then rewriting the equation as ")#mi("(b/a)^{\\prime} = \\alpha/a^2")#text(" to recover b. (This doesn’t quite work at the locations when a vanishes, but there are a variety of ways to resolve that; as I said above, we are ignoring this issue for the purposes of this post.)")

#text("This is not the only way to express solutions. Factoring a(u)d(v) (say) from (12), we see that ")#mi("\\Phi")#text(" is the product of a solution ")#mi("c(v)/d(v) + b(u)/a(u)")#text(" to the linear wave equation, plus the exponential of a solution ")#mi("\\log a(u) + \\log d(u)")#text(" to the linear wave equation. Thus we may write ")#mi("\\phi = F - 2 \\log G")#text(", where F and G solve the linear wave equation. Inserting this back ansatz into (1) we obtain")

#align(center)[#tao-fit-display[#mitex("2(- G_t^2 + G_x^2)/G^2 = e^F / G^2")]]

#text("and so we see that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\phi = \\log \\frac{2 (-G_t^2+G_x^2)}{G^2} = \\log \\frac{ -8 G_u G_v}{G^2}")]]

#text("for some solution G to the free wave equation, and conversely every expression of the form (16) can be verified to solve (1) (since ")#mi("\\log 2(-G_t^2 + G_x^2)")#text(" does indeed solve the free wave equation, thanks to (2)). Inserting (2) into (16) we thus obtain the explicit solution")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\phi = \\log \\frac{-8 f^{\\prime}(t+x) g^{\\prime}(t-x)}{(f(t+x) + g(t-x))^2}")]]

#text("to (1), where f and g are arbitrary functions (recall that we are neglecting issues such as whether the quotient and the logarithm are well-defined).")

#text("I, for one, would not have expected the solution to take this form. But it is instructive to check that (17) does at least respect all the symmetries (4)-(7).")

#heading(level: 1)[#text("— Some special solutions —")]

#text("If we set U=V=0, then a,b,c,d are linear functions, and so ")#mi("\\Phi")#text(" is affine-linear in u, v. One also checks that the uv term in ")#mi("\\Phi")#text(" cannot vanish. After translating in u and v, we end up with the ansatz ")#mi("\\Phi(u,v) = c_1 + c_2 uv")#text(" for some constants ")#mi("c_1, c_2")#text("; applying (15) we see that ")#mi("c_1 c_2=1/8")#text(", and by using the scaling symmetry (7) we may normalise e.g. ")#mi("c_1=8, c_2 = 1")#text(", and so we arrive at the (singular) solution")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\phi = - 2 \\log (8+uv) = \\log \\frac{1}{(8+t^2-x^2)^2}.")]]

#text("To express this solution in the form (17), one can take ")#mi("f(u) = \\frac{8}{u}")#text(" and ")#mi("g(v) = v")#text("; some other choices of f, g are also possible. (Determining the extent to which f, g are uniquely determined by ")#mi("\\phi")#text(" in general can be established from a closer inspection of the previous arguments, and is left as an exercise.)")

#text("We can also look at what happens when ")#mi("\\phi")#text(" is constant in space, i.e. it solves the ODE ")#mi("-\\phi_{tt} = e^\\phi")#text(". It is not hard to see that U and V must be constant in this case, leading to a,b,c,d which are either trigonometric or exponential functions. This soon leads to the ansatz ")#mi("\\Phi = c_1 e^{\\alpha t} + c_2 e^{-\\alpha t}")#text(" for some (possibly complex) constants ")#mi("c_1, c_2, \\alpha")#text(", thus ")#mi("\\phi = - 2 \\log( c_1 e^{\\alpha t} + c_2 e^{-\\alpha t} )")#text(". By using the symmetries (4), (7) we can make ")#mi("c_1=c_2")#text(" and specify ")#mi("\\alpha")#text(" to be whatever we please, thus leading to the solutions ")#mi("\\phi = - 2 \\log \\cosh \\alpha t + c_3")#text(". Applying (1) we see that this is a solution as long as ")#mi("e^{c_3} =2 \\alpha^2")#text(". For instance, we may fix ")#mi("c_3=0")#text(" and ")#mi("\\alpha = 1/\\sqrt{2}")#text(", leading to the solution")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\phi = - 2 \\log \\cosh \\frac{t}{\\sqrt{2}}.")]]

#text("To express this solution in the form (17), one can take for instance ")#mi("f(u) = e^{u/\\sqrt{2}}")#text(" and ")#mi("g(v) = e^{-v/\\sqrt{2}}")#text(".")

#text("One can of course push around (18), (19) by the symmetries (4)-(7) to generate a few more special solutions.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (31)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35208")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2009")])]

#text("Nice post! A very low-level question: are there simple cases in which non-linear heat equations can be solved in closed-form?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35211")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2009")])]

#text("Well, I know that the viscid Burgers equation ")#mi("u_t + u u_x = u_{xx}")#text(" can be solved explicitly by the Cole-Hopf transformation ")#mi("\\phi = -2 \\partial_x \\log u")#text(" to the heat equation ")#mi("\\phi_t = \\phi_{xx}")#text(", and scalar harmonic map heat flow equations such as ")#tao-math("u_t = \\Delta u + \\left|\\nabla u\\right|^2", block: false)#text(" can be similarly solved by a change of coordinates to trivialise the target (in this case, one sets ")#mi("\\phi := e^u")#text(" to obtain the linear heat equation ")#mi("\\phi_t = \\Delta \\phi")#text("). There are probably a few other examples too.")

#text("Now that I have learned the provenance of the equation in the post as ")#link("http://en.wikipedia.org/wiki/Liouville%27s_equation")[#text("Liouville’s theorem")]#text(" (within two hours of posting it!) I wonder whether it could ever be possible to “Google” for an equation, without knowing its name, to find out the existing literature on it (much as the ")#link("http://www.research.att.com/~njas/sequences/")[#text("online encyclopedia of integer sequences")]#text(" does for sequences). One has the ")#link("http://tosio.math.toronto.edu/wiki/index.php/Main_Page")[#text("DispersiveWiki")]#text(", of course, but this equation was not listed there (though ")#link("http://tosio.math.utoronto.ca/wiki/index.php/Liouville%27s_equation")[#text("I’ve fixed that now")]#text("…). In the meantime, it seems that asking readers through a blog is one of the more efficient ways to answer these sorts of questions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35213")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2009")])]

#text("Incidentally – since the heat equation is non-relativistic, and since Lorentz symmetry is an important piece of the puzzle in your post – is there a relativistic form of the heat equation that is somehow more natural?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6252ef125f373f768379a3027fe26f2a4bbe9351fa93287c51fdd46c5d179b26-62731544ac5605a5441d0b2e8f57a3093656529cdf813263e79eb3d1ba9b39f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jake K.")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35219")[#strong[#text("Jake K.")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2009")])]

#text("There’s a couple typos.")#linebreak()#text(" * Equation (10) isn’t actually labeled as such")#linebreak()#text(" * After “this density obeys the transfer equation”, in the displayed math there’s a “phi_uv” that should be “phi_{uv}” ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35226")[#strong[#text("The Art of Finding General Solutions « Teaching")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2009")]

#text("[…] to obtain general solutions, and that there is no universally effective algorithm to follow. This post, appearing yesterday on Prof. Terence Tao’s blog, reveals how one of today’s very best […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f31ecd41a0f617904988dfe0871a9bff6c03982806373e6e2eeecf3959d2208-bcab85fade5c57b65e988b88d472553acef7da3d47fdbe085c32bf3175e94fac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M. E. Irizarry-Gelpí")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35227")[#strong[#text("M. E. Irizarry-Gelpí")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2009")])]

#text("This is a very illuminating post. Thanks for sharing this result.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of user")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35228")[#strong[#text("user")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2009")])]

#text("I too wish there was a large searchable database of mathematical expressions, but I have never seen anyone actually implement one. We should try to get someone at Google to spend their “innovation time off” and implement such a search feature. Paired with a database such as MathSciNet (which contains lots of expressions in TeX-format, which is a lot easier to parse to a tree-form compared to OCRed text) it would be pretty awesome.")

#text("As of now, we are left with trying to figuring out how the OCR/text conversion process will botch the mathematical expressions. In this case, it actually worked: searching for uxx utt eu (try it on Google Book search: ")#link("http://books.google.com/books?q=utt+uxx+eu")[#text("http://books.google.com/books?q=utt+uxx+eu")]#text(" ) gives the correct answer (searching for ")#mi("\\phi")#text(" is not as easy though, but it can work if the text was not OCRed). Always easy in hindsight…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maglev")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35229")[#strong[#text("maglev")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2009")])]

#text("Dear Terry,")#linebreak()#text(" The wave equation, which was used e.g., for determining the speed of light, is an approximation of a discrete version. Does the discrete wave equation also have a closed form solution of (2) type?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35232")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2009")])]

#text("Dear anonymous: I have occasionally seen relativistic versions of the heat equation proposed, for instance by Brenier, but I do not know how well grounded their physical derivations are; presumably there must be some literature on relativistic thermodynamics and statistical mechanics, but this is somewhat outside of my own area of expertise. (The Schrodinger equation, which is superficially similar in appearance to the heat equation, has relativistic analogues, such as the Klein-Gordon or Dirac equations, but this does not seem to shed any light as to what the relativistic heat equation should be.)")

#text("Dear user: that’s a nice trick (searching for a mangled version of the equation); I’ll bear it in mind next time I come up against this sort of issue.")

#text("Dear maglev: the discrete linear wave equation ")#mi("\\phi(t+dt,x) + \\phi(t-dt, x) - \\phi(t,x+dt) - \\phi(t,x-dt) = 0")#text(" has essentially the same solution (2) as its continuous counterpart. There appear to be discrete analogues of the Liouville equation in the literature (it is quite common for exactly solvable integrable systems to have discrete analogues that are also exactly solvable), but I do not know much about them as yet.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-688733")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2025")])]

#text("I’ve come across this comment from 2009 concerning the possibility of “googling” an equation. I suppose this is now possible using large language models. I wonder whether this is actually a method that works in practice. Or is it still the case that posting on a blog and seeking human feedback is the best possible option? (I hope so)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gambit")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35236")[#strong[#text("gambit")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2009")])]

#text("Dear Terry,")#linebreak()#text(" You are right, however, if one considers the classical")#linebreak()#text(" {\\ddot u}_n = u_{n+1} – 2u_n + u_{n-1}, n \\in Z, with the initial conditions u_n (t=0)=\\delta_{n0}, {\\dot u}_n (t=0)=0, then the solution u_n (t) = J_{2n} (2t) is dispersive.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The high exponent limit $p to infty$ for the one-dimensional nonlinear wave equation « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35237")[#strong[#text("The high exponent limit $p to infty$ for the one-dimensional nonlinear wave equation « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2009")])]

#text("[…] In the remainder of this post I would like to describe the strategy of proof and one of the key a priori bounds needed. I also want to point out the connection to Liouville’s equation, which was discussed in the previous post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Th%")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35238")[#strong[#text("Th%")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2009")])]

#text("Hello, Professor Tao. I remember equation (3) was called Liouville equation when I learned how to find its solutions using Backlund transformations 20 years ago. These transformations apply solutions of Liouville to solutions of the wave equations and back. I think Liouville actually solved the elliptic equation in this way. My interest was that superposition principle of the linear equation was tranformed to a non linear combination law, and I seeked to understand what happens in the quantum case. I believe this method is essentially equivalent to yours, at least with the same result (17). But I like your presentation of this result.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8bf0b2d6d9ffe490f8c758e2d74ac04cd247979dc9f6068402465329a269e5fa-3f3e0d2044c77a9c00f0d64300c10ba46c29a27411fda62693a22aa82eea8ba2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hydrobates")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35247")[#strong[#text("hydrobates")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2009")])]

#text("Dear Terry,")

#text("I just wanted to make a comment on the difficult subject of relativistic generalizations of the heat equation, which relates to the wider question of relativistic generalizations of the Navier-Stokes equations. A basic problem is that the infinite propagation speed associated with diffusion is not compatible with the limitation of speeds by the speed of light in (special) relativity. A relativistic equation for a viscous fluid should naturally turn out to be hyperbolic rather than parabolic. The attempt to derive equations of this type from kinetic theory succeeds in the sense that the existence of a reasonable system is OK but there is a huge non-uniqueness. As a source of a lot more information on this topic than I possess I recommend the review article by Ingo Muller in the online journal Living Reviews in Relativity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of IM")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35250")[#strong[#text("IM")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2009")])]

#text("Dear Terry,")

#text("Following up from my earlier questions, then (as Anonymous): is there a sense in which the Dirac or Klein-Gordon equations are mathematically “nicer” than the Schrodinger equation? And if so, might there be analogues of this for the heat equation/ Navier-Stokes equation?")

#text("I guess what I’m asking (from, as is probably clear, a position of almost total ignorance) is whether an oblique approach, of taking the nonrelativistic limit ")#mi("c \\to \\infty")#text(" of a relativistic equation, is ever a better way of attacking the nonrelativistic equation itself.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aef5952340bb6bff3731f98d2d3c1dd9678b3cf7a31e8adaa413d5a449849a63-2282b8795059a7dc66cca6eef5758b61dc6bc6914983ed58ca5a96044d3d7376.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of McGuigan")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35255")[#strong[#text("McGuigan")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2009")])]

#text("The Lagrangian associated with the Liouville equation is")#linebreak()#text(" important in the study of 1+1 dimensional quantum gravity")#linebreak()#text(" and strings. For example:")

#text("Quantum Geometry of Bosonic Strings.")#linebreak()#text(" Alexander M. Polyakov .")#linebreak()#text(" Published in Phys.Lett.B103:207-210,1981")

#text("Liouville field theory: A Decade after the revolution.")#linebreak()#text(" Yu Nakayama (Tokyo U.) . UT-04-02, Jan 2004. 261pp.")#linebreak()#text(" Published in Int.J.Mod.Phys.A19:2771-2930,2004.")#linebreak()#text(" e-Print: hep-th/0402009")

#text("Distler and Kawai: Conformal Field Theory And 2d Quantum Gravity Or Who’s Afraid Of Joseph Liouville?Nucl.Phys.B321:509,1989 [")

#text("If one multiples both sides of the equation by e^{-phi}")#linebreak()#text(" and quantizes this as in the above references would this")#linebreak()#text(" be an approach to quantized wave maps, simpler than the 2+1 quantum gravity connnection discussed previously.?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dynamic stripes")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35256")[#strong[#text("dynamic stripes")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2009")])]

#text("Deer maglev and gambit,")#linebreak()#text(" I wonder, can the Bessel function solution be obtained without complex analysis? Any new ideas on nonlocal in time evolutions?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a718fe0ae1ce222ea33275174bc93b6011081a9ba6d690bd7cf9c39f0317e62a-6170224188d25c8da1133b3e3d9c851d6c93c48eb9e4532aaaf759d38dceb8b4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mfrasca")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35272")[#strong[#text("mfrasca")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2009")])]

#text("Liouville equation is an equation of a Ricci soliton in dimension two. See here")

#link("http://tosio.math.toronto.edu/wiki/index.php/Liouville%27s_equation")[#text("http://tosio.math.toronto.edu/wiki/index.php/Liouville%27s_equation")]

#text("Marco")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35277")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2009")])]

#text("Dear Marco,")

#text("Thanks for the comment (and thanks for contributing to the Dispersive Wiki!)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35274")[#strong[#text("Ricci solitons in two dimensions « The Gauge Connection")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2009")]

#text("[…] a new page about Liouville’s equation as he got involved with it in a way you can read here. Physicists working on quantum gravity has been aware of this equation since eighties as it is the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a718fe0ae1ce222ea33275174bc93b6011081a9ba6d690bd7cf9c39f0317e62a-6170224188d25c8da1133b3e3d9c851d6c93c48eb9e4532aaaf759d38dceb8b4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mfrasca")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35296")[#strong[#text("mfrasca")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2009")])]

#text("Dear Terry,")

#text("It is a pleasure. DispersiveWiki is the nicest place in the web about differential equations.")

#text("Marco")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb7109d2b62e95bac2fbe04a9bea8803f40f5c2e9cb41a2bfce7689178a0cc0f-6560b3b52073c9b6e73cd78a96a64a2bee82ad156ae84553258a1859a54a206d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of robert")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35330")[#strong[#text("robert")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2009")])]

#text("The simple special case you discuss at the end of this post is very reminiscent of the one dimensional non-linear Poisson Boltzman equation (Debye Huckel theory of ionic solutions, space charge in semi-conductors) whose closed form solution (due to Sir Nevil Mott in 1938) has always seemed more or less magical.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35361")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2009")])]

#text("Dear IM,")

#text("From an algebraic/geometric perspective, wave equations such as Dirac or Klein-Gordon are a little bit nicer than their Schrodinger-type counterparts (in particular, they are related to elliptic equations via Wick rotation, and so every algebraic identity for elliptic equations has a counterpart for wave equations). So one can often derive many algebraic facts about Schrodinger equations by viewing them as a nonrelativistic limit of the corresponding wave-type equations; for instance conservation of mass, momentum, and energy for, say, the nonlinear Schrodinger equation can be deduced as the limiting case of conservation of the stress-energy tensor for the nonlinear wave equation (this is done for instance in my book on the subject).")

#text("But for more analytic issues, such as local or global existence and regularity of solutions, approximating a dispersive equation by a relativistic one has proven to be somewhat tricky – it can be done, but generally requires one to already understand both equations pretty well and so does not seem to simplify the basic theory of either equation. However, what does seem to work well is to approximate a dispersive equation by adding a small amount of viscosity (or dissipation, or friction), turning the equation into a parabolic one (for which the existence theory is much better understood, thanks to the parabolic smoothing effect), and then taking limits as the viscosity goes to zero. From a mathematical point of view, adding viscosity seems to smooth out the solution much more nicely than capping the speed of propagation to be finite.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of IM")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35385")[#strong[#text("IM")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2009")])]

#text("Dear Terry,")

#text("Fascinating. Thanks for taking the time to answer my question!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-35420")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2009")])]

#text("Concerning the “relativistic heat equation”, there is some recent literature (Andreu, Caselles, Mazon) that explores its solutions, which seem to have physically plausible properties.")

#text("Bernier’s equation is")

#tao-math("u_t=\\nu\\mathrm{div}\\left(\\frac{\\left|u\\right|Du}{\\sqrt{u^2+\\frac{\\nu^2}{c^2}\\left|Du\\right|^2}}\\right)", block: false)

#text("where ")#mi("\\nu")#text(" is a kinematic viscosity and c is the speed of light.")

#text("Notice that it gives the usual heat equation as c tends to infinity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e5336f504a580ac3d9f74cebd225085115068a9884686bc6dc772d425b08e73-bd3e34c75baf77f7e3e3af0cf3703d02379eaf71371709c99e0e6a4f62c6fb10.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nikhil Chakrabarti")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-37373")[#strong[#text("Nikhil Chakrabarti")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2009")])]

#text("Dear Dr. Tao,")#linebreak()#text(" Could you help me to solve a nonlinear wave equation given below")#linebreak()#text(" \\ddot{psi} = -\\dprime(1/2 psi^2)")

#text("\\ddot means double derivative w r t time")#linebreak()#text(" \\dprime means double derivative with respect to space.")

#text("Thanks in advance")#linebreak()#text(" Nikhil")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-40054")[#strong[#text("Exact solutions of nonlinear equations « The Gauge Connection")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2009")]

#text("[…] relevant results come from soliton theory. Terry posted on his blog about Liouville equation (see here). This equation is exactly solvable and is widely known to people working in string theory. But […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0407444868fc42987e0e767c3fa8c7571cd73af435533bcece7a36bd594b0514-2ae27efe97fcf1ece7ea67e36afa94eee62825664716dc4ee7cf030a881d77c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shannon7774")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-43257")[#strong[#text("shannon7774")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2010")])]

#text("I just saw your really nice blog on this topic. I wish I read it a year ago when you first posted it. The hyperbolic Liouville equation also arises when considering a mean-field spin system. PDE’s sometimes arise for mean-field spin systems. For example, the simplest such model is the Curie-Weiss model. There are ")#mi("N")#text(" spins with the Hamiltonian ")#mi("-h \\sum_{i=1}^{N} \\sigma_i - J (N-1)^{-1} \\sum_{i<j} \\sigma_i \\sigma_j")#text(". Physicists consider the free energy ")#mi("\\phi")#text(". As a function of h and J, this satisfies the viscous Burgers equation. In fact the viscosity is proportional to ")#mi("1/N")#text(" so that the phase transition for this model is related to shocks in the inviscid limit. This was written up last year by Genovese and Barra and their paper is here: ")#link("http://arxiv.org/abs/0812.1978")[#text("http://arxiv.org/abs/0812.1978")]#text(". I wrote up a paper on the Mallows model ")#link("http://arxiv.org/abs/0904.0696")[#text("http://arxiv.org/abs/0904.0696")]#text(". This has \"spins\" which are vectors in the 2-d plane, and the Hamiltonian is a 2-body interaction which just gives an energy of 1 if the slope of the line segment between the two vectors is negative. Taking the second mixed partial ")#mi("\\partial_x \\partial_y")#text(" of this function gives the Dirac delta function in the plane. The reason that this leads to the Liouville equation has to do with the fact that the Boltzmann-Gibbs probability is proportional to the exponential of the Hamiltonian. That's why the e-to-the-power of phi comes up. The reason I'm bringing all this up is that a lot is known about the Mallows model, even at the discrete level. In fact my paper merely re-derived results already known. Even for finite N the problem is well studied.")#linebreak()#text(" A really good paper is by Diaconis and Ram, called \"Analysis of Systematic Scan Metropolis Algorithms Using Iwahori–Hecke Algebra Techniques,\" available on Persi Diaconis's website. So this might possibly be one (of many) interpretations of a discrete version of the Liouville equation. Although, this might be a little far off what Anonymous and you were talking about. But I enjoyed your article a lot.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-193924")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2012")])]

#text("i think it should be ∑=Ω-ƒ(2log)+ƒyx")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cd16bde09d8834ec27d528d9d74c8c1789c69786cfe28a19c37ae77d7399c2a-3f03289850e5fe86fbc86e24ed6820f8d46ae898c2af8c39165567af2ab49ab4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Solitary Splendor | Tamás F. Görbe")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-460500")[#strong[#text("Solitary Splendor | Tamás F. Görbe")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2015")])]

#text("[…] T., An explicitly solvable nonlinear wave equation, blogpost, January 22, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/#comment-460505")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2015")])]

#text("The following generalization of (3):")

#mi("-\\phi_{t t} + \\phi_{x x} = f(\\phi)")

#text("is discusses (with several references) in the EqWorld website:")

#link("http://eqworld.ipmnet.ru/en/solutions/npde/npde2107.pdf")[#text("Click to access npde2107.pdf")]

#text("It seems that the basic idea (to reduce it to ODE) is by assuming a solution of the form ")#mi("\\phi = g(h)")#text(" where ")#mi("h = h(x,t)")#text(" is a function to be determined. It is easy to verify that")

#mi("-\\phi_{t t} + \\phi_{x x} = g^{\\prime\\prime}(h)[-h_t^2 + h_x^2] +g^{\\prime}(h)[-h_{t t} +h_{x x}]")

#text("The choice ")#mi("h(x,t) := [(t+c_1)^2 - (x+c_2)^2] / 4")#linebreak()#text(" where ")#mi("c_1, c_2")#text(" are constants, gives")

#mi("-h_t^2 +h_x^2 = -h")#text(" and ")#mi("-h_{t t} + h_{x x} = -1")

#text("Hence ")#mi("h g^{\\prime\\prime}(h) + g^{\\prime}(h) = - f(g(h))")#text(" is the ODE for ")#mi("g(h)")#text(".")
]
