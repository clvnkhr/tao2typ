// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/
// Converted to Typst by tao2typ: "2026-10-14T09:29:26.977258+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A mathematical formalisation of dimensional analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A mathematical formalisation of dimensional analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 December 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/")[#text("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Mathematicians study a variety of different mathematical structures, but perhaps the structures that are most commonly associated with mathematics are the ")#emph[#text("number systems")]#text(", such as the integers ")#mi("{{\\bf Z}}")#text(" or the real numbers ")#mi("{{\\bf R}}")#text(". Indeed, the use of number systems is so closely identified with the practice of mathematics that one sometimes forgets that it is possible to do mathematics without explicit reference to any concept of number. For instance, the ancient Greeks were able to prove many theorems in Euclidean geometry, well before the development of ")#link("http://en.wikipedia.org/wiki/Cartesian_coordinate_system")[#text("Cartesian coordinates")]#text(" and ")#link("http://en.wikipedia.org/wiki/Analytic_geometry")[#text("analytic geometry")]#text(" in the seventeenth century, or the formal constructions or axiomatisations of the real number system that emerged in the nineteenth century (not to mention precursor concepts such as zero or negative numbers, whose very existence was highly controversial, if entertained at all, to the ancient Greeks). To do this, the Greeks used geometric operations as substitutes for the arithmetic operations that would be more familiar to modern mathematicians. For instance, concatenation of line segments or planar regions serves as a substitute for addition; the operation of forming a rectangle out of two line segments would serve as a substitute for multiplication; the concept of similarity can be used as a substitute for ratios or division; and so forth.")

#text("A similar situation exists in modern physics. Physical quantities such as length, mass, momentum, charge, and so forth are routinely measured and manipulated using the real number system ")#mi("{{\\bf R}}")#text(" (or related systems, such as ")#mi("{{\\bf R}^3}")#text(" if one wishes to measure a vector-valued physical quantity such as velocity). Much as analytic geometry allows one to use the laws of algebra and trigonometry to calculate and prove theorems in geometry, the identification of physical quantities with numbers allows one to express physical laws and relationships (such as Einstein’s famous mass-energy equivalence ")#mi("{E=mc^2}")#text(") as algebraic (or differential) equations, which can then be solved and otherwise manipulated through the extensive mathematical toolbox that has been developed over the centuries to deal with such equations.")

#text("However, as any student of physics is aware, most physical quantities are not represented ")#emph[#text("purely")]#text(" by one or more numbers, but instead by a combination of a number and some sort of ")#emph[#text("unit")]#text(". For instance, it would be a category error to assert that the length of some object was a number such as ")#mi("{10}")#text("; instead, one has to say something like “the length of this object is ")#mi("{10}")#text(" yards”, combining both a number ")#mi("{10}")#text(" and a unit (in this case, the yard). Changing the unit leads to a change in the numerical value assigned to this physical quantity, even though no physical change to the object being measured has occurred. For instance, if one decides to use feet as the unit of length instead of yards, then the length of the object is now ")#mi("{30}")#text(" feet; if one instead uses metres, the length is now ")#mi("{9.144}")#text(" metres; and so forth. But nothing physical has changed when performing this change of units, and these lengths are considered all equal to each other:")

#align(center)[#tao-fit-display[#mitex("10 \\text{ yards } = 30 \\text{ feet } = 9.144 \\text{ metres}.")]]

#text("It is then common to declare that while physical quantities and units are not, strictly speaking, numbers, they should be manipulated using the laws of algebra ")#emph[#text("as if")]#text(" they were numerical quantities. For instance, if an object travels ")#mi("{10}")#text(" metres in ")#mi("{5}")#text(" seconds, then its speed should be")

#align(center)[#tao-fit-display[#mitex("(10 m) / (5 s) = 2 ms^{-1}")]]

#text("where we use the usual abbreviations of ")#mi("{m}")#text(" and ")#mi("{s}")#text(" for metres and seconds respectively. Similarly, if the speed of light ")#mi("{c}")#text(" is ")#mi("{c=299 792 458 ms^{-1}}")#text(" and an object has mass ")#mi("{10 kg}")#text(", then Einstein’s mass-energy equivalence ")#mi("{E=mc^2}")#text(" then tells us that the energy-content of this object is")

#align(center)[#tao-fit-display[#mitex("(10 kg) (299 792 458 ms^{-1})^2 \\approx 8.99 \\times 10^{17} kg m^2 s^{-2}.")]]

#text("Note that the symbols ")#mi("{kg, m, s}")#text(" are being manipulated algebraically as if they were mathematical variables such as ")#mi("{x}")#text(" and ")#mi("{y}")#text(". By collecting all these units together, we see that every physical quantity gets assigned a unit of a certain ")#emph[#text("dimension")]#text(": for instance, we see here that the energy ")#mi("{E}")#text(" of an object can be given the unit of ")#mi("{kg m^2 s^{-2}}")#text(" (more commonly known as a ")#link("http://en.wikipedia.org/wiki/Joule")[#text("Joule")]#text("), which has the dimension of ")#mi("{M L^2 T^{-2}}")#text(" where ")#mi("{M, L, T}")#text(" are the dimensions of mass, length, and time respectively.")

#text("There is however one important limitation to the ability to manipulate “dimensionful” quantities as if they were numbers: one is not supposed to add, subtract, or compare two physical quantities if they have different dimensions, although it is acceptable to multiply or divide two such quantities. For instance, if ")#mi("{m}")#text(" is a mass (having the units ")#mi("{M}")#text(") and ")#mi("{v}")#text(" is a speed (having the units ")#mi("{LT^{-1}}")#text("), then it is physically “legitimate” to form an expression such as ")#mi("{\\frac{1}{2} mv^2}")#text(", but not an expression such as ")#mi("{m+v}")#text(" or ")#mi("{m-v}")#text("; in a similar spirit, statements such as ")#mi("{m=v}")#text(" or ")#mi("{m\\geq v}")#text(" are physically meaningless. This combines well with the mathematical distinction between vector, scalar, and matrix quantities, which among other things prohibits one from adding together two such quantities if their vector or matrix type are different (e.g. one cannot add a scalar to a vector, or a vector to a matrix), and also places limitations on when two such quantities can be multiplied together. A related limitation, which is not always made explicit in physics texts, is that transcendental mathematical functions such as ")#mi("{\\sin}")#text(" or ")#mi("{\\exp}")#text(" should only be applied to arguments that are ")#emph[#text("dimensionless")]#text("; thus, for instance, if ")#mi("{v}")#text(" is a speed, then ")#mi("{\\text{arctanh}(v)}")#text(" is not physically meaningful, but ")#mi("{\\text{arctanh}(v/c)}")#text(" is (this particular quantity is known as the ")#link("http://en.wikipedia.org/wiki/Rapidity")[#text("rapidity")]#text(" associated to this speed).")

#text("These limitations may seem like a weakness in the mathematical modeling of physical quantities; one may think that one could get a more “powerful” mathematical framework if one were allowed to perform dimensionally inconsistent operations, such as add together a mass and a velocity, add together a vector and a scalar, exponentiate a length, etc. Certainly there is some precedent for this in mathematics; for instance, the formalism of ")#link("http://en.wikipedia.org/wiki/Clifford_algebra")[#text("Clifford algebras")]#text(" does in fact allow one to (among other things) add vectors with scalars, and in differential geometry it is quite common to formally apply transcendental functions (such as the exponential function) to a differential form (for instance, the ")#link("http://en.wikipedia.org/wiki/Liouville_measure")[#text("Liouville measure")]#text(" ")#mi("{\\frac{1}{n!} \\omega^n}")#text(" of a symplectic manifold can be usefully thought of as a component of the exponential ")#mi("{\\exp(\\omega)}")#text(" of the symplectic form ")#mi("{\\omega}")#text(").")

#text("However, there are several reasons why it is advantageous to retain the limitation to only perform dimensionally consistent operations. One is that of error correction: one can often catch (and correct for) errors in one’s calculations by discovering a dimensional inconsistency, and tracing it back to the first step where it occurs. Also, by performing ")#link("http://en.wikipedia.org/wiki/Dimensional_analysis")[#text("dimensional analysis")]#text(", one can often identify the form of a physical law before one has fully derived it. For instance, if one postulates the existence of a mass-energy relationship involving only the mass of an object ")#mi("{m}")#text(", the energy content ")#mi("{E}")#text(", and the speed of light ")#mi("{c}")#text(", dimensional analysis is already sufficient to deduce that the relationship must be of the form ")#mi("{E = \\alpha mc^2}")#text(" for some dimensionless absolute constant ")#mi("{\\alpha}")#text("; the only remaining task is then to work out the constant of proportionality ")#mi("{\\alpha}")#text(", which requires physical arguments beyond that provided by dimensional analysis. (This is a simple instance of a more general application of dimensional analysis known as the ")#link("http://en.wikipedia.org/wiki/Buckingham_%CF%80_theorem")[#text("Buckingham ")#mi("{\\pi}")#text(" theorem")]#text(".)")

#text("The use of units and dimensional analysis has certainly been proven to be very effective tools in physics. But one can pose the question of whether it has a properly grounded mathematical foundation, in order to settle any lingering unease about using such tools in physics, and also in order to rigorously develop such tools for purely mathematical purposes (such as analysing identities and inequalities in such fields of mathematics as harmonic analysis or partial differential equations).")

#text("The example of Euclidean geometry mentioned previously offers one possible approach to formalising the use of dimensions. For instance, one could model the length of a line segment not by a number, but rather by the ")#link("http://en.wikipedia.org/wiki/Equivalence_class")[#text("equivalence class")]#text(" of all line segments congruent to the original line segment (cf. the ")#link("http://en.wikipedia.org/wiki/Set-theoretic_definition_of_natural_numbers#The_oldest_definition")[#text("Frege-Russell definition of a number")]#text("). Similarly, the area of a planar region can be modeled not by a number, but by the equivalence class of all regions that are ")#link("http://mathworld.wolfram.com/Equidecomposable.html")[#text("equidecomposable")]#text(" with the original region (one can, if one wishes, restrict attention here to measurable sets in order to avoid ")#link("http://en.wikipedia.org/wiki/Banach%E2%80%93Tarski_paradox")[#text("Banach-Tarski-type paradoxes")]#text(", though that particular paradox actually only arises in three and higher dimensions). As mentioned before, it is then geometrically natural to multiply two lengths to form an area, by taking a rectangle whose line segments have the stated lengths, and using the area of that rectangle as a product. This geometric picture works well for units such as length and volume that have a spatial geometric interpretation, but it is less clear how to apply it for more general units. For instance, it does not seem geometrically natural (or, for that matter, conceptually helpful) to envision the equation ")#mi("{E=mc^2}")#text(" as the assertion that the energy ")#mi("{E}")#text(" is the volume of a rectangular box whose height is the mass ")#mi("{m}")#text(" and whose length and width is given by the speed of light ")#mi("{c}")#text(".")

#text("But there are at least two other ways to formalise dimensionful quantities in mathematics, which I will discuss below the fold. The first is a “parametric” model in which dimensionful objects are modeled as numbers (or vectors, matrices, etc.) depending on some base dimensional parameters (such as units of length, mass, and time, or perhaps a coordinate system for space or spacetime), and transforming according to some representation of a ")#emph[#text("structure group")]#text(" that encodes the range of these parameters; this type of “coordinate-heavy” model is often used (either implicitly or explicitly) by physicists in order to efficiently perform calculations, particularly when manipulating vector or tensor-valued quantities. The second is an “abstract” model in which dimensionful objects now live in an abstract mathematical space (e.g. an abstract vector space), in which only a subset of the operations available to general-purpose number systems such as ")#mi("{{\\bf R}}")#text(" or ")#mi("{{\\bf R}^3}")#text(" are available, namely those operations which are “dimensionally consistent” or invariant (or more precisely, ")#link("http://en.wikipedia.org/wiki/Equivariant_map")[#text("equivariant")]#text(") with respect to the action of the underlying structure group. This sort of “coordinate-free” approach tends to be the one which is preferred by pure mathematicians, particularly in the various branches of modern geometry, in part because it can lead to greater conceptual clarity, as well as results of great generality; it is also close to the more informal practice of treating mathematical manipulations that do not preserve dimensional consistency as being physically meaningless.")

#metadata(none) <tao-df29c1f71ace1b5e33e8>

#heading(level: 1)[#strong[#text(" — 1. The parametric approach — ")]]

#text("In the parametric approach to formalising units and dimension, we postulate the existence of one or more dimensional parameters; for sake of discussion, let us initially use ")#mi("{M, L, T}")#text(" (representing the mass unit, length unit, and time unit respectively) for the dimensional parameters, though later in this discussion we will consider other sets of dimensional parameters. We will allow these parameters ")#mi("{M,L,T}")#text(" to range freely and independently among the positive real numbers ")#mi("{{\\bf R}^+}")#text(", thus the parameter space (or ")#emph[#text("structure group")]#text(") here is given by the multiplicative group ")#mi("{({\\bf R}^+)^3}")#text(". Later on, we will consider more general situations in which the parameter space is given by more general structure groups. (Actually, it would be slightly more natural to use a parameter space which was a ")#link("http://en.wikipedia.org/wiki/Principal_homogeneous_space")[#text("torsor")]#text(" of the structure group, rather than the structure group itself; we discuss this at the very end of the post.)")

#text("We then distinguish two types of mathematical object in the “dimensionful universe”:")

#enum(start: 1, 
[#emph[#text("Dimensionless objects")]#text(" ")#mi("{x}")#text(", which do not depend on the dimensional parameters ")#mi("{M,L,T}")#text(";")],
[#emph[#text("Dimensionful objects")]#text(" ")#mi("{x = x_{M,L,T}}")#text(", which depend on the dimensional parameters ")#mi("{M,L,T}")#text(".")]
)

#text("Similarly with “object” replaced by “number”, “vector”, or any other mathematical object. (Strictly speaking, with this convention, a dimensionless object is a degenerate special case of a dimensionful object; one could, if one wished, talk about ")#emph[#text("strictly dimensionful")]#text(" objects in which the dependence of ")#mi("{x_{M,L,T}}")#text(" on ")#mi("{M,L,T}")#text(" is non-constant.) Our conventions will be slightly different when we turn to dimensionful ")#emph[#text("sets")]#text(" rather than dimensionful ")#emph[#text("objects")]#text(", but we postpone discussion of this subtlety until later.")

#text("The distinction between dimensionless and dimensionful objects is analogous to the distinction between standard and (cheap) nonstandard objects in ")#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/")[#text("(cheap) nonstandard analysis")]#text(". However, whereas in nonstandard analysis the underlying parameter ")#mi("{\\mathbf{n}}")#text(" is usually thought of as an infinitely large parameter, in dimensional analysis the dimensional parameters ")#mi("{M,L,T}")#text(" are usually thought of as neither being infinitesimally small or infinitely large, but rather a medium-sized quantity taking values comparable to those encountered in the physical system being studied.")

#text("A typical example of a dimensionful quantity is the numerical length ")#mi("{l = l_{M,L,T}}")#text(" of a physical rod ")#mi("{AB}")#text(", in terms of a length unit which is ")#mi("{L}")#text(" yards (say) long. For instance, if ")#mi("{AB}")#text(" is ten yards long, then ")#mi("{l_1 = 10}")#text(". Furthermore, ")#mi("{l_{1/3}=30}")#text(", since when ")#mi("{L=1/3}")#text(", the length unit is now ")#mi("{1/3}")#text(" yards, i.e. a foot, and ")#mi("{AB}")#text(" is thirty feet long. More generally, we see that")

#align(center)[#tao-fit-display[#mitex("l_{M,L,T} = 10 L^{-1}.")]]

#text("Thus, a quantity which measures the numerical length of an object is a dimensionful quantity behaves inversely to the size of the length unit. More generally, let us say that a dimensionful numerical quantity ")#mi("{x = x_{M,L,T}}")#text(" ")#emph[#text("has dimension")]#text(" ")#mi("{M^a L^b T^c}")#text(" for some (dimensionless) exponents ")#mi("{a,b,c}")#text(" if one has a proportionality relationship of the form ")#metadata(none) <tao-bf92a04e60b4b2362d45>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("x_{M,L,T} = \\tilde x M^{-a} L^{-b} T^{-c}")]]

#text("for some number ")#mi("{\\tilde x}")#text(". For instance, the speed of an object, measured in length units per time unit, where length unit is ")#mi("{L}")#text(" yards long and the time unit is ")#mi("{T}")#text(" seconds in duration, is a dimensionful quantity of dimension ")#mi("{LT^{-1}}")#text(". The presence of the negative signs in ")#link(<tao-bf92a04e60b4b2362d45>)[#text("(1)")]#text(" may seem surprising at first, but this is due to the fact that ")#link(<tao-bf92a04e60b4b2362d45>)[#text("(1)")]#text(" is describing the effect of a ")#link("http://en.wikipedia.org/wiki/Active_and_passive_transformation")[#text("passive change")]#text(" of units rather than an ")#link("http://en.wikipedia.org/wiki/Active_and_passive_transformation")[#text("active change")]#text(" of the object ")#mi("{x}")#text(".")

#text("(Note here one slight defect of this approach in modeling physical quantities, in that one has to select a preferred system of units (in this case, yards, seconds, and some unspecified mass unit) in order to interpret the parameters ")#mi("{M,L,T}")#text(" numerically. As mentioned above, one can avoid this by viewing the parameters as torsors rather than numbers; we will discuss this briefly at the end of this post.)")

#text("In the language of ")#link("http://en.wikipedia.org/wiki/Representation_theory")[#text("representation theory")]#text(", the collection of dimensionful quantities of dimension ")#mi("{M^a L^b T^c}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Weight_space#Weight_space_of_a_representation")[#text("weight space")]#text(" of the structure group ")#mi("{({\\bf R}^+)^3 = \\{ (M,L,T): M,L,T \\in {\\bf R}^+ \\}}")#text(" of weight ")#mi("{(a,b,c)}")#text(". One can indeed view dimensional analysis as being the representation theory of groups such as ")#mi("{({\\bf R}^+)^3}")#text(", this viewpoint will become more prominent when we consider more general structure groups than ")#mi("{({\\bf R}^+)^3}")#text(" later in this section.")

#text("Note that with this definition, it is possible that some dimensionful quantities do not have any specific dimension ")#mi("{M^a L^b T^c}")#text(", due to the dependence on ")#mi("{M,L,T}")#text(" being more complicated than a simple power law relationship. To give a (contrived) example, the dimensionful quantity ")#mi("{L^{\\sin(M+T)}}")#text(" does not have any specific dimension attached to it.")

#text("We can manipulate dimensionful quantities mathematically by applying any given mathematical operation pointwise for each choice of dimensional parameters ")#mi("{M,L,T}")#text(". For instance, if ")#mi("{x = x_{M,L,T}}")#text(" and ")#mi("{y = y_{M,L,T}}")#text(" are two dimensionful numerical quantities, we can form their sum ")#mi("{x+y = (x+y)_{M,L,T}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("(x+y)_{M,L,T} = x_{M,L,T} + y_{M,L,T}.")]]

#text("Similarly one can define ")#mi("{x-y}")#text(", ")#mi("{xy}")#text(", ")#mi("{x/y}")#text(" (if ")#mi("{y}")#text(" is never vanishing), ")#mi("{x^y}")#text(", ")#mi("{\\sin(x)}")#text(", etc.. We also declare ")#mi("{x=y}")#text(" if one has ")#mi("{x_{M,L,T} = y_{M,L,T}}")#text(" for all ")#mi("{M,L,T}")#text(", and similarly declare ")#mi("{x \\leq y}")#text(" if one has ")#mi("{x_{M,L,T} \\leq y_{M,L,T}}")#text(" for all ")#mi("{M,L,T}")#text(", and so forth. Note that any law of algebra that is expressible as a universal identity will continue to hold for dimensionful quantities; for instance, the distributive law ")#mi("{x(y+z)=xy+xz}")#text(" holds for ordinary real numbers, and hence clearly also holds for dimensionful real numbers.")

#text("With these conventions, we now see a difference between dimensionally consistent and dimensionally inconsistent operations. If ")#mi("{x}")#text(" and ")#mi("{y}")#text(" both have units ")#mi("{M^a L^b T^c}")#text(", then their sum ")#mi("{x+y}")#text(" and difference ")#mi("{x-y}")#text(" also has units ")#mi("{M^a L^b T^c}")#text("; but if ")#mi("{x}")#text(" has units ")#mi("{M^a L^b T^c}")#text(" and ")#mi("{y}")#text(" has units ")#mi("{M^{a^{\\prime}} L^{b^{\\prime}} T^{c^{\\prime}}}")#text(" for some ")#mi("{(a^{\\prime},b^{\\prime},c^{\\prime}) \\neq (a,b,c)}")#text(", then the sum ")#mi("{x+y}")#text(" or difference ")#mi("{x-y}")#text(", while still defined as a dimensionful quantity, no longrer has any single dimension. For instance, if one adds a length ")#mi("{l = l_{M,L,T} = 10 L^{-1}}")#text(" to a speed ")#mi("{v = v_{M,L,T} = 30 L^{-1} T}")#text(", one obtains a hybrid dimensionful quantity ")#mi("{10L^{-1} + 30 L^{-1} T}")#text(" which is not of the form ")#link(<tao-bf92a04e60b4b2362d45>)[#text("(1)")]#text(". Similarly, applying a transcendental function ")#mi("{\\sin}")#text(" to a dimensionful quantity ")#mi("{x}")#text(" will almost certainly generate a quantity with no specific dimension, unless the quantity ")#mi("{x}")#text(" was actually dimensionless (in which case ")#mi("{\\sin(x)}")#text(" will be dimensionless too, of course). On the other hand, dimensions interact very well with products and quotients: the product of a quantity of dimension ")#mi("{M^a L^b T^c}")#text(" with a quantity of dimension ")#mi("{M^{a^{\\prime}} L^{b^{\\prime}} T^{c^{\\prime}}}")#text(" is a quantity of dimension ")#mi("{M^{a+a^{\\prime}} L^{b+b^{\\prime}} T^{c+c^{\\prime}}}")#text(", and similarly for quotients.")

#text("Now we turn to equality. If two quantities ")#mi("{x,y}")#text(" have the same units ")#mi("{M^a L^b T^c}")#text(", then we see that in order to test the equality ")#mi("{x=y}")#text(" of the two objects, it suffices to do so for a single choice of dimensional parameters ")#mi("{M,L,T}")#text(": if ")#mi("{x_{M_0,L_0,T_0} = y_{M_0,L_0,T_0}}")#text(" for a single tuple ")#mi("{(M_0,L_0,T_0)}")#text(", then one has ")#mi("{x_{M,L,T} = y_{M,L,T}}")#text(" for all ")#mi("{M,L,T}")#text(". Similarly for order relations such as ")#mi("{x \\geq y}")#text(" or ")#mi("{x < y}")#text(". In particular, if two quantities ")#mi("{x, y}")#text(" have the same units, then we have the usual order ")#link("http://en.wikipedia.org/wiki/Trichotomy_(mathematics)")[#text("trichotomy")]#text(": exactly of ")#mi("{x=y, x<y, x>y}")#text(" holds. In contrast, it is possible for two dimensionful quantities to be incomparable: for instance, using the quantities ")#mi("{l = 10 L^{-1}}")#text(" and ")#mi("{v = 30 L^{-1} T}")#text(" from before, we see that none of the three statements ")#mi("{l=v}")#text(", ")#mi("{l>v}")#text(", ")#mi("{l<v}")#text(" are true (which, in the dimensionful universe, means that they are valid for all choices of dimension parameters ")#mi("{M,L,T}")#text("): instead, we have ")#mi("{l_{M,L,T} > v_{M,L,T}}")#text(" for ")#mi("{T < 1/3}")#text(" and ")#mi("{l_{L,M,T} < v_{L,M,T}}")#text(" for ")#mi("{T > 1/3}")#text(". Indeed, if ")#mi("{x}")#text(" and ")#mi("{y}")#text(" have different dimensions, we see that the equation ")#mi("{x=y}")#text(" cannot hold at all, unless ")#mi("{x}")#text(" and ")#mi("{y}")#text(" both vanish. Thus we see that any non-trivial dimensionally inconsistent identity (in which the left and right-hand sides have different dimensions) can be automatically ruled out as being false.")

#text("A similar situation holds for inequality: if ")#mi("{x, y}")#text(" are strictly positive dimensionful quantities with different dimensions, then none of the statements ")#mi("{x<y}")#text(", ")#mi("{x>y}")#text(", ")#mi("{x \\leq y}")#text(", or ")#mi("{x \\geq y}")#text(" can hold. (On the other hand, with our conventions, a strictly positive quantity is always greater than a strictly negative quantity, even when the dimensions do not match.) The situation gets more complicated though when dealing with quantities of hybrid dimension. For instance, the ")#link("http://en.wikipedia.org/wiki/Inequality_of_arithmetic_and_geometric_means")[#text("arithmetic mean-geometric mean inequality")]#text(" tells us that ")#metadata(none) <tao-626cf6d4f7ea4f20b105>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("l v \\leq \\frac{1}{2} l^2 + \\frac{1}{2} v^2")]]

#text("for any two strictly positive dimensionful quantities ")#mi("{l, v}")#text(", even if these quantities have different dimensions. For instance, if ")#mi("{l}")#text(" has dimension ")#mi("{L}")#text(" and ")#mi("{v}")#text(" has dimension ")#mi("{LT^{-1}}")#text(", then the left-hand side ")#mi("{lv}")#text(" has dimension ")#mi("{L^2 T^{-1}}")#text(", but the two terms ")#mi("{\\frac{1}{2}l^2}")#text(", ")#mi("{\\frac{1}{2} v^2}")#text(" on the right-hand side have dimensions ")#mi("{L^2}")#text(" and ")#mi("{L^2 T^{-2}}")#text(" respectively. But this inequality can still be viewed as dimensionally consistent, if one broadens the notion of dimensional consistency sufficiently. For instance, if ")#mi("{x}")#text(" is the sum of ")#mi("{n}")#text(" strictly positive quantities of dimension ")#mi("{M^{a_i} L^{b_i} T^{c_i}}")#text(" for ")#mi("{i=1,2,\\ldots,n}")#text(" and some ")#mi("{(a_i,b_i,c_i) \\in {\\bf R}^3}")#text(", and ")#mi("{y}")#text(" is similarly the sum of ")#mi("{m}")#text(" strictly quantities of dimension ")#mi("{M^{a^{\\prime}_j} L^{b^{\\prime}_j} T^{c^{\\prime}_j}}")#text(" for ")#mi("{j=1,\\ldots,m}")#text(" and some ")#mi("{(a^{\\prime}_j,b^{\\prime}_j,c^{\\prime}_j) \\in {\\bf R}^3}")#text(", it is an instructive exercise to show that an inequality of the form ")#mi("{x < y}")#text(" or ")#mi("{x \\leq y}")#text(" can only hold if the convex hull of the ")#mi("{(a_i,b_i,c_i)}")#text(" is contained in the convex hull of the ")#mi("{(a^{\\prime}_j,b^{\\prime}_j,c^{\\prime}_j)}")#text(" (and that equality ")#mi("{x=y}")#text(" can only hold if the two sets ")#mi("{\\{ (a_i,b_i,c_i): 1 \\le i \\leq n\\}}")#text(" and ")#mi("{\\{ (a^{\\prime}_j,b^{\\prime}_j,c^{\\prime}_j): 1 \\le j \\le m \\}}")#text(" agree). Thus, for instance, ")#link(<tao-626cf6d4f7ea4f20b105>)[#text("(2)")]#text(" is dimensionally consistent in this generalised sense, because the exponent pair ")#mi("{(0,2,-1)}")#text(" associated to the left-hand side ")#mi("{lv}")#text(" lies in the convex hull of the exponent pairs ")#mi("{(0,2,0), (0,2,-2)}")#text(" associated to the right-hand side ")#mi("{\\frac{1}{2} l^2 + \\frac{1}{2} v^2}")#text(". On the other hand, this analysis helps explain why we almost never see such hybrid dimensional quantities appear in a physical problem, because while one can bound a positive quantity with a single dimension by a combination of positive quantities of different dimensions (as in ")#link(<tao-626cf6d4f7ea4f20b105>)[#text("(2)")]#text("), the converse is not possible: one cannot bound a positive quantity of hybrid dimension by a quantity with a single dimension. As a consequence, if one is trying to establish an inequality ")#mi("{x \\leq y}")#text(" between two positive quantities of the same dimension by writing down a chain ")#mi("{x \\leq z_1 \\leq \\ldots\\leq z_n \\leq y}")#text(" of intermediate inequalities, one cannot have any of the intermediate quantities ")#mi("{z_j}")#text(" be of hybrid dimension, as this will necessarily cause one of the inequalities in the chain to fail as soon as one attempts to bound a hybrid quantity by a non-hybrid quantity. Similarly if one wishes to prove an equality ")#mi("{x=y}")#text(" instead of an inequality.")

#text("We have already observed that to verify a dimensionally consistent statement between dimensionful quantities, it suffices to do so for a single choice of the dimension parameters ")#mi("{M,L,T}")#text("; one can view this as being analogous to the ")#link("http://en.wikipedia.org/wiki/Transfer_principle")[#text("transfer principle")]#text(" in nonstandard analysis, relating dimensionful mathematics with dimensionless mathematics. Thus, for instance, if ")#mi("{E, m, c}")#text(" have the units of ")#mi("{M L^2 T^{-2}}")#text(", ")#mi("{M}")#text(", and ")#mi("{L T^{-1}}")#text(" respectively, then to verify the dimensionally consistent identity ")#mi("{E=mc^2}")#text(", it suffices to do so for a single choice of units ")#mi("{M,L,T}")#text(". For instance, one can choose a set of units (such as ")#link("http://en.wikipedia.org/wiki/Planck_units")[#text("Planck units")]#text(") for which the speed of light ")#mi("{c}")#text(" becomes ")#mi("{1}")#text(", in which case the dimensionally consistent identity ")#mi("{E=mc^2}")#text(" simplifies to the dimensionally ")#emph[#text("inconsistent")]#text(" identity ")#mi("{E=m}")#text(". Note that once we sacrifice dimensional consistency, though, we cannot then transfer back to the dimensionful setting; the identity ")#mi("{E=m}")#text(" does not hold for all choices of units, only the special choice of units for which ")#mi("{c=1}")#text(". So we see a tradeoff between the freedom to vary units, and the freedom to work with dimensionally inconsistent equations; one can spend one freedom for another, but one cannot have both at the same time. (This is closely related to the concept of ")#emph[#text("spending symmetry")]#text(", which I discuss for instance ")#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/")[#text("in this post")]#text(" (or in Section 2.1 of ")#link("https://terrytao.wordpress.com/books/spending-symmetry/")[#text("this book")]#text(").)")

#text("Thus far, we have only considered scalar dimensionful quantities: quantities which, for each choice of dimensional parameters ")#mi("{M,L,T}")#text(", take values in a number system such as ")#mi("{{\\bf R}}")#text(". One can similarly consider vector-valued or matrix-valued dimensionful quantities, with only minor changes (though see below, when we consider coordinate systems to themselves be a dimensional parameter). We remark though that one could consider vectors in which different components have different dimensions. For instance, one could consider a four-dimensional vector ")#mi("{(x,y,z,t)}")#text(" in which the first three components ")#mi("{x,y,z}")#text(" have the dimension of length ")#mi("{L}")#text(", while the final component ")#mi("{t}")#text(" has the dimension of time ")#mi("{T}")#text(".")

#text("Now we turn to the notion of a dimensionful ")#emph[#text("set")]#text(", which requires some care. We will define a dimensionful set to be a set ")#mi("{\\Omega}")#text(" of dimensionful objects ")#mi("{x = x_{M,L,T}}")#text(". Thus, for instance, the collection ")#mi("{{\\bf R}_{M^a L^b T^c}}")#text(" of all dimensionful numbers of dimension ")#mi("{M^a L^b T^c}")#text(" would be a dimensionful set; it is isomorphic to the reals ")#mi("{{\\bf R}}")#text(", because a dimensionful real number of a given dimension is entirely determined by its value for a single choice of parameters. But one should view the dimensionful sets ")#mi("{{\\bf R}_{M^a L^b T^c}}")#text(" as ")#mi("{a,b,c}")#text(" vary as being distinct copies of ")#mi("{{\\bf R}}")#text(". We say that a dimensionful set ")#mi("{\\Omega}")#text(" of reals has dimension ")#mi("{M^a L^b T^c}")#text(" if each element of ")#mi("{\\Omega}")#text(" has this dimension.")

#text("Given a dimensionful set ")#mi("{\\Omega}")#text(", one can ")#emph[#text("evaluate")]#text(" it at any given choice ")#mi("{M_0,L_0,T_0}")#text(" of parameters, by evaluating each point of ")#mi("{\\Omega}")#text(" at this choice:")

#align(center)[#tao-fit-display[#mitex("\\Omega_{M_0,L_0,T_0} := \\{ x_{M_0,L_0,T_0}: x \\in \\Omega \\}.")]]

#text("However, in contrast with the situation with dimensionful objects, a dimensionful set ")#mi("{\\Omega}")#text(" is ")#emph[#text("not")]#text(" completely characterised by its evaluations ")#mi("{\\Omega_{M_0,L_0,T_0}}")#text(" at each choice of parameters ")#mi("{M_0,L_0,T_0}")#text(". For instance, if one evaluates the dimensionful set ")#mi("{{\\bf R}_{M^a L^b T^c}}")#text(" at any given ")#mi("{M_0,L_0,T_0}")#text(", one just gets the ordinary real numbers:")

#align(center)[#tao-fit-display[#mitex("({\\bf R}_{M^a L^b T^c})_{M_0,L_0,T_0} = {\\bf R}.")]]

#text("However, the sets ")#mi("{{\\bf R}_{M^a L^b T^c}}")#text(" and ")#mi("{{\\bf R}_{M^{a^{\\prime}} L^{b^{\\prime}} T^{c^{\\prime}}}}")#text(" are still distinct (indeed, they only intersect at the origin). The point is that membership of a dimensionful point ")#mi("{x}")#text(" in a dimensionful set ")#mi("{\\Omega}")#text(" is a global property rather than a local one; in order for ")#mi("{x}")#text(" to lie in ")#mi("{\\Omega}")#text(", it is necessary that ")#mi("{x_{M,L,T} \\in \\Omega_{M,L,T}}")#text(" for all ")#mi("{M,L,T}")#text(", but this condition is not sufficient (unless ")#mi("{x}")#text(" and ")#mi("{\\Omega}")#text(" have the same dimension, in which case it suffices to have ")#mi("{x_{M,L,T} \\in \\Omega_{M,L,T}}")#text(" for just a single ")#mi("{M,L,T}")#text(").")

#text("Given two dimensionful sets ")#mi("{\\Omega, \\Omega^{\\prime}}")#text(", we define a dimensionful function ")#mi("{f: \\Omega \\rightarrow \\Omega^{\\prime}}")#text(" from ")#mi("{\\Omega}")#text(" to ")#mi("{\\Omega^{\\prime}}")#text(" to be a family ")#mi("{f_{M,L,T}: \\Omega_{M,L,T} \\rightarrow \\Omega^{\\prime}_{M,L,T}}")#text(" of functions which maps points in ")#mi("{\\Omega}")#text(" to points in ")#mi("{\\Omega^{\\prime}}")#text("; thus, if ")#mi("{x = x_{M,L,T}}")#text(" is a point in ")#mi("{\\Omega}")#text(", then the dimensionful object ")#mi("{f(x)}")#text(" defined by pointwise evaluation")

#align(center)[#tao-fit-display[#mitex("f(x)_{M,L,T} := f_{M,L,T}(x_{M,L,T})")]]

#text("is a point in ")#mi("{\\Omega^{\\prime}}")#text(". Thus, for instance, the squaring function ")#mi("{x \\mapsto x^2}")#text(" can be viewed both as a dimensionless function, and also as a function from ")#mi("{{\\bf R}_{M^a L^b T^c}}")#text(" to ")#mi("{{\\bf R}_{M^{2a} L^{2b} T^{2c}}}")#text(" for any ")#mi("{a,b,c}")#text(". (Thus, when describing a dimensionful function ")#mi("{f: \\Omega \\rightarrow \\Omega^{\\prime}}")#text(", it is not quite enough to specify the specific instantiations ")#mi("{f_{M,L,T}}")#text(" of that function; one must also specify the dimensionful domain ")#mi("{\\Omega}")#text(" and range ")#mi("{\\Omega^{\\prime}}")#text(".) As another example, if ")#mi("{A}")#text(" is a dimensionful quantity of some units ")#mi("{M^a L^b T^c}")#text(" (representing amplitude) and ")#mi("{\\omega}")#text(" is a dimensionful quantity of units ")#mi("{T^{-1}}")#text(" (representing a time frequency), then the function ")#mi("{f(t) := A \\sin(\\omega t)}")#text(" (thus ")#mi("{f(t)_{M,L,T} = A_{M,L,T} \\sin(\\omega_{M,L,T} t_{M,L,T})}")#text(" for all ")#mi("{M,L,T}")#text(") is a dimensional function from ")#mi("{{\\bf R}_T}")#text(" to ")#mi("{{\\bf R}_{M^a L^b T^c}}")#text(".")

#text("A dimensionful function ")#mi("{f: {\\bf R}_{M^a L^b T^c} \\rightarrow {\\bf R}_{M^{a^{\\prime}} L^{b^{\\prime}} T^{c^{\\prime}}}}")#text(" has instantiations ")#mi("{f_{M,L,T}: {\\bf R} \\rightarrow {\\bf R}}")#text(" that scale according to the rule ")#metadata(none) <tao-2d93de39850958f02301>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("f_{M,L,T}( x ) = \\tilde f( M^a L^b T^c x ) M^{-a^{\\prime}} L^{-b^{\\prime}} T^{-c^{\\prime}}")]]

#text("for any ")#mi("{M,L,T,x}")#text(" and some dimensionless function ")#mi("{\\tilde f: {\\bf R} \\rightarrow {\\bf R}}")#text("; conversely, every dimensionless function ")#mi("{\\tilde f}")#text(" creates a dimensionful function ")#mi("{f}")#text(" in this fashion. As such, one can again transfer between the dimensionful and dimensionless settings when manipulating functions and objects, provided as before that all statements involved are dimensionally consistent.")

#text("An important additional operation available to dimensionful functions that is not available (in any non-trivial sense) to dimensionful scalars is that of ")#emph[#text("integration")]#text(". Given a dimensionful function ")#mi("{f: \\Omega \\rightarrow {\\bf R}_{M^{a^{\\prime}} L^{b^{\\prime}} T^{c^{\\prime}}}}")#text(" on some one-dimensional dimensionful set ")#mi("{\\Omega \\subset {\\bf R}_{M^a L^b T^c}}")#text(", one can form the integral ")#mi("{\\int_\\Omega f(x)\\ dx \\in {\\bf R}_{M^{a+a^{\\prime}} L^{b+b^{\\prime}} T^{c+c^{\\prime}}}}")#text(" (assuming sufficient regularity and decay conditions on ")#mi("{f}")#text(" and ")#mi("{\\Omega}")#text(", which we will not dwell on here) by the formula")

#align(center)[#tao-fit-display[#mitex("(\\int_\\Omega f(x)\\ dx)_{M,L,T} := \\int_{\\Omega_{M,L,T}} f_{M,L,T}(x)\\ dx.")]]

#text("One can verify that this integral ")#mi("{\\int_\\Omega f(x)\\ dx}")#text(" is indeed a dimensionful quantity of dimension ")#mi("{M^{a+a^{\\prime}} L^{b+b^{\\prime}} T^{c+c^{\\prime}}}")#text(". (One way to see this is to first verify the analogous claim for Riemann sums, and then to observe that the property of being a given dimension is a closed condition in the sense that it is preserved under limits.) In the opposite direction, the derivative ")#mi("{\\frac{d}{dx}f(x)}")#text(" of this function, defined in the obvious fashion as")

#align(center)[#tao-fit-display[#mitex("(\\frac{d}{dx} f(x))_{M,L,T} := \\frac{d}{dx_{M,L,T}} f_{M,L,T}(x_{M,L,T}),")]]

#text("can be easily verified to be a dimensionful quantity of dimension ")#mi("{{\\bf R}^{M^{a^{\\prime}-a} L^{b^{\\prime}-b} T^{c^{\\prime}-c}}}")#text(". (As before, this can be seen by first considering Newton quotients and then taking limits.)")

#text("With this formalism, one can now use dimensional analysis to help test the truth of various estimates in harmonic analysis. Consider for instance the homogeneous ")#link("http://en.wikipedia.org/wiki/Sobolev_inequality")[#text("Sobolev inequality")]#text(" ")#metadata(none) <tao-7dcb6ad9f0e717e8ef3a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("(\\int_{{\\bf R}^d} \\left|f(x)\\right|^q\\ dx)^{1/q} \\leq C_{p,q,d} (\\int_{{\\bf R}^d} \\left|\\nabla f(x)\\right|^p\\ dx)^{1/p}", block: true)]]

#text("for all sufficiently nice functions ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" (again, we will not dwell on the precise regularity needed here, as it is not the main focus of this post), for certain choices of exponents ")#mi("{1 \\leq p,q < \\infty}")#text(" and ")#mi("{d \\geq 1}")#text(", and a constant ")#mi("{C_{p,q,d}}")#text(" that is independent of ")#mi("{f}")#text(". To dimensionally analyse this inequality, we introduce two dimensional parameters – a length unit ")#mi("{L}")#text(" and an amplitude unit ")#mi("{A}")#text(" – and view ")#mi("{f}")#text(" as a function from ")#mi("{{\\bf R}_L^d}")#text(" to ")#mi("{{\\bf R}_A}")#text(" rather than from ")#mi("{{\\bf R}^d}")#text(" to ")#mi("{{\\bf R}}")#text("; thus, by ")#link(<tao-2d93de39850958f02301>)[#text("(3)")]#text(" (now using parameters ")#mi("{L,A}")#text(" instead of ")#mi("{M,L,T}")#text("), we have")

#align(center)[#tao-fit-display[#mitex("f_{L,A}( x ) = A^{-1} f(Lx).")]]

#text("(As before, the exponents seem reversed from the more familiar rescaling ")#mi("{A f(x/L)}")#text(", due to the fact that we are measuring change with respect to ")#link("http://en.wikipedia.org/wiki/Active_and_passive_transformation")[#text("passive rescaling")]#text(" of units rather than an ")#link("http://en.wikipedia.org/wiki/Active_and_passive_transformation")[#text("active rescaling")]#text(" of the function ")#mi("{f}")#text(".) We can then verify that ")#mi("{f(x)}")#text(" has dimension ")#mi("{A}")#text(", ")#tao-math("{\\left|f(x)\\right|^q}", block: false)#text(" has dimension ")#mi("{A^q}")#text(", ")#tao-math("{\\int_{{\\bf R}^d} \\left|f(x)\\right|^q\\ dx}", block: false)#text(" has dimension ")#mi("{A^q L^d}")#text(", and so the left-hand side ")#link(<tao-7dcb6ad9f0e717e8ef3a>)[#text("(4)")]#text(" of ")#tao-math("{(\\int_{{\\bf R}^d} \\left|f(x)\\right|^q\\ dx)^{1/q}}", block: false)#text(" has dimension ")#mi("{A L^{d/q}}")#text(". A similar calculation (treating ")#mi("{C_{p,q,d}}")#text(" as dimensionless) shows that the right-hand side of ")#link(<tao-7dcb6ad9f0e717e8ef3a>)[#text("(4)")]#text(" has dimension ")#mi("{A L^{-1} L^{d/p}}")#text(". If ")#link(<tao-7dcb6ad9f0e717e8ef3a>)[#text("(4)")]#text(" holds for dimensionless functions, it holds for dimensionful functions as well (by applying the inequality to each instantiation of the dimensionful function); as the quantities in ")#link(<tao-7dcb6ad9f0e717e8ef3a>)[#text("(4)")]#text(" are positive for non-trivial ")#mi("{f}")#text(", we conclude that ")#link(<tao-7dcb6ad9f0e717e8ef3a>)[#text("(4)")]#text(" can only hold if we have the dimensional consistency relation")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{q} = \\frac{d}{p} - 1.")]]

#text("In fact, this condition turns out to be sufficient as well as necessary, although this is a non-trivial fact that cannot be proven purely by dimensional analysis; see e.g. ")#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/")[#text("these notes")]#text(".")

#text("In a similar vein, one can dimensionally analyse the inhomogeneous Sobolev inequality ")#metadata(none) <tao-1f447d77f0b62b06ea12>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("(\\int_{{\\bf R}^d} \\left|f(x)\\right|^q\\ dx)^{1/q} \\leq C_{p,q,d} [(\\int_{{\\bf R}^d} \\left|f(x)\\right|^p\\ dx)^{1/p} + (\\int_{{\\bf R}^d} \\left|\\nabla f(x)\\right|^p\\ dx)^{1/p}].", block: true)]]

#text("Using the same units as before, the left-hand side has dimension ")#mi("{A L^{d/q}}")#text(", and the right-hand side is a hybrid of the dimensions ")#mi("{A L^{d/p}}")#text(" and ")#mi("{A L^{-1} L^{d/q}}")#text(", leading to the dimensional consistency relation")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{p} - 1 \\leq \\frac{d}{q} \\leq \\frac{d}{p}")]]

#text("for this inequality, as a necessary condition for ")#link(<tao-1f447d77f0b62b06ea12>)[#text("(5)")]#text(". (See also ")#link("https://terrytao.wordpress.com/2008/12/27/tricks-wiki-use-basic-examples-to-calibrate-exponents/")[#text("this blog post")]#text(" for an equivalent way to establish these conditions, using rescaled test functions instead of dimensional analysis; as mentioned earlier, the relation between these two approaches is essentially the difference between ")#link("https://terrytao.wordpress.com/2008/12/27/tricks-wiki-use-basic-examples-to-calibrate-exponents/")[#text("active and passive transformations")]#text(".)")

#text("We saw earlier that hybrid inequalities (in which the right-hand side contains terms of different dimension) are not as useful or “efficient” as dimensionally pure inequalities (in which both sides have the same, single dimension). But it is often possible to ")#emph[#text("amplify")]#text(" a hybrid inequality into a dimensionally pure one by optimising over all rescalings; see ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("this previous blog post")]#text(" for a discussion of this trick (which, among other things, amplifies the inhomogeneous Sobolev inequality into the Gagliardo-Nirenberg inequality).")

#text("In all the above discussion, the dimensional parameters used (such as ")#mi("{M,L,T}")#text(" or ")#mi("{A,L}")#text(") were scalar quantities, taking values in the multiplicative group ")#mi("{{\\bf R}^+}")#text(", and representing units in one-dimensional spaces. But, when dealing with vector quantities, one can perform a more powerful form of dimensional analysis in which the dimensional parameters lie in a more general group (which we call the ")#emph[#text("structure group")]#text(" of the dimensionful universe being analysed). Suppose for instance one wishes to represent a vector ")#mi("{v}")#text(" in a three-dimensional vector space ")#mi("{V}")#text(". One could designate some basis ")#mi("{e_1,e_2,e_3}")#text(" of this space ")#mi("{V}")#text(" as a reference basis, so that ")#mi("{v}")#text(" is expressible as some linear combination ")#mi("{v = x_1 e_1 + x_2 e_2 + x_3 e_3}")#text(", in which case one could identify ")#mi("{v}")#text(" with the row vector ")#mi("{\\tilde v = (x_1,x_2,x_3)}")#text(", and identify ")#mi("{V}")#text(" with ")#mi("{{\\bf R}^3}")#text(". But one could instead represent ")#mi("{v}")#text(" in some different basis ")#mi("{Le_1, Le_2, Le_3}")#text(", where ")#mi("{L = \\begin{pmatrix} L_{11} & L_{12} & L_{13} \\\\ L_{21} & L_{22} & L_{23} \\\\ L_{31} & L_{32} & L_{33} \\end{pmatrix}}")#text(" is a ")#mi("{3 \\times 3}")#text(" matrix (where, by an abuse of notation, we use ")#mi("{Le_i}")#text(" as shorthand for ")#mi("{L_{1i} e_1 + L_{2i} e_2 + L_{3i}e_3}")#text("), in which case one obtains a new decomposition")

#align(center)[#tao-fit-display[#mitex("v = x_{1,L} Le_1 + x_{2,L} Le_2 + x_{3,L} L e_3")]]

#text("where the row vector ")#mi("{v_L := (x_{1,L}, x_{2,L}, x_{3,L})}")#text(" is related to the original row vector ")#mi("{\\tilde x}")#text(" by the formula ")#metadata(none) <tao-01979b66ee1794c473f5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("v_L = \\tilde v (L^t)^{-1},")]]

#text("where ")#mi("{L^t}")#text(" is the transpose of ")#mi("{L}")#text(". Motivated by this, we may take the matrix ")#mi("{L}")#text(" as the dimensional parameter (taking values in the structure group ")#mi("{GL_3({\\bf R})}")#text(" of invertible ")#mi("{3 \\times 3}")#text(" matrices), and define a ")#emph[#text("polar vector")]#text(" or ")#emph[#text("type ")#mi("{(1,0)}")#text(" tensor")]#text(" to be a dimensionful vector ")#mi("{v = v_L}")#text(" taking values in the space ")#mi("{{\\bf R}^3}")#text(" of three-dimensional row vectors and transforming according to the law ")#link(<tao-01979b66ee1794c473f5>)[#text("(6)")]#text(". This is the three-dimensional analogue of a scalar quantity of dimension ")#mi("{L}")#text(" (which, in the one-dimensional setting, is just a scalar parameter in ")#mi("{{\\bf R}^+}")#text(" rather than an element of ")#mi("{GL_3({\\bf R})}")#text("). Indeed, one can view units as being simply the one-dimensional special case of coordinate systems. (As with previous transformation laws, the presence of the transpose inverse in ")#link(<tao-01979b66ee1794c473f5>)[#text("(6)")]#text(" comes from the use of passive transformations rather than active ones.)")

#text("Now suppose we do not wish to model a vector ")#mi("{v}")#text(" in ")#mi("{V}")#text(", but rather a ")#link("http://en.wikipedia.org/wiki/Linear_functional")[#text("linear functional")]#text(" ")#mi("{w: V \\rightarrow {\\bf R}}")#text(" on ")#mi("{V}")#text(". Using the standard basis ")#mi("{e_1,e_2,e_3}")#text(", one can identify ")#mi("{w}")#text(" with the row vector ")#mi("{\\tilde w := (w(e_1), w(e_2), w(e_3))}")#text(". Replacing that basis with ")#mi("{L e_1, Le_2, Le_3}")#text(", we obtain a new row vector ")#mi("{w_L := (w(Le_1), w(Le_2), w(Le_3))}")#text(", which is related to the original vector by the formula ")#metadata(none) <tao-603f25c103da612bb9b0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("w_L = \\tilde w L.")]]

#text("We will call a dimensionful vector-valued quantity ")#mi("{w=w_L}")#text(" of the form ")#link(<tao-603f25c103da612bb9b0>)[#text("(7)")]#text(" a ")#emph[#text("covector")]#text(" or ")#emph[#text("type ")#mi("{(0,1)}")#text(" tensor")]#text(". Thus we see that while polar vectors and covectors can both be expressed (for each choice of ")#mi("{L}")#text(") as an element of ")#mi("{{\\bf R}^3}")#text(", they transform differently with respect to coordinate change (coming from the two different ")#link("http://en.wikipedia.org/wiki/Group_action")[#text("right-actions")]#text(" of the structure group ")#mi("{GL_3({\\bf R})}")#text(" on ")#mi("{{\\bf R}^3}")#text(" given by ")#link(<tao-01979b66ee1794c473f5>)[#text("(6)")]#text(", ")#link(<tao-603f25c103da612bb9b0>)[#text("(7)")]#text(") and so it is not possible for a vector and covector to be equal as dimensionful quantities (unless they are both zero). If one tries to add a non-zero vector to a non-zero covector, one still obtains a dimensionful quantity taking values in ")#mi("{{\\bf R}^3}")#text(", but it is no longer transforms according to a single group action such as ")#link(<tao-01979b66ee1794c473f5>)[#text("(6)")]#text(" or ")#link(<tao-603f25c103da612bb9b0>)[#text("(7)")]#text(", but is instead coming from a more complicated hybrid of two such actions. On the other hand, the dot product of a vector and a covector becomes a dimensionless scalar, whereas the dot product of a vector with another vector, or a covector with another covector, does not transform according to any simple rule. This makes the distinction between vectors and covectors well suited to problems in ")#link("http://en.wikipedia.org/wiki/Affine_geometry")[#text("affine geometry")]#text(", which by their nature transform well with respect to the action of ")#mi("{GL_3({\\bf R})}")#text(". (However, if the geometric problem involves concepts such as length and angles, which do not transform easily with respect to ")#mi("{GL_3({\\bf R})}")#text(" actions, then the vector/covector distinction is much less useful.)")

#text("One can also assign dimensions to higher rank ")#link("http://en.wikipedia.org/wiki/Tensor")[#text("tensors")]#text(", such as matrices, ")#mi("{k}")#text("-vectors, or ")#mi("{k}")#text("-forms; the notation here becomes rather complicated, but is perhaps best described using ")#link("http://en.wikipedia.org/wiki/Abstract_index_notation")[#text("abstract index notation")]#text(". The dimensional consistency of equations involving such tensors then becomes the requirement in abstract index notation that the subscripts and superscripts on the left-hand side of a tensor equation must match those on the right-hand side, after “canceling” any index that appears as both a subscript and a superscript on one side. (Abstract index notation is discussed further in ")#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/")[#text("this previous blog post")]#text(".)")

#text("Another type of dimensional analysis arises when one takes the structure group to be a ")#link("http://en.wikipedia.org/wiki/Euclidean_group")[#text("Euclidean group")]#text(" such as ")#mi("{E(2)}")#text(" or ")#mi("{E(3)}")#text(", rather than ")#mi("{GL_3({\\bf R})}")#text(" or (some power of) ")#mi("{{\\bf R}^+}")#text(". For instance, one might be studying Euclidean geometry in the Euclidean plane ")#mi("{P}")#text(", which one might identify with the Cartesian plane ")#mi("{{\\bf R}^2}")#text(" by some reference isomorphism ")#mi("{\\iota: {\\bf R}^2 \\rightarrow P}")#text(" (which can be viewed as a choice of origin, coordinate axes, orientation, and unit length on ")#mi("{P}")#text("), so that a given point ")#mi("{p}")#text(" in the Euclidean plane ")#mi("{P}")#text(" is associated to a Cartesian point ")#mi("{\\tilde p := \\iota^{-1}(p)}")#text(" in ")#mi("{{\\bf R}^2}")#text(". If we let ")#mi("{L \\in E(2)}")#text(" denote a rigid motion of ")#mi("{{\\bf R}^2}")#text(" (some combination of a translation, rotation, and/or reflection on ")#mi("{{\\bf R}^2}")#text("), this gives rise to a new isomorphism ")#mi("{\\iota \\circ L: {\\bf R}^2 \\rightarrow P}")#text(", and a new Cartesian point")

#align(center)[#tao-fit-display[#mitex("p_L = (\\iota \\circ L)^{-1} p = L^{-1} \\tilde p.")]]

#text("If we view ")#mi("{L}")#text(" as a dimensional parameter, we can then define a ")#link("http://en.wikipedia.org/wiki/Position_(vector)")[#text("position vector")]#text(" to be a dimensionful quantity ")#mi("{p = p_L}")#text(" taking values in ")#mi("{{\\bf R}^2}")#text(" that transforms according to the law ")#metadata(none) <tao-8a25fee8ec14da5b416c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("p_L = L^{-1} \\tilde p")]]

#text("for some ")#mi("{\\tilde p \\in {\\bf R}^2}")#text(". If, instead of considering the position of a single point ")#mi("{p}")#text(" in the Euclidean plane, one considers the displacement ")#mi("{v = q-p}")#text(" between two points ")#mi("{p,q}")#text(" in that plane, a similar line of reasoning leads to the concept of a ")#link("http://en.wikipedia.org/wiki/Displacement_vector")[#text("displacement vector")]#text(", which would be a dimensionful quantity ")#mi("{v = v_L}")#text(" taking values in ")#mi("{{\\bf R}^2}")#text(" that transforms according to the law ")#metadata(none) <tao-098774f8425236446d5c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("p_L = \\dot L^{-1} \\tilde p")]]

#text("where ")#mi("{\\dot L \\in O(2)}")#text(" is the homogeneous portion of ")#mi("{L}")#text(" (thus ")#mi("{\\dot L}")#text(" is an orthogonal linear transformation on ")#mi("{R^2}")#text(", and ")#mi("{L(x) = \\dot L(x) + L(0)}")#text(" for all ")#mi("{x \\in {\\bf R}^2}")#text("). Thus we see a rigorous distinction between the concepts of position and displacement vector that one sometimes sees in introductory linear algebra or physics courses. Note for instance that one can add a position vector to a displacement vector to obtain another position vector, or a displacement vector to a displacement vector to obtain a further displacement vector, but when adding a position vector to another position vector, one obtains a new type of vector which is neither a position vector nor a displacement vector. (On the other hand, convex combinations of position vectors still give a position vector as output.) The dimensional analysis distinction between position and displacement vectors can be useful in situations in which the ambient plane ")#mi("{P}")#text(" has no preferred origin, allowing for a clean action by the Euclidean group ")#mi("{E(2)}")#text(" (or at least the translation subgroup ")#mi("{{\\bf R}^2}")#text(").")

#text("A similar discussion can also be given in three-dimensions for the Euclidean group ")#mi("{E(3)}")#text(" (or the orthogonal subgroup ")#mi("{O(3)}")#text("); in addition to the position/displacement vector distinction, one can also distinguish polar vectors from ")#link("http://en.wikipedia.org/wiki/Pseudovector")[#text("axial vectors")]#text(", leading in particular to the conclusion that the ")#link("http://en.wikipedia.org/wiki/Cross_product")[#text("cross product")]#text(" of two polar vectors is an axial vector rather than a polar vector. Among other things, this helps explain why, in any identity involving cross products, such as the ")#link("http://en.wikipedia.org/wiki/Hodge_decomposition#Hodge_decomposition")[#text("Hodge decomposition")]

#align(center)[#tao-fit-display[#mitex("\\Delta f = \\nabla \\cdot (\\nabla f) + \\nabla \\times (\\nabla \\times f)")]]

#text("of the three-dimensional Laplacian ")#mi("{\\Delta}")#text(", either all terms have an even number of cross products, or all terms have an odd number of cross products.")

#text("In a similar vein, one can dimensionally analyse physical quantities in spacetime using the ")#link("http://en.wikipedia.org/wiki/Poincar%C3%A9_group")[#text("Poincaré group")]#text(" ")#mi("{SO(3,1) \\ltimes {\\bf R}^{3+1}}")#text(" as the structure group, in which case the ")#link("http://en.wikipedia.org/wiki/Special_relativity")[#text("principle of special relativity")]#text(" can be interpreted as the assertion that all physical quantities transform cleanly with respect to this group action (as opposed to having a hybrid transformation law, or one which privileges a specific reference frame). Similarly, if one enlarges the structure group to the ")#link("http://en.wikipedia.org/wiki/Diffeomorphism_group")[#text("diffeomorphism group")]#text(" of spacetime, one recovers the ")#link("http://en.wikipedia.org/wiki/Principle_of_relativity#General_principle_of_relativity")[#text("principle of general relativity")]#text(" (though an important caveat here is that if the spacetime is topologically non-trivial, one needs to work with ")#emph[#text("local")]#text(" coordinate charts (or ")#link("http://en.wikipedia.org/wiki/Atlas_(topology)")[#text("atlases")]#text(" of such charts, and the structure group needs to be relaxed to a looser concept, such as that of a ")#link("http://en.wikipedia.org/wiki/Pseudogroup")[#text("pseudogroup")]#text(") rather than a single global coordinate chart, which greatly complicates the parametrisation space). Using a group of gauge transformations instead as the symmetry group leads to a mathematical framework suitable for ")#link("http://en.wikipedia.org/wiki/Gauge_transformation#Classical_gauge_theory")[#text("gauge theory")]#text("; and so forth.")

#text("In the preceding examples, the structure groups were all examples of continuous Lie groups: ")#mi("{({\\bf R}^+)^3}")#text(", ")#mi("{GL_3({\\bf R})}")#text(", ")#mi("{E(2)}")#text(", etc.. But even a discrete structure group can lead to a non-trivial capability for dimensional analysis. Perhaps the most familiar example is the use of the structure group ")#mi("{\\{-1,+1\\}}")#text(" as the range of the dimensional parameter ")#mi("{L}")#text(", leading to two types of scalars: ")#emph[#text("symmetric")]#text(" scalars ")#mi("{x = x_L}")#text(", which are dimensionless (so ")#mi("{x_{-1}=x_{+1}}")#text("), and ")#emph[#text("antisymmetric")]#text(" scalars ")#mi("{x = x_L}")#text(", which transform according to the law ")#mi("{x_{-1} = -x_{+1}}")#text(". A function ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" then transforms antisymmetric scalars to symmetric ones if the function is even, or to antisymmetric ones if the function is odd; this leads to the usual parity rules regarding combinations of even and odd functions, explaining for instance why in any trigonometric identity such as")

#align(center)[#tao-fit-display[#mitex("\\sin(x+y) = \\sin(x) \\cos(y) + \\cos(x) \\sin(y),")]]

#text("the number of odd functions (sine, tangent, cotangent, and their inverses) in each term has the same parity. (Incidentally, this particular discrete structure group ")#mi("{\\{-1,+1\\}}")#text(" can be combined with continuous structure groups, giving rise to various mathematical structures used in the theory of ")#link("http://en.wikipedia.org/wiki/Supersymmetry_algebra")[#text("supersymmetry")]#text(" in physics.)")

#heading(level: 1)[#strong[#text(" — 2. The abstract approach — ")]]

#text("The parameteric approach described above is essentially the one which is emphasised in physics courses, in which any mathematical representation of a physical object includes a description of how that representation transforms with respect to elements of the relevant structure group, so that in effect all coordinatisations of the object are considered simultaneously. However, in pure mathematics it is often more preferable to take a more abstract, “coordinate free” approach, in which explicit use of coordinates is avoided whenever possible, in order to keep the mathematical framework as close as possible to the underlying geometry or physics of the situation, and also in order to allow for easy generalisation to other contexts of mathematical interest in which coordinate systems become inconvenient to use (as we already saw in the case of general relativity on a topologically non-trivial situations, in which global coordinate systems had to be replaced by local ones), or completely unavailable (e.g. in studying more general topological spaces than manifolds). With this abstract, minimalistic approach, one models objects as elements of abstract structures in which only the bare minimum of operations (namely, the “geometric”, “physical”, or “dimensionally consistent” operations) are permitted, viewing any excess structure (such as coordinates) as superfluous ontological baggage to be discarded if possible.")

#text("We have already implicitly seen this philosophy when discussing the example of different coordinatisations of a three-dimensional vector space ")#mi("{V}")#text(". One can simply forget about coordinatisations altogether, and view ")#mi("{V}")#text(" as an abstract vector space ")#mi("{V = (V,0,+,\\cdot)}")#text(", with the only operations initially available on ")#mi("{V}")#text(" being that of addition and scalar multiplication, which obey a ")#link("http://en.wikipedia.org/wiki/Vector_space#Definition")[#text("standard set of compatibility axioms")]#text(" which we omit here. (Thus, for instance, the dot product of two vectors in ")#mi("{V}")#text(" would be undefined, due to the lack of a canonical inner product structure on this space.) The ")#link("http://en.wikipedia.org/wiki/Dual_space")[#text("dual space")]#text(" ")#mi("{V^*}")#text(" of covectors is also a three-dimensional vector space, but because there is no canonical identification between ")#mi("{V}")#text(" and ")#mi("{V^*}")#text(", there is no way (with only these minimal structural operations) to equate a vector to a covector, or to add a vector to a covector. Thus, in this framework, dimensionally inconsistent operations are not just inconvenient to use; they are impossible to write down in the first place (unless one introduces some non-canonical choices, such as an identification of ")#mi("{V}")#text(" with ")#mi("{{\\bf R}^3}")#text(").")

#text("One can add or remove structures to this vector space ")#mi("{V}")#text(", depending on the situation. For instance, if one wants to remove the preferred origin from the vector space, one can work instead with the slightly weaker structure of an ")#link("http://en.wikipedia.org/wiki/Affine_space")[#text("affine space")]#text(", in which no preferred origin is present. In order to recover the operations of Euclidean geometry, one can then place a ")#link("http://en.wikipedia.org/wiki/Euclidean_metric")[#text("Euclidean metric")]#text(" on the affine space; in some situations, one may also wish to add an ")#link("http://en.wikipedia.org/wiki/Orientation_(vector_space)")[#text("orientation")]#text(" or a ")#link("http://en.wikipedia.org/wiki/Haar_measure")[#text("Haar measure")]#text(" to the list of structures. By adding or deleting such structures, one changes the group of isomorphisms of the space (or the ")#link("http://en.wikipedia.org/wiki/Groupoid")[#text("groupoid")]#text(" of isomorphisms between different spaces in the same category), which serve as the analogue of the structure group in the parametric viewpoint. For instance, for a three-dimensional vector space with no additional structure, the group of isomorphisms is ")#mi("{GL_3({\\bf R})}")#text(" (or more precisely, the group is isomorphic to this matrix group). Adding a Euclidean metric on this space reduces the group to ")#mi("{O_3({\\bf R})}")#text(", but then deleting the origin increases it again to ")#mi("{E_3({\\bf R})}")#text(", and so forth. In the Kleinian approach to geometry as described by the ")#link("http://en.wikipedia.org/wiki/Erlangen_program")[#text("Erlangen program")]#text(", the group of isomorphisms plays a primary role; indeed, one can view any given type of geometry (e.g. Euclidean geometry, affine geometry, projective geometry, spherical geometry, etc.) as the study of all structures on a given ")#link("http://en.wikipedia.org/wiki/Homogeneous_space")[#text("homogeneous space")]#text(" that are invariant with respect to the action of the group of isomorphisms.")

#text("Many foundational mathematical structures (e.g. vector spaces, groups, rings, fields, topological spaces, measure spaces, etc.) are routinely presented in this sort of abstract, axiomatic framework, without reference to explicit coordinates or number systems. (But there are some exceptions; for instance, the standard definition of a smooth manifold (or a complex manifold, etc.) makes reference to an altas of smooth coordinate charts, the standard definition of an algebraic variety or scheme makes reference to affine charts, and so forth.) One can apply the same abstract perspective to scalars, such as the length or mass of an object, by viewing these quantities as lying in an abstract one-dimensional real vector space, rather than in a copy of ")#mi("{{\\bf R}}")#text(".")

#text("For instance, to continue the example of the ")#mi("{M,L,T}")#text(" system of dimensions from the previous section, we can postulate the existence of three one-dimensional real vector spaces ")#mi("{V^M, V^L, V^T}")#text(" (which are supposed to represent the vector space of possible masses, lengths, and times, where we permit for now the possibility of negative values for these units). As it is physically natural to distinguish between positive and negative masses, lengths, or times, we endow these one-dimensional spaces with a total ordering (obeying the obvious compatibility conditions with the vector space structure), so that these spaces are ordered one-dimensional real vector spaces. However, we do not designate a preferred unit in these spaces (which would identify each of them with ")#mi("{{\\bf R}}")#text(").")

#text("We can then use basic algebraic operations such as tensor product to create further one-dimensional real vector spaces, without ever needing to explicitly invoke a coordinate system (except perhaps in the ")#emph[#text("proofs")]#text(" of some foundational lemmas, though not in the ")#emph[#text("statements")]#text(" of those lemmas). For instance, one can define ")#mi("{V^{ML}}")#text(" to be the ")#link("http://en.wikipedia.org/wiki/Tensor_product")[#text("tensor product")]#text(" ")#mi("{V^M \\otimes V^L}")#text(" of ")#mi("{V^M}")#text(" and ")#mi("{V^L}")#text(", which can be defined categorically as the universal vector space with a bilinear product ")#mi("{\\cdot: V^M \\times V^L \\rightarrow V^{ML}}")#text(" (thus any other bilinear product ")#mi("{\\tilde \\cdot: V^M \\times V^L \\rightarrow W}")#text(" must factor uniquely through the universal bilinear product). Note that we can canonically place an ordering on this tensor product ")#mi("{V^{ML}}")#text(" by declaring the tensor product of two positive quantities to again be positive. Similarly, one can define ")#mi("{V^{T^{-1}}}")#text(" as the dual space to ")#mi("{V^T}")#text(" (with a linear functional on ")#mi("{V^T}")#text(" being positive if it is positive on positive values of ")#mi("{V^T}")#text("), define ")#mi("{V^{LT^{-1}}}")#text(" as the tensor product of ")#mi("{V^L}")#text(" and ")#mi("{V^{T^{-1}}}")#text(", and so forth. This leads to a definition of ")#mi("{V^{M^a L^b T^c}}")#text(" for any integers ")#mi("{a,b,c}")#text(" (actually, to be pedantic, it leads to multiple definitions of ")#mi("{V^{M^a L^b T^c}}")#text(" for each ")#mi("{a,b,c}")#text(", but these definitions can are canonically and ")#link("http://en.wikipedia.org/wiki/Natural_transformation")[#text("naturally")]#text(" isomorphic to each other, and so by abuse of notation one can safely treat them as being a single definition). With a bit of additional effort (and taking full advantage of the one-dimensionality of the vector spaces), one can also define spaces with fractional exponents; for instance, one can define ")#mi("{V^{L^{1/2}}}")#text(" as the space of formal signed square roots ")#mi("{\\pm l^{1/2}}")#text(" of non-negative elements ")#mi("{l}")#text(" in ")#mi("{V^L}")#text(", with a rather complicated but explicitly definable rule for addition and scalar multiplication. (Such formal square roots do occasionally appear naturally in mathematical applications; for instance, ")#link("http://en.wikipedia.org/wiki/Tensor_field#Twisting_by_a_line_bundle")[#text("half-densities")]#text(" (formal square roots of measures) arise naturally in the theory of Fourier integral operators. However, when working with vector-valued quantities in two and higher dimensions, there are representation-theoretic obstructions to taking arbitrary fractional powers of units (though the double cover of orthogonal groups by ")#link("http://en.wikipedia.org/wiki/Spin_group")[#text("spin groups")]#text(" does allow for ")#link("http://en.wikipedia.org/wiki/Spinor")[#text("spinor")]#text("-valued quantities whose “dimension” is in some sense the square root of that of a vector).")

#text("If one views elements of ")#mi("{V^{M^a L^b T^c}}")#text(" as having dimension ")#mi("{M^a L^b T^c}")#text(" then, operations which are dimensionally consistent are well-defined, but operations which are dimensionally inconsistent are not. For instance, one can multiply an element in ")#mi("{V^{M^a L^b T^c}}")#text(" with an element in ")#mi("{V^{M^{a^{\\prime}} L^{b^{\\prime}} T^{c^{\\prime}}}}")#text(" to obtain a product in ")#mi("{V^{M^{a+a^{\\prime}} L^{b+b^{\\prime}}T^{c+c^{\\prime}}}}")#text(", but one cannot canonically place this product in any other space ")#mi("{V^{M^{\\tilde a} L^{\\tilde b} T^{\\tilde c}}}")#text(". One can compare two quantities ")#mi("{x}")#text(" and ")#mi("{y}")#text(" (i.e. decide if ")#mi("{x=y}")#text(", ")#mi("{x<y}")#text(", or ")#mi("{x>y}")#text(" if they lie in the same spaces ")#mi("{V^{M^a L^b T^c}}")#text(", but not if they lie in different spaces (particularly if one is careful to keep the origins ")#mi("{0_{V^{M^a L^b T^c}}}")#text(" of each of these vector spaces ")#mi("{V^{M^a L^b T^c}}")#text(" distinct from each other). And so forth. Subject to the requirement of dimensional consistency, all the usual laws of algebra continue to hold; for instance, the distributive law ")#mi("{x(y+z)=xy+xz}")#text(" continues to hold as long as ")#mi("{y,z}")#text(" have the same dimension. (The situation here is similar to that of a ")#link("http://en.wikipedia.org/wiki/Graded_algebra")[#text("graded algebra")]#text(", except that one does not permit addition of objects of different dimensions or gradings.) Thus, one expects many proofs of results that work in a dimensionless context to translate over to this abstract dimensionful setting. However, some results will not translate into this framework due to their dimensional inconsistency. For instance, the inequality ")#link(<tao-626cf6d4f7ea4f20b105>)[#text("(2)")]#text(" does not make sense if ")#mi("{l}")#text(" lies in ")#mi("{V^L}")#text(" and ")#mi("{v}")#text(" lies in ")#mi("{V^{LT^{-1}}}")#text(", and similarly the inequality ")#link(<tao-1f447d77f0b62b06ea12>)[#text("(5)")]#text(" does not make sense for ")#mi("{f}")#text(" a nice function from ")#mi("{V^L}")#text(" to ")#mi("{V^A}")#text(". (Note that the usual definitions of integral and dimension (as limits of Riemann sums and Newton quotients respectively) can be extended to this abstract dimensionful setting, so long as one keeps track of the dimensionality of all objects involved.) But if a statement is dimensionally consistent and can be proven in a dimensionless framework, then it should be provable in the abstract dimensionful setting as well (indeed, if all else fails, one can simply pick a set of coordinates to express all the abstract quantities here numerically, and then run the dimensionless argument). So, while the abstract framework is apparently less powerful than the parameterised framework due to the restricted number of operations available, in practice it can be a more useful framework to work in, as the operations that remain in the framework tend to be precisely the ones that one actually needs to solve problems (provided, of course, that one has chosen the right abstract formalism that is adapted to the symmetries of the situation).")

#text("It is possible to convert the abstract framework into the parametric one by making some non-canonical choices of a reference unit system. For instance, in the abstract ")#mi("{M,L,T}")#text(" dimensional system, after selecting a reference system of units ")#mi("{M_0 \\in V^M}")#text(", ")#mi("{L_0 \\in V^L}")#text(", ")#mi("{T_0 \\in V^T}")#text(", one can then identify ")#mi("{{\\bf R}^{M^a L^b T^c}}")#text(" with ")#mi("{{\\bf R}}")#text(" by identifying ")#mi("{M_0^a L_0^b T_0^c}")#text(" with ")#mi("{1}")#text(", so that any ")#mi("{x \\in {\\bf R}^{M^a L^b T^c}}")#text(" gets identified with some real number ")#mi("{\\tilde x \\in {\\bf R}}")#text(". For any ")#mi("{M,L,T \\in {\\bf R}^+}")#text(", one can then replace the units ")#mi("{M_0,L_0,T_0}")#text(" with rescaled units ")#mi("{MM_0, LL_0, TT_0}")#text(", which changes the identification of ")#mi("{{\\bf R}^{M^a L^b T^c}}")#text(" with ")#mi("{{\\bf R}}")#text(", so that an element ")#mi("{x \\in {\\bf R}^{M^aL^bT^c}}")#text(" is now identified with the real number")

#align(center)[#tao-fit-display[#mitex("x_{M,L,T} := \\tilde x M^{-a} L^{-b} T^{-c}")]]

#text("which is of course just ")#link(<tao-bf92a04e60b4b2362d45>)[#text("(1)")]#text(". Thus we see that after selecting a reference unit system, one can convert an object ")#mi("{x}")#text(" which has dimension ")#mi("{M^a L^b T^c}")#text(" in the abstract framework into an object ")#mi("{x_{M,L,T}}")#text(" which has dimension ")#mi("{M^a L^b T^c}")#text(" in the parametric framework; conversely, every object ")#mi("{x_{M,L,T}}")#text(" that has dimension ")#mi("{M^a L^b T^c}")#text(" in the parametric framework arises from a unique object ")#mi("{x}")#text(" in the abstract framework (if one keeps the reference units ")#mi("{M_0,L_0,T_0}")#text(" fixed). Similarly for sets of objects, or functions between such sets. Note though that objects in the parametric dimension that do not have a single dimension, but rather some hybrid of various dimensions, do not correspond to any particular object in the abstract setting, unless one performs some additional algebraic constructions in the latter setting, such as taking formal sums of spaces of different dimensionalities.")

#text("The need to select some arbitrary reference units ")#mi("{M_0,L_0,T_0}")#text(" in order to connect the abstract and parametric frameworks is a bit inelegant. One way to avoid this (which was alluded to previously) is to interpret ")#mi("{M,L,T}")#text(" not as scalars in ")#mi("{{\\bf R}}")#text(", but rather as elements of the ")#mi("{{\\bf R}}")#text("-torsors ")#mi("{V^M}")#text(", ")#mi("{V^L}")#text(", ")#mi("{V^T}")#text(" respectively. With this modification to the parametric framework, the reference units ")#mi("{M_0,L_0,T_0}")#text(" can now be omitted. On the other hand, by turning the parameters ")#mi("{M,L,T}")#text(" into abstractly dimensionful quantities instead of dimensionless scalars, one loses some of the power of the parametric model, namely the power to perform numerical operations even if they are dimensionally inconsistent, and so one may as well work entirely in the abstract setting instead.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (94)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ff76cf15ee691f3228f1b9198d839fcdfb0ecf33f2a3a81142120dc32933a071-d8f2c818180533ed0e6a5f6314e49d86208ca6227e6198d8c0b83c3b930e71d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ted")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-492129")[#strong[#text("Ted")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2018")])]

#text("You say that one can define spaces with fractional exponents – is there a way to extend this construction to irrational exponents? Physical quantities with dimensions that are irrational powers of the base units come up as, e.g., the prefactors in two-point correlation functions for interacting conformal field theories.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-493421")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2018")])]

#text("I’m still trying to read this article, which seems very fancy. I would have guessed that physical quantity was a pair (r,u) where r is a real number and u is an element of the free abelian group generated by the ground units (length, mass, time, etc.). I guess the addition rule (a,u)+(b,u) doesn’t work for things like temperatures though, which is why it is a torsor (modulo the discussion about absolute zero further up). Hmm.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ffbe26eaa7562bfc2eadd58d82c2e3baa5a214b699bde222bff498ae0eb93bc-3cd3bdd79fe6bec076ce6aaf6c1c7299f2805c49a9cc01dec919301c0193a933.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ted")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-506172")[#strong[#text("Ted")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2018")])]

#text("One slightly unfortunate aspect of considering dimensionful quantities as tensor products of 1D vector spaces is that the commutativity of multiplication is not very natural. We can’t simply promote naive products to tensor products, because then e.g. the unit (length*time) would be inequivalent to the unit (time*length). To remedy this, we need to e.g. fix some arbitrary ordering, e.g. that all the “length” basis vectors go to the left of all of the “time” basis vectors, which isn’t terribly natural.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-506466")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2018")])]

#text("Well, in practice this is not a problem because there is a canonical isomorphism ")#mi("\\iota: X \\otimes Y \\to Y \\otimes X")#text(" between the two different ways to take the tensor product of two vector spaces (and similarly for tensor products ")#mi("(X \\otimes Y) \\otimes Z")#text(", ")#mi("X \\otimes (Y \\otimes Z)")#text(" of three spaces). So, up to the abuse of notation of identifying these two spaces, multiplication becomes commutative and associative again.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c452aeb7466293c4d827463d0019c9e7e83db8113210de3cd436ad5a6093b6c-55babe53ec9286a3e73d2949aab1cc1cf2290a7ce6922e82b05f568081353233.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ashok M Dhareshwar")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-524056")[#strong[#text("Ashok M Dhareshwar")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2019")])]

#text("There is the project of establishing sound foundation for measurement by Krantz, Luce, Suppes and Tversky, which has resulted in a series of volumes entitled Foundations of Measurement. Is there any significant overlap between that project and your project of foundations of dimensional analysis?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c7e0073c3d142938221110a30b48634631b7bd464edb0e00ab5d6e3d5939410-3f1843500b4f5751ad4393c38f9375d8b2df581130e76ad9bd4334723fab6dc1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josh Samani")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-566222")[#strong[#text("Josh Samani")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2020")])]

#text("Perhaps you’re already aware of this, but Whitney formalized dimensional analysis as well in “The mathematics of physical quantities: Part II: Quantity structures and dimensional analysis.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e04abdde587ed7bf8395e4d35b8d71817de211264d3a2e86cccea4fd767605f1-9f9271afb64e3af46f3f904d262a11f8aeecf178d36678f389cef10d8ed2e493.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mauricio Calvao")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-576202")[#strong[#text("Mauricio Calvao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2020")])]

#text("Sometimes (e. g. Gelfand & Fomin, “Calculus of variations”, Chap. 1, Sec. 2; or Kreiszig, “Introductory functional analysis with applications”, Chap. 2, Sec. 9, Prob. 6) people define a norm on the real vector space ")#mi("C^1[a,b]")#text(" of all real-valued functions ")#mi("x(t)")#text(" with closed interval ")#mi("[a,b]")#text(" for domain, via:")

#tao-math("\\displaystyle \\left\\|x\\right\\|_1 := max_{a\\leq t\\leq b}\\left|x(t)\\right| + max_{a\\leq t \\leq b}\\left|x^{\\prime}(t)\\right|,", block: false)

#text("where, of course, ")#mi("x^{\\prime}")#text(" is the derivative of ")#mi("x")#text(".")

#text("How can that be for cases where ")#mi("t")#text(" is *not* a dimensionless quantity, since then ")#mi("x")#text(" and ")#mi("x^{\\prime}")#text(" do not have the same dimensions and thus cannot be compared (added) at all? I do intuit this norm is trying, through the corresponding distance ")#mi("\\|x-x*\\|")#text(" between two arbitrary functions in ")#mi("C^1[a,b]")#text(", to formalize the notion that not only they have nearby values but also do so their derivatives; however it seems to miss the mark (just think of ")#mi("x(t)")#text(" for ")#mi("x")#text(" a position, with dimension of length, and ")#mi("t")#text(" an instant, with dimension of time). If we modified the above norm so as to include a dimensional constant factor ")#mi("C")#text(", with the same dimension of ")#mi("t")#text(", in the second term of the RHS, then, dimensionally everything would now be fine. However, our results would seem to be dependent on this choice of scale, since these two norms would not be equivalent… Perhaps this is unavoidable and reflects the arbitrary choice of a tolerance degree in our comparison of the functions, taking into account their first derivatives. Of course, this issue is clearly generalized to ")#mi("C^k[a,b]")#text(" spaces.")

#text("Thanks for any comments and clarifications.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-578117")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2020")])]

#text("You are correct that inhomogeneous norms such as the standard ")#mi("C^k")#text(" norms do not have a scale invariance and so cannot be assigned a single “dimension”; at best they can be viewed as a combination of expressions of different homogeneity, and as such they are sensitive to the choice of unit length scale. If one wants to proceed in a unit-independent fashion then the fix is as you say, to introduce a length scale parameter in front of the terms involving derivatives and to permit the inhomogeneous norms to depend on this choice of parameter. For instance, in ")#link("https://arxiv.org/abs/1811.09223")[#text("this recent paper of mine")]#text(" I relied quite frequently on such scale-dependent ")#mi("C^k")#text(" and Holder norms, see page 9.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ffbe26eaa7562bfc2eadd58d82c2e3baa5a214b699bde222bff498ae0eb93bc-3cd3bdd79fe6bec076ce6aaf6c1c7299f2805c49a9cc01dec919301c0193a933.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ted")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-578170")[#strong[#text("Ted")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2020")])]

#text("What do you mean by “inhomogeneous norm”? I thought that “homogeneous” meant that scaling the vector by a scalar scales the norm by the absolute value of the same scalar (which, as far I can tell, is indeed the case for the $C^k$ norm), and that this property is part of the definition of a norm.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-578171")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2020")])]

#text("All norms are homogeneous in that sense but when people call a norm homogeneous they mean the fourier multipliers that appear in the definition have the same homogeneity (eg. homogeneous H^2 has the symbol |\\xi|^2 rather than 1+|\\xi|^2)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-578172")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2020")])]

#text("Correction: a better definition of homogeneous norm would be \\|f(lambda x)\\|=|lambda|^\\alpha\\|f\\|")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ffbe26eaa7562bfc2eadd58d82c2e3baa5a214b699bde222bff498ae0eb93bc-3cd3bdd79fe6bec076ce6aaf6c1c7299f2805c49a9cc01dec919301c0193a933.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ted")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-578358")[#strong[#text("Ted")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2020")])]

#text("Anonymous, in your second comment, do you mean $|f(\\lambda x)| = |\\lambda|^\\alpha |f(x)|$, where $\\lambda$ and $x$ are an arbitrary scalar and vector respectively and $f$ represents the norm? In that case, your equation is trivially true by definition for all norms, with $\\alpha = 1$.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-578375")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2020")])]

#text("No; here ")#mi("f(x)")#text(" is shorthand for ")#mi("x \\mapsto f(x)")#text(" – a function in the function space of interest (e.g., a Holder space or a Sobolev space) – and ")#mi("f(\\lambda x)")#text(" is shorthand for ")#mi("x \\mapsto f(\\lambda x)")#text(" – a rescaled version of ")#mi("f")#text(" formed by dilating the underlying variable. For instance, if the function space in question is ")#mi("L^p({\\bf R}^d)")#text(", then ")#tao-math("\\left\\| f(\\lambda x) \\right\\|_{L^p({\\bf R}^d)} = \\left|\\lambda\\right|^{-d/p} \\left\\|f(x) \\right\\|_{L^p({\\bf R}^d)}", block: false)#text(", thus the ")#mi("L^p({\\bf R}^d)")#text(" norm is homogeneous with exponent ")#mi("d/p")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ffbe26eaa7562bfc2eadd58d82c2e3baa5a214b699bde222bff498ae0eb93bc-3cd3bdd79fe6bec076ce6aaf6c1c7299f2805c49a9cc01dec919301c0193a933.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ted")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-578451")[#strong[#text("Ted")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2020")])]

#text("Ah, I see, thank you.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-642982")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2022")])]

#text("I think this area lack something. deletion and annihilation can’t be expressed as minus – . $a_{-1} \\oplus a = null $ such math symbol . But I don’t know is there any other people have done these work.")

#text("here is the paper about this area.")

#link("https://www.zhihu.com/question/273505468/answer/2425536318")[#text("https://www.zhihu.com/question/273505468/answer/2425536318")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-684615")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2024")])]

#text("Hello, I follow you from Turkey. I’m a civil engineer. As I was thinking about multiplication and understanding the nature of numbers, something started to confuse me. I realized that the multiplication we do when finding the area of a square is actually a magnitude in two different dimensions.")

#link("https://hizliresim.com/pejwcb5")[#text("https://hizliresim.com/pejwcb5")]

#text("First, consider a square with sides $4m$ long. The number $4$ and its unit is Meter. While one of these edges is on the x axis, the other is on the z axis. We multiply these edges $(4m)$, which are two different sizes, and an area emerges $16^{2}$. But the problem starts at this point. For example, if we multiply two 4m long edges on the x-axis, the result will be meaningless. Because we can multiply the length of 4m, which is the unit given by a number of the same size, by a number. For example, $(4m)")#emph[#text("cdot")]#text("(4)$=16m Or we can multiply a 4m vector by a number. However, doesn’t $(4m)")#emph[#text("cdot")]#text("(4m)$=undefined in one dimension? However, if there are two different sizes, I think these sizes are defined. So is there such a thing as dimensional warping? By size I don’t mean units. Thank you professor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-685768")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2024")])]

#text("Here is a recent paper on the topic, a more abstract version: ")#link("https://arxiv.org/pdf/2108.08703")[#text("https://arxiv.org/pdf/2108.08703")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-687013")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2025")])]

#text("I tried posting a comment earlier about a potential issue I see with the approach taken here, but my comment seems to have disappeared. Perhaps this one will suffer the same fate, but in case it doesn’t, I’ve asked a question ")#link("https://math.stackexchange.com/questions/5020651/how-to-remove-explicit-choice-of-physical-quantities-from-mathematical-model-of?noredirect=1#comment10771534_5020651")[#text("here")]#text(" on Math.SE, based on my previous comment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-687014")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2025")])]

#text("Terry, I haven’t read all of the comments, so I don’t know if anyone has observed the following yet:")

#list(
[#text("This type of dimensional analysis also arises naturally but more simply in finance, because each asset type has a value relative to any other asset type. In practice, you always choose a base asset, such as US dollars, to measure the value of every other asset. But in principle, any asset can be used as the base asset. It is in this context that I first realized that dimensional analysis could be modeled by 1-dimensional vector spaces, their duals and tensor products, and 1-dimensional affine spaces. I in fact implemented this in C++ code, where these concepts combined with strong type checking caught a lot of my coding errors.")],
[#text("It is in fact useful to distinguish between affine quantities and linear ones:")

#list(
[#text("A quantity such as time or change in temperature is modeled by a 1-dimensional vector space.")],
[#text("A quantity such as temperature is modeled by a 1-dimensional affine space (possibly with boundary), where the associated vector space models the change in the affine quantity.")],
[#text("For example, it makes no sense to add two temperature measurements but it does makes sense to add a change in temperature to a temperature")],
[#text("Physical quantities that can’t be negative, such as mass is modeled by a closed half-line where you can add, rescale by a non-negative factor, and subtract, as long as you don’t go below zero. I’m not sure what the mathematical term for this is. Is it a module over the nonnegative reals?")]
)]
)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-688204")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2025")])]

#text("I’m trying to grasp the relations between the representation of base quantities and the representation of change or gradients of those base quantities. Your comment helped me by distinguishing affine and linear quantities, but I wonder if that distinction is specific to some physical quantities (e.g., temperature) or if it can be generalized. For example, in the case of mass, which you pointed out, representing it in a vector space means accepting negative masses, since additive inverses must be present… An affine space would not bring this issue.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-688205")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2025")])]

#text("Formally, one could view masses that are restricted for physical reasons to be positive to lie in a ")#link("https://en.wikipedia.org/wiki/Convex_cone")[#text("convex cone")]#text(" inside a one-dimensional vector space, if desired.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-2/#comment-687025")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2025")])]

#text("I wonder why there is so less material upon this subject. I myself as a “overthinking” engineer always wondered, that at university, one learns tons of math about number systems and their abstract properties like groups, rings and fields, but from day one in a physics course, one has to calculate with scalar physical quantities and I haven’t seen any rigorous explanation or formalization of how to treat physical quantities mathematically. Every course or textbook I’ve seen treats physical quantities like numbers with units attached to it (by multiplication, sort of) and deal with units like numerical factors or constants obeying the laws of algebra of real numbers. For instance, if I divide 5m by 3s, I get a fraction if 5m/3s and dealing “m” and “s” as numerical factors, I can get 5/3 *m/s, or I could say 5/s * m/3.")

#text("If one things about it from a real world perspective, it makes sense and the mathematical framework seems to work, but since I’m a person that likes to know exactly what I’m doing, this discomforts me nevertheless.")

#text("Thanks for the article!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3c2b5af328c046ad3222de5d3fbfa56eb118548a20b08cd3b472c0a6fb3cbd7-cb521af920a1a26d12cba6c4635b57704aede715672ea4b080b54a9ae78bc458.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S J Green")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211411")[#strong[#text("S J Green")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2012")])]

#text("It always annoys me in thermodynamics lectures and books were expressions are routinely used such as ")#mi("\\text{ln} T")#text(" and ")#mi("\\text{ln} T")#text(", where T is the temperature and V is the volume. I always tried to rewrite these in terms such as ")#mi("\\text{ln}V/V_0")#text(" to get the correct dimensionality.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211479")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2012")])]

#text("The logarithm of an absolute temperature is an element in a one dimensional affine space, because the zero point of the logarithm depend on the unit of temperature: log(300 kelvin) = log(300) + log(kelvin). Also: log(10 liter) = log(10) + log(liter). Here the expressions log(kelvin) and log(liter) are zero points. The unit of the logarithm depend on the base: log(300) = 2.47712 log(10) = 5.70378 log(e) = 8.22882 log(2). Here log(10) and log(e) and log(2) are units of measurement of logarithms. The symbol log may be any old logarithm, natural or decadic or binary or whatever. The Planck constants, h and h-bar, are but one constant measured in two units: h is measured in joule second per wave, and h-bar is measured in joule second per radian, where radian = i log(e) and wave = 2 log(-1) = 2 pi radian. Omitting the unit of angle leads to confusion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211440")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2012")])]

#text("Typos:")

#text("“where {L = …}” should show a 3×3 matrix")

#text("For “acordingy” read accordingly”")

#text("For “all terms either have” read “either all terms have”")

#text("For “spatial vector” suggest traditional “polar vector”")

#text("For “square roots of that” read “square root of that”")

#text("Quote:")#linebreak()#text(" “the standard definition of a smooth manifold (or a complex manifold, etc.)")#linebreak()#text(" makes reference to an altas of smooth coordinate charts, …”")#linebreak()#text(" Nice insight, nailing a concrete explanation for why I should")#linebreak()#text(" always have felt unhappy about these definitions.")#linebreak()#text(" Nevertheless, the diff. geom. fraternity blithely refer to them")#linebreak()#text(" as “abstract” (in contrast to embedded in Euclidean space)!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e0921c3e80b8ddc5e6b1ef369085d319f2b10fc658e85112dc618b7a5017efa-53707146d243075aac73037d130b8829a3f66a14cf54edc71d05840b60b76d70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of morningsideroad")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211446")[#strong[#text("morningsideroad")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2012")])]

#text("Reblogged this on ")#link("http://morningsideroad.wordpress.com/2012/12/30/a-mathematical-formalisation-of-dimensional-analysis/")[#text("morningsideroad")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae8461e0132a14b601b9e759b29e8bf55ab18c2e8319bea84c92705f045afceb-2355733f005069d29ef94b3b79978270f4125505ecbb25a228ec7a4084166b3e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211461")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2012")])]

#text("So called type theory in functional programming languages is concerned with similar issues")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b7e2a1bd0526391c20e26577dd944eca8d0cb6691746df2afe6fd2b2c94e086-20257719d9ae3d6d0e100d3ea8225b8877f47930a8ee8c92d310256210c9063e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211462")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2012")])]

#text("a very small contribution to this great post: typo in the third to last paragraph: “choicess” :-)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/19d9f4f49d6afd3df615dc2291abba1d73b4536c685c5337e80319ad6c58f144-fe3ad7b32c9fa7584c674a2335baf89f0cde67898de31a28b20677da4fbd1e05.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anirudh Kumar Satsangi")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211494")[#strong[#text("Anirudh Kumar Satsangi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2012")])]

#text("Spiritual Quotient can be expressed mathematically as the ratio of parasympathetic dominance to sympathetic dominance. I have discoved this relationship")

#text("I have discovered a mathematical formula to measure spirituality in physiological terms. In this mathematical relationship spiritual quotient (SQ) can be expressed mathematically as the ratio of parasympathetic dominance to sympathetic dominance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f98160844e931d158077bdf7cfb95acd4ff8ab720fbdfc4b113a8362df5be7cf-4a552d29e7a6f3b09a9bf9d95329b64bd71333e48b87d5ce1f33236224164ab9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lindsay Rex")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211513")[#strong[#text("Lindsay Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2012")])]

#text("I love this this idea. It seems similar to the way I write and practise composing music using computer based tools. I always look for finding new ways of collapsing complexity in my creative processes. I have current processes to produce an X musical idea, which is difficult, and then find a new method, that is on a higher/parallel order, but requires less effort to ‘create’ the same output of the existing method. If the new process is not equivariant , it is usually apparent in the lack of harmonic or melodic completeness.")

#text("On another note, could you meta program proofs from this idea? I can clearly see the benefit of using the mathematical construct of defining dimensions algorithmically, to test for new dimensional properties of suspected ‘new’ objects by breeding (testing for properties) genetically?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chorasimilarity")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211568")[#strong[#text("chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2012")])]

#text("Re:”For instance, the ancient Greeks were able to prove many theorems in Euclidean geometry, well before the development of Cartesian coordinates and analytic geometry in the seventeenth century”, it is funny to notice that the ancient greek term ")#link("http://en.wikipedia.org/wiki/Gnomon")[#text("gnomon")]#text(" (which has “measuring stick” as one of its meanings) appears computer graphics. Wiki dixit: “A three dimensional gnomon is commonly used in CAD and computer graphics as an aid to positioning objects in the virtual world. By convention, the X axis direction is colored red, the Y axis green and the Z axis blue.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91ba065c8bb4f7d002b7842a03f300980122cd55943861d33657023f8cd401c6-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211580")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2012")])]

#text("In thermodynamics conserved quantities possess an natural additive structure. E.g., it commonly happens that mass, energy, and charge all are conserved quantities; thus (mass+energy+charge) and (mass-energy-2*charge) etc. are conserved also, such that conserved quantities are naturally endowed with a vector-space structure.")

#text("Where there is a vector space there also is a dual space, and in thermodynamics the convexity of the entropy function specifies a natural dual space via the Legendre transform; a terrific article in this regard is Zia, Redish, and McKay ")#emph[#text("Making sense of the Legendre transform")]#text(" (2009).")

#text("In this view, physical units are associated with basis vectors of the vector space of thermodynamically conserved quantities. Every basis vector has a thermodynamically natural dual potential, and in particular the thermodynamical functions are defined in terms of fluctuations via Onsager relations (or in mathematical terms, Frobenius integrability relations).")

#text("In what sense is {mass,energy} a preferred basis, while {mass+energy,mass-energy} is not preferred? This has to do with how we humans observe, control, and interact with thermodynamic systems, and as Charles Kittel has noted: “It is rarely a trivial problem to find the correct choice of (generalized) forces and fluxes applicable to the Onsager relations.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chorasimilarity")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211589")[#strong[#text("chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2012")])]

#text("In continuum media mechanics, the Legendre transform in convex (but not smooth) context, as well as its relations to termodynamics, are basic, well-known facts. It is the main part of a beautiful theory, the one of standard materials (or standard constitutive laws). From the ’70s to the 90’s, probably half of the advances in engineering are due to this theory.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91ba065c8bb4f7d002b7842a03f300980122cd55943861d33657023f8cd401c6-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211591")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2012")])]

#text("This is true not only in mechanical engineering, but more broadly across multiple scientific disciplines, per")#linebreak()#text(" Martyushev and Seleznev’s review “Maximum entropy production principle in physics, chemistry and biology” (")#emph[#text("Physics Reports")]#text(", 2006). Yet even this magisterial review is substantially handicapped by (1) the results not being expressed within an abstract/natural mathematical framework, and (2) quantum effects are almost entirely ignored. Possibly lack (1) is largely responsible for lack (2)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chorasimilarity")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211593")[#strong[#text("chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2012")])]

#text("Probably so! The story of the Legendre transform in convex analysis is that it started from some efforts back in the ’50s (?) with the aim to model Coulomb friction, then continued with some engineering tricks, but stating from some point (with Moreau basically) it just fluorished into a solid part of what is now called “convex analysis”. It turned out that there is a theory which could be applied (up to obtaining good algorithms for solving engineering problems) for a large class of materials (like steel, say) and engineering problems. But what caused all this explosion of “generalized standard materials” was simply the fact that it has been formulated as a “pure” mathematical theory. Now it is part of the basic curriculum in applied math and mechanics, in France, for example.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chorasimilarity")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211594")[#strong[#text("chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2012")])]

#text("Sorry for being off-topic, here is the start of the story: ")#link("http://archive.numdam.org/article/SJL_1966-1967___2_1_0.pdf")[#text("J.J. Moreau, Fonctionnelles convexes. Séminaire Jean Leray, 2 (1966-1967), p. 1-108")]#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e3f51c6a4616b904a7bf913f57e004c4e90b40197bcf1ff6acdc57863f5247e4-ddea01dcc2ac783e388889925dc3074dc7f939ee50f5de691bc70ec31b0fa2a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sylvester J.Ryan")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211623")[#strong[#text("Sylvester J.Ryan")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2012")])]

#text("To me, this excellent flow of thoughts is another attempt to relate multiplication to the additive process..but is x+x+x..= n times x.., when there are the multiple products as the Cartesian product, the dot product, the exterior products..reminds me of the oft stated concept of one differential, but multiple integral calculi..various algebras have been submitted with amazing results..but as with the philosophical foundations of Quantum physics and that of the Einsteinian logicism, no mesh as yet..it probably awaits another Hamilton or Maxwell, or better yet the realization of the value of an unrecognized mathematical approach, already lying fallow in the pages of a mathematical memoir")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/794c16caee5db46d7638dc1bae9f85c84fc5b989280ad61d6058aa1e2f410720-01efd1e657b7860ee983e131905ef337703f583cda3366a6c482f86197ba464d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jjqphysics")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211647")[#strong[#text("jjqphysics")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2012")])]

#text("Reblogged this on ")#link("http://jiaqijiang.wordpress.com/2013/01/01/58/")[#text("What about being a physicist")]#text(" and commented:")#linebreak()#text(" Need to read this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymouse")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211786")[#strong[#text("Anonymouse")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2013")])]

#text("The sense in which the exponential function takes dimensionless numbers as arguments and returns dimensionless numbers as values is rather subtle. exp is, after all, a specific case of the exponential map on manifolds, which takes a tangent vector as argument and produces a point on the manifold (which we can think of for small arguments in terms of a geodesic arclength).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211806")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2013")])]

#text("Hmm, interesting point. Of course, for the classical exponential function (or, more generally, the exponential map from Lie algebras to Lie groups), the manifold involved has the structure of a group (")#mi("{\\bf R}^+ = ({\\bf R}^+, \\cdot)")#text(" or ")#mi("{\\bf C}^\\times = ({\\bf C} \\backslash \\{0\\}, \\cdot)")#text(", in the case of the classical exponential ")#mi("\\exp")#text("), which forces it to be dimensionless (otherwise the group multiplication law wouldn’t be dimensionally consistent). But you are right that on a dimensionful Riemannian manifold ")#mi("M = (M,g)")#text(" (i.e. a manifold whose metric ")#mi("g")#text(" scales in some polynomial fashion with respect to the dimensional parameters), the exponential map ")#mi("\\exp_p: T_p M \\to M")#text(" is a map between two spaces ")#mi("T_p M, M")#text(" of the same dimension, rather than between two dimensionless spaces.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c79ce32ccc641a093c2f38488766d59d2da81e8123a1cfecfded7490683588ba-660603e351f95c59c6cdd43a05d0014e6f88a60ee50036ae8b9171b7f39944bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Goen Kamg")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211919")[#strong[#text("Goen Kamg")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2013")])]

#text("Terry Tao It was pretty interesting point but I think it seems like missing something that we need try in new mathematic way.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211863")[#strong[#text("Vuelta a la carga « Adsu's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2013")]

#text("[…] empezar, un reblog de la última entrada de Terry Tao, el genio matemático actual por excelencia, el Mozart de las […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Goodbutter")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-211994")[#strong[#text("John Goodbutter")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2013")])]

#text("Following on the abstract spaces formalisation, how would one then write Newton’s second law ")#mi("\\vec F = m\\vec a")#text(" ?")#linebreak()#text(" More precisely, if we model time by an abstract one-dimensional affine space ")#mi("T")#text(", space by an abstract three-dimensional affine space ")#mi("E")#text(" and mass by a one-dimensional vector space ")#mi("M")#text(", then the position of a particle of mass ")#mi("m\\in M")#text(" is a function")#linebreak()#text(" ")#mi("x(\\cdot):T\\to E")#linebreak()#text(" To define the velocity ")#mi("v(t)")#text(" of the particle one then has to take a differential")

#mi("v:T\\to L(T,E), t\\to dx(t)")#linebreak()#text(" where ")#mi("L(T,E)")#text(" denotes the space of linear maps from ")#mi("T")#text(" to ")#mi("E")#text(", and to define the acceleration ")#mi("a")#text(" a second differential is needed :")

#mi("a:T\\to B(T,E), t\\to d^2x(t)")#text(",")

#text("where ")#mi("B(T,E)")#text(" denotes the space of bilinear maps from ")#mi("T")#text(" to ")#mi("E")#text(".")

#text("How would one then define what a force ")#mi("F")#text(" is, and then get a formula binding ")#mi("F")#text(", ")#mi("m")#text(" and ")#mi("a")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-212002")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2013")])]

#text("Strictly speaking, ")#mi("v")#text(" and ")#mi("a")#text(" should take values in ")#mi("L( \\dot T, \\dot E)")#text(" and ")#mi("B( \\dot T, \\dot E)")#text(", where ")#mi("\\dot T, \\dot E")#text(" are the homogenisations (or tangent spaces) of the affine spaces ")#mi("T, E")#text(". The force at any given time would take values in ")#mi("M \\otimes B(\\dot T, \\dot E)")#text(" or in a canonically equivalent space (e.g. ")#mi("M \\otimes \\dot T^* \\otimes \\dot T^* \\otimes \\dot E")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31de0f59f0446cc21f44204948fde4e0fb42bc4105e3e83ad425745e6a14bf0a-6424ab5f57d206bf5f02df4ba22b50e7d0f8ee7e504926d2136626376c4c55db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Goodbutter")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-212006")[#strong[#text("John Goodbutter")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2013")])]

#text("Yes, my bad for forgetting the tangent spaces… Now I guess gravity ")#mi("m\\vec g")#text(" would be written in this framework as ")#mi("m\\otimes g")#text(" where ")#mi("g")#text(" would be some element in ")#mi("B(\\dot T,\\dot E)")#text(".")

#text("But how about other forces where mass doesn’t appear explicitly, such as Lorentz force ")#mi("\\vec f=q\\vec E")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-212016")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2013")])]

#text("This would require another dimensional parameter, for instance charge, which in the abstract framework would be another one-dimensional vector space ")#mi("C")#text(". Electric field strength would then take values in ")#mi("M \\otimes \\dot T^* \\otimes \\dot T^* \\otimes \\dot E \\otimes C^*")#text(" (or an equivalent space). (Alternatively, one could work more covariantly and model electromagnetism as a U(1) gauge field, and then charge (or more precisely, the current four-vector) would take values in the space of linear transformations from the range of the electromagnetic curvature tensor to the range of the divergence of the stress-energy tensor.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Goodbutter")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-212109")[#strong[#text("John Goodbutter")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2013")])]

#text("I see, thanks for the reply!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e3c701c8770512a3129eb40ccfc8f9c7dcd8f10077907584f0e02daaa0b3a11-e06d507667d24314c1cd75a262aec85fd2a8bade7801245ffe1dad855061958b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Keegan")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-212315")[#strong[#text("Martin Keegan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2013")])]

#text("I don’t understand how this is different from type theory? And if it’s not, could we run Hindley-Milner on the whole of physics and economics and see if there are bugs? :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27e8412f888c569a9be1ea171fca277001b3529b40fd5b744477630ab233b68c-05bad328c0ff3a76596d1574691a67abec98c1884bc3f88e4c852126de63b9c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mpetrache")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-212370")[#strong[#text("mpetrache")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2013")])]

#text("Very nice post! I have one small question/doubt:")#linebreak()#text(" “(though the double cover of orthogonal groups by spin groups does allow for spinor-valued quantities whose “dimension” is in some sense the square root of that of a vector)”")

#text("Can you explain in what sense is it square root? (I would have guessed again “half” as for the half-densities)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-212456")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2013")])]

#text("Ah, for me the dimension refers to multiplicative expressions such as ")#mi("M^a L^b T^c")#text(" rather than the exponents ")#mi("a,b,c")#text(", so I tend to think of taking square roots of the dimension rather than halving the exponents. (So I would personally call half-densities the square root of densities, but the terminology seems entrenched.)")

#text("But I was a little inaccurate in asserting that spinors behave like the square root of vectors. If one takes a Clifford algebra perspective, when one takes the square of a spinor, one actually gets the sum of a vector and a scalar. (This looks dimensionally inconsistent at first glance, but the structure group here is the orthogonal group rather than R^+ and so has a different representation theory, and a different dimensional analysis.) Perhaps it’s better to say that half-integer spin quantities and integer spin quantities interact dimensionally much like odd and even functions do.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27e8412f888c569a9be1ea171fca277001b3529b40fd5b744477630ab233b68c-05bad328c0ff3a76596d1574691a67abec98c1884bc3f88e4c852126de63b9c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mpetrache")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-212587")[#strong[#text("mpetrache")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2013")])]

#text("It’s true, I had forgotten that we were using another dimension concept, thanks! I guess that many of the Lie group identifications in small dimensions could also inherit this kind of “dimensional” restatements")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb6268cbed30cccbc31d3bcb25353720767ea5fac57341b64560a2164ab98d52-b305ea421a2226f1dd4ca3d1f69533f801af6248fa89845a152498615814b636.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of d")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-216078")[#strong[#text("d")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2013")])]

#text("Nice post! I think people may misread your introduction to the two approaches as saying “Physicists use Approach 1, mathematicians use Approach 2.” Just to clarify: Approach 2 is the most common in both fields.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-216087")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2013")])]

#text("Well, for manipulating scalar quantities this may be the case, but in my experience, when manipulating vector and tensor quantities, there is certainly a preference for something like Approach 1 among physicists; in particular, they often view a tensor as an array of numbers that transforms in a certain fashion with respect to coordinate transformations, as opposed to, say, a section of a certain tensor combination of the tangent bundle and its dual, which is closer to Approach 2 and is common among mathematicians. I’ll add that clarification to the text.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-216100")[#strong[#text("The BEST Science Online (Henry’s List) | Education|Education Details and Additional Information|Details about education resources")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2013")]

#text("[…] Tao – ")#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/It’s")[#text("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/It’s")]#text(" Okay To Be Smart – […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-216224")[#strong[#text("MinutePhysics’ lijstje van beste wetenschap online | Astroblogs")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2013")]

#text("[…] Sean Carroll – http://www.preposterousuniverse.com/b… Terry Tao – https://terrytao.wordpress.com/2012/12… It’s Okay To Be Smart – http://www.itsokaytobesmart.com/post/… I ¶#@*ing Love Science […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-216241")[#strong[#text("» The BEST Science")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2013")]

#text("[…] Red Button xkcd xkcd what if? Saturday Morning Breakfast Cereal Empirical Zeal Sean Carroll Terry Tao It’s Okay To Be Smart I ¶#@*ing Love Science NASA Astronomy Picture of the Day Radiolab […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-216334")[#strong[#text("OMG SCIENCE! | Text 2 All")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2013")]

#text("[…] Carroll – ")#link("http://www.preposterousuniverse.com/b…Terry")[#text("http://www.preposterousuniverse.com/b…Terry")]#text(" Tao – ")#link("https://terrytao.wordpress.com/2012/12…Its")[#text("https://terrytao.wordpress.com/2012/12…Its")]#text(" Okay To Be Smart – ")#link("http://www.itsokaytobesmart.com/post/…I")[#text("http://www.itsokaytobesmart.com/post/…I")]#text(" ¶#@*ing Love Science […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-217080")[#strong[#text("The Best of Science on the Internet | Physics Database")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2013")]

#text("[…] Sean Carroll – http://www.preposterousuniverse.com/b… Terry Tao – https://terrytao.wordpress.com/2012/12… It’s Okay To Be Smart – http://www.itsokaytobesmart.com/post/… I ¶#@*ing Love Science […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-218709")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2013")])]

#text("I think in the 6th paragraph of part 2, ")#mi("\\mathbf{R}^M")#text(" and ")#mi("\\mathbf{R}^L")#text(" should be ")#mi("V^M")#text(" and ")#mi("V^L")#text(", respectively.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/42c53fd880778b11776a9ab550d29b7b29a749f5fc3f1dd7243dd200ff21499a-8249daf65d3b5c8230b49663c70ef94763462929225b0d113f79ce936dcb5813.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Count Iblis")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-221261")[#strong[#text("Count Iblis")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2013")])]

#text("I think this statement is a bit misleading: “Note that once we sacrifice dimensional consistency, though, we cannot then transfer back to the dimensionful setting; the identity c = 1 does not hold for all choices of units, only the special choice of units for which c = 1.”")

#text("It hides the fact that the units were arbitry to begin with, and the physics doesn’t depend on that choice. This means that the results of dimensional analysis must be reproducable while working in natural units. Dimensional anysis can be interpreted as considering some scaling limit of a theory.")

#text("E.g., if we start with special relativity formulated in c = 1 units, one can ask how to obtain the classical limit. I give a rough outline of how to do that here:")

#link("http://en.wikipedia.org/wiki/User:Count_Iblis/Speed_of_light")[#text("http://en.wikipedia.org/wiki/User:Count_Iblis/Speed_of_light")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-225064")[#strong[#text("The BEST Science Online (Henry’s List) | Nayi TV")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2013")]

#text("[…] Tao – ")#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/It’s")[#text("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/It’s")]#text(" Okay To Be Smart – […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/077ab96978f5b3b58337da4d67ddacaf647fe060642e98aefba5912bd681f681-ff241cfddc1b3de67e4be0a2ee2266ec477b072d3f171bdee25d6287e3ae31f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mauricio Calvao")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-230349")[#strong[#text("Mauricio Calvao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2013")])]

#text("I would like to call attention to a particular consequence of this topic of dimensional analysis which has particularly bothered me for some time. I will just give an example of it. We use to say that, in the context of classical single particle point mechanics, “force has the same direction as acceleration” (")#mi("\\vec{F}=m\\vec{a}")#text(". Well, both ")#mi("\\vec{F}")#text(" and ")#mi("\\vec{a}")#text(" are vectors from necessarily distinct three-dimensional vector spaces, since we are not allowed to add ")#mi("\\vec{F}")#text(" and ")#mi("\\vec{a}")#text(", if only because of the difference of their dimensions (“units”). Thus I really do not understand what it means to assert that they have the same direction. For if they belong to distinct vector spaces, how can I unambiguously compare their directions? If there were some sort of natural isomorphism between the corresponding spaces, it might help, but I do not see where/how it comes from/about and this is obviously related to the presence of “units”. In usual, abstract, formal linear algebra the scalar field and the vector spaces are constituted by purely dimensionless objects. Somehow related to that: the quantity mass ")#mi("m")#text(" in the above second law of mechanics is not a pure number scalar… These things really intrigue me and, naively, seem to be completely basic and so I must be missing something very simple…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-230358")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2013")])]

#text("The vector space ")#mi("V_F")#text(" of forces and the vector space ")#mi("V_A")#text(" of accelerations are indeed distinct (and not identifiable in a dimensionally consistent fashion), but the ")#link("http://en.wikipedia.org/wiki/Projective_space")[#text("projective spaces")]#text(" ")#mi("PV_F")#text(" and ")#mi("PV_A")#text(" are canonically identifiable, and this is where the direction of both force and acceleration live. (To put it another way, while ")#mi("\\vec F")#text(" and ")#mi("\\vec a")#text(" do not have the same dimensional units, ")#tao-math("\\vec F/\\left\\|\\vec F\\right\\|", block: false)#text(" and ")#tao-math("\\vec a / \\left\\|\\vec a\\right\\|", block: false)#text(" does have the same units.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/077ab96978f5b3b58337da4d67ddacaf647fe060642e98aefba5912bd681f681-ff241cfddc1b3de67e4be0a2ee2266ec477b072d3f171bdee25d6287e3ae31f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mauricio Calvao")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-230497")[#strong[#text("Mauricio Calvao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2013")])]

#text("Sorry Terry, but I did not quite get it:")#linebreak()#text(" 1) how do I build or go from vector spaces to projective spaces?")#linebreak()#text(" 2) what does it mean for projective spaces to be canonically (naturally?) identifiable (isomorphic?)??")#linebreak()#text(" 3) is this related to the expression of any (dimensionful) vector as a sort of linear combination of dimensionless unit vectors (")#mi("\\vec{V}=V^ie_i")#text(") and then being able to naturally identify the corresponding unit vectors somehow? If that is the case, I do not here intuitively get what it means to say they are naturally isomorphic, as opposed, for instance, to the identification we make between a given vector space and the dual of its dual! Here it is easy to see the independence of the starting basis!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-230503")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2013")])]

#text("(1) Given a real vector space V, one can define the ")#link("http://en.wikipedia.org/wiki/Projective_space")[#text("projective space")]#text(" ")#mi("PV")#text(" to be the equivalence classes of ")#mi("V \\backslash \\{0\\}")#text(" under the equivalence relation ")#mi("x \\sim y")#text(" if ")#mi("x = ty")#text(" for some non-zero t. Thus each non-zero vector v in V gets assigned a class [v] in the associated projective space which can be viewed as capturing the “unsigned” direction of v. (If one wants the “signed” direction of v, one should restrict t to be positive rather than non-zero real, but this is a minor detail which I will ignore here.)")

#text("(2) The identification between projective spaces in this context comes from the following observation: if V is a real vector space and R is a one-dimensional vector space, and one forms the ")#link("http://en.wikipedia.org/wiki/Tensor_product")[#text("tensor product")]#text(" ")#mi("V \\otimes R")#text(" (which is a vector space of the same dimension as V) then the projective spaces ")#mi("P( V \\otimes R)")#text(" and ")#mi("P(V)")#text(" are canonically isomorphic, by identifying ")#mi("[v \\otimes r]")#text(" with ")#mi("[v]")#text(" for any non-zero ")#mi("v \\in V, r \\in R")#text(" (one can check that the class of ")#mi("[v \\otimes r]")#text(" does not depend on r).")

#text("In the case of F=ma, acceleration takes values in the three-dimensional vector space ")#mi("V_L \\otimes R_{T^{-2}}")#text(", where ")#mi("V_L")#text(" is the three-dimensional space of displacement vectors, and ")#mi("R_{T^{-2}}")#text(" is the one-dimensional vector space of dimensionality equal to time raised to the negative two power. Similarly force takes values in ")#mi("V_L \\otimes R_{T^{-2}} \\otimes R_M")#text(" where ")#mi("R_M")#text(" is the one-dimensional vector space of dimensionality equal to that of mass. By the previous discussion, the projective space ")#mi("P( V_L \\otimes R_{T^{-2}} )")#text(" and ")#mi("P( V_L \\otimes R_{T^{-2}} \\otimes R_M )")#text(" are canonically isomorphic, thus allowing one to assign meaning to the statement that force and acceleration have the same direction.")

#text("(3) one can indeed work in coordinates if desired, though of course the co-ordinate independence of one’s constructions becomes less clear when doing so.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/077ab96978f5b3b58337da4d67ddacaf647fe060642e98aefba5912bd681f681-ff241cfddc1b3de67e4be0a2ee2266ec477b072d3f171bdee25d6287e3ae31f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mauricio Calvao")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-230572")[#strong[#text("Mauricio Calvao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2013")])]

#text("Dear Terry")

#text("Excellent; thank you very much. I guess now I have a lot of food for thought and if anything worthwhile strikes my mind I will post back.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-239458")[#strong[#text("The BEST Science Online (Henry's List) » Oi Veh")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2013")]

#text("[…] Tao – ")#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/It’s")[#text("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/It’s")]#text(" Okay To Be Smart – […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-239982")[#strong[#text("The BEST Science Online (Henry’s List) | DLG")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2013")]

#text("[…] Tao – ")#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/It’s")[#text("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/It’s")]#text(" Okay To Be Smart – […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-242154")[#strong[#text("The BEST Science Online (Henry’s List) | World Mysteries TV")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2013")]

#text("[…] Tao – ")#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/It’s")[#text("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/It’s")]#text(" Okay To Be Smart – […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1af7868ef53b59fcae38742deb0a2391cc394deb829ff7c98cf3e008d495cb3f-def3e0ca6d6ee35ee60bdc363785cd7e1000cc964cbe77ed6c0696aebaaef4f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Farkitox")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-246074")[#strong[#text("Farkitox")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2013")])]

#text("Thanks for the wonderful post! A newbie question: How to treat the following situation with the formalism above?")

#text("In thermodynamics exist equations with the form:")

#text("dx/x = c/y^2 dy")

#text("Where c, x and y are dimentionful quantities. By taking indefinite integrals one gets")#linebreak()#text(" log x = – c / y + constant")

#text("If log x is an element of an one dimensional affine space (as said above), what exactly (or exactly enough for a non mathematician ;-) ) means the equality? Where does “constant” belong? and – c / y ? There are dimensional inconsistencies? If x units are Kelvin, what is the log x unity?")

#text("Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-247165")[#strong[#text("The BEST Science Online (Henry’s List) | TeachPlaylist")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2013")]

#text("[…] Tao – ")#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/It’s")[#text("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/It’s")]#text(" Okay To Be Smart – […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-265657")[#strong[#text("The BEST Science Online (Henry's List) - World MysteriesTV | World MysteriesTV")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2014")]

#text("[…] Tao – ")#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/It’s")[#text("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/It’s")]#text(" Okay To Be Smart – […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-277026")[#strong[#text("The BEST Science Online (Henry’s List)")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2014")]

#text("[…] Tao – ")#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/It’s")[#text("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/It’s")]#text(" Okay To Be Smart – […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-362254")[#strong[#text("Best Online Physics! | Physicsweird")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2014")]

#text("[…] Sean Carroll – ")#link("http://www.preposterousuniverse.com/b&#8230")[#text("http://www.preposterousuniverse.com/b&#8230")]#text("; Terry Tao – ")#link("https://terrytao.wordpress.com/2012/12&#8230")[#text("https://terrytao.wordpress.com/2012/12&#8230")]#text("; It’s Okay To Be Smart – ")#link("http://www.itsokaytobesmart.com/post/&#8230")[#text("http://www.itsokaytobesmart.com/post/&#8230")]#text("; I ¶#@*ing Love […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-436158")[#strong[#text("Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2014")]

#strong[#text("Why does the kinetic energy of an object depend on the square of it’s speed rather than being directly proportional to it’s speed?")]

#text("I think it’s just inherent in the math. Dimensions or units are just part of the math, part of the language we use to conceptualize the universe. ")#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/")[#text("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-446458")[#strong[#text("The BEST Science Online (Henry’s List) | Best Kitesurf Video")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2014")]

#text("[…] Carroll – ")#link("http://www.preposterousuniverse.com/b…Terry")[#text("http://www.preposterousuniverse.com/b…Terry")]#text(" Tao – ")#link("https://terrytao.wordpress.com/2012/12…It's")[#text("https://terrytao.wordpress.com/2012/12…It's")]#text(" Okay To Be Smart – ")#link("http://www.itsokaytobesmart.com/post/…I")[#text("http://www.itsokaytobesmart.com/post/…I")]#text(" ¶#@*ing Love […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-452882")[#strong[#text("The BEST Science Online (Henry's List) -")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2015")]

#text("[…] Tao – ")#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/It’s")[#text("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/It’s")]#text(" Okay To Be Smart – […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-453543")[#strong[#text("The BEST Science Online (Henry's List) - enimerosou")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2015")]

#text("[…] Tao – ")#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/It’s")[#text("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/It’s")]#text(" Okay To Be Smart – […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4a0caf2d869c1ba42dc9fbbcc4a2f90c2dd9f8cc003fe8db8de6679dc5e91c3-4eb176e37f9481b9469741517b8fba0aad200f027d7206a11f36d16f4dfadf96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Crowell")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-456896")[#strong[#text("Ben Crowell")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2015")])]

#text("Re dimensional analysis with tensors, what you’ve given here is sort of half of the picture. For comparison, see Dicke, “Mach’s principle and invariance under transformation of units,” Phys Rev 125 (1962) 2163. Consider the relation $ds^2=g_{ij}dx^i dx^j$. It’s an arbitrary convention how you assign units to the four factors. Since your approach is based on counting indices, you’d assign them units of $L^0=L^{\\mp 2}L^{\\pm 1}L^{\\pm 1}$. Dicke calls it $L^2=L^2L^0L^0$. In general, if you assign units of $L^{2\\gamma}$ to $g_{ij}$, then raising and lowering indices to form a tensor of rank $(r,s)$ makes units vary in proportion to $L^{\\gamma(s-r)}$. But this is only a proportionality, which describes the purely geometrical part of the tensor’s units. In addition to that, you can have a further factor that makes one $(r,s)$ tensor different from another $(r,s)$ tensor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-465880")[#strong[#text("The BEST Science Online (Henry's List) - Skeptic.live | Skeptic.live")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2016")]

#text("[…] Terry Tao – ")#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/")[#text("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/")]#text(" It’s Okay To Be Smart – […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-466435")[#strong[#text("The BEST Science Online (Henry’s List) | Trek Video")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2016")]

#text("[…] Terry Tao – ")#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/")[#text("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/")]#text(" It’s Okay To Be Smart – […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-468761")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("I read from a monograph in PDE the following.")#linebreak()#text(" ")#emph[#linebreak()#text(" We say that a function of a bounded open set ")#mi("\\Omega\\subset\\mathbb{R}^n")#text(", ")#mi("c(\\Omega)")#text(", is scale invariant if ")#mi("c(\\Omega)=c(\\Omega^{\\prime})")#text(" for all ")#mi("\\Omega^{\\prime}")#text(" obtained from ")#mi("\\Omega")#text(" by a rigid transformation and a dilation ")#mi("x\\mapsto\\delta x")#text(". ")]

#text("Denote by ")#mi("T_\\delta")#text(" the operation mapping functions defined on ")#mi("\\Omega")#text(" to function defined on ")#mi("\\Omega_\\delta:=\\{\\delta x\\mid x\\in\\Omega\\}")#text(":")#linebreak()#text(" ")#mi("\\displaystyle (T_\\delta f)(y)=f(\\frac{y}{\\delta}).")#linebreak()#text(" When we refer to the way something scales we mean under the dilations ")#mi("\\delta")#text(" and operations ")#mi("T_\\delta")#text(". One can modify the definition of the norms ")#mi("\\|\\cdot\\|_{m,\\Omega}")#text(" of ")#mi("H^m(\\Omega)")#text(" in such a way that they scale as the pure ")#mi("m")#text("-th order derivatives do. We shall denote by")#linebreak()#text(" ")#tao-math("\\displaystyle \\left|\\Omega\\right|=\\int_\\Omega 1\\ dx", block: false)#linebreak()#text(" and by")#linebreak()#text(" ")#tao-math("L(\\Omega)=L=\\left|\\Omega\\right|^{1/n}", block: false)#linebreak()#text(" the linear size of ")#mi("\\Omega\\subset\\mathbb{R}^n")#text(".")

#text("Define ")#mi("\\|\\|_{m,\\Omega}")#text(" with")#linebreak()#text(" ")#tao-math("\\displaystyle \\left\\|f\\right\\|_{m,\\Omega}^2=\\sum_{\\left|\\alpha\\right|\\leq m}{\\big{\\left|\\Omega\\right|}^{\\dfrac{2(\\left|\\alpha\\right|-m)}{n}}} \\int_{\\Omega}\\left|D^\\alpha f\\right|^2\\ dx", block: false)#linebreak()#text(" With this definition the quantity ")#tao-math("\\left\\|f\\right\\|_{m,\\Omega}", block: false)#text(" scales like ")#mi("L^{\\frac{n}{2}-m}")#text(", i.e.,")#linebreak()#text(" ")#tao-math("\\displaystyle C(\\Omega):=\\dfrac{1}{\\big{\\left|\\Omega\\right|}^{\\dfrac{1}{2}-\\dfrac{m}{n}}}\\cdot \\left\\|f\\right\\|_{m,\\Omega}", block: false)#linebreak()#text(" is scale invariant.")#linebreak()

#text("I’m wondering if one can use the “dimensional analysis” in this post to answer the following questions:")

#text("Is there a heuristic way to cook up the exponent in the term")#linebreak()#text(" ")#tao-math("\\displaystyle \\displaystyle {\\big{\\left|\\Omega\\right|}^{\\dfrac{2(\\left|\\alpha\\right|-m)}{n}}}?", block: false)

#text("A direct simplification gives")#linebreak()#text(" ")#tao-math("\\displaystyle C(\\Omega)=\\sqrt{\\sum_{\\left|\\alpha\\right|\\leq m} \\big{\\left|\\Omega\\right|}^{\\dfrac{2\\left|\\alpha\\right|}{n}-1}\\int_\\Omega\\left|D^\\alpha f\\right|^2\\ dx}.", block: false)#linebreak()#text(" Why is this scale invariant?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-468823")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2016")])]

#text("If ")#mi("f")#text(" is dimensionless, then ")#mi("D^\\alpha f")#text(" has the units of ")#tao-math("L^{-\\left|\\alpha\\right|}", block: false)#text(", and so ")#tao-math("\\int_\\Omega \\left|D^\\alpha f\\right|^2\\ dx", block: false)#text(" has the units of ")#mi("L^n \\times (L^{-\\alpha})^2")#text(". As ")#mi("\\Omega")#text(" has units of ")#mi("L^n")#text(", each summand in ")#tao-math("\\left\\|f\\right\\|_{m,\\Omega}^2", block: false)#text(" has the units of ")#tao-math("(L^n)^{\\frac{2(\\left|\\alpha\\right|-m)}{n}} \\times L^n \\times (L^{-\\alpha})^2 = L^{n-2m}", block: false)#text(", and hence ")#tao-math("\\left\\|f\\right\\|_{m,\\Omega}", block: false)#text(" scales as ")#mi("L^{\\frac{n}{2}-m}")#text(" as claimed.")

#text("In terms of the language of the post, the dimensional parameter is ")#mi("\\delta")#text(", and ")#mi("\\Omega_\\delta")#text(" varies in ")#mi("\\delta")#text(" according to the formula ")#mi("\\Omega_\\delta := \\frac{1}{\\delta} \\cdot \\Omega")#text(", thus ")#mi("\\Omega_\\delta")#text(" is the dilation of a fixed region ")#mi("\\Omega")#text(" by ")#mi("\\frac{1}{\\delta}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-468825")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2016")])]

#text("I don’t quite understand the following argument")

#emph[#text("If ")#mi("f")#text(" is ")#strong[#text("dimensionless")]#text(", then ")#mi("D^\\alpha f")#text(" has the units of ")#tao-math("L^{-\\left|\\alpha\\right|}\\quad (1)", block: false)]

#text("I guess this follows from the definition in the post:")

#mi("\\displaystyle  (\\frac{d}{dx} f(x))_{M,L,T} := \\frac{d}{dx_{M,L,T}} f_{M,L,T}(x_{M,L,T}).\\quad (2)")

#text("I feel that this seems to relate to some calculation in the one-dimensional case like")

#mi("\\displaystyle f^{(m)}(cx)=c^mf(x)\\quad (3)")#text(".")

#text("But I can’t match the notation/language in definition (2) to (1) and (3).")

#text("Also, I’m confused that why you say “")#mi("\\Omega")#text(" has units of ")#mi("L^n")#text("” instead of ")#tao-math("\\left|\\Omega\\right|", block: false)#text(" has units of ")#mi("L^n")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-468826")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2016")])]

#text("Oops, I meant")#linebreak()#text(" ")#mi("\\displaystyle f^{(m)}(cx)=c^mf^{(m)}(x)")#linebreak()#text(" in (3)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-468828")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2016")])]

#text("I meant to write ")#tao-math("\\left|\\Omega\\right|", block: false)#text(" instead of ")#mi("\\Omega")#text(" in the previous post.")

#text("If ")#mi("f")#text(" is dimensionless, then its scaling behaviour with respect to the dimensional parameter ")#mi("L")#text(" (playing the role of ")#mi("M,L,T")#text(" in the post; one can also use ")#mi("\\delta")#text(" if one prefers) is given by ")#mi("f_L(x) := f( L x )")#text(". From the chain rule one then has ")#tao-math("\\partial^\\alpha f_L(x) = L^{\\left|\\alpha\\right|} (\\partial^\\alpha f)( L x )", block: false)#text(", and so ")#mi("\\partial^\\alpha f")#text(" has dimension ")#tao-math("L^{-\\left|\\alpha\\right|}", block: false)#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-468831")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2016")])]

#text("I try to give a direct calculation by the change of variable formula as follows:")

#mi("\\displaystyle \\int_{\\delta\\Omega}F(x)\\ dx\\\\ =\\int_{\\mathbb{R}^n}F(x)1_{\\delta\\Omega}(x)\\ dx\\\\ =\\int_{\\mathbb{R}^n}F(x)1_{\\Omega}(x/\\delta)\\ dx\\\\ =\\int_{\\mathbb{R}^n}F(\\delta\\cdot x/\\delta)1_{\\Omega}(x/\\delta)\\ dx\\\\ =\\delta^n\\int_{\\mathbb{R}^n}F(\\delta x)1_{\\Omega}(x)\\ dx\\\\ =\\delta^n\\int_\\Omega F(\\delta x)\\ dx")

#text("Let ")#tao-math("F(x)=\\left|D^\\alpha f(x)\\right|^2", block: false)#text(". Then one needs")

#tao-math("\\displaystyle \\int_{\\Omega}F(\\delta x)\\ dx =\\delta^{-2\\left|\\alpha\\right|}\\int_{\\Omega}F(x) dx", block: false)

#text("I messed up with building up with this last step.")

#text("What is needed is")

#tao-math("\\delta^{\\left|\\alpha\\right|}D^\\alpha f(\\delta x)=D^\\alpha f(x)", block: false)

#text("But")

#tao-math("\\delta^{\\left|\\alpha\\right|}D^\\alpha f(\\delta x)=D^\\alpha_x f(\\delta x)", block: false)#text(".")

#text("What is the mistake here and how can I correct it?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-468764")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("I’m not sure if I understand this post correctly. I’m trying to rephrase the following using the language of this post.")

#emph[#text("We say that a function of a bounded open set ")#mi("\\Omega\\subset\\mathbb{R}^n")#text(", ")#mi("c(\\Omega)")#text(", is scale invariant if ")#mi("c(\\Omega)=c(\\Omega^{\\prime})")#text(" for all ")#mi("\\Omega^{\\prime}")#text(" obtained from ")#mi("\\Omega")#text(" by a rigid transformation and a dilation ")#mi("x\\mapsto\\delta x")#text(".")#linebreak()#text(" ")]

#text("Is the bounded domain ")#mi("\\Omega")#text(" in the beginning of the quoted text above a “dimensionful set” and the scalar invariant function ")#mi("c")#text(" a dimensionful function?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-468767")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("In the following paragraph,")

#emph[#linebreak()#text(" … thus, by (3) (now using parameters {L,A} instead of {M,L,T}), we have")]

#mi("\\displaystyle  f_{L,A}( x ) = A^{-1} f(Lx).")

#text("In (3), only the abstract exponents are given. Would you elaborate how to get the formula above by (3)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd83df368f5a465e4458f676823fe63af18caa3828a7c8d866400b549db7ea66-50338db75eee8858da9108c36b9554c86942eff17d4d12f7588cd08b81d90776.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-468840")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2016")])]

#text("Could there be a relation to Stoichiometry in the chemistry Lab.")

#text("$")#mi("\\text{CH}_4 + \\color{blue}{2}\\;\\text{O}_2 \\longrightarrow \\color{blue}{2}\\;\\t ext{CO}_2 + \\text{H}_2\\text{O}")#text("$")

#text("Stoichiometry is indeed a method where we can find the various amounts of ingredients in a chemical reaction, using the conservation of matter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd83df368f5a465e4458f676823fe63af18caa3828a7c8d866400b549db7ea66-50338db75eee8858da9108c36b9554c86942eff17d4d12f7588cd08b81d90776.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-468843")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2016")])]

#text("sorry the chemical reaction is just lighting methane (or propane) with a match giving carbon dioxide and some water. CH4 + 2 O2 → CO2 + 2 H2O.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-471208")[#strong[#text("Why use units in which c=1? | Page 4 | Physics Forums - The Fusion of Science and Community")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2016")]

#text("[…] could start an explanation by myself, but I guess a field medalist will give a better exposition: ")#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/")[#text("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/")]#text(" a short extract said: However, as any student of physics is aware, most physical quantities are […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f07bdc0bcec83c3fb3c3743d5642ca57be607ca8ce067dd1bf49210d6c3ae16d-8c695dc2f05856f83527430ffcddafc6507f33a2d13c2eb6a33095781fcc12c0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stephen Tashiro")]], [#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-474767")[#strong[#text("Stephen Tashiro")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2016")])]

#text("Consider the famous saying of dimensional analysis “You can’t add quantities with different dimensions” Is this saying based on empirical observations? Is it a mathematical assumption motivated by empirical observations? Or is it supposed to be provable from simpler assumptions?")

#text("There are many examples where adding quantities with unlike dimensions is not useful. However, there are examples where multiplying quantities with unlike dimensions is also not useful. For example if a weight of 3 newtons is hanging from a thread of length 2 meters, the quantity 6 newton-meters doesn’t seem very informative.")

#text("The special status granted the multiplication of units seems (to me) to result from the empirical fact that there are many situations where the information lost in summarizing a situation by a product is unimportant. For example, a torque of 6 ft-lbs allows us to predict certain effects without knowing whether it came from a force of 6 lbs on a 1 ft lever or a force of 3 lbs on a 2 ft lever.")

#text("Inventing a situation where adding unlike units is useful is difficult. For example the quantity 6 apples+oranges might describe a situation where there are 3 apples and 2 oranges – or zero apples and 6 oranges – or 19 apples and -13 oranges. Perhaps, for integer values, we could imagine a fruit counting machine and pretend we are only interested in effects resulting from the number of fruits, not from their species.")

#text("It’s interesting that the “+” in “apples+oranges” suggests the logical connective “or”. Are we willing to make the grand generality that no useful physical predictions can be made from a quantity that summarizes a total that is “one type of thing or another”? If we assert that generality, are we to prove it from other assumptions? Or do we take it as an axiom supported by empirical observations?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/comment-page-1/#comment-488094")[#strong[#text("The BEST Science Online (Henry's List) - weboin")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2017")]

#text("[…] Terry Tao – ")#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/")[#text("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/")]#text(" It’s Okay To Be Smart – […]")
]
