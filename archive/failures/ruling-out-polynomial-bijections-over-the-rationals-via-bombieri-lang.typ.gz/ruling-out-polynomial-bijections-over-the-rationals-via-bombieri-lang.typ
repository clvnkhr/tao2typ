// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/
// Converted to Typst by tao2typ: "2026-10-14T10:52:10.449111+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Ruling out polynomial bijections over the rationals via Bombieri-Lang?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Ruling out polynomial bijections over the rationals via Bombieri-Lang?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 June 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/")[#text("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("[")#strong[#text("UPDATE")]#text(", Feb 1, 2021: the strategy sketched out below has been successfully implemented to rigorously obtain the desired implication in this ")#link("https://arxiv.org/abs/2101.01090")[#text("recent preprint of Giulio Bresciani")]#text(".]")#linebreak()#text(" I recently came across ")#link("https://mathoverflow.net/questions/21003/polynomial-bijection-from-mathbb-q-times-mathbb-q-to-mathbb-q")[#text("this question on MathOverflow")]#text(" asking if there are any polynomials ")#mi("{P}")#text(" of two variables with rational coefficients, such that the map ")#mi("{P: {\\bf Q} \\times {\\bf Q} \\rightarrow {\\bf Q}}")#text(" is a bijection. The answer to this question is almost surely “no”, but it is remarkable how hard this problem resists any attempt at rigorous proof. (MathOverflow users with enough privileges to see deleted answers will find that there are no less than seventeen deleted attempts at a proof in response to this question!)")#linebreak()#text(" On the other hand, the one surviving response to the question does point out ")#link("http://arxiv.org/abs/0902.3961")[#text("this paper of Poonen")]#text(" which shows that assuming a powerful conjecture in Diophantine geometry known as the ")#link("http://www.ams.org/mathscinet-getitem?mr=715605")[#text("Bombieri-Lang conjecture")]#text(" (discussed in ")#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/")[#text("this previous post")]#text("), it is at least possible to exhibit polynomials ")#mi("{P: {\\bf Q} \\times {\\bf Q} \\rightarrow {\\bf Q}}")#text(" which are injective.")#linebreak()#text(" I believe that it should be possible to also rule out the existence of bijective polynomials ")#mi("{P: {\\bf Q} \\times {\\bf Q} \\rightarrow {\\bf Q}}")#text(" if one assumes the Bombieri-Lang conjecture, and have sketched out a strategy to do so, but filling in the gaps requires a fair bit more algebraic geometry than I am capable of. So as a sort of experiment, I would like to see if a rigorous implication of this form (similarly to the rigorous implication of the Erdos-Ulam conjecture from the Bombieri-Lang conjecture in ")#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/")[#text("my previous post")]#text(") can be crowdsourced, in the spirit of the ")#link("https://en.wikipedia.org/wiki/Polymath_Project")[#text("polymath projects")]#text(" (though I feel that this particular problem should be significantly quicker to resolve than a typical such project).")#linebreak()#text(" Here is how I imagine a Bombieri-Lang-powered resolution of this question should proceed (modulo a large number of unjustified and somewhat vague steps that I believe to be true but have not established rigorously). Suppose for contradiction that we have a bijective polynomial ")#mi("{P: {\\bf Q} \\times {\\bf Q} \\rightarrow {\\bf Q}}")#text(". Then for any polynomial ")#mi("{Q: {\\bf Q} \\rightarrow {\\bf Q}}")#text(" of one variable, the surface")

#align(center)[#tao-fit-display[#mitex("S_Q := \\{ (x,y,z) \\in \\mathbb{A}^3: P(x,y) = Q(z) \\}")]]

#text("has infinitely many rational points; indeed, every rational ")#mi("{z \\in {\\bf Q}}")#text(" lifts to exactly one rational point in ")#mi("{S_Q}")#text(". I believe that for “typical” ")#mi("{Q}")#text(" this surface ")#mi("{S_Q}")#text(" should be irreducible. One can now split into two cases:")

#list(
[#text("(a) The rational points in ")#mi("{S_Q}")#text(" are Zariski dense in ")#mi("{S_Q}")#text(".")],
[#text("(b) The rational points in ")#mi("{S_Q}")#text(" are not Zariski dense in ")#mi("{S_Q}")#text(".")]
)

#text("Consider case (b) first. By definition, this case asserts that the rational points in ")#mi("{S_Q}")#text(" are contained in a finite number of algebraic curves. By ")#link("https://en.wikipedia.org/wiki/Faltings%27s_theorem#039;s_theorem")[#text("Faltings’ theorem")]#text(" (a special case of the Bombieri-Lang conjecture), any curve of genus two or higher only contains a finite number of rational points. So all but finitely many of the rational points in ")#mi("{S_Q}")#text(" are contained in a finite union of genus zero and genus one curves. I think all genus zero curves are ")#link("http://en.wikipedia.org/wiki/Kodaira_dimension#General_type")[#text("birational")]#text(" to a line, and all the genus one curves are birational to an elliptic curve (though I don’t have an immediate reference for this). These curves ")#mi("{C}")#text(" all can have an infinity of rational points, but very few of them should have “enough” rational points ")#mi("{C \\cap {\\bf Q}^3}")#text(" that their projection ")#mi("{\\pi(C \\cap {\\bf Q}^3) := \\{ z \\in {\\bf Q} : (x,y,z) \\in C \\text{ for some } x,y \\in {\\bf Q} \\}}")#text(" to the third coordinate is “large”. In particular, I believe")

#list(
[#text("(i) If ")#mi("{C \\subset {\\mathbb A}^3}")#text(" is birational to an elliptic curve, then the number of elements of ")#mi("{\\pi(C \\cap {\\bf Q}^3)}")#text(" of ")#link("https://en.wikipedia.org/wiki/Glossary_of_arithmetic_and_diophantine_geometry#N")[#text("height")]#text(" at most ")#mi("{H}")#text(" should grow at most polylogarithmically in ")#mi("{H}")#text(" (i.e., be of order ")#mi("{O( \\log^{O(1)} H )}")#text(".")],
[#text("(ii) If ")#mi("{C \\subset {\\mathbb A}^3}")#text(" is birational to a line but not of the form ")#mi("{\\{ (f(z), g(z), z) \\}}")#text(" for some rational ")#mi("{f,g}")#text(", then then the number of elements of ")#mi("{\\pi(C \\cap {\\bf Q}^3)}")#text(" of height at most ")#mi("{H}")#text(" should grow slower than ")#mi("{H^2}")#text(" (in fact I think it can only grow like ")#mi("{O(H)}")#text(").")]
)

#text("I do not have proofs of these results (though I think something similar to (i) can be found in Knapp’s book, and (ii) should basically follow by using a rational parameterisation ")#mi("{\\{(f(t),g(t),h(t))\\}}")#text(" of ")#mi("{C}")#text(" with ")#mi("{h}")#text(" nonlinear). Assuming these assertions, this would mean that there is a curve of the form ")#mi("{\\{ (f(z),g(z),z)\\}}")#text(" that captures a “positive fraction” of the rational points of ")#mi("{S_Q}")#text(", as measured by restricting the height of the third coordinate ")#mi("{z}")#text(" to lie below a large threshold ")#mi("{H}")#text(", computing density, and sending ")#mi("{H}")#text(" to infinity (taking a limit superior). I believe this forces an identity of the form ")#metadata(none) <tao-b32e7844e0e6426ca71e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("P(f(z), g(z)) = Q(z)")]]

#text("for all ")#mi("{z}")#text(". Such identities are certainly possible for some choices of ")#mi("{Q}")#text(" (e.g. ")#mi("{Q(z) = P(F(z), G(z))}")#text(" for arbitrary polynomials ")#mi("{F,G}")#text(" of one variable) but I believe that the only way that such identities hold for a “positive fraction” of ")#mi("{Q}")#text(" (as measured using height as before) is if there is in fact a rational identity of the form")

#align(center)[#tao-fit-display[#mitex("P( f_0(z), g_0(z) ) = z")]]

#text("for some rational functions ")#mi("{f_0,g_0}")#text(" with rational coefficients (in which case we would have ")#mi("{f = f_0 \\circ Q}")#text(" and ")#mi("{g = g_0 \\circ Q}")#text("). But such an identity would contradict the hypothesis that ")#mi("{P}")#text(" is bijective, since one can take a rational point ")#mi("{(x,y)}")#text(" outside of the curve ")#mi("{\\{ (f_0(z), g_0(z)): z \\in {\\bf Q} \\}}")#text(", and set ")#mi("{z := P(x,y)}")#text(", in which case we have ")#mi("{P(x,y) = P(f_0(z), g_0(z) )}")#text(" violating the injective nature of ")#mi("{P}")#text(". Thus, modulo a lot of steps that have not been fully justified, we have ruled out the scenario in which case (b) holds for a “positive fraction” of ")#mi("{Q}")#text(".")#linebreak()#text(" This leaves the scenario in which case (a) holds for a “positive fraction” of ")#mi("{Q}")#text(". Assuming the Bombieri-Lang conjecture, this implies that for such ")#mi("{Q}")#text(", any resolution of singularities of ")#mi("{S_Q}")#text(" fails to be of ")#link("http://en.wikipedia.org/wiki/Kodaira_dimension#General_type")[#text("general type")]#text(". I would imagine that this places some very strong constraints on ")#mi("{P,Q}")#text(", since I would expect the equation ")#mi("{P(x,y) = Q(z)}")#text(" to describe a surface of general type for “generic” choices of ")#mi("{P,Q}")#text(" (after resolving singularities). However, I do not have a good set of techniques for detecting whether a given surface is of general type or not. Presumably one should proceed by viewing the surface ")#mi("{\\{ (x,y,z): P(x,y) = Q(z) \\}}")#text(" as a fibre product of the simpler surface ")#mi("{\\{ (x,y,w): P(x,y) = w \\}}")#text(" and the curve ")#mi("{\\{ (z,w): Q(z) = w \\}}")#text(" over the line ")#mi("{\\{w \\}}")#text(". In any event, I believe the way to handle (a) is to show that the failure of general type of ")#mi("{S_Q}")#text(" implies some strong algebraic constraint between ")#mi("{P}")#text(" and ")#mi("{Q}")#text(" (something in the spirit of ")#link(<tao-b32e7844e0e6426ca71e>)[#text("(1)")]#text(", perhaps), and then use this constraint to rule out the bijectivity of ")#mi("{P}")#text(" by some further ")#emph[#text("ad hoc")]#text(" method.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (32)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517184")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2019")])]

#text("I saw a nice talk by Hector Pasten on this problem in January in Chile. If I recall correctly, which is a dubious hypothesis, he had constructed bijections in topologically similar situations, which put some constraint on what kind of argument could work in the QxQ -> Q problem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517186")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2019")])]

#text("Injection, not bijection. Found the abstract:")

#text("Bivariate polynomial injections of rational points")#linebreak()#text(" H´ector PASTEN (P. Universidad Cat´olica de Santiago) ´")#linebreak()#text(" Abstract I will prove that there is an affine curve C over Q with a dense set")#linebreak()#text(" of rational points, and a polynomial function f on C × C defined over Q with")#linebreak()#text(" the property that f induces an injective function C(Q)×C(Q) → Q on rational")#linebreak()#text(" points.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bbb59377c9338b9b05763bc23a0e6c419829381203e68da20361422f1b24a101-08e545a4e8ab77c20677d32c50e3e34ccc02dbc3e80daf3e8687d52b79faad86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pasten")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517303")[#strong[#text("Pasten")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2019")])]

#text("If you want to see the details: ")#link("https://arxiv.org/abs/1811.02416")[#text("https://arxiv.org/abs/1811.02416")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f0b9a908987dfdfc75dae02356a635e8ff78f8d3d1ca98913514ae4baf88d46-d00c0befd789903b432aea6071945fa92bf8636b4820e83fbd2e6a03dea15f9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517185")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2019")])]

#text("After getting the finitely many curves, the next step is to apply Hilbert’s irreducibility theorem, which shows that for any curve with a map to ")#mi("\\mathbb P^1")#text(" (in this case the ")#mi("z")#text(" coordinate map), either the curve has a section (which would be your identity (1)) or else a density zero subset of points lie in its image.")

#text("For ruling out the case of a large system of polynomial identities (1), this seems very likely to be possible if the degrees of the polynomial identities can be bounded. Then constructibility arguments show that there must be a universal polynomial identity that works for a generic polynomial. Possibly the degree-bounding follows from arguments relating to function field versions of Mordell’s conjecture.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f0b9a908987dfdfc75dae02356a635e8ff78f8d3d1ca98913514ae4baf88d46-d00c0befd789903b432aea6071945fa92bf8636b4820e83fbd2e6a03dea15f9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517188")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2019")])]

#text("For getting the surface to be general type by base change, a necessary condition is that the curve ")#mi("P(x,y) = z")#text(" for general ")#mi("z")#text(" have genus at least two – a surface with a rational fibration has Kodaira dimension at most ")#mi("-\\infty")#text(", and a surface with an elliptic fibration has Kodaira dimension at most ")#mi("1")#text(".")

#text("For genus zero fibrations there is a special argument – any genus zero curve with one rational point has infinitely many, so there cannot be a bijection. For genus one fibrations, I think there is a more complicated arguments. Any genus one fibration is a torsor for an elliptic fibration. Because every algebraic genus one fibration has a multisection, it must be a torsor for the ")#mi("n")#text("-torsion of an elliptic curve. By Hilbert irreducibility, as an ")#mi("E[n]")#text("-torsor, it remains nontrivial for most fibers. But as all fibers have a rational point it must be nontrivial as en element of the Tate-Shafarevich group. But the kernel map from ")#mi("H^1(\\mathbb Q, E[n])")#text(" to the Tate-Shaferevich group is ")#mi("E(\\mathbb Q) /n E(\\mathbb Q)")#text(", so that must be nontrivial, so the fiber must have more than one point.")

#text("For genus two and up fibrations, I imagine it must always be possible to obtain general type by base change by polynomials, but I don’t know a reference. If a sufficiently strong result of this form could be proven, one could try to do it by base changing by a polynomial such that ")#mi("Q(z)")#text(" which fails to be injective infinitely often, and use that, plus the polynomial identity from earlier, to contradict the injectivity of the earlier map.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pasten")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517372")[#strong[#text("Pasten")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2019")])]

#text("Maybe the non-degeneracy condition on ")#mi("P(x,y)")#text(" has to do with the homogeneous part of highest degree ")#mi("H(x,y)")#text(" (to so say, the possible singularities of ")#mi("P(x,y)=ct")#text(" at infinity, that force the genus to decrease). For instance, assume that ")#mi("H")#text(" has no repeated linear factor. If ")#mi("\\mathrm{deg}(P)>6")#text(" then I think that the double plane construction (cf. [BPvdV]) gives that for all but finitely constants b, the surface ")#mi("P(x,y)=z^2-b")#text(" is birational to a smooth projective surface of general type.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bbb59377c9338b9b05763bc23a0e6c419829381203e68da20361422f1b24a101-08e545a4e8ab77c20677d32c50e3e34ccc02dbc3e80daf3e8687d52b79faad86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pasten")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517373")[#strong[#text("Pasten")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2019")])]

#text("Here are the details: replace ")#mi("P")#text(" by ")#mi("P+b")#text(" so that the affine zero set of ")#mi("P")#text(" is smooth. Let ")#mi("B")#text(" be the projective closure of ")#mi("P=0")#text(" in the projective plane, and let ")#mi("D=B")#text(" if ")#mi("\\mathrm{deg}(P)")#text(" is even, ")#mi("D=B+L")#text(" if ")#mi("\\mathrm{deg}(P)")#text(" is odd (")#mi("L")#text("=line at infinity in the projective plane). The hypothesis on ")#mi("H")#text(" makes ")#mi("D")#text(" a normal crossings divisor. There is a double cover ")#mi("Y")#text(" of the projective plane branched exactly along ")#mi("D")#text(" (since ")#mi("\\mathrm{deg}(D)=2d")#text(" is even). The canonical sheaf of the canonical resolution of ")#mi("Y")#text(" is the pull-back of ")#mi("O(-3)+O(d)=O(d-3)")#text(" (since ")#mi("D")#text(" is n.c.), which is big when ")#mi("d>3")#text(", i.e. ")#mi("\\mathrm{deg}(D)>6")#text(". ")#mi("Y")#text(" is birational to our surface.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517498")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2019")])]

#text("That’s great! This construction seems to knock out a lot of the subcases of Case (a) (assuming Bombieri-Lang of course) leaving mostly just the cases of low degree ")#mi("P")#text(" which possibly can be done by hand. The obvious thing to try next is to replace ")#mi("z^2-b")#text(" by ")#mi("z^k-b")#text(" for larger ")#mi("k")#text(", but I guess this would tend to make the degree requirement on ")#mi("P")#text(" worse as ")#mi("k \\to \\infty")#text("?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517227")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2019")])]

#text("Ah, this looks like a much simpler route to getting a section than invoking Faltings theorem and then analysing the genus one and genus zero curves by hand.")

#text("It occurs to me that one can take ")#mi("Q")#text(" to be a rational function rather than a polynomial. The large system of identities (1) is then basically saying that if ")#mi("P: {\\bf Q} \\times {\\bf Q} \\to {\\bf Q}")#text(" is bijective, then ")#mi("P: {\\bf Q}(t) \\times {\\bf Q}(t) \\to {\\bf Q}(t)")#text(" is more or less bijective also (certainly it is injective, and it looks like it will be surjective on the range in which Case (b) applies). I suppose one could then try to apply Bombieri-Lang for ")#mi("{\\bf Q}(t)")#text(" (which maybe follows from three-dimensional Bombieri-Lang over ")#mi("{\\bf Q}")#text("?) to try to get things like the uniform degree bound? This would be somewhat in the spirit of the ")#link("https://www.ams.org/journals/jams/1997-10-01/S0894-0347-97-00195-1/")[#text("work of Caporaso, Harris and Mazur")]#text(" deriving uniform bounds on Faltings’ theorem from Bombieri-Lang for surfaces (see also this ")#link("https://arxiv.org/abs/alg-geom/9505020")[#text("followup paper of Abramovich")]#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69a08000d93c54bdeb9a5046aef2f5c798aeba2781fb594a6db4e5b940b0faf6-dccff0bdb71e4ee432448926adea0efe424858674fe99fef9e627994d8b85b45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Loughran")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517255")[#strong[#text("Daniel Loughran")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2019")])]

#text("Here is my attempt at making clear some of the geometry of the problem (following Will Sawin’s comments).")

#text("Let ")#mi("S")#text(" be the affine surface given by")

#mi("\\displaystyle S: \\quad P(x,y) = z.")

#text("This is equipped with the natural projection ")#mi("S \\to \\mathbb{A}^1")#text(" to the ")#mi("z")#text("-coordinate, which is assumed to be a bijection on rational points. Note that ")#mi("S")#text(" is a rational variety, in particular its rational points are Zariski dense.")

#text("We can probably assume that the generic fibre is a curve of genus at least ")#mi("2")#text(", as the small genus cases can be treated separably, as Will suggests.")

#text("We then consider the base-change ")#mi("S_Q")#text(" of ")#mi("S \\to \\mathbb{A}^1")#text(" via the map ")#mi("\\mathbb{A}^1 \\to \\mathbb{A}^1, z \\mapsto Q(z)")#text(", for some polynomial ")#mi("z")#text(". Explicitly, ")#mi("S_Q")#text(" is given by")

#mi("\\displaystyle S_Q: \\quad P(x,y) = Q(z)")

#text("equipped with the associated map ")#mi("\\pi_Q: S_Q \\to \\mathbb{A}^1")#text(" given by the base change of ")#mi("\\pi")#text(", which is again just projection onto the ")#mi("z")#text("-coordinate. Note that ")#mi("\\pi_Q")#text(" is surjective on rational points as it arises as the base change of map with the same property.")

#text("Now, providing that ")#mi("Q")#text(" is separable of sufficiently large degree, the surface ")#mi("S_Q")#text(" should be a surface of general type. Then the Bomberi-Lang conjecture predicts that its rational points are not Zariski dense, so they lie in the union of finitely many curves ")#mi("C \\subset S_Q")#text(". We then consider the map ")#mi("C \\to \\mathbb{A}^1")#text(" induced by ")#mi("\\pi_Q")#text("; if each such map is not of degree one then the image is a so-called thin set. But then this contradicts the fact that ")#mi("\\pi_Q")#text(" is surjective on rational points, by Hilbert’s irreducibility theorem. Hence there is some ")#mi("C")#text(" such that ")#mi("C \\to \\mathbb{A}^1")#text(" is of degree ")#mi("1")#text(". This ")#mi("C")#text(" therefore gives a section of ")#mi("\\pi_Q")#text(".")

#text("Note that the exact same arguments also applies to more general finite covers ")#mi("D \\to \\mathbb{A}^1")#text(", rather than the special covers ")#mi("\\mathbb{A}^1 \\to \\mathbb{A}^1")#text(" considered above. This extra flexibility might come in useful.")

#text("These arguments all seem reasonable so far. However, the next claim is that this implies that ")#mi("\\pi")#text(" itself must have a section. This seems reasonable, but I don’t see how to prove this. We have the freedom to vary ")#mi("Q")#text(" and its degree, so these arguments seem to show that the generic fibre ")#mi("S_{\\mathbb{Q}(z)}")#text(", viewed as a curve over the function field ")#mi("\\mathbb{Q}(z)")#text(", has a rational point over field extensions of coprime degree, hence has a ")#mi("0")#text("-cycle of degree one. But in general this need not imply the existence of a rational point.")

#text("Anyway, let me finish the argument. Assuming that ")#mi("\\pi")#text(" has a section, we deduce a contradiction as follows. As ")#mi("S")#text(" has a Zariski dense set of rational points and the image of a section is a closed subset, there must be a rational point not lying in the section; however this contradicts that ")#mi("\\pi")#text(" is bijective on rational points.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517279")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2019")])]

#text("It seems that perhaps the (strong) abc conjecture for function fields or polynomials (which is actually a theorem) could give a uniform degree bound for ")#mi("f(t)")#text(" and ")#mi("g(t)")#text(" in (1) in terms of ")#mi("P")#text(" and ")#mi("Q")#text(", as long as ")#mi("P")#text(" is “non-degenerate” in some sense. I found a paper on this strong function field abc conjecture at ")#link("https://arxiv.org/abs/0811.3153")[#text("https://arxiv.org/abs/0811.3153")]#text(" but am still digesting it. (If one is willing to assume the analogous strong abc conjecture for ")#mi("{\\bf Q}")#text(", this presumably also gives a polynomial bound for the heights of ")#mi("x,y")#text(" in terms of the height of ")#mi("P(x,y)")#text(" for any rational ")#mi("x,y")#text(", again assuming some suitable non-degeneracy condition on ")#mi("P")#text(", though I am not sure what one would do with such a bound.)")

#text("ADDED: presumably ")#link("https://www.math.u-bordeaux.fr/~fpazuki/index_fichiers/Elkies91.pdf")[#text("Elkies observation")]#text(" that the abc conjecture implies an effective version of Mordell’s conjecture (Faltings’ theorem) can be adapted to the polynomial case and indeed get a uniform degree bound on ")#mi("f,g")#text(" in terms of the degree of ")#mi("Q")#text(", assuming we are in the case where the level sets of ")#mi("P")#text(" have genus at least two, which it seems we can reduce to by other comments.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517187")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2019")])]

#text("The set ")#mi("\\mathbb A")#text(" in the definition of ")#mi("S_Q")#text(" seems to be undefined.")

#emph[#text("[This is my notation for affine space – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517192")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2019")])]

#text("Is it possible to generalize this problem to polynomials over other coefficient fields?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fdb4d5145bdcae0084cde43d92f0a8f82326446721b2ac1cb9e6e4803a4b82a4-1d85604cd6cb52945d4c6212ad90d3d353618ac4d54017c4f344ed8688e4cd22.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TR")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517210")[#strong[#text("TR")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2019")])]

#text("How about ")#mi("\\mathbb F_q(x)\\times\\mathbb F_q(x)\\rightarrow\\mathbb F_q(x)")#text(" bijection and for that matter ")#mi("\\mathbb F_1(x)\\times\\mathbb F_1(x)\\rightarrow\\mathbb F_1(x)")#text(" bijection?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517322")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2019")])]

#text("The map ")#mi("(u,v) \\mapsto u^2+x v^2")#text(" is a bijection ")#mi("\\mathbb{F}_2(x) \\times \\mathbb{F}_2(x) \\longrightarrow \\mathbb{F}_2(x)")#text(". Proof of injectivity: If ")#mi("u_1^2 + x v_1^2 = u_2^2 + x v_2^2")#text(", then ")#mi("(u_1-u_2)^2 = x (v_1 - v_2)^2")#text(" and, since ")#mi("x")#text(" is not square, we must have ")#mi("u_1-u_2 = v_1 - v_2 = 0")#text(". Proof of surjectivity: Every element of ")#mi("\\mathbb{F}_2(x)")#text(" can be written as ")#mi("a(x)/b(x)^2")#text(", and we can write ")#mi("a(x) = c(x^2) + x d(x^2) = c(x)^2 + x d(x)^2")#text(", so every element of ")#mi("\\mathbb{F}_2(x)")#text(" is ")#mi("(c/b)^2 + x (d/b)^2")#text(".")

#text("The analogous trick does ")#mi("\\mathbb{F}_q(x)^q \\leftrightarrow \\mathbb{F}_q(x)")#text(". I suspect some trickery could do ")#mi("\\mathbb{F}_q(x)^2 \\leftrightarrow \\mathbb{F}_q(x)")#text(" but I don’t see it. Since no one know what ")#mi("\\mathbb{F}_1")#text(" is, I’m not going to address that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517337")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2019")])]

#text("Nice observation! I wonder what part of the strategy outlined in the post fails in positive characteristic. It seems that the surface ")#mi("\\{ (u,v,w): u^2 + xv^2 = Q(w) \\}")#text(" has a Zariski-dense set of ")#mi("{\\mathbb F}_2(x)")#text("-points for any ")#mi("{\\mathbb F}_2(x)")#text("-rational function ")#mi("Q")#text(", so either the naive version of Bombieri-Lang is false in ")#mi("{\\mathbb F}_2(x)")#text(" or these surfaces are not of general type. Presumably it is the latter (I guess the fibres ")#mi("\\{ u^2 + xv^2 = c \\}")#text(" are now some sort of double line? Characteristic 2 geometry is so strange…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bbb59377c9338b9b05763bc23a0e6c419829381203e68da20361422f1b24a101-08e545a4e8ab77c20677d32c50e3e34ccc02dbc3e80daf3e8687d52b79faad86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pasten")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517363")[#strong[#text("Pasten")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2019")])]

#text("This example goes back to Proposition 8 in G. Cornelissen’s article “Stockage diophantien et hypothèse abc généralisée”. Regarding BL in global function fields of characteristic p>0, already for curves (i.e. Mordell’s conjecture –Samuel’s theorem in this case) one needs to allow exceptions in the isotrivial case. Note that ")#mi("Ax^n+By^n=Q")#text(" becomes isomorphic to a Fermat curve (constant coefficients) after base change, thus, such varieties are isotrivial.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69a08000d93c54bdeb9a5046aef2f5c798aeba2781fb594a6db4e5b940b0faf6-dccff0bdb71e4ee432448926adea0efe424858674fe99fef9e627994d8b85b45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Loughran")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517360")[#strong[#text("Daniel Loughran")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2019")])]

#text("I should say that this example already appears in Remark 1.6 of Poonen’s paper mentioned above. These examples also indeed do not appear to give surfaces of general type, and really use pathological behaviour in positive characteristic.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d936fed4af37afdca30708460058e14c54bb7173802382b26fc9b3d95f79e617-cefb6f7c3e840f1b67793ffaee1673dd155539bdeb27c61e38a8f0742c9093e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martini")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517228")[#strong[#text("Martini")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2019")])]

#text("Neglecting the dependency on one argument, there are many polynomials which give a bijection, e.g., the identity or x cubed.")

#text("Where in the above arguments is it assumed that P really depends on two variables?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517299")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2019")])]

#text("x cubed is not a bijection since there are many rationals with no rational cube root.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65b2ea070936748c33339895b7d67b0eb72e599846423bccb09c3f80ef1865b4-b639da33830634e53ff9a86ec9aa80050fd4e8598ff4bbfde6e4dc7075b9c811.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Omar")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517339")[#strong[#text("Omar")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2019")])]

#text("A polynomial that only depends on one of the two variables can never be injective: f(x,y0) = f(x,y1), if f(x,y) only depends on x.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4ad6c18186ffa1aab4aadbb6437ddfdfd03ffdb28fa7b75fb5a4b74dadd060d-b17876bb6ed44b4eb4e6f409d6e9c2e04bf2fd6789fad7fda897a642de72445e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A sort of Polymath on a famous MathOverflow problem | The polymath blog")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517230")[#strong[#text("A sort of Polymath on a famous MathOverflow problem | The polymath blog")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2019")])]

#text("[…] that the map is a bijection? This is a famous 9-years old open question on MathOverflow. Terry Tao initiated a sort of polymath attempt to solve this problem conditioned on some conjectures from arithmetic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-517262")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2019")])]

#text("The problem formulation is very simple, but its difficulty is not necessarily related to its simple formulation (e.g. the case of FLT)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-518108")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2019")])]

#text("Dear Terry, what is the current status of this project?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-518118")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2019")])]

#text("Basically, there is partial progress on both case (a) and case (b) but there is still significant amount of work to be done. In case (a), it now seems reasonably clear that we get identities of the form (1) for typical ")#mi("Q")#text(", and there should be a uniform degree bound on ")#mi("f,g")#text(" coming from the abc conjecture from polynomials, but this doesn’t quite finish off the problem because we don’t know how to get from this to the identity in the display below (1). (Instead what seems to happen is that we pass from the original hypothesis that ")#mi("P: {\\bf Q} \\times {\\bf Q} \\to {\\bf Q}")#text(" is a bijection, to a hypothesis that ")#mi("P: {\\bf Q}(t) \\times {\\bf Q}(t) \\to {\\bf Q}(t)")#text(" is also either a bijection, or something very close to a bijection.) It does seem to raise a purely algebraic subproblem though, which is to classify those polynomials ")#mi("P \\in {\\bf C}[x,y]")#text(" for which the map ")#mi("P: {\\bf C}(t) \\times {\\bf C}(t) \\to {\\bf C}(t)")#text(" taking ")#mi("f(t), g(t)")#text(" to ")#mi("P(f(t), g(t))")#text(" is surjective. There are some simple examples of such polynomials (e.g. ")#mi("P(x,y) = x + R(y)")#text(") but it seems that most polynomials would not be of this form and in particular would not have identities of the form (1) for generic ")#mi("Q")#text(".")

#text("In case (b), Hector Pasten gave a nice geometric argument that showed that a typical high-degree ")#mi("P")#text(" should have a base change of general type which would finish off this case assuming Bombieri-Lang. In principle this means that we only need to consider the case of low-degree ")#mi("P")#text(" (e.g. degree six or less) to complete this side of the story, but this may require some enormous amount of case checking, plus there some degenerate high-degree polynomials that aren’t yet covered by Pasten’s construction that also have to be addressed at some point.")

#text("I am unfortunately going to be extremely distracted with other duties for the next week or two, but may eventually post a followup post to this one to try to regain some momentum on this problem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bea0886eea91494ed4a9e5a0a16a6f2a9fbaac3ebcc40106ed9e2a6db323452d-06e48ba65981bef4922e2ef4abb31ee78dfeda749d6965060eb41fd5315b1ccd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 一个变量“存储”任意多的数– 从“康托配对函数”聊开去 – 大老李聊数学")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-604805")[#strong[#text("一个变量“存储”任意多的数– 从“康托配对函数”聊开去 – 大老李聊数学")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2020")])]

#text("[…] 如果再加入“满射”这一条件，那问题当然就更难了。根据陶哲轩的一篇博客，他几乎肯定不存在哈维·弗里德曼问的那个二元有理数函数到有理数集合上的双射多项式函数。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-615358")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2021")])]

#text("Giulio Bresciani has just ")#link("https://arxiv.org/abs/2101.01090")[#text("posted a preprint")]#text(" on the arXiv which apparently manages to complete the strategy initiated in this blog post and comments and formally rule out polynomial bijections from ")#mi("k \\times k")#text(" to ")#mi("k")#text(" for any finite extension ")#mi("k")#text(" over the rationals assuming Bombieri-Lang. A substantial amount of algebraic geometry (more than I am personally familiar with) is introduced to treat the higher genus case. It is beyond my ability to readily summarise the argument, but perhaps some other readers more expert in algebraic geometry will be able to do so.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-615360")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2021")])]

#text("Whoops, I had this window open for a while and was too slow in posting my comment below. Feel free to delete it and this one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f75c6e6afb95b1cb24ac63bf8074c2e6d86f4c4e6bf7fc9e8216335cc5f6fc56-59b3503947be771e23e2f594a807bca00d6994b69e14a0c6d6162b526b8457a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giulio Bresciani")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-615690")[#strong[#text("Giulio Bresciani")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2021")])]

#text("I will try to summarise the argument. Obviously this does not exclude that someone else does it again, different points of view are always helpful.")

#text("W. Sawin here has settled the cases in which the generic fiber has genus 0 or 1 (I fill in the details of Sawin’s proof in the preprint). This leaves us with the higher genus case, which follows easily from the following.")

#text("*Theorem A* Assume that the weak Bombieri-Lang conjecture holds over ")#mi("k")#text(". Let ")#mi("X")#text(" be a surface, ")#mi("X \\to \\mathbb{P}^1")#text(" a morphism whose generic fiber is geometrically irreducible of genus at least ")#mi("2")#text(". Assume that ")#mi("X(k) \\to \\mathbb{P}^{1}(k)")#text(" is surjective up to a finite number of points. Then there exists an open subset ")#mi("U\\subseteq \\mathbb{P}^1")#text(" and a section ")#mi("U \\to X")#text(".")

#text("In the preprint, Theorem A is more general than this, but this version is enough for the application to our problem. I am going to summarise the strategy to prove this version. We call a generic section of ")#mi("X\\to\\mathbb{P}^{1}")#text(" a rational map ")#mi("\\mathbb{P}^{1}\\dashrightarrow X")#text(" making the obvious diagram commute (we are not assuming ")#mi("X")#text(" complete, any finite number of points of ")#mi("X")#text(" or ")#mi("\\mathbb{P}^{1}")#text(" is irrelevant).")

#text("First observe that, if the family is constant i.e. ")#mi("X")#text(" is birational to a product ")#mi("\\mathbb{P}^1 \\times C")#text(", then the statement follows from Hilbert’s irreducibility theorem, since ")#mi("C")#text(" has a finite number of rational points. So let us assume that this is not the case.")

#text("The strategy is then divided in two parts. In the first part, I prove that for a generic cover ")#mi("c : \\mathbb{P}^1 \\to \\mathbb{P}^1")#text(" of degree high enough the base change ")#mi("X_{c}")#text(" is of general type. By Bombieri-Lang and Hilbert irreducibility, the morphism ")#mi("X_{c} \\to \\mathbb{P}^1")#text(" has then a generic section. In the second part, using a theorem of Caporaso-Harris-Mazur (with a follow up by Abramovich-Voloch for the higher dimensional case) I show that this abundance of covers with generic sections forces a generic section of ")#mi("X \\to \\mathbb{P}^{1}")#text(".")

#text("*Part 1* This part is the most technical one, I don’t know if there is a way to make it more accessible: since we want to use Bombieri-Lang, we can’t avoid showing that some surface is of general type, and this requires a certain familiarity with the topic.")

#text("By resolution of singularities, it is easy to reduce to the case in which both ")#mi("X")#text(" and the generic fiber of ")#mi("f")#text(" are smooth and projective. Consider the relative dualizing sheaf ")#mi("\\omega_{f} = \\omega_{X} \\otimes f^{*} \\omega_{\\mathbb{P}^1}^{-1}")#text(". Then ")#mi("f_{*}\\omega_{f}^m = f_{*}\\omega_{X}^m \\otimes \\mathcal{O}_{\\mathbb{P}^1}(2m)")#text(" is a vector bundle for every ")#mi("m")#text(", the argument is centered around the positivity of this vector bundle. As far as I know, the study of this positivity was initiated by Viehweg, with later important contributions by Kollar. Since we are over ")#mi("\\mathbb{P}^{1}")#text(", we may write ")#mi("f_{*}\\omega_{f}^m = \\oplus_{i}\\mathcal{O}(a_{i})")#text(", we are interested in the positivity of the integers ")#mi("a_{i}")#text(". Then part 1 is divided in three steps.")

#text("*Part 1, step 1* For every non-trivial family, I prove that there exist an ")#mi("m")#text(" and an ")#mi("i")#text(" such that ")#mi("a_{i}>0")#text(". If two generic fibers of the family are not birational one to another, then Kollar and Viehweg have shown that there exists an ")#mi("m")#text(" such that ")#mi("a_{i}>0")#text(" for *every* ")#mi("i")#text(", so there is nothing to do in this case. My work then is focused on the case in which two generic fibers are isomorphic, but the family is not trivial, i.e. the so called isotrivial families. The treatment of the isotrivial case is quite complex, see 3.9 and 3.10 of the paper. If needed, I can try to summarise this, too.")

#text("*Part 1, step 2* I show that, if ")#mi("a_{i}\\ge 5m_{0}")#text(" for some ")#mi("i")#text(" and some ")#mi("m_{0}")#text(", then ")#mi("X")#text(" is of general type. Viehweg has shown that ")#mi("a_{i}\\ge 0")#text(" for every ")#mi("i")#text(" and every ")#mi("m>0")#text(", thus we may choose an injective homomorphism ")#mi("\\mathcal{O}^{r(m)}\\to f_{*}\\omega_{X}^{m}")#text(" where ")#mi("r(m)")#text(" is the rank of ")#mi("f_{*}\\omega_{f}^{m}")#text(". This rank coincides with ")#mi("h^{0}(F,\\omega_{F}^{m})")#text(" where ")#mi("F")#text(" is a generic fiber, thus ")#mi("r(m)")#text(" has growth ")#mi("O(m)")#text(" since ")#mi("F")#text(" is of general type. Moreover, we have an injective homomorphism ")#mi("\\mathcal{O}(5m_{0})\\to f_{*}\\omega_{f}^{m_{0}}")#text(" for some ")#mi("m_{0}")#text(" by hypothesis. These induce an injective homomorphism ")#mi("\\mathcal{O}(5mm_{0})^{r(mm_{0})}\\to f_{*}\\omega_{f}^{2mm_{0}}")#text(", and thus ")#mi("\\mathcal{O}(mm_{0})^{r(mm_{0})}\\to f_{*}\\omega_{X}^{2mm_{0}}")#text(". We have then that ")#mi("h^{0}(X,\\omega_{X}^{2mm_{0}})")#text(" has growth ")#mi("O(m^{2})")#text(", thus ")#mi("X")#text(" is of general type. In the paper, I do more and give a precise characterization of which families are of general type as a whole.")

#text("*Part 1, step 3* So we know that ")#mi("a_{i}\\ge 1")#text(" for some ")#mi("m")#text(" and some ")#mi("i")#text(", and that ")#mi("X")#text(" is of general type if ")#mi("a_{i}\\ge 5m")#text(" for some ")#mi("m")#text(" and some ")#mi("i")#text(". Since the relative dualizing sheaf behaves well with respect to base change, we may pass from the first condition to the second by taking a cover ")#mi("c:\\mathbb{P}^{1}\\to\\mathbb{P}^{1}")#text(" of degree ")#mi("\\ge 5m")#text(". It might happen that the base change is singular, and if we apply resolution of singularities we ruin all the estimates we have done. Fortunately, for most covers the base change is smooth, it is enough to avoid ramification over a finite number of points.")

#text("*Part 2* So we know that ")#mi("X_{c}")#text(" is of general type for a generic cover ")#mi("c:\\mathbb{P}^{1}\\to\\mathbb{P}^{1}")#text(" of degree high enough. Choose coordinates on ")#mi("\\mathbb{P}^{1}")#text(" so that we are allowed to ramify over ")#mi("0")#text(" and ")#mi("\\infty")#text(". If ")#mi("c(p):\\mathbb{P}^{1}\\to\\mathbb{P}^{1}")#text(" is the map ")#mi("t\\mapsto t^{p}")#text(" for ")#mi("p")#text(" prime great enough, we have then a generic section of ")#mi("X_{c(p)}\\to\\mathbb{P}^{1}")#text(". Consider the composition ")#mi("s(p):\\mathbb{P}^{1}\\dashrightarrow X_{c(p)}\\to X")#text(". By Caporaso-Harris-Mazur, there is a bound on the number of rational points in the fibers of ")#mi("X\\to\\mathbb{P}^{1}")#text(". This implies that we may find two different prime numbers ")#mi("p,p^{\\prime}")#text(" such that the images of ")#mi("s(p),s(p^{\\prime})")#text(" coincide. By elementary Galois theory for cyclic covers, we conclude that the image of ")#mi("s(p)")#text(" in ")#mi("X")#text(" is birational over ")#mi("\\mathbb{P}^{1}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-615760")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2021")])]

#text("Many thanks for this! I compiled the LaTeX (the format WordPress uses to encode LaTeX is described at the bottom of this page and also at ")#link("https://terrytao.wordpress.com/about/")[#text("https://terrytao.wordpress.com/about/")]#text(" ) and look forward to going through the argument more carefully.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f75c6e6afb95b1cb24ac63bf8074c2e6d86f4c4e6bf7fc9e8216335cc5f6fc56-59b3503947be771e23e2f594a807bca00d6994b69e14a0c6d6162b526b8457a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giulio Bresciani")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-615990")[#strong[#text("Giulio Bresciani")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2021")])]

#text("Bibliography:")

#text("– For the positivity theorem of Kollar-Viehweg, see Theorem, pg 363 of Kollar, “Subadditivity of the Kodaira dimension: fibers of general type”. In: Algebraic geometry, Sendai, 1985. Vol. 10. Adv. Stud. Pure Math. North-Holland, Amsterdam, 1987, pp. 361–398.")

#text("– For the weak positivity theorem of Viehweg, see Theorem III of Viehweg, “Weak positivity and the additivity of the Kodaira dimension for certain fibre spaces”. In: Algebraic varieties and analytic varieties (Tokyo, 1981). Vol. 1. Adv. Stud. Pure Math. North-Holland, Amsterdam, 1983, pp. 329–353.")

#text("– For the uniform bound on fibers, see Theorem 1.1 of Caporaso-Harris-Mazur “Uniformity of rational points”. In: J. Amer. Math. Soc. 10.1 (1997), pp. 1–35.")

#text("Addendum:")

#text("Theorem A actually uses the weak Bombieri-Lang conjecture in all dimensions in order to apply the theorem of Caporaso-Harris-Mazur and give an uniform bound on the cardinality of fibers (the full conjecture is already needed for one dimensional families of curves!). For the problem of bijections ")#mi("\\mathbb{Q} \\times \\mathbb{Q} \\to \\mathbb{Q}")#text(", the uniform bound is given by hypothesis, thus the theorem of CHM is not needed. It follows that Bombieri-Lang for surfaces is sufficient.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2019/06/08/ruling-out-polynomial-bijections-over-the-rationals-via-bombieri-lang/#comment-615359")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2021")])]

#text("For what it’s worth, this has dropped on the arXiv:")

#text("Giulio Bresciani, “A higher dimensional Hilbert irreducibility theorem”")

#text("Abstract:")#linebreak()#text(" Assuming the weak Bombieri-Lang conjecture, we prove that a kind of Hilbert irreducibility theorem holds for families of geometrically mordellic varieties (for instance, families of hyperbolic curves). As an application we prove that, assuming Bombieri-Lang, there are no polynomial bijections ℚ×ℚ→ℚ, using a strategy first outlined in a “polymath project” led by T. Tao.")

#link("https://arxiv.org/abs/2101.01090")[#text("https://arxiv.org/abs/2101.01090")]
]
