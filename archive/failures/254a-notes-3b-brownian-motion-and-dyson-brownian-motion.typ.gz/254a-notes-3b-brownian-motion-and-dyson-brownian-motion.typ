// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/
// Converted to Typst by tao2typ: "2026-10-14T11:30:03.141596+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 3b: Brownian motion and Dyson Brownian motion", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 3b: Brownian motion and Dyson Brownian motion")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 January 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/")[#text("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One theme in this course will be the central nature played by the ")#emph[#text("gaussian random variables")]#text(" ")#mi("{X \\equiv N(\\mu,\\sigma^2)}")#text(". Gaussians have an incredibly rich algebraic structure, and many results about general random variables can be established by first using this structure to verify the result for gaussians, and then using universality techniques (such as the Lindeberg exchange strategy) to extend the results to more general variables.")

#text("One way to exploit this algebraic structure is to continuously deform the variance ")#mi("{t := \\sigma^2}")#text(" from an initial variance of zero (so that the random variable is deterministic) to some final level ")#mi("{T}")#text(". We would like to use this to give a continuous family ")#mi("{t \\mapsto X_t}")#text(" of random variables ")#mi("{X_t \\equiv N(\\mu, t)}")#text(" as ")#mi("{t}")#text(" (viewed as a “time” parameter) runs from ")#mi("{0}")#text(" to ")#mi("{T}")#text(".")

#text("At present, we have not completely specified what ")#mi("{X_t}")#text(" should be, because we have only described the individual distribution ")#mi("{X_t \\equiv N(\\mu,t)}")#text(" of each ")#mi("{X_t}")#text(", and not the joint distribution. However, there is a very natural way to specify a joint distribution of this type, known as ")#link("http://en.wikipedia.org/wiki/Brownian_motion")[#text("Brownian motion")]#text(". In these notes we lay the necessary probability theory foundations to set up this motion, and indicate its connection with the heat equation, the central limit theorem, and the Ornstein-Uhlenbeck process. This is the beginning of ")#link("http://en.wikipedia.org/wiki/Stochastic_calculus")[#text("stochastic calculus")]#text(", which we will not develop fully here.")

#text("We will begin with one-dimensional Brownian motion, but it is a simple matter to extend the process to higher dimensions. In particular, we can define Brownian motion on vector spaces of matrices, such as the space of ")#mi("{n \\times n}")#text(" Hermitian matrices. This process is equivariant with respect to conjugation by unitary matrices, and so we can quotient out by this conjugation and obtain a new process on the quotient space, or in other words on the ")#emph[#text("spectrum")]#text(" of ")#mi("{n \\times n}")#text(" Hermitian matrices. This process is called ")#emph[#text("Dyson Brownian motion")]#text(", and turns out to have a simple description in terms of ordinary Brownian motion; it will play a key role in several of the subsequent notes in this course.")

#metadata(none) <tao-bec8a8ecd7c50bb38e92>

#heading(level: 1)[#strong[#text(" — 1. Formal construction of Brownian motion — ")]]

#text("We begin with constructing one-dimensional Brownian motion. We shall model this motion using the machinery of ")#link("http://en.wikipedia.org/wiki/Wiener_process")[#text("Wiener processes")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Wiener process)")]#text(" ")#metadata(none) <tao-bd2b8a407c25757e310c>#text(" Let ")#mi("{\\mu \\in {\\bf R}}")#text(", and let ")#mi("{\\Sigma \\subset [0,+\\infty)}")#text(" be a set of times containing ")#mi("{0}")#text(". A (one-dimensional) ")#emph[#text("Wiener process")]#text(" on ")#mi("{\\Sigma}")#text(" with initial position ")#mi("{\\mu}")#text(" is a collection ")#mi("{(X_t)_{t \\in \\Sigma}}")#text(" of real random variables ")#mi("{X_t}")#text(" for each time ")#mi("{t \\in \\Sigma}")#text(", with the following properties:")

#list(
[#text("(i) ")#mi("{X_0 = \\mu}")#text(".")],
[#text("(ii) Almost surely, the map ")#mi("{t \\mapsto X_t}")#text(" is a continuous function on ")#mi("{\\Sigma}")#text(".")],
[#text("(iii) For every ")#mi("{0 \\leq t_- < t_+}")#text(" in ")#mi("{\\Sigma}")#text(", the increment ")#mi("{X_{t_+}-X_{t_-}}")#text(" has the distribution of ")#mi("{N( 0, t_+ - t_- )_{\\bf R}}")#text(". (In particular, ")#mi("{X_t \\equiv N(\\mu,t)_{\\bf R}}")#text(" for every ")#mi("{t > 0}")#text(".)")],
[#text("(iv) For every ")#mi("{t_0 \\leq t_1 \\leq \\ldots \\leq t_n}")#text(" in ")#mi("{\\Sigma}")#text(", the increments ")#mi("{X_{t_{i}} - X_{t_{i-1}}}")#text(" for ")#mi("{i=1,\\ldots,n}")#text(" are jointly independent.")]
)

#text("If ")#mi("{\\Sigma}")#text(" is discrete, we say that ")#mi("{(X_t)_{t \\in \\Sigma}}")#text(" is a ")#emph[#text("discrete Wiener process")]#text("; if ")#mi("{\\Sigma = [0,+\\infty)}")#text(" then we say that ")#mi("{(X_t)_{t \\in \\Sigma}}")#text(" is a ")#emph[#text("continuous Wiener process")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" Collections of random variables ")#mi("{(X_t)_{t \\in \\Sigma}}")#text(", where ")#mi("{\\Sigma}")#text(" is a set of times, will be referred to as ")#link("http://en.wikipedia.org/wiki/Stochastic_process")[#text("stochastic processes")]#text(", thus Wiener processes are a (very) special type of stochastic process.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" In the case of discrete Wiener processes, the continuity requirement (ii) is automatic. For continuous Wiener processes, there is a minor technical issue: the event that ")#mi("{t \\mapsto X_t}")#text(" is continuous need not be a measurable event (one has to take uncountable intersections to define this event). Because of this, we interpret (ii) by saying that there exists a measurable event of probability ")#mi("{1}")#text(", such that ")#mi("{t \\mapsto X_t}")#text(" is continuous on all of this event, while also allowing for the possibility that ")#mi("{t \\mapsto X_t}")#text(" could also sometimes be continuous outside of this event also. One can view the collection ")#mi("{(X_t)_{t \\in \\Sigma}}")#text(" as a single random variable, taking values in the product space ")#mi("{{\\bf R}^\\Sigma}")#text(" (with the product ")#mi("{\\sigma}")#text("-algebra, of course).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" One can clearly normalise the initial position ")#mi("{\\mu}")#text(" of a Wiener process to be zero by replacing ")#mi("{X_t}")#text(" with ")#mi("{X_t-\\mu}")#text(" for each ")#mi("{t}")#text(".")
]

#text("We shall abuse notation somewhat and identify continuous Wiener processes with Brownian motion in our informal discussion, although technically the former is merely a model for the latter. To emphasise this link with Brownian motion, we shall often denote continuous Wiener processes as ")#mi("{(B_t)_{t \\in [0,+\\infty)}}")#text(" rather than ")#mi("{(X_t)_{t \\in [0,+\\infty)}}")#text(".")

#text("It is not yet obvious that Wiener processes exist, and to what extent they are unique. The situation is easily clarified though for discrete processes:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5 (Discrete Brownian motion)")]#text(" ")#metadata(none) <tao-7bdc25d1694ef984782a>#text(" Let ")#mi("{\\Sigma}")#text(" be a discrete subset of ")#mi("{[0,+\\infty)}")#text(" containing ")#mi("{0}")#text(", and let ")#mi("{\\mu\\in {\\bf R}}")#text(". Then (after extending the sample space if necessary) there exists a Wiener process ")#mi("{(X_t)_{t \\in \\Sigma}}")#text(" with base point ")#mi("{\\mu}")#text(". Furthermore, any other Wiener process ")#mi("{(X^{\\prime}_t)_{t \\in \\Sigma}}")#text(" with base point ")#mi("{\\mu}")#text(" has the same distribution as ")#mi("{(X_t)_{t \\in \\Sigma}}")#text(".")
]

#emph[#text("Proof:")]#text(" As ")#mi("{\\Sigma}")#text(" is discrete and contains ")#mi("{0}")#text(", we can write it as ")#mi("{\\{t_0,t_1,t_2,\\ldots\\}}")#text(" for some")

#align(center)[#tao-fit-display[#mitex("0 = t_0 < t_1 < t_2 < \\ldots.")]]

#text("Let ")#mi("{(dX_i)_{i=1}^\\infty}")#text(" be a collection of jointly independent random variables with ")#mi("{dX_i \\equiv N(0,t_i-t_{i-1})_{\\bf R}}")#text(" (the existence of such a collection, after extending the sample space, is guaranteed by Exercise 18 of ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("Notes 0")]#text(".) If we then set")

#align(center)[#tao-fit-display[#mitex("X_{t_i} := \\mu + dX_1 + \\ldots + dX_i")]]

#text("for all ")#mi("{i=0,1,2,\\ldots}")#text(", then one easily verifies (using Exercise 9 of ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text(") that ")#mi("{(X_t)_{t \\in \\Sigma}}")#text(" is a Wiener process.")

#text("Conversely, if ")#mi("{(X^{\\prime}_t)_{t \\in \\Sigma}}")#text(" is a Wiener process, and we define ")#mi("{dX^{\\prime}_i := X^{\\prime}_i - X^{\\prime}_{i-1}}")#text(" for ")#mi("{i=1,2,\\ldots}")#text(", then from the definition of a Wiener process we see that the ")#mi("{dX^{\\prime}_i}")#text(" have distribution ")#mi("{N(0,t_i-t_{i-1})_{\\bf R}}")#text(" and are jointly independent (i.e. any finite subcollection of the ")#mi("{dX^{\\prime}_i}")#text(" are jointly independent). This implies for any finite ")#mi("{n}")#text(" that the random variables ")#mi("{(dX_i)_{i=1}^n}")#text(" and ")#mi("{(dX^{\\prime}_i)_{i=1}^n}")#text(" have the same distribution, and thus ")#mi("{(X_t)_{t \\in \\Sigma^{\\prime}}}")#text(" and ")#mi("{(X^{\\prime}_t)_{t \\in \\Sigma^{\\prime}}}")#text(" have the same distribution for any finite subset ")#mi("{\\Sigma^{\\prime}}")#text(" of ")#mi("{\\Sigma}")#text(". From the construction of the product ")#mi("{\\sigma}")#text("-algebra we conclude that ")#mi("{(X_t)_{t \\in \\Sigma}}")#text(" and ")#mi("{(X^{\\prime}_t)_{t \\in \\Sigma}}")#text(" have the same distribution, as required. ")#mi("\\Box")

#text("Now we pass from the discrete case to the continuous case.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6 (Continuous Brownian motion)")]#text(" Let ")#mi("{\\mu\\in {\\bf R}}")#text(". Then (after extending the sample space if necessary) there exists a Wiener process ")#mi("{(X_t)_{t \\in [0,+\\infty)}}")#text(" with base point ")#mi("{\\mu}")#text(". Furthermore, any other Wiener process ")#mi("{(X^{\\prime}_t)_{t \\in [0,+\\infty)}}")#text(" with base point ")#mi("{\\mu}")#text(" has the same distribution as ")#mi("{(X_t)_{t \\in [0,+\\infty)}}")#text(".")
]

#emph[#text("Proof:")]#text(" The uniqueness claim follows by the same argument used to prove the uniqueness component of Proposition ")#link(<tao-7bdc25d1694ef984782a>)[#text("5")]#text(", so we just prove existence here. The iterative construction we give here is somewhat analogous to that used to create self-similar fractals, such as the ")#link("http://en.wikipedia.org/wiki/Koch_snowflake")[#text("Koch snowflake")]#text(". (Indeed, Brownian motion can be viewed as a probabilistic analogue of a self-similar fractal.)")

#text("The idea is to create a sequence of increasingly fine discrete Brownian motions, and then to take a limit. Proposition ")#link(<tao-7bdc25d1694ef984782a>)[#text("5")]#text(" allows one to create each individual discrete Brownian motion, but the key is to ")#emph[#text("couple")]#text(" these discrete processes together in a consistent manner.")

#text("Here’s how. We start with a discrete Wiener process ")#mi("{(X_t)_{t \\in {\\bf N}}}")#text(" on the natural numbers ")#mi("{{\\bf N} = \\{0,1,2\\ldots\\}}")#text(" with initial position ")#mi("{\\mu}")#text(", which exists by Proposition ")#link(<tao-7bdc25d1694ef984782a>)[#text("5")]#text(". We now extend this process to the denser set of times ")#mi("{\\frac{1}{2} {\\bf N} := \\{ \\frac{1}{2} n: n \\in {\\bf N} \\}}")#text(" by setting")

#align(center)[#tao-fit-display[#mitex("X_{t+\\frac{1}{2}} := \\frac{X_t + X_{t+1}}{2} + Y_{t,0}")]]

#text("for ")#mi("{t=0,1,2,\\ldots}")#text(", where ")#mi("{(Y_{t,0})_{t \\in {\\bf N}}}")#text(" are iid copies of ")#mi("{N(0,1/4)_{\\bf R}}")#text(", which are jointly independent of the ")#mi("{(X_t)_{t \\in {\\bf N}}}")#text(". It is a routine matter to use Exercise 9 of ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text(" to show that this creates a discrete Wiener process ")#mi("{(X_t)_{t \\in \\frac{1}{2} {\\bf N}}}")#text(" on ")#mi("{\\frac{1}{2}{\\bf N}}")#text(" which extends the previous process.")

#text("Next, we extend the process further to the denser set of times ")#mi("{\\frac{1}{4} {\\bf N}}")#text(" by defining")

#align(center)[#tao-fit-display[#mitex("X_{t+\\frac{1}{4}} := \\frac{X_{t} + X_{t+1/2}}{2} + Y_{t,1}")]]

#text("where ")#mi("{(Y_{t,1})_{t \\in \\frac{1}{2}{\\bf N}}}")#text(" are iid copies of ")#mi("{N(0,1/8)_{\\bf R}}")#text(", jointly independent of ")#mi("{(X_t)_{t \\in \\frac{1}{2} {\\bf N}}}")#text(". Again, it is a routine matter to show that this creates a discrete Wiener process ")#mi("{(X_t)_{t \\in \\frac{1}{4} {\\bf N}}}")#text(" on ")#mi("{\\frac{1}{4}{\\bf N}}")#text(".")

#text("Iterating this procedure a countable number of times, we obtain a collection of discrete Wiener processes ")#mi("{(X_t)_{t \\in \\frac{1}{2^k} {\\bf N}}}")#text(" for ")#mi("{k=0,1,2,\\ldots}")#text(" which are consistent with each other, in the sense that the earlier processes in this collection are restrictions of later ones. (This requires a countable number of extensions of the underlying sample space, but one can capture all of these extensions into a single extension via the machinery of ")#link("http://en.wikipedia.org/wiki/Inverse_limit")[#text("inverse limits")]#text(" of probability spaces; it is also not difficult to manually build a single extension sufficient for performing all the above constructions.)")

#text("Now we establish a Hölder continuity property. Let ")#mi("{\\theta}")#text(" be any exponent between ")#mi("{0}")#text(" and ")#mi("{1/2}")#text(", and let ")#mi("{T > 0}")#text(" be finite. Observe that for any ")#mi("{k = 0,1,\\ldots}")#text(" and any ")#mi("{j \\in {\\bf N}}")#text(", we have ")#mi("{X_{(j+1)/2^k} - X_{j/2^k} \\equiv N(0,1/2^k)_{\\bf R}}")#text(" and hence (by the subgaussian nature of the normal distribution)")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|X_{(j+1)/2^k} - X_{j/2^k}\\right| \\geq 2^{-k \\theta} ) \\leq C \\exp( - c 2^{k(1-2\\theta)} )", block: true)]]

#text("for some absolute constants ")#mi("{C, c}")#text(". The right-hand side is summable as ")#mi("{j,k}")#text(" run over ")#mi("{{\\bf N}}")#text(" subject to the constraint ")#mi("{j/2^k \\leq T}")#text(". Thus, by the Borel-Cantelli lemma, for each fixed ")#mi("{T}")#text(", we almost surely have that")

#align(center)[#tao-fit-display[#tao-math("\\left|X_{(j+1)/2^k} - X_{j/2^k}\\right| \\leq 2^{-k \\theta}", block: true)]]

#text("for all but finitely many ")#mi("{j,k \\in {\\bf N}}")#text(" with ")#mi("{j/2^k \\leq T}")#text(". In particular, this implies that for each fixed ")#mi("{T}")#text(", the function ")#mi("{t \\mapsto X_t}")#text(" is almost surely ")#link("http://en.wikipedia.org/wiki/H%C3%B6lder_condition")[#text("Hölder continuous")]#text(" of exponent ")#mi("{\\theta}")#text(" on the dyadic rationals ")#mi("{j/2^k}")#text(" in ")#mi("{[0,T]}")#text(", and thus (by the countable union bound) is almost surely locally Hölder continuous of exponent ")#mi("{\\theta}")#text(" on the dyadic rationals in ")#mi("{[0,+\\infty)}")#text(". In particular, they are almost surely locally uniformly continuous on this domain.")

#text("As the dyadic rationals are dense in ")#mi("{[0,+\\infty)}")#text(", we can thus almost surely extend ")#mi("{t \\mapsto X_t}")#text(" uniquely to a continuous function on all of ")#mi("{[0,+\\infty)}")#text(". (On the remaining probability zero event, we extend ")#mi("{t \\mapsto X_t}")#text(" in some arbitrary measurable fashion.) Note that if ")#mi("{t_n}")#text(" is any sequence in ")#mi("{[0,+\\infty)}")#text(" converging to ")#mi("{t}")#text(", then ")#mi("{X_{t_n}}")#text(" converges almost surely to ")#mi("{X_t}")#text(", and thus also converges in probability and in distribution. Similarly for differences such as ")#mi("{X_{t_{+,n}} - X_{t_{-,n}}}")#text(". Using this, we easily verify that ")#mi("{(X_t)_{t \\in [0,+\\infty)}}")#text(" is a continuous Wiener process, as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" One could also have used the ")#link("http://en.wikipedia.org/wiki/Kolmogorov_extension_theorem")[#text("Kolmogorov extension theorem")]#text(" to establish the limit.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Let ")#mi("{(X_t)_{t \\in [0,+\\infty)}}")#text(" be a continuous Wiener process. We have already seen that if ")#mi("{0 < \\theta < 1/2}")#text(", that the map ")#mi("{t \\mapsto X_t}")#text(" is almost surely Hölder continuous of order ")#mi("{\\theta}")#text(". Show that if ")#mi("{1/2 \\leq \\theta \\leq 1}")#text(", then the map ")#mi("{t \\mapsto X_t}")#text(" is almost surely ")#emph[#text("not")]#text(" Hölder continuous of order ")#mi("{\\theta}")#text(".")

#text("Show also that the map ")#mi("{t \\mapsto X_t}")#text(" is almost surely nowhere differentiable. Thus, Brownian motion provides a (probabilistic) example of a continuous function which is nowhere differentiable.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" ")#metadata(none) <tao-eef039444ec32273e238>#text(" In the above constructions, the initial position ")#mi("{\\mu}")#text(" of the Wiener process was deterministic. However, one can easily construct Wiener processes in which the initial position ")#mi("{X_0}")#text(" is itself a random variable. Indeed, one can simply set")

#align(center)[#tao-fit-display[#mitex("X_t := X_0 + B_t")]]

#text("where ")#mi("{(B_t)_{t \\in [0,+\\infty)}}")#text(" is a continuous Wiener process with initial position ")#mi("{0}")#text(" which is independent of ")#mi("{X_0}")#text(". Then we see that ")#mi("{X_t}")#text(" obeys properties (ii), (iii), (iv) of Definition ")#link(<tao-bd2b8a407c25757e310c>)[#text("1")]#text(", but the distribution of ")#mi("{X_t}")#text(" is no longer ")#mi("{N(\\mu,t)_{\\bf R}}")#text(", but is instead the convolution of the law of ")#mi("{X_0}")#text(", and the law of ")#mi("{N(0,t)_{\\bf R}}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 2. Connection with random walks — ")]]

#text("We saw how to construct Brownian motion as a limit of discrete Wiener processes, which were partial sums of independent gaussian random variables. The central limit theorem (see Notes 2) allows one to interpret Brownian motion in terms of limits of partial sums of more general independent random variables, otherwise known as (independent) ")#link("http://en.wikipedia.org/wiki/Random_walk")[#text("random walks")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 10 (Random walk)")]#text(" Let ")#mi("{\\Delta X}")#text(" be a real random variable, let ")#mi("{\\mu \\in {\\bf R}}")#text(" be an initial position, and let ")#mi("{\\Delta t > 0}")#text(" be a time step. We define a ")#emph[#text("discrete random walk")]#text(" with initial position ")#mi("{\\mu}")#text(", time step ")#mi("{\\Delta t}")#text(" and step distribution ")#mi("{\\Delta X}")#text(" (or ")#mi("{\\mu_{\\Delta X}}")#text(") to be a process ")#mi("{(X_t)_{t \\in \\Delta t \\cdot {\\bf N}}}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("X_{n \\Delta t} := \\mu + \\sum_{i=1}^n \\Delta X_{i \\Delta t}")]]

#text("where ")#mi("{(\\Delta X_{i \\Delta t})_{i=1}^\\infty}")#text(" are iid copies of ")#mi("{\\Delta X}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 11")]#text(" From the proof of Proposition ")#link(<tao-7bdc25d1694ef984782a>)[#text("5")]#text(", we see that a discrete Wiener process on ")#mi("{\\Delta t \\cdot {\\bf N}}")#text(" with initial position ")#mi("{\\mu}")#text(" is nothing more than a discrete random walk with step distribution of ")#mi("{N(0,\\Delta t)_{\\bf R}}")#text(". Another basic example is ")#emph[#text("simple random walk")]#text(", in which ")#mi("{\\Delta X}")#text(" is equal to ")#mi("{(\\Delta t)^{1/2}}")#text(" times a signed Bernoulli variable, thus we have ")#mi("{X_{(n+1) \\Delta t} = X_{n\\Delta t} \\pm (\\Delta t)^{1/2}}")#text(", where the signs ")#mi("{\\pm}")#text(" are unbiased and are jointly independent in ")#mi("{n}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Central limit theorem)")]#text(" ")#metadata(none) <tao-667ae99a22d281e83efd>#text(" Let ")#mi("{X}")#text(" be a real random variable with mean zero and variance ")#mi("{1}")#text(", and let ")#mi("{\\mu \\in {\\bf R}}")#text(". For each ")#mi("{\\Delta t > 0}")#text(", let ")#mi("{(X^{(\\Delta t)}_t)_{t \\in [0,+\\infty)}}")#text(" be a process formed by starting with a random walk ")#mi("{(X^{(\\Delta t)}_t)_{t \\in \\Delta t \\cdot {\\bf N}}}")#text(" with initial position ")#mi("{\\mu}")#text(", time step ")#mi("{\\Delta t}")#text(", and step distribution ")#mi("{(\\Delta t)^{1/2} X}")#text(", and then extending to other times in ")#mi("{[0,+\\infty)}")#text(", in a piecewise linear fashion, thus")

#align(center)[#tao-fit-display[#mitex("X^{(\\Delta t)}_{(n+\\theta) \\Delta t} := (1-\\theta) X^{(\\Delta t)}_{n \\Delta t} + \\theta X^{(\\Delta t)}_{(n+1) \\Delta t}")]]

#text("for all ")#mi("{n \\in {\\bf N}}")#text(" and ")#mi("{0 < \\theta < 1}")#text(". Show that as ")#mi("{\\Delta t \\rightarrow 0}")#text(", the process ")#mi("{(X^{(\\Delta t)}_t)_{t \\in [0,+\\infty)}}")#text(" converges in distribution to a continuous Wiener process with initial position ")#mi("{\\mu}")#text(". (")#emph[#text("Hint:")]#text(" from the Riesz representation theorem (or the ")#link("http://en.wikipedia.org/wiki/Kolmogorov_extension_theorem")[#text("Kolmogorov extension theorem")]#text("), it suffices to establish this convergence for every finite set of times in ")#mi("{[0,+\\infty)}")#text(". Now use the central limit theorem; treating the piecewise linear modifications to the process as an error term.)")
]

#heading(level: 1)[#strong[#text(" — 3. Connection with the heat equation — ")]]

#text("Let ")#mi("{(B_t)_{t \\in [0,+\\infty)}}")#text(" be a Wiener process with base point ")#mi("{\\mu}")#text(", and let ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a smooth function with all derivatives bounded. Then, for each time ")#mi("{t}")#text(", the random variable ")#mi("{F(B_t)}")#text(" is bounded and thus has an expectation ")#mi("{{\\bf E} F(B_t)}")#text(". From the almost sure continuity of ")#mi("{B_t}")#text(" and the dominated convergence theorem we see that the map ")#mi("{t \\mapsto {\\bf E} F(B_t)}")#text(" is continuous. In fact it is differentiable, and obeys the following differential equation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 13 (Equation of motion)")]#text(" ")#metadata(none) <tao-79c934390f9dac7f0c51>#text(" For all times ")#mi("{t \\geq 0}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} {\\bf E} F(B_t) = \\frac{1}{2} {\\bf E} F_{xx}(B_t)")]]

#text("where ")#mi("{F_{xx}}")#text(" is the second derivative of ")#mi("{F}")#text(". In particular, ")#mi("{t \\mapsto {\\bf E} F(B_t)}")#text(" is continuously differentiable (because the right-hand side is continuous).")
]

#emph[#text("Proof:")]#text(" We work from first principles. It suffices to show for fixed ")#mi("{t \\geq 0}")#text(", that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} F(B_{t+dt}) = {\\bf E} F(B_t) + \\frac{1}{2} dt {\\bf E} F_{xx}(B_t) + o(dt)")]]

#text("as ")#mi("{dt \\rightarrow 0}")#text(". We shall establish this just for non-negative ")#mi("{dt}")#text("; the claim for negative ")#mi("{dt}")#text(" (which only needs to be considered for ")#mi("{t>0}")#text(") is similar and is left as an exercise.")

#text("Write ")#mi("{dB_t := B_{t+dt} - B_t}")#text(". From Taylor expansion and the bounded third derivative of ")#mi("{F}")#text(", we have ")#metadata(none) <tao-52d39e8483d105cff165>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("F(B_{t+dt}) = F(B_t) + F_x(B_t) dB_t + \\frac{1}{2} F_{xx}(B_t) \\left|dB_t\\right|^2 + O( \\left|dB_t\\right|^3 ).", block: true)]]

#text("We take expectations. Since ")#mi("{dB_t \\equiv N(0,dt)_{\\bf R}}")#text(", we have ")#tao-math("{{\\bf E} \\left|dB_t\\right|^3 = O( (dt)^{3/2} )}", block: false)#text(", so in particular")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} F(B_{t+dt}) = {\\bf E} F(B_t) + {\\bf E} F_x(B_t) dB_t + \\frac{1}{2} {\\bf E} F_{xx}(B_t) \\left|dB_t\\right|^2 + o(dt).", block: true)]]

#text("Now observe that ")#mi("{dB_t}")#text(" is independent of ")#mi("{B_t}")#text(", and has mean zero and variance ")#mi("{dt}")#text(". The claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Complete the proof of the lemma by considering negative values of ")#mi("{dt}")#text(". (")#emph[#text("Hint:")]#text(" one has to exercise caution because ")#mi("{dB_t}")#text(" is not independent of ")#mi("{B_t}")#text(" in this case. However, it will be independent of ")#mi("{B_{t+dt}}")#text(". Also, use the fact that ")#mi("{{\\bf E} F_x(B_t)}")#text(" and ")#mi("{{\\bf E} F_{xx}(B_t)}")#text(" are continuous in ")#mi("{t}")#text(". Alternatively, one can deduce the formula for the left-derivative from that of the right-derivative via a careful application of the fundamental theorem of calculus, paying close attention to the hypotheses of that theorem.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 15")]#text(" In the language of ")#link("http://en.wikipedia.org/wiki/It%C5%8D_calculus")[#text("Ito calculus")]#text(", we can write ")#link(<tao-52d39e8483d105cff165>)[#text("(1)")]#text(" as ")#metadata(none) <tao-fb4cf9a05ec9ea65fbbb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("d F(B_t) = F_x(B_t) dB_t + \\frac{1}{2} F_{xx}(B_t) dt.")]]

#text("Here, ")#mi("{dF(B_t) := F(B_{t+dt}) - F(B_t)}")#text(", and ")#mi("{dt}")#text(" should either be thought of as being infinitesimal, or being very small, though in the latter case the equation ")#link(<tao-fb4cf9a05ec9ea65fbbb>)[#text("(2)")]#text(" should not be viewed as being exact, but instead only being true up to errors of mean ")#mi("{o(dt)}")#text(" and third moment ")#mi("{O(dt^3)}")#text(". This is a special case of ")#link("http://en.wikipedia.org/wiki/It%C5%8D%27s_lemma")[#text("Ito’s formula")]#text(". It should be compared against the chain rule")

#align(center)[#tao-fit-display[#mitex("dF(X_t) = F_x(X_t) dX_t")]]

#text("when ")#mi("{t \\mapsto X_t}")#text(" is a ")#emph[#text("smooth")]#text(" process. The non-smooth nature of Brownian motion causes the quadratic term in the Taylor expansion to be non-negligible, which explains the additional term in ")#link(<tao-fb4cf9a05ec9ea65fbbb>)[#text("(2)")]#text(", although the Hölder continuity of this motion is sufficient to still be able to ignore terms that are of cubic order or higher. (In this spirit, one can summarise (the differential side of) Ito calculus informally by the heuristic equations ")#mi("{dB_t = O( (dt)^{1/2} )}")#text(" and ")#tao-math("{\\left|dB_t\\right|^2 = dt}", block: false)#text(", with the understanding that all terms that are ")#mi("{o(dt)}")#text(" are discarded.)")
]

#text("Let ")#mi("{\\rho(t,x)\\ dx}")#text(" be the probability density function of ")#mi("{B_t}")#text("; by inspection of the normal distribution, this is a smooth function for ")#mi("{t>0}")#text(", but is a Dirac mass at ")#mi("{\\mu}")#text(" at time ")#mi("{t=0}")#text(". By definition of density function,")

#align(center)[#tao-fit-display[#mitex("{\\bf E} F(B_t) = \\int_{\\bf R} F(x) \\rho(t,x)\\ dx")]]

#text("for any ")#link("http://en.wikipedia.org/wiki/Schwartz_space")[#text("Schwartz function")]#text(" ")#mi("{F}")#text(". Applying Lemma ")#link(<tao-79c934390f9dac7f0c51>)[#text("13")]#text(" and integrating by parts, we see that ")#metadata(none) <tao-5a2a0ed9aa3ab7d82b53>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\partial_t \\rho = \\frac{1}{2} \\partial_{xx} \\rho")]]

#text("in the sense of (tempered) distributions (see e.g. ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("my earlier notes")]#text(" on this topic). In other words, ")#mi("{\\rho}")#text(" is a (tempered distributional) solution to the ")#link("http://en.wikipedia.org/wiki/Heat_equation")[#text("heat equation")]#text(" ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(3)")]#text(". Indeed, since ")#mi("{\\rho}")#text(" is the Dirac mass at ")#mi("{\\mu}")#text(" at time ")#mi("{t=0}")#text(", ")#mi("{\\rho}")#text(" for later times ")#mi("{t}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Fundamental_solution")[#text("fundamental solution")]#text(" of that equation from initial position ")#mi("{\\mu}")#text(".")

#text("From the theory of PDE (e.g. from Fourier analysis, see Exercise 38 of ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("these notes")]#text(") one can solve the (distributional) heat equation with this initial data to obtain the unique solution")

#align(center)[#tao-fit-display[#tao-math("\\rho(t,x) = \\frac{1}{\\sqrt{2\\pi t}} e^{-\\left|x-\\mu\\right|^2/2t}.", block: true)]]

#text("Of course, this is also the density function of ")#mi("{N(\\mu,t)_{\\bf R}}")#text(", which is (unsurprisingly) consistent with the fact that ")#mi("{B_t \\equiv N(\\mu,t)}")#text(". Thus we see why the normal distribution of the central limit theorem involves the same type of functions (i.e. gaussians) as the fundamental solution of the heat equation. Indeed, one can use this argument to heuristically ")#emph[#text("derive")]#text(" the central limit theorem from the fundamental solution of the heat equation (cf. Section 7 of ")#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/")[#text("Notes 2")]#text("), although the derivation is only heuristic because one first needs to know that ")#emph[#text("some")]#text(" limiting distribution already exists (in the spirit of Exercise ")#link(<tao-667ae99a22d281e83efd>)[#text("12")]#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 16")]#text(" Because we considered a Wiener process with a deterministic initial position ")#mi("{\\mu}")#text(", the density function ")#mi("{\\rho}")#text(" was a Dirac mass at time ")#mi("{t=0}")#text(". However, one can run exactly the same arguments for Wiener processes with stochastic initial position (see Remark ")#link(<tao-eef039444ec32273e238>)[#text("9")]#text("), and one will still obtain the same heat equation ")#link(<tao-eef039444ec32273e238>)[#text("(9)")]#text(", but now with a more general initial condition.")
]

#text("We have related one-dimensional Brownian motion to the one-dimensional heat equation, but there is no difficulty establishing a similar relationship in higher dimensions. In a vector space ")#mi("{{\\bf R}^n}")#text(", define a (continuous) ")#emph[#text("Wiener process")]#text(" ")#mi("{(X_t)_{t \\in [0,+\\infty)}}")#text(" in ")#mi("{{\\bf R}^n}")#text(" with an initial position ")#mi("{\\mu = (\\mu_1,\\ldots,\\mu_n) \\in {\\bf R}^n}")#text(" to be a process whose components ")#mi("{(X_{t,i})_{t \\in [0,+\\infty)}}")#text(" for ")#mi("{i=1,\\ldots,n}")#text(" are independent Wiener processes with initial position ")#mi("{\\mu_i}")#text(". It is easy to see that such processes exist, are unique in distribution, and obey the same sort of properties as in Definition ")#link(<tao-bd2b8a407c25757e310c>)[#text("1")]#text(", but with the one-dimensional gaussian distribution ")#mi("{N(\\mu,\\sigma^2)_{\\bf R}}")#text(" replaced by the ")#mi("{n}")#text("-dimensional analogue ")#mi("{N(\\mu,\\sigma^2 I)_{{\\bf R}^n}}")#text(", which is given by the density function")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{(2\\pi \\sigma)^{n/2}} e^{-\\left|x-\\mu\\right|^2/\\sigma^2}\\ dx", block: true)]]

#text("where ")#mi("{dx}")#text(" is now Lebesgue measure on ")#mi("{{\\bf R}^n}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" If ")#mi("{(B_t)_{t \\in [0,+\\infty)}}")#text(" is an ")#mi("{n}")#text("-dimensional continuous Wiener process, show that")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} {\\bf E} F(B_t) = \\frac{1}{2} {\\bf E} (\\Delta F)(B_t)")]]

#text("whenever ")#mi("{F: {\\bf R}^n \\rightarrow {\\bf R}}")#text(" is smooth with all derivatives bounded, where")

#align(center)[#tao-fit-display[#mitex("\\Delta F := \\sum_{i=1}^n \\frac{\\partial^2}{\\partial x_i^2} F")]]

#text("is the Laplacian of ")#mi("{F}")#text(". Conclude in particular that the density function ")#mi("{\\rho(t,x)\\ dx}")#text(" of ")#mi("{B_t}")#text(" obeys the (distributional) heat equation")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\rho = \\frac{1}{2} \\Delta \\rho.")]]
]

#text("A simple but fundamental observation is that ")#mi("{n}")#text("-dimensional Brownian motion is rotation-invariant: more precisely, if ")#mi("{(X_t)_{t \\in [0,+\\infty)}}")#text(" is an ")#mi("{n}")#text("-dimensional Wiener process with initial position ")#mi("{0}")#text(", and ")#mi("{U \\in O(n)}")#text(" is any orthogonal transformation on ")#mi("{{\\bf R}^n}")#text(", then ")#mi("{(UX_t)_{t \\in [0,+\\infty)}}")#text(" is another Wiener process with initial position ")#mi("{0}")#text(", and thus has the same distribution: ")#metadata(none) <tao-25c94e09cf2c7da8b639>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("(UX_t)_{t \\in [0,+\\infty)} \\equiv (X_t)_{t \\in [0,+\\infty)}.")]]

#text("This is ultimately because the ")#mi("{n}")#text("-dimensional normal distributions ")#mi("{N(0,\\sigma^2 I)_{{\\bf R}^n}}")#text(" are manifestly rotation-invariant (see Exercise 10 of ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 18")]#text(" One can also relate variable-coefficient heat equations to variable-coefficient Brownian motion ")#mi("{(X_t)_{t \\in [0,+\\infty)}}")#text(", in which the variance of an increment ")#mi("{dX_t}")#text(" is now only proportional to ")#mi("{dt}")#text(" for infinitesimal ")#mi("{dt}")#text(" rather than being equal to ")#mi("{dt}")#text(", with the constant of proportionality allowed to depend on the time ")#mi("{t}")#text(" and on the position ")#mi("{X_t}")#text(". One can also add drift terms by allowing the increment ")#mi("{dX_t}")#text(" to have a non-zero mean (which is also proportional to ")#mi("{dt}")#text("). This can be accomplished through the machinery of ")#link("http://en.wikipedia.org/wiki/Stochastic_calculus")[#text("stochastic calculus")]#text(", which we will not discuss in detail in these notes. In a similar fashion, one can construct Brownian motion (and heat equations) on manifolds or on domains with boundary, though we will not discuss this topic here.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Let ")#mi("{X_1}")#text(" be a real random variable of mean zero and variance ")#mi("{1}")#text(". Define a stochastic process ")#mi("{(X_t)_{t \\in [0,+\\infty)}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("X_t := e^{-t} ( X_1 + B_{e^{2t}-1} )")]]

#text("where ")#mi("{(B_t)_{t \\in [0,+\\infty)}}")#text(" is a Wiener process with initial position zero that is independent of ")#mi("{X_1}")#text(". This process is known as an ")#link("http://en.wikipedia.org/wiki/Ornstein%E2%80%93Uhlenbeck_process")[#text("Ornstein-Uhlenbeck process")]#text(".")

#list(
[#text("Show that each ")#mi("{X_t}")#text(" has mean zero and variance ")#mi("{1}")#text(".")],
[#text("Show that ")#mi("{X_t}")#text(" converges in distribution to ")#mi("{N(0,1)_{\\bf R}}")#text(" as ")#mi("{t \\rightarrow \\infty}")#text(".")],
[#text("If ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" is smooth with all derivatives bounded, show that")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} {\\bf E} F(X_t) = {\\bf E} LF(X_t)")]]

#text("where ")#mi("{L}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Ornstein%E2%80%93Uhlenbeck_operator")[#text("Ornstein-Uhlenbeck operator")]

#align(center)[#tao-fit-display[#mitex("LF := F_{xx} - x F_x.")]]

#text("Conclude that the density function ")#mi("{\\rho(t,x)}")#text(" of ")#mi("{X_t}")#text(" obeys (in a distributional sense, at least) the ")#emph[#text("Ornstein-Uhlenbeck equation")]

#align(center)[#tao-fit-display[#mitex("\\partial_t \\rho = L^* \\rho")]]

#text("where the adjoint operator ")#mi("{L^*}")#text(" is given by")

#align(center)[#tao-fit-display[#mitex("L^* \\rho := \\rho_{xx} + \\partial_x(x \\rho).")]]],
[#text("Show that the only probability density function ")#mi("{\\rho}")#text(" for which ")#mi("{L^*\\rho=0}")#text(" is the Gaussian ")#mi("{\\frac{1}{\\sqrt{2\\pi}} e^{-x^2/2}\\ dx}")#text("; furthermore, show that ")#mi("{\\text{Re} \\langle \\rho, L^* \\rho \\rangle_{L^2({\\bf R})} \\leq 0}")#text(" for all probability density functions ")#mi("{\\rho}")#text(" in the Schwartz space with mean zero and variance ")#mi("{1}")#text(". Discuss how this fact relates to the preceding two parts of this exercise.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 20")]#text(" The heat kernel ")#tao-math("{\\frac{1}{(\\sqrt{2\\pi t})^d} e^{-\\left|x-\\mu\\right|^2/2t}}", block: false)#text(" in ")#mi("{d}")#text(" dimensions is absolutely integrable in time away from the initial time ")#mi("{t=0}")#text(" for dimensions ")#mi("{d \\geq 3}")#text(", but becomes divergent in dimension ")#mi("{1}")#text(" and (just barely) divergent for ")#mi("{d=2}")#text(". This causes the qualitative behaviour of Brownian motion ")#mi("{B_t}")#text(" in ")#mi("{{\\bf R}^d}")#text(" to be rather different in the two regimes. For instance, in dimensions ")#mi("{d \\geq 3}")#text(" Brownian motion is ")#emph[#text("transient")]#text("; almost surely one has ")#mi("{B_t \\rightarrow \\infty}")#text(" as ")#mi("{t \\rightarrow \\infty}")#text(". But in dimension ")#mi("{d=1}")#text(" Brownian motion is ")#emph[#text("recurrent")]#text(": for each ")#mi("{x_0 \\in {\\bf R}}")#text(", one almost surely has ")#mi("{B_t=x_0}")#text(" for infinitely many ")#mi("{t}")#text(". In the critical dimension ")#mi("{d=2}")#text(", Brownian motion turns out to not be recurrent, but is instead ")#emph[#text("neighbourhood recurrent")]#text(": almost surely, ")#mi("{B_t}")#text(" revisits every neighbourhood of ")#mi("{x_0}")#text(" at arbitrarily large times, but does not visit ")#mi("{x_0}")#text(" itself for any positive time ")#mi("{t}")#text(". The study of Brownian motion and its relatives is in fact a huge and active area of study in modern probability theory, but will not be discussed in this course.")
]

#heading(level: 1)[#strong[#text(" — 4. Dyson Brownian motion — ")]]

#text("The space ")#mi("{V}")#text(" of ")#mi("{n \\times n}")#text(" Hermitian matrices can be viewed as a real vector space of dimension ")#mi("{n^2}")#text(" using the ")#emph[#text("Frobenius norm")]

#align(center)[#tao-fit-display[#mitex("A \\mapsto \\text{tr}(A^2)^{1/2} = \\sum_{i=1}^n a_{ii}^2 + 2 \\sum_{1 \\leq i < j \\leq n} \\text{Re}(a_{ij})^2 + \\text{Im}(a_{ij})^2")]]

#text("where ")#mi("{a_{ij}}")#text(" are the coefficients of ")#mi("{A}")#text(". One can then identify ")#mi("{V}")#text(" explicitly with ")#mi("{{\\bf R}^{n^2}}")#text(" via the identification")

#align(center)[#tao-fit-display[#mitex("(a_{ij})_{1 \\leq i,j \\leq n} \\equiv ( (a_{ii})_{i=1}^n, (\\sqrt{2} \\text{Re}(a_{ij}), \\sqrt{2} \\text{Im}(a_{ij}))_{1 \\leq i<j \\leq n} ).")]]

#text("Now that one has this identification, for each Hermitian matrix ")#mi("{A_0 \\in V}")#text(" (deterministic or stochastic) we can define a Wiener process ")#mi("{(A_t)_{t \\in [0,+\\infty)}}")#text(" on ")#mi("{V}")#text(" with initial position ")#mi("{A_0}")#text(". By construction, we see that ")#mi("{t \\mapsto A_t}")#text(" is almost surely continuous, and each increment ")#mi("{A_{t_+} - A_{t_-}}")#text(" is equal to ")#mi("{(t_+-t_-)^{1/2}}")#text(" times a matrix drawn from the ")#link("http://en.wikipedia.org/wiki/Gaussian_Unitary_Ensemble")[#text("gaussian unitary ensemble")]#text(" (GUE), with disjoint increments being jointly independent. In particular, the diagonal entries of ")#mi("{A_{t_+}-A_{t_-}}")#text(" have distribution ")#mi("{N(0,t_+-t_-)_{\\bf R}}")#text(", and the off-diagonal entries have distribution ")#mi("{N(0,t_+-t_-)_{\\bf C}}")#text(".")

#text("Given any Hermitian matrix ")#mi("{A}")#text(", one can form the ")#emph[#text("spectrum")]#text(" ")#mi("{(\\lambda_1(A),\\ldots,\\lambda_n(A))}")#text(", which lies in the ")#link("http://en.wikipedia.org/wiki/Weyl_group#Weyl_chambers")[#text("Weyl chamber")]#text(" ")#mi("{{\\bf R}^n_\\geq := \\{ (\\lambda_1,\\ldots,\\lambda_n) \\in {\\bf R}^n: \\lambda_1 \\geq \\ldots \\geq \\lambda_n \\}}")#text(". Taking the spectrum of the Wiener process ")#mi("{(A_t)_{t \\in [0,+\\infty)}}")#text(", we obtain a process")

#align(center)[#tao-fit-display[#mitex("(\\lambda_1(A_t),\\ldots,\\lambda_n(A_t))_{t \\in [0,+\\infty)}")]]

#text("in the Weyl cone. We abbreviate ")#mi("{\\lambda_i(A_t)}")#text(" as ")#mi("{\\lambda_i}")#text(".")

#text("For ")#mi("{t>0}")#text(", we see that ")#mi("{A_t}")#text(" is absolutely continuously distributed in ")#mi("{V}")#text(". In particular, since almost every Hermitian matrix has simple spectrum, we see that ")#mi("{A_t}")#text(" has almost surely simple spectrum for ")#mi("{t>0}")#text(". (The same is true for ")#mi("{t=0}")#text(" if we assume that ")#mi("{A_0}")#text(" also has an absolutely continuous distribution.)")

#text("The stochastic dynamics of this evolution can be described by ")#link("http://www.ams.org/mathscinet-getitem?mr=148397")[#text("Dyson Brownian motion")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 21 (Dyson Brownian motion)")]#text(" Let ")#mi("{t > 0}")#text(", and let ")#mi("{dt > 0}")#text(", and let ")#mi("{\\lambda_1,\\ldots,\\lambda_n}")#text(" be as above. Then we have ")#metadata(none) <tao-2ca69efd4ea5af91a637>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("d\\lambda_i = dB_i + \\sum_{1 \\leq j \\leq n: j \\neq i} \\frac{dt}{\\lambda_i - \\lambda_j} + \\ldots")]]

#text("for all ")#mi("{1 \\leq i \\leq n}")#text(", where ")#mi("{d\\lambda_i := \\lambda_i(A_{t+dt}) - \\lambda_i(A_t)}")#text(", and ")#mi("{dB_1,\\ldots,dB_n}")#text(" are iid copies of ")#mi("{N(0,dt)_{\\bf R}}")#text(" which are jointly independent of ")#mi("{(A_{t^{\\prime}})_{t^{\\prime} \\in [0,t]}}")#text(", and the error term ")#mi("{\\ldots}")#text(" is the sum of two terms, one of which has ")#mi("{L^1}")#text(" norm ")#mi("{o(dt)}")#text(", and the other has mean zero and second moment ")#mi("{O(dt)}")#text(" in the limit ")#mi("{dt \\rightarrow 0}")#text(" (holding ")#mi("{t}")#text(" and ")#mi("{n}")#text(" fixed).")
]

#text("Using the language of Ito calculus, one usually views ")#mi("{dt}")#text(" as infinitesimal and drops the ")#mi("{\\ldots}")#text(" error, thus giving the elegant formula")

#align(center)[#tao-fit-display[#mitex("d\\lambda_i = dB_i + \\sum_{1 \\leq j \\leq n: j \\neq i} \\frac{dt}{\\lambda_i - \\lambda_j}")]]

#text("that shows that the eigenvalues ")#mi("{\\lambda_i}")#text(" evolve by Brownian motion, combined with a deterministic ")#emph[#text("repulsion")]#text(" force that repels nearby eigenvalues from each other with a strength inversely proportional to the separation. One can extend the theorem to the ")#mi("{t=0}")#text(" case by a limiting argument provided that ")#mi("{A_0}")#text(" has an absolutely continuous distribution. Note that the decay rate of the error ")#mi("{\\ldots}")#text(" can depend on ")#mi("{n}")#text(", so it is not safe to let ")#mi("{n}")#text(" go off to infinity while holding ")#mi("{dt}")#text(" fixed. However, it is safe to let ")#mi("{dt}")#text(" go to zero ")#emph[#text("first")]#text(", and ")#emph[#text("then")]#text(" send ")#mi("{n}")#text(" off to infinity. (It is also possible, by being more explicit with the error terms, to work with ")#mi("{dt}")#text(" being a specific negative power of ")#mi("{n}")#text(". We will see this sort of analysis later in this course.)")

#emph[#text("Proof:")]#text(" Fix ")#mi("{t}")#text(". We can write ")#mi("{A_{t+dt} = A_t + (dt)^{1/2} G}")#text(", where ")#mi("{G}")#text(" is independent of ")#mi("{A_t}")#text(" and has the GUE distribution. (Strictly speaking, ")#mi("{G}")#text(" depends on ")#mi("{dt}")#text(", but this dependence will not concern us.) We now condition ")#mi("{A_t}")#text(" to be fixed, and establish ")#link(<tao-2ca69efd4ea5af91a637>)[#text("(5)")]#text(" for almost every fixed choice of ")#mi("{A_t}")#text("; the general claim then follows upon undoing the conditioning (and applying the dominated convergence theorem). Due to independence, observe that ")#mi("{G}")#text(" continues to have the GUE distribution even after conditioning ")#mi("{A_t}")#text(" to be fixed.")

#text("Almost surely, ")#mi("{A_t}")#text(" has simple spectrum; so we may assume that the fixed choice of ")#mi("{A_t}")#text(" has simple spectrum also. Actually, we can say more: since the Wiener random matrix ")#mi("{A_t}")#text(" has a smooth distribution in the space ")#mi("{V}")#text(" of Hermitian matrices, while the space ")#mi("{S}")#text(" of matrices in ")#mi("{V}")#text(" with non-simple spectrum has codimension ")#mi("{3}")#text(" by Exercise 10 of ")#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/")[#text("Notes 3a")]#text(", we see that for any ")#mi("{\\delta>0}")#text(" the probability that ")#mi("{A_t}")#text(" lies within ")#mi("{\\delta}")#text(" of ")#mi("{S}")#text(" is ")#mi("{O(\\delta^3)}")#text(", where we allow implied constants to depend on ")#mi("{n}")#text(". In particular, if we let ")#tao-math("{\\Delta := \\min_{i \\neq j} \\left|\\lambda_i - \\lambda_j\\right|}", block: false)#text(" denote the minimal eigenvalue gap, we have")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf P}( \\Delta \\leq \\delta ) = O(\\delta^3)")]]

#text("which by dyadic decomposition implies the finite negative second moment ")#metadata(none) <tao-0c1c541af9cc252a1c75>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\mathop{\\bf E} \\Delta^{-2} = O(1).")]]

#text("Let ")#mi("{\\nabla_G \\lambda_i}")#text(" denote the derivative of the eigenvalue ")#mi("{\\lambda_i(A_t)}")#text(" in the ")#mi("{G}")#text(" direction. From the first and second Hadamard variation formulae (see Section 4 of ")#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/")[#text("Notes 3a")]#text(") we have")

#align(center)[#tao-fit-display[#tao-math("\\nabla_G \\lambda_i = u_i^* G u_i = O( \\left\\|G\\right\\| )", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\nabla^2_G \\lambda_i = 2 \\sum_{i \\neq j} \\frac{\\left|u_j^* G u_i\\right|^2}{\\lambda_i - \\lambda_j} = O( \\left\\|G\\right\\|^2 \\Delta^{-1} )", block: true)]]

#text("where ")#mi("{u_1,\\ldots,u_n}")#text(" are an orthonormal eigenbasis for ")#mi("{A_t}")#text(", and also ")#tao-math("{\\nabla_G u_i = O( \\left\\|G\\right\\| \\Delta^{-1})}", block: false)#text(". A further differentiation then yields")

#align(center)[#tao-fit-display[#tao-math("\\nabla^3_G \\lambda_i = O( \\left\\|G\\right\\|^3 \\Delta^{-2} ).", block: true)]]

#text("(One can obtain a more exact third Hadamard variation formula if desired, but it is messy and will not be needed here.) A Taylor expansion now gives the bound ")#metadata(none) <tao-8e924025a26c584ad4ac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\lambda_i(A_{t+dt}) = \\lambda_i + (dt)^{1/2} \\nabla_G \\lambda_i + \\frac{1}{2} dt \\nabla_G^2 \\lambda_i + O( (dt)^{3/2} \\left\\|G\\right\\|^3 \\Delta^{-2} )", block: true)]]

#text("provided that one is in the regime")

#align(center)[#tao-fit-display[#tao-math("dt^{1/2} \\left\\|G\\right\\| \\leq \\frac{1}{2} \\Delta", block: true)]]

#text("(in order to keep the eigenvalue gap at least ")#mi("{\\Delta/2}")#text(" as one travels from ")#mi("{A_t}")#text(" to ")#mi("{A_{t+dt} = A_t + dt^{1/2} G}")#text("). In the opposite regime")

#align(center)[#tao-fit-display[#tao-math("dt^{1/2} \\left\\|G\\right\\| > \\frac{1}{2} \\Delta", block: true)]]

#text("we can instead use the Weyl inequalities to bound ")#tao-math("{\\lambda_i(A_{t+dt}) = \\lambda_i(A_t) + O( dt^{1/2} \\left\\|G\\right\\| ) = \\lambda_i(A_t) + O( (dt)^{3/2} \\left\\|G\\right\\|^3 \\Delta^{-2} )}", block: false)#text("; the other two terms ")#mi("{(dt)^{1/2} \\nabla_G \\lambda_i, \\frac{1}{2} dt \\nabla_G^2 \\lambda_i}")#text(" in the Taylor expansion are also ")#tao-math("{O( (dt)^{3/2} \\left\\|G\\right\\|^3 \\Delta^{-2} )}", block: false)#text(" in this case. Thus ")#link(<tao-8e924025a26c584ad4ac>)[#text("(7)")]#text(" holds in all cases.")

#text("Now we take advantage of the unitary invariance of the Gaussian unitary ensemble (that is, that ")#mi("{UGU^* \\equiv G}")#text(" for all unitary matrices ")#mi("{G}")#text("; this is easiest to see by noting that the probability density function of ")#mi("{G}")#text(" is proportional to ")#tao-math("{\\exp( - \\left\\|G\\right\\|_F^2 / 2 )}", block: false)#text("). From this invariance, we can assume without loss of generality that ")#mi("{u_1,\\ldots,u_n}")#text(" is the standard orthonormal basis of ")#mi("{{\\bf C}^n}")#text(", so that we now have")

#align(center)[#tao-fit-display[#tao-math("d\\lambda_i = (dt)^{1/2} \\xi_{ii} + dt \\sum_{i \\neq j} \\frac{\\left|\\xi_{ij}\\right|^2}{\\lambda_i - \\lambda_j} + O( (dt)^{3/2} \\left\\|G\\right\\|^3 \\Delta^{-2} )", block: true)]]

#text("where ")#mi("{\\xi_{ij}}")#text(" are the coefficients of ")#mi("{G}")#text(". But the ")#mi("{\\xi_{ii}}")#text(" are iid copies of ")#mi("{N(0,1)_{\\bf R}}")#text(", so we will be done as soon as we show that the terms")

#align(center)[#tao-fit-display[#tao-math("dt \\sum_{i \\neq j} \\frac{\\left|\\xi_{ij}\\right|^2-1}{\\lambda_i - \\lambda_j} + O( (dt)^{3/2} \\left\\|G\\right\\|^3 \\Delta^{-2} )", block: true)]]

#text("are acceptable error terms. But the first term has mean zero and is bounded by ")#mi("{O( dt \\Delta^{-1})}")#text(" and thus has second moment ")#mi("{O(dt^2)}")#text(" by ")#link(<tao-0c1c541af9cc252a1c75>)[#text("(6)")]#text(", while the second term has ")#mi("{L^1}")#text(" norm of ")#mi("{O((dt)^{3/2}) = o(dt)}")#text(", again by ")#link(<tao-0c1c541af9cc252a1c75>)[#text("(6)")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 22")]#text(" Interestingly, one can interpret Dyson Brownian motion in a different way, namely as the motion of ")#mi("{n}")#text(" independent Wiener processes ")#mi("{\\lambda_i(t)}")#text(" ")#emph[#text("after")]#text(" one conditions the ")#mi("{\\lambda_i}")#text(" to be non-intersecting for all time; see ")#link("http://www.ams.org/mathscinet-getitem?mr=1678525")[#text("this paper of Grabiner")]#text(". It is intuitively reasonable that this conditioning would cause a repulsion effect, though I do not know of a simple heuristic reason why this conditioning should end up giving the specific repulsion force present in ")#link(<tao-2ca69efd4ea5af91a637>)[#text("(5)")]#text(".")
]

#text("In the previous section, we saw how a Wiener process led to a PDE (the heat flow equation) that could be used to derive the probability density function for each component ")#mi("{X_t}")#text(" of that process. We can do the same thing here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" ")#metadata(none) <tao-bd9b8d8e9aa8e2aa24c0>#text(" Let ")#mi("{\\lambda_1,\\ldots,\\lambda_n}")#text(" be as above. Let ")#mi("{F: {\\bf R}^n \\rightarrow {\\bf R}}")#text(" be a smooth function with bounded derivatives. Show that for any ")#mi("{t \\geq 0}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\partial_t {\\bf E} F(\\lambda_1,\\ldots,\\lambda_n) = {\\bf E} D^* F(\\lambda_1,\\ldots,\\lambda_n)")]]

#text("where ")#mi("{D^*}")#text(" is the ")#emph[#text("adjoint Dyson operator")]

#align(center)[#tao-fit-display[#mitex("D^* F := \\frac{1}{2} \\sum_{i=1}^n \\partial_{\\lambda_i}^2 F + \\sum_{1 \\leq i,j \\leq n: i \\neq j} \\frac{ \\partial_{\\lambda_i} F }{\\lambda_i - \\lambda_j }.")]]

#text("If we let ")#mi("{\\rho: [0,+\\infty) \\times {\\bf R}^n_{\\geq} \\rightarrow {\\bf R}}")#text(" denote the density function ")#mi("{\\rho(t,\\cdot): {\\bf R}^n_{\\geq} \\rightarrow {\\bf R}}")#text(" of ")#mi("{(\\lambda_1(t),\\ldots,\\lambda_n(t))}")#text(" at time ")#mi("{t \\in [0,+\\infty)}")#text(", deduce the ")#emph[#text("Dyson partial differential equation")]#text(" ")#metadata(none) <tao-e2bd9c6236a519d406d1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\partial_t \\rho = D \\rho")]]

#text("(in the sense of distributions, at least, and on the interior of ")#mi("{{\\bf R}^n_\\geq}")#text("), where ")#mi("{D}")#text(" is the ")#emph[#text("Dyson operator")]#text(" ")#metadata(none) <tao-4dbf3df20c151fc88cda>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("D \\rho := \\frac{1}{2} \\sum_{i=1}^n \\partial_{\\lambda_i}^2 \\rho - \\sum_{1 \\leq i,j \\leq n: i \\neq j} \\partial_{\\lambda_i} ( \\frac{\\rho}{\\lambda_i - \\lambda_j} ).")]]
]

#text("The Dyson partial differential equation ")#link(<tao-e2bd9c6236a519d406d1>)[#text("(8)")]#text(" looks a bit complicated, but it can be simplified (formally, at least) by introducing the ")#link("http://en.wikipedia.org/wiki/Vandermonde_matrix")[#text("Vandermonde determinant")]#text(" ")#metadata(none) <tao-09513ba78b1c2cbeae78>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\Delta_n(\\lambda_1,\\ldots,\\lambda_n) := \\prod_{1 \\leq i < j \\leq n} (\\lambda_i - \\lambda_j).")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" ")#metadata(none) <tao-66dfa657fdae9f5a58a3>#text(" Show that ")#link(<tao-09513ba78b1c2cbeae78>)[#text("(10)")]#text(" is the determinant of the matrix ")#mi("{(\\lambda_i^{j-1})_{1 \\leq i,j \\leq n}}")#text(", and is also the sum ")#mi("{\\sum_{\\sigma \\in S_n} \\text{sgn}(\\sigma) \\prod_{i=1}^n \\lambda_{\\sigma(i)}^{i-1}}")#text(".")
]

#text("Note that this determinant is non-zero on the interior of the Weyl chamber ")#mi("{{\\bf R}^n_\\geq}")#text(". The significance of this determinant for us lies in the identity ")#metadata(none) <tao-a1d699c01ca0a4cc70b2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\partial_{\\lambda_i} \\Delta_n = \\sum_{1 \\leq j \\leq n: i \\neq j} \\frac{\\Delta_n}{\\lambda_i - \\lambda_j}")]]

#text("which can be used to cancel off the second term in ")#link(<tao-4dbf3df20c151fc88cda>)[#text("(9)")]#text(". Indeed, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" ")#metadata(none) <tao-128df13c1e54ffaaafcc>#text(" Let ")#mi("{\\rho}")#text(" be a smooth solution to ")#link(<tao-e2bd9c6236a519d406d1>)[#text("(8)")]#text(" in the interior of ")#mi("{{\\bf R}^n_\\geq}")#text(", and write ")#metadata(none) <tao-41a093100bbbb59e31dc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\rho = \\Delta_n u")]]

#text("in this interior. Show that ")#mi("{u}")#text(" obeys the linear heat equation")

#align(center)[#tao-fit-display[#mitex("\\partial_t u = \\frac{1}{2} \\sum_{i=1}^n \\partial_{\\lambda_i}^2 u")]]

#text("in the interior of ")#mi("{{\\bf R}^n_\\geq}")#text(". (")#emph[#text("Hint:")]#text(" You may need to exploit the identity ")#mi("{\\frac{1}{(a-b)(a-c)} + \\frac{1}{(b-a)(b-c)} + \\frac{1}{(c-a)(c-b)} = 0}")#text(" for distinct ")#mi("{a,b,c}")#text(". Equivalently, you may need to first establish that the Vandermonde determinant is a harmonic function.)")
]

#text("Let ")#mi("{\\rho}")#text(" be the density function of the ")#mi("{(\\lambda_1,\\ldots,\\lambda_n)}")#text(", as in ")#link(<tao-bd9b8d8e9aa8e2aa24c0>)[#text("(23)")]#text(". As previously remarked, the Wiener random matrix ")#mi("{A_t}")#text(" has a smooth distribution in the space ")#mi("{V}")#text(" of Hermitian matrices, while the space of matrices in ")#mi("{V}")#text(" with non-simple spectrum has codimension ")#mi("{3}")#text(" by Exercise 10 of ")#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/")[#text("Notes 3a")]#text(". On the other hand, the non-simple spectrum only has codimension ")#mi("{1}")#text(" in the Weyl chamber (being the boundary of this cone). Because of this, we see that ")#mi("{\\rho}")#text(" vanishes to at least second order on the boundary of this cone (with correspondingly higher vanishing on higher codimension facets of this boundary). Thus, the function ")#mi("{u}")#text(" in Exercise ")#link(<tao-128df13c1e54ffaaafcc>)[#text("25")]#text(" vanishes to first order on this boundary (again with correspondingly higher vanishing on higher codimension facets). Thus, if we extend ")#mi("{\\rho}")#text(" symmetrically across the cone to all of ")#mi("{{\\bf R}^n}")#text(", and extend the function ")#mi("{u}")#text(" antisymmetrically, then the equation ")#link(<tao-e2bd9c6236a519d406d1>)[#text("(8)")]#text(" and the factorisation ")#link(<tao-41a093100bbbb59e31dc>)[#text("(12)")]#text(" extend (in the distributional sense) to all of ")#mi("{{\\bf R}^n}")#text(". Extending ")#link(<tao-128df13c1e54ffaaafcc>)[#text("(25)")]#text(" to this domain (and being somewhat careful with various issues involving distributions), we now see that ")#mi("{u}")#text(" obeys the linear heat equation on all of ")#mi("{{\\bf R}^n}")#text(".")

#text("Now suppose that the initial matrix ")#mi("{A_0}")#text(" had a deterministic spectrum ")#mi("{\\nu = (\\nu_1,\\ldots,\\nu_n)}")#text(", which to avoid technicalities we will assume to be in the interior of the Weyl chamber (the boundary case then being obtainable by a limiting argument). Then ")#mi("{\\rho}")#text(" is initially the Dirac delta function at ")#mi("{\\nu}")#text(", extended symmetrically. Hence, ")#mi("{u}")#text(" is initially ")#mi("{\\frac{1}{\\Delta_n(\\nu)}}")#text(" times the Dirac delta function at ")#mi("{\\nu}")#text(", extended antisymmetrically:")

#align(center)[#tao-fit-display[#mitex("u(0,\\lambda) = \\frac{1}{\\Delta_n(\\nu)} \\sum_{\\sigma \\in S_n} \\text{sgn}(\\sigma) \\delta_{\\lambda - \\sigma(\\nu)}.")]]

#text("Using the fundamental solution for the heat equation in ")#mi("{n}")#text(" dimensions, we conclude that")

#align(center)[#tao-fit-display[#tao-math("u(t,\\lambda) = \\frac{1}{(2\\pi t)^{n/2}} \\sum_{\\sigma \\in S_n} \\text{sgn}(\\sigma) e^{-\\left|\\lambda - \\sigma(\\nu)\\right|^2/2t}.", block: true)]]

#text("By the ")#link("http://en.wikipedia.org/wiki/Leibniz_formula_for_determinants")[#text("Leibniz formula for determinants")]#text(", we can express the sum here as a determinant of the matrix")

#align(center)[#tao-fit-display[#mitex("(e^{-(\\lambda_i - \\nu_j)^2 / 2t})_{1 \\leq i,j \\leq n}.")]]

#text("Applying ")#link(<tao-41a093100bbbb59e31dc>)[#text("(12)")]#text(", we conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 26 (Johansson formula)")]#text(" Let ")#mi("{A_0}")#text(" be a Hermitian matrix with simple spectrum ")#mi("{\\nu = (\\nu_1,\\ldots,\\nu_n)}")#text(", let ")#mi("{t > 0}")#text(", and let ")#mi("{A_t = A_0 + t^{1/2} G}")#text(" where ")#mi("{G}")#text(" is drawn from GUE. Then the spectrum ")#mi("{\\lambda = (\\lambda_1,\\ldots,\\lambda_n)}")#text(" of ")#mi("{A_t}")#text(" has probability density function ")#metadata(none) <tao-486f788305969a3d1684>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\rho(t,\\lambda) = \\frac{1}{(2\\pi t)^{n/2}} \\frac{\\Delta_n(\\lambda)}{\\Delta_n(\\nu)} \\det(e^{-(\\lambda_i - \\nu_j)^2 / 2t})_{1 \\leq i,j \\leq n}")]]

#text("on ")#mi("{{\\bf R}^n_\\geq}")#text(".")
]

#text("This formula is given explicitly in ")#link("http://www.ams.org/mathscinet-getitem?mr=1810949")[#text("this paper of Johansson")]#text(", who cites ")#link("http://www.ams.org/mathscinet-getitem?mr=1418841")[#text("this paper of Brézin and Hikami")]#text(" as inspiration. This formula can also be proven by a variety of other means, for instance via the ")#link("http://en.wikipedia.org/wiki/Plancherel_theorem_for_spherical_functions")[#text("Harish-Chandra formula")]#text(". (One can also check by hand that ")#link(<tao-486f788305969a3d1684>)[#text("(13)")]#text(" satisfies the Dyson equation ")#link(<tao-e2bd9c6236a519d406d1>)[#text("(8)")]#text(".)")

#text("We will be particularly interested in the case when ")#mi("{A_0=0}")#text(" and ")#mi("{t=1}")#text(", so that we are studying the probability density function of the eigenvalues ")#mi("{(\\lambda_1(G),\\ldots,\\lambda_n(G))}")#text(" of a GUE matrix ")#mi("{G}")#text(". The Johansson formula does not directly apply here, because ")#mi("{\\nu}")#text(" is vanishing. However, we can investigate the limit of ")#link(<tao-486f788305969a3d1684>)[#text("(13)")]#text(" in the limit as ")#mi("{\\nu \\rightarrow 0}")#text(" inside the Weyl chamber; the Lipschitz nature of the eigenvalue operations ")#mi("{A \\mapsto \\lambda_i(A)}")#text(" (from the Weyl inequalities) tell us that if ")#link(<tao-486f788305969a3d1684>)[#text("(13)")]#text(" converges locally uniformly as ")#mi("{\\nu \\rightarrow 0}")#text(" for ")#mi("{\\lambda}")#text(" in the interior of ")#mi("{{\\bf R}^n_\\geq}")#text(", then the limit will indeed be the probability density function for ")#mi("{\\nu=0}")#text(". (Note from continuity that the density function cannot assign any mass to the boundary of the Weyl chamber, and in fact must vanish to at least second order by the previous discussion.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" Show that as ")#mi("{\\nu \\rightarrow 0}")#text(", we have the identities")

#align(center)[#tao-fit-display[#tao-math("\\det(e^{-(\\lambda_i - \\nu_j)^2 / 2})_{1 \\leq i,j \\leq n} = e^{-\\left|\\lambda\\right|^2/2} e^{-\\left|\\nu\\right|^2/2} \\det(e^{\\lambda_i \\nu_j})_{1 \\leq i,j \\leq n}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\det(e^{\\lambda_i \\nu_j})_{1 \\leq i,j \\leq n} = \\frac{1}{1! \\ldots (n-1)!} \\Delta_n(\\lambda) \\Delta_n(\\nu) + o( \\Delta_n(\\nu) )")]]

#text("locally uniformly in ")#mi("{\\lambda}")#text(". (")#emph[#text("Hint:")]#text(" for the second identity, use Taylor expansion and the Leibniz formula for determinants, noting the left-hand side vanishes whenever ")#mi("{\\Delta_n(\\nu)}")#text(" vanishes and so can be treated by the (smooth) factor theorem.)")
]

#text("From the above exercise, we conclude the fundamental ")#link("http://www.ams.org/mathscinet-getitem?mr=173726")[#text("Ginibre formula")]#text(" ")#metadata(none) <tao-01254bb6cb3b4ecf62ce>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\rho(\\lambda) = \\frac{1}{(2\\pi)^{n/2} 1! \\ldots (n-1)!} e^{-\\left|\\lambda\\right|^2/2} \\left|\\Delta_n(\\lambda)\\right|^2", block: true)]]

#text("for the density function for the spectrum ")#mi("{(\\lambda_1(G),\\ldots,\\lambda_n(G))}")#text(" of a GUE matrix ")#mi("{G}")#text(".")

#text("This formula can be derived by a variety of other means; we sketch one such way below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" For this exercise, assume that it is known that ")#link(<tao-01254bb6cb3b4ecf62ce>)[#text("(14)")]#text(" is indeed a probability distribution on the Weyl chamber ")#mi("{{\\bf R}^n_\\geq}")#text(" (if not, one would have to replace the constant ")#mi("{(2\\pi)^{n/2}}")#text(" by an unspecified normalisation factor depending only on ")#mi("{n}")#text("). Let ")#mi("{D = \\text{diag}( \\lambda_1, \\ldots, \\lambda_n )}")#text(" be drawn at random using the distribution ")#link(<tao-01254bb6cb3b4ecf62ce>)[#text("(14)")]#text(", and let ")#mi("{U}")#text(" be drawn at random from Haar measure on ")#mi("{U(n)}")#text(". Show that the probability density function of ")#mi("{UDU^*}")#text(" at a matrix ")#mi("{A}")#text(" with simple spectrum is equal to ")#tao-math("{c_n e^{-\\left\\|A\\right\\|_F^2/2}}", block: false)#text(" for some constant ")#mi("{c_n>0}")#text(". (")#emph[#text("Hint")]#text(": use unitary invariance to reduce to the case when ")#mi("{A}")#text(" is diagonal. Now take a small ")#mi("{\\varepsilon}")#text(" and consider what ")#mi("{U}")#text(" and ")#mi("{D}")#text(" must be in order for ")#mi("{UDU^*}")#text(" to lie within ")#mi("{\\varepsilon}")#text(" of ")#mi("{A}")#text(" in the Frobenius norm, performing first order calculations only (i.e. linearising and ignoring all terms of order ")#mi("{o(\\varepsilon)}")#text(").)")

#text("Conclude that ")#link(<tao-01254bb6cb3b4ecf62ce>)[#text("(14)")]#text(" must be the probability density function of the spectrum of a GUE matrix.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" Verify by hand that the self-similar extension")

#align(center)[#tao-fit-display[#mitex("\\rho(t,x) := t^{-n/2} \\rho(x/\\sqrt{t})")]]

#text("of the function ")#link(<tao-01254bb6cb3b4ecf62ce>)[#text("(14)")]#text(" obeys the Dyson PDE ")#link(<tao-e2bd9c6236a519d406d1>)[#text("(8)")]#text(". Why is this consistent with ")#link(<tao-01254bb6cb3b4ecf62ce>)[#text("(14)")]#text(" being the density function for the spectrum of GUE?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 30")]#text(" Similar explicit formulae exist for other invariant ensembles, such as the ")#emph[#text("gaussian orthogonal ensemble")]#text(" GOE and the ")#emph[#text("gaussian symplectic ensemble")]#text(" GSE. One can also replace the exponent in density functions such as ")#tao-math("{e^{-\\left\\|A\\right\\|_F^2/2}}", block: false)#text(" with more general expressions than quadratic expressions of ")#mi("{A}")#text(". We will however not detail these formulae in this course (with the exception of the spectral distribution law for random iid gaussian matrices, which we will discuss in a later set of notes).")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (56)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f24a97b13a38989afb1d97d4058775a34d5ebb4f4b680491fba9f0daaaf6cc1-8c4202cd59223e301f43977249a21d6879dc14e7056d91c2d65f2fb9d5309f6f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Batson")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43275")[#strong[#text("Joshua Batson")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2010")])]

#text("I think last display in the proof of prop. 3 should be ")#mi("\\leq")#text(" not ")#mi("\\geq")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43277")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2010")])]

#text("Wonderful post. Everything looks different in your hands.")#linebreak()#text(" Thank you Prof. Tao.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af45d79e5b098ceb6de38fde366406c35900957c8d6b7df4dd04d7299dee2e9f-577326d8a604a42aebab67c6282a15db482f82e7fc3459676170911250f1955e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim vB")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43290")[#strong[#text("Tim vB")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2010")])]

#text("Dear Terry,")

#text("marvelous lecture notes, thanks for making them public!")

#text("On a side note I would like to mention that it can be fun to code a discretization scheme for stochastic differential equations aka a simulation of a stochastic process, in order to solve the associated partial differential equation. It’s one thing to prove that it can be done, but it can be fun too to look at some specific examples and compare the results of the simulation with numerical or analytical results that you get from the partial differential equation.")#linebreak()#text(" That’s off topic with regard to your class of course, but maybe some of your students would like to takle that in their spare time, if they have any :-)")#linebreak()#text(" (I think that is still an active research topic, used e.g. for PDE with complicated domains/boundaries and boundary conditions, but I’ve been out of the field for years).")#linebreak()#text(" BTW: Do you use computer simulations in the class?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43292")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2010")])]

#text("Possible typo: In the paragraph beginning “Now we establish a Hölder continuity property. Let theta be any exponent between 0 and 2”, I think that 2 should be 1/2.")

#text("These are great notes; I am starting to understand what a random walk is.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43296")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2010")])]

#text("There are eleven “Formula does not parse” errors. I’m using Firefox 3.5.7. The first one is in the def of Wiener Process:")

#text("A (one-dimensional) Wiener process on {\\Sigma} with initial position {\\mu} is a collection {(X_t)_{t \\in \\Sigma}} of real random …")

#text("Here, {(X_t)_{t \\in \\Sigma}} does not parse.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43300")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2010")])]

#text("I also get eleven “Formula does not parse” errors, using Firefox 3.5.7.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af45d79e5b098ceb6de38fde366406c35900957c8d6b7df4dd04d7299dee2e9f-577326d8a604a42aebab67c6282a15db482f82e7fc3459676170911250f1955e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim vB")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43304")[#strong[#text("Tim vB")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2010")])]

#text("That does not seem to be a problem of the browser, I’m using Firefox 3.5.7 as well and all formulas are rendered without any problems, but I see them as embedded png graphics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43314")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2010")])]

#text("A few hours ago I also got the same errors but now all formulas are OK. (I’m using IE).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/79a190795d80e8c530d4a698e6be06bac867e32eed945b944b9cc603f8f83754-717d77f039a97e939bab0746ac8ac93e3d6f29dd80ba56d28d6bf76de4a9939f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of solrize")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43370")[#strong[#text("solrize")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2010")])]

#text("This post and and the post of a few days ago reviewing probability theory are great. It’s important material that I’ve been wanting to understand for quite a while. I’ve looked at some elementary books that were muddled and left out all the interesting stuff, and I’ve looked at some more advanced books that had way too much assumed background for me (ex-undergrad math major) to understand. These posts of yours are at a level that I think I can make my way through if I work at it, and which appear to demystify the subject. That’s hard to find. Thanks!!!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43404")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2010")])]

#text("Hi Terrence,")

#text("I have found a discussion of the LOUIS BACHELIER 1900 thesis “THEORIE DE LA SPECULATION” with Brownian motion applied to the stock market [Mathematical Finance, Vol.10, No.3 (July 2000), 341–353].")

#text("The appendix of this paper includes the faculty report by Appell, Poincare, J. Boussinesq.")#linebreak()#text(" This report is somewhat critical of the institution used, but praises the originality of this type of probability theory [p 349]:")

#text("“The manner in which M. Bachelier deduces Gauss’s law is very original, and all the more interesting in that his reasoning can be extended with a few changes to the theory of errors. … In fact, the author makes a comparison with the analytic theory of heat flow. A bit of thought shows that the analogy is real and the comparison is legitimate. The reasoning of Fourier, almost without change, is applicable to this problem so different from the one for which it was originally created. It is regrettable that M. Bachelier did not develop this part of his thesis further. He could have entered into the details of Fourier’s analysis. He did, however, say enough about it to justify Gauss’s law and to foresee cases where it would no longer hold.")#linebreak()#text(" Once Gauss’s law is established, one can easily deduce certain consequences susceptible to experimental verification. Such an example is the relation between the value of an option and the deviation from the underlying. One should not expect a very exact verification. The principle of the mathematical expectation holds in the sense that, if it were violated, there would always be people who would act so as to re-establish it and they would eventually notice this. But they would only notice it if the deviations were considerable. The verification, then, can only be gross. The author of the thesis gives statistics where this happens in a very satisfactory manner.")#linebreak()#text(" …")#linebreak()#text(" In summary, we are of the opinion that there is reason to authorize M. Bachelier tohave his thesis printed and to submit it.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43454")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2010")])]

#text("Dear Prof. Tao, there seem to be two typos")#linebreak()#text(" between Exercise 4 and Remark 8: “dmiensional”, “ebcause”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 4: The semi-circular law « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43463")[#strong[#text("254A, Notes 4: The semi-circular law « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2010")])]

#text("[…] transform method, together with a third (heuristic) method based on Dyson Brownian motion (Notes 3b). In the next set of notes we shall also study the free probability method, and in the set of notes […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0d49273a6902d73f656aaf6252e01edfa69c067c009c75f7c3231020e000cf5-7063c982cd9f41e7454975c7905a8c3429dd93f63516b4fb265f355332515577.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43663")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2010")])]

#text("Hi Terry,")#linebreak()#text(" I think there’s a link problem. These notes, Notes 3b: Brownian motion and Dyson Brownian motion seem to be the the same as the notes on eigenvalues, Notes 3b (and don’t mention Dyson’s BM at all). I was able to access the notes yesterday but not today. I’m not sure if this problem is specific to me.")

#emph[#text("[Whoops, this was caused by a bad edit on my part. Corrected, thanks. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74fe8f5f5ef12162b549053442a59d012066bdf44e6c6ab5d3e4dbad268dd523-310f779dc12b3450006b3529c103f2fd0f223a88176de7b69a129ae0bc30e7da.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mio")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43705")[#strong[#text("Mio")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2010")])]

#text("In fractal construction, in order for ")#mi("X_{t+1/2}")#text(" to have variance ")#mi("t+1/2")#text(", shouldn’t ")#mi("Y_{t,0}")#text(" have variance 1/2 and not 1/4 (same for ")#mi("Y_{t,1}")#text(" below, 1/4 instead of 1/8)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43706")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2010")])]

#text("Well, ")#mi("(X_t+X_{t+1})/2 = X_t + (X_{t+1}-X_t)/2")#text(" already has a variance of ")#mi("t+1/4")#text(", so one only needs an additional variance of ")#mi("1/4")#text(" from ")#mi("Y_t")#text(" to balance it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74fe8f5f5ef12162b549053442a59d012066bdf44e6c6ab5d3e4dbad268dd523-310f779dc12b3450006b3529c103f2fd0f223a88176de7b69a129ae0bc30e7da.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mio")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43707")[#strong[#text("Mio")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2010")])]

#text("Oops, sorry. Thanks for a great lecture.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0d49273a6902d73f656aaf6252e01edfa69c067c009c75f7c3231020e000cf5-7063c982cd9f41e7454975c7905a8c3429dd93f63516b4fb265f355332515577.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43708")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2010")])]

#mi("\\sigma \\cdot N(0,1) = N(0, \\sigma^2)")#text(". So eg ")#mi("X_{t+1} -  X_{t+\\frac{1}{2}}")#text(" has the right distribution.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ad769094b23d44fe9bd0580a4f7fcf3c3fd4ac76d5b4510b7fc1e44795baa7d-cffd096f5ab07b6a2bbcd5369cacbfe33b7de9984f5fd20d2b32db31b972e937.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Bloemendal")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43715")[#strong[#text("Alex Bloemendal")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2010")])]

#text("Great lecture. The proof of the Ginibre formula ")#link(<tao-01254bb6cb3b4ecf62ce>)[#text("(12)")]#text(" for the eigenvalue density of a GUE matrix given in ")#link("http://www.ams.org/mathscinet-getitem?mr=173726")[#text("Dyson’s original paper")]#text(" is perhaps even simpler than the one you present. Dyson adds the Ornstein-Uhlenbeck restoring term to the matrix entry processes, which just adds the same term to the induced eigenvalue processes. The matrix evolution then has GUE as its unique stationary distribution; on the other hand, we can obtain the corresponding stationary distribution for the eigenvalues as the unique probability density that is a stationary solution of the resulting modified Dyson PDE ")#link(<tao-e2bd9c6236a519d406d1>)[#text("(6)")]#text(", which is easily seen to be ")#link(<tao-01254bb6cb3b4ecf62ce>)[#text("(12)")]#text(".")

#text("I do realize this comment boils down to Exercise 11, but thought it was worth mentioning anyway — because the argument is physically compelling, and because you did introduce the Ornstein-Uhlenbeck process.")

#text("By the way, while Exercise 5 is internally consistent, your definition of Ornstein-Uhlenbeck is off from the usual one by a time-change — it has the wrong quadratic variation! I guess this is the source of the extra ")#mi("1/t")#text(" factor that appears in the definition of the generator ")#mi("L")#text(" (which, incidentally, is not self-adjoint!).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43722")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2010")])]

#text("Thanks for the corrections and comments! It’s true that the Ornstein-Uhlenbeck approach is slightly more efficient to get the Ginibre formula, but I like the heat equation approach as it also gives the Johansson formula quite easily. Though of course, as you say, the two approaches are simply rescalings of each other, so the differences are minor.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ad769094b23d44fe9bd0580a4f7fcf3c3fd4ac76d5b4510b7fc1e44795baa7d-cffd096f5ab07b6a2bbcd5369cacbfe33b7de9984f5fd20d2b32db31b972e937.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Bloemendal")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43716")[#strong[#text("Alex Bloemendal")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2010")])]

#text("A comment regarding Remark 9:")

#text("Two-dimensional Brownian motion ")#mi("B_t")#text(" almost surely never hits a given point ")#mi("x_0")#text(" after time 0. My favourite proof uses the interpretation of certain harmonic functions as hitting probabilities, together with the form of the Green’s function of the 2-d Laplacian, to establish the following fact. Surround ")#mi("x_0")#text(" with concentric circles ")#mi("C_n")#text(" of radii ")#mi("2^n")#text(" for all ")#mi("n\\in{\\mathbb Z}")#text("; then the sequence of indices of the successive circles hit by ")#mi("B_t")#text(" (ignoring immediate repetition) forms a simple random walk on ")#mi("{\\mathbb Z}")#text("! In particular, ")#mi("B_t")#text(" must return to ")#mi("C_0")#text(" at arbitrarily large times, in between any two of which it can visit only finitely many ")#mi("C_n")#text("‘s. (This argument actually establishes neighbourhood recurrence as well, since ")#mi("B_t")#text(" must also hit each small circle at arbitrarily large times.)")

#text("Like everyone here, I seriously appreciate your wonderful notes and all the time you spend interacting with your readers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 6: Gaussian ensembles « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43718")[#strong[#text("254A, Notes 6: Gaussian ensembles « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2010")])]

#text("[…] have already shown using Dyson Brownian motion in Notes 3b that we have the Ginibre […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 7: The least singular value « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43791")[#strong[#text("254A, Notes 7: The least singular value « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2010")])]

#text("[…] so we expect each to have magnitude about . This, together with the Hoeffman-Wielandt inequality (Notes 3b) means that we expect to differ by from . In principle, this gives us asymptotic universality on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43857")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2010")])]

#text("Dear Prof. Tao,")

#text("Can we define Brownian motion on an infinite dimensional vector space?")

#text("a second question :we know that ")#mi("dB_t=B_{t+dt}-B_t")#text(" has mean zero and variance is ")#mi("dt.")#text(" therefore ")#mi("\\frac{dB_t}{(dt)^{1/2}}")#text(" has variance 1. but why do we have ")#mi("\\frac{dB_t}{(dt)^{1/2}}")#text(" be of ")#mi("O(1)")#text("?")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43869")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2010")])]

#text("Well, there are no non-trivial unitarily invariant probability distributions on a Hilbert space (each coordinate would almost surely be zero), so one has to give up either isotropy or finite norm in order to have a meaningful infinite-dimensional Brownian motion. Of course, once one gives up either, one can certainly define Brownian-like motions (e.g. by picking an orthonormal basis and placing an independent weighted copy of Brownian motion in each coordinate).")

#mi("dB_t/(dt)^{1/2}")#text(" has the standard normal distribution; it is of size O(1) on the average (and all moments are bounded), but will occasionally be large, and so is not a bounded random variable per se. Nevertheless it is a useful heuristic to think of this quantity as being of size O(1).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43867")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2010")])]

#text("Dear Prof. Tao,")

#text("We can consider Brownian motion as a random variable from a probability space to ")#mi("C([0,T]\\rightarrow {\\mathbb R})")

#text("Do we have a Markov process which can be considered as a random variable from a probability space to ")#mi("C^{\\infty}([0,T]\\rightarrow {\\mathbb R})")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43870")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2010")])]

#text("It depends a little on how one defines the “present state” of the system, but using a naive notion of the Markov property, the right-derivative would need to be independent of the left-derivative at time t when the position at t is fixed. But for a ")#mi("C^\\infty")#text(" function, these two derivatives are equal, and thus must be determined completely by the position at t. This suggests to me (from the Picard uniqueness theorem) that the only processes of this type are the deterministic ones, though there is the loophole that the derivative is not required to depend in a Lipschitz manner on the position.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of beginner")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43876")[#strong[#text("beginner")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2010")])]

#text("but the same argument should apply the continuous case as well. on the other hand we know that Brownian motion is a Markov process and has continuous paths. Maybe I am missing a point.")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-43878")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2010")])]

#text("Continuous paths need not have left or right derivatives.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76981c17af934a27adc124c8c9aa279ccf91f92a8293e82a00c1146329ea1b2f-ead17e27e3770dd1e1dcc1db15b3d6cdba48150e2c753f732fa37ec08216a369.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carl Mueller")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-49958")[#strong[#text("Carl Mueller")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2011")])]

#text("Usually the sigma-fields are assumed to be right continuous, meaning that the current state contains information about the infinitesimal future. So the right hand derivative (if it existed) would be part of the current state.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-44100")[#strong[#text("Dyson’s Brownian Motion « Rochester Probability Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2010")]

#text("[…] Dyson’s Brownian Motion Filed under: Uncategorized — carl0mueller @ 3:57 pm Tags: background See also: Tao’s blog on Dyson’s Brownian motion […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e3a4ad2bffece83e0b30983e48ae41ce7275975ac2c7e192db28c4bb4c835f16-0823e52cd2b464508a8804303cab6dc926d532ef8acf98e82fed1419ec145e85.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Minyu")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-49894")[#strong[#text("Minyu")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2011")])]

#text("Hi, Professor Tao:")

#text("There is a constant missing in the Ginibre formula and Exercise 9. It’s the reciprocal of a product of some factorials…")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yucao")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-49956")[#strong[#text("yucao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2011")])]

#text("Is it possible to extend the Brownian motion ")#mi("(W_t)_{t\\in[0,\\infity)}")#text(" on the whole ")#mi("{\\Bbb R}")#text(", i.e. ")#mi("(W_t)_{t\\in(-\\infty,\\infity)}")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-57221")[#strong[#text("Dyson Brownian Motion | Research Notebook")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2011")]

#text("[…] main source for the material in this post is Terry Tao‘s set of lecture notes on Random Matrix Theory, though I also used Mehta (2004) and Anderson, Guinnet and Zeitouni (2009) as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-69252")[#strong[#text("On Understanding Probability Puzzles | Nair Research Notes")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2011")]

#text("[…] by , from an experimental point of view. The formal construction for the Brownian motion can be found here for example. And you will get a good historical perspective of the Brownian motion here. One of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-107227")[#strong[#text("Diffusion in Ehrenfest wind-tree model « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2011")]

#text("[…] the “justification” of the word “abnormal” comes by comparison with Brownian motion and/or central limit theorem: once we know that the diffusion is “sublinear” (maybe […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e888551dfd5547b2ea72800bed3223e610fbf43b25f51fceefbfdf2fc12cbdf5-1af7816170205c864aff1e68929afe8f0fd3d0352d8a2a27101471e8a36e8116.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-123310")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2012")])]

#text("Hi prof. Tau,")

#text("Thanks for these great notes!")

#text("Maybe this question is much too late, but I’d be very grateful for a reply. I’m used to think about the eigenvalues of the GUE as being subjected to a quadratic confining potential and mutual log repulsion: is there an easy way to understand the absence of the effect of the confining potential (which would give rise to a simple harmonic restoring force for each eigenvalue) in the formula for the Dyson Brownian motion, equation (5)?")

#text("Thanks for a great blog!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-123384")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2012")])]

#text("One can restore the confining potential by adding a ")#mi("- \\lambda_i dt")#text(" term to the equation for ")#mi("d\\lambda_i")#text(", turning the Dyson Brownian motion to a Dyson Ornstein-Uhlenbeck process. This has the effect of keeping the variance of the matrix entries in the process constant, instead of growing linearly in time as is done here.")

#text("The two processes (normalised variance and non-normalised variance) can be easily rescaled to each other, so the choice of which one to use is basically a matter of taste.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/535b8982adda52a880c72db15536b13f320f6cdc7d45a5fbbbf58a9095dde90d-bb5820a5c297e6e30da8807c8bdc1a4192224b1f1e5b1647554b8a04a7d394e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alabair")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-141176")[#strong[#text("alabair")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2012")])]

#text("I am amazed by the surprising number of knowledge that is difficult to me to digest. And by the way, I would like to hear about a white noise process. Good luck.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A direct proof of the stationarity of the Dyson sine process under Dyson Brownian motion « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-191739")[#strong[#text("A direct proof of the stationarity of the Dyson sine process under Dyson Brownian motion « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2012")])]

#text("[…] of a Hermitian matrix under independent Brownian motion of its entries, and is discussed in this previous blog post. To cut a long story short, this stationarity tells us that the self-similar -point correlation […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/89ce32fd9ec0a5effa186642ab7f333e79fa5dda76716207f6762764edf8728e-f53e0d018f9ec920a1fc0607be19969bd0c1b2bbdc77f1d4c5479b78a3dd217a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hera")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-215672")[#strong[#text("hera")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2013")])]

#text("Great lecture! Prof. Tao, do you have ideas to simulate the Dyson’s brownian motion ? I’d like to do a computer simulation with MATLAB, can you give me some ideas?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Some notes on Bakry-Emery theory « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-215889")[#strong[#text("Some notes on Bakry-Emery theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2013")])]

#text("[…] is a stochastic process with initial probability distribution ; see for instance this previous blog post for more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Harish-Chandra-Itzykson-Zuber integral formula « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-216233")[#strong[#text("The Harish-Chandra-Itzykson-Zuber integral formula « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2013")])]

#text("[…] motion (as well as the closely related formulae for the GUE ensemble), which were derived in this previous blog post. Both of these approaches can be found in several places in the literature (and I do not actually […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/07a7ff91b522bd7e3d602d732862da024ca4139da9b2c9c501209e58c172fe3f-3d62c9479bfbdbb2f0dea100b15ffb0ef7ef841b2b446f14120e79e1bc868c13.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sticky Brownian Motion | Eventually Almost Everywhere")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-311030")[#strong[#text("Sticky Brownian Motion | Eventually Almost Everywhere")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2014")])]

#text("[…] 254A, Notes 3b: Brownian motion and Dyson Brownian motion (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/803266c7ab6472ec9611dec2a090501ff6a79f58d5fafdfa3adcb82545657a27-c970c3296e1dc3dc780be6c4b796c7dbe0400c04eb3c2551fa89687a5f60e113.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ramis Movassagh")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-446791")[#strong[#text("Ramis Movassagh")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2014")])]

#text("Dear Terry,")#linebreak()#text(" Thank you for the wonderful post (your posts are always a joy to read and learn from).")

#text("Shouldn’t Prop. 2 end with “…same distribution at X_t” instead of \\mu?")#linebreak()#text(" Best, – Ramis")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/803266c7ab6472ec9611dec2a090501ff6a79f58d5fafdfa3adcb82545657a27-c970c3296e1dc3dc780be6c4b796c7dbe0400c04eb3c2551fa89687a5f60e113.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ramis Movassagh")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-446814")[#strong[#text("Ramis Movassagh")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2014")])]

#text("Hi Terry, Same with Prop 3. Thanks for the great post.")#linebreak()#text(" cheers, -R")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-464968")[#strong[#text("Ito Calculus by peatar | wanikanidailyscience")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2016")]

#text("[…] Warning: I don’t really know much about financial mathematics so if there are any economists around: Let me know about eventual mistakes. Sources: Links in the text and Terry Tao’s blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d12cff0b00bf3f61f2c930ddd0a06ff8ad2df057fa7d6a39cc591560aad0036d-db4dabcddbff803ac592010f3539d335128687cdcc9ce0dc42b7b73ba449f7b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-488590")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2017")])]

#text("Dear Professor Tao,")#linebreak()#text(" In the last part Theorem 6, ")#tao-math("\\sum_{i \\neq j} \\frac{\\left|\\xi_{ij}\\right|-1}{\\lambda_i - \\lambda_j}", block: false)#text(" has O(")#mi("dt^3")#text(") third moment, but the constant of the big order should be O(")#tao-math("(\\sum_{i \\neq j} \\frac{1}{\\left|\\lambda_i-\\lambda_j\\right|})^3", block: false)#text("). Upon doing the conditioning I think one should check ")#tao-math("\\sum_{i \\neq j} \\frac{1}{\\left|\\lambda_i - \\lambda_j\\right|}", block: false)#text(" has finite third moment, but how can I do that?")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-488617")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2017")])]

#text("Actually, the third derivative scales like ")#tao-math("O( \\sum_{i \\neq j} \\frac{1}{\\left|\\lambda_i-\\lambda_j\\right|^2} )", block: false)#text(", so one only needs to control the second moment, not the third. The probability that two eigenvalues are within ")#mi("\\varepsilon")#text(" of each other is bounded by ")#mi("O( \\varepsilon^3 )")#text(" (this is because the Vandermonde determinant is ")#mi("O(\\varepsilon)")#text("), where we allow implied constants to depend on ")#mi("n")#text(". So the second moment is finite.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d12cff0b00bf3f61f2c930ddd0a06ff8ad2df057fa7d6a39cc591560aad0036d-db4dabcddbff803ac592010f3539d335128687cdcc9ce0dc42b7b73ba449f7b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-488699")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2017")])]

#text("By the independence of ")#tao-math("\\{\\left|\\xi_{ij}\\right|^2 -1\\}", block: false)#text(", product of two or three random variables will have zero expectation, so")#linebreak()#text(" ")#tao-math("E(dt \\sum_{j\\neq i} \\frac{\\left|\\xi_{ij}\\right| -1}{\\lambda_i-\\lambda_j})^3 = E(dt^3 (\\frac{\\left|\\xi_{ij}\\right| -1}{\\lambda_i-\\lambda_j})^3) =  C^3 dt^3 \\sum_{j\\neq i}( \\frac{1}{\\lambda_i-\\lambda_j})^3", block: false)#text(".")#linebreak()#text(" Can the term ")#mi("O(\\sum_{j\\neq i}( \\frac{1}{\\lambda_i-\\lambda_j})^2)")#text(" be derived by direct computation? or there is some relation I need to use?")

#text("The of Vandermonde determinant and the process is derived in Exercise 6 and Theorem 6.")#linebreak()#text(" Will Using it to discuss the gap between the eigenvalues lead to circular argument(because it is a part of proof of Theorem 6)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-488711")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2017")])]

#text("You are right, the third moment bound is a bit too strong. I have rewritten the argument to only claim the second moment bound (for one error term) and an L^1 bound (for the other error term), which still suffices.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246C notes 4: Brownian motion, conformal invariance, and SLE | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-500282")[#strong[#text("246C notes 4: Brownian motion, conformal invariance, and SLE | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2018")])]

#text("[…] and complex Brownian motions exist from any base point or ; see e.g. this previous blog post for a construction. We have the following simple […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01952b95b038ce498d7fef633f889cd2b1a076265e56d3f92a53d5a42bd28870-cf57ebc707894ce5d39536e1bc8b455f8ab306c70d4b3e02695cdb6ee2f4fe8a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yixuan Zhou")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-584833")[#strong[#text("Yixuan Zhou")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2020")])]

#text("Dear Professor Tao, I want to ask whether we can take the derivatives of the eigenvalues when we are trying to prove the Dyson Brownian Motion’s equation. I know from a previous note you justified the smoothness when the matrix process that we obtained is smooth with respect to time. However, it is not clear to me that Hermitian matrix valued BM is smooth.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-586489")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2020")])]

#text("The eigenvalues of a DBM will not be classically differentiable, but one can still manipulate their time derivative by the usual tools of stochastic differential calculus (in particular ")#link("https://en.wikipedia.org/wiki/It%C3%B4_calculus")[#text("Ito calculus")]#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-589007")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2020")])]

#text("Dear Professor Tao,")

#text("I have a question about the last part where we derive the Johansson formula. I don’t think I am understanding the argument of extending the probability density function symmetrically from the Weyl chamber to the whole space. The questions that lingers are, first what do you mean by extending a function symmetrically. And second, why would we sum up the different initial starting location if the eigenvalues should be non-crossing.")

#text("Thanks in advance!")

#emph[#text("[See ")#link("https://en.wikipedia.org/wiki/Symmetric_function")[#text("https://en.wikipedia.org/wiki/Symmetric_function")]#text(" ]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/450b3cda25e9523f8057a6a5fc343eeae7161d8ea0638d24503c8d91e7614f87-87e12d3668fa38c9f891407f84c42f3b4cca9246ecc10e11f94a7bd031f8ebd4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-621990")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2021")])]

#text("Don’t the eigenvalues of a GUE sample lie on a disk of unit radius, i.e. Girko’s law?")

#emph[#text("[The circular law of Girko is for non-Hermitian random matrices such as the Ginibre ensemble, whereas the GUE ensemble (which shoudl not be confused with the Ginibre ensemble) is Hermitian. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/#comment-692556")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2026")])]

#text("A small typo: “indentification” should be “identification”.")

#text("Nice post! But I’m a bit confused about the notation conventions in it. Why do you denote “X follows distribution μ” as X≡μ? I think the more common notation would be X~μ. I feel that ≡ easily reminds people of “identically equal to,” such as a constant function f≡3, so it could cause confusion. I imagine you must have a reason for doing it this way.")

#emph[#text("[This is the notation I selected when writing the notes, see ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")]#text(" . In retrospect, if I had to rewrite the notes now, I would do so with more standard notation here. -T]")]
]
