// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/
// Converted to Typst by tao2typ: "2026-10-14T11:30:06.161029+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Higher order Hilbert spaces", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Higher order Hilbert spaces")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 May 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/")[#text("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A (complex, semi-definite) ")#link("http://en.wikipedia.org/wiki/Inner_product_space")[#text("inner product space")]#text(" is a complex vector space ")#mi("{V}")#text(" equipped with a sesquilinear form ")#mi("{\\langle, \\rangle: V \\times V \\rightarrow {\\bf C}}")#text(" which is conjugate symmetric, in the sense that ")#mi("{\\langle w, v \\rangle = \\overline{\\langle v, w \\rangle}}")#text(" for all ")#mi("{v,w \\in V}")#text(", and non-negative in the sense that ")#mi("{\\langle v, v \\rangle \\geq 0}")#text(" for all ")#mi("{v \\in V}")#text(". By inspecting the non-negativity of ")#mi("{\\langle v+\\lambda w, v+\\lambda w\\rangle}")#text(" for complex numbers ")#mi("{\\lambda \\in {\\bf C}}")#text(", one obtains the ")#link("http://en.wikipedia.org/wiki/Cauchy-Schwarz_inequality")[#text("Cauchy-Schwarz inequality")]

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle v, w \\rangle\\right| \\leq \\left|\\langle v, v \\rangle\\right|^{1/2} \\left|\\langle w, w \\rangle\\right|^{1/2};", block: true)]]

#text("if one then defines ")#tao-math("{\\left\\|v\\right\\| := \\left|\\langle v, v \\rangle\\right|^{1/2}}", block: false)#text(", one then quickly concludes the ")#link("http://en.wikipedia.org/wiki/Triangle_inequality")[#text("triangle inequality")]

#align(center)[#tao-fit-display[#tao-math("\\left\\|v + w \\right\\| \\leq \\left\\|v\\right\\| + \\left\\|w\\right\\|", block: true)]]

#text("which then soon implies that ")#mi("{\\| \\|}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Semi-norm")[#text("semi-norm")]#text(" on ")#mi("{V}")#text(". If we make the additional assumption that the inner product ")#mi("{\\langle,\\rangle}")#text(" is positive definite, i.e. that ")#mi("{\\langle v, v \\rangle > 0}")#text(" whenever ")#mi("{v}")#text(" is non-zero, then this semi-norm becomes a norm. If ")#mi("{V}")#text(" is complete with respect to the metric ")#tao-math("{d(v,w) := \\left\\|v-w\\right\\|}", block: false)#text(" induced by this norm, then ")#mi("{V}")#text(" is called a ")#link("http://en.wikipedia.org/wiki/Hilbert_space")[#text("Hilbert space")]#text(".")

#text("The above material is extremely standard, and can be found in any graduate real analysis course; I myself covered it ")#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/")[#text("here")]#text(". But what is perhaps less well known (except inside the fields of additive combinatorics and ergodic theory) is that the above theory of classical Hilbert spaces is just the first case of a hierarchy of ")#emph[#text("higher order Hilbert spaces")]#text(", in which the binary inner product ")#mi("{f, g \\mapsto \\langle f, g \\rangle}")#text(" is replaced with a ")#mi("{2^d}")#text("-ary inner product ")#mi("{(f_\\omega)_{\\omega \\in \\{0,1\\}^d} \\mapsto \\langle (f_\\omega)_{\\omega \\in \\{0,1\\}^d}}")#text(" that obeys an appropriate generalisation of the conjugate symmetry, sesquilinearity, and positive semi-definiteness axioms. Such inner products then obey a higher order Cauchy-Schwarz inequality, known as the ")#emph[#text("Cauchy-Schwarz-Gowers")]#text(" inequality, and then also obey a triangle inequality and become semi-norms (or norms, if the inner product was non-degenerate). Examples of such norms and spaces include the ")#emph[#text("Gowers uniformity norms")]#text(" ")#mi("{\\| \\|_{U^d(G)}}")#text(", the ")#emph[#text("Gowers box norms")]#text(" ")#mi("{\\| \\|_{\\Box^d(X_1 \\times \\ldots \\times X_d)}}")#text(", and the ")#emph[#text("Gowers-Host-Kra seminorms")]#text(" ")#mi("{\\| \\|_{U^d(X)}}")#text("; a more elementary example are the family of Lebesgue spaces ")#mi("{L^{2^d}(X)}")#text(" when the exponent is a power of two. They play a central role in modern additive combinatorics and to certain aspects of ergodic theory, particularly those relating to Szemerédi’s theorem (or its ergodic counterpart, the Furstenberg multiple recurrence theorem); they also arise in the regularity theory of hypergraphs (which is not unrelated to the other two topics).")

#text("A simple example to keep in mind here is the order two Hilbert space ")#mi("{L^4(X)}")#text(" on a measure space ")#mi("{X = (X,{\\mathcal B},\\mu)}")#text(", where the inner product takes the form")

#align(center)[#tao-fit-display[#mitex("\\langle f_{00}, f_{01}, f_{10}, f_{11} \\rangle_{L^4(X)} := \\int_X f_{00}(x) \\overline{f_{01}(x)} \\overline{f_{10}(x)} f_{11}(x)\\ d\\mu(x).")]]

#text("In this brief note I would like to set out the abstract theory of such higher order Hilbert spaces. This is not new material, being already implicit in the breakthrough papers ")#link("http://www.ams.org/mathscinet-getitem?mr=1844079")[#text("of Gowers")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("Host-Kra")]#text(", but I just wanted to emphasise the fact that the material is abstract, and is not particularly tied to any explicit choice of norm so long as a certain axiom are satisfied. (Also, I wanted to ")#link("https://terrytao.wordpress.com/career-advice/write-down-what-youve-done/")[#text("write things down")]#text(" so that I would not have to reconstruct this formalism again in the future.) Unfortunately, the notation is quite heavy and the abstract axiom is a little strange; it may be that there is a better way to formulate things. In this particular case it does seem that a concrete approach is significantly clearer, but abstraction is at least possible.")

#text("Note: the discussion below is likely to be comprehensible only to readers who already have some exposure to the Gowers norms.")

#metadata(none) <tao-26e4beae9d5c19e78271>

#heading(level: 1)[#strong[#text(" — 1. Definition of a higher order Hilbert space — ")]]

#text("Let ")#mi("{V, W}")#text(" be complex vector spaces. Then one can form the (algebraic) ")#link("http://en.wikipedia.org/wiki/Tensor_product")[#text("tensor product")]#text(" ")#mi("{V \\otimes W}")#text(", which can be defined as the vector space spanned by formal tensor products ")#mi("{v \\otimes w}")#text(", subject to the constraint that the tensor product is bilinear (i.e. that ")#mi("{v \\otimes (w_1+w_2) = (v \\otimes w_1) + (v \\otimes w_2)}")#text(", ")#mi("{v \\otimes cw = c (v \\otimes w)}")#text(", and similarly with the roles of ")#mi("{v}")#text(" and ")#mi("{w}")#text(" reversed). More generally, one can define the tensor product ")#mi("{\\bigotimes_{\\omega \\in \\Omega} V_\\omega}")#text(" of any finite family of complex vector spaces ")#mi("{V_\\omega}")#text(".")

#text("Given a complex vector space ")#mi("{V}")#text(", one can define its ")#emph[#text("complex conjugate")]#text(" ")#mi("{\\overline{V}}")#text(" to be the set of formal conjugates ")#mi("{\\{ \\overline{v}: v \\in V \\}}")#text(" of vectors in ")#mi("{V}")#text(", with the vector space operations given by")

#tao-aligned(keep: true)[


#tao-math("0  & := \\overline{0}", block: true)



#tao-math("\\overline{v} + \\overline{w}  & := \\overline{v+w}", block: true)



#tao-math("c \\overline{v}  & := \\overline{\\overline{c} v}.", block: true)
]

#text("The map ")#mi("{v \\mapsto \\overline{v}}")#text(" is then an antilinear isomorphism from ")#mi("{V}")#text(" to ")#mi("{\\overline{V}}")#text(". We adopt the convention that ")#mi("{\\overline{\\overline{v}} = v}")#text(", thus ")#mi("{v \\mapsto \\overline{v}}")#text(" is also an antilinear isomorphism from ")#mi("{\\overline{V}}")#text(" to ")#mi("{V}")#text(". (One can work with real higher order Hilbert spaces instead of complex ones, in which case the conjugation symbols can be completely ignored.)")

#text("For inductive reasons, it is convenient to use finite sets ")#mi("{A}")#text(" of labels, rather than natural numbers ")#mi("{d}")#text(", to index the order of the systems we will be studying. In any case, the cardinality ")#tao-math("{\\left|A\\right|}", block: false)#text(" of the set of labels will be the most important feature of this set.")

#text("Given a complex vector space ")#mi("{V}")#text(" and a finite set ")#mi("{A}")#text(" of labels, we form the tensor cube ")#mi("{V^{[A]}}")#text(" to be")

#align(center)[#tao-fit-display[#tao-math("V^{[A]} := \\bigotimes_{\\omega \\in \\{0,1\\}^A} {\\mathcal C}^{\\left|\\omega\\right|} V,", block: true)]]

#text("where ")#mi("{{\\mathcal C}}")#text(" is the conjugation map ")#mi("{V \\mapsto \\overline{V}}")#text(", and ")#tao-math("{\\left|\\omega\\right| := \\sum_{i \\in A} \\omega_i}", block: false)#text(" when ")#mi("{\\omega = (\\omega_i)_{i \\in A}}")#text("; thus for instance ")#mi("{V^{[\\{\\}]} = V}")#text(", ")#mi("{V^{[\\{1\\}]} \\equiv V \\otimes \\overline{V}}")#text(" is spanned by tensor products ")#mi("{v_0 \\otimes \\overline{v_1}}")#text(" with ")#mi("{v_0, v_1 \\in V}")#text(", ")#mi("{V^{[\\{1,2\\}]} \\equiv V \\otimes \\overline{V} \\otimes \\overline{V} \\otimes V}")#text(" is spanned by tensor products ")#mi("{v_{00} \\otimes \\overline{v_{01}} \\otimes \\overline{v_{10}} \\otimes v_{11}}")#text(" with ")#mi("{v_{00}, v_{01}, v_{10}, v_{11} \\in V}")#text(", and so forth. (It would be better to order the four factors ")#mi("{v_{00}, v_{01}, v_{10}, v_{11}}")#text(" in a square pattern, rather than linearly as is done here, but we have used the inferior linear ordering here for typographical reasons.)")

#text("Given any finite set ")#mi("{A}")#text(" of labels and any ")#mi("{i \\in A}")#text(", one can form an identification")

#align(center)[#tao-fit-display[#mitex("V^{[A]} \\equiv V^{[A \\backslash \\{i\\}]} \\otimes \\overline{V^{[A \\backslash \\{i\\}]}}")]]

#text("by identifying a tensor product ")#tao-math("{\\bigotimes_{\\omega \\in \\{0,1\\}^A} {\\mathcal C}^{\\left|\\omega\\right|} v_\\omega}", block: false)#text(" in ")#mi("{V^{[A]}}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("(\\bigotimes_{\\omega^{\\prime} \\in \\{0,1\\}^{A \\backslash i}} {\\mathcal C}^{\\left|\\omega^{\\prime}\\right|} v_{(\\omega^{\\prime},0)}) \\otimes \\overline{(\\bigotimes_{\\omega^{\\prime} \\in \\{0,1\\}^{A \\backslash i}} {\\mathcal C}^{\\left|\\omega^{\\prime}\\right|} v_{(\\omega^{\\prime},1)})}", block: true)]]

#text("where, for ")#mi("{\\omega^{\\prime} \\in \\{0,1\\}^{A \\backslash i}}")#text(" and ")#mi("{\\omega_i \\in \\{0,1\\}}")#text(", ")#mi("{(\\omega^{\\prime},\\omega_i)}")#text(" denotes the element of ")#mi("{\\{0,1\\}^A}")#text(" that agrees with ")#mi("{\\omega^{\\prime}}")#text(" on ")#mi("{A \\backslash i}")#text(" and equals ")#mi("{\\omega_i}")#text(" on ")#mi("{i}")#text(". We refer to this identification as ")#mi("{\\otimes_i}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\otimes_i: V^{[A \\backslash \\{i\\}]} \\otimes \\overline{V^{[A \\backslash \\{i\\}]}} \\rightarrow V^{[A]}")]]

#text("is an isomorphism, and one can define the ")#mi("{i^{th}}")#text(" tensor product ")#mi("{v \\otimes_i \\overline{w} \\in V^{[A]}}")#text(" of two elements ")#mi("{v, w \\in V^{[A \\backslash \\{i\\}]}}")#text(". Thus for instance, if ")#mi("{v = v_0 \\otimes \\overline{v_1}}")#text(" and ")#mi("{w = w_0 \\otimes \\overline{w_1}}")#text(" are elements of ")#mi("{V^{[\\{1\\}]}}")#text(", then")

#align(center)[#tao-fit-display[#mitex("v \\otimes_2 \\overline{w} = v_0 \\otimes \\overline{v_1} \\otimes \\overline{w_0} \\otimes w_1")]]

#text("using the linear ordering conventions used earlier. If we instead view ")#mi("{v, w}")#text(" as elements of ")#mi("{V^{[\\{2\\}]}}")#text(" rather than ")#mi("{V^{[\\{1\\}]}}")#text(", then")

#align(center)[#tao-fit-display[#mitex("v \\otimes_1 \\overline{w} = v_0 \\otimes \\overline{w_0} \\otimes \\overline{v_1} \\otimes w_1.")]]

#text("A (semi-)definite inner product ")#mi("{\\langle, \\rangle}")#text(" on a complex vector space ")#mi("{V}")#text(" can be viewed as a linear functional ")#mi("{\\langle \\rangle: V \\otimes \\overline{V} \\rightarrow {\\bf C}}")#text(" on ")#mi("{V^{[\\{1\\}]} = V \\otimes \\overline{V}}")#text(" obeying a conjugation symmetry and positive (semi-)definiteness property, defined on tensor products ")#mi("{v \\otimes \\overline{w}}")#text(" as ")#mi("{\\langle v \\otimes \\overline{w} \\rangle := \\langle v, w \\rangle}")#text(". With this notation, the conjugation symmetry axiom becomes")

#align(center)[#tao-fit-display[#mitex("\\langle w \\otimes \\overline{v} \\rangle := \\overline{\\langle v \\otimes \\overline{w} \\rangle}")]]

#text("and the positive semi-definiteness property becomes")

#align(center)[#tao-fit-display[#mitex("\\langle v \\otimes \\overline{v} \\rangle \\geq 0")]]

#text("with equality iff ")#mi("{v=0}")#text(" in the definite case.")

#text("Now we can define a higher order inner product space.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1")]#text(" Let ")#mi("{A}")#text(" be a finite set of labels. A ")#emph[#text("(semi-definite) inner product space of order ")#mi("{A}")]#text(" is a complex vector space ")#mi("{V}")#text(", together with a linear functional ")#mi("{\\langle \\rangle_A: V^{[A]} \\rightarrow {\\bf C}}")#text(" that obeys the following axiom:")

#list(
[#text("(Splitting axiom) For every ")#mi("{i \\in A}")#text(", ")#mi("{\\langle \\rangle_A}")#text(" is a semi-definite classical inner product ")#mi("{\\langle \\rangle_{A \\backslash \\{i\\}}}")#text(" on ")#mi("{V^{[A \\backslash \\{i\\}]} \\otimes \\overline{V^{[A \\backslash \\{i\\}]}}}")#text(", which we identify with ")#mi("{V^{[A]}}")#text(" using ")#mi("{\\otimes_i}")#text(" as mentioned above.")]
)

#text("We say that the inner product space is ")#emph[#text("positive definite")]#text(" if one has ")#tao-math("{\\langle \\bigotimes_{\\omega \\in \\{0,1\\}^A} {\\mathcal C}^{\\left|\\omega\\right|} v \\rangle_A > 0}", block: false)#text(" whenever ")#mi("{v \\in V}")#text(" is non-zero. (Note from the splitting axiom that one already has the non-strict inequality. But the positive definiteness property is weaker than the assertion that each of the classical inner products)")
]

#text("For instance, if ")#mi("{A}")#text(" is the empty set, then an inner product space of order ")#mi("{A}")#text(" is just a complex vector space ")#mi("{V}")#text(" equipped with a linear functional ")#mi("{v \\mapsto \\langle v \\rangle_A}")#text(" from ")#mi("{V}")#text(" to ")#mi("{{\\bf C}}")#text(" (which one could interpret as an expectation or a trace, if one wished). If ")#mi("{A}")#text(" is a singleton set, then an inner product space of order ")#mi("{A}")#text(" is the same thing as a classical inner product space.")

#text("If ")#mi("{A = \\{1,2\\}}")#text(", then an inner product space of order ")#mi("{A}")#text(" is a complex vector space ")#mi("{V}")#text(" equipped with a linear functional ")#mi("{\\langle \\rangle_A: V \\otimes \\overline{V} \\otimes \\overline{V} \\otimes V}")#text(", which in particular gives rise to a quartisesquilinear (!) form")

#align(center)[#tao-fit-display[#mitex("(v_{00}, v_{01}, v_{10}, v_{11}) \\mapsto \\langle v_{00} \\otimes \\overline{v_{01}} \\otimes \\overline{v_{10}} \\otimes v_{11} \\rangle_A")]]

#text("which is a classical inner product in two different ways, thus for instance we have")

#align(center)[#tao-fit-display[#mitex("\\langle v_{00} \\otimes \\overline{v_{01}} \\otimes \\overline{v_{10}} \\otimes v_{11} \\rangle_A = \\langle v_{00} \\otimes \\overline{v_{01}}, v_{10} \\otimes \\overline{v_{11}} \\rangle_{\\{2\\}}")]]

#text("for ")#mi("{v_{00}, v_{01}, v_{10}, v_{11} \\in V}")#text(" and some classical inner product ")#mi("{\\langle, \\rangle_{\\{2\\}}}")#text(" on ")#mi("{V^{[\\{2\\}]}}")#text(", and similarly")

#align(center)[#tao-fit-display[#mitex("\\langle v_{00} \\otimes \\overline{v_{01}} \\otimes \\overline{v_{10}} \\otimes v_{11} \\rangle_A = \\langle v_{00} \\otimes \\overline{v_{10}}, v_{01} \\otimes \\overline{v_{11}} \\rangle_{\\{1\\}}")]]

#text("for some classical inner product ")#mi("{\\langle,\\rangle_{\\{1\\}}}")#text(" on ")#mi("{V^{[\\{1\\}]}}")#text(".")

#heading(level: 1)[#strong[#text(" — 2. Examples — ")]]

#text("Let us now give the three major (and inter-related) examples of inner product spaces of higher order: the ")#emph[#text("Gowers uniformity spaces")]#text(", that arise in additive combinatorics; the ")#emph[#text("Gowers box spaces")]#text(", which arise in hypergraph regularity theory, and the ")#emph[#text("Gowers-Host-Kra spaces")]#text(", which arise in ergodic theory. We also remark on the much simpler example of the Lebesgue spaces of dyadic exponent.")

#text("The first example is the family of ")#emph[#text("Gowers uniformity spaces")]#text(" ")#mi("{U^A(G)}")#text(", which we will define for simplicity on a finite additive group ")#mi("{G}")#text(" (one can also define this norm more generally on finite subsets of abelian groups, and probably also nilpotent groups, but we will not do so here). Here ")#mi("{A}")#text(" is a finite set of labels; in applications one usually sets ")#mi("{A := \\{1,\\ldots,d\\}}")#text(", in which case one abbreviates ")#mi("{U^{\\{1,\\ldots,d\\}}(G)}")#text(" as ")#mi("{U^d(G)}")#text(". The space ")#mi("{U^A(G)}")#text(" is the space of all functions ")#mi("{f: G \\rightarrow {\\bf C}}")#text(", and so ")#mi("{U^A(G)^{[A]}}")#text(" can be canonically identified with the space of functions ")#mi("{F: G^{\\{0,1\\}^A} \\rightarrow {\\bf C}}")#text(". To make ")#mi("{U^A(G)}")#text(" into an inner product space of order ")#mi("{A}")#text(", we define")

#align(center)[#tao-fit-display[#mitex("\\langle F \\rangle_A := \\mathop{\\bf E}_{x \\in G^{[A]}} F(x)")]]

#text("where ")#mi("{G^{[A]}}")#text(" is the subgroup of ")#mi("{G^{\\{0,1\\}^A}}")#text(" consisting of the parallelopipeds")

#align(center)[#tao-fit-display[#mitex("G^{[A]} := \\{ ( x + \\sum_{i \\in A} \\omega_i h_i )_{\\omega \\in \\{0,1\\}^A}: x \\in G, h_i \\in G \\text{ for all } i \\in A \\}.")]]

#text("This is clearly a linear functional. To verify the splitting axiom, one observes the identity")

#align(center)[#tao-fit-display[#mitex("\\langle F_0 \\otimes_i \\overline{F_1} \\rangle_A = \\mathop{\\bf E}_{h_j \\in G \\text{ for } j \\in A \\backslash \\{i\\}} \\mathop{\\bf E}_{x,h_i \\in G}")]]

#align(center)[#tao-fit-display[#mitex("F_0( ( x + \\sum_{j \\in A \\backslash \\{i\\}} \\omega_j h_j )_{\\omega \\in \\{0,1\\}^{A\\backslash \\{i\\}}} )")]]

#align(center)[#tao-fit-display[#mitex("\\overline{F_1}( ( x + h_i + \\sum_{j \\in A \\backslash \\{i\\}} \\omega_j h_j )_{\\omega \\in \\{0,1\\}^{A\\backslash \\{i\\}}} )")]]

#text("for any ")#mi("{i \\in A}")#text(" and ")#mi("{F_0, F_1 \\in U^A(G)^{[A \\backslash \\{i\\}]}}")#text(". The right-hand side is then a semi-definite classical inner product on ")#mi("{U^A(G)^{[A \\backslash \\{i\\}]}}")#text("; the semi-definiteness becomes more apparent if one makes the substitution ")#mi("{(x,y) := (x,x+h_i)}")#text(".")

#text("Specialising to tensor products, we obtain the ")#emph[#text("Gowers inner product")]

#align(center)[#tao-fit-display[#tao-math("\\langle \\otimes_{\\omega \\in \\{0,1\\}^A} {\\mathcal C}^{\\left|\\omega\\right|} f_\\omega \\rangle_A = \\mathop{\\bf E}_{x \\in G, h_i \\in G \\forall i \\in A} \\prod_{\\omega \\in \\{0,1\\}^A} {\\mathcal C}^{\\left|\\omega\\right|} f_\\omega(x + \\sum_{i=1}^A \\omega_i h_i ).", block: true)]]

#text("Thus, for instance, when ")#mi("{A = \\{1,2\\}}")#text(",")

#align(center)[#tao-fit-display[#mitex("\\langle f_{00} \\otimes \\overline{f_{01}} \\otimes \\overline{f_{10}} \\otimes f_{11} \\rangle_A =")]]

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{x, h_1, h_2 \\in G} f_{00}(x) \\overline{f_{10}}(x+h_2) \\overline{f_{10}}(x+h_1) f_{11}(x+h_1+h_2).")]]

#text("The second example is the family of the (incomplete) ")#emph[#text("Gowers box spaces")]#text(" ")#mi("{\\Box^A \\cap L^\\infty( X )}")#text(", defined on a Cartesian product ")#mi("{X := \\prod_{i \\in A} X_i}")#text(" of a family ")#mi("{X_i = (X_i, {\\mathcal B}_i, \\mu_i)}")#text(" of measure spaces indexed by a finite set ")#mi("{A}")#text(". To avoid some minor technicalities regarding absolute integrability, we assume that all the measure spaces have finite measure (the theory also works in the ")#mi("{\\sigma}")#text("-finite case, but we will not discuss this here). This space is the space of all bounded measurable functions ")#mi("{f \\in L^\\infty( X )}")#text(" (here, for technical reasons, it is best not to quotient out by almost everywhere equivalence until later in the theory). The tensor power ")#mi("{L^\\infty( X )^{[A]}}")#text(" can thus be identified with a subspace of ")#mi("{L^\\infty( X^{\\{0,1\\}^A} )}")#text(" (roughly speaking, this is the subspace of “elementary functions”). We can then define an inner product of order ")#mi("{A}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\langle F \\rangle = \\int_X \\int_X F( ((x_{\\omega_i,i})_{i \\in A})_{\\omega \\in \\{0,1\\}^A} )\\ d\\mu(x_0) d\\mu(x_1)")]]

#text("for all ")#mi("{F \\in L^\\infty( X )^{[A]} \\subset L^\\infty( X^{\\{0,1\\}^A} )}")#text(", where ")#mi("{x_0 = (x_{0,i})_{i \\in A}}")#text(" and ")#mi("{x_1 = (x_{0,i})_{i \\in A}}")#text(" are integrated using product measure ")#mi("{\\mu := \\prod_{i \\in A} \\mu_i}")#text(".")

#text("The verification of the splitting property is analogous to that for the Gowers uniformity spaces. Indeed, there is the identity")

#align(center)[#tao-fit-display[#mitex("\\langle F_0 \\otimes_i \\overline{F_1} \\rangle_A = \\int_{X^{(i)}} \\int_{X^{(i)}} \\int_{X_i} \\int_{X_i}")]]

#align(center)[#tao-fit-display[#mitex("F_0( ( ( ( x_{\\omega^{\\prime}_j,j} )_{j \\in A \\backslash \\{i\\}}, x_{0,i} ) )_{\\omega^{\\prime} \\in A \\backslash \\{i\\}}")]]

#align(center)[#tao-fit-display[#mitex("\\overline{F_1}( ( ( ( x_{\\omega^{\\prime}_j,j} )_{j \\in A \\backslash \\{i\\}}, x_{1,i} ) )_{\\omega^{\\prime} \\in A \\backslash \\{i\\}}")]]

#align(center)[#tao-fit-display[#mitex("d\\mu_i(x_{0,i}) d\\mu_i(x_{1,i}) d \\mu^{(i)}(x^{(i)}_0) d \\mu^{(i)}(x^{(i)}_1)")]]

#text("for all ")#mi("{i \\in A}")#text(" and ")#mi("{F_0, F_1 \\in L^\\infty( X )^{[A \\backslash \\{i\\}]} \\subset L^\\infty( X^{\\{0,1\\}^{A \\backslash \\{i\\}}} )}")#text(", where ")#mi("{X^{(i)} := \\prod_{j \\in A \\backslash \\{i\\}} X_j}")#text(", ")#mi("{\\mu^{(i)} := \\prod_{j \\in A \\backslash \\{i\\}} \\mu_j}")#text(", and ")#mi("{x^{(i)}_a = (x_{a,j})_{j \\in A \\backslash \\{i\\}}}")#text(" for ")#mi("{a=0,1}")#text(". From this formula one can verify the inner product property without much trouble (the main difficulty here is simply in unpacking all the notation).")

#text("The third example is that of the (incomplete) ")#emph[#text("Gowers-Host-Kra")]#text(" spaces ")#mi("{U^A \\cap L^\\infty(X)}")#text(". Here, ")#mi("{X = (X, {\\mathcal B}, \\mu)}")#text(" is a probability space with an invertible measure-preserving shift ")#mi("{T}")#text(", which of course induces a measure-preserving action ")#mi("{n \\mapsto T^n}")#text(" of the integers ")#mi("{{\\bf Z}}")#text(" on ")#mi("{X}")#text(". (One can replace the integers in the discussion that follows by more general nilpotent amenable groups, but we will stick to integer actions for simplicity.) It is often convenient to also assume that the measure ")#mi("{\\mu}")#text(" is ergodic, though this is not strictly required to define the semi-norms. The space here is ")#mi("{L^\\infty(X)}")#text("; the power ")#mi("{L^\\infty(X)^{[A]}}")#text(" is then a subspace of ")#mi("{L^\\infty(X^{\\{0,1\\}^A})}")#text(". One can define the ")#emph[#text("Host-Kra measure")]#text(" ")#mi("{\\mu^{[A]}}")#text(" on ")#mi("{X^{[A]}}")#text(" for any finite ")#mi("{A}")#text(" by the following recursive procedure. Firstly, when ")#mi("{A}")#text(" is empty, then ")#mi("{\\mu^{[A]}}")#text(" is just ")#mi("{\\mu}")#text(". If instead ")#mi("{A}")#text(" is non-empty, then pick an element ")#mi("{i \\in A}")#text(" and view ")#mi("{X^{[A]}}")#text(" as the Cartesian product of ")#mi("{X^{[A \\backslash \\{i\\}]}}")#text(" with itself. The shift ")#mi("{T}")#text(" acts on ")#mi("{X}")#text(", and thus acts diagonally on ")#mi("{X^{[A \\backslash \\{i\\}]}}")#text(" by acting on each component separately. It is not hard to show inductively from the construction that we are about to give that ")#mi("{\\mu^{[A \\backslash \\{i\\}]}}")#text(" is invariant with respect to this diagonal shift, which we will call ")#mi("{T^{[A \\backslash \\{i\\}]}}")#text(". The product ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}^{[A \\backslash \\{i\\}]}}")#text(" has an invariant factor ")#mi("{({\\mathcal B}^{[A \\backslash \\{i\\}]})^{T^{[A \\backslash \\{i\\}]}}}")#text(" with respect to this shift. We then define ")#mi("{\\mu^{[A]}}")#text(" to be the ")#emph[#text("relative")]#text(" product of ")#mi("{\\mu^{[A \\backslash \\{i\\}]}}")#text(" with itself relative to this invariant factor. One can show that this definition is independent of the choice of ")#mi("{i}")#text(", and that the form")

#align(center)[#tao-fit-display[#mitex("\\langle F \\rangle_A := \\int_{X^{[A]}} F\\ d\\mu^{[A]}")]]

#text("is an inner product of order ")#mi("{A}")#text("; see the ")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("paper of Host and Kra")]#text(" for details.")

#text("A final (and significantly simpler) example of a inner product space of order ")#mi("{A}")#text(" is the Lebesgue space ")#tao-math("{L^{2^{\\left|A\\right|}}(X)}", block: false)#text(" on some measure space ")#mi("{X = (X,{\\mathcal B},\\mu)}")#text(", with inner product")

#align(center)[#tao-fit-display[#mitex("\\langle F \\rangle_A := \\int_X F( (x,\\ldots,x) )\\ d\\mu(x)")]]

#text("where ")#mi("{x \\mapsto (x,\\ldots,x)}")#text(" is the diagonal embedding from ")#mi("{X}")#text(" to ")#tao-math("{X^{[A]} \\equiv X^{2^{\\left|A\\right|}}}", block: false)#text(". For tensor products, this inner product takes the form")

#align(center)[#tao-fit-display[#tao-math("\\langle \\bigotimes_{\\omega \\in \\{0,1\\}^A} {\\mathcal C}^{\\left|\\omega\\right|} f_\\omega \\rangle_A = \\int_X \\prod_{\\omega \\in \\{0,1\\}^A} {\\mathcal C}^{\\left|\\omega\\right|} f_\\omega\\ d\\mu,", block: true)]]

#text("thus for instance when ")#mi("{A = \\{1,2\\}}")#text(",")

#align(center)[#tao-fit-display[#mitex("\\langle f_{00} \\otimes \\overline{f_{01}} \\otimes \\overline{f_{10}} \\otimes f_{11} \\rangle_A = \\int_X f_{00} \\overline{f_{01}} \\overline{f_{10}} f_{11}\\ d\\mu.")]]

#text("We leave it as an exercise to the reader to show ")#tao-math("{L^{2^{\\left|A\\right|}}(X)}", block: false)#text(" is indeed an inner product space of order ")#mi("{A}")#text(". This example is (the completion of) the Gowers-Host-Kra space in the case when the shift ")#mi("{T}")#text(" is trivial.")

#text("We also remark that given an inner product space ")#mi("{(V, \\langle \\rangle_A)}")#text(" of some order ")#mi("{A}")#text(", given some subset ")#mi("{B}")#text(" of ")#mi("{A}")#text(", and given a fixed vector ")#mi("{v_*}")#text(" in ")#mi("{V}")#text(", one can define a weighted inner product space ")#mi("{(V, \\langle \\rangle_{B,v_*})}")#text(" of order ")#mi("{B}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\langle F \\rangle_{B,v_*} := \\langle F \\otimes \\bigotimes_{\\omega \\in \\{0,1\\}^A \\backslash \\{0,1\\}^B} {\\mathcal C}^{\\left|\\omega\\right|} v_* \\rangle_A", block: true)]]

#text("for all ")#mi("{F \\in V^{[B]}}")#text(", where ")#mi("{\\{0,1\\}^B}")#text(" is embedded in ")#mi("{\\{0,1\\}^A}")#text(" by extension by zero and the tensor product on the right-hand side is defined in the obvious manner. One can check that this is indeed a weighted inner product space. This is a generalisation of the classical fact that every vector ")#mi("{v_*}")#text(" in an inner product space ")#mi("{V}")#text(" naturally defines a linear functional ")#mi("{w \\mapsto \\langle w, v_* \\rangle}")#text(" on ")#mi("{V}")#text(". In the case of the Gowers uniformity spaces with ")#mi("{v_* := 1}")#text(", this construction takes ")#mi("{U^A(G)}")#text(" to ")#mi("{U^B(G)}")#text("; similarly for the Gowers box spaces.")

#heading(level: 1)[#strong[#text(" — 3. Basic theory — ")]]

#text("Let ")#mi("{V}")#text(" be an inner product space of order ")#mi("{A}")#text(" for some finite non-empty ")#mi("{A}")#text(". The splitting axiom tells us that")

#align(center)[#tao-fit-display[#mitex("\\langle F_0 \\otimes_i \\overline{F_1} \\rangle_A = \\langle F_0, F_1 \\rangle_{A \\backslash \\{i\\}}")]]

#text("for all ")#mi("{i \\in A}")#text(", ")#mi("{F_0, F_1 \\in V^{[A \\backslash \\{i\\}]}}")#text(", and some inner product ")#mi("{\\langle, \\rangle}")#text(" on ")#mi("{X^{[A \\backslash \\{i\\}]}}")#text(". In particular one has")

#align(center)[#tao-fit-display[#mitex("\\langle F \\otimes_i \\overline{F} \\rangle_A \\geq 0")]]

#text("for all ")#mi("{F \\in V^{[A \\backslash \\{i\\}]}}")#text(", as well as the classical Cauchy-Schwarz inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle F_0 \\otimes_i \\overline{F_1} \\rangle_A\\right| \\leq \\left|\\langle F_0 \\otimes_i \\overline{F_0} \\rangle_A\\right|^{1/2} \\left|\\langle F_1 \\otimes_i \\overline{F_1} \\rangle_A\\right|^{1/2}.", block: true)]]

#text("If we specialise this inequality to the tensor products")

#align(center)[#tao-fit-display[#tao-math("F_a := \\bigotimes_{\\omega^{\\prime} \\in \\{0,1\\}^{A \\backslash \\{i\\}}} {\\mathcal C}^{\\left|\\omega^{\\prime}\\right|} v_{a,\\omega^{\\prime}}", block: true)]]

#text("for various ")#mi("{v_{a,\\omega^{\\prime}} \\in V}")#text(", one concludes that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle \\bigotimes_{\\omega \\in \\{0,1\\}^A} {\\mathcal C}^{\\left|\\omega\\right|} v_\\omega \\rangle_A\\right| \\leq \\prod_{a \\in \\{0,1\\}} \\left|\\langle \\bigotimes_{\\omega \\in \\{0,1\\}^A} {\\mathcal C}^{\\left|\\omega\\right|} v_{a,\\omega^{\\prime}} \\rangle_A\\right|^{1/2}", block: true)]]

#text("where we write ")#mi("{\\omega = (\\omega_i, \\omega^{\\prime})}")#text(" for some ")#mi("{\\omega_i \\in\\{0,1\\}}")#text(" and ")#mi("{\\omega^{\\prime} \\in \\{0,1\\}^{A \\backslash \\{i\\}}}")#text(". If we iterate this inequality once for each ")#mi("{i \\in A}")#text(", we obtain the ")#emph[#text("Cauchy-Schwarz-Gowers inequality")]

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle \\bigotimes_{\\omega \\in \\{0,1\\}^A} {\\mathcal C}^{\\left|\\omega\\right|} v_\\omega \\rangle_A\\right| \\leq \\prod_{\\omega \\in \\{0,1\\}^A} \\left\\|v_\\omega\\right\\|_A", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#tao-math("\\left\\| v \\right\\|_A := \\left|\\langle \\bigotimes_{\\omega \\in \\{0,1\\}^A} {\\mathcal C}^{\\left|\\omega\\right|} v \\rangle_A\\right|^{1/2^{\\left|A\\right|}}.", block: true)]]

#text("The quantity ")#tao-math("{\\left\\|v\\right\\|_A}", block: false)#text(" is clearly non-negative and homogeneous. We also have the ")#emph[#text("Gowers triangle inequality")]

#align(center)[#tao-fit-display[#tao-math("\\left\\|v_0+v_1\\right\\|_A \\leq \\left\\|v_0\\right\\|_A + \\left\\|v_1\\right\\|_A,", block: true)]]

#text("which makes ")#mi("{\\|\\|_A}")#text(" a semi-norm (and in fact a norm, if the inner product space was positive definite). To see this inequality, we first raise both sides to the power ")#tao-math("{2^{\\left|A\\right|}}", block: false)#text(":")

#align(center)[#tao-fit-display[#tao-math("\\left\\|v_0+v_1\\right\\|_A^{2^{\\left|A\\right|}} \\leq (\\left\\|v_0\\right\\|_A + \\left\\|v_1\\right\\|_A)^{2^{\\left|A\\right|}}.", block: true)]]

#text("The left-hand side can be expanded as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle \\bigotimes_{\\omega \\in \\{0,1\\}^A} {\\mathcal C}^{\\left|\\omega\\right|} (v_0+v_1) \\rangle_A\\right|", block: true)]]

#text("which after expanding out using linearity and the triangle inequality, can be bounded by")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\alpha \\in \\{0,1\\}^{\\{0,1\\}^A}} \\left|\\langle \\bigotimes_{\\omega \\in \\{0,1\\}^A} {\\mathcal C}^{\\left|\\omega\\right|} v_{\\alpha_\\omega} \\rangle_A\\right|", block: true)]]

#text("which by the Cauchy-Schwarz-Gowers inequality can be bounded in turn by")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\alpha \\in \\{0,1\\}^{\\{0,1\\}^A}} \\prod_{\\omega \\in \\{0,1\\}^A} \\left\\| v_{\\alpha_\\omega} \\right\\|_A", block: true)]]

#text("which can then be factored into ")#tao-math("{(\\left\\|v_0\\right\\|_A + \\left\\|v_1\\right\\|_A)^{2^{\\left|A\\right|}}}", block: false)#text(" as required.")

#text("Note that when ")#mi("{A}")#text(" is a singleton set, the above argument collapses to the usual derivation of the triangle inequality from the classical Cauchy-Schwarz inequality. It is also instructive to see how this collapses to one of the standard proofs of the triangle inequality for ")#mi("{L^{2^k}(X)}")#text(" using a large number of applications of the Cauchy-Schwarz inequality.")

#text("In analogy with classical Hilbert spaces, one can define a ")#emph[#text("Hilbert space of order ")#mi("{A}")]#text(" to be an inner product space ")#mi("{V}")#text(" of order ")#mi("{A}")#text(" which is both positive definite and complete, so that the norm ")#mi("{\\| \\|_A}")#text(" gives ")#mi("{V}")#text(" the structure of a Banach space. A typical example is ")#mi("{U^2(G)}")#text(" for a finite abelian ")#mi("{G}")#text(", which is the space of all functions ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" with the norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^2(G)} = \\left\\|\\hat f\\right\\|_{\\ell^4(\\hat G)}", block: true)]]

#text("where ")#mi("{\\hat G}")#text(" is the Pontraygin dual of ")#mi("{G}")#text(" (i.e. the space of homomorphisms ")#mi("{\\xi: x \\mapsto \\xi \\cdot x}")#text(" from ")#mi("{G}")#text(" to ")#mi("{{\\bf R}/{\\bf Z}}")#text(") and ")#mi("{\\hat f(\\xi) := \\mathop{\\bf E}_{x \\in G} f(x) e(-\\xi \\cdot x)}")#text(" is the Fourier transform. Thus we see that ")#mi("{\\ell^4(\\hat G)}")#text(" is a Hilbert space of order ")#mi("{2}")#text(". More generally, ")#mi("{L^{2^k}(X)}")#text(" for any measure space ")#mi("{X}")#text(" and any ")#mi("{k \\geq 0}")#text(" can be viewed as a Hilbert space of order ")#mi("{k}")#text(".")

#text("The Gowers norms ")#mi("{U^d(G)}")#text(" and Gowers-Host-Kra norms ")#mi("{U^d(X)}")#text(" coincide in the model case when ")#mi("{X=G={\\bf Z}/N{\\bf Z}}")#text(" is a cyclic group with uniform measure and the standard shift ")#mi("{T: x \\mapsto x+1}")#text(". Also, the Gowers norms ")#mi("{U^d(G)}")#text(" can be viewed as a special case of the box norms via the identity")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^d(G)} := \\left\\| f \\circ s \\right\\|_{\\Box^d(G^d)}", block: true)]]

#text("where ")#mi("{s: G^d \\rightarrow G}")#text(" is the summation operation ")#mi("{s(x_1,\\ldots,x_d) := x_1+\\ldots+x_d}")#text(".")

#text("Just as classical inner product spaces can be made positive definite by quotienting out the norm zero elements, and then made into a classical Hilbert space by metric completion, inner product spaces of any order can also be made positive definite and completed. One can apply this procedure for instance to obtain the completed Gowers box spaces ")#mi("{\\Box^A(X)}")#text(" and the completed Gowers-Host-Kra spaces ")#mi("{U^A(X)}")#text(" (which become ")#tao-math("{L^{2^{\\left|A\\right|}}(X)}", block: false)#text(" when the shift ")#mi("{T}")#text(" is trivial). These spaces are related, but not equal, to their Lebesgue counterparts ")#mi("{L^p(X)}")#text("; for instance for the Gowers-Host-Kra spaces in the ergodic setting, a repeated application of Young’s inequality reveals the inequalities")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^{A}(X)} \\leq \\left\\|f\\right\\|_{L^{2^{\\left|A\\right|}/(\\left|A\\right|+1)}(X)} \\leq \\left\\|f\\right\\|_{L^\\infty(X)},", block: true)]]

#text("and so ")#mi("{U^A(X)}")#text(" contains a (quotient) of ")#tao-math("{L^{2^{\\left|A\\right|}/(\\left|A\\right|+1)}(X)}", block: false)#text(".")

#text("The null space of the Gowers-Host-Kra norm ")#mi("{U^A(X)}")#text(" in ")#mi("{L^\\infty(X)}")#text(" in the ergodic case is quite interesting; it turns out to be the space ")#tao-math("{L^\\infty({\\mathcal Z}_{< \\left|A\\right|})^\\perp}", block: false)#text(" of bounded measurable functions ")#mi("{f}")#text(" whose conditional expectation ")#tao-math("{\\mathop{\\bf E}(f|{\\mathcal Z}_{<\\left|A\\right|}}", block: false)#text(" on the ")#emph[#text("characteristic factor")]#text(" ")#tao-math("{{\\mathcal Z}_{< \\left|A\\right|}}", block: false)#text(" of order ")#tao-math("{\\left|A\\right|-1}", block: false)#text(" of ")#mi("{X}")#text(" vanishes; in particular, ")#tao-math("{L^\\infty({\\mathcal Z}_{<\\left|A\\right|})}", block: false)#text(" becomes a dense subspace of ")#mi("{U^A(X)}")#text(", embedded injectively. It is a highly non-trivial and useful result, first obtained ")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("by Host and Kra")]#text("), that ")#tao-math("{{\\mathcal Z}_{<\\left|A\\right|}}", block: false)#text(" is the inverse limit of all nilsystem factors of step at most ")#tao-math("{\\left|A\\right|-1}", block: false)#text("; this is the ergodic counterpart of the ")#emph[#text("inverse conjecture for the Gowers norms")]#text(".")

#heading(level: 1)[#strong[#text(" — 4. The category of higher order inner product spaces — ")]]

#text("The higher order Hilbert spaces ")#mi("{L^1(X), L^2(X), L^4(X), L^8(X), \\ldots}")#text(" are related to each other via Hölder’s inequality; the pointwise product of two ")#mi("{L^4}")#text(" functions is in ")#mi("{L^2}")#text(", the product of two ")#mi("{L^8}")#text(" functions is in ")#mi("{L^4}")#text(", and so forth. Furthermore, the inner products on all of these spaces are can be connected to each other via the pointwise product.")

#text("We can generalise this concept, giving the class of inner product spaces (of arbitrary orders) the structure of a category.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2")]#text(" Let ")#mi("{B \\subseteq A}")#text(" be finite sets, and let ")#mi("{V_B = (V_B, \\langle \\rangle_B)}")#text(", ")#mi("{V_A = (V_A, \\langle \\rangle_A)}")#text(" be inner product spaces of order ")#mi("{B, A}")#text(" respectively. An ")#emph[#text("isometry")]#text(" ")#mi("{\\phi}")#text(" from ")#mi("{V_A}")#text(" to ")#mi("{V_B}")#text(" is a linear map")

#align(center)[#tao-fit-display[#tao-math("\\phi: \\bigotimes_{\\omega \\in \\{0,1\\}^{A \\backslash B}} {\\mathcal C}^{\\left|\\omega\\right|} V_A \\rightarrow V_B", block: true)]]

#text("which preserves the inner product in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\langle \\bigotimes_{\\omega \\in \\{0,1\\}^A} {\\mathcal C}^{\\left|\\omega\\right|} v_\\omega \\rangle_A", block: true)]]

#align(center)[#tao-fit-display[#tao-math("= \\langle \\bigotimes_{\\omega^{\\prime} \\in \\{0,1\\}^B} {\\mathcal C}^{\\left|\\omega^{\\prime}\\right|} \\phi( \\bigotimes_{\\omega^{\\prime\\prime} \\in \\{0,1\\}^{A \\backslash B}} {\\mathcal C}^{\\left|\\omega^{\\prime\\prime}\\right|} v_{(\\omega^{\\prime},\\omega^{\\prime\\prime})} ) \\rangle_B,", block: true)]]

#text("where ")#mi("{\\omega^{\\prime}, \\omega^{\\prime\\prime} \\rightarrow (\\omega^{\\prime},\\omega^{\\prime\\prime})}")#text(" is the obvious concatenation map from ")#mi("{\\{0,1\\}^{B} \\times \\{0,1\\}^{A \\backslash B}}")#text(" to ")#mi("{\\{0,1\\}^A}")#text(".")

#text("Given an isometry ")#mi("{\\phi}")#text(" from ")#mi("{V_A}")#text(" to ")#mi("{V_B}")#text(", and an isometry ")#mi("{\\psi}")#text(" from ")#mi("{V_B}")#text(" to ")#mi("{V_C}")#text(" for some ")#mi("{C \\subset B \\subset A}")#text(", one can form the composition")

#align(center)[#tao-fit-display[#tao-math("\\psi \\circ \\phi: \\bigotimes_{\\omega \\in \\{0,1\\}^{A \\backslash C}} {\\mathcal C}^{\\left|\\omega\\right|} V_A \\rightarrow V_C", block: true)]]

#text("by the formula")

#align(center)[#tao-fit-display[#tao-math("\\psi \\circ \\phi( \\bigotimes_{\\omega \\in \\{0,1\\}^{A \\backslash C}} {\\mathcal C}^{\\left|\\omega\\right|} v_\\omega )", block: true)]]

#align(center)[#tao-fit-display[#tao-math(":= \\psi( \\bigotimes_{\\omega^{\\prime} \\in \\{0,1\\}^{B \\backslash C}} {\\mathcal C}^{\\left|\\omega^{\\prime}\\right|} \\phi( \\bigotimes_{\\omega^{\\prime\\prime} \\in \\{0,1\\}^{A \\backslash B}} {\\mathcal C}^{\\left|\\omega^{\\prime\\prime}\\right|} v_{(\\omega^{\\prime},\\omega^{\\prime\\prime})}))", block: true)]]

#text("and extending by linearity; one can verify that this continues to be an isometry, and that the class of inner product spaces of arbitrary order together with isomorphisms form a category.")
]

#text("When ")#mi("{A=B}")#text(" is a singleton set, the above concept collapses to the classical notion of an isometry for inner product spaces. Of course, one could specialise to the subcategory of higher order Hilbert spaces if desired. The inner product on a higher order inner product space can now be interpreted as an isometry from that space to the space ")#mi("{{\\bf C}}")#text(" (viewed as an inner product space of order ")#mi("{\\emptyset}")#text("), and is the unique such isometry; in the language of category theory, this space ")#mi("{{\\bf C}}")#text(" becomes the ")#link("http://en.wikipedia.org/wiki/Terminal_object")[#text("terminal object")]#text(" of the category.")

#text("A model example of an isometry is the sesquilinear product map ")#mi("{f, g \\mapsto f \\overline{g}}")#text(", which is an isometry from ")#mi("{L^{2^d}(X)}")#text(" to ")#mi("{L^{2^{d-1}}(X)}")#text(" for any ")#mi("{d \\geq 1}")#text(". For the Gowers-Host-Kra norms, the map ")#mi("{f, g \\mapsto f \\otimes \\overline{g}}")#text(" is an isometry from ")#mi("{U^d(X^{[k]})}")#text(" to ")#mi("{U^{d-1}(X^{[k+1]})}")#text(" for any ")#mi("{d \\geq 2}")#text(" and ")#mi("{k \\geq 0}")#text(".")

#text("To see analogous isometries for the Gowers uniformity norms, one has to generalise these norms to the “non-ergodic” setting when one does not average the shift parameter ")#mi("{h}")#text(" over the entire group ")#mi("{G}")#text(", but on a subgroup ")#mi("{H}")#text(". Specifically, for finite additive groups ")#mi("{H \\leq G}")#text(" and functions ")#mi("{f_\\omega: G \\rightarrow {\\bf C}}")#text(" with ")#mi("{\\omega \\in \\{0,1\\}^A}")#text(", define the ")#emph[#text("local Gowers inner product")]

#align(center)[#tao-fit-display[#tao-math("\\langle \\otimes_{\\omega \\in \\{0,1\\}^A} {\\mathcal C}^{\\left|\\omega\\right|} f_\\omega \\rangle_{U^A(G,H)} = \\mathop{\\bf E}_{x \\in G, h_i \\in H \\forall i \\in A} \\prod_{\\omega \\in \\{0,1\\}^A} {\\mathcal C}^{\\left|\\omega\\right|} f_\\omega(x + \\sum_{i=1}^A \\omega_i h_i ).", block: true)]]

#text("By foliating ")#mi("{G}")#text(" into cosets of ")#mi("{H}")#text(", one can express this local Gowers inner product as an amalgam of the ordinary Gowers inner product and a Lebesgue inner product. For instance, one has the identity")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^A(G,H)} = (\\sum_{y \\in G/H} \\left\\| f(\\cdot+y) \\right\\|_{U^A(H)}^{2^{\\left|A\\right|}})^{1/2^{\\left|A\\right|}}.", block: true)]]

#text("We define the inner product space ")#mi("{U^A(G,H)}")#text(" to be the space of functions from ")#mi("{G}")#text(" to ")#mi("{{\\bf C}}")#text(" with the above inner product. Given any ")#mi("{j \\in A}")#text(", we can then create an isometry ")#mi("{\\Delta = \\Delta_j}")#text(" from ")#mi("{U^A(G,H)}")#text(" to ")#mi("{U^{A \\backslash \\{j\\}}( G \\times H, H )}")#text(" by defining")

#align(center)[#tao-fit-display[#mitex("\\Delta( f, f^{\\prime} )( x, h ) := f(x+h) \\overline{f^{\\prime}(x)}.")]]

#text("(This isometry does not ostensibly depend on ")#mi("{j}")#text(", except through the labels of the inner product of the target space ")#mi("{U^{A \\backslash \\{j\\}}( G \\times H, H )}")#text(" of the isometry.)")

#text("One can obtain analogous isometries for the Gowers box norms after similarly generalising to “non-ergodic” settings; we leave this as an exercise to the interested reader.")

#text("Actually, the “derivative maps” from inner product spaces ")#mi("{V_A}")#text(" of order ")#mi("{A}")#text(" to those of order ")#mi("{A \\backslash \\{j\\}}")#text(" can be constructed abstractly. Indeed, one can view ")#mi("{V_A \\otimes \\overline{V_A}}")#text(" as an inner product space of order ")#mi("{A \\backslash \\{j\\}}")#text(" with the inner product defined on tensor products by")

#align(center)[#tao-fit-display[#tao-math("\\langle \\bigotimes_{\\omega^{\\prime} \\in \\{0,1\\}^{A \\backslash \\{j\\}}} {\\mathcal C}^{\\left|\\omega^{\\prime}\\right|} ( v_{\\omega^{\\prime},0} \\otimes \\overline{v_{\\omega^{\\prime},1}} ) \\rangle_{A \\backslash \\{j\\}}", block: true)]]

#align(center)[#tao-fit-display[#tao-math(":= \\langle \\bigotimes_{(\\omega^{\\prime},\\omega_j) \\in \\{0,1\\}^A} {\\mathcal C}^{\\left|(\\omega^{\\prime},\\omega_j)\\right|} v_{\\omega^{\\prime},\\omega_j} \\rangle_A", block: true)]]

#text("and then the map ")#mi("{v, w \\mapsto v \\otimes \\overline{w}}")#text(" is an isometry. One can iterate this construction and obtain a ")#emph[#text("cubic complex")]#text(" of inner product spaces")

#align(center)[#tao-fit-display[#tao-math("V_B := \\bigotimes_{\\omega \\in \\{0,1\\}^{A \\backslash B}} {\\mathcal C}^{\\left|\\omega\\right|} V_A", block: true)]]

#text("of order ")#mi("{B}")#text(" for each ")#mi("{B \\subset A}")#text(", together with a commuting system of derivative isometries ")#mi("{\\Delta}")#text(" from ")#mi("{V_B}")#text(" to ")#mi("{V_{B \\backslash \\{j\\}}}")#text(" for each ")#mi("{j \\in B \\subset A}")#text(".")

#text("Conversely, one can use cubic complexes to build higher order inner product spaces:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3")]#text(" Let ")#mi("{A}")#text(" be a finite set. For each ")#mi("{B \\subset A}")#text(", suppose that we have a vector space ")#mi("{V_B}")#text(" equipped with a ")#mi("{\\{0,1\\}^B}")#text("-sesquilinear form")

#align(center)[#tao-fit-display[#tao-math("\\langle \\rangle_B: \\bigotimes_{\\omega\\in \\{0,1\\}^B} {\\mathcal C}^{\\left|\\omega\\right|} V_B \\rightarrow {\\bf C}", block: true)]]

#text("and suppose that for each ")#mi("{j \\in B}")#text(" one has a sesquilinear product")

#align(center)[#tao-fit-display[#mitex("\\Delta_{B \\rightarrow B \\backslash \\{j\\}}: V_B \\otimes \\overline{V_B} \\rightarrow V_{B \\backslash \\{j\\}}")]]

#text("obeying the compatibility conditions")

#align(center)[#tao-fit-display[#tao-math("\\langle \\bigotimes_{\\omega\\in \\{0,1\\}^B} {\\mathcal C}^{\\left|\\omega\\right|} v_\\omega \\rangle_B", block: true)]]

#align(center)[#tao-fit-display[#mitex("= \\langle \\bigotimes_{\\omega^{\\prime} \\in \\{0,1\\}^{B \\backslash \\{j\\}}} \\Delta_{B \\rightarrow B \\backslash \\{j\\}}( v_{(\\omega^{\\prime},0)}, v_{(\\omega^{\\prime},1)} ) \\rangle_{B \\backslash \\{j\\}}")]]

#text("whenever ")#mi("{v_\\omega \\in V_B}")#text(" for all ")#mi("{\\omega \\in \\{0,1\\}^B}")#text(". Suppose also that the form ")#mi("{\\langle \\rangle_{\\{j\\}}}")#text(" is a classical inner product on ")#mi("{V_{\\{j\\}}}")#text(" for every ")#mi("{j \\in A}")#text(". Then for each ")#mi("{B \\subset A}")#text(", ")#mi("{V_B}")#text(" is an inner product space of order ")#mi("{j}")#text(", and the maps ")#mi("{\\Delta_{B \\rightarrow B \\backslash \\{j\\}}}")#text(" become isometries.")
]

#text("This proposition is established by an easy induction on the cardinality of ")#mi("{B}")#text(". Note that we do not require the derivative maps ")#mi("{\\Delta_{B \\rightarrow B \\backslash \\{j\\}}}")#text(" to commute with each other, although this is almost always the case in applications.")

#text("[")#emph[#text("Update, May 20")]#text(": added section on cubic complexes.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (17)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec5f78731edc201d99268e7ee5bebd4048b4ac34c2179a7eaef3942d18742858-f9923df6c91dc1e48da7945d10b89b1991a00ed102e3db0c701993c9edb15aac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt Leifer")]], [#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/#comment-44994")[#strong[#text("Matt Leifer")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2010")])]

#text("Where is the best place to get some further background on the Gower’s norms? Is there a review article?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/#comment-44995")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2010")])]

#text("One can try Section 11.1 of ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("my book with Van")]#text(", or ")#link("https://terrytao.wordpress.com/category/teaching/254b-higher-order-fourier-analysis/")[#text("my lecture notes")]#text(" in my current course on higher Fourier analysis (starting with ")#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/")[#text("Notes 3")]#text("). Ben Green also has ")#link("http://www.arxiv.org/abs/math.CA/0604089")[#text("some notes on quadratic Fourier analysis")]#text(" for a conference in Montreal which is also quite relevant.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tou")]], [#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/#comment-45005")[#strong[#text("tou")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2010")])]

#text("Dear Prof.Tao:")#linebreak()#text(" First thank you for your posts.")#linebreak()#text(" At first I must say Im not a mathematican at all.But I am curious about some thing to ask.I dont know where it is suitable to ask so please forgive me to put it on here.")

#text("It is well known that alge-geom was changed by brought in language of scheme.")#linebreak()#text(" It is said that it is not necessary for a beginner to study “old-fashion-stuff” to enter that fields.Because it became more abstract and more different from the origin.")

#text("So what I want to know is that is AddCom going through the same change as alge-geom were?")

#text("It seems that many researchers created or bring in many new concepts into the field such as Higher Order FA,nilsequence,regularity lemma, etc and I am not be able to see any connection with additive and combinatorics.So I wonder is that means AddCom have already became as abstract as Alge-geom.")

#text("Im very poor in knowledge of this fields so maybe this is a stupid question,but I would be very appreciate if anyone would like to clearify that for me.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/#comment-45017")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2010")])]

#text("I think we are getting closer to having a natural and conceptual framework for the subject, but it will probably evolve a little more. Additive combinatorics has already evolved a fair way from its roots in additive number theory and combinatorial number theory (most notably, by moving the focus away from the integers, or on special subsets of integers such as the squares or the primes, though these are of course still an important special case). Given the remarkable interconnections between additive combinatorics and ergodic theory, Fourier analysis, graph theory, geometric group theory, and even model theory and cohomology, it seems clear to me that there should be a more unified perspective that should come more into focus in the near future.")

#text("The distinction between having an abstract framework and a concrete one (or between geometric and algebraic, etc.) seems to me to be a false dichotomy, though. I think a field is healthiest when there are multiple overlapping perspectives that are compatible with and complement each other. For instance, the classical approach to algebraic geometry based on varieties and solutions to polynomial equations via elimination, invariants, etc. is still hugely important, and has been improved by the scheme-theoretic perspective rather than supplanted by it. (I myself recently used this classical theory in a paper with Ben and Emmanuel on expansion in groups; to deal with issues such as complexity of varieties, it seems better to use the classical approach than the scheme-theoretic one, at least with the current state of the art.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tou")]], [#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/#comment-45039")[#strong[#text("tou")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2010")])]

#text("Thank you very much for your answer Prof.Tao. I think I really need to read more math :)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of johnny :)")]], [#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/#comment-45016")[#strong[#text("johnny :)")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2010")])]

#text("that’s wicked :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of richard borcherds")]], [#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/#comment-45263")[#strong[#text("richard borcherds")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2010")])]

#text("A higher order inner product on a space V reminds me of a state w on the tensor algebra TV of V, as in operator algebra theory, though this would give maps from all tensor powers of V to C, not just the ones corresponding to powers of 2. These things turn up in the construction of free quantum field theories, when V is the space of 1-particle states, and w encodes the Wightman distributions of the qft. I cant figure out if this has anything to do with additive combinatorics as I’m still confused your notation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/#comment-45264")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2010")])]

#text("Yes, a higher order inner product is a special type of tensor state. I think the power of two restriction is needed in order to get Hilbert-like positivity properties; possibly there would be inner products for any even exponent with some positivity (e.g. the L^6 inner product, coming from the diagonal state over 6-tensors) but most of the Hilbert-like structure seems to be lost in those cases.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/181769477cf0e1352f672b71d0f46979bc8feb8b99f4b1bc23f45d2a241e4a15-6884cfdbbd97d010c43586528bf5830891bf81b69bd1e720a9ded593daa486de.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hilbert spaces from the mathematician’s perspective « Polariton")]], [#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/#comment-46723")[#strong[#text("Hilbert spaces from the mathematician’s perspective « Polariton")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2010")])]

#text("[…] Higher order Hilbert spaces Possibly related posts: (automatically generated)The Intermission 02/28/09Chorin-Temem Projection methodWelcome to Hilbert College Blog Categories: Links, Mathematics, Quantum, Recommendations Comments (0) Trackbacks (0) Leave a comment Trackback […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Higher order Fourier analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/#comment-51106")[#strong[#text("Higher order Fourier analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2011")])]

#text("[…] based primarily on my graduate course in the topic, though it also contains material from some additional posts related to linear and higher order Fourier analysis on the blog. It is available online […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/474d871e676fb0041078243243605e5d9885b665d0662559ae911400eb7c8ed1-c9ffea11b43eb65fa18e49f5eccfe64e1014c6e48071ddf24b2585caef04bd27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S")]], [#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/#comment-52739")[#strong[#text("S")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2011")])]

#text("Prof Tao, you write above that the Gowers spaces are initially incomplete. I am trying to see this explicitly for the normed space of complex measurable functions on the circle R/Z with finite Gowers U2 norm. Do you have an example showing this space is not complete? Thank you")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/#comment-52740")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2011")])]

#text("In this case, the complete ")#mi("U^2")#text(" space is the space of distributions on the unit circle whose Fourier transform has finite ")#mi("\\ell^4")#text(" norm (and is thus isomorphic to ")#mi("\\ell^4({\\bf Z})")#text(". The incomplete space of ")#emph[#text("bounded")]#text(" functions on the unit circle is dense in the complete ")#mi("U^2")#text(" but is not all of ")#mi("U^2")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/474d871e676fb0041078243243605e5d9885b665d0662559ae911400eb7c8ed1-c9ffea11b43eb65fa18e49f5eccfe64e1014c6e48071ddf24b2585caef04bd27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S")]], [#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/#comment-52885")[#strong[#text("S")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2011")])]

#text("Thank you for your reply. Sorry if this is naive but does this incompleteness persist if one restricts the range of the functions? For instance I would very much like to see an explicit example of a sequence of [-1,1]-valued functions on the circle which is Cauchy in the U2 norm and yet does not converge in U2 to a [-1,1]-valued function. Even more restricted: can a sequence of indicator functions on the circle be Cauchy in U2 yet not converge to an indicator function (or even a real valued function) in U2? Thank you for your time.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/#comment-52889")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2011")])]

#text("For your first question, the answer is no; U^2 convergence implies weak convergence, which preserves bounds on the range (cf. the standard fact that the closed unit ball in a normed vector space is always weakly closed).")

#text("For your second question, the answer is yes. For instance, divide the circle into N congruent intervals and let f_N be a random function that, on each such interval, is either equal to the constant +1 or the constant 0 with equal probability of each, with the sign being independent on each interval. One can then show (by Borel-Cantelli and concentration of measure) that almost surely, f_N converges in U^2 to the constant function 1/2.")

#text("More generally, one can think of convergence in U^2 (or higher) norms as a strengthened version of weak convergence which “knows” about additive structure (but cannot “see” sufficiently pseudorandom behaviour).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Furstenberg limits of the Liouville function | What's new")]], [#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/#comment-478886")[#strong[#text("Furstenberg limits of the Liouville function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("[…] factor of ; equivalently, the first Gowers-Host-Kra seminorm of (as defined for instance in this previous post) vanishes. The Chowla conjecture, which asserts […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/#comment-640758")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2022")])]

#text("A few somewhat vague questions, but that hopefully will make sense. Is there a notion of adjoint of an operator in a higher order space like this? Or maybe an analogue of what a “TT*” argument is to prove that certain operators are bounded?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/#comment-640762")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2022")])]

#text("Higher order spaces are normed vector spaces, so one can define adjoints in the usual fashion. In addition there is also the useful concept of a “dual function”: for instance, in a second order Hilbert space (with inner product that I will denote by ")#mi("U^2")#text(") that is also equipped with a usual inner product (which I’ll denote as ")#mi("L^2")#text("), any three functions ")#mi("f,g,h")#text(" in this space can (in principle at least) generate a dual function ")#mi("{\\mathcal D}(f,g,h)")#text(" by the formula")

#mi("\\centerline k, \\langle {\\mathcal D}(f,g,h) \\rangle_{L^2} = \\langle k, f, g, h \\rangle_{U^2}.")#text("$")

#text("These dual functions play an important role in the structural theory of spaces such as the Gowers norm spaces ")#mi("U^k(G)")#text(" or the Host-Kra seminorm spaces ")#mi("U^k(X)")#text(". Perhaps an analogue to the TT^* method in this context is the method of “stashing” a dual function in one of the inputs of a multilinear form, as used for instance recently ")#link("https://arxiv.org/abs/2109.05731")[#text("by Manners")]#text(".")
]
]
