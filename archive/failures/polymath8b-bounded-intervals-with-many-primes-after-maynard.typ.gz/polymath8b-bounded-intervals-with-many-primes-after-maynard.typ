// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/
// Converted to Typst by tao2typ: "2026-10-14T09:34:47.251811+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath8b: Bounded intervals with many primes, after Maynard", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath8b: Bounded intervals with many primes, after Maynard")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 November 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/")[#text("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("For each natural number ")#mi("{m}")#text(", let ")#mi("{H_m}")#text(" denote the quantity")

#align(center)[#tao-fit-display[#mitex("H_m := \\liminf_{n \\rightarrow\\infty} (p_{n+m} - p_n),")]]

#text("where ")#mi("{p_n}")#text(" denotes the ")#mi("{n\\textsuperscript{th}}")#text(" prime. In other words, ")#mi("{H_m}")#text(" is the least quantity such that there are infinitely many intervals of length ")#mi("{H_m}")#text(" that contain ")#mi("{m+1}")#text(" or more primes. Thus, for instance, the twin prime conjecture is equivalent to the assertion that ")#mi("{H_1 = 2}")#text(", and the ")#link("http://en.wikipedia.org/wiki/Prime_k-tuple")[#text("prime tuples conjecture")]#text(" would imply that ")#mi("{H_m}")#text(" is equal to the diameter of the narrowest admissible tuple of cardinality ")#mi("{m+1}")#text(" (thus we conjecturally have ")#mi("{H_1 = 2}")#text(", ")#mi("{H_2 = 6}")#text(", ")#mi("{H_3 = 8}")#text(", ")#mi("{H_4 = 12}")#text(", ")#mi("{H_5 = 16}")#text(", and so forth; see ")#link("http://math.mit.edu/~primegaps/")[#text("this web page")]#text(" for further continuation of this sequence).")

#text("In 2004, ")#link("http://www.ams.org/mathscinet-getitem?mr=2552109")[#text("Goldston, Pintz, and Yildirim")]#text(" established the bound ")#mi("{H_1 \\leq 16}")#text(" conditional on the ")#link("http://en.wikipedia.org/wiki/Elliott%E2%80%93Halberstam_conjecture")[#text("Elliott-Halberstam conjecture")]#text(", which remains unproven. However, no unconditional finiteness of ")#mi("{H_1}")#text(" was obtained (although they famously obtained the non-trivial bound ")#mi("{p_{n+1}-p_n = o(\\log p_n)}")#text("), and even on the Elliot-Halberstam conjecture no finiteness result on the higher ")#mi("{H_m}")#text(" was obtained either (although they were able to show ")#mi("{p_{n+2}-p_n=o(\\log p_n)}")#text(" on this conjecture). In the recent ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("breakthrough of Zhang")]#text(", the unconditional bound ")#mi("{H_1 \\leq 70,000,000}")#text(" was obtained, by establishing a weak partial version of the Elliott-Halberstam conjecture; by refining these methods, the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8 project")]#text(" (which I suppose we could retroactively call the Polymath8a project) then lowered this bound to ")#mi("{H_1 \\leq 4,680}")#text(".")

#text("With the ")#link("http://arxiv.org/abs/1311.4600")[#text("very recent preprint of James Maynard")]#text(", we have the following further substantial improvements:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Maynard’s theorem)")]#text(" ")#metadata(none) <tao-17bdbe4eff51a93c5714>#text(" Unconditionally, we have the following bounds:")

#list(
[#mi("{H_1 \\leq 600}")#text(".")],
[#mi("{H_m \\leq C m^3 e^{4m}}")#text(" for an absolute constant ")#mi("{C}")#text(" and any ")#mi("{m \\geq 1}")#text(".")]
)

#text("If one assumes the Elliott-Halberstam conjecture, we have the following improved bounds:")

#list(
[#mi("{H_1 \\leq 12}")#text(".")],
[#mi("{H_2 \\leq 600}")#text(".")],
[#mi("{H_m \\leq C m^3 e^{2m}}")#text(" for an absolute constant ")#mi("{C}")#text(" and any ")#mi("{m \\geq 1}")#text(".")]
)
]

#text("The final conclusion ")#mi("{H_m \\leq C m^3 e^{2m}}")#text(" on Elliott-Halberstam is not explicitly stated in Maynard’s paper, but follows easily from his methods, as I will describe below the fold. (At around the same time as Maynard’s work, I had also begun a similar set of calculations concerning ")#mi("{H_m}")#text(", but was only able to obtain the slightly weaker bound ")#mi("{H_m \\leq C \\exp( C m )}")#text(" unconditionally.) In the converse direction, the prime tuples conjecture implies that ")#mi("{H_m}")#text(" should be comparable to ")#mi("{m \\log m}")#text(". ")#link("http://www.dms.umontreal.ca/~andrew/CEBBrochureFinal.pdf")[#text("Granville has also obtained")]#text(" the slightly weaker explicit bound ")#mi("{H_m \\leq e^{8m+5}}")#text(" for any ")#mi("{m \\geq 1}")#text(" by a slight modification of Maynard’s argument.")

#text("The arguments of Maynard avoid using the difficult partial results on (weakened forms of) the Elliott-Halberstam conjecture that were established by Zhang and then refined by Polymath8; instead, the main input is the classical ")#link("http://en.wikipedia.org/wiki/Bombieri-Vinogradov_theorem")[#text("Bombieri-Vinogradov theorem")]#text(", combined with a sieve that is closer in spirit to an ")#link("http://www.ams.org/mathscinet-getitem?mr=2368279")[#text("older sieve of Goldston and Yildirim")]#text(", than to the sieve used later ")#link("http://www.ams.org/mathscinet-getitem?mr=2552109")[#text("by Goldston, Pintz, and Yildirim")]#text(" on which almost all subsequent work is based.")

#text("The aim of the Polymath8b project is to obtain improved bounds on ")#mi("{H_1, H_2}")#text(", and higher values of ")#mi("{H_m}")#text(", either conditional on the Elliott-Halberstam conjecture or unconditional. The likeliest routes for doing this are by optimising Maynard’s arguments and/or combining them with some of the results from the Polymath8a project. This post is intended to be the first research thread for that purpose. To start the ball rolling, I am going to give below a presentation of Maynard’s results, with some minor technical differences (most significantly, I am using the Goldston-Pintz-Yildirim variant of the Selberg sieve, rather than the traditional “elementary Selberg sieve” that is used by Maynard (and also in the Polymath8 project), although it seems that the numerology obtained by both sieves is essentially the same). An alternate exposition of Maynard’s work has ")#link("http://www.dms.umontreal.ca/~andrew/CEBBrochureFinal.pdf")[#text("just been completed also by Andrew Granville")]#text(".")

#metadata(none) <tao-82c61b3d8b9b8886e754>

#heading(level: 1)[#strong[#text(" — 1. Overview of argument — ")]]

#text("Define an ")#emph[#text("admissible ")#mi("{k_0}")#text("-tuple")]#text(" to be an increasing tuple ")#mi("{{\\cal H} = (h_1,\\ldots,h_{k_0})}")#text(" of integers, which avoids at least one residue class modulo ")#mi("{p}")#text(" for each ")#mi("{p}")#text(". For ")#mi("{1 \\leq j_0 \\leq k_0}")#text(", let ")#mi("{DHL[k_0,j_0]}")#text(" denote the following claim:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2")]#text(" (")#mi("{DHL[k_0,j_0]}")#text(") If ")#mi("{{\\cal H}}")#text(" is an admissible ")#mi("{k_0}")#text("-tuple, then there are infinitely many translates ")#mi("{n + {\\cal H}}")#text(" of ")#mi("{{\\cal H}}")#text(" that contain at least ")#mi("{j_0}")#text(" primes.")
]

#text("The prime tuples conjecture is then the assertion that ")#mi("{DHL[k_0,j_0]}")#text(" holds for all ")#mi("{k_0,j_0}")#text(". Clearly, if ")#mi("{DHL[k_0,m+1]}")#text(" is true, then we have ")#mi("{H_m \\leq h_{k_0}-h_1}")#text(" whenever ")#mi("{(h_1,\\ldots,h_{k_0})}")#text(" is an admissible ")#mi("{k_0}")#text("-tuple. Theorem ")#link(<tao-17bdbe4eff51a93c5714>)[#text("1")]#text(" then follows from the following claim:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Maynard’s theorem, DHL version)")]#text(" ")#metadata(none) <tao-2d9672cd5a407e540d6a>#text(" Unconditionally, we have the following bounds:")

#list(
[#mi("{DHL[105,2]}")#text(".")],
[#mi("{DHL[k_0,m+1]}")#text(" whenever ")#mi("{k_0}")#text(" is sufficiently large and ")#mi("{4m < \\log k_0 - 2 \\log\\log k_0 - 2}")#text(".")]
)

#text("If one assumes the Elliott-Halberstam conjecture, we have the following improved bounds:")

#list(
[#mi("{DHL[5,2]}")#text(".")],
[#mi("{DHL[105,3]}")#text(".")],
[#mi("{DHL[k_0,m+1]}")#text(" whenever ")#mi("{k_0}")#text(" is sufficiently large and ")#mi("{2m < \\log k_0 - 2 \\log\\log k_0 - 2}")#text(".")]
)
]

#text("Indeed, the ")#mi("{m=1,2}")#text(" results then follow from using the admissible ")#mi("{5}")#text("-tuple ")#mi("{(0,2,6,8,12)}")#text(" and the admissible ")#mi("{105}")#text("-tuple")

#align(center)[#tao-fit-display[#mitex("(0, 10, 12, 24, 28, 30, 34, 42, 48, 52, 54, 64, 70, 72, 78, 82, 90, 94, 100,")]]

#align(center)[#tao-fit-display[#mitex("112, 114, 118, 120, 124, 132, 138, 148, 154, 168, 174, 178, 180, 184, 190,")]]

#align(center)[#tao-fit-display[#mitex("192, 202, 204, 208, 220, 222, 232, 234, 250, 252, 258, 262, 264, 268, 280,")]]

#align(center)[#tao-fit-display[#mitex("288, 294, 300, 310, 322, 324, 328, 330, 334, 342, 352, 358, 360, 364, 372,")]]

#align(center)[#tao-fit-display[#mitex("378, 384, 390, 394, 400, 402, 408, 412, 418, 420, 430, 432, 442, 444, 450,")]]

#align(center)[#tao-fit-display[#mitex("454, 462, 468, 472, 478, 484, 490, 492, 498, 504, 510, 528, 532, 534, 538,")]]

#align(center)[#tao-fit-display[#mitex("544, 558, 562, 570, 574, 580, 582, 588, 594, 598, 600)")]]

#text("found by Engelsma (and recorded on ")#link("http://math.mit.edu/~primegaps/")[#text("this site")]#text("). For the larger ")#mi("{m}")#text(" results, note that the bound ")#mi("{4m < \\log k_0 - 2 \\log\\log k_0 - 2}")#text(" is obeyed if ")#mi("{k_0 \\geq C m^2 e^{4m}}")#text(" for a sufficiently large ")#mi("{C}")#text(" and ")#mi("{m}")#text(" is large enough, and the claim follows by using the observation that one can create an admissible ")#mi("{k_0}")#text("-tuple of length ")#mi("{O( k_0 \\log k_0)}")#text(" by using the first ")#mi("{k_0}")#text(" primes past ")#mi("{k_0}")#text("; similarly if one assumes the Elliott-Halberstam conjecture. (Note as the ")#mi("{H_m}")#text(" are clearly non-decreasing in ")#mi("{m}")#text(", it suffices to work with sufficiently large ")#mi("{m}")#text(" to obtain bounds such as ")#mi("{H_m \\leq C m^3 e^{4m}}")#text(".)")

#text("As in previous work, the ")#mi("{DHL[k_0,m+1]}")#text(" conclusions are obtained by constructing a sieve weight with good properties. We use the same asymptotic notation as in the Polymath8a project, thus all quantities depend on an asymptotic parameter ")#mi("{x}")#text(" unless explicitly declared to be fixed, and asymptotic notation such ")#mi("{O()}")#text(", ")#mi("{o()}")#text(" or ")#mi("{\\ll}")#text(" is relative to this parameter. We let")

#align(center)[#tao-fit-display[#mitex("w := \\lfloor \\log\\log\\log x \\rfloor")]]

#text("and ")#mi("{W := \\prod_{p < w} p}")#text(" as before. We let ")#mi("{\\theta(n)}")#text(" be the quantity ")#mi("{\\log n}")#text(" when ")#mi("{n}")#text(" is prime, and zero otherwise.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Criterion for ")#mi("{DHL}")#text(")")]#text(" ")#metadata(none) <tao-d5963d22f572ba25cba0>#text(" Let ")#mi("{k_0 \\geq 2}")#text(" and ")#mi("{m \\geq 1}")#text(" be fixed integers. Suppose that for each fixed admissible ")#mi("{k_0}")#text("-tuple ")#mi("{{\\cal H}}")#text(" and each congruence class ")#mi("{b\\ (W)}")#text(" such that ")#mi("{b+h}")#text(" is coprime to ")#mi("{W}")#text(" for all ")#mi("{h \\in {\\cal H}}")#text(", one can find a non-negative weight function ")#mi("{\\nu \\colon {\\bf N} \\rightarrow {\\bf R}^+}")#text(", fixed quantities ")#mi("{\\alpha,\\beta > 0}")#text(", a quantity ")#mi("{B>0}")#text(", and a quantity ")#mi("{R>0}")#text(" such that one has the upper bound ")#metadata(none) <tao-e8bc163c82eee1873328>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{x \\leq n \\leq 2x: n = b\\ (W)} \\nu(n) \\leq (\\alpha+o(1)) B\\frac{x}{W},")]]

#text("the lower bound ")#metadata(none) <tao-ad328846aa18b32a3358>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{x \\leq n \\leq 2x: n = b\\ (W)} \\nu(n) \\theta(n+h_i) \\geq (\\beta-o(1)) B\\frac{x}{W} \\log R")]]

#text("for all ")#mi("{h_i \\in {\\cal H}}")#text(", and the key inequality ")#metadata(none) <tao-2c70e12b7a0646f92279>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\frac{\\log R}{\\log x} > \\frac{m}{k_0} \\frac{\\alpha}{\\beta}.")]]

#text("Then ")#mi("{DHL[k_0,m+1]}")#text(" holds.")
]

#text("The ")#mi("{m=1}")#text(" case of this lemma is Lemma 4.1 of the ")#link("https://www.dropbox.com/s/16bei7l944twojr/newgap.pdf")[#text("polymath8a paper")]#text(". The general ")#mi("{m}")#text(" case is proven by an essentially identical argument, namely one considers the expression")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq 2x: n = b\\ (W)} \\nu(n) (\\sum_{i=1}^{k_0} \\theta(n+h_i) - m \\log 3x ),")]]

#text("uses the hypotheses ")#link(<tao-e8bc163c82eee1873328>)[#text("(1)")]#text(", ")#link(<tao-ad328846aa18b32a3358>)[#text("(2)")]#text(", ")#link(<tao-2c70e12b7a0646f92279>)[#text("(3)")]#text(" to show that this is positive for sufficiently large ")#mi("{m}")#text(", and observing that the summand is only positive when ")#mi("{n+h_1,\\ldots,n+h_{k_0}}")#text(" contain at least ")#mi("{m+1}")#text(" primes.")

#text("We recall the statement of the Elliott-Halberstam conjecture, for a given choice of parameter ")#mi("{0 < \\theta < 1}")#text(":")

#metadata(none) <tao-20826672491cd3f1dcc0>#text(" If ")#mi("{Q \\lessapprox x^\\theta}")#text(" and ")#mi("{A \\geq 1}")#text(" is fixed, then ")#metadata(none) <tao-d5ce2b19fbda14a25dea>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\sum_{q \\leq Q} \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\Lambda 1_{[x,2x]}; a\\ (q))\\right| \\ll x \\log^{-A} x", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\Delta(\\alpha; a\\ (q)) := \\sum_{n = a\\ (q)} \\alpha(n) - \\frac{1}{\\phi(q)} \\sum_{(n,q)=1} \\alpha(n).")]]

#text("The Bombieri-Vinogradov theorem asserts that ")#mi("{EH[\\theta]}")#text(" holds for all ")#mi("{0 <\\theta < 1/2}")#text(", while the Elliott-Halberstam conjecture asserts that ")#mi("{EH[\\theta]}")#text(" holds for all ")#mi("{0 < \\theta < 1}")#text(".")

#text("In Polymath8a, the sieve weight ")#mi("{\\nu}")#text(" was constructed in terms of a smooth compactly supported one-variable function ")#mi("{F: [0,+\\infty) \\rightarrow {\\bf R}}")#text(". A key innovation in Maynard’s work is to replace the sieve with one constructed using a smooth compactly supported ")#emph[#text("multi-variable")]#text(" function ")#mi("{f: [0,+\\infty)^{k_0} \\rightarrow {\\bf R}}")#text(", which affords significantly greater flexibility. More precisely, we will show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5 (Sieve asymptotics)")]#text(" ")#metadata(none) <tao-3b517115314ed587be3d>#text(" Suppose that ")#mi("{EH[\\theta]}")#text(" holds for some fixed ")#mi("{0 < \\theta < 1}")#text(", and set ")#mi("{R = x^{c/2}}")#text(" for some fixed ")#mi("{0 < c < \\theta}")#text(". Let ")#mi("{f: [0,+\\infty)^{k_0} \\rightarrow {\\bf R}}")#text(" is a fixed symmetric smooth function supported on the simplex")

#align(center)[#tao-fit-display[#mitex("\\Delta_{k_0} := \\{ (t_1,\\ldots,t_{k_0}) \\in [0,+\\infty)^{k_0}: t_1+\\ldots+t_{k_0} \\leq 1 \\}.")]]

#text("Then one can find ")#mi("{\\nu}")#text(" obeying the bounds ")#link(<tao-e8bc163c82eee1873328>)[#text("(1)")]#text(", ")#link(<tao-ad328846aa18b32a3358>)[#text("(2)")]#text(" with")

#align(center)[#tao-fit-display[#mitex("B := (\\frac{W}{\\phi(W)})^{k_0} \\frac{1}{\\log^{k_0} R}")]]

#metadata(none) <tao-f81ab872625c131d92e7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\alpha := \\int_{\\Delta_{k_0}} f_{1,\\ldots,k_0}(t_1,\\ldots,t_{k_0})^2\\ dt_1 \\ldots dt_{k_0}")]]

#metadata(none) <tao-f096890dbb1b514cf178>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\beta := \\int_{\\Delta_{k_0-1}} f_{1,\\ldots,k_0-1}(t_1,\\ldots,t_{k_0-1},0)^2\\ dt_1 \\ldots dt_{k_0-1}")]]

#text("where we use the shorthand")

#align(center)[#tao-fit-display[#mitex("f_{i_1,\\ldots,i_j}(t_1,\\ldots,t_n) := \\frac{\\partial^j}{\\partial t_{i_1} \\ldots \\partial t_{i_j}} f(t_1,\\ldots,t_n)")]]

#text("for the mixed partial derivatives of ")#mi("{f}")#text(".")

#text("(In fact, one can obtain asymptotics for ")#link(<tao-e8bc163c82eee1873328>)[#text("(1)")]#text(", ")#link(<tao-ad328846aa18b32a3358>)[#text("(2)")]#text(", rather than upper and lower bounds.)")
]

#text("(One can work with non-symmetric functions ")#mi("{f}")#text(", but this does not improve the numerology; see the remark after (7.1) of ")#link("http://arxiv.org/abs/1311.4600")[#text("Maynard’s paper")]#text(".)")

#text("We prove this proposition in Section ")#link(<tao-60bfcc5e146d64155149>)[#text("2")]#text(". We remark that if one restricts attention to functions ")#mi("{f}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("f(t_1,\\ldots,t_k) = F(t_1+\\ldots+t_k)")]]

#text("for ")#mi("{F: [0,+\\infty) \\rightarrow {\\bf R}}")#text(" smooth and supported on ")#mi("{[0,1]}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\alpha = \\int_0^1 f^{(k_0)}(t)^2 \\frac{t^{k_0-1}}{(k_0-1)!}\\ dt")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\beta = \\int_0^1 f^{(k_0-1)}(t)^2 \\frac{t^{k_0-2}}{(k_0-2)!}\\ dt")]]

#text("and this claim was already essentially established back in this ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("Polymath8a post")]#text(" (or see Proposition 4.1 and Lemma 4.7 of the Polymath8a paper for essentially these bounds). In that previous post (and also in the paper of Farkas, Pintz, and Revesz), the ratio ")#mi("{\\alpha/\\beta}")#text(" was optimised in this one-dimensional context using Bessel functions, and the method was unable to reach ")#mi("{m=1}")#text(" without an improvement to Bombieri-Vinogradov, or to reach ")#mi("{m=2}")#text(" even on Elliott-Halberstam. However, the additional flexibility afforded by the use of multi-dimensional cutoffs allows one to do better.")

#text("Combining Proposition ")#link(<tao-3b517115314ed587be3d>)[#text("5")]#text(" with Lemma ")#link(<tao-d5963d22f572ba25cba0>)[#text("4")]#text(", we obtain the following conclusion. For each ")#mi("{k_0}")#text(", let ")#mi("{M_{k_0}}")#text(" be the quantity")

#align(center)[#tao-fit-display[#mitex("M_{k_0} := \\sup_f k_0 \\frac{ \\int_{\\Delta_{k_0-1}} f_{1,\\ldots,k_0-1}(t_1,\\ldots,t_{k_0-1},0)^2\\ dt_1 \\ldots dt_{k_0-1} }{ \\int_{\\Delta_{k_0}} f_{1,\\ldots,k_0}(t_1,\\ldots,t_{k_0})^2\\ dt_1 \\ldots dt_{k_0} }")]]

#text("where ")#mi("{f}")#text(" ranges over all smooth symmetric functions ")#mi("{f: [0,+\\infty)^{k_0} \\rightarrow {\\bf R}}")#text(" that are supported on the simplex ")#mi("{\\Delta_{k_0}}")#text(". Equivalently, by substituting ")#mi("{F := f_{1,\\ldots,k_0}}")#text(" and using the fundamental theorem of calculus, followed by an approximation argument to remove the smoothness hypotheses on ")#mi("{F}")#text(", we have ")#metadata(none) <tao-62a49eb83b518b7b5146>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("M_{k_0} := \\sup_F k_0 \\frac{ \\int_{\\Delta_{k_0-1}} (\\int_0^\\infty F(t_1,\\ldots,t_{k_0-1},t_{k_0})\\ dt_{k_0})^2\\ dt_1 \\ldots dt_{k_0-1} }{ \\int_{\\Delta_{k_0}} F(t_1,\\ldots,t_{k_0})^2\\ dt_1 \\ldots dt_{k_0} }")]]

#text("where ")#mi("{F}")#text(" ranges over all bounded measurable functions supported on ")#mi("{\\Delta_{k_0}}")#text(". Then we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 6")]#text(" ")#metadata(none) <tao-53478db94ea65ea77f0c>#text(" Let ")#mi("{0 < \\theta<1}")#text(" be such that ")#mi("{EH[\\theta]}")#text(" holds, and let ")#mi("{k_0 \\geq 2}")#text(", ")#mi("{m \\geq 1}")#text(" be integers such that")

#align(center)[#tao-fit-display[#mitex("M_{k_0} > \\frac{2m}{\\theta}.")]]

#text("Then ")#mi("{DHL[k_0,m+1]}")#text(" holds.")
]

#text("To use this corollary, we simply have to locate test functions ")#mi("{f}")#text(" that give as large a lower bound for ")#mi("{M_{k_0}}")#text(" as one can manage; this is a purely analytic problem that no longer requires any further number-theoretic input.")

#text("In particular, Theorem ")#link(<tao-2d9672cd5a407e540d6a>)[#text("3")]#text(" follows from the following lower bounds:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7")]#text(" ")#metadata(none) <tao-fc72611852fc5775a1bd>

#list(
[#mi("{M_5 > 2}")#text(".")],
[#mi("{M_{105} > 4}")#text(".")],
[#text("If ")#mi("{k_0}")#text(" is sufficiently large, then")

#metadata(none) <tao-59d6d61431fce7d91388>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("M_{k_0} > \\log k_0 - 2 \\log\\log k_0 - 2.")]]]
)
]

#text("The first two cases of this proposition are obtained numerically (see Section 7 of ")#link("http://arxiv.org/abs/1311.4600")[#text("Maynard’s paper")]#text("), by working with functions ")#mi("{F}")#text(" that of the special form")

#align(center)[#tao-fit-display[#mitex("F = 1_{\\Delta_{k_0}} \\sum_{i=1}^d a_i (1-P_1)^{b_i} P_2^{c_i}")]]

#text("for various real coefficients ")#mi("{a_i}")#text(" and non-negative integers ")#mi("{b_i,c_i}")#text(", where")

#align(center)[#tao-fit-display[#mitex("P_1(t_1,\\ldots,t_{k_0}) := t_1+\\ldots+t_{k_0}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("P_2(t_1,\\ldots,t_{k_0}) := t_1^2+\\ldots+t_{k_0}^2.")]]

#text("In Maynard’s paper, the ratio")

#align(center)[#tao-fit-display[#mitex("k_0 \\frac{ \\int_{\\Delta_{k_0-1}} (\\int_0^\\infty F(t_1,\\ldots,t_{k_0-1},t_{k_0})\\ dt_{k_0})^2\\ dt_1 \\ldots dt_{k_0-1} }{ \\int_{\\Delta_{k_0}} F(t_1,\\ldots,t_{k_0})^2\\ dt_1 \\ldots dt_{k_0} }")]]

#text("in this case is computed to be")

#align(center)[#tao-fit-display[#mitex("\\frac{a^T M_2 a}{a^T M_1 a}")]]

#text("where ")#mi("{a}")#text(" is the ")#mi("{d \\times 1}")#text(" matrix with entries ")#mi("{a_1,\\ldots,a_d}")#text(", ")#mi("{M_1}")#text(" is the ")#mi("{d \\times d}")#text(" matrix with ")#mi("{ij}")#text(" entry equal to")

#align(center)[#tao-fit-display[#mitex("\\frac{(b_i+b_j)! G_{c_i+c_j,2}(k_0)}{(k_0+b_i+b_j+2c_i+2c_j)!}")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("G_{b,j}(x) := b! \\sum_{r=1}^b \\binom{x}{r} \\sum_{b_1,\\ldots,b_r \\geq 1: \\sum_{i=1}^r b_i = b} \\prod_{i=1}^r \\frac{(jb_i)!}{b_i!}")]]

#text("and ")#mi("{M_2}")#text(" is the ")#mi("{d \\times d}")#text(" matrix with ")#mi("{ij}")#text(" entry equal to")

#align(center)[#tao-fit-display[#mitex("k_0 \\sum_{c^{\\prime}_1=0}^{c_1} \\sum_{c^{\\prime}_2=0}^{c_2} \\binom{c_1}{c^{\\prime}_1} \\binom{c_2}{c^{\\prime}_2} \\frac{\\gamma_{b_i,b_j,c_i,c_j,c^{\\prime}_1,c^{\\prime}_2} G_{c^{\\prime}_1+c^{\\prime}_2,2}(k_0-1)}{(k_0+b_i+b_j+2c_i+2c_j+1)!}")]]

#text("where ")#mi("{\\gamma_{b_i,b_j,c_i,c_j,c^{\\prime}_1,c^{\\prime}_2}}")#text(" is the quantity")

#align(center)[#tao-fit-display[#mitex("\\frac{b_i! b_j! (2c_i-2c^{\\prime}_1)! (2c_j-2c^{\\prime}_2)! (b_i+b_j+2c_i+2c_j-2c^{\\prime}_i-2c^{\\prime}_j+2)!}{(b_i+2c_i-2c^{\\prime}_1+1)! (b_j + 2c_j-2c^{\\prime}_2+1)!}.")]]

#text("One then optimises the ratio ")#mi("{\\frac{a^T M_2 a}{a^T M_1 a}}")#text(" by linear programming methods (a similar idea appears in the original paper of Goldston, Pintz, and Yildirim) to obtain a lower bound for ")#mi("{M_{k_0}}")#text(" for ")#mi("{k_0=5}")#text(" and ")#mi("{k_0=105}")#text(".")

#text("The final case is established in a different manner; we give a proof of the slightly weaker bound ")#metadata(none) <tao-6815f3c300383519de8e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("M_{k_0} > \\log k_0 - 4 \\log\\log k_0 - O(1)")]]

#text("in Section ")#link(<tao-059e34e1d84166e42c9d>)[#text("3")]#text(".")

#heading(level: 1)[#strong[#text(" — 2. Sieve asymptotics — ")]]

#metadata(none) <tao-60bfcc5e146d64155149>

#text("We now prove Proposition ")#link(<tao-3b517115314ed587be3d>)[#text("5")]#text(". We use a Fourier-analytic method, similar to that in ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("this previous blog post")]#text(".")

#text("The sieve we will use is of the form ")#metadata(none) <tao-80e36ab6752b8127f700>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\nu(n) := (\\sum_{d_1,\\ldots,d_{k_0} \\in {\\cal S}: d_i|n+h_i \\text{ for all } i=1,\\ldots,k_0}")]]

#align(center)[#tao-fit-display[#mitex("(\\prod_{i=1}^{k_0} \\mu(d_i)) f( \\frac{\\log d_1}{\\log R}, \\ldots, \\frac{\\log d_{k_0} }{\\log R} ))^2,")]]

#text("where ")#mi("{{\\cal S}}")#text(" denotes the square-free integers and ")#mi("{\\mu}")#text(" is the Möbius function This should be compared with the sieve")

#align(center)[#tao-fit-display[#mitex("\\nu(n) := (\\sum_{d \\in {\\cal S}: d|\\prod_{i=1}^{k_0}(n+h_i)} \\mu(d) F( \\frac{\\log d}{\\log R}))^2")]]

#text("used in the previous blog post, which basically corresponds to the special case ")#mi("{f(t_1,\\ldots,t_{k_0}) =F(t_1+\\ldots+t_{k_0})}")#text(".")

#text("We begin with ")#link(<tao-e8bc163c82eee1873328>)[#text("(1)")]#text(". Using ")#link(<tao-80e36ab6752b8127f700>)[#text("(10)")]#text(", we may rearrange the left-hand side of ")#link(<tao-e8bc163c82eee1873328>)[#text("(1)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,\\ldots,d_{k_0},d^{\\prime}_1,\\ldots,d^{\\prime}_{k_0}\\in {\\cal S}} (\\prod_{j=1}^{k_0} \\mu(d_j) \\mu(d^{\\prime}_j))")]]

#align(center)[#tao-fit-display[#mitex("f( \\frac{\\log d_1}{\\log R}, \\ldots, \\frac{\\log d_{k_0} }{\\log R} ) f( \\frac{\\log d^{\\prime}_1}{\\log R}, \\ldots, \\frac{\\log d^{\\prime}_{k_0} }{\\log R} )")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq 2x: n = b\\ (W); [d_j,d^{\\prime}_j] | n+h_j \\text{ for all } j=1,\\ldots,k_0} 1.")]]

#text("Observe that as the numbers ")#mi("{n+h_1,\\ldots,n+h_{k_0}}")#text(" have no common factor when ")#mi("{n = b\\ (W)}")#text(", the inner sum vanishes unless the quantities ")#mi("{[d_1,d^{\\prime}_1],\\ldots,[d_{k_0},d^{\\prime}_{k_0}]}")#text(" are coprime, in which case this inner sum can be estimated as")

#align(center)[#tao-fit-display[#mitex("\\frac{x}{W [d_1,d^{\\prime}_1] \\ldots [d_{k_0},d^{\\prime}_{k_0}]}+O(1).")]]

#text("Also, at least one of the two products involving ")#mi("{f}")#text(" will vanish unless one has")

#align(center)[#tao-fit-display[#mitex("d_1 \\ldots d_{k_0}, d^{\\prime}_1,\\ldots,d^{\\prime}_{k_0} \\leq R.")]]

#text("Let us first deal with the contribution of the error term ")#mi("{O(1)}")#text(" to ")#link(<tao-e8bc163c82eee1873328>)[#text("(1)")]#text(". This contribution may be bounded by")

#align(center)[#tao-fit-display[#mitex("O( \\sum_{d_1,\\ldots,d_{k_0},d^{\\prime}_1,\\ldots,d^{\\prime}_{k_0}: d_1 \\ldots d_{k_0}, d^{\\prime}_1,\\ldots,d^{\\prime}_{k_0} \\leq R} 1 ),")]]

#text("which sums to ")#mi("{\\ll R^2 \\log^{O(1)} R}")#text("; since ")#mi("{R = x^{c/2}}")#text(" and ")#mi("{c < 1/2 < 1}")#text(", we conclude that this contribution is negligible.")

#text("To conclude the proof of ")#link(<tao-e8bc163c82eee1873328>)[#text("(1)")]#text(", it thus suffices to show that ")#metadata(none) <tao-8dccea5217902053b636>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\sum_{d_1,\\ldots,d_{k_0},d^{\\prime}_1,\\ldots,d^{\\prime}_{k_0}\\in {\\cal S}: [d_1,d^{\\prime}_1],\\ldots,[d_{k_0},d^{\\prime}_{k_0}] \\text{ coprime}} (\\prod_{j=1}^{k_0} \\mu(d_j) \\mu(d^{\\prime}_j))")]]

#align(center)[#tao-fit-display[#mitex("\\frac{f( \\frac{\\log d_1}{\\log R}, \\ldots, \\frac{\\log d_{k_0} }{\\log R} ) f( \\frac{\\log d^{\\prime}_1}{\\log R}, \\ldots, \\frac{\\log d^{\\prime}_{k_0} }{\\log R} )}{[d_1,d^{\\prime}_1] \\ldots [d_k,d^{\\prime}_k]}")]]

#align(center)[#tao-fit-display[#mitex("= (\\alpha+o(1)) (\\frac{W}{\\phi(W)})^{k_0} \\frac{1}{\\log^{k_0} R}.")]]

#text("Next, we smoothly extend the function ")#mi("{f: [0,+\\infty)^{k_0} \\rightarrow {\\bf R}}")#text(" to a smooth compactly supported function ")#mi("{f: {\\bf R}^{k_0}\\rightarrow {\\bf R}}")#text(", which by abuse of notation we will continue to refer to as ")#mi("{f}")#text(". By Fourier inversion, we may then express ")#mi("{f}")#text(" in the form ")#metadata(none) <tao-df1a59ec3001c99fa8bb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("f(t_1,\\ldots,t_{k_0}) = \\int_{{\\bf R}^{k_0}} \\eta(\\vec s) e^{-\\sum_{j=1}^{k_0} (1+is_j)t_j}\\ d \\vec s")]]

#text("where ")#mi("{\\vec s := (s_1,\\ldots,s_{k_0})}")#text(" and where ")#mi("{\\eta: {\\bf R}^k \\rightarrow {\\bf C}}")#text(" is a smooth function obeying the rapid decay bounds ")#metadata(none) <tao-ac04f0a0fa15b190fde8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left|\\eta(\\vec s)\\right| \\ll (1+\\left|\\vec s\\right|)^{-A}", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(". The left-hand side of ")#link(<tao-8dccea5217902053b636>)[#text("(11)")]#text(" may then be rewritten as ")#metadata(none) <tao-9dfbc63747c6ec4e8d43>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\int_{{\\bf R}^{k_0}} \\int_{{\\bf R}^{k_0}} \\eta(\\vec s) \\eta(\\vec s^{\\prime}) H(\\vec s, \\vec s^{\\prime})\\ d\\vec s d\\vec s^{\\prime}")]]

#text("where ")#mi("{\\vec s^{\\prime} := (s^{\\prime}_1,\\ldots,s^{\\prime}_{k_0})}")#text(" and")

#align(center)[#tao-fit-display[#mitex("H(\\vec s, \\vec s^{\\prime}) := \\sum_{d_1,\\ldots,d_{k_0},d^{\\prime}_1,\\ldots,d^{\\prime}_{k_0}\\in {\\cal S}: [d_1,d^{\\prime}_1],\\ldots,[d_{k_0},d^{\\prime}_{k_0}] \\text{ coprime}} (\\prod_{j=1}^{k_0} \\mu(d_j) \\mu(d^{\\prime}_j))")]]

#align(center)[#tao-fit-display[#mitex("\\frac{\\prod_{j=1}^{k_0} d_j^{-(1+is_j)/\\log R} (d^{\\prime}_j)^{-(1+is^{\\prime}_j)/\\log R}}{[d_1,d^{\\prime}_1] \\ldots [d_k,d^{\\prime}_k]}.")]]

#text("We may factorise ")#mi("{H(\\vec s,\\vec s^{\\prime})}")#text(" as an Euler product")

#align(center)[#tao-fit-display[#mitex("H(\\vec s,\\vec s^{\\prime}) = \\prod_{p>w}")]]

#align(center)[#tao-fit-display[#mitex("(1 - \\sum_{j=1}^{k_0} p^{-1-(1+is_j)/\\log R} + p^{-1-(1+is^{\\prime}_j)/\\log R} - p^{-1-(1+is_j)/\\log R - (1+is^{\\prime}_j)/\\log R} ).")]]

#text("In particular, we have the crude bound")

#align(center)[#tao-fit-display[#tao-math("\\left|H(\\vec s,\\vec s^{\\prime})\\right| \\leq \\prod_{p>w} (1 +3p^{-1/\\log R}) \\ll \\log^{O(1)} R;", block: true)]]

#text("combining this with ")#link(<tao-ac04f0a0fa15b190fde8>)[#text("(13)")]#text(" we see that the contribution to ")#link(<tao-9dfbc63747c6ec4e8d43>)[#text("(14)")]#text(" in which ")#tao-math("{\\left|\\vec s\\right| \\geq \\sqrt{\\log R}}", block: false)#text(" or ")#tao-math("{\\left|\\vec s^{\\prime}\\right| \\geq \\sqrt{\\log R}}", block: false)#text(" is negligible, so we may restrict the integral in ")#link(<tao-9dfbc63747c6ec4e8d43>)[#text("(14)")]#text(" to the region ")#tao-math("{\\left|\\vec s\\right|,\\left|\\vec s^{\\prime}\\right| \\leq \\sqrt{\\log R}}", block: false)#text(". In this region, we have the Euler product approximations")

#tao-aligned(keep: true)[


#tao-math("\\prod_{p>w} (1 - p^{-1-(1+is_j)/\\log R})  & = \\zeta(1+\\frac{1+is_j}{\\log R})^{-1} \\prod_{p \\leq w} (1 - p^{-1-(1+is_j)/\\log R})^{-1}", block: true)



#tao-math(" & = (1+o(1)) (\\frac{1+is_j}{\\log R}) \\prod_{p \\leq w} (1-p^{-1})^{-1}", block: true)



#tao-math(" & = (1+o(1)) \\frac{W}{\\phi(W)} (\\frac{1+is_j}{\\log R})", block: true)
]

#text("where we have used the bound ")#mi("{W = O(\\log\\log x)}")#text(" and the asymptotic ")#mi("{\\zeta(s) = (1+o(1)) (s-1)^{-1}}")#text(" for ")#mi("{s = 1 + O(1/\\log R)}")#text(". Since also ")#mi("{\\sum_{p>w} p^{-2} = o(1)}")#text(", we conclude that")

#tao-aligned(keep: true)[


#tao-math("F(\\vec s,\\vec s^{\\prime})  & = (1+o(1)) \\prod_{j=1}^{k_0} \\prod_{p>w} \\frac{ (1-p^{-1-(1+is_j)/\\log R}) (1-p^{-1-(1+is^{\\prime}_j)/\\log R})}{1-p^{-1-(1+is_j)/\\log R- (1+is^{\\prime}_j)/\\log R}}", block: true)



#tao-math(" & = (1+o(1)) (\\frac{W}{\\phi(W)})^{k_0} \\frac{1}{\\log^{k_0} R} \\prod_{j=1}^{k_0} \\frac{ (1+is_j) (1+is^{\\prime}_j)}{1+is_j+1+is^{\\prime}_j}.", block: true)
]

#text("Using ")#link(<tao-ac04f0a0fa15b190fde8>)[#text("(13)")]#text(" again to dispose of the ")#mi("{o(1)}")#text(" error term, and then using ")#link(<tao-ac04f0a0fa15b190fde8>)[#text("(13)")]#text(" once more to remove the restriction to ")#tao-math("{\\left|\\vec s\\right|,\\left|\\vec s^{\\prime}\\right| \\leq \\sqrt{\\log R}}", block: false)#text(", we thus reduce to verifying the identity")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^{k_0}} \\int_{{\\bf R}^{k_0}} \\eta(\\vec s) \\eta(\\vec s^{\\prime}) \\prod_{j=1}^{k_0} \\frac{ (1+is_j) (1+is^{\\prime}_j)}{1+is_j+1+is^{\\prime}_j} \\ d\\vec s d\\vec s^{\\prime} = \\alpha.")]]

#text("But from repeatedly differentiating ")#link(<tao-df1a59ec3001c99fa8bb>)[#text("(12)")]#text(" under the integral sign, one has")

#align(center)[#tao-fit-display[#mitex("f_{1,\\ldots,k_0}(t_1,\\ldots,t_{k_0}) = (-1)^{k_0} \\int_{{\\bf R}^{k_0}} \\eta(\\vec s) e^{-\\sum_{j=1}^{k_0} (1+is_j)t_j} \\prod_{j=1}^{k_0} (1+is_j)\\ d \\vec s")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("f_{1,\\ldots,k_0}(t_1,\\ldots,t_{k_0})^2 = \\int_{{\\bf R}^{k_0}} \\int_{{\\bf R}^{k_0}} \\eta(\\vec s) \\eta(\\vec s^{\\prime}) e^{-\\sum_{j=1}^{k_0} (1+is_j +1 +is^{\\prime}_j)t_j}")]]

#align(center)[#tao-fit-display[#mitex("\\prod_{j=1}^{k_0} (1+is_j) (1+is^{\\prime}_j)\\ d \\vec s d\\vec s^{\\prime};")]]

#text("integrating this for ")#mi("{(t_1,\\ldots,t_{k_0} \\in [0,+\\infty)}")#text(" using Fubini’s theorem (and ")#link(<tao-ac04f0a0fa15b190fde8>)[#text("(13)")]#text("), the claim then follows from ")#link(<tao-f81ab872625c131d92e7>)[#text("(5)")]#text(". This concludes the proof of ")#link(<tao-e8bc163c82eee1873328>)[#text("(1)")]#text(".")

#text("Now we prove ")#link(<tao-ad328846aa18b32a3358>)[#text("(2)")]#text(". We will just prove the claim for ")#mi("{i=k_0}")#text(", as the other cases follow similarly using the symmetry hypothesis on ")#mi("{f}")#text(". The left-hand side of ")#link(<tao-ad328846aa18b32a3358>)[#text("(2)")]#text(" may then be expanded as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,\\ldots,d_{k_0},d^{\\prime}_1,\\ldots,d^{\\prime}_{k_0}\\in {\\cal S}} (\\prod_{j=1}^{k_0} \\mu(d_j) \\mu(d^{\\prime}_j))")]]

#align(center)[#tao-fit-display[#mitex("f( \\frac{\\log d_1}{\\log R}, \\ldots, \\frac{\\log d_{k_0} }{\\log R} ) f( \\frac{\\log d^{\\prime}_1}{\\log R}, \\ldots, \\frac{\\log d^{\\prime}_{k_0} }{\\log R} )")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq 2x: n = b\\ (W); [d_j,d^{\\prime}_j] | n+h_j \\text{ for all } j=1,\\ldots,k_0} \\theta(n+h_{k_0}).")]]

#text("Observe that the summand vanishes unless ")#mi("{d_{k_0}=d^{\\prime}_{k_0}=1}")#text(" (note that ")#mi("{n+k_0}")#text(" is comparable to ")#mi("{x}")#text(" and thus exceeds ")#mi("{R}")#text("). So we may simplify the above expression to")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,\\ldots,d_{k_0-1},d^{\\prime}_1,\\ldots,d^{\\prime}_{k_0-1}\\in {\\cal S}} (\\prod_{j=1}^{k_0-1} \\mu(d_j) \\mu(d^{\\prime}_j)) f( \\frac{\\log d_1}{\\log R}, \\ldots, \\frac{\\log d_{k_0-1} }{\\log R}, 0 ) f( \\frac{\\log d^{\\prime}_1}{\\log R}, \\ldots, \\frac{\\log d^{\\prime}_{k_0-1} }{\\log R}, 0 )")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq 2x: n = b\\ (W); [d_j,d^{\\prime}_j] | n+h_j \\text{ for all } j=1,\\ldots,k_0-1} \\theta(n+h_{k_0}).")]]

#text("As in the estimation of ")#link(<tao-e8bc163c82eee1873328>)[#text("(1)")]#text(", the summand vanishes unless ")#mi("{[d_1,d^{\\prime}_1],\\ldots,[d_{k_0-1},d^{\\prime}_{k_0-1}]}")#text(" are coprime, and if")

#align(center)[#tao-fit-display[#mitex("d_1 \\ldots d_{k_0-1}, d^{\\prime}_1 \\ldots d^{\\prime}_{k_0-1} \\leq R.")]]

#text("Let ")#mi("{d_1,\\ldots,d_{k_0-1},d^{\\prime}_1,\\ldots,d^{\\prime}_{k_0-1} \\in {\\cal S}}")#text(" obey the above constraints. For any modulus ")#mi("{q}")#text(", define the discrepancy ")#metadata(none) <tao-7d601f9d20703a97b8cb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("E(q) := \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\sum_{x \\leq n \\leq 2x: n+ h_{k_0} = a\\ (q)} \\theta(n+h_{k_0}) - \\frac{x}{\\phi(q)}\\right|.", block: true)]]

#text("Since ")#mi("{R = x^{c/2}}")#text(" and ")#mi("{0 < c < \\theta}")#text(" is fixed, the hypothesis ")#mi("{EH[\\theta]}")#text(" implies that ")#metadata(none) <tao-c5c8fcbf6d9460bd16fa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\sum_{q \\leq WR^2} E(q) \\ll x \\log^{-A} x")]]

#text("for any fixed ")#mi("{A>0}")#text(". On the other hand, the sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq 2x: n = b\\ (W); [d_j,d^{\\prime}_j] | n+h_j \\text{ for all } j=1,\\ldots,k_0-1} \\theta(n+h_{k_0})")]]

#text("can, by the Chinese remainder theorem, be rewritten in the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq 2x: n+h_{k_0} = a\\ (q)} \\theta(n+h_{k_0})")]]

#text("where ")#metadata(none) <tao-a8b771920b8319e47251>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("q := W \\prod_{j=0}^{k_0-1} [d_j,d^{\\prime}_j]")]]

#text("and ")#mi("{a\\ (q)}")#text(" is a primitive residue class; note that ")#mi("{q}")#text(" does not exceed ")#mi("{WR^2}")#text(". By ")#link(<tao-7d601f9d20703a97b8cb>)[#text("(15)")]#text(", this expression can then be written as")

#align(center)[#tao-fit-display[#mitex("\\frac{x}{\\phi(W) \\prod_{j=0}^{k_0-1} \\phi([d_j,d^{\\prime}_j])} + O( E(W \\prod_{j=0}^{k_0-1} [d_j,d^{\\prime}_j]) ).")]]

#text("Let us first control the error term, which may be bounded by")

#align(center)[#tao-fit-display[#mitex("O( \\sum_{d_1,\\ldots,d_{k_0-1},d^{\\prime}_1,\\ldots,d^{\\prime}_{k_0-1}: d_1 \\ldots d_{k_0-1}, d^{\\prime}_1 \\ldots d^{\\prime}_{k_0-1} \\leq R} E(W \\prod_{j=0}^{k_0-1} [d_j,d^{\\prime}_j]) ).")]]

#text("Note that for any ")#mi("{q \\leq WR^2}")#text(", there are ")#mi("{O( \\tau(q)^{O(1)})}")#text(" choices of ")#mi("{d_1 \\ldots d_{k_0-1}, d^{\\prime}_1 \\ldots d^{\\prime}_{k_0-1}}")#text(" for which ")#link(<tao-a8b771920b8319e47251>)[#text("(17)")]#text(" holds. Thus we may bound the previous expression by")

#align(center)[#tao-fit-display[#mitex("\\ll \\sum_{q \\leq WR^2} \\tau(q)^{O(1)} E(q).")]]

#text("By the Cauchy-Schwarz inequality and ")#link(<tao-c5c8fcbf6d9460bd16fa>)[#text("(16)")]#text(", this expression may be bounded by")

#align(center)[#tao-fit-display[#mitex("\\ll (x \\log^{-A} x)^{1/2} (\\sum_{q \\leq WR^2} \\tau(q)^{O(1)} E(q))^{1/2}")]]

#text("for any fixed ")#mi("{A}")#text(". On the other hand, we have the crude bound ")#mi("{E(q) \\ll \\frac{x}{q} \\log^{O(1)} x}")#text(", as well as the standard estimate")

#align(center)[#tao-fit-display[#mitex("\\sum_{q \\leq y} \\frac{\\tau(q)^{O(1)}}{q} \\ll \\log^{O(1)} y.")]]

#text("(see e.g. Corollary 2.15 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2378655")[#text("Montgomery-Vaughan")]#text("). Putting all this together, we conclude that the contribution of the error term to ")#link(<tao-ad328846aa18b32a3358>)[#text("(2)")]#text(" is negligible. To conclude the proof of ")#link(<tao-ad328846aa18b32a3358>)[#text("(2)")]#text(", it thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,\\ldots,d_{k_0-1},d^{\\prime}_1,\\ldots,d^{\\prime}_{k_0-1}\\in {\\cal S}} (\\prod_{j=1}^{k_0-1} \\mu(d_j) \\mu(d^{\\prime}_j))")]]

#align(center)[#tao-fit-display[#mitex("\\frac{f( \\frac{\\log d_1}{\\log R}, \\ldots, \\frac{\\log d_{k_0-1} }{\\log R}, 0 ) f( \\frac{\\log d^{\\prime}_1}{\\log R}, \\ldots, \\frac{\\log d^{\\prime}_{k_0-1} }{\\log R}, 0 )}{\\prod_{j=0}^{k_0-1} \\phi([d_j,d^{\\prime}_j])}")]]

#align(center)[#tao-fit-display[#mitex("= (\\beta-o(1)) (\\frac{W}{\\phi(W)})^{k_0-1} \\frac{1}{\\log^{k_0-1} R}.")]]

#text("But this can be proven by repeating the arguments used to prove ")#link(<tao-8dccea5217902053b636>)[#text("(11)")]#text(" (with ")#mi("{k_0}")#text(" replaced by ")#mi("{k_0-1}")#text(", and ")#mi("{f(t_1,\\ldots,t_{k_0})}")#text(" replaced by ")#mi("{f(t_1,\\ldots,t_{k_0-1},0)}")#text("); the presence of the Euler totient function causes some factors of ")#mi("{\\frac{1}{p}}")#text(" in that analysis to be replaced by ")#mi("{\\frac{1}{p-1} = \\frac{1}{p} + O(\\frac{1}{p^2})}")#text(", but this turns out to have a negligible impact on the final asymptotics since ")#mi("{\\sum_{p >w} \\frac{1}{p^2} = o(1)}")#text(". This concludes the proof of ")#link(<tao-ad328846aa18b32a3358>)[#text("(2)")]#text(" and hence Proposition ")#link(<tao-3b517115314ed587be3d>)[#text("5")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" An inspection of the above arguments shows that the simplex ")#mi("{\\Delta_{k_0}}")#text(" can be enlarged slightly to the region")

#tao-aligned(keep: true)[


#tao-math("\\Delta^{\\prime}_{k_0}  & := \\{ (t_1,\\ldots,t_{k_0}) \\in [0,+\\infty)^{k_0}: t_1+\\ldots+t_{k_0} \\leq 1 + t_i", block: true)



#tao-math("\\text{ for all } 1  & \\leq i \\leq k_0 \\},", block: true)
]

#text("however this only leads to a tiny improvement in the numerology. It is interesting to note however that in the ")#mi("{k_0=2}")#text(" case, ")#mi("{\\Delta^{\\prime}_{k_0}}")#text(" is the unit square ")#mi("{[0,1]^2}")#text(", and by taking ")#mi("{f(t_1,t_2) := (1-t_1)_+ (1-t_2)_+}")#text(" and taking ")#mi("{c}")#text(" close to ")#mi("{1}")#text(", one can come “within an epsilon” of establishing ")#mi("{DHL[2,2]}")#text(" (and in particular, the twin prime conjecture) from the full Elliott-Halberstam conjecture; this fact was already essentially observed ")#link("http://www.ams.org/mathscinet-getitem?mr=396435")[#text("by Bombieri")]#text(", using the weight ")#mi("{\\nu(n):=\\Lambda_2(n) \\Lambda_2(n+2)}")#text(" rather than the Selberg sieve. (Strictly speaking, to establish ")#link(<tao-e8bc163c82eee1873328>)[#text("(1)")]#text(" in this context, one needs the Elliott-Halberstam conjecture not only for ")#mi("{\\Lambda}")#text(", but also for other arithmetic functions with a suitable Dirichlet convolution ")#mi("{\\alpha*\\beta}")#text(" structure; we omit the details.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" It appears that the ")#mi("{MPZ[\\varpi,\\delta]}")#text(" conjecture studied in Polymath8a can serve as a substitute for ")#mi("{EH[\\frac{1}{2}+2\\varpi]}")#text(" in Corollary ")#link(<tao-53478db94ea65ea77f0c>)[#text("6")]#text(", except that one also has to impose an additional constraint on the function ")#mi("{F}")#text(" (or ")#mi("{f}")#text("), namely that it is supported in the cube ")#mi("{[0, \\frac{\\delta}{1/4 +\\varpi}]^{k_0}}")#text(" (in order to keep the moduli involved appropriately smooth). Perhaps as a first approximation, we should ignore the role of ")#mi("{\\delta}")#text(", and just pretend that ")#mi("{MPZ[\\varpi,\\delta]}")#text(" is as good as ")#mi("{EH[\\frac{1}{2}+2\\varpi]}")#text(". In particular, inserting our most optimistic value of ")#mi("{\\varpi}")#text(" obtained by Polymath8, namely ")#mi("{\\frac{13}{1080}}")#text(", we can in principle take ")#mi("{\\theta}")#text(" as large as ")#mi("{283/540 = 0.524\\ldots}")#text(", although this only is a ")#mi("{5\\%}")#text(" improvement or so over the Bombieri-Vinogradov inequality.")
]

#heading(level: 1)[#strong[#text(" — 3. Large ")#mi("{k_0}")#text(" computations — ")]]

#metadata(none) <tao-059e34e1d84166e42c9d>

#text("We now give a proof of ")#link(<tao-6815f3c300383519de8e>)[#text("(9)")]#text(" for sufficiently large ")#mi("{k_0}")#text(". We use the ansatz")

#align(center)[#tao-fit-display[#mitex("F = 1_{\\Delta_{k_0}} F_0")]]

#text("where ")#mi("{F_0}")#text(" is the tensor product")

#align(center)[#tao-fit-display[#mitex("F_0(t_1,\\ldots,t_k) = \\prod_{i=1}^{k_0} k_0^{1/2} g( k_0 t_i )")]]

#text("and ")#mi("{g: [0,+\\infty) \\rightarrow {\\bf R}}")#text(" is supported on some interval ")#mi("{[0,T]}")#text(" and normalised so that ")#metadata(none) <tao-69727902b857d1e1356c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\int_0^\\infty g(t)^2\\ dt = 1.")]]

#text("The function ")#mi("{F}")#text(" is clearly symmetric and supported on ")#mi("{\\Delta_{k_0}}")#text(". We now estimate the numerator and denominator of the ratio")

#align(center)[#tao-fit-display[#mitex("k_0 \\frac{ \\int_{\\Delta_{k_0-1}} (\\int_0^\\infty F(t_1,\\ldots,t_{k_0-1},t_{k_0})\\ dt_{k_0})^2\\ dt_1 \\ldots dt_{k_0-1} }{ \\int_{\\Delta_{k_0}} F(t_1,\\ldots,t_{k_0})^2\\ dt_1 \\ldots dt_{k_0} }")]]

#text("that lower bounds ")#mi("{M_{k_0}}")#text(".")

#text("For the denominator, we bound ")#mi("{F}")#text(" by ")#mi("{F_0}")#text(" and use Fubini’s theorem and ")#link(<tao-59d6d61431fce7d91388>)[#text("(8)")]#text(" to obtain the upper bound")

#align(center)[#tao-fit-display[#mitex("\\int_{\\Delta_{k_0}} F(t_1,\\ldots,t_{k_0})^2\\ dt_1 \\ldots dt_{k_0} \\leq 1")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("M_{k_0} \\geq k_0 \\int_{\\Delta_{k_0-1}} (\\int_0^\\infty F(t_1,\\ldots,t_{k_0-1},t_{k_0})\\ dt_{k_0})^2\\ dt_1 \\ldots dt_{k_0-1}.")]]

#text("Now we observe that")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty F(t_1,\\ldots,t_{k_0-1},t_{k_0})\\ dt_{k_0} = (\\prod_{i=0}^{k_0-1} k_0^{1/2} g(k_0 t_i)) k_0^{-1/2} \\int_0^\\infty g(t)\\ dt")]]

#text("whenever ")#mi("{t_1+\\ldots+t_{k_0-1} \\leq 1 - \\frac{T}{k_0}}")#text(", and so we have the lower bound")

#align(center)[#tao-fit-display[#mitex("M_{k_0} \\geq (\\int_0^\\infty g(t)\\ dt)^2 \\int_{t_1+\\ldots+t_{k_0-1} \\leq 1-\\frac{T}{k_0}} (\\prod_{i=0}^{k_0-1} k_0^{1/2} g(k_0 t_i))^2 dt_1 \\ldots dt_{k_0-1}.")]]

#text("We interpret this probabilistically. Let ")#mi("{X_1,\\ldots,X_{k_0-1}}")#text(" be ")#link("http://en.wikipedia.org/wiki/Independent_and_identically_distributed_random_variables")[#text("independent, identically distributed")]#text(" non-negative real random variables with probability density ")#mi("{g(t)^2\\ dt}")#text("; this is well-defined thanks to ")#link(<tao-69727902b857d1e1356c>)[#text("(18)")]#text(". Observe that ")#mi("{(\\prod_{i=1}^{k_0-1} k_0^{1/2} g( k_0 t_i ))^2}")#text(" is the joint probability density of ")#mi("{\\frac{1}{k_0}(X_1,\\ldots,X_{k_0-1})}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("M_{k_0} \\geq (\\int_0^\\infty g(t)\\ dt)^2 {\\bf P} (X_1 + \\ldots + X_{k_0-1} \\leq k_0 - T).")]]

#text("We will lower bound this probability using the ")#link("http://en.wikipedia.org/wiki/Chebyshev_inequality")[#text("Chebyshev inequality")]#text(". (In my own calculations, I had used the ")#link("http://en.wikipedia.org/wiki/Hoeffding_inequality")[#text("Hoeffding inequality")]#text(" instead, but it seems to only give a slightly better bound in the end for ")#mi("{H_m}")#text(" (perhaps saving one or two powers of ")#mi("{m}")#text(").) In order to exploit the law of large numbers, we would like the mean ")#mi("{(k_0-1) \\mu}")#text(" of ")#mi("{X_1 + \\ldots + X_{k_0-1}}")#text(", where ")#mi("{\\mu := \\int_0^T t g(t)^2\\ dt}")#text(", to be less than ")#mi("{k_0-T}")#text(":")

#align(center)[#tao-fit-display[#mitex("(k_0-1) \\mu < k_0 - T.")]]

#text("The variance of ")#mi("{X_1 + \\ldots + X_{k_0-1}}")#text(" is ")#mi("{k_0-1}")#text(" times the variance of a single ")#mi("{X_i}")#text(", which we can bound (somewhat crudely) by")

#align(center)[#tao-fit-display[#mitex("\\text{Var}(X_i) \\leq {\\bf E} X_i^2 \\leq T {\\bf E} X_i = T \\mu.")]]

#text("Thus by Chebyshev’s inequality, we have")

#align(center)[#tao-fit-display[#mitex("{\\bf P} (X_1 + \\ldots + X_{k_0-1} \\leq k_0 - T) \\geq 1 - \\frac{(k_0-1) T \\mu}{(k_0-T-(k_0-1)\\mu)^2}.")]]

#text("To clean things up a bit we bound ")#mi("{k_0-1}")#text(" by ")#mi("{k_0}")#text(" to obtain the simpler bound")

#align(center)[#tao-fit-display[#mitex("{\\bf P} (X_1 + \\ldots + X_{k_0-1} \\leq k_0 - T) \\geq 1 - \\frac{k_0 T \\mu}{(k_0-T-k_0\\mu)^2}")]]

#text("assuming now that ")#mi("{k_0 \\mu < k_0 - T}")#text(". In particular, ")#mi("{\\mu \\leq 1}")#text(", so we have the cleaner bound")

#align(center)[#tao-fit-display[#mitex("{\\bf P} (X_1 + \\ldots + X_{k_0-1} \\leq k_0 - T) \\geq 1 - \\frac{T}{k_0 (1-T/k_0-\\mu)^2}.")]]

#text("To summarise, we have shown that ")#metadata(none) <tao-3c7d2a5478ede3b149fa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("M_{k_0} \\geq (\\int_0^T g(t)\\ dt)^2 ( 1 - \\frac{T}{k_0 (1-T/k_0-\\mu)^2} )")]]

#text("whenever ")#mi("{g: [0,T] \\rightarrow {\\bf R}}")#text(" is such that ")#metadata(none) <tao-0bdabb5697aae2c21e43>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\int_0^T g(t)^2\\ dt = 1")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\mu = \\int_0^T t g(t)^2\\ dt < 1 - \\frac{T}{k_0}.")]]

#text("One can optimise this carefully to give ")#link(<tao-59d6d61431fce7d91388>)[#text("(8)")]#text(" (as is done in Maynard’s paper), but for the purposes of establishing the slightly weaker bound ")#link(<tao-6815f3c300383519de8e>)[#text("(9)")]#text(", we can use ")#mi("{g}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("g(t) = \\frac{c}{1+At}")]]

#text("with ")#mi("{A := \\log k_0}")#text(" and ")#mi("{T := k_0 \\log^{-3} k_0}")#text(". With the normalisation ")#link(<tao-0bdabb5697aae2c21e43>)[#text("(20)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("c^2 = \\frac{1+AT}{T} = \\log k_0 + O(1)")]]

#text("so")

#align(center)[#tao-fit-display[#mitex("c = \\log^{1/2} k_0 + O(\\log^{-1/2} k_0)")]]

#text("and")

#tao-aligned(keep: true)[


#tao-math("\\mu  & = \\frac{c^2}{A^2} (\\log(1+AT) -1 - \\frac{1}{1+AT})", block: true)



#tao-math(" & = 1 - \\frac{2 \\log\\log k_0}{\\log k_0} + O( \\frac{1}{\\log k_0} )", block: true)
]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\frac{T}{k_0 (1-T/k_0-\\mu)^2} = O( \\frac{1}{\\log k_0} )")]]

#text("while")

#tao-aligned(keep: true)[


#tao-math("\\int_0^T g(t) & = \\frac{c}{A} \\log(1+AT)", block: true)



#tao-math(" & = \\log^{1/2} k_0 - 2 \\log^{-1/2} k_0 \\log\\log k_0 + O( \\log^{-1/2} k_0 )", block: true)
]

#text("which gives the claim.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (161)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251696")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2013")])]

#text("There are a couple of initial directions to proceed from here, I think. One is to get better bounds on ")#mi("M_{k_0}")#text("; as pointed out by Eytan in the previous thread; Maynard is working with functions of the first two symmetric polynomials ")#mi("P_1 = t_1+\\ldots+t_{k_0}")#text(" and ")#mi("P_2 = t_1^2+\\ldots+t_{k_0}^2")#text(", but in principle all the symmetric functions are available. (Though perhaps before doing that we should at least get to the point where we can replicate Maynard’s computations; note that he has supplied a Mathematica notebook in the source code of his arXiv file, although it is slightly nontrivial to extract it from the arXiv interface.) Another is to use MPZ instead of Bombieri-Vinogradov, but this puts an additional constraint on the test function F that has to be accounted for, and is likely to have a modest impact on ")#mi("k_0")#text(" (improving this quantity by about 5% or so). A third thing to do is to try to enlarge the allowable support of the function F, as per Remark 1; this is likely to be a very modest gain (basically it should shift ")#mi("k_0")#text(" downward by 1 or so), but this could be significant for bounding ")#mi("H_1")#text(" on EH, as it may shift ")#mi("k_0")#text(" down from 5 to 4 (bringing the ")#mi("H_1")#text(" bound from 12 to 8).")

#text("Indeed, it seems that focusing on the ")#mi("k_0=4")#text(" case (assuming EH) may well be the best place to start, as the numerics should be fast and one can work a certain number of things out by hand in such low-dimensional cases.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251715")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("With Maynard’s permission, I have posted a copy of his Mathematica notebook source as a text file ")#link("https://math.mit.edu/~primegaps/MaynardMathematicaNotebook.txt")[#text("here")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251726")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("Any chance I can make you (on anyone else) convert the text document into a notebook? I’m totally new to Mathematica and would like to play around with a fully working notebook. (I’m using v9.0 in case it is important.) [Sorry for interrupting the thread.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251734")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("You should be able to just save the file with the extension .nb and mathematica will be happy to load it as a notebook.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251737")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("Thank you, Andrew.")

#text("@Terry: Just remove this post and my previous question if you want.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251753")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("I don’t think you can get to ")#mi("k_0=4")#text(" (under EH) using just Remark 1 and higher symmetric polynomials (this seems to get only about half way numerically). That said, there are various possible small modifications (such as those you mention below) which might give enough of an improvement.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a34de3cadf72ccac6610285e12c3bcebfccb65bbfbc1dbf4a0a4e1418f0dfae9-ff08d1e6595501802fa250f8098ab7d7e733ad521cc83d71559bc3462cc6ab4f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vít Tuček")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251761")[#strong[#text("Vít Tuček")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("Did you try nonpolynomial symmetric functions? There is some work done on symmetric orthogonal polynomials on the standard simplex. See e.g. the section 3.3 of ")#link("https://www.sciencedirect.com/science/article/pii/S0021904504002199")[#text("https://www.sciencedirect.com/science/article/pii/S0021904504002199")]#text(" and ")#link("https://www.sciencedirect.com/science/article/pii/S0377042700005045")[#text("https://www.sciencedirect.com/science/article/pii/S0377042700005045")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251771")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("A related idea is to use the transformation ")#mi("t_j = x_j^2")#text(" to have the weight function over the unit ball (which is perhaps simpler than the simplex).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a34de3cadf72ccac6610285e12c3bcebfccb65bbfbc1dbf4a0a4e1418f0dfae9-ff08d1e6595501802fa250f8098ab7d7e733ad521cc83d71559bc3462cc6ab4f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vít Tuček")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251782")[#strong[#text("Vít Tuček")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("That’s precisely what is happening in the articles I’ve linked. The author then “constructs” some invariant orthogonal polynomials on the standard simplex. The problem is to find the matrix of ")#mi("F \\to (\\int_0^\\infty F(t_1,\\ldots,t_{k-1},t_k) dt_k)^2")#text(" with respect to the basis of orthogonal symmetric polynomials.")

#text("Of course, we can always take arbitrary polynomials in elementary symmetric functions (which give us all invariant polynomials) and evaluate the integrals numerically.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251783")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("I only looked very briefly at the numerical optimization with non-polynomial functions.")

#text("We know (Weierstrass) that polynomial approximations will converge to the optimal function. Moreover, I found that the numerical bounds from polynomial approximations seemed to converge quickly.")

#text("For ")#mi("k_0=4")#text(", it is easy to use approximations involving higher symmetric polynomials, but there is only a very limited numerical improvement after having taken a low-degree approximation.")

#text("For ")#mi("k_0\\approx 105")#text(" things are more complicated, and convergence is a bit slower, so if there is some nicer basis of symmetric functions maybe thats worth looking at. That said, I would have guessed that it is computationally feasible to include higher degree symmetric polynomials and get a bound that is accurate enough to get the globally best value of ")#mi("k_0")#text(" (if we’re only following the method in my paper – with new ideas, such as MPZ this might no longer be true).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251785")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("There is no need for numerical evaluation since any monomial in ")#mi("t_1, ..., t_k")#text(" over the simplex is transformed to a monomial in ")#mi("x_1, ..., x_k")#text(" over the unit ball whose integral is separable (by using spherical coordinates) with explicit expression in terms of beta functions (in this case factorials.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251697")[#strong[#text("Polymath 8 – a Success! | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2013")]

#text("[…] Tao launched a followup polymath8b to improve the bounds for gaps between primes based on Maynard’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251699")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2013")])]

#text("Naive questions: 1) Do the small gaps results apply to primes in arithmetic progressions? 2) Could there be a way to bootstrap results for k-tuples of prime in small intervals to get back results on 2-tuples. (The k-tuples result feels in some sense also stronger than the twin prime conjecture.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251736")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("For (1), this should be possible. The original Goldston-Pintz-Yildirim results were extended to arithmetic progressions by Freiberg (")#link("http://arxiv.org/abs/1110.6624")[#text("http://arxiv.org/abs/1110.6624")]#text(") and to more general sets of Bohr type by my student Benatar (")#link("http://arxiv.org/abs/1305.0348")[#text("http://arxiv.org/abs/1305.0348")]#text("). In Maynard’s paper, it is noted that for the purposes of getting finite values for ")#mi("H_m")#text(", the set of primes can be replaced by any other set that obeys a Bombieri-Vinogradov type theorem (at any level of distribution, not necessarily as large as 1/2), which includes the primes in arithmetic progressions (and also primes in fairly short intervals).")

#text("There may be some interplay between the k-tuple results and the 2-tuple results, but note that the set of primes we can detect in a k-tuple is rather sparse, we only catch about ")#mi("\\log k")#text(" primes in such a tuple. Basically, Maynard’s construction gives, for each ")#mi("k")#text(" and each admissible tuple ")#mi("(h_1,\\ldots,h_k)")#text(", a sieve weight ")#mi("\\nu= \\nu_k")#text(" (which is basically concentrated on a set in ")#mi("[x,2x]")#text(" of density about ")#mi("\\log^{-k} x")#text(") with the property that if ")#mi("n \\in [x,2x]")#text(" is chosen randomly with probability density equal to ")#mi("\\frac{\\nu(n)}{\\sum_m \\nu(m)}")#text(", then")

#mi("{\\bf P}( n + h_i \\text{ prime}) \\gg \\frac{\\log k}{k}")

#text("(or, in the original notation, ")#mi("\\sum_{n+h_i \\text{ prime}} \\nu(n) \\gg \\frac{\\log k}{k} \\sum_n \\nu(n)")#text(") for ")#mi("i=1,\\ldots,k")#text(", which by the first moment method shows that with positive probability at least ")#mi("\\log k")#text(" of the ")#mi("n+h_i")#text(" will be prime. As ")#mi("k")#text(" increases, it is true that we get a few more primes this way, but they are spread out in a much longer interval, and the number of ")#mi("n")#text(" with this many primes also gets sparser, so it’s not clear how to perform the tradeoff.")

#text("But this does remind me of a possible idea I had to shave 1 off of ")#mi("k")#text(". Suppose for instance one was trying to catch two primes close together in the tuple ")#mi("n,n+2,n+6,n+8")#text(". Currently, we need estimates of the form")

#mi("{\\bf P}( n \\text{ prime}) > \\frac{1}{4}")

#mi("{\\bf P}( n+2 \\text{ prime}) > \\frac{1}{4}")

#mi("{\\bf P}( n+6 \\text{ prime}) > \\frac{1}{4}")

#mi("{\\bf P}( n+8 \\text{ prime}) > \\frac{1}{4}")

#text("to catch two primes at distance at most 8 apart; one can also replace the four constants ")#mi("\\frac{1}{4}")#text(" by other constants that add up to 1, although this doesn’t seem to help much. To get primes distance at most 6 apart, one would ordinarily need to boost three of these constants up to ")#mi("1/3")#text(" (and drop the last one down to zero). But suppose we had bounds of the form")

#mi("{\\bf P}( n \\text{ prime}) > \\frac{1}{4} + \\varepsilon")

#mi("{\\bf P}( n+2 \\text{ prime}) > \\frac{1}{4}  + \\varepsilon")

#mi("{\\bf P}( n+6 \\text{ prime}) > \\frac{1}{4} + \\varepsilon")

#mi("{\\bf P}( n+8 \\text{ prime}) > \\frac{1}{4}  + \\varepsilon")

#mi("{\\bf P}( n, n+8 \\text{ both prime}) \\leq \\varepsilon")#text(".")

#text("Then one could get a gap of at most 6, and not just 8, because the first four estimates show that there are two primes in n,n+2,n+6,n+8 with probability greater than ")#mi("\\varepsilon")#text(", and the last estimate excludes the possibility that this only occurs for the n,n+8 pair. Unfortunately with sieve theory it is difficult to get really good bounds on ")#mi("{\\bf P}( n, n+8 \\text{ both prime})")#text(", so I don’t know whether this idea will actually work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251755")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("Here is a slight refinement of the last idea. Assume EH, and suppose we want to improve the current bound of ")#mi("H_1 \\leq 12")#text(" to ")#mi("H_1 \\leq 10")#text(". Assume this were false, thus after some point there are no pairs of primes of distance 10 or less apart. Thus, given any large random integer n (chosen using a probability distribution ")#mi("\\nu(n) / \\sum_m\\nu(m)")#text("), the events “n prime”, “n+2 prime”, “n+6 prime”, “n+8 prime”, “n+12 prime” are all disjoint, except for the pair “n prime” and “n+12 prime” which are allowed to overlap. If we then let ")#mi("P_h")#text(" be the probability that ")#mi("n+h")#text(" is prime, and ")#mi("P_{0,12}")#text(" be the probability that n and n+12 are simultaneously prime, we thus have the inequality")

#mi("P_0 + P_2 + P_6 + P_8 + P_{12} \\leq 1 + P_{0,12}.")

#text("So if we can get a lower bound on")

#mi("\\sum_{h=0,2,6,8,12} \\sum_n 1_{n+h \\text{ prime}} \\nu(n)")#text(" (1)")

#text("which is asymptotically better than an upper bound for")

#mi("\\sum_n \\nu(n) + \\sum_n 1_{n,n+12 \\text{ prime}} \\nu(n)")

#text("then we can reduce ")#mi("H_1")#text(" from 12 to 10. The tricky thing though is still how to get a good upper bound on ")#mi("\\sum_n 1_{n,n+12 \\text{ prime}} \\nu(n)")#text(". But perhaps there is now a fair amount of “room” in the ratio between (1) and ")#mi("\\sum_n \\nu(n)")#text(" if we use more symmetric polynomials and enlarge the simplex as per Remark 1; the computations in Maynard’s paper show that this ratio is at least ")#mi("\\frac{1}{2} M_5 > 1.00058")#text(" which gives almost no room to play with, but perhaps with the above improvements one can get a more favorable ratio.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251757")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("Another comment in the same vein:")

#text("Instead of using ")#mi("\\sum_n \\nu(n)")#text(" we can use ")#mi("\\sum_n \\nu(n)-\\sum_n 1_{\\text{none of } n,n+2,\\dots,n+12 \\text{ prime}} \\nu(n)")#text(". We can therefore get a small improvement numerically from removing e.g. the contribution when all of ")#mi("n,n+2,n+6,n+8,n+12")#text(" have a small prime factor.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251787")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("I thought about this idea a bit more, but encountered a problem in the EH case: if one wants a meaningful lower bound on the second term, then one starts wanting to estimate sums such as ")#mi("\\sum_{d_1|n,d_2|n+2,\\ldots,d_5|n+12} \\nu(n)")#text(" for various values of ")#mi("d_1,\\ldots,d_5")#text(", but this is only plausible if the sieve level ")#mi("R^2")#text(" of ")#mi("\\nu")#text(" is a bit below the threshold of ")#mi("x")#text(" (by a factor of ")#mi("d_1\\ldots d_5")#text("), but then one is probably losing more from having a reduced sieve level ")#mi("R")#text(" (as it now has to be below the optimal value of ")#mi("x^{1/2}")#text(" that one wants to pick if one wants to get the maximum benefit of EH) than one is gaining from removing this piece.")

#text("However, the situation is better if one is starting from Bombieri-Vinogradov or MPZ as the distribution estimate (so one would now be trying to beat the 600 bound rather than the 12 bound). Here the sieve level ")#mi("R^2")#text(" is more like ")#mi("x^{1/2}")#text(" and so there is actually a fair bit of room to insert some divisibility constraints ")#mi("d_1|n,\\ldots,d_{105}|n+600")#text(" and still be able to control ")#mi("\\sum_{d_1|n,\\ldots,d_{105}|n+600} \\nu(n)")#text(". The bad news is that the final bound one gets here could be really small, something like ")#mi("105^{-105}")#text(" of the main term, which looks too tiny to lead to any actual improvement in the H value.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251911")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("Good point. Maybe (I haven’t really thought about this) we can use exponential sum estimates to get us a bit of extra room, but this is already sounding like quite a lot of work for what would be only a very small numerical improvement.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251848")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("I found a way to get an upper bound on the quantity")

#mi("\\displaystyle \\sum_n 1_{n,n+12 prime} \\nu(n)")

#text("(and hence ")#mi("P_{0,12}")#text(") but I don’t know how effective it will be yet. Basically, the idea is to observe that if ")#mi("\\nu")#text(" is given in terms of a multidimensional GPY cutoff function f as in equation (10) in the blog post, then when n and n+12 are both prime, we have ")#mi("\\nu(n) = \\nu^{\\prime}(n)")#text(", whenever ")#mi("\\nu^{\\prime}")#text(" is given in terms of another multidimensional GPY cutoff function f’ with the property that ")#mi("f(0,t_2,t_3,t_4,0) = f^{\\prime}(0,t_2,t_3,t_4,0)")#text(" for all ")#mi("t_2,t_3,t_4")#text(". Then")

#mi("\\displaystyle \\sum_n 1_{n,n+12 prime} \\nu(n) = \\sum_n 1_{n,n+12 prime} \\nu^{\\prime}(n)")#linebreak()#text(" ")#mi("\\displaystyle \\leq \\sum_n 1_{n prime} \\nu^{\\prime}(n)")#text(".")

#text("The last step is of course crude, but it crucially replaces a sum over two primality conditions (which is hopeless to estimate with current technology) with a sum over one primality condition (which we do know how to control, assuming a suitable distribution hypothesis). The final expression may be computed by Proposition 5 of the blog post to be")

#mi("\\displaystyle (1+o(1)) \\frac{Bx}{W} \\frac{\\log R}{\\log x} \\int f^{\\prime}_{2345}(0,t_2,t_3,t_4,t_5)^2\\ dt_2 dt_3 dt_4 dt_5")

#text("and so the probability ")#mi("P_{0,12}")#text(" above may be upper bounded by the ratio")

#mi("\\displaystyle \\frac{\\log R}{\\log x} \\frac{ \\int f^{\\prime}_{2345}(0,t_2,t_3,t_4,t_5)^2\\ dt_2 dt_3 dt_4 dt_5 }{ \\int f_{12345}^2(t_1,t_2,t_3,t_4,t_5)^2\\ dt_1dt_2 dt_3 dt_4 dt_5 } + o(1)")#text(".")

#text("If we set f’=f then this gives the trivial upper bound ")#mi("P_{0,12}\\leq P_0")#text(", but the point is that we can do better by optimising in f’.")

#text("Now the optimisation problem for f’ is much easier than the main optimisation for ")#mi("M_k")#text(": we need to optimise the square-integral of ")#mi("f^{\\prime}_{2345}(0,t_2,t_3,t_4,t_5)")#text(" subject to ")#mi("f^{\\prime}")#text(" being supported on the simplex and having the same trace as ")#mi("f")#text(" on the boundary ")#mi("t_1=t_5=0")#text(". (No symmetry hypothesis needs to be imposed on f’.) It is not difficult (basically fundamental theorem of calculus + converse to Cauchy-Schwarz) to see that the extremiser occurs with")

#mi("\\displaystyle f^{\\prime}_{2345}(0,t_2,t_3,t_4,t_5) = \\frac{f_{234}(0,t_2,t_3,t_4,0)}{1-t_2-t_3-t_4}")

#text("and so we have")

#mi("\\displaystyle P_{0,12} \\leq \\frac{\\log R}{\\log x} \\frac{ \\int \\frac{f_{234}(0,t_2,t_3,t_4,0)^2}{1-t_2-t_3-t_4}\\ dt_2 dt_3 dt_4 }{ \\int f_{12345}^2(t_1,t_2,t_3,t_4,t_5)^2\\ dt_1dt_2 dt_3 dt_4 dt_5 } + o(1)")#text(".")

#text("But I don’t know yet how strong this bound will be in practice; one needs ")#mi("f")#text(" to stay a little bit away from the extreme points of the simplex in order for the denominator ")#mi("\\frac{1}{1-t_2-t_3-t-4}")#text(" not to kill us. (On the other hand, as observed earlier, the bound can’t get worse than ")#mi("P_0")#text(".)")

#text("In the large k regime, the analogue of ")#mi("P_0,P_{12}")#text(" has size about ")#mi("\\log k/k")#text("; I’m hoping that the bound for ")#mi("P_{0,12}")#text(" is significantly smaller, indeed independence heuristics suggest it should be something like ")#mi("O( \\log^2 k / k^2 )")#text(". It’s dangerous of course to extrapolate this to the k=5 case but one can hope that it is still the case that ")#mi("P_{0,12}")#text(" is small compared to ")#mi("P_0")#text(" in this case.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251910")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("Nice! If we’re only using Bombieri-Vinogradov (or MPZ) then presumably we can use a hybrid bound, where if ")#mi("d_2d_3d_4")#text(" is small we use your argument as above, but if ")#mi("d_2d_3d_4")#text(" is larger we instead use ")#mi("\\displaystyle\\sum_n 1_{n,n+12 prime}\\nu (n)\\le \\sum_n \\nu ^{\\prime\\prime}(n)")#linebreak()#text(" (i.e. rather than forcing n to be prime and n+12 an almost-prime with a very small level-of-distribution, we relax this to n and n+12 being almost-primes.)")

#text("If we’re using Elliott-Halberstam then we get no use from this, since the primes have (apart from an ")#mi("\\epsilon")#text(") the same level-of-distribution results available.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251913")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("Certainly we have the option of deleting both primality constraints, but I’m not sure how one can separate the large ")#mi("d_2d_3d_4")#text(" case from the small ")#mi("d_2d_3d_4")#text(" case while retaining the positivity of all the relevant components of ")#mi("\\nu")#text(", which is implicitly used in order to safely drop the constraints that n is prime or n+12 is prime.")

#text("In the large k regime, if we take the sieve from your Section 8, but restrict it to a smaller simplex, such as ")#mi("\\{t_1+\\ldots+t_k \\leq 0.9\\}")#text(", then it does appear that the analogue of ")#mi("P_{0,12}")#text(" scales like ")#mi("\\log^2 k/k^2")#text(", which it should (morally we should have ")#mi("P_{0,12} \\sim P_0 P_{12}")#text(", though with current methods we could only hope for an upper bound that is of this order of magnitude). It would be interesting to see what numerics we can get in the k=5 case though.")

#text("One nice thing is that all the bounds for ")#mi("P_0, P_{0,12}")#text(", etc. are quadratic forms in the function f, so the same linear programming methods in your paper will continue to be useful here, without need for more nonlinear optimisation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251917")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("I guess I was imagining a Cauchy-Schwarz step:")#linebreak()#text(" ")#mi("\\displaystyle 1_{n,n+12 prime}(\\sum_{d_2,d_3,d_4}\\lambda_{d_2,d_3,d_4})^2")

#mi("\\displaystyle \\le 1_{n,n+12 prime}(\\sum_{d_2,d_3,d_4 `small^{\\prime}}\\lambda_{d_2,d_3,d_4})^2")

#mi("\\displaystyle +1_{n,n+12 prime}(\\sum_{d_2,d_3,d_4 `large^{\\prime}}\\lambda_{d_2,d_3,d_4})^2")#linebreak()#text(" and then using the separate bounds in for the different sums.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251922")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("Ah, I see. That could work, although one loses a factor of 2 from using the inequality ")#mi("(a+b)^2 \\leq 2a^2 + 2b^2")#text(" and so splitting might not be efficient in practice – but I guess we can experiment with all sorts of combinations to see what works numerically and what doesn’t.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251924")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("We can regain the factor of two by being a bit more careful. Let ")#mi("\\lambda_{d_2,d_3,d_4}=\\lambda_{small}+\\lambda_{large}")#text(", where ")#mi("\\lambda_{small}")#text(" is ")#mi("\\lambda")#text(" provided ")#mi("d_2d_3d_4")#text(" is small, and ")#mi("\\lambda_{large}")#text(" is the remainder. Then, expanding the square, we would use your bound for all the terms except the ")#mi("\\lambda_{large}\\lambda_{large}")#text(" terms. Of course, it might be that in practice that the benefit of doing this is small.")

#text("(PS: Apologies for the formatting errors I’ve had in my posts – I’ll try to check them more carefully)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251926")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("Ignore my last comment – this loses positivity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251927")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("Hmm… but in general, the ")#mi("\\lambda_{large}, \\lambda_{small}")#text(" do not have a definite sign, and so I don’t see how to discard the cutoffs ")#mi("1_{n \\text{ prime}}")#text(" or ")#mi("1_{n+12 \\text{ prime}}")#text(" in the cross terms ")#mi("\\sum_n 1_{n,n+12 \\text{ prime}} \\lambda_{small} \\lambda_{large}")#text(" unless one used Cauchy-Schwarz (which would be a little bit more efficient than the ")#mi("(a+b)^2 \\leq 2a^2+2b^2")#text(" inequality, though not by too much).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252135")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("Actually, I think the Cauchy step I suggested above is rubbish (I was clearly more tired last night than I realized). We would lose the vital filtering out of small primes, or we would be doing worse than just going one way or the other.")

#text("I think my concern was that with only a limited amount of room for divisibility constraints we might only be filtering out factors of ")#mi("n+12")#text(" which are typically less than ")#mi("N^{c/k}")#text(" for a constant ")#mi("c")#text(", and potentially losing a factor of ")#mi("k")#text(". (I’m thinking about the case when ")#mi("k")#text(" is large).I think this is what would be happening with the original GPY weights, but our weights are constructed so that the main contribution is when ")#mi("d_2\\dotsc d_k")#text(" is of size ")#mi("N^c")#text(" (some suitable constant ")#mi("c")#text("), which gives us enough room that we don’t need to worry here.")

#text("Presumably this would give an improvement to ")#mi("k_0")#text(" of size about ")#mi("k_0^{1/2}")#text(" (ignoring all log factors).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d60427dba63a6cfa10ccc224ed0398a20a625f4a6389acaf4bb6c4afd7824ee6-a0fd9e7a3bee10e8ecfcb2b71ce867b5ca593144801d5b37fafae36fced46e69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tristan Freiberg")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251789")[#strong[#text("Tristan Freiberg")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("Re (1), depends what exactly one means by GPY for APs, but GPY extended their original work to primes in APs — wasn’t me. My understanding is that these amazing new results apply equally well to admissible k-tuples of linear forms g_1x + h_1,…,g_kx + h_k, not just monic ones. I’m sure we’ll see lots of neat applications of this that we can get almost for free after Maynard’s spectacular proof!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251727")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("In the second sentence, is it mean that H_m is the least quantity such that there are infinitely many intervals of length H_m that contain m+1 (not m) or more primes?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251739")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("Dear Terry,")

#text("Could you expound a little bit on your Remark 1? If we are within epsilon of DHL[2,2] under EH, why don’t we have DHL[3,2] under EH?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251748")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("Good question! There is a funny failure of monotonicity when one tries to use the boost in Remark 1, which I’ll try to explain a bit more here.")

#text("Start with the task of trying to prove DHL[2,2], or more precisely the twin prime problem of finding two primes in ")#mi("n, n+2")#text(". The way we try to do this is to pick a sieve weight ")#mi("\\nu")#text(" which basically has the form")

#mi("\\nu(n) = \\sum_{d_1 | n, d_2|n+2} \\lambda_{d_1,d_2}")

#text("for some sieve coefficients ")#mi("\\lambda_{d_1,d_2}")#text(" whose exact value we will ignore for now. We then want to control sums such as")

#mi("\\sum_n \\nu(n)")#linebreak()#text(" ")#mi("\\sum_n \\theta(n) \\nu(n)")#linebreak()#text(" ")#mi("\\sum_n \\theta(n+2) \\nu(n).")

#text("The first sum can be easily estimated in practice, so let us ignore it for now and focus on the second two sums. At first glance, because of the two divisibility constraints ")#mi("d_1|n, d_2|n+2")#text(", it looks like we need ")#mi("d_1 d_2 < x")#text(" to have any real hope of controlling the sum; but note that the weight ")#mi("\\theta(n)")#text(" forces ")#mi("n")#text(" to be prime and so ")#mi("d_1")#text(" will be ")#mi("1")#text(", so we actually only need ")#mi("d_2 < x")#text(" to control the second sum, and similarly ")#mi("d_1 < x")#text(" to control the first sum. The upshot of this is that the function ")#mi("F")#text(" in the blog post only needs to be supported on the square ")#mi("\\{ (t_1,t_2): t_1,t_2 \\leq 1\\}")#text(" rather than the triangle ")#mi("\\{(t_1,t_2): t_1+t_2 \\leq 1\\}")#text(" (and if one then sets F equal to 1 on this square, one gets ")#mi("M_2 = 2")#text(", coming within an epsilon of the twin prime conjecture on EH).")

#text("[I'm glossing over some details as to how to deal with the allegedly easy first sum. If ")#mi("d_1 d_2 < x")#text(" then this sum is indeed easy to estimate, but if ")#mi("d_1 d_2")#text(" can exceed ")#mi("x")#text(" then one has to proceed more carefully. I think what one does here is try to use a separation of variables trick, breaking up ")#mi("\\nu")#text(" into pieces of the form ")#mi("\\nu_1(n) \\nu_2(n)")#text(", where ")#mi("\\nu_1(n) = \\sum_{d_1|n} \\lambda_{d_1}")#text(" is a divisor sum of ")#mi("n")#text(" only, and ")#mi("\\nu_2(n) = \\sum_{d_2|n+2} \\lambda_{d_2}")#text(" is a divisor sum of ")#mi("n+2")#text(" only, and then use an Elliott-Halberstam hypothesis for ")#mi("\\nu_1")#text(" or ")#mi("\\nu_2")#text(" (rather than ")#mi("\\theta")#text(") to control error terms; this should get us back to the weaker constraints ")#mi("d_1 < x")#text(", ")#mi("d_2 < x")#text(".]")

#text("Now we turn to DHL[3,2], playing with the tuple n,n+2,n+6. Now we use a sieve of the form")

#mi("\\nu(n) = \\sum_{d_1 | n, d_2|n+2, d_3|n+6} \\lambda_{d_1,d_2,d_3}")

#text("and want to estimate the sums")#linebreak()#text(" ")#mi("\\sum_n \\nu(n)")#linebreak()#text(" ")#mi("\\sum_n \\theta(n) \\nu(n)")#linebreak()#text(" ")#mi("\\sum_n \\theta(n+2) \\nu(n)")#linebreak()#text(" ")#mi("\\sum_n \\theta(n+6) \\nu(n)")#text(".")

#text("Again ignoring the first sum as being presumably easy to handle, we now need the constraints ")#mi("d_2 d_3 < x, d_1 d_3 < x, d_1 d_2 < x")#text(" in order to control the latter three sums respectively (rather than ")#mi("d_1 d_2 d_3 < x")#text("). In terms of the cutoff function F, this means that we may enlarge the support from the simplex ")#mi("\\{(t_1,t_2,t_3): t_1+t_2+t_3 \\leq 1 \\}")#text(" to ")#mi("\\{ (t_1,t_2,t_3): t_2+t_3, t_1+t_3, t_1+t_2 \\leq 1 \\}")#text(". But note now that we have a constraint ")#mi("d_1 d_2 < x")#text(" present for the 3-tuple problem which was not present in the 2-tuple problem, because we had no need to control ")#mi("\\sum_n \\theta(n+6) \\nu(n)")#text(" in the 2-tuple problem. So there is a failure of monotonicity; the simple example of ")#mi("F(t_1,t_2) = 1_{[0,1]}(t_1) 1_{[0,1]}(t_2)")#text(" which gets us within an epsilon of success for 2-tuples on EH doesn't directly translate to something for 3-tuples.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251763")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("Thinking about it a bit more, this lack of monotonicity is probably a sign that the arguments are not as efficient as they could be. In what one might now call the “classical” GPY/Zhang arguments, one relies on the Elliott-Halberstam conjecture just for the von Mangoldt function ")#mi("\\Lambda(n) = \\sum_{d|n} \\mu(d) \\log(n/d) = - \\sum_{d|n} \\mu(d) \\log d")#text(". To obtain the enlargement of the simplex, one would also need the EH conjecture for other divisor sums ")#mi("\\sum_{d|n} \\lambda_d")#text(", but this type of generalisation of EH is a standard extension (see e.g. Conjecture 1 of ")#link("http://link.springer.com/article/10.1007/BF02399204")[#text("Bombieri-Friedlander-Iwaniec")]#text(") and so this would not be considered that much more “expensive” than EH just for von Mangoldt (although the latter is pretty expensive at present!).")

#text("To recover monotonicity, one would have to also assume EH for hybrid functions such as ")#mi("\\Lambda(n+2) \\sum_{d|n} \\lambda_d")#text(". One could simply conjecture EH for such beasts, but this now looks considerably more “expensive” than the previous versions of EH (indeed, it may already be stronger than the twin prime conjecture, especially if the level of the divisor sum is allowed to be large). On the other hand, perhaps a Bombieri-Vinogradov type theorem for these hybrid functions is not unreasonable to hope for (though I am not sure exactly how this would help in a situation in which we already had EH for the non-hybrid functions).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251765")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("Thank you for this explanation. It makes a lot of sense.")

#text("I wonder if taking different admissible 3-tuples (e.g. {0,2,6} and {0,4,6}) and then weighting them appropriately in the sieve would allow further refinement of the support simplex.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251780")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("Unfortunately these tuples somehow live in completely different worlds and don’t seem to have much interaction. Specifically, the only chance we have to make ")#mi("n,n+2,n+6")#text(" prime for large n is if ")#mi("n = 2\\ (3)")#text(", while the only chance we have to make ")#mi("n, n+4, n+6")#text(" prime is if ")#mi("n=1\\ (3)")#text(". So any sieve that “sees” the first tuple in any non-trivial way would necessarily be concentrated on ")#mi("2\\ (3)")#text(", and any sieve that sees the second tuple would be concentrated instead on ")#mi("1\\ (3)")#text(". The distribution of primes in ")#mi("2\\ (3)")#text(" and in ")#mi("1\\ (3)")#text(" are more or less independent (one may at best save a multiplicative factor of two in the error terms by treating them together, which is negligible in the grand scheme of things), so I don’t think one gains much from a weighted average of sieves adapted to two different residue classes mod 3.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251795")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("Good point. I should have used {0,2,6} and {2,6,8} together instead. I think the idea in my head was something along the lines of your earlier post, about using probabilities in some ways. This would require our weights to discriminate against both 0 and 8 being prime simultaneously (in this case), and that appears to be a difficult task.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sylvain JULIEN")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251749")[#strong[#text("Sylvain JULIEN")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("You might be interested in the following heuristics conditional on a rather stronger form of Goldbach’s conjecture (that I call NFPR conjecture) explaining roughly why $H_{k}$ should be $O(k\\log k)$: ")#link("http://mathoverflow.net/questions/132973/would-the-following-conjectures-imply-lim-inf-n-to-inftyp-nk-p-n-ok-lo")[#text("http://mathoverflow.net/questions/132973/would-the-following-conjectures-imply-lim-inf-n-to-inftyp-nk-p-n-ok-lo")]#linebreak()#text(" It would be interesting to try to establish rigorously the presumably best possible upper bound $r_{0}(n)=O*(\\log^{2}n)$ that would settle both NFPR conjecture and Cramer’s conjecture: maybe you could start a future Polymath project to do so?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251767")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("One thought on the variational problem; for sake of discussion let us take k=3. The quantity ")#mi("M_3")#text(" is then the maximum value of")

#mi("3 \\int_{x+y \\leq 1} (\\int_{z \\leq 1-x-y} F(x,y,z)\\ dz)^2 dx dy")

#text("for symmetric F(x,y,z) supported on the simplex ")#mi("\\{x+y+z \\leq 1\\}")#text(" subject to the constraint")

#mi("\\int_{x+y+z \\leq 1} F(x,y,z)^2\\ dx dy dz = 1.")

#text("(As discussed earlier, we can hope to enlarge this simplex to the larger region ")#mi("\\{x+y,y+z,z+x \\leq 1\\}")#text(", but let us ignore this improvement for now.) In Maynard’s paper, one considers arbitrary polynomial combinations of the first two symmetric polynomials ")#mi("P_1 = x+y+z")#text(", ")#mi("P_2=x^2+y^2+z^2")#text(" as candidates for F.")

#text("However, we know from Lagrange multipliers (as remarked after (7.1) in Maynard’s paper) that the optimal F must be a constant multiple of")

#mi("\\int_0^{1-x-y} F(x,y,t)\\ dt + \\int_0^{1-x-z} F(x,t,z)\\ dt + \\int_0^{1-y-z} F(t,y,z)\\ dt")

#text("and so in particular takes the form")

#mi("F(x,y,z) = G(x,y)+ G(x,z) + G(y,z)")

#text("for a symmetric function G(x,y) of two variables supported on the triangle ")#mi("\\{x+y \\leq 1\\}")#text(". So one could collapse the three-dimensional variational problem to a two-dimensional one, which in principle helps avoid the “curse of dimensionality” and would allow one to numerically explore a greater region of the space of symmetric functions (e.g. by writing everything in terms of G and expanding G into functions of symmetric polynomials such as ")#mi("x+y, x^2+y^2")#text(").")

#text("It is possible that one could iterate this process and reduce to a one-dimensional variational problem, but it looks messy and I have not yet attempted this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251786")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("I was unable to iterate the reduction in dimension step more than once. (This is roughly why I was able to solve the eigenfunction equation when ")#mi("k_0=2")#text(", since it reduces to solving a single variable PDE, but not for ")#mi("k_0>2")#text(").")

#text("The eigenfunction equation for ")#mi("G(x,y)")#text(" looks like")#linebreak()#text(" ")#mi("(\\lambda-1+x+y)G(x,y)=\\int_0^{1-x-y}(G(x,t)+G(t,y))dt,")#linebreak()#text(" and I failed to get anything particularly useful out of this (although maybe someone else has some clever ideas – I’m far from an expert at this. Differentiating wrt x and y turns this into a two variable PDE). One can do some sort of iterative substitution, but I just got a mess.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251777")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("Notation:")

#text("* Use “")#mi("\\liminf_{n\\to\\infty}")#text("” instead of “")#mi("\\lim\\inf_{n\\to\\infty}")#text("”. (Also, it is easier to use “")#mi("\\to")#text("” than “")#mi("\\rightarrow")#text("”.)")#linebreak()#text(" * Use “")#mi("m\\textsuperscript{th}")#text("” instead of “")#mi("m^{th}")#text("”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251781")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("By representing ")#mi("M_{k_0}")#text(" as the largest eigenvalue of a certain non-negative integral operator, a simple upper bound for ")#mi("M_{k_0}")#text(" (implying some limitations of the method) is given by the operator trace.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251788")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("A cheap way to combine Maynard’s paper with the Zhang/Polymath8a stuff: if ")#mi("MPZ[\\varpi,\\delta]")#text(" is true, then we have ")#mi("H_m \\ll \\exp( \\frac{m}{1/4+\\varpi} + o(m) )")#text(" as ")#mi("m \\to\\infty")#text(". The reason for this is that the function F (or f) constructed in the large k_0 setting is supported in the cube ")#mi("[0,T/k_0]^{k_0}")#text(" (as well as in the simplex); by construction, ")#mi("T/k_0")#text(" decays like ")#mi("\\log^{-3} k_0")#text(", so in particular f will be supported on ")#mi("[0, \\frac{\\delta}{1/4+\\varpi}]^{k_0}")#text(" for ")#mi("k_0")#text(" large enough. This means that the moduli that come out of the sieve asymptotic analysis will be ")#mi("x^\\delta")#text("-smooth, and so MPZ may be used in place of EH much as in Zhang (or Polymath8a).")

#text("So using our best verified value 7/600 of ")#mi("\\varpi")#text(", we have the bound ")#mi("H_m \\ll \\exp( 3.822 m)")#text(", and using the tentative value 13/1080 this improves to ")#mi("H_m \\ll \\exp( 3.817 m)")#text(". Not all that dramatic of an improvement, but it does show that the Polymath8a stuff is good for something :).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251796")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("The computations in Section 8 of Maynard’s paper should give explicit values of H_m for small m that are fairly competitive with the bound ")#mi("H_1 \\leq 600")#text(", I think.")

#text("For simplicity let us just work off of Bombieri-Vinogradov (so ")#mi("\\theta")#text(" is basically 1/2); one can surely push things further by using the MPZ estimates, but let’s defer that to later. The criterion (Proposition 4.2 of Maynard, or Corollary 6 here) is then that ")#mi("H_m \\leq H(k)")#text(" holds whenever ")#mi("M_k > 4m")#text(", where ")#mi("H(k)")#text(" is the diameter of the narrowest k-tuple. For instance, ")#mi("M_{105} > 4")#text(" gives ")#mi("H_1 \\leq 600")#text(".")

#text("In Section 8 of Maynard, the lower bound")

#mi("\\displaystyle M_k \\geq \\frac{m_1^2}{m_2} (1 - \\frac{T}{k(1-T/k-\\mu)^2} )")#text(" (1)")

#text("holds for any ")#mi("A,T > 0")#text(" such that")

#mi("\\displaystyle 1-T/k-\\mu > 0")#text(" (1′)")

#text("where")

#mi("\\displaystyle m_1 = \\frac{\\log(1+AT)}{A}")

#mi("\\displaystyle m_2 = \\frac{1}{A} (1 - \\frac{1}{1+AT} )")

#mi("\\displaystyle \\mu = \\frac{1}{m_2} \\frac{1}{A^2} ( \\log(1+AT) - 1 + \\frac{1}{1+AT} )")#text(".")

#text("(here ")#mi("m_i")#text(" are the moments ")#mi("m_i = \\int_0^T g(t)^i dt")#text(", where ")#mi("g(t) = \\frac{1}{1+At}")#text(".) It looks like a fairly routine matter to optimise A,T for any given k, and then find the first k with ")#mi("M_k > 4")#text(" (to get a ")#mi("H_1")#text(" bound), the first k with ")#mi("M_k > 8")#text(" (to get a ")#mi("H_2")#text(" bound), and so forth.")

#text("Actually there is some room to improve things a bit; if one inspects Maynard’s argument more carefully, one can improve (1) to")

#mi("\\displaystyle M_k \\geq \\frac{m_1^2}{m_2} (1 - \\frac{(k-1)\\sigma^2}{(k - T - (k-1)\\mu)^2} )")#text(" (2)")

#text("where ")#mi("\\sigma^2")#text(" is the variance")

#mi("\\displaystyle\\sigma^2 = \\frac{1}{m_2} \\int_0^T t^2 g(t)^2\\ dt - \\mu^2")#linebreak()#text(" ")#mi("\\displaystyle = \\frac{T}{A^2} + \\frac{T}{A^2(1+AT)} - \\frac{2 \\log(1+AT)}{A^3} - \\mu^2")

#text("and the criterion (1′) is replaced with")

#mi("k-T-(k-1)\\mu > 0")#text(" (2′)")

#text("which could lead to some modest improvement in the numerology. (I also have an idea on removing the -T in the denominator in (2) and (2′) (or the -T/k in (1) and (1′), but this is a bit more complicated.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251808")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("“The computations in Section 8 of Maynard’s paper should give explicit values of H_m for small m that are fairly competitive with the bound H_1 \\leq 600, I think.”")

#text("Assuming I didn’t make any errors, for ")#mi("m=1")#text(" you can get ")#mi("k=145")#text(" rather easily with your improved equations. (Take ")#mi("T=21,A=5.3")#text(" for example.) I couldn’t get ")#mi("k=144")#text(" to work out. Also, I didn’t try to do ")#mi("m=2")#text(" so others might want to give it a try.")

#text("I didn’t do anything fancy to find the solution for ")#mi("k=145")#text(" — just made a lot of graphs. Similarly, for ")#mi("k=144")#text(" I just graphed enough points so that I was convinced that the maximum for the RHS of (2) is less than 4.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251810")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("P.S. While I was playing around with trying to actually find the optimal solution, I did notice that making the substitution ")#mi("A=(B-1)/T")#text(" (for some variable ")#mi("B>1")#text(", which we may want to replace with an exponential) simplifies things quite a bit. For instance, this allows one to convert (2′) into an inequality of the form ")#mi("T< f(B,k)")#text(" for a function ")#mi("f")#text(" (which has a number of nice properties).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251811")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("P.P.S. I just discovered the “FindMaximum” function in Mathematica, which concurs with my findings. When ")#mi("k=145")#text(", It says that the RHS of (2) takes a maximum value of ")#mi("4.00324717")#text(" when (2′) holds, at ")#mi("T=21.9045,A=5.45969")#text(". On the other hand, when ")#mi("k=144")#text(", then the RHS of (2) is less than 4, when (2′) holds.")

#text("If this function is to be believed, when ")#mi("m=2")#text(" then ")#mi("k=13986")#text(" is the lowest ")#mi("k")#text(" value for which the RHS of (2) is bigger than 8 when (2′) also holds. One takes ")#mi("T=994.001,A=10.0689")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251826")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#mi("k=13986")#text(" for ")#mi("m=2")#text(" gives ")#mi("H_2 \\le 145212")#text(".")#linebreak()#text(" The admissible ")#mi("k")#text("-tuple is ")#link("http://math.mit.edu/~drew/admissible_13986_145212.txt")[#text("here")]#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251885")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("In light of James’ calculation below that a naive insertion of ")#mi("\\varpi=7/600")#text(" (or ")#mi("\\varpi=13/1080")#text(") gives good results for the small k numerics, it is now tempting to do the same for the large k asymptotics given above.")

#text("If one does things optimistically (ignoring ")#mi("\\delta")#text("), then all one has to do is replace the condition ")#mi("M_k > 4m")#text(" with ")#mi("M_k > \\frac{m}{1/4+\\varpi}")#text(" for one’s favourite value of ")#mi("\\varpi")#text(". Given that in the small k case this improved 105 to 68, perhaps we could hope that 145 improves to below 105?")

#text("To do things properly (i.e. rigorously), we unfortunately have to also take into account ")#mi("\\delta")#text(", and specifically there is an annoying new constraint")

#mi("\\displaystyle \\frac{T}{k_0} \\leq \\frac{\\delta}{1/4+\\varpi}")

#text("needed to ensure that all the moduli involved are ")#mi("x^\\delta")#text("-smooth. This (when combined with either ")#mi("\\frac{600}{7} \\varpi + \\frac{180}{7} \\delta < 1")#text(" or ")#mi("\\frac{1080}{13} \\varpi + \\frac{330}{13} \\delta < 1")#text(") is likely to cause some degradation in the bounds, but at least these bounds would be rigorous.")

#text("On the other hand, we do know that our MPZ estimates only need a certain amount of dense divisibility rather than smoothness. It is likely that one could modify the above arguments (probably by introducing two different deltas, much as we did in Polymath8a) we could reduce the dependence on delta to the point where it is almost negligible. But this looks a little tricky and is probably best deferred until a little later.")

#text("p.s. Gah, I just realised that my formula for ")#mi("\\sigma^2")#text(" given previously was incorrect, as I had lost the ")#mi("m_2")#text(" factor. The true formula for ")#mi("\\sigma^2")#text(" is")

#mi("\\displaystyle \\sigma^2 = \\frac{1}{m_2}( \\frac{T}{A^2} + \\frac{T}{A^2(1+AT)} - \\frac{2 \\log(1+AT)}{A^3} ) - \\mu^2")

#text("which unfortunately is likely to make the previous computations a little bit worse. Sorry about that!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251889")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("With the corrected formula for ")#mi("\\sigma^2")#text(", the FindMaximum command gives the following results:")

#text("For ")#mi("m=1")#text(", we have ")#mi("k=582, T=38.5972,A=6.91488")#text(".")

#text("For ")#mi("m=2")#text(", we have ")#mi("k=59451,T=1574.21,A=10.9443")#text(".")

#text("I’ll give your other improvement some thought when I have more time.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251897")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("Thanks for the quick recalculation! It’s a shame that we lost a factor of 5 due to the error, although we still beat Polymath8a, for what it’s worth…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251997")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("With ")#mi("k = 59451")#text(" we get ")#mi("H_2 \\le 698288")#text(" with this ")#link("http://math.mit.edu/~drew/admissible_59451_698288.txt")[#text("tuple")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251894")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("Just had an initial try for ")#mi("\\frac{1080}{13} \\varpi + \\frac{330}{13} \\delta < 1")#text(". Seems ")#mi("k")#text(" cannot be dropped down too far. Here is a possible solution ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi1080d13_508.mpl")[#text("508")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251921")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("Using ")#mi("\\frac{1080}{13}\\varpi + \\frac{330}{13}\\delta <1")#text(", xfxie's ")#mi("k")#text(" appears optimal for ")#mi("m=1")#text(". For ")#mi("m=2")#text(", we can get ")#mi("k=42392")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252106")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("This gives the lower bound ")#link("https://math.mit.edu/~drew/admissible_42392_484290.txt")[#text("484290")]#text(" on ")#mi("H_2")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252123")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("Of course I meant to say upper bound :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252138")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("Actually we can get H_2 down to ")#link("https://math.mit.edu/~drew/admissible_42392_484276.txt")[#text("484276")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252184")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("The link to the 484276 tuple keeps throwing 403")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252200")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("Fixed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252819")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2013")])]

#text("For ")#mi("k")#text("=42392, seems ")#mi("H")#text(" can be further down to ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/admissible_42392_484272_-211144.txt")[#text("484272")]#text(" :).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252823")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2013")])]

#text("Slight further improvement: ")#link("http://math.mit.edu/~drew/admissible_42392_484260.txt")[#text("484260")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252857")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2013")])]

#text("Further improved to ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/admissible_42392_484238_-211144.txt")[#text("484238")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252928")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2013")])]

#text("Another small improvement: ")#link("http://math.mit.edu/~drew/admissible_42392_484234.txt")[#text("484234")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252951")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2013")])]

#text("Can be further down to ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/admissible_42392_484200_-210008.txt")[#text("484200")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252988")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2013")])]

#text("A little more progress: ")#link("http://math.mit.edu/~drew/admissible_42392_484192.txt")[#text("484192")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-253019")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#link("https://math.mit.edu/~drew/admissible_42392_484176.txt")[#text("484176")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-253160")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2013")])]

#text("Can be dropped to: ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/admissible_42392_484168_-209744.txt")[#text("484168")]#text(" (for k=42392).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-253278")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2013")])]

#link("https://math.mit.edu/~drew/admissible_42392_484162.txt")[#text("484162")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-253381")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2013")])]

#link("http://math.mit.edu/~drew/admissible_42392_484142.txt")[#text("484142")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-253621")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2013")])]

#link("http://math.mit.edu/~drew/admissible_42392_484136.txt")[#text("484136")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-253661")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2013")])]

#link("http://math.mit.edu/~drew/admissible_42392_484126.txt")[#text("484126")]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46e7a76cd66a757d19d9f5af908aaed13cda328d2dc85fc45cb638835f8f0b2a-8f4cfbdf2ec7a89c9d4c76f0eb76619c0bc29a5ea4ff8cf298140822c00bc6f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andre")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251798")[#strong[#text("andre")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("Please forgive me my ignorance, I even didn’t fully read Maynard’s preprint.")#linebreak()#text(" On page 5, in Proposition 4.1, he defines ")#mi("J_k^{(m)}(F)")#text(" with an outer integration over the (k-1)-dim. cube. On page 19, along the proof of Lemma 7.2, formula (7.12) he uses an outer integration over the (k-1)-dim simplex. So my question is, if the outer integration in the definition of ")#mi("J_k^{(m)}(F)")#text(" was over the (k-1)-dim simplex, too?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251806")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("In Lemma 7.2, one is only considering functions F of the form defined in (7.3), which are supported on the simplex, and so integration of such functions in the cube is the same as on the simplex.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251799")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("It seems that the largest eigenvalue of the operator defined in (7.2) of Maynard’s preprint is the square root of ")#mi("M_k")#text(" (not ")#mi("M_k")#text(" as remarked there.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251800")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("In fact, the exact relationship between the above linear operator and ")#mi("M_k")#text(" is not sufficiently clear to me.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251804")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("The connection comes from the identity")

#mi("\\sum_{m=1}^k J_k^{(m)}(F) = \\int_{{\\mathcal R}_k} F {\\cal L} F")

#text("which shows that ")#mi("M_k")#text(" is the largest eigenvalue of ")#mi("{\\cal L}")#text(". (Actually, as ")#mi("{\\cal L}")#text(" is not quite compact, although it is bounded, self-adjoint, and positive definite, one has to be a little careful here with the spectral theory to ensure that ")#mi("{\\cal L}")#text(" only has point spectrum at its operator norm; I think it will work out though, I will try to supply some details later. In any case this doesn’t impact the substance of Maynard’s paper, as one never actually analyses eigenfunctions in that paper.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251809")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("Thanks for the explanation! One may use this to show that for each given polynomial P, the ratio for ")#mi("L P")#text(" should increase (unless P is optimal). This gives iterative process for improving ")#mi("F")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252133")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("A little expansion of Eytan’s remark (a version of the ")#link("http://en.wikipedia.org/wiki/Power_iteration")[#text("power method")]#text("): from Cauchy-Schwarz one has")

#mi("\\displaystyle (\\int_{{\\cal R}_k} f {\\cal L} f)^2 \\leq (\\int_{{\\cal R}_k} f f)  (\\int_{{\\cal R}_k} {\\cal L} f {\\cal L} f)")

#text("which upon rearranging means that the Rayleigh quotient ")#mi("\\int_{{\\cal R}_k} f {\\cal L} f / \\int_{{\\cal R}_k} f f")#text(" is non-decreasing if one replaces ")#mi("f")#text(" by ")#mi("{\\cal L}^{1/2} f")#text(". Iterating this, we may replace ")#mi("f")#text(" by ")#mi("{\\cal L} f")#text(" (or any higher power ")#mi("{\\cal L}^m f")#text(" and guarantee a better lower bound on ")#mi("M_k")#text(" unless one is already at an eigenfunction.")

#text("This suggests that we can improve the large k analysis (and in particular, the m=2 values) by taking our current candidate for f and applying ")#mi("{\\cal L}")#text(" to it to obtain a new candidate that is guaranteed to be better. This is a bit messy though; a simpler (though slightly less efficient) approach would be to compute ")#mi("\\int_{{\\cal R}_k} {\\cal L} f {\\cal L} f")#text(" instead of ")#mi("\\int_{{\\cal R}_k} f {\\cal L} f")#text(" and use the inequality")

#mi("M_k^2 \\geq \\int_{{\\cal R}_k} {\\cal L} f {\\cal L} f / \\int_{{\\cal R}_k} f f")

#text("to obtain what should presumably be a better lower bound for M_k than what we currently have.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252159")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("In general this iteration gives linear convergence to ")#mi("M_k")#text(", so one may try to accelerate it numerically (e.g. by Aitken’s ")#mi("\\delta ^2")#text(" method.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251840")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("It seems that the integral operator above is compact since its representing integrand is continuous on its domain (i.e. the product of the simplex in t and the simplex in u.)")#linebreak()#text(" But I don’t see why its representing integrand is symmetric (as it should for a self-adjoint operator)!")

#text("I suggest to see if the integrands representing powers of this operators can be evaluated explicitly (e.g. by the integrand composition operation) – so the traces of (small) powers of the operator may be evaluated – giving upper bounds for corresponding powers of ")#mi("M_k")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251845")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("One can check by hand that ")#mi("\\int F {\\cal L} G = \\int G {\\cal L} F")#text(" for any (say) bounded compactly supported F,G on the simplex.")

#text("The operator ")#mi("{\\cal L}")#text(" is not quite an integral operator because each of the ")#mi("k")#text(" components only integrates in one of the dimensions rather than all ")#mi("k")#text(" of the dimensions. As such, it doesn’t look compact, but may still have pure point spectrum, at least at the top of the spectrum (I have to check this). In particular, I don’t expect the traces of powers of this operator to be finite. A model case here is the operator ")#mi("T: L^2([0,1]^2) \\to L^2([0,1]^2)")#text(" given by")

#mi("T f(x,y) := \\int_0^1 f(x,t)\\ dt")

#text("which is positive semi-definite and bounded with an operator norm of 1, but has an infinity of eigenfunctions at 1 (any f that is independent of y will be an eigenfunction).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251850")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("Thanks! (I see now my error.)")

#text("Anyway, I think that it is also important to get also some upper bounds for ")#mi("M_k")#text(" (to estimate the tightness of its lower bounds and to get some limitations of the method.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251870")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("I no longer have any clear intuition as to whether the spectrum of ")#mi("{\\cal L}")#text(" is pure point, absolutely continuous, or some combination of both (it could also possibly have singular continuous spectrum); the situation could be as complicated as it is for discrete or continuous Schrodinger operators, which have a very wide range of possible behaviours. Consider for instance the model operator")

#mi("T F(x,y) = \\int_0^{1-x} F(x,t)\\ dt")

#text("on the triangle ")#mi("\\Delta = \\{ (x,y): x+y \\le 1\\}")#text(" (all variables are assumed to be non-negative); this is one of the two components of ")#mi("{\\cal L}")#text(" in the k=2 case. One can split ")#mi("L^2(\\Delta)")#text(" into the functions that are constant in the y direction, and functions that are mean zero in the y direction. The operator T annihilates the latter space, and acts by multiplication by ")#mi("1-x")#text(" on the former space. So there is absolutely continuous spectrum on ")#mi("[0,1]")#text(" and a big null space at 0. The operator norm of 1 is not attained by any function, but one can get arbitrarily close to this norm by, e.g. the indicator function of the rectangle ")#mi("[0,\\varepsilon] \\times [0,1-\\varepsilon]")#text(" for ")#mi("\\varepsilon > 0")#text(" (one can normalise to have unit norm in L^2 if one wishes).")

#text("Despite the possible lack of eigenfunctions (which in particular may mean that in some cases the maximum of the ratio ")#mi("\\sum_{m=1}^k J_k^{(m)}(F)/I(F)")#text(" is not attainable), I believe it is still correct that the operator norm of ")#mi("{\\cal L}")#text(" for all functions on the simplex is the same as the operator norm of ")#mi("{\\cal L}")#text(" for symmetric functions on the simplex, which informally means that we can restrict without loss of generality to the case of symmetric functions F. To see this, suppose that we have a sequence ")#mi("F_n")#text(" of ")#mi("L^2")#text("-normalised functions on the simplex which is a extremising sequence for ")#mi("\\int F_n {\\cal L} F_n = \\sum_{m=1}^k J_k^{(m)}(F_n)")#text(", thus this sequence approaches the supremum ")#mi("M_k")#text(" as ")#mi("n \\to\\infty")#text(". By replacing ")#mi("F_n")#text(" with its absolute value ")#tao-math("\\left|F_n\\right|", block: false)#text(" (which does not change the L^2 norm, but can only serve to increase the ")#mi("J_k^{(m)}(F_n)")#text(") we may assume that the ")#mi("F_n")#text(" are non-negative. In particular, the projection ")#mi("F_n")#text(" to the symmetric functions (i.e. the symmetrisation of ")#mi("F_n")#text(") is bounded away from zero (in fact it is at least ")#mi("1/k!")#text("). An application of the parallelogram law (or the spectral theorem) shows that any average of two or more extremising sequences is again an extremising sequence (if the norms stay away from zero), so the symmetrised ")#mi("F_n")#text(" are also extremising. (One could also have taken a slightly higher-minded approach and split up ")#mi("{\\cal L}")#text(" according to isotypic ")#mi("S_k")#text(" components here if one wished.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251872")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("My tentative understanding of what is going on near the top of the spectrum is that if one has strict monotonicity ")#mi("M_k > M_{k-1}")#text(" then the supremum should be obtained by an eigenfunction of ")#mi("{\\cal L}")#text(", but if one has equality ")#mi("M_k = M_{k-1}")#text(" then the near-extrema may instead be obtained from lower-dimensional functions, e.g. functions of the form ")#mi("F(t_1,\\ldots,t_k) = F_\\varepsilon(t_1,\\ldots,t_{k-1}) 1_{[0,\\varepsilon]}(t_k)")#text(" where ")#mi("F_\\varepsilon")#text(" is a near-extremiser of the ")#mi("k-1")#text("-dimensional problem (supported on a slightly shrunken version of the ")#mi("k-1")#text("-dimensional simplex).")

#text("It is presumably the case that the ")#mi("M_k")#text(" are strictly increasing (except possibly for very small k), but I don’t see how one would prove this other than numerically (and even numerical verification is a bit of a challenge because we do not yet have good upper bounds on ")#mi("M_k")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252218")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("A “steepest descent” type iteration for ")#mi("M_k")#text(":")

#text("Consider the ratio")

#mi("R(x) = \\langle x, L x \\rangle / \\langle x, x \\rangle")

#text("In a given Hilbert space ")#mi("X")#text(" (in our case ")#mi("L^2")#text(" over the simplex) where L is a linear, symmetric, bounded operator on ")#mi("X")#text(".")

#text("Clearly, we need to consider ")#mi("\\log R(x)")#text(" whose first variation is")

#mi("g(x) = 2 L x / \\langle x, L x \\rangle  - 2 x / \\langle x, x \\rangle")

#text("Note that ")#mi("g(x)")#text(" may be interpreted as the “gradient” of ")#mi("\\log R")#text(" at x. This implies the “line search” iteration")

#mi("x_{j+1} = x_j + \\alpha_j d(x_j)")

#text("Where ")#tao-math("d(x_j) = g(x_j)/ \\left|\\left|g(x_j)\\right|\\right|", block: false)#text(" is the direction of search and")#linebreak()#text(" ")#mi("\\alpha_j \\geq 0")#text(" is the search step size (determined to maximize the ratio at ")#mi("x_{j+1}")#text(".")

#text("Remarks:")

#text("1. If ")#mi("x_0")#text(" is a polynomial then all ")#mi("x_j")#text(" are polynomials.")

#text("2. It is easy to find the closed form formula for the search step size.")

#text("3. This search can be improved to a “conjugate gradient” type search (and perhaps even to “quasi Newton” type methods) with quadratic convergence rate!")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252309")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("It should be remarked that in all iterative methods of this type (i.e. “gradient based”), ")#mi("x_j")#text(" is a linear combination of ")#mi("x_0, L x_0, ..., L^{j-1} x_0")#text(" – for which Maynard’s method (for best linear combination) should be applied on these basis functions.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2e54664627aa86221000c04fa45f6626e59e5feb9c42b489c40c1c62b8d1354-d4fb613dd9fabf0e54929d5df79eb293b8f4730c5427b793d47fa51ebcb8a578.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andreas")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251831")[#strong[#text("Andreas")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("Shouldn’t that be “where $p_n$ denotes the $n$-th prime” in the beginning?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251841")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("I think you are right. Also, I would write “")#mi("(p_{n+m}-p_n)")#text("”, i.e., with parentheses.")

#text("The improvements suggestioned in ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251777")[#text("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251777")]#text(" could also be incorporated. :)")

#emph[#text("[Changes now made – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251876")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("One numerical data point that people might find interesting:")

#text("Assume ")#mi("EH[1/4+\\varpi]")#text(" with the provisional value ")#mi("\\varpi=7/600")#text(". Using computations as in my paper (a polynomial approximation of terms ")#mi("P_1^b(1-P_2)^c")#text(" with ")#mi("b+2c\\le 13")#text(", we find for ")#mi("k_0=68")#text(" that ")#mi("M_{68}>3.822...")#text(". We find then that ")#mi("(1/4+7/600)M_{68}>1")#text(", and so two primes with ")#mi("k_0=68")#text(", which corresponds to gaps of size 356.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251877")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("That’s smaller than I would have expected, given that ")#mi("1/4 + 7/600")#text(" is only 5% or so bigger than 1/4. (Incidentally, with our conventions, we would use ")#mi("EH[2 * (1/4+\\varpi) ]")#text(" rather than ")#mi("EH[1/4+\\varpi]")#text(". But I guess since ")#mi("M_5")#text(" is already as large as 2, and ")#mi("M_k")#text(" seems to grow logarithmically, it isn’t so unreasonable.")

#text("Do you have some preliminary data on how your lower bounds on ")#mi("M_k")#text(" behave in k for small k (e.g. up to 105)? This would give a baseline for further numerical improvement, and would also give a better sense as to what kind of growth ")#mi("M_k")#text(" should have (given that the values should be pretty good for small k, perhaps enough to do some reliable extrapolation).")

#text("Of course we have to play with MPZ instead of EH, which causes some difficulties (specifically, we can’t play on the entire simplex, but must truncate to the cube ")#mi("[0, \\frac{\\delta}{1/4+\\varpi}]^k")#text("), but it does show that there is hopefully a fair bit of room for improvement.")

#text("Incidentally, the 7/600 value is not so provisional (once Emmanuel signs off on Section 10 of the Polymath8a paper, in particular, it would have been checked at least once). We have a much more tentative value of 13/1080 that is not fully verified (it requires some difficult algebraic geometry that we haven’t got around to yet) but it might be interesting to see how much more of a gain one could expect with this slightly better value.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251896")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("The growth looks roughly logarithmic.")

#text("A reasonable approximation for ")#mi("10 <k_0<100")#text(" is ")#mi("M_{k_0} \\approx 0.6\\log{k_0}+1.3")#text(".Specifically, for ")#mi("k_0=10,20,...100")#text(" I get the following bounds: 2.53, 3.05, 3.34, 3.52, 3.66, 3.76, 3.84, 3.90, 3.95, 3.99.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ffe89443b5bd903c46f0e36ab16b745fe9977f85cacf9fec586271c4ed2cea0b-ac4fdc455655250683cd6bc175d5a2b4626c30d38b6f18e26772587f5e3831e4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stijn Hanson")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251879")[#strong[#text("Stijn Hanson")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("Sorry for the stupid question but, In Maynard’s Lemma 5.1 (and roughly in here just below (10) ) it states that if ")#mi("W, [d_1, e_1], \\ldots, [d_k, e_k]")#text(" are not pairwise coprime then ")#mi("n \\cong v_0 \\pmod{W}")#text(" and ")#mi("[d_i,e_i]|n+h_i")#text(" cannot be satisfied by any n. It’s utterly trivial if d divides n and one of the lcms but I can’t seem to understand why it works if d divides two of the lcms.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251898")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("If d divides both ")#mi("[d_i,e_i]")#text(" and ")#mi("[d_j,e_j]")#text(", then it divides ")#mi("n+h_i")#text(" and ")#mi("n+h_j")#text(", and hence also ")#mi("h_i-h_j")#text(". On the other hand, since ")#mi("n+h_i")#text(" is coprime to W, ")#mi("d")#text(" must be coprime to ")#mi("W")#text(". Since ")#mi("W")#text(" is the product of all small primes, and in particular all primes dividing ")#mi("h_i-h_j")#text(" (if x is large enough), we obtain a contradiction.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252167")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("I think there is a probabilistic interpretation of M_k, as follows. Consider the following random process ")#mi("x^{(0)}, x^{(1)}, \\ldots \\in [0,1]^k")#text(" on the unit cube as follows:")

#text("* ")#mi("x^{(0)}")#text(" is chosen uniformly at random from the unit cube.")

#text("* Once ")#mi("x^{(i)}")#text(" is chosen, ")#mi("x^{(i+1)}")#text(" is chosen by taking ")#mi("x^{(i)}")#text(", selecting a random coordinate of ")#mi("x^{(i)}")#text(", and replacing it with a number chosen uniformly from [0,1] independently of all previous choices.")

#text("(For the chess-oriented, this process describes a (k-dimensional) rook moving randomly in the unit cube.)")

#text("The probability that ")#mi("x^{(0)},\\ldots,x^{(n)}")#text(" all lie in the simplex is ")#mi("\\int_{{\\cal R}_k} 1 k^{-n} {\\cal L}^n 1")#text(", which asymptotically is ")#mi("(M_k/k + o(1))^n")#text(" as ")#mi("n \\to \\infty")#text(". So ")#mi("M_k")#text(" is measuring the exponential decay of the probability that the randomly moving rook always stays inside the simplex.")

#text("Among other things, this suggests that a Monte Carlo method might be used to approximate ")#mi("M_k")#text(", although this would not give rigorous deterministic bounds on ")#mi("M_k")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-267313")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2014")])]

#text("Is it possible to give to ")#mi("M_k")#text(" a quantum mechanical interpretation as well? (The problem is to give a quantum mechanical interpretation to the operator ")#mi("\\mathcal L")#text(" – which may make sense in smaller dimensions like 3,4).")#linebreak()#text(" Perhaps quantum mechanical bounds (a kind of “uncertainty principle”) bounds may be obtained for ")#mi("M_k")#text("?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252202")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("Here are my (unfortunately somewhat lengthy) computations for the second moment ")#mi("\\int f {\\mathcal L}^2   f")#text(" for the function")

#mi("\\displaystyle f(t_1,\\ldots,t_k) = \\prod_{i=1}^k k^{-1/2} m_2^{-1/2} g(k t_i) 1_{t_1+\\ldots+t_k \\leq 1}")

#text("used in the large k analysis, with the quantities ")#mi("m_1,m_2,\\sigma,\\mu")#text(" defined in ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251796")[#text("this previous comment")]#text(". Note that ")#mi("\\int f^2 \\leq 1")#text(", and hence")

#mi("\\displaystyle M_k \\geq \\int f {\\mathcal L} f")#text(" (1)")

#text("and")

#mi("\\displaystyle M_k^2 \\geq \\int f {\\mathcal L}^2 f")#text(" (2)")

#text("so we can get lower bounds on ")#mi("M_k")#text(" by computing either of the quantities in (1) and (2), and we know from Cauchy-Schwarz that (2) should give a slightly better bound.")

#text("As a warmup, let us first compute the RHS of (1). By symmetry, this becomes")

#mi("\\displaystyle k \\int f(t_1,t_2,\\ldots,t_k) f(t^{\\prime}_1,t_2,\\ldots,t_k)\\ dt_1 dt^{\\prime}_1 dt_2 \\ldots dt_k")

#text("which if we restrict to the region ")#mi("t_2+\\ldots+t_k \\leq 1 - T/k")#text(", simplifies to")

#mi("\\displaystyle \\frac{m_1^2}{m_2} {\\bf P}( X_2+\\ldots+X_k \\leq k-T )")

#text("where ")#mi("X_1,\\ldots,X_k")#text(" are iid with distribution ")#mi("\\frac{1}{m_2} g(t)^2 dt")#text(" on ")#mi("[0,T]")#text(". This, together with the Chebyshev inequality, is what gives the lower bound")

#mi("\\displaystyle M_k \\geq \\frac{m_1^2}{m_2} (1 - \\frac{(k-1)\\sigma^2}{k-T-(k-1)\\mu} )")

#text("which is what we had in the previous comment.")

#text("Now we compute the RHS of (2). By symmetry, this becomes the sum of")

#mi("\\displaystyle k (k-1) \\int f(t_1,t_2,t_3,\\ldots,t_k) f(t^{\\prime}_1,t^{\\prime}_2,t_3,\\ldots,t_k)")#linebreak()#text(" ")#mi("\\displaystyle 1_{t^{\\prime}_1+t_2+\\ldots+t_k \\leq 1} \\ dt_1 dt^{\\prime}_1 dt_2 dt^{\\prime}_2 dt_3 \\ldots dt_k")

#text("and")

#mi("\\displaystyle k \\int f(t_1,t_2,\\ldots,t_k) f(t^{\\prime\\prime}_1,t_2,\\ldots,t_k)")#linebreak()#text(" ")#mi("\\displaystyle 1_{t^{\\prime}_1+t_2+\\ldots+t_k \\leq 1}\\ dt_1 dt^{\\prime}_1 dt^{\\prime\\prime}_1 dt_2 \\ldots dt_k")#text(".")

#text("For the first expression, we restrict to the region ")#mi("t_3+\\ldots+t_k \\geq 1-2T/k")#text(" and obtain a lower bound of")

#mi("\\displaystyle \\frac{k-1}{k} \\frac{m_1^4}{m_2^2} {\\bf P}( X_3+\\ldots+X_k \\leq k-2T)")#text(".")

#text("By Chebyshev, this is at least")

#mi("\\displaystyle \\frac{k-1}{k} \\frac{m_1^4}{m_2^2} (1 - \\frac{(k-2)\\sigma^2}{k-2T-(k-2)\\mu} )")#text(" (3)")

#text("subject to the constraint")

#mi("\\displaystyle k - 2T - (k-2) \\mu > 0")#text(". (4)")

#text("Meanwhile,for the second expression we restrict to the region ")#mi("t_2+\\ldots+t_k \\geq 1-T/k")#text(" and obtain a lower bound of")

#mi("\\displaystyle \\frac{1}{k} (\\int_0^T g(t)\\ dt)^2 {\\bf E} (k - X_2 - \\ldots - X_k ) 1_{X_2+\\ldots+X_k \\leq k-T}")

#text("which we can lower bound by")

#mi("\\displaystyle \\frac{1}{k} \\frac{m_1^2}{m_2} {\\bf E} (k - T - X_2 - \\ldots - X_k )")

#text("which is equal to")

#mi("\\displaystyle \\frac{1}{k} \\frac{m_1^2}{m_2} (k - T - (k-1) \\mu)")#text(". (5)")

#text("Thus we obtain the bound")

#mi("M_k^2 \\geq (3) + (5)")

#text("whenever ")#mi("A,T>0")#text(" obey the constraint (4).")

#text("Asymptotically, this does not seem to give too much of an improvement to the lower bound of ")#mi("M_k")#text(" (a back of the envelope calculation suggests that the gain is only ")#mi("O(1)")#text(" or less) but it might still give some noticeable improvement for the m=1 and m=2 numerics. (And if it doesn’t, it would provide some indication as to how close our test function F is to being an eigenfunction.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252276")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("Is your formula for (3) correct? Or should there be a square in the denominator of the rightmost fraction? [I ask, because three offset equations earlier, you have a formula that doesn’t match your earlier bound for ")#mi("M_k")#text(" as it it missing a square in the denominator of the rightmost fraction as well.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252279")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("Yes, you’re right; there should be a square in the denominator in both cases as per Chebyshev. So the first lower bound for M_k should be")

#mi("\\displaystyle M_k\\geq \\frac{m_1^2}{m_2} ( 1 - \\frac{(k-1)\\sigma^2}{(k-T-(k-1)\\mu)^2} )")

#text("and the quantity in (3) should instead be")

#mi("\\displaystyle \\frac{k-1}{k} \\frac{m_1^4}{m_2^2} (1 - \\frac{(k-2)\\sigma^2}{(k-2T-(k-2)\\mu)^2} ).")

#text("Thanks for spotting the error. But actually this error may end up in our favour, since I think the denominator is in fact greater than 1, so perhaps xfxie’s calculations below will in fact improve with this correction!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252283")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("Unfortunately (or fortunately, depending on your frame of reference) xfxie’s calculation used the correct formula. When I wasn’t able to reproduce his results, I discovered the error.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252314")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("Pace is right. For the implementation, I modified the code based on the obvious difference between M_k and (3) — so it might be the reason that the typo (which appeared in both places) was automatically skipped.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252282")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("Assuming that the answer to my question is that the formula for (3) was incorrect, and that there should be a square (which I think is true, if I’m understanding your use of Chebyshev), we get (without using the ")#mi("\\delta,\\varpi")#text(" inequalities from Polymath 8a) the following:")

#text("For ")#mi("m=1")#text(", ")#mi("k=448,T=26.1665,A=6.15853")#text(".")#linebreak()#text(" For ")#mi("m=2")#text(", ")#mi("k=43134, T=1079.33, A=10.2938")#text(".")#linebreak()#text(" Under EH, ")#mi("k=28, T=3.5308, A=3.52752")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252534")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2013")])]

#text("This implies ")#mi("H_2")#text(" is at most ")#link("http://math.mit.edu/~drew/admissible_43134_493528.txt")[#text("493528")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252691")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2013")])]

#text("Actually, this can be improved slightly: ")#link("http://math.mit.edu/~drew/admissible_43134_493510.txt")[#text("493510")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252824")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2013")])]

#text("Further improved to ")#link("http://math.mit.edu/~drew/admissible_43134_493458.txt")[#text("493458")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252987")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2013")])]

#text("Down to ")#link("http://math.mit.edu/~drew/admissible_43134_493442.txt")[#text("493442")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-253086")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#link("http://math.mit.edu/~drew/admissible_43134_493436.txt")[#text("493436")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-253143")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2013")])]

#link("http://math.mit.edu/~drew/admissible_43134_493426.txt")[#text("493426")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-255735")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2013")])]

#link("http://math.mit.edu/~drew/admissible_43134_493408.txt")[#text("493408")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252361")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("I’m noting a rather technical complication with this second moment computation when one tries to combine it with ")#mi("MPZ[\\varpi,\\delta]")#text(". When using MPZ, one has effectively limited oneself to using functions ")#mi("f")#text(" supported on the cube ")#mi("[0, \\frac{\\delta}{1/4+\\varpi}]^k")#text(" to get smoothness of the moduli. However, while the original function f has this form (if ")#mi("T \\leq \\frac{\\delta}{1/4+\\varpi} k")#text("), higher iterates ")#mi("{\\mathcal L}^m f")#text(" do not necessarily have this form. So, strictly speaking, one cannot combine the two improvements.")

#text("However, this is likely a fixable problem provided one puts in a certain amount of effort. The function ")#mi("{\\mathcal L}^m f")#text(" is still supported on a set in which all but m of the coordinates are known to lie in ")#mi("[0, \\frac{\\delta}{1/4+\\varpi}]^k")#text(", which for small m almost guarantees multiple ")#mi("x^\\delta")#text("-dense divisibility, if not ")#mi("x^\\delta")#text("-smoothness (there will be an exceptional set in which this fails but it will be exponentially small). So it is likely that this technicality will have a negligible impact on the estimates, and hopefully will not degrade the value of k at all.")

#text("It’s all getting rather complicated; I will try to write up a fresh blog post soon to summarise the various things being explored here.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252229")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("For ")#mi("\\frac{1080}{13} \\varpi + \\frac{330}{13} \\delta < 1")#text(", seems ")#mi("k")#text(" can drop significantly. Here is a possible solution ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi1080d13_388.mpl")[#text("388")]#text(", if my implementation is correct.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252260")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("xfxie, can you please clarify – which permutation of other assumptions are you using here? Or to put it another way, to which previously-mentioned k0 assuming varpi = 7/600 (if any) is your 388 the 13/1080 counterpart?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252326")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("Aubery, 13/1080 is based on Terence’s calculation ")#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/#comment-247766")[#text("here")]#text(" (and the counterpart of k_0 is 603). It is also mentioned in an ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251877")[#text("comment")]#text(" above by Terence. The result is not totally verified yet. But the calculation might provide a basic sense on how far the method can reach.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252969")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2013")])]

#text("Thanks, but actually that wasn’t quite my question: I know that 603 is the pre-Maynard k0 for varpi = 13/1080, but I was looking for the post-Maynard k0 for varpi = 7/600. If I’m not mistaken, Pace’s k0 of 448 assumes only Bombieri-Vinogradov, and until 13/1080 is fully confirmed I’m thinking that it might be of interest also to continue tracking the various k0 that arise from 7/600.")

#text("Also, incidentally, isn’t k0 = 42392 obsolete now? – isn’t that the m=2 counterpart of 508, which was superseded by Terry’s second-moment computations on Friday? I’m unclear as to why you and Drew are still refining H for 42392 rather than for the m=2 counterpart of 388 (which I don’t think anyone has posted yet).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252989")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2013")])]

#text("The situation with k0=42392 isn’t clear to me, but if someone has a better value, please post it; I agree there is no point in optimizing H values for an obsolete k0 (although it has motivated me to spend some time tweaking the algorithm to more efficiently handle k0 in this range, so the time isn’t wasted). I’d also be curious to see a k0 for m=3 if anyone is motivated enough to try it.")

#text("As far as I know the best “Deligne-free” k0 for m=2 is still 43134, but someone please correct me if I am wrong.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252286")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("I think I now have an upper bound of ")#mi("M_k")#text(" of logarithmic type that matches the lower bound asymptotically (up to the ")#mi("\\log\\log k")#text(" correction terms).")

#text("First, let me describe the warmup problem which led me to discover the bound. Morally speaking (ignoring the ")#mi("\\sigma^2")#text(" terms), the large k computations boil down to the problem of maximising ")#mi("(\\int_0^T g(t)\\ dt)^2")#text(" subject to the constraints ")#mi("\\int_0^T g(t)^2\\ dt = 1")#text(" and ")#mi("\\int_0^T t g(t)^2\\ dt \\leq 1")#text(". Calculus of variations tells us that the extremiser should be a multiple of ")#mi("1/(1+At)")#text(" for some suitable ")#mi("A")#text(". Motivated by this, I wrote down the Cauchy-Schwarz inequality")

#mi("\\displaystyle (\\int_0^T g(t)\\ dt)^2 \\leq (\\int_0^T (1+At) g(t)^2\\ dt) (\\int_0^T \\frac{1}{1+At}\\ dt)")

#text("(knowing that equality is attained here when ")#mi("g")#text(" is a multiple of ")#mi("1/(1+At)")#text(") and the right-hand side evaluates to be bounded by")

#mi("\\displaystyle (1+ \\frac{1}{A}) \\log(1+AT)")

#text("which optimises to essentially ")#mi("\\log T")#text(" (up to errors of ")#mi("\\log\\log T")#text(") after setting ")#mi("A = \\log T")#text(" (say).")

#text("This then led me to an analogous argument in the multidimensional setting (after a rescaling). Namely, Cauchy-Schwarz gives")

#mi("\\displaystyle (\\int_0^{1-t_1-\\ldots-t_{k-1}} f(t_1,\\ldots,t_k)\\ dt_k)^2 \\leq")#linebreak()#text(" ")#mi("\\displaystyle (\\int_0^{1-t_1-\\ldots-t_{k-1}} (1+k A t_k) f(t_1,\\ldots,t_k)^2\\ dt_k)")#linebreak()#text(" ")#mi("\\displaystyle \\times (\\int_0^1 (1+k At_k)^{-1}\\ dt_k)")#text(".")

#text("The latter integral evaluates to ")#mi("\\frac{1}{kA} \\log(1+kA)")#text(". Integrating in the remaining variables ")#mi("t_1,\\ldots,t_{k-1}")#text(", we conclude that")

#mi("\\displaystyle J_k^{(k)}(f) \\leq \\frac{1}{kA} \\log(1+kA) \\int_{{\\cal R}_k} (1+kAt_k) f(t_1,\\ldots,t_k)^2\\ dt_1 \\ldots t_k.")

#text("Similarly for permutations. Summing and using the fact that ")#mi("t_1 +\\ldots+t_k \\leq 1")#text(" on the simplex, we conclude that")

#mi("\\displaystyle \\sum_{m=1}^k J_k^{(m)}(f) \\leq \\frac{1}{kA} \\log(1+kA) \\int_{{\\cal R}_k} (k+kA) f(t_1,\\ldots,t_k)^2\\ dt_1 \\ldots t_k")

#mi("\\displaystyle = (1+\\frac{1}{A}) \\log(1+Ak) I_k(f)")

#text("and so we have the upper bound")

#mi("\\displaystyle M_k \\leq (1 + \\frac{1}{A}) \\log(1+Ak)")

#text("for any ")#mi("A>0")#text("; again setting ")#mi("A = \\log k")#text(", we obtain an upper bound of the form")

#mi("\\displaystyle M_k \\leq \\log k + \\log \\log k + O(1)")

#text("and one can probably optimise this a bit further.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252316")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("For small ")#mi("k")#text(", this is quite close to Maynard’s lower bounds logarithmic approximation above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-285450")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2014")])]

#text("Just a very small note that the ")#mi("O(1)")#text(" term can be taken as ")#mi("2")#text(" for all ")#mi("k\\geq 2")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252290")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("It seems that it should be “…multiple of ")#mi("1/(1+ A t)")#text(" …”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252294")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("Sorry, at first sight it seems to me ")#mi("1+A t")#text(" (instead of its inverse.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252295")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("Minor typo: Eight lines from the bottom, ")#mi("(1+A)")#text(" should be ")#mi("(1+Ak)")#text(".")

#emph[#text("[Actually, I think it is correct as it stands, although I had skipped a step involving cancelling a factor of ")#mi("k")#text(" which I have now put back in to try to reduce confusion. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252373")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("You are right. Sorry about that!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8b, II: Optimising the variational problem and the sieve | What's new")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252410")[#strong[#text("Polymath8b, II: Optimising the variational problem and the sieve | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("[…] for small values of (in particular ) or asymptotically as . The previous thread may be found here. The currently best known bounds on […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252413")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("Rolling over the thread to a fresh one in order to make it easier to catch up on the discussion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8615db255bcf8ad4e6466232a7c4c2b9075810d442ba390301eb0e327c77b81b-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nikita Sidorov")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252552")[#strong[#text("Nikita Sidorov")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2013")])]

#text("Out of curiosity – what does the numerics suggest for $H_m$?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Primzahlenzwillinge | UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-253308")[#strong[#text("Primzahlenzwillinge | UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2013")])]

#text("[…] Artikel in dem Quanta Magazin findet man mehr über die neusten Entwicklungen dazu (siehe auch den Blog von Terence Tao […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-255864")[#strong[#text("Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2013")])]

#text("[…] transfer from the corresponding laws for the standard natural numbers . For a more topical example, it is now a theorem that given any standard natural number , there exist standard primes such that ; it is an […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8b, III: Numerical optimisation of the variational problem, and a search for new sieves | What's new")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-255957")[#strong[#text("Polymath8b, III: Numerical optimisation of the variational problem, and a search for new sieves | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2013")])]

#text("[…] the notation of this previous post, we have the lower […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8b, IV: Enlarging the sieve support, more efficient numerics, and explicit asymptotics. | What's new")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-258016")[#strong[#text("Polymath8b, IV: Enlarging the sieve support, more efficient numerics, and explicit asymptotics. | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("[…] products supported on small cubes in avoiding (5). For the GPY argument to work (as laid out in this previous post), we need the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8b, V: Stretching the sieve support further | What's new")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-262400")[#strong[#text("Polymath8b, V: Stretching the sieve support further | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("[…] baseline bounds for the numerator and denominator in (1) (as established for instance in this previous post) are as follows. If is supported on the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8b, VII: Using the generalised Elliott-Halberstam hypothesis to enlarge the sieve support yet further | What's new")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-268540")[#strong[#text("Polymath8b, VII: Using the generalised Elliott-Halberstam hypothesis to enlarge the sieve support yet further | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2014")])]

#text("[…] wish to understand the correlation of various products of divisor sums on . For instance, in this previous blog post, the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-269523")[#strong[#text("Коллективный разум в теории чисел » CreativLabs")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2014")]

#text("[…] растерялся и огранизовал новый коллективный проект polymath8b, направленный на улучшение вновь полученной границы. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-269539")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2014")])]

#text("On the dependence of the current M-value on ")#mi("\\epsilon")#text(":")

#text("According to some preliminary analysis, it seems that for ")#mi("\\epsilon  \\geq 1/4")#text(", we have the linear dependence")

#mi("\\hat{M}^{\\prime\\prime}_{3, \\epsilon, 1} = \\frac{3}{2} + (1-\\epsilon)C")

#text("For some (still undetermined) absolute positive constant C (related to the solution of a certain integral equation). Interestingly, it is easy to determine the dependence on ")#mi("\\epsilon")#text(" without knowing the constant C!")

#text("I suggest to verify empirically this linear dependence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/07a7ff91b522bd7e3d602d732862da024ca4139da9b2c9c501209e58c172fe3f-3d62c9479bfbdbb2f0dea100b15ffb0ef7ef841b2b446f14120e79e1bc868c13.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Urns and the Dirichlet Distribution | Eventually Almost Everywhere")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-276116")[#strong[#text("Urns and the Dirichlet Distribution | Eventually Almost Everywhere")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2014")])]

#text("[…] Polymath8b: Bounded intervals with many primes, after Maynard (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-284575")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2014")])]

#text("I think that (8) in Proposition 7 is valid for all ")#mi("k_0")#text(", not just for ")#mi("k_0")#text(" sufficiently large. First, we can assume that ")#mi("k_0 > 200")#text(", since otherwise the right hand side of (8) is negative. Then, in the bound (8.17) of Maynard’s paper, we can choose ")#mi("\\log k_0 > A > 3")#text(" such that ")#mi("A^2e^A = k_0")#text(". Clearly, ")#mi("e^A = k_0/A^2 > k_0/\\log^2 k_0")#text(", i.e. ")#mi("A > \\log k_0-2\\log\\log k_0")#text(". In addition, on the right hand side of (8.17), ")#mi("A/(e^A-1) < 1/6")#text(" and ")#mi("e^A/k_0 = 1/A^2")#text(". ")#mi("1/A^2")#text(" is less than ")#mi("1/9")#text(", hence the right hand side of (8.17) exceeds ")#mi("A-1/(1-1/6-1/9)^2")#text(", which in turn is greater than ")#mi("\\log k_0-2\\log\\log k_0-2")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-401508")[#strong[#text("Together and Alone, Closing the Prime Gap | For a better Vietnam")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2014")]

#text("[…] However, Tao predicted that the project’s participants will not be able to resist immediately sinking their teeth into Maynard’s new preprint. “It’s like red meat,” he […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac2cebf8a018dabaf84eb7f9dea9f72d5c628979d8dd77546ba87a6bd7737aa-f216a713208693d29ebdd5bbfe510a9dd85b37c22c2f9f7eed47a82bcb8a2872.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-463136")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2015")])]

#text("Why we need to choose the simplex such? What to change if you take $R_k=\\{\\dots(x)\\in[0,1]^k\\}$?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-463167")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2015")])]

#text("The restriction to the simplex is needed to force the products ")#mi("d_1 \\dots d_{k_0}")#text(" and ")#mi("d^{\\prime}_1 \\dots d^{\\prime}_{k_0}")#text(" to be bounded by ")#mi("R")#text(" (see second display before (11)), which is in turn needed in order to have good equidistribution estimates available (with error term smaller than the main term).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac2cebf8a018dabaf84eb7f9dea9f72d5c628979d8dd77546ba87a6bd7737aa-f216a713208693d29ebdd5bbfe510a9dd85b37c22c2f9f7eed47a82bcb8a2872.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-467153")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2016")])]

#text("If you apply the approach of Maynard to ")#mi("E_2=\\left{x\\in \\mathbb{N}|\\Omega(x)=2\\right}=\\left{q_{n}}_{n=1}^{\\infty}")#text(", then to assess the difference ")#mi("\\liminf_{n}(q_{n+r_{k}-1}-q_{n})<h_k-h_1")#text(" we must demand ")#mi("\\frac{\\log N}{N}\\sum_{N<nr_k-1")#text(". But ")#mi("\\sum_{N<n<2N}\\chi_{E_2}(n)~\\frac{N \\log\\log N}{\\log N}")#text(". Choosing N large enough, we achieve the minimum distance for any r, which obviously leads to a contradiction. Where am I wrong?")

#emph[#text("[Wordpress treats < and > as HTML, causing text with both symbols in it to be corrupted. Use &lt; and &gt; instead – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-468990")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2016")])]

#text("Where in the proof of the asymptotics for sums (10),(11) significantly that the set is admissible? Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-468992")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2016")])]

#text("One needs admissibility in order to have at least one residue class ")#mi("b\\ (W)")#text(" with all of the ")#mi("b+h_i")#text(" coprime to ")#mi("W")#text(". So estimates such as (1) and (2) are vacuously true in the non-admissible case (because there is no ")#mi("b")#text(" that obeys the requirements).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-468993")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2016")])]

#text("Is it possible to formulate the allowed set is defined for arbitrary subsets of natural numbers? For example, if we consider the set of Prime numbers,the distance between which is greater than 1000, then the asymptotic amount and level of distribution will not change. Then, using Your approach, we would have the presence of smaller distances of 600 and would come to a contradiction. This is due to the choice of the set H. We knew in advance that, for example, n and n+2 could not lie simultaneously in our set and therefore had no right to choose so.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-468995")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2016")])]

#text("I’m not fully sure I understand your question, but this method has been extended to find small gaps in other sets of numbers than the primes, see e.g. the work of ")#link("http://arxiv.org/abs/1305.0348")[#text("Benatar")]#text(", ")#link("http://arxiv.org/abs/1401.6677")[#text("Thorner")]#text(", ")#link("http://arxiv.org/abs/1403.4527")[#text("Li-Pan")]#text(", ")#link("http://arxiv.org/abs/1404.4007")[#text("Pollack")]#text(", ")#link("http://arxiv.org/abs/1405.2593")[#text("Maynard")]#text(", ")#link("http://arxiv.org/abs/1407.1747")[#text("Chua-Park-Smith")]#text(", and ")#link("http://arxiv.org/abs/1411.2989")[#text("Baker-Zhao")]#text(" (this may not be a complete list of references).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-469863")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2016")])]

#text("Good afternoon!")#linebreak()#text(" Take the set of primes p such that p+2 and p-2 is obviously not a prime number. The asymptotic number of integers in this set and the level of distribution are the same as primes. Can we apply to this set the approach of Maynard? Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-469882")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2016")])]

#text("It depends on what you mean by “obviously”. If you mean that ")#mi("p +2")#text(" and ")#mi("p-2")#text(" are each divisible by some small prime (e.g. 3 and 5 respectively), then as you say one has the required level of distribution, and it is not difficult to adapt the arguments (there are already several papers in the literature dealing with bounded gaps between special sets of primes obeying these sorts of level of distribution axioms). But if you only require that ")#mi("p+2,p-2")#text(" are both composite, then a level of distribution result (with error terms that are better than the main terms by an arbitrary power of ")#mi("\\log x")#text(") would basically require the conjectural asymptotics for the twin prime conjecture, which is of course still open.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-469901")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2016")])]

#text("Could You provide a link to the literature?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-469918")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2016")])]

#text("See my previous comment on this blog post at 2016/05/26 at 10:39 am.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-478239")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2017")])]

#text("What is known about such sums with weights fourth degree or more? Why we study a second degree? Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-478246")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2017")])]

#text("It seems that fourth degree weights should have narrower peaks (i.e. more selective) which is somewhat analogous to Jackson kernel (fourth degree weights) versus Fejer kernel (second degree weights) in approximation theory.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-478367")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2017")])]

#text("Where I could read more about it? I tried to bring the corresponding coefficients of the main parts, and got unexpectedly complicated structure.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-478390")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2017")])]

#text("The idea to use such weights already appeared in a comment (10 August, 2014, at 11:38 am) in the 36-th Polymath8 thread (from 21 July 2014).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sylvainjulien")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-478251")[#strong[#text("sylvainjulien")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2017")])]

#text("Assuming Goldbach’s conjecture, and denoting by $ latex r_{0}(n) $ the smallest positive integer $ latex r $ such that both $ latex n-r $ and $ latex n+r $ are primes for latex n$ a large enough composite integer, and by $ latex l0(n) $ the number of primes in the interval $ latex [n-r_{0}(n),n+r_{0}(n)] $ , what would be the best upper bound for $ latex l_{0}(n) $ in terms of $ latex r_{0}(n) $ ? Can $ latex l_{0}(n)\\ll_{h} (r_{0}(n))^{1/2+h} $ hold true under GRH ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-478435")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2017")])]

#text("Dear Terry,")

#text("Could you please answer the following question: if we consider the weight of the fourth degree, the ")#mi("I_k")#text(" values will look like as in the second degree with the exception of the degree of ")#mi("F")#text("? I used the Fourier transform method and received a rather complex structure. So I’m trying to understand if I have a mistake.")

#text("Thank you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-479048")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2017")])]

#text("What restrictions need to require the function ")#mi("f(x_1,...,x_{k0}")#text(" to compute values ")#mi("\\alpha")#text(" and ")#mi("\\beta")#text(" in the original form (5),(6)?")#linebreak()#text(" For example, if we take ")#mi("f(x,y)=e^{x+y}")#text(" then ")#mi("\\frac{\\alpha}{\\beta}=3.046.")#text(" Where am I making a mistake?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-479136")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2017")])]

#text("This function is not supported on the simplex ")#mi("\\Delta_2")#text(" (and if one truncates the function to this simplex, it will no longer be smooth).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-479139")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2017")])]

#text("Then which function to choose?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sylvainjulien")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-479073")[#strong[#text("sylvainjulien")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2017")])]

#text("Dear Terry,")

#text("Can an interesting lower bound for the de Polignac constant as introduced in ")#link("http://math.stackexchange.com/questions/2183872/lower-bound-for-the-de-polignac-constant")[#text("http://math.stackexchange.com/questions/2183872/lower-bound-for-the-de-polignac-constant")]#text(" be obtained as of today (March 12th 2017) ?")#linebreak()#text(" Many thanks in advance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6358e427f60dd9b92901456f116b89ad4c32c97987d8ce17457a4d9b41d3dc3c-33974ea251b54833a7b82de1e4c31290b82353cbfe8cbe98b5ebccbfc18bf474.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hoa Huynh")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-593237")[#strong[#text("Hoa Huynh")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2020")])]

#text("Assuming the GEH, the bounded gap is 6.")#linebreak()#text(" In Wikipedia of “Polignac’s conjecture”, in section “Conjectured density”, there is a statement:")#linebreak()#text(" Twin primes have the same conjectured density as cousin primes, and half that of sexy primes.")#linebreak()#text(" Together, don’t they imply that all 3: Twin Prime, Cousin Prime and Sexy Prime have infinite counts?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-593498")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2020")])]

#text("Conjecturally, yes. But this is not yet proven.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sylvainjulien")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-593623")[#strong[#text("sylvainjulien")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("You may be interested in this: ")#link("https://mathoverflow.net/questions/358027/a-conditional-approach-to-twin-prime-conjecture?r=SearchResults")[#text("https://mathoverflow.net/questions/358027/a-conditional-approach-to-twin-prime-conjecture?r=SearchResults")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6358e427f60dd9b92901456f116b89ad4c32c97987d8ce17457a4d9b41d3dc3c-33974ea251b54833a7b82de1e4c31290b82353cbfe8cbe98b5ebccbfc18bf474.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hoa Huynh")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-593914")[#strong[#text("Hoa Huynh")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2020")])]

#text("For “admissible tuples”, the first element’s position or pattern is fixed for “k equal to or greater than 6.”")#linebreak()#text(" Examples:")#linebreak()#text(" For k = 5, we have 2 patterns: (p, p + 2, p + 6, p + 8, p + 12)")#linebreak()#text(" 16061, 16063, 16067, 16069, 16073 (*)")#linebreak()#text(" 21011, 21013, 21017, 21019, 21023")#linebreak()#text(" 43781, 43783, 43787, 43789, 43793 (*)")#linebreak()#text(" 247601, 247603, 247607, 247609, 247613")#linebreak()#text(" 1063961, 1063963, 1063967, 1063969, 1063973")#linebreak()#text(" 1091261, 1091263, 1091267, 1091269, 1091273 (*)")#linebreak()#text(" 1246361, 1246363, 1246367, 1246369, 1246373")

#text("and (p, p + 4, p + 6, p + 10, p + 12)")#linebreak()#text(" 15727, 15731, 15733, 15737, 15739")#linebreak()#text(" 16057, 16061, 16063, 16067, 16069 (*)")#linebreak()#text(" 43777, 43781, 43783, 43787, 43789 (*)")#linebreak()#text(" 79687, 79691, 79693, 79697, 79699")#linebreak()#text(" 736357, 736361, 736363, 736367, 736369")#linebreak()#text(" 1091257, 1091261, 1091263, 1091267, 1091269 (*)")#linebreak()#text(" 1155607, 1155611, 1155613, 1155617, 1155619")#linebreak()#text(" ——–")#linebreak()#text(" For k = 6, we have 1 pattern: (p, p + 4, p + 6, p + 10, p + 12, p + 16)")#linebreak()#text(" 16057, 16061, 16063, 16067, 16069, 16073 (*)")#linebreak()#text(" 43777, 43781, 43783, 43787, 43789, 43793 (*)")#linebreak()#text(" 1091257, 1091261, 1091263, 1091267, 1091269, 1091273 (*)")#linebreak()#text(" ——–")#linebreak()#text(" There are many many more of them, the examples are chosen to illustrate the points: pattern for k = 6 exists in k = 5; and the 4 middle elements are in the same decade, and the 2 outside ones are in adjacent decades.")#linebreak()#text(" The unit digits for k = 6 are fixed: 7, 1, 3, 7, 9, 3. The obvious reason is to avoid divisibility by 5.")#linebreak()#text(" Likewise, “fixed unit digit patterns” also happen for k > 6, for “optimal sieving.”")#linebreak()#text(" ——–")#linebreak()#text(" Has this information/fact been used in some proofs of bounded gap?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6358e427f60dd9b92901456f116b89ad4c32c97987d8ce17457a4d9b41d3dc3c-33974ea251b54833a7b82de1e4c31290b82353cbfe8cbe98b5ebccbfc18bf474.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hoa Huynh")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-594440")[#strong[#text("Hoa Huynh")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2020")])]

#text("For the 105-tuple, we can not place its FIRST element at even-numbered locations, because it sieves all even numbers.")

#text("It has 26 numbers ended with 0, let’s call it group A. We would NOT place it at locations ended with 5, because we waste 25% of the “resource.”")#linebreak()#text(" Group A (26 counts)")#linebreak()#text(" 0, 10, 30, 70, 90, 100,")#linebreak()#text(" 120, 180, 190,")#linebreak()#text(" 220, 250, 280,")#linebreak()#text(" 300, 310, 330, 360,")#linebreak()#text(" 390, 400, 420, 430, 450,")#linebreak()#text(" 490, 510,")#linebreak()#text(" 570, 580, 600")#linebreak()#text(" ——————-")#linebreak()#text(" Let’s group the rest of 105-tuple in numbers ended with 2, 4, 6 and 8. Note that we don’t have any number ended with 6. So, we have 3 more groups B, C and D, as followed.")#linebreak()#text(" Group B (27 counts)")#linebreak()#text(" 12, 42, 52, 72, 82,")#linebreak()#text(" 112, 132,")#linebreak()#text(" 192, 202, 222, 232, 252, 262,")#linebreak()#text(" 322, 342, 352, 372,")#linebreak()#text(" 402, 412, 432, 442,")#linebreak()#text(" 462, 472, 492, 532,")#linebreak()#text(" 562, 582")#linebreak()#text(" —–")#linebreak()#text(" Group C (27 counts)")#linebreak()#text(" 24, 34, 54, 64, 94,")#linebreak()#text(" 114, 124, 154, 174, 184,")#linebreak()#text(" 204, 234, 264,")#linebreak()#text(" 294, 324, 334, 364,")#linebreak()#text(" 384, 394, 444,")#linebreak()#text(" 454, 484, 504, 534,")#linebreak()#text(" 544, 574, 594")#linebreak()#text(" ——-")#linebreak()#text(" Group D (25 counts)")#linebreak()#text(" 28, 48, 78,")#linebreak()#text(" 118, 138, 148, 168, 178,")#linebreak()#text(" 208, 258, 268,")#linebreak()#text(" 288, 328, 358,")#linebreak()#text(" 378, 408, 418,")#linebreak()#text(" 468, 478, 498, 528, 538,")#linebreak()#text(" 558, 588, 598")#linebreak()#text(" —————————")#linebreak()#text(" We would not place FIRST element of 105-tuple at locations ended with 3, because group B would waste 25% of the “resource.”")#linebreak()#text(" Likewise, for locations ended with 1 and 7, for groups C and D, respectively.")#linebreak()#text(" —————————")#linebreak()#text(" Therefore, the most strategic locations to place 105-tuple are where they are ended with 9, in order to maximize the result.")#linebreak()#text(" Same reason for all k-tuples, with k > 6.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Infinite partial sumsets in the primes | What's new")]], [#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-672667")[#strong[#text("Infinite partial sumsets in the primes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2023")])]

#text("[…] that powers the proof of that theorem (though we use a formulation of that sieve closer to that in this blog post of mine). Indeed, the failure of (iii) basically arises from the failure of Maynard’s theorem for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-673051")[#strong[#text("Infinite partial sumsets in the primes – Terence Tao – A2Z Facts")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2023")]

#text("[…] that powers the proof of that theorem (though we use a formulation of that sieve closer to that in this blog post of mine). Indeed, the failure of (iii) basically arises from the failure of Maynard’s theorem for dense […]")
]
