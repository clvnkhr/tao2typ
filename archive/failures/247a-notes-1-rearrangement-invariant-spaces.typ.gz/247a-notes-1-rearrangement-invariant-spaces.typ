// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/20/247a-notes-1-rearrangement-invariant-spaces/
// Converted to Typst by tao2typ: "2026-10-14T11:20:04.728609+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "247A, Notes 1: Rearrangement-invariant spaces", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("247A, Notes 1: Rearrangement-invariant spaces")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/20/247a-notes-1-rearrangement-invariant-spaces/")[#text("https://terrytao.wordpress.com/2026/09/20/247a-notes-1-rearrangement-invariant-spaces/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Disclaimer: due to current events, I have not been able to devote as much time to lecture notes preparation as I would have liked, so I apologize in advance for the unpolished nature of the text below, which has been largely recycled from previous lecture notes I have written.")

#text("This is the first set of lecture notes for my graduate course 247A, “Fourier analysis”. The course name is rather general, but I will focus the course not on the Fourier transform ")#emph[#text("per se")]#text(", but on the closely related topic of ")#link("https://en.wikipedia.org/wiki/Harmonic_analysis")[#text("real variable harmonic analysis")]#text(", with a particular emphasis on ")#emph[#text("Calderón–Zygmund theory")]#text(", which underlies basic tools in PDE such as the theory of Sobolev spaces.")

#text("To avoid confusion at the outset, let us make the distinction between real-variable harmonic analysis and ")#emph[#text("abstract harmonic analysis")]#text(", which are only distantly related to each other despite the similar names. Abstract harmonic analysis, roughly speaking, is the extension of the classical theory of the Fourier transform to other domains, such as ")#link("https://en.wikipedia.org/wiki/Locally_compact_abelian_group")[#text("locally compact abelian (LCA) groups")]#text(", non-abelian Lie groups, or symmetric spaces, and typically involves a blend of representation theory, group theory, and analysis. Real-variable harmonic analysis, by contrast, tends to work on classical domains, such as a Euclidean space ")#mi("{{\\bf R}^d}")#text(", a torus ")#mi("{{\\bf R}^d/{\\bf Z}^d}")#text(", or a lattice ")#mi("{{\\bf Z}^d}")#text(", although many of the techniques can extend to more general domains (e.g., to Riemannian manifolds). While the Fourier transform often plays a prominent role (in particular, by setting the stage for ")#emph[#text("time-frequency analysis")]#text(" and enabling various decompositions or other transforms that involve frequency space or phase space in addition to physical space), real-variable harmonic analysis is often focused on estimating other transforms or expressions that often interact well with the Fourier transform, but need not explicitly invoke it. Examples include ")#link("https://en.wikipedia.org/wiki/Hilbert_transform")[#text("the Hilbert transform")]#text(" ")#metadata(none) <tao-812592913d114ecbc707>#mi("\\displaystyle  Hf(x) := p.v. \\int_{\\bf R} \\frac{f(y)}{x-y}\\ dy \\ \\ \\ \\ \\ (1)")#text(" ")#text(" (where we have made the somewhat arbitrary decision to omit the normalizing constant ")#mi("{\\frac{1}{\\pi}}")#text(") or the ")#link("https://en.wikipedia.org/wiki/Hardy%E2%80%93Littlewood_maximal_function")[#text("Hardy-Littlewood maximal function")]

#align(center)[#tao-fit-display[#tao-math("Mf(x) := \\sup_{r>0} \\frac{1}{\\left|B(x,r)\\right|} \\int_{B(x,r)} |f(y)|\\ dy.", block: true)]]

#text("These operators do not at first glance seem related to the Fourier transform, but as we shall see in later notes, the maximal function can be used to control the size of the Hilbert transform, and the Hilbert transform is a Fourier multiplier, with")

#align(center)[#tao-fit-display[#mitex("\\widehat{Hf}(\\xi) = -i \\, \\text{sgn}(\\xi) \\hat{f}(\\xi)")]]

#text("for any reasonable function ")#mi("{f}")#text(", where we use the normalization ")#mi("{\\hat f(\\xi) := \\int_{\\bf R} f(x) e^{-2\\pi i x \\xi}\\ dx}")#text(".")

#text("A typical question in harmonic analysis is the following: let ")#mi("{f}")#text(" be some function on a standard domain (such as Euclidean space), and let ")#mi("{T f}")#text(" be an explicit transform of ")#mi("{f}")#text(" (e.g., the Hilbert transform ")#mi("{Hf}")#text(" or maximal function ")#mi("{Mf}")#text("). To what extent is the “size” of ")#mi("{Tf}")#text(" controlled by the “size” of ")#mi("{f}")#text("? The value of such bounds often lies in the general nature of the input function ")#mi("{f}")#text("; some mild regularity or decay hypotheses might be imposed on ")#mi("{f}")#text(", but beyond that the function ")#mi("{f}")#text(" is typically not required to have a very structured form (in particular, it need not be describable by any closed-form expression).")

#text("In many situations the transform ")#mi("{T}")#text(" being studied is linear or sublinear, in which case the natural type of bound to ask is a linear bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\|Tf\\right\\|_Y \\leq C \\left\\|f\\right\\|_X", block: true)]]

#text("for suitable function space norms ")#mi("{X,Y}")#text(" (e.g., ")#mi("{L^p}")#text(" norms), and ")#mi("{C}")#text(" is some bound. Depending on the application, we may be interested in various levels of precision regarding the bound ")#mi("{C}")#text(":")

#list(
[#text("(a) Optimal bounds, in which we seek the exact optimal value of ")#mi("{C}")#text(" (i.e., the operator norm of ")#mi("{T}")#text("). For instance, the optimal ")#mi("{L^2({\\bf R}) \\rightarrow L^2({\\bf R})}")#text(" constant for the Hilbert transform ")#mi("{H}")#text(" is exactly ")#mi("{\\pi}")#text(", and the optimal ")#mi("{L^1({\\bf R}) \\rightarrow L^{1,\\infty}({\\bf R})}")#text(" constant for ")#mi("{M}")#text(" in one dimension turns out to be ")#mi("{\\frac{11+\\sqrt{61}}{12}}")#text(" (a ")#link("https://www.jstor.org/stable/3597214")[#text("result of Melas")]#text(").")],
[#text("(b) Bounds accurate up to absolute constants (or maybe constants that can depend on basic parameters such as the ambient dimension).")],
[#text("(c) Bounds in which we are willing to accept “logarithmic type losses” such as ")#mi("{\\log R}")#text(" or ")#mi("{R^{o(1)}}")#text(" in auxiliary parameters, such as a scale parameter ")#mi("{R}")#text(".")]
)

#text("All three regimes are interesting, but we will focus in this class on the regime (b), where we can “afford” to lose absolute constants in the bounds, but will work hard to avoid any logarithmic losses. In particular, significant effort will be devoted in this class to avoiding “logarithmic pileups of scales”, in which the contributions of different dyadic scales such as ")#mi("{[2^k, 2^{k+1}]}")#text(" for ")#mi("{k=1,2,3,\\dots}")#text(" all potentially contribute an equal amount that “interfere constructively” to cause a logarithmic divergence. This can be unnecessarily conservative when one is in regime (c) (which is for instance the situation in modern topics such as restriction theory or the Kakeya conjecture); nevertheless, the general skills gained by trying to not lose even a logarithmic factor in the bounds are often valuable in these other types of analysis.")

#text("When dealing with linear or sublinear problems, it is natural to try to ")#emph[#text("decompose")]#text(" the initial function ")#mi("{f}")#text(" into various smaller components ")#mi("{f_\\alpha}")#text(" by some decomposition ")#mi("{f = \\sum_\\alpha f_\\alpha}")#text(", so that the transformed function ")#mi("{Tf}")#text(" can be controlled by more tractable expressions ")#mi("{Tf_\\alpha}")#text(" in various ways (e.g., via the triangle inequality, by Bessel type inequalities, or by the more modern technique of decoupling inequalities). In short, the subject tends to proceed by a ")#emph[#text("divide and conquer")]#text(" philosophy: it is generally preferable to replace a simple-looking but hard-to-estimate expression with a large, messy-looking combination of expressions that are easier to estimate. As such, the aesthetics of the subject are almost the reverse of those in the more algebraic portions of mathematics, in which progress is often made by making the expressions involved look as simple and unified as possible.")

#text("One of the main themes in this classical type of harmonic analysis is the struggle to understand the effect of two phenomena in integrals or sums: ")#emph[#text("singularity")]#text(" and ")#emph[#text("oscillation")]#text(". The Hilbert transform ")#link(<tao-812592913d114ecbc707>)[#text("(1)")]#text(" is a quintessential example of a ")#emph[#text("singular integral")]#text(", which combines both features: the non-locally integrable nature of the kernel ")#mi("{\\frac{1}{x-y}}")#text(" provides the singularity, but the sign change from ")#mi("{x < y}")#text(" to ")#mi("{x>y}")#text(" provides the oscillation. Classically, the interplay between these two phenomena can be tamed by analyzing the behavior of this operator both in the time (or “physical”) domain and in frequency (or “Fourier”) domain; in particular, the fact that singular integral operators such as the Hilbert transform are simultaneously a well-behaved Fourier multiplier and is “pseudo-local” in physical space lies at the heart of the standard Calderón–Zygmund theory for such operators. This dovetails nicely with more modern “time-frequency analysis” approaches to the subject, which can also handle other interesting operators, such as restriction or Bochner–Riesz operators via tools such as the wave packet decomposition, although these will be outside the scope of this course.")

#text("In this initial set of notes I will ignore the effect of oscillation, and develop some tools, such as interpolation theory, which can help control non-oscillatory sums and integrals if they are not too singular. Here, the focus will be on rearrangement-invariant spaces, such as the Lebesgue spaces ")#mi("{L^p}")#text(" and their weak variants ")#mi("{L^{p,\\infty}}")#text(", which are function spaces that are useful for measuring how “singular” or “decaying” various functions are, but do not pay attention to how they oscillate or where their mass is distributed. As such, these spaces do not capture the underlying geometry of the domain, which also plays an essential role in the subject; but it is nevertheless essential to have a good base understanding of the rearrangement-invariant theory before moving on to the more delicate aspects of harmonic analysis that are sensitive to rearrangements.")

#text("We will use the following asymptotic notation throughout the course: ")#mi("{X = O(Y)}")#text(", ")#mi("{X \\lesssim Y}")#text(", or ")#mi("{Y \\gtrsim X}")#text(" denotes the assertion that ")#tao-math("{\\left|X\\right| \\leq CY}", block: false)#text(" for some constant ")#mi("{C}")#text(", and write ")#mi("{X \\sim Y}")#text(" for ")#mi("{X \\lesssim Y \\lesssim X}")#text(". If we permit this constant ")#mi("{C}")#text(" to depend on some ambient parameters, we indicate this by subscripts; for instance, ")#mi("{X = O_{p,d}(Y)}")#text(" or ")#mi("{X \\lesssim_{p,d} Y}")#text(" denotes a bound of the form ")#tao-math("{\\left|X\\right| \\leq C_{p,d} Y}", block: false)#text(" for some constant ")#mi("{C_{p,d}}")#text(" that can depend on ")#mi("{p}")#text(" and ")#mi("{d}")#text(". As indicated above, in this course we will generally not dwell much on exactly what these constants ")#mi("{C_{p,d}}")#text(" are, or attempt to optimize them.")

#metadata(none) <tao-7e97e0fc46b3299cf351>

#heading(level: 1)[#strong[#text(" — 1. ")#mi("{L^p}")#text(" norms — ")]]

#text("Suppose one has some measurable function ")#mi("{f : X \\rightarrow {\\bf C}}")#text(" on some measure space ")#mi("{(X,{\\mathcal B},\\mu) = (X,\\mu)}")#text(". (Here we will follow the common practice if identifying functions that agree almost everywhere; in particular, we will be content to work with functions that are undefined on a set of measure zero. Also, while we work here with complex-valued functions throughout, most of the discussion here is also valid for real-valued or vector-valued functions.) Informally speaking, to measure how “big” such a function is, there are two (imprecisely defined) basic statistics to be aware of:")

#list(
[#text("The ")#emph[#text("height")]#text(" or ")#emph[#text("amplitude")]#text(" of the function, which describes what the typical size of the magnitude ")#tao-math("{\\left|f(x)\\right|}", block: false)#text(" is for ")#mi("{x}")#text(" in the “dominant” component of the support of ")#mi("{f}")#text("; and")],
[#text("The ")#emph[#text("width")]#text(" of the function, which describes the measure of this dominant component.")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" (Informal) Given a Gaussian wave packet type function")

#align(center)[#tao-fit-display[#tao-math("f(x) = A \\exp( - \\left|x-x_0\\right|^2 / R^2 ) e^{2\\pi i \\xi \\cdot x}", block: true)]]

#text("on ")#mi("{{\\bf R}^d}")#text(" for some ")#mi("{A, R > 0}")#text(" and ")#mi("{\\xi \\in {\\bf R}^d}")#text(", this function has magnitude ")#mi("{\\approx A}")#text(" on the ball ")#mi("{B(x_0,R)}")#text(", which has volume ")#mi("{\\approx R^d}")#text(" (if we allow constants in the informal ")#mi("{\\approx}")#text(" notation to depend on the dimension ")#mi("{d}")#text("), so such a function has height ")#mi("{\\approx A}")#text(" and width ")#mi("{\\approx R^d}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" (Informal) The function ")#mi("{\\frac{1}{x}}")#text(" on ")#mi("{{\\bf R}}")#text(", which is implicitly involved in the definition of the Hilbert transform ")#link(<tao-812592913d114ecbc707>)[#text("(1)")]#text(", does not have a clear amplitude or width as is. However, if one performs a ")#emph[#text("dyadic decomposition")]

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{x} = \\sum_{n \\in {\\bf Z}} 1_{2^n \\leq \\left|x\\right| < 2^{n+1}} \\frac{1}{x},", block: true)]]

#text("where we use ")#mi("{1_E}")#text(" to denote the ")#link("https://en.wikipedia.org/wiki/Indicator_function")[#text("indicator")]#text(" of a statement ")#mi("{E}")#text(" (equal to ")#mi("{1}")#text(" when ")#mi("{E}")#text(" is true and ")#mi("{0}")#text(" otherwise), then each component")

#align(center)[#tao-fit-display[#tao-math("1_{2^n \\leq \\left|x\\right| < 2^{n+1}} \\frac{1}{x}", block: true)]]

#text("of this decomposition has height ")#mi("{\\approx 2^{-n}}")#text(" and width ")#mi("{\\approx 2^n}")#text(". Thus, while this function can be viewed as a ")#emph[#text("superposition")]#text(" of components of various heights and widths, rather than a single such component.")
]

#text("These informal concepts of height and width are too imprecise to work with in practice. Experience has shown that a convenient proxy for these concepts are the ")#emph[#mi("{L^p(X,{\\mathcal B}, \\mu)}")#text(" norms")]#text(" of a function ")#mi("{f}")#text(", defined for ")#mi("{0 < p < \\infty}")#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^p(X,{\\mathcal B},\\mu)} := \\Big( \\int_{X} \\left|f(x)\\right|^p \\, d\\mu(x) \\Big)^{1/p}", block: true)]]

#text("and for ")#mi("{p = \\infty}")#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^\\infty(X,{\\mathcal B},\\mu)} := \\mathrm{ess\\,sup}_{x \\in X} \\left|f(x)\\right|", block: true)]]

#text("where ")#mi("{\\mathrm{ess\\,sup}}")#text(" denotes the ")#link("https://en.wikipedia.org/wiki/Essential_infimum_and_essential_supremum")[#text("essential supremum")]#text(" of the function ")#tao-math("{x \\mapsto \\left|f(x)\\right|}", block: false)#text(" with respect to the measure ")#mi("{\\mu}")#text(". Often we abbreviate ")#mi("{L^p(X,{\\mathcal B},\\mu)}")#text(" as ")#mi("{L^p(X,\\mu)}")#text(", ")#mi("{L^p(X)}")#text(", ")#mi("{L^p(\\mu)}")#text(", or just ")#mi("{L^p}")#text(" (and abbreviate ")#tao-math("{\\left\\|f\\right\\|_{L^p(X,{\\mathcal B},\\mu)}}", block: false)#text(" as ")#tao-math("{\\left\\|f\\right\\|_p}", block: false)#text(") when the missing arguments are clear from context. (For instance, when working with Euclidean spaces ")#mi("{{\\bf R}^d}")#text(", the measure ")#mi("{\\mu}")#text(" is understood to be Lebesgue measure, and ")#mi("{{\\mathcal B}}")#text(" the Lebesgue ")#mi("{\\sigma}")#text("-algebra, unless otherwise specified.) In terms of the width ")#mi("{W}")#text(" and height ")#mi("{H}")#text(" of a function ")#mi("{f}")#text(", one heuristically has")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^p(X,\\mu)} \\approx H W^{1/p}", block: true)]]

#text("for both finite and infinite values of ")#mi("{p}")#text(", with the convention that ")#mi("{W^{1/\\infty}}")#text(" is equal to ")#mi("{1}")#text(" when ")#mi("{W}")#text(" is positive and ")#mi("{0}")#text(" when ")#mi("{W}")#text(" is zero. In the case of a step function ")#mi("{f = A 1_E}")#text(" (where now ")#mi("{1_E(x) = 1_{x \\in E}}")#text(" is the indicator function of a measurable set ")#mi("{E}")#text("), this heuristic becomes exact:")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^p(X,\\mu)} = A \\mu(E)^{1/p}.", block: true)]]

#text("The function space ")#mi("{L^p(X,\\mu)}")#text(" is defined as the set of all measurable functions ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" for which the ")#mi("{L^p}")#text(" norm is finite, up to almost everywhere equivalence, though we will often abuse notation by identifying a function with its almost everywhere equivalence class.")

#text("In the case where ")#mi("{X}")#text(" is discrete and ")#mi("{\\mu}")#text(" is counting measure, we abbreviate ")#mi("{L^p(X,\\mu)}")#text(" as ")#mi("{\\ell^p(X)}")#text(", or even just ")#mi("{\\ell^p}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" Let ")#mi("{\\alpha > 0}")#text(". On a Euclidean space ")#mi("{{\\bf R}^d}")#text(", the function ")#tao-math("{f(x) := \\left|x\\right|^{-\\alpha} 1_{\\left|x\\right| > 1}}", block: false)#text(" lies in ")#mi("{L^p({\\bf R}^d)}")#text(" (with a norm of ")#mi("{O_{p,\\alpha,d}(1)}")#text(") if and only if ")#mi("{\\alpha > d/p}")#text(", while the function ")#tao-math("{g(x) := \\left|x\\right|^{-\\alpha} 1_{\\left|x\\right| \\leq 1}}", block: false)#text(" lies in ")#mi("{L^p({\\bf R}^d)}")#text(" (with a norm of ")#mi("{O_{p,\\alpha,d}(1)}")#text(") if and only if ")#mi("{\\alpha < d/p}")#text(". The function ")#tao-math("{\\left|x\\right|^{-\\alpha}}", block: false)#text(" does not lie in any ")#mi("{L^p({\\bf R}^d)}")#text(", although it only fails “logarithmically” to lie in ")#mi("{L^{d/\\alpha}}")#text(". Thus we see that control in ")#mi("{L^p}")#text(" for high ")#mi("{p}")#text(" rules out severe local singularities at a point, while control in ")#mi("{L^p}")#text(" for low ")#mi("{p}")#text(" rules out insufficiently rapid decay at infinity.")
]

#text("As is well known (see ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("these previous notes")]#text(") these function spaces enjoy many useful properties:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Basic properties of ")#mi("{L^p}")#text(" spaces)")]

#list(
[#text("(i) The space ")#mi("{L^p(X,\\mu)}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Banach_space")[#text("Banach space")]#text(" when ")#mi("{1 \\leq p \\leq \\infty}")#text(", a ")#link("https://en.wikipedia.org/wiki/Hilbert_space")[#text("Hilbert space")]#text(" when ")#mi("{p=2}")#text(", and a ")#link("https://en.wikipedia.org/wiki/Topological_vector_space")[#text("topological vector")]#text(" space when ")#mi("{0 < p < 1}")#text(".")],
[#text("(ii) If ")#mi("{0 < p, q, r \\leq \\infty}")#text(" obeys the scaling condition")

#metadata(none) <tao-567cf013bf70f18fc5d4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\frac{1}{p} + \\frac{1}{q} = \\frac{1}{r}")]]

#text("then one has the ")#link("https://en.wikipedia.org/wiki/H%C3%B6lder%27s_inequality")[#text("Hölder inequality")]

#metadata(none) <tao-6e45386daeb0b86da1ac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\| fg \\right\\|_{L^r(X,\\mu)} \\leq \\left\\|f\\right\\|_{L^p(X,\\mu)} \\left\\|g\\right\\|_{L^q(X,\\mu)}", block: true)]]

#text("for any measurable ")#mi("{f,g: X \\rightarrow {\\bf C}}")#text(" (here we adopt the usual conventions ")#mi("{0 \\cdot +\\infty = +\\infty \\cdot 0 = 0}")#text("). In particular, if ")#mi("{f \\in L^p(X,\\mu)}")#text(" and ")#mi("{g \\in L^q(X,\\mu)}")#text(", then ")#mi("{fg \\in L^r(X,\\mu)}")#text(".")],
[#text("(iii) If ")#mi("{f \\in L^p(X,\\mu)}")#text(" for some ")#mi("{1 \\leq p \\leq \\infty}")#text(", then one has the duality relationship")

#metadata(none) <tao-c5419f8b099324d31350>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\begin{array}{c} \\left\\|f\\right\\|_{L^p(X,\\mu)} = \\sup \\left\\{ \\left| \\int_X f(x) \\overline{g(x)} \\, d\\mu(x) \\right| : \\right. \\\\ \\left. g \\in L^q(X,\\mu), \\left\\|g\\right\\|_{L^q(X,\\mu)} \\leq 1 \\right\\}. \\end{array}", block: true)]]

#text("where ")#mi("{q}")#text(" is the conjugate exponent to ")#mi("{p}")#text(", defined by ")#mi("{\\frac{1}{p} + \\frac{1}{q} = 1}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" Closely related to (iii) is the fact that the dual of ")#mi("{L^p(X,\\mu)}")#text(" can be identified with ")#mi("{L^q(X,\\mu)}")#text(" when ")#mi("{1 \\leq p < \\infty}")#text(" (with the additional hypothesis that ")#mi("{X}")#text(" is ")#mi("{\\sigma}")#text("-finite if ")#mi("{p=1}")#text("), but in practice the relation ")#link(<tao-c5419f8b099324d31350>)[#text("(4)")]#text(" will already be good enough for our purposes.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" The Banach space property gives us the basic triangle inequality")

#metadata(none) <tao-0a3f13c673af2389ecb9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| \\sum_i f_i \\right\\|_{L^p(X,\\mu)} \\leq \\sum_i \\left\\| f_i \\right\\|_{L^p(X,\\mu)}", block: true)]]

#text("for both finite and infinite collections of functions ")#mi("{f_i \\in L^p(X,\\mu)}")#text(" when ")#mi("{1 \\leq p \\leq \\infty}")#text(", where in the infinite case the assertion is that if the right-hand side is finite, then the series ")#mi("{\\sum_i f_i}")#text(" is absolutely convergent almost everywhere, and obeys the above inequality (so in particular is in ")#mi("{L^p(X,\\mu)}")#text("). For ")#mi("{0 < p < 1}")#text(", this inequality fails (can you come up with a counterexample?), but one has the weaker ")#mi("{p}")#text("-triangle inequality")

#metadata(none) <tao-4858eb5454a90767d929>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left\\| \\sum_i f_i \\right\\|_{L^p(X,\\mu)}^p \\leq \\sum_i \\left\\| f_i \\right\\|_{L^p(X,\\mu)}^p", block: true)]]

#text("in this case, which follows easily from iterating the easy observation that ")#tao-math("{\\left|z+w\\right|^p \\leq \\left|z\\right|^p + \\left|w\\right|^p}", block: false)#text(" for any complex numbers ")#mi("{z,w}")#text(", which in turn ultimately stems from the complex triangle inequality ")#tao-math("{\\left|z+w\\right| \\leq \\left|z\\right| + \\left|w\\right|}", block: false)#text(" and concave nature of ")#mi("{t \\mapsto t^p}")#text(" for ")#mi("{t \\geq 0}")#text(". In particular, for a finite sum ")#mi("{\\sum_{i=1}^N f_i}")#text(", another application of Hölder’s inequality gives the quasi-triangle inequality")

#metadata(none) <tao-5a4aed87b57cbc77c23d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left\\| \\sum_{i=1}^N f_i \\right\\|_{L^p(X,\\mu)} \\leq N^{\\frac{1}{p}-1} \\sum_{i=1}^N \\left\\| f_i \\right\\|_{L^p(X,\\mu)}", block: true)]]

#text("for ")#mi("{0 < p < 1}")#text(", which is not too much worse than ")#link(<tao-0a3f13c673af2389ecb9>)[#text("(5)")]#text(" when ")#mi("{N}")#text(" is not too large.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Give an example to show that the quantity ")#mi("{N^{\\frac{1}{p}-1}}")#text(" in ")#link(<tao-5a4aed87b57cbc77c23d>)[#text("(7)")]#text(" cannot be replaced by any smaller quantity.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" ")#metadata(none) <tao-003c7e8c5bbe871e5142>#text(" For ")#mi("{f}")#text(" a simple function, verify that ")#tao-math("{\\lim_{p \\rightarrow \\infty} \\left\\|f\\right\\|_p = \\left\\|f\\right\\|_\\infty}", block: false)#text(", and that ")#tao-math("{\\lim_{p \\rightarrow 0} \\left\\|f\\right\\|_p^p = \\mu( \\mathrm{supp}(f) )}", block: false)#text(", where ")#mi("{\\mathrm{supp}(f) := \\{ x: f(x) \\neq 0 \\}}")#text(". For this reason, the measure of the support of ")#mi("{f}")#text(" is sometimes referred to as the ")#emph[#mi("{L^0}")#text(" norm")]#text(" of ")#mi("{f}")#text(", though it would be more accurate (though confusing) to refer to it as the ")#mi("{0^{th}}")#text(" power of the ")#mi("{L^0}")#text(" norm.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" Note that Hölder’s inequality is not just symmetric under the homogeneities ")#mi("{f \\mapsto cf}")#text(" and ")#mi("{g \\mapsto cg}")#text(" of the functions, but also under the homogeneity ")#mi("{\\mu \\mapsto \\lambda\\mu}")#text(" of the underlying ")#emph[#text("measure")]#text(". This latter symmetry demonstrates why the condition ")#mi("{\\frac{1}{p}+\\frac{1}{q}=\\frac{1}{r}}")#text(" is necessary. (The first two symmetries demonstrate why ")#mi("{f}")#text(" appears the same number of times on both sides of the inequality, and similarly for ")#mi("{g}")#text(".)")

#text("In the case of Euclidean space, the measure homogeneity symmetry ")#mi("{\\mu \\mapsto \\lambda \\mu}")#text(" is equivalent to the scaling symmetry ")#mi("{x \\mapsto ax}")#text(" for ")#mi("{a > 0}")#text(", as the Jacobian of this map is ")#mi("{\\lambda = a^d}")#text(". But the point is that by manipulating the measure directly, one still enjoys this symmetry even when no scaling operation is present.")
]

#text("It is instructive to try to understand inequalities such as ")#link(<tao-6e45386daeb0b86da1ac>)[#text("(3)")]#text(" using the height-width heuristic introduced previously. Suppose informally that ")#mi("{f,g,fg}")#text(" have heights ")#mi("{H_f}")#text(", ")#mi("{H_g}")#text(", ")#mi("{H_{fg}}")#text(" and widths ")#mi("{W_f}")#text(", ")#mi("{W_g}")#text(", ")#mi("{W_{fg}}")#text(" respectively. Then one expects the heights to be related by the formula")

#align(center)[#tao-fit-display[#mitex("H_{fg} \\approx H_f H_g.")]]

#text("What about the widths? Heuristically, the region that ")#mi("{fg}")#text(" concentrates in ought to be a subset of the region that ")#mi("{f}")#text(" concentrates in, so")

#align(center)[#tao-fit-display[#mitex("W_{fg} \\lessapprox W_f")]]

#text("and similarly with ")#mi("{W_f}")#text(" replaced by ")#mi("{W_g}")#text(". We can combine these bounds as")

#align(center)[#tao-fit-display[#mitex("W_{fg} \\lessapprox \\min(W_f, W_g).")]]

#text("The bound ")#link(<tao-6e45386daeb0b86da1ac>)[#text("(3)")]#text(" then is morally")

#align(center)[#tao-fit-display[#mitex("H_{fg} W^{1/r}_{fg} \\lessapprox H_f W^{1/p}_{f} \\cdot H_g W^{1/q}_g,")]]

#text("which on applying the previous bounds and ")#link(<tao-567cf013bf70f18fc5d4>)[#text("(2)")]#text(" should simplify to")

#align(center)[#tao-fit-display[#mitex("\\min(W_f, W_g)^{1/p} \\min(W_f, W_g)^{1/q} \\lessapprox W^{1/p}_{f} W^{1/q}_g.")]]

#text("But this is clear by bounding ")#mi("{\\min(W_f,W_g)}")#text(" by ")#mi("{W_f}")#text(" for the first factor on the left-hand side, and by ")#mi("{W_g}")#text(" for the second factor. Thus we see that the key geometric input that is morally driving the Hölder inequality is the simple fact that the concentration region of the product is contained in the concentration regions of the factors.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Determine the cases for which ")#link(<tao-6e45386daeb0b86da1ac>)[#text("(3)")]#text(" holds with equality (dealing with edge cases such as when one or more of ")#mi("{p,q,r}")#text(" equal infinity as appropriate). Discuss how your conclusions align with the heuristic analysis presented above.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" If ")#mi("{1 < p < \\infty}")#text(", determine the cases for which ")#link(<tao-0a3f13c673af2389ecb9>)[#text("(5)")]#text(" holds with equality. What changes when ")#mi("{p=1}")#text(" or ")#mi("{p=\\infty}")#text("?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" Show that Hölder’s inequality is equivalent to the ")#emph[#text("log-convexity of ")#mi("{L^p}")#text(" norms")]#text(":")

#metadata(none) <tao-91b9fae3d797b93d82e9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\begin{array}{c} \\left\\|f\\right\\|_r \\leq \\left\\|f\\right\\|^{1-\\theta}_p \\left\\|f\\right\\|_q^\\theta \\text{ whenever } 0 < p < q < \\infty, 0 < \\theta < 1 \\\\ \\text{ and } \\frac{1}{r} = \\frac{1-\\theta}{p} + \\frac{\\theta}{q}. \\end{array}", block: true)]]

#text("(For technical reasons one needs to first reduce to the case where ")#mi("{X}")#text(" has finite measure, and then ")#mi("{f}")#text(" and ")#mi("{g}")#text(" are everywhere non-vanishing simple functions. Now consider the convexity of ")#tao-math("{\\left|f\\right|^\\alpha \\left|g\\right|^\\beta}", block: false)#text(" with respect to a measure ")#tao-math("{\\left|f\\right|^\\gamma \\left|g\\right|^\\delta \\mu}", block: false)#text(" for some suitable exponents ")#mi("{\\alpha,\\beta,\\gamma,\\delta}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Direct approach to log convexity)")]#text(" Differentiate ")#tao-math("{\\log \\left\\|f\\right\\|_p}", block: false)#text(" twice with respect to ")#mi("{\\alpha := 1/p}")#text(" and show that this is non-negative (take ")#mi("{f}")#text(" to be a non-zero simple function with finite measure support to avoid technicalities). This is an example of a ")#emph[#text("monotonicity formula method")]#text(" — deriving estimates from a monotonicity property, which in turn follows from the non-negativity of a derivative.")
]

#text("You will see that this approach is surprisingly messy. For a much slicker proof, observe that ")#link(<tao-91b9fae3d797b93d82e9>)[#text("(8)")]#text(" enjoys homogeneity symmetry in both ")#mi("{f}")#text(" and ")#mi("{\\mu}")#text(", which lets one normalise ")#emph[#text("both")]#text(" ")#tao-math("{\\left\\|f\\right\\|_p}", block: false)#text(" and ")#tao-math("{\\left\\|f\\right\\|_q}", block: false)#text(" to equal one. Thus the task is now to show that if ")#tao-math("{\\left\\|f\\right\\|_p=\\left\\|f\\right\\|_q=1}", block: false)#text(", then ")#tao-math("{\\left\\|f\\right\\|_r \\leq 1}", block: false)#text(" for all ")#mi("{r}")#text(" between ")#mi("{p}")#text(" and ")#mi("{q}")#text(". This can be done by the pointwise convexity of ")#tao-math("{p \\mapsto \\left|f(x)\\right|^p}", block: false)#text(", or more precisely the estimate")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x)\\right|^r \\leq (1-\\theta) \\left|f(x)\\right|^p + \\theta \\left|f(x)\\right|^q;", block: true)]]

#text("the observant reader will note that this is merely the proof of Hölder’s inequality in disguise.")

#text("Let us now give a more unusual proof of the log-convexity which does not appeal to any pointwise convexity estimate, instead combining the “divide and conquer” strategy with an elegant (and rather cheeky) “")#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/")[#text("tensor power trick")]#text("“. Again normalise ")#tao-math("{\\left\\|f\\right\\|_p = \\left\\|f\\right\\|_q = 1}", block: false)#text(". We split ")#mi("{f}")#text(" into a broad flat piece and a narrow tall piece")

#align(center)[#tao-fit-display[#tao-math("f = f 1_{\\left|f\\right| \\leq 1} + f 1_{\\left|f\\right| > 1}", block: true)]]

#text("which are disjoint, and thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_r^r = \\int_{\\left|f\\right| \\leq 1} \\left|f\\right|^r + \\int_{\\left|f\\right| \\geq 1} \\left|f\\right|^r.", block: true)]]

#text("What we are doing here is exploiting some very basic intuition about ")#mi("{L^p}")#text(" norms, namely that ")#mi("{L^p}")#text(" bounds for large ")#mi("{p}")#text(" tend to exclude tall narrow spikes, whereas ")#mi("{L^p}")#text(" bounds for small ")#mi("{p}")#text(" tend to exclude short broad tails. Of course, either sort of bound would exclude tall broad functions, and neither excludes narrow short functions. Once again, this intuition can be buttressed by considering the special case of step functions.")

#text("When ")#tao-math("{\\left|f\\right| \\leq 1}", block: false)#text(", then ")#tao-math("{\\left|f\\right|^r \\leq \\left|f\\right|^p}", block: false)#text(", and when ")#tao-math("{\\left|f\\right| \\geq 1}", block: false)#text(", then ")#tao-math("{\\left|f\\right|^r \\leq \\left|f\\right|^q}", block: false)#text(". Thus we end up with")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_r^r \\leq \\int_X \\left|f\\right|^p + \\int_X \\left|f\\right|^q = 2.", block: true)]]

#text("The above argument (which is a prototype of the ")#emph[#text("real interpolation method")]#text(") obtained an estimate which is off by a factor of two from what we wanted; this is a typical feature of the method. However we can recover this factor for free by the following ")#emph[#text("tensor power trick")]#text(". Let ")#mi("{M}")#text(" be a large integer. We replace the measure space ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" by its ")#mi("{M^{th}}")#text(" power ")#mi("{(X^M, {\\mathcal B}^{\\oplus M}, \\mu^{\\oplus M})}")#text(" using the product measure construction, and similarly replace ")#mi("{f}")#text(" with its tensor power ")#mi("{f^{\\oplus M}: X^M \\rightarrow {\\bf C}}")#text(", defined by")

#align(center)[#tao-fit-display[#mitex("f^{\\oplus M}(x_1,\\ldots,x_M) := f(x_1) \\ldots f(x_M).")]]

#text("One then observes that")

#align(center)[#tao-fit-display[#tao-math("\\begin{array}{rl}  \\left\\|f^{\\oplus M}\\right\\|_{L^p(X^M)} &= \\left\\|f\\right\\|_{L^p(X)}^M = 1; \\\\ \\left\\|f^{\\oplus M}\\right\\|_{L^q(X^M)} &= \\left\\|f\\right\\|_{L^q(X)}^M = 1; \\\\ \\left\\|f^{\\oplus M}\\right\\|_{L^r(X^M)} &= \\left\\|f\\right\\|_{L^r(X)}^M. \\end{array}", block: true)]]

#text("Now we apply the preceding arguments to ")#mi("{f^{\\oplus M}}")#text(" instead of ")#mi("{f}")#text(" to deduce that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f^{\\oplus M}\\right\\|_{L^r(X^M)}^r \\leq 2", block: true)]]

#text("which on taking ")#mi("{M^{th}}")#text(" roots gives")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^r(X)}^r \\leq 2^{1/M}.", block: true)]]

#text("Now the left-hand side is independent of ")#mi("{M}")#text("; take limits as ")#mi("{M \\rightarrow \\infty}")#text(" and we obtain ")#tao-math("{\\left\\|f\\right\\|_r \\leq 1}", block: false)#text(" as desired.")

#text("The tensor power trick can be viewed as another application of symmetry: if an estimate is invariant under raising to a tensor power, then one can automatically replace all absolute constants with ")#mi("{1}")#text("; thus we obtain the “free lunch” of deducing a bound with an explicit constant ")#mi("{1}")#text(", from a bound with an unspecified constant (or even with “logarithmic losses”). Contrapositively, if an estimate is invariant under tensor power, then a weak counterexample (which shows that the constant must exceed one) can be ")#emph[#text("amplified")]#text(" into a strong counterexample (which shows that no finite constant suffices) by tensor powering. The tensor power trick seems like a magical trick at present, but is actually exploiting some basic results in information theory such as the Shannon entropy inequalities and the central limit theorem; it also combines well with virtually any inequality which involves Gaussians. Unfortunately due to lack of time we will not be discussing these beautiful topics further in this course. At any rate one sees the power of abstraction in this tensor power trick. (One could similarly perform this trick in ")#mi("{{\\bf R}^d}")#text(", so long as the constants only grew sub-exponentially in the dimension ")#mi("{d}")#text(".)")

#text("The final proof of log-convexity of the norm that we give here proceeds via complex analysis, and the maximum principle — which in many ways is a complex analogue of convexity (or subharmonicity). We need the following result from complex analysis, namely a form of the ")#link("https://en.wikipedia.org/wiki/Phragm%C3%A9n%E2%80%93Lindel%C3%B6f_principle")[#text("Phragmén–Lindelöf principle")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 14 (Three lines lemma)")]#text(" Let ")#mi("{f}")#text(" be a complex-analytic function on the strip ")#mi("{\\{ 0 \\leq \\Re(z) \\leq 1 \\}}")#text(", which is of at most double-exponential growth, or more precisely ")#tao-math("{\\left|f(z)\\right| \\lesssim_f e^{O_f(e^{(\\pi-\\delta)\\left|z\\right|})}}", block: false)#text(" for some ")#mi("{\\delta > 0}")#text(". Suppose that we have the bounds ")#tao-math("{\\left|f(z)\\right| \\leq A}", block: false)#text(" when ")#mi("{\\Re(z) = 0}")#text(" and ")#tao-math("{\\left|f(z)\\right| \\leq B}", block: false)#text(" when ")#mi("{\\Re(z) = 1}")#text(". Then we have ")#tao-math("{\\left|f(z)\\right| \\leq A^{1-\\Re(z)} B^{\\Re(z)}}", block: false)#text(" for all ")#mi("{z}")#text(" in the strip.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 15")]#text(" The rather strange sub-double-exponential hypothesis here is completely sharp, as the example ")#mi("{f(z) = e^{-ie^{\\pi iz}}}")#text(" shows. Note in this hypothesis that we allow the implied constants in the asymptotic notation to depend on ")#mi("{f}")#text(", but the hypothesis is ")#emph[#text("qualitative")]#text(" rather than quantitative: the value of these constants is irrelevant for the final conclusion, as long as they are finite. In practice, these sorts of qualitative hypothesis are usually easy to establish (especially when compared to quantitative estimates) by restricting, smoothing, or damping to a nice class of functions, or by smoothing out or discretising various operators and domains. See for instance the proof of this very lemma in which we upgrade “for free” a weak qualitative bound (sub-double-exponential growth) to a strong qualitative bound (decay at infinity).")
]

#emph[#text("Proof:")]#text(" The hypotheses and conclusion of the lemma are invariant under the operation of multiplying ")#mi("{f}")#text(" by a constant (and adjusting ")#mi("{A,B}")#text(" appropriately). So we may normalise ")#mi("{A=1}")#text(". Similarly, the hypotheses and conclusion of the lemma are invariant under the operation of multiplying ")#mi("{f}")#text(" by an exponential ")#mi("{\\exp(cz)}")#text(" for some real ")#mi("{c}")#text(". Using this, one can also normalise ")#mi("{B=1}")#text(". So now ")#mi("{f}")#text(" is bounded by ")#mi("{1}")#text(" on both sides of the strip and we want to show it is bounded by ")#mi("{1}")#text(" inside the strip.")

#text("Let us first assume that ")#mi("{f}")#text(" is much better than exponential growth, namely that it goes to zero at infinity. Then for all sufficiently large rectangles ")#mi("{\\{ 0 \\leq \\Re(z) \\leq 1; -N \\leq \\Im(z) \\leq N\\}}")#text(" the complex-analytic function ")#mi("{f}")#text(" is bounded by ")#mi("{1}")#text(" on all four sides of this rectangle, and hence in the interior also by the maximum principle, and we are done by setting ")#mi("{N \\rightarrow \\infty}")#text(".")

#text("Now let us handle the general case; as is usual when removing a qualitative assumption, we do this by a limiting argument. We replace ")#mi("{f(z)}")#text(" by ")#mi("{f(z) \\exp(\\varepsilon e^{i [(\\pi-\\varepsilon)z + \\varepsilon/2]})}")#text("; a little complex arithmetic shows that this converts the almost double-exponentially growing function ")#mi("{f}")#text(" to one which is still complex analytic but is now decaying at infinity. It is still bounded by ")#mi("{1}")#text(" at both sides of the strip, and hence by ")#mi("{1}")#text(" in the interior also by the previous argument. Now take ")#mi("{\\varepsilon \\rightarrow 0}")#text(" to conclude the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Suppose that ")#mi("{f}")#text(" is analytic on the strip ")#mi("{\\{ 0 \\leq \\Re(z) \\leq 1 \\}}")#text(", obeys the sub-double-exponential bound ")#tao-math("{\\left|f(z)\\right| \\lesssim_f e^{O_f(e^{(\\pi-\\delta)\\left|z\\right|})}}", block: false)#text(" on the strip, and obeys the polynomial bounds ")#tao-math("{\\left|f(z)\\right| \\lesssim (1 + \\left|z\\right|)^{O(1)}}", block: false)#text(" on the sides of the strip. Show that it obeys the polynomial bound ")#tao-math("{\\left|f(z)\\right| \\lesssim (1 + \\left|z\\right|)^{O(1)}}", block: false)#text(" on the interior of the strip also.")
]

#text("To apply the three-lines lemma to prove ")#link(<tao-91b9fae3d797b93d82e9>)[#text("(8)")]#text(", take ")#mi("{f}")#text(" to be a simple function (with finite measure support) and consider the entire function")

#align(center)[#tao-fit-display[#tao-math("z \\mapsto \\int_X \\left|f\\right|^{z}.", block: true)]]

#text("This function has exponential growth at most (because of the qualitative assumption that ")#mi("{f}")#text(" is simple with finite measure support), and is bounded by ")#mi("{1}")#text(" on the lines ")#mi("{\\Re(z) = p}")#text(" and ")#mi("{\\Re(z) = q}")#text(", and hence (by a trivially rescaled version of the three lines lemma) bounded by ")#mi("{1}")#text(" on the strip inside the lines. In particular it is bounded by ")#mi("{1}")#text(" at ")#mi("{z=r}")#text(", which gives the claim for simple functions. The claim for more general functions (dropping the qualitative assumption of simpleness and finite measure support) then follows by a standard limiting argument (using for instance monotone convergence) which we leave as an exercise.")

#text("The above argument is a prototype of the ")#emph[#text("complex interpolation method")]#text(". As one can see, it can give slightly sharper results than the real interpolation method (though using the tensor power trick the real method can sometimes “catch up”), but on the other hand requires the quantities being studied to depend complex-analytically on a parameter rather than (say) real-analytically.")

#text("Having conclusively demonstrated the log-convexity ")#link(<tao-91b9fae3d797b93d82e9>)[#text("(8)")]#text(" in multiple ways, let us now give some quick applications. It shows that control on two extreme ")#mi("{L^p}")#text(" norms implies control of the intermediate ")#mi("{L^p}")#text(" norms. Under additional assumptions on the measure space ")#mi("{(X, \\mu)}")#text(", one of these extremes is not necessary. If the measure space is ")#emph[#text("finite")]#text(" in the sense that ")#mi("{\\mu(X) < \\infty}")#text(" (thus prohibiting functions from being arbitrarily broad), then higher ")#mi("{L^p}")#text(" norms control lower ones: ")#metadata(none) <tao-15831a06c4342b1af031>#tao-math("\\displaystyle  \\left\\| f \\right\\|_p \\leq \\left\\|f\\right\\|_q \\mu(X)^{\\frac{1}{p} - \\frac{1}{q}} \\text{ whenever } 0 < p \\leq q \\leq \\infty. \\ \\ \\ \\ \\ (9)", block: false)#text(" ")#text(" Indeed this is trivial when ")#mi("{q=\\infty}")#text(", and the general case then follows by convexity. The bound ")#link(<tao-15831a06c4342b1af031>)[#text("(9)")]#text(" can also be usefully written in terms of averages: if we write ")#mi("{\\rlap{\\hspace{3pt}-}\\int_X f\\ d\\mu}")#text(" for ")#mi("{\\frac{1}{\\mu(X)} \\int_X f\\ d\\mu}")#text(", then we see that higher ")#mi("{L^p}")#text(" averages control lower ")#mi("{L^p}")#text(" averages:")

#align(center)[#tao-fit-display[#tao-math("(\\rlap{\\hspace{2pt}-}\\int_X \\left|f\\right|^p\\ d\\mu)^{1/p} \\leq (\\rlap{\\hspace{2pt}-}\\int_X \\left|f\\right|^q\\ d\\mu)^{1/q} \\text{ whenever } 0 < p \\leq q \\leq \\infty.", block: true)]]

#text("One way to view this is that as one lowers the exponent ")#mi("{p}")#text(", the exceptionally large values of ")#mi("{f}")#text(" become less important, leaving the small values of ")#mi("{f}")#text(" to dominate. By restricting ")#mi("{X}")#text(" to its support ")#mi("{\\mathrm{supp}(f)}")#text(" one can refine ")#link(<tao-15831a06c4342b1af031>)[#text("(9)")]#text(" to")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_p \\leq \\left\\|f\\right\\|_q \\mu(\\mathrm{supp}(f))^{\\frac{1}{p} - \\frac{1}{q}} \\text{ whenever } 0 < p \\leq q \\leq \\infty.", block: true)]]

#text("(Note that this is a limiting case of log-convexity at the exponent ")#mi("{0}")#text(", in view of Exercise ")#link(<tao-003c7e8c5bbe871e5142>)[#text("8")]#text("). In the converse direction, if the measure space is ")#emph[#text("granular")]#text(" in the sense that one has a lower bound ")#mi("{\\mu(E) \\geq c}")#text(" for all sets ")#mi("{E}")#text(" of positive measure, then functions are prohibited from being arbitrarily narrow, and lower norms control higher norms:")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_q \\leq \\left\\|f\\right\\|_p c^{\\frac{1}{q} - \\frac{1}{p}} \\text{ whenever } 0 < p \\leq q \\leq \\infty.", block: true)]]

#text("This can be seen by first checking the ")#mi("{q=\\infty}")#text(" case, and then using log-convexity to get the remaining cases. In particular, in the ")#mi("{\\ell^p}")#text(" spaces we see that ")#tao-math("{\\left\\|f\\right\\|_{\\ell^q} \\leq \\left\\|f\\right\\|_{\\ell^p}}", block: false)#text(" for ")#mi("{q \\geq p}")#text(". For ")#mi("{\\ell^p}")#text(" spaces on ")#mi("{N}")#text(" points, we thus have (non-matching) upper and lower bounds")

#metadata(none) <tao-b1b927541c77e69aea9d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left\\|f\\right\\|_{\\ell^q} \\leq \\left\\|f\\right\\|_{\\ell^p} \\leq N^{\\frac{1}{p}-\\frac{1}{q}} \\left\\|f\\right\\|_{\\ell^q},", block: true)]]

#mi("{\\ell^p}")#text(" and ")#mi("{\\ell^q}")#text(" norms are comparable to some extent, but the comparability gets worse as ")#mi("{N \\rightarrow \\infty}")#text(" or as ")#mi("{p}")#text(" and ")#mi("{q}")#text(" get further apart.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Heuristically justify the bounds ")#link(<tao-15831a06c4342b1af031>)[#text("(9)")]#text(", ")#link(<tao-b1b927541c77e69aea9d>)[#text("(10)")]#text(" by appealing to the informal notions of width and height of a function.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" When does equality occur for either of the inequalities in ")#link(<tao-b1b927541c77e69aea9d>)[#text("(10)")]#text("? Note how the example that attains the lower bound is in many ways the “opposite extreme” to the example which attains the upper bound.")
]

#text("Lebesgue measure on Euclidean spaces ")#mi("{{\\bf R}^d}")#text(" with the usual Borel or Lebesgue ")#mi("{\\sigma}")#text("-algebra is not granular. However one can create granularity by coarsening the ")#mi("{\\sigma}")#text("-algebra. For instance, if we let ")#mi("{{\\mathcal B}_1}")#text(" be the ")#mi("{\\sigma}")#text("-algebra generated by the lattice unit cubes ")#mi("{n + [0,1)^d}")#text(" for ")#mi("{n \\in {\\bf Z}^d}")#text(", then we have granularity with constant ")#mi("{c=1}")#text(", and now lower ")#mi("{L^p}")#text(" norms of functions ")#mi("{f}")#text(" control higher ones — but only for functions which are ")#emph[#text("measurable")]#text(" with respect to this algebra, i.e. only for functions which are constant on each lattice unit cube. (This is the first time we have actually manipulated the ")#emph[#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}}")]#text(" to say something non-trivial, as opposed to manipulating ")#mi("{f}")#text(", ")#mi("{X}")#text(", or ")#mi("{\\mu}")#text(".) Thus we see that local constancy of functions can lead to additional estimates on ")#mi("{L^p}")#text(" norms. Later on we shall see that ")#emph[#text("frequency localisation")]#text(" achieves a similar effect as local constancy, as quantified by ")#emph[#text("Bernstein’s inequality")]#text("; this is a concrete manifestation of the famous ")#emph[#text("Heisenberg uncertainty principle")]#text(".")

#text("Finiteness and granularity of the measure space prevent a function from being too broad or too narrow respectively. Similar things happen when a function is being prevented from being too tall or too short; for instance if ")#mi("{f}")#text(" is bounded above by a constant ")#mi("{M}")#text(", then we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_q \\leq \\left\\|f\\right\\|_p^{p/q} M^{1-p/q} \\text{ whenever } 0 \\leq p \\leq q \\leq \\infty", block: true)]]

#text("(this is just log-convexity at the ")#mi("{\\infty}")#text(" exponent), while if ")#mi("{f}")#text(" is bounded below by ")#mi("{M}")#text(" on its support, then we have the reverse inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_p \\leq \\left\\|f\\right\\|_q^{q/p} M^{1-q/p} \\text{ whenever } 0 \\leq p \\leq q \\leq \\infty.", block: true)]]

#text("There are two obvious algebraic identities involving ")#mi("{L^p}")#text(" norms which are worth knowing. The first is that one can interchange ")#mi("{l^p}")#text(" sums with ")#mi("{L^p}")#text(" integrals for any ")#mi("{0 < p < \\infty}")#text(", in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_n \\left|f_n\\right|^p)^{1/p} \\right\\|_{L^p} = (\\sum_n \\left\\|f_n\\right\\|_{L^p}^p)^{1/p};", block: true)]]

#text("this is just an application of the Fubini-Tonelli theorem. Secondly, exponents can pass through ")#mi("{L^p}")#text(" norms by changing the exponent: for any ")#mi("{0 < p,q < \\infty}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\left|f\\right|^q \\right\\|_{L^p} = \\left\\| f \\right\\|_{L^{pq}}^q.", block: true)]]

#text("We shall use both of these identities in the sequel without further comment.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Establish the bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_n \\left|f_n\\right|^q)^{1/q} \\right\\|_{L^p} \\leq (\\sum_n \\left\\|f_n\\right\\|_{L^p}^q)^{1/q}", block: true)]]

#text("for any measurable ")#mi("{f_n}")#text(" and any ")#mi("{0 < q < p \\leq \\infty}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 2. Lorentz spaces — ")]]

#text("Recall that the ")#emph[#text("weak ")#mi("{L^p}")#text(" norm")]#text(" ")#tao-math("{\\left\\|f\\right\\|_{L^{p,\\infty}(X,\\mu)}}", block: false)#text(" of a function ")#mi("{f}")#text(" is defined for ")#mi("{0 < p < \\infty}")#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^{p,\\infty}(X,\\mu)} := \\sup_{\\lambda > 0} \\lambda \\mu( \\{ \\left|f\\right| \\geq \\lambda \\} )^{1/p}.", block: true)]]

#text("Since")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_p^p = \\int_X \\left|f\\right|^p\\ d\\mu \\geq \\int_X \\lambda^p 1_{\\left|f\\right| \\geq \\lambda}\\ d\\mu = \\lambda^p \\mu( \\{ \\left|f\\right| \\geq \\lambda \\} )", block: true)]]

#text("for any ")#mi("{f}")#text(" and ")#mi("{\\lambda}")#text(", we obtain ")#link("https://en.wikipedia.org/wiki/Chebyshev%27s_inequality")[#text("Chebyshev’s inequality")]

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^{p,\\infty}(X,\\mu)} \\leq \\left\\|f\\right\\|_{L^{p}(X,\\mu)}", block: true)]]

#text("(the case ")#mi("{p=1}")#text(" is also known as ")#link("https://en.wikipedia.org/wiki/Markov%27s_inequality")[#text("Markov’s inequality")]#text("). When ")#mi("{p=\\infty}")#text(" we adopt the convention that ")#mi("{L^{\\infty,\\infty} = L^\\infty}")#text(".")

#text("We define weak ")#mi("{L^p(X,\\mu)}")#text(" or ")#mi("{L^{p,\\infty}(X,\\mu)}")#text(" to be the space of all functions with finite ")#mi("{L^{p,\\infty}(X,\\mu)}")#text(" norm, with the usual abbreviations. We sometimes refer to ")#mi("{L^p}")#text(" as ")#emph[#text("strong ")#mi("{L^p}")]#text(" to distinguish it from weak ")#mi("{L^p}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 20")]#text(" On a Euclidean space ")#mi("{{\\bf R}^d}")#text(", the power function ")#tao-math("{\\left|x\\right|^{-\\alpha}}", block: false)#text(" lies in weak ")#mi("{L^p}")#text(" if and only if ")#mi("{\\alpha = d/p}")#text(". Indeed one can think of a weak ")#mi("{L^p}")#text(" function as a function which is pointwise dominated in magnitude by a rearrangement of (a multiple of) ")#tao-math("{\\left|x\\right|^{-d/\\alpha}}", block: false)#text(".")
]

#text("Suppose ")#mi("{0 < p < \\infty}")#text(". From elementary calculus we have")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x)\\right|^p = p \\int_0^\\infty 1_{\\left|f(x)\\right| \\geq \\lambda} \\lambda^p \\frac{d\\lambda}{\\lambda}", block: true)]]

#text("and hence on integration and Fubini’s theorem")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_p^p = p \\int_0^\\infty \\mu( \\{ \\left|f\\right| \\geq \\lambda \\} ) \\lambda^p \\frac{d\\lambda}{\\lambda}.", block: true)]]

#text("To summarise, we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^{p,\\infty}} = \\left\\| \\lambda \\mu( \\{ \\left|f\\right| \\geq \\lambda \\} )^{1/p} \\right\\|_{L^\\infty({\\bf R}^+,\\frac{d\\lambda}{\\lambda})}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^p} = p^{1/p} \\left\\| \\lambda \\mu( \\{ \\left|f\\right| \\geq \\lambda \\} )^{1/p} \\right\\|_{L^p({\\bf R}^+,\\frac{d\\lambda}{\\lambda})}", block: true)]]

#text("for ")#mi("{0 < p < \\infty}")#text(". These two identities motivate introducing the ")#emph[#text("Lorentz (quasi-)norm")]#text(" ")#mi("{L^{p,q}(X,\\mu)}")#text(" for ")#mi("{0 < p < \\infty}")#text(" and ")#mi("{0 < q \\leq \\infty}")#text(" by")

#metadata(none) <tao-ce4e9a0dad1eed8d69c7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left\\|f\\right\\|_{L^{p,q}(X,\\mu)} := p^{1/q} \\left\\| \\lambda \\mu( \\{ \\left|f\\right| \\geq \\lambda \\} )^{1/p} \\right\\|_{L^q({\\bf R}^+,\\frac{d\\lambda}{\\lambda})}.", block: true)]]

#text("Thus for instance ")#mi("{L^p}")#text(" norm is identical to the ")#mi("{L^{p,p}}")#text(" norm. We shall abbreviate ")#tao-math("{\\left\\|f\\right\\|_{L^{p,q}(X,\\mu)}}", block: false)#text(" by ")#tao-math("{\\left\\|f\\right\\|_{L^{p,q}(X)}}", block: false)#text(", ")#tao-math("{\\left\\|f\\right\\|_{L^{p,q}}}", block: false)#text(", or even ")#tao-math("{\\left\\|f\\right\\|_{p,q}}", block: false)#text(" when there is no chance of confusion.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 21")]#text(" For various reasons it is not worth trying to define Lorentz norms when ")#mi("{p=\\infty}")#text(", although we will use the convention ")#mi("{L^{\\infty,\\infty}=L^\\infty}")#text(". The most important values of ")#mi("{q}")#text(", in descending order, are ")#mi("{q=p}")#text(", ")#mi("{q=\\infty}")#text(", ")#mi("{q=1}")#text(", and ")#mi("{q=2}")#text("; the other cases essentially never occur in applications.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 22")]#text(" The factor ")#mi("{p^{1/q}}")#text(" is inconsequential, but is traditional in order to maintain compatibility with the strong ")#mi("{L^p}")#text(" norm. But in practice the exact form of the Lorentz norm is not important; there are many formulations which are equivalent up to constants, and one generally just picks the formulation which is most convenient. The measure ")#mi("{\\frac{d\\lambda}{\\lambda}}")#text(" is of course multiplicative Haar measure on ")#mi("{{\\bf R}^+}")#text(". One can interpret the equivalence of (i)-(iii) below by making the change of variables ")#mi("{\\lambda = 2^m}")#text(", so that the Haar measure just becomes Lebesgue measure in ")#mi("{m}")#text(" (modulo an inessential constant) and then passing from continuous ")#mi("{m}")#text(" to discrete ")#mi("{m}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" If ")#mi("{f: {\\bf R}^+ \\rightarrow {\\bf R}^+}")#text(" is a monotone non-increasing function, show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^{p,q}(X,\\mu)} = \\left\\| f(t) t^{1/p} \\right\\|_{L^q({\\bf R}^+, \\frac{dt}{t})}.", block: true)]]

#text("(Depending on how you prove this, it may be convenient to first prove this for smoother ")#mi("{f}")#text(", such as diffeomorphisms with strictly negative derivative, in order to apply an inverse function theorem.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Show that a step function of height ")#mi("{H}")#text(" and width ")#mi("{W}")#text(" has an ")#mi("{L^{p,q}}")#text(" norm of ")#mi("{(p/q)^{1/q} H W^{1/p}}")#text(" for any ")#mi("{0 < p < \\infty}")#text(" and ")#mi("{0 < q \\leq \\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" For any ")#mi("{0 < p,r < \\infty}")#text(" and ")#mi("{0 < q \\leq \\infty}")#text(" show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f^r \\right\\|_{L^{p,q}(X,\\mu)} \\sim_{p,q,r} \\left\\|f\\right\\|_{L^{pr,qr}(X,\\mu)}^r.", block: true)]]
]

#text("It is obvious that these norms are both rearrangement-invariant and monotone. To get a better intuitive handle on what the ")#mi("{L^{p,q}}")#text(" norm represents, we need some more definitions.")

#list(

)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 26")]#text(" It is a little dangerous to put fuzzy notation such as ")#mi("{\\sim}")#text(" within a definition; if multiple quasi-step functions appear in an argument, the question then arises as to whether the implied constants are uniform. In our applications, the implied constants here are true absolute constants (like ")#mi("{1}")#text(" and ")#mi("{2}")#text(") so this will not be an issue.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 27")]#text(" ")#metadata(none) <tao-9a3a45d01531a20e89ac>#text(" From the binary expansion of the unit interval ")#mi("{[0,1)}")#text(" we see that a non-negative sub-step function ")#mi("{f}")#text(" of height ")#mi("{1}")#text(" and width ")#mi("{W}")#text(" can always be decomposed as ")#mi("{\\sum_{k=1}^\\infty 2^{-k} f_k}")#text(" where ")#mi("{f_k}")#text(" is an actual step function of height ")#mi("{1}")#text(" and width at most ")#mi("{W}")#text(". By homogeneity we have a similar statement for other heights. Because of this, bounds on step functions tend to automatically extend to sub-step functions (and hence quasi-step functions) without difficulty.")
]

#text("Just like actual step functions, the ")#mi("{L^{p,q}}")#text(" norm of sub-step and quasi-step functions are well controlled; a sub-step function of height ")#mi("{H}")#text(" and width ")#mi("{W}")#text(" has ")#mi("{L^{p,q}}")#text(" norm ")#mi("{O_{p,q}( H W^{1/p} )}")#text(", while a quasi-step function has ")#mi("{L^{p,q}}")#text(" norm ")#mi("{\\sim_{p,q} H W^{1/p}}")#text(" – almost exactly like actual step functions. In the converse direction, it turns out that every ")#mi("{L^{p,q}}")#text(" function can be decomposed as an ")#mi("{l^q}")#text(" sum of “very different” ")#mi("{L^{p,q}}")#text("-normalised sub-step or quasi-step functions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 28 (Characterisation of ")#mi("{L^{p,q}}")#text(")")]#text(" ")#metadata(none) <tao-411b0496da5eeced5314>#text(" Let ")#mi("{f}")#text(" be a function, let ")#mi("{0 < p < \\infty}")#text(" and ")#mi("{1 \\leq q \\leq \\infty}")#text(", and let ")#mi("{0 < A < \\infty}")#text(". Then the following are equivalent up to changes in the implied constants:")

#list(
[#text("(i) We have ")#tao-math("{\\left\\|f\\right\\|_{L^{p,q}} \\lesssim_{p,q} A}", block: false)#text(".")],
[#text("(ii) There exists a decomposition ")#mi("{f = \\sum_{m \\in {\\bf Z}} f_m}")#text(" where each ")#mi("{f_m}")#text(" is a quasi-step function of height ")#mi("{2^m}")#text(" and some width ")#mi("{0 \\leq W_m < \\infty}")#text(", with the ")#mi("{f_m}")#text(" having disjoint supports and")

#metadata(none) <tao-7c1c5ee5c6a4dec20983>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\left\\| 2^m W_m^{1/p} \\right\\|_{\\ell^q_m({\\bf Z})} \\lesssim_{p,q} A.", block: true)]]

#text("Here the ")#mi("{m}")#text(" subscript in ")#mi("{l^q_m}")#text(" denotes the variable that the ")#mi("{l^q}")#text(" norm is being taken over.")],
[#text("(iii) There exists a pointwise bound ")#tao-math("{\\left|f\\right| \\leq \\sum_{m \\in {\\bf Z}} 2^m 1_{E_m}}", block: false)#text(", with")

#metadata(none) <tao-8f14105e19bbf0228bc5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left\\| 2^m \\mu(E_m)^{1/p} \\right\\|_{\\ell^q_m({\\bf Z})} \\lesssim_{p,q} A.", block: true)]]],
[#text("(iv) There exists a decomposition ")#mi("{f = \\sum_{n \\in {\\bf Z}} f_n}")#text(" where each ")#mi("{f_n}")#text(" is a sub-step function of width ")#mi("{2^n}")#text(" and some height ")#mi("{0 \\leq H_n < \\infty}")#text(", with the ")#mi("{f_n}")#text(" having disjoint supports, the ")#mi("{H_n}")#text(" non-increasing in ")#mi("{n}")#text(", the bounds ")#tao-math("{H_{n+1} \\leq \\left|f_n\\right| \\leq H_n}", block: false)#text(" on the support of ")#mi("{f_n}")#text(", and")

#metadata(none) <tao-5e550ca391bee4a4138b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\left\\| H_n 2^{n/p} \\right\\|_{\\ell^q_n({\\bf Z})} \\lesssim_{p,q} A.", block: true)]]],
[#text("(v) There exists a pointwise bound ")#tao-math("{\\left|f\\right| \\leq \\sum_{n \\in {\\bf Z}} H_n 1_{E_n}}", block: false)#text(", where ")#mi("{\\mu(E_n) \\lesssim_{p,q} 2^n}")#text(" and ")#link(<tao-5e550ca391bee4a4138b>)[#text("(14)")]#text(" holds.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 29")]#text(" The formulations (ii), (iv) are useful when trying to ")#emph[#text("use")]#text(" an ")#mi("{L^{p,q}}")#text(" bound on ")#mi("{f}")#text("; the formulations (iii), (v) are useful when trying to ")#emph[#text("obtain")]#text(" an ")#mi("{L^{p,q}}")#text(" bound on ")#mi("{f}")#text(". Heuristically, the above theorem is trying to say the following. If ")#mi("{f}")#text(" is a quasi-step function of height ")#mi("{H}")#text(" and width ")#mi("{W}")#text(", then ")#tao-math("{\\left\\|f\\right\\|_{L^{p,q}} \\sim_{p,q} H W^{1/p}}", block: false)#text(". But if ")#mi("{f}")#text(" is instead the sum ")#mi("{\\sum_n f_n}")#text(" of quasi-step functions of height ")#mi("{H_n}")#text(" and width ")#mi("{W_n}")#text(", and either the heights or the widths are sufficiently variable in ")#mi("{n}")#text(" (e.g. one or the other grows like a power of two), then ")#tao-math("{\\left\\|\\sum_n f_n \\right\\|_{L^{p,q}} \\sim_{p,q} \\left\\| H_n W_n^{1/p} \\right\\|_{\\ell^q_n}}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" We may use homogeneity symmetry to normalise ")#mi("{A=1}")#text(". The implications ")#mi("{(ii) \\implies (iii)}")#text(" and ")#mi("{(iv) \\implies (v)}")#text(" are trivial. To see that (i) implies (ii), set ")#tao-math("{f_m := f 1_{2^{m-1} < \\left|f\\right| \\leq 2^m}}", block: false)#text(" and ")#tao-math("{W_m := \\mu( \\{ 2^{m-1} < \\left|f\\right| \\leq 2^m \\} )}", block: false)#text(". (This is the “vertically dyadic layer cake decomposition”.) The only thing that requires nontrivial verification is ")#link(<tao-7c1c5ee5c6a4dec20983>)[#text("(12)")]#text("; but one easily verifies that")

#align(center)[#tao-fit-display[#tao-math("2^m W_m^{1/p} \\lesssim_{p,q} \\left\\| \\lambda \\mu( \\{ \\left|f\\right| \\geq \\lambda \\} )^{1/p} \\right\\|_{L^q([2^{m-2}, 2^{m-1}],\\frac{d\\lambda}{\\lambda})}", block: true)]]

#text("and the claim follows by summing this in ")#mi("{l^q}")#text(".")

#text("Similarly, to see that (i) implies (iv), define")

#align(center)[#tao-fit-display[#tao-math("H_n := \\inf \\{ \\lambda: \\mu( \\{ \\left|f\\right| > \\lambda \\} ) \\leq 2^{n-1} \\};", block: true)]]

#text("note that this is a non-increasing function of ")#mi("{n}")#text(", which goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(" (this comes from the hypothesis that ")#tao-math("{\\left\\|f\\right\\|_{L^{p,q}}}", block: false)#text(" is finite). We then define")

#align(center)[#tao-fit-display[#tao-math("f_n := f 1_{ H_n \\geq \\left|f\\right| > H_{n+1} }.", block: true)]]

#text("(This is the “horizontally dyadic layer cake decomposition”.) The only non-trivial thing to verify is ")#link(<tao-5e550ca391bee4a4138b>)[#text("(14)")]#text(". But one easily verifies the telescoping estimate")

#align(center)[#tao-fit-display[#tao-math("\\begin{array}{rl}  H_n 2^{n/p} &= (H_n^q 2^{nq/p})^{1/q} \\\\ &= (\\sum_{k=0}^\\infty (H_{n+k}^q - H_{n+k+1}^q) 2^{nq/p} )^{1/q} \\\\ &\\lesssim_{p,q} (\\sum_{k=0}^\\infty 2^{-kq/p} \\left\\| \\lambda 2^{(n+k)/p} \\right\\|_{L^q([H_{n+k+1}, H_{n+k}],\\frac{d\\lambda}{\\lambda})}^q)^{1/q}\\\\ &\\lesssim_{p,q} (\\sum_{k=0}^\\infty 2^{-kq/p} \\left\\| \\lambda \\mu( \\{ \\left|f\\right| \\geq \\lambda \\} )^{1/p} \\right\\|_{L^q([H_{n+k+1}, H_{n+k}],\\frac{d\\lambda}{\\lambda})}^q)^{1/q} \\end{array}", block: true)]]

#text("and the claim follows by summing this in ")#mi("{\\ell^q}")#text(" and interchanging the summation signs. (We leave to the reader how to modify the above argument to handle the case ")#mi("{q=\\infty}")#text(".)")

#text("It remains to show that (iii) implies (i) and (iv) implies (i). Suppose first that (iii) holds. It is clear that for any ")#mi("{m}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\mu( \\{ \\left|f\\right| > 2^m \\} ) \\leq \\sum_{k=0}^\\infty \\mu(E_{m+k})", block: true)]]

#text("and hence")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\lambda \\mu( \\{ \\left|f\\right| \\geq \\lambda \\} )^{1/p} \\right\\|_{L^q((2^m,2^{m+1}],\\frac{d\\lambda}{\\lambda})} \\lesssim_{p,q} 2^m (\\sum_{k=0}^\\infty \\mu(E_{m+k}))^{1/p}", block: true)]]

#text("and so on taking ")#mi("{l^q}")#text(" summation in ")#mi("{m}")#text(" it would suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| 2^m (\\sum_{k=0}^\\infty \\mu(E_{m+k}))^{1/p} \\right\\|_{\\ell^q_m} \\lesssim_{p,q} 1.", block: true)]]

#text("Raising to the ")#mi("{p^{th}}")#text(" power we rewrite as")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{k=0}^\\infty 2^{pm} \\mu(E_{m+k}) \\right\\|_{\\ell^{q/p}_m} \\lesssim_{p,q} 1.", block: true)]]

#text("But from the hypothesis we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| 2^{pm} \\mu(E_{m}) \\right\\|_{\\ell^{q/p}_m} \\lesssim_{p,q} 1", block: true)]]

#text("and hence on shifting ")#mi("{m}")#text(" by ")#mi("{k}")

#align(center)[#tao-fit-display[#tao-math("\\left\\| 2^{pm} \\mu(E_{m+k}) \\right\\|_{\\ell^{q/p}_m} \\lesssim_{p,q} 2^{-kp}.", block: true)]]

#text("The claim then follows from ")#link(<tao-0a3f13c673af2389ecb9>)[#text("(5)")]#text(" or ")#link(<tao-5a4aed87b57cbc77c23d>)[#text("(7)")]#text(".")

#text("Now suppose that (iv) holds. Observe that for any ")#mi("{\\lambda > 0}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\mu( \\{ \\left|f\\right| > \\lambda \\} ) \\lesssim_{p,q} \\sup \\{ 2^n: H^{\\prime}_n \\geq \\lambda \\}", block: true)]]

#text("where ")#mi("{H^{\\prime}_n}")#text(" are the modified heights")

#align(center)[#tao-fit-display[#mitex("H^{\\prime}_n := \\sum_{k=0}^\\infty H_{n+k}.")]]

#text("Indeed, if ")#tao-math("{\\mu( \\{ \\left|f\\right| > \\lambda \\} ) > 2^{n-1}}", block: false)#text(" for some ")#mi("{n}")#text(" then one easily verifies that ")#mi("{H_n \\geq \\lambda}")#text(" and hence ")#mi("{H^{\\prime}_n \\geq \\lambda}")#text(". The shifting trick and triangle inequality argument used previously shows that ")#mi("{H^{\\prime}_n}")#text(" obeys the same bound ")#link(<tao-5e550ca391bee4a4138b>)[#text("(14)")]#text(" as ")#mi("{H_n}")#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\| H^{\\prime}_n 2^{n/p} \\right\\|_{\\ell^q_n({\\bf Z})} \\lesssim_{p,q} 1.", block: true)]]

#text("We now compute")

#align(center)[#tao-fit-display[#tao-math("\\begin{array}{rl}  \\left\\| \\lambda \\mu( \\{ \\left|f\\right| \\geq \\lambda \\} )^{1/p} \\right\\|_{L^q({\\bf R}^+,\\frac{d\\lambda}{\\lambda})}^q &\\lesssim_{p,q} \\int_0^\\infty \\lambda^{q-1} \\sup \\{ 2^{nq/p}: H^{\\prime}_n \\geq \\lambda \\}\\ d\\lambda \\\\ &\\lesssim_{p,q} \\sum_n \\int_0^\\infty \\lambda^{q-1} 2^{nq/p} 1_{H^{\\prime}_n \\geq \\lambda}\\ d\\lambda \\\\ &\\sim_{p,q} \\sum_n 2^{nq/p} (H^{\\prime}_n)^q \\\\ &\\lesssim 1 \\end{array}", block: true)]]

#text("as desired. (We leave to the reader how to modify the above argument to handle the case ")#mi("{q=\\infty}")#text(".) ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 30")]#text(" ")#metadata(none) <tao-a383bcb77c832a8ff52c>#text(" For future reference we make the technical remark that if ")#mi("{f}")#text(" is a simple function, then in the horizontal and vertical decompositions in the above theorem, only finitely many of the ")#mi("{f_n}")#text(" are non-zero.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 31")]#text(" Suppose that the ratio between the tallest height and lowest non-zero height of a function ")#mi("{f}")#text(" is ")#mi("{N}")#text(" (i.e. there exists ")#mi("{A}")#text(" such that ")#tao-math("{A \\leq \\left|f(x)\\right| \\leq AN}", block: false)#text(" whenever ")#mi("{f(x)}")#text(" is non-zero). Then the above theorem shows that two different Lorentz norms ")#tao-math("{\\left\\|f\\right\\|_{L^{p,q_1}}}", block: false)#text(", ")#tao-math("{\\left\\|f\\right\\|_{L^{p,q_2}}}", block: false)#text(" with the same primary exponent ")#mi("{p}")#text(" only differ by multiplicative powers of ")#mi("{\\log N}")#text(". Similarly if the broadest width and narrowest width of a function differs by ")#mi("{N}")#text(" (e.g. if ")#mi("{\\mu(X)}")#text(" is equal to ")#mi("{N}")#text(" times the granularity ")#mi("{c}")#text(" of ")#mi("{X}")#text("). What this indicates is that the secondary exponent ")#mi("{q}")#text(" in the Lorentz norms only offers “logarithmic correction” to the Lebesgue norms ")#mi("{L^p}")#text("; in contrast, ")#link(<tao-b1b927541c77e69aea9d>)[#text("(10)")]#text(" shows that varying the primary exponent ")#mi("{p}")#text(" leads to polynomial-strength changes in the norm. So as a first approximation (ignoring logarithms) one can pretend that ")#mi("{L^{p,q} \\approx L^p}")#text(". Note also that for quasi-step functions, the ")#mi("{L^{p,q}}")#text(" norms barely depend on ")#mi("{q}")#text(" at all.")
]

#text("One easy corollary of the above theorem is that the ")#mi("{L^{p,q}}")#text(" quasi-norm is indeed a quasi-norm, and in particular that ")#metadata(none) <tao-1840299c6a9b97aedac4>#tao-math("\\displaystyle  \\left\\| f + g \\right\\|_{L^{p,q}} \\lesssim_{p,q} \\left\\| f \\right\\|_{L^{p,q}} + \\left\\| g \\right\\|_{L^{p,q}} \\ \\ \\ \\ \\ (15)", block: false)#text(" ")#text(" for any ")#mi("{f,g \\in L^{p,q}}")#text("; this can be seen for instance by using the equivalence of (i) and (iii). Another easy consequence is that the simple functions are dense in ")#mi("{L^{p,q}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" ")#metadata(none) <tao-c75de8c1b7c3ae525209>

#list(
[#text("(i) Suppose that ")#mi("{\\| \\|}")#text(" is a quasinorm on some function space ")#mi("{X}")#text(" with quasitriangle inequality constant ")#mi("{C \\geq 1}")#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f+g\\right\\| \\leq C (\\left\\|f\\right\\| + \\left\\|g\\right\\|)", block: true)]]

#text("for all ")#mi("{f,g \\in X}")#text(". Let ")#mi("{p}")#text(" be such that ")#mi("{(2C)^p = 2}")#text(". Show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{n=1}^N f_n \\right\\| \\leq 2 C_0 (\\sum_{n=1}^N \\left\\|f_n\\right\\|^p)^{1/p}.", block: true)]]

#text("(Hint: first show that if ")#tao-math("{\\left\\|f\\right\\|^p, \\left\\|g\\right\\|^p \\leq 2^k}", block: false)#text(", then ")#tao-math("{\\left\\|f+g\\right\\|^p \\leq 2^{k+1}}", block: false)#text(". Then iterate this carefully to show that if ")#tao-math("{\\left\\|f_n\\right\\|^p \\leq 2^{k_n}}", block: false)#text(" for some integers ")#mi("{k_n}")#text(" and ")#mi("{\\sum_{n=1}^N 2^{k_n} \\leq 2^k}")#text(", then ")#tao-math("{\\left\\| \\sum_{n=1}^N f_n \\right\\|^p \\leq 2^{k}}", block: false)#text(". Experience with the game “2048” may be useful here.)")],
[#text("(ii) Suppose that a sequence ")#mi("{f_n \\in L^{p,q}}")#text(" for ")#mi("{n \\geq 0}")#text(" obeys an exponential decay bound of the form")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f_n\\right\\|_{L^{p,q}} \\leq A 2^{-\\varepsilon n}", block: true)]]

#text("for some ")#mi("{A, \\varepsilon > 0}")#text(" and all ")#mi("{n \\geq 0}")#text(". Show that the series")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=0}^\\infty f_n")]]

#text("converges in ")#mi("{L^{p,q}}")#text(", with")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{n=0}^\\infty f_n \\right\\|_{L^{p,q}} \\lesssim_{p,q,A,\\varepsilon} 1.", block: true)]]]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" ")#metadata(none) <tao-112f2dfa31205df3f5f9>#text(" For each integer ")#mi("{n}")#text(", let ")#mi("{f_n}")#text(" be a quasi-step function of height ")#mi("{2^n}")#text(" and width ")#mi("{W_n}")#text(" for some ")#mi("{W_n > 0}")#text(". Show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_n \\left|f_n\\right| \\right\\|_p \\sim_p \\left\\| 2^n W_n^{1/p} \\right\\|_{l^p_n({\\bf Z})}", block: true)]]

#text("for all ")#mi("{0 < p < \\infty}")#text(". If instead ")#mi("{f_n}")#text(" is a quasi-step function of height ")#mi("{H_n}")#text(" and width ")#mi("{2^n}")#text(" for some ")#mi("{H_n > 0}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_n \\left|f_n\\right| \\right\\|_p \\sim_p \\left\\| H_n 2^{n/p} \\right\\|_{l^p_n({\\bf Z})}", block: true)]]

#text("for all ")#mi("{0 < p < \\infty}")#text(". What goes wrong when we remove the absolute values on the ")#mi("{f_n}")#text("? (This can be repaired by replacing the powers of ")#mi("{2}")#text(" with powers of a sufficiently large constant (depending on the implied constant in the definition of a quasi-step function) – why?)")
]

#text("A particularly useful consequence of the above theorem is a Hölder inequality for Lorentz spaces, due to O’Neil.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 34 (Hölder’s inequality in Lorentz spaces)")]#text(" ")#metadata(none) <tao-e8b22d83b417e85ba4f2>#text(" If ")#mi("{0 < p_1,p_2,p < \\infty}")#text(" and ")#mi("{0 < q_1,q_2,q \\leq \\infty}")#text(" obey ")#mi("{\\frac{1}{p} = \\frac{1}{p_1} + \\frac{1}{p_2}}")#text(" and ")#mi("{\\frac{1}{q} = \\frac{1}{q_1} + \\frac{1}{q_2}}")#text(" then")

#align(center)[#tao-fit-display[#tao-math("\\left\\|fg \\right\\|_{L^{p,q}} \\lesssim_{p_1,p_2,q_1,q_2} \\left\\|f\\right\\|_{L^{p_1,q_1}} \\left\\|g\\right\\|_{L^{p_2,q_2}}", block: true)]]

#text("whenever the right-hand side norms are finite.")
]

#emph[#text("Proof:")]#text(" We may normalise ")#tao-math("{\\left\\|f\\right\\|_{L^{p_1,q_1}} = \\left\\|g\\right\\|_{L^{p_2,q_2}} = 1}", block: false)#text(", and drop the dependence of the implied constants on ")#mi("{p_1,p_2,q_1,q_2}")#text(" for brevity. By the equivalence of (i) and (v) in Theorem ")#link(<tao-411b0496da5eeced5314>)[#text("28")]#text(" we may dominate ")#tao-math("{\\left|f\\right| \\leq \\sum_n H_n 1_{E_n}}", block: false)#text(" and ")#tao-math("{\\left|g\\right| \\leq \\sum_n H^{\\prime}_n 1_{E^{\\prime}_n}}", block: false)#text(" where ")#mi("{\\mu(E_n), \\mu(E^{\\prime}_n) \\lesssim 2^n}")#text(" and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| H_n 2^{n/p_1} \\right\\|_{l^{q_1}_n}, \\left\\| H^{\\prime}_n 2^{n/p_2} \\right\\|_{l^{q_2}_n} \\lesssim 1.", block: true)]]

#text("Then we have")

#align(center)[#tao-fit-display[#tao-math("\\left|fg\\right| \\leq \\sum_k \\sum_n H_n H^{\\prime}_{n+k} 1_{E_n \\cap E^{\\prime}_{n+k}}.", block: true)]]

#text("By the quasi-triangle inequality and monotonicity it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{k \\geq 0} \\sum_n H_n H^{\\prime}_{n+k} 1_{E_n \\cap E^{\\prime}_{n+k}} \\right\\|_{L^{p,q}} \\lesssim 1", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{k < 0} \\sum_n H_n H^{\\prime}_{n+k} 1_{E_n \\cap E^{\\prime}_{n+k}} \\right\\|_{L^{p,q}} \\lesssim 1.", block: true)]]

#text("By symmetry it suffices to consider the ")#mi("{k \\geq 0}")#text(" component. Here we observe that ")#mi("{E_n \\cap E^{\\prime}_{n+k}}")#text(" has measure at most ")#mi("{2^n}")#text(", so by the equivalence of (i) and (v) in Theorem ")#link(<tao-411b0496da5eeced5314>)[#text("28")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_n H_n H^{\\prime}_{n+k} 1_{E_n \\cap E^{\\prime}_{n+k}} \\right\\|_{L^{p,q}} \\lesssim \\left\\| H_n H^{\\prime}_{n+k} 2^{n/p} \\right\\|_{l^q_n}.", block: true)]]

#text("But by the ordinary Hölder inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| H_n H^{\\prime}_{n+k} 2^{n/p} \\right\\|_{l^q_n} \\leq \\left\\| H_n 2^{n/p_1} \\right\\|_{l^{q_1}_n} \\left\\| H^{\\prime}_{n+k} 2^{n/p_2} \\right\\|_{l^{q_2}_n};", block: true)]]

#text("shifting the second ")#mi("{n}")#text(" by ")#mi("{k}")#text(" we conclude")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_n H_n H^{\\prime}_{n+k} 1_{E_n \\cap E^{\\prime}_{n+k}} \\right\\|_{L^{p,q}} \\lesssim 2^{-k/p_2}.", block: true)]]

#text("The claim now follows from Exercise ")#link(<tao-c75de8c1b7c3ae525209>)[#text("32")]#text(". ")#mi("\\Box")

#text("One corollary of this Hölder inequality is that ")#mi("{L^{p,q}}")#text(" functions are absolutely integrable on sets of finite measure whenever ")#mi("{p > 1}")#text(".")

#text("Now we consider dual formulations of the ")#mi("{L^{p,q}}")#text(" norms. The case ")#mi("{q=\\infty}")#text(" is fairly straightforward:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35 (Dual formulation of weak ")#mi("{L^p}")#text(")")]#text(" ")#metadata(none) <tao-263ee003202c57530e24>#text(" Let ")#mi("{1 < p \\leq \\infty}")#text(". Then for every ")#mi("{f}")#text(" in ")#mi("{L^{p,\\infty}(X,d\\mu)}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^{p,\\infty}(X,d\\mu)}", block: true)]]

#metadata(none) <tao-4ec7b4a66524f8d6bdd4>#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\sim_p \\sup \\{ \\mu(E)^{-1/p^{\\prime}} \\left|\\int_X f 1_E\\ d\\mu\\right|: 0 < \\mu(E) < \\infty \\}", block: true)]]

#text("Also show that the hypothesis ")#mi("{f \\in L^{p,\\infty}(X,d\\mu)}")#text(" can be dropped if one instead assumes ")#mi("{f}")#text(" to be non-negative.")
]

#text("The right-hand side of ")#link(<tao-4ec7b4a66524f8d6bdd4>)[#text("(16)")]#text(" is clearly a semi-norm at least on ")#mi("{f}")#text(". This leads in particular to a quasi-triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f_1 + \\ldots + f_N \\right\\|_{L^{p,\\infty}(X,d\\mu)} \\sim_p \\left\\|f_1\\right\\|_{L^{p,\\infty}(X,d\\mu)} + \\ldots + \\left\\|f_N\\right\\|_{L^{p,\\infty}(X,d\\mu)}", block: true)]]

#text("for any ")#mi("{f_1,\\ldots,f_N \\in L^{p,\\infty}(X,d\\mu)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 36")]#text(" It is worth comparing ")#link(<tao-4ec7b4a66524f8d6bdd4>)[#text("(16)")]#text(" to ")#link(<tao-c5419f8b099324d31350>)[#text("(4)")]#text(". In ")#link(<tao-c5419f8b099324d31350>)[#text("(4)")]#text(", one takes the inner product of ")#mi("{f}")#text(" against all ")#mi("{L^{p^{\\prime}}}")#text("-normalised functions, and the worst inner product becomes the ")#mi("{L^p}")#text(" norm. In ")#link(<tao-4ec7b4a66524f8d6bdd4>)[#text("(16)")]#text(", one only takes the inner product of ")#mi("{f}")#text(" against the ")#mi("{L^{p^{\\prime}}}")#text("-normalised ")#emph[#text("step functions")]#text(" ")#mi("{\\mu(E)^{-1/p^{\\prime}} 1_E}")#text(". This is fully consistent with the fact that the ")#mi("{L^p}")#text(" norm is stronger than the weak ")#mi("{L^p}")#text(" norm.")
]

#text("Exercise ")#link(<tao-263ee003202c57530e24>)[#text("35")]#text(" can be rephrased as follows: if ")#mi("{f \\in L^{p,\\infty}}")#text(" for some ")#mi("{1 < p < \\infty}")#text(" and ")#mi("{A > 0}")#text(", then the following two statements are equivalent (up to changes in the implied constants):")

#list(
[#tao-math("{\\left\\|f\\right\\|_{L^{p,\\infty}} \\lesssim_p A}", block: false)#text(".")],
[#mi("{\\int_X f 1_E\\ d\\mu = O_p( A \\mu(E)^{1/p^{\\prime}} )}")#text(" for all sets ")#mi("{E}")#text(" of finite measure.")]
)

#text("Unfortunately this equivalence breaks down at ")#mi("{p=1}")#text(" or below (consider for instance the weak ")#mi("{L^p}")#text(" function ")#tao-math("{\\left|x\\right|^{-d/p}}", block: false)#text(" on ")#mi("{{\\bf R}^d}")#text(", which is not even locally integrable when ")#mi("{p \\leq 1}")#text("). However, one does have a substitute:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37")]#text(" ")#metadata(none) <tao-26eab90d2b0be7cd1889>#text(" Let ")#mi("{0 < p < \\infty}")#text(", ")#mi("{0 < A < \\infty}")#text(", and ")#mi("{f \\in L^{p,\\infty}(X,d\\mu)}")#text(". Show that the following are equivalent (up to changes in the implied constant):")

#list(
[#tao-math("{\\left\\|f\\right\\|_{L^{p,\\infty}(X,d\\mu)} \\lesssim_p A}", block: false)#text(".")],
[#text("For every set ")#mi("{E}")#text(" of finite measure, there exists a subset ")#mi("{E^{\\prime}}")#text(" of ")#mi("{E}")#text(" with ")#mi("{\\mu(E^{\\prime}) \\geq \\frac{1}{2} \\mu(E)}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_X f 1_{E^{\\prime}}\\ d\\mu = O( \\mu(E)^{1/p^{\\prime}} )")]]

#text("(in particular, we assert that the integral on the left-hand side is absolutely integrable).")]
)

#text("Hint: It may be instructive to work out the example ")#tao-math("{f(x) = \\left|x\\right|^{-d/p}}", block: false)#text(" on ")#mi("{{\\bf R}^d}")#text(" by hand to get a sense of what is going on; this should suggest how to prove things in general. The proof is slightly simpler in the case when ")#mi("{f}")#text(" is non-negative, so you may want to try that case first. Comment on how this result implies Exercise ")#link(<tao-263ee003202c57530e24>)[#text("35")]#text(" (or its equivalent version discussed shortly afterwards) when ")#mi("{p > 1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38")]#text(" ")#metadata(none) <tao-58e2791934fdd9cfdd6d>#text(" Let ")#mi("{f_1,\\ldots,f_N}")#text(" be functions with ")#mi("{N \\geq 2}")#text(". Show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f_1 + \\ldots + f_N \\right\\|_{L^{1,\\infty}} \\lesssim \\log N ( \\left\\|f_1\\right\\|_{L^{1,\\infty}} + \\ldots + \\left\\| f_N \\right\\|_{L^{1,\\infty}} ).", block: true)]]

#text("thus the weak ")#mi("{L^{1,\\infty}}")#text(" quasinorm only fails to be a norm “by a logarithm”. Show with an example that the ")#mi("{\\log N}")#text(" cannot be removed.")
]

#text("For more general ")#mi("{L^{p,q}}")#text(" spaces, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 39 (Dual characterisation of ")#mi("{L^{p,q}}")#text(")")]#text(" ")#metadata(none) <tao-95b3667a66d21c2aca2a>#text(" Let ")#mi("{1 < p < \\infty}")#text(" and ")#mi("{1 \\leq q \\leq \\infty}")#text(". Then for any ")#mi("{f \\in L^{p,q}}")#text(",")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^{p,q}} \\sim_{p,q} \\sup \\{ \\left|\\int_X f \\overline{g}\\ d\\mu\\right|: \\left\\|g\\right\\|_{L^{p^{\\prime},q^{\\prime}}} \\leq 1 \\}.", block: true)]]

#text("Again, the hypothesis ")#mi("{f \\in L^{p,q}}")#text(" can be dropped if ")#mi("{f}")#text(" is non-negative and ")#mi("{g}")#text(" is restricted to also be non-negative.")
]

#text("Thus the ")#mi("{L^{p,q}}")#text(" quasi-norm is in fact equivalent to a norm when ")#mi("{1 < p < \\infty}")#text(" and ")#mi("{q \\geq 1}")#text(". In particular, weak ")#mi("{L^p}")#text(" is equivalent to a normed space when ")#mi("{1 < p < \\infty}")#text(". (For ")#mi("{p=1}")#text(", weak ")#mi("{L^p}")#text(" fails to be normable “by a logarithm”; see Q3.) As with other dual characterisations, one can restrict ")#mi("{g}")#text(" to a dense subclass of ")#mi("{L^{p^{\\prime},q^{\\prime}}}")#text(", for instance simple functions with finite measure support.")

#emph[#text("Proof:")]#text(" To obtain the ")#mi("{\\gtrsim_{p,q}}")#text(" part of this theorem, we simply estimate")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_X f \\overline{g}\\ d\\mu\\right| \\leq \\left\\|fg\\right\\|_{L^1} = \\left\\|fg\\right\\|_{L^{1,1}}", block: true)]]

#text("and use Theorem ")#link(<tao-e8b22d83b417e85ba4f2>)[#text("34")]#text(". To obtain the ")#mi("{\\lesssim_{p,q}}")#text(" part, we normalise ")#tao-math("{\\left\\|f\\right\\|_{L^{p,q}} = 1}", block: false)#text(". It then suffices by homogeneity to find ")#mi("{g}")#text(" with ")#tao-math("{\\left\\|g\\right\\|_{L^{p^{\\prime},q^{\\prime}}} \\leq 1}", block: false)#text(" and ")#mi("{\\int_X f \\overline{g}\\ d\\mu \\gtrsim 1}")#text(".")

#text("The case ")#mi("{q=\\infty}")#text(" follows from ")#link(<tao-4ec7b4a66524f8d6bdd4>)[#text("(16)")]#text(", so let us take ")#mi("{q < \\infty}")#text(". We will just give the proof in the case ")#mi("{q \\geq p}")#text("; the case ")#mi("{p<q}")#text(" is trickier, and a partial argument is given in the exercises. By the equivalence of (i) and (ii) in Theorem ")#link(<tao-411b0496da5eeced5314>)[#text("28")]#text(" may write ")#mi("{f = \\sum_m f_m}")#text(" where ")#mi("{f_m}")#text(" is a quasi-step function of height ")#mi("{H_n}")#text(" and width ")#mi("{W_m}")#text(" with disjoint supports such that the sequence ")#mi("{a_m := 2^m W_m^{1/p}}")#text(" has an ")#mi("{l^q_m}")#text(" norm of ")#mi("{\\sim_{p,q} 1}")#text(". Now take")

#align(center)[#tao-fit-display[#mitex("g := \\sum_m g_m")]]

#text("where")

#align(center)[#tao-fit-display[#tao-math("g_m := a_m^{q-p} \\left|f_m\\right|^{p-2} f_m", block: true)]]

#text("adopting the obvious convention that ")#tao-math("{\\left|f_m\\right|^{p-2} f_m = 0}", block: false)#text(" when ")#mi("{f_m=0}")#text(". Then (because of the disjoint supports)")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_X f \\overline{g}\\right| = \\sum_m \\int_X a_m^{q-p} \\left|f_m\\right|^p.", block: true)]]

#text("But since ")#mi("{f_m}")#text(" has height ")#mi("{2^m}")#text(" and width ")#mi("{W_m}")#text(", ")#tao-math("{\\int_X \\left|f_m\\right|^p \\sim_p 2^{mp} W_m = a_m^p}", block: false)#text(" and so")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_X f \\overline{g}\\right| \\sim_p \\sum_m a_m^q \\sim_{p,q} 1.", block: true)]]

#text("To conclude it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|\\sum_m g_m \\right\\|_{L^{p^{\\prime},q^{\\prime}}} \\lesssim_{p,q} 1.", block: true)]]

#text("If ")#mi("{E_m}")#text(" is the support of ")#mi("{f_m}")#text(", then we have the pointwise bound")

#align(center)[#tao-fit-display[#mitex("g_m \\lesssim_{p,q} a_m^{q-p} 2^{m(p-1)} 1_{E_m}")]]

#text("and the measure bound ")#mi("{\\mu(E_m) \\lesssim_{p,q} W_m = 2^{-mp} a_m^p}")#text(".")

#text("At this point we would like to apply Theorem ")#link(<tao-411b0496da5eeced5314>)[#text("28")]#text(", but neither the height nor width of ")#mi("{g_m}")#text(" is necessarily a power of ")#mi("{2}")#text(". But we can remedy this by introducing the modified heights")

#align(center)[#tao-fit-display[#mitex("H_m := \\sup_{k \\geq 0} a_{m-k}^{q-p} 2^{m(p-1)} 2^{-k(p-1)/2}.")]]

#text("We have ")#mi("{H_{m+1} \\geq 2^{(p-1)/2} H_m}")#text(", and so the ")#mi("{H_m}")#text(" increase geometrically. It then suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_m H_m 1_{E_m} \\right\\|_{L^{p^{\\prime},q^{\\prime}}} \\lesssim_{p,q} 1.", block: true)]]

#text("By refining the ")#mi("{m}")#text(" by a constant factor we can make each ")#mi("{H_m}")#text(" at least twice as large as the previous, and so by applying the equivalences of (i) and (iii) in Theorem ")#link(<tao-411b0496da5eeced5314>)[#text("28")]#text(" and the triangle inequality it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| H_m \\mu(E_m)^{1/p^{\\prime}} \\right\\|_{l^{q^{\\prime}}_m} \\lesssim_{p,q} 1", block: true)]]

#text("which we expand using our bound on ")#mi("{\\mu(E_m)}")#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\left\\| a_m^{p-1} \\sup_{k \\geq 0} a_{m-k}^{q-p} 2^{-k(p-1)/2} \\right\\|_{l^{q^{\\prime}}_m}.", block: true)]]

#text("But from Hölder’s inequality (using the hypothesis ")#mi("{q-p \\geq 0}")#text(") and the ")#mi("{l^q}")#text(" bound on ")#mi("{a_m}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| a_m^{p-1} a_{m-k}^{q-p} 2^{-k(p-1)/2} \\right\\|_{l^{q^{\\prime}}_m} \\lesssim_{p,q} 2^{-k(p-1)/2};", block: true)]]

#text("summing this using the triangle inequality (and estimating the supremum by a sum) we obtain the claim.")

#text("The case when ")#mi("{f,g}")#text(" are restricted to be non-negative can be deduced from the above result and a monotone convergence argument (representing ")#mi("{f}")#text(" as a monotone limit of simple functions of finite measure support) which we leave as an exercise to the reader. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 40")]#text(" A measure space ")#mi("{(X,\\mu)}")#text(" is said to be ")#link("https://en.wikipedia.org/wiki/Atom_(measure_theory)")[#text("non-atomic")]#text(" if, for every measurable set ")#mi("{A \\subset X}")#text(" with ")#mi("{\\mu(A) > 0}")#text(", there exists a measurable subset ")#mi("{B \\subset A}")#text(" such that ")#mi("{0 < \\mu(B) < \\mu(A)}")#text(".")

#list(
[#text("(i) (Sierpinski’s theorem) Show that if ")#mi("{(X,\\mu)}")#text(" is non-atomic, ")#mi("{A \\subset X}")#text(" is measurable, and ")#mi("{0 \\leq b \\leq \\mu(A)}")#text(", then there exists a measurable subset ")#mi("{B}")#text(" of ")#mi("{A}")#text(" such that ")#mi("{\\mu(B) = b}")#text(". (You may find it convenient to use Zorn’s lemma.)")],
[#text("(ii) Show that if ")#mi("{(X,\\mu)}")#text(" is non-atomic, then the decomposition in Theorem ")#link(<tao-411b0496da5eeced5314>)[#text("28")]#text("(iv) can be chosen so that for each ")#mi("{n}")#text(", either ")#mi("{H_{n+1}}")#text(" vanishes, or ")#mi("{f_n}")#text(" has support of measure ")#mi("{\\sim 2^n}")#text(" (not just bounded by ")#mi("{2^n}")#text(").")],
[#text("(iii) Establish Theorem ")#link(<tao-411b0496da5eeced5314>)[#text("28")]#text(" in the case that ")#mi("{q < p}")#text(" and ")#mi("{(X,\\mu)}")#text(" is non-atomic, by using the modification of Theorem ")#link(<tao-411b0496da5eeced5314>)[#text("28")]#text(" indicated in the previous part of the exercise.")]
)

#text("The duality can also be established for measure spaces that contain atoms, but this requires a more careful analysis that treats large atoms separately.")
]

#heading(level: 1)[#strong[#text(" — 3. Orlicz spaces (Optional) — ")]]

#text("So far we have studied the Lebesgue spaces ")#mi("{L^p}")#text(", together with the more general Lorentz spaces ")#mi("{L^{p,q}}")#text(", which includes weak ")#mi("{L^p}")#text(" as a special case. These spaces are all rearrangement-invariant and monotone. There is a different generalisation of the Lebesgue spaces ")#mi("{L^p}")#text(", the ")#emph[#text("Orlicz spaces")]#text(" ")#mi("{\\Phi(L)}")#text(", which are also rearrangement-invariant and monotone, and which are occasionally useful. (There is a common generalisation of both, the ")#emph[#text("Lorentz-Orlicz spaces")]#text(", but these occur very rarely in applications.)")

#text("The motivation for Orlicz spaces starts with the trivial observation that if ")#mi("{1 \\leq p < \\infty}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^p} \\leq 1 \\text{ if and only if } \\int_X \\left|f\\right|^p\\ d\\mu \\leq 1.", block: true)]]

#text("Inspired by this, we generalise by letting ")#mi("{\\Phi: {\\bf R}^+ \\rightarrow {\\bf R}^+}")#text(" be a function (with some additional properties to be selected shortly) and ask if we can find a norm ")#tao-math("{\\left\\| f \\right\\|_{\\Phi(L)}}", block: false)#text(" which obeys the property")

#metadata(none) <tao-4b25923a4f31b83195ce>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\left\\|f\\right\\|_{\\Phi(L)} \\leq 1 \\text{ if and only if } \\int_X \\Phi(\\left|f\\right|)\\ d\\mu \\leq 1.", block: true)]]

#text("Since norms need to be homogeneous, this would imply")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{\\Phi(L)} \\leq A \\text{ if and only if } \\int_X \\Phi(\\left|f\\right|/A)\\ d\\mu \\leq 1", block: true)]]

#text("for all ")#mi("{A > 0}")#text(". In particular, if ")#mi("{A < A^{\\prime}}")#text(", then we need")

#align(center)[#tao-fit-display[#tao-math("\\int_X \\Phi(\\left|f\\right|/A)\\ d\\mu \\leq 1 \\text{ implies } \\int_X \\Phi(\\left|f\\right|/A^{\\prime})\\ d\\mu \\leq 1.", block: true)]]

#text("To ensure this property it is thus very natural to require that ")#mi("{\\Phi}")#text(" be ")#emph[#text("increasing")]#text(". Also to deal with the zero norm case one typically requires ")#mi("{\\Phi(0)=0}")#text(".")

#text("Next, in order for ")#mi("{\\Phi(L)}")#text(" to be a norm, the unit ball ")#tao-math("{\\{ f: \\left\\| f \\right\\|_{\\Phi(L)} \\leq 1 \\}}", block: false)#text(" needs to be convex. Looking at ")#link(<tao-4b25923a4f31b83195ce>)[#text("(17)")]#text(", we see that this will indeed be the case when ")#mi("{\\Phi}")#text(" is itself convex. (Note that the proof of ")#link(<tao-0a3f13c673af2389ecb9>)[#text("(5)")]#text(" was a special case of this argument).")

#text("We can put all the above discussion together and conclude: if ")#mi("{\\Phi: {\\bf R}^+ \\rightarrow {\\bf R}^+}")#text(" is increasing and convex with ")#mi("{\\Phi(0)=0}")#text(", then the norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{\\Phi(L)} := \\inf \\{ A > 0: \\int_X \\Phi(\\left|f\\right|/A)\\ d\\mu \\leq 1 \\}", block: true)]]

#text("is a norm on the space ")#tao-math("{\\Phi(L) := \\{ f: \\left\\|f\\right\\|_{\\Phi(L)} < \\infty \\}}", block: false)#text(".")

#text("As discussed above, the ")#mi("{L^p}")#text(" spaces for ")#mi("{1 \\leq p < \\infty}")#text(" are examples of Orlicz spaces with ")#mi("{\\Phi(x) := x^p}")#text(". The space ")#mi("{L^\\infty}")#text(" is not really an Orlicz space, but can be viewed the limiting case where ")#mi("{\\Phi(x)}")#text(" is infinite for ")#mi("{x > 1}")#text(" and zero for ")#mi("{x \\leq 1}")#text(" (or more informally, ")#mi("{\\Phi(x) = x^{+\\infty}}")#text("). Aside from the Lebesgue spaces, the most common Orlicz spaces which appear are")

#list(
[#text("The space ")#mi("{L \\log L}")#text(", defined as the Orlicz space with ")#mi("{\\Phi(x) := x \\log (2+x)}")#text(";")],
[#text("The space ")#mi("{e^L}")#text(", defined as the Orlicz space with ")#mi("{\\Phi(x) := e^x - 1}")#text(";")],
[#text("The space ")#mi("{e^{L^2}}")#text(", defined as the Orlicz space with ")#mi("{\\Phi(x) := e^{x^2} - 1}")#text(".")]
)

#text("The correction factors of ")#mi("{2}")#text(" and ")#mi("{1}")#text(" in the above functions should not be taken too seriously; note that if two functions ")#mi("{\\Phi, \\tilde \\Phi}")#text(" are comparable then their Orlicz norms are comparable also; a little more generally, if ")#mi("{\\Phi \\lesssim \\tilde \\Phi}")#text(", then ")#tao-math("{\\left\\|f\\right\\|_{\\Phi(L)} \\lesssim \\left\\| f \\right\\|_{\\tilde \\Phi(L)}}", block: false)#text(". It is the behaviour of ")#mi("{\\Phi(x)}")#text(" for large values of ")#mi("{x}")#text(" which is the most important, although when ")#mi("{X}")#text(" has infinite measure the behaviour at small values of ")#mi("{x}")#text(" is also relevant.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 41")]#text(" If ")#mi("{X}")#text(" has finite measure, verify the relation")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{\\Phi(L)} \\sim_{\\Phi, \\mu(X)} \\left\\| f \\right\\|_{1+\\Phi(L)}", block: true)]]

#text("which is another indication of the irrelevance of the low values of ")#mi("{\\Phi}")#text(" in the finite measure case.")
]

#text("The final fact about Orlicz spaces that we give here is the duality relation. Suppose that ")#mi("{\\Phi: {\\bf R}^+ \\rightarrow {\\bf R}^+}")#text(" is increasing, convex, and is also ")#emph[#text("superlinear")]#text(" in the sense that ")#mi("{\\lim_{x \\rightarrow +\\infty} \\Phi(x)/x = +\\infty}")#text(". We can then define the ")#emph[#text("Young dual")]#text(" ")#mi("{\\Psi: {\\bf R}^+ \\rightarrow {\\bf R}^+}")#text(" of ")#mi("{\\Phi}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\Psi(y) := \\sup \\{ xy - \\Phi(x): x \\in {\\bf R}^+ \\};")]]

#text("the hypothesis that ")#mi("{\\Phi}")#text(" is superlinear ensures that this function is well-defined. We may equivalently define ")#mi("{\\Psi(y)}")#text(" to be the smallest function for which one has the inequality")

#metadata(none) <tao-769a4e6d0003189c7e96>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("xy \\leq \\Phi(x) + \\Psi(y) \\text{ for all } x, y \\in {\\bf R}^+.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42")]#text(" If ")#mi("{1 < p < \\infty}")#text(", show that the Young dual of ")#mi("{\\Phi(x) = x^p}")#text(" is ")#mi("{\\Psi(y) = \\frac{p^{p^{\\prime}/p}}{p^{\\prime}} y^{p^{\\prime}}}")#text(". Show also that the Young dual of ")#mi("{\\Phi(x) = x \\log(2+x)}")#text(" takes the form ")#mi("{\\Psi(y) \\sim e^y}")#text(" for ")#mi("{y > 1}")#text(". What does the Young duals of ")#mi("{e^x - 1}")#text(" and ")#mi("{e^{x^2}-1}")#text(" look like?")
]

#text("One can easily verify that ")#mi("{\\Psi}")#text(" is also increasing, convex, and super-linear, and so the Orlicz norm ")#mi("{\\| \\|_{\\Psi(L)}}")#text(" makes sense. From ")#link(<tao-769a4e6d0003189c7e96>)[#text("(18)")]#text(" and the triangle inequality it is immediate that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_X f \\overline{g}\\ d\\mu\\right| \\leq 2 \\text{ whenever } \\left\\|f\\right\\|_{\\Phi(L)}, \\left\\|g\\right\\|_{\\Psi(L)} \\leq 1", block: true)]]

#text("and hence by homogeneity we obtain the duality relation")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_X f \\overline{g}\\ d\\mu\\right| \\leq 2 \\left\\|f\\right\\|_{\\Phi(L)} \\left\\|g\\right\\|_{\\Psi(L)}", block: true)]]

#text("whenever ")#mi("{f \\in \\Phi(L)}")#text(" and ")#mi("{g \\in \\Psi(L)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 43")]#text(" Establish the more precise relationship")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{\\Phi(L)} \\sim \\sup \\{ \\left|\\int_X f \\overline{g}\\ d\\mu\\right| : \\left\\|g\\right\\|_{\\Psi(L)} \\leq 1 \\}.", block: true)]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 44")]#text(" Let ")#mi("{\\Phi}")#text(" be superlinear, increasing, convex, and vanishing at the origin.")

#list(
[#text("(i) Show that the Young dual ")#mi("{\\Psi}")#text(" of ")#mi("{\\Phi}")#text(" is also superlinear, increasing, convex, and vanishing at the origin.")],
[#text("(ii) Show that ")#mi("{\\Phi}")#text(" is the Young dual of ")#mi("{\\Psi}")#text(".")]
)

#text("(It may help to view things geometrically, and in particular understanding ")#mi("{\\Psi}")#text(" as parameterising the support lines of the graph of the convex function ")#mi("{\\Phi}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 45")]#text(" When ")#mi("{X}")#text(" has finite measure, show that the spaces ")#mi("{L \\log L}")#text(" and ")#mi("{e^L}")#text(" are dual to each other. What is the dual to ")#mi("{e^{L^2}}")#text("?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 46")]#text(" ")#metadata(none) <tao-77ec676ad8200ac1dc86>#text(" Let ")#mi("{f}")#text(" be a function on a measure space ")#mi("{X}")#text(" of bounded measure ")#mi("{\\mu(X) = O(1)}")#text(". Show that the following are equivalent (up to changes in the implied constants):")

#list(
[#text("(i) ")#tao-math("{\\left\\|f\\right\\|_{e^L} = O(1)}", block: false)#text(".")],
[#text("(ii) ")#tao-math("{\\left\\|f\\right\\|_{L^{p,\\infty}} = O(p)}", block: false)#text(" for all ")#mi("{1 \\leq p < \\infty}")#text(".")],
[#text("(iii) ")#tao-math("{\\left\\|f\\right\\|_{L^p} = O(p)}", block: false)#text(" for all ")#mi("{1 \\leq p < \\infty}")#text(".")]
)

#text("Hint: You may find the Taylor expansion for ")#mi("{e^x}")#text(", together with the obvious bounds ")#mi("{(k/2)^{k/2 - 1} \\leq k! \\leq k^k}")#text(" for integer ")#mi("{k}")#text(" (or Stirling’s formula, if you know what that is), to be useful.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 47")]#text(" Obtain the analogue of Exercise ")#link(<tao-77ec676ad8200ac1dc86>)[#text("46")]#text(" for the Orlicz space ")#mi("{e^{L^2}}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 4. Real interpolation — ")]]

#text("So far we have only considered functions ")#mi("{f}")#text(" on a single measure space ")#mi("{X = (X, {\\mathcal B}_X, \\mu_X)}")#text(". Now we shall consider operators ")#mi("{T}")#text(" which take functions on one measure space ")#mi("{X = (X, {\\mathcal B}_X, \\mu_X)}")#text(" to functions on another measure space ")#mi("{Y = (Y, {\\mathcal B}_Y, \\mu_Y)}")#text("; the study of such operators is in fact a major focus of harmonic analysis. Ultimately we want to extend ")#mi("{T}")#text(" to a standard normed vector space such as ")#mi("{L^p(X)}")#text(", but in practice one has to initially first restrict attention to a dense subspace of functions, such as simple functions or test functions.")

#text("We are primarily interested in linear operators, thus ")#mi("{T(cf) = c Tf}")#text(" and ")#mi("{T(f+g) = Tf + Tg}")#text(". But it is also worth considering the more general ")#emph[#text("sublinear operators")]#text(", in which")

#align(center)[#tao-fit-display[#tao-math("\\left|T(cf)\\right| = \\left|c\\right| \\left|Tf\\right|", block: true)]]

#text("and we have the pointwise estimate")

#align(center)[#tao-fit-display[#tao-math("\\left|T(f+g)\\right| \\leq \\left|Tf\\right| + \\left|Tg\\right|.", block: true)]]

#text("Apart from the linear operators, the next most important example of a sublinear operator is a ")#emph[#text("maximal operator")]

#align(center)[#tao-fit-display[#tao-math("Tf(x) := \\sup_n \\left|T_n f(x)\\right|", block: true)]]

#text("where ")#mi("{T_n}")#text(" are a collection (possibly countably or uncountably infinite, though in the latter case one has to take some care in ensuring measurability) of linear or sublinear operators. The third most important example is a ")#emph[#text("square function")]#text(" such as")

#align(center)[#tao-fit-display[#tao-math("Tf(x) := (\\sum_n \\left|T_n f(x)\\right|^2)^{1/2}.", block: true)]]

#text("More generally, one can consider a family ")#mi("{T_y}")#text(" of operators indexed by some parameter ")#mi("{y}")#text(", and take ")#mi("{Tf(x)}")#text(" to be the norm in the ")#mi("{y}")#text(" variable of ")#mi("{T_y f}")#text(" in some suitable norm. But the above three examples of linear operators, maximal operators, and square functions already cover the vast majority of applications.")

#text("Let ")#mi("{0 < p,q \\leq \\infty}")#text(" be exponents, and let ")#mi("{T}")#text(" be sublinear. Let us define the following concepts.")

#list(

)

#text("Clearly, whenever ")#mi("{p,q}")#text(" are fixed, strong-type implies weak-type and restricted strong-type, either of which imply restricted weak-type. In most applications, it is the strong-type bounds which are desired; however, we shall see in this section that the ")#emph[#text("real interpolation method")]#text(" allows us to deduce strong-type bounds from weak-type, or even restricted weak-type bounds, as long as the strong-type bounds are an interpolant between the restricted weak-type bounds. This can be a very useful strategy, because (as we shall see in next week’s notes) weak-type or restricted weak-type bounds are easier to prove than strong-type estimate.")

#text("Let us first make a mild (and qualitative) assumption, namely that the form ")#metadata(none) <tao-0a8125a9f9ab79e4a5bc>#tao-math("\\displaystyle  \\langle \\left|Tf\\right|, \\left|g\\right| \\rangle := \\int_Y \\left|Tf\\right| \\left|g\\right|\\ d\\nu \\ \\ \\ \\ \\ (23)", block: false)#text(" ")#text(" is well-defined whenever ")#mi("{f, g}")#text(" are simple functions with finite measure support. This is for instance the case if ")#mi("{T}")#text(" is of restricted type ")#mi("{(p,q)}")#text(" for some ")#mi("{0 < p < \\infty}")#text(" and ")#mi("{1 \\leq q \\leq \\infty}")#text(", or restricted weak-type ")#mi("{(p,q)}")#text(" for some ")#mi("{0 < p < \\infty}")#text(" and ")#mi("{1 < q < \\infty}")#text("; thus in practice this assumption is easily satisfied. We observe that this form is non-negative, homogeneous and sublinear in both ")#mi("{f}")#text(" and ")#mi("{g}")#text(":")

#align(center)[#tao-fit-display[#tao-math("\\begin{array}{rl}  \\langle \\left|Tcf\\right|, \\left|g\\right| \\rangle = \\langle \\left|Tf\\right|, \\left|cg\\right| \\rangle &= \\left|c\\right| \\langle \\left|Tf\\right|, \\left|g\\right| \\rangle \\\\ \\langle \\left|T(f_1+f_2)\\right|, \\left|g\\right| \\rangle &\\leq \\langle \\left|T f_1\\right|, \\left|g\\right| \\rangle + \\langle \\left|T f_2\\right|, \\left|g\\right| \\rangle \\\\ \\langle \\left|Tf\\right|, \\left|g_1+g_2\\right| \\rangle &\\leq \\langle \\left|T f\\right|, \\left|g_1\\right| \\rangle + \\langle \\left|T f\\right|, \\left|g_2\\right| \\rangle. \\end{array}", block: true)]]

#text("The form ")#tao-math("{\\langle \\left|Tf\\right|, \\left|g\\right| \\rangle}", block: false)#text(" turns out to be a convenient way to understand the various types of ")#mi("{T}")#text(", and the ability to decompose both ")#mi("{f}")#text(" and ")#mi("{g}")#text(" independently is very useful in establishing interpolation type results. There is a near-symmetry between ")#mi("{f}")#text(" and ")#mi("{g}")#text(" here, if we could somehow take an “adjoint” of the operator ")#mi("{T}")#text(", but we will not explicitly exploit this symmetry here as it is not always available for sublinear operators (though the “duality” or “adjoint” trick is undoubtedly very powerful in the important linear case).")

#text("Let us look in particular at the form ")#link(<tao-0a8125a9f9ab79e4a5bc>)[#text("(23)")]#text(" applied to indicator functions, thus we look at the quantity ")#tao-math("{\\langle \\left|T1_E\\right|, 1_F \\rangle}", block: false)#text(" for ")#mi("{E \\subset X}")#text(" and ")#mi("{F \\subset Y}")#text(" of finite measure. Now suppose that ")#mi("{T}")#text(" had some strong type ")#mi("{(p,q)}")#text(" bound for some ")#mi("{0 < p < \\infty}")#text(" and ")#mi("{1 \\leq q \\leq \\infty}")#text(", say")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Tf \\right\\|_{L^q(Y)} \\lesssim_{p,q} A \\left\\|f\\right\\|_{L^p(X)}", block: true)]]

#text("for some ")#mi("{A > 0}")#text(". Then in particular")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T1_E \\right\\|_{L^q(Y)} \\lesssim_{p,q} A \\mu(E)^{1/p}", block: true)]]

#text("and hence by Hölder’s inequality")

#metadata(none) <tao-8272b4d3ee32969b07da>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#tao-math("\\langle \\left|T1_E\\right|, 1_F \\rangle \\lesssim_{p,q} A \\mu(E)^{1/p} \\nu(F)^{1/q^{\\prime}}.", block: true)]]

#text("Actually it is clear that strong type ")#mi("{(p,q)}")#text(" is too much of an assumption; restricted type ")#mi("{(p,q)}")#text(" would have sufficed for the conclusion. If ")#mi("{q > 1}")#text(", we can relax things further to restricted weak-type:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 48")]#text(" ")#metadata(none) <tao-0c5245f4ec183c41851a>#text(" Let ")#mi("{0 < p \\leq \\infty}")#text(", ")#mi("{1 < q \\leq \\infty}")#text(", and ")#mi("{A > 0}")#text(". Let ")#mi("{T}")#text(" be a sublinear operator such that the form ")#link(<tao-0a8125a9f9ab79e4a5bc>)[#text("(23)")]#text(" is well-defined. Then the following are equivalent up to changes in the implied constant:")

#list(
[#mi("{T}")#text(" is restricted weak-type ")#mi("{(p,q)}")#text(" with constant ")#mi("{A}")#text(", in the sense that")

#metadata(none) <tao-160b648003f5084f0f43>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#tao-math("\\left\\| T f \\right\\|_{L^{q,\\infty}(Y)} \\lesssim_{p,q} A H W^{1/p}", block: true)]]

#text("for all simple sub-step functions ")#mi("{f}")#text(" of height ")#mi("{H}")#text(" and width ")#mi("{W}")#text(".")],
[#text("For all ")#mi("{E \\subset X}")#text(", ")#mi("{F \\subset Y}")#text(" of finite measure, we have the bound")

#align(center)[#tao-fit-display[#tao-math("\\langle \\left|T1_E\\right|, 1_F \\rangle \\lesssim_{p,q} A \\mu(E)^{1/p} \\nu(F)^{1/q^{\\prime}}", block: true)]]]
)

#text("(Hint: use ")#link(<tao-4ec7b4a66524f8d6bdd4>)[#text("(16)")]#text(" and Remark ")#link(<tao-9a3a45d01531a20e89ac>)[#text("27")]#text(".)")
]

#text("This already gives a simple version of real interpolation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 49 (Baby real interpolation)")]#text(" ")#metadata(none) <tao-d864124834f9d01a1107>#text(" Let ")#mi("{T}")#text(" be a sublinear operator such that the form ")#link(<tao-0a8125a9f9ab79e4a5bc>)[#text("(23)")]#text(" is well-defined. Let ")#mi("{0 < p_0,p_1 \\leq \\infty}")#text(", ")#mi("{1 < q_0,q_1 \\leq \\infty}")#text(" and ")#mi("{A_0,A_1 > 0}")#text(" be such that ")#mi("{T}")#text(" is restricted weak-type ")#mi("{(p_i,q_i)}")#text(" with constant ")#mi("{A_i}")#text(" (in the sense of ")#link(<tao-160b648003f5084f0f43>)[#text("(25)")]#text(") for ")#mi("{i=0,1}")#text(". Then ")#mi("{T}")#text(" is also restricted weak-type ")#mi("{(p_\\theta,q_\\theta)}")#text(" with constant ")#mi("{A_\\theta}")#text(" for ")#mi("{0 \\leq \\theta \\leq 1}")#text(", where")

#metadata(none) <tao-45b182f566f2efb3077f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\frac{1}{p_\\theta} := \\frac{1-\\theta}{p_0} + \\frac{\\theta}{p_1}; \\quad \\frac{1}{q_\\theta} := \\frac{1-\\theta}{q_0} + \\frac{\\theta}{q_1}; A_\\theta := A_0^{1-\\theta} A_1^\\theta")]]

#text("and the implied constant depends on ")#mi("{p_0,p_1,q_0,q_1}")#text(".")
]

#text("Indeed, all we are using here is the obvious algebraic observation that if ")#mi("{X \\lesssim Y_0}")#text(" and ")#mi("{X \\lesssim Y_1}")#text(", then ")#mi("{X \\lesssim Y_\\theta := Y_0^{1-\\theta} Y_1^\\theta}")#text(" for all ")#mi("{0 \\leq \\theta \\leq 1}")#text(".")

#text("The above corollary has two defects. Firstly, it can only conclude restricted weak-type rather than strong type. Secondly, the restriction ")#mi("{q_0, q_1 > 1}")#text(" is inconvenient for many applications, since weak ")#mi("{L^{1,\\infty}}")#text(" bounds are actually rather common. To address the second concern, we have the following variant of Exercise ")#link(<tao-0c5245f4ec183c41851a>)[#text("48")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 50")]#text(" Let ")#mi("{0 < p \\leq \\infty}")#text(", ")#mi("{0 < q \\leq \\infty}")#text(", and ")#mi("{A > 0}")#text(". Let ")#mi("{T}")#text(" be a sublinear operator such that the form ")#link(<tao-0a8125a9f9ab79e4a5bc>)[#text("(23)")]#text(" is well-defined. Then the following are equivalent up to changes in the implied constant:")

#list(
[#mi("{T}")#text(" is restricted weak-type ")#mi("{(p,q)}")#text(" with constant ")#mi("{A}")#text(", in the sense that ")#link(<tao-160b648003f5084f0f43>)[#text("(25)")]#text(" holds.")],
[#text("For all ")#mi("{E \\subset X}")#text(", ")#mi("{F \\subset Y}")#text(" of finite non-zero measure, there exists ")#mi("{F^{\\prime} \\subset F}")#text(" with ")#mi("{\\mu(F^{\\prime}) \\geq \\frac{1}{2} \\mu(F)}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\langle \\left|T1_E\\right|, 1_{F^{\\prime}} \\rangle \\lesssim_{p,q} A \\mu(E)^{1/p} \\nu(F)^{1/q^{\\prime}}", block: true)]]]
)

#text("Hint: use Exercise ")#link(<tao-26eab90d2b0be7cd1889>)[#text("37")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 51")]#text(" ")#metadata(none) <tao-79eb3df96eaf299e1891>#text(" The hypothesis ")#mi("{q_0,q_1 > 1}")#text(" in Corollary ")#link(<tao-d864124834f9d01a1107>)[#text("49")]#text(" can be weakened to ")#mi("{q_0,q_1 > 0}")#text(".")
]

#text("Now we can give a significantly more useful real interpolation theorem, which can interpolate between restricted weak-type estimates to obtain strong-type estimates.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 52 (Marcinkiewicz interpolation theorem)")]#text(" Let ")#mi("{T}")#text(" be a sublinear operator such that the form ")#link(<tao-0a8125a9f9ab79e4a5bc>)[#text("(23)")]#text(" is well-defined. Let ")#mi("{0 < p_0,p_1 \\leq \\infty}")#text(", ")#mi("{0 < q_0,q_1 \\leq \\infty}")#text(" and ")#mi("{A_0,A_1 > 0}")#text(" be such that ")#mi("{T}")#text(" is restricted weak-type ")#mi("{(p_i,q_i)}")#text(" with constant ")#mi("{A_i}")#text(" (in the sense of ")#link(<tao-160b648003f5084f0f43>)[#text("(25)")]#text(") for ")#mi("{i=0,1}")#text(". Suppose also that ")#mi("{p_0 \\neq p_1}")#text(" and ")#mi("{q_0 \\neq q_1}")#text(". Then for any ")#mi("{0 < \\theta < 1}")#text(" and ")#mi("{1 \\leq r \\leq \\infty}")#text(" with ")#mi("{q_\\theta > 1}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Tf \\right\\|_{L^{q_\\theta,r}(Y)} \\lesssim_{p_0,p_1,q_0,q_1,r,\\theta} A_\\theta \\left\\| f \\right\\|_{L^{p_\\theta,r}(X)}", block: true)]]

#text("for all simple functions ")#mi("{f}")#text(" with finite measure support, where ")#mi("{p_\\theta, q_\\theta, A}")#text(" were defined in ")#link(<tao-45b182f566f2efb3077f>)[#text("(26)")]#text(". In particular, if ")#mi("{q_\\theta \\geq p_\\theta}")#text(", then ")#mi("{T}")#text(" is strong-type ")#mi("{(p_\\theta,q_\\theta)}")#text(" with constant ")#mi("{O_{p_0,p_1,q_1,\\theta}(A_\\theta)}")#text(".")
]

#emph[#text("Proof:")]#text(" To simplify the notation let us suppress the dependence on ")#mi("{p_0,p_1,q_0,q_1,r,\\theta}")#text(". Observe that the statement and conclusion of the theorem have several homogeneity symmetries. The most obvious one is that we can multiply ")#mi("{T}")#text(" (and the ")#mi("{A_\\theta}")#text(") by an arbitrary constant, but we may also multiply the measure ")#mi("{\\mu}")#text(" by a constant ")#mi("{C}")#text(" (and the ")#mi("{A_\\theta}")#text(" by the constant ")#mi("{C^{-1/p_\\theta}}")#text("); similarly we may multiply ")#mi("{\\nu}")#text(" by ")#mi("{C}")#text(" and ")#mi("{A_\\theta}")#text(" by ")#mi("{C^{1/q_\\theta}}")#text("). Using these symmetries we may normalise ")#mi("{A_0=A_1=1}")#text(" (and hence ")#mi("{A_\\theta = 1}")#text(" for all ")#mi("{\\theta}")#text("). Our task is then to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Tf \\right\\|_{L^{q_\\theta,r}(Y)} \\lesssim \\left\\| f \\right\\|_{L^{p_\\theta,r}(X)}", block: true)]]

#text("for all simple functions ")#mi("{f}")#text(" with finite measure support.")

#text("Using Theorem ")#link(<tao-95b3667a66d21c2aca2a>)[#text("39")]#text(" (and the hypothesis ")#mi("{q_\\theta > 1}")#text("), this is equivalent to showing that ")#metadata(none) <tao-8b13882cdab851e87f5e>#tao-math("\\displaystyle  \\langle \\left|Tf\\right|, \\left|g\\right| \\rangle \\lesssim \\left\\| f \\right\\|_{L^{p_\\theta,r}(X)} \\left\\| g \\right\\|_{L^{q^{\\prime}_\\theta,r^{\\prime}}(Y)} \\ \\ \\ \\ \\ (27)", block: false)#text(" ")#text(" for all simple functions ")#mi("{f,g}")#text(" of finite measure support.")

#text("We currently have ")#mi("{q_0,q_1 > 0}")#text(" and ")#mi("{q_\\theta > 1}")#text(". By using Corollary ")#link(<tao-79eb3df96eaf299e1891>)[#text("51")]#text(" to bring the restricted weak-type exponents ")#mi("{(p_0,q_0)}")#text(" and ")#mi("{(p_1,q_1)}")#text(" a bit closer to ")#mi("{(p_\\theta,q_\\theta)}")#text(" we may assume that ")#mi("{q_0,q_1 > 1}")#text(" as well. Applying Exercise ")#link(<tao-0c5245f4ec183c41851a>)[#text("48")]#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\langle \\left|T1_E\\right|, 1_F \\rangle \\lesssim \\left|E\\right|^{1/p_i} \\left|F\\right|^{1/q^{\\prime}_i}", block: true)]]

#text("for all sets ")#mi("{E, F}")#text(" of finite measure and ")#mi("{i=0,1}")#text(". From Remark ")#link(<tao-9a3a45d01531a20e89ac>)[#text("27")]#text(" and sublinearity we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\langle \\left|Tf\\right|, \\left|g\\right| \\rangle \\lesssim H W^{1/p_i} H^{\\prime} (W^{\\prime})^{1/q^{\\prime}_i}", block: true)]]

#text("whenever ")#mi("{f,g}")#text(" are sub-step functions of height and widths ")#mi("{H,H^{\\prime}}")#text(" and ")#mi("{W,W^{\\prime}}")#text(" respectively. We can of course pick the better of the two estimates, leading to")

#metadata(none) <tao-3cb8201e7ff1e7777446>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#tao-math("\\langle \\left|Tf\\right|, \\left|g\\right| \\rangle \\lesssim H H^{\\prime} \\min_{i=0,1}( W^{1/p_i} (W^{\\prime})^{1/q^{\\prime}_i} ).", block: true)]]

#text("Now we can return to proving ")#link(<tao-8b13882cdab851e87f5e>)[#text("(27)")]#text(". By homogeneity we may normalise")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{L^{p_\\theta,r}(X)} = \\left\\| g \\right\\|_{L^{q^{\\prime}_\\theta,r^{\\prime}}(Y)} = 1.", block: true)]]

#text("We then apply Theorem ")#link(<tao-411b0496da5eeced5314>)[#text("28")]#text(" to decompose ")#mi("{f = \\sum_{n \\in {\\bf Z}} f_n}")#text(", ")#mi("{g = \\sum_{n \\in {\\bf Z}} g_n}")#text(" with ")#mi("{f_n, g_n}")#text(" sub-step functions of width ")#mi("{2^n}")#text(" and heights ")#mi("{H_n, H^{\\prime}_n}")#text(" respectively, with the height bounds")

#metadata(none) <tao-2e6839f29b1ea4ae7bed>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#tao-math("\\left\\| a \\right\\|_{l^r({\\bf Z})}, \\left\\| b \\right\\|_{l^{r^{\\prime}}({\\bf Z})} \\lesssim 1", block: true)]]

#text("where ")#mi("{a,b}")#text(" are the sequences")

#align(center)[#tao-fit-display[#mitex("a_n := H_n 2^{n/p_\\theta}; \\quad b_n := H^{\\prime}_n 2^{n/q^{\\prime}_\\theta}.")]]

#text("Since ")#mi("{f,g}")#text(" are simple functions, only finitely many of the ")#mi("{f_n}")#text(" and ")#mi("{g_n}")#text(" are non-zero by Remark ")#link(<tao-a383bcb77c832a8ff52c>)[#text("30")]#text(". We now use sublinearity to estimate")

#align(center)[#tao-fit-display[#tao-math("\\langle \\left|Tf\\right|, \\left|g\\right| \\rangle \\leq \\sum_{n,m} \\langle \\left|Tf_n\\right|, \\left|g_m\\right| \\rangle", block: true)]]

#text("and then use ")#link(<tao-3cb8201e7ff1e7777446>)[#text("(28)")]#text(" to obtain")

#align(center)[#tao-fit-display[#tao-math("\\langle \\left|Tf\\right|, \\left|g\\right| \\rangle \\lesssim \\sum_{n,m} H_n H^{\\prime}_m \\min_{i=0,1} ( 2^{n/p_i} 2^{m/q^{\\prime}_i} ).", block: true)]]

#text("We can write this in terms of ")#mi("{a}")#text(", ")#mi("{b}")#text(", and reduce to showing that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n,m} a_n b_m \\min_{i=0,1}( 2^{n (\\frac{1}{p_i}-\\frac{1}{p_\\theta})} 2^{m (\\frac{1}{q_\\theta} - \\frac{1}{q_i})} ) \\lesssim 1.")]]

#text("Because ")#mi("{p_0 \\neq p_1}")#text(" and ")#mi("{q_0 \\neq q_1}")#text(", and because of the definitions of ")#mi("{p_\\theta, q_\\theta}")#text(", we can write the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n,m} a_n b_m \\min( 2^{\\varepsilon(n+\\alpha m)}, 2^{-\\varepsilon^{\\prime}(n+\\alpha m)} )")]]

#text("for some non-zero ")#mi("{\\alpha \\in {\\bf R}}")#text(" and some ")#mi("{\\varepsilon,\\varepsilon^{\\prime} > 0}")#text(" depending only on ")#mi("{p_0,p_1,q_0,q_1,\\theta}")#text(". We substitute ")#mi("{k := \\lfloor n + \\alpha m \\rfloor}")#text(" (thus ")#mi("{n = k - \\lfloor \\alpha m \\rfloor}")#text(") and estimate this by")

#align(center)[#tao-fit-display[#mitex("\\sum_k \\min( 2^{\\varepsilon k}, 2^{-\\varepsilon k} ) \\sum_{m} a_{k - \\lfloor \\alpha m \\rfloor} b_m.")]]

#text("By ")#link(<tao-2e6839f29b1ea4ae7bed>)[#text("(29)")]#text(" and Hölder we see that the inner sum is ")#mi("{O(1)}")#text(" uniformly in ")#mi("{k}")#text(", and the claim follows.")

#text("Finally, if we specialise ")#mi("{r = q_\\theta}")#text(" and recall that the ")#mi("{L^{p_\\theta,q_\\theta}}")#text(" norm will be dominated by the ")#mi("{L^{p_\\theta}}")#text(" norm for ")#mi("{p_\\theta \\geq q_\\theta}")#text(", the last claim of the theorem follows. ")#mi("\\Box")

#text("There are many other variations on the real interpolation method, for instance an extension to multilinear operators, or to other function spaces. However, the basic method of proof is still the same: dualise, decompose all inputs, estimate each term as optimally as one can, and then sum.")

#text("One can illustrate the real interpolation method graphically using ")#emph[#text("type diagrams")]#text(". One plots all points ")#mi("{(\\frac{1}{p}, \\frac{1}{q})}")#text(" where the operator ")#mi("{T}")#text(" is strong-type ")#mi("{(p,q)}")#text(" or restricted weak-type ")#mi("{(p,q)}")#text(". Ignoring some of the technical hypotheses, the above interpolation theorems then essentially assert that the restricted weak-type diagram and strong-type diagrams are both convex, with the latter contained in the former. Furthermore, if two points lie in the former, then the open interval connecting them lies in the latter. Determining the type diagrams of various operators ")#mi("{T}")#text(" is a basic task of harmonic analysis, as it conveys a lot of information as to how ")#mi("{T}")#text(" transforms the width and height of functions.")

#text("There is a different interpolation method, the ")#emph[#text("complex interpolation method")]#text(", which offers similar results to the real interpolation method but with some slight differences. On the plus side, the complex interpolation method gives sharper bounds, and more importantly can handle the case where the operator ")#mi("{T}")#text(" itself varies (analytically) with the interpolation parameter. On the minus side, the method cannot upgrade weak or restricted weak-type estimates to strong-type estimates.")

#text("In the next set of notes we shall present several applications of the real interpolation method.")

#heading(level: 1)[#strong[#text(" — 5. Miscellaneous exercises — ")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 53 (Loomis-Whitney inequality)")]#text(" Let ")#mi("{d \\geq 2}")#text(", let ")#mi("{X_1,\\ldots,X_d}")#text(" be measure spaces, and for ")#mi("{i=1,\\ldots,d}")#text(" let ")#mi("{f_i \\in L^p(\\prod_{1 \\leq j \\leq d: j \\neq i} X_j)}")#text(" for some ")#mi("{0 < p \\leq \\infty}")#text(". Show that the function")

#align(center)[#tao-fit-display[#mitex("F(x_1,\\ldots,x_d) := \\prod_{i=1}^d f_i( x_1,\\ldots,x_{i-1},x_{i+1},\\ldots,x_d)")]]

#text("lies in ")#mi("{L^{p/(d-1)}(\\prod_{1 \\leq j \\leq d} X_j)}")#text(" with the ")#emph[#text("Loomis-Whitney inequality")]

#align(center)[#tao-fit-display[#tao-math("\\left\\|F\\right\\|_{L^{p/(d-1)}(\\prod_{1 \\leq j \\leq d} X_j)} \\leq \\prod_{i=1}^d \\left\\| f_i \\right\\|_{L^p(\\prod_{1 \\leq j \\leq d: j \\neq i} X_j)}.", block: true)]]

#text("Conclude in particular the ")#emph[#text("box inequality")]

#align(center)[#tao-fit-display[#mitex("\\mu_{\\prod_{1 \\leq j \\leq d} X_j}(E) \\leq (\\prod_{i=1}^d \\mu_{\\prod_{1 \\leq j \\leq d: j \\neq i}}( \\pi_i(E) ))^{1/(d-1)}")]]

#text("where ")#mi("{E}")#text(" is any subset of ")#mi("{\\prod_{1 \\leq j \\leq d} X_j}")#text(" and ")#mi("{\\pi_i}")#text(" is the canonical projection from ")#mi("{\\prod_{1 \\leq j \\leq d} X_j}")#text(" to ")#mi("{\\prod_{1 \\leq j \\leq d: j \\neq i} X_j}")#text(". From this, deduce the ")#emph[#text("weak isoperimetric inequality")]

#align(center)[#tao-fit-display[#tao-math("\\left|E\\right| \\lesssim_d \\left|\\partial E\\right|^{d/(d-1)}", block: true)]]

#text("for any ")#mi("{E \\subset {\\bf R}^d}")#text(", where ")#tao-math("{\\left|E\\right|}", block: false)#text(" is the Lebesgue measure of ")#mi("{E}")#text(" and ")#tao-math("{\\left|\\partial E\\right|}", block: false)#text(" is the ")#mi("{d-1}")#text("-dimensional Hausdorff measure of the boundary of ")#mi("{E}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 54 (Borel-Cantelli lemma for functions)")]#text(" Let ")#mi("{f_1, f_2, \\ldots \\in L^1(X)}")#text(" be such that ")#tao-math("{\\sum_{n=1}^\\infty \\left\\|f_n\\right\\|_{L^1(X)} < \\infty}", block: false)#text(". Show that ")#mi("{f_n}")#text(" converges to zero pointwise almost everywhere.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 55 (Borel-Cantelli lemma for sets)")]#text(" Let ")#mi("{E_1, E_2, \\ldots \\subset X}")#text(" be such that ")#mi("{\\sum_{n=1}^\\infty \\mu(E_n) < \\infty}")#text(". Show that almost every ")#mi("{x \\in X}")#text(" is contained in only finitely many of the ")#mi("{E_n}")#text(".")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/20/247a-notes-1-rearrangement-invariant-spaces/#comment-695905")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("Thanks for writing this! What prerequisites are for the course, and are there any references?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/20/247a-notes-1-rearrangement-invariant-spaces/#comment-695915")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("you being overworked is not good for ucla. Is there a possibility you can get an AI (actual intelligence) assistant who you can offload work? I understand it would be non standard to get a phd level assistant but thereight be people interested in the gig and who have math phd.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/20/247a-notes-1-rearrangement-invariant-spaces/#comment-695931")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Hello Terry,")

#text("in equations (8), (16) and (26), the equation number gets lost because they are too long.")

#text("A typo in Example 1: It should say “this function has magnitude ~A” instead of R.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ff6e675aff93d5e735e5ffd00d72d9a65cd62a828bc2999f528613f91bf2f128-da8b631fc55c2bed84eb587567929f0c1c419e111a22234426673ac5703b5e3c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guillaume Aubrun")]], [#link("https://terrytao.wordpress.com/2026/09/20/247a-notes-1-rearrangement-invariant-spaces/#comment-696089")[#strong[#text("Guillaume Aubrun")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Dear Terry,")

#text("the result by Melas to which you refer and which involves the value $(11+\\sqrt{61})/2$ is about the weak (1,1) inequality for the centered maximal function operator in one dimension and not the L^2 inequality.")

#text("Actually, the best constant in the L^p inequality for the same operator is also known. It equals p/(p-1) and this is a very recent result by Madrid, see ")#link("https://arxiv.org/abs/2609.12440")[#text("https://arxiv.org/abs/2609.12440")]

#text("Guillaume")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b296978a6e701ae03f8128438d3422c2b557c0a042b2298e2ece4fa70006c22d-eba25498d8c6779fa91a3d405aec64e18ff513e377824427cdccdc187f818290.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guillaume Aubrun")]], [#link("https://terrytao.wordpress.com/2026/09/20/247a-notes-1-rearrangement-invariant-spaces/#comment-696112")[#strong[#text("Guillaume Aubrun")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Also, there is a typo in Melas’s result, it should be ")#mi("(11+\\\\sqrt{61})/12")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/20/247a-notes-1-rearrangement-invariant-spaces/#comment-696111")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Exercise 55: Should the series be assumed to be finite rather than 0? (Or did you intend to close by a trivial exercise?)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab701ecebc9397e2c794acb4f86064bf2fb14961c633c9374002f9686868d2e4-f5dfb9c341b0a5739fbb9c680846b55acc1e67462966fce22f05ffc0101433ab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valiantly245f650684")]], [#link("https://terrytao.wordpress.com/2026/09/20/247a-notes-1-rearrangement-invariant-spaces/#comment-696125")[#strong[#text("valiantly245f650684")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Finally a math post that is not about discussing AI")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/20/247a-notes-1-rearrangement-invariant-spaces/#comment-696501")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2026")])]

#text("Hello,")

#text("Could common reconstruction geometry be useful for the decompositions considered here? For example, let")

#text("Tⱼ = Sₙ Pⱼ Sₙ⁻¹,")

#text("where Pⱼ are coordinate projections and the reconstruction maps satisfy")

#text("‖Sₙ‖ · ‖Sₙ⁻¹‖ ≤ C,")

#text("with the same constant C for every N. Then")

#text("‖c₁T₁ + c₂T₂ + ⋯ + cₙTₙ‖ ≤ C whenever |cⱼ| ≤ 1,")

#text("even when the absolute pairwise-interaction estimates grow with N.")

#text("Is there scope for exploiting that relationship in the operator families arising in the course?")

#text("Regards")

#text("Joe White")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/20/247a-notes-1-rearrangement-invariant-spaces/#comment-696554")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("Are there applications of harmonic analysis in differential geometry?")
]
